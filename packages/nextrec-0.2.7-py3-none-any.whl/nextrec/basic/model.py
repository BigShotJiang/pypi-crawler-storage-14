"""
Base Model & Base Match Model Class

Date: create on 27/10/2025
Author: Yang Zhou,zyaztec@gmail.com
"""

import os
import tqdm
import pickle
import logging
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

from pathlib import Path
from typing import Union, Literal, Any
from torch.utils.data import DataLoader

from nextrec.basic.callback import EarlyStopper
from nextrec.basic.features import DenseFeature, SparseFeature, SequenceFeature, FeatureSpecMixin
from nextrec.basic.metrics import configure_metrics, evaluate_metrics

from nextrec.loss import get_loss_fn, get_loss_kwargs
from nextrec.data import get_column_data, collate_fn
from nextrec.data.dataloader import TensorDictDataset, build_tensors_from_data
from nextrec.basic.loggers import setup_logger, colorize
from nextrec.utils import get_optimizer, get_scheduler
from nextrec.basic.session import resolve_save_path, create_session
from nextrec.basic.metrics import CLASSIFICATION_METRICS, REGRESSION_METRICS
from nextrec import __version__

class BaseModel(FeatureSpecMixin, nn.Module):
    @property
    def model_name(self) -> str:
        raise NotImplementedError
    
    @property
    def task_type(self) -> str:
        raise NotImplementedError

    def __init__(self, 
                 dense_features: list[DenseFeature] | None = None, 
                 sparse_features: list[SparseFeature] | None = None, 
                 sequence_features: list[SequenceFeature] | None = None,
                 target: list[str] | str | None = None,
                 id_columns: list[str] | str | None = None,
                 task: str|list[str] = 'binary',
                 device: str = 'cpu',
                 embedding_l1_reg: float = 0.0,
                 dense_l1_reg: float = 0.0,
                 embedding_l2_reg: float = 0.0, 
                 dense_l2_reg: float = 0.0,
                 early_stop_patience: int = 20, 
                 session_id: str | None = None,): 
        
        super(BaseModel, self).__init__()

        try:
            self.device = torch.device(device)
        except Exception as e:
            logging.warning("Invalid device , defaulting to CPU.")
            self.device = torch.device('cpu')

        self.session_id = session_id
        self.session = create_session(session_id)
        self.session_path = self.session.root # pwd/session_id, path for this session
        self.checkpoint_path = os.path.join(self.session_path, self.model_name+"_checkpoint"+".model")
        self.best_path = os.path.join(self.session_path, self.model_name+ "_best.model")
        self.features_config_path = os.path.join(self.session_path, "features_config.pkl")
        self._set_feature_config(dense_features, sparse_features, sequence_features, target, id_columns)
        self.target = self.target_columns
        self.target_index = {target_name: idx for idx, target_name in enumerate(self.target)}

        self.task = task
        self.nums_task = len(task) if isinstance(task, list) else 1

        self._embedding_l1_reg = embedding_l1_reg
        self._dense_l1_reg = dense_l1_reg
        self._embedding_l2_reg = embedding_l2_reg
        self._dense_l2_reg = dense_l2_reg
        self._regularization_weights = [] 
        self._embedding_params = []
        self._early_stop_patience = early_stop_patience
        self._max_gradient_norm = 1.0   
        self._logger_initialized = False

    def _register_regularization_weights(self, embedding_attr: str = "embedding", exclude_modules: list[str] | None = None, include_modules: list[str] | None = None) -> None:
        exclude_modules = exclude_modules or []
        include_modules = include_modules or []
        if hasattr(self, embedding_attr):
            embedding_layer = getattr(self, embedding_attr)
            if hasattr(embedding_layer, "embed_dict"):
                for embed in embedding_layer.embed_dict.values():
                    self._embedding_params.append(embed.weight)
        for name, module in self.named_modules():
            if module is self:
                continue
            if embedding_attr in name:
                continue
            if isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, nn.Dropout, nn.Dropout2d, nn.Dropout3d),):
                continue
            if include_modules:
                if not any(inc_name in name for inc_name in include_modules):
                    continue
            if any(exc_name in name for exc_name in exclude_modules):
                continue
            if isinstance(module, nn.Linear):
                self._regularization_weights.append(module.weight)

    def add_reg_loss(self) -> torch.Tensor:
        reg_loss = torch.tensor(0.0, device=self.device)
        if self._embedding_params:
            if self._embedding_l1_reg > 0:
                reg_loss += self._embedding_l1_reg * sum(param.abs().sum() for param in self._embedding_params)
            if self._embedding_l2_reg > 0:
                reg_loss += self._embedding_l2_reg * sum((param ** 2).sum() for param in self._embedding_params)
        if self._regularization_weights:
            if self._dense_l1_reg > 0:
                reg_loss += self._dense_l1_reg * sum(param.abs().sum() for param in self._regularization_weights)
            if self._dense_l2_reg > 0:
                reg_loss += self._dense_l2_reg * sum((param ** 2).sum() for param in self._regularization_weights)
        return reg_loss

    def _to_tensor(self, value, dtype: torch.dtype) -> torch.Tensor:        
        tensor = value if isinstance(value, torch.Tensor) else torch.as_tensor(value)
        if tensor.dtype != dtype:
            tensor = tensor.to(dtype=dtype)
        if tensor.device != self.device:
            tensor = tensor.to(self.device)
        return tensor

    def get_input(self, input_data: dict, require_labels: bool = True):
        feature_source = input_data.get("features", {})
        label_source = input_data.get("labels")
        X_input = {}
        for feature in self.all_features:
            if feature.name not in feature_source:
                raise KeyError(f"Feature '{feature.name}' not found in input data.")
            feature_data = get_column_data(feature_source, feature.name)
            dtype = torch.float32 if isinstance(feature, DenseFeature) else torch.long
            X_input[feature.name] = self._to_tensor(feature_data, dtype=dtype)
        y = None
        if (len(self.target) > 0 and (require_labels or (label_source and any(name in label_source for name in self.target)))): # need labels: training or eval with labels
            target_tensors = []
            for target_name in self.target:
                if label_source is None or target_name not in label_source:
                    if require_labels:
                        raise KeyError(f"Target column '{target_name}' not found in input data.")
                    continue
                target_data = get_column_data(label_source, target_name)
                if target_data is None:
                    if require_labels:
                        raise ValueError(f"Target column '{target_name}' contains no data.")
                    continue
                target_tensor = self._to_tensor(target_data, dtype=torch.float32)
                target_tensor = target_tensor.view(target_tensor.size(0), -1)
                target_tensors.append(target_tensor)
            if target_tensors:
                y = torch.cat(target_tensors, dim=1)
                if y.shape[1] == 1:
                    y = y.view(-1)
            elif require_labels:
                raise ValueError("Labels are required but none were found in the input batch.")
        return X_input, y

    def _set_metrics(self, metrics: list[str] | dict[str, list[str]] | None = None):
        self.metrics, self.task_specific_metrics, self.best_metrics_mode = configure_metrics(task=self.task, metrics=metrics, target_names=self.target) # ['auc', 'logloss'], {'target1': ['auc', 'logloss'], 'target2': ['mse']}, 'max'
        self.early_stopper = EarlyStopper(patience=self._early_stop_patience, mode=self.best_metrics_mode)

    def _handle_validation_split(self, train_data: dict | pd.DataFrame, validation_split: float, batch_size: int, shuffle: bool,) -> tuple[DataLoader, dict | pd.DataFrame]:
        if not (0 < validation_split < 1):
            raise ValueError(f"validation_split must be between 0 and 1, got {validation_split}")
        if not isinstance(train_data, (pd.DataFrame, dict)):
            raise TypeError(f"train_data must be a pandas DataFrame or a dict, got {type(train_data)}")
        if isinstance(train_data, pd.DataFrame):
            total_length = len(train_data)
        else:
            sample_key = next(iter(train_data))
            total_length = len(train_data[sample_key])
            for k, v in train_data.items():
                if len(v) != total_length:
                    raise ValueError(f"Length of field '{k}' ({len(v)}) != length of field '{sample_key}' ({total_length})")
        rng = np.random.default_rng(42)
        indices = rng.permutation(total_length)
        split_idx = int(total_length * (1 - validation_split))
        train_indices = indices[:split_idx]
        valid_indices = indices[split_idx:]
        if isinstance(train_data, pd.DataFrame):
            train_split = train_data.iloc[train_indices].reset_index(drop=True)
            valid_split = train_data.iloc[valid_indices].reset_index(drop=True)
        else:
            train_split = {}
            valid_split = {}
            for key, value in train_data.items():
                if isinstance(value, np.ndarray):
                    train_split[key] = value[train_indices]
                    valid_split[key] = value[valid_indices]
                elif isinstance(value, (list, tuple)):
                    arr = np.asarray(value)
                    train_split[key] = arr[train_indices].tolist()
                    valid_split[key] = arr[valid_indices].tolist()
                elif isinstance(value, pd.Series):
                    train_split[key] = value.iloc[train_indices].values
                    valid_split[key] = value.iloc[valid_indices].values
                else:
                    train_split[key] = [value[i] for i in train_indices]
                    valid_split[key] = [value[i] for i in valid_indices]
        train_loader = self._prepare_data_loader(train_split, batch_size=batch_size, shuffle=shuffle)
        logging.info(f"Split data: {len(train_indices)} training samples, {len(valid_indices)} validation samples")
        return train_loader, valid_split

    def compile(
        self, optimizer="adam", optimizer_params: dict | None = None,
        scheduler: str | torch.optim.lr_scheduler._LRScheduler | type[torch.optim.lr_scheduler._LRScheduler] | None = None, scheduler_params: dict | None = None,
        loss: str | nn.Module | list[str | nn.Module] | None = "bce", loss_params: dict | list[dict] | None = None,):
        optimizer_params = optimizer_params or {}
        self._optimizer_name = optimizer if isinstance(optimizer, str) else optimizer.__class__.__name__
        self._optimizer_params = optimizer_params
        self.optimizer_fn = get_optimizer(optimizer=optimizer, params=self.parameters(), **optimizer_params,)

        scheduler_params = scheduler_params or {}
        if isinstance(scheduler, str):
            self._scheduler_name = scheduler
        elif scheduler is None:
            self._scheduler_name = None
        else:
            self._scheduler_name = getattr(scheduler, "__name__", scheduler.__class__.__name__)
        self._scheduler_params = scheduler_params
        self.scheduler_fn = (get_scheduler(scheduler, self.optimizer_fn, **scheduler_params) if scheduler else None)

        self._loss_config = loss
        self._loss_params = loss_params or {}
        self.loss_fn = []
        for i in range(self.nums_task):
            if isinstance(loss, list):
                loss_value = loss[i] if i < len(loss) else None
            else:
                loss_value = loss
            if self.nums_task == 1: # single task
                loss_kwargs = self._loss_params if isinstance(self._loss_params, dict) else self._loss_params[0]
            else:
                loss_kwargs = self._loss_params if isinstance(self._loss_params, dict) else (self._loss_params[i] if i < len(self._loss_params) else {})
            self.loss_fn.append(get_loss_fn(loss=loss_value, **loss_kwargs,))

    def compute_loss(self, y_pred, y_true):
        if y_true is None:
            raise ValueError("Ground truth labels (y_true) are required to compute loss.")
        if self.nums_task == 1:
            loss = self.loss_fn[0](y_pred, y_true)
            return loss
        else:
            task_losses = []
            for i in range(self.nums_task):
                task_loss = self.loss_fn[i](y_pred[:, i], y_true[:, i])
                task_losses.append(task_loss)
            return torch.stack(task_losses)

    def _prepare_data_loader(self, data: dict | pd.DataFrame | DataLoader, batch_size: int = 32, shuffle: bool = True,):
        if isinstance(data, DataLoader):
            return data
        tensors = build_tensors_from_data(data=data, raw_data=data, features=self.all_features, target_columns=self.target, id_columns=self.id_columns,)
        if tensors is None:
            raise ValueError("No data available to create DataLoader.")
        dataset = TensorDictDataset(tensors)
        return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, collate_fn=collate_fn)

    def _batch_to_dict(self, batch_data: Any, include_ids: bool = True) -> dict:
        if not (isinstance(batch_data, dict) and "features" in batch_data):
            raise TypeError("Batch data must be a dict with 'features' produced by the current DataLoader.")
        return {
            "features": batch_data.get("features", {}),
            "labels": batch_data.get("labels"),
            "ids": batch_data.get("ids") if include_ids else None,
        }

    def fit(self, 
            train_data: dict|pd.DataFrame|DataLoader, 
            valid_data: dict|pd.DataFrame|DataLoader|None=None, 
            metrics: list[str]|dict[str, list[str]]|None = None, # ['auc', 'logloss'] or {'target1': ['auc', 'logloss'], 'target2': ['mse']}
            epochs:int=1, shuffle:bool=True, batch_size:int=32,
            user_id_column: str = 'user_id',
            validation_split: float | None = None):
        self.to(self.device)
        if not self._logger_initialized:
            setup_logger(session_id=self.session_id)
            self._logger_initialized = True
        self._set_metrics(metrics) # add self.metrics, self.task_specific_metrics, self.best_metrics_mode, self.early_stopper
        self.summary()
        valid_loader = None
        valid_user_ids: np.ndarray | None = None
        needs_user_ids: bool = self._needs_user_ids_for_metrics()

        if validation_split is not None and valid_data is None:
            train_loader, valid_data = self._handle_validation_split(
                train_data=train_data, # type: ignore
                validation_split=validation_split, batch_size=batch_size, shuffle=shuffle,)
        else:
            train_loader = (train_data if isinstance(train_data, DataLoader) else self._prepare_data_loader(train_data, batch_size=batch_size, shuffle=shuffle))
        if isinstance(valid_data, DataLoader):
            valid_loader = valid_data
        elif valid_data is not None:
            valid_loader = self._prepare_data_loader(valid_data, batch_size=batch_size, shuffle=False)
            if needs_user_ids:
                if isinstance(valid_data, pd.DataFrame) and user_id_column in valid_data.columns:
                    valid_user_ids = np.asarray(valid_data[user_id_column].values)
                elif isinstance(valid_data, dict) and user_id_column in valid_data:
                    valid_user_ids = np.asarray(valid_data[user_id_column])
        try:
            self._steps_per_epoch = len(train_loader)
            is_streaming = False
        except TypeError: # len() not supported, e.g., streaming data loader
            self._steps_per_epoch = None
            is_streaming = True

        self._epoch_index = 0
        self._stop_training = False
        self._best_checkpoint_path = self.best_path
        self._best_metric = float('-inf') if self.best_metrics_mode == 'max' else float('inf')
        
        logging.info("")
        logging.info(colorize("=" * 80, bold=True))
        if is_streaming:
            logging.info(colorize(f"Start streaming training", bold=True))
        else:
            logging.info(colorize(f"Start training", bold=True))
        logging.info(colorize("=" * 80, bold=True))
        logging.info("")
        logging.info(colorize(f"Model device: {self.device}", bold=True))
    
        for epoch in range(epochs):
            self._epoch_index = epoch
            if is_streaming:
                logging.info("")
                logging.info(colorize(f"Epoch {epoch + 1}/{epochs}", bold=True)) # streaming mode, print epoch header before progress bar
            train_result = self.train_epoch(train_loader, is_streaming=is_streaming)
            if isinstance(train_result, tuple):
                train_loss, train_metrics = train_result
            else:
                train_loss = train_result
                train_metrics = None
            if self.nums_task == 1:
                log_str = f"Epoch {epoch + 1}/{epochs} - Train: loss={train_loss:.4f}"
                if train_metrics:
                    metrics_str = ", ".join([f"{k}={v:.4f}" for k, v in train_metrics.items()])
                    log_str += f", {metrics_str}"
                logging.info(colorize(log_str, color="white"))
            else:
                task_labels = []
                for i in range(self.nums_task):
                    if i < len(self.target):
                        task_labels.append(self.target[i])
                    else:
                        task_labels.append(f"task_{i}")
                
                total_loss_val = np.sum(train_loss) if isinstance(train_loss, np.ndarray) else train_loss  # type: ignore
                log_str = f"Epoch {epoch + 1}/{epochs} - Train: loss={total_loss_val:.4f}"
                
                if train_metrics:
                    # Group metrics by task
                    task_metrics = {}
                    for metric_key, metric_value in train_metrics.items():
                        for target_name in self.target:
                            if metric_key.endswith(f"_{target_name}"):
                                if target_name not in task_metrics:
                                    task_metrics[target_name] = {}
                                metric_name = metric_key.rsplit(f"_{target_name}", 1)[0]
                                task_metrics[target_name][metric_name] = metric_value
                                break
                    
                    if task_metrics:
                        task_metric_strs = []
                        for target_name in self.target:
                            if target_name in task_metrics:
                                metrics_str = ", ".join([f"{k}={v:.4f}" for k, v in task_metrics[target_name].items()])
                                task_metric_strs.append(f"{target_name}[{metrics_str}]")
                        log_str += ", " + ", ".join(task_metric_strs)
                logging.info(colorize(log_str, color="white"))
        
            if valid_loader is not None:
                # Pass user_ids only if needed for GAUC metric
                val_metrics = self.evaluate(valid_loader, user_ids=valid_user_ids if needs_user_ids else None) # {'auc': 0.75, 'logloss': 0.45} or {'auc_target1': 0.75, 'logloss_target1': 0.45, 'mse_target2': 3.2}
                if self.nums_task == 1:
                    metrics_str = ", ".join([f"{k}={v:.4f}" for k, v in val_metrics.items()])
                    logging.info(colorize(f"Epoch {epoch + 1}/{epochs} - Valid: {metrics_str}", color="cyan"))
                else:
                    # multi task metrics
                    task_metrics = {}
                    for metric_key, metric_value in val_metrics.items():
                        for target_name in self.target:
                            if metric_key.endswith(f"_{target_name}"):
                                if target_name not in task_metrics:
                                    task_metrics[target_name] = {}
                                metric_name = metric_key.rsplit(f"_{target_name}", 1)[0]
                                task_metrics[target_name][metric_name] = metric_value
                                break
                    task_metric_strs = []
                    for target_name in self.target:
                        if target_name in task_metrics:
                            metrics_str = ", ".join([f"{k}={v:.4f}" for k, v in task_metrics[target_name].items()])
                            task_metric_strs.append(f"{target_name}[{metrics_str}]")
                    logging.info(colorize(f"Epoch {epoch + 1}/{epochs} - Valid: " + ", ".join(task_metric_strs), color="cyan"))
                # Handle empty validation metrics
                if not val_metrics:
                    self.save_model(self.checkpoint_path, add_timestamp=False, verbose=False)
                    self._best_checkpoint_path = self.checkpoint_path
                    logging.info(colorize(f"Warning: No validation metrics computed. Skipping validation for this epoch.", color="yellow"))
                    continue
                
                if self.nums_task == 1:
                    primary_metric_key = self.metrics[0]
                else:
                    primary_metric_key = f"{self.metrics[0]}_{self.target[0]}"
                
                primary_metric = val_metrics.get(primary_metric_key, val_metrics[list(val_metrics.keys())[0]])
                improved = False
                
                if self.best_metrics_mode == 'max':
                    if primary_metric > self._best_metric:
                        self._best_metric = primary_metric
                        self.save_model(self.best_path, add_timestamp=False, verbose=False)
                        improved = True
                else:
                    if primary_metric < self._best_metric:
                        self._best_metric = primary_metric
                        improved = True
                # Always keep the latest weights as a rolling checkpoint
                self.save_model(self.checkpoint_path, add_timestamp=False, verbose=False)
                if improved:
                    logging.info(colorize(f"Validation {primary_metric_key} improved to {self._best_metric:.4f}"))
                    self.save_model(self.best_path, add_timestamp=False, verbose=False)
                    self._best_checkpoint_path = self.best_path
                    self.early_stopper.trial_counter = 0
                else:
                    self.early_stopper.trial_counter += 1
                    logging.info(colorize(f"No improvement for {self.early_stopper.trial_counter} epoch(s)"))
                if self.early_stopper.trial_counter >= self.early_stopper.patience:
                    self._stop_training = True
                    logging.info(colorize(f"Early stopping triggered after {epoch + 1} epochs", color="bright_red", bold=True))
                    break
            else:
                self.save_model(self.checkpoint_path, add_timestamp=False, verbose=False)
                self.save_model(self.best_path, add_timestamp=False, verbose=False)
                self._best_checkpoint_path = self.best_path
            if self._stop_training:
                break
            if self.scheduler_fn is not None:
                if isinstance(self.scheduler_fn, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    if valid_loader is not None:
                        self.scheduler_fn.step(primary_metric)
                else:
                    self.scheduler_fn.step()
                    
        logging.info("\n")
        logging.info(colorize("Training finished.", color="bright_green", bold=True))
        logging.info("\n")

        if valid_loader is not None:
            logging.info(colorize(f"Load best model from: {self._best_checkpoint_path}", color="bright_blue"))
            self.load_model(self._best_checkpoint_path, map_location=self.device, verbose=False)
        return self

    def train_epoch(self, train_loader: DataLoader, is_streaming: bool = False) -> Union[float, np.ndarray, tuple[Union[float, np.ndarray], dict]]:
        if self.nums_task == 1:
            accumulated_loss = 0.0
        else:
            accumulated_loss = np.zeros(self.nums_task, dtype=np.float64)
        self.train()
        num_batches = 0
        y_true_list = []
        y_pred_list = []
        needs_user_ids = self._needs_user_ids_for_metrics()
        user_ids_list = [] if needs_user_ids else None
        if self._steps_per_epoch is not None:
            batch_iter = enumerate(tqdm.tqdm(train_loader, desc=f"Epoch {self._epoch_index + 1}", total=self._steps_per_epoch))
        else:
            if is_streaming:
                batch_iter = enumerate(tqdm.tqdm(train_loader, desc="Batches")) # Streaming mode: show batch/file progress without epoch in desc
            else:
                batch_iter = enumerate(tqdm.tqdm(train_loader, desc=f"Epoch {self._epoch_index + 1}"))

        for batch_index, batch_data in batch_iter:
            batch_dict = self._batch_to_dict(batch_data)
            X_input, y_true = self.get_input(batch_dict, require_labels=True)
            y_pred = self.forward(X_input)
            loss = self.compute_loss(y_pred, y_true)
            reg_loss = self.add_reg_loss()
            if self.nums_task == 1:
                total_loss = loss + reg_loss
            else:
                total_loss = loss.sum() + reg_loss
            self.optimizer_fn.zero_grad()
            total_loss.backward()
            nn.utils.clip_grad_norm_(self.parameters(), self._max_gradient_norm)
            self.optimizer_fn.step()
            if self.nums_task == 1:
                accumulated_loss += loss.item()
            else:
                accumulated_loss += loss.detach().cpu().numpy()
            if y_true is not None:
                y_true_list.append(y_true.detach().cpu().numpy()) # Collect predictions and labels for metrics if requested
            if needs_user_ids and user_ids_list is not None and batch_dict.get("ids"):
                batch_user_id = None
                if self.id_columns:
                    for id_name in self.id_columns:
                        if id_name in batch_dict["ids"]:
                            batch_user_id = batch_dict["ids"][id_name]
                            break
                if batch_user_id is None and batch_dict["ids"]:
                    batch_user_id = next(iter(batch_dict["ids"].values()), None)
                if batch_user_id is not None:
                    ids_np = batch_user_id.detach().cpu().numpy() if isinstance(batch_user_id, torch.Tensor) else np.asarray(batch_user_id)
                    user_ids_list.append(ids_np.reshape(ids_np.shape[0]))
            if y_pred is not None and isinstance(y_pred, torch.Tensor): # For pairwise/listwise mode, y_pred is a tuple of embeddings, skip metric collection during training
                y_pred_list.append(y_pred.detach().cpu().numpy())
            num_batches += 1
        if self.nums_task == 1:
            avg_loss = accumulated_loss / num_batches
        else:
            avg_loss = accumulated_loss / num_batches
        if len(y_true_list) > 0 and len(y_pred_list) > 0: # Compute metrics if requested
            y_true_all = np.concatenate(y_true_list, axis=0)
            y_pred_all = np.concatenate(y_pred_list, axis=0)
            combined_user_ids = None
            if needs_user_ids and user_ids_list:
                combined_user_ids = np.concatenate(user_ids_list, axis=0)
            metrics_dict = self.evaluate_metrics(y_true_all, y_pred_all, self.metrics, user_ids=combined_user_ids)
            return avg_loss, metrics_dict
        return avg_loss

    def _needs_user_ids_for_metrics(self, metrics: list[str] | dict[str, list[str]] | None = None) -> bool:
        """Check if any configured metric requires user_ids (e.g., gauc, ranking @K)."""
        metric_names = set()
        sources = [metrics if metrics is not None else getattr(self, "metrics", None), getattr(self, "task_specific_metrics", None),]
        for src in sources:
            stack = [src]
            while stack:
                item = stack.pop()
                if not item:
                    continue
                if isinstance(item, dict):
                    stack.extend(item.values())
                elif isinstance(item, str):
                    metric_names.add(item.lower())
                else:
                    try:
                        for m in item:
                            metric_names.add(m.lower())
                    except TypeError:
                        continue
        for name in metric_names:
            if name == "gauc":
                return True
            if name.startswith(("recall@", "precision@", "hitrate@", "hr@", "mrr@", "ndcg@", "map@")):
                return True
        return False

    def evaluate(self, 
                 data: dict | pd.DataFrame | DataLoader, 
                 metrics: list[str] | dict[str, list[str]] | None = None,
                 batch_size: int = 32,
                 user_ids: np.ndarray | None = None,
                 user_id_column: str = 'user_id') -> dict:
        self.eval()
        
        # Use provided metrics or fall back to configured metrics
        eval_metrics = metrics if metrics is not None else self.metrics
        if eval_metrics is None:
            raise ValueError("No metrics specified for evaluation. Please provide metrics parameter or call fit() first.")
        needs_user_ids = self._needs_user_ids_for_metrics(eval_metrics)
        
        # Prepare DataLoader if needed
        if isinstance(data, DataLoader):
            data_loader = data
        else:
            # Extract user_ids if needed and not provided
            if user_ids is None and needs_user_ids:
                if isinstance(data, pd.DataFrame) and user_id_column in data.columns:
                    user_ids = np.asarray(data[user_id_column].values)
                elif isinstance(data, dict) and user_id_column in data:
                    user_ids = np.asarray(data[user_id_column])
            
            data_loader = self._prepare_data_loader(data, batch_size=batch_size, shuffle=False)
        
        y_true_list = []
        y_pred_list = []
        collected_user_ids: list[np.ndarray] = []
        
        batch_count = 0
        with torch.no_grad():
            for batch_data in data_loader:
                batch_count += 1
                batch_dict = self._batch_to_dict(batch_data)
                X_input, y_true = self.get_input(batch_dict, require_labels=True)
                y_pred = self.forward(X_input)
                
                if y_true is not None:
                    y_true_list.append(y_true.cpu().numpy())
                # Skip if y_pred is not a tensor (e.g., tuple in pairwise mode, though this shouldn't happen in eval mode)
                if y_pred is not None and isinstance(y_pred, torch.Tensor):
                    y_pred_list.append(y_pred.cpu().numpy())
                if needs_user_ids and user_ids is None and batch_dict.get("ids"):
                    batch_user_id = None
                    if self.id_columns:
                        for id_name in self.id_columns:
                            if id_name in batch_dict["ids"]:
                                batch_user_id = batch_dict["ids"][id_name]
                                break
                    if batch_user_id is None and batch_dict["ids"]:
                        batch_user_id = next(iter(batch_dict["ids"].values()), None)
                    if batch_user_id is not None:
                        ids_np = batch_user_id.detach().cpu().numpy() if isinstance(batch_user_id, torch.Tensor) else np.asarray(batch_user_id)
                        collected_user_ids.append(ids_np.reshape(ids_np.shape[0]))

        logging.info(colorize(f"  Evaluation batches processed: {batch_count}", color="cyan"))
        
        if len(y_true_list) > 0:
            y_true_all = np.concatenate(y_true_list, axis=0)
            logging.info(colorize(f"  Evaluation samples: {y_true_all.shape[0]}", color="cyan"))
        else:
            y_true_all = None
            logging.info(colorize(f"  Warning: No y_true collected from evaluation data", color="yellow"))
            
        if len(y_pred_list) > 0:
            y_pred_all = np.concatenate(y_pred_list, axis=0)
        else:
            y_pred_all = None
            logging.info(colorize(f"  Warning: No y_pred collected from evaluation data", color="yellow"))
        
        # Convert metrics to list if it's a dict
        if isinstance(eval_metrics, dict):
            # For dict metrics, we need to collect all unique metric names
            unique_metrics = []
            for task_metrics in eval_metrics.values():
                for m in task_metrics:
                    if m not in unique_metrics:
                        unique_metrics.append(m)
            metrics_to_use = unique_metrics
        else:
            metrics_to_use = eval_metrics
        
        final_user_ids = user_ids
        if final_user_ids is None and collected_user_ids:
            final_user_ids = np.concatenate(collected_user_ids, axis=0)

        metrics_dict = self.evaluate_metrics(y_true_all, y_pred_all, metrics_to_use, final_user_ids)
        
        return metrics_dict


    def evaluate_metrics(self, y_true: np.ndarray|None, y_pred: np.ndarray|None, metrics: list[str], user_ids: np.ndarray|None = None) -> dict:
        """Evaluate metrics using the metrics module."""
        task_specific_metrics = getattr(self, 'task_specific_metrics', None)
        
        return evaluate_metrics(
            y_true=y_true,
            y_pred=y_pred,
            metrics=metrics,
            task=self.task,
            target_names=self.target,
            task_specific_metrics=task_specific_metrics,
            user_ids=user_ids
        )


    def predict(
        self,
        data: str | dict | pd.DataFrame | DataLoader,
        batch_size: int = 32,
        save_path: str | os.PathLike | None = None,
        save_format: Literal["npy", "csv"] = "npy",
        include_ids: bool | None = None,
        return_dataframe: bool | None = None,
    ) -> pd.DataFrame | np.ndarray:
        """
        Run inference and optionally return ID-aligned predictions.

        When ``id_columns`` are configured and ``include_ids`` is True (default),
        the returned object will include those IDs to keep a one-to-one mapping
        between each prediction and its source row.
        """
        self.eval()
        if include_ids is None:
            include_ids = bool(self.id_columns)
        include_ids = include_ids and bool(self.id_columns)
        if return_dataframe is None:
            return_dataframe = include_ids

        # todo: handle file path input later
        if isinstance(data, (str, os.PathLike)):
            pass

        if not isinstance(data, DataLoader):
            data_loader = self._prepare_data_loader(data, batch_size=batch_size, shuffle=False,)
        else:
            data_loader = data
        
        y_pred_list: list[np.ndarray] = []
        id_buffers: dict[str, list[np.ndarray]] = {name: [] for name in (self.id_columns or [])} if include_ids else {}
        
        with torch.no_grad():
            for batch_data in tqdm.tqdm(data_loader, desc="Predicting"):
                batch_dict = self._batch_to_dict(batch_data, include_ids=include_ids)
                X_input, _ = self.get_input(batch_dict, require_labels=False)
                y_pred = self.forward(X_input)

                if y_pred is not None and isinstance(y_pred, torch.Tensor):
                    y_pred_list.append(y_pred.detach().cpu().numpy())

                if include_ids and self.id_columns and batch_dict.get("ids"):
                    for id_name in self.id_columns:
                        if id_name not in batch_dict["ids"]:
                            continue
                        id_tensor = batch_dict["ids"][id_name]
                        if isinstance(id_tensor, torch.Tensor):
                            id_np = id_tensor.detach().cpu().numpy()
                        else:
                            id_np = np.asarray(id_tensor)
                        id_buffers[id_name].append(id_np.reshape(id_np.shape[0], -1) if id_np.ndim == 1 else id_np)

        if len(y_pred_list) > 0:
            y_pred_all = np.concatenate(y_pred_list, axis=0)
        else:
            y_pred_all = np.array([])

        if y_pred_all.ndim == 1:
            y_pred_all = y_pred_all.reshape(-1, 1)
        if y_pred_all.size == 0:
            num_outputs = len(self.target) if self.target else 1
            y_pred_all = y_pred_all.reshape(0, num_outputs)
        num_outputs = y_pred_all.shape[1]

        pred_columns: list[str] = []
        if self.target:
            for name in self.target[:num_outputs]:
                pred_columns.append(f"{name}_pred")
        while len(pred_columns) < num_outputs:
            pred_columns.append(f"pred_{len(pred_columns)}")

        output: pd.DataFrame | np.ndarray

        if include_ids and self.id_columns:
            id_arrays: dict[str, np.ndarray] = {}
            for id_name, pieces in id_buffers.items():
                if pieces:
                    concatenated = np.concatenate([p.reshape(p.shape[0], -1) for p in pieces], axis=0)
                    id_arrays[id_name] = concatenated.reshape(concatenated.shape[0])
                else:
                    id_arrays[id_name] = np.array([], dtype=np.int64)

            if return_dataframe:
                id_df = pd.DataFrame(id_arrays)
                pred_df = pd.DataFrame(y_pred_all, columns=pred_columns)
                if len(id_df) and len(pred_df) and len(id_df) != len(pred_df):
                    raise ValueError(f"Mismatch between id rows ({len(id_df)}) and prediction rows ({len(pred_df)}).")
                output = pd.concat([id_df, pred_df], axis=1)
            else:
                output = y_pred_all
        else:
            output = pd.DataFrame(y_pred_all, columns=pred_columns) if return_dataframe else y_pred_all

        if save_path is not None:
            suffix = ".npy" if save_format == "npy" else ".csv"
            target_path = resolve_save_path(
                path=save_path,
                default_dir=self.session.predictions_dir,
                default_name="predictions",
                suffix=suffix,
                add_timestamp=True if save_path is None else False,
            )

            if save_format == "npy":
                if isinstance(output, pd.DataFrame):
                    np.save(target_path, output.to_records(index=False))
                else:
                    np.save(target_path, output)
            else:
                if isinstance(output, pd.DataFrame):
                    output.to_csv(target_path, index=False)
                else:
                    pd.DataFrame(output, columns=pred_columns).to_csv(target_path, index=False)

            logging.info(colorize(f"Predictions saved to: {target_path}", color="green"))

        return output

    def save_model(self, save_path: str | Path | None = None, add_timestamp: bool | None = None, verbose: bool = True):
        add_timestamp = False if add_timestamp is None else add_timestamp
        target_path = resolve_save_path(
            path=save_path,
            default_dir=self.session_path,
            default_name=self.model_name,
            suffix=".model",
            add_timestamp=add_timestamp,
        )
        model_path = Path(target_path)
        torch.save(self.state_dict(), model_path)

        config_path = self.features_config_path
        features_config = {
            "all_features": self.all_features,
            "target": self.target,
            "id_columns": self.id_columns,
            "version": __version__,
        }
        with open(config_path, "wb") as f:
            pickle.dump(features_config, f)
        self.features_config_path = str(config_path)
        if verbose:
            logging.info(colorize(f"Model saved to: {model_path}, features config saved to: {config_path}, NextRec version: {__version__}",color="green",))
    
    def load_model(self, save_path: str | Path, map_location: str | torch.device | None = "cpu", verbose: bool = True):
        self.to(self.device)
        base_path = Path(save_path)
        if base_path.is_dir():
            model_files = sorted(base_path.glob("*.model"))
            if not model_files:
                raise FileNotFoundError(f"No *.model file found in directory: {base_path}")
            model_path = model_files[-1]
            config_dir = base_path
        else:
            model_path = base_path.with_suffix(".model") if base_path.suffix == "" else base_path
            config_dir = model_path.parent
        if not model_path.exists():
            raise FileNotFoundError(f"Model file does not exist: {model_path}")

        state_dict = torch.load(model_path, map_location=map_location)
        self.load_state_dict(state_dict)

        features_config_path = config_dir / "features_config.pkl"
        if not features_config_path.exists():
            raise FileNotFoundError(f"features_config.pkl not found in: {config_dir}")
        with open(features_config_path, "rb") as f:
            features_config = pickle.load(f)

        all_features = features_config.get("all_features", [])
        target = features_config.get("target", [])
        id_columns = features_config.get("id_columns", [])
        dense_features = [f for f in all_features if isinstance(f, DenseFeature)]
        sparse_features = [f for f in all_features if isinstance(f, SparseFeature)]
        sequence_features = [f for f in all_features if isinstance(f, SequenceFeature)]
        self._set_feature_config(
            dense_features=dense_features,
            sparse_features=sparse_features,
            sequence_features=sequence_features,
            target=target,
            id_columns=id_columns,
        )
        self.target = self.target_columns
        self.target_index = {name: idx for idx, name in enumerate(self.target)}
        cfg_version = features_config.get("version")
        if verbose:
            logging.info(colorize(f"Model weights loaded from: {model_path}, features config loaded from: {features_config_path}, NextRec version: {cfg_version}",color="green",))

    def summary(self):
        logger = logging.getLogger()
        
        logger.info(colorize("=" * 80, color="bright_blue", bold=True))
        logger.info(colorize(f"Model Summary: {self.model_name}", color="bright_blue", bold=True))
        logger.info(colorize("=" * 80, color="bright_blue", bold=True))
        
        logger.info("")
        logger.info(colorize("[1] Feature Configuration", color="cyan", bold=True))
        logger.info(colorize("-" * 80, color="cyan"))
        
        if self.dense_features:
            logger.info(f"Dense Features ({len(self.dense_features)}):")
            for i, feat in enumerate(self.dense_features, 1):
                embed_dim = feat.embedding_dim if hasattr(feat, 'embedding_dim') else 1
                logger.info(f"  {i}. {feat.name:20s}")
        
        if self.sparse_features:
            logger.info(f"Sparse Features ({len(self.sparse_features)}):")

            max_name_len = max(len(feat.name) for feat in self.sparse_features)
            max_embed_name_len = max(len(feat.embedding_name) for feat in self.sparse_features)
            name_width = max(max_name_len, 10) + 2
            embed_name_width = max(max_embed_name_len, 15) + 2
            
            logger.info(f"  {'#':<4} {'Name':<{name_width}} {'Vocab Size':>12} {'Embed Name':>{embed_name_width}} {'Embed Dim':>10}")
            logger.info(f"  {'-'*4} {'-'*name_width} {'-'*12} {'-'*embed_name_width} {'-'*10}")
            for i, feat in enumerate(self.sparse_features, 1):
                vocab_size = feat.vocab_size if hasattr(feat, 'vocab_size') else 'N/A'
                embed_dim = feat.embedding_dim if hasattr(feat, 'embedding_dim') else 'N/A'
                logger.info(f"  {i:<4} {feat.name:<{name_width}} {str(vocab_size):>12} {feat.embedding_name:>{embed_name_width}} {str(embed_dim):>10}")
        
        if self.sequence_features:
            logger.info(f"Sequence Features ({len(self.sequence_features)}):")

            max_name_len = max(len(feat.name) for feat in self.sequence_features)
            max_embed_name_len = max(len(feat.embedding_name) for feat in self.sequence_features)
            name_width = max(max_name_len, 10) + 2
            embed_name_width = max(max_embed_name_len, 15) + 2
            
            logger.info(f"  {'#':<4} {'Name':<{name_width}} {'Vocab Size':>12} {'Embed Name':>{embed_name_width}} {'Embed Dim':>10} {'Max Len':>10}")
            logger.info(f"  {'-'*4} {'-'*name_width} {'-'*12} {'-'*embed_name_width} {'-'*10} {'-'*10}")
            for i, feat in enumerate(self.sequence_features, 1):
                vocab_size = feat.vocab_size if hasattr(feat, 'vocab_size') else 'N/A'
                embed_dim = feat.embedding_dim if hasattr(feat, 'embedding_dim') else 'N/A'
                max_len = feat.max_len if hasattr(feat, 'max_len') else 'N/A'
                logger.info(f"  {i:<4} {feat.name:<{name_width}} {str(vocab_size):>12} {feat.embedding_name:>{embed_name_width}} {str(embed_dim):>10} {str(max_len):>10}")
        
        logger.info("")
        logger.info(colorize("[2] Model Parameters", color="cyan", bold=True))
        logger.info(colorize("-" * 80, color="cyan"))
        
        # Model Architecture
        logger.info("Model Architecture:")
        logger.info(str(self))
        logger.info("")
        
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        non_trainable_params = total_params - trainable_params
        
        logger.info(f"Total Parameters:        {total_params:,}")
        logger.info(f"Trainable Parameters:    {trainable_params:,}")
        logger.info(f"Non-trainable Parameters: {non_trainable_params:,}")
        
        logger.info("Layer-wise Parameters:")
        for name, module in self.named_children():
            layer_params = sum(p.numel() for p in module.parameters())
            if layer_params > 0:
                logger.info(f"  {name:30s}: {layer_params:,}")
        
        logger.info("")
        logger.info(colorize("[3] Training Configuration", color="cyan", bold=True))
        logger.info(colorize("-" * 80, color="cyan"))
        
        logger.info(f"Task Type:               {self.task}")
        logger.info(f"Number of Tasks:         {self.nums_task}")
        logger.info(f"Metrics:                 {self.metrics}")
        logger.info(f"Target Columns:          {self.target}")
        logger.info(f"Device:                  {self.device}")
        
        if hasattr(self, '_optimizer_name'):
            logger.info(f"Optimizer:               {self._optimizer_name}")
            if self._optimizer_params:
                for key, value in self._optimizer_params.items():
                    logger.info(f"  {key:25s}: {value}")
        
        if hasattr(self, '_scheduler_name') and self._scheduler_name:
            logger.info(f"Scheduler:               {self._scheduler_name}")
            if self._scheduler_params:
                for key, value in self._scheduler_params.items():
                    logger.info(f"  {key:25s}: {value}")
        
        if hasattr(self, '_loss_config'):
            logger.info(f"Loss Function:           {self._loss_config}")
        
        logger.info("Regularization:")
        logger.info(f"  Embedding L1:          {self._embedding_l1_reg}")
        logger.info(f"  Embedding L2:          {self._embedding_l2_reg}")
        logger.info(f"  Dense L1:              {self._dense_l1_reg}")
        logger.info(f"  Dense L2:              {self._dense_l2_reg}")
        
        logger.info("Other Settings:")
        logger.info(f"  Early Stop Patience:   {self._early_stop_patience}")
        logger.info(f"  Max Gradient Norm:     {self._max_gradient_norm}")
        logger.info(f"  Session ID:            {self.session_id}")
        logger.info(f"  Latest Checkpoint:     {self.checkpoint_path}")
        
        logger.info("")
        logger.info("")


class BaseMatchModel(BaseModel):
    """
    Base class for match (retrieval/recall) models
    Supports pointwise, pairwise, and listwise training modes
    """
    @property
    def model_name(self) -> str:
        raise NotImplementedError

    @property
    def task_type(self) -> str:
        raise NotImplementedError
    
    @property
    def support_training_modes(self) -> list[str]:
        """
        Returns list of supported training modes for this model.
        Override in subclasses to restrict training modes.
        
        Returns:
            List of supported modes: ['pointwise', 'pairwise', 'listwise']
        """
        return ['pointwise', 'pairwise', 'listwise']
    
    def __init__(self,
                 user_dense_features: list[DenseFeature] | None = None,
                 user_sparse_features: list[SparseFeature] | None = None,
                 user_sequence_features: list[SequenceFeature] | None = None,
                 item_dense_features: list[DenseFeature] | None = None,
                 item_sparse_features: list[SparseFeature] | None = None,
                 item_sequence_features: list[SequenceFeature] | None = None,
                 training_mode: Literal['pointwise', 'pairwise', 'listwise'] = 'pointwise',
                 num_negative_samples: int = 4,
                 temperature: float = 1.0,
                 similarity_metric: Literal['dot', 'cosine', 'euclidean'] = 'dot',
                 device: str = 'cpu',
                 embedding_l1_reg: float = 0.0,
                 dense_l1_reg: float = 0.0,
                 embedding_l2_reg: float = 0.0,
                 dense_l2_reg: float = 0.0,
                 early_stop_patience: int = 20,
                 **kwargs):
        
        all_dense_features = []
        all_sparse_features = []
        all_sequence_features = []
        
        if user_dense_features:
            all_dense_features.extend(user_dense_features)
        if item_dense_features:
            all_dense_features.extend(item_dense_features)
        if user_sparse_features:
            all_sparse_features.extend(user_sparse_features)
        if item_sparse_features:
            all_sparse_features.extend(item_sparse_features)
        if user_sequence_features:
            all_sequence_features.extend(user_sequence_features)
        if item_sequence_features:
            all_sequence_features.extend(item_sequence_features)
        
        super(BaseMatchModel, self).__init__(
            dense_features=all_dense_features,
            sparse_features=all_sparse_features,
            sequence_features=all_sequence_features,
            target=['label'],  
            task='binary',  
            device=device,
            embedding_l1_reg=embedding_l1_reg,
            dense_l1_reg=dense_l1_reg,
            embedding_l2_reg=embedding_l2_reg,
            dense_l2_reg=dense_l2_reg,
            early_stop_patience=early_stop_patience,
            **kwargs
        )
        
        self.user_dense_features = list(user_dense_features) if user_dense_features else []
        self.user_sparse_features = list(user_sparse_features) if user_sparse_features else []
        self.user_sequence_features = list(user_sequence_features) if user_sequence_features else []
        
        self.item_dense_features = list(item_dense_features) if item_dense_features else []
        self.item_sparse_features = list(item_sparse_features) if item_sparse_features else []
        self.item_sequence_features = list(item_sequence_features) if item_sequence_features else []
        
        self.training_mode = training_mode
        self.num_negative_samples = num_negative_samples
        self.temperature = temperature
        self.similarity_metric = similarity_metric

        self.user_feature_names = [f.name for f in (
            self.user_dense_features + self.user_sparse_features + self.user_sequence_features
        )]
        self.item_feature_names = [f.name for f in (
            self.item_dense_features + self.item_sparse_features + self.item_sequence_features
        )]

    def get_user_features(self, X_input: dict) -> dict:
        return {
            name: X_input[name]
            for name in self.user_feature_names
            if name in X_input
        }

    def get_item_features(self, X_input: dict) -> dict:
        return {
            name: X_input[name]
            for name in self.item_feature_names
            if name in X_input
        }
        
    def compile(self, 
                optimizer: str | torch.optim.Optimizer = "adam",
                optimizer_params: dict | None = None,
                scheduler: str | torch.optim.lr_scheduler._LRScheduler | type[torch.optim.lr_scheduler._LRScheduler] | None = None,
                scheduler_params: dict | None = None,
                loss: str | nn.Module | list[str | nn.Module] | None = "bce",
                loss_params: dict | list[dict] | None = None):
        """
        Compile match model with optimizer, scheduler, and loss function.
        Mirrors BaseModel.compile while adding training_mode validation for match tasks.
        """
        if self.training_mode not in self.support_training_modes:
            raise ValueError(
                f"{self.model_name} does not support training_mode='{self.training_mode}'. "
                f"Supported modes: {self.support_training_modes}"
            )

        # Call parent compile with match-specific logic
        optimizer_params = optimizer_params or {}
        
        self._optimizer_name = optimizer if isinstance(optimizer, str) else optimizer.__class__.__name__
        self._optimizer_params = optimizer_params
        if isinstance(scheduler, str):
            self._scheduler_name = scheduler
        elif scheduler is not None:
            # Try to get __name__ first (for class types), then __class__.__name__ (for instances)
            self._scheduler_name = getattr(scheduler, '__name__', getattr(scheduler.__class__, '__name__', str(scheduler)))
        else:
            self._scheduler_name = None
        self._scheduler_params = scheduler_params or {}
        self._loss_config = loss
        self._loss_params = loss_params or {}
        
        # set optimizer
        self.optimizer_fn = get_optimizer(
            optimizer=optimizer, 
            params=self.parameters(), 
            **optimizer_params
        )
        
        # Set loss function based on training mode
        default_losses = {
            'pointwise': 'bce',
            'pairwise': 'bpr',
            'listwise': 'sampled_softmax',
        }

        if loss is None:
            loss_value = default_losses.get(self.training_mode, "bce")
        elif isinstance(loss, list):
            loss_value = loss[0] if loss and loss[0] is not None else default_losses.get(self.training_mode, "bce")
        else:
            loss_value = loss

        # Pairwise/listwise modes do not support BCE, fall back to sensible defaults
        if self.training_mode in {"pairwise", "listwise"} and loss_value in {"bce", "binary_crossentropy"}:
            loss_value = default_losses.get(self.training_mode, loss_value)

        loss_kwargs = get_loss_kwargs(self._loss_params, 0)
        self.loss_fn = [get_loss_fn(
            loss=loss_value,
            **loss_kwargs
        )]
        
        # set scheduler
        self.scheduler_fn = get_scheduler(scheduler, self.optimizer_fn, **(scheduler_params or {})) if scheduler else None

    def compute_similarity(self, user_emb: torch.Tensor, item_emb: torch.Tensor) -> torch.Tensor:
        if self.similarity_metric == 'dot':
            if user_emb.dim() == 3 and item_emb.dim() == 3:
                # [batch_size, num_items, emb_dim] @ [batch_size, num_items, emb_dim]
                similarity = torch.sum(user_emb * item_emb, dim=-1)  # [batch_size, num_items]
            elif user_emb.dim() == 2 and item_emb.dim() == 3:
                # [batch_size, emb_dim] @ [batch_size, num_items, emb_dim]
                user_emb_expanded = user_emb.unsqueeze(1)  # [batch_size, 1, emb_dim]
                similarity = torch.sum(user_emb_expanded * item_emb, dim=-1)  # [batch_size, num_items]
            else:
                similarity = torch.sum(user_emb * item_emb, dim=-1)  # [batch_size]
        
        elif self.similarity_metric == 'cosine':
            if user_emb.dim() == 3 and item_emb.dim() == 3:
                similarity = F.cosine_similarity(user_emb, item_emb, dim=-1)
            elif user_emb.dim() == 2 and item_emb.dim() == 3:
                user_emb_expanded = user_emb.unsqueeze(1)
                similarity = F.cosine_similarity(user_emb_expanded, item_emb, dim=-1)
            else:
                similarity = F.cosine_similarity(user_emb, item_emb, dim=-1)
        
        elif self.similarity_metric == 'euclidean':
            if user_emb.dim() == 3 and item_emb.dim() == 3:
                distance = torch.sum((user_emb - item_emb) ** 2, dim=-1)
            elif user_emb.dim() == 2 and item_emb.dim() == 3:
                user_emb_expanded = user_emb.unsqueeze(1)
                distance = torch.sum((user_emb_expanded - item_emb) ** 2, dim=-1)
            else:
                distance = torch.sum((user_emb - item_emb) ** 2, dim=-1)
            similarity = -distance 
        
        else:
            raise ValueError(f"Unknown similarity metric: {self.similarity_metric}")
        
        similarity = similarity / self.temperature
        
        return similarity
    
    def user_tower(self, user_input: dict) -> torch.Tensor:
        raise NotImplementedError
    
    def item_tower(self, item_input: dict) -> torch.Tensor:
        raise NotImplementedError
    
    def forward(self, X_input: dict) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        user_input = self.get_user_features(X_input)
        item_input = self.get_item_features(X_input)
        
        user_emb = self.user_tower(user_input)   # [B, D]
        item_emb = self.item_tower(item_input)   # [B, D]
        
        if self.training and self.training_mode in ['pairwise', 'listwise']:
            return user_emb, item_emb

        similarity = self.compute_similarity(user_emb, item_emb)  # [B]
        
        if self.training_mode == 'pointwise':
            return torch.sigmoid(similarity)
        else:
            return similarity
    
    def compute_loss(self, y_pred, y_true):
        if self.training_mode == 'pointwise':
            if y_true is None:
                return torch.tensor(0.0, device=self.device)
            return self.loss_fn[0](y_pred, y_true)
        
        # pairwise / listwise using inbatch neg
        elif self.training_mode in ['pairwise', 'listwise']:
            if not isinstance(y_pred, (tuple, list)) or len(y_pred) != 2:
                raise ValueError(
                    "For pairwise/listwise training, forward should return (user_emb, item_emb). "
                    "Please check BaseMatchModel.forward implementation."
                )
            
            user_emb, item_emb = y_pred  # [B, D], [B, D]
            
            logits = torch.matmul(user_emb, item_emb.t())  # [B, B]
            logits = logits / self.temperature            
            
            batch_size = logits.size(0)
            targets = torch.arange(batch_size, device=logits.device)  # [0, 1, 2, ..., B-1]
            
            # Cross-Entropy = InfoNCE
            loss = F.cross_entropy(logits, targets)
            return loss
        
        else:
            raise ValueError(f"Unknown training mode: {self.training_mode}")
    
    def _set_metrics(self, metrics: list[str] | dict[str, list[str]] | None = None):
        """Reuse BaseModel metric configuration (mode + early stopper)."""
        super()._set_metrics(metrics)
    
    def encode_user(self, data: dict | pd.DataFrame | DataLoader, batch_size: int = 512) -> np.ndarray:
        self.eval()
        
        if not isinstance(data, DataLoader):
            user_data = {}
            all_user_features = self.user_dense_features + self.user_sparse_features + self.user_sequence_features
            for feature in all_user_features:
                if isinstance(data, dict):
                    if feature.name in data:
                        user_data[feature.name] = data[feature.name]
                elif isinstance(data, pd.DataFrame):
                    if feature.name in data.columns:
                        user_data[feature.name] = data[feature.name].values
            
            data_loader = self._prepare_data_loader(
                user_data,
                batch_size=batch_size,
                shuffle=False,
            )
        else:
            data_loader = data
        
        embeddings_list = []
        
        with torch.no_grad():
            for batch_data in tqdm.tqdm(data_loader, desc="Encoding users"):
                batch_dict = self._batch_to_dict(batch_data, include_ids=False)
                user_input = self.get_user_features(batch_dict["features"])
                user_emb = self.user_tower(user_input)
                embeddings_list.append(user_emb.cpu().numpy())
        
        embeddings = np.concatenate(embeddings_list, axis=0)
        return embeddings
    
    def encode_item(self, data: dict | pd.DataFrame | DataLoader, batch_size: int = 512) -> np.ndarray:
        self.eval()
        
        if not isinstance(data, DataLoader):
            item_data = {}
            all_item_features = self.item_dense_features + self.item_sparse_features + self.item_sequence_features
            for feature in all_item_features:
                if isinstance(data, dict):
                    if feature.name in data:
                        item_data[feature.name] = data[feature.name]
                elif isinstance(data, pd.DataFrame):
                    if feature.name in data.columns:
                        item_data[feature.name] = data[feature.name].values

            data_loader = self._prepare_data_loader(
                item_data,
                batch_size=batch_size,
                shuffle=False,
            )
        else:
            data_loader = data
        
        embeddings_list = []
        
        with torch.no_grad():
            for batch_data in tqdm.tqdm(data_loader, desc="Encoding items"):
                batch_dict = self._batch_to_dict(batch_data, include_ids=False)
                item_input = self.get_item_features(batch_dict["features"])
                item_emb = self.item_tower(item_input)
                embeddings_list.append(item_emb.cpu().numpy())
        
        embeddings = np.concatenate(embeddings_list, axis=0)
        return embeddings
