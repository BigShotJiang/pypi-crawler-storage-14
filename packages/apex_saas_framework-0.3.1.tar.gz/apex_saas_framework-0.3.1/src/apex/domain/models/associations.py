"""Association tables for many-to-many relationships."""

from sqlalchemy import Column, ForeignKey, Table
from sqlalchemy import UUID as SQLUUID

from apex.infrastructure.database.base import Base

# Association table for many-to-many relationship between users and roles
user_role_association = Table(
    "user_role_association",
    Base.metadata,
    Column("user_id", SQLUUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("role_id", SQLUUID(as_uuid=True), ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
)

# Association table for many-to-many relationship between roles and permissions
role_permission_association = Table(
    "role_permission_association",
    Base.metadata,
    Column("role_id", SQLUUID(as_uuid=True), ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
    Column("permission_id", SQLUUID(as_uuid=True), ForeignKey("permissions.id", ondelete="CASCADE"), primary_key=True),
)

