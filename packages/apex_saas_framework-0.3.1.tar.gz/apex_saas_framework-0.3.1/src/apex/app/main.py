"""
Entry point for generated FastAPI application.
"""
from fastapi import FastAPI

from apex.app.api import get_api_router
from apex.app.core.config import get_settings


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title=settings.APP_NAME, version=settings.APP_VERSION)
    app.include_router(get_api_router(prefix=settings.API_V1_PREFIX))
    return app


app = create_app()

