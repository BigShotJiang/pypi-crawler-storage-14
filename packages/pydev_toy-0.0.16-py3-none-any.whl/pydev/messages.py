"""pydev messages"""

ALLOW_PUBLISH = """
Publishing needs to be enabled in pyproject.toml!

Add the following lines to pyproject.toml:

[tool.pydev]
allow-publish = true 
"""
