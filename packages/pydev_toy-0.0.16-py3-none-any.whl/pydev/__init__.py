"""pydev package"""

from .program import main as main
