from fastapi import APIRouter, HTTPException, status, Header, Depends
from pro_craft_infer.core import AsyncIntel
import os

def create_router(database_url: str,
                  model_name: str,
                  log_database_url: str,
                  log_path: str,
                  logger = None):
    """
    # os.getenv("log_database_url")
    os.getenv("log_file_path")
    """

    intels = AsyncIntel(
        database_url=database_url,
        model_name=model_name,
        logger=logger
        )

    router = APIRouter(
        tags=["log"], # 这里使用 Depends 确保每次请求都验证
    )
    @router.get("/sync_log")
    async def sync_log():
        try:
            database_url = "mysql+aiomysql://"+ log_database_url 
            
            result = await intels.sync_log(os.path.join(log_path,"app_notice.log"),database_url=database_url)
            result = await intels.sync_log(os.path.join(log_path,"app_info.log"))

            return {'msg':"success","content":""}
        except Exception as e:
            raise HTTPException(
                status_code=500, detail=f"{e}"
            )
    
    return router