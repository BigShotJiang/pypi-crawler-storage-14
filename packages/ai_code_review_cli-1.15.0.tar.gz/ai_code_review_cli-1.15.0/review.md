## AI Code Review

### 📋 MR Summary
This MR implements a two-phase "Intelligent Review Context" system that fetches and synthesizes previous PR comments/reviews to prevent the AI from repeating invalidated suggestions.

- **Key Changes:**
    - Introduced a synthesis phase in `ReviewEngine` using a faster/cheaper model (e.g., Gemini Flash) to summarize context before the main review.
    - Updated `GitHubClient` and `GitLabClient` to fetch reviews and comments, utilizing `asyncio.to_thread` for non-blocking execution of synchronous library calls.
    - Added logic to identify the bot's own user to distinguish between AI output and human feedback.
- **Impact:** Affects `ReviewEngine`, platform clients, and configuration models. Adds a new dependency on fetching comment history.
- **Risk Level:** Medium - The logic involves new API calls and prompt engineering, but fallback mechanisms are in place to ensure the main review proceeds if synthesis fails.

### Detailed Code Review

The implementation demonstrates a solid understanding of the project's asynchronous architecture and the limitations of the underlying synchronous platform libraries.

- **Asynchronous Integration:** The use of `asyncio.to_thread` in `GitHubClient` and `GitLabClient` is the correct pattern for integrating blocking I/O calls (`pygithub`, `python-gitlab`) into the `aiohttp`-based application. This ensures the event loop remains responsive.
- **Resilience:** The `try...except` block wrapping the synthesis phase in `ReviewEngine` is excellent. It ensures that if the synthesis fails (API error, context limit, etc.), the tool gracefully degrades to a standard review rather than crashing.
- **Prompt Engineering:** The logic in `_format_reviews_and_comments` to prioritize "Author Responses" and filter out system/bot comments is well-designed. This directly addresses the business goal of respecting author feedback.
- **Configuration:** The addition of `synthesis_model` with intelligent defaults based on the provider allows for cost optimization without complex user configuration.

#### 📂 File Reviews

<details>
<summary><strong>📄 `src/ai_code_review/core/review_engine.py`</strong> - Synthesis orchestration</summary>

- **[Suggestion]** You are using `print()` to display the synthesis output for transparency. Since this is a CLI tool built with `click`, it is generally better practice to use `click.echo()` (or `click.secho` for colors) to ensure proper handling of stdout/stderr and terminal encoding.
    ```python
    # Current
    print("\n" + "=" * 80)
    # Suggested
    import click
    click.echo("\n" + "=" * 80)
    ```
- **[Review]** The logic to reuse `_create_ai_provider` with a `model_override` for the synthesis LLM is clean and avoids code duplication.

</details>

<details>
<summary><strong>📄 `src/ai_code_review/core/gitlab_client.py`</strong> - GitLab API integration</summary>

- **[Question]** In `_fetch_merge_request_discussions`, you use `max_comments_to_fetch` as the `per_page` limit for *discussions* (threads). Since a discussion can contain multiple notes (comments), this might fetch significantly more individual comments than the configured limit (e.g., 30 threads × 5 comments = 150 comments). While `MAX_OTHER_COMMENTS_IN_SYNTHESIS` limits what is sent to the LLM, is this potential over-fetching on the API side intentional?
- **[Review]** The filtering of system notes (`if note.get("system", False):`) is a crucial detail for reducing noise. Good inclusion.

</details>

<details>
<summary><strong>📄 `src/ai_code_review/utils/prompts.py`</strong> - Prompt logic</summary>

- **[Review]** The sorting logic `sorted(other_comments, key=lambda c: c.created_at, reverse=True)` correctly relies on ISO 8601 string comparison. This is efficient and correct.
- **[Review]** Explicitly identifying the bot's own comments via `bot_username` prevents the synthesis model from treating previous AI hallucinations as human consensus. This is a critical safety check.

</details>

### ✅ Summary

- **Overall Assessment:** High quality. The feature is well-architected, fitting seamlessly into the existing async framework while handling synchronous dependencies correctly. The fallback logic makes it safe to deploy.
- **Priority Issues:** None.
- **Minor Suggestions:** Consider swapping `print` for `click.echo` for consistency with CLI best practices. Verify if the GitLab discussion fetching limit aligns with the intended "comment" limit.