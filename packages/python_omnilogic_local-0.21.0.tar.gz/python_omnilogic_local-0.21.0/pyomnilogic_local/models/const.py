"""Constants for the models package."""

XML_NS = {"api": "http://nextgen.hayward.com/api"}
