"""CLI commands for debugging the Hayward OmniLogic Local API."""
