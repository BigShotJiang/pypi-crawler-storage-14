"""CLI commands for retrieving data from the Hayward OmniLogic Local API."""
