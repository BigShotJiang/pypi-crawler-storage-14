"""
Source Atlas - setup.py for backward compatibility.

For modern installations, use pyproject.toml.
"""

from setuptools import setup

# Setup configuration is in pyproject.toml
# This file exists for backward compatibility
setup()
