#!/usr/bin/env bash
set -ex

branch="pre-commit-autoupdate"
status=0
default_branch="main"


# Check for a dirty repo
git diff --exit-code || status=$?
if [[ $status -ne 0 ]]; then
    echo "Error: dirty repo, commit your changes first."
    exit 1
fi

git fetch origin && git checkout "origin/${default_branch}"

git branch -D $branch || true
git checkout -b $branch


# Check for updates
pre-commit autoupdate
git diff --exit-code || status=$?

if [[ $status -eq 0 ]]; then
    git checkout "origin/${default_branch}"
    git branch -D $branch
    # No changes to commit
    echo "No updates necessary."
    exit 0
fi

git add -u .
git commit -m "Update pre-commit dependencies"
# See push options at https://docs.gitlab.com/ee/user/project/push_options.html
# This push command will create a Merge Request (MR).
# A new MR is created even when a previous MR exists.
# TODO Add git push options for:
#      - merge_request.description=
#      - merge_request.assign=
git push \
  -u --force-with-lease \
  origin $branch \
  -o merge_request.create \
  -o merge_request.target=$default_branch \
  -o merge_request.title="Pre-commit automated dependency updates for $(date +'%d-%B-%Y')" \
  -o merge_request.merge_when_pipeline_succeeds
git checkout "origin/${default_branch}"
git branch -D $branch
