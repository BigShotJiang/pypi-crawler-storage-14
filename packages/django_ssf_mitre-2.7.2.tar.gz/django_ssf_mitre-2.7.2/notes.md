# Notes

## Building the package

Run the following:

    pip install hatchling
    hatchling build

See also [Packaging your package](https://packaging.python.org/en/latest/guides/distributing-packages-using-setuptools/#packaging-your-project)

This produces a tarball (source build) and wheel that can be found
in the `dist` directory.

## Releasing the package

This package is only internal to Shadowserver at this time.
It gets released as a wheel file (`.whl` extension) to the projects
that use it.

To tag the project use:

    git tag -a v$(hatchling metadata version)

No tag message is necessary, but conventionally I've included a list changes using the commit subject line.

The `./.release-update.sh` script was created to ease the release of this
and other packages into two level projects (e.g. outputcattle and metis).
The script does require the `hatchling` Python dependency to operate.

The release script builds this package,
updates the package in the target project,
commits the change in that project,
and pushes the changes with parameters that create a merge request
that will automatically merge if all tests pass.

For example, run the following to release this package for outputcattle:

    ./.release-update.sh ../outputcattle

In this example, it is assumed the outputcattle codebase is checked out
in the parent directory. The result of this command is a merge request
created in the outputcattle codebase.
