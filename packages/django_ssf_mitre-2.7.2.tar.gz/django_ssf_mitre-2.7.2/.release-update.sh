#!/usr/bin/env bash
set +ex

# The intention of this script is
# to build and release the package,
# then update package in $project.
# If the $project contains a `.update-vendor-pkg.sh` script,
# the script is called with the $pkg_name argument.
# The $project script can then proceed as desired.

if ! command -v hatchling &> /dev/null; then
    echo "Error: Missing 'hatchling' dependency. Install using:  pip install hatchling"
    exit 1
fi

pkg_name=$(hatchling metadata name)
version=$(hatchling metadata version)


function build_release() {
    echo "Building release for ${pkg_name}"

    # Remove previous build and dist
    rm -rf ./build ./dist || true
    # Build the python wheel
    hatchling build
}

function update_project() {
    echo "Updating project ($1)"

    function recovery_handler() {
        echo "Error: ^^^"
        # move back to the previous working directory
        popd
        exit 1
    }
    pkg_here=$PWD
    trap "recovery_handler $pkg_here" ERR

    # Switch to the project for context specific commands
    pushd $1

    # Replace the previous released wheel
    _pkg_name=${pkg_name//-/_}
    git rm vendor/${_pkg_name}-*.whl
    # Vendor directory may disappear if this pkg was the only file
    mkdir -p vendor
    cp ${pkg_here}/dist/${_pkg_name}-${version}-py3-none-any.whl $1/vendor/
    git add vendor/${_pkg_name}-*.whl
    if [[ -f "./.update-vendor-pkg.sh" ]]; then
        ./.update-vendor-pkg.sh $_pkg_name
    fi

    # Return to location and reset error signal trap
    popd
    trap '' ERR
}

function verify_clean_project() {
    echo "Verifying project environment is clean"

    function recovery_handler() {
        echo "Error: ^^^"
        # move back to the previous working directory
        popd
        exit 1
    }
    pkg_here=$PWD
    trap "recovery_handler $pkg_here" ERR

    # Switch to the project for context specific commands
    pushd $1

    status=0
    git diff --exit-code || status=$?
    if [[ $status -ne 0 ]]; then
        echo "Error: dirty project repo at '$1', commit your changes first."
        exit 1
    fi
    git diff --exit-code --cached || status=$?
    if [[ $status -ne 0 ]]; then
        echo "Error: staged changes in project repo at '$1', please commit your changes first."
        exit 1
    fi

    # Return to location and reset error signal trap
    popd
    trap '' ERR
}

function main() {
    verify_clean_project $1
    build_release
    update_project $1
}

function print_help() {
    echo "Usage: $0 <project-directory>"
}


if [[ $# -eq 0 ]]; then
    print_help
    exit 1
elif [[ ! -d "$1" ]]; then
    print_help
    echo "Error: The project directory '$1' is not a directory on the filesystem"
    exit 1
fi

main $1
