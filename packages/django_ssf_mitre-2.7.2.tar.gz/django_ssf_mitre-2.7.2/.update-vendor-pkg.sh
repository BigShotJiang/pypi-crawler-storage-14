#!/usr/bin/env bash
set +ex

# This script is intended to be called by scripts in other packages we manage
# that release wheels into the 'vendor' directory of this project.
# The upstream script will update the release in the 'vendor' directory.
# It will also have the side-effect of staging the change in git before
# calling this script. So we are able to complete the git change as part of
# this script's actions.


default_remote_branch=$(git symbolic-ref refs/remotes/origin/HEAD)
default_branch=$(echo $default_remote_branch | cut -d '/' -f 4)


function main() {
    pkg_name=$1
    branch="update-${pkg_name}-$(date +'%d-%B-%Y')"

    echo "Update, commit and push release of ${pkg_name}"

    # Create a new working branch
    git checkout $default_remote_branch
    git branch -D $branch || true
    git checkout -b $branch $default_remote_branch

    # Find the name of the update wheel package
    whl_filepath=$(find vendor -name "${pkg_name}-*-py3-none-any.whl" -type f -print -quit)
    whl_filename=$(basename $whl_filepath)

    # Assume upstream calling script has already staged changes for the new wheel package file.

    # Make the adjustments to the requirements file
    # This is run in a `busybox` container to guarantee GNU sed is used.
    docker run --rm -v $PWD:/code -w /code busybox sh -c "sed -i 's/\(${pkg_name}-[.0-9]\+-py3-none-any\.whl\)/${whl_filename}/g' example_project/requirements.txt"
    git add example_project/requirements.txt

    # Commit and push the changes
    git commit -m "Update ${pkg_name} package"
    git push \
        -u --force-with-lease \
        origin $branch \
        -o merge_request.create \
        -o merge_request.target=$default_branch \
        -o merge_request.title="Automated update for the ${pkg_name} vendor package on $(date +'%d-%B-%Y')" \
        -o merge_request.merge_when_pipeline_succeeds
    git checkout $default_remote_branch
}

function print_help() {
    echo "Usage: $0 <package-name>"
    exit 1
}


if [[ $# -eq 0 ]]; then
    print_help
    exit 1
fi

main $1
