"""
A set of MITRE identifier patterns.

These patterns uniquely indentify objects by MITRE ID using a character prefix.

This package uses these patterns to create url paths, search by identifier,
rewrite urls in content description, etc.
"""

import re

from . import models


__all__ = (
    "DATASOURCE_ID_PATTERN",
    "GROUP_ID_PATTERN",
    "MATRIX_ID_PATTERN",
    "MITIGATION_ID_PATTERN",
    "SOFTWARE_ID_PATTERN",
    "TACTIC_ID_PATTERN",
    "TECHNIQUE_ID_PATTERN",
)


# In known cases, the character case of the mitre identifier does not matter.
# The position of the letters in the identifier are the important part.
# Identifier can therefore be matched with case insensitivity (i.e. `re.I`).
# However, they are written for case exact matching in view url registration,
# because we don't absolutely know that MITRE won't change to a character
# case-sensitive identifier scheme.
CAMPAIGN_ID_PATTERN = [models.Campaign, re.compile(r"(?P<slug>C[0-9]+)", re.I)]
DATASOURCE_ID_PATTERN = [models.DataSource, re.compile(r"(?P<slug>DS[0-9]+)", re.I)]
GROUP_ID_PATTERN = [models.Group, re.compile(r"(?P<slug>G[0-9]+)", re.I)]
MATRIX_ID_PATTERN = [models.Matrix, re.compile(r"(?P<slug>[-a-z0-9]+)", re.I)]
MITIGATION_ID_PATTERN = [models.Mitigation, re.compile(r"(?P<slug>M[0-9]+)", re.I)]
SOFTWARE_ID_PATTERN = [models.Software, re.compile(r"(?P<slug>S[0-9]+)", re.I)]
TACTIC_ID_PATTERN = [models.Tactic, re.compile(r"(?P<slug>TA[0-9]+)", re.I)]
TECHNIQUE_ID_PATTERN = [models.Technique, re.compile(r"(?P<slug>T[.0-9]+)", re.I)]
