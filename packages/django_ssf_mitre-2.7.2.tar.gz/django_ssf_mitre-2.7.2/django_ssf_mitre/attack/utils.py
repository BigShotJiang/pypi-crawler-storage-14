from . import patterns


__all__ = (
    "MATCHABLE_MODEL_PATTERNS",
    "get_model_by_id",
    "get_object_by_id",
)


MATCHABLE_MODEL_PATTERNS = (
    patterns.CAMPAIGN_ID_PATTERN,
    patterns.DATASOURCE_ID_PATTERN,
    patterns.GROUP_ID_PATTERN,
    patterns.MITIGATION_ID_PATTERN,
    patterns.SOFTWARE_ID_PATTERN,
    patterns.TACTIC_ID_PATTERN,
    patterns.TECHNIQUE_ID_PATTERN,
)


def get_model_by_id(id_: str):
    """Retrieve the model given the ``id_``."""
    for model, pattern in MATCHABLE_MODEL_PATTERNS:
        match = pattern.match(id_)
        if match:
            return model
    return None


def get_object_by_id(id_: str):
    """Retrieve the object for the given ``id_``.

    Raises ``ValueError`` when the identifier is invalid.
    Raises ``<Model>.DoesNotExist`` when the object cannot be found.

    """
    model = get_model_by_id(id_)
    if model is None:
        raise ValueError(f"Invalid identifier: {id_}")

    # Assume we shouldn't allow deprecated or revoked items to be found.
    # Let DoesNotExist raise in the event that the object can't be found.
    return model.objects.get(mitre_id=id_, deprecated=False, revoked=False)
