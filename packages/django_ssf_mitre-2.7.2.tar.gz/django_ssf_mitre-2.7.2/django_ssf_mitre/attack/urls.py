from django.urls import include, path, re_path
from django_ssf_core.utils.decorators import login_required, permission_required
from django_ssf_core.utils.models import model_permission_name

from ..core.utils import produce_paths_for_model
from ..core.views import AppIndexView
from . import models, patterns, views
from .filters import MitreAttackFilterSet


urlpatterns = [
    path(
        "",
        permission_required(
            # If you can view the matrix, you can view the navigation.
            model_permission_name(models.Matrix, "view"),
            raise_exception=True,
        )(AppIndexView.as_view(title="Mitre Att&ck")),
        name="mitreattack_index",
    ),
]

VIEWABLE_MODELS_AND_PK_PATTERNS = (
    # [<model>, <pattern>],
    patterns.CAMPAIGN_ID_PATTERN,
    patterns.DATASOURCE_ID_PATTERN,
    patterns.GROUP_ID_PATTERN,
    patterns.MATRIX_ID_PATTERN,
    patterns.MITIGATION_ID_PATTERN,
    patterns.SOFTWARE_ID_PATTERN,
    patterns.TACTIC_ID_PATTERN,
    patterns.TECHNIQUE_ID_PATTERN,
)


for model, regex_pk_pattern in VIEWABLE_MODELS_AND_PK_PATTERNS:
    urlpatterns += [
        path(
            f"{model._meta.model_name}/",
            #: regex_pk_pattern is an re.compile object; pull out the pattern
            include(
                produce_paths_for_model(
                    model, regex_pk_pattern.pattern, default_filterset_class=MitreAttackFilterSet
                )
            ),
        ),
    ]


# URLs for prefiltered records by Collection shortname
urlpatterns.extend(
    [
        re_path(
            r"^matrix/(?P<slug>[-a-z/]+)/$",
            permission_required(
                model_permission_name(models.Matrix, "view"), raise_exception=True
            )(views.MatrixDetailView.as_view()),
            name="mitreattack_detail_by_collection_matrix",
        ),
    ]
)


# Redirect to the correct model view based on the mitre id
urlpatterns.append(
    re_path(
        r"^redirect-id/(?P<mitre_id>[\w.]+)/",
        login_required(views.redirect_by_id),
        name="mitreattack_redirect_by_mitre_id",
    )
)
