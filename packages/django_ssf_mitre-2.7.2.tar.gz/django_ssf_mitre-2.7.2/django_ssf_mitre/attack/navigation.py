from django_ssf_core.utils.models import model_url_name
from django_ssf_core.utils.navigation import Navigation, NavigationItem

from .models import Matrix


class MatricesItem(NavigationItem):
    """Lookup the active (not deprecated) Matrix objects for navigation."""

    def __init__(self, *args, **kwargs):
        label = "Matrices"
        qs = Matrix.objects.exclude(deprecated=True)
        items = []
        for obj in qs.all():
            url_name = model_url_name(obj, "detail_by_collection")
            nav_details = {"name": url_name, "kwargs": {"slug": obj.slug}}
            items.append((obj.name, nav_details))
        super().__init__(label, items)


LABEL = "Mitre Att&ck"
ITEMS = [
    MatricesItem,
    ("Campaign", "mitreattack_index_campaign"),
    ("Tactics", "mitreattack_index_tactic"),
    ("Techniques", "mitreattack_index_technique"),
    ("Data Sources", "mitreattack_index_data_source"),
    ("Mitigations", "mitreattack_index_mitigation"),
    ("Groups", "mitreattack_index_group"),
    ("Software", "mitreattack_index_software"),
]


class MitreAttackNavigationItem(NavigationItem):
    def __init__(self, *args, **kwargs):
        super().__init__(LABEL, ITEMS)


class MitreAttackNavigation(Navigation):
    def __init__(self, *args, **kwargs):
        super().__init__((MitreAttackNavigationItem,))
