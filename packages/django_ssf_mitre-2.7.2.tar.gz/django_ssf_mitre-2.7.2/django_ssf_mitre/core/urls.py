from django.urls import include, path
from django_ssf_core.utils.decorators import permission_required
from django_ssf_core.utils.models import model_permission_name

from ..attack.models import Matrix
from . import views


urlpatterns = [
    path(
        "",
        permission_required(
            # FIXME Need a special permission for viewing navigation
            model_permission_name(Matrix, "view"),
            raise_exception=True,
        )(views.AppIndexView.as_view()),
        name="mitrecore_index",
    ),
    path("attack/", include("django_ssf_mitre.attack.urls")),
    path("mbc/", include("django_ssf_mitre.mbc.urls")),
]
