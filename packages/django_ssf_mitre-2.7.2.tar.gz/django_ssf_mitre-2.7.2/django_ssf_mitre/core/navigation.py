from django_ssf_core.utils.navigation import Navigation

from ..attack.navigation import MitreAttackNavigationItem
from ..mbc.navigation import MitreMBCNavigationItem


class MitreCoreNavigation(Navigation):
    def __init__(self, *args, **kwargs):
        super().__init__(
            (
                MitreAttackNavigationItem,
                MitreMBCNavigationItem,
            )
        )
