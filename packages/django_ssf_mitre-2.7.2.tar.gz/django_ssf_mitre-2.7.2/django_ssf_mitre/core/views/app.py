from django.views.generic import TemplateView


__all__ = ("AppIndexView",)


class AppIndexView(TemplateView):
    template_name = "mitrecore/app-index.html"
    title = None
