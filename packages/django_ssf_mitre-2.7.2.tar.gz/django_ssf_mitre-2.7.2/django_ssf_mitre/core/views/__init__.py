# Import all application views by default
from .app import *  # noqa: F401, F403
