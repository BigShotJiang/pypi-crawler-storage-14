# flake8: noqa: E221

from ...attack.utils import MATCHABLE_MODEL_PATTERNS as ATTACK_MATCHABLE_MODEL_PATTERNS
from ...mbc.utils import MATCHABLE_MODEL_PATTERNS as MBC_MATCHABLE_MODEL_PATTERNS


__all__ = (
    "get_model_by_id",
    "get_model_context",
    "get_object_by_id",
)


MATCHABLE_MODEL_PATTERNS_BY_CONTEXT = {
    "attack": ATTACK_MATCHABLE_MODEL_PATTERNS,
    "mbc": MBC_MATCHABLE_MODEL_PATTERNS,
    # prioritize attack over mbc when not specified
    None: ATTACK_MATCHABLE_MODEL_PATTERNS + MBC_MATCHABLE_MODEL_PATTERNS,
}


def get_model_context(model_or_object):
    """Provide the context given a model or instance of a model"""
    for ctx in (
        "attack",
        "mbc",
    ):
        for model, pattern in MATCHABLE_MODEL_PATTERNS_BY_CONTEXT[ctx]:
            if model is model_or_object or isinstance(model_or_object, model):
                return ctx
    raise ValueError("Could not find a context match for the given model or object.")


def get_model_by_id(id_: str, context: str = None):
    """Retrieve the model given the ``id_`` and ``context`` (i.e. attack or mbc)."""
    try:
        patterns = MATCHABLE_MODEL_PATTERNS_BY_CONTEXT[context]
    except KeyError:
        raise ValueError(f"invalid context specified: {context}")

    for model, pattern in patterns:
        match = pattern.match(id_)
        if match:
            return model
    return None


def get_object_by_id(id_: str, context: str = None):
    """Retrieve the object for the given ``id_`` and ``context`` (i.e. attack or mbc).

    Raises ``ValueError`` when the identifier is invalid.
    Raises ``<Model>.DoesNotExist`` when the object cannot be found.

    """
    model = get_model_by_id(id_, context)
    if model is None:
        raise ValueError(f"Invalid identifier: {id_}")

    # Assume we shouldn't allow deprecated or revoked items to be found.
    # Let DoesNotExist raise in the event that the object can't be found.
    return model.objects.get(mitre_id=id_, deprecated=False, revoked=False)
