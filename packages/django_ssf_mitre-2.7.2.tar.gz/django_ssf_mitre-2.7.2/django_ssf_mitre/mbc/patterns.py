# flake8: noqa: E221
import re

from . import models


__all__ = (
    "SOFTWARE_ID_PATTERN",
    "TACTIC_ID_PATTERN",
    "TECHNIQUE_ID_PATTERN",
)


# In known cases, the character case of the mitre identifier does not matter.
# The position of the letters in the identifier are the important part.
# Identifier can therefore be matched with case insensitivity (i.e. `re.I`).
# However, they are written for case exact matching in view url registration,
# because we don't absolutely know that MITRE won't change to a character
# case-sensitive identifier scheme.
# fmt: off
MATRIX_ID_PATTERN    = [models.Matrix,    re.compile(r"(?P<slug>[-a-z0-9]+)", re.I)]
SOFTWARE_ID_PATTERN  = [models.Software,  re.compile(r"(?P<slug>X[0-9]+)", re.I)]
TACTIC_ID_PATTERN    = [models.Tactic,    re.compile(r"(?P<slug>(OB|OC){1}[0-9]+)", re.I)]
TECHNIQUE_ID_PATTERN = [models.Technique, re.compile(r"(?P<slug>[BCEF]{1}[.0-9m]+)", re.I)]
# fmt: on
