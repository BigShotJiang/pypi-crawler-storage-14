from django.urls import include, path, re_path
from django_ssf_core.utils.decorators import login_required, permission_required
from django_ssf_core.utils.models import model_permission_name

from ..core.utils import produce_paths_for_model
from ..core.views import AppIndexView
from . import models, patterns, views


urlpatterns = [
    path(
        "",
        permission_required(
            #: Assuming you can view the app index if you have perms to view Matrix.
            model_permission_name(models.Matrix, "view"),
            raise_exception=True,
        )(AppIndexView.as_view(title="Mitre MBC")),
        name="mitrembc_index",
    ),
    # Matrix
    path(
        "matrix/",
        permission_required(
            model_permission_name(models.Matrix, "view"),
            raise_exception=True,
        )(views.MatrixIndexView.as_view()),
        name="mitrembc_index_matrix",
    ),
]

VIEWABLE_MODELS_AND_PK_PATTERNS = (
    # [<model>, <pattern>],
    # patterns.MATRIX_ID_PATTERN,  # Matrix is special
    patterns.SOFTWARE_ID_PATTERN,
    patterns.TACTIC_ID_PATTERN,
    patterns.TECHNIQUE_ID_PATTERN,
)

for model, regex_pk_pattern in VIEWABLE_MODELS_AND_PK_PATTERNS:
    urlpatterns += [
        path(
            f"{model._meta.model_name}/",
            #: regex_pk_pattern is an re.compile object; pull out the pattern
            include(produce_paths_for_model(model, regex_pk_pattern.pattern)),
        ),
    ]


# Redirect to the correct model view based on the mitre id
urlpatterns.append(
    re_path(
        r"^redirect-id/(?P<mitre_id>[\w.]+)/",
        login_required(views.redirect_by_id),
        name="mitrembc_redirect_by_mitre_id",
    )
)
