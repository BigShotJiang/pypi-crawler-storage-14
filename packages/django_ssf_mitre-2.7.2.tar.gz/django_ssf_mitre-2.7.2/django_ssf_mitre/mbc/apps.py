from pathlib import Path

from django.apps import AppConfig


HERE = Path(__file__).parent


class MitreMBCConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    label = "mitrembc"
    name = "django_ssf_mitre.mbc"
    path = HERE
