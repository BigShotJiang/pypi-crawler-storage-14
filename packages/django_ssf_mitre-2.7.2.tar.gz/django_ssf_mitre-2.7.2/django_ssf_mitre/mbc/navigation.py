from django_ssf_core.utils.navigation import Navigation, NavigationItem


LABEL = "Mitre MBC"
ITEMS = [
    ("Matrix", "mitrembc_index_matrix"),
    ("Objectives", "mitrembc_index_tactic"),
    ("Behaviors", "mitrembc_index_technique"),
    ("Malware", "mitrembc_index_software"),
]


class MitreMBCNavigationItem(NavigationItem):
    def __init__(self, *args, **kwargs):
        super().__init__(LABEL, ITEMS)


class MitreMBCNavigation(Navigation):
    def __init__(self, *args, **kwargs):
        super().__init__((MitreMBCNavigationItem,))
