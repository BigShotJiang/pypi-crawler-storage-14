# Changelog

## 0.1.1 (2025-11-28)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.1.0...v0.1.1)

### Bug Fixes

* ensure streams are always closed ([a95a16e](https://github.com/aimonlabs/dataframer-python-sdk/commit/a95a16e7916383d9a3d2df96ee349554c451ec84))


### Chores

* add Python 3.14 classifier and testing ([e4d8e08](https://github.com/aimonlabs/dataframer-python-sdk/commit/e4d8e0897bf3c2c6936631723966de48bfa5f8d1))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([43a3d31](https://github.com/aimonlabs/dataframer-python-sdk/commit/43a3d3126a63e93b73ebb4607856ef5d6a62bf3b))

## 0.1.0 (2025-11-20)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/aimonlabs/dataframer-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** fixed parameters to be compliant to openapi 3.0 ([a33ea08](https://github.com/aimonlabs/dataframer-python-sdk/commit/a33ea085d56276bacafee1e7363706e3c11df5cc))
* **api:** manual updates ([5b4b8e4](https://github.com/aimonlabs/dataframer-python-sdk/commit/5b4b8e465d31df281cab3c8b63915e77e7f9afc2))
* **api:** manual updates ([2cd2653](https://github.com/aimonlabs/dataframer-python-sdk/commit/2cd265380eb3acf273becce9835ceaf878680ba1))
* **api:** manual updates ([6103e74](https://github.com/aimonlabs/dataframer-python-sdk/commit/6103e7444bf36a5fc5e7c7e30a5ee6476921a220))
* **api:** manual updates ([943a854](https://github.com/aimonlabs/dataframer-python-sdk/commit/943a854003cc8017eef3d59891acb005d0224d98))
* **api:** manual updates ([80cf9d5](https://github.com/aimonlabs/dataframer-python-sdk/commit/80cf9d5b8d5c8c14b27571bc528aa84c5e92e6df))
* **api:** manual updates ([1d4f6c6](https://github.com/aimonlabs/dataframer-python-sdk/commit/1d4f6c6a765ad9d3a091e9101d45cbd6521ff668))
* **api:** manual updates ([536a4d5](https://github.com/aimonlabs/dataframer-python-sdk/commit/536a4d54c823082d6beadd346e3cc20c3ef0dddb))
* **api:** manual updates ([d34676b](https://github.com/aimonlabs/dataframer-python-sdk/commit/d34676b1c90a628e85185bce5587693bd24aefb6))
* **api:** manual updates ([94fa1ae](https://github.com/aimonlabs/dataframer-python-sdk/commit/94fa1ae5093d56e24ea66854274842040b532cb1))
* **api:** manual updates ([0956709](https://github.com/aimonlabs/dataframer-python-sdk/commit/09567093fda7443b66d5673d6392db801aa9a944))
* **api:** manual updates ([c53c0af](https://github.com/aimonlabs/dataframer-python-sdk/commit/c53c0af906e8a6369a6cb2a408fac2ac19c52e05))
* **api:** manual updates ([1171eba](https://github.com/aimonlabs/dataframer-python-sdk/commit/1171eba3c0a306e0c37e017febf5acc71a4c466a))
* **api:** manual updates ([e09640c](https://github.com/aimonlabs/dataframer-python-sdk/commit/e09640cecbd2f4d195be1a60251e5b79d1e8c972))
* **api:** manual updates ([02afcbf](https://github.com/aimonlabs/dataframer-python-sdk/commit/02afcbf699dc84e044150c8422a022847a5d69e5))
* **api:** manual updates ([23456d6](https://github.com/aimonlabs/dataframer-python-sdk/commit/23456d6511020ec8cbf29ecd4c0af63d6e540702))
* **api:** manual updates ([f91a639](https://github.com/aimonlabs/dataframer-python-sdk/commit/f91a639b50ab922466e2361a4d80eebe9b9e657d))
* **api:** manual updates ([d03e7b9](https://github.com/aimonlabs/dataframer-python-sdk/commit/d03e7b93bddbf5b658929c514d40d6bb2c4fab55))
* **api:** manual updates ([e5fa408](https://github.com/aimonlabs/dataframer-python-sdk/commit/e5fa408188a61f53dc89d9b7b200e1145f319d2b))
* **api:** manual updates ([eb310b1](https://github.com/aimonlabs/dataframer-python-sdk/commit/eb310b1dedf9050252d79025d67d7282801ec988))
* **api:** manual updates ([490a115](https://github.com/aimonlabs/dataframer-python-sdk/commit/490a1155282218f405eabc7866f0f3341e7c19e4))
* **api:** manual updates ([2b67257](https://github.com/aimonlabs/dataframer-python-sdk/commit/2b6725775a1f7d0645ea6d8b17897d8bb878ee8f))
* **api:** manual updates ([d18bbe6](https://github.com/aimonlabs/dataframer-python-sdk/commit/d18bbe60a14f218585db01a88222694f0ed69e0c))
* **api:** manual updates ([4dcff69](https://github.com/aimonlabs/dataframer-python-sdk/commit/4dcff69b5e23e1b83d0b4592edd185fb8cd544e9))
* **api:** manual updates ([b044068](https://github.com/aimonlabs/dataframer-python-sdk/commit/b044068b442db76449d709fd0e481e297c903273))
* **api:** manual updates ([8df4811](https://github.com/aimonlabs/dataframer-python-sdk/commit/8df48116575162bdc14eb14ae1e6cde1557dcd53))
* **api:** manual updates ([e2cbaed](https://github.com/aimonlabs/dataframer-python-sdk/commit/e2cbaed701a65ae3767ce4af5fb336251953745e))
* **api:** manual updates ([993c406](https://github.com/aimonlabs/dataframer-python-sdk/commit/993c406aa5c30a010726d96e10bcf673e6da34cc))
* **api:** manual updates ([747aa39](https://github.com/aimonlabs/dataframer-python-sdk/commit/747aa397012371d3c5ee839808f808f736a37baf))
* **api:** manual updates ([d64c197](https://github.com/aimonlabs/dataframer-python-sdk/commit/d64c19763f4b6b11a727d074f34832df6b8abeb6))
* **api:** manual updates ([cddd29f](https://github.com/aimonlabs/dataframer-python-sdk/commit/cddd29f91978c30a098a8d1ef352a04f89f46f35))
* **api:** manual updates ([a1023d4](https://github.com/aimonlabs/dataframer-python-sdk/commit/a1023d4349e6e813bd372f94c17c77f55ef2c6a4))
* **api:** manual updates ([f7d13cf](https://github.com/aimonlabs/dataframer-python-sdk/commit/f7d13cf428f2f79673c0a90ea4d95eb020fa513f))
* **api:** proper conversion to openapi 3.0 ([74b532e](https://github.com/aimonlabs/dataframer-python-sdk/commit/74b532e5864607c7eda1456c4af8f375f344b117))


### Bug Fixes

* compat with Python 3.14 ([312e95e](https://github.com/aimonlabs/dataframer-python-sdk/commit/312e95e153c0b9caa8bb19bed53ef1f9037a8c01))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([d7e8df0](https://github.com/aimonlabs/dataframer-python-sdk/commit/d7e8df0a5b50d5dec40fcb5601e3bac9e2e6e496))


### Chores

* **internal:** grammar fix (it's -&gt; its) ([79bea7b](https://github.com/aimonlabs/dataframer-python-sdk/commit/79bea7bcacc4cd201f9a663e8922a3a3c86fc4c1))
* **package:** drop Python 3.8 support ([aeda96a](https://github.com/aimonlabs/dataframer-python-sdk/commit/aeda96a83a70cfd3b799c0a1751199f2a5eedbaa))
* update SDK settings ([39d0dcb](https://github.com/aimonlabs/dataframer-python-sdk/commit/39d0dcb4dfa4c83656c3b3c169466ccf3cf17aaa))
* update SDK settings ([aaf8e3b](https://github.com/aimonlabs/dataframer-python-sdk/commit/aaf8e3b50292985c5392a51c605bf2b4c75148f0))
* update SDK settings ([e01ce10](https://github.com/aimonlabs/dataframer-python-sdk/commit/e01ce10e0056ff4dc0580500ee09a02504eee13f))
