# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["AnalyzeCreateParams"]


class AnalyzeCreateParams(TypedDict, total=False):
    dataset_id: Required[str]
    """ID of the dataset to analyze"""

    name: Required[str]
    """Name for the new spec to be created"""

    analysis_model_name: Literal["claude-3-5-sonnet-v2@20241022", "gpt-4o", "gpt-4o-mini"]
    """AI model to use for analysis"""

    description: str
    """Description of the spec"""

    extrapolate_axes: bool
    """Extrapolate to new axes/dimensions"""

    extrapolate_values: bool
    """Extrapolate new values beyond existing data ranges"""

    generate_distributions: bool
    """Generate statistical distributions from the data"""

    generation_objectives: str
    """Custom objectives or instructions for data generation"""

    use_truncation: bool
    """Apply truncation to limit value ranges"""
