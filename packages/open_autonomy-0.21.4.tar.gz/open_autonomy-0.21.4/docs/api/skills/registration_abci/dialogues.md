<a id="packages.valory.skills.registration_abci.dialogues"></a>

# packages.valory.skills.registration`_`abci.dialogues

This module contains the classes required for dialogue management.

