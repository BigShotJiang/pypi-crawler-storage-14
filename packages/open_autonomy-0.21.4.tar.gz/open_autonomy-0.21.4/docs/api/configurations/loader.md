<a id="autonomy.configurations.loader"></a>

# autonomy.configurations.loader

Service component base.

<a id="autonomy.configurations.loader.load_service_config"></a>

#### load`_`service`_`config

```python
def load_service_config(service_path: Path,
                        substitute_env_vars: bool = False) -> Service
```

Load service config from the path.

