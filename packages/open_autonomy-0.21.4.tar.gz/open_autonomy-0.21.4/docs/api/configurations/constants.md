<a id="autonomy.configurations.constants"></a>

# autonomy.configurations.constants

Configuration constants.

