<a id="autonomy.chain.constants"></a>

# autonomy.chain.constants

Chain constants

<a id="autonomy.chain.constants.CONTRACTS_DIR_LOCAL"></a>

#### CONTRACTS`_`DIR`_`LOCAL

use from an editable/local installation

<a id="autonomy.chain.constants.ERC20_TOKEN_ADDRESS_LOCAL"></a>

#### ERC20`_`TOKEN`_`ADDRESS`_`LOCAL

nosec

<a id="autonomy.chain.constants.GNOSIS_SAFE_PROXY_FACTORY_CONTRACT"></a>

#### GNOSIS`_`SAFE`_`PROXY`_`FACTORY`_`CONTRACT

Multisig WITHOUT recovery module

<a id="autonomy.chain.constants.GNOSIS_SAFE_SAME_ADDRESS_MULTISIG_CONTRACT"></a>

#### GNOSIS`_`SAFE`_`SAME`_`ADDRESS`_`MULTISIG`_`CONTRACT

Same address multisig WITHOUT recovery module

<a id="autonomy.chain.constants.SAFE_MULTISIG_WITH_RECOVERY_MODULE_CONTRACT"></a>

#### SAFE`_`MULTISIG`_`WITH`_`RECOVERY`_`MODULE`_`CONTRACT

Multisig WITH recovery module

<a id="autonomy.chain.constants.RECOVERY_MODULE_CONTRACT"></a>

#### RECOVERY`_`MODULE`_`CONTRACT

Same address multisig WITH recovery module

