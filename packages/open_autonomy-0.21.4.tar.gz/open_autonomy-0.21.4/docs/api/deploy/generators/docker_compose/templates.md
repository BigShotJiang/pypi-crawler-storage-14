<a id="autonomy.deploy.generators.docker_compose.templates"></a>

# autonomy.deploy.generators.docker`_`compose.templates

Deployment Templates.

<a id="autonomy.deploy.generators.docker_compose.templates.indent_yaml"></a>

#### indent`_`yaml

```python
def indent_yaml(data: Dict[str, str], level: int = 4) -> str
```

Convert dict to YAML and indent it properly.

