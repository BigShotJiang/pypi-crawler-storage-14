Find the latest version of the Python implementation of the [Open Autonomy](https://pypi.org/project/open-autonomy/) on PyPI.

If you are upgrading your AEA project from a previous version of the AEA framework, please check out [the upgrading guide](./upgrading.md).
