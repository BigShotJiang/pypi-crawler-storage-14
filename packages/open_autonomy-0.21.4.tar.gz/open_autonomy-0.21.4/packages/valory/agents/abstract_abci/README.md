# Abstract ABCI AEA

This agent blueprint uses the `abci` connection and the `abstract_abci` skill
to demonstrate a simple interaction between the components and the tendermint node.

Use for testing purposes only!
