# Register Terminate ABCI Agent Blueprint

This agent blueprint uses the registration and termination skills to test the termination feature.