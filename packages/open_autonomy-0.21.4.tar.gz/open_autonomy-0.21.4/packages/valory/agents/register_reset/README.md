# Register Reset ABCI Agent Blueprint

This agent blueprint uses the registration and reset skills to debug the Tendermint issue.
