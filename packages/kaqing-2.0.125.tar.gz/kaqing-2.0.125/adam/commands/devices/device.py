from abc import abstractmethod
from adam.repl_state import ReplState

class Device:
    @abstractmethod
    def ls(self, cmd: str, state: ReplState):
        pass

    def ls_completion(self, cmd: str, state: ReplState):
        return None
