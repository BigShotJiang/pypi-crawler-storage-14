from adam.commands.command import Command
from adam.commands.devices.device import Device
from adam.commands.export.utils_export import ExportDatabases
from adam.repl_state import ReplState
from adam.utils import lines_to_tabular, log

class DeviceExport(Command, Device):
    COMMAND = f'{ReplState.X}:'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DeviceExport, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DeviceExport.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not self.args(cmd):
            return super().run(cmd, state)

        state.device = ReplState.X

        return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, _: ReplState):
        return f'{DeviceExport.COMMAND}\t move to Export Database Operations device'

    def ls(self, cmd: str, state: ReplState):
        if state.export_session:
            self.show_export_tables(state.export_session)
        else:
            self.show_export_databases()

    def show_export_databases(self):
        log(lines_to_tabular(ExportDatabases.database_names(), 'NAME', separator=','))

    def show_export_tables(self, export_session: str):
        log(lines_to_tabular(ExportDatabases.table_names(export_session), 'NAME', separator=','))