# API reference

```{eval-rst}
.. automodule:: clig
    :members:
.. autofunction:: clig.run
.. autofunction:: clig.data
```
