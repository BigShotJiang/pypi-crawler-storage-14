"""
Parsers package for Amazon Bedrock model documentation.
Contains abstract base classes and concrete implementations for parsing documentation.
"""
