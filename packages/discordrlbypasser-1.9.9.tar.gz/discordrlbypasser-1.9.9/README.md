# DiscordRLBypasser

A Python library that syncs with various Discord libraries (discord.py, disnake, etc.) to bypass rate limits.

## Installation

```bash
pip install DiscordRLBypasser
```

## Usage

```python
from discordrlbypasser import DiscordRLBypasser

bypasser = DiscordRLBypasser()
bypasser.patch_libraries()

# Now use your Discord bot as usual
import discord
from discord.ext import commands

bot = commands.Bot(command_prefix='!')
# Your bot code here
```
