__version__ = "0.0.5"


def version():
    return __version__
