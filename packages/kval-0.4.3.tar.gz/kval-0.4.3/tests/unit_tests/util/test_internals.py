'''
Note: 

Turns out to be hard to do this testing - have to mock different backends/python environments.

A bit above my pay grade - skipping for now.
'''