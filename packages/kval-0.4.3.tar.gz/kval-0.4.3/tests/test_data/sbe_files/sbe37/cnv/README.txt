ØF:

This file is from a SBE37 that was on ATWAIN during 2013-2015. I've manually removed most of the data rows to reduce file size.