# Re-export classes for convenient imports
from .LinearRegression import LinearRegression

__all__ = ["LinearRegression"]
