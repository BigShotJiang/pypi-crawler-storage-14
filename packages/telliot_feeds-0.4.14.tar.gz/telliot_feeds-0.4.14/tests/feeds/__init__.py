"""Tests for example datafeeds."""
