"""Needed for the Ampleforth integration."""
