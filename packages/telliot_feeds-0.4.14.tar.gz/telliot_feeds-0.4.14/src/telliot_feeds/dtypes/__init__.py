""" :mod:`telliot_feeds.dtypes`

The Types package provides mechanisms to specify response dtypes
for Oracle Queries.
"""
# Copyright (c) 2021-, Tellor Development Community
# Distributed under the terms of the MIT License.
