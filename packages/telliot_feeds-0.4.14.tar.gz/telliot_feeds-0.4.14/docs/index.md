# Telliot Feed Examples

## Overview

This package provides tools for interacting with the Tellor Protocol.

!!! warning
    Use this software at your own risk.  **You could lose money, as this software is not optimized for profit, or there could be undiscovered bugs!**
    If you find any, please [submit an issue](https://github.com/tellor-io/telliot-core/issues),
    or [create a pull request](https://github.com/tellor-io/telliot-core/pulls)
    with a suggested fix.

