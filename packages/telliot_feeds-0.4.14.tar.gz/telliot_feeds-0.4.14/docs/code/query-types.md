::: telliot_feeds.queries.price.spot_price.SpotPrice

::: telliot_feeds.queries.string_query.StringQuery
