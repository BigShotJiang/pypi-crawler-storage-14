mammos
======

End-to-end workflows are shown in the following set of tutorials. Some require additional software, see `Requirements` at the top of the individual workflows.

.. toctree::
   :caption: Workflows
   :maxdepth: 1

   hard-magnet-tutorial
   hard-magnet-material-exploration
   sensor
