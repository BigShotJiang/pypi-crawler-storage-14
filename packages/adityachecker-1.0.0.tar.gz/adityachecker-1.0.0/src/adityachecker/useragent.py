import random
import re

class UserAgent:
    def __init__(self):
        self.windows_os = [
            '[Windows; |Windows; U; |]Windows NT 6.:number0-3:;[ Win64; x64| WOW64| x64|]',
            '[Windows; |Windows; U; |]Windows NT 10.:number0-5:;[ Win64; x64| WOW64| x64|]'
        ]
        
        self.linux_os = [
            '[Linux; |][U; |]Linux x86_64',
            '[Linux; |][U; |]Linux i:number5-6::number4-8::number0-6: [x86_64|]'
        ]
        
        self.mac_os = [
            'Macintosh; [U; |]Intel Mac OS X :number7-9:_:number0-9:_:number0-9:',
            'Macintosh; [U; |]Intel Mac OS X 10_:number0-12:_:number0-9:'
        ]
        
        self.android_versions = [
            '10', '11', '12', '13', '14', '15'
        ]
        
        self.android_devices = {
            '10': [
                'SM-G973F Build/QP1A.190711.020',
                'SM-G975F Build/QP1A.190711.020',
                'SM-N960F Build/QP1A.190711.020',
                'Pixel 4 Build/QD1A.190821.007',
                'Pixel 3a Build/QQ3A.200805.001',
                'ONEPLUS A6013 Build/QKQ1.190716.003',
                'Mi 9T Pro Build/QKQ1.190825.002'
            ],
            '11': [
                'SM-G991B Build/RP1A.200720.012',
                'SM-G998B Build/RP1A.200720.012',
                'Pixel 5 Build/RQ3A.210805.001',
                'Pixel 4a Build/RQ3A.210805.001',
                'ONEPLUS A5010 Build/RKQ1.201022.002',
                'M2101K6G Build/RKQ1.200826.002'
            ],
            '12': [
                'SM-S901B Build/SP1A.210812.016',
                'SM-S908B Build/SP1A.210812.016',
                'Pixel 6 Build/SD1A.210817.036',
                'Pixel 6 Pro Build/SD1A.210817.036',
                'ONEPLUS A8010 Build/SKQ1.211006.001',
                '2201116SG Build/SKQ1.211006.001'
            ],
            '13': [
                'SM-S911B Build/TP1A.220624.014',
                'SM-S918B Build/TP1A.220624.014',
                'Pixel 7 Build/TQ3A.230901.001',
                'Pixel 7 Pro Build/TQ3A.230901.001',
                'CPH2449 Build/TP1A.220905.001'
            ],
            '14': [
                'SM-S921B Build/UP1A.231005.007',
                'SM-S928B Build/UP1A.231005.007',
                'Pixel 8 Build/UQ1A.240205.004',
                'Pixel 8 Pro Build/UQ1A.240205.004'
            ],
            '15': [
                'Pixel 9 Build/AP31.240617.009',
                'Pixel 9 Pro Build/AP31.240617.009',
                'SM-S931B Build/VP1A.240505.001'
            ]
        }
        
        self.mobile_ios = {
            'iphone': 'iPhone; CPU iPhone OS :number15-18:_:number0-6:_:number0-3: like Mac OS X',
            'ipad': 'iPad; CPU OS :number15-18:_:number0-6: like Mac OS X'
        }
        
        self.chrome_versions = list(range(120, 140))
        self.android_version = None

    def process_random_numbers(self, text):
        def replace_number(match):
            min_val = int(match.group(1))
            max_val = int(match.group(2))
            return str(random.randint(min_val, max_val))
        return re.sub(r':number(\d+)-(\d+):', replace_number, text)

    def process_spin_syntax(self, text):
        def replace_spin(match):
            options = match.group(1).split('|')
            return random.choice(options)
        return re.sub(r'\[([\w\-\s|;]*?)\]', replace_spin, text)

    def get_os(self, os_type=None):
        if os_type == 'explorer':
            os_list = self.windows_os
        else:
            os_list = self.windows_os + self.linux_os + self.mac_os
        
        selected_os = random.choice(os_list).rstrip(';')
        
        if '[' in selected_os:
            selected_os = self.process_spin_syntax(selected_os)
        if ':number' in selected_os:
            selected_os = self.process_random_numbers(selected_os)
        
        if random.randint(1, 100) > 50:
            selected_os += '; en-US'
        
        return selected_os

    def get_mobile_os(self, os_type=None):
        if os_type == 'android':
            self.android_version = random.choice(self.android_versions)
            device = random.choice(self.android_devices.get(self.android_version, self.android_devices['14']))
            return f'Linux; Android {self.android_version}; {device}'
        elif os_type in ['iphone', 'ipad']:
            selected_os = self.mobile_ios[os_type]
            selected_os = self.process_random_numbers(selected_os)
            return selected_os
        else:
            if random.randint(1, 100) > 50:
                return self.get_mobile_os('android')
            else:
                return self.get_mobile_os(random.choice(['iphone', 'ipad']))

    def chrome_version(self):
        major = random.choice(self.chrome_versions)
        return f'{major}.0.{random.randint(4000, 6700)}.{random.randint(50, 250)}'

    def firefox_version(self):
        return f'{random.randint(100, 130)}.{random.randint(0, 9)}'

    def generate(self, agent_type=None):
        if agent_type is None:
            r = random.randint(0, 100)
            if r >= 30:
                agent_type = random.choice(['android', 'iphone'])
            else:
                agent_type = random.choice(['chrome', 'firefox'])
        
        if agent_type == 'chrome':
            os_string = self.get_os(agent_type)
            chrome_ver = self.chrome_version()
            webkit = random.randint(533, 537)
            safari = random.randint(533, 537)
            return f'Mozilla/5.0 ({os_string}) AppleWebKit/{webkit}.36 (KHTML, like Gecko) Chrome/{chrome_ver} Safari/{safari}.36'
        
        elif agent_type == 'firefox':
            os_string = self.get_os(agent_type)
            gecko = '20100101' if random.randint(1, 100) > 30 else '20130401'
            ff_ver = self.firefox_version()
            return f'Mozilla/5.0 ({os_string}; rv:{ff_ver}) Gecko/{gecko} Firefox/{ff_ver}'
        
        elif agent_type in ['android', 'mobile']:
            os_string = self.get_mobile_os('android')
            chrome_ver = self.chrome_version()
            return f'Mozilla/5.0 ({os_string}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_ver} Mobile Safari/537.36'
        
        elif agent_type in ['iphone', 'ipad']:
            os_string = self.get_mobile_os(agent_type)
            webkit = random.randint(600, 610)
            chrome_ver = self.chrome_version()
            return f'Mozilla/5.0 ({os_string}) AppleWebKit/{webkit}.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/{webkit}.1'
        
        else:
            return self.generate('android')

def get_random_useragent(agent_type=None):
    ua = UserAgent()
    return ua.generate(agent_type)

if __name__ == '__main__':
    for i in range(5):
        print(get_random_useragent())
        print()
