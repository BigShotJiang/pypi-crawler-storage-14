"""
Aditya Checker - Stripe Auth CC Checker
by Aditya
"""

__version__ = "1.0.0"
__author__ = "Aditya"

from .main import main
from .useragent import get_random_useragent
