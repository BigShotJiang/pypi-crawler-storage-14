# ⚡ Aditya Checker - Stripe Auth CC Checker

Fast and reliable Stripe Auth CC Checker by **Aditya**

## Installation

```bash
pip install adityachecker
```

## Usage

After installation, simply run:

```bash
adityachecker
```

The tool will ask you for:
1. **Telegram Bot Token** - Your bot token
2. **Telegram Chat ID** - Your chat ID for notifications
3. **Proxy File Path** - Path to proxy.txt (optional)

Then choose:
- **[1] Single CC Check** - Check one CC at a time
- **[2] Mass CC Check** - Check multiple CCs from file (3 parallel threads)

## Features

- Stripe Auth Gateway
- Telegram notifications for live cards
- Proxy support (IP:PORT or IP:PORT:USER:PASS)
- BIN lookup with country flags
- Fast parallel checking (3 threads)
- Monospace CC format for easy copy

## CC Format

```
CARD_NUMBER|MM|YYYY|CVV
```

Example:
```
4865608090273539|02|2026|540
```

## Proxy Format

Create a `proxy.txt` file with one proxy per line:

```
IP:PORT
```
or
```
IP:PORT:USERNAME:PASSWORD
```

## Contact

Telegram: [@Aditya](https://t.me/Tum_bhen_ke_laude)

## License

MIT License

---

**Made with ⚡ by Aditya**
