# This is actually an 'external' dependency, since it comes from a different package
from gauge.utils import something
