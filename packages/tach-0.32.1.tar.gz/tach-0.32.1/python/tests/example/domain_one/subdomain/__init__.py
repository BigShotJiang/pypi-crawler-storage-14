from __future__ import annotations

from domain_three.core import d3function

d3function()
