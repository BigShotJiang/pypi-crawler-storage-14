# tach-ignore(ok)
from module2 import something

from module4 import something_else