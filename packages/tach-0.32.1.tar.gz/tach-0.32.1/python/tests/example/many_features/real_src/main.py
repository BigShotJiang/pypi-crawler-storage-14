# tach-ignore
from external import something