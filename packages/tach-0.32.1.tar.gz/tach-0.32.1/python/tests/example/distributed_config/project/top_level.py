from project.module_one import module_one
from project.module_two import module_two


def top_level():
    module_one()
    module_two()
