from __future__ import annotations

x = 3

__all__ = ["x"]
