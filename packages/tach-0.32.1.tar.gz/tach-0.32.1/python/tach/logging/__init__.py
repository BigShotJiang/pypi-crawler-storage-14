from __future__ import annotations

from tach.logging.logger import CallInfo, logger

__all__ = ["logger", "CallInfo"]
