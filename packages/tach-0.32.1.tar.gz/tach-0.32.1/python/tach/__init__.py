from __future__ import annotations

__version__: str = "0.32.1"

__all__ = ["__version__"]
