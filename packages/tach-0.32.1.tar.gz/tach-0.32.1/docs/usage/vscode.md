# VSCode

Tach is installable as a VS Code extension which can be found [here](https://marketplace.visualstudio.com/items?itemName=detachhead.dtach).
Instructions for installation and setup are in the extension README and on the [marketplace link](https://marketplace.visualstudio.com/items?itemName=detachhead.dtach).

If you have any questions or run into any issues, let us know by submitting a [Github Issue](https://github.com/gauge-sh/tach/issues)!
