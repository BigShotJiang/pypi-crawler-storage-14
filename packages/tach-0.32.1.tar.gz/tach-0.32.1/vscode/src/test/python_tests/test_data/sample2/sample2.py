from __future__ import annotations

from sample1.sample import SAMPLE1

SAMPLE2 = "sample2"
print(SAMPLE1)
