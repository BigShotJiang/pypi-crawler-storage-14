
## How to file issues

This project uses [GitHub Issues](https://github.com/tach-org/tach/issues) to track bugs and feature requests. Please search the existing
issues before filing new issues to avoid duplicates. File your bug or
feature request as a new Issue.
