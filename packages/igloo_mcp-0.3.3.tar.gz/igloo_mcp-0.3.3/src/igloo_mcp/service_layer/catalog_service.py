"""Catalog service for service layer."""

from ..catalog.catalog_service import CatalogService

__all__ = ["CatalogService"]
