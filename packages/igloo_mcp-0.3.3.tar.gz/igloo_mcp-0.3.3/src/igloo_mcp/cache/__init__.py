"""Query result caching helpers."""

from .query_result_cache import CacheHit, QueryResultCache

__all__ = ["CacheHit", "QueryResultCache"]
