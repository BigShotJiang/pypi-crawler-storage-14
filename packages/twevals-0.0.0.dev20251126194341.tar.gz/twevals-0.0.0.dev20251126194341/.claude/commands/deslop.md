De-slop the changes

Slop refers to a style of coding that I do not like. The code make work, and tests may pass, but its about the style of code thats written. Your job is to review the changes and remove the slop.

This applies to uncommited changes, as well as changes against the dev branch if you are not already on it.