
class ProtocolException(Exception):
    pass

class ApplicationException(Exception):
    pass
