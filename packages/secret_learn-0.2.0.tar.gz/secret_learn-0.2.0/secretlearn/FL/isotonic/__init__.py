"""SecretFlow isotonic adapters"""
