from .communication.baseCommunicationService import BaseCommunicationService
from .repository.dynamodb import BaseDynamoDBRepository
from .aws import AWS
from .hashing.idObfuscation import IdObfuscationService
from .hashing.baseHashing import HashService
from .shortner import UrlService

# Export a global instance that supports await
hashIds = IdObfuscationService()

__all__ = [
    "BaseCommunicationService",
    "BaseDynamoDBRepository",
    "AWS",
    "HashService",
    "IdObfuscationService"
    "hashIds",
    "UrlService"
]