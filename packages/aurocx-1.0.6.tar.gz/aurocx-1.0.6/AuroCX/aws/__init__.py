from .services.AWSDynamoDb import DynamoDb
from .services.AWSLambda import Lambda
from .services.AWSS3 import S3
from .services.AWSSES import SES
from .services.AWSSNS import SNS
from .services.AWSSQS import SQS
from .services.AWSSSM import SSM
from .services.AWSSTS import STS

class AWS:
    DynamoDb = DynamoDb()
    Lambda = Lambda()
    S3 = S3()
    SES = SES()
    SNS = SNS()
    SQS = SQS()
    SSM = SSM()
    STS = STS()