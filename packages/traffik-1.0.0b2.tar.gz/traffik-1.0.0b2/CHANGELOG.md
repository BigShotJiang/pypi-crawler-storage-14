
Version 1.0.0b2 (2025-27-11)
----------------------------

- **Enhancements**:
  - Add support for cost parameter in rate limiting strategies.
  
- **Bug Fixes**:
  - Small code fixes and optimizations.
