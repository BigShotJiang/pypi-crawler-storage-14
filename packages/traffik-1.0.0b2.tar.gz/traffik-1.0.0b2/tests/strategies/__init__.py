"""Tests for rate limiting strategies."""
