"""
---
module: core.ai.q_assistant
summary: Wrapper around agentfoundry Orchestrator with enriched logging.
responsibilities:
  - Initialize Orchestrator with registered tools and LLM
  - Provide a simple API to answer questions
  - Pass identity context (user_id, thread_id, org_id) to Orchestrator for memory scoping
logging:
  levels:
    - INFO: high-level lifecycle and outcomes
    - DEBUG: inputs, constructed configs, timings, sizes
  notes:
    - Exceptions include full tracebacks
    - Question text is truncated to avoid logging sensitive content in full
---

QAssistant: a wrapper around the agentfoundry Orchestrator with rich logging.

This module provides extensive instrumentation to make production diagnosis
easier. It captures initialization details, per-question timings, and the
identity context used to scope Orchestrator memory.
"""

from __future__ import annotations

import logging
import time
from typing import Optional, Union, Tuple, Any

from agentfoundry.agents.orchestrator import Orchestrator
from agentfoundry.registry.tool_registry import ToolRegistry
from agentfoundry.llm.llm_factory import LLMFactory


class QAssistant:
    """
    ---
    name: QAssistant
    summary: Thin facade over Orchestrator that adds logging and a convenient API.
    methods:
      - answer_question
      - run_task
    dependencies:
      - agentfoundry.agents.orchestrator.Orchestrator
      - agentfoundry.registry.tool_registry.ToolRegistry
      - agentfoundry.llm.llm_factory.LLMFactory
    logging:
      info:
        - Initialization progress and success
        - Each question processed and high-level outcome
      debug:
        - Tool registry contents
        - IDs passed to Orchestrator and full config
        - Timings for chat calls
    ---

    A wrapper class for the Orchestrator to provide a simple interface for
    the digital assistant 'Q' to answer questions.
    """

    def __init__(self) -> None:
        """Create a new class:`QAssistant` instance.

        The constructor tries to build a class: Orchestrator.  When
        *agentfoundry* is not available (e.g., in lightweight environments or
        during unit-testing), we transparently fall back to a *stub mode* that
        returns an informative placeholder string.  All execution paths are
        thoroughly logged.
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        # Timestamp used to compute initialization duration later.
        _t0 = time.perf_counter()

        # Require agentfoundry components
        self.agent: Orchestrator | None = None
        if ToolRegistry is None or LLMFactory is None or Orchestrator is None:
            self.logger.error("Agentfoundry dependencies missing; cannot initialize Orchestrator")
            raise RuntimeError("Agentfoundry unavailable: ToolRegistry/LLMFactory/Orchestrator missing")

        # -------------------------------------------------------------------
        # Real agent initialisation
        # -------------------------------------------------------------------
        try:
            # Resolve LLM provider/model via AgentFoundry config + env overrides.
            # Environment variables can be populated via Secrets Manager at startup.
            self.logger.debug("Creating LLM instance using factory/provider defaults")
            llm = LLMFactory.get_llm_model()  # type: ignore[arg-type]

            tool_registry = ToolRegistry()
            tool_registry.load_tools_from_directory()
            self.logger.info(f"Registered tools: {tool_registry.list_tools()}")

            # Ensure the orchestrator has an agent→tools map. If none is provided,
            # default to a single general agent with all registered tools.
            available_tools = tool_registry.as_langchain_tools()
            agent_tools_map = getattr(tool_registry, 'agent_tools', None)
            if not isinstance(agent_tools_map, dict) or not agent_tools_map:
                tool_registry.agent_tools = {"general_agent": available_tools}
                self.logger.info("No agent_tools mapping provided; using default with %d tools", len(available_tools))

            # Initialize the Orchestrator; failure is fatal
            self.agent = Orchestrator(tool_registry, llm)
            self.logger.info("Orchestrator initialized successfully.")
        except Exception as e:  # pragma: no cover
            self.logger.exception(f"Failed to initialise Orchestrator: {e}")
            raise

    def answer_question(
            self,
            question: str,
            user_id: Optional[str] = None,
            thread_id: Optional[str] = None,
            org_id: Optional[str] = None,
    ) -> str:
        """
        ---
        method: answer_question
        summary: Answer a user question using Orchestrator with memory scoped by IDs.
        parameters:
          question:
            type: str
            required: true
            description: The user's natural-language question.
          user_id:
            type: str
            required: false
            description: Identity of the user; scopes memory. Defaults to "1" if not provided.
          thread_id:
            type: str
            required: false
            description: Conversation thread identifier; scopes memory. Defaults to "1" if not provided.
          org_id:
            type: str
            required: false
            description: Organization identifier; scopes memory. Defaults to "NA" if not provided.
        returns:
          type: str
          description: Assistant's reply.
        raises:
          - RuntimeError: if the underlying agent is not initialized.
          - Exception: any error raised by the Orchestrator; logged with traceback.
        logging:
          info:
            - Start/end of processing with truncated question and reply
          debug:
            - IDs used and constructed config
            - Call duration and reply length
        ---

        Answer a question using the underlying Orchestrator agent. The
        Orchestrator maintains memory keyed by the provided IDs.
        """

        self.logger.info(f"Processing question: {question[:85]}...")

        if not self.agent:
            self.logger.error("QAssistant agent not initialized; aborting")
            raise RuntimeError("QAssistant unavailable: Orchestrator not initialized")

        _t0 = time.perf_counter()
        try:
            self.logger.info("QAssistant mode=agent (chat)")
            messages = []
            # Opportunistic user-memory recall targeted to the question to
            # improve personal answers (e.g., "my eye color") even when the
            # agent chooses not to invoke tools on its own.
            try:
                if user_id and org_id:
                    from agentfoundry.agents.memory.user_memory import UserMemory as _UM
                    um = _UM(user_id, org_id)
                    hits = um.semantic_search(question, caller_role_level=0, k=5)
                    if hits:
                        snippet = "\n".join(f"- {h}" for h in hits)
                        self.logger.info("QAssistant preloaded %d user-memory hits for query", len(hits))
                        messages.append({"role": "system", "content": f"USER_MEMORY_HITS:\n{snippet}"})
            except Exception as _um_ex:  # noqa: E722  (defensive)
                self.logger.debug("UserMemory preload failed: %s", _um_ex)

            messages.append({"role": "user", "content": question})
            # Build RunnableConfig for Orchestrator memory scoping.
            cfg = {
                "configurable": {
                    "user_id": user_id or "1",
                    "thread_id": thread_id or "1",
                    "org_id": org_id or "NA",
                    # Intentionally omitting security_level as requested.
                }
            }
            # Log whether any defaults were used (helps diagnose memory scoping).
            if user_id is None or thread_id is None or org_id is None:
                self.logger.debug(
                    "One or more IDs not provided; using defaults -> user_id=%s thread_id=%s org_id=%s",
                    cfg["configurable"]["user_id"], cfg["configurable"]["thread_id"], cfg["configurable"]["org_id"],
                )
            self.logger.debug(
                "Calling orchestrator.chat with ids user_id=%s thread_id=%s org_id=%s",
                cfg["configurable"]["user_id"], cfg["configurable"]["thread_id"], cfg["configurable"]["org_id"],
            )
            response = self.agent.chat(messages, config=cfg)
            elapsed = time.perf_counter() - _t0
            self.logger.debug("agent.chat completed in %.3f s (reply_len=%d)", elapsed, len(str(response)))
            self.logger.info("Response: %s", response)
            return response
        except Exception:
            self.logger.exception("Exception while processing question: %s", question)
            raise

    def run_task(self, task: str, *, use_memory: bool = False, additional: bool = False,
                 allow_tools: bool = False, allowed_tool_names: list[str] | None = None,
                 file_ids: list | None = None, vector_store_id: str | None = None) -> Union[str, Tuple[str, Any]]:
        """
        ---
        method: run_task
        summary: Execute a single-turn task via Orchestrator.run_task.
        notes:
          - Stateless helper intended for one-off operations or smoke tests.
          - Set use_memory=true to inject summarized memory context (optional).
        parameters:
          task:
            type: str
            required: true
            description: The instruction or question to execute.
          use_memory:
            type: bool
            required: false
            default: false
            description: When true, Orchestrator adds a summarized memory context.
          additional:
            type: bool
            required: false
            default: false
            description: When true, also returns full supervisor outputs.
        returns:
          type: str | tuple[str, Any]
          description: Assistant reply, optionally with the full responses' payload.
        raises:
          - RuntimeError: if the agent is not initialized.
          - Exception: bubbled up from the Orchestrator and logged with traceback.
        ---

        Execute a single-turn task through the Orchestrator's run_task helper.
        """
        self.logger.info(f"Running task (stateless): {task[:85]}...")
        try:
            _n_files = len(file_ids or [])
        except Exception:
            _n_files = 0
        self.logger.debug(
            "run_task params: use_memory=%s additional=%s allow_tools=%s allowed_tool_names=%s file_ids_count=%d vector_store_id=%s",
            use_memory, additional, allow_tools, bool(allowed_tool_names), _n_files, bool(vector_store_id),
        )

        if not self.agent:
            self.logger.error("QAssistant agent not initialized; aborting")
            raise RuntimeError("QAssistant unavailable: Orchestrator not initialized")

        _t0 = time.perf_counter()
        try:
            # If file IDs are provided, route via chat() so the underlying
            # Orchestrator can attach files to the request (Responses API).
            if file_ids:
                self.logger.info(
                    "Routing run_task via chat() due to file attachments (files=%d)",
                    len(file_ids or []),
                )
                messages = [{"role": "user", "content": task}]
                # Use the same config path; Orchestrator.chat will include memory
                # as a system message automatically.
                result = self.agent.chat(messages, config=None, additional=additional, file_ids=file_ids, vector_store_id=vector_store_id)
            else:
                self.logger.debug(
                    f"Calling orchestrator.run_task(use_memory={use_memory}, additional={additional}) without file attachments"
                )
                result = self.agent.run_task(
                    task,
                    use_memory=use_memory,
                    additional=additional,
                    allow_tools=allow_tools,
                    allowed_tool_names=allowed_tool_names,
                )
            elapsed = time.perf_counter() - _t0
            # Normalize logging for both return shapes
            if isinstance(result, tuple) and len(result) >= 1:
                reply = result[0]
            else:
                reply = result  # type: ignore[assignment]
            self.logger.debug(
                "run_task completed in %.3f s (reply_len=%d, routed_via=%s)",
                elapsed,
                len(str(reply)),
                ("chat" if file_ids else "run_task"),
            )
            self.logger.info("Task response head: %s", str(reply)[:300])
            return result
        except Exception:
            self.logger.exception("Exception while running task: %s", task)
            raise


if __name__ == "__main__":
    # Initialize required components
    # Create a QAssistant instance
    assistant = QAssistant()

    # Test with a simple question
    question = "Who wrote the book 'Core Security Patterns'?"
    response = assistant.answer_question(question)

    # Verify response
    print(f"Response: {response}")
