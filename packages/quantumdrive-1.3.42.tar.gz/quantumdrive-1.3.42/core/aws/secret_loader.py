from __future__ import annotations

import os
from pathlib import Path
from typing import Mapping

from core.aws.secrets_manager import SecretsManager

_DEFAULT_DEMO_ENV = Path.cwd() / "demo.env"
DEMO_ENV_FILE = Path(os.getenv("QUANTIFY_DEMO_ENV_FILE", str(_DEFAULT_DEMO_ENV)))


def load_env_from_secret(
    secret_name: str | None = None,
    *,
    region_name: str | None = None,
    overwrite: bool = False,
    persist: bool = False,
) -> dict:
    """
    Load key/value pairs from AWS Secrets Manager and inject them into os.environ.

    - secret_name: The name/ARN of the secret. Defaults to env QUANTIFY_CONFIG_SECRET
      or 'quantify/app/config' when not set.
    - region_name: Optional region override (falls back to default boto3 resolution).
    - overwrite: When True, overwrites existing environment variables; otherwise only sets
      variables that are not already present in the process environment.

    Returns a dict of the keys that were applied to the environment.
    """
    name = secret_name or os.getenv('QUANTIFY_CONFIG_SECRET') or 'quantify/app/config'
    sm = SecretsManager(name, region_name=region_name or os.getenv('AWS_REGION', 'us-east-1'))
    data = sm.get_secret() or {}
    if not isinstance(data, Mapping):
        return {}
    applied: dict[str, str] = {}
    for k, v in data.items():
        key = str(k)
        val = '' if v is None else str(v)
        if overwrite or key not in os.environ:
            os.environ[key] = val
            applied[key] = val
        # Normalize dotted keys to underscore form expected by env lookups, e.g. CHROMA.URL -> CHROMA_URL
        if '.' in key:
            norm = key.replace('.', '_')
            if overwrite or norm not in os.environ:
                os.environ[norm] = val
                applied[norm] = val
    # Compatibility shims for historical/variant keys
    # Map CHROMADB_PERSIST_DIR -> CHROMA_PERSIST_DIR if the latter is missing
    if 'CHROMADB_PERSIST_DIR' in os.environ and 'CHROMA_PERSIST_DIR' not in os.environ:
        os.environ['CHROMA_PERSIST_DIR'] = os.environ['CHROMADB_PERSIST_DIR']
        applied['CHROMA_PERSIST_DIR'] = os.environ['CHROMA_PERSIST_DIR']
    # Map generic PERSISTENCE_DIR (used in some configs) to CHROMA_PERSIST_DIR if missing
    if 'PERSISTENCE_DIR' in os.environ and 'CHROMA_PERSIST_DIR' not in os.environ:
        os.environ['CHROMA_PERSIST_DIR'] = os.environ['PERSISTENCE_DIR']
        applied['CHROMA_PERSIST_DIR'] = os.environ['CHROMA_PERSIST_DIR']
    if persist and applied:
        _persist_demo_env(applied)
    return applied


def _persist_demo_env(values: Mapping[str, str]) -> None:
    """
    Persist the applied configuration values to demo.env so offline environments
    can preload the same settings without Secrets Manager.
    """
    if not values:
        return
    try:
        existing: dict[str, str] = {}
        if DEMO_ENV_FILE.exists():
            for line in DEMO_ENV_FILE.read_text().splitlines():
                if not line or line.strip().startswith("#") or "=" not in line:
                    continue
                key, _, raw_val = line.partition("=")
                existing[key.strip()] = raw_val.strip().strip('"')
        # merged preference: new values overwrite previous entries
        merged = {**existing, **{k: str(v) for k, v in values.items()}}
        DEMO_ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
        with DEMO_ENV_FILE.open("w", encoding="utf-8") as fh:
            for key in sorted(merged):
                safe_val = merged[key].replace("\\", "\\\\").replace('"', r'\"')
                fh.write(f'{key}="{safe_val}"\n')
    except Exception:
        # Silent failure: demo env persistence should never block main flow
        pass
