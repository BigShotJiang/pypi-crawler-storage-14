#!/usr/bin/env python
import os
import subprocess
from setuptools import setup, find_packages

def get_git_tag():
    try:
        tag = subprocess.check_output(
            ["git", "describe", "--tags", "--abbrev=0"],
            stderr=subprocess.STDOUT
        ).decode().strip()
        return tag.lstrip('v')
    except subprocess.CalledProcessError:
        # Fallback to VERSION file if present (for sdist installs without .git)
        version_file = os.path.join(os.path.dirname(__file__), 'VERSION')
        if os.path.exists(version_file):
            with open(version_file, 'r') as vf:
                return vf.read().strip()
        return "0.0.0"

# read in requirements.txt, ignoring comments and blank lines
req_file = os.path.join(os.path.dirname(__file__), "requirements.txt")
if os.path.exists(req_file):
    with open(req_file, encoding="utf-8") as f:
        install_requires = [
            line.strip()
            for line in f
            if line.strip() and not line.startswith("#")
        ]
else:
    install_requires = []

# optionally read a README if you have one
long_description = ""
readme_file = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_file):
    with open(readme_file, encoding="utf-8") as f:
        long_description = f.read()

setup(
    # Distributed package name published to PyPI / internal index
    name="quantumdrive",
    # Keep the version in-sync with pyproject.toml to avoid confusion
    version=get_git_tag(),
    author="Chris Steel",
    author_email="chris.steel@alphsix.com",
    description="QuantumDrive platform and SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="AlphaSix Proprietary License",
    license_files=("LICENSE",),
    # The runtime Python import packages that should be included in the
    # distribution.  The project is published as `quantumdrive`, but the
    # actual import roots currently live under the `core` and `webapp`
    # directories.  We therefore include those while excluding assets and
    # test data that shouldn't be shipped.
    # Automatically discover python import packages rooted at the project
    # top-level while skipping directories that are not meant for
    # distribution (test suites, demos, large data bundles, etc.).
    packages=find_packages(
        exclude=[
            "tests*",
            "demo*",
            "data*",
            "dist*",
            "logs*",
        ],
    ),
    install_requires=install_requires,
    python_requires=">=3.11,<3.14",
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
    ],
    entry_points={
        # if you later want to expose a CLI, you can add:
        # "console_scripts": [
        #     "agentforge-orch = agentforge.orchestrator:main",
        # ],
    },
)
