# make this a namespace packages (plone.app.theming.plugins is an
# extensible python namespace
__import__("pkg_resources").declare_namespace(__name__)
