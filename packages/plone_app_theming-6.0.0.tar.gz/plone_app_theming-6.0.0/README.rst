This package offers a simple way to develop and deploy Plone themes using the Diazo theming engine. 
If you are not familiar with Diazo, check out the `Diazo documentation <http://diazo.org>`_.

It comes with a user guide, reproduced below, available through the theming
control panel.
