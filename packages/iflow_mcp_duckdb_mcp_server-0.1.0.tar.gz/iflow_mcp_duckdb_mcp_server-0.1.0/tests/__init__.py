"""
Test package for the MCP DuckDB server.
"""