# DuckDB Documentation XML Files

This directory contains XML documentation files for DuckDB features.

- `duckdb_friendly_sql.xml`: Documentation on DuckDB's friendly SQL features
- `duckdb_data_import.xml`: Documentation on importing data from various sources