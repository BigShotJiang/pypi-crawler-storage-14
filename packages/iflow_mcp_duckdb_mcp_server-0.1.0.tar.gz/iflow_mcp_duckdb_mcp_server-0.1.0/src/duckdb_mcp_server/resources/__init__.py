"""
Resources for the DuckDB MCP server.
"""

# This package contains resources like documentation