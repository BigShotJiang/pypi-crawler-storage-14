# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.


# pyfrontkit/dom.py

# Simple global DOM manager and generator of functions by id (accumulative).

from typing import Dict, Optional
import builtins
# Importamos aquí la clase Block para evitar dependencias circulares
from .block import Block 
# CSSRegistry se importará localmente en add_children, lo cual es más seguro.

class DOMManager:
    """
    Global registry of blocks by id. Creates global functions (in builtins)
    to allow adding children by id with the syntax:
        Div(id='parent')
        parent(child1, child2)
    Calls are accumulative (they append children).
    """
    def __init__(self):
        self._by_id: Dict[str, object] = {}

    def register(self, id_name: str, block_obj):
        """Registers the block in the DOM. Creates the global function to add children."""
        try:
            if not id_name:
                return

            # replace: if it already exists, overwrite the object reference
            self._by_id[id_name] = block_obj

            # Create global function 'id_name' that appends children to the block (accumulative).
            if id_name.isidentifier():
                # define a function capturing id_name (avoid late-binding)
                def make_adder(name):
                    def adder(*children):
                        # La llamada CRÍTICA a add_children
                        return DOM.add_children(name, *children)
                    return adder

                adder_func = make_adder(id_name)
                # Poniéndolo en builtins permite la sintaxis global `parent(...)`
                setattr(builtins, id_name, adder_func)
        except Exception as e:
            # 🐞 Debugging temporal: Error al registrar un ID en el DOM o crear la función
            print(f"❌ DOM DEBUG ERROR in register ID '{id_name}': {e}")
            raise # Re-lanza la excepción

    def get(self, id_name: str) -> Optional[Block]:
        return self._by_id.get(id_name)


    def add_children(self, parent_id: str, *children) -> Block:
        """
        Añade hijos al bloque padre por su ID y fuerza el re-registro CSS
        del padre para generar las nuevas cascadas.
        """
        try:
            parent = self.get(parent_id)
            if parent is None:
                raise KeyError(f"No block exists with id='{parent_id}'")

             # Add children normally (llama a block.py:add_child)
            parent.add_child(*children)

            # ⭐ PUNTO CRÍTICO DEL BUG: 
            # Re-registrar el padre en CSS para generar las cascadas en memoria.
            from .css_register import CSSRegistry
            CSSRegistry.register_block(parent)

            return parent
        except Exception as e:
            # 🐞 Debugging temporal: Error al añadir hijos
            print(f"❌ DOM DEBUG ERROR in add_children to '{parent_id}': {e}")
            raise # Re-lanza la excepción


# Create DOM singleton to be used from other modules
DOM = DOMManager()