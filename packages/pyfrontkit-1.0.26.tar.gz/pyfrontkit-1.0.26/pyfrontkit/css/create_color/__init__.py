# ----------------------------------------------------------------------
# create_color/__init__.py
# ----------------------------------------------------------------------

# Expose main class
from .create_color import CreateColor

# Expose all palettes and their internal rules
try:
    from .palettes_homologous import palette_homologous, homologous_color_rule
    from .palettes_triadic import palette_triadic, triadic_color_rule
    from .palettes_tetradic import palette_tetradic, tetradic_color_rule
except ImportError:
    # If any palette module does not exist yet, ignore
    pass

# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------
__all__ = [
    "CreateColor",
    "palette_homologous", "homologous_color_rule",
    "palette_triadic", "triadic_color_rule",
    "palette_tetradic", "tetradic_color_rule",
]
