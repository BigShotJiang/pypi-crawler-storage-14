# sage_setup: distribution = sagemath-glpk

from sage.all__sagemath_glpk import *
