from mcp.server.fastmcp import FastMCP
import platform
import psutil
import json



# 1. 创建一个 FastMCP 实例，用于运行 MCP 协议服务
mcp = FastMCP("host info mcp")



# 向 MCP 注册一个工具
@mcp.tool()
def get_host_info() -> str:
    mem = psutil.virtual_memory()
    info : dict[str, str] = {
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "precessor": platform.processor(),
        "cpu_count": str(psutil.cpu_count()),
        "memory_total_gb": str(round(mem.total / (1024**3), 2)),     # 总内存 GB
        "memory_used_gb": str(round(mem.used / (1024**3), 2)),       # 已用内存 GB
        "memory_available_gb": str(round(mem.available / (1024**3), 2)),  # 可用内存 GB
        "memory_percent": str(round(mem.percent, 1))                 # 使用百分比
        
    }
    
    return json.dumps(info, indent=4)



# 主入口函数
def main() -> None:
    # 启动 MCP 服务，使用 "stdio" 通道（标准输入输出）
    # 也可以用 "sse" 表示通过 Server-Sent Events 通信
    # StreamableHTTP: 支持流式传输的 HTTP
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
