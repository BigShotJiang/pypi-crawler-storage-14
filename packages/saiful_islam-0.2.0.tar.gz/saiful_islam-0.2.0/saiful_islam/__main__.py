from .speakers import Saiful

def main():
    Saiful().print_name()

if __name__ == "__main__":
    main()