from .base import KittyCadBaseModel


class SelectClear(KittyCadBaseModel):
    """The response from the `SelectClear` endpoint."""
