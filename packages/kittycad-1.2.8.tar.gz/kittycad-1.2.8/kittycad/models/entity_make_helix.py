from .base import KittyCadBaseModel


class EntityMakeHelix(KittyCadBaseModel):
    """The response from the `EntityMakeHelix` endpoint."""
