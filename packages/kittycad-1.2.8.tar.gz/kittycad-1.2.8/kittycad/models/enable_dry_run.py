from .base import KittyCadBaseModel


class EnableDryRun(KittyCadBaseModel):
    """The response from the `EnableDryRun` endpoint."""
