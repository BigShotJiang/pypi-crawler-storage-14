from .base import KittyCadBaseModel


class SetBackgroundColor(KittyCadBaseModel):
    """The response from the `SetBackgroundColor` endpoint."""
