from .base import KittyCadBaseModel


class SetObjectTransform(KittyCadBaseModel):
    """The response from the `SetObjectTransform` command."""
