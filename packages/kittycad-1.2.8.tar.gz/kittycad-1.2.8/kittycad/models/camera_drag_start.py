from .base import KittyCadBaseModel


class CameraDragStart(KittyCadBaseModel):
    """The response from the `CameraDragStart` endpoint."""
