from .base import KittyCadBaseModel


class ExtrudeToReference(KittyCadBaseModel):
    """The response from the `ExtrudeToReference` endpoint."""
