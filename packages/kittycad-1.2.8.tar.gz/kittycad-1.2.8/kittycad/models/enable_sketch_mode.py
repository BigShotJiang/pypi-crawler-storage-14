from .base import KittyCadBaseModel


class EnableSketchMode(KittyCadBaseModel):
    """The response from the `EnableSketchMode` endpoint."""
