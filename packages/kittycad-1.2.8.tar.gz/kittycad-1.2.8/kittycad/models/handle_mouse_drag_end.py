from .base import KittyCadBaseModel


class HandleMouseDragEnd(KittyCadBaseModel):
    """The response from the `HandleMouseDragEnd` endpoint."""
