from .base import KittyCadBaseModel


class SetCurrentToolProperties(KittyCadBaseModel):
    """The response from the `SetCurrentToolProperties` endpoint."""
