from .base import KittyCadBaseModel


class HandleMouseDragStart(KittyCadBaseModel):
    """The response from the `HandleMouseDragStart` endpoint."""
