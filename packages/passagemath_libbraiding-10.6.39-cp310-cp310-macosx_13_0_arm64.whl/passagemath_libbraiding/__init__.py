# sage_setup: distribution = sagemath-libbraiding

from sage.all__sagemath_libbraiding import *
