"""Configuration management for MXCP.

This module handles loading and parsing of site and user configurations.
"""
