from google.apps import meet_v2
from .service import aget_service
from googleapiclient.errors import HttpError

async def create_space() -> dict:
    """
    There is no sync function for creating spaces.
    So this an asynchronous function that creates spaces which is actually google meet link for the meeting.

    Returns:
        dict: Meeting space details.

    Raises:
        Exception: For errors to create space.
    """
    try:
        service = await aget_service('meet')
        request = meet_v2.CreateSpaceRequest(
            space=meet_v2.Space()
        )
        response = await service.create_space(request=request)
        meeting_space = {
            'name': response.name,
            'meeting_url': response.meeting_uri,
            'meeting_code': response.meeting_code,
            'config': response.config
        }
        return meeting_space
    except HttpError as error:
        raise Exception(f" Error {error}")