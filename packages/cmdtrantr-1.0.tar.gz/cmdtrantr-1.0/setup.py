from setuptools import setup, find_packages

setup(
    name="cmdtrantr",
    version="1.0",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "cmdtrantr=cmdtrantr.main:main",
        ],
    },
    description="CMD Çeviri CLI Paketi (API Yok)",
    author="YusufStudio18",
    author_email="yusufstudio913@gmail.com",
    include_package_data=True,
)