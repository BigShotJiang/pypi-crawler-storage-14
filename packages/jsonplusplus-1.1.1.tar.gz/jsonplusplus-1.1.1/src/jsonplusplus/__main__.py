"""
Point d'entrée pour l'exécution en tant que module.
Permet d'utiliser: python -m jsonplusplus
"""

from .cli import main

if __name__ == "__main__":
    main()

