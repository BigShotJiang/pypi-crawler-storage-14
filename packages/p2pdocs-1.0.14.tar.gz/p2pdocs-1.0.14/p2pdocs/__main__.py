"""
Main entry point when running as a module: python -m p2pdocs
"""

from .cli import main

if __name__ == "__main__":
    main()
