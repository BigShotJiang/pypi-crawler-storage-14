"""
UI styling constants and color schemes.
"""

# Color scheme
PRIMARY = "#3491e8"
BG_LIGHT = "#f6f7f8"
BG_SIDEBAR = "#ffffff"
BG_SIDEBAR_OPACITY = "#fcfcfc"
TEXT_DARK = "#1f2937"
TEXT_GRAY = "#6b7280"
TEXT_LIGHT = "#9ca3af"
GREEN = "#10b981"
BORDER_COLOR = "#e5e7eb"

# Avatar colors for peers
AVATAR_COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#8b5cf6", "#ec4899"]

# Peer list colors
BG_HIGHLIGHT = "#e0f2fe"
BG_HOVER = "#f9fafb"
