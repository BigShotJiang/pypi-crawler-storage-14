"""
UI module for P2P collaborative text editor.
"""

from .editor import P2PEditor
from . import styles

__all__ = ['P2PEditor', 'styles']
