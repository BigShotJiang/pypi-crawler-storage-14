from typing import List, Optional
from dataclasses import dataclass
import uuid
import json

from ..auxiliary.changelog_entry import ChangelogEntry
from ..auxiliary.correlations import Correlations
from ..auxiliary.state import State

from .quantity_values import QuantityValues

@dataclass
class Measurement:
    """
    Represents a measurement in the experiment.
    """
    id: str = None
    description: Optional[str] = None
    changelog: Optional[List[ChangelogEntry]] = None
    correct: Optional[bool] = None
    state: Optional[List[State]] = None
    results: List[QuantityValues] = None
    correlations: Optional[Correlations] = None
    measurands: Optional[List[str]] = None
    source: Optional["Source"] = None # Use forward reference for Source

    def __post_init__(self):
        """Generates a UUID for the id field if it's not provided."""
        if self.id is None:
            self.id = str(uuid.uuid4())

        # Delay the import of Source until the object is fully initialized
        if isinstance(self.source, dict):
            from .source import Source
            self.source = Source(**self.source)

    def to_dict(self):
        return {
            "id": self.id,
            "description": self.description,
            "changelog": [entry.to_dict() for entry in self.changelog] if self.changelog else None,
            "correct": self.correct,
            "state": [st.to_dict() for st in self.state] if self.state else None,
            "results": [result.to_dict() for result in self.results],
            "correlations": self.correlations.to_dict() if self.correlations else None,
            "measurands": self.measurands,
            "source": self.source.to_dict(),
        }

    def to_json(self):
        """Converts the Measurement instance to a JSON string."""
        return json.dumps(self.to_dict(), indent=4)

    def save_to_file(self, filepath: str):
        """Exports the Measurement instance to a JSON file."""
        with open(filepath, "w") as json_file:
            json_file.write(self.to_json())

    @classmethod
    def from_dict(cls, data: dict):
        """Creates a Measurement instance from a dictionary."""
        from .source import Source
        return cls(
            id=data.get("id"),
            description=data.get("description"),
            changelog=[ChangelogEntry.from_dict(entry) for entry in data.get("changelog", [])],
            correct=data.get("correct"),
            state=[State.from_dict(st) for st in data.get("state", [])],
            results=[QuantityValues.from_dict(result) for result in data["results"]],
            correlations=Correlations.from_dict(data["correlations"]) if data.get("correlations") else None,
            measurands=data.get("measurands"),
            source=Source.from_dict(data["source"])
        )

    @classmethod
    def from_json(cls, json_str: str):
        """Creates a Measurement instance from a JSON string."""
        data = json.loads(json_str)
        return cls.from_dict(data)

    @classmethod
    def load_from_file(cls, filepath: str):
        """Loads a Measurement instance from a JSON file."""
        with open(filepath, "r") as json_file:
            data = json.load(json_file)
        return cls.from_dict(data)
    
    def plot_measurement(
        self,
        show_uncertainty=True,
        show_grid=False,
        label_style="symbol",
        **kwargs
    ):
        """
        Automatically plots each result in the measurement based on measurands.

        Logic:
        - y-values are the measurand quantities
        - x-values are the only remaining quantity (if there is exactly one)
        - if more than 1 remaining quantity, skip plotting
        """

        import matplotlib.pyplot as plt

        figs = []

        if not self.measurands:
            raise ValueError("No measurands defined for this measurement.")

        for result in self.results:

            title = result.name

            # Determine which quantities are measurands (y-values)
            y_indices = [i for i, q in enumerate(result.quantities) if q in self.measurands]

            if not y_indices:
                continue  # no measurand in this result, skip

            for y_idx in y_indices:
                y_quantity = result.quantities[y_idx]

                # Remaining quantities
                remaining = [q for i, q in enumerate(result.quantities) if i != y_idx]

                if len(remaining) == 0:
                    # No x-values, use indices
                    x_values = list(range(len(result.values[y_idx])))
                    x_label = "Index"
                elif len(remaining) == 1:
                    # Use the remaining quantity as x
                    x_quantity = remaining[0]
                    x_values = result.values[result.quantities.index(x_quantity)]
                    x_label = (
                        f"{result.symbols[result.quantities.index(x_quantity)]} / "
                        f"{result.units[result.quantities.index(x_quantity)]}"
                        if label_style == "symbol" else
                        f"{x_quantity} / {result.units[result.quantities.index(x_quantity)]}"
                    )
                else:
                    # More than one remaining quantity → skip plotting
                    print(f"Skipping result '{result.name}': more than 1 remaining quantity.")
                    continue

                # y-values
                y_values = result.values[y_idx]
                y_label = (
                    f"{result.symbols[y_idx]} / {result.units[y_idx]}"
                    if label_style == "symbol" else
                    f"{y_quantity} / {result.units[y_idx]}"
                )

                # Uncertainty if available
                yerr = None
                if show_uncertainty and result.standard_uncertainties and len(result.standard_uncertainties) > y_idx:
                    yerr = result.standard_uncertainties[y_idx]

                # Plot
                fig, ax = plt.subplots()
                if yerr is not None:
                    ax.errorbar(x_values, y_values, yerr=yerr, fmt='o-', capsize=4, **kwargs)
                else:
                    ax.plot(x_values, y_values, 'o-', **kwargs)

                ax.set_xlabel(x_label)
                ax.set_ylabel(y_label)
                ax.set_title(f"{title}")
                ax.grid(show_grid)
                fig.tight_layout()

                figs.append(fig)

        return figs
    

    def to_dataframe(self):
        """
        Returns a pandas DataFrame with all QuantityValues and states of this measurement.
        Uses quantity names as column labels instead of symbols.
        """
        import pandas as pd  # import inside the method

        data = []

        # Extract state info
        state_info = {}
        for state in self.state or []:
            if state.quantity_value:
                column_name = state.quantity_value.name or state.name
                try:
                    value = state.quantity_value.values[0][0] if state.quantity_value.values else None
                except:
                    value = None
            else:
                column_name = state.name
                value = state.description if state.description else "Unknown"

            state_info[column_name] = value

        # Loop over results
        for result in self.results or []:
            # Determine y-values = measurands
            y_indices = [i for i, q in enumerate(result.quantities) if q in (self.measurands or [])]
            if not y_indices:
                continue

            for y_idx in y_indices:
                y_quantity = result.quantities[y_idx]
                remaining = [q for i, q in enumerate(result.quantities) if i != y_idx]

                if len(remaining) == 0:
                    # Use index as x
                    x_values = list(range(len(result.values[y_idx])))
                    x_label = "Index"
                elif len(remaining) == 1:
                    x_quantity = remaining[0]
                    x_values = result.values[result.quantities.index(x_quantity)]
                    x_label = x_quantity
                else:
                    continue  # skip if more than 1 remaining quantity

                # y-values
                y_values = result.values[y_idx]
                y_label = y_quantity

                # uncertainties
                yerr = None
                if result.standard_uncertainties and len(result.standard_uncertainties) > y_idx:
                    yerr = result.standard_uncertainties[y_idx]

                # Add rows
                for xi, yi, ui in zip(x_values, y_values, yerr if yerr else [None]*len(y_values)):
                    row = {**state_info, x_label: xi, y_label: yi, "standard uncertainty": ui}
                    data.append(row)

        df = pd.DataFrame(data)
        return df


    def to_csv(self, filepath):
        """
        Generates a CSV from the measurement and returns the DataFrame.
        """
        df = self.to_dataframe()
        df.to_csv(filepath, index=False)
        return df
