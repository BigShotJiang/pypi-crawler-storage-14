#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.systemcoupling.core.adaptor.impl.types import *


class _clear_state(Command):
    """
    For internal use only.
    """

    syc_name = "ClearState"
