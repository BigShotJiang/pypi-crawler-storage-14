"""
CSGHub SDK setup configuration
"""
from setuptools import setup

# This file is now mainly used for backward compatibility
# The main configuration has been moved to pyproject.toml

if __name__ == "__main__":
    setup()
