"""
Generic view classes for FastAPI CBV

These classes combine the base APIView with mixins to provide commonly used functionality.
Similar to Django REST Framework's generic views.
"""

from .base import GenericAPIView
from .mixins import (
    CreateModelMixin,
    ListModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin,
)


class CreateAPIView(CreateModelMixin, GenericAPIView):
    """
    Concrete view for creating a model instance.
    
    Provides:
    - POST: Create a new instance
    """
    pass


class ListAPIView(ListModelMixin, GenericAPIView):
    """
    Concrete view for listing a queryset.
    
    Provides:
    - GET: List all instances (with optional filtering/pagination)
    """
    pass


class RetrieveAPIView(RetrieveModelMixin, GenericAPIView):
    """
    Concrete view for retrieving a model instance.
    
    Provides:
    - GET: Retrieve a single instance
    """
    pass


class UpdateAPIView(UpdateModelMixin, GenericAPIView):
    """
    Concrete view for updating a model instance.
    
    Provides:
    - PUT: Full update of an instance
    - PATCH: Partial update of an instance
    """
    pass


class DestroyAPIView(DestroyModelMixin, GenericAPIView):
    """
    Concrete view for deleting a model instance.
    
    Provides:
    - DELETE: Delete an instance
    """
    pass


class ListCreateAPIView(ListModelMixin, CreateModelMixin, GenericAPIView):
    """
    Concrete view for listing a queryset or creating a model instance.
    
    Provides:
    - GET: List all instances (with optional filtering/pagination)
    - POST: Create a new instance
    """
    pass


class RetrieveUpdateAPIView(RetrieveModelMixin, UpdateModelMixin, GenericAPIView):
    """
    Concrete view for retrieving, updating a model instance.
    
    Provides:
    - GET: Retrieve a single instance
    - PUT: Full update of an instance
    - PATCH: Partial update of an instance
    """
    pass


class RetrieveDestroyAPIView(RetrieveModelMixin, DestroyModelMixin, GenericAPIView):
    """
    Concrete view for retrieving or deleting a model instance.
    
    Provides:
    - GET: Retrieve a single instance
    - DELETE: Delete an instance
    """
    pass


class RetrieveUpdateDestroyAPIView(
    RetrieveModelMixin, 
    UpdateModelMixin, 
    DestroyModelMixin, 
    GenericAPIView
):
    """
    Concrete view for retrieving, updating or deleting a model instance.
    
    Provides:
    - GET: Retrieve a single instance
    - PUT: Full update of an instance
    - PATCH: Partial update of an instance
    - DELETE: Delete an instance
    """
    pass