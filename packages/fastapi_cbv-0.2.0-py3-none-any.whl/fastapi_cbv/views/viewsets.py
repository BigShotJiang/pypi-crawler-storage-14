"""
ViewSet classes for FastAPI CBV

ViewSets are a type of class-based View that do not provide any method handlers 
(like .get() or .post()), but instead provide actions (like .list() or .create()).
"""

from typing import Dict, List, Set, Optional, Any
from .base import GenericAPIView
from .mixins import (
    CreateModelMixin,
    ListModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin,
)


class ViewSetMixin:
    """
    This is the magic that makes ViewSets work.
    
    Overrides `.as_view()` so that it takes an `actions` argument that 
    performs the binding of HTTP methods to actions on the ViewSet.
    """
    
    @classmethod
    def as_view(cls, actions: Optional[Dict[str, str]] = None, **initkwargs):
        """
        Because of the way class-based views create a closure around the
        instantiated view, we need to totally reimplement `.as_view`,
        and slightly modify the view function that is created and returned.
        """
        # The suffix initkwarg is reserved for identifying the viewset type
        # during schema introspection.
        if 'suffix' in initkwargs:
            initkwargs.pop('suffix')
        
        # actions must not be empty
        if not actions:
            raise TypeError(
                f"The `actions` argument must be provided when "
                f"calling `.as_view()` on a ViewSet. For example "
                f"`.as_view({{'get': 'list'}})`"
            )
        
        # sanitize keyword arguments
        for key in initkwargs:
            if key in actions:
                raise TypeError(
                    f"The method name {key} is not accepted as a keyword argument "
                    f"to {cls.__name__}()."
                )
            if not hasattr(cls, key):
                raise TypeError(
                    f"{cls.__name__}() received an invalid keyword {key}. "
                    f"as_view only accepts arguments that are already "
                    f"attributes of the class."
                )
        
        # name and suffix args are mutually exclusive
        if 'name' in initkwargs and 'suffix' in initkwargs:
            raise TypeError(
                f"{cls.__name__}() received both 'name' and 'suffix', which are "
                f"mutually exclusive arguments."
            )
        
        from fastapi import Request
        
        async def view(request: Request):
            self = cls(request=request, **initkwargs)
            
            # We also store the mapping of actions on the view instance
            # so that we can later set the action attribute.
            # This is done in the `initialize_request` method
            self.action_map = actions
            
            # Extract path parameters from request and store in self.kwargs
            if hasattr(request, 'path_params'):
                self.kwargs.update(dict(request.path_params))
            
            # For backwards compatibility, also pass as kwargs to handler
            kwargs = dict(self.kwargs)
            
            # Get the HTTP method and find the corresponding action
            method = request.method.lower()
            
            # If the method isn't in our action mapping, that's a 405
            if method not in actions:
                from fastapi import HTTPException, status
                allowed_methods = [method.upper() for method in actions.keys()]
                raise HTTPException(
                    status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
                    detail=f"Method '{method.upper()}' not allowed. Allowed methods: {allowed_methods}"
                )
            
            # Get the action name and set it on the view
            action = actions[method]
            self.action = action
            
            # Get the handler method
            handler = getattr(self, action)
            
            # Perform authentication and permission checks
            await self.initial(request)
            
            # Call the handler
            import inspect
            if inspect.iscoroutinefunction(handler):
                response = await handler(**kwargs)
            else:
                response = handler(**kwargs)
            
            # Handle the response
            return await self.finalize_response(response)
        
        view.cls = cls
        view.actions = actions
        view.initkwargs = initkwargs
        
        # Copy some attributes for introspection
        view.__name__ = cls.__name__
        view.__qualname__ = cls.__qualname__
        view.__module__ = cls.__module__
        view.__doc__ = cls.__doc__
        
        return view
    
    def initialize_request(self, request, *args, **kwargs):
        """
        Set the `.action` attribute on the view,
        depending on the request method.
        """
        self.action = self.action_map.get(request.method.lower())
        return super().initialize_request(request, *args, **kwargs)


class GenericViewSet(ViewSetMixin, GenericAPIView):
    """
    The GenericViewSet class does not provide any actions by default,
    but does include the base set of generic view behavior, such as
    the `get_object` and `get_queryset` methods.
    """
    pass


class ReadOnlyModelViewSet(
    ListModelMixin, 
    RetrieveModelMixin, 
    GenericViewSet
):
    """
    A viewset that provides default `list()` and `retrieve()` actions.
    
    To use it, override the class and set the `.queryset` and
    `.serializer_class` attributes.
    
    Example:
        class UserViewSet(ReadOnlyModelViewSet):
            queryset = User.objects.all()
            serializer_class = UserSerializer
    """
    pass


class ModelViewSet(
    CreateModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin,
    ListModelMixin,
    GenericViewSet
):
    """
    A viewset that provides default `create()`, `retrieve()`, `update()`,
    `partial_update()`, `destroy()` and `list()` actions.
    
    To use it, override the class and set the `.queryset` and
    `.serializer_class` attributes.
    
    Example:
        class UserViewSet(ModelViewSet):
            queryset = User.objects.all()
            serializer_class = UserSerializer
    """
    pass