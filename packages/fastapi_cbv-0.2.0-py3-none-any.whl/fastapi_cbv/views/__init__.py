"""
Views package initialization

This module exports all view-related classes for easy importing.
"""

from .base import APIView, GenericAPIView
from .mixins import (
    CreateModelMixin,
    ListModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin,
)
from .generics import (
    CreateAPIView,
    ListAPIView,
    RetrieveAPIView,
    UpdateAPIView,
    DestroyAPIView,
    ListCreateAPIView,
    RetrieveUpdateAPIView,
    RetrieveDestroyAPIView,
    RetrieveUpdateDestroyAPIView,
)
from .viewsets import (
    ViewSetMixin,
    GenericViewSet,
    ModelViewSet,
    ReadOnlyModelViewSet,
)

__all__ = [
    # Base classes
    "APIView",
    "GenericAPIView",
    # Mixins
    "CreateModelMixin",
    "ListModelMixin",
    "RetrieveModelMixin",
    "UpdateModelMixin",
    "DestroyModelMixin",
    # Generic views
    "CreateAPIView",
    "ListAPIView",
    "RetrieveAPIView",
    "UpdateAPIView",
    "DestroyAPIView",
    "ListCreateAPIView",
    "RetrieveUpdateAPIView",
    "RetrieveDestroyAPIView",
    "RetrieveUpdateDestroyAPIView",
    # ViewSets
    "ViewSetMixin",
    "GenericViewSet",
    "ModelViewSet",
    "ReadOnlyModelViewSet",
]