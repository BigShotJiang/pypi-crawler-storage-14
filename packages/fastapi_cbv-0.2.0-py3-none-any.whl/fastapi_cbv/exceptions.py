"""
Exception handling for FastAPI CBV

This module provides Django REST Framework style exception handling,
including custom exception classes and exception handlers.
"""

from typing import Any, Dict, List, Optional, Union
from fastapi import Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from pydantic import ValidationError


class APIException(Exception):
    """
    Base class for all API exceptions.
    
    Subclasses should provide `.status_code` and `.default_detail` properties.
    Similar to Django REST Framework's APIException.
    """
    
    status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR
    default_detail: str = "A server error occurred."
    default_code: str = "error"
    
    def __init__(
        self,
        detail: Optional[Union[str, List, Dict]] = None,
        code: Optional[str] = None,
        status_code: Optional[int] = None
    ):
        if detail is None:
            detail = self.default_detail
        if code is None:
            code = self.default_code
        if status_code is not None:
            self.status_code = status_code
        
        self.detail = detail
        self.code = code
    
    def __str__(self) -> str:
        return str(self.detail)
    
    def get_full_details(self) -> Dict[str, Any]:
        """
        Return the full details of this exception.
        """
        return {
            "detail": self.detail,
            "code": self.code
        }


# ============================================================
# 4xx Client Error Exceptions
# ============================================================

class ValidationError(APIException):
    """
    Exception raised when validation fails.
    """
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "Invalid input."
    default_code = "invalid"


class ParseError(APIException):
    """
    Exception raised when parsing fails (e.g., invalid JSON).
    """
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "Malformed request."
    default_code = "parse_error"


class AuthenticationFailed(APIException):
    """
    Exception raised when authentication fails.
    """
    status_code = status.HTTP_401_UNAUTHORIZED
    default_detail = "Incorrect authentication credentials."
    default_code = "authentication_failed"


class NotAuthenticated(APIException):
    """
    Exception raised when the request is not authenticated.
    """
    status_code = status.HTTP_401_UNAUTHORIZED
    default_detail = "Authentication credentials were not provided."
    default_code = "not_authenticated"


class PermissionDenied(APIException):
    """
    Exception raised when permission is denied.
    """
    status_code = status.HTTP_403_FORBIDDEN
    default_detail = "You do not have permission to perform this action."
    default_code = "permission_denied"


class NotFound(APIException):
    """
    Exception raised when a resource is not found.
    """
    status_code = status.HTTP_404_NOT_FOUND
    default_detail = "Not found."
    default_code = "not_found"


class MethodNotAllowed(APIException):
    """
    Exception raised when a method is not allowed.
    """
    status_code = status.HTTP_405_METHOD_NOT_ALLOWED
    default_detail = "Method not allowed."
    default_code = "method_not_allowed"
    
    def __init__(self, method: str, detail: Optional[str] = None, **kwargs):
        if detail is None:
            detail = f"Method '{method}' not allowed."
        super().__init__(detail=detail, **kwargs)


class NotAcceptable(APIException):
    """
    Exception raised when the requested content type is not acceptable.
    """
    status_code = status.HTTP_406_NOT_ACCEPTABLE
    default_detail = "Could not satisfy the request Accept header."
    default_code = "not_acceptable"


class Conflict(APIException):
    """
    Exception raised when there's a conflict (e.g., duplicate resource).
    """
    status_code = status.HTTP_409_CONFLICT
    default_detail = "Conflict with current state of the resource."
    default_code = "conflict"


class UnsupportedMediaType(APIException):
    """
    Exception raised when the media type is unsupported.
    """
    status_code = status.HTTP_415_UNSUPPORTED_MEDIA_TYPE
    default_detail = "Unsupported media type in request."
    default_code = "unsupported_media_type"


class Throttled(APIException):
    """
    Exception raised when the request is throttled.
    """
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    default_detail = "Request was throttled."
    default_code = "throttled"
    
    def __init__(self, wait: Optional[int] = None, detail: Optional[str] = None, **kwargs):
        if detail is None:
            if wait is not None:
                detail = f"Request was throttled. Expected available in {wait} seconds."
            else:
                detail = self.default_detail
        
        self.wait = wait
        super().__init__(detail=detail, **kwargs)


# ============================================================
# 5xx Server Error Exceptions
# ============================================================

class ServerError(APIException):
    """
    Exception raised for internal server errors.
    """
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = "A server error occurred."
    default_code = "server_error"


class ServiceUnavailable(APIException):
    """
    Exception raised when the service is unavailable.
    """
    status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    default_detail = "Service temporarily unavailable, try again later."
    default_code = "service_unavailable"


# ============================================================
# Exception Handler Functions
# ============================================================

def format_validation_errors(errors: List[Dict]) -> List[Dict[str, Any]]:
    """
    Format Pydantic validation errors into a consistent structure.
    
    Args:
        errors: List of Pydantic validation error dicts
    
    Returns:
        Formatted list of error dicts with field, message, and type
    """
    formatted = []
    for error in errors:
        formatted.append({
            "field": ".".join(str(loc) for loc in error.get("loc", [])),
            "message": error.get("msg", "Validation error"),
            "type": error.get("type", "value_error")
        })
    return formatted


async def api_exception_handler(request: Request, exc: APIException) -> JSONResponse:
    """
    Handle APIException and return a JSON response.
    
    Args:
        request: The incoming request
        exc: The APIException that was raised
    
    Returns:
        JSONResponse with error details
    """
    headers = {}
    
    # Add WWW-Authenticate header for 401 responses
    if exc.status_code == status.HTTP_401_UNAUTHORIZED:
        headers["WWW-Authenticate"] = "Bearer"
    
    # Add Retry-After header for throttled responses
    if isinstance(exc, Throttled) and exc.wait:
        headers["Retry-After"] = str(exc.wait)
    
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "code": exc.code},
        headers=headers or None
    )


async def http_exception_handler(
    request: Request, exc: StarletteHTTPException
) -> JSONResponse:
    """
    Handle Starlette/FastAPI HTTPException and return a JSON response.
    
    Args:
        request: The incoming request
        exc: The HTTPException that was raised
    
    Returns:
        JSONResponse with error details
    """
    headers = getattr(exc, "headers", None)
    
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "code": "http_error"},
        headers=headers
    )


async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """
    Handle FastAPI RequestValidationError and return a JSON response.
    
    Args:
        request: The incoming request
        exc: The RequestValidationError that was raised
    
    Returns:
        JSONResponse with formatted validation errors
    """
    errors = format_validation_errors(exc.errors())
    
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "detail": "Validation error",
            "code": "validation_error",
            "errors": errors
        }
    )


async def pydantic_validation_exception_handler(
    request: Request, exc: ValidationError
) -> JSONResponse:
    """
    Handle Pydantic ValidationError and return a JSON response.
    
    Args:
        request: The incoming request
        exc: The Pydantic ValidationError that was raised
    
    Returns:
        JSONResponse with formatted validation errors
    """
    errors = format_validation_errors(exc.errors())
    
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "detail": "Validation error",
            "code": "validation_error",
            "errors": errors
        }
    )


async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """
    Handle any unhandled exception and return a JSON response.
    
    In production, this should not expose internal error details.
    
    Args:
        request: The incoming request
        exc: The exception that was raised
    
    Returns:
        JSONResponse with generic error message
    """
    # In debug mode, you might want to include the actual error
    # For production, always return a generic message
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "detail": "Internal server error",
            "code": "server_error"
        }
    )


def setup_exception_handlers(app, include_generic: bool = True):
    """
    Set up all exception handlers for a FastAPI application.
    
    This is a convenience function that registers all the exception handlers
    defined in this module.
    
    Args:
        app: The FastAPI application instance
        include_generic: Whether to include the generic exception handler
                        (catches all unhandled exceptions)
    
    Usage:
        from fastapi import FastAPI
        from fastapi_cbv.exceptions import setup_exception_handlers
        
        app = FastAPI()
        setup_exception_handlers(app)
    """
    # Handle our custom API exceptions
    app.add_exception_handler(APIException, api_exception_handler)
    
    # Handle Starlette/FastAPI HTTP exceptions
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    
    # Handle FastAPI validation errors
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    
    # Handle generic exceptions (optional, for production)
    if include_generic:
        app.add_exception_handler(Exception, generic_exception_handler)


# ============================================================
# Exception Handler Middleware
# ============================================================

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request as StarletteRequest
from starlette.responses import Response
import traceback
import logging

logger = logging.getLogger("fastapi_cbv.exceptions")


class ExceptionHandlerMiddleware(BaseHTTPMiddleware):
    """
    Middleware that catches all exceptions and converts them to JSON responses.
    
    This middleware provides:
    - Consistent JSON error responses for all exceptions
    - Logging of exceptions
    - Optional debug mode with stack traces
    
    Usage:
        from fastapi import FastAPI
        from fastapi_cbv.exceptions import ExceptionHandlerMiddleware
        
        app = FastAPI()
        app.add_middleware(ExceptionHandlerMiddleware, debug=False)
    """
    
    def __init__(self, app, debug: bool = False):
        super().__init__(app)
        self.debug = debug
    
    async def dispatch(
        self, request: StarletteRequest, call_next
    ) -> Response:
        try:
            response = await call_next(request)
            return response
        
        except APIException as exc:
            # Our custom API exceptions
            logger.warning(
                f"API Exception: {exc.code} - {exc.detail}",
                extra={"request_path": request.url.path}
            )
            return await api_exception_handler(request, exc)
        
        except StarletteHTTPException as exc:
            # Starlette/FastAPI HTTP exceptions
            logger.warning(
                f"HTTP Exception: {exc.status_code} - {exc.detail}",
                extra={"request_path": request.url.path}
            )
            return await http_exception_handler(request, exc)
        
        except RequestValidationError as exc:
            # Validation errors
            logger.warning(
                f"Validation Error: {exc.errors()}",
                extra={"request_path": request.url.path}
            )
            return await validation_exception_handler(request, exc)
        
        except Exception as exc:
            # Unexpected exceptions
            logger.exception(
                f"Unhandled Exception: {type(exc).__name__} - {str(exc)}",
                extra={"request_path": request.url.path}
            )
            
            if self.debug:
                # In debug mode, include stack trace
                return JSONResponse(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    content={
                        "detail": str(exc),
                        "code": "server_error",
                        "type": type(exc).__name__,
                        "traceback": traceback.format_exc()
                    }
                )
            else:
                # In production, return generic error
                return JSONResponse(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    content={
                        "detail": "Internal server error",
                        "code": "server_error"
                    }
                )
