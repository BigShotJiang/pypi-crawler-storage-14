"""
Tortoise ORM integration utilities

This module provides utilities and enhancements for working with Tortoise ORM
in FastAPI CBV, including serializers, pagination, and query utilities.
"""

from typing import Any, Dict, List, Optional, Type, Union, get_type_hints
import inspect
from datetime import datetime, date
from decimal import Decimal

from pydantic import BaseModel, create_model
from tortoise.models import Model
from tortoise.queryset import QuerySet
from tortoise.fields import Field
from tortoise import fields


class TortoiseORMSerializer(BaseModel):
    """
    Base serializer for Tortoise ORM models.
    
    Automatically creates Pydantic models from Tortoise ORM models.
    """
    
    model_config = {
        "from_attributes": True,
        "validate_assignment": True,
        "use_enum_values": True,
    }
    
    @classmethod
    def from_tortoise_orm(cls, tortoise_model: Type[Model]) -> Type[BaseModel]:
        """
        Create a Pydantic model from a Tortoise ORM model.
        """
        field_definitions = {}
        
        # Process model fields
        for field_name, field_obj in tortoise_model._meta.fields_map.items():
            python_type, pydantic_field = cls._get_field_info(field_obj)
            field_definitions[field_name] = (python_type, pydantic_field)
        
        # Create the Pydantic model
        pydantic_model = create_model(
            f"{tortoise_model.__name__}Serializer",
            **field_definitions,
            __config__=cls.model_config
        )
        
        return pydantic_model
    
    @classmethod
    def _get_field_info(cls, field_obj: Field):
        """
        Convert a Tortoise field to Pydantic field info.
        """
        from pydantic import Field as PydanticField
        
        # Handle ForeignKey fields specially
        if isinstance(field_obj, fields.relational.ForeignKeyFieldInstance):
            # For foreign keys, use int type (the ID)
            python_type = int
            pydantic_kwargs = {}
            if field_obj.null:
                python_type = Optional[int]
                pydantic_kwargs['default'] = None
            pydantic_field = PydanticField(**pydantic_kwargs) if pydantic_kwargs else ...
            return python_type, pydantic_field
        
        # Get the base Python type
        python_type = field_obj.field_type
        pydantic_kwargs = {}
        
        # Handle nullable fields
        if field_obj.null:
            python_type = Optional[python_type]
            pydantic_kwargs['default'] = None
        elif field_obj.default is not None:
            pydantic_kwargs['default'] = field_obj.default
        elif isinstance(field_obj, fields.IntField) and getattr(field_obj, 'pk', False):
            # Primary key fields are optional for creation
            python_type = Optional[python_type]
            pydantic_kwargs['default'] = None
        
        # Add validation constraints
        if hasattr(field_obj, 'max_length') and field_obj.max_length:
            pydantic_kwargs['max_length'] = field_obj.max_length
        
        if hasattr(field_obj, 'description') and field_obj.description:
            pydantic_kwargs['description'] = field_obj.description
        
        # Create Pydantic field
        pydantic_field = PydanticField(**pydantic_kwargs) if pydantic_kwargs else ...
        
        return python_type, pydantic_field


def create_tortoise_serializer(
    model: Type[Model], 
    name: Optional[str] = None,
    fields: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None
) -> Type[BaseModel]:
    """
    Create a Pydantic serializer for a Tortoise ORM model.
    
    Args:
        model: The Tortoise ORM model class
        name: Custom name for the serializer (defaults to {ModelName}Serializer)
        fields: List of fields to include (if None, includes all)
        exclude: List of fields to exclude
    
    Returns:
        A Pydantic model class that can serialize/deserialize the Tortoise model
    """
    if name is None:
        name = f"{model.__name__}Serializer"
    
    field_definitions = {}
    
    # Get all model fields
    model_fields = model._meta.fields_map
    
    # Determine which fields to include
    if fields is not None:
        # Only include specified fields
        fields_to_process = {k: v for k, v in model_fields.items() if k in fields}
    else:
        # Include all fields except excluded ones
        exclude = exclude or []
        fields_to_process = {k: v for k, v in model_fields.items() if k not in exclude}
    
    # Process each field
    for field_name, field_obj in fields_to_process.items():
        python_type, pydantic_field = TortoiseORMSerializer._get_field_info(field_obj)
        field_definitions[field_name] = (python_type, pydantic_field)
    
    # Create the Pydantic model
    pydantic_model = create_model(
        name,
        **field_definitions,
        __config__=TortoiseORMSerializer.model_config
    )
    
    return pydantic_model


class TortoisePagination:
    """
    Pagination class for Tortoise ORM querysets.
    
    This paginator is designed to be reusable and thread-safe.
    Each paginate_queryset call stores pagination info that can be
    retrieved via get_paginated_response.
    """
    
    def __init__(self, page_size: int = 20, page_size_query_param: str = 'page_size', 
                 max_page_size: int = 100):
        self.default_page_size = page_size
        self.page_size_query_param = page_size_query_param
        self.max_page_size = max_page_size
        # Per-request state (set during paginate_queryset)
        self._page: int = 1
        self._page_size: int = page_size
        self._total: int = 0
        self._total_pages: int = 0
    
    async def paginate_queryset(self, queryset: QuerySet, request, view=None):
        """
        Paginate a queryset and return a page of results.
        
        Stores pagination metadata for use in get_paginated_response.
        """
        # Get page number and size from query parameters
        self._page = int(request.query_params.get('page', 1))
        self._page_size = int(request.query_params.get(
            self.page_size_query_param, self.default_page_size
        ))
        
        # Limit page size
        if self._page_size > self.max_page_size:
            self._page_size = self.max_page_size
        
        # Ensure valid page number
        if self._page < 1:
            self._page = 1
        
        # Calculate offset
        offset = (self._page - 1) * self._page_size
        
        # Get total count
        self._total = await queryset.count()
        
        # Calculate total pages
        self._total_pages = (self._total + self._page_size - 1) // self._page_size if self._page_size > 0 else 0
        
        # Get the page of results
        items = await queryset.offset(offset).limit(self._page_size)
        
        return items
    
    def get_paginated_response(self, data):
        """
        Return a paginated response with metadata.
        
        Returns a dict containing:
        - count: Total number of items
        - page: Current page number
        - page_size: Items per page
        - total_pages: Total number of pages
        - next: Whether there's a next page
        - previous: Whether there's a previous page
        - results: The actual data
        """
        return {
            'count': self._total,
            'page': self._page,
            'page_size': self._page_size,
            'total_pages': self._total_pages,
            'next': self._page < self._total_pages,
            'previous': self._page > 1,
            'results': data
        }
    
    @property
    def page(self):
        """Current page number."""
        return self._page
    
    @property
    def page_size(self):
        """Current page size."""
        return self._page_size
    
    @property
    def total(self):
        """Total number of items."""
        return self._total
    
    @property
    def total_pages(self):
        """Total number of pages."""
        return self._total_pages


class TortoiseFilterBackend:
    """
    Filter backend for Tortoise ORM querysets.
    """
    
    def filter_queryset(self, request, queryset: QuerySet, view):
        """
        Apply filtering to the queryset based on query parameters.
        """
        # Get filter parameters from the request
        filter_params = {}
        
        # Get the model class
        model_class = queryset.model
        model_fields = model_class._meta.fields_map
        
        # Process query parameters
        for param, value in request.query_params.items():
            if param in ['page', 'page_size']:
                continue
            
            # Handle field lookups (e.g., name__icontains, age__gte)
            if '__' in param:
                field_name, lookup = param.split('__', 1)
                if field_name in model_fields:
                    filter_params[param] = value
            elif param in model_fields:
                filter_params[param] = value
        
        # Apply filters
        if filter_params:
            queryset = queryset.filter(**filter_params)
        
        return queryset


class TortoiseSearchBackend:
    """
    Search backend for Tortoise ORM querysets.
    """
    
    def filter_queryset(self, request, queryset: QuerySet, view):
        """
        Apply search filtering to the queryset.
        """
        search_query = request.query_params.get('search')
        if not search_query:
            return queryset
        
        search_fields = getattr(view, 'search_fields', [])
        if not search_fields:
            return queryset
        
        # Build search filter
        from tortoise.expressions import Q
        
        search_filter = Q()
        for field in search_fields:
            search_filter |= Q(**{f"{field}__icontains": search_query})
        
        return queryset.filter(search_filter)


class TortoiseOrderingBackend:
    """
    Ordering backend for Tortoise ORM querysets.
    """
    
    def filter_queryset(self, request, queryset: QuerySet, view):
        """
        Apply ordering to the queryset.
        """
        ordering = request.query_params.get('ordering')
        if not ordering:
            # Use default ordering if specified
            ordering = getattr(view, 'ordering', None)
        
        if ordering:
            # Handle multiple ordering fields
            if isinstance(ordering, str):
                ordering_fields = [ordering]
            else:
                ordering_fields = ordering
            
            # Validate ordering fields
            valid_fields = getattr(view, 'ordering_fields', None)
            if valid_fields:
                validated_fields = []
                for field in ordering_fields:
                    # Remove '-' prefix for descending order
                    field_name = field.lstrip('-')
                    if field_name in valid_fields:
                        validated_fields.append(field)
                ordering_fields = validated_fields
            
            if ordering_fields:
                queryset = queryset.order_by(*ordering_fields)
        
        return queryset


# Convenience function to create a complete serializer setup
def setup_tortoise_serializers(model: Type[Model], **kwargs):
    """
    Create both create and read serializers for a Tortoise model.
    
    Returns:
        tuple: (CreateSerializer, ReadSerializer)
    """
    # Create serializer for reading (includes all fields including ID)
    read_serializer = create_tortoise_serializer(model, name=f"{model.__name__}Read", **kwargs)
    
    # Create serializer for creating (excludes auto-generated fields)
    exclude_fields = kwargs.get('exclude', [])
    create_exclude = exclude_fields + ['id']  # Usually exclude ID for creation
    
    create_kwargs = kwargs.copy()
    create_kwargs['exclude'] = create_exclude
    create_serializer = create_tortoise_serializer(model, name=f"{model.__name__}Create", **create_kwargs)
    
    return create_serializer, read_serializer