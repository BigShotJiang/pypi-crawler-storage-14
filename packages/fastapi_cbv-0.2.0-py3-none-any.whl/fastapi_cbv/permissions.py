"""
Permission classes for FastAPI CBV

This module provides Django REST Framework style permission classes
for controlling access to API endpoints.
"""

from typing import Any
from fastapi import Request


class BasePermission:
    """
    Base class from which all permission classes should inherit.
    
    Permission classes define access control rules for your API.
    They are checked in order, and if any permission check fails,
    access is denied with a 403 Forbidden response.
    
    To create a custom permission, subclass BasePermission and
    implement the has_permission and/or has_object_permission methods.
    """
    
    def has_permission(self, request: Request, view) -> bool:
        """
        Return True if permission is granted, False otherwise.
        
        This method is called for every request to the view.
        Override this method to implement your permission logic.
        
        Args:
            request: The incoming HTTP request
            view: The view instance handling the request
        
        Returns:
            bool: True if access is allowed, False otherwise
        """
        return True
    
    def has_object_permission(self, request: Request, view, obj: Any) -> bool:
        """
        Return True if permission is granted for a specific object.
        
        This method is called when accessing a specific object (e.g., GET /users/1/).
        Override this method to implement object-level permission logic.
        
        Note: This is only called after has_permission() returns True.
        
        Args:
            request: The incoming HTTP request
            view: The view instance handling the request
            obj: The object being accessed
        
        Returns:
            bool: True if access is allowed, False otherwise
        """
        return True


class AllowAny(BasePermission):
    """
    Allow any access.
    
    This permission class will permit unrestricted access,
    regardless of whether the request was authenticated or unauthenticated.
    """
    
    def has_permission(self, request: Request, view) -> bool:
        return True


class IsAuthenticated(BasePermission):
    """
    Allows access only to authenticated users.
    
    This permission class requires that the request has a valid
    authentication token/session.
    
    Requires that request.state.user is set by an authentication class.
    """
    
    def has_permission(self, request: Request, view) -> bool:
        user = getattr(request.state, 'user', None)
        return user is not None


class IsAuthenticatedOrReadOnly(BasePermission):
    """
    Allows access to authenticated users, or read-only access to anyone.
    
    Safe methods (GET, HEAD, OPTIONS) are allowed for unauthenticated users.
    Other methods require authentication.
    """
    
    SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS')
    
    def has_permission(self, request: Request, view) -> bool:
        if request.method in self.SAFE_METHODS:
            return True
        user = getattr(request.state, 'user', None)
        return user is not None


class IsAdminUser(BasePermission):
    """
    Allows access only to admin users.
    
    Requires that request.state.user exists and has an is_admin 
    or is_superuser attribute set to True.
    
    Supports both object-style users (with attributes) and dict-style users.
    """
    
    def has_permission(self, request: Request, view) -> bool:
        user = getattr(request.state, 'user', None)
        if user is None:
            return False
        
        # Support both dict and object style users
        if isinstance(user, dict):
            return user.get('is_admin', False) or user.get('is_superuser', False)
        
        return getattr(user, 'is_admin', False) or getattr(user, 'is_superuser', False)


class IsOwnerOrReadOnly(BasePermission):
    """
    Object-level permission to only allow owners of an object to edit it.
    
    Assumes the model instance has an `owner` or `user` attribute.
    Read operations are allowed for any authenticated user.
    """
    
    SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS')
    
    def has_object_permission(self, request: Request, view, obj: Any) -> bool:
        # Read permissions are allowed for any request
        if request.method in self.SAFE_METHODS:
            return True
        
        # Write permissions are only allowed to the owner of the object
        user = getattr(request.state, 'user', None)
        if user is None:
            return False
        
        # Check for various owner attribute names
        owner = getattr(obj, 'owner', None) or getattr(obj, 'user', None)
        if owner is None:
            return False
        
        # Compare user IDs
        user_id = getattr(user, 'id', None)
        owner_id = getattr(owner, 'id', owner)  # owner might be an ID or an object
        
        return user_id == owner_id


class DjangoModelPermissions(BasePermission):
    """
    Permission class that checks Django-style model permissions.
    
    This permission class ties into Django's standard `django.contrib.auth`
    model permissions. It requires that the user has the appropriate
    'add', 'change', 'delete', or 'view' permissions on the model.
    
    Note: This is primarily for projects that integrate with Django's
    permission system. For pure FastAPI projects, consider using
    custom permission classes.
    """
    
    # Map methods to required permission codenames
    perms_map = {
        'GET': ['%(app_label)s.view_%(model_name)s'],
        'OPTIONS': [],
        'HEAD': [],
        'POST': ['%(app_label)s.add_%(model_name)s'],
        'PUT': ['%(app_label)s.change_%(model_name)s'],
        'PATCH': ['%(app_label)s.change_%(model_name)s'],
        'DELETE': ['%(app_label)s.delete_%(model_name)s'],
    }
    
    def get_required_permissions(self, method: str, model_class) -> list:
        """
        Given a model class and an HTTP method, return the list of permission
        codes that the user is required to have.
        """
        kwargs = {
            'app_label': model_class._meta.app_label if hasattr(model_class, '_meta') else 'app',
            'model_name': model_class.__name__.lower(),
        }
        
        if method not in self.perms_map:
            return []
        
        return [perm % kwargs for perm in self.perms_map[method]]
    
    def has_permission(self, request: Request, view) -> bool:
        user = getattr(request.state, 'user', None)
        if user is None:
            return False
        
        # Get the model class from the view
        queryset = getattr(view, 'queryset', None)
        model_class = getattr(view, 'model', None)
        
        if queryset is not None:
            model_class = queryset.model
        
        if model_class is None:
            return True
        
        perms = self.get_required_permissions(request.method, model_class)
        
        # Check if user has all required permissions
        if hasattr(user, 'has_perms'):
            return user.has_perms(perms)
        
        return True
