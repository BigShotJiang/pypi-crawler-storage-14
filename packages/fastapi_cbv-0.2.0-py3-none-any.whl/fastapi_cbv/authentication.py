"""
Authentication classes for FastAPI CBV

This module provides Django REST Framework style authentication classes
for authenticating API requests.
"""

from typing import Any, Optional, Tuple
from fastapi import Request, HTTPException, status


class BaseAuthentication:
    """
    Base class from which all authentication classes should inherit.
    
    Authentication classes define how users are identified for each request.
    They are called in order, and the first one to successfully authenticate
    sets the user on the request.
    
    To create a custom authentication class, subclass BaseAuthentication and
    implement the authenticate method.
    """
    
    def authenticate(self, request: Request) -> Optional[Tuple[Any, Any]]:
        """
        Authenticate the request and return a tuple of (user, auth_info).
        
        Return None if authentication is not attempted.
        Raise HTTPException if authentication fails.
        
        Args:
            request: The incoming HTTP request
        
        Returns:
            Tuple of (user, auth_info) if authentication succeeds
            None if this authenticator does not apply to this request
        
        Raises:
            HTTPException: If authentication is attempted but fails
        """
        raise NotImplementedError(
            ".authenticate() must be overridden."
        )
    
    def authenticate_header(self, request: Request) -> Optional[str]:
        """
        Return a string to be used as the value of the `WWW-Authenticate`
        header in a 401 Unauthenticated response.
        
        If this method returns None, a 403 Permission Denied response will
        be used instead of 401 Unauthenticated.
        
        Args:
            request: The incoming HTTP request
        
        Returns:
            A string for the WWW-Authenticate header, or None
        """
        return None


class SessionAuthentication(BaseAuthentication):
    """
    Use FastAPI's session-based authentication.
    
    This authentication class uses the session middleware to identify users.
    Requires that session middleware is configured.
    """
    
    def authenticate(self, request: Request) -> Optional[Tuple[Any, Any]]:
        """
        Authenticate using session data.
        """
        # Check if session is available
        session = getattr(request, 'session', None)
        if session is None:
            return None
        
        # Get user from session
        user_id = session.get('user_id')
        if user_id is None:
            return None
        
        # You would typically load the user from database here
        # This is a placeholder that should be overridden
        user = {'id': user_id}
        
        return (user, None)


class TokenAuthentication(BaseAuthentication):
    """
    Simple token-based authentication.
    
    Clients should authenticate by passing the token key in the
    "Authorization" HTTP header, prefixed with "Token ".
    
    Example:
        Authorization: Token 9944b09199c62bcf9418ad846dd0e4bbdfc6ee4b
    """
    
    keyword = 'Token'
    
    def authenticate(self, request: Request) -> Optional[Tuple[Any, Any]]:
        """
        Authenticate using Authorization header with Token prefix.
        """
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return None
        
        parts = auth_header.split()
        
        if len(parts) == 0:
            return None
        
        if parts[0].lower() != self.keyword.lower():
            return None
        
        if len(parts) == 1:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token header. No credentials provided.",
                headers={"WWW-Authenticate": self.keyword}
            )
        
        if len(parts) > 2:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token header. Token string should not contain spaces.",
                headers={"WWW-Authenticate": self.keyword}
            )
        
        token = parts[1]
        return self.authenticate_credentials(token)
    
    def authenticate_credentials(self, token: str) -> Tuple[Any, Any]:
        """
        Validate the token and return (user, token) if valid.
        
        Override this method to implement your token validation logic.
        
        Args:
            token: The token string from the Authorization header
        
        Returns:
            Tuple of (user, token)
        
        Raises:
            HTTPException: If the token is invalid
        """
        # This should be overridden to validate the token and return user
        raise NotImplementedError(
            "TokenAuthentication.authenticate_credentials() must be overridden "
            "to validate tokens and return (user, token) tuple."
        )
    
    def authenticate_header(self, request: Request) -> str:
        return self.keyword


class BearerAuthentication(TokenAuthentication):
    """
    Bearer token authentication (commonly used with JWT).
    
    Clients should authenticate by passing the token in the
    "Authorization" HTTP header, prefixed with "Bearer ".
    
    Example:
        Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
    """
    
    keyword = 'Bearer'


class BasicAuthentication(BaseAuthentication):
    """
    HTTP Basic authentication.
    
    Clients should authenticate by passing the username and password
    as HTTP Basic authentication credentials.
    
    Warning: This authentication scheme sends credentials in clear text.
    Use only with HTTPS.
    """
    
    def authenticate(self, request: Request) -> Optional[Tuple[Any, Any]]:
        """
        Authenticate using HTTP Basic authentication.
        """
        import base64
        
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return None
        
        parts = auth_header.split()
        
        if len(parts) == 0 or parts[0].lower() != 'basic':
            return None
        
        if len(parts) == 1:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid basic header. No credentials provided.",
                headers={"WWW-Authenticate": "Basic"}
            )
        
        if len(parts) > 2:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid basic header. Credentials string should not contain spaces.",
                headers={"WWW-Authenticate": "Basic"}
            )
        
        try:
            auth_decoded = base64.b64decode(parts[1]).decode('utf-8')
            username, password = auth_decoded.split(':', 1)
        except (TypeError, ValueError, UnicodeDecodeError):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid basic header. Credentials not correctly base64 encoded.",
                headers={"WWW-Authenticate": "Basic"}
            )
        
        return self.authenticate_credentials(username, password, request)
    
    def authenticate_credentials(
        self, username: str, password: str, request: Request
    ) -> Tuple[Any, Any]:
        """
        Validate the username and password and return (user, None) if valid.
        
        Override this method to implement your authentication logic.
        
        Args:
            username: The username from Basic auth
            password: The password from Basic auth
            request: The incoming HTTP request
        
        Returns:
            Tuple of (user, None)
        
        Raises:
            HTTPException: If the credentials are invalid
        """
        raise NotImplementedError(
            "BasicAuthentication.authenticate_credentials() must be overridden "
            "to validate credentials and return (user, None) tuple."
        )
    
    def authenticate_header(self, request: Request) -> str:
        return 'Basic realm="api"'


class APIKeyAuthentication(BaseAuthentication):
    """
    API Key authentication using header or query parameter.
    
    Supports both:
    - Header: X-API-Key: your-api-key
    - Query parameter: ?api_key=your-api-key
    """
    
    api_key_header = 'X-API-Key'
    api_key_query_param = 'api_key'
    
    def authenticate(self, request: Request) -> Optional[Tuple[Any, Any]]:
        """
        Authenticate using API key from header or query parameter.
        """
        # Try header first
        api_key = request.headers.get(self.api_key_header)
        
        # Fall back to query parameter
        if not api_key:
            api_key = request.query_params.get(self.api_key_query_param)
        
        if not api_key:
            return None
        
        return self.authenticate_credentials(api_key)
    
    def authenticate_credentials(self, api_key: str) -> Tuple[Any, Any]:
        """
        Validate the API key and return (user, api_key) if valid.
        
        Override this method to implement your API key validation logic.
        
        Args:
            api_key: The API key from header or query parameter
        
        Returns:
            Tuple of (user, api_key)
        
        Raises:
            HTTPException: If the API key is invalid
        """
        raise NotImplementedError(
            "APIKeyAuthentication.authenticate_credentials() must be overridden "
            "to validate API keys and return (user, api_key) tuple."
        )
