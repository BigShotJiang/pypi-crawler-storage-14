"""
FastAPI CBV - Class-Based Views for FastAPI
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A FastAPI extension that provides Django REST Framework style class-based views
with full async support and Tortoise ORM integration.

:copyright: (c) 2024
:license: MIT
"""

__version__ = "0.2.0"
__author__ = "FastAPI CBV Team"

from .views.base import APIView, GenericAPIView
from .views.mixins import (
    CreateModelMixin,
    ListModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin,
)
from .views.generics import (
    CreateAPIView,
    ListAPIView,
    RetrieveAPIView,
    UpdateAPIView,
    DestroyAPIView,
    ListCreateAPIView,
    RetrieveUpdateAPIView,
    RetrieveDestroyAPIView,
    RetrieveUpdateDestroyAPIView,
)
from .views.viewsets import (
    ViewSetMixin,
    GenericViewSet,
    ModelViewSet,
    ReadOnlyModelViewSet,
)
from .decorators import (
    cbv,
    viewset_routes,
    api_route,
    action,
    get_extra_actions,
    register_viewset_actions,
    RouteRegistry,
)
from .routers import CBVRouter, create_router_for_model
from .tortoise_integration import (
    create_tortoise_serializer,
    TortoisePagination,
    TortoiseFilterBackend,
    TortoiseSearchBackend,
    TortoiseOrderingBackend,
    TortoiseORMSerializer,
    setup_tortoise_serializers,
)
from .permissions import (
    BasePermission,
    AllowAny,
    IsAuthenticated,
    IsAuthenticatedOrReadOnly,
    IsAdminUser,
    IsOwnerOrReadOnly,
    DjangoModelPermissions,
)
from .authentication import (
    BaseAuthentication,
    SessionAuthentication,
    TokenAuthentication,
    BearerAuthentication,
    BasicAuthentication,
    APIKeyAuthentication,
)
from .exceptions import (
    # Base exception
    APIException,
    # 4xx exceptions
    ValidationError,
    ParseError,
    AuthenticationFailed,
    NotAuthenticated,
    PermissionDenied,
    NotFound,
    MethodNotAllowed,
    NotAcceptable,
    Conflict,
    UnsupportedMediaType,
    Throttled,
    # 5xx exceptions
    ServerError,
    ServiceUnavailable,
    # Exception handlers
    api_exception_handler,
    http_exception_handler,
    validation_exception_handler,
    generic_exception_handler,
    setup_exception_handlers,
    # Middleware
    ExceptionHandlerMiddleware,
)

__all__ = [
    # Version info
    "__version__",
    "__author__",
    # Base classes
    "APIView",
    "GenericAPIView",
    # Mixins
    "CreateModelMixin",
    "ListModelMixin", 
    "RetrieveModelMixin",
    "UpdateModelMixin",
    "DestroyModelMixin",
    # Generic views
    "CreateAPIView",
    "ListAPIView",
    "RetrieveAPIView", 
    "UpdateAPIView",
    "DestroyAPIView",
    "ListCreateAPIView",
    "RetrieveUpdateAPIView",
    "RetrieveDestroyAPIView",
    "RetrieveUpdateDestroyAPIView",
    # ViewSets
    "ViewSetMixin",
    "GenericViewSet",
    "ModelViewSet",
    "ReadOnlyModelViewSet",
    # Decorators and utilities
    "cbv",
    "viewset_routes",
    "api_route",
    "action",
    "get_extra_actions",
    "register_viewset_actions",
    "RouteRegistry",
    "CBVRouter",
    "create_router_for_model",
    # Tortoise ORM integration
    "create_tortoise_serializer",
    "TortoisePagination",
    "TortoiseFilterBackend",
    "TortoiseSearchBackend",
    "TortoiseOrderingBackend",
    "TortoiseORMSerializer",
    "setup_tortoise_serializers",
    # Permissions
    "BasePermission",
    "AllowAny",
    "IsAuthenticated",
    "IsAuthenticatedOrReadOnly",
    "IsAdminUser",
    "IsOwnerOrReadOnly",
    "DjangoModelPermissions",
    # Authentication
    "BaseAuthentication",
    "SessionAuthentication",
    "TokenAuthentication",
    "BearerAuthentication",
    "BasicAuthentication",
    "APIKeyAuthentication",
    # Exceptions
    "APIException",
    "ValidationError",
    "ParseError",
    "AuthenticationFailed",
    "NotAuthenticated",
    "PermissionDenied",
    "NotFound",
    "MethodNotAllowed",
    "NotAcceptable",
    "Conflict",
    "UnsupportedMediaType",
    "Throttled",
    "ServerError",
    "ServiceUnavailable",
    # Exception handlers
    "api_exception_handler",
    "http_exception_handler",
    "validation_exception_handler",
    "generic_exception_handler",
    "setup_exception_handlers",
    "ExceptionHandlerMiddleware",
]