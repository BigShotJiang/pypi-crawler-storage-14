"""The official Python library for the OmniEdge API."""

__version__ = "0.1.0"


def main():
    """Main entry point for omniedge-python."""
    print("Hello from omniedge-python!")

