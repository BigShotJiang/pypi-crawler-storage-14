class NoResultsFound(Exception):
    """
    Raised when no results are found for a given query.
    """

    pass
