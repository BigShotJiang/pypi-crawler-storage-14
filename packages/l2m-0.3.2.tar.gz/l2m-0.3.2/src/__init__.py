__version__ = "0.3.2"

__all__ = [__version__]

# Note: We don't import submodules here to avoid circular imports.
# Import directly from submodules: from src.core import models, etc.
