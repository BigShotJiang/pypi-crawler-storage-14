# This file makes the 'resources' directory a Python package.
# It will contain icons, stylesheets, etc.
