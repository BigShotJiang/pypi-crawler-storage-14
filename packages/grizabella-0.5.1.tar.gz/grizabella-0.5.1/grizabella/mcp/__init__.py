"""Grizabella MCP Server Package."""
from .server import app

__all__ = ["app"]
