stable = True
version = "0.6.6.3"
