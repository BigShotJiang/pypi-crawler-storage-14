class DastState:
    CREATED = 0
    STARTING = 1
    STARTED = 2
    ANALYZING = 3
    SUCCESS = 4
    FAILED = 5
    STOPPING = 6
    RECALCULATING = 7
    INTERRUPTING = 8
    INITIALIZING = 9
    CANCELLED = 10
    CANCELLING = 11


DastStateDict = {
    0: "CREATED",
    1: "STARTING",
    2: "STARTED",
    3: "ANALYZING",
    4: "SUCCESS",
    5: "FAILED",
    6: "STOPPING",
    7: "RECALCULATING",
    8: "INTERRUPTING",
    9: "INITIALIZING",
    10: "CANCELLED",
    11: "CANCELLING"
}

ANDROID_EXTENSIONS = ['.apk', '.apks', '.zip', '.aab']

# Default architecture names for auto-selection
DEFAULT_ANDROID_ARCHITECTURE = 'Android 11'
DEFAULT_IOS_ARCHITECTURE = 'iOS 14'

# Timeout constants (in seconds)
TRY = 360
LONG_TRY = 20160
END_SCAN_TIMEOUT = 30
SLEEP_TIMEOUT = 10

# HTTP timeout constants
HTTP_REQUEST_TIMEOUT = 30
HTTP_DOWNLOAD_TIMEOUT = 300
