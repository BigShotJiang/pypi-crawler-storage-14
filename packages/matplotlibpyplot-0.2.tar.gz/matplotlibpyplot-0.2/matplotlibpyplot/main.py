def hello():
    print("Hello")