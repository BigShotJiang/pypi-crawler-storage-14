DEBUG = False

if DEBUG:
    url_address = "http://127.0.0.1:8000/"
    ws_address = "ws://127.0.0.1:8000/ws/"
    app_address = "http://localhost:3000/"
else:
    url_address = "https://backend.speedbuild.dev/"
    ws_address = "wss://backend.speedbuild.dev/ws/"
    app_address = "https://app.speedbuild.dev/"