import os

def getTemplateFileNames(path):
    file_paths = []
    for root, _, files in os.walk(path):
        if "node_modules" in root or  "migrations" in root or  "__pycache__" in root:
            continue
        for file in files:
            # Get the absolute path by joining root and file
            absolute_path = os.path.join(root, file)
            if not absolute_path.endswith(".yaml"): #TODO : remove this in the future
                file_paths.append(absolute_path)
    return file_paths