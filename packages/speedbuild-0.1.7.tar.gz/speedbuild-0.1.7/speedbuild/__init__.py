import os

# Base directory of the sb_cleaned package
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
