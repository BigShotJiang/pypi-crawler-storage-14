from datetime import date
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

def validate_imei_format(value):
  
  #  Validates if the provided string looks like a standard 15-digit IMEI number.
   
    if not isinstance(value, str) or not value.isdigit():
        raise ValidationError(
            _('IMEI must contain only numbers.'),
            code='imei_invalid_chars'
        )
        
    if len(value) != 15:
        raise ValidationError(
            _('IMEI must be exactly 15 digits long.'),
            code='imei_length_invalid'
        )

def validate_past_incident_date(value):

    if value > date.today():
        raise ValidationError(
            _('The incident date cannot be in the future.'),
            code='incident_date_future'
        )