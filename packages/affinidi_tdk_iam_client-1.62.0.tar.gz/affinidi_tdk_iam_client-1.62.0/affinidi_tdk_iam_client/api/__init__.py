# flake8: noqa

# import apis into api package
from affinidi_tdk_iam_client.api.authz_api import AuthzApi
from affinidi_tdk_iam_client.api.consumer_auth_api import ConsumerAuthApi
from affinidi_tdk_iam_client.api.default_api import DefaultApi
from affinidi_tdk_iam_client.api.policies_api import PoliciesApi
from affinidi_tdk_iam_client.api.projects_api import ProjectsApi
from affinidi_tdk_iam_client.api.sts_api import StsApi
from affinidi_tdk_iam_client.api.tokens_api import TokensApi
from affinidi_tdk_iam_client.api.well_known_api import WellKnownApi

