"""Command-line interface for binance-futures-availability."""

from binance_futures_availability.cli.main import main

__all__ = ["main"]
