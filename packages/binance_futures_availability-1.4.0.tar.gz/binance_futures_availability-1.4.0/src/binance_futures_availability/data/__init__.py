"""Data files for binance-futures-availability."""
