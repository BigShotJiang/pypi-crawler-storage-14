#!/usr/bin/env python3
"""
AWS CLI-based historical backfill (MUCH FASTER than HEAD requests).

Uses aws s3 ls to list all files per symbol in one call, extracting
availability from filenames. 3.5x faster than individual HEAD requests.

Performance:
  - 708 symbols × 4.5 sec = ~53 minutes (vs 3 hours with HEAD requests)
  - Single API call per symbol gets ALL dates at once

Usage:
    python scripts/run_backfill_aws.py
    python scripts/run_backfill_aws.py --start-date 2024-01-01
    python scripts/run_backfill_aws.py --symbols BTCUSDT ETHUSDT  # Test subset
"""

import argparse
import datetime
import logging
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from binance_futures_availability.database import AvailabilityDatabase
from binance_futures_availability.probing.aws_s3_lister import AWSS3Lister
from binance_futures_availability.probing.symbol_discovery import load_discovered_symbols


def backfill_symbol(
    symbol: str,
    start_date: datetime.date,
    end_date: datetime.date,
    db_path: Path | None,
    skip_materialized_refresh: bool = False,
    collect_volume: bool = True,
) -> dict:
    """
    Backfill all availability data for a single symbol using AWS CLI.

    Args:
        symbol: Trading pair symbol
        start_date: Start of date range
        end_date: End of date range (inclusive)
        db_path: Database path (each worker creates its own connection for thread-safety)
        skip_materialized_refresh: Skip auto-refresh of materialized views (for parallel operations)
        collect_volume: ADR-0007: Download 1d klines for volume metrics (default: True)

    Returns:
        Dict with symbol, dates_found, volume_count, error (if any)
    """
    lister = AWSS3Lister()

    # Create thread-local database connection for thread-safety
    db = AvailabilityDatabase(db_path=db_path, skip_materialized_refresh=skip_materialized_refresh)

    try:
        # Get all available dates for this symbol
        availability = lister.get_symbol_availability(
            symbol, start_date=start_date, end_date=end_date
        )

        # ADR-0007: Download 1d klines for volume metrics
        volume_data = {}
        if collect_volume and availability:
            for date in availability:
                try:
                    volume_metrics = lister.download_1d_kline(symbol, date)
                    if volume_metrics:
                        volume_data[date] = volume_metrics
                except Exception:
                    # Silently skip volume download failures (volume is optional)
                    # Main availability data still gets inserted
                    pass

        # Build records for ALL dates in range (available + unavailable)
        records = []
        probe_time = datetime.datetime.now(datetime.UTC)
        current_date = start_date

        while current_date <= end_date:
            if current_date in availability:
                # Available: file exists
                meta = availability[current_date]
                record = {
                    "date": current_date,
                    "symbol": symbol,
                    "available": True,
                    "file_size_bytes": meta["file_size_bytes"],
                    "last_modified": meta["last_modified"],
                    "url": meta["url"],
                    "status_code": 200,  # Inferred from file existence
                    "probe_timestamp": probe_time,
                }
                # ADR-0007: Merge volume metrics if downloaded
                if current_date in volume_data:
                    record.update(volume_data[current_date])
                records.append(record)
            else:
                # Unavailable: file does not exist
                records.append(
                    {
                        "date": current_date,
                        "symbol": symbol,
                        "available": False,
                        "file_size_bytes": None,
                        "last_modified": None,
                        "url": f"https://data.binance.vision/data/futures/um/daily/klines/{symbol}/1m/{symbol}-1m-{current_date}.zip",
                        "status_code": 404,  # Inferred from absence
                        "probe_timestamp": probe_time,
                    }
                )

            current_date += datetime.timedelta(days=1)

        # Bulk insert into database (uses INSERT OR REPLACE for UPSERT)
        db.insert_batch(records)

        result = {
            "symbol": symbol,
            "dates_found": len(availability),
            "volume_count": len(volume_data),
            "total_dates": len(records),
            "error": None,
        }

    except Exception as e:
        result = {"symbol": symbol, "dates_found": 0, "volume_count": 0, "total_dates": 0, "error": str(e)}

    finally:
        # Always close the thread-local connection
        db.close()

    return result


def main() -> int:
    """Run AWS CLI-based historical backfill."""

    parser = argparse.ArgumentParser(description="AWS CLI-based historical backfill (3.5x faster)")

    parser.add_argument(
        "--start-date",
        type=str,
        help="Backfill start date (YYYY-MM-DD, default: 2019-09-25)",
    )

    parser.add_argument(
        "--end-date",
        type=str,
        help="Backfill end date (YYYY-MM-DD, default: yesterday)",
    )

    parser.add_argument(
        "--symbols",
        type=str,
        help="Specific symbols to backfill - comma-separated (e.g., BTCUSDT,ETHUSDT) or space-separated (default: all perpetuals)",
    )

    parser.add_argument(
        "--workers",
        type=int,
        default=10,
        help="Number of parallel workers (default: 10)",
    )

    parser.add_argument(
        "--skip-materialized-refresh",
        action="store_true",
        help="Skip auto-refresh of materialized views after each batch (use for parallel operations to avoid conflicts)",
    )

    parser.add_argument(
        "--collect-volume",
        action="store_true",
        default=True,
        help="ADR-0007: Download 1d klines for volume metrics (default: True)",
    )

    parser.add_argument(
        "--no-collect-volume",
        dest="collect_volume",
        action="store_false",
        help="ADR-0007: Skip volume collection (only collect availability)",
    )

    args = parser.parse_args()

    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    logger = logging.getLogger(__name__)

    # Parse dates
    start_date = (
        datetime.date.fromisoformat(args.start_date)
        if args.start_date
        else datetime.date(2019, 9, 25)
    )

    end_date = (
        datetime.date.fromisoformat(args.end_date)
        if args.end_date
        else datetime.date.today() - datetime.timedelta(days=1)
    )

    # Load symbols (ADR-0012: Support comma-separated for workflow integration)
    if args.symbols:
        # Parse comma-separated symbols: "BTCUSDT,ETHUSDT" → ["BTCUSDT", "ETHUSDT"]
        # Also supports space for backward compatibility (though comma is preferred)
        symbols = [s.strip() for s in args.symbols.replace(",", " ").split() if s.strip()]
        logger.info(
            f"Using {len(symbols)} specified symbols: {', '.join(symbols[:5])}{' ...' if len(symbols) > 5 else ''}"
        )
    else:
        symbols = load_discovered_symbols()
        logger.info(f"Using all {len(symbols)} perpetual USDT futures")

    total_days = (end_date - start_date).days + 1

    logger.info("=" * 60)
    logger.info("AWS CLI-Based Historical Backfill (3.5x Faster)")
    logger.info("=" * 60)
    logger.info(f"Date range: {start_date} to {end_date} ({total_days} days)")
    logger.info(f"Symbols: {len(symbols)}")
    logger.info(f"Parallel workers: {args.workers}")
    logger.info(f"Volume collection (ADR-0007): {'ENABLED' if args.collect_volume else 'DISABLED'}")
    logger.info(f"Estimated time: ~{len(symbols) * 4.5 / 60:.0f} minutes")
    logger.info("=" * 60)

    # Determine database path (respect DB_PATH environment variable if set)
    db_path_str = os.environ.get("DB_PATH")
    if db_path_str:
        logger.info(f"Using database from DB_PATH: {db_path_str}")
        db_path = Path(db_path_str)
    else:
        logger.info("Using default database path: ~/.cache/binance-futures/availability.duckdb")
        db_path = None  # Use default path

    # Initialize database schema ONCE before starting workers
    # (avoids catalog write-write conflicts when 10 workers try to CREATE TABLE simultaneously)
    logger.info("Initializing database schema...")
    init_db = AvailabilityDatabase(db_path=db_path)
    init_db.close()
    logger.info("Schema initialized successfully")

    # Process symbols in parallel (each worker creates its own DB connection for thread-safety)
    results = []
    failed_symbols = []

    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        # Submit all symbol backfill tasks
        future_to_symbol = {
            executor.submit(
                backfill_symbol,
                symbol,
                start_date,
                end_date,
                db_path,
                args.skip_materialized_refresh,
                args.collect_volume,  # ADR-0007: Volume collection flag
            ): symbol
            for symbol in symbols
        }

        # Process results as they complete
        for i, future in enumerate(as_completed(future_to_symbol), 1):
            symbol = future_to_symbol[future]

            try:
                result = future.result()
                results.append(result)

                if result["error"]:
                    failed_symbols.append(symbol)
                    logger.error(f"[{i}/{len(symbols)}] ❌ {symbol}: {result['error']}")
                else:
                    # ADR-0007: Show volume coverage in progress logs
                    volume_pct = (
                        result["volume_count"] * 100 // result["dates_found"]
                        if result["dates_found"] > 0
                        else 0
                    )
                    logger.info(
                        f"[{i}/{len(symbols)}] ✅ {symbol}: {result['dates_found']}/{result['total_dates']} available, "
                        f"{result['volume_count']} volume ({volume_pct}%)"
                    )

            except Exception as e:
                failed_symbols.append(symbol)
                logger.error(f"[{i}/{len(symbols)}] ❌ {symbol}: Unexpected error: {e}")

    # Summary
    total_records = sum(r["total_dates"] for r in results if not r["error"])
    available_count = sum(r["dates_found"] for r in results if not r["error"])
    volume_count = sum(r["volume_count"] for r in results if not r["error"])

    logger.info("=" * 60)
    logger.info("Backfill Complete!")
    logger.info("=" * 60)
    logger.info(f"Symbols processed: {len(results) - len(failed_symbols)}/{len(symbols)}")
    logger.info(f"Records inserted: {total_records:,}")
    logger.info(
        f"Available: {available_count:,} ({available_count * 100 // total_records if total_records else 0}%)"
    )
    logger.info(f"Unavailable: {total_records - available_count:,}")
    # ADR-0007: Volume collection summary
    if args.collect_volume:
        volume_pct = volume_count * 100 // available_count if available_count > 0 else 0
        logger.info(f"Volume metrics: {volume_count:,} ({volume_pct}% of available)")

    if failed_symbols:
        logger.warning(f"Failed symbols ({len(failed_symbols)}): {', '.join(failed_symbols[:10])}")
        if len(failed_symbols) > 10:
            logger.warning(f"... and {len(failed_symbols) - 10} more")
        return 1

    logger.info("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
