"""Tests for ADR-0012: Auto-Backfill New Symbols."""
