"""Tests for volume rankings generation (ADR-0013)."""
