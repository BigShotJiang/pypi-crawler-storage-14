"""CLI smoke tests (ADR-0027)."""
