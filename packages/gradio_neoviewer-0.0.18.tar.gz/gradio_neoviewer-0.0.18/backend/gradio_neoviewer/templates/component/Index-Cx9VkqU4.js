var c1 = Object.defineProperty;
var gi = (r) => {
  throw TypeError(r);
};
var h1 = (r, e, t) => e in r ? c1(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var xe = (r, e, t) => h1(r, typeof e != "symbol" ? e + "" : e, t), d1 = (r, e, t) => e.has(r) || gi("Cannot " + t);
var _i = (r, e, t) => e.has(r) ? gi("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(r) : e.set(r, t);
var qn = (r, e, t) => (d1(r, e, "access private method"), t);
var m1 = Object.defineProperty, f1 = (r, e, t) => e in r ? m1(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t, m0 = (r, e, t) => (f1(r, typeof e != "symbol" ? e + "" : e, t), t), us = (r, e, t) => {
  if (!e.has(r))
    throw TypeError("Cannot " + t);
}, un = (r, e, t) => (us(r, e, "read from private field"), e.get(r)), p1 = (r, e, t) => {
  if (e.has(r))
    throw TypeError("Cannot add the same private member more than once");
  e instanceof WeakSet ? e.add(r) : e.set(r, t);
}, g1 = (r, e, t, n) => (us(r, e, "write to private field"), e.set(r, t), t), C0;
new Intl.Collator(0, { numeric: 1 }).compare;
class _1 {
  constructor({
    path: e,
    url: t,
    orig_name: n,
    size: a,
    blob: i,
    is_stream: l,
    mime_type: s,
    alt_text: o
  }) {
    m0(this, "path"), m0(this, "url"), m0(this, "orig_name"), m0(this, "size"), m0(this, "blob"), m0(this, "is_stream"), m0(this, "mime_type"), m0(this, "alt_text"), m0(this, "meta", { _type: "gradio.FileData" }), this.path = e, this.url = t, this.orig_name = n, this.size = a, this.blob = t ? void 0 : i, this.is_stream = l, this.mime_type = s, this.alt_text = o;
  }
}
typeof process < "u" && process.versions && process.versions.node;
class _4 extends TransformStream {
  /** Constructs a new instance. */
  constructor(e = { allowCR: !1 }) {
    super({
      transform: (t, n) => {
        for (t = un(this, C0) + t; ; ) {
          const a = t.indexOf(`
`), i = e.allowCR ? t.indexOf("\r") : -1;
          if (i !== -1 && i !== t.length - 1 && (a === -1 || a - 1 > i)) {
            n.enqueue(t.slice(0, i)), t = t.slice(i + 1);
            continue;
          }
          if (a === -1)
            break;
          const l = t[a - 1] === "\r" ? a - 1 : a;
          n.enqueue(t.slice(0, l)), t = t.slice(a + 1);
        }
        g1(this, C0, t);
      },
      flush: (t) => {
        if (un(this, C0) === "")
          return;
        const n = e.allowCR && un(this, C0).endsWith("\r") ? un(this, C0).slice(0, -1) : un(this, C0);
        t.enqueue(n);
      }
    }), p1(this, C0, "");
  }
}
C0 = /* @__PURE__ */ new WeakMap();
const {
  SvelteComponent: v1,
  assign: y1,
  children: b1,
  claim_element: w1,
  create_slot: x1,
  detach: vi,
  element: k1,
  get_all_dirty_from_scope: S1,
  get_slot_changes: $1,
  get_spread_update: D1,
  init: A1,
  insert_hydration: C1,
  safe_not_equal: E1,
  set_dynamic_element_data: yi,
  set_style: Ye,
  toggle_class: St,
  transition_in: cs,
  transition_out: hs,
  update_slot_base: F1
} = window.__gradio__svelte__internal;
function T1(r) {
  let e, t, n;
  const a = (
    /*#slots*/
    r[22].default
  ), i = x1(
    a,
    r,
    /*$$scope*/
    r[21],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      r[10]
    ) },
    { id: (
      /*elem_id*/
      r[5]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      r[6].join(" ") + " svelte-1ezsyiy"
    }
  ], s = {};
  for (let o = 0; o < l.length; o += 1)
    s = y1(s, l[o]);
  return {
    c() {
      e = k1(
        /*tag*/
        r[18]
      ), i && i.c(), this.h();
    },
    l(o) {
      e = w1(
        o,
        /*tag*/
        (r[18] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0
        }
      );
      var h = b1(e);
      i && i.l(h), h.forEach(vi), this.h();
    },
    h() {
      yi(
        /*tag*/
        r[18]
      )(e, s), St(
        e,
        "hidden",
        /*visible*/
        r[13] === !1
      ), St(
        e,
        "padded",
        /*padding*/
        r[9]
      ), St(
        e,
        "flex",
        /*flex*/
        r[0]
      ), St(
        e,
        "border_focus",
        /*border_mode*/
        r[8] === "focus"
      ), St(
        e,
        "border_contrast",
        /*border_mode*/
        r[8] === "contrast"
      ), St(e, "hide-container", !/*explicit_call*/
      r[11] && !/*container*/
      r[12]), Ye(
        e,
        "height",
        /*get_dimension*/
        r[19](
          /*height*/
          r[1]
        )
      ), Ye(
        e,
        "min-height",
        /*get_dimension*/
        r[19](
          /*min_height*/
          r[2]
        )
      ), Ye(
        e,
        "max-height",
        /*get_dimension*/
        r[19](
          /*max_height*/
          r[3]
        )
      ), Ye(e, "width", typeof /*width*/
      r[4] == "number" ? `calc(min(${/*width*/
      r[4]}px, 100%))` : (
        /*get_dimension*/
        r[19](
          /*width*/
          r[4]
        )
      )), Ye(
        e,
        "border-style",
        /*variant*/
        r[7]
      ), Ye(
        e,
        "overflow",
        /*allow_overflow*/
        r[14] ? (
          /*overflow_behavior*/
          r[15]
        ) : "hidden"
      ), Ye(
        e,
        "flex-grow",
        /*scale*/
        r[16]
      ), Ye(e, "min-width", `calc(min(${/*min_width*/
      r[17]}px, 100%))`), Ye(e, "border-width", "var(--block-border-width)");
    },
    m(o, h) {
      C1(o, e, h), i && i.m(e, null), n = !0;
    },
    p(o, h) {
      i && i.p && (!n || h & /*$$scope*/
      2097152) && F1(
        i,
        a,
        o,
        /*$$scope*/
        o[21],
        n ? $1(
          a,
          /*$$scope*/
          o[21],
          h,
          null
        ) : S1(
          /*$$scope*/
          o[21]
        ),
        null
      ), yi(
        /*tag*/
        o[18]
      )(e, s = D1(l, [
        (!n || h & /*test_id*/
        1024) && { "data-testid": (
          /*test_id*/
          o[10]
        ) },
        (!n || h & /*elem_id*/
        32) && { id: (
          /*elem_id*/
          o[5]
        ) },
        (!n || h & /*elem_classes*/
        64 && t !== (t = "block " + /*elem_classes*/
        o[6].join(" ") + " svelte-1ezsyiy")) && { class: t }
      ])), St(
        e,
        "hidden",
        /*visible*/
        o[13] === !1
      ), St(
        e,
        "padded",
        /*padding*/
        o[9]
      ), St(
        e,
        "flex",
        /*flex*/
        o[0]
      ), St(
        e,
        "border_focus",
        /*border_mode*/
        o[8] === "focus"
      ), St(
        e,
        "border_contrast",
        /*border_mode*/
        o[8] === "contrast"
      ), St(e, "hide-container", !/*explicit_call*/
      o[11] && !/*container*/
      o[12]), h & /*height*/
      2 && Ye(
        e,
        "height",
        /*get_dimension*/
        o[19](
          /*height*/
          o[1]
        )
      ), h & /*min_height*/
      4 && Ye(
        e,
        "min-height",
        /*get_dimension*/
        o[19](
          /*min_height*/
          o[2]
        )
      ), h & /*max_height*/
      8 && Ye(
        e,
        "max-height",
        /*get_dimension*/
        o[19](
          /*max_height*/
          o[3]
        )
      ), h & /*width*/
      16 && Ye(e, "width", typeof /*width*/
      o[4] == "number" ? `calc(min(${/*width*/
      o[4]}px, 100%))` : (
        /*get_dimension*/
        o[19](
          /*width*/
          o[4]
        )
      )), h & /*variant*/
      128 && Ye(
        e,
        "border-style",
        /*variant*/
        o[7]
      ), h & /*allow_overflow, overflow_behavior*/
      49152 && Ye(
        e,
        "overflow",
        /*allow_overflow*/
        o[14] ? (
          /*overflow_behavior*/
          o[15]
        ) : "hidden"
      ), h & /*scale*/
      65536 && Ye(
        e,
        "flex-grow",
        /*scale*/
        o[16]
      ), h & /*min_width*/
      131072 && Ye(e, "min-width", `calc(min(${/*min_width*/
      o[17]}px, 100%))`);
    },
    i(o) {
      n || (cs(i, o), n = !0);
    },
    o(o) {
      hs(i, o), n = !1;
    },
    d(o) {
      o && vi(e), i && i.d(o);
    }
  };
}
function M1(r) {
  let e, t = (
    /*tag*/
    r[18] && T1(r)
  );
  return {
    c() {
      t && t.c();
    },
    l(n) {
      t && t.l(n);
    },
    m(n, a) {
      t && t.m(n, a), e = !0;
    },
    p(n, [a]) {
      /*tag*/
      n[18] && t.p(n, a);
    },
    i(n) {
      e || (cs(t, n), e = !0);
    },
    o(n) {
      hs(t, n), e = !1;
    },
    d(n) {
      t && t.d(n);
    }
  };
}
function z1(r, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: i = void 0 } = e, { min_height: l = void 0 } = e, { max_height: s = void 0 } = e, { width: o = void 0 } = e, { elem_id: h = "" } = e, { elem_classes: m = [] } = e, { variant: p = "solid" } = e, { border_mode: g = "base" } = e, { padding: _ = !0 } = e, { type: C = "normal" } = e, { test_id: T = void 0 } = e, { explicit_call: F = !1 } = e, { container: M = !0 } = e, { visible: w = !0 } = e, { allow_overflow: v = !0 } = e, { overflow_behavior: x = "auto" } = e, { scale: $ = null } = e, { min_width: E = 0 } = e, { flex: A = !1 } = e;
  w || (A = !1);
  let q = C === "fieldset" ? "fieldset" : "div";
  const B = (z) => {
    if (z !== void 0) {
      if (typeof z == "number")
        return z + "px";
      if (typeof z == "string")
        return z;
    }
  };
  return r.$$set = (z) => {
    "height" in z && t(1, i = z.height), "min_height" in z && t(2, l = z.min_height), "max_height" in z && t(3, s = z.max_height), "width" in z && t(4, o = z.width), "elem_id" in z && t(5, h = z.elem_id), "elem_classes" in z && t(6, m = z.elem_classes), "variant" in z && t(7, p = z.variant), "border_mode" in z && t(8, g = z.border_mode), "padding" in z && t(9, _ = z.padding), "type" in z && t(20, C = z.type), "test_id" in z && t(10, T = z.test_id), "explicit_call" in z && t(11, F = z.explicit_call), "container" in z && t(12, M = z.container), "visible" in z && t(13, w = z.visible), "allow_overflow" in z && t(14, v = z.allow_overflow), "overflow_behavior" in z && t(15, x = z.overflow_behavior), "scale" in z && t(16, $ = z.scale), "min_width" in z && t(17, E = z.min_width), "flex" in z && t(0, A = z.flex), "$$scope" in z && t(21, a = z.$$scope);
  }, [
    A,
    i,
    l,
    s,
    o,
    h,
    m,
    p,
    g,
    _,
    T,
    F,
    M,
    w,
    v,
    x,
    $,
    E,
    q,
    B,
    C,
    a,
    n
  ];
}
class B1 extends v1 {
  constructor(e) {
    super(), A1(this, e, z1, M1, E1, {
      height: 1,
      min_height: 2,
      max_height: 3,
      width: 4,
      elem_id: 5,
      elem_classes: 6,
      variant: 7,
      border_mode: 8,
      padding: 9,
      type: 20,
      test_id: 10,
      explicit_call: 11,
      container: 12,
      visible: 13,
      allow_overflow: 14,
      overflow_behavior: 15,
      scale: 16,
      min_width: 17,
      flex: 0
    });
  }
}
class _t {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, n) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = n;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new _t(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class Ft {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new Ft(t, _t.range(this, e));
  }
}
class O {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var n = "KaTeX parse error: " + e, a, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var s = l.lexer.input;
      a = l.start, i = l.end, a === s.length ? n += " at end of input: " : n += " at position " + (a + 1) + ": ";
      var o = s.slice(a, i).replace(/[^]/g, "$&̲"), h;
      a > 15 ? h = "…" + s.slice(a - 15, a) : h = s.slice(0, a);
      var m;
      i + 15 < s.length ? m = s.slice(i, i + 15) + "…" : m = s.slice(i), n += h + o + m;
    }
    var p = new Error(n);
    return p.name = "ParseError", p.__proto__ = O.prototype, p.position = a, a != null && i != null && (p.length = i - a), p.rawMessage = e, p;
  }
}
O.prototype.__proto__ = Error.prototype;
var q1 = function(e, t) {
  return e.indexOf(t) !== -1;
}, R1 = function(e, t) {
  return e === void 0 ? t : e;
}, N1 = /([A-Z])/g, L1 = function(e) {
  return e.replace(N1, "-$1").toLowerCase();
}, I1 = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, O1 = /[&><"']/g;
function P1(r) {
  return String(r).replace(O1, (e) => I1[e]);
}
var ds = function r(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? r(e.body[0]) : e : e.type === "font" ? r(e.body) : e;
}, H1 = function(e) {
  var t = ds(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, U1 = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, G1 = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, Z = {
  contains: q1,
  deflt: R1,
  escape: P1,
  hyphenate: L1,
  getBaseElem: ds,
  isCharacterBox: H1,
  protocolFromUrl: G1
}, rr = {
  displayMode: {
    type: "boolean",
    description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
    cli: "-d, --display-mode"
  },
  output: {
    type: {
      enum: ["htmlAndMathml", "html", "mathml"]
    },
    description: "Determines the markup language of the output.",
    cli: "-F, --format <type>"
  },
  leqno: {
    type: "boolean",
    description: "Render display math in leqno style (left-justified tags)."
  },
  fleqn: {
    type: "boolean",
    description: "Render display math flush left."
  },
  throwOnError: {
    type: "boolean",
    default: !0,
    cli: "-t, --no-throw-on-error",
    cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
  },
  errorColor: {
    type: "string",
    default: "#cc0000",
    cli: "-c, --error-color <color>",
    cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
    cliProcessor: (r) => "#" + r
  },
  macros: {
    type: "object",
    cli: "-m, --macro <def>",
    cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
    cliDefault: [],
    cliProcessor: (r, e) => (e.push(r), e)
  },
  minRuleThickness: {
    type: "number",
    description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
    processor: (r) => Math.max(0, r),
    cli: "--min-rule-thickness <size>",
    cliProcessor: parseFloat
  },
  colorIsTextColor: {
    type: "boolean",
    description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
    cli: "-b, --color-is-text-color"
  },
  strict: {
    type: [{
      enum: ["warn", "ignore", "error"]
    }, "boolean", "function"],
    description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
    cli: "-S, --strict",
    cliDefault: !1
  },
  trust: {
    type: ["boolean", "function"],
    description: "Trust the input, enabling all HTML features such as \\url.",
    cli: "-T, --trust"
  },
  maxSize: {
    type: "number",
    default: 1 / 0,
    description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
    processor: (r) => Math.max(0, r),
    cli: "-s, --max-size <n>",
    cliProcessor: parseInt
  },
  maxExpand: {
    type: "number",
    default: 1e3,
    description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
    processor: (r) => Math.max(0, r),
    cli: "-e, --max-expand <n>",
    cliProcessor: (r) => r === "Infinity" ? 1 / 0 : parseInt(r)
  },
  globalGroup: {
    type: "boolean",
    cli: !1
  }
};
function V1(r) {
  if (r.default)
    return r.default;
  var e = r.type, t = Array.isArray(e) ? e[0] : e;
  if (typeof t != "string")
    return t.enum[0];
  switch (t) {
    case "boolean":
      return !1;
    case "string":
      return "";
    case "number":
      return 0;
    case "object":
      return {};
  }
}
class Ea {
  constructor(e) {
    this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, e = e || {};
    for (var t in rr)
      if (rr.hasOwnProperty(t)) {
        var n = rr[t];
        this[t] = e[t] !== void 0 ? n.processor ? n.processor(e[t]) : e[t] : V1(n);
      }
  }
  /**
   * Report nonstrict (non-LaTeX-compatible) input.
   * Can safely not be called if `this.strict` is false in JavaScript.
   */
  reportNonstrict(e, t, n) {
    var a = this.strict;
    if (typeof a == "function" && (a = a(e, t, n)), !(!a || a === "ignore")) {
      if (a === !0 || a === "error")
        throw new O("LaTeX-incompatible input and strict mode is set to 'error': " + (t + " [" + e + "]"), n);
      a === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + a + "': " + t + " [" + e + "]"));
    }
  }
  /**
   * Check whether to apply strict (LaTeX-adhering) behavior for unusual
   * input (like `\\`).  Unlike `nonstrict`, will not throw an error;
   * instead, "error" translates to a return value of `true`, while "ignore"
   * translates to a return value of `false`.  May still print a warning:
   * "warn" prints a warning and returns `false`.
   * This is for the second category of `errorCode`s listed in the README.
   */
  useStrictBehavior(e, t, n) {
    var a = this.strict;
    if (typeof a == "function")
      try {
        a = a(e, t, n);
      } catch {
        a = "error";
      }
    return !a || a === "ignore" ? !1 : a === !0 || a === "error" ? !0 : a === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + a + "': " + t + " [" + e + "]")), !1);
  }
  /**
   * Check whether to test potentially dangerous input, and return
   * `true` (trusted) or `false` (untrusted).  The sole argument `context`
   * should be an object with `command` field specifying the relevant LaTeX
   * command (as a string starting with `\`), and any other arguments, etc.
   * If `context` has a `url` field, a `protocol` field will automatically
   * get added by this function (changing the specified object).
   */
  isTrusted(e) {
    if (e.url && !e.protocol) {
      var t = Z.protocolFromUrl(e.url);
      if (t == null)
        return !1;
      e.protocol = t;
    }
    var n = typeof this.trust == "function" ? this.trust(e) : this.trust;
    return !!n;
  }
}
class $0 {
  constructor(e, t, n) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = n;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return Yt[W1[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return Yt[j1[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return Yt[X1[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return Yt[Y1[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return Yt[Z1[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return Yt[K1[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var Fa = 0, ur = 1, tn = 2, y0 = 3, Sn = 4, At = 5, rn = 6, at = 7, Yt = [new $0(Fa, 0, !1), new $0(ur, 0, !0), new $0(tn, 1, !1), new $0(y0, 1, !0), new $0(Sn, 2, !1), new $0(At, 2, !0), new $0(rn, 3, !1), new $0(at, 3, !0)], W1 = [Sn, At, Sn, At, rn, at, rn, at], j1 = [At, At, At, At, at, at, at, at], X1 = [tn, y0, Sn, At, rn, at, rn, at], Y1 = [y0, y0, At, At, at, at, at, at], Z1 = [ur, ur, y0, y0, At, At, at, at], K1 = [Fa, ur, tn, y0, tn, y0, tn, y0], J = {
  DISPLAY: Yt[Fa],
  TEXT: Yt[tn],
  SCRIPT: Yt[Sn],
  SCRIPTSCRIPT: Yt[rn]
}, sa = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function Q1(r) {
  for (var e = 0; e < sa.length; e++)
    for (var t = sa[e], n = 0; n < t.blocks.length; n++) {
      var a = t.blocks[n];
      if (r >= a[0] && r <= a[1])
        return t.name;
    }
  return null;
}
var ar = [];
sa.forEach((r) => r.blocks.forEach((e) => ar.push(...e)));
function ms(r) {
  for (var e = 0; e < ar.length; e += 2)
    if (r >= ar[e] && r <= ar[e + 1])
      return !0;
  return !1;
}
var Q0 = 80, J1 = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, eu = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, tu = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, nu = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, ru = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, au = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, iu = function(e, t, n) {
  var a = n - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, lu = function(e, t, n) {
  t = 1e3 * t;
  var a = "";
  switch (e) {
    case "sqrtMain":
      a = J1(t, Q0);
      break;
    case "sqrtSize1":
      a = eu(t, Q0);
      break;
    case "sqrtSize2":
      a = tu(t, Q0);
      break;
    case "sqrtSize3":
      a = nu(t, Q0);
      break;
    case "sqrtSize4":
      a = ru(t, Q0);
      break;
    case "sqrtTall":
      a = iu(t, Q0, n);
  }
  return a;
}, su = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, bi = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, ou = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class Dn {
  // HtmlDomNode
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return Z.contains(this.classes, e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var Qt = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, Rn = {
  slant: [0.25, 0.25, 0.25],
  // sigma1
  space: [0, 0, 0],
  // sigma2
  stretch: [0, 0, 0],
  // sigma3
  shrink: [0, 0, 0],
  // sigma4
  xHeight: [0.431, 0.431, 0.431],
  // sigma5
  quad: [1, 1.171, 1.472],
  // sigma6
  extraSpace: [0, 0, 0],
  // sigma7
  num1: [0.677, 0.732, 0.925],
  // sigma8
  num2: [0.394, 0.384, 0.387],
  // sigma9
  num3: [0.444, 0.471, 0.504],
  // sigma10
  denom1: [0.686, 0.752, 1.025],
  // sigma11
  denom2: [0.345, 0.344, 0.532],
  // sigma12
  sup1: [0.413, 0.503, 0.504],
  // sigma13
  sup2: [0.363, 0.431, 0.404],
  // sigma14
  sup3: [0.289, 0.286, 0.294],
  // sigma15
  sub1: [0.15, 0.143, 0.2],
  // sigma16
  sub2: [0.247, 0.286, 0.4],
  // sigma17
  supDrop: [0.386, 0.353, 0.494],
  // sigma18
  subDrop: [0.05, 0.071, 0.1],
  // sigma19
  delim1: [2.39, 1.7, 1.98],
  // sigma20
  delim2: [1.01, 1.157, 1.42],
  // sigma21
  axisHeight: [0.25, 0.25, 0.25],
  // sigma22
  // These font metrics are extracted from TeX by using tftopl on cmex10.tfm;
  // they correspond to the font parameters of the extension fonts (family 3).
  // See the TeXbook, page 441. In AMSTeX, the extension fonts scale; to
  // match cmex7, we'd use cmex7.tfm values for script and scriptscript
  // values.
  defaultRuleThickness: [0.04, 0.049, 0.049],
  // xi8; cmex7: 0.049
  bigOpSpacing1: [0.111, 0.111, 0.111],
  // xi9
  bigOpSpacing2: [0.166, 0.166, 0.166],
  // xi10
  bigOpSpacing3: [0.2, 0.2, 0.2],
  // xi11
  bigOpSpacing4: [0.6, 0.611, 0.611],
  // xi12; cmex7: 0.611
  bigOpSpacing5: [0.1, 0.143, 0.143],
  // xi13; cmex7: 0.143
  // The \sqrt rule width is taken from the height of the surd character.
  // Since we use the same font at all sizes, this thickness doesn't scale.
  sqrtRuleThickness: [0.04, 0.04, 0.04],
  // This value determines how large a pt is, for metrics which are defined
  // in terms of pts.
  // This value is also used in katex.scss; if you change it make sure the
  // values match.
  ptPerEm: [10, 10, 10],
  // The space between adjacent `|` columns in an array definition. From
  // `\showthe\doublerulesep` in LaTeX. Equals 2.0 / ptPerEm.
  doubleRuleSep: [0.2, 0.2, 0.2],
  // The width of separator lines in {array} environments. From
  // `\showthe\arrayrulewidth` in LaTeX. Equals 0.4 / ptPerEm.
  arrayRuleWidth: [0.04, 0.04, 0.04],
  // Two values from LaTeX source2e:
  fboxsep: [0.3, 0.3, 0.3],
  //        3 pt / ptPerEm
  fboxrule: [0.04, 0.04, 0.04]
  // 0.4 pt / ptPerEm
}, wi = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function uu(r, e) {
  Qt[r] = e;
}
function Ta(r, e, t) {
  if (!Qt[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var n = r.charCodeAt(0), a = Qt[e][n];
  if (!a && r[0] in wi && (n = wi[r[0]].charCodeAt(0), a = Qt[e][n]), !a && t === "text" && ms(n) && (a = Qt[e][77]), a)
    return {
      depth: a[0],
      height: a[1],
      italic: a[2],
      skew: a[3],
      width: a[4]
    };
}
var qr = {};
function cu(r) {
  var e;
  if (r >= 5 ? e = 0 : r >= 3 ? e = 1 : e = 2, !qr[e]) {
    var t = qr[e] = {
      cssEmPerMu: Rn.quad[e] / 18
    };
    for (var n in Rn)
      Rn.hasOwnProperty(n) && (t[n] = Rn[n][e]);
  }
  return qr[e];
}
var hu = [
  // Each element contains [textsize, scriptsize, scriptscriptsize].
  // The size mappings are taken from TeX with \normalsize=10pt.
  [1, 1, 1],
  // size1: [5, 5, 5]              \tiny
  [2, 1, 1],
  // size2: [6, 5, 5]
  [3, 1, 1],
  // size3: [7, 5, 5]              \scriptsize
  [4, 2, 1],
  // size4: [8, 6, 5]              \footnotesize
  [5, 2, 1],
  // size5: [9, 6, 5]              \small
  [6, 3, 1],
  // size6: [10, 7, 5]             \normalsize
  [7, 4, 2],
  // size7: [12, 8, 6]             \large
  [8, 6, 3],
  // size8: [14.4, 10, 7]          \Large
  [9, 7, 6],
  // size9: [17.28, 12, 10]        \LARGE
  [10, 8, 7],
  // size10: [20.74, 14.4, 12]     \huge
  [11, 10, 9]
  // size11: [24.88, 20.74, 17.28] \HUGE
], xi = [
  // fontMetrics.js:getGlobalMetrics also uses size indexes, so if
  // you change size indexes, change that function.
  0.5,
  0.6,
  0.7,
  0.8,
  0.9,
  1,
  1.2,
  1.44,
  1.728,
  2.074,
  2.488
], ki = function(e, t) {
  return t.size < 2 ? e : hu[e - 1][t.size - 1];
};
class _0 {
  // A font family applies to a group of fonts (i.e. SansSerif), while a font
  // represents a specific font (i.e. SansSerif Bold).
  // See: https://tex.stackexchange.com/questions/22350/difference-between-textrm-and-mathrm
  /**
   * The base size index.
   */
  constructor(e) {
    this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = e.style, this.color = e.color, this.size = e.size || _0.BASESIZE, this.textSize = e.textSize || this.size, this.phantom = !!e.phantom, this.font = e.font || "", this.fontFamily = e.fontFamily || "", this.fontWeight = e.fontWeight || "", this.fontShape = e.fontShape || "", this.sizeMultiplier = xi[this.size - 1], this.maxSize = e.maxSize, this.minRuleThickness = e.minRuleThickness, this._fontMetrics = void 0;
  }
  /**
   * Returns a new options object with the same properties as "this".  Properties
   * from "extension" will be copied to the new options object.
   */
  extend(e) {
    var t = {
      style: this.style,
      size: this.size,
      textSize: this.textSize,
      color: this.color,
      phantom: this.phantom,
      font: this.font,
      fontFamily: this.fontFamily,
      fontWeight: this.fontWeight,
      fontShape: this.fontShape,
      maxSize: this.maxSize,
      minRuleThickness: this.minRuleThickness
    };
    for (var n in e)
      e.hasOwnProperty(n) && (t[n] = e[n]);
    return new _0(t);
  }
  /**
   * Return an options object with the given style. If `this.style === style`,
   * returns `this`.
   */
  havingStyle(e) {
    return this.style === e ? this : this.extend({
      style: e,
      size: ki(this.textSize, e)
    });
  }
  /**
   * Return an options object with a cramped version of the current style. If
   * the current style is cramped, returns `this`.
   */
  havingCrampedStyle() {
    return this.havingStyle(this.style.cramp());
  }
  /**
   * Return an options object with the given size and in at least `\textstyle`.
   * Returns `this` if appropriate.
   */
  havingSize(e) {
    return this.size === e && this.textSize === e ? this : this.extend({
      style: this.style.text(),
      size: e,
      textSize: e,
      sizeMultiplier: xi[e - 1]
    });
  }
  /**
   * Like `this.havingSize(BASESIZE).havingStyle(style)`. If `style` is omitted,
   * changes to at least `\textstyle`.
   */
  havingBaseStyle(e) {
    e = e || this.style.text();
    var t = ki(_0.BASESIZE, e);
    return this.size === t && this.textSize === _0.BASESIZE && this.style === e ? this : this.extend({
      style: e,
      size: t
    });
  }
  /**
   * Remove the effect of sizing changes such as \Huge.
   * Keep the effect of the current style, such as \scriptstyle.
   */
  havingBaseSizing() {
    var e;
    switch (this.style.id) {
      case 4:
      case 5:
        e = 3;
        break;
      case 6:
      case 7:
        e = 1;
        break;
      default:
        e = 6;
    }
    return this.extend({
      style: this.style.text(),
      size: e
    });
  }
  /**
   * Create a new options object with the given color.
   */
  withColor(e) {
    return this.extend({
      color: e
    });
  }
  /**
   * Create a new options object with "phantom" set to true.
   */
  withPhantom() {
    return this.extend({
      phantom: !0
    });
  }
  /**
   * Creates a new options object with the given math font or old text font.
   * @type {[type]}
   */
  withFont(e) {
    return this.extend({
      font: e
    });
  }
  /**
   * Create a new options objects with the given fontFamily.
   */
  withTextFontFamily(e) {
    return this.extend({
      fontFamily: e,
      font: ""
    });
  }
  /**
   * Creates a new options object with the given font weight
   */
  withTextFontWeight(e) {
    return this.extend({
      fontWeight: e,
      font: ""
    });
  }
  /**
   * Creates a new options object with the given font weight
   */
  withTextFontShape(e) {
    return this.extend({
      fontShape: e,
      font: ""
    });
  }
  /**
   * Return the CSS sizing classes required to switch from enclosing options
   * `oldOptions` to `this`. Returns an array of classes.
   */
  sizingClasses(e) {
    return e.size !== this.size ? ["sizing", "reset-size" + e.size, "size" + this.size] : [];
  }
  /**
   * Return the CSS sizing classes required to switch to the base size. Like
   * `this.havingSize(BASESIZE).sizingClasses(this)`.
   */
  baseSizingClasses() {
    return this.size !== _0.BASESIZE ? ["sizing", "reset-size" + this.size, "size" + _0.BASESIZE] : [];
  }
  /**
   * Return the font metrics for this size.
   */
  fontMetrics() {
    return this._fontMetrics || (this._fontMetrics = cu(this.size)), this._fontMetrics;
  }
  /**
   * Gets the CSS color of the current options object
   */
  getColor() {
    return this.phantom ? "transparent" : this.color;
  }
}
_0.BASESIZE = 6;
var oa = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, du = {
  ex: !0,
  em: !0,
  mu: !0
}, fs = function(e) {
  return typeof e != "string" && (e = e.unit), e in oa || e in du || e === "ex";
}, Ee = function(e, t) {
  var n;
  if (e.unit in oa)
    n = oa[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    n = t.fontMetrics().cssEmPerMu;
  else {
    var a;
    if (t.style.isTight() ? a = t.havingStyle(t.style.text()) : a = t, e.unit === "ex")
      n = a.fontMetrics().xHeight;
    else if (e.unit === "em")
      n = a.fontMetrics().quad;
    else
      throw new O("Invalid unit: '" + e.unit + "'");
    a !== t && (n *= a.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * n, t.maxSize);
}, G = function(e) {
  return +e.toFixed(4) + "em";
}, M0 = function(e) {
  return e.filter((t) => t).join(" ");
}, ps = function(e, t, n) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = n || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var a = t.getColor();
    a && (this.style.color = a);
  }
}, gs = function(e) {
  var t = document.createElement(e);
  t.className = M0(this.classes);
  for (var n in this.style)
    this.style.hasOwnProperty(n) && (t.style[n] = this.style[n]);
  for (var a in this.attributes)
    this.attributes.hasOwnProperty(a) && t.setAttribute(a, this.attributes[a]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, mu = /[\s"'>/=\x00-\x1f]/, _s = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + Z.escape(M0(this.classes)) + '"');
  var n = "";
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (n += Z.hyphenate(a) + ":" + this.style[a] + ";");
  n && (t += ' style="' + Z.escape(n) + '"');
  for (var i in this.attributes)
    if (this.attributes.hasOwnProperty(i)) {
      if (mu.test(i))
        throw new O("Invalid attribute name '" + i + "'");
      t += " " + i + '="' + Z.escape(this.attributes[i]) + '"';
    }
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class An {
  constructor(e, t, n, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, ps.call(this, e, n, a), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return Z.contains(this.classes, e);
  }
  toNode() {
    return gs.call(this, "span");
  }
  toMarkup() {
    return _s.call(this, "span");
  }
}
class Ma {
  constructor(e, t, n, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, ps.call(this, t, a), this.children = n || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return Z.contains(this.classes, e);
  }
  toNode() {
    return gs.call(this, "a");
  }
  toMarkup() {
    return _s.call(this, "a");
  }
}
class fu {
  constructor(e, t, n) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = n;
  }
  hasClass(e) {
    return Z.contains(this.classes, e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + Z.escape(this.src) + '"' + (' alt="' + Z.escape(this.alt) + '"'), t = "";
    for (var n in this.style)
      this.style.hasOwnProperty(n) && (t += Z.hyphenate(n) + ":" + this.style[n] + ";");
    return t && (e += ' style="' + Z.escape(t) + '"'), e += "'/>", e;
  }
}
var pu = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class Mt {
  constructor(e, t, n, a, i, l, s, o) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = n || 0, this.italic = a || 0, this.skew = i || 0, this.width = l || 0, this.classes = s || [], this.style = o || {}, this.maxFontSize = 0;
    var h = Q1(this.text.charCodeAt(0));
    h && this.classes.push(h + "_fallback"), /[îïíì]/.test(this.text) && (this.text = pu[this.text]);
  }
  hasClass(e) {
    return Z.contains(this.classes, e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = G(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = M0(this.classes));
    for (var n in this.style)
      this.style.hasOwnProperty(n) && (t = t || document.createElement("span"), t.style[n] = this.style[n]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += Z.escape(M0(this.classes)), t += '"');
    var n = "";
    this.italic > 0 && (n += "margin-right:" + this.italic + "em;");
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (n += Z.hyphenate(a) + ":" + this.style[a] + ";");
    n && (e = !0, t += ' style="' + Z.escape(n) + '"');
    var i = Z.escape(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class w0 {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var n in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, n) && t.setAttribute(n, this.attributes[n]);
    for (var a = 0; a < this.children.length; a++)
      t.appendChild(this.children[a].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + Z.escape(this.attributes[t]) + '"');
    e += ">";
    for (var n = 0; n < this.children.length; n++)
      e += this.children[n].toMarkup();
    return e += "</svg>", e;
  }
}
class z0 {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", bi[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + Z.escape(this.alternate) + '"/>' : '<path d="' + Z.escape(bi[this.pathName]) + '"/>';
  }
}
class ua {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var n in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, n) && t.setAttribute(n, this.attributes[n]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + Z.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function Si(r) {
  if (r instanceof Mt)
    return r;
  throw new Error("Expected symbolNode but got " + String(r) + ".");
}
function gu(r) {
  if (r instanceof An)
    return r;
  throw new Error("Expected span<HtmlDomNode> but got " + String(r) + ".");
}
var _u = {
  bin: 1,
  close: 1,
  inner: 1,
  open: 1,
  punct: 1,
  rel: 1
}, vu = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, be = {
  math: {},
  text: {}
};
function u(r, e, t, n, a, i) {
  be[r][a] = {
    font: e,
    group: t,
    replace: n
  }, i && n && (be[r][n] = be[r][a]);
}
var c = "math", R = "text", d = "main", y = "ams", $e = "accent-token", W = "bin", st = "close", an = "inner", Q = "mathord", Ne = "op-token", bt = "open", wr = "punct", b = "rel", S0 = "spacing", k = "textord";
u(c, d, b, "≡", "\\equiv", !0);
u(c, d, b, "≺", "\\prec", !0);
u(c, d, b, "≻", "\\succ", !0);
u(c, d, b, "∼", "\\sim", !0);
u(c, d, b, "⊥", "\\perp");
u(c, d, b, "⪯", "\\preceq", !0);
u(c, d, b, "⪰", "\\succeq", !0);
u(c, d, b, "≃", "\\simeq", !0);
u(c, d, b, "∣", "\\mid", !0);
u(c, d, b, "≪", "\\ll", !0);
u(c, d, b, "≫", "\\gg", !0);
u(c, d, b, "≍", "\\asymp", !0);
u(c, d, b, "∥", "\\parallel");
u(c, d, b, "⋈", "\\bowtie", !0);
u(c, d, b, "⌣", "\\smile", !0);
u(c, d, b, "⊑", "\\sqsubseteq", !0);
u(c, d, b, "⊒", "\\sqsupseteq", !0);
u(c, d, b, "≐", "\\doteq", !0);
u(c, d, b, "⌢", "\\frown", !0);
u(c, d, b, "∋", "\\ni", !0);
u(c, d, b, "∝", "\\propto", !0);
u(c, d, b, "⊢", "\\vdash", !0);
u(c, d, b, "⊣", "\\dashv", !0);
u(c, d, b, "∋", "\\owns");
u(c, d, wr, ".", "\\ldotp");
u(c, d, wr, "⋅", "\\cdotp");
u(c, d, k, "#", "\\#");
u(R, d, k, "#", "\\#");
u(c, d, k, "&", "\\&");
u(R, d, k, "&", "\\&");
u(c, d, k, "ℵ", "\\aleph", !0);
u(c, d, k, "∀", "\\forall", !0);
u(c, d, k, "ℏ", "\\hbar", !0);
u(c, d, k, "∃", "\\exists", !0);
u(c, d, k, "∇", "\\nabla", !0);
u(c, d, k, "♭", "\\flat", !0);
u(c, d, k, "ℓ", "\\ell", !0);
u(c, d, k, "♮", "\\natural", !0);
u(c, d, k, "♣", "\\clubsuit", !0);
u(c, d, k, "℘", "\\wp", !0);
u(c, d, k, "♯", "\\sharp", !0);
u(c, d, k, "♢", "\\diamondsuit", !0);
u(c, d, k, "ℜ", "\\Re", !0);
u(c, d, k, "♡", "\\heartsuit", !0);
u(c, d, k, "ℑ", "\\Im", !0);
u(c, d, k, "♠", "\\spadesuit", !0);
u(c, d, k, "§", "\\S", !0);
u(R, d, k, "§", "\\S");
u(c, d, k, "¶", "\\P", !0);
u(R, d, k, "¶", "\\P");
u(c, d, k, "†", "\\dag");
u(R, d, k, "†", "\\dag");
u(R, d, k, "†", "\\textdagger");
u(c, d, k, "‡", "\\ddag");
u(R, d, k, "‡", "\\ddag");
u(R, d, k, "‡", "\\textdaggerdbl");
u(c, d, st, "⎱", "\\rmoustache", !0);
u(c, d, bt, "⎰", "\\lmoustache", !0);
u(c, d, st, "⟯", "\\rgroup", !0);
u(c, d, bt, "⟮", "\\lgroup", !0);
u(c, d, W, "∓", "\\mp", !0);
u(c, d, W, "⊖", "\\ominus", !0);
u(c, d, W, "⊎", "\\uplus", !0);
u(c, d, W, "⊓", "\\sqcap", !0);
u(c, d, W, "∗", "\\ast");
u(c, d, W, "⊔", "\\sqcup", !0);
u(c, d, W, "◯", "\\bigcirc", !0);
u(c, d, W, "∙", "\\bullet", !0);
u(c, d, W, "‡", "\\ddagger");
u(c, d, W, "≀", "\\wr", !0);
u(c, d, W, "⨿", "\\amalg");
u(c, d, W, "&", "\\And");
u(c, d, b, "⟵", "\\longleftarrow", !0);
u(c, d, b, "⇐", "\\Leftarrow", !0);
u(c, d, b, "⟸", "\\Longleftarrow", !0);
u(c, d, b, "⟶", "\\longrightarrow", !0);
u(c, d, b, "⇒", "\\Rightarrow", !0);
u(c, d, b, "⟹", "\\Longrightarrow", !0);
u(c, d, b, "↔", "\\leftrightarrow", !0);
u(c, d, b, "⟷", "\\longleftrightarrow", !0);
u(c, d, b, "⇔", "\\Leftrightarrow", !0);
u(c, d, b, "⟺", "\\Longleftrightarrow", !0);
u(c, d, b, "↦", "\\mapsto", !0);
u(c, d, b, "⟼", "\\longmapsto", !0);
u(c, d, b, "↗", "\\nearrow", !0);
u(c, d, b, "↩", "\\hookleftarrow", !0);
u(c, d, b, "↪", "\\hookrightarrow", !0);
u(c, d, b, "↘", "\\searrow", !0);
u(c, d, b, "↼", "\\leftharpoonup", !0);
u(c, d, b, "⇀", "\\rightharpoonup", !0);
u(c, d, b, "↙", "\\swarrow", !0);
u(c, d, b, "↽", "\\leftharpoondown", !0);
u(c, d, b, "⇁", "\\rightharpoondown", !0);
u(c, d, b, "↖", "\\nwarrow", !0);
u(c, d, b, "⇌", "\\rightleftharpoons", !0);
u(c, y, b, "≮", "\\nless", !0);
u(c, y, b, "", "\\@nleqslant");
u(c, y, b, "", "\\@nleqq");
u(c, y, b, "⪇", "\\lneq", !0);
u(c, y, b, "≨", "\\lneqq", !0);
u(c, y, b, "", "\\@lvertneqq");
u(c, y, b, "⋦", "\\lnsim", !0);
u(c, y, b, "⪉", "\\lnapprox", !0);
u(c, y, b, "⊀", "\\nprec", !0);
u(c, y, b, "⋠", "\\npreceq", !0);
u(c, y, b, "⋨", "\\precnsim", !0);
u(c, y, b, "⪹", "\\precnapprox", !0);
u(c, y, b, "≁", "\\nsim", !0);
u(c, y, b, "", "\\@nshortmid");
u(c, y, b, "∤", "\\nmid", !0);
u(c, y, b, "⊬", "\\nvdash", !0);
u(c, y, b, "⊭", "\\nvDash", !0);
u(c, y, b, "⋪", "\\ntriangleleft");
u(c, y, b, "⋬", "\\ntrianglelefteq", !0);
u(c, y, b, "⊊", "\\subsetneq", !0);
u(c, y, b, "", "\\@varsubsetneq");
u(c, y, b, "⫋", "\\subsetneqq", !0);
u(c, y, b, "", "\\@varsubsetneqq");
u(c, y, b, "≯", "\\ngtr", !0);
u(c, y, b, "", "\\@ngeqslant");
u(c, y, b, "", "\\@ngeqq");
u(c, y, b, "⪈", "\\gneq", !0);
u(c, y, b, "≩", "\\gneqq", !0);
u(c, y, b, "", "\\@gvertneqq");
u(c, y, b, "⋧", "\\gnsim", !0);
u(c, y, b, "⪊", "\\gnapprox", !0);
u(c, y, b, "⊁", "\\nsucc", !0);
u(c, y, b, "⋡", "\\nsucceq", !0);
u(c, y, b, "⋩", "\\succnsim", !0);
u(c, y, b, "⪺", "\\succnapprox", !0);
u(c, y, b, "≆", "\\ncong", !0);
u(c, y, b, "", "\\@nshortparallel");
u(c, y, b, "∦", "\\nparallel", !0);
u(c, y, b, "⊯", "\\nVDash", !0);
u(c, y, b, "⋫", "\\ntriangleright");
u(c, y, b, "⋭", "\\ntrianglerighteq", !0);
u(c, y, b, "", "\\@nsupseteqq");
u(c, y, b, "⊋", "\\supsetneq", !0);
u(c, y, b, "", "\\@varsupsetneq");
u(c, y, b, "⫌", "\\supsetneqq", !0);
u(c, y, b, "", "\\@varsupsetneqq");
u(c, y, b, "⊮", "\\nVdash", !0);
u(c, y, b, "⪵", "\\precneqq", !0);
u(c, y, b, "⪶", "\\succneqq", !0);
u(c, y, b, "", "\\@nsubseteqq");
u(c, y, W, "⊴", "\\unlhd");
u(c, y, W, "⊵", "\\unrhd");
u(c, y, b, "↚", "\\nleftarrow", !0);
u(c, y, b, "↛", "\\nrightarrow", !0);
u(c, y, b, "⇍", "\\nLeftarrow", !0);
u(c, y, b, "⇏", "\\nRightarrow", !0);
u(c, y, b, "↮", "\\nleftrightarrow", !0);
u(c, y, b, "⇎", "\\nLeftrightarrow", !0);
u(c, y, b, "△", "\\vartriangle");
u(c, y, k, "ℏ", "\\hslash");
u(c, y, k, "▽", "\\triangledown");
u(c, y, k, "◊", "\\lozenge");
u(c, y, k, "Ⓢ", "\\circledS");
u(c, y, k, "®", "\\circledR");
u(R, y, k, "®", "\\circledR");
u(c, y, k, "∡", "\\measuredangle", !0);
u(c, y, k, "∄", "\\nexists");
u(c, y, k, "℧", "\\mho");
u(c, y, k, "Ⅎ", "\\Finv", !0);
u(c, y, k, "⅁", "\\Game", !0);
u(c, y, k, "‵", "\\backprime");
u(c, y, k, "▲", "\\blacktriangle");
u(c, y, k, "▼", "\\blacktriangledown");
u(c, y, k, "■", "\\blacksquare");
u(c, y, k, "⧫", "\\blacklozenge");
u(c, y, k, "★", "\\bigstar");
u(c, y, k, "∢", "\\sphericalangle", !0);
u(c, y, k, "∁", "\\complement", !0);
u(c, y, k, "ð", "\\eth", !0);
u(R, d, k, "ð", "ð");
u(c, y, k, "╱", "\\diagup");
u(c, y, k, "╲", "\\diagdown");
u(c, y, k, "□", "\\square");
u(c, y, k, "□", "\\Box");
u(c, y, k, "◊", "\\Diamond");
u(c, y, k, "¥", "\\yen", !0);
u(R, y, k, "¥", "\\yen", !0);
u(c, y, k, "✓", "\\checkmark", !0);
u(R, y, k, "✓", "\\checkmark");
u(c, y, k, "ℶ", "\\beth", !0);
u(c, y, k, "ℸ", "\\daleth", !0);
u(c, y, k, "ℷ", "\\gimel", !0);
u(c, y, k, "ϝ", "\\digamma", !0);
u(c, y, k, "ϰ", "\\varkappa");
u(c, y, bt, "┌", "\\@ulcorner", !0);
u(c, y, st, "┐", "\\@urcorner", !0);
u(c, y, bt, "└", "\\@llcorner", !0);
u(c, y, st, "┘", "\\@lrcorner", !0);
u(c, y, b, "≦", "\\leqq", !0);
u(c, y, b, "⩽", "\\leqslant", !0);
u(c, y, b, "⪕", "\\eqslantless", !0);
u(c, y, b, "≲", "\\lesssim", !0);
u(c, y, b, "⪅", "\\lessapprox", !0);
u(c, y, b, "≊", "\\approxeq", !0);
u(c, y, W, "⋖", "\\lessdot");
u(c, y, b, "⋘", "\\lll", !0);
u(c, y, b, "≶", "\\lessgtr", !0);
u(c, y, b, "⋚", "\\lesseqgtr", !0);
u(c, y, b, "⪋", "\\lesseqqgtr", !0);
u(c, y, b, "≑", "\\doteqdot");
u(c, y, b, "≓", "\\risingdotseq", !0);
u(c, y, b, "≒", "\\fallingdotseq", !0);
u(c, y, b, "∽", "\\backsim", !0);
u(c, y, b, "⋍", "\\backsimeq", !0);
u(c, y, b, "⫅", "\\subseteqq", !0);
u(c, y, b, "⋐", "\\Subset", !0);
u(c, y, b, "⊏", "\\sqsubset", !0);
u(c, y, b, "≼", "\\preccurlyeq", !0);
u(c, y, b, "⋞", "\\curlyeqprec", !0);
u(c, y, b, "≾", "\\precsim", !0);
u(c, y, b, "⪷", "\\precapprox", !0);
u(c, y, b, "⊲", "\\vartriangleleft");
u(c, y, b, "⊴", "\\trianglelefteq");
u(c, y, b, "⊨", "\\vDash", !0);
u(c, y, b, "⊪", "\\Vvdash", !0);
u(c, y, b, "⌣", "\\smallsmile");
u(c, y, b, "⌢", "\\smallfrown");
u(c, y, b, "≏", "\\bumpeq", !0);
u(c, y, b, "≎", "\\Bumpeq", !0);
u(c, y, b, "≧", "\\geqq", !0);
u(c, y, b, "⩾", "\\geqslant", !0);
u(c, y, b, "⪖", "\\eqslantgtr", !0);
u(c, y, b, "≳", "\\gtrsim", !0);
u(c, y, b, "⪆", "\\gtrapprox", !0);
u(c, y, W, "⋗", "\\gtrdot");
u(c, y, b, "⋙", "\\ggg", !0);
u(c, y, b, "≷", "\\gtrless", !0);
u(c, y, b, "⋛", "\\gtreqless", !0);
u(c, y, b, "⪌", "\\gtreqqless", !0);
u(c, y, b, "≖", "\\eqcirc", !0);
u(c, y, b, "≗", "\\circeq", !0);
u(c, y, b, "≜", "\\triangleq", !0);
u(c, y, b, "∼", "\\thicksim");
u(c, y, b, "≈", "\\thickapprox");
u(c, y, b, "⫆", "\\supseteqq", !0);
u(c, y, b, "⋑", "\\Supset", !0);
u(c, y, b, "⊐", "\\sqsupset", !0);
u(c, y, b, "≽", "\\succcurlyeq", !0);
u(c, y, b, "⋟", "\\curlyeqsucc", !0);
u(c, y, b, "≿", "\\succsim", !0);
u(c, y, b, "⪸", "\\succapprox", !0);
u(c, y, b, "⊳", "\\vartriangleright");
u(c, y, b, "⊵", "\\trianglerighteq");
u(c, y, b, "⊩", "\\Vdash", !0);
u(c, y, b, "∣", "\\shortmid");
u(c, y, b, "∥", "\\shortparallel");
u(c, y, b, "≬", "\\between", !0);
u(c, y, b, "⋔", "\\pitchfork", !0);
u(c, y, b, "∝", "\\varpropto");
u(c, y, b, "◀", "\\blacktriangleleft");
u(c, y, b, "∴", "\\therefore", !0);
u(c, y, b, "∍", "\\backepsilon");
u(c, y, b, "▶", "\\blacktriangleright");
u(c, y, b, "∵", "\\because", !0);
u(c, y, b, "⋘", "\\llless");
u(c, y, b, "⋙", "\\gggtr");
u(c, y, W, "⊲", "\\lhd");
u(c, y, W, "⊳", "\\rhd");
u(c, y, b, "≂", "\\eqsim", !0);
u(c, d, b, "⋈", "\\Join");
u(c, y, b, "≑", "\\Doteq", !0);
u(c, y, W, "∔", "\\dotplus", !0);
u(c, y, W, "∖", "\\smallsetminus");
u(c, y, W, "⋒", "\\Cap", !0);
u(c, y, W, "⋓", "\\Cup", !0);
u(c, y, W, "⩞", "\\doublebarwedge", !0);
u(c, y, W, "⊟", "\\boxminus", !0);
u(c, y, W, "⊞", "\\boxplus", !0);
u(c, y, W, "⋇", "\\divideontimes", !0);
u(c, y, W, "⋉", "\\ltimes", !0);
u(c, y, W, "⋊", "\\rtimes", !0);
u(c, y, W, "⋋", "\\leftthreetimes", !0);
u(c, y, W, "⋌", "\\rightthreetimes", !0);
u(c, y, W, "⋏", "\\curlywedge", !0);
u(c, y, W, "⋎", "\\curlyvee", !0);
u(c, y, W, "⊝", "\\circleddash", !0);
u(c, y, W, "⊛", "\\circledast", !0);
u(c, y, W, "⋅", "\\centerdot");
u(c, y, W, "⊺", "\\intercal", !0);
u(c, y, W, "⋒", "\\doublecap");
u(c, y, W, "⋓", "\\doublecup");
u(c, y, W, "⊠", "\\boxtimes", !0);
u(c, y, b, "⇢", "\\dashrightarrow", !0);
u(c, y, b, "⇠", "\\dashleftarrow", !0);
u(c, y, b, "⇇", "\\leftleftarrows", !0);
u(c, y, b, "⇆", "\\leftrightarrows", !0);
u(c, y, b, "⇚", "\\Lleftarrow", !0);
u(c, y, b, "↞", "\\twoheadleftarrow", !0);
u(c, y, b, "↢", "\\leftarrowtail", !0);
u(c, y, b, "↫", "\\looparrowleft", !0);
u(c, y, b, "⇋", "\\leftrightharpoons", !0);
u(c, y, b, "↶", "\\curvearrowleft", !0);
u(c, y, b, "↺", "\\circlearrowleft", !0);
u(c, y, b, "↰", "\\Lsh", !0);
u(c, y, b, "⇈", "\\upuparrows", !0);
u(c, y, b, "↿", "\\upharpoonleft", !0);
u(c, y, b, "⇃", "\\downharpoonleft", !0);
u(c, d, b, "⊶", "\\origof", !0);
u(c, d, b, "⊷", "\\imageof", !0);
u(c, y, b, "⊸", "\\multimap", !0);
u(c, y, b, "↭", "\\leftrightsquigarrow", !0);
u(c, y, b, "⇉", "\\rightrightarrows", !0);
u(c, y, b, "⇄", "\\rightleftarrows", !0);
u(c, y, b, "↠", "\\twoheadrightarrow", !0);
u(c, y, b, "↣", "\\rightarrowtail", !0);
u(c, y, b, "↬", "\\looparrowright", !0);
u(c, y, b, "↷", "\\curvearrowright", !0);
u(c, y, b, "↻", "\\circlearrowright", !0);
u(c, y, b, "↱", "\\Rsh", !0);
u(c, y, b, "⇊", "\\downdownarrows", !0);
u(c, y, b, "↾", "\\upharpoonright", !0);
u(c, y, b, "⇂", "\\downharpoonright", !0);
u(c, y, b, "⇝", "\\rightsquigarrow", !0);
u(c, y, b, "⇝", "\\leadsto");
u(c, y, b, "⇛", "\\Rrightarrow", !0);
u(c, y, b, "↾", "\\restriction");
u(c, d, k, "‘", "`");
u(c, d, k, "$", "\\$");
u(R, d, k, "$", "\\$");
u(R, d, k, "$", "\\textdollar");
u(c, d, k, "%", "\\%");
u(R, d, k, "%", "\\%");
u(c, d, k, "_", "\\_");
u(R, d, k, "_", "\\_");
u(R, d, k, "_", "\\textunderscore");
u(c, d, k, "∠", "\\angle", !0);
u(c, d, k, "∞", "\\infty", !0);
u(c, d, k, "′", "\\prime");
u(c, d, k, "△", "\\triangle");
u(c, d, k, "Γ", "\\Gamma", !0);
u(c, d, k, "Δ", "\\Delta", !0);
u(c, d, k, "Θ", "\\Theta", !0);
u(c, d, k, "Λ", "\\Lambda", !0);
u(c, d, k, "Ξ", "\\Xi", !0);
u(c, d, k, "Π", "\\Pi", !0);
u(c, d, k, "Σ", "\\Sigma", !0);
u(c, d, k, "Υ", "\\Upsilon", !0);
u(c, d, k, "Φ", "\\Phi", !0);
u(c, d, k, "Ψ", "\\Psi", !0);
u(c, d, k, "Ω", "\\Omega", !0);
u(c, d, k, "A", "Α");
u(c, d, k, "B", "Β");
u(c, d, k, "E", "Ε");
u(c, d, k, "Z", "Ζ");
u(c, d, k, "H", "Η");
u(c, d, k, "I", "Ι");
u(c, d, k, "K", "Κ");
u(c, d, k, "M", "Μ");
u(c, d, k, "N", "Ν");
u(c, d, k, "O", "Ο");
u(c, d, k, "P", "Ρ");
u(c, d, k, "T", "Τ");
u(c, d, k, "X", "Χ");
u(c, d, k, "¬", "\\neg", !0);
u(c, d, k, "¬", "\\lnot");
u(c, d, k, "⊤", "\\top");
u(c, d, k, "⊥", "\\bot");
u(c, d, k, "∅", "\\emptyset");
u(c, y, k, "∅", "\\varnothing");
u(c, d, Q, "α", "\\alpha", !0);
u(c, d, Q, "β", "\\beta", !0);
u(c, d, Q, "γ", "\\gamma", !0);
u(c, d, Q, "δ", "\\delta", !0);
u(c, d, Q, "ϵ", "\\epsilon", !0);
u(c, d, Q, "ζ", "\\zeta", !0);
u(c, d, Q, "η", "\\eta", !0);
u(c, d, Q, "θ", "\\theta", !0);
u(c, d, Q, "ι", "\\iota", !0);
u(c, d, Q, "κ", "\\kappa", !0);
u(c, d, Q, "λ", "\\lambda", !0);
u(c, d, Q, "μ", "\\mu", !0);
u(c, d, Q, "ν", "\\nu", !0);
u(c, d, Q, "ξ", "\\xi", !0);
u(c, d, Q, "ο", "\\omicron", !0);
u(c, d, Q, "π", "\\pi", !0);
u(c, d, Q, "ρ", "\\rho", !0);
u(c, d, Q, "σ", "\\sigma", !0);
u(c, d, Q, "τ", "\\tau", !0);
u(c, d, Q, "υ", "\\upsilon", !0);
u(c, d, Q, "ϕ", "\\phi", !0);
u(c, d, Q, "χ", "\\chi", !0);
u(c, d, Q, "ψ", "\\psi", !0);
u(c, d, Q, "ω", "\\omega", !0);
u(c, d, Q, "ε", "\\varepsilon", !0);
u(c, d, Q, "ϑ", "\\vartheta", !0);
u(c, d, Q, "ϖ", "\\varpi", !0);
u(c, d, Q, "ϱ", "\\varrho", !0);
u(c, d, Q, "ς", "\\varsigma", !0);
u(c, d, Q, "φ", "\\varphi", !0);
u(c, d, W, "∗", "*", !0);
u(c, d, W, "+", "+");
u(c, d, W, "−", "-", !0);
u(c, d, W, "⋅", "\\cdot", !0);
u(c, d, W, "∘", "\\circ", !0);
u(c, d, W, "÷", "\\div", !0);
u(c, d, W, "±", "\\pm", !0);
u(c, d, W, "×", "\\times", !0);
u(c, d, W, "∩", "\\cap", !0);
u(c, d, W, "∪", "\\cup", !0);
u(c, d, W, "∖", "\\setminus", !0);
u(c, d, W, "∧", "\\land");
u(c, d, W, "∨", "\\lor");
u(c, d, W, "∧", "\\wedge", !0);
u(c, d, W, "∨", "\\vee", !0);
u(c, d, k, "√", "\\surd");
u(c, d, bt, "⟨", "\\langle", !0);
u(c, d, bt, "∣", "\\lvert");
u(c, d, bt, "∥", "\\lVert");
u(c, d, st, "?", "?");
u(c, d, st, "!", "!");
u(c, d, st, "⟩", "\\rangle", !0);
u(c, d, st, "∣", "\\rvert");
u(c, d, st, "∥", "\\rVert");
u(c, d, b, "=", "=");
u(c, d, b, ":", ":");
u(c, d, b, "≈", "\\approx", !0);
u(c, d, b, "≅", "\\cong", !0);
u(c, d, b, "≥", "\\ge");
u(c, d, b, "≥", "\\geq", !0);
u(c, d, b, "←", "\\gets");
u(c, d, b, ">", "\\gt", !0);
u(c, d, b, "∈", "\\in", !0);
u(c, d, b, "", "\\@not");
u(c, d, b, "⊂", "\\subset", !0);
u(c, d, b, "⊃", "\\supset", !0);
u(c, d, b, "⊆", "\\subseteq", !0);
u(c, d, b, "⊇", "\\supseteq", !0);
u(c, y, b, "⊈", "\\nsubseteq", !0);
u(c, y, b, "⊉", "\\nsupseteq", !0);
u(c, d, b, "⊨", "\\models");
u(c, d, b, "←", "\\leftarrow", !0);
u(c, d, b, "≤", "\\le");
u(c, d, b, "≤", "\\leq", !0);
u(c, d, b, "<", "\\lt", !0);
u(c, d, b, "→", "\\rightarrow", !0);
u(c, d, b, "→", "\\to");
u(c, y, b, "≱", "\\ngeq", !0);
u(c, y, b, "≰", "\\nleq", !0);
u(c, d, S0, " ", "\\ ");
u(c, d, S0, " ", "\\space");
u(c, d, S0, " ", "\\nobreakspace");
u(R, d, S0, " ", "\\ ");
u(R, d, S0, " ", " ");
u(R, d, S0, " ", "\\space");
u(R, d, S0, " ", "\\nobreakspace");
u(c, d, S0, null, "\\nobreak");
u(c, d, S0, null, "\\allowbreak");
u(c, d, wr, ",", ",");
u(c, d, wr, ";", ";");
u(c, y, W, "⊼", "\\barwedge", !0);
u(c, y, W, "⊻", "\\veebar", !0);
u(c, d, W, "⊙", "\\odot", !0);
u(c, d, W, "⊕", "\\oplus", !0);
u(c, d, W, "⊗", "\\otimes", !0);
u(c, d, k, "∂", "\\partial", !0);
u(c, d, W, "⊘", "\\oslash", !0);
u(c, y, W, "⊚", "\\circledcirc", !0);
u(c, y, W, "⊡", "\\boxdot", !0);
u(c, d, W, "△", "\\bigtriangleup");
u(c, d, W, "▽", "\\bigtriangledown");
u(c, d, W, "†", "\\dagger");
u(c, d, W, "⋄", "\\diamond");
u(c, d, W, "⋆", "\\star");
u(c, d, W, "◃", "\\triangleleft");
u(c, d, W, "▹", "\\triangleright");
u(c, d, bt, "{", "\\{");
u(R, d, k, "{", "\\{");
u(R, d, k, "{", "\\textbraceleft");
u(c, d, st, "}", "\\}");
u(R, d, k, "}", "\\}");
u(R, d, k, "}", "\\textbraceright");
u(c, d, bt, "{", "\\lbrace");
u(c, d, st, "}", "\\rbrace");
u(c, d, bt, "[", "\\lbrack", !0);
u(R, d, k, "[", "\\lbrack", !0);
u(c, d, st, "]", "\\rbrack", !0);
u(R, d, k, "]", "\\rbrack", !0);
u(c, d, bt, "(", "\\lparen", !0);
u(c, d, st, ")", "\\rparen", !0);
u(R, d, k, "<", "\\textless", !0);
u(R, d, k, ">", "\\textgreater", !0);
u(c, d, bt, "⌊", "\\lfloor", !0);
u(c, d, st, "⌋", "\\rfloor", !0);
u(c, d, bt, "⌈", "\\lceil", !0);
u(c, d, st, "⌉", "\\rceil", !0);
u(c, d, k, "\\", "\\backslash");
u(c, d, k, "∣", "|");
u(c, d, k, "∣", "\\vert");
u(R, d, k, "|", "\\textbar", !0);
u(c, d, k, "∥", "\\|");
u(c, d, k, "∥", "\\Vert");
u(R, d, k, "∥", "\\textbardbl");
u(R, d, k, "~", "\\textasciitilde");
u(R, d, k, "\\", "\\textbackslash");
u(R, d, k, "^", "\\textasciicircum");
u(c, d, b, "↑", "\\uparrow", !0);
u(c, d, b, "⇑", "\\Uparrow", !0);
u(c, d, b, "↓", "\\downarrow", !0);
u(c, d, b, "⇓", "\\Downarrow", !0);
u(c, d, b, "↕", "\\updownarrow", !0);
u(c, d, b, "⇕", "\\Updownarrow", !0);
u(c, d, Ne, "∐", "\\coprod");
u(c, d, Ne, "⋁", "\\bigvee");
u(c, d, Ne, "⋀", "\\bigwedge");
u(c, d, Ne, "⨄", "\\biguplus");
u(c, d, Ne, "⋂", "\\bigcap");
u(c, d, Ne, "⋃", "\\bigcup");
u(c, d, Ne, "∫", "\\int");
u(c, d, Ne, "∫", "\\intop");
u(c, d, Ne, "∬", "\\iint");
u(c, d, Ne, "∭", "\\iiint");
u(c, d, Ne, "∏", "\\prod");
u(c, d, Ne, "∑", "\\sum");
u(c, d, Ne, "⨂", "\\bigotimes");
u(c, d, Ne, "⨁", "\\bigoplus");
u(c, d, Ne, "⨀", "\\bigodot");
u(c, d, Ne, "∮", "\\oint");
u(c, d, Ne, "∯", "\\oiint");
u(c, d, Ne, "∰", "\\oiiint");
u(c, d, Ne, "⨆", "\\bigsqcup");
u(c, d, Ne, "∫", "\\smallint");
u(R, d, an, "…", "\\textellipsis");
u(c, d, an, "…", "\\mathellipsis");
u(R, d, an, "…", "\\ldots", !0);
u(c, d, an, "…", "\\ldots", !0);
u(c, d, an, "⋯", "\\@cdots", !0);
u(c, d, an, "⋱", "\\ddots", !0);
u(c, d, k, "⋮", "\\varvdots");
u(R, d, k, "⋮", "\\varvdots");
u(c, d, $e, "ˊ", "\\acute");
u(c, d, $e, "ˋ", "\\grave");
u(c, d, $e, "¨", "\\ddot");
u(c, d, $e, "~", "\\tilde");
u(c, d, $e, "ˉ", "\\bar");
u(c, d, $e, "˘", "\\breve");
u(c, d, $e, "ˇ", "\\check");
u(c, d, $e, "^", "\\hat");
u(c, d, $e, "⃗", "\\vec");
u(c, d, $e, "˙", "\\dot");
u(c, d, $e, "˚", "\\mathring");
u(c, d, Q, "", "\\@imath");
u(c, d, Q, "", "\\@jmath");
u(c, d, k, "ı", "ı");
u(c, d, k, "ȷ", "ȷ");
u(R, d, k, "ı", "\\i", !0);
u(R, d, k, "ȷ", "\\j", !0);
u(R, d, k, "ß", "\\ss", !0);
u(R, d, k, "æ", "\\ae", !0);
u(R, d, k, "œ", "\\oe", !0);
u(R, d, k, "ø", "\\o", !0);
u(R, d, k, "Æ", "\\AE", !0);
u(R, d, k, "Œ", "\\OE", !0);
u(R, d, k, "Ø", "\\O", !0);
u(R, d, $e, "ˊ", "\\'");
u(R, d, $e, "ˋ", "\\`");
u(R, d, $e, "ˆ", "\\^");
u(R, d, $e, "˜", "\\~");
u(R, d, $e, "ˉ", "\\=");
u(R, d, $e, "˘", "\\u");
u(R, d, $e, "˙", "\\.");
u(R, d, $e, "¸", "\\c");
u(R, d, $e, "˚", "\\r");
u(R, d, $e, "ˇ", "\\v");
u(R, d, $e, "¨", '\\"');
u(R, d, $e, "˝", "\\H");
u(R, d, $e, "◯", "\\textcircled");
var vs = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
u(R, d, k, "–", "--", !0);
u(R, d, k, "–", "\\textendash");
u(R, d, k, "—", "---", !0);
u(R, d, k, "—", "\\textemdash");
u(R, d, k, "‘", "`", !0);
u(R, d, k, "‘", "\\textquoteleft");
u(R, d, k, "’", "'", !0);
u(R, d, k, "’", "\\textquoteright");
u(R, d, k, "“", "``", !0);
u(R, d, k, "“", "\\textquotedblleft");
u(R, d, k, "”", "''", !0);
u(R, d, k, "”", "\\textquotedblright");
u(c, d, k, "°", "\\degree", !0);
u(R, d, k, "°", "\\degree");
u(R, d, k, "°", "\\textdegree", !0);
u(c, d, k, "£", "\\pounds");
u(c, d, k, "£", "\\mathsterling", !0);
u(R, d, k, "£", "\\pounds");
u(R, d, k, "£", "\\textsterling", !0);
u(c, y, k, "✠", "\\maltese");
u(R, y, k, "✠", "\\maltese");
var $i = '0123456789/@."';
for (var Rr = 0; Rr < $i.length; Rr++) {
  var Di = $i.charAt(Rr);
  u(c, d, k, Di, Di);
}
var Ai = '0123456789!@*()-=+";:?/.,';
for (var Nr = 0; Nr < Ai.length; Nr++) {
  var Ci = Ai.charAt(Nr);
  u(R, d, k, Ci, Ci);
}
var cr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Lr = 0; Lr < cr.length; Lr++) {
  var Nn = cr.charAt(Lr);
  u(c, d, Q, Nn, Nn), u(R, d, k, Nn, Nn);
}
u(c, y, k, "C", "ℂ");
u(R, y, k, "C", "ℂ");
u(c, y, k, "H", "ℍ");
u(R, y, k, "H", "ℍ");
u(c, y, k, "N", "ℕ");
u(R, y, k, "N", "ℕ");
u(c, y, k, "P", "ℙ");
u(R, y, k, "P", "ℙ");
u(c, y, k, "Q", "ℚ");
u(R, y, k, "Q", "ℚ");
u(c, y, k, "R", "ℝ");
u(R, y, k, "R", "ℝ");
u(c, y, k, "Z", "ℤ");
u(R, y, k, "Z", "ℤ");
u(c, d, Q, "h", "ℎ");
u(R, d, Q, "h", "ℎ");
var ee = "";
for (var tt = 0; tt < cr.length; tt++) {
  var Be = cr.charAt(tt);
  ee = String.fromCharCode(55349, 56320 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56372 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56424 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56580 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56684 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56736 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56788 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56840 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56944 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), tt < 26 && (ee = String.fromCharCode(55349, 56632 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee), ee = String.fromCharCode(55349, 56476 + tt), u(c, d, Q, Be, ee), u(R, d, k, Be, ee));
}
ee = "𝕜";
u(c, d, Q, "k", ee);
u(R, d, k, "k", ee);
for (var R0 = 0; R0 < 10; R0++) {
  var D0 = R0.toString();
  ee = String.fromCharCode(55349, 57294 + R0), u(c, d, Q, D0, ee), u(R, d, k, D0, ee), ee = String.fromCharCode(55349, 57314 + R0), u(c, d, Q, D0, ee), u(R, d, k, D0, ee), ee = String.fromCharCode(55349, 57324 + R0), u(c, d, Q, D0, ee), u(R, d, k, D0, ee), ee = String.fromCharCode(55349, 57334 + R0), u(c, d, Q, D0, ee), u(R, d, k, D0, ee);
}
var ca = "ÐÞþ";
for (var Ir = 0; Ir < ca.length; Ir++) {
  var Ln = ca.charAt(Ir);
  u(c, d, Q, Ln, Ln), u(R, d, k, Ln, Ln);
}
var In = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], Ei = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], yu = function(e, t) {
  var n = e.charCodeAt(0), a = e.charCodeAt(1), i = (n - 55296) * 1024 + (a - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var s = Math.floor((i - 119808) / 26);
    return [In[s][2], In[s][l]];
  } else if (120782 <= i && i <= 120831) {
    var o = Math.floor((i - 120782) / 10);
    return [Ei[o][2], Ei[o][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [In[0][2], In[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new O("Unsupported character: " + e);
  }
}, xr = function(e, t, n) {
  return be[n][e] && be[n][e].replace && (e = be[n][e].replace), {
    value: e,
    metrics: Ta(e, t, n)
  };
}, Ut = function(e, t, n, a, i) {
  var l = xr(e, t, n), s = l.metrics;
  e = l.value;
  var o;
  if (s) {
    var h = s.italic;
    (n === "text" || a && a.font === "mathit") && (h = 0), o = new Mt(e, s.height, s.depth, h, s.skew, s.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + n + "'")), o = new Mt(e, 0, 0, 0, 0, 0, i);
  if (a) {
    o.maxFontSize = a.sizeMultiplier, a.style.isTight() && o.classes.push("mtight");
    var m = a.getColor();
    m && (o.style.color = m);
  }
  return o;
}, bu = function(e, t, n, a) {
  return a === void 0 && (a = []), n.font === "boldsymbol" && xr(e, "Main-Bold", t).metrics ? Ut(e, "Main-Bold", t, n, a.concat(["mathbf"])) : e === "\\" || be[t][e].font === "main" ? Ut(e, "Main-Regular", t, n, a) : Ut(e, "AMS-Regular", t, n, a.concat(["amsrm"]));
}, wu = function(e, t, n, a, i) {
  return i !== "textord" && xr(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, xu = function(e, t, n) {
  var a = e.mode, i = e.text, l = ["mord"], s = a === "math" || a === "text" && t.font, o = s ? t.font : t.fontFamily, h = "", m = "";
  if (i.charCodeAt(0) === 55349 && ([h, m] = yu(i, a)), h.length > 0)
    return Ut(i, h, a, t, l.concat(m));
  if (o) {
    var p, g;
    if (o === "boldsymbol") {
      var _ = wu(i, a, t, l, n);
      p = _.fontName, g = [_.fontClass];
    } else s ? (p = ws[o].fontName, g = [o]) : (p = On(o, t.fontWeight, t.fontShape), g = [o, t.fontWeight, t.fontShape]);
    if (xr(i, p, a).metrics)
      return Ut(i, p, a, t, l.concat(g));
    if (vs.hasOwnProperty(i) && p.slice(0, 10) === "Typewriter") {
      for (var C = [], T = 0; T < i.length; T++)
        C.push(Ut(i[T], p, a, t, l.concat(g)));
      return bs(C);
    }
  }
  if (n === "mathord")
    return Ut(i, "Math-Italic", a, t, l.concat(["mathnormal"]));
  if (n === "textord") {
    var F = be[a][i] && be[a][i].font;
    if (F === "ams") {
      var M = On("amsrm", t.fontWeight, t.fontShape);
      return Ut(i, M, a, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (F === "main" || !F) {
      var w = On("textrm", t.fontWeight, t.fontShape);
      return Ut(i, w, a, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var v = On(F, t.fontWeight, t.fontShape);
      return Ut(i, v, a, t, l.concat(v, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + n + " in makeOrd");
}, ku = (r, e) => {
  if (M0(r.classes) !== M0(e.classes) || r.skew !== e.skew || r.maxFontSize !== e.maxFontSize)
    return !1;
  if (r.classes.length === 1) {
    var t = r.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var n in r.style)
    if (r.style.hasOwnProperty(n) && r.style[n] !== e.style[n])
      return !1;
  for (var a in e.style)
    if (e.style.hasOwnProperty(a) && r.style[a] !== e.style[a])
      return !1;
  return !0;
}, Su = (r) => {
  for (var e = 0; e < r.length - 1; e++) {
    var t = r[e], n = r[e + 1];
    t instanceof Mt && n instanceof Mt && ku(t, n) && (t.text += n.text, t.height = Math.max(t.height, n.height), t.depth = Math.max(t.depth, n.depth), t.italic = n.italic, r.splice(e + 1, 1), e--);
  }
  return r;
}, za = function(e) {
  for (var t = 0, n = 0, a = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > n && (n = l.depth), l.maxFontSize > a && (a = l.maxFontSize);
  }
  e.height = t, e.depth = n, e.maxFontSize = a;
}, mt = function(e, t, n, a) {
  var i = new An(e, t, n, a);
  return za(i), i;
}, ys = (r, e, t, n) => new An(r, e, t, n), $u = function(e, t, n) {
  var a = mt([e], [], t);
  return a.height = Math.max(n || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), a.style.borderBottomWidth = G(a.height), a.maxFontSize = 1, a;
}, Du = function(e, t, n, a) {
  var i = new Ma(e, t, n, a);
  return za(i), i;
}, bs = function(e) {
  var t = new Dn(e);
  return za(t), t;
}, Au = function(e, t) {
  return e instanceof Dn ? mt([], [e], t) : e;
}, Cu = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, n = [t[0]], a = -t[0].shift - t[0].elem.depth, i = a, l = 1; l < t.length; l++) {
      var s = -t[l].shift - i - t[l].elem.depth, o = s - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + s, n.push({
        type: "kern",
        size: o
      }), n.push(t[l]);
    }
    return {
      children: n,
      depth: a
    };
  }
  var h;
  if (e.positionType === "top") {
    for (var m = e.positionData, p = 0; p < e.children.length; p++) {
      var g = e.children[p];
      m -= g.type === "kern" ? g.size : g.elem.height + g.elem.depth;
    }
    h = m;
  } else if (e.positionType === "bottom")
    h = -e.positionData;
  else {
    var _ = e.children[0];
    if (_.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      h = -_.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      h = -_.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: h
  };
}, Eu = function(e, t) {
  for (var {
    children: n,
    depth: a
  } = Cu(e), i = 0, l = 0; l < n.length; l++) {
    var s = n[l];
    if (s.type === "elem") {
      var o = s.elem;
      i = Math.max(i, o.maxFontSize, o.height);
    }
  }
  i += 2;
  var h = mt(["pstrut"], []);
  h.style.height = G(i);
  for (var m = [], p = a, g = a, _ = a, C = 0; C < n.length; C++) {
    var T = n[C];
    if (T.type === "kern")
      _ += T.size;
    else {
      var F = T.elem, M = T.wrapperClasses || [], w = T.wrapperStyle || {}, v = mt(M, [h, F], void 0, w);
      v.style.top = G(-i - _ - F.depth), T.marginLeft && (v.style.marginLeft = T.marginLeft), T.marginRight && (v.style.marginRight = T.marginRight), m.push(v), _ += F.height + F.depth;
    }
    p = Math.min(p, _), g = Math.max(g, _);
  }
  var x = mt(["vlist"], m);
  x.style.height = G(g);
  var $;
  if (p < 0) {
    var E = mt([], []), A = mt(["vlist"], [E]);
    A.style.height = G(-p);
    var q = mt(["vlist-s"], [new Mt("​")]);
    $ = [mt(["vlist-r"], [x, q]), mt(["vlist-r"], [A])];
  } else
    $ = [mt(["vlist-r"], [x])];
  var B = mt(["vlist-t"], $);
  return $.length === 2 && B.classes.push("vlist-t2"), B.height = g, B.depth = -p, B;
}, Fu = (r, e) => {
  var t = mt(["mspace"], [], e), n = Ee(r, e);
  return t.style.marginRight = G(n), t;
}, On = function(e, t, n) {
  var a = "";
  switch (e) {
    case "amsrm":
      a = "AMS";
      break;
    case "textrm":
      a = "Main";
      break;
    case "textsf":
      a = "SansSerif";
      break;
    case "texttt":
      a = "Typewriter";
      break;
    default:
      a = e;
  }
  var i;
  return t === "textbf" && n === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", a + "-" + i;
}, ws = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  mathsfit: {
    variant: "sans-serif-italic",
    fontName: "SansSerif-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, xs = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, Tu = function(e, t) {
  var [n, a, i] = xs[e], l = new z0(n), s = new w0([l], {
    width: G(a),
    height: G(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + G(a),
    viewBox: "0 0 " + 1e3 * a + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), o = ys(["overlay"], [s], t);
  return o.height = i, o.style.height = G(i), o.style.width = G(a), o;
}, D = {
  fontMap: ws,
  makeSymbol: Ut,
  mathsym: bu,
  makeSpan: mt,
  makeSvgSpan: ys,
  makeLineSpan: $u,
  makeAnchor: Du,
  makeFragment: bs,
  wrapFragment: Au,
  makeVList: Eu,
  makeOrd: xu,
  makeGlue: Fu,
  staticSvg: Tu,
  svgData: xs,
  tryCombineChars: Su
}, Ce = {
  number: 3,
  unit: "mu"
}, N0 = {
  number: 4,
  unit: "mu"
}, f0 = {
  number: 5,
  unit: "mu"
}, Mu = {
  mord: {
    mop: Ce,
    mbin: N0,
    mrel: f0,
    minner: Ce
  },
  mop: {
    mord: Ce,
    mop: Ce,
    mrel: f0,
    minner: Ce
  },
  mbin: {
    mord: N0,
    mop: N0,
    mopen: N0,
    minner: N0
  },
  mrel: {
    mord: f0,
    mop: f0,
    mopen: f0,
    minner: f0
  },
  mopen: {},
  mclose: {
    mop: Ce,
    mbin: N0,
    mrel: f0,
    minner: Ce
  },
  mpunct: {
    mord: Ce,
    mop: Ce,
    mrel: f0,
    mopen: Ce,
    mclose: Ce,
    mpunct: Ce,
    minner: Ce
  },
  minner: {
    mord: Ce,
    mop: Ce,
    mbin: N0,
    mrel: f0,
    mopen: Ce,
    mpunct: Ce,
    minner: Ce
  }
}, zu = {
  mord: {
    mop: Ce
  },
  mop: {
    mord: Ce,
    mop: Ce
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: Ce
  },
  mpunct: {},
  minner: {
    mop: Ce
  }
}, ks = {}, hr = {}, dr = {};
function V(r) {
  for (var {
    type: e,
    names: t,
    props: n,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, s = {
    type: e,
    numArgs: n.numArgs,
    argTypes: n.argTypes,
    allowedInArgument: !!n.allowedInArgument,
    allowedInText: !!n.allowedInText,
    allowedInMath: n.allowedInMath === void 0 ? !0 : n.allowedInMath,
    numOptionalArgs: n.numOptionalArgs || 0,
    infix: !!n.infix,
    primitive: !!n.primitive,
    handler: a
  }, o = 0; o < t.length; ++o)
    ks[t[o]] = s;
  e && (i && (hr[e] = i), l && (dr[e] = l));
}
function W0(r) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: n
  } = r;
  V({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: n
  });
}
var mr = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, Re = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, x0 = D.makeSpan, Bu = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], qu = ["rightmost", "mrel", "mclose", "mpunct"], Ru = {
  display: J.DISPLAY,
  text: J.TEXT,
  script: J.SCRIPT,
  scriptscript: J.SCRIPTSCRIPT
}, Nu = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, He = function(e, t, n, a) {
  a === void 0 && (a = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var s = oe(e[l], t);
    if (s instanceof Dn) {
      var o = s.children;
      i.push(...o);
    } else
      i.push(s);
  }
  if (D.tryCombineChars(i), !n)
    return i;
  var h = t;
  if (e.length === 1) {
    var m = e[0];
    m.type === "sizing" ? h = t.havingSize(m.size) : m.type === "styling" && (h = t.havingStyle(Ru[m.style]));
  }
  var p = x0([a[0] || "leftmost"], [], t), g = x0([a[1] || "rightmost"], [], t), _ = n === "root";
  return Fi(i, (C, T) => {
    var F = T.classes[0], M = C.classes[0];
    F === "mbin" && Z.contains(qu, M) ? T.classes[0] = "mord" : M === "mbin" && Z.contains(Bu, F) && (C.classes[0] = "mord");
  }, {
    node: p
  }, g, _), Fi(i, (C, T) => {
    var F = ha(T), M = ha(C), w = F && M ? C.hasClass("mtight") ? zu[F][M] : Mu[F][M] : null;
    if (w)
      return D.makeGlue(w, h);
  }, {
    node: p
  }, g, _), i;
}, Fi = function r(e, t, n, a, i) {
  a && e.push(a);
  for (var l = 0; l < e.length; l++) {
    var s = e[l], o = Ss(s);
    if (o) {
      r(o.children, t, n, null, i);
      continue;
    }
    var h = !s.hasClass("mspace");
    if (h) {
      var m = t(s, n.node);
      m && (n.insertAfter ? n.insertAfter(m) : (e.unshift(m), l++));
    }
    h ? n.node = s : i && s.hasClass("newline") && (n.node = x0(["leftmost"])), n.insertAfter = /* @__PURE__ */ ((p) => (g) => {
      e.splice(p + 1, 0, g), l++;
    })(l);
  }
  a && e.pop();
}, Ss = function(e) {
  return e instanceof Dn || e instanceof Ma || e instanceof An && e.hasClass("enclosing") ? e : null;
}, Lu = function r(e, t) {
  var n = Ss(e);
  if (n) {
    var a = n.children;
    if (a.length) {
      if (t === "right")
        return r(a[a.length - 1], "right");
      if (t === "left")
        return r(a[0], "left");
    }
  }
  return e;
}, ha = function(e, t) {
  return e ? (t && (e = Lu(e, t)), Nu[e.classes[0]] || null) : null;
}, $n = function(e, t) {
  var n = ["nulldelimiter"].concat(e.baseSizingClasses());
  return x0(t.concat(n));
}, oe = function(e, t, n) {
  if (!e)
    return x0();
  if (hr[e.type]) {
    var a = hr[e.type](e, t);
    if (n && t.size !== n.size) {
      a = x0(t.sizingClasses(n), [a], t);
      var i = t.sizeMultiplier / n.sizeMultiplier;
      a.height *= i, a.depth *= i;
    }
    return a;
  } else
    throw new O("Got group of unknown type: '" + e.type + "'");
};
function Pn(r, e) {
  var t = x0(["base"], r, e), n = x0(["strut"]);
  return n.style.height = G(t.height + t.depth), t.depth && (n.style.verticalAlign = G(-t.depth)), t.children.unshift(n), t;
}
function da(r, e) {
  var t = null;
  r.length === 1 && r[0].type === "tag" && (t = r[0].tag, r = r[0].body);
  var n = He(r, e, "root"), a;
  n.length === 2 && n[1].hasClass("tag") && (a = n.pop());
  for (var i = [], l = [], s = 0; s < n.length; s++)
    if (l.push(n[s]), n[s].hasClass("mbin") || n[s].hasClass("mrel") || n[s].hasClass("allowbreak")) {
      for (var o = !1; s < n.length - 1 && n[s + 1].hasClass("mspace") && !n[s + 1].hasClass("newline"); )
        s++, l.push(n[s]), n[s].hasClass("nobreak") && (o = !0);
      o || (i.push(Pn(l, e)), l = []);
    } else n[s].hasClass("newline") && (l.pop(), l.length > 0 && (i.push(Pn(l, e)), l = []), i.push(n[s]));
  l.length > 0 && i.push(Pn(l, e));
  var h;
  t ? (h = Pn(He(t, e, !0)), h.classes = ["tag"], i.push(h)) : a && i.push(a);
  var m = x0(["katex-html"], i);
  if (m.setAttribute("aria-hidden", "true"), h) {
    var p = h.children[0];
    p.style.height = G(m.height + m.depth), m.depth && (p.style.verticalAlign = G(-m.depth));
  }
  return m;
}
function $s(r) {
  return new Dn(r);
}
class yt {
  constructor(e, t, n) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = n || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = M0(this.classes));
    for (var n = 0; n < this.children.length; n++)
      if (this.children[n] instanceof Jt && this.children[n + 1] instanceof Jt) {
        for (var a = this.children[n].toText() + this.children[++n].toText(); this.children[n + 1] instanceof Jt; )
          a += this.children[++n].toText();
        e.appendChild(new Jt(a).toNode());
      } else
        e.appendChild(this.children[n].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += Z.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + Z.escape(M0(this.classes)) + '"'), e += ">";
    for (var n = 0; n < this.children.length; n++)
      e += this.children[n].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class Jt {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return Z.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class Iu {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", G(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + G(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var I = {
  MathNode: yt,
  TextNode: Jt,
  SpaceNode: Iu,
  newDocumentFragment: $s
}, zt = function(e, t, n) {
  return be[t][e] && be[t][e].replace && e.charCodeAt(0) !== 55349 && !(vs.hasOwnProperty(e) && n && (n.fontFamily && n.fontFamily.slice(4, 6) === "tt" || n.font && n.font.slice(4, 6) === "tt")) && (e = be[t][e].replace), new I.TextNode(e);
}, Ba = function(e) {
  return e.length === 1 ? e[0] : new I.MathNode("mrow", e);
}, qa = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var n = t.font;
  if (!n || n === "mathnormal")
    return null;
  var a = e.mode;
  if (n === "mathit")
    return "italic";
  if (n === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (n === "mathbf")
    return "bold";
  if (n === "mathbb")
    return "double-struck";
  if (n === "mathsfit")
    return "sans-serif-italic";
  if (n === "mathfrak")
    return "fraktur";
  if (n === "mathscr" || n === "mathcal")
    return "script";
  if (n === "mathsf")
    return "sans-serif";
  if (n === "mathtt")
    return "monospace";
  var i = e.text;
  if (Z.contains(["\\imath", "\\jmath"], i))
    return null;
  be[a][i] && be[a][i].replace && (i = be[a][i].replace);
  var l = D.fontMap[n].fontName;
  return Ta(i, l, a) ? D.fontMap[n].variant : null;
};
function Or(r) {
  if (!r)
    return !1;
  if (r.type === "mi" && r.children.length === 1) {
    var e = r.children[0];
    return e instanceof Jt && e.text === ".";
  } else if (r.type === "mo" && r.children.length === 1 && r.getAttribute("separator") === "true" && r.getAttribute("lspace") === "0em" && r.getAttribute("rspace") === "0em") {
    var t = r.children[0];
    return t instanceof Jt && t.text === ",";
  } else
    return !1;
}
var ft = function(e, t, n) {
  if (e.length === 1) {
    var a = ye(e[0], t);
    return n && a instanceof yt && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
  }
  for (var i = [], l, s = 0; s < e.length; s++) {
    var o = ye(e[s], t);
    if (o instanceof yt && l instanceof yt) {
      if (o.type === "mtext" && l.type === "mtext" && o.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...o.children);
        continue;
      } else if (o.type === "mn" && l.type === "mn") {
        l.children.push(...o.children);
        continue;
      } else if (Or(o) && l.type === "mn") {
        l.children.push(...o.children);
        continue;
      } else if (o.type === "mn" && Or(l))
        o.children = [...l.children, ...o.children], i.pop();
      else if ((o.type === "msup" || o.type === "msub") && o.children.length >= 1 && (l.type === "mn" || Or(l))) {
        var h = o.children[0];
        h instanceof yt && h.type === "mn" && (h.children = [...l.children, ...h.children], i.pop());
      } else if (l.type === "mi" && l.children.length === 1) {
        var m = l.children[0];
        if (m instanceof Jt && m.text === "̸" && (o.type === "mo" || o.type === "mi" || o.type === "mn")) {
          var p = o.children[0];
          p instanceof Jt && p.text.length > 0 && (p.text = p.text.slice(0, 1) + "̸" + p.text.slice(1), i.pop());
        }
      }
    }
    i.push(o), l = o;
  }
  return i;
}, B0 = function(e, t, n) {
  return Ba(ft(e, t, n));
}, ye = function(e, t) {
  if (!e)
    return new I.MathNode("mrow");
  if (dr[e.type]) {
    var n = dr[e.type](e, t);
    return n;
  } else
    throw new O("Got group of unknown type: '" + e.type + "'");
};
function Ti(r, e, t, n, a) {
  var i = ft(r, t), l;
  i.length === 1 && i[0] instanceof yt && Z.contains(["mrow", "mtable"], i[0].type) ? l = i[0] : l = new I.MathNode("mrow", i);
  var s = new I.MathNode("annotation", [new I.TextNode(e)]);
  s.setAttribute("encoding", "application/x-tex");
  var o = new I.MathNode("semantics", [l, s]), h = new I.MathNode("math", [o]);
  h.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), n && h.setAttribute("display", "block");
  var m = a ? "katex" : "katex-mathml";
  return D.makeSpan([m], [h]);
}
var Ds = function(e) {
  return new _0({
    style: e.displayMode ? J.DISPLAY : J.TEXT,
    maxSize: e.maxSize,
    minRuleThickness: e.minRuleThickness
  });
}, As = function(e, t) {
  if (t.displayMode) {
    var n = ["katex-display"];
    t.leqno && n.push("leqno"), t.fleqn && n.push("fleqn"), e = D.makeSpan(n, [e]);
  }
  return e;
}, Ou = function(e, t, n) {
  var a = Ds(n), i;
  if (n.output === "mathml")
    return Ti(e, t, a, n.displayMode, !0);
  if (n.output === "html") {
    var l = da(e, a);
    i = D.makeSpan(["katex"], [l]);
  } else {
    var s = Ti(e, t, a, n.displayMode, !1), o = da(e, a);
    i = D.makeSpan(["katex"], [s, o]);
  }
  return As(i, n);
}, Pu = function(e, t, n) {
  var a = Ds(n), i = da(e, a), l = D.makeSpan(["katex"], [i]);
  return As(l, n);
}, Hu = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, Uu = function(e) {
  var t = new I.MathNode("mo", [new I.TextNode(Hu[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, Gu = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, Vu = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, Wu = function(e, t) {
  function n() {
    var s = 4e5, o = e.label.slice(1);
    if (Z.contains(["widehat", "widecheck", "widetilde", "utilde"], o)) {
      var h = e, m = Vu(h.base), p, g, _;
      if (m > 5)
        o === "widehat" || o === "widecheck" ? (p = 420, s = 2364, _ = 0.42, g = o + "4") : (p = 312, s = 2340, _ = 0.34, g = "tilde4");
      else {
        var C = [1, 1, 2, 2, 3, 3][m];
        o === "widehat" || o === "widecheck" ? (s = [0, 1062, 2364, 2364, 2364][C], p = [0, 239, 300, 360, 420][C], _ = [0, 0.24, 0.3, 0.3, 0.36, 0.42][C], g = o + C) : (s = [0, 600, 1033, 2339, 2340][C], p = [0, 260, 286, 306, 312][C], _ = [0, 0.26, 0.286, 0.3, 0.306, 0.34][C], g = "tilde" + C);
      }
      var T = new z0(g), F = new w0([T], {
        width: "100%",
        height: G(_),
        viewBox: "0 0 " + s + " " + p,
        preserveAspectRatio: "none"
      });
      return {
        span: D.makeSvgSpan([], [F], t),
        minWidth: 0,
        height: _
      };
    } else {
      var M = [], w = Gu[o], [v, x, $] = w, E = $ / 1e3, A = v.length, q, B;
      if (A === 1) {
        var z = w[3];
        q = ["hide-tail"], B = [z];
      } else if (A === 2)
        q = ["halfarrow-left", "halfarrow-right"], B = ["xMinYMin", "xMaxYMin"];
      else if (A === 3)
        q = ["brace-left", "brace-center", "brace-right"], B = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + A + " children.");
      for (var U = 0; U < A; U++) {
        var N = new z0(v[U]), K = new w0([N], {
          width: "400em",
          height: G(E),
          viewBox: "0 0 " + s + " " + $,
          preserveAspectRatio: B[U] + " slice"
        }), ie = D.makeSvgSpan([q[U]], [K], t);
        if (A === 1)
          return {
            span: ie,
            minWidth: x,
            height: E
          };
        ie.style.height = G(E), M.push(ie);
      }
      return {
        span: D.makeSpan(["stretchy"], M, t),
        minWidth: x,
        height: E
      };
    }
  }
  var {
    span: a,
    minWidth: i,
    height: l
  } = n();
  return a.height = l, a.style.height = G(l), i > 0 && (a.style.minWidth = G(i)), a;
}, ju = function(e, t, n, a, i) {
  var l, s = e.height + e.depth + n + a;
  if (/fbox|color|angl/.test(t)) {
    if (l = D.makeSpan(["stretchy", t], [], i), t === "fbox") {
      var o = i.color && i.getColor();
      o && (l.style.borderColor = o);
    }
  } else {
    var h = [];
    /^[bx]cancel$/.test(t) && h.push(new ua({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && h.push(new ua({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var m = new w0(h, {
      width: "100%",
      height: G(s)
    });
    l = D.makeSvgSpan([], [m], i);
  }
  return l.height = s, l.style.height = G(s), l;
}, k0 = {
  encloseSpan: ju,
  mathMLnode: Uu,
  svgSpan: Wu
};
function ae(r, e) {
  if (!r || r.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (r ? "node of type " + r.type : String(r)));
  return r;
}
function Ra(r) {
  var e = kr(r);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (r ? "node of type " + r.type : String(r)));
  return e;
}
function kr(r) {
  return r && (r.type === "atom" || vu.hasOwnProperty(r.type)) ? r : null;
}
var Na = (r, e) => {
  var t, n, a;
  r && r.type === "supsub" ? (n = ae(r.base, "accent"), t = n.base, r.base = t, a = gu(oe(r, e)), r.base = n) : (n = ae(r, "accent"), t = n.base);
  var i = oe(t, e.havingCrampedStyle()), l = n.isShifty && Z.isCharacterBox(t), s = 0;
  if (l) {
    var o = Z.getBaseElem(t), h = oe(o, e.havingCrampedStyle());
    s = Si(h).skew;
  }
  var m = n.label === "\\c", p = m ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), g;
  if (n.isStretchy)
    g = k0.svgSpan(n, e), g = D.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: g,
        wrapperClasses: ["svg-align"],
        wrapperStyle: s > 0 ? {
          width: "calc(100% - " + G(2 * s) + ")",
          marginLeft: G(2 * s)
        } : void 0
      }]
    }, e);
  else {
    var _, C;
    n.label === "\\vec" ? (_ = D.staticSvg("vec", e), C = D.svgData.vec[1]) : (_ = D.makeOrd({
      mode: n.mode,
      text: n.label
    }, e, "textord"), _ = Si(_), _.italic = 0, C = _.width, m && (p += _.depth)), g = D.makeSpan(["accent-body"], [_]);
    var T = n.label === "\\textcircled";
    T && (g.classes.push("accent-full"), p = i.height);
    var F = s;
    T || (F -= C / 2), g.style.left = G(F), n.label === "\\textcircled" && (g.style.top = ".2em"), g = D.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -p
      }, {
        type: "elem",
        elem: g
      }]
    }, e);
  }
  var M = D.makeSpan(["mord", "accent"], [g], e);
  return a ? (a.children[0] = M, a.height = Math.max(M.height, a.height), a.classes[0] = "mord", a) : M;
}, Cs = (r, e) => {
  var t = r.isStretchy ? k0.mathMLnode(r.label) : new I.MathNode("mo", [zt(r.label, r.mode)]), n = new I.MathNode("mover", [ye(r.base, e), t]);
  return n.setAttribute("accent", "true"), n;
}, Xu = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((r) => "\\" + r).join("|"));
V({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var t = mr(e[0]), n = !Xu.test(r.funcName), a = !n || r.funcName === "\\widehat" || r.funcName === "\\widetilde" || r.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: r.parser.mode,
      label: r.funcName,
      isStretchy: n,
      isShifty: a,
      base: t
    };
  },
  htmlBuilder: Na,
  mathmlBuilder: Cs
});
V({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = e[0], n = r.parser.mode;
    return n === "math" && (r.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + r.funcName + " works only in text mode"), n = "text"), {
      type: "accent",
      mode: n,
      label: r.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: Na,
  mathmlBuilder: Cs
});
V({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: n,
      base: a
    };
  },
  htmlBuilder: (r, e) => {
    var t = oe(r.base, e), n = k0.svgSpan(r, e), a = r.label === "\\utilde" ? 0.12 : 0, i = D.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: n,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return D.makeSpan(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = k0.mathMLnode(r.label), n = new I.MathNode("munder", [ye(r.base, e), t]);
    return n.setAttribute("accentunder", "true"), n;
  }
});
var Hn = (r) => {
  var e = new I.MathNode("mpadded", r ? [r] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
V({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: n,
      funcName: a
    } = r;
    return {
      type: "xArrow",
      mode: n.mode,
      label: a,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(r, e) {
    var t = e.style, n = e.havingStyle(t.sup()), a = D.wrapFragment(oe(r.body, n, e), e), i = r.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(i + "-arrow-pad");
    var l;
    r.below && (n = e.havingStyle(t.sub()), l = D.wrapFragment(oe(r.below, n, e), e), l.classes.push(i + "-arrow-pad"));
    var s = k0.svgSpan(r, e), o = -e.fontMetrics().axisHeight + 0.5 * s.height, h = -e.fontMetrics().axisHeight - 0.5 * s.height - 0.111;
    (a.depth > 0.25 || r.label === "\\xleftequilibrium") && (h -= a.depth);
    var m;
    if (l) {
      var p = -e.fontMetrics().axisHeight + l.height + 0.5 * s.height + 0.111;
      m = D.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: h
        }, {
          type: "elem",
          elem: s,
          shift: o
        }, {
          type: "elem",
          elem: l,
          shift: p
        }]
      }, e);
    } else
      m = D.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: h
        }, {
          type: "elem",
          elem: s,
          shift: o
        }]
      }, e);
    return m.children[0].children[0].children[1].classes.push("svg-align"), D.makeSpan(["mrel", "x-arrow"], [m], e);
  },
  mathmlBuilder(r, e) {
    var t = k0.mathMLnode(r.label);
    t.setAttribute("minsize", r.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var n;
    if (r.body) {
      var a = Hn(ye(r.body, e));
      if (r.below) {
        var i = Hn(ye(r.below, e));
        n = new I.MathNode("munderover", [t, i, a]);
      } else
        n = new I.MathNode("mover", [t, a]);
    } else if (r.below) {
      var l = Hn(ye(r.below, e));
      n = new I.MathNode("munder", [t, l]);
    } else
      n = Hn(), n = new I.MathNode("mover", [t, n]);
    return n;
  }
});
var Yu = D.makeSpan;
function Es(r, e) {
  var t = He(r.body, e, !0);
  return Yu([r.mclass], t, e);
}
function Fs(r, e) {
  var t, n = ft(r.body, e);
  return r.mclass === "minner" ? t = new I.MathNode("mpadded", n) : r.mclass === "mord" ? r.isCharacterBox ? (t = n[0], t.type = "mi") : t = new I.MathNode("mi", n) : (r.isCharacterBox ? (t = n[0], t.type = "mo") : t = new I.MathNode("mo", n), r.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : r.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : r.mclass === "mopen" || r.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : r.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
V({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + n.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: Re(a),
      isCharacterBox: Z.isCharacterBox(a)
    };
  },
  htmlBuilder: Es,
  mathmlBuilder: Fs
});
var Sr = (r) => {
  var e = r.type === "ordgroup" && r.body.length ? r.body[0] : r;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
V({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Sr(e[0]),
      body: Re(e[1]),
      isCharacterBox: Z.isCharacterBox(e[1])
    };
  }
});
V({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[1], i = e[0], l;
    n !== "\\stackrel" ? l = Sr(a) : l = "mrel";
    var s = {
      type: "op",
      mode: a.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: n !== "\\stackrel",
      body: Re(a)
    }, o = {
      type: "supsub",
      mode: i.mode,
      base: s,
      sup: n === "\\underset" ? null : i,
      sub: n === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [o],
      isCharacterBox: Z.isCharacterBox(o)
    };
  },
  htmlBuilder: Es,
  mathmlBuilder: Fs
});
V({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: Sr(e[0]),
      body: Re(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = He(r.body, e, !0), n = D.makeSpan([r.mclass], t, e);
    return n.style.textShadow = "0.02em 0.01em 0.04px", n;
  },
  mathmlBuilder(r, e) {
    var t = ft(r.body, e), n = new I.MathNode("mstyle", t);
    return n.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), n;
  }
});
var Zu = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, Mi = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), zi = (r) => r.type === "textord" && r.text === "@", Ku = (r, e) => (r.type === "mathord" || r.type === "atom") && r.text === e;
function Qu(r, e, t) {
  var n = Zu[r];
  switch (n) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(n, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var a = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: n,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), s = t.callFunction("\\\\cdright", [e[1]], []), o = {
        type: "ordgroup",
        mode: "math",
        body: [a, l, s]
      };
      return t.callFunction("\\\\cdparent", [o], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var h = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [h], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function Ju(r) {
  var e = [];
  for (r.gullet.beginGroup(), r.gullet.macros.set("\\cr", "\\\\\\relax"), r.gullet.beginGroup(); ; ) {
    e.push(r.parseExpression(!1, "\\\\")), r.gullet.endGroup(), r.gullet.beginGroup();
    var t = r.fetch().text;
    if (t === "&" || t === "\\\\")
      r.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new O("Expected \\\\ or \\cr or \\end", r.nextToken);
  }
  for (var n = [], a = [n], i = 0; i < e.length; i++) {
    for (var l = e[i], s = Mi(), o = 0; o < l.length; o++)
      if (!zi(l[o]))
        s.body.push(l[o]);
      else {
        n.push(s), o += 1;
        var h = Ra(l[o]).text, m = new Array(2);
        if (m[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, m[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(h) > -1)) if ("<>AV".indexOf(h) > -1)
          for (var p = 0; p < 2; p++) {
            for (var g = !0, _ = o + 1; _ < l.length; _++) {
              if (Ku(l[_], h)) {
                g = !1, o = _;
                break;
              }
              if (zi(l[_]))
                throw new O("Missing a " + h + " character to complete a CD arrow.", l[_]);
              m[p].body.push(l[_]);
            }
            if (g)
              throw new O("Missing a " + h + " character to complete a CD arrow.", l[o]);
          }
        else
          throw new O('Expected one of "<>AV=|." after @', l[o]);
        var C = Qu(h, m, r), T = {
          type: "styling",
          body: [C],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        n.push(T), s = Mi();
      }
    i % 2 === 0 ? n.push(s) : n.shift(), n = [], a.push(n);
  }
  r.gullet.endGroup(), r.gullet.endGroup();
  var F = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: F,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
V({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: n.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = e.havingStyle(e.style.sup()), n = D.wrapFragment(oe(r.label, t, e), e);
    return n.classes.push("cd-label-" + r.side), n.style.bottom = G(0.8 - n.depth), n.height = 0, n.depth = 0, n;
  },
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mrow", [ye(r.label, e)]);
    return t = new I.MathNode("mpadded", [t]), t.setAttribute("width", "0"), r.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new I.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
V({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = D.wrapFragment(oe(r.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(r, e) {
    return new I.MathNode("mrow", [ye(r.fragment, e)]);
  }
});
V({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    for (var {
      parser: t
    } = r, n = ae(e[0], "ordgroup"), a = n.body, i = "", l = 0; l < a.length; l++) {
      var s = ae(a[l], "textord");
      i += s.text;
    }
    var o = parseInt(i), h;
    if (isNaN(o))
      throw new O("\\@char has non-numeric argument " + i);
    if (o < 0 || o >= 1114111)
      throw new O("\\@char with invalid code point " + i);
    return o <= 65535 ? h = String.fromCharCode(o) : (o -= 65536, h = String.fromCharCode((o >> 10) + 55296, (o & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: h
    };
  }
});
var Ts = (r, e) => {
  var t = He(r.body, e.withColor(r.color), !1);
  return D.makeFragment(t);
}, Ms = (r, e) => {
  var t = ft(r.body, e.withColor(r.color)), n = new I.MathNode("mstyle", t);
  return n.setAttribute("mathcolor", r.color), n;
};
V({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = ae(e[0], "color-token").color, a = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: n,
      body: Re(a)
    };
  },
  htmlBuilder: Ts,
  mathmlBuilder: Ms
});
V({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(r, e) {
    var {
      parser: t,
      breakOnTokenText: n
    } = r, a = ae(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", a);
    var i = t.parseExpression(!0, n);
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: i
    };
  },
  htmlBuilder: Ts,
  mathmlBuilder: Ms
});
V({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    var {
      parser: n
    } = r, a = n.gullet.future().text === "[" ? n.parseSizeGroup(!0) : null, i = !n.settings.displayMode || !n.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: n.mode,
      newLine: i,
      size: a && ae(a, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(r, e) {
    var t = D.makeSpan(["mspace"], [], e);
    return r.newLine && (t.classes.push("newline"), r.size && (t.style.marginTop = G(Ee(r.size, e)))), t;
  },
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mspace");
    return r.newLine && (t.setAttribute("linebreak", "newline"), r.size && t.setAttribute("height", G(Ee(r.size, e)))), t;
  }
});
var ma = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, zs = (r) => {
  var e = r.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new O("Expected a control sequence", r);
  return e;
}, ec = (r) => {
  var e = r.gullet.popToken();
  return e.text === "=" && (e = r.gullet.popToken(), e.text === " " && (e = r.gullet.popToken())), e;
}, Bs = (r, e, t, n) => {
  var a = r.gullet.macros.get(t.text);
  a == null && (t.noexpand = !0, a = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !r.gullet.isExpandable(t.text)
  }), r.gullet.macros.set(e, a, n);
};
V({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    e.consumeSpaces();
    var n = e.fetch();
    if (ma[n.text])
      return (t === "\\global" || t === "\\\\globallong") && (n.text = ma[n.text]), ae(e.parseFunction(), "internal");
    throw new O("Invalid token after macro prefix", n);
  }
});
V({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = e.gullet.popToken(), a = n.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a))
      throw new O("Expected a control sequence", n);
    for (var i = 0, l, s = [[]]; e.gullet.future().text !== "{"; )
      if (n = e.gullet.popToken(), n.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), s[i].push("{");
          break;
        }
        if (n = e.gullet.popToken(), !/^[1-9]$/.test(n.text))
          throw new O('Invalid argument number "' + n.text + '"');
        if (parseInt(n.text) !== i + 1)
          throw new O('Argument number "' + n.text + '" out of order');
        i++, s.push([]);
      } else {
        if (n.text === "EOF")
          throw new O("Expected a macro definition");
        s[i].push(n.text);
      }
    var {
      tokens: o
    } = e.gullet.consumeArg();
    return l && o.unshift(l), (t === "\\edef" || t === "\\xdef") && (o = e.gullet.expandTokens(o), o.reverse()), e.gullet.macros.set(a, {
      tokens: o,
      numArgs: i,
      delimiters: s
    }, t === ma[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
V({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = zs(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var a = ec(e);
    return Bs(e, n, a, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
V({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = zs(e.gullet.popToken()), a = e.gullet.popToken(), i = e.gullet.popToken();
    return Bs(e, n, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(a), {
      type: "internal",
      mode: e.mode
    };
  }
});
var _n = function(e, t, n) {
  var a = be.math[e] && be.math[e].replace, i = Ta(a || e, t, n);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, La = function(e, t, n, a) {
  var i = n.havingBaseStyle(t), l = D.makeSpan(a.concat(i.sizingClasses(n)), [e], n), s = i.sizeMultiplier / n.sizeMultiplier;
  return l.height *= s, l.depth *= s, l.maxFontSize = i.sizeMultiplier, l;
}, qs = function(e, t, n) {
  var a = t.havingBaseStyle(n), i = (1 - t.sizeMultiplier / a.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = G(i), e.height -= i, e.depth += i;
}, tc = function(e, t, n, a, i, l) {
  var s = D.makeSymbol(e, "Main-Regular", i, a), o = La(s, t, a, l);
  return n && qs(o, a, t), o;
}, nc = function(e, t, n, a) {
  return D.makeSymbol(e, "Size" + t + "-Regular", n, a);
}, Rs = function(e, t, n, a, i, l) {
  var s = nc(e, t, i, a), o = La(D.makeSpan(["delimsizing", "size" + t], [s], a), J.TEXT, a, l);
  return n && qs(o, a, J.TEXT), o;
}, Pr = function(e, t, n) {
  var a;
  t === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
  var i = D.makeSpan(["delimsizinginner", a], [D.makeSpan([], [D.makeSymbol(e, t, n)])]);
  return {
    type: "elem",
    elem: i
  };
}, Hr = function(e, t, n) {
  var a = Qt["Size4-Regular"][e.charCodeAt(0)] ? Qt["Size4-Regular"][e.charCodeAt(0)][4] : Qt["Size1-Regular"][e.charCodeAt(0)][4], i = new z0("inner", su(e, Math.round(1e3 * t))), l = new w0([i], {
    width: G(a),
    height: G(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + G(a),
    viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), s = D.makeSvgSpan([], [l], n);
  return s.height = t, s.style.height = G(t), s.style.width = G(a), {
    type: "elem",
    elem: s
  };
}, fa = 8e-3, Un = {
  type: "kern",
  size: -1 * fa
}, rc = ["|", "\\lvert", "\\rvert", "\\vert"], ac = ["\\|", "\\lVert", "\\rVert", "\\Vert"], Ns = function(e, t, n, a, i, l) {
  var s, o, h, m, p = "", g = 0;
  s = h = m = e, o = null;
  var _ = "Size1-Regular";
  e === "\\uparrow" ? h = m = "⏐" : e === "\\Uparrow" ? h = m = "‖" : e === "\\downarrow" ? s = h = "⏐" : e === "\\Downarrow" ? s = h = "‖" : e === "\\updownarrow" ? (s = "\\uparrow", h = "⏐", m = "\\downarrow") : e === "\\Updownarrow" ? (s = "\\Uparrow", h = "‖", m = "\\Downarrow") : Z.contains(rc, e) ? (h = "∣", p = "vert", g = 333) : Z.contains(ac, e) ? (h = "∥", p = "doublevert", g = 556) : e === "[" || e === "\\lbrack" ? (s = "⎡", h = "⎢", m = "⎣", _ = "Size4-Regular", p = "lbrack", g = 667) : e === "]" || e === "\\rbrack" ? (s = "⎤", h = "⎥", m = "⎦", _ = "Size4-Regular", p = "rbrack", g = 667) : e === "\\lfloor" || e === "⌊" ? (h = s = "⎢", m = "⎣", _ = "Size4-Regular", p = "lfloor", g = 667) : e === "\\lceil" || e === "⌈" ? (s = "⎡", h = m = "⎢", _ = "Size4-Regular", p = "lceil", g = 667) : e === "\\rfloor" || e === "⌋" ? (h = s = "⎥", m = "⎦", _ = "Size4-Regular", p = "rfloor", g = 667) : e === "\\rceil" || e === "⌉" ? (s = "⎤", h = m = "⎥", _ = "Size4-Regular", p = "rceil", g = 667) : e === "(" || e === "\\lparen" ? (s = "⎛", h = "⎜", m = "⎝", _ = "Size4-Regular", p = "lparen", g = 875) : e === ")" || e === "\\rparen" ? (s = "⎞", h = "⎟", m = "⎠", _ = "Size4-Regular", p = "rparen", g = 875) : e === "\\{" || e === "\\lbrace" ? (s = "⎧", o = "⎨", m = "⎩", h = "⎪", _ = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (s = "⎫", o = "⎬", m = "⎭", h = "⎪", _ = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (s = "⎧", m = "⎩", h = "⎪", _ = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (s = "⎫", m = "⎭", h = "⎪", _ = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (s = "⎧", m = "⎭", h = "⎪", _ = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (s = "⎫", m = "⎩", h = "⎪", _ = "Size4-Regular");
  var C = _n(s, _, i), T = C.height + C.depth, F = _n(h, _, i), M = F.height + F.depth, w = _n(m, _, i), v = w.height + w.depth, x = 0, $ = 1;
  if (o !== null) {
    var E = _n(o, _, i);
    x = E.height + E.depth, $ = 2;
  }
  var A = T + v + x, q = Math.max(0, Math.ceil((t - A) / ($ * M))), B = A + q * $ * M, z = a.fontMetrics().axisHeight;
  n && (z *= a.sizeMultiplier);
  var U = B / 2 - z, N = [];
  if (p.length > 0) {
    var K = B - T - v, ie = Math.round(B * 1e3), we = ou(p, Math.round(K * 1e3)), _e = new z0(p, we), Ue = (g / 1e3).toFixed(3) + "em", ue = (ie / 1e3).toFixed(3) + "em", Me = new w0([_e], {
      width: Ue,
      height: ue,
      viewBox: "0 0 " + g + " " + ie
    }), De = D.makeSvgSpan([], [Me], a);
    De.height = ie / 1e3, De.style.width = Ue, De.style.height = ue, N.push({
      type: "elem",
      elem: De
    });
  } else {
    if (N.push(Pr(m, _, i)), N.push(Un), o === null) {
      var re = B - T - v + 2 * fa;
      N.push(Hr(h, re, a));
    } else {
      var ce = (B - T - v - x) / 2 + 2 * fa;
      N.push(Hr(h, ce, a)), N.push(Un), N.push(Pr(o, _, i)), N.push(Un), N.push(Hr(h, ce, a));
    }
    N.push(Un), N.push(Pr(s, _, i));
  }
  var he = a.havingBaseStyle(J.TEXT), Le = D.makeVList({
    positionType: "bottom",
    positionData: U,
    children: N
  }, he);
  return La(D.makeSpan(["delimsizing", "mult"], [Le], he), J.TEXT, a, l);
}, Ur = 80, Gr = 0.08, Vr = function(e, t, n, a, i) {
  var l = lu(e, a, n), s = new z0(e, l), o = new w0([s], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: G(t),
    viewBox: "0 0 400000 " + n,
    preserveAspectRatio: "xMinYMin slice"
  });
  return D.makeSvgSpan(["hide-tail"], [o], i);
}, ic = function(e, t) {
  var n = t.havingBaseSizing(), a = Ps("\\surd", e * n.sizeMultiplier, Os, n), i = n.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), s, o = 0, h = 0, m = 0, p;
  return a.type === "small" ? (m = 1e3 + 1e3 * l + Ur, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), o = (1 + l + Gr) / i, h = (1 + l) / i, s = Vr("sqrtMain", o, m, l, t), s.style.minWidth = "0.853em", p = 0.833 / i) : a.type === "large" ? (m = (1e3 + Ur) * yn[a.size], h = (yn[a.size] + l) / i, o = (yn[a.size] + l + Gr) / i, s = Vr("sqrtSize" + a.size, o, m, l, t), s.style.minWidth = "1.02em", p = 1 / i) : (o = e + l + Gr, h = e + l, m = Math.floor(1e3 * e + l) + Ur, s = Vr("sqrtTall", o, m, l, t), s.style.minWidth = "0.742em", p = 1.056), s.height = h, s.style.height = G(o), {
    span: s,
    advanceWidth: p,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, Ls = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], lc = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], Is = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], yn = [0, 1.2, 1.8, 2.4, 3], sc = function(e, t, n, a, i) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), Z.contains(Ls, e) || Z.contains(Is, e))
    return Rs(e, t, !1, n, a, i);
  if (Z.contains(lc, e))
    return Ns(e, yn[t], !1, n, a, i);
  throw new O("Illegal delimiter: '" + e + "'");
}, oc = [{
  type: "small",
  style: J.SCRIPTSCRIPT
}, {
  type: "small",
  style: J.SCRIPT
}, {
  type: "small",
  style: J.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], uc = [{
  type: "small",
  style: J.SCRIPTSCRIPT
}, {
  type: "small",
  style: J.SCRIPT
}, {
  type: "small",
  style: J.TEXT
}, {
  type: "stack"
}], Os = [{
  type: "small",
  style: J.SCRIPTSCRIPT
}, {
  type: "small",
  style: J.SCRIPT
}, {
  type: "small",
  style: J.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], cc = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, Ps = function(e, t, n, a) {
  for (var i = Math.min(2, 3 - a.style.size), l = i; l < n.length && n[l].type !== "stack"; l++) {
    var s = _n(e, cc(n[l]), "math"), o = s.height + s.depth;
    if (n[l].type === "small") {
      var h = a.havingBaseStyle(n[l].style);
      o *= h.sizeMultiplier;
    }
    if (o > t)
      return n[l];
  }
  return n[n.length - 1];
}, Hs = function(e, t, n, a, i, l) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var s;
  Z.contains(Is, e) ? s = oc : Z.contains(Ls, e) ? s = Os : s = uc;
  var o = Ps(e, t, s, a);
  return o.type === "small" ? tc(e, o.style, n, a, i, l) : o.type === "large" ? Rs(e, o.size, n, a, i, l) : Ns(e, t, n, a, i, l);
}, hc = function(e, t, n, a, i, l) {
  var s = a.fontMetrics().axisHeight * a.sizeMultiplier, o = 901, h = 5 / a.fontMetrics().ptPerEm, m = Math.max(t - s, n + s), p = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    m / 500 * o,
    2 * m - h
  );
  return Hs(e, p, !0, a, i, l);
}, b0 = {
  sqrtImage: ic,
  sizedDelim: sc,
  sizeToMaxHeight: yn,
  customSizedDelim: Hs,
  leftRightDelim: hc
}, Bi = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, dc = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function $r(r, e) {
  var t = kr(r);
  if (t && Z.contains(dc, t.text))
    return t;
  throw t ? new O("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", r) : new O("Invalid delimiter type '" + r.type + "'", r);
}
V({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = $r(e[0], r);
    return {
      type: "delimsizing",
      mode: r.parser.mode,
      size: Bi[r.funcName].size,
      mclass: Bi[r.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => r.delim === "." ? D.makeSpan([r.mclass]) : b0.sizedDelim(r.delim, r.size, e, r.mode, [r.mclass]),
  mathmlBuilder: (r) => {
    var e = [];
    r.delim !== "." && e.push(zt(r.delim, r.mode));
    var t = new I.MathNode("mo", e);
    r.mclass === "mopen" || r.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var n = G(b0.sizeToMaxHeight[r.size]);
    return t.setAttribute("minsize", n), t.setAttribute("maxsize", n), t;
  }
});
function qi(r) {
  if (!r.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
V({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = r.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new O("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: r.parser.mode,
      delim: $r(e[0], r).text,
      color: t
      // undefined if not set via \color
    };
  }
});
V({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = $r(e[0], r), n = r.parser;
    ++n.leftrightDepth;
    var a = n.parseExpression(!1);
    --n.leftrightDepth, n.expect("\\right", !1);
    var i = ae(n.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: n.mode,
      body: a,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (r, e) => {
    qi(r);
    for (var t = He(r.body, e, !0, ["mopen", "mclose"]), n = 0, a = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (n = Math.max(t[l].height, n), a = Math.max(t[l].depth, a));
    n *= e.sizeMultiplier, a *= e.sizeMultiplier;
    var s;
    if (r.left === "." ? s = $n(e, ["mopen"]) : s = b0.leftRightDelim(r.left, n, a, e, r.mode, ["mopen"]), t.unshift(s), i)
      for (var o = 1; o < t.length; o++) {
        var h = t[o], m = h.isMiddle;
        m && (t[o] = b0.leftRightDelim(m.delim, n, a, m.options, r.mode, []));
      }
    var p;
    if (r.right === ".")
      p = $n(e, ["mclose"]);
    else {
      var g = r.rightColor ? e.withColor(r.rightColor) : e;
      p = b0.leftRightDelim(r.right, n, a, g, r.mode, ["mclose"]);
    }
    return t.push(p), D.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (r, e) => {
    qi(r);
    var t = ft(r.body, e);
    if (r.left !== ".") {
      var n = new I.MathNode("mo", [zt(r.left, r.mode)]);
      n.setAttribute("fence", "true"), t.unshift(n);
    }
    if (r.right !== ".") {
      var a = new I.MathNode("mo", [zt(r.right, r.mode)]);
      a.setAttribute("fence", "true"), r.rightColor && a.setAttribute("mathcolor", r.rightColor), t.push(a);
    }
    return Ba(t);
  }
});
V({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = $r(e[0], r);
    if (!r.parser.leftrightDepth)
      throw new O("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: r.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    if (r.delim === ".")
      t = $n(e, []);
    else {
      t = b0.sizedDelim(r.delim, 1, e, r.mode, []);
      var n = {
        delim: r.delim,
        options: e
      };
      t.isMiddle = n;
    }
    return t;
  },
  mathmlBuilder: (r, e) => {
    var t = r.delim === "\\vert" || r.delim === "|" ? zt("|", "text") : zt(r.delim, r.mode), n = new I.MathNode("mo", [t]);
    return n.setAttribute("fence", "true"), n.setAttribute("lspace", "0.05em"), n.setAttribute("rspace", "0.05em"), n;
  }
});
var Ia = (r, e) => {
  var t = D.wrapFragment(oe(r.body, e), e), n = r.label.slice(1), a = e.sizeMultiplier, i, l = 0, s = Z.isCharacterBox(r.body);
  if (n === "sout")
    i = D.makeSpan(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / a, l = -0.5 * e.fontMetrics().xHeight;
  else if (n === "phase") {
    var o = Ee({
      number: 0.6,
      unit: "pt"
    }, e), h = Ee({
      number: 0.35,
      unit: "ex"
    }, e), m = e.havingBaseSizing();
    a = a / m.sizeMultiplier;
    var p = t.height + t.depth + o + h;
    t.style.paddingLeft = G(p / 2 + o);
    var g = Math.floor(1e3 * p * a), _ = au(g), C = new w0([new z0("phase", _)], {
      width: "400em",
      height: G(g / 1e3),
      viewBox: "0 0 400000 " + g,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = D.makeSvgSpan(["hide-tail"], [C], e), i.style.height = G(p), l = t.depth + o + h;
  } else {
    /cancel/.test(n) ? s || t.classes.push("cancel-pad") : n === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var T = 0, F = 0, M = 0;
    /box/.test(n) ? (M = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), T = e.fontMetrics().fboxsep + (n === "colorbox" ? 0 : M), F = T) : n === "angl" ? (M = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), T = 4 * M, F = Math.max(0, 0.25 - t.depth)) : (T = s ? 0.2 : 0, F = T), i = k0.encloseSpan(t, n, T, F, e), /fbox|boxed|fcolorbox/.test(n) ? (i.style.borderStyle = "solid", i.style.borderWidth = G(M)) : n === "angl" && M !== 0.049 && (i.style.borderTopWidth = G(M), i.style.borderRightWidth = G(M)), l = t.depth + F, r.backgroundColor && (i.style.backgroundColor = r.backgroundColor, r.borderColor && (i.style.borderColor = r.borderColor));
  }
  var w;
  if (r.backgroundColor)
    w = D.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var v = /cancel|phase/.test(n) ? ["svg-align"] : [];
    w = D.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: v
        }
      ]
    }, e);
  }
  return /cancel/.test(n) && (w.height = t.height, w.depth = t.depth), /cancel/.test(n) && !s ? D.makeSpan(["mord", "cancel-lap"], [w], e) : D.makeSpan(["mord"], [w], e);
}, Oa = (r, e) => {
  var t = 0, n = new I.MathNode(r.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [ye(r.body, e)]);
  switch (r.label) {
    case "\\cancel":
      n.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      n.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      n.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      n.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      n.setAttribute("notation", "box");
      break;
    case "\\angl":
      n.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, n.setAttribute("width", "+" + 2 * t + "pt"), n.setAttribute("height", "+" + 2 * t + "pt"), n.setAttribute("lspace", t + "pt"), n.setAttribute("voffset", t + "pt"), r.label === "\\fcolorbox") {
        var a = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        n.setAttribute("style", "border: " + a + "em solid " + String(r.borderColor));
      }
      break;
    case "\\xcancel":
      n.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return r.backgroundColor && n.setAttribute("mathbackground", r.backgroundColor), n;
};
V({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: n,
      funcName: a
    } = r, i = ae(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: n.mode,
      label: a,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: Ia,
  mathmlBuilder: Oa
});
V({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: n,
      funcName: a
    } = r, i = ae(e[0], "color-token").color, l = ae(e[1], "color-token").color, s = e[2];
    return {
      type: "enclose",
      mode: n.mode,
      label: a,
      backgroundColor: l,
      borderColor: i,
      body: s
    };
  },
  htmlBuilder: Ia,
  mathmlBuilder: Oa
});
V({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
V({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: n,
      body: a
    };
  },
  htmlBuilder: Ia,
  mathmlBuilder: Oa
});
V({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var Us = {};
function l0(r) {
  for (var {
    type: e,
    names: t,
    props: n,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, s = {
    type: e,
    numArgs: n.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: a
  }, o = 0; o < t.length; ++o)
    Us[t[o]] = s;
  i && (hr[e] = i), l && (dr[e] = l);
}
var Gs = {};
function f(r, e) {
  Gs[r] = e;
}
function Ri(r) {
  var e = [];
  r.consumeSpaces();
  var t = r.fetch().text;
  for (t === "\\relax" && (r.consume(), r.consumeSpaces(), t = r.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    r.consume(), e.push(t === "\\hdashline"), r.consumeSpaces(), t = r.fetch().text;
  return e;
}
var Dr = (r) => {
  var e = r.parser.settings;
  if (!e.displayMode)
    throw new O("{" + r.envName + "} can be used only in display mode.");
};
function Pa(r) {
  if (r.indexOf("ed") === -1)
    return r.indexOf("*") === -1;
}
function q0(r, e, t) {
  var {
    hskipBeforeAndAfter: n,
    addJot: a,
    cols: i,
    arraystretch: l,
    colSeparationType: s,
    autoTag: o,
    singleRow: h,
    emptySingleRow: m,
    maxNumCols: p,
    leqno: g
  } = e;
  if (r.gullet.beginGroup(), h || r.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var _ = r.gullet.expandMacroAsText("\\arraystretch");
    if (_ == null)
      l = 1;
    else if (l = parseFloat(_), !l || l < 0)
      throw new O("Invalid \\arraystretch: " + _);
  }
  r.gullet.beginGroup();
  var C = [], T = [C], F = [], M = [], w = o != null ? [] : void 0;
  function v() {
    o && r.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function x() {
    w && (r.gullet.macros.get("\\df@tag") ? (w.push(r.subparse([new Ft("\\df@tag")])), r.gullet.macros.set("\\df@tag", void 0, !0)) : w.push(!!o && r.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (v(), M.push(Ri(r)); ; ) {
    var $ = r.parseExpression(!1, h ? "\\end" : "\\\\");
    r.gullet.endGroup(), r.gullet.beginGroup(), $ = {
      type: "ordgroup",
      mode: r.mode,
      body: $
    }, t && ($ = {
      type: "styling",
      mode: r.mode,
      style: t,
      body: [$]
    }), C.push($);
    var E = r.fetch().text;
    if (E === "&") {
      if (p && C.length === p) {
        if (h || s)
          throw new O("Too many tab characters: &", r.nextToken);
        r.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      r.consume();
    } else if (E === "\\end") {
      x(), C.length === 1 && $.type === "styling" && $.body[0].body.length === 0 && (T.length > 1 || !m) && T.pop(), M.length < T.length + 1 && M.push([]);
      break;
    } else if (E === "\\\\") {
      r.consume();
      var A = void 0;
      r.gullet.future().text !== " " && (A = r.parseSizeGroup(!0)), F.push(A ? A.value : null), x(), M.push(Ri(r)), C = [], T.push(C), v();
    } else
      throw new O("Expected & or \\\\ or \\cr or \\end", r.nextToken);
  }
  return r.gullet.endGroup(), r.gullet.endGroup(), {
    type: "array",
    mode: r.mode,
    addJot: a,
    arraystretch: l,
    body: T,
    cols: i,
    rowGaps: F,
    hskipBeforeAndAfter: n,
    hLinesBeforeRow: M,
    colSeparationType: s,
    tags: w,
    leqno: g
  };
}
function Ha(r) {
  return r.slice(0, 1) === "d" ? "display" : "text";
}
var s0 = function(e, t) {
  var n, a, i = e.body.length, l = e.hLinesBeforeRow, s = 0, o = new Array(i), h = [], m = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), p = 1 / t.fontMetrics().ptPerEm, g = 5 * p;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var _ = t.havingStyle(J.SCRIPT).sizeMultiplier;
    g = 0.2778 * (_ / t.sizeMultiplier);
  }
  var C = e.colSeparationType === "CD" ? Ee({
    number: 3,
    unit: "ex"
  }, t) : 12 * p, T = 3 * p, F = e.arraystretch * C, M = 0.7 * F, w = 0.3 * F, v = 0;
  function x(L) {
    for (var te = 0; te < L.length; ++te)
      te > 0 && (v += 0.25), h.push({
        pos: v,
        isDashed: L[te]
      });
  }
  for (x(l[0]), n = 0; n < e.body.length; ++n) {
    var $ = e.body[n], E = M, A = w;
    s < $.length && (s = $.length);
    var q = new Array($.length);
    for (a = 0; a < $.length; ++a) {
      var B = oe($[a], t);
      A < B.depth && (A = B.depth), E < B.height && (E = B.height), q[a] = B;
    }
    var z = e.rowGaps[n], U = 0;
    z && (U = Ee(z, t), U > 0 && (U += w, A < U && (A = U), U = 0)), e.addJot && (A += T), q.height = E, q.depth = A, v += E, q.pos = v, v += A + U, o[n] = q, x(l[n + 1]);
  }
  var N = v / 2 + t.fontMetrics().axisHeight, K = e.cols || [], ie = [], we, _e, Ue = [];
  if (e.tags && e.tags.some((L) => L))
    for (n = 0; n < i; ++n) {
      var ue = o[n], Me = ue.pos - N, De = e.tags[n], re = void 0;
      De === !0 ? re = D.makeSpan(["eqn-num"], [], t) : De === !1 ? re = D.makeSpan([], [], t) : re = D.makeSpan([], He(De, t, !0), t), re.depth = ue.depth, re.height = ue.height, Ue.push({
        type: "elem",
        elem: re,
        shift: Me
      });
    }
  for (
    a = 0, _e = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    a < s || _e < K.length;
    ++a, ++_e
  ) {
    for (var ce = K[_e] || {}, he = !0; ce.type === "separator"; ) {
      if (he || (we = D.makeSpan(["arraycolsep"], []), we.style.width = G(t.fontMetrics().doubleRuleSep), ie.push(we)), ce.separator === "|" || ce.separator === ":") {
        var Le = ce.separator === "|" ? "solid" : "dashed", H = D.makeSpan(["vertical-separator"], [], t);
        H.style.height = G(v), H.style.borderRightWidth = G(m), H.style.borderRightStyle = Le, H.style.margin = "0 " + G(-m / 2);
        var Ge = v - N;
        Ge && (H.style.verticalAlign = G(-Ge)), ie.push(H);
      } else
        throw new O("Invalid separator type: " + ce.separator);
      _e++, ce = K[_e] || {}, he = !1;
    }
    if (!(a >= s)) {
      var ze = void 0;
      (a > 0 || e.hskipBeforeAndAfter) && (ze = Z.deflt(ce.pregap, g), ze !== 0 && (we = D.makeSpan(["arraycolsep"], []), we.style.width = G(ze), ie.push(we)));
      var ke = [];
      for (n = 0; n < i; ++n) {
        var et = o[n], Ie = et[a];
        if (Ie) {
          var Ze = et.pos - N;
          Ie.depth = et.depth, Ie.height = et.height, ke.push({
            type: "elem",
            elem: Ie,
            shift: Ze
          });
        }
      }
      ke = D.makeVList({
        positionType: "individualShift",
        children: ke
      }, t), ke = D.makeSpan(["col-align-" + (ce.align || "c")], [ke]), ie.push(ke), (a < s - 1 || e.hskipBeforeAndAfter) && (ze = Z.deflt(ce.postgap, g), ze !== 0 && (we = D.makeSpan(["arraycolsep"], []), we.style.width = G(ze), ie.push(we)));
    }
  }
  if (o = D.makeSpan(["mtable"], ie), h.length > 0) {
    for (var ot = D.makeLineSpan("hline", t, m), ut = D.makeLineSpan("hdashline", t, m), We = [{
      type: "elem",
      elem: o,
      shift: 0
    }]; h.length > 0; ) {
      var Ke = h.pop(), wt = Ke.pos - N;
      Ke.isDashed ? We.push({
        type: "elem",
        elem: ut,
        shift: wt
      }) : We.push({
        type: "elem",
        elem: ot,
        shift: wt
      });
    }
    o = D.makeVList({
      positionType: "individualShift",
      children: We
    }, t);
  }
  if (Ue.length === 0)
    return D.makeSpan(["mord"], [o], t);
  var xt = D.makeVList({
    positionType: "individualShift",
    children: Ue
  }, t);
  return xt = D.makeSpan(["tag"], [xt], t), D.makeFragment([o, xt]);
}, mc = {
  c: "center ",
  l: "left ",
  r: "right "
}, o0 = function(e, t) {
  for (var n = [], a = new I.MathNode("mtd", [], ["mtr-glue"]), i = new I.MathNode("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var s = e.body[l], o = [], h = 0; h < s.length; h++)
      o.push(new I.MathNode("mtd", [ye(s[h], t)]));
    e.tags && e.tags[l] && (o.unshift(a), o.push(a), e.leqno ? o.unshift(i) : o.push(i)), n.push(new I.MathNode("mtr", o));
  }
  var m = new I.MathNode("mtable", n), p = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  m.setAttribute("rowspacing", G(p));
  var g = "", _ = "";
  if (e.cols && e.cols.length > 0) {
    var C = e.cols, T = "", F = !1, M = 0, w = C.length;
    C[0].type === "separator" && (g += "top ", M = 1), C[C.length - 1].type === "separator" && (g += "bottom ", w -= 1);
    for (var v = M; v < w; v++)
      C[v].type === "align" ? (_ += mc[C[v].align], F && (T += "none "), F = !0) : C[v].type === "separator" && F && (T += C[v].separator === "|" ? "solid " : "dashed ", F = !1);
    m.setAttribute("columnalign", _.trim()), /[sd]/.test(T) && m.setAttribute("columnlines", T.trim());
  }
  if (e.colSeparationType === "align") {
    for (var x = e.cols || [], $ = "", E = 1; E < x.length; E++)
      $ += E % 2 ? "0em " : "1em ";
    m.setAttribute("columnspacing", $.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? m.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? m.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? m.setAttribute("columnspacing", "0.5em") : m.setAttribute("columnspacing", "1em");
  var A = "", q = e.hLinesBeforeRow;
  g += q[0].length > 0 ? "left " : "", g += q[q.length - 1].length > 0 ? "right " : "";
  for (var B = 1; B < q.length - 1; B++)
    A += q[B].length === 0 ? "none " : q[B][0] ? "dashed " : "solid ";
  return /[sd]/.test(A) && m.setAttribute("rowlines", A.trim()), g !== "" && (m = new I.MathNode("menclose", [m]), m.setAttribute("notation", g.trim())), e.arraystretch && e.arraystretch < 1 && (m = new I.MathNode("mstyle", [m]), m.setAttribute("scriptlevel", "1")), m;
}, Vs = function(e, t) {
  e.envName.indexOf("ed") === -1 && Dr(e);
  var n = [], a = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", l = q0(e.parser, {
    cols: n,
    addJot: !0,
    autoTag: i ? void 0 : Pa(e.envName),
    emptySingleRow: !0,
    colSeparationType: a,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), s, o = 0, h = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var m = "", p = 0; p < t[0].body.length; p++) {
      var g = ae(t[0].body[p], "textord");
      m += g.text;
    }
    s = Number(m), o = s * 2;
  }
  var _ = !o;
  l.body.forEach(function(M) {
    for (var w = 1; w < M.length; w += 2) {
      var v = ae(M[w], "styling"), x = ae(v.body[0], "ordgroup");
      x.body.unshift(h);
    }
    if (_)
      o < M.length && (o = M.length);
    else {
      var $ = M.length / 2;
      if (s < $)
        throw new O("Too many math in a row: " + ("expected " + s + ", but got " + $), M[0]);
    }
  });
  for (var C = 0; C < o; ++C) {
    var T = "r", F = 0;
    C % 2 === 1 ? T = "l" : C > 0 && _ && (F = 1), n[C] = {
      type: "align",
      align: T,
      pregap: F,
      postgap: 0
    };
  }
  return l.colSeparationType = _ ? "align" : "alignat", l;
};
l0({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = kr(e[0]), n = t ? [e[0]] : ae(e[0], "ordgroup").body, a = n.map(function(l) {
      var s = Ra(l), o = s.text;
      if ("lcr".indexOf(o) !== -1)
        return {
          type: "align",
          align: o
        };
      if (o === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (o === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new O("Unknown column alignment: " + o, l);
    }), i = {
      cols: a,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: a.length
    };
    return q0(r.parser, i, Ha(r.envName));
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[r.envName.replace("*", "")], t = "c", n = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (r.envName.charAt(r.envName.length - 1) === "*") {
      var a = r.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), t = a.fetch().text, "lcr".indexOf(t) === -1)
          throw new O("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), n.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = q0(r.parser, n, Ha(r.envName)), l = Math.max(0, ...i.body.map((s) => s.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: r.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 0.5
    }, t = q0(r.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = kr(e[0]), n = t ? [e[0]] : ae(e[0], "ordgroup").body, a = n.map(function(l) {
      var s = Ra(l), o = s.text;
      if ("lc".indexOf(o) !== -1)
        return {
          type: "align",
          align: o
        };
      throw new O("Unknown column alignment: " + o, l);
    });
    if (a.length > 1)
      throw new O("{subarray} can contain only one column");
    var i = {
      cols: a,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = q0(r.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new O("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = q0(r.parser, e, Ha(r.envName));
    return {
      type: "leftright",
      mode: r.mode,
      body: [t],
      left: r.envName.indexOf("r") > -1 ? "." : "\\{",
      right: r.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: Vs,
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    Z.contains(["gather", "gather*"], r.envName) && Dr(r);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: Pa(r.envName),
      emptySingleRow: !0,
      leqno: r.parser.settings.leqno
    };
    return q0(r.parser, e, "display");
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: Vs,
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    Dr(r);
    var e = {
      autoTag: Pa(r.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: r.parser.settings.leqno
    };
    return q0(r.parser, e, "display");
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
l0({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(r) {
    return Dr(r), Ju(r.parser);
  },
  htmlBuilder: s0,
  mathmlBuilder: o0
});
f("\\nonumber", "\\gdef\\@eqnsw{0}");
f("\\notag", "\\nonumber");
V({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(r, e) {
    throw new O(r.funcName + " valid only within array environment");
  }
});
var Ni = Us;
V({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    if (a.type !== "ordgroup")
      throw new O("Invalid environment name", a);
    for (var i = "", l = 0; l < a.body.length; ++l)
      i += ae(a.body[l], "textord").text;
    if (n === "\\begin") {
      if (!Ni.hasOwnProperty(i))
        throw new O("No such environment: " + i, a);
      var s = Ni[i], {
        args: o,
        optArgs: h
      } = t.parseArguments("\\begin{" + i + "}", s), m = {
        mode: t.mode,
        envName: i,
        parser: t
      }, p = s.handler(m, o, h);
      t.expect("\\end", !1);
      var g = t.nextToken, _ = ae(t.parseFunction(), "environment");
      if (_.name !== i)
        throw new O("Mismatch: \\begin{" + i + "} matched by \\end{" + _.name + "}", g);
      return p;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: a
    };
  }
});
var Ws = (r, e) => {
  var t = r.font, n = e.withFont(t);
  return oe(r.body, n);
}, js = (r, e) => {
  var t = r.font, n = e.withFont(t);
  return ye(r.body, n);
}, Li = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
V({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    "\\mathsfit",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = mr(e[0]), i = n;
    return i in Li && (i = Li[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: a
    };
  },
  htmlBuilder: Ws,
  mathmlBuilder: js
});
V({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0], a = Z.isCharacterBox(n);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Sr(n),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: n
      }],
      isCharacterBox: a
    };
  }
});
V({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n,
      breakOnTokenText: a
    } = r, {
      mode: i
    } = t, l = t.parseExpression(!0, a), s = "math" + n.slice(1);
    return {
      type: "font",
      mode: i,
      font: s,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: Ws,
  mathmlBuilder: js
});
var Xs = (r, e) => {
  var t = e;
  return r === "display" ? t = t.id >= J.SCRIPT.id ? t.text() : J.DISPLAY : r === "text" && t.size === J.DISPLAY.size ? t = J.TEXT : r === "script" ? t = J.SCRIPT : r === "scriptscript" && (t = J.SCRIPTSCRIPT), t;
}, Ua = (r, e) => {
  var t = Xs(r.size, e.style), n = t.fracNum(), a = t.fracDen(), i;
  i = e.havingStyle(n);
  var l = oe(r.numer, i, e);
  if (r.continued) {
    var s = 8.5 / e.fontMetrics().ptPerEm, o = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < s ? s : l.height, l.depth = l.depth < o ? o : l.depth;
  }
  i = e.havingStyle(a);
  var h = oe(r.denom, i, e), m, p, g;
  r.hasBarLine ? (r.barSize ? (p = Ee(r.barSize, e), m = D.makeLineSpan("frac-line", e, p)) : m = D.makeLineSpan("frac-line", e), p = m.height, g = m.height) : (m = null, p = 0, g = e.fontMetrics().defaultRuleThickness);
  var _, C, T;
  t.size === J.DISPLAY.size || r.size === "display" ? (_ = e.fontMetrics().num1, p > 0 ? C = 3 * g : C = 7 * g, T = e.fontMetrics().denom1) : (p > 0 ? (_ = e.fontMetrics().num2, C = g) : (_ = e.fontMetrics().num3, C = 3 * g), T = e.fontMetrics().denom2);
  var F;
  if (m) {
    var w = e.fontMetrics().axisHeight;
    _ - l.depth - (w + 0.5 * p) < C && (_ += C - (_ - l.depth - (w + 0.5 * p))), w - 0.5 * p - (h.height - T) < C && (T += C - (w - 0.5 * p - (h.height - T)));
    var v = -(w - 0.5 * p);
    F = D.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: h,
        shift: T
      }, {
        type: "elem",
        elem: m,
        shift: v
      }, {
        type: "elem",
        elem: l,
        shift: -_
      }]
    }, e);
  } else {
    var M = _ - l.depth - (h.height - T);
    M < C && (_ += 0.5 * (C - M), T += 0.5 * (C - M)), F = D.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: h,
        shift: T
      }, {
        type: "elem",
        elem: l,
        shift: -_
      }]
    }, e);
  }
  i = e.havingStyle(t), F.height *= i.sizeMultiplier / e.sizeMultiplier, F.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var x;
  t.size === J.DISPLAY.size ? x = e.fontMetrics().delim1 : t.size === J.SCRIPTSCRIPT.size ? x = e.havingStyle(J.SCRIPT).fontMetrics().delim2 : x = e.fontMetrics().delim2;
  var $, E;
  return r.leftDelim == null ? $ = $n(e, ["mopen"]) : $ = b0.customSizedDelim(r.leftDelim, x, !0, e.havingStyle(t), r.mode, ["mopen"]), r.continued ? E = D.makeSpan([]) : r.rightDelim == null ? E = $n(e, ["mclose"]) : E = b0.customSizedDelim(r.rightDelim, x, !0, e.havingStyle(t), r.mode, ["mclose"]), D.makeSpan(["mord"].concat(i.sizingClasses(e)), [$, D.makeSpan(["mfrac"], [F]), E], e);
}, Ga = (r, e) => {
  var t = new I.MathNode("mfrac", [ye(r.numer, e), ye(r.denom, e)]);
  if (!r.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (r.barSize) {
    var n = Ee(r.barSize, e);
    t.setAttribute("linethickness", G(n));
  }
  var a = Xs(r.size, e.style);
  if (a.size !== e.style.size) {
    t = new I.MathNode("mstyle", [t]);
    var i = a.size === J.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", i), t.setAttribute("scriptlevel", "0");
  }
  if (r.leftDelim != null || r.rightDelim != null) {
    var l = [];
    if (r.leftDelim != null) {
      var s = new I.MathNode("mo", [new I.TextNode(r.leftDelim.replace("\\", ""))]);
      s.setAttribute("fence", "true"), l.push(s);
    }
    if (l.push(t), r.rightDelim != null) {
      var o = new I.MathNode("mo", [new I.TextNode(r.rightDelim.replace("\\", ""))]);
      o.setAttribute("fence", "true"), l.push(o);
    }
    return Ba(l);
  }
  return t;
};
V({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0], i = e[1], l, s = null, o = null, h = "auto";
    switch (n) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, s = "(", o = ")";
        break;
      case "\\\\bracefrac":
        l = !1, s = "\\{", o = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, s = "[", o = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (n) {
      case "\\dfrac":
      case "\\dbinom":
        h = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        h = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: a,
      denom: i,
      hasBarLine: l,
      leftDelim: s,
      rightDelim: o,
      size: h,
      barSize: null
    };
  },
  htmlBuilder: Ua,
  mathmlBuilder: Ga
});
V({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0], i = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: a,
      denom: i,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
V({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t,
      token: n
    } = r, a;
    switch (t) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: a,
      token: n
    };
  }
});
var Ii = ["display", "text", "script", "scriptscript"], Oi = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
V({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = e[4], a = e[5], i = mr(e[0]), l = i.type === "atom" && i.family === "open" ? Oi(i.text) : null, s = mr(e[1]), o = s.type === "atom" && s.family === "close" ? Oi(s.text) : null, h = ae(e[2], "size"), m, p = null;
    h.isBlank ? m = !0 : (p = h.value, m = p.number > 0);
    var g = "auto", _ = e[3];
    if (_.type === "ordgroup") {
      if (_.body.length > 0) {
        var C = ae(_.body[0], "textord");
        g = Ii[Number(C.text)];
      }
    } else
      _ = ae(_, "textord"), g = Ii[Number(_.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: n,
      denom: a,
      continued: !1,
      hasBarLine: m,
      barSize: p,
      leftDelim: l,
      rightDelim: o,
      size: g
    };
  },
  htmlBuilder: Ua,
  mathmlBuilder: Ga
});
V({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n,
      token: a
    } = r;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: ae(e[0], "size").value,
      token: a
    };
  }
});
V({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0], i = U1(ae(e[1], "infix").size), l = e[2], s = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: l,
      continued: !1,
      hasBarLine: s,
      barSize: i,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: Ua,
  mathmlBuilder: Ga
});
var Ys = (r, e) => {
  var t = e.style, n, a;
  r.type === "supsub" ? (n = r.sup ? oe(r.sup, e.havingStyle(t.sup()), e) : oe(r.sub, e.havingStyle(t.sub()), e), a = ae(r.base, "horizBrace")) : a = ae(r, "horizBrace");
  var i = oe(a.base, e.havingBaseStyle(J.DISPLAY)), l = k0.svgSpan(a, e), s;
  if (a.isOver ? (s = D.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }, e), s.children[0].children[0].children[1].classes.push("svg-align")) : (s = D.makeVList({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }, e), s.children[0].children[0].children[0].classes.push("svg-align")), n) {
    var o = D.makeSpan(["mord", a.isOver ? "mover" : "munder"], [s], e);
    a.isOver ? s = D.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: o
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: n
      }]
    }, e) : s = D.makeVList({
      positionType: "bottom",
      positionData: o.depth + 0.2 + n.height + n.depth,
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: o
      }]
    }, e);
  }
  return D.makeSpan(["mord", a.isOver ? "mover" : "munder"], [s], e);
}, fc = (r, e) => {
  var t = k0.mathMLnode(r.label);
  return new I.MathNode(r.isOver ? "mover" : "munder", [ye(r.base, e), t]);
};
V({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: n,
      isOver: /^\\over/.test(n),
      base: e[0]
    };
  },
  htmlBuilder: Ys,
  mathmlBuilder: fc
});
V({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[1], a = ae(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: t.mode,
      href: a,
      body: Re(n)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (r, e) => {
    var t = He(r.body, e, !1);
    return D.makeAnchor(r.href, [], t, e);
  },
  mathmlBuilder: (r, e) => {
    var t = B0(r.body, e);
    return t instanceof yt || (t = new yt("mrow", [t])), t.setAttribute("href", r.href), t;
  }
});
V({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = ae(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: n
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var a = [], i = 0; i < n.length; i++) {
      var l = n[i];
      l === "~" && (l = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var s = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: t.mode,
      href: n,
      body: Re(s)
    };
  }
});
V({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "hbox",
      mode: t.mode,
      body: Re(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = He(r.body, e, !1);
    return D.makeFragment(t);
  },
  mathmlBuilder(r, e) {
    return new I.MathNode("mrow", ft(r.body, e));
  }
});
V({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n,
      token: a
    } = r, i = ae(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var s, o = {};
    switch (n) {
      case "\\htmlClass":
        o.class = i, s = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        o.id = i, s = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        o.style = i, s = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var h = i.split(","), m = 0; m < h.length; m++) {
          var p = h[m].split("=");
          if (p.length !== 2)
            throw new O("Error parsing key-value for \\htmlData");
          o["data-" + p[0].trim()] = p[1].trim();
        }
        s = {
          command: "\\htmlData",
          attributes: o
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(s) ? {
      type: "html",
      mode: t.mode,
      attributes: o,
      body: Re(l)
    } : t.formatUnsupportedCmd(n);
  },
  htmlBuilder: (r, e) => {
    var t = He(r.body, e, !1), n = ["enclosing"];
    r.attributes.class && n.push(...r.attributes.class.trim().split(/\s+/));
    var a = D.makeSpan(n, t, e);
    for (var i in r.attributes)
      i !== "class" && r.attributes.hasOwnProperty(i) && a.setAttribute(i, r.attributes[i]);
    return a;
  },
  mathmlBuilder: (r, e) => B0(r.body, e)
});
V({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: Re(e[0]),
      mathml: Re(e[1])
    };
  },
  htmlBuilder: (r, e) => {
    var t = He(r.html, e, !1);
    return D.makeFragment(t);
  },
  mathmlBuilder: (r, e) => B0(r.mathml, e)
});
var Wr = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new O("Invalid size: '" + e + "' in \\includegraphics");
  var n = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!fs(n))
    throw new O("Invalid unit: '" + n.unit + "' in \\includegraphics.");
  return n;
};
V({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (r, e, t) => {
    var {
      parser: n
    } = r, a = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, s = "";
    if (t[0])
      for (var o = ae(t[0], "raw").string, h = o.split(","), m = 0; m < h.length; m++) {
        var p = h[m].split("=");
        if (p.length === 2) {
          var g = p[1].trim();
          switch (p[0].trim()) {
            case "alt":
              s = g;
              break;
            case "width":
              a = Wr(g);
              break;
            case "height":
              i = Wr(g);
              break;
            case "totalheight":
              l = Wr(g);
              break;
            default:
              throw new O("Invalid key: '" + p[0] + "' in \\includegraphics.");
          }
        }
      }
    var _ = ae(e[0], "url").url;
    return s === "" && (s = _, s = s.replace(/^.*[\\/]/, ""), s = s.substring(0, s.lastIndexOf("."))), n.settings.isTrusted({
      command: "\\includegraphics",
      url: _
    }) ? {
      type: "includegraphics",
      mode: n.mode,
      alt: s,
      width: a,
      height: i,
      totalheight: l,
      src: _
    } : n.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (r, e) => {
    var t = Ee(r.height, e), n = 0;
    r.totalheight.number > 0 && (n = Ee(r.totalheight, e) - t);
    var a = 0;
    r.width.number > 0 && (a = Ee(r.width, e));
    var i = {
      height: G(t + n)
    };
    a > 0 && (i.width = G(a)), n > 0 && (i.verticalAlign = G(-n));
    var l = new fu(r.src, r.alt, i);
    return l.height = t, l.depth = n, l;
  },
  mathmlBuilder: (r, e) => {
    var t = new I.MathNode("mglyph", []);
    t.setAttribute("alt", r.alt);
    var n = Ee(r.height, e), a = 0;
    if (r.totalheight.number > 0 && (a = Ee(r.totalheight, e) - n, t.setAttribute("valign", G(-a))), t.setAttribute("height", G(n + a)), r.width.number > 0) {
      var i = Ee(r.width, e);
      t.setAttribute("width", G(i));
    }
    return t.setAttribute("src", r.src), t;
  }
});
V({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = ae(e[0], "size");
    if (t.settings.strict) {
      var i = n[1] === "m", l = a.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " supports only mu units, " + ("not " + a.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: a.value
    };
  },
  htmlBuilder(r, e) {
    return D.makeGlue(r.dimension, e);
  },
  mathmlBuilder(r, e) {
    var t = Ee(r.dimension, e);
    return new I.SpaceNode(t);
  }
});
V({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: n.slice(5),
      body: a
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    r.alignment === "clap" ? (t = D.makeSpan([], [oe(r.body, e)]), t = D.makeSpan(["inner"], [t], e)) : t = D.makeSpan(["inner"], [oe(r.body, e)]);
    var n = D.makeSpan(["fix"], []), a = D.makeSpan([r.alignment], [t, n], e), i = D.makeSpan(["strut"]);
    return i.style.height = G(a.height + a.depth), a.depth && (i.style.verticalAlign = G(-a.depth)), a.children.unshift(i), a = D.makeSpan(["thinbox"], [a], e), D.makeSpan(["mord", "vbox"], [a], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new I.MathNode("mpadded", [ye(r.body, e)]);
    if (r.alignment !== "rlap") {
      var n = r.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", n + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
V({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    var {
      funcName: t,
      parser: n
    } = r, a = n.mode;
    n.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = n.parseExpression(!1, i);
    return n.expect(i), n.switchMode(a), {
      type: "styling",
      mode: n.mode,
      style: "text",
      body: l
    };
  }
});
V({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    throw new O("Mismatched " + r.funcName);
  }
});
var Pi = (r, e) => {
  switch (e.style.size) {
    case J.DISPLAY.size:
      return r.display;
    case J.TEXT.size:
      return r.text;
    case J.SCRIPT.size:
      return r.script;
    case J.SCRIPTSCRIPT.size:
      return r.scriptscript;
    default:
      return r.text;
  }
};
V({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: Re(e[0]),
      text: Re(e[1]),
      script: Re(e[2]),
      scriptscript: Re(e[3])
    };
  },
  htmlBuilder: (r, e) => {
    var t = Pi(r, e), n = He(t, e, !1);
    return D.makeFragment(n);
  },
  mathmlBuilder: (r, e) => {
    var t = Pi(r, e);
    return B0(t, e);
  }
});
var Zs = (r, e, t, n, a, i, l) => {
  r = D.makeSpan([], [r]);
  var s = t && Z.isCharacterBox(t), o, h;
  if (e) {
    var m = oe(e, n.havingStyle(a.sup()), n);
    h = {
      elem: m,
      kern: Math.max(n.fontMetrics().bigOpSpacing1, n.fontMetrics().bigOpSpacing3 - m.depth)
    };
  }
  if (t) {
    var p = oe(t, n.havingStyle(a.sub()), n);
    o = {
      elem: p,
      kern: Math.max(n.fontMetrics().bigOpSpacing2, n.fontMetrics().bigOpSpacing4 - p.height)
    };
  }
  var g;
  if (h && o) {
    var _ = n.fontMetrics().bigOpSpacing5 + o.elem.height + o.elem.depth + o.kern + r.depth + l;
    g = D.makeVList({
      positionType: "bottom",
      positionData: _,
      children: [{
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: o.elem,
        marginLeft: G(-i)
      }, {
        type: "kern",
        size: o.kern
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: h.kern
      }, {
        type: "elem",
        elem: h.elem,
        marginLeft: G(i)
      }, {
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }]
    }, n);
  } else if (o) {
    var C = r.height - l;
    g = D.makeVList({
      positionType: "top",
      positionData: C,
      children: [{
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: o.elem,
        marginLeft: G(-i)
      }, {
        type: "kern",
        size: o.kern
      }, {
        type: "elem",
        elem: r
      }]
    }, n);
  } else if (h) {
    var T = r.depth + l;
    g = D.makeVList({
      positionType: "bottom",
      positionData: T,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: h.kern
      }, {
        type: "elem",
        elem: h.elem,
        marginLeft: G(i)
      }, {
        type: "kern",
        size: n.fontMetrics().bigOpSpacing5
      }]
    }, n);
  } else
    return r;
  var F = [g];
  if (o && i !== 0 && !s) {
    var M = D.makeSpan(["mspace"], [], n);
    M.style.marginRight = G(i), F.unshift(M);
  }
  return D.makeSpan(["mop", "op-limits"], F, n);
}, Ks = ["\\smallint"], ln = (r, e) => {
  var t, n, a = !1, i;
  r.type === "supsub" ? (t = r.sup, n = r.sub, i = ae(r.base, "op"), a = !0) : i = ae(r, "op");
  var l = e.style, s = !1;
  l.size === J.DISPLAY.size && i.symbol && !Z.contains(Ks, i.name) && (s = !0);
  var o;
  if (i.symbol) {
    var h = s ? "Size2-Regular" : "Size1-Regular", m = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (m = i.name.slice(1), i.name = m === "oiint" ? "\\iint" : "\\iiint"), o = D.makeSymbol(i.name, h, "math", e, ["mop", "op-symbol", s ? "large-op" : "small-op"]), m.length > 0) {
      var p = o.italic, g = D.staticSvg(m + "Size" + (s ? "2" : "1"), e);
      o = D.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: o,
          shift: 0
        }, {
          type: "elem",
          elem: g,
          shift: s ? 0.08 : 0
        }]
      }, e), i.name = "\\" + m, o.classes.unshift("mop"), o.italic = p;
    }
  } else if (i.body) {
    var _ = He(i.body, e, !0);
    _.length === 1 && _[0] instanceof Mt ? (o = _[0], o.classes[0] = "mop") : o = D.makeSpan(["mop"], _, e);
  } else {
    for (var C = [], T = 1; T < i.name.length; T++)
      C.push(D.mathsym(i.name[T], i.mode, e));
    o = D.makeSpan(["mop"], C, e);
  }
  var F = 0, M = 0;
  return (o instanceof Mt || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (F = (o.height - o.depth) / 2 - e.fontMetrics().axisHeight, M = o.italic), a ? Zs(o, t, n, e, l, M, F) : (F && (o.style.position = "relative", o.style.top = G(F)), o);
}, Cn = (r, e) => {
  var t;
  if (r.symbol)
    t = new yt("mo", [zt(r.name, r.mode)]), Z.contains(Ks, r.name) && t.setAttribute("largeop", "false");
  else if (r.body)
    t = new yt("mo", ft(r.body, e));
  else {
    t = new yt("mi", [new Jt(r.name.slice(1))]);
    var n = new yt("mo", [zt("⁡", "text")]);
    r.parentIsSupSub ? t = new yt("mrow", [t, n]) : t = $s([t, n]);
  }
  return t;
}, pc = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
V({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = n;
    return a.length === 1 && (a = pc[a]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: ln,
  mathmlBuilder: Cn
});
V({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: Re(n)
    };
  },
  htmlBuilder: ln,
  mathmlBuilder: Cn
});
var gc = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
V({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: ln,
  mathmlBuilder: Cn
});
V({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: ln,
  mathmlBuilder: Cn
});
V({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, n = t;
    return n.length === 1 && (n = gc[n]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: n
    };
  },
  htmlBuilder: ln,
  mathmlBuilder: Cn
});
var Qs = (r, e) => {
  var t, n, a = !1, i;
  r.type === "supsub" ? (t = r.sup, n = r.sub, i = ae(r.base, "operatorname"), a = !0) : i = ae(r, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var s = i.body.map((p) => {
      var g = p.text;
      return typeof g == "string" ? {
        type: "textord",
        mode: p.mode,
        text: g
      } : p;
    }), o = He(s, e.withFont("mathrm"), !0), h = 0; h < o.length; h++) {
      var m = o[h];
      m instanceof Mt && (m.text = m.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = D.makeSpan(["mop"], o, e);
  } else
    l = D.makeSpan(["mop"], [], e);
  return a ? Zs(l, t, n, e, e.style, 0, 0) : l;
}, _c = (r, e) => {
  for (var t = ft(r.body, e.withFont("mathrm")), n = !0, a = 0; a < t.length; a++) {
    var i = t[a];
    if (!(i instanceof I.SpaceNode)) if (i instanceof I.MathNode)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof I.TextNode ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : n = !1;
          break;
        }
        default:
          n = !1;
      }
    else
      n = !1;
  }
  if (n) {
    var s = t.map((m) => m.toText()).join("");
    t = [new I.TextNode(s)];
  }
  var o = new I.MathNode("mi", t);
  o.setAttribute("mathvariant", "normal");
  var h = new I.MathNode("mo", [zt("⁡", "text")]);
  return r.parentIsSupSub ? new I.MathNode("mrow", [o, h]) : I.newDocumentFragment([o, h]);
};
V({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: Re(a),
      alwaysHandleSupSub: n === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: Qs,
  mathmlBuilder: _c
});
f("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
W0({
  type: "ordgroup",
  htmlBuilder(r, e) {
    return r.semisimple ? D.makeFragment(He(r.body, e, !1)) : D.makeSpan(["mord"], He(r.body, e, !0), e);
  },
  mathmlBuilder(r, e) {
    return B0(r.body, e, !0);
  }
});
V({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: n
    };
  },
  htmlBuilder(r, e) {
    var t = oe(r.body, e.havingCrampedStyle()), n = D.makeLineSpan("overline-line", e), a = e.fontMetrics().defaultRuleThickness, i = D.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: a
      }]
    }, e);
    return D.makeSpan(["mord", "overline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mo", [new I.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var n = new I.MathNode("mover", [ye(r.body, e), t]);
    return n.setAttribute("accent", "true"), n;
  }
});
V({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: Re(n)
    };
  },
  htmlBuilder: (r, e) => {
    var t = He(r.body, e.withPhantom(), !1);
    return D.makeFragment(t);
  },
  mathmlBuilder: (r, e) => {
    var t = ft(r.body, e);
    return new I.MathNode("mphantom", t);
  }
});
V({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: n
    };
  },
  htmlBuilder: (r, e) => {
    var t = D.makeSpan([], [oe(r.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var n = 0; n < t.children.length; n++)
        t.children[n].height = 0, t.children[n].depth = 0;
    return t = D.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), D.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (r, e) => {
    var t = ft(Re(r.body), e), n = new I.MathNode("mphantom", t), a = new I.MathNode("mpadded", [n]);
    return a.setAttribute("height", "0px"), a.setAttribute("depth", "0px"), a;
  }
});
V({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, n = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: n
    };
  },
  htmlBuilder: (r, e) => {
    var t = D.makeSpan(["inner"], [oe(r.body, e.withPhantom())]), n = D.makeSpan(["fix"], []);
    return D.makeSpan(["mord", "rlap"], [t, n], e);
  },
  mathmlBuilder: (r, e) => {
    var t = ft(Re(r.body), e), n = new I.MathNode("mphantom", t), a = new I.MathNode("mpadded", [n]);
    return a.setAttribute("width", "0px"), a;
  }
});
V({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r, n = ae(e[0], "size").value, a = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: n,
      body: a
    };
  },
  htmlBuilder(r, e) {
    var t = oe(r.body, e), n = Ee(r.dy, e);
    return D.makeVList({
      positionType: "shift",
      positionData: -n,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mpadded", [ye(r.body, e)]), n = r.dy.number + r.dy.unit;
    return t.setAttribute("voffset", n), t;
  }
});
V({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInArgument: !0
  },
  handler(r) {
    var {
      parser: e
    } = r;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
V({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    argTypes: ["size", "size", "size"]
  },
  handler(r, e, t) {
    var {
      parser: n
    } = r, a = t[0], i = ae(e[0], "size"), l = ae(e[1], "size");
    return {
      type: "rule",
      mode: n.mode,
      shift: a && ae(a, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(r, e) {
    var t = D.makeSpan(["mord", "rule"], [], e), n = Ee(r.width, e), a = Ee(r.height, e), i = r.shift ? Ee(r.shift, e) : 0;
    return t.style.borderRightWidth = G(n), t.style.borderTopWidth = G(a), t.style.bottom = G(i), t.width = n, t.height = a + i, t.depth = -i, t.maxFontSize = a * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(r, e) {
    var t = Ee(r.width, e), n = Ee(r.height, e), a = r.shift ? Ee(r.shift, e) : 0, i = e.color && e.getColor() || "black", l = new I.MathNode("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", G(t)), l.setAttribute("height", G(n));
    var s = new I.MathNode("mpadded", [l]);
    return a >= 0 ? s.setAttribute("height", G(a)) : (s.setAttribute("height", G(a)), s.setAttribute("depth", G(-a))), s.setAttribute("voffset", G(a)), s;
  }
});
function Js(r, e, t) {
  for (var n = He(r, e, !1), a = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < n.length; i++) {
    var l = n[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(n[i].classes, e.sizingClasses(t)) : n[i].classes[l + 1] === "reset-size" + e.size && (n[i].classes[l + 1] = "reset-size" + t.size), n[i].height *= a, n[i].depth *= a;
  }
  return D.makeFragment(n);
}
var Hi = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], vc = (r, e) => {
  var t = e.havingSize(r.size);
  return Js(r.body, t, e);
};
V({
  type: "sizing",
  names: Hi,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      breakOnTokenText: t,
      funcName: n,
      parser: a
    } = r, i = a.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: a.mode,
      // Figure out what size to use based on the list of functions above
      size: Hi.indexOf(n) + 1,
      body: i
    };
  },
  htmlBuilder: vc,
  mathmlBuilder: (r, e) => {
    var t = e.havingSize(r.size), n = ft(r.body, t), a = new I.MathNode("mstyle", n);
    return a.setAttribute("mathsize", G(t.sizeMultiplier)), a;
  }
});
V({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (r, e, t) => {
    var {
      parser: n
    } = r, a = !1, i = !1, l = t[0] && ae(t[0], "ordgroup");
    if (l)
      for (var s = "", o = 0; o < l.body.length; ++o) {
        var h = l.body[o];
        if (s = h.text, s === "t")
          a = !0;
        else if (s === "b")
          i = !0;
        else {
          a = !1, i = !1;
          break;
        }
      }
    else
      a = !0, i = !0;
    var m = e[0];
    return {
      type: "smash",
      mode: n.mode,
      body: m,
      smashHeight: a,
      smashDepth: i
    };
  },
  htmlBuilder: (r, e) => {
    var t = D.makeSpan([], [oe(r.body, e)]);
    if (!r.smashHeight && !r.smashDepth)
      return t;
    if (r.smashHeight && (t.height = 0, t.children))
      for (var n = 0; n < t.children.length; n++)
        t.children[n].height = 0;
    if (r.smashDepth && (t.depth = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].depth = 0;
    var i = D.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return D.makeSpan(["mord"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new I.MathNode("mpadded", [ye(r.body, e)]);
    return r.smashHeight && t.setAttribute("height", "0px"), r.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
V({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: n
    } = r, a = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: n.mode,
      body: i,
      index: a
    };
  },
  htmlBuilder(r, e) {
    var t = oe(r.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = D.wrapFragment(t, e);
    var n = e.fontMetrics(), a = n.defaultRuleThickness, i = a;
    e.style.id < J.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = a + i / 4, s = t.height + t.depth + l + a, {
      span: o,
      ruleWidth: h,
      advanceWidth: m
    } = b0.sqrtImage(s, e), p = o.height - h;
    p > t.height + t.depth + l && (l = (l + p - t.height - t.depth) / 2);
    var g = o.height - t.height - l - h;
    t.style.paddingLeft = G(m);
    var _ = D.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + g)
      }, {
        type: "elem",
        elem: o
      }, {
        type: "kern",
        size: h
      }]
    }, e);
    if (r.index) {
      var C = e.havingStyle(J.SCRIPTSCRIPT), T = oe(r.index, C, e), F = 0.6 * (_.height - _.depth), M = D.makeVList({
        positionType: "shift",
        positionData: -F,
        children: [{
          type: "elem",
          elem: T
        }]
      }, e), w = D.makeSpan(["root"], [M]);
      return D.makeSpan(["mord", "sqrt"], [w, _], e);
    } else
      return D.makeSpan(["mord", "sqrt"], [_], e);
  },
  mathmlBuilder(r, e) {
    var {
      body: t,
      index: n
    } = r;
    return n ? new I.MathNode("mroot", [ye(t, e), ye(n, e)]) : new I.MathNode("msqrt", [ye(t, e)]);
  }
});
var Ui = {
  display: J.DISPLAY,
  text: J.TEXT,
  script: J.SCRIPT,
  scriptscript: J.SCRIPTSCRIPT
};
V({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      breakOnTokenText: t,
      funcName: n,
      parser: a
    } = r, i = a.parseExpression(!0, t), l = n.slice(1, n.length - 5);
    return {
      type: "styling",
      mode: a.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(r, e) {
    var t = Ui[r.style], n = e.havingStyle(t).withFont("");
    return Js(r.body, n, e);
  },
  mathmlBuilder(r, e) {
    var t = Ui[r.style], n = e.havingStyle(t), a = ft(r.body, n), i = new I.MathNode("mstyle", a), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, s = l[r.style];
    return i.setAttribute("scriptlevel", s[0]), i.setAttribute("displaystyle", s[1]), i;
  }
});
var yc = function(e, t) {
  var n = e.base;
  if (n)
    if (n.type === "op") {
      var a = n.limits && (t.style.size === J.DISPLAY.size || n.alwaysHandleSupSub);
      return a ? ln : null;
    } else if (n.type === "operatorname") {
      var i = n.alwaysHandleSupSub && (t.style.size === J.DISPLAY.size || n.limits);
      return i ? Qs : null;
    } else {
      if (n.type === "accent")
        return Z.isCharacterBox(n.base) ? Na : null;
      if (n.type === "horizBrace") {
        var l = !e.sub;
        return l === n.isOver ? Ys : null;
      } else
        return null;
    }
  else return null;
};
W0({
  type: "supsub",
  htmlBuilder(r, e) {
    var t = yc(r, e);
    if (t)
      return t(r, e);
    var {
      base: n,
      sup: a,
      sub: i
    } = r, l = oe(n, e), s, o, h = e.fontMetrics(), m = 0, p = 0, g = n && Z.isCharacterBox(n);
    if (a) {
      var _ = e.havingStyle(e.style.sup());
      s = oe(a, _, e), g || (m = l.height - _.fontMetrics().supDrop * _.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var C = e.havingStyle(e.style.sub());
      o = oe(i, C, e), g || (p = l.depth + C.fontMetrics().subDrop * C.sizeMultiplier / e.sizeMultiplier);
    }
    var T;
    e.style === J.DISPLAY ? T = h.sup1 : e.style.cramped ? T = h.sup3 : T = h.sup2;
    var F = e.sizeMultiplier, M = G(0.5 / h.ptPerEm / F), w = null;
    if (o) {
      var v = r.base && r.base.type === "op" && r.base.name && (r.base.name === "\\oiint" || r.base.name === "\\oiiint");
      (l instanceof Mt || v) && (w = G(-l.italic));
    }
    var x;
    if (s && o) {
      m = Math.max(m, T, s.depth + 0.25 * h.xHeight), p = Math.max(p, h.sub2);
      var $ = h.defaultRuleThickness, E = 4 * $;
      if (m - s.depth - (o.height - p) < E) {
        p = E - (m - s.depth) + o.height;
        var A = 0.8 * h.xHeight - (m - s.depth);
        A > 0 && (m += A, p -= A);
      }
      var q = [{
        type: "elem",
        elem: o,
        shift: p,
        marginRight: M,
        marginLeft: w
      }, {
        type: "elem",
        elem: s,
        shift: -m,
        marginRight: M
      }];
      x = D.makeVList({
        positionType: "individualShift",
        children: q
      }, e);
    } else if (o) {
      p = Math.max(p, h.sub1, o.height - 0.8 * h.xHeight);
      var B = [{
        type: "elem",
        elem: o,
        marginLeft: w,
        marginRight: M
      }];
      x = D.makeVList({
        positionType: "shift",
        positionData: p,
        children: B
      }, e);
    } else if (s)
      m = Math.max(m, T, s.depth + 0.25 * h.xHeight), x = D.makeVList({
        positionType: "shift",
        positionData: -m,
        children: [{
          type: "elem",
          elem: s,
          marginRight: M
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var z = ha(l, "right") || "mord";
    return D.makeSpan([z], [l, D.makeSpan(["msupsub"], [x])], e);
  },
  mathmlBuilder(r, e) {
    var t = !1, n, a;
    r.base && r.base.type === "horizBrace" && (a = !!r.sup, a === r.base.isOver && (t = !0, n = r.base.isOver)), r.base && (r.base.type === "op" || r.base.type === "operatorname") && (r.base.parentIsSupSub = !0);
    var i = [ye(r.base, e)];
    r.sub && i.push(ye(r.sub, e)), r.sup && i.push(ye(r.sup, e));
    var l;
    if (t)
      l = n ? "mover" : "munder";
    else if (r.sub)
      if (r.sup) {
        var h = r.base;
        h && h.type === "op" && h.limits && e.style === J.DISPLAY || h && h.type === "operatorname" && h.alwaysHandleSupSub && (e.style === J.DISPLAY || h.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var o = r.base;
        o && o.type === "op" && o.limits && (e.style === J.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || e.style === J.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var s = r.base;
      s && s.type === "op" && s.limits && (e.style === J.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || e.style === J.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new I.MathNode(l, i);
  }
});
W0({
  type: "atom",
  htmlBuilder(r, e) {
    return D.mathsym(r.text, r.mode, e, ["m" + r.family]);
  },
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mo", [zt(r.text, r.mode)]);
    if (r.family === "bin") {
      var n = qa(r, e);
      n === "bold-italic" && t.setAttribute("mathvariant", n);
    } else r.family === "punct" ? t.setAttribute("separator", "true") : (r.family === "open" || r.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var eo = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
W0({
  type: "mathord",
  htmlBuilder(r, e) {
    return D.makeOrd(r, e, "mathord");
  },
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mi", [zt(r.text, r.mode, e)]), n = qa(r, e) || "italic";
    return n !== eo[t.type] && t.setAttribute("mathvariant", n), t;
  }
});
W0({
  type: "textord",
  htmlBuilder(r, e) {
    return D.makeOrd(r, e, "textord");
  },
  mathmlBuilder(r, e) {
    var t = zt(r.text, r.mode, e), n = qa(r, e) || "normal", a;
    return r.mode === "text" ? a = new I.MathNode("mtext", [t]) : /[0-9]/.test(r.text) ? a = new I.MathNode("mn", [t]) : r.text === "\\prime" ? a = new I.MathNode("mo", [t]) : a = new I.MathNode("mi", [t]), n !== eo[a.type] && a.setAttribute("mathvariant", n), a;
  }
});
var jr = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, Xr = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
W0({
  type: "spacing",
  htmlBuilder(r, e) {
    if (Xr.hasOwnProperty(r.text)) {
      var t = Xr[r.text].className || "";
      if (r.mode === "text") {
        var n = D.makeOrd(r, e, "textord");
        return n.classes.push(t), n;
      } else
        return D.makeSpan(["mspace", t], [D.mathsym(r.text, r.mode, e)], e);
    } else {
      if (jr.hasOwnProperty(r.text))
        return D.makeSpan(["mspace", jr[r.text]], [], e);
      throw new O('Unknown type of space "' + r.text + '"');
    }
  },
  mathmlBuilder(r, e) {
    var t;
    if (Xr.hasOwnProperty(r.text))
      t = new I.MathNode("mtext", [new I.TextNode(" ")]);
    else {
      if (jr.hasOwnProperty(r.text))
        return new I.MathNode("mspace");
      throw new O('Unknown type of space "' + r.text + '"');
    }
    return t;
  }
});
var Gi = () => {
  var r = new I.MathNode("mtd", []);
  return r.setAttribute("width", "50%"), r;
};
W0({
  type: "tag",
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mtable", [new I.MathNode("mtr", [Gi(), new I.MathNode("mtd", [B0(r.body, e)]), Gi(), new I.MathNode("mtd", [B0(r.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var Vi = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, Wi = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, bc = {
  "\\textit": "textit",
  "\\textup": "textup"
}, ji = (r, e) => {
  var t = r.font;
  if (t) {
    if (Vi[t])
      return e.withTextFontFamily(Vi[t]);
    if (Wi[t])
      return e.withTextFontWeight(Wi[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(bc[t]);
};
V({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: n
    } = r, a = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: Re(a),
      font: n
    };
  },
  htmlBuilder(r, e) {
    var t = ji(r, e), n = He(r.body, t, !0);
    return D.makeSpan(["mord", "text"], n, t);
  },
  mathmlBuilder(r, e) {
    var t = ji(r, e);
    return B0(r.body, t);
  }
});
V({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = oe(r.body, e), n = D.makeLineSpan("underline-line", e), a = e.fontMetrics().defaultRuleThickness, i = D.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return D.makeSpan(["mord", "underline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new I.MathNode("mo", [new I.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var n = new I.MathNode("munder", [ye(r.body, e), t]);
    return n.setAttribute("accentunder", "true"), n;
  }
});
V({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = oe(r.body, e), n = e.fontMetrics().axisHeight, a = 0.5 * (t.height - n - (t.depth + n));
    return D.makeVList({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    return new I.MathNode("mpadded", [ye(r.body, e)], ["vcenter"]);
  }
});
V({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    throw new O("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(r, e) {
    for (var t = Xi(r), n = [], a = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), n.push(D.makeSymbol(l, "Typewriter-Regular", r.mode, a, ["mord", "texttt"]));
    }
    return D.makeSpan(["mord", "text"].concat(a.sizingClasses(e)), D.tryCombineChars(n), a);
  },
  mathmlBuilder(r, e) {
    var t = new I.TextNode(Xi(r)), n = new I.MathNode("mtext", [t]);
    return n.setAttribute("mathvariant", "monospace"), n;
  }
});
var Xi = (r) => r.body.replace(/ /g, r.star ? "␣" : " "), F0 = ks, to = `[ \r
	]`, wc = "\\\\[a-zA-Z@]+", xc = "\\\\[^\uD800-\uDFFF]", kc = "(" + wc + ")" + to + "*", Sc = `\\\\(
|[ \r	]+
?)[ \r	]*`, pa = "[̀-ͯ]", $c = new RegExp(pa + "+$"), Dc = "(" + to + "+)|" + // whitespace
(Sc + "|") + // \whitespace
"([!-\\[\\]-‧‪-퟿豈-￿]" + // single codepoint
(pa + "*") + // ...plus accents
"|[\uD800-\uDBFF][\uDC00-\uDFFF]" + // surrogate pair
(pa + "*") + // ...plus accents
"|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + // \verb unstarred
("|" + kc) + // \macroName + spaces
("|" + xc + ")");
class Yi {
  // Category codes. The lexer only supports comment characters (14) for now.
  // MacroExpander additionally distinguishes active (13).
  constructor(e, t) {
    this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = e, this.settings = t, this.tokenRegex = new RegExp(Dc, "g"), this.catcodes = {
      "%": 14,
      // comment character
      "~": 13
      // active character
    };
  }
  setCatcode(e, t) {
    this.catcodes[e] = t;
  }
  /**
   * This function lexes a single token.
   */
  lex() {
    var e = this.input, t = this.tokenRegex.lastIndex;
    if (t === e.length)
      return new Ft("EOF", new _t(this, t, t));
    var n = this.tokenRegex.exec(e);
    if (n === null || n.index !== t)
      throw new O("Unexpected character: '" + e[t] + "'", new Ft(e[t], new _t(this, t, t + 1)));
    var a = n[6] || n[3] || (n[2] ? "\\ " : " ");
    if (this.catcodes[a] === 14) {
      var i = e.indexOf(`
`, this.tokenRegex.lastIndex);
      return i === -1 ? (this.tokenRegex.lastIndex = e.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = i + 1, this.lex();
    }
    return new Ft(a, new _t(this, t, this.tokenRegex.lastIndex));
  }
}
class Ac {
  /**
   * Both arguments are optional.  The first argument is an object of
   * built-in mappings which never change.  The second argument is an object
   * of initial (global-level) mappings, which will constantly change
   * according to any global/top-level `set`s done.
   */
  constructor(e, t) {
    e === void 0 && (e = {}), t === void 0 && (t = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = t, this.builtins = e, this.undefStack = [];
  }
  /**
   * Start a new nested group, affecting future local `set`s.
   */
  beginGroup() {
    this.undefStack.push({});
  }
  /**
   * End current nested group, restoring values before the group began.
   */
  endGroup() {
    if (this.undefStack.length === 0)
      throw new O("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
    var e = this.undefStack.pop();
    for (var t in e)
      e.hasOwnProperty(t) && (e[t] == null ? delete this.current[t] : this.current[t] = e[t]);
  }
  /**
   * Ends all currently nested groups (if any), restoring values before the
   * groups began.  Useful in case of an error in the middle of parsing.
   */
  endGroups() {
    for (; this.undefStack.length > 0; )
      this.endGroup();
  }
  /**
   * Detect whether `name` has a definition.  Equivalent to
   * `get(name) != null`.
   */
  has(e) {
    return this.current.hasOwnProperty(e) || this.builtins.hasOwnProperty(e);
  }
  /**
   * Get the current value of a name, or `undefined` if there is no value.
   *
   * Note: Do not use `if (namespace.get(...))` to detect whether a macro
   * is defined, as the definition may be the empty string which evaluates
   * to `false` in JavaScript.  Use `if (namespace.get(...) != null)` or
   * `if (namespace.has(...))`.
   */
  get(e) {
    return this.current.hasOwnProperty(e) ? this.current[e] : this.builtins[e];
  }
  /**
   * Set the current value of a name, and optionally set it globally too.
   * Local set() sets the current value and (when appropriate) adds an undo
   * operation to the undo stack.  Global set() may change the undo
   * operation at every level, so takes time linear in their number.
   * A value of undefined means to delete existing definitions.
   */
  set(e, t, n) {
    if (n === void 0 && (n = !1), n) {
      for (var a = 0; a < this.undefStack.length; a++)
        delete this.undefStack[a][e];
      this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][e] = t);
    } else {
      var i = this.undefStack[this.undefStack.length - 1];
      i && !i.hasOwnProperty(e) && (i[e] = this.current[e]);
    }
    t == null ? delete this.current[e] : this.current[e] = t;
  }
}
var Cc = Gs;
f("\\noexpand", function(r) {
  var e = r.popToken();
  return r.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
f("\\expandafter", function(r) {
  var e = r.popToken();
  return r.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
f("\\@firstoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
f("\\@secondoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
f("\\@ifnextchar", function(r) {
  var e = r.consumeArgs(3);
  r.consumeSpaces();
  var t = r.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
f("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
f("\\TextOrMath", function(r) {
  var e = r.consumeArgs(2);
  return r.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var Zi = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
f("\\char", function(r) {
  var e = r.popToken(), t, n = "";
  if (e.text === "'")
    t = 8, e = r.popToken();
  else if (e.text === '"')
    t = 16, e = r.popToken();
  else if (e.text === "`")
    if (e = r.popToken(), e.text[0] === "\\")
      n = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new O("\\char` missing argument");
      n = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (n = Zi[e.text], n == null || n >= t)
      throw new O("Invalid base-" + t + " digit " + e.text);
    for (var a; (a = Zi[r.future().text]) != null && a < t; )
      n *= t, n += a, r.popToken();
  }
  return "\\@char{" + n + "}";
});
var Va = (r, e, t, n) => {
  var a = r.consumeArg().tokens;
  if (a.length !== 1)
    throw new O("\\newcommand's first argument must be a macro name");
  var i = a[0].text, l = r.isDefined(i);
  if (l && !e)
    throw new O("\\newcommand{" + i + "} attempting to redefine " + (i + "; use \\renewcommand"));
  if (!l && !t)
    throw new O("\\renewcommand{" + i + "} when command " + i + " does not yet exist; use \\newcommand");
  var s = 0;
  if (a = r.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
    for (var o = "", h = r.expandNextToken(); h.text !== "]" && h.text !== "EOF"; )
      o += h.text, h = r.expandNextToken();
    if (!o.match(/^\s*[0-9]+\s*$/))
      throw new O("Invalid number of arguments: " + o);
    s = parseInt(o), a = r.consumeArg().tokens;
  }
  return l && n || r.macros.set(i, {
    tokens: a,
    numArgs: s
  }), "";
};
f("\\newcommand", (r) => Va(r, !1, !0, !1));
f("\\renewcommand", (r) => Va(r, !0, !1, !1));
f("\\providecommand", (r) => Va(r, !0, !0, !0));
f("\\message", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
f("\\errmessage", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
f("\\show", (r) => {
  var e = r.popToken(), t = e.text;
  return console.log(e, r.macros.get(t), F0[t], be.math[t], be.text[t]), "";
});
f("\\bgroup", "{");
f("\\egroup", "}");
f("~", "\\nobreakspace");
f("\\lq", "`");
f("\\rq", "'");
f("\\aa", "\\r a");
f("\\AA", "\\r A");
f("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
f("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
f("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
f("ℬ", "\\mathscr{B}");
f("ℰ", "\\mathscr{E}");
f("ℱ", "\\mathscr{F}");
f("ℋ", "\\mathscr{H}");
f("ℐ", "\\mathscr{I}");
f("ℒ", "\\mathscr{L}");
f("ℳ", "\\mathscr{M}");
f("ℛ", "\\mathscr{R}");
f("ℭ", "\\mathfrak{C}");
f("ℌ", "\\mathfrak{H}");
f("ℨ", "\\mathfrak{Z}");
f("\\Bbbk", "\\Bbb{k}");
f("·", "\\cdotp");
f("\\llap", "\\mathllap{\\textrm{#1}}");
f("\\rlap", "\\mathrlap{\\textrm{#1}}");
f("\\clap", "\\mathclap{\\textrm{#1}}");
f("\\mathstrut", "\\vphantom{(}");
f("\\underbar", "\\underline{\\text{#1}}");
f("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
f("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
f("\\ne", "\\neq");
f("≠", "\\neq");
f("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
f("∉", "\\notin");
f("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
f("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
f("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
f("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
f("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
f("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
f("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
f("⟂", "\\perp");
f("‼", "\\mathclose{!\\mkern-0.8mu!}");
f("∌", "\\notni");
f("⌜", "\\ulcorner");
f("⌝", "\\urcorner");
f("⌞", "\\llcorner");
f("⌟", "\\lrcorner");
f("©", "\\copyright");
f("®", "\\textregistered");
f("️", "\\textregistered");
f("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
f("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
f("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
f("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
f("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
f("⋮", "\\vdots");
f("\\varGamma", "\\mathit{\\Gamma}");
f("\\varDelta", "\\mathit{\\Delta}");
f("\\varTheta", "\\mathit{\\Theta}");
f("\\varLambda", "\\mathit{\\Lambda}");
f("\\varXi", "\\mathit{\\Xi}");
f("\\varPi", "\\mathit{\\Pi}");
f("\\varSigma", "\\mathit{\\Sigma}");
f("\\varUpsilon", "\\mathit{\\Upsilon}");
f("\\varPhi", "\\mathit{\\Phi}");
f("\\varPsi", "\\mathit{\\Psi}");
f("\\varOmega", "\\mathit{\\Omega}");
f("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
f("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
f("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
f("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
f("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
f("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
f("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
f("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var Ki = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
f("\\dots", function(r) {
  var e = "\\dotso", t = r.expandAfterFuture().text;
  return t in Ki ? e = Ki[t] : (t.slice(0, 4) === "\\not" || t in be.math && Z.contains(["bin", "rel"], be.math[t].group)) && (e = "\\dotsb"), e;
});
var Wa = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
f("\\dotso", function(r) {
  var e = r.future().text;
  return e in Wa ? "\\ldots\\," : "\\ldots";
});
f("\\dotsc", function(r) {
  var e = r.future().text;
  return e in Wa && e !== "," ? "\\ldots\\," : "\\ldots";
});
f("\\cdots", function(r) {
  var e = r.future().text;
  return e in Wa ? "\\@cdots\\," : "\\@cdots";
});
f("\\dotsb", "\\cdots");
f("\\dotsm", "\\cdots");
f("\\dotsi", "\\!\\cdots");
f("\\dotsx", "\\ldots\\,");
f("\\DOTSI", "\\relax");
f("\\DOTSB", "\\relax");
f("\\DOTSX", "\\relax");
f("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
f("\\,", "\\tmspace+{3mu}{.1667em}");
f("\\thinspace", "\\,");
f("\\>", "\\mskip{4mu}");
f("\\:", "\\tmspace+{4mu}{.2222em}");
f("\\medspace", "\\:");
f("\\;", "\\tmspace+{5mu}{.2777em}");
f("\\thickspace", "\\;");
f("\\!", "\\tmspace-{3mu}{.1667em}");
f("\\negthinspace", "\\!");
f("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
f("\\negthickspace", "\\tmspace-{5mu}{.277em}");
f("\\enspace", "\\kern.5em ");
f("\\enskip", "\\hskip.5em\\relax");
f("\\quad", "\\hskip1em\\relax");
f("\\qquad", "\\hskip2em\\relax");
f("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
f("\\tag@paren", "\\tag@literal{({#1})}");
f("\\tag@literal", (r) => {
  if (r.macros.get("\\df@tag"))
    throw new O("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
f("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
f("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
f("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
f("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
f("\\newline", "\\\\\\relax");
f("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var no = G(Qt["Main-Regular"][84][1] - 0.7 * Qt["Main-Regular"][65][1]);
f("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + no + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
f("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + no + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
f("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
f("\\@hspace", "\\hskip #1\\relax");
f("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
f("\\ordinarycolon", ":");
f("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
f("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
f("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
f("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
f("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
f("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
f("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
f("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
f("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
f("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
f("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
f("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
f("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
f("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
f("∷", "\\dblcolon");
f("∹", "\\eqcolon");
f("≔", "\\coloneqq");
f("≕", "\\eqqcolon");
f("⩴", "\\Coloneqq");
f("\\ratio", "\\vcentcolon");
f("\\coloncolon", "\\dblcolon");
f("\\colonequals", "\\coloneqq");
f("\\coloncolonequals", "\\Coloneqq");
f("\\equalscolon", "\\eqqcolon");
f("\\equalscoloncolon", "\\Eqqcolon");
f("\\colonminus", "\\coloneq");
f("\\coloncolonminus", "\\Coloneq");
f("\\minuscolon", "\\eqcolon");
f("\\minuscoloncolon", "\\Eqcolon");
f("\\coloncolonapprox", "\\Colonapprox");
f("\\coloncolonsim", "\\Colonsim");
f("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
f("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
f("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
f("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
f("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
f("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
f("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
f("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
f("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
f("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
f("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
f("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
f("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
f("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
f("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
f("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
f("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
f("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
f("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
f("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
f("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
f("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
f("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
f("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
f("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
f("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
f("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
f("\\imath", "\\html@mathml{\\@imath}{ı}");
f("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
f("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
f("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
f("⟦", "\\llbracket");
f("⟧", "\\rrbracket");
f("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
f("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
f("⦃", "\\lBrace");
f("⦄", "\\rBrace");
f("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
f("⦵", "\\minuso");
f("\\darr", "\\downarrow");
f("\\dArr", "\\Downarrow");
f("\\Darr", "\\Downarrow");
f("\\lang", "\\langle");
f("\\rang", "\\rangle");
f("\\uarr", "\\uparrow");
f("\\uArr", "\\Uparrow");
f("\\Uarr", "\\Uparrow");
f("\\N", "\\mathbb{N}");
f("\\R", "\\mathbb{R}");
f("\\Z", "\\mathbb{Z}");
f("\\alef", "\\aleph");
f("\\alefsym", "\\aleph");
f("\\Alpha", "\\mathrm{A}");
f("\\Beta", "\\mathrm{B}");
f("\\bull", "\\bullet");
f("\\Chi", "\\mathrm{X}");
f("\\clubs", "\\clubsuit");
f("\\cnums", "\\mathbb{C}");
f("\\Complex", "\\mathbb{C}");
f("\\Dagger", "\\ddagger");
f("\\diamonds", "\\diamondsuit");
f("\\empty", "\\emptyset");
f("\\Epsilon", "\\mathrm{E}");
f("\\Eta", "\\mathrm{H}");
f("\\exist", "\\exists");
f("\\harr", "\\leftrightarrow");
f("\\hArr", "\\Leftrightarrow");
f("\\Harr", "\\Leftrightarrow");
f("\\hearts", "\\heartsuit");
f("\\image", "\\Im");
f("\\infin", "\\infty");
f("\\Iota", "\\mathrm{I}");
f("\\isin", "\\in");
f("\\Kappa", "\\mathrm{K}");
f("\\larr", "\\leftarrow");
f("\\lArr", "\\Leftarrow");
f("\\Larr", "\\Leftarrow");
f("\\lrarr", "\\leftrightarrow");
f("\\lrArr", "\\Leftrightarrow");
f("\\Lrarr", "\\Leftrightarrow");
f("\\Mu", "\\mathrm{M}");
f("\\natnums", "\\mathbb{N}");
f("\\Nu", "\\mathrm{N}");
f("\\Omicron", "\\mathrm{O}");
f("\\plusmn", "\\pm");
f("\\rarr", "\\rightarrow");
f("\\rArr", "\\Rightarrow");
f("\\Rarr", "\\Rightarrow");
f("\\real", "\\Re");
f("\\reals", "\\mathbb{R}");
f("\\Reals", "\\mathbb{R}");
f("\\Rho", "\\mathrm{P}");
f("\\sdot", "\\cdot");
f("\\sect", "\\S");
f("\\spades", "\\spadesuit");
f("\\sub", "\\subset");
f("\\sube", "\\subseteq");
f("\\supe", "\\supseteq");
f("\\Tau", "\\mathrm{T}");
f("\\thetasym", "\\vartheta");
f("\\weierp", "\\wp");
f("\\Zeta", "\\mathrm{Z}");
f("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
f("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
f("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
f("\\bra", "\\mathinner{\\langle{#1}|}");
f("\\ket", "\\mathinner{|{#1}\\rangle}");
f("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
f("\\Bra", "\\left\\langle#1\\right|");
f("\\Ket", "\\left|#1\\right\\rangle");
var ro = (r) => (e) => {
  var t = e.consumeArg().tokens, n = e.consumeArg().tokens, a = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), s = e.macros.get("\\|");
  e.macros.beginGroup();
  var o = (p) => (g) => {
    r && (g.macros.set("|", l), a.length && g.macros.set("\\|", s));
    var _ = p;
    if (!p && a.length) {
      var C = g.future();
      C.text === "|" && (g.popToken(), _ = !0);
    }
    return {
      tokens: _ ? a : n,
      numArgs: 0
    };
  };
  e.macros.set("|", o(!1)), a.length && e.macros.set("\\|", o(!0));
  var h = e.consumeArg().tokens, m = e.expandTokens([
    ...i,
    ...h,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: m.reverse(),
    numArgs: 0
  };
};
f("\\bra@ket", ro(!1));
f("\\bra@set", ro(!0));
f("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
f("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
f("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
f("\\angln", "{\\angl n}");
f("\\blue", "\\textcolor{##6495ed}{#1}");
f("\\orange", "\\textcolor{##ffa500}{#1}");
f("\\pink", "\\textcolor{##ff00af}{#1}");
f("\\red", "\\textcolor{##df0030}{#1}");
f("\\green", "\\textcolor{##28ae7b}{#1}");
f("\\gray", "\\textcolor{gray}{#1}");
f("\\purple", "\\textcolor{##9d38bd}{#1}");
f("\\blueA", "\\textcolor{##ccfaff}{#1}");
f("\\blueB", "\\textcolor{##80f6ff}{#1}");
f("\\blueC", "\\textcolor{##63d9ea}{#1}");
f("\\blueD", "\\textcolor{##11accd}{#1}");
f("\\blueE", "\\textcolor{##0c7f99}{#1}");
f("\\tealA", "\\textcolor{##94fff5}{#1}");
f("\\tealB", "\\textcolor{##26edd5}{#1}");
f("\\tealC", "\\textcolor{##01d1c1}{#1}");
f("\\tealD", "\\textcolor{##01a995}{#1}");
f("\\tealE", "\\textcolor{##208170}{#1}");
f("\\greenA", "\\textcolor{##b6ffb0}{#1}");
f("\\greenB", "\\textcolor{##8af281}{#1}");
f("\\greenC", "\\textcolor{##74cf70}{#1}");
f("\\greenD", "\\textcolor{##1fab54}{#1}");
f("\\greenE", "\\textcolor{##0d923f}{#1}");
f("\\goldA", "\\textcolor{##ffd0a9}{#1}");
f("\\goldB", "\\textcolor{##ffbb71}{#1}");
f("\\goldC", "\\textcolor{##ff9c39}{#1}");
f("\\goldD", "\\textcolor{##e07d10}{#1}");
f("\\goldE", "\\textcolor{##a75a05}{#1}");
f("\\redA", "\\textcolor{##fca9a9}{#1}");
f("\\redB", "\\textcolor{##ff8482}{#1}");
f("\\redC", "\\textcolor{##f9685d}{#1}");
f("\\redD", "\\textcolor{##e84d39}{#1}");
f("\\redE", "\\textcolor{##bc2612}{#1}");
f("\\maroonA", "\\textcolor{##ffbde0}{#1}");
f("\\maroonB", "\\textcolor{##ff92c6}{#1}");
f("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
f("\\maroonD", "\\textcolor{##ca337c}{#1}");
f("\\maroonE", "\\textcolor{##9e034e}{#1}");
f("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
f("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
f("\\purpleC", "\\textcolor{##aa87ff}{#1}");
f("\\purpleD", "\\textcolor{##7854ab}{#1}");
f("\\purpleE", "\\textcolor{##543b78}{#1}");
f("\\mintA", "\\textcolor{##f5f9e8}{#1}");
f("\\mintB", "\\textcolor{##edf2df}{#1}");
f("\\mintC", "\\textcolor{##e0e5cc}{#1}");
f("\\grayA", "\\textcolor{##f6f7f7}{#1}");
f("\\grayB", "\\textcolor{##f0f1f2}{#1}");
f("\\grayC", "\\textcolor{##e3e5e6}{#1}");
f("\\grayD", "\\textcolor{##d6d8da}{#1}");
f("\\grayE", "\\textcolor{##babec2}{#1}");
f("\\grayF", "\\textcolor{##888d93}{#1}");
f("\\grayG", "\\textcolor{##626569}{#1}");
f("\\grayH", "\\textcolor{##3b3e40}{#1}");
f("\\grayI", "\\textcolor{##21242c}{#1}");
f("\\kaBlue", "\\textcolor{##314453}{#1}");
f("\\kaGreen", "\\textcolor{##71B307}{#1}");
var ao = {
  "^": !0,
  // Parser.js
  _: !0,
  // Parser.js
  "\\limits": !0,
  // Parser.js
  "\\nolimits": !0
  // Parser.js
};
class Ec {
  constructor(e, t, n) {
    this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = t, this.expansionCount = 0, this.feed(e), this.macros = new Ac(Cc, t.macros), this.mode = n, this.stack = [];
  }
  /**
   * Feed a new input string to the same MacroExpander
   * (with existing macros etc.).
   */
  feed(e) {
    this.lexer = new Yi(e, this.settings);
  }
  /**
   * Switches between "text" and "math" modes.
   */
  switchMode(e) {
    this.mode = e;
  }
  /**
   * Start a new group nesting within all namespaces.
   */
  beginGroup() {
    this.macros.beginGroup();
  }
  /**
   * End current group nesting within all namespaces.
   */
  endGroup() {
    this.macros.endGroup();
  }
  /**
   * Ends all currently nested groups (if any), restoring values before the
   * groups began.  Useful in case of an error in the middle of parsing.
   */
  endGroups() {
    this.macros.endGroups();
  }
  /**
   * Returns the topmost token on the stack, without expanding it.
   * Similar in behavior to TeX's `\futurelet`.
   */
  future() {
    return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
  }
  /**
   * Remove and return the next unexpanded token.
   */
  popToken() {
    return this.future(), this.stack.pop();
  }
  /**
   * Add a given token to the token stack.  In particular, this get be used
   * to put back a token returned from one of the other methods.
   */
  pushToken(e) {
    this.stack.push(e);
  }
  /**
   * Append an array of tokens to the token stack.
   */
  pushTokens(e) {
    this.stack.push(...e);
  }
  /**
   * Find an macro argument without expanding tokens and append the array of
   * tokens to the token stack. Uses Token as a container for the result.
   */
  scanArgument(e) {
    var t, n, a;
    if (e) {
      if (this.consumeSpaces(), this.future().text !== "[")
        return null;
      t = this.popToken(), {
        tokens: a,
        end: n
      } = this.consumeArg(["]"]);
    } else
      ({
        tokens: a,
        start: t,
        end: n
      } = this.consumeArg());
    return this.pushToken(new Ft("EOF", n.loc)), this.pushTokens(a), t.range(n, "");
  }
  /**
   * Consume all following space tokens, without expansion.
   */
  consumeSpaces() {
    for (; ; ) {
      var e = this.future();
      if (e.text === " ")
        this.stack.pop();
      else
        break;
    }
  }
  /**
   * Consume an argument from the token stream, and return the resulting array
   * of tokens and start/end token.
   */
  consumeArg(e) {
    var t = [], n = e && e.length > 0;
    n || this.consumeSpaces();
    var a = this.future(), i, l = 0, s = 0;
    do {
      if (i = this.popToken(), t.push(i), i.text === "{")
        ++l;
      else if (i.text === "}") {
        if (--l, l === -1)
          throw new O("Extra }", i);
      } else if (i.text === "EOF")
        throw new O("Unexpected end of input in a macro argument, expected '" + (e && n ? e[s] : "}") + "'", i);
      if (e && n)
        if ((l === 0 || l === 1 && e[s] === "{") && i.text === e[s]) {
          if (++s, s === e.length) {
            t.splice(-s, s);
            break;
          }
        } else
          s = 0;
    } while (l !== 0 || n);
    return a.text === "{" && t[t.length - 1].text === "}" && (t.pop(), t.shift()), t.reverse(), {
      tokens: t,
      start: a,
      end: i
    };
  }
  /**
   * Consume the specified number of (delimited) arguments from the token
   * stream and return the resulting array of arguments.
   */
  consumeArgs(e, t) {
    if (t) {
      if (t.length !== e + 1)
        throw new O("The length of delimiters doesn't match the number of args!");
      for (var n = t[0], a = 0; a < n.length; a++) {
        var i = this.popToken();
        if (n[a] !== i.text)
          throw new O("Use of the macro doesn't match its definition", i);
      }
    }
    for (var l = [], s = 0; s < e; s++)
      l.push(this.consumeArg(t && t[s + 1]).tokens);
    return l;
  }
  /**
   * Increment `expansionCount` by the specified amount.
   * Throw an error if it exceeds `maxExpand`.
   */
  countExpansion(e) {
    if (this.expansionCount += e, this.expansionCount > this.settings.maxExpand)
      throw new O("Too many expansions: infinite loop or need to increase maxExpand setting");
  }
  /**
   * Expand the next token only once if possible.
   *
   * If the token is expanded, the resulting tokens will be pushed onto
   * the stack in reverse order, and the number of such tokens will be
   * returned.  This number might be zero or positive.
   *
   * If not, the return value is `false`, and the next token remains at the
   * top of the stack.
   *
   * In either case, the next token will be on the top of the stack,
   * or the stack will be empty (in case of empty expansion
   * and no other tokens).
   *
   * Used to implement `expandAfterFuture` and `expandNextToken`.
   *
   * If expandableOnly, only expandable tokens are expanded and
   * an undefined control sequence results in an error.
   */
  expandOnce(e) {
    var t = this.popToken(), n = t.text, a = t.noexpand ? null : this._getExpansion(n);
    if (a == null || e && a.unexpandable) {
      if (e && a == null && n[0] === "\\" && !this.isDefined(n))
        throw new O("Undefined control sequence: " + n);
      return this.pushToken(t), !1;
    }
    this.countExpansion(1);
    var i = a.tokens, l = this.consumeArgs(a.numArgs, a.delimiters);
    if (a.numArgs) {
      i = i.slice();
      for (var s = i.length - 1; s >= 0; --s) {
        var o = i[s];
        if (o.text === "#") {
          if (s === 0)
            throw new O("Incomplete placeholder at end of macro body", o);
          if (o = i[--s], o.text === "#")
            i.splice(s + 1, 1);
          else if (/^[1-9]$/.test(o.text))
            i.splice(s, 2, ...l[+o.text - 1]);
          else
            throw new O("Not a valid argument number", o);
        }
      }
    }
    return this.pushTokens(i), i.length;
  }
  /**
   * Expand the next token only once (if possible), and return the resulting
   * top token on the stack (without removing anything from the stack).
   * Similar in behavior to TeX's `\expandafter\futurelet`.
   * Equivalent to expandOnce() followed by future().
   */
  expandAfterFuture() {
    return this.expandOnce(), this.future();
  }
  /**
   * Recursively expand first token, then return first non-expandable token.
   */
  expandNextToken() {
    for (; ; )
      if (this.expandOnce() === !1) {
        var e = this.stack.pop();
        return e.treatAsRelax && (e.text = "\\relax"), e;
      }
    throw new Error();
  }
  /**
   * Fully expand the given macro name and return the resulting list of
   * tokens, or return `undefined` if no such macro is defined.
   */
  expandMacro(e) {
    return this.macros.has(e) ? this.expandTokens([new Ft(e)]) : void 0;
  }
  /**
   * Fully expand the given token stream and return the resulting list of
   * tokens.  Note that the input tokens are in reverse order, but the
   * output tokens are in forward order.
   */
  expandTokens(e) {
    var t = [], n = this.stack.length;
    for (this.pushTokens(e); this.stack.length > n; )
      if (this.expandOnce(!0) === !1) {
        var a = this.stack.pop();
        a.treatAsRelax && (a.noexpand = !1, a.treatAsRelax = !1), t.push(a);
      }
    return this.countExpansion(t.length), t;
  }
  /**
   * Fully expand the given macro name and return the result as a string,
   * or return `undefined` if no such macro is defined.
   */
  expandMacroAsText(e) {
    var t = this.expandMacro(e);
    return t && t.map((n) => n.text).join("");
  }
  /**
   * Returns the expanded macro as a reversed array of tokens and a macro
   * argument count.  Or returns `null` if no such macro.
   */
  _getExpansion(e) {
    var t = this.macros.get(e);
    if (t == null)
      return t;
    if (e.length === 1) {
      var n = this.lexer.catcodes[e];
      if (n != null && n !== 13)
        return;
    }
    var a = typeof t == "function" ? t(this) : t;
    if (typeof a == "string") {
      var i = 0;
      if (a.indexOf("#") !== -1)
        for (var l = a.replace(/##/g, ""); l.indexOf("#" + (i + 1)) !== -1; )
          ++i;
      for (var s = new Yi(a, this.settings), o = [], h = s.lex(); h.text !== "EOF"; )
        o.push(h), h = s.lex();
      o.reverse();
      var m = {
        tokens: o,
        numArgs: i
      };
      return m;
    }
    return a;
  }
  /**
   * Determine whether a command is currently "defined" (has some
   * functionality), meaning that it's a macro (in the current group),
   * a function, a symbol, or one of the special commands listed in
   * `implicitCommands`.
   */
  isDefined(e) {
    return this.macros.has(e) || F0.hasOwnProperty(e) || be.math.hasOwnProperty(e) || be.text.hasOwnProperty(e) || ao.hasOwnProperty(e);
  }
  /**
   * Determine whether a command is expandable.
   */
  isExpandable(e) {
    var t = this.macros.get(e);
    return t != null ? typeof t == "string" || typeof t == "function" || !t.unexpandable : F0.hasOwnProperty(e) && !F0[e].primitive;
  }
}
var Qi = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, Gn = Object.freeze({
  "₊": "+",
  "₋": "-",
  "₌": "=",
  "₍": "(",
  "₎": ")",
  "₀": "0",
  "₁": "1",
  "₂": "2",
  "₃": "3",
  "₄": "4",
  "₅": "5",
  "₆": "6",
  "₇": "7",
  "₈": "8",
  "₉": "9",
  "ₐ": "a",
  "ₑ": "e",
  "ₕ": "h",
  "ᵢ": "i",
  "ⱼ": "j",
  "ₖ": "k",
  "ₗ": "l",
  "ₘ": "m",
  "ₙ": "n",
  "ₒ": "o",
  "ₚ": "p",
  "ᵣ": "r",
  "ₛ": "s",
  "ₜ": "t",
  "ᵤ": "u",
  "ᵥ": "v",
  "ₓ": "x",
  "ᵦ": "β",
  "ᵧ": "γ",
  "ᵨ": "ρ",
  "ᵩ": "ϕ",
  "ᵪ": "χ",
  "⁺": "+",
  "⁻": "-",
  "⁼": "=",
  "⁽": "(",
  "⁾": ")",
  "⁰": "0",
  "¹": "1",
  "²": "2",
  "³": "3",
  "⁴": "4",
  "⁵": "5",
  "⁶": "6",
  "⁷": "7",
  "⁸": "8",
  "⁹": "9",
  "ᴬ": "A",
  "ᴮ": "B",
  "ᴰ": "D",
  "ᴱ": "E",
  "ᴳ": "G",
  "ᴴ": "H",
  "ᴵ": "I",
  "ᴶ": "J",
  "ᴷ": "K",
  "ᴸ": "L",
  "ᴹ": "M",
  "ᴺ": "N",
  "ᴼ": "O",
  "ᴾ": "P",
  "ᴿ": "R",
  "ᵀ": "T",
  "ᵁ": "U",
  "ⱽ": "V",
  "ᵂ": "W",
  "ᵃ": "a",
  "ᵇ": "b",
  "ᶜ": "c",
  "ᵈ": "d",
  "ᵉ": "e",
  "ᶠ": "f",
  "ᵍ": "g",
  ʰ: "h",
  "ⁱ": "i",
  ʲ: "j",
  "ᵏ": "k",
  ˡ: "l",
  "ᵐ": "m",
  ⁿ: "n",
  "ᵒ": "o",
  "ᵖ": "p",
  ʳ: "r",
  ˢ: "s",
  "ᵗ": "t",
  "ᵘ": "u",
  "ᵛ": "v",
  ʷ: "w",
  ˣ: "x",
  ʸ: "y",
  "ᶻ": "z",
  "ᵝ": "β",
  "ᵞ": "γ",
  "ᵟ": "δ",
  "ᵠ": "ϕ",
  "ᵡ": "χ",
  "ᶿ": "θ"
}), Yr = {
  "́": {
    text: "\\'",
    math: "\\acute"
  },
  "̀": {
    text: "\\`",
    math: "\\grave"
  },
  "̈": {
    text: '\\"',
    math: "\\ddot"
  },
  "̃": {
    text: "\\~",
    math: "\\tilde"
  },
  "̄": {
    text: "\\=",
    math: "\\bar"
  },
  "̆": {
    text: "\\u",
    math: "\\breve"
  },
  "̌": {
    text: "\\v",
    math: "\\check"
  },
  "̂": {
    text: "\\^",
    math: "\\hat"
  },
  "̇": {
    text: "\\.",
    math: "\\dot"
  },
  "̊": {
    text: "\\r",
    math: "\\mathring"
  },
  "̋": {
    text: "\\H"
  },
  "̧": {
    text: "\\c"
  }
}, Ji = {
  á: "á",
  à: "à",
  ä: "ä",
  ǟ: "ǟ",
  ã: "ã",
  ā: "ā",
  ă: "ă",
  ắ: "ắ",
  ằ: "ằ",
  ẵ: "ẵ",
  ǎ: "ǎ",
  â: "â",
  ấ: "ấ",
  ầ: "ầ",
  ẫ: "ẫ",
  ȧ: "ȧ",
  ǡ: "ǡ",
  å: "å",
  ǻ: "ǻ",
  ḃ: "ḃ",
  ć: "ć",
  ḉ: "ḉ",
  č: "č",
  ĉ: "ĉ",
  ċ: "ċ",
  ç: "ç",
  ď: "ď",
  ḋ: "ḋ",
  ḑ: "ḑ",
  é: "é",
  è: "è",
  ë: "ë",
  ẽ: "ẽ",
  ē: "ē",
  ḗ: "ḗ",
  ḕ: "ḕ",
  ĕ: "ĕ",
  ḝ: "ḝ",
  ě: "ě",
  ê: "ê",
  ế: "ế",
  ề: "ề",
  ễ: "ễ",
  ė: "ė",
  ȩ: "ȩ",
  ḟ: "ḟ",
  ǵ: "ǵ",
  ḡ: "ḡ",
  ğ: "ğ",
  ǧ: "ǧ",
  ĝ: "ĝ",
  ġ: "ġ",
  ģ: "ģ",
  ḧ: "ḧ",
  ȟ: "ȟ",
  ĥ: "ĥ",
  ḣ: "ḣ",
  ḩ: "ḩ",
  í: "í",
  ì: "ì",
  ï: "ï",
  ḯ: "ḯ",
  ĩ: "ĩ",
  ī: "ī",
  ĭ: "ĭ",
  ǐ: "ǐ",
  î: "î",
  ǰ: "ǰ",
  ĵ: "ĵ",
  ḱ: "ḱ",
  ǩ: "ǩ",
  ķ: "ķ",
  ĺ: "ĺ",
  ľ: "ľ",
  ļ: "ļ",
  ḿ: "ḿ",
  ṁ: "ṁ",
  ń: "ń",
  ǹ: "ǹ",
  ñ: "ñ",
  ň: "ň",
  ṅ: "ṅ",
  ņ: "ņ",
  ó: "ó",
  ò: "ò",
  ö: "ö",
  ȫ: "ȫ",
  õ: "õ",
  ṍ: "ṍ",
  ṏ: "ṏ",
  ȭ: "ȭ",
  ō: "ō",
  ṓ: "ṓ",
  ṑ: "ṑ",
  ŏ: "ŏ",
  ǒ: "ǒ",
  ô: "ô",
  ố: "ố",
  ồ: "ồ",
  ỗ: "ỗ",
  ȯ: "ȯ",
  ȱ: "ȱ",
  ő: "ő",
  ṕ: "ṕ",
  ṗ: "ṗ",
  ŕ: "ŕ",
  ř: "ř",
  ṙ: "ṙ",
  ŗ: "ŗ",
  ś: "ś",
  ṥ: "ṥ",
  š: "š",
  ṧ: "ṧ",
  ŝ: "ŝ",
  ṡ: "ṡ",
  ş: "ş",
  ẗ: "ẗ",
  ť: "ť",
  ṫ: "ṫ",
  ţ: "ţ",
  ú: "ú",
  ù: "ù",
  ü: "ü",
  ǘ: "ǘ",
  ǜ: "ǜ",
  ǖ: "ǖ",
  ǚ: "ǚ",
  ũ: "ũ",
  ṹ: "ṹ",
  ū: "ū",
  ṻ: "ṻ",
  ŭ: "ŭ",
  ǔ: "ǔ",
  û: "û",
  ů: "ů",
  ű: "ű",
  ṽ: "ṽ",
  ẃ: "ẃ",
  ẁ: "ẁ",
  ẅ: "ẅ",
  ŵ: "ŵ",
  ẇ: "ẇ",
  ẘ: "ẘ",
  ẍ: "ẍ",
  ẋ: "ẋ",
  ý: "ý",
  ỳ: "ỳ",
  ÿ: "ÿ",
  ỹ: "ỹ",
  ȳ: "ȳ",
  ŷ: "ŷ",
  ẏ: "ẏ",
  ẙ: "ẙ",
  ź: "ź",
  ž: "ž",
  ẑ: "ẑ",
  ż: "ż",
  Á: "Á",
  À: "À",
  Ä: "Ä",
  Ǟ: "Ǟ",
  Ã: "Ã",
  Ā: "Ā",
  Ă: "Ă",
  Ắ: "Ắ",
  Ằ: "Ằ",
  Ẵ: "Ẵ",
  Ǎ: "Ǎ",
  Â: "Â",
  Ấ: "Ấ",
  Ầ: "Ầ",
  Ẫ: "Ẫ",
  Ȧ: "Ȧ",
  Ǡ: "Ǡ",
  Å: "Å",
  Ǻ: "Ǻ",
  Ḃ: "Ḃ",
  Ć: "Ć",
  Ḉ: "Ḉ",
  Č: "Č",
  Ĉ: "Ĉ",
  Ċ: "Ċ",
  Ç: "Ç",
  Ď: "Ď",
  Ḋ: "Ḋ",
  Ḑ: "Ḑ",
  É: "É",
  È: "È",
  Ë: "Ë",
  Ẽ: "Ẽ",
  Ē: "Ē",
  Ḗ: "Ḗ",
  Ḕ: "Ḕ",
  Ĕ: "Ĕ",
  Ḝ: "Ḝ",
  Ě: "Ě",
  Ê: "Ê",
  Ế: "Ế",
  Ề: "Ề",
  Ễ: "Ễ",
  Ė: "Ė",
  Ȩ: "Ȩ",
  Ḟ: "Ḟ",
  Ǵ: "Ǵ",
  Ḡ: "Ḡ",
  Ğ: "Ğ",
  Ǧ: "Ǧ",
  Ĝ: "Ĝ",
  Ġ: "Ġ",
  Ģ: "Ģ",
  Ḧ: "Ḧ",
  Ȟ: "Ȟ",
  Ĥ: "Ĥ",
  Ḣ: "Ḣ",
  Ḩ: "Ḩ",
  Í: "Í",
  Ì: "Ì",
  Ï: "Ï",
  Ḯ: "Ḯ",
  Ĩ: "Ĩ",
  Ī: "Ī",
  Ĭ: "Ĭ",
  Ǐ: "Ǐ",
  Î: "Î",
  İ: "İ",
  Ĵ: "Ĵ",
  Ḱ: "Ḱ",
  Ǩ: "Ǩ",
  Ķ: "Ķ",
  Ĺ: "Ĺ",
  Ľ: "Ľ",
  Ļ: "Ļ",
  Ḿ: "Ḿ",
  Ṁ: "Ṁ",
  Ń: "Ń",
  Ǹ: "Ǹ",
  Ñ: "Ñ",
  Ň: "Ň",
  Ṅ: "Ṅ",
  Ņ: "Ņ",
  Ó: "Ó",
  Ò: "Ò",
  Ö: "Ö",
  Ȫ: "Ȫ",
  Õ: "Õ",
  Ṍ: "Ṍ",
  Ṏ: "Ṏ",
  Ȭ: "Ȭ",
  Ō: "Ō",
  Ṓ: "Ṓ",
  Ṑ: "Ṑ",
  Ŏ: "Ŏ",
  Ǒ: "Ǒ",
  Ô: "Ô",
  Ố: "Ố",
  Ồ: "Ồ",
  Ỗ: "Ỗ",
  Ȯ: "Ȯ",
  Ȱ: "Ȱ",
  Ő: "Ő",
  Ṕ: "Ṕ",
  Ṗ: "Ṗ",
  Ŕ: "Ŕ",
  Ř: "Ř",
  Ṙ: "Ṙ",
  Ŗ: "Ŗ",
  Ś: "Ś",
  Ṥ: "Ṥ",
  Š: "Š",
  Ṧ: "Ṧ",
  Ŝ: "Ŝ",
  Ṡ: "Ṡ",
  Ş: "Ş",
  Ť: "Ť",
  Ṫ: "Ṫ",
  Ţ: "Ţ",
  Ú: "Ú",
  Ù: "Ù",
  Ü: "Ü",
  Ǘ: "Ǘ",
  Ǜ: "Ǜ",
  Ǖ: "Ǖ",
  Ǚ: "Ǚ",
  Ũ: "Ũ",
  Ṹ: "Ṹ",
  Ū: "Ū",
  Ṻ: "Ṻ",
  Ŭ: "Ŭ",
  Ǔ: "Ǔ",
  Û: "Û",
  Ů: "Ů",
  Ű: "Ű",
  Ṽ: "Ṽ",
  Ẃ: "Ẃ",
  Ẁ: "Ẁ",
  Ẅ: "Ẅ",
  Ŵ: "Ŵ",
  Ẇ: "Ẇ",
  Ẍ: "Ẍ",
  Ẋ: "Ẋ",
  Ý: "Ý",
  Ỳ: "Ỳ",
  Ÿ: "Ÿ",
  Ỹ: "Ỹ",
  Ȳ: "Ȳ",
  Ŷ: "Ŷ",
  Ẏ: "Ẏ",
  Ź: "Ź",
  Ž: "Ž",
  Ẑ: "Ẑ",
  Ż: "Ż",
  ά: "ά",
  ὰ: "ὰ",
  ᾱ: "ᾱ",
  ᾰ: "ᾰ",
  έ: "έ",
  ὲ: "ὲ",
  ή: "ή",
  ὴ: "ὴ",
  ί: "ί",
  ὶ: "ὶ",
  ϊ: "ϊ",
  ΐ: "ΐ",
  ῒ: "ῒ",
  ῑ: "ῑ",
  ῐ: "ῐ",
  ό: "ό",
  ὸ: "ὸ",
  ύ: "ύ",
  ὺ: "ὺ",
  ϋ: "ϋ",
  ΰ: "ΰ",
  ῢ: "ῢ",
  ῡ: "ῡ",
  ῠ: "ῠ",
  ώ: "ώ",
  ὼ: "ὼ",
  Ύ: "Ύ",
  Ὺ: "Ὺ",
  Ϋ: "Ϋ",
  Ῡ: "Ῡ",
  Ῠ: "Ῠ",
  Ώ: "Ώ",
  Ὼ: "Ὼ"
};
class Ar {
  constructor(e, t) {
    this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new Ec(e, t, this.mode), this.settings = t, this.leftrightDepth = 0;
  }
  /**
   * Checks a result to make sure it has the right type, and throws an
   * appropriate error otherwise.
   */
  expect(e, t) {
    if (t === void 0 && (t = !0), this.fetch().text !== e)
      throw new O("Expected '" + e + "', got '" + this.fetch().text + "'", this.fetch());
    t && this.consume();
  }
  /**
   * Discards the current lookahead token, considering it consumed.
   */
  consume() {
    this.nextToken = null;
  }
  /**
   * Return the current lookahead token, or if there isn't one (at the
   * beginning, or if the previous lookahead token was consume()d),
   * fetch the next token as the new lookahead token and return it.
   */
  fetch() {
    return this.nextToken == null && (this.nextToken = this.gullet.expandNextToken()), this.nextToken;
  }
  /**
   * Switches between "text" and "math" modes.
   */
  switchMode(e) {
    this.mode = e, this.gullet.switchMode(e);
  }
  /**
   * Main parsing function, which parses an entire input.
   */
  parse() {
    this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
    try {
      var e = this.parseExpression(!1);
      return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), e;
    } finally {
      this.gullet.endGroups();
    }
  }
  /**
   * Fully parse a separate sequence of tokens as a separate job.
   * Tokens should be specified in reverse order, as in a MacroDefinition.
   */
  subparse(e) {
    var t = this.nextToken;
    this.consume(), this.gullet.pushToken(new Ft("}")), this.gullet.pushTokens(e);
    var n = this.parseExpression(!1);
    return this.expect("}"), this.nextToken = t, n;
  }
  /**
   * Parses an "expression", which is a list of atoms.
   *
   * `breakOnInfix`: Should the parsing stop when we hit infix nodes? This
   *                 happens when functions have higher precedence han infix
   *                 nodes in implicit parses.
   *
   * `breakOnTokenText`: The text of the token that the expression should end
   *                     with, or `null` if something else should end the
   *                     expression.
   */
  parseExpression(e, t) {
    for (var n = []; ; ) {
      this.mode === "math" && this.consumeSpaces();
      var a = this.fetch();
      if (Ar.endOfExpression.indexOf(a.text) !== -1 || t && a.text === t || e && F0[a.text] && F0[a.text].infix)
        break;
      var i = this.parseAtom(t);
      if (i) {
        if (i.type === "internal")
          continue;
      } else break;
      n.push(i);
    }
    return this.mode === "text" && this.formLigatures(n), this.handleInfixNodes(n);
  }
  /**
   * Rewrites infix operators such as \over with corresponding commands such
   * as \frac.
   *
   * There can only be one infix operator per group.  If there's more than one
   * then the expression is ambiguous.  This can be resolved by adding {}.
   */
  handleInfixNodes(e) {
    for (var t = -1, n, a = 0; a < e.length; a++)
      if (e[a].type === "infix") {
        if (t !== -1)
          throw new O("only one infix operator per group", e[a].token);
        t = a, n = e[a].replaceWith;
      }
    if (t !== -1 && n) {
      var i, l, s = e.slice(0, t), o = e.slice(t + 1);
      s.length === 1 && s[0].type === "ordgroup" ? i = s[0] : i = {
        type: "ordgroup",
        mode: this.mode,
        body: s
      }, o.length === 1 && o[0].type === "ordgroup" ? l = o[0] : l = {
        type: "ordgroup",
        mode: this.mode,
        body: o
      };
      var h;
      return n === "\\\\abovefrac" ? h = this.callFunction(n, [i, e[t], l], []) : h = this.callFunction(n, [i, l], []), [h];
    } else
      return e;
  }
  /**
   * Handle a subscript or superscript with nice errors.
   */
  handleSupSubscript(e) {
    var t = this.fetch(), n = t.text;
    this.consume(), this.consumeSpaces();
    var a;
    do {
      var i;
      a = this.parseGroup(e);
    } while (((i = a) == null ? void 0 : i.type) === "internal");
    if (!a)
      throw new O("Expected group after '" + n + "'", t);
    return a;
  }
  /**
   * Converts the textual input of an unsupported command into a text node
   * contained within a color node whose color is determined by errorColor
   */
  formatUnsupportedCmd(e) {
    for (var t = [], n = 0; n < e.length; n++)
      t.push({
        type: "textord",
        mode: "text",
        text: e[n]
      });
    var a = {
      type: "text",
      mode: this.mode,
      body: t
    }, i = {
      type: "color",
      mode: this.mode,
      color: this.settings.errorColor,
      body: [a]
    };
    return i;
  }
  /**
   * Parses a group with optional super/subscripts.
   */
  parseAtom(e) {
    var t = this.parseGroup("atom", e);
    if ((t == null ? void 0 : t.type) === "internal" || this.mode === "text")
      return t;
    for (var n, a; ; ) {
      this.consumeSpaces();
      var i = this.fetch();
      if (i.text === "\\limits" || i.text === "\\nolimits") {
        if (t && t.type === "op") {
          var l = i.text === "\\limits";
          t.limits = l, t.alwaysHandleSupSub = !0;
        } else if (t && t.type === "operatorname")
          t.alwaysHandleSupSub && (t.limits = i.text === "\\limits");
        else
          throw new O("Limit controls must follow a math operator", i);
        this.consume();
      } else if (i.text === "^") {
        if (n)
          throw new O("Double superscript", i);
        n = this.handleSupSubscript("superscript");
      } else if (i.text === "_") {
        if (a)
          throw new O("Double subscript", i);
        a = this.handleSupSubscript("subscript");
      } else if (i.text === "'") {
        if (n)
          throw new O("Double superscript", i);
        var s = {
          type: "textord",
          mode: this.mode,
          text: "\\prime"
        }, o = [s];
        for (this.consume(); this.fetch().text === "'"; )
          o.push(s), this.consume();
        this.fetch().text === "^" && o.push(this.handleSupSubscript("superscript")), n = {
          type: "ordgroup",
          mode: this.mode,
          body: o
        };
      } else if (Gn[i.text]) {
        var h = Qi.test(i.text), m = [];
        for (m.push(new Ft(Gn[i.text])), this.consume(); ; ) {
          var p = this.fetch().text;
          if (!Gn[p] || Qi.test(p) !== h)
            break;
          m.unshift(new Ft(Gn[p])), this.consume();
        }
        var g = this.subparse(m);
        h ? a = {
          type: "ordgroup",
          mode: "math",
          body: g
        } : n = {
          type: "ordgroup",
          mode: "math",
          body: g
        };
      } else
        break;
    }
    return n || a ? {
      type: "supsub",
      mode: this.mode,
      base: t,
      sup: n,
      sub: a
    } : t;
  }
  /**
   * Parses an entire function, including its base and all of its arguments.
   */
  parseFunction(e, t) {
    var n = this.fetch(), a = n.text, i = F0[a];
    if (!i)
      return null;
    if (this.consume(), t && t !== "atom" && !i.allowedInArgument)
      throw new O("Got function '" + a + "' with no arguments" + (t ? " as " + t : ""), n);
    if (this.mode === "text" && !i.allowedInText)
      throw new O("Can't use function '" + a + "' in text mode", n);
    if (this.mode === "math" && i.allowedInMath === !1)
      throw new O("Can't use function '" + a + "' in math mode", n);
    var {
      args: l,
      optArgs: s
    } = this.parseArguments(a, i);
    return this.callFunction(a, l, s, n, e);
  }
  /**
   * Call a function handler with a suitable context and arguments.
   */
  callFunction(e, t, n, a, i) {
    var l = {
      funcName: e,
      parser: this,
      token: a,
      breakOnTokenText: i
    }, s = F0[e];
    if (s && s.handler)
      return s.handler(l, t, n);
    throw new O("No function handler for " + e);
  }
  /**
   * Parses the arguments of a function or environment
   */
  parseArguments(e, t) {
    var n = t.numArgs + t.numOptionalArgs;
    if (n === 0)
      return {
        args: [],
        optArgs: []
      };
    for (var a = [], i = [], l = 0; l < n; l++) {
      var s = t.argTypes && t.argTypes[l], o = l < t.numOptionalArgs;
      (t.primitive && s == null || // \sqrt expands into primitive if optional argument doesn't exist
      t.type === "sqrt" && l === 1 && i[0] == null) && (s = "primitive");
      var h = this.parseGroupOfType("argument to '" + e + "'", s, o);
      if (o)
        i.push(h);
      else if (h != null)
        a.push(h);
      else
        throw new O("Null argument, please report this as a bug");
    }
    return {
      args: a,
      optArgs: i
    };
  }
  /**
   * Parses a group when the mode is changing.
   */
  parseGroupOfType(e, t, n) {
    switch (t) {
      case "color":
        return this.parseColorGroup(n);
      case "size":
        return this.parseSizeGroup(n);
      case "url":
        return this.parseUrlGroup(n);
      case "math":
      case "text":
        return this.parseArgumentGroup(n, t);
      case "hbox": {
        var a = this.parseArgumentGroup(n, "text");
        return a != null ? {
          type: "styling",
          mode: a.mode,
          body: [a],
          style: "text"
          // simulate \textstyle
        } : null;
      }
      case "raw": {
        var i = this.parseStringGroup("raw", n);
        return i != null ? {
          type: "raw",
          mode: "text",
          string: i.text
        } : null;
      }
      case "primitive": {
        if (n)
          throw new O("A primitive argument cannot be optional");
        var l = this.parseGroup(e);
        if (l == null)
          throw new O("Expected group as " + e, this.fetch());
        return l;
      }
      case "original":
      case null:
      case void 0:
        return this.parseArgumentGroup(n);
      default:
        throw new O("Unknown group type as " + e, this.fetch());
    }
  }
  /**
   * Discard any space tokens, fetching the next non-space token.
   */
  consumeSpaces() {
    for (; this.fetch().text === " "; )
      this.consume();
  }
  /**
   * Parses a group, essentially returning the string formed by the
   * brace-enclosed tokens plus some position information.
   */
  parseStringGroup(e, t) {
    var n = this.gullet.scanArgument(t);
    if (n == null)
      return null;
    for (var a = "", i; (i = this.fetch()).text !== "EOF"; )
      a += i.text, this.consume();
    return this.consume(), n.text = a, n;
  }
  /**
   * Parses a regex-delimited group: the largest sequence of tokens
   * whose concatenated strings match `regex`. Returns the string
   * formed by the tokens plus some position information.
   */
  parseRegexGroup(e, t) {
    for (var n = this.fetch(), a = n, i = "", l; (l = this.fetch()).text !== "EOF" && e.test(i + l.text); )
      a = l, i += a.text, this.consume();
    if (i === "")
      throw new O("Invalid " + t + ": '" + n.text + "'", n);
    return n.range(a, i);
  }
  /**
   * Parses a color description.
   */
  parseColorGroup(e) {
    var t = this.parseStringGroup("color", e);
    if (t == null)
      return null;
    var n = /^(#[a-f0-9]{3}|#?[a-f0-9]{6}|[a-z]+)$/i.exec(t.text);
    if (!n)
      throw new O("Invalid color: '" + t.text + "'", t);
    var a = n[0];
    return /^[0-9a-f]{6}$/i.test(a) && (a = "#" + a), {
      type: "color-token",
      mode: this.mode,
      color: a
    };
  }
  /**
   * Parses a size specification, consisting of magnitude and unit.
   */
  parseSizeGroup(e) {
    var t, n = !1;
    if (this.gullet.consumeSpaces(), !e && this.gullet.future().text !== "{" ? t = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : t = this.parseStringGroup("size", e), !t)
      return null;
    !e && t.text.length === 0 && (t.text = "0pt", n = !0);
    var a = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t.text);
    if (!a)
      throw new O("Invalid size: '" + t.text + "'", t);
    var i = {
      number: +(a[1] + a[2]),
      // sign + magnitude, cast to number
      unit: a[3]
    };
    if (!fs(i))
      throw new O("Invalid unit: '" + i.unit + "'", t);
    return {
      type: "size",
      mode: this.mode,
      value: i,
      isBlank: n
    };
  }
  /**
   * Parses an URL, checking escaped letters and allowed protocols,
   * and setting the catcode of % as an active character (as in \hyperref).
   */
  parseUrlGroup(e) {
    this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
    var t = this.parseStringGroup("url", e);
    if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), t == null)
      return null;
    var n = t.text.replace(/\\([#$%&~_^{}])/g, "$1");
    return {
      type: "url",
      mode: this.mode,
      url: n
    };
  }
  /**
   * Parses an argument with the mode specified.
   */
  parseArgumentGroup(e, t) {
    var n = this.gullet.scanArgument(e);
    if (n == null)
      return null;
    var a = this.mode;
    t && this.switchMode(t), this.gullet.beginGroup();
    var i = this.parseExpression(!1, "EOF");
    this.expect("EOF"), this.gullet.endGroup();
    var l = {
      type: "ordgroup",
      mode: this.mode,
      loc: n.loc,
      body: i
    };
    return t && this.switchMode(a), l;
  }
  /**
   * Parses an ordinary group, which is either a single nucleus (like "x")
   * or an expression in braces (like "{x+y}") or an implicit group, a group
   * that starts at the current position, and ends right before a higher explicit
   * group ends, or at EOF.
   */
  parseGroup(e, t) {
    var n = this.fetch(), a = n.text, i;
    if (a === "{" || a === "\\begingroup") {
      this.consume();
      var l = a === "{" ? "}" : "\\endgroup";
      this.gullet.beginGroup();
      var s = this.parseExpression(!1, l), o = this.fetch();
      this.expect(l), this.gullet.endGroup(), i = {
        type: "ordgroup",
        mode: this.mode,
        loc: _t.range(n, o),
        body: s,
        // A group formed by \begingroup...\endgroup is a semi-simple group
        // which doesn't affect spacing in math mode, i.e., is transparent.
        // https://tex.stackexchange.com/questions/1930/when-should-one-
        // use-begingroup-instead-of-bgroup
        semisimple: a === "\\begingroup" || void 0
      };
    } else if (i = this.parseFunction(t, e) || this.parseSymbol(), i == null && a[0] === "\\" && !ao.hasOwnProperty(a)) {
      if (this.settings.throwOnError)
        throw new O("Undefined control sequence: " + a, n);
      i = this.formatUnsupportedCmd(a), this.consume();
    }
    return i;
  }
  /**
   * Form ligature-like combinations of characters for text mode.
   * This includes inputs like "--", "---", "``" and "''".
   * The result will simply replace multiple textord nodes with a single
   * character in each value by a single textord node having multiple
   * characters in its value.  The representation is still ASCII source.
   * The group will be modified in place.
   */
  formLigatures(e) {
    for (var t = e.length - 1, n = 0; n < t; ++n) {
      var a = e[n], i = a.text;
      i === "-" && e[n + 1].text === "-" && (n + 1 < t && e[n + 2].text === "-" ? (e.splice(n, 3, {
        type: "textord",
        mode: "text",
        loc: _t.range(a, e[n + 2]),
        text: "---"
      }), t -= 2) : (e.splice(n, 2, {
        type: "textord",
        mode: "text",
        loc: _t.range(a, e[n + 1]),
        text: "--"
      }), t -= 1)), (i === "'" || i === "`") && e[n + 1].text === i && (e.splice(n, 2, {
        type: "textord",
        mode: "text",
        loc: _t.range(a, e[n + 1]),
        text: i + i
      }), t -= 1);
    }
  }
  /**
   * Parse a single symbol out of the string. Here, we handle single character
   * symbols and special functions like \verb.
   */
  parseSymbol() {
    var e = this.fetch(), t = e.text;
    if (/^\\verb[^a-zA-Z]/.test(t)) {
      this.consume();
      var n = t.slice(5), a = n.charAt(0) === "*";
      if (a && (n = n.slice(1)), n.length < 2 || n.charAt(0) !== n.slice(-1))
        throw new O(`\\verb assertion failed --
                    please report what input caused this bug`);
      return n = n.slice(1, -1), {
        type: "verb",
        mode: "text",
        body: n,
        star: a
      };
    }
    Ji.hasOwnProperty(t[0]) && !be[this.mode][t[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + t[0] + '" used in math mode', e), t = Ji[t[0]] + t.slice(1));
    var i = $c.exec(t);
    i && (t = t.substring(0, i.index), t === "i" ? t = "ı" : t === "j" && (t = "ȷ"));
    var l;
    if (be[this.mode][t]) {
      this.settings.strict && this.mode === "math" && ca.indexOf(t) >= 0 && this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + t[0] + '" used in math mode', e);
      var s = be[this.mode][t].group, o = _t.range(e), h;
      if (_u.hasOwnProperty(s)) {
        var m = s;
        h = {
          type: "atom",
          mode: this.mode,
          family: m,
          loc: o,
          text: t
        };
      } else
        h = {
          type: s,
          mode: this.mode,
          loc: o,
          text: t
        };
      l = h;
    } else if (t.charCodeAt(0) >= 128)
      this.settings.strict && (ms(t.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + t[0] + '" used in math mode', e) : this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + t[0] + '"' + (" (" + t.charCodeAt(0) + ")"), e)), l = {
        type: "textord",
        mode: "text",
        loc: _t.range(e),
        text: t
      };
    else
      return null;
    if (this.consume(), i)
      for (var p = 0; p < i[0].length; p++) {
        var g = i[0][p];
        if (!Yr[g])
          throw new O("Unknown accent ' " + g + "'", e);
        var _ = Yr[g][this.mode] || Yr[g].text;
        if (!_)
          throw new O("Accent " + g + " unsupported in " + this.mode + " mode", e);
        l = {
          type: "accent",
          mode: this.mode,
          loc: _t.range(e),
          label: _,
          isStretchy: !1,
          isShifty: !0,
          // $FlowFixMe
          base: l
        };
      }
    return l;
  }
}
Ar.endOfExpression = ["}", "\\endgroup", "\\end", "\\right", "&"];
var ja = function(e, t) {
  if (!(typeof e == "string" || e instanceof String))
    throw new TypeError("KaTeX can only parse string typed expression");
  var n = new Ar(e, t);
  delete n.gullet.macros.current["\\df@tag"];
  var a = n.parse();
  if (delete n.gullet.macros.current["\\current@color"], delete n.gullet.macros.current["\\color"], n.gullet.macros.get("\\df@tag")) {
    if (!t.displayMode)
      throw new O("\\tag works only in display equations");
    a = [{
      type: "tag",
      mode: "text",
      body: a,
      tag: n.subparse([new Ft("\\df@tag")])
    }];
  }
  return a;
}, io = function(e, t, n) {
  t.textContent = "";
  var a = Xa(e, n).toNode();
  t.appendChild(a);
};
typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), io = function() {
  throw new O("KaTeX doesn't work in quirks mode.");
});
var Fc = function(e, t) {
  var n = Xa(e, t).toMarkup();
  return n;
}, Tc = function(e, t) {
  var n = new Ea(t);
  return ja(e, n);
}, lo = function(e, t, n) {
  if (n.throwOnError || !(e instanceof O))
    throw e;
  var a = D.makeSpan(["katex-error"], [new Mt(t)]);
  return a.setAttribute("title", e.toString()), a.setAttribute("style", "color:" + n.errorColor), a;
}, Xa = function(e, t) {
  var n = new Ea(t);
  try {
    var a = ja(e, n);
    return Ou(a, e, n);
  } catch (i) {
    return lo(i, e, n);
  }
}, Mc = function(e, t) {
  var n = new Ea(t);
  try {
    var a = ja(e, n);
    return Pu(a, e, n);
  } catch (i) {
    return lo(i, e, n);
  }
}, zc = "0.16.22", Bc = {
  Span: An,
  Anchor: Ma,
  SymbolNode: Mt,
  SvgNode: w0,
  PathNode: z0,
  LineNode: ua
}, el = {
  /**
   * Current KaTeX version
   */
  version: zc,
  /**
   * Renders the given LaTeX into an HTML+MathML combination, and adds
   * it as a child to the specified DOM node.
   */
  render: io,
  /**
   * Renders the given LaTeX into an HTML+MathML combination string,
   * for sending to the client.
   */
  renderToString: Fc,
  /**
   * KaTeX error, usually during parsing.
   */
  ParseError: O,
  /**
   * The schema of Settings
   */
  SETTINGS_SCHEMA: rr,
  /**
   * Parses the given LaTeX into KaTeX's internal parse tree structure,
   * without rendering to HTML or MathML.
   *
   * NOTE: This method is not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __parse: Tc,
  /**
   * Renders the given LaTeX into an HTML+MathML internal DOM tree
   * representation, without flattening that representation to a string.
   *
   * NOTE: This method is not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __renderToDomTree: Xa,
  /**
   * Renders the given LaTeX into an HTML internal DOM tree representation,
   * without MathML and without flattening that representation to a string.
   *
   * NOTE: This method is not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __renderToHTMLTree: Mc,
  /**
   * extends internal font metrics object with a new object
   * each key in the new object represents a font name
  */
  __setFontMetrics: uu,
  /**
   * adds a new symbol to builtin symbols table
   */
  __defineSymbol: u,
  /**
   * adds a new function to builtin function list,
   * which directly produce parse tree elements
   * and have their own html/mathml builders
   */
  __defineFunction: V,
  /**
   * adds a new macro to builtin macro list
   */
  __defineMacro: f,
  /**
   * Expose the dom tree node types, which can be useful for type checking nodes.
   *
   * NOTE: These methods are not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __domTree: Bc
}, qc = function(e, t, n) {
  for (var a = n, i = 0, l = e.length; a < t.length; ) {
    var s = t[a];
    if (i <= 0 && t.slice(a, a + l) === e)
      return a;
    s === "\\" ? a++ : s === "{" ? i++ : s === "}" && i--, a++;
  }
  return -1;
}, Rc = function(e) {
  return e.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
}, Nc = /^\\begin{/, Lc = function(e, t) {
  for (var n, a = [], i = new RegExp("(" + t.map((h) => Rc(h.left)).join("|") + ")"); n = e.search(i), n !== -1; ) {
    n > 0 && (a.push({
      type: "text",
      data: e.slice(0, n)
    }), e = e.slice(n));
    var l = t.findIndex((h) => e.startsWith(h.left));
    if (n = qc(t[l].right, e, t[l].left.length), n === -1)
      break;
    var s = e.slice(0, n + t[l].right.length), o = Nc.test(s) ? s : e.slice(t[l].left.length, n);
    a.push({
      type: "math",
      data: o,
      rawData: s,
      display: t[l].display
    }), e = e.slice(n + t[l].right.length);
  }
  return e !== "" && a.push({
    type: "text",
    data: e
  }), a;
}, Ic = function(e, t) {
  var n = Lc(e, t.delimiters);
  if (n.length === 1 && n[0].type === "text")
    return null;
  for (var a = document.createDocumentFragment(), i = 0; i < n.length; i++)
    if (n[i].type === "text")
      a.appendChild(document.createTextNode(n[i].data));
    else {
      var l = document.createElement("span"), s = n[i].data;
      t.displayMode = n[i].display;
      try {
        t.preProcess && (s = t.preProcess(s)), el.render(s, l, t);
      } catch (o) {
        if (!(o instanceof el.ParseError))
          throw o;
        t.errorCallback("KaTeX auto-render: Failed to parse `" + n[i].data + "` with ", o), a.appendChild(document.createTextNode(n[i].rawData));
        continue;
      }
      a.appendChild(l);
    }
  return a;
}, Oc = function r(e, t) {
  for (var n = 0; n < e.childNodes.length; n++) {
    var a = e.childNodes[n];
    if (a.nodeType === 3) {
      for (var i = a.textContent, l = a.nextSibling, s = 0; l && l.nodeType === Node.TEXT_NODE; )
        i += l.textContent, l = l.nextSibling, s++;
      var o = Ic(i, t);
      if (o) {
        for (var h = 0; h < s; h++)
          a.nextSibling.remove();
        n += o.childNodes.length - 1, e.replaceChild(o, a);
      } else
        n += s;
    } else a.nodeType === 1 && function() {
      var m = " " + a.className + " ", p = t.ignoredTags.indexOf(a.nodeName.toLowerCase()) === -1 && t.ignoredClasses.every((g) => m.indexOf(" " + g + " ") === -1);
      p && r(a, t);
    }();
  }
}, Pc = function(e, t) {
  if (!e)
    throw new Error("No element provided to render");
  var n = {};
  for (var a in t)
    t.hasOwnProperty(a) && (n[a] = t[a]);
  n.delimiters = n.delimiters || [
    {
      left: "$$",
      right: "$$",
      display: !0
    },
    {
      left: "\\(",
      right: "\\)",
      display: !1
    },
    // LaTeX uses $…$, but it ruins the display of normal `$` in text:
    // {left: "$", right: "$", display: false},
    // $ must come after $$
    // Render AMS environments even if outside $$…$$ delimiters.
    {
      left: "\\begin{equation}",
      right: "\\end{equation}",
      display: !0
    },
    {
      left: "\\begin{align}",
      right: "\\end{align}",
      display: !0
    },
    {
      left: "\\begin{alignat}",
      right: "\\end{alignat}",
      display: !0
    },
    {
      left: "\\begin{gather}",
      right: "\\end{gather}",
      display: !0
    },
    {
      left: "\\begin{CD}",
      right: "\\end{CD}",
      display: !0
    },
    {
      left: "\\[",
      right: "\\]",
      display: !0
    }
  ], n.ignoredTags = n.ignoredTags || ["script", "noscript", "style", "textarea", "pre", "code", "option"], n.ignoredClasses = n.ignoredClasses || [], n.errorCallback = n.errorCallback || console.error, n.macros = n.macros || {}, Oc(e, n);
};
function Ya() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let j0 = Ya();
function so(r) {
  j0 = r;
}
const oo = /[&<>"']/, Hc = new RegExp(oo.source, "g"), uo = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Uc = new RegExp(uo.source, "g"), Gc = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, tl = (r) => Gc[r];
function vt(r, e) {
  if (e) {
    if (oo.test(r))
      return r.replace(Hc, tl);
  } else if (uo.test(r))
    return r.replace(Uc, tl);
  return r;
}
const Vc = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Wc(r) {
  return r.replace(Vc, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const jc = /(^|[^\[])\^/g;
function ge(r, e) {
  let t = typeof r == "string" ? r : r.source;
  e = e || "";
  const n = {
    replace: (a, i) => {
      let l = typeof i == "string" ? i : i.source;
      return l = l.replace(jc, "$1"), t = t.replace(a, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function nl(r) {
  try {
    r = encodeURI(r).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return r;
}
const bn = { exec: () => null };
function rl(r, e) {
  const t = r.replace(/\|/g, (i, l, s) => {
    let o = !1, h = l;
    for (; --h >= 0 && s[h] === "\\"; )
      o = !o;
    return o ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function Vn(r, e, t) {
  const n = r.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && r.charAt(n - a - 1) === e; )
    a++;
  return r.slice(0, n - a);
}
function Xc(r, e) {
  if (r.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < r.length; n++)
    if (r[n] === "\\")
      n++;
    else if (r[n] === e[0])
      t++;
    else if (r[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function al(r, e, t, n) {
  const a = e.href, i = e.title ? vt(e.title) : null, l = r[1].replace(/\\([\[\]])/g, "$1");
  if (r[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: a,
      title: i,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: i,
    text: vt(l)
  };
}
function Yc(r, e) {
  const t = r.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const i = a.match(/^\s+/);
    if (i === null)
      return a;
    const [l] = i;
    return l.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class fr {
  // set by the lexer
  constructor(e) {
    xe(this, "options");
    xe(this, "rules");
    // set by the lexer
    xe(this, "lexer");
    this.options = e || j0;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Vn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = Yc(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = Vn(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Vn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, i = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", o = "", h = !1;
      for (; e; ) {
        let m = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let p = t[2].split(`
`, 1)[0].replace(/^\t+/, (M) => " ".repeat(3 * M.length)), g = e.split(`
`, 1)[0], _ = 0;
        this.options.pedantic ? (_ = 2, o = p.trimStart()) : (_ = t[2].search(/[^ ]/), _ = _ > 4 ? 1 : _, o = p.slice(_), _ += t[1].length);
        let C = !1;
        if (!p && /^ *$/.test(g) && (s += g + `
`, e = e.substring(g.length + 1), m = !0), !m) {
          const M = new RegExp(`^ {0,${Math.min(3, _ - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), w = new RegExp(`^ {0,${Math.min(3, _ - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), v = new RegExp(`^ {0,${Math.min(3, _ - 1)}}(?:\`\`\`|~~~)`), x = new RegExp(`^ {0,${Math.min(3, _ - 1)}}#`);
          for (; e; ) {
            const $ = e.split(`
`, 1)[0];
            if (g = $, this.options.pedantic && (g = g.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), v.test(g) || x.test(g) || M.test(g) || w.test(e))
              break;
            if (g.search(/[^ ]/) >= _ || !g.trim())
              o += `
` + g.slice(_);
            else {
              if (C || p.search(/[^ ]/) >= 4 || v.test(p) || x.test(p) || w.test(p))
                break;
              o += `
` + g;
            }
            !C && !g.trim() && (C = !0), s += $ + `
`, e = e.substring($.length + 1), p = g.slice(_);
          }
        }
        i.loose || (h ? i.loose = !0 : /\n *\n *$/.test(s) && (h = !0));
        let T = null, F;
        this.options.gfm && (T = /^\[[ xX]\] /.exec(o), T && (F = T[0] !== "[ ] ", o = o.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: s,
          task: !!T,
          checked: F,
          loose: !1,
          text: o,
          tokens: []
        }), i.raw += s;
      }
      i.items[i.items.length - 1].raw = s.trimEnd(), i.items[i.items.length - 1].text = o.trimEnd(), i.raw = i.raw.trimEnd();
      for (let m = 0; m < i.items.length; m++)
        if (this.lexer.state.top = !1, i.items[m].tokens = this.lexer.blockTokens(i.items[m].text, []), !i.loose) {
          const p = i.items[m].tokens.filter((_) => _.type === "space"), g = p.length > 0 && p.some((_) => /\n.*\n/.test(_.raw));
          i.loose = g;
        }
      if (i.loose)
        for (let m = 0; m < i.items.length; m++)
          i.items[m].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = rl(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const s of a)
        /^ *-+: *$/.test(s) ? l.align.push("right") : /^ *:-+: *$/.test(s) ? l.align.push("center") : /^ *:-+ *$/.test(s) ? l.align.push("left") : l.align.push(null);
      for (const s of n)
        l.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of i)
        l.rows.push(rl(s, l.header.length).map((o) => ({
          text: o,
          tokens: this.lexer.inline(o)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: vt(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = Vn(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = Xc(t[2], "()");
        if (l > -1) {
          const o = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, o).trim(), t[3] = "";
        }
      }
      let a = t[2], i = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], i = l[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), al(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), i = t[a.toLowerCase()];
      if (!i) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return al(n, i, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...a[0]].length - 1;
      let s, o, h = l, m = 0;
      const p = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = p.exec(t)) != null; ) {
        if (s = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !s)
          continue;
        if (o = [...s].length, a[3] || a[4]) {
          h += o;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + o) % 3)) {
          m += o;
          continue;
        }
        if (h -= o, h > 0)
          continue;
        o = Math.min(o, o + h + m);
        const g = [...a[0]][0].length, _ = e.slice(0, l + a.index + g + o);
        if (Math.min(l, o) % 2) {
          const T = _.slice(1, -1);
          return {
            type: "em",
            raw: _,
            text: T,
            tokens: this.lexer.inlineTokens(T)
          };
        }
        const C = _.slice(2, -2);
        return {
          type: "strong",
          raw: _,
          text: C,
          tokens: this.lexer.inlineTokens(C)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), i = /^ /.test(n) && / $/.test(n);
      return a && i && (n = n.substring(1, n.length - 1)), n = vt(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = vt(t[1]), a = "mailto:" + n) : (n = vt(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, i;
      if (t[2] === "@")
        a = vt(t[0]), i = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        a = vt(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: i,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = vt(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Zc = /^(?: *(?:\n|$))+/, Kc = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Qc = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, En = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Jc = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, co = /(?:[*+-]|\d{1,9}[.)])/, ho = ge(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, co).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Za = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, eh = /^[^\n]+/, Ka = /(?!\s*\])(?:\\.|[^\[\]\\])+/, th = ge(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Ka).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), nh = ge(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, co).getRegex(), Cr = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Qa = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, rh = ge("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Qa).replace("tag", Cr).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), mo = ge(Za).replace("hr", En).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Cr).getRegex(), ah = ge(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", mo).getRegex(), Ja = {
  blockquote: ah,
  code: Kc,
  def: th,
  fences: Qc,
  heading: Jc,
  hr: En,
  html: rh,
  lheading: ho,
  list: nh,
  newline: Zc,
  paragraph: mo,
  table: bn,
  text: eh
}, il = ge("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", En).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Cr).getRegex(), ih = {
  ...Ja,
  table: il,
  paragraph: ge(Za).replace("hr", En).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", il).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Cr).getRegex()
}, lh = {
  ...Ja,
  html: ge(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Qa).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: bn,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: ge(Za).replace("hr", En).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ho).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, fo = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, sh = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, po = /^( {2,}|\\)\n(?!\s*$)/, oh = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Fn = "\\p{P}\\p{S}", uh = ge(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Fn).getRegex(), ch = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, hh = ge(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Fn).getRegex(), dh = ge("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Fn).getRegex(), mh = ge("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Fn).getRegex(), fh = ge(/\\([punct])/, "gu").replace(/punct/g, Fn).getRegex(), ph = ge(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), gh = ge(Qa).replace("(?:-->|$)", "-->").getRegex(), _h = ge("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", gh).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), pr = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, vh = ge(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", pr).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), go = ge(/^!?\[(label)\]\[(ref)\]/).replace("label", pr).replace("ref", Ka).getRegex(), _o = ge(/^!?\[(ref)\](?:\[\])?/).replace("ref", Ka).getRegex(), yh = ge("reflink|nolink(?!\\()", "g").replace("reflink", go).replace("nolink", _o).getRegex(), ei = {
  _backpedal: bn,
  // only used for GFM url
  anyPunctuation: fh,
  autolink: ph,
  blockSkip: ch,
  br: po,
  code: sh,
  del: bn,
  emStrongLDelim: hh,
  emStrongRDelimAst: dh,
  emStrongRDelimUnd: mh,
  escape: fo,
  link: vh,
  nolink: _o,
  punctuation: uh,
  reflink: go,
  reflinkSearch: yh,
  tag: _h,
  text: oh,
  url: bn
}, bh = {
  ...ei,
  link: ge(/^!?\[(label)\]\((.*?)\)/).replace("label", pr).getRegex(),
  reflink: ge(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", pr).getRegex()
}, ga = {
  ...ei,
  escape: ge(fo).replace("])", "~|])").getRegex(),
  url: ge(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, wh = {
  ...ga,
  br: ge(po).replace("{2,}", "*").getRegex(),
  text: ge(ga.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Wn = {
  normal: Ja,
  gfm: ih,
  pedantic: lh
}, cn = {
  normal: ei,
  gfm: ga,
  breaks: wh,
  pedantic: bh
};
class e0 {
  constructor(e) {
    xe(this, "tokens");
    xe(this, "options");
    xe(this, "state");
    xe(this, "tokenizer");
    xe(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || j0, this.options.tokenizer = this.options.tokenizer || new fr(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Wn.normal,
      inline: cn.normal
    };
    this.options.pedantic ? (t.block = Wn.pedantic, t.inline = cn.pedantic) : this.options.gfm && (t.block = Wn.gfm, this.options.breaks ? t.inline = cn.breaks : t.inline = cn.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Wn,
      inline: cn
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new e0(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new e0(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, o, h) => o + "    ".repeat(h.length));
    let n, a, i, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (n = s.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const o = e.slice(1);
          let h;
          this.options.extensions.startBlock.forEach((m) => {
            h = m.call({ lexer: this }, o), typeof h == "number" && h >= 0 && (s = Math.min(s, h));
          }), s < 1 / 0 && s >= 0 && (i = e.substring(0, s + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(i))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), l = i.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, i, l = e, s, o, h;
    if (this.tokens.links) {
      const m = Object.keys(this.tokens.links);
      if (m.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          m.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, s.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (o || (h = ""), o = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((m) => (n = m.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, h)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let m = 1 / 0;
          const p = e.slice(1);
          let g;
          this.options.extensions.startInline.forEach((_) => {
            g = _.call({ lexer: this }, p), typeof g == "number" && g >= 0 && (m = Math.min(m, g));
          }), m < 1 / 0 && m >= 0 && (i = e.substring(0, m + 1));
        }
        if (n = this.tokenizer.inlineText(i)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (h = n.raw.slice(-1)), o = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const m = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(m);
            break;
          } else
            throw new Error(m);
        }
      }
    return t;
  }
}
class gr {
  constructor(e) {
    xe(this, "options");
    this.options = e || j0;
  }
  code(e, t, n) {
    var i;
    const a = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + vt(a) + '">' + (n ? e : vt(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : vt(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", i = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + i + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = nl(e);
    if (a === null)
      return n;
    e = a;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + n + "</a>", i;
  }
  image(e, t, n) {
    const a = nl(e);
    if (a === null)
      return n;
    e = a;
    let i = `<img src="${e}" alt="${n}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class ti {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class t0 {
  constructor(e) {
    xe(this, "options");
    xe(this, "renderer");
    xe(this, "textRenderer");
    this.options = e || j0, this.options.renderer = this.options.renderer || new gr(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new ti();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new t0(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new t0(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = i, s = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += s || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = i;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, Wc(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = i;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = i;
          let s = "", o = "";
          for (let m = 0; m < l.header.length; m++)
            o += this.renderer.tablecell(this.parseInline(l.header[m].tokens), { header: !0, align: l.align[m] });
          s += this.renderer.tablerow(o);
          let h = "";
          for (let m = 0; m < l.rows.length; m++) {
            const p = l.rows[m];
            o = "";
            for (let g = 0; g < p.length; g++)
              o += this.renderer.tablecell(this.parseInline(p[g].tokens), { header: !1, align: l.align[g] });
            h += this.renderer.tablerow(o);
          }
          n += this.renderer.table(s, h);
          continue;
        }
        case "blockquote": {
          const l = i, s = this.parse(l.tokens);
          n += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const l = i, s = l.ordered, o = l.start, h = l.loose;
          let m = "";
          for (let p = 0; p < l.items.length; p++) {
            const g = l.items[p], _ = g.checked, C = g.task;
            let T = "";
            if (g.task) {
              const F = this.renderer.checkbox(!!_);
              h ? g.tokens.length > 0 && g.tokens[0].type === "paragraph" ? (g.tokens[0].text = F + " " + g.tokens[0].text, g.tokens[0].tokens && g.tokens[0].tokens.length > 0 && g.tokens[0].tokens[0].type === "text" && (g.tokens[0].tokens[0].text = F + " " + g.tokens[0].tokens[0].text)) : g.tokens.unshift({
                type: "text",
                text: F + " "
              }) : T += F + " ";
            }
            T += this.parse(g.tokens, h), m += this.renderer.listitem(T, C, !!_);
          }
          n += this.renderer.list(m, s, o);
          continue;
        }
        case "html": {
          const l = i;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = i;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = i, s = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], s += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          n += l || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const l = i;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = i;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = i;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = i;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = i;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = i;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = i;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = i;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = i;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class wn {
  constructor(e) {
    xe(this, "options");
    this.options = e || j0;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
xe(wn, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var V0, _a, yo;
class vo {
  constructor(...e) {
    _i(this, V0);
    xe(this, "defaults", Ya());
    xe(this, "options", this.setOptions);
    xe(this, "parse", qn(this, V0, _a).call(this, e0.lex, t0.parse));
    xe(this, "parseInline", qn(this, V0, _a).call(this, e0.lexInline, t0.parseInline));
    xe(this, "Parser", t0);
    xe(this, "Renderer", gr);
    xe(this, "TextRenderer", ti);
    xe(this, "Lexer", e0);
    xe(this, "Tokenizer", fr);
    xe(this, "Hooks", wn);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, i;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const s = l;
          for (const o of s.header)
            n = n.concat(this.walkTokens(o.tokens, t));
          for (const o of s.rows)
            for (const h of o)
              n = n.concat(this.walkTokens(h.tokens, t));
          break;
        }
        case "list": {
          const s = l;
          n = n.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = l;
          (i = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && i[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((o) => {
            const h = s[o].flat(1 / 0);
            n = n.concat(this.walkTokens(h, t));
          }) : s.tokens && (n = n.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const l = t.renderers[i.name];
          l ? t.renderers[i.name] = function(...s) {
            let o = i.renderer.apply(this, s);
            return o === !1 && (o = l.apply(this, s)), o;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[i.level];
          l ? l.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), a.extensions = t), n.renderer) {
        const i = this.defaults.renderer || new gr(this.defaults);
        for (const l in n.renderer) {
          if (!(l in i))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const s = l, o = n.renderer[s], h = i[s];
          i[s] = (...m) => {
            let p = o.apply(i, m);
            return p === !1 && (p = h.apply(i, m)), p || "";
          };
        }
        a.renderer = i;
      }
      if (n.tokenizer) {
        const i = this.defaults.tokenizer || new fr(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in i))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const s = l, o = n.tokenizer[s], h = i[s];
          i[s] = (...m) => {
            let p = o.apply(i, m);
            return p === !1 && (p = h.apply(i, m)), p;
          };
        }
        a.tokenizer = i;
      }
      if (n.hooks) {
        const i = this.defaults.hooks || new wn();
        for (const l in n.hooks) {
          if (!(l in i))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const s = l, o = n.hooks[s], h = i[s];
          wn.passThroughHooks.has(l) ? i[s] = (m) => {
            if (this.defaults.async)
              return Promise.resolve(o.call(i, m)).then((g) => h.call(i, g));
            const p = o.call(i, m);
            return h.call(i, p);
          } : i[s] = (...m) => {
            let p = o.apply(i, m);
            return p === !1 && (p = h.apply(i, m)), p;
          };
        }
        a.hooks = i;
      }
      if (n.walkTokens) {
        const i = this.defaults.walkTokens, l = n.walkTokens;
        a.walkTokens = function(s) {
          let o = [];
          return o.push(l.call(this, s)), i && (o = o.concat(i.call(this, s))), o;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return e0.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return t0.parse(e, t ?? this.defaults);
  }
}
V0 = new WeakSet(), _a = function(e, t) {
  return (n, a) => {
    const i = { ...a }, l = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const s = qn(this, V0, yo).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((o) => e(o, l)).then((o) => l.hooks ? l.hooks.processAllTokens(o) : o).then((o) => l.walkTokens ? Promise.all(this.walkTokens(o, l.walkTokens)).then(() => o) : o).then((o) => t(o, l)).then((o) => l.hooks ? l.hooks.postprocess(o) : o).catch(s);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let o = e(n, l);
      l.hooks && (o = l.hooks.processAllTokens(o)), l.walkTokens && this.walkTokens(o, l.walkTokens);
      let h = t(o, l);
      return l.hooks && (h = l.hooks.postprocess(h)), h;
    } catch (o) {
      return s(o);
    }
  };
}, yo = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + vt(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const G0 = new vo();
function pe(r, e) {
  return G0.parse(r, e);
}
pe.options = pe.setOptions = function(r) {
  return G0.setOptions(r), pe.defaults = G0.defaults, so(pe.defaults), pe;
};
pe.getDefaults = Ya;
pe.defaults = j0;
pe.use = function(...r) {
  return G0.use(...r), pe.defaults = G0.defaults, so(pe.defaults), pe;
};
pe.walkTokens = function(r, e) {
  return G0.walkTokens(r, e);
};
pe.parseInline = G0.parseInline;
pe.Parser = t0;
pe.parser = t0.parse;
pe.Renderer = gr;
pe.TextRenderer = ti;
pe.Lexer = e0;
pe.lexer = e0.lex;
pe.Tokenizer = fr;
pe.Hooks = wn;
pe.parse = pe;
pe.options;
pe.setOptions;
pe.use;
pe.walkTokens;
pe.parseInline;
t0.parse;
e0.lex;
function xh(r) {
  if (typeof r == "function" && (r = {
    highlight: r
  }), !r || typeof r.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof r.langPrefix != "string" && (r.langPrefix = "language-"), typeof r.emptyLangClass != "string" && (r.emptyLangClass = ""), {
    async: !!r.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const t = ll(e.lang);
      if (r.async)
        return Promise.resolve(r.highlight(e.text, t, e.lang || "")).then(sl(e));
      const n = r.highlight(e.text, t, e.lang || "");
      if (n instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      sl(e)(n);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, t, n) {
        typeof e == "object" && (n = e.escaped, t = e.lang, e = e.text);
        const a = ll(t), i = a ? r.langPrefix + ul(a) : r.emptyLangClass, l = i ? ` class="${i}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${l}>${n ? e : ul(e, !0)}
</code></pre>`;
      }
    }
  };
}
function ll(r) {
  return (r || "").match(/\S*/)[0];
}
function sl(r) {
  return (e) => {
    typeof e == "string" && e !== r.text && (r.escaped = !0, r.text = e);
  };
}
const bo = /[&<>"']/, kh = new RegExp(bo.source, "g"), wo = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Sh = new RegExp(wo.source, "g"), $h = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ol = (r) => $h[r];
function ul(r, e) {
  if (e) {
    if (bo.test(r))
      return r.replace(kh, ol);
  } else if (wo.test(r))
    return r.replace(Sh, ol);
  return r;
}
const Dh = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Ah = Object.hasOwnProperty;
class ni {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = Ch(e, t === !0);
    const i = a;
    for (; Ah.call(n.occurrences, a); )
      n.occurrences[i]++, a = i + "-" + n.occurrences[i];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Ch(r, e) {
  return typeof r != "string" ? "" : (e || (r = r.toLowerCase()), r.replace(Dh, "").replace(/ /g, "-"));
}
let xo = new ni(), ko = [];
function Eh({ prefix: r = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return e || Fh(), t;
      }
    },
    renderer: {
      heading(t, n, a) {
        a = a.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const i = `${r}${xo.slug(a)}`, l = { level: n, text: t, id: i };
        return ko.push(l), `<h${n} id="${i}">${t}</h${n}>
`;
      }
    }
  };
}
function Fh() {
  ko = [], xo = new ni();
}
var cl = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function v4(r) {
  return r && r.__esModule && Object.prototype.hasOwnProperty.call(r, "default") ? r.default : r;
}
function y4(r) {
  if (r.__esModule) return r;
  var e = r.default;
  if (typeof e == "function") {
    var t = function n() {
      return this instanceof n ? Reflect.construct(e, arguments, this.constructor) : e.apply(this, arguments);
    };
    t.prototype = e.prototype;
  } else t = {};
  return Object.defineProperty(t, "__esModule", { value: !0 }), Object.keys(r).forEach(function(n) {
    var a = Object.getOwnPropertyDescriptor(r, n);
    Object.defineProperty(t, n, a.get ? a : {
      enumerable: !0,
      get: function() {
        return r[n];
      }
    });
  }), t;
}
var So = { exports: {} };
(function(r) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, l = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function w(v) {
          return v instanceof o ? new o(v.type, w(v.content), v.alias) : Array.isArray(v) ? v.map(w) : v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(w) {
          return Object.prototype.toString.call(w).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(w) {
          return w.__id || Object.defineProperty(w, "__id", { value: ++i }), w.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function w(v, x) {
          x = x || {};
          var $, E;
          switch (s.util.type(v)) {
            case "Object":
              if (E = s.util.objId(v), x[E])
                return x[E];
              $ = /** @type {Record<string, any>} */
              {}, x[E] = $;
              for (var A in v)
                v.hasOwnProperty(A) && ($[A] = w(v[A], x));
              return (
                /** @type {any} */
                $
              );
            case "Array":
              return E = s.util.objId(v), x[E] ? x[E] : ($ = [], x[E] = $, /** @type {Array} */
              /** @type {any} */
              v.forEach(function(q, B) {
                $[B] = w(q, x);
              }), /** @type {any} */
              $);
            default:
              return v;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(w) {
          for (; w; ) {
            var v = a.exec(w.className);
            if (v)
              return v[1].toLowerCase();
            w = w.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(w, v) {
          w.className = w.className.replace(RegExp(a, "gi"), ""), w.classList.add("language-" + v);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch ($) {
            var w = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec($.stack) || [])[1];
            if (w) {
              var v = document.getElementsByTagName("script");
              for (var x in v)
                if (v[x].src == w)
                  return v[x];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(w, v, x) {
          for (var $ = "no-" + v; w; ) {
            var E = w.classList;
            if (E.contains(v))
              return !0;
            if (E.contains($))
              return !1;
            w = w.parentElement;
          }
          return !!x;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(w, v) {
          var x = s.util.clone(s.languages[w]);
          for (var $ in v)
            x[$] = v[$];
          return x;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(w, v, x, $) {
          $ = $ || /** @type {any} */
          s.languages;
          var E = $[w], A = {};
          for (var q in E)
            if (E.hasOwnProperty(q)) {
              if (q == v)
                for (var B in x)
                  x.hasOwnProperty(B) && (A[B] = x[B]);
              x.hasOwnProperty(q) || (A[q] = E[q]);
            }
          var z = $[w];
          return $[w] = A, s.languages.DFS(s.languages, function(U, N) {
            N === z && U != w && (this[U] = A);
          }), A;
        },
        // Traverse a language definition with Depth First Search
        DFS: function w(v, x, $, E) {
          E = E || {};
          var A = s.util.objId;
          for (var q in v)
            if (v.hasOwnProperty(q)) {
              x.call(v, q, v[q], $ || q);
              var B = v[q], z = s.util.type(B);
              z === "Object" && !E[A(B)] ? (E[A(B)] = !0, w(B, x, null, E)) : z === "Array" && !E[A(B)] && (E[A(B)] = !0, w(B, x, q, E));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(w, v) {
        s.highlightAllUnder(document, w, v);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(w, v, x) {
        var $ = {
          callback: x,
          container: w,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", $), $.elements = Array.prototype.slice.apply($.container.querySelectorAll($.selector)), s.hooks.run("before-all-elements-highlight", $);
        for (var E = 0, A; A = $.elements[E++]; )
          s.highlightElement(A, v === !0, $.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(w, v, x) {
        var $ = s.util.getLanguage(w), E = s.languages[$];
        s.util.setLanguage(w, $);
        var A = w.parentElement;
        A && A.nodeName.toLowerCase() === "pre" && s.util.setLanguage(A, $);
        var q = w.textContent, B = {
          element: w,
          language: $,
          grammar: E,
          code: q
        };
        function z(N) {
          B.highlightedCode = N, s.hooks.run("before-insert", B), B.element.innerHTML = B.highlightedCode, s.hooks.run("after-highlight", B), s.hooks.run("complete", B), x && x.call(B.element);
        }
        if (s.hooks.run("before-sanity-check", B), A = B.element.parentElement, A && A.nodeName.toLowerCase() === "pre" && !A.hasAttribute("tabindex") && A.setAttribute("tabindex", "0"), !B.code) {
          s.hooks.run("complete", B), x && x.call(B.element);
          return;
        }
        if (s.hooks.run("before-highlight", B), !B.grammar) {
          z(s.util.encode(B.code));
          return;
        }
        if (v && n.Worker) {
          var U = new Worker(s.filename);
          U.onmessage = function(N) {
            z(N.data);
          }, U.postMessage(JSON.stringify({
            language: B.language,
            code: B.code,
            immediateClose: !0
          }));
        } else
          z(s.highlight(B.code, B.grammar, B.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(w, v, x) {
        var $ = {
          code: w,
          grammar: v,
          language: x
        };
        if (s.hooks.run("before-tokenize", $), !$.grammar)
          throw new Error('The language "' + $.language + '" has no grammar.');
        return $.tokens = s.tokenize($.code, $.grammar), s.hooks.run("after-tokenize", $), o.stringify(s.util.encode($.tokens), $.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(w, v) {
        var x = v.rest;
        if (x) {
          for (var $ in x)
            v[$] = x[$];
          delete v.rest;
        }
        var E = new p();
        return g(E, E.head, w), m(w, E, v, E.head, 0), C(E);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(w, v) {
          var x = s.hooks.all;
          x[w] = x[w] || [], x[w].push(v);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(w, v) {
          var x = s.hooks.all[w];
          if (!(!x || !x.length))
            for (var $ = 0, E; E = x[$++]; )
              E(v);
        }
      },
      Token: o
    };
    n.Prism = s;
    function o(w, v, x, $) {
      this.type = w, this.content = v, this.alias = x, this.length = ($ || "").length | 0;
    }
    o.stringify = function w(v, x) {
      if (typeof v == "string")
        return v;
      if (Array.isArray(v)) {
        var $ = "";
        return v.forEach(function(z) {
          $ += w(z, x);
        }), $;
      }
      var E = {
        type: v.type,
        content: w(v.content, x),
        tag: "span",
        classes: ["token", v.type],
        attributes: {},
        language: x
      }, A = v.alias;
      A && (Array.isArray(A) ? Array.prototype.push.apply(E.classes, A) : E.classes.push(A)), s.hooks.run("wrap", E);
      var q = "";
      for (var B in E.attributes)
        q += " " + B + '="' + (E.attributes[B] || "").replace(/"/g, "&quot;") + '"';
      return "<" + E.tag + ' class="' + E.classes.join(" ") + '"' + q + ">" + E.content + "</" + E.tag + ">";
    };
    function h(w, v, x, $) {
      w.lastIndex = v;
      var E = w.exec(x);
      if (E && $ && E[1]) {
        var A = E[1].length;
        E.index += A, E[0] = E[0].slice(A);
      }
      return E;
    }
    function m(w, v, x, $, E, A) {
      for (var q in x)
        if (!(!x.hasOwnProperty(q) || !x[q])) {
          var B = x[q];
          B = Array.isArray(B) ? B : [B];
          for (var z = 0; z < B.length; ++z) {
            if (A && A.cause == q + "," + z)
              return;
            var U = B[z], N = U.inside, K = !!U.lookbehind, ie = !!U.greedy, we = U.alias;
            if (ie && !U.pattern.global) {
              var _e = U.pattern.toString().match(/[imsuy]*$/)[0];
              U.pattern = RegExp(U.pattern.source, _e + "g");
            }
            for (var Ue = U.pattern || U, ue = $.next, Me = E; ue !== v.tail && !(A && Me >= A.reach); Me += ue.value.length, ue = ue.next) {
              var De = ue.value;
              if (v.length > w.length)
                return;
              if (!(De instanceof o)) {
                var re = 1, ce;
                if (ie) {
                  if (ce = h(Ue, Me, w, K), !ce || ce.index >= w.length)
                    break;
                  var Ge = ce.index, he = ce.index + ce[0].length, Le = Me;
                  for (Le += ue.value.length; Ge >= Le; )
                    ue = ue.next, Le += ue.value.length;
                  if (Le -= ue.value.length, Me = Le, ue.value instanceof o)
                    continue;
                  for (var H = ue; H !== v.tail && (Le < he || typeof H.value == "string"); H = H.next)
                    re++, Le += H.value.length;
                  re--, De = w.slice(Me, Le), ce.index -= Me;
                } else if (ce = h(Ue, 0, De, K), !ce)
                  continue;
                var Ge = ce.index, ze = ce[0], ke = De.slice(0, Ge), et = De.slice(Ge + ze.length), Ie = Me + De.length;
                A && Ie > A.reach && (A.reach = Ie);
                var Ze = ue.prev;
                ke && (Ze = g(v, Ze, ke), Me += ke.length), _(v, Ze, re);
                var ot = new o(q, N ? s.tokenize(ze, N) : ze, we, ze);
                if (ue = g(v, Ze, ot), et && g(v, ue, et), re > 1) {
                  var ut = {
                    cause: q + "," + z,
                    reach: Ie
                  };
                  m(w, v, x, ue.prev, Me, ut), A && ut.reach > A.reach && (A.reach = ut.reach);
                }
              }
            }
          }
        }
    }
    function p() {
      var w = { value: null, prev: null, next: null }, v = { value: null, prev: w, next: null };
      w.next = v, this.head = w, this.tail = v, this.length = 0;
    }
    function g(w, v, x) {
      var $ = v.next, E = { value: x, prev: v, next: $ };
      return v.next = E, $.prev = E, w.length++, E;
    }
    function _(w, v, x) {
      for (var $ = v.next, E = 0; E < x && $ !== w.tail; E++)
        $ = $.next;
      v.next = $, $.prev = v, w.length -= E;
    }
    function C(w) {
      for (var v = [], x = w.head.next; x !== w.tail; )
        v.push(x.value), x = x.next;
      return v;
    }
    if (!n.document)
      return n.addEventListener && (s.disableWorkerMessageHandler || n.addEventListener("message", function(w) {
        var v = JSON.parse(w.data), x = v.language, $ = v.code, E = v.immediateClose;
        n.postMessage(s.highlight($, s.languages[x], x)), E && n.close();
      }, !1)), s;
    var T = s.util.currentScript();
    T && (s.filename = T.src, T.hasAttribute("data-manual") && (s.manual = !0));
    function F() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var M = document.readyState;
      M === "loading" || M === "interactive" && T && T.defer ? document.addEventListener("DOMContentLoaded", F) : window.requestAnimationFrame ? window.requestAnimationFrame(F) : window.setTimeout(F, 16);
    }
    return s;
  }(e);
  r.exports && (r.exports = t), typeof cl < "u" && (cl.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, i) {
      var l = {};
      l["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      s["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var o = {};
      o[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", o);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var i = n.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(T, F) {
      return "✖ Error " + T + " while fetching file: " + F;
    }, i = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", o = "loading", h = "loaded", m = "failed", p = "pre[data-src]:not([" + s + '="' + h + '"]):not([' + s + '="' + o + '"])';
    function g(T, F, M) {
      var w = new XMLHttpRequest();
      w.open("GET", T, !0), w.onreadystatechange = function() {
        w.readyState == 4 && (w.status < 400 && w.responseText ? F(w.responseText) : w.status >= 400 ? M(a(w.status, w.statusText)) : M(i));
      }, w.send(null);
    }
    function _(T) {
      var F = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(T || "");
      if (F) {
        var M = Number(F[1]), w = F[2], v = F[3];
        return w ? v ? [M, Number(v)] : [M, void 0] : [M, M];
      }
    }
    t.hooks.add("before-highlightall", function(T) {
      T.selector += ", " + p;
    }), t.hooks.add("before-sanity-check", function(T) {
      var F = (
        /** @type {HTMLPreElement} */
        T.element
      );
      if (F.matches(p)) {
        T.code = "", F.setAttribute(s, o);
        var M = F.appendChild(document.createElement("CODE"));
        M.textContent = n;
        var w = F.getAttribute("data-src"), v = T.language;
        if (v === "none") {
          var x = (/\.(\w+)$/.exec(w) || [, "none"])[1];
          v = l[x] || x;
        }
        t.util.setLanguage(M, v), t.util.setLanguage(F, v);
        var $ = t.plugins.autoloader;
        $ && $.loadLanguages(v), g(
          w,
          function(E) {
            F.setAttribute(s, h);
            var A = _(F.getAttribute("data-range"));
            if (A) {
              var q = E.split(/\r\n?|\n/g), B = A[0], z = A[1] == null ? q.length : A[1];
              B < 0 && (B += q.length), B = Math.max(0, Math.min(B - 1, q.length)), z < 0 && (z += q.length), z = Math.max(0, Math.min(z, q.length)), E = q.slice(B, z).join(`
`), F.hasAttribute("data-start") || F.setAttribute("data-start", String(B + 1));
            }
            M.textContent = E, t.highlightElement(M);
          },
          function(E) {
            F.setAttribute(s, m), M.textContent = E;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(F) {
        for (var M = (F || document).querySelectorAll(p), w = 0, v; v = M[w++]; )
          t.highlightElement(v);
      }
    };
    var C = !1;
    t.fileHighlight = function() {
      C || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), C = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(So);
var Zr = So.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(r) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  r.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, r.languages.tex = r.languages.latex, r.languages.context = r.languages.latex;
})(Prism);
(function(r) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  r.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = r.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = n.variable[1].inside, l = 0; l < a.length; l++)
    i[a[l]] = r.languages.bash[a[l]];
  r.languages.sh = r.languages.bash, r.languages.shell = r.languages.bash;
})(Prism);
const Th = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', Mh = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, zh = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, hl = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${Mh}</span>
  <span class="check">${zh}</span>
</button>`, $o = /[&<>"']/, Bh = new RegExp($o.source, "g"), Do = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, qh = new RegExp(Do.source, "g"), Rh = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, dl = (r) => Rh[r] || "";
function Kr(r, e) {
  if (e) {
    if ($o.test(r))
      return r.replace(Bh, dl);
  } else if (Do.test(r))
    return r.replace(qh, dl);
  return r;
}
function Nh(r) {
  const e = r.map((t) => ({
    start: new RegExp(t.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(t.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(t) {
      for (const n of e) {
        const a = t.match(n.start);
        if (a)
          return a.index;
      }
      return -1;
    },
    tokenizer(t, n) {
      for (const a of e) {
        const i = new RegExp(
          `${a.start.source}([\\s\\S]+?)${a.end.source}`
        ).exec(t);
        if (i)
          return {
            type: "latex",
            raw: i[0],
            text: i[1].trim()
          };
      }
    },
    renderer(t) {
      return `<div class="latex-block">${t.text}</div>`;
    }
  };
}
const Lh = {
  code(r, e, t) {
    var a;
    const n = ((a = (e ?? "").match(/\S*/)) == null ? void 0 : a[0]) ?? "";
    return r = r.replace(/\n$/, "") + `
`, n ? '<div class="code_wrap">' + hl + '<pre><code class="language-' + Kr(n) + '">' + (t ? r : Kr(r, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + hl + "<pre><code>" + (t ? r : Kr(r, !0)) + `</code></pre></div>
`;
  }
}, Ih = new ni();
function Oh({
  header_links: r,
  line_breaks: e,
  latex_delimiters: t
}) {
  const n = new vo();
  n.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    xh({
      highlight: (i, l) => Zr.languages[l] ? Zr.highlight(i, Zr.languages[l], l) : i
    }),
    { renderer: Lh }
  ), r && (n.use(Eh()), n.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(i) {
          const l = i.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), s = "h" + Ih.slug(l), o = i.depth, h = this.parser.parseInline(i.tokens);
          return `<h${o} id="${s}"><a class="md-header-anchor" href="#${s}">${Th}</a>${h}</h${o}>
`;
        }
      }
    ]
  }));
  const a = Nh(t);
  return n.use({
    extensions: [a]
  }), n;
}
const va = (r) => JSON.parse(JSON.stringify(r)), Ph = (r) => r.nodeType === 1, Hh = (r) => ud.has(r.tagName), Uh = (r) => "action" in r, Gh = (r) => r.tagName === "IFRAME", Vh = (r) => "formAction" in r, Wh = (r) => "protocol" in r, jn = /* @__PURE__ */ (() => {
  const r = /^(?:\w+script|data):/i;
  return (e) => r.test(e);
})(), jh = /* @__PURE__ */ (() => {
  const r = /(?:script|data):/i;
  return (e) => r.test(e);
})(), Xh = (r) => {
  const e = {};
  for (let t = 0, n = r.length; t < n; t++) {
    const a = r[t];
    for (const i in a)
      e[i] ? e[i] = e[i].concat(a[i]) : e[i] = a[i];
  }
  return e;
}, Ao = (r, e) => {
  let t = r.firstChild;
  for (; t; ) {
    const n = t.nextSibling;
    Ph(t) && (e(t, r), t.parentNode && Ao(t, e)), t = n;
  }
}, Yh = (r, e) => {
  const t = document.createNodeIterator(r, NodeFilter.SHOW_ELEMENT);
  let n;
  for (; n = t.nextNode(); ) {
    const a = n.parentNode;
    a && e(n, a);
  }
}, Zh = (r, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? Yh(r, e) : Ao(r, e), Co = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Kh = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], Qh = /* @__PURE__ */ new Set([
  ...Co,
  ...Kh
]), Eo = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Jh = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], ed = /* @__PURE__ */ new Set([
  ...Eo,
  ...Jh
]), Fo = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], td = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], nd = /* @__PURE__ */ new Set([
  ...Fo,
  ...td
]), rd = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], ad = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], id = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], Wt = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, ld = {
  [Wt.HTML]: Qh,
  [Wt.SVG]: ed,
  [Wt.MATH]: nd
}, sd = {
  [Wt.HTML]: "html",
  [Wt.SVG]: "svg",
  [Wt.MATH]: "math"
}, od = {
  [Wt.HTML]: "",
  [Wt.SVG]: "svg:",
  [Wt.MATH]: "math:"
}, ud = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), To = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...Co,
    ...Eo.map((r) => `svg:${r}`),
    ...Fo.map((r) => `math:${r}`)
  ],
  allowAttributes: Xh([
    Object.fromEntries(rd.map((r) => [r, ["*"]])),
    Object.fromEntries(ad.map((r) => [r, ["svg:*"]])),
    Object.fromEntries(id.map((r) => [r, ["math:*"]]))
  ])
};
var Qr = function(r, e, t, n, a) {
  if (n === "m") throw new TypeError("Private method is not writable");
  if (n === "a" && !a) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? r !== e || !a : !e.has(r)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? a.call(r, t) : a ? a.value = t : e.set(r, t), t;
}, L0 = function(r, e, t, n) {
  if (t === "a" && !n) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? r !== e || !n : !e.has(r)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? n : t === "a" ? n.call(r) : n ? n.value : e.get(r);
}, E0, ir, lr;
class Mo {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    E0.set(this, void 0), ir.set(this, void 0), lr.set(this, void 0), this.getConfiguration = () => va(L0(this, E0, "f")), this.sanitize = (m) => {
      const p = L0(this, ir, "f"), g = L0(this, lr, "f");
      return Zh(m, (_, C) => {
        const T = _.namespaceURI || Wt.HTML, F = C.namespaceURI || Wt.HTML, M = ld[T], w = sd[T], v = od[T], x = _.tagName.toLowerCase(), $ = `${v}${x}`, A = `${v}*`;
        if (!M.has(x) || !p.has($) || T !== F && x !== w)
          C.removeChild(_);
        else {
          const q = _.getAttributeNames(), B = q.length;
          if (B) {
            for (let z = 0; z < B; z++) {
              const U = q[z], N = g[U];
              (!N || !N.has(A) && !N.has($)) && _.removeAttribute(U);
            }
            if (Hh(_))
              if (Wh(_)) {
                const z = _.getAttribute("href");
                z && jh(z) && jn(_.protocol) && _.removeAttribute("href");
              } else Uh(_) ? jn(_.action) && _.removeAttribute("action") : Vh(_) ? jn(_.formAction) && _.removeAttribute("formaction") : Gh(_) && (jn(_.src) && _.removeAttribute("formaction"), _.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), m;
    }, this.sanitizeFor = (m, p) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: t, allowCustomElements: n, allowUnknownMarkup: a, blockElements: i, dropElements: l, dropAttributes: s } = e;
    if (t === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (n)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (a)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (i)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (l)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (s)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    Qr(this, E0, va(To), "f");
    const { allowElements: o, allowAttributes: h } = e;
    o && (L0(this, E0, "f").allowElements = e.allowElements), h && (L0(this, E0, "f").allowAttributes = e.allowAttributes), Qr(this, ir, new Set(L0(this, E0, "f").allowElements), "f"), Qr(this, lr, Object.fromEntries(Object.entries(L0(this, E0, "f").allowAttributes || {}).map(([m, p]) => [m, new Set(p)])), "f");
  }
}
E0 = /* @__PURE__ */ new WeakMap(), ir = /* @__PURE__ */ new WeakMap(), lr = /* @__PURE__ */ new WeakMap();
Mo.getDefaultConfiguration = () => va(To);
const cd = (r, e) => {
  try {
    return !!r && new URL(r).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function ml(r, e) {
  const t = new Mo(), n = new DOMParser().parseFromString(r, "text/html");
  return zo(n.body, "A", (a) => {
    a instanceof HTMLElement && "target" in a && cd(a.getAttribute("href"), e) && (a.setAttribute("target", "_blank"), a.setAttribute("rel", "noopener noreferrer"));
  }), t.sanitize(n).body.innerHTML;
}
function zo(r, e, t) {
  r && (r.nodeName === e || typeof e == "function") && t(r);
  const n = (r == null ? void 0 : r.childNodes) || [];
  for (let a = 0; a < n.length; a++)
    zo(n[a], e, t);
}
const {
  HtmlTagHydration: hd,
  SvelteComponent: dd,
  attr: md,
  binding_callbacks: fd,
  children: pd,
  claim_element: gd,
  claim_html_tag: _d,
  detach: fl,
  element: vd,
  init: yd,
  insert_hydration: bd,
  noop: pl,
  safe_not_equal: wd,
  toggle_class: Xn
} = window.__gradio__svelte__internal, { afterUpdate: xd } = window.__gradio__svelte__internal;
function kd(r) {
  let e, t;
  return {
    c() {
      e = vd("span"), t = new hd(!1), this.h();
    },
    l(n) {
      e = gd(n, "SPAN", { class: !0 });
      var a = pd(e);
      t = _d(a, !1), a.forEach(fl), this.h();
    },
    h() {
      t.a = null, md(e, "class", "md svelte-1m32c2s"), Xn(
        e,
        "chatbot",
        /*chatbot*/
        r[0]
      ), Xn(
        e,
        "prose",
        /*render_markdown*/
        r[1]
      );
    },
    m(n, a) {
      bd(n, e, a), t.m(
        /*html*/
        r[3],
        e
      ), r[10](e);
    },
    p(n, [a]) {
      a & /*html*/
      8 && t.p(
        /*html*/
        n[3]
      ), a & /*chatbot*/
      1 && Xn(
        e,
        "chatbot",
        /*chatbot*/
        n[0]
      ), a & /*render_markdown*/
      2 && Xn(
        e,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    i: pl,
    o: pl,
    d(n) {
      n && fl(e), r[10](null);
    }
  };
}
function gl(r) {
  return r.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Sd(r, e, t) {
  var n = this && this.__awaiter || function(w, v, x, $) {
    function E(A) {
      return A instanceof x ? A : new x(function(q) {
        q(A);
      });
    }
    return new (x || (x = Promise))(function(A, q) {
      function B(N) {
        try {
          U($.next(N));
        } catch (K) {
          q(K);
        }
      }
      function z(N) {
        try {
          U($.throw(N));
        } catch (K) {
          q(K);
        }
      }
      function U(N) {
        N.done ? A(N.value) : E(N.value).then(B, z);
      }
      U(($ = $.apply(w, v || [])).next());
    });
  };
  let { chatbot: a = !0 } = e, { message: i } = e, { sanitize_html: l = !0 } = e, { latex_delimiters: s = [] } = e, { render_markdown: o = !0 } = e, { line_breaks: h = !0 } = e, { header_links: m = !1 } = e, { root: p } = e, g, _;
  const C = Oh({
    header_links: m,
    line_breaks: h,
    latex_delimiters: s
  });
  function T(w) {
    let v = w;
    if (o) {
      const x = [];
      s.forEach(($, E) => {
        const A = gl($.left), q = gl($.right), B = new RegExp(`${A}([\\s\\S]+?)${q}`, "g");
        v = v.replace(B, (z, U) => (x.push(z), `%%%LATEX_BLOCK_${x.length - 1}%%%`));
      }), v = C.parse(v), v = v.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, ($, E) => x[parseInt(E, 10)]);
    }
    return l && ml && (v = ml(v, p)), v;
  }
  function F(w) {
    return n(this, void 0, void 0, function* () {
      s.length > 0 && w && s.some((x) => w.includes(x.left) && w.includes(x.right)) && Pc(g, {
        delimiters: s,
        throwOnError: !1
      });
    });
  }
  xd(() => n(void 0, void 0, void 0, function* () {
    g && document.body.contains(g) ? yield F(i) : console.error("Element is not in the DOM");
  }));
  function M(w) {
    fd[w ? "unshift" : "push"](() => {
      g = w, t(2, g);
    });
  }
  return r.$$set = (w) => {
    "chatbot" in w && t(0, a = w.chatbot), "message" in w && t(4, i = w.message), "sanitize_html" in w && t(5, l = w.sanitize_html), "latex_delimiters" in w && t(6, s = w.latex_delimiters), "render_markdown" in w && t(1, o = w.render_markdown), "line_breaks" in w && t(7, h = w.line_breaks), "header_links" in w && t(8, m = w.header_links), "root" in w && t(9, p = w.root);
  }, r.$$.update = () => {
    r.$$.dirty & /*message*/
    16 && (i && i.trim() ? t(3, _ = T(i)) : t(3, _ = ""));
  }, [
    a,
    o,
    g,
    _,
    i,
    l,
    s,
    h,
    m,
    p,
    M
  ];
}
class $d extends dd {
  constructor(e) {
    super(), yd(this, e, Sd, kd, wd, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      root: 9
    });
  }
}
const {
  SvelteComponent: b4,
  attr: w4,
  children: x4,
  claim_component: k4,
  claim_element: S4,
  create_component: $4,
  destroy_component: D4,
  detach: A4,
  element: C4,
  init: E4,
  insert_hydration: F4,
  mount_component: T4,
  safe_not_equal: M4,
  transition_in: z4,
  transition_out: B4
} = window.__gradio__svelte__internal, {
  SvelteComponent: q4,
  attr: R4,
  check_outros: N4,
  children: L4,
  claim_component: I4,
  claim_element: O4,
  claim_space: P4,
  create_component: H4,
  create_slot: U4,
  destroy_component: G4,
  detach: V4,
  element: W4,
  empty: j4,
  get_all_dirty_from_scope: X4,
  get_slot_changes: Y4,
  group_outros: Z4,
  init: K4,
  insert_hydration: Q4,
  mount_component: J4,
  safe_not_equal: ef,
  space: tf,
  toggle_class: nf,
  transition_in: rf,
  transition_out: af,
  update_slot_base: lf
} = window.__gradio__svelte__internal, {
  SvelteComponent: sf,
  append_hydration: of,
  attr: uf,
  children: cf,
  claim_component: hf,
  claim_element: df,
  claim_space: mf,
  claim_text: ff,
  create_component: pf,
  destroy_component: gf,
  detach: _f,
  element: vf,
  init: yf,
  insert_hydration: bf,
  mount_component: wf,
  safe_not_equal: xf,
  set_data: kf,
  space: Sf,
  text: $f,
  toggle_class: Df,
  transition_in: Af,
  transition_out: Cf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dd,
  append_hydration: ya,
  attr: p0,
  bubble: Ad,
  check_outros: Cd,
  children: ba,
  claim_component: Ed,
  claim_element: wa,
  claim_space: Fd,
  claim_text: Td,
  construct_svelte_component: _l,
  create_component: vl,
  destroy_component: yl,
  detach: xn,
  element: xa,
  group_outros: Md,
  init: zd,
  insert_hydration: Bo,
  listen: Bd,
  mount_component: bl,
  safe_not_equal: qd,
  set_data: Rd,
  set_style: Yn,
  space: Nd,
  text: Ld,
  toggle_class: dt,
  transition_in: wl,
  transition_out: xl
} = window.__gradio__svelte__internal;
function kl(r) {
  let e, t;
  return {
    c() {
      e = xa("span"), t = Ld(
        /*label*/
        r[1]
      ), this.h();
    },
    l(n) {
      e = wa(n, "SPAN", { class: !0 });
      var a = ba(e);
      t = Td(
        a,
        /*label*/
        r[1]
      ), a.forEach(xn), this.h();
    },
    h() {
      p0(e, "class", "svelte-vk34kx");
    },
    m(n, a) {
      Bo(n, e, a), ya(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && Rd(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && xn(e);
    }
  };
}
function Id(r) {
  let e, t, n, a, i, l, s, o = (
    /*show_label*/
    r[2] && kl(r)
  );
  var h = (
    /*Icon*/
    r[0]
  );
  function m(p, g) {
    return {};
  }
  return h && (a = _l(h, m())), {
    c() {
      e = xa("button"), o && o.c(), t = Nd(), n = xa("div"), a && vl(a.$$.fragment), this.h();
    },
    l(p) {
      e = wa(p, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var g = ba(e);
      o && o.l(g), t = Fd(g), n = wa(g, "DIV", { class: !0 });
      var _ = ba(n);
      a && Ed(a.$$.fragment, _), _.forEach(xn), g.forEach(xn), this.h();
    },
    h() {
      p0(n, "class", "svelte-vk34kx"), dt(
        n,
        "small",
        /*size*/
        r[4] === "small"
      ), dt(
        n,
        "large",
        /*size*/
        r[4] === "large"
      ), dt(
        n,
        "medium",
        /*size*/
        r[4] === "medium"
      ), e.disabled = /*disabled*/
      r[7], p0(
        e,
        "aria-label",
        /*label*/
        r[1]
      ), p0(
        e,
        "aria-haspopup",
        /*hasPopup*/
        r[8]
      ), p0(
        e,
        "title",
        /*label*/
        r[1]
      ), p0(e, "class", "svelte-vk34kx"), dt(
        e,
        "pending",
        /*pending*/
        r[3]
      ), dt(
        e,
        "padded",
        /*padded*/
        r[5]
      ), dt(
        e,
        "highlight",
        /*highlight*/
        r[6]
      ), dt(
        e,
        "transparent",
        /*transparent*/
        r[9]
      ), Yn(e, "color", !/*disabled*/
      r[7] && /*_color*/
      r[11] ? (
        /*_color*/
        r[11]
      ) : "var(--block-label-text-color)"), Yn(e, "--bg-color", /*disabled*/
      r[7] ? "auto" : (
        /*background*/
        r[10]
      ));
    },
    m(p, g) {
      Bo(p, e, g), o && o.m(e, null), ya(e, t), ya(e, n), a && bl(a, n, null), i = !0, l || (s = Bd(
        e,
        "click",
        /*click_handler*/
        r[13]
      ), l = !0);
    },
    p(p, [g]) {
      if (/*show_label*/
      p[2] ? o ? o.p(p, g) : (o = kl(p), o.c(), o.m(e, t)) : o && (o.d(1), o = null), g & /*Icon*/
      1 && h !== (h = /*Icon*/
      p[0])) {
        if (a) {
          Md();
          const _ = a;
          xl(_.$$.fragment, 1, 0, () => {
            yl(_, 1);
          }), Cd();
        }
        h ? (a = _l(h, m()), vl(a.$$.fragment), wl(a.$$.fragment, 1), bl(a, n, null)) : a = null;
      }
      (!i || g & /*size*/
      16) && dt(
        n,
        "small",
        /*size*/
        p[4] === "small"
      ), (!i || g & /*size*/
      16) && dt(
        n,
        "large",
        /*size*/
        p[4] === "large"
      ), (!i || g & /*size*/
      16) && dt(
        n,
        "medium",
        /*size*/
        p[4] === "medium"
      ), (!i || g & /*disabled*/
      128) && (e.disabled = /*disabled*/
      p[7]), (!i || g & /*label*/
      2) && p0(
        e,
        "aria-label",
        /*label*/
        p[1]
      ), (!i || g & /*hasPopup*/
      256) && p0(
        e,
        "aria-haspopup",
        /*hasPopup*/
        p[8]
      ), (!i || g & /*label*/
      2) && p0(
        e,
        "title",
        /*label*/
        p[1]
      ), (!i || g & /*pending*/
      8) && dt(
        e,
        "pending",
        /*pending*/
        p[3]
      ), (!i || g & /*padded*/
      32) && dt(
        e,
        "padded",
        /*padded*/
        p[5]
      ), (!i || g & /*highlight*/
      64) && dt(
        e,
        "highlight",
        /*highlight*/
        p[6]
      ), (!i || g & /*transparent*/
      512) && dt(
        e,
        "transparent",
        /*transparent*/
        p[9]
      ), g & /*disabled, _color*/
      2176 && Yn(e, "color", !/*disabled*/
      p[7] && /*_color*/
      p[11] ? (
        /*_color*/
        p[11]
      ) : "var(--block-label-text-color)"), g & /*disabled, background*/
      1152 && Yn(e, "--bg-color", /*disabled*/
      p[7] ? "auto" : (
        /*background*/
        p[10]
      ));
    },
    i(p) {
      i || (a && wl(a.$$.fragment, p), i = !0);
    },
    o(p) {
      a && xl(a.$$.fragment, p), i = !1;
    },
    d(p) {
      p && xn(e), o && o.d(), a && yl(a), l = !1, s();
    }
  };
}
function Od(r, e, t) {
  let n, { Icon: a } = e, { label: i = "" } = e, { show_label: l = !1 } = e, { pending: s = !1 } = e, { size: o = "small" } = e, { padded: h = !0 } = e, { highlight: m = !1 } = e, { disabled: p = !1 } = e, { hasPopup: g = !1 } = e, { color: _ = "var(--block-label-text-color)" } = e, { transparent: C = !1 } = e, { background: T = "var(--block-background-fill)" } = e;
  function F(M) {
    Ad.call(this, r, M);
  }
  return r.$$set = (M) => {
    "Icon" in M && t(0, a = M.Icon), "label" in M && t(1, i = M.label), "show_label" in M && t(2, l = M.show_label), "pending" in M && t(3, s = M.pending), "size" in M && t(4, o = M.size), "padded" in M && t(5, h = M.padded), "highlight" in M && t(6, m = M.highlight), "disabled" in M && t(7, p = M.disabled), "hasPopup" in M && t(8, g = M.hasPopup), "color" in M && t(12, _ = M.color), "transparent" in M && t(9, C = M.transparent), "background" in M && t(10, T = M.background);
  }, r.$$.update = () => {
    r.$$.dirty & /*highlight, color*/
    4160 && t(11, n = m ? "var(--color-accent)" : _);
  }, [
    a,
    i,
    l,
    s,
    o,
    h,
    m,
    p,
    g,
    C,
    T,
    n,
    _,
    F
  ];
}
class Pd extends Dd {
  constructor(e) {
    super(), zd(this, e, Od, Id, qd, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Ef,
  append_hydration: Ff,
  attr: Tf,
  binding_callbacks: Mf,
  children: zf,
  claim_element: Bf,
  create_slot: qf,
  detach: Rf,
  element: Nf,
  get_all_dirty_from_scope: Lf,
  get_slot_changes: If,
  init: Of,
  insert_hydration: Pf,
  safe_not_equal: Hf,
  toggle_class: Uf,
  transition_in: Gf,
  transition_out: Vf,
  update_slot_base: Wf
} = window.__gradio__svelte__internal, {
  SvelteComponent: jf,
  append_hydration: Xf,
  attr: Yf,
  children: Zf,
  claim_svg_element: Kf,
  detach: Qf,
  init: Jf,
  insert_hydration: ep,
  noop: tp,
  safe_not_equal: np,
  svg_element: rp
} = window.__gradio__svelte__internal, {
  SvelteComponent: ap,
  append_hydration: ip,
  attr: lp,
  children: sp,
  claim_svg_element: op,
  detach: up,
  init: cp,
  insert_hydration: hp,
  noop: dp,
  safe_not_equal: mp,
  svg_element: fp
} = window.__gradio__svelte__internal, {
  SvelteComponent: pp,
  append_hydration: gp,
  attr: _p,
  children: vp,
  claim_svg_element: yp,
  detach: bp,
  init: wp,
  insert_hydration: xp,
  noop: kp,
  safe_not_equal: Sp,
  svg_element: $p
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dp,
  append_hydration: Ap,
  attr: Cp,
  children: Ep,
  claim_svg_element: Fp,
  detach: Tp,
  init: Mp,
  insert_hydration: zp,
  noop: Bp,
  safe_not_equal: qp,
  svg_element: Rp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Np,
  append_hydration: Lp,
  attr: Ip,
  children: Op,
  claim_svg_element: Pp,
  detach: Hp,
  init: Up,
  insert_hydration: Gp,
  noop: Vp,
  safe_not_equal: Wp,
  svg_element: jp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xp,
  append_hydration: Yp,
  attr: Zp,
  children: Kp,
  claim_svg_element: Qp,
  detach: Jp,
  init: e2,
  insert_hydration: t2,
  noop: n2,
  safe_not_equal: r2,
  svg_element: a2
} = window.__gradio__svelte__internal, {
  SvelteComponent: i2,
  append_hydration: l2,
  attr: s2,
  children: o2,
  claim_svg_element: u2,
  detach: c2,
  init: h2,
  insert_hydration: d2,
  noop: m2,
  safe_not_equal: f2,
  svg_element: p2
} = window.__gradio__svelte__internal, {
  SvelteComponent: g2,
  append_hydration: _2,
  attr: v2,
  children: y2,
  claim_svg_element: b2,
  detach: w2,
  init: x2,
  insert_hydration: k2,
  noop: S2,
  safe_not_equal: $2,
  svg_element: D2
} = window.__gradio__svelte__internal, {
  SvelteComponent: A2,
  append_hydration: C2,
  attr: E2,
  children: F2,
  claim_svg_element: T2,
  detach: M2,
  init: z2,
  insert_hydration: B2,
  noop: q2,
  safe_not_equal: R2,
  svg_element: N2
} = window.__gradio__svelte__internal, {
  SvelteComponent: L2,
  append_hydration: I2,
  attr: O2,
  children: P2,
  claim_svg_element: H2,
  detach: U2,
  init: G2,
  insert_hydration: V2,
  noop: W2,
  safe_not_equal: j2,
  svg_element: X2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y2,
  append_hydration: Z2,
  attr: K2,
  children: Q2,
  claim_svg_element: J2,
  detach: e5,
  init: t5,
  insert_hydration: n5,
  noop: r5,
  safe_not_equal: a5,
  set_style: i5,
  svg_element: l5
} = window.__gradio__svelte__internal, {
  SvelteComponent: s5,
  append_hydration: o5,
  attr: u5,
  children: c5,
  claim_svg_element: h5,
  detach: d5,
  init: m5,
  insert_hydration: f5,
  noop: p5,
  safe_not_equal: g5,
  svg_element: _5
} = window.__gradio__svelte__internal, {
  SvelteComponent: v5,
  append_hydration: y5,
  attr: b5,
  children: w5,
  claim_svg_element: x5,
  detach: k5,
  init: S5,
  insert_hydration: $5,
  noop: D5,
  safe_not_equal: A5,
  svg_element: C5
} = window.__gradio__svelte__internal, {
  SvelteComponent: E5,
  append_hydration: F5,
  attr: T5,
  children: M5,
  claim_svg_element: z5,
  detach: B5,
  init: q5,
  insert_hydration: R5,
  noop: N5,
  safe_not_equal: L5,
  svg_element: I5
} = window.__gradio__svelte__internal, {
  SvelteComponent: O5,
  append_hydration: P5,
  attr: H5,
  children: U5,
  claim_svg_element: G5,
  detach: V5,
  init: W5,
  insert_hydration: j5,
  noop: X5,
  safe_not_equal: Y5,
  svg_element: Z5
} = window.__gradio__svelte__internal, {
  SvelteComponent: K5,
  append_hydration: Q5,
  attr: J5,
  children: e3,
  claim_svg_element: t3,
  detach: n3,
  init: r3,
  insert_hydration: a3,
  noop: i3,
  safe_not_equal: l3,
  svg_element: s3
} = window.__gradio__svelte__internal, {
  SvelteComponent: o3,
  append_hydration: u3,
  attr: c3,
  children: h3,
  claim_svg_element: d3,
  detach: m3,
  init: f3,
  insert_hydration: p3,
  noop: g3,
  safe_not_equal: _3,
  svg_element: v3
} = window.__gradio__svelte__internal, {
  SvelteComponent: y3,
  append_hydration: b3,
  attr: w3,
  children: x3,
  claim_svg_element: k3,
  detach: S3,
  init: $3,
  insert_hydration: D3,
  noop: A3,
  safe_not_equal: C3,
  svg_element: E3
} = window.__gradio__svelte__internal, {
  SvelteComponent: F3,
  append_hydration: T3,
  attr: M3,
  children: z3,
  claim_svg_element: B3,
  detach: q3,
  init: R3,
  insert_hydration: N3,
  noop: L3,
  safe_not_equal: I3,
  svg_element: O3
} = window.__gradio__svelte__internal, {
  SvelteComponent: P3,
  append_hydration: H3,
  attr: U3,
  children: G3,
  claim_svg_element: V3,
  detach: W3,
  init: j3,
  insert_hydration: X3,
  noop: Y3,
  safe_not_equal: Z3,
  svg_element: K3
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q3,
  append_hydration: J3,
  attr: e6,
  children: t6,
  claim_svg_element: n6,
  detach: r6,
  init: a6,
  insert_hydration: i6,
  noop: l6,
  safe_not_equal: s6,
  svg_element: o6
} = window.__gradio__svelte__internal, {
  SvelteComponent: u6,
  append_hydration: c6,
  attr: h6,
  children: d6,
  claim_svg_element: m6,
  detach: f6,
  init: p6,
  insert_hydration: g6,
  noop: _6,
  safe_not_equal: v6,
  svg_element: y6
} = window.__gradio__svelte__internal, {
  SvelteComponent: b6,
  append_hydration: w6,
  attr: x6,
  children: k6,
  claim_svg_element: S6,
  detach: $6,
  init: D6,
  insert_hydration: A6,
  noop: C6,
  safe_not_equal: E6,
  svg_element: F6
} = window.__gradio__svelte__internal, {
  SvelteComponent: T6,
  append_hydration: M6,
  attr: z6,
  children: B6,
  claim_svg_element: q6,
  detach: R6,
  init: N6,
  insert_hydration: L6,
  noop: I6,
  safe_not_equal: O6,
  svg_element: P6
} = window.__gradio__svelte__internal, {
  SvelteComponent: H6,
  append_hydration: U6,
  attr: G6,
  children: V6,
  claim_svg_element: W6,
  detach: j6,
  init: X6,
  insert_hydration: Y6,
  noop: Z6,
  safe_not_equal: K6,
  svg_element: Q6
} = window.__gradio__svelte__internal, {
  SvelteComponent: J6,
  append_hydration: e7,
  attr: t7,
  children: n7,
  claim_svg_element: r7,
  detach: a7,
  init: i7,
  insert_hydration: l7,
  noop: s7,
  safe_not_equal: o7,
  svg_element: u7
} = window.__gradio__svelte__internal, {
  SvelteComponent: c7,
  append_hydration: h7,
  attr: d7,
  children: m7,
  claim_svg_element: f7,
  detach: p7,
  init: g7,
  insert_hydration: _7,
  noop: v7,
  safe_not_equal: y7,
  svg_element: b7
} = window.__gradio__svelte__internal, {
  SvelteComponent: w7,
  append_hydration: x7,
  attr: k7,
  children: S7,
  claim_svg_element: $7,
  detach: D7,
  init: A7,
  insert_hydration: C7,
  noop: E7,
  safe_not_equal: F7,
  svg_element: T7
} = window.__gradio__svelte__internal, {
  SvelteComponent: M7,
  append_hydration: z7,
  attr: B7,
  children: q7,
  claim_svg_element: R7,
  detach: N7,
  init: L7,
  insert_hydration: I7,
  noop: O7,
  safe_not_equal: P7,
  svg_element: H7
} = window.__gradio__svelte__internal, {
  SvelteComponent: U7,
  append_hydration: G7,
  attr: V7,
  children: W7,
  claim_svg_element: j7,
  detach: X7,
  init: Y7,
  insert_hydration: Z7,
  noop: K7,
  safe_not_equal: Q7,
  svg_element: J7
} = window.__gradio__svelte__internal, {
  SvelteComponent: e8,
  append_hydration: t8,
  attr: n8,
  children: r8,
  claim_svg_element: a8,
  detach: i8,
  init: l8,
  insert_hydration: s8,
  noop: o8,
  safe_not_equal: u8,
  svg_element: c8
} = window.__gradio__svelte__internal, {
  SvelteComponent: h8,
  append_hydration: d8,
  attr: m8,
  children: f8,
  claim_svg_element: p8,
  detach: g8,
  init: _8,
  insert_hydration: v8,
  noop: y8,
  safe_not_equal: b8,
  svg_element: w8
} = window.__gradio__svelte__internal, {
  SvelteComponent: x8,
  append_hydration: k8,
  attr: S8,
  children: $8,
  claim_svg_element: D8,
  detach: A8,
  init: C8,
  insert_hydration: E8,
  noop: F8,
  safe_not_equal: T8,
  svg_element: M8
} = window.__gradio__svelte__internal, {
  SvelteComponent: z8,
  append_hydration: B8,
  attr: q8,
  children: R8,
  claim_svg_element: N8,
  detach: L8,
  init: I8,
  insert_hydration: O8,
  noop: P8,
  safe_not_equal: H8,
  svg_element: U8
} = window.__gradio__svelte__internal, {
  SvelteComponent: G8,
  append_hydration: V8,
  attr: W8,
  children: j8,
  claim_svg_element: X8,
  detach: Y8,
  init: Z8,
  insert_hydration: K8,
  noop: Q8,
  safe_not_equal: J8,
  svg_element: eg
} = window.__gradio__svelte__internal, {
  SvelteComponent: tg,
  append_hydration: ng,
  attr: rg,
  children: ag,
  claim_svg_element: ig,
  detach: lg,
  init: sg,
  insert_hydration: og,
  noop: ug,
  safe_not_equal: cg,
  svg_element: hg
} = window.__gradio__svelte__internal, {
  SvelteComponent: dg,
  append_hydration: mg,
  attr: fg,
  children: pg,
  claim_svg_element: gg,
  detach: _g,
  init: vg,
  insert_hydration: yg,
  noop: bg,
  safe_not_equal: wg,
  svg_element: xg
} = window.__gradio__svelte__internal, {
  SvelteComponent: kg,
  append_hydration: Sg,
  attr: $g,
  children: Dg,
  claim_svg_element: Ag,
  detach: Cg,
  init: Eg,
  insert_hydration: Fg,
  noop: Tg,
  safe_not_equal: Mg,
  svg_element: zg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bg,
  append_hydration: qg,
  attr: Rg,
  children: Ng,
  claim_svg_element: Lg,
  detach: Ig,
  init: Og,
  insert_hydration: Pg,
  noop: Hg,
  safe_not_equal: Ug,
  svg_element: Gg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vg,
  append_hydration: Wg,
  attr: jg,
  children: Xg,
  claim_svg_element: Yg,
  detach: Zg,
  init: Kg,
  insert_hydration: Qg,
  noop: Jg,
  safe_not_equal: e_,
  svg_element: t_
} = window.__gradio__svelte__internal, {
  SvelteComponent: n_,
  append_hydration: r_,
  attr: a_,
  children: i_,
  claim_svg_element: l_,
  detach: s_,
  init: o_,
  insert_hydration: u_,
  noop: c_,
  safe_not_equal: h_,
  set_style: d_,
  svg_element: m_
} = window.__gradio__svelte__internal, {
  SvelteComponent: f_,
  append_hydration: p_,
  attr: g_,
  children: __,
  claim_svg_element: v_,
  detach: y_,
  init: b_,
  insert_hydration: w_,
  noop: x_,
  safe_not_equal: k_,
  svg_element: S_
} = window.__gradio__svelte__internal, {
  SvelteComponent: $_,
  append_hydration: D_,
  attr: A_,
  children: C_,
  claim_svg_element: E_,
  detach: F_,
  init: T_,
  insert_hydration: M_,
  noop: z_,
  safe_not_equal: B_,
  svg_element: q_
} = window.__gradio__svelte__internal, {
  SvelteComponent: R_,
  append_hydration: N_,
  attr: L_,
  children: I_,
  claim_svg_element: O_,
  detach: P_,
  init: H_,
  insert_hydration: U_,
  noop: G_,
  safe_not_equal: V_,
  svg_element: W_
} = window.__gradio__svelte__internal, {
  SvelteComponent: j_,
  append_hydration: X_,
  attr: Y_,
  children: Z_,
  claim_svg_element: K_,
  detach: Q_,
  init: J_,
  insert_hydration: e9,
  noop: t9,
  safe_not_equal: n9,
  svg_element: r9
} = window.__gradio__svelte__internal, {
  SvelteComponent: a9,
  append_hydration: i9,
  attr: l9,
  children: s9,
  claim_svg_element: o9,
  detach: u9,
  init: c9,
  insert_hydration: h9,
  noop: d9,
  safe_not_equal: m9,
  svg_element: f9
} = window.__gradio__svelte__internal, {
  SvelteComponent: p9,
  append_hydration: g9,
  attr: _9,
  children: v9,
  claim_svg_element: y9,
  detach: b9,
  init: w9,
  insert_hydration: x9,
  noop: k9,
  safe_not_equal: S9,
  svg_element: $9
} = window.__gradio__svelte__internal, {
  SvelteComponent: D9,
  append_hydration: A9,
  attr: C9,
  children: E9,
  claim_svg_element: F9,
  detach: T9,
  init: M9,
  insert_hydration: z9,
  noop: B9,
  safe_not_equal: q9,
  svg_element: R9
} = window.__gradio__svelte__internal, {
  SvelteComponent: N9,
  append_hydration: L9,
  attr: I9,
  children: O9,
  claim_svg_element: P9,
  detach: H9,
  init: U9,
  insert_hydration: G9,
  noop: V9,
  safe_not_equal: W9,
  svg_element: j9
} = window.__gradio__svelte__internal, {
  SvelteComponent: X9,
  append_hydration: Y9,
  attr: Z9,
  children: K9,
  claim_svg_element: Q9,
  claim_text: J9,
  detach: ev,
  init: tv,
  insert_hydration: nv,
  noop: rv,
  safe_not_equal: av,
  svg_element: iv,
  text: lv
} = window.__gradio__svelte__internal, {
  SvelteComponent: sv,
  append_hydration: ov,
  attr: uv,
  children: cv,
  claim_svg_element: hv,
  detach: dv,
  init: mv,
  insert_hydration: fv,
  noop: pv,
  safe_not_equal: gv,
  svg_element: _v
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  append_hydration: yv,
  attr: bv,
  children: wv,
  claim_svg_element: xv,
  detach: kv,
  init: Sv,
  insert_hydration: $v,
  noop: Dv,
  safe_not_equal: Av,
  svg_element: Cv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ev,
  append_hydration: Fv,
  attr: Tv,
  children: Mv,
  claim_svg_element: zv,
  detach: Bv,
  init: qv,
  insert_hydration: Rv,
  noop: Nv,
  safe_not_equal: Lv,
  svg_element: Iv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ov,
  append_hydration: Pv,
  attr: Hv,
  children: Uv,
  claim_svg_element: Gv,
  detach: Vv,
  init: Wv,
  insert_hydration: jv,
  noop: Xv,
  safe_not_equal: Yv,
  svg_element: Zv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kv,
  append_hydration: Qv,
  attr: Jv,
  children: ey,
  claim_svg_element: ty,
  detach: ny,
  init: ry,
  insert_hydration: ay,
  noop: iy,
  safe_not_equal: ly,
  svg_element: sy
} = window.__gradio__svelte__internal, {
  SvelteComponent: oy,
  append_hydration: uy,
  attr: cy,
  children: hy,
  claim_svg_element: dy,
  claim_text: my,
  detach: fy,
  init: py,
  insert_hydration: gy,
  noop: _y,
  safe_not_equal: vy,
  svg_element: yy,
  text: by
} = window.__gradio__svelte__internal, {
  SvelteComponent: wy,
  append_hydration: xy,
  attr: ky,
  children: Sy,
  claim_svg_element: $y,
  claim_text: Dy,
  detach: Ay,
  init: Cy,
  insert_hydration: Ey,
  noop: Fy,
  safe_not_equal: Ty,
  svg_element: My,
  text: zy
} = window.__gradio__svelte__internal, {
  SvelteComponent: By,
  append_hydration: qy,
  attr: Ry,
  children: Ny,
  claim_svg_element: Ly,
  claim_text: Iy,
  detach: Oy,
  init: Py,
  insert_hydration: Hy,
  noop: Uy,
  safe_not_equal: Gy,
  svg_element: Vy,
  text: Wy
} = window.__gradio__svelte__internal, {
  SvelteComponent: jy,
  append_hydration: Xy,
  attr: Yy,
  children: Zy,
  claim_svg_element: Ky,
  detach: Qy,
  init: Jy,
  insert_hydration: eb,
  noop: tb,
  safe_not_equal: nb,
  svg_element: rb
} = window.__gradio__svelte__internal, {
  SvelteComponent: ab,
  append_hydration: ib,
  attr: lb,
  children: sb,
  claim_svg_element: ob,
  detach: ub,
  init: cb,
  insert_hydration: hb,
  noop: db,
  safe_not_equal: mb,
  svg_element: fb
} = window.__gradio__svelte__internal, {
  SvelteComponent: pb,
  append_hydration: gb,
  attr: _b,
  children: vb,
  claim_svg_element: yb,
  detach: bb,
  init: wb,
  insert_hydration: xb,
  noop: kb,
  safe_not_equal: Sb,
  svg_element: $b
} = window.__gradio__svelte__internal, {
  SvelteComponent: Db,
  append_hydration: Ab,
  attr: Cb,
  children: Eb,
  claim_svg_element: Fb,
  detach: Tb,
  init: Mb,
  insert_hydration: zb,
  noop: Bb,
  safe_not_equal: qb,
  svg_element: Rb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nb,
  append_hydration: Lb,
  attr: Ib,
  children: Ob,
  claim_svg_element: Pb,
  detach: Hb,
  init: Ub,
  insert_hydration: Gb,
  noop: Vb,
  safe_not_equal: Wb,
  svg_element: jb
} = window.__gradio__svelte__internal, Hd = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Sl = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Hd.reduce(
  (r, { color: e, primary: t, secondary: n }) => ({
    ...r,
    [e]: {
      primary: Sl[e][t],
      secondary: Sl[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: Xb,
  claim_component: Yb,
  create_component: Zb,
  destroy_component: Kb,
  init: Qb,
  mount_component: Jb,
  safe_not_equal: ew,
  transition_in: tw,
  transition_out: nw
} = window.__gradio__svelte__internal, { createEventDispatcher: rw } = window.__gradio__svelte__internal, {
  SvelteComponent: aw,
  append_hydration: iw,
  attr: lw,
  check_outros: sw,
  children: ow,
  claim_component: uw,
  claim_element: cw,
  claim_space: hw,
  claim_text: dw,
  create_component: mw,
  destroy_component: fw,
  detach: pw,
  element: gw,
  empty: _w,
  group_outros: vw,
  init: yw,
  insert_hydration: bw,
  mount_component: ww,
  safe_not_equal: xw,
  set_data: kw,
  space: Sw,
  text: $w,
  toggle_class: Dw,
  transition_in: Aw,
  transition_out: Cw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ew,
  attr: Fw,
  children: Tw,
  claim_element: Mw,
  create_slot: zw,
  detach: Bw,
  element: qw,
  get_all_dirty_from_scope: Rw,
  get_slot_changes: Nw,
  init: Lw,
  insert_hydration: Iw,
  safe_not_equal: Ow,
  toggle_class: Pw,
  transition_in: Hw,
  transition_out: Uw,
  update_slot_base: Gw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vw,
  append_hydration: Ww,
  attr: jw,
  check_outros: Xw,
  children: Yw,
  claim_component: Zw,
  claim_element: Kw,
  claim_space: Qw,
  create_component: Jw,
  destroy_component: ex,
  detach: tx,
  element: nx,
  empty: rx,
  group_outros: ax,
  init: ix,
  insert_hydration: lx,
  listen: sx,
  mount_component: ox,
  safe_not_equal: ux,
  space: cx,
  toggle_class: hx,
  transition_in: dx,
  transition_out: mx
} = window.__gradio__svelte__internal, {
  SvelteComponent: fx,
  attr: px,
  children: gx,
  claim_element: _x,
  create_slot: vx,
  detach: yx,
  element: bx,
  get_all_dirty_from_scope: wx,
  get_slot_changes: xx,
  init: kx,
  insert_hydration: Sx,
  null_to_empty: $x,
  safe_not_equal: Dx,
  transition_in: Ax,
  transition_out: Cx,
  update_slot_base: Ex
} = window.__gradio__svelte__internal;
function en(r) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; r > 1e3 && t < e.length - 1; )
    r /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(r) ? r : r.toFixed(1)) + n;
}
function sr() {
}
function Ud(r, e) {
  return r != r ? e == e : r !== e || r && typeof r == "object" || typeof r == "function";
}
const qo = typeof window < "u";
let $l = qo ? () => window.performance.now() : () => Date.now(), Ro = qo ? (r) => requestAnimationFrame(r) : sr;
const nn = /* @__PURE__ */ new Set();
function No(r) {
  nn.forEach((e) => {
    e.c(r) || (nn.delete(e), e.f());
  }), nn.size !== 0 && Ro(No);
}
function Gd(r) {
  let e;
  return nn.size === 0 && Ro(No), {
    promise: new Promise((t) => {
      nn.add(e = { c: r, f: t });
    }),
    abort() {
      nn.delete(e);
    }
  };
}
const J0 = [];
function Vd(r, e = sr) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(s) {
    if (Ud(r, s) && (r = s, t)) {
      const o = !J0.length;
      for (const h of n)
        h[1](), J0.push(h, r);
      if (o) {
        for (let h = 0; h < J0.length; h += 2)
          J0[h][0](J0[h + 1]);
        J0.length = 0;
      }
    }
  }
  function i(s) {
    a(s(r));
  }
  function l(s, o = sr) {
    const h = [s, o];
    return n.add(h), n.size === 1 && (t = e(a, i) || sr), s(r), () => {
      n.delete(h), n.size === 0 && t && (t(), t = null);
    };
  }
  return { set: a, update: i, subscribe: l };
}
function Dl(r) {
  return Object.prototype.toString.call(r) === "[object Date]";
}
function ka(r, e, t, n) {
  if (typeof t == "number" || Dl(t)) {
    const a = n - t, i = (t - e) / (r.dt || 1 / 60), l = r.opts.stiffness * a, s = r.opts.damping * i, o = (l - s) * r.inv_mass, h = (i + o) * r.dt;
    return Math.abs(h) < r.opts.precision && Math.abs(a) < r.opts.precision ? n : (r.settled = !1, Dl(t) ? new Date(t.getTime() + h) : t + h);
  } else {
    if (Array.isArray(t))
      return t.map(
        (a, i) => ka(r, e[i], t[i], n[i])
      );
    if (typeof t == "object") {
      const a = {};
      for (const i in t)
        a[i] = ka(r, e[i], t[i], n[i]);
      return a;
    } else
      throw new Error(`Cannot spring ${typeof t} values`);
  }
}
function Al(r, e = {}) {
  const t = Vd(r), { stiffness: n = 0.15, damping: a = 0.8, precision: i = 0.01 } = e;
  let l, s, o, h = r, m = r, p = 1, g = 0, _ = !1;
  function C(F, M = {}) {
    m = F;
    const w = o = {};
    return r == null || M.hard || T.stiffness >= 1 && T.damping >= 1 ? (_ = !0, l = $l(), h = F, t.set(r = m), Promise.resolve()) : (M.soft && (g = 1 / ((M.soft === !0 ? 0.5 : +M.soft) * 60), p = 0), s || (l = $l(), _ = !1, s = Gd((v) => {
      if (_)
        return _ = !1, s = null, !1;
      p = Math.min(p + g, 1);
      const x = {
        inv_mass: p,
        opts: T,
        settled: !0,
        dt: (v - l) * 60 / 1e3
      }, $ = ka(x, h, r, m);
      return l = v, h = r, t.set(r = $), x.settled && (s = null), !x.settled;
    })), new Promise((v) => {
      s.promise.then(() => {
        w === o && v();
      });
    }));
  }
  const T = {
    set: C,
    update: (F, M) => C(F(m, r), M),
    subscribe: t.subscribe,
    stiffness: n,
    damping: a,
    precision: i
  };
  return T;
}
const {
  SvelteComponent: Wd,
  append_hydration: Lt,
  attr: se,
  children: $t,
  claim_element: jd,
  claim_svg_element: It,
  component_subscribe: Cl,
  detach: gt,
  element: Xd,
  init: Yd,
  insert_hydration: Zd,
  noop: El,
  safe_not_equal: Kd,
  set_style: Zn,
  svg_element: Ot,
  toggle_class: Fl
} = window.__gradio__svelte__internal, { onMount: Qd } = window.__gradio__svelte__internal;
function Jd(r) {
  let e, t, n, a, i, l, s, o, h, m, p, g;
  return {
    c() {
      e = Xd("div"), t = Ot("svg"), n = Ot("g"), a = Ot("path"), i = Ot("path"), l = Ot("path"), s = Ot("path"), o = Ot("g"), h = Ot("path"), m = Ot("path"), p = Ot("path"), g = Ot("path"), this.h();
    },
    l(_) {
      e = jd(_, "DIV", { class: !0 });
      var C = $t(e);
      t = It(C, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var T = $t(t);
      n = It(T, "g", { style: !0 });
      var F = $t(n);
      a = It(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), $t(a).forEach(gt), i = It(F, "path", { d: !0, fill: !0, class: !0 }), $t(i).forEach(gt), l = It(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), $t(l).forEach(gt), s = It(F, "path", { d: !0, fill: !0, class: !0 }), $t(s).forEach(gt), F.forEach(gt), o = It(T, "g", { style: !0 });
      var M = $t(o);
      h = It(M, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), $t(h).forEach(gt), m = It(M, "path", { d: !0, fill: !0, class: !0 }), $t(m).forEach(gt), p = It(M, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), $t(p).forEach(gt), g = It(M, "path", { d: !0, fill: !0, class: !0 }), $t(g).forEach(gt), M.forEach(gt), T.forEach(gt), C.forEach(gt), this.h();
    },
    h() {
      se(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), se(a, "fill", "#FF7C00"), se(a, "fill-opacity", "0.4"), se(a, "class", "svelte-43sxxs"), se(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), se(i, "fill", "#FF7C00"), se(i, "class", "svelte-43sxxs"), se(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), se(l, "fill", "#FF7C00"), se(l, "fill-opacity", "0.4"), se(l, "class", "svelte-43sxxs"), se(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), se(s, "fill", "#FF7C00"), se(s, "class", "svelte-43sxxs"), Zn(n, "transform", "translate(" + /*$top*/
      r[1][0] + "px, " + /*$top*/
      r[1][1] + "px)"), se(h, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), se(h, "fill", "#FF7C00"), se(h, "fill-opacity", "0.4"), se(h, "class", "svelte-43sxxs"), se(m, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), se(m, "fill", "#FF7C00"), se(m, "class", "svelte-43sxxs"), se(p, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), se(p, "fill", "#FF7C00"), se(p, "fill-opacity", "0.4"), se(p, "class", "svelte-43sxxs"), se(g, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), se(g, "fill", "#FF7C00"), se(g, "class", "svelte-43sxxs"), Zn(o, "transform", "translate(" + /*$bottom*/
      r[2][0] + "px, " + /*$bottom*/
      r[2][1] + "px)"), se(t, "viewBox", "-1200 -1200 3000 3000"), se(t, "fill", "none"), se(t, "xmlns", "http://www.w3.org/2000/svg"), se(t, "class", "svelte-43sxxs"), se(e, "class", "svelte-43sxxs"), Fl(
        e,
        "margin",
        /*margin*/
        r[0]
      );
    },
    m(_, C) {
      Zd(_, e, C), Lt(e, t), Lt(t, n), Lt(n, a), Lt(n, i), Lt(n, l), Lt(n, s), Lt(t, o), Lt(o, h), Lt(o, m), Lt(o, p), Lt(o, g);
    },
    p(_, [C]) {
      C & /*$top*/
      2 && Zn(n, "transform", "translate(" + /*$top*/
      _[1][0] + "px, " + /*$top*/
      _[1][1] + "px)"), C & /*$bottom*/
      4 && Zn(o, "transform", "translate(" + /*$bottom*/
      _[2][0] + "px, " + /*$bottom*/
      _[2][1] + "px)"), C & /*margin*/
      1 && Fl(
        e,
        "margin",
        /*margin*/
        _[0]
      );
    },
    i: El,
    o: El,
    d(_) {
      _ && gt(e);
    }
  };
}
function em(r, e, t) {
  let n, a;
  var i = this && this.__awaiter || function(_, C, T, F) {
    function M(w) {
      return w instanceof T ? w : new T(function(v) {
        v(w);
      });
    }
    return new (T || (T = Promise))(function(w, v) {
      function x(A) {
        try {
          E(F.next(A));
        } catch (q) {
          v(q);
        }
      }
      function $(A) {
        try {
          E(F.throw(A));
        } catch (q) {
          v(q);
        }
      }
      function E(A) {
        A.done ? w(A.value) : M(A.value).then(x, $);
      }
      E((F = F.apply(_, C || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const s = Al([0, 0]);
  Cl(r, s, (_) => t(1, n = _));
  const o = Al([0, 0]);
  Cl(r, o, (_) => t(2, a = _));
  let h;
  function m() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 140]), o.set([-125, -140])]), yield Promise.all([s.set([-125, 140]), o.set([125, -140])]), yield Promise.all([s.set([-125, 0]), o.set([125, -0])]), yield Promise.all([s.set([125, 0]), o.set([-125, 0])]);
    });
  }
  function p() {
    return i(this, void 0, void 0, function* () {
      yield m(), h || p();
    });
  }
  function g() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 0]), o.set([-125, 0])]), p();
    });
  }
  return Qd(() => (g(), () => h = !0)), r.$$set = (_) => {
    "margin" in _ && t(0, l = _.margin);
  }, [l, n, a, s, o];
}
class tm extends Wd {
  constructor(e) {
    super(), Yd(this, e, em, Jd, Kd, { margin: 0 });
  }
}
const {
  SvelteComponent: Fx,
  append_hydration: Tx,
  attr: Mx,
  children: zx,
  claim_svg_element: Bx,
  detach: qx,
  init: Rx,
  insert_hydration: Nx,
  noop: Lx,
  safe_not_equal: Ix,
  svg_element: Ox
} = window.__gradio__svelte__internal, {
  SvelteComponent: Px,
  append_hydration: Hx,
  attr: Ux,
  children: Gx,
  claim_svg_element: Vx,
  detach: Wx,
  init: jx,
  insert_hydration: Xx,
  noop: Yx,
  safe_not_equal: Zx,
  svg_element: Kx
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qx,
  append_hydration: Jx,
  attr: ek,
  children: tk,
  claim_svg_element: nk,
  detach: rk,
  init: ak,
  insert_hydration: ik,
  noop: lk,
  safe_not_equal: sk,
  svg_element: ok
} = window.__gradio__svelte__internal, {
  SvelteComponent: uk,
  append_hydration: ck,
  attr: hk,
  children: dk,
  claim_svg_element: mk,
  detach: fk,
  init: pk,
  insert_hydration: gk,
  noop: _k,
  safe_not_equal: vk,
  svg_element: yk
} = window.__gradio__svelte__internal, {
  SvelteComponent: bk,
  append_hydration: wk,
  attr: xk,
  children: kk,
  claim_svg_element: Sk,
  detach: $k,
  init: Dk,
  insert_hydration: Ak,
  noop: Ck,
  safe_not_equal: Ek,
  svg_element: Fk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tk,
  append_hydration: Mk,
  attr: zk,
  children: Bk,
  claim_svg_element: qk,
  detach: Rk,
  init: Nk,
  insert_hydration: Lk,
  noop: Ik,
  safe_not_equal: Ok,
  svg_element: Pk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hk,
  append_hydration: Uk,
  attr: Gk,
  children: Vk,
  claim_svg_element: Wk,
  detach: jk,
  init: Xk,
  insert_hydration: Yk,
  noop: Zk,
  safe_not_equal: Kk,
  svg_element: Qk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jk,
  append_hydration: eS,
  attr: tS,
  children: nS,
  claim_svg_element: rS,
  detach: aS,
  init: iS,
  insert_hydration: lS,
  noop: sS,
  safe_not_equal: oS,
  svg_element: uS
} = window.__gradio__svelte__internal, {
  SvelteComponent: cS,
  append_hydration: hS,
  attr: dS,
  children: mS,
  claim_svg_element: fS,
  detach: pS,
  init: gS,
  insert_hydration: _S,
  noop: vS,
  safe_not_equal: yS,
  svg_element: bS
} = window.__gradio__svelte__internal, {
  SvelteComponent: wS,
  append_hydration: xS,
  attr: kS,
  children: SS,
  claim_svg_element: $S,
  detach: DS,
  init: AS,
  insert_hydration: CS,
  noop: ES,
  safe_not_equal: FS,
  svg_element: TS
} = window.__gradio__svelte__internal, {
  SvelteComponent: nm,
  append_hydration: Jr,
  attr: Pt,
  children: Kn,
  claim_svg_element: Qn,
  detach: hn,
  init: rm,
  insert_hydration: am,
  noop: ea,
  safe_not_equal: im,
  set_style: Xt,
  svg_element: Jn
} = window.__gradio__svelte__internal;
function lm(r) {
  let e, t, n, a;
  return {
    c() {
      e = Jn("svg"), t = Jn("g"), n = Jn("path"), a = Jn("path"), this.h();
    },
    l(i) {
      e = Qn(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = Kn(e);
      t = Qn(l, "g", { transform: !0 });
      var s = Kn(t);
      n = Qn(s, "path", { d: !0, style: !0 }), Kn(n).forEach(hn), s.forEach(hn), a = Qn(l, "path", { d: !0, style: !0 }), Kn(a).forEach(hn), l.forEach(hn), this.h();
    },
    h() {
      Pt(n, "d", "M18,6L6.087,17.913"), Xt(n, "fill", "none"), Xt(n, "fill-rule", "nonzero"), Xt(n, "stroke-width", "2px"), Pt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Pt(a, "d", "M4.364,4.364L19.636,19.636"), Xt(a, "fill", "none"), Xt(a, "fill-rule", "nonzero"), Xt(a, "stroke-width", "2px"), Pt(e, "width", "100%"), Pt(e, "height", "100%"), Pt(e, "viewBox", "0 0 24 24"), Pt(e, "version", "1.1"), Pt(e, "xmlns", "http://www.w3.org/2000/svg"), Pt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Pt(e, "xml:space", "preserve"), Pt(e, "stroke", "currentColor"), Xt(e, "fill-rule", "evenodd"), Xt(e, "clip-rule", "evenodd"), Xt(e, "stroke-linecap", "round"), Xt(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      am(i, e, l), Jr(e, t), Jr(t, n), Jr(e, a);
    },
    p: ea,
    i: ea,
    o: ea,
    d(i) {
      i && hn(e);
    }
  };
}
class sm extends nm {
  constructor(e) {
    super(), rm(this, e, null, lm, im, {});
  }
}
const {
  SvelteComponent: MS,
  append_hydration: zS,
  attr: BS,
  children: qS,
  claim_svg_element: RS,
  detach: NS,
  init: LS,
  insert_hydration: IS,
  noop: OS,
  safe_not_equal: PS,
  svg_element: HS
} = window.__gradio__svelte__internal, {
  SvelteComponent: US,
  append_hydration: GS,
  attr: VS,
  children: WS,
  claim_svg_element: jS,
  detach: XS,
  init: YS,
  insert_hydration: ZS,
  noop: KS,
  safe_not_equal: QS,
  svg_element: JS
} = window.__gradio__svelte__internal, {
  SvelteComponent: e$,
  append_hydration: t$,
  attr: n$,
  children: r$,
  claim_svg_element: a$,
  detach: i$,
  init: l$,
  insert_hydration: s$,
  noop: o$,
  safe_not_equal: u$,
  svg_element: c$
} = window.__gradio__svelte__internal, {
  SvelteComponent: h$,
  append_hydration: d$,
  attr: m$,
  children: f$,
  claim_svg_element: p$,
  detach: g$,
  init: _$,
  insert_hydration: v$,
  noop: y$,
  safe_not_equal: b$,
  svg_element: w$
} = window.__gradio__svelte__internal, {
  SvelteComponent: x$,
  append_hydration: k$,
  attr: S$,
  children: $$,
  claim_svg_element: D$,
  detach: A$,
  init: C$,
  insert_hydration: E$,
  noop: F$,
  safe_not_equal: T$,
  svg_element: M$
} = window.__gradio__svelte__internal, {
  SvelteComponent: z$,
  append_hydration: B$,
  attr: q$,
  children: R$,
  claim_svg_element: N$,
  detach: L$,
  init: I$,
  insert_hydration: O$,
  noop: P$,
  safe_not_equal: H$,
  svg_element: U$
} = window.__gradio__svelte__internal, {
  SvelteComponent: G$,
  append_hydration: V$,
  attr: W$,
  children: j$,
  claim_svg_element: X$,
  detach: Y$,
  init: Z$,
  insert_hydration: K$,
  noop: Q$,
  safe_not_equal: J$,
  svg_element: eD
} = window.__gradio__svelte__internal, {
  SvelteComponent: tD,
  append_hydration: nD,
  attr: rD,
  children: aD,
  claim_svg_element: iD,
  detach: lD,
  init: sD,
  insert_hydration: oD,
  noop: uD,
  safe_not_equal: cD,
  svg_element: hD
} = window.__gradio__svelte__internal, {
  SvelteComponent: dD,
  append_hydration: mD,
  attr: fD,
  children: pD,
  claim_svg_element: gD,
  detach: _D,
  init: vD,
  insert_hydration: yD,
  noop: bD,
  safe_not_equal: wD,
  svg_element: xD
} = window.__gradio__svelte__internal, {
  SvelteComponent: kD,
  append_hydration: SD,
  attr: $D,
  children: DD,
  claim_svg_element: AD,
  detach: CD,
  init: ED,
  insert_hydration: FD,
  noop: TD,
  safe_not_equal: MD,
  svg_element: zD
} = window.__gradio__svelte__internal, {
  SvelteComponent: BD,
  append_hydration: qD,
  attr: RD,
  children: ND,
  claim_svg_element: LD,
  detach: ID,
  init: OD,
  insert_hydration: PD,
  noop: HD,
  safe_not_equal: UD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: VD,
  append_hydration: WD,
  attr: jD,
  children: XD,
  claim_svg_element: YD,
  detach: ZD,
  init: KD,
  insert_hydration: QD,
  noop: JD,
  safe_not_equal: eA,
  svg_element: tA
} = window.__gradio__svelte__internal, {
  SvelteComponent: nA,
  append_hydration: rA,
  attr: aA,
  children: iA,
  claim_svg_element: lA,
  detach: sA,
  init: oA,
  insert_hydration: uA,
  noop: cA,
  safe_not_equal: hA,
  svg_element: dA
} = window.__gradio__svelte__internal, {
  SvelteComponent: mA,
  append_hydration: fA,
  attr: pA,
  children: gA,
  claim_svg_element: _A,
  detach: vA,
  init: yA,
  insert_hydration: bA,
  noop: wA,
  safe_not_equal: xA,
  svg_element: kA
} = window.__gradio__svelte__internal, {
  SvelteComponent: SA,
  append_hydration: $A,
  attr: DA,
  children: AA,
  claim_svg_element: CA,
  detach: EA,
  init: FA,
  insert_hydration: TA,
  noop: MA,
  safe_not_equal: zA,
  svg_element: BA
} = window.__gradio__svelte__internal, {
  SvelteComponent: qA,
  append_hydration: RA,
  attr: NA,
  children: LA,
  claim_svg_element: IA,
  detach: OA,
  init: PA,
  insert_hydration: HA,
  noop: UA,
  safe_not_equal: GA,
  svg_element: VA
} = window.__gradio__svelte__internal, {
  SvelteComponent: WA,
  append_hydration: jA,
  attr: XA,
  children: YA,
  claim_svg_element: ZA,
  detach: KA,
  init: QA,
  insert_hydration: JA,
  noop: eC,
  safe_not_equal: tC,
  svg_element: nC
} = window.__gradio__svelte__internal, {
  SvelteComponent: rC,
  append_hydration: aC,
  attr: iC,
  children: lC,
  claim_svg_element: sC,
  detach: oC,
  init: uC,
  insert_hydration: cC,
  noop: hC,
  safe_not_equal: dC,
  svg_element: mC
} = window.__gradio__svelte__internal, {
  SvelteComponent: fC,
  append_hydration: pC,
  attr: gC,
  children: _C,
  claim_svg_element: vC,
  detach: yC,
  init: bC,
  insert_hydration: wC,
  noop: xC,
  safe_not_equal: kC,
  svg_element: SC
} = window.__gradio__svelte__internal, {
  SvelteComponent: $C,
  append_hydration: DC,
  attr: AC,
  children: CC,
  claim_svg_element: EC,
  detach: FC,
  init: TC,
  insert_hydration: MC,
  noop: zC,
  safe_not_equal: BC,
  svg_element: qC
} = window.__gradio__svelte__internal, {
  SvelteComponent: RC,
  append_hydration: NC,
  attr: LC,
  children: IC,
  claim_svg_element: OC,
  detach: PC,
  init: HC,
  insert_hydration: UC,
  noop: GC,
  safe_not_equal: VC,
  svg_element: WC
} = window.__gradio__svelte__internal, {
  SvelteComponent: jC,
  append_hydration: XC,
  attr: YC,
  children: ZC,
  claim_svg_element: KC,
  detach: QC,
  init: JC,
  insert_hydration: eE,
  noop: tE,
  safe_not_equal: nE,
  svg_element: rE
} = window.__gradio__svelte__internal, {
  SvelteComponent: aE,
  append_hydration: iE,
  attr: lE,
  children: sE,
  claim_svg_element: oE,
  detach: uE,
  init: cE,
  insert_hydration: hE,
  noop: dE,
  safe_not_equal: mE,
  svg_element: fE
} = window.__gradio__svelte__internal, {
  SvelteComponent: pE,
  append_hydration: gE,
  attr: _E,
  children: vE,
  claim_svg_element: yE,
  detach: bE,
  init: wE,
  insert_hydration: xE,
  noop: kE,
  safe_not_equal: SE,
  svg_element: $E
} = window.__gradio__svelte__internal, {
  SvelteComponent: DE,
  append_hydration: AE,
  attr: CE,
  children: EE,
  claim_svg_element: FE,
  detach: TE,
  init: ME,
  insert_hydration: zE,
  noop: BE,
  safe_not_equal: qE,
  svg_element: RE
} = window.__gradio__svelte__internal, {
  SvelteComponent: NE,
  append_hydration: LE,
  attr: IE,
  children: OE,
  claim_svg_element: PE,
  detach: HE,
  init: UE,
  insert_hydration: GE,
  noop: VE,
  safe_not_equal: WE,
  svg_element: jE
} = window.__gradio__svelte__internal, {
  SvelteComponent: XE,
  append_hydration: YE,
  attr: ZE,
  children: KE,
  claim_svg_element: QE,
  detach: JE,
  init: eF,
  insert_hydration: tF,
  noop: nF,
  safe_not_equal: rF,
  svg_element: aF
} = window.__gradio__svelte__internal, {
  SvelteComponent: iF,
  append_hydration: lF,
  attr: sF,
  children: oF,
  claim_svg_element: uF,
  detach: cF,
  init: hF,
  insert_hydration: dF,
  noop: mF,
  safe_not_equal: fF,
  svg_element: pF
} = window.__gradio__svelte__internal, {
  SvelteComponent: gF,
  append_hydration: _F,
  attr: vF,
  children: yF,
  claim_svg_element: bF,
  detach: wF,
  init: xF,
  insert_hydration: kF,
  noop: SF,
  safe_not_equal: $F,
  svg_element: DF
} = window.__gradio__svelte__internal, {
  SvelteComponent: AF,
  append_hydration: CF,
  attr: EF,
  children: FF,
  claim_svg_element: TF,
  detach: MF,
  init: zF,
  insert_hydration: BF,
  noop: qF,
  safe_not_equal: RF,
  set_style: NF,
  svg_element: LF
} = window.__gradio__svelte__internal, {
  SvelteComponent: IF,
  append_hydration: OF,
  attr: PF,
  children: HF,
  claim_svg_element: UF,
  detach: GF,
  init: VF,
  insert_hydration: WF,
  noop: jF,
  safe_not_equal: XF,
  svg_element: YF
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZF,
  append_hydration: KF,
  attr: QF,
  children: JF,
  claim_svg_element: eT,
  detach: tT,
  init: nT,
  insert_hydration: rT,
  noop: aT,
  safe_not_equal: iT,
  svg_element: lT
} = window.__gradio__svelte__internal, {
  SvelteComponent: sT,
  append_hydration: oT,
  attr: uT,
  children: cT,
  claim_svg_element: hT,
  detach: dT,
  init: mT,
  insert_hydration: fT,
  noop: pT,
  safe_not_equal: gT,
  svg_element: _T
} = window.__gradio__svelte__internal, {
  SvelteComponent: vT,
  append_hydration: yT,
  attr: bT,
  children: wT,
  claim_svg_element: xT,
  detach: kT,
  init: ST,
  insert_hydration: $T,
  noop: DT,
  safe_not_equal: AT,
  svg_element: CT
} = window.__gradio__svelte__internal, {
  SvelteComponent: ET,
  append_hydration: FT,
  attr: TT,
  children: MT,
  claim_svg_element: zT,
  detach: BT,
  init: qT,
  insert_hydration: RT,
  noop: NT,
  safe_not_equal: LT,
  svg_element: IT
} = window.__gradio__svelte__internal, {
  SvelteComponent: OT,
  append_hydration: PT,
  attr: HT,
  children: UT,
  claim_svg_element: GT,
  detach: VT,
  init: WT,
  insert_hydration: jT,
  noop: XT,
  safe_not_equal: YT,
  svg_element: ZT
} = window.__gradio__svelte__internal, {
  SvelteComponent: KT,
  append_hydration: QT,
  attr: JT,
  children: eM,
  claim_svg_element: tM,
  detach: nM,
  init: rM,
  insert_hydration: aM,
  noop: iM,
  safe_not_equal: lM,
  svg_element: sM
} = window.__gradio__svelte__internal, {
  SvelteComponent: oM,
  append_hydration: uM,
  attr: cM,
  children: hM,
  claim_svg_element: dM,
  detach: mM,
  init: fM,
  insert_hydration: pM,
  noop: gM,
  safe_not_equal: _M,
  svg_element: vM
} = window.__gradio__svelte__internal, {
  SvelteComponent: yM,
  append_hydration: bM,
  attr: wM,
  children: xM,
  claim_svg_element: kM,
  claim_text: SM,
  detach: $M,
  init: DM,
  insert_hydration: AM,
  noop: CM,
  safe_not_equal: EM,
  svg_element: FM,
  text: TM
} = window.__gradio__svelte__internal, {
  SvelteComponent: MM,
  append_hydration: zM,
  attr: BM,
  children: qM,
  claim_svg_element: RM,
  detach: NM,
  init: LM,
  insert_hydration: IM,
  noop: OM,
  safe_not_equal: PM,
  svg_element: HM
} = window.__gradio__svelte__internal, {
  SvelteComponent: UM,
  append_hydration: GM,
  attr: VM,
  children: WM,
  claim_svg_element: jM,
  detach: XM,
  init: YM,
  insert_hydration: ZM,
  noop: KM,
  safe_not_equal: QM,
  svg_element: JM
} = window.__gradio__svelte__internal, {
  SvelteComponent: ez,
  append_hydration: tz,
  attr: nz,
  children: rz,
  claim_svg_element: az,
  detach: iz,
  init: lz,
  insert_hydration: sz,
  noop: oz,
  safe_not_equal: uz,
  svg_element: cz
} = window.__gradio__svelte__internal, {
  SvelteComponent: hz,
  append_hydration: dz,
  attr: mz,
  children: fz,
  claim_svg_element: pz,
  detach: gz,
  init: _z,
  insert_hydration: vz,
  noop: yz,
  safe_not_equal: bz,
  svg_element: wz
} = window.__gradio__svelte__internal, {
  SvelteComponent: xz,
  append_hydration: kz,
  attr: Sz,
  children: $z,
  claim_svg_element: Dz,
  detach: Az,
  init: Cz,
  insert_hydration: Ez,
  noop: Fz,
  safe_not_equal: Tz,
  svg_element: Mz
} = window.__gradio__svelte__internal, {
  SvelteComponent: zz,
  append_hydration: Bz,
  attr: qz,
  children: Rz,
  claim_svg_element: Nz,
  claim_text: Lz,
  detach: Iz,
  init: Oz,
  insert_hydration: Pz,
  noop: Hz,
  safe_not_equal: Uz,
  svg_element: Gz,
  text: Vz
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wz,
  append_hydration: jz,
  attr: Xz,
  children: Yz,
  claim_svg_element: Zz,
  claim_text: Kz,
  detach: Qz,
  init: Jz,
  insert_hydration: eB,
  noop: tB,
  safe_not_equal: nB,
  svg_element: rB,
  text: aB
} = window.__gradio__svelte__internal, {
  SvelteComponent: iB,
  append_hydration: lB,
  attr: sB,
  children: oB,
  claim_svg_element: uB,
  claim_text: cB,
  detach: hB,
  init: dB,
  insert_hydration: mB,
  noop: fB,
  safe_not_equal: pB,
  svg_element: gB,
  text: _B
} = window.__gradio__svelte__internal, {
  SvelteComponent: vB,
  append_hydration: yB,
  attr: bB,
  children: wB,
  claim_svg_element: xB,
  detach: kB,
  init: SB,
  insert_hydration: $B,
  noop: DB,
  safe_not_equal: AB,
  svg_element: CB
} = window.__gradio__svelte__internal, {
  SvelteComponent: EB,
  append_hydration: FB,
  attr: TB,
  children: MB,
  claim_svg_element: zB,
  detach: BB,
  init: qB,
  insert_hydration: RB,
  noop: NB,
  safe_not_equal: LB,
  svg_element: IB
} = window.__gradio__svelte__internal, {
  SvelteComponent: OB,
  append_hydration: PB,
  attr: HB,
  children: UB,
  claim_svg_element: GB,
  detach: VB,
  init: WB,
  insert_hydration: jB,
  noop: XB,
  safe_not_equal: YB,
  svg_element: ZB
} = window.__gradio__svelte__internal, {
  SvelteComponent: KB,
  append_hydration: QB,
  attr: JB,
  children: eq,
  claim_svg_element: tq,
  detach: nq,
  init: rq,
  insert_hydration: aq,
  noop: iq,
  safe_not_equal: lq,
  svg_element: sq
} = window.__gradio__svelte__internal, {
  SvelteComponent: oq,
  append_hydration: uq,
  attr: cq,
  children: hq,
  claim_svg_element: dq,
  detach: mq,
  init: fq,
  insert_hydration: pq,
  noop: gq,
  safe_not_equal: _q,
  svg_element: vq
} = window.__gradio__svelte__internal, {
  SvelteComponent: om,
  append_hydration: P0,
  attr: Vt,
  binding_callbacks: Tl,
  check_outros: Sa,
  children: n0,
  claim_component: Lo,
  claim_element: r0,
  claim_space: Ct,
  claim_text: Fe,
  create_component: Io,
  create_slot: Oo,
  destroy_component: Po,
  destroy_each: Ho,
  detach: Y,
  element: a0,
  empty: Bt,
  ensure_array_like: _r,
  get_all_dirty_from_scope: Uo,
  get_slot_changes: Go,
  group_outros: $a,
  init: um,
  insert_hydration: ne,
  mount_component: Vo,
  noop: Da,
  safe_not_equal: cm,
  set_data: qt,
  set_style: T0,
  space: Et,
  text: Te,
  toggle_class: Dt,
  transition_in: Gt,
  transition_out: i0,
  update_slot_base: Wo
} = window.__gradio__svelte__internal, { tick: hm } = window.__gradio__svelte__internal, { onDestroy: dm } = window.__gradio__svelte__internal, { createEventDispatcher: mm } = window.__gradio__svelte__internal, fm = (r) => ({}), Ml = (r) => ({}), pm = (r) => ({}), zl = (r) => ({});
function Bl(r, e, t) {
  const n = r.slice();
  return n[41] = e[t], n[43] = t, n;
}
function ql(r, e, t) {
  const n = r.slice();
  return n[41] = e[t], n;
}
function gm(r) {
  let e, t, n, a, i = (
    /*i18n*/
    r[1]("common.error") + ""
  ), l, s, o;
  t = new Pd({
    props: {
      Icon: sm,
      label: (
        /*i18n*/
        r[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    r[32]
  );
  const h = (
    /*#slots*/
    r[30].error
  ), m = Oo(
    h,
    r,
    /*$$scope*/
    r[29],
    Ml
  );
  return {
    c() {
      e = a0("div"), Io(t.$$.fragment), n = Et(), a = a0("span"), l = Te(i), s = Et(), m && m.c(), this.h();
    },
    l(p) {
      e = r0(p, "DIV", { class: !0 });
      var g = n0(e);
      Lo(t.$$.fragment, g), g.forEach(Y), n = Ct(p), a = r0(p, "SPAN", { class: !0 });
      var _ = n0(a);
      l = Fe(_, i), _.forEach(Y), s = Ct(p), m && m.l(p), this.h();
    },
    h() {
      Vt(e, "class", "clear-status svelte-17v219f"), Vt(a, "class", "error svelte-17v219f");
    },
    m(p, g) {
      ne(p, e, g), Vo(t, e, null), ne(p, n, g), ne(p, a, g), P0(a, l), ne(p, s, g), m && m.m(p, g), o = !0;
    },
    p(p, g) {
      const _ = {};
      g[0] & /*i18n*/
      2 && (_.label = /*i18n*/
      p[1]("common.clear")), t.$set(_), (!o || g[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      p[1]("common.error") + "") && qt(l, i), m && m.p && (!o || g[0] & /*$$scope*/
      536870912) && Wo(
        m,
        h,
        p,
        /*$$scope*/
        p[29],
        o ? Go(
          h,
          /*$$scope*/
          p[29],
          g,
          fm
        ) : Uo(
          /*$$scope*/
          p[29]
        ),
        Ml
      );
    },
    i(p) {
      o || (Gt(t.$$.fragment, p), Gt(m, p), o = !0);
    },
    o(p) {
      i0(t.$$.fragment, p), i0(m, p), o = !1;
    },
    d(p) {
      p && (Y(e), Y(n), Y(a), Y(s)), Po(t), m && m.d(p);
    }
  };
}
function _m(r) {
  let e, t, n, a, i, l, s, o, h, m = (
    /*variant*/
    r[8] === "default" && /*show_eta_bar*/
    r[18] && /*show_progress*/
    r[6] === "full" && Rl(r)
  );
  function p(v, x) {
    if (
      /*progress*/
      v[7]
    ) return bm;
    if (
      /*queue_position*/
      v[2] !== null && /*queue_size*/
      v[3] !== void 0 && /*queue_position*/
      v[2] >= 0
    ) return ym;
    if (
      /*queue_position*/
      v[2] === 0
    ) return vm;
  }
  let g = p(r), _ = g && g(r), C = (
    /*timer*/
    r[5] && Il(r)
  );
  const T = [Sm, km], F = [];
  function M(v, x) {
    return (
      /*last_progress_level*/
      v[15] != null ? 0 : (
        /*show_progress*/
        v[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = M(r)) && (l = F[i] = T[i](r));
  let w = !/*timer*/
  r[5] && Wl(r);
  return {
    c() {
      m && m.c(), e = Et(), t = a0("div"), _ && _.c(), n = Et(), C && C.c(), a = Et(), l && l.c(), s = Et(), w && w.c(), o = Bt(), this.h();
    },
    l(v) {
      m && m.l(v), e = Ct(v), t = r0(v, "DIV", { class: !0 });
      var x = n0(t);
      _ && _.l(x), n = Ct(x), C && C.l(x), x.forEach(Y), a = Ct(v), l && l.l(v), s = Ct(v), w && w.l(v), o = Bt(), this.h();
    },
    h() {
      Vt(t, "class", "progress-text svelte-17v219f"), Dt(
        t,
        "meta-text-center",
        /*variant*/
        r[8] === "center"
      ), Dt(
        t,
        "meta-text",
        /*variant*/
        r[8] === "default"
      );
    },
    m(v, x) {
      m && m.m(v, x), ne(v, e, x), ne(v, t, x), _ && _.m(t, null), P0(t, n), C && C.m(t, null), ne(v, a, x), ~i && F[i].m(v, x), ne(v, s, x), w && w.m(v, x), ne(v, o, x), h = !0;
    },
    p(v, x) {
      /*variant*/
      v[8] === "default" && /*show_eta_bar*/
      v[18] && /*show_progress*/
      v[6] === "full" ? m ? m.p(v, x) : (m = Rl(v), m.c(), m.m(e.parentNode, e)) : m && (m.d(1), m = null), g === (g = p(v)) && _ ? _.p(v, x) : (_ && _.d(1), _ = g && g(v), _ && (_.c(), _.m(t, n))), /*timer*/
      v[5] ? C ? C.p(v, x) : (C = Il(v), C.c(), C.m(t, null)) : C && (C.d(1), C = null), (!h || x[0] & /*variant*/
      256) && Dt(
        t,
        "meta-text-center",
        /*variant*/
        v[8] === "center"
      ), (!h || x[0] & /*variant*/
      256) && Dt(
        t,
        "meta-text",
        /*variant*/
        v[8] === "default"
      );
      let $ = i;
      i = M(v), i === $ ? ~i && F[i].p(v, x) : (l && ($a(), i0(F[$], 1, 1, () => {
        F[$] = null;
      }), Sa()), ~i ? (l = F[i], l ? l.p(v, x) : (l = F[i] = T[i](v), l.c()), Gt(l, 1), l.m(s.parentNode, s)) : l = null), /*timer*/
      v[5] ? w && ($a(), i0(w, 1, 1, () => {
        w = null;
      }), Sa()) : w ? (w.p(v, x), x[0] & /*timer*/
      32 && Gt(w, 1)) : (w = Wl(v), w.c(), Gt(w, 1), w.m(o.parentNode, o));
    },
    i(v) {
      h || (Gt(l), Gt(w), h = !0);
    },
    o(v) {
      i0(l), i0(w), h = !1;
    },
    d(v) {
      v && (Y(e), Y(t), Y(a), Y(s), Y(o)), m && m.d(v), _ && _.d(), C && C.d(), ~i && F[i].d(v), w && w.d(v);
    }
  };
}
function Rl(r) {
  let e, t = `translateX(${/*eta_level*/
  (r[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = a0("div"), this.h();
    },
    l(n) {
      e = r0(n, "DIV", { class: !0 }), n0(e).forEach(Y), this.h();
    },
    h() {
      Vt(e, "class", "eta-bar svelte-17v219f"), T0(e, "transform", t);
    },
    m(n, a) {
      ne(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && T0(e, "transform", t);
    },
    d(n) {
      n && Y(e);
    }
  };
}
function vm(r) {
  let e;
  return {
    c() {
      e = Te("processing |");
    },
    l(t) {
      e = Fe(t, "processing |");
    },
    m(t, n) {
      ne(t, e, n);
    },
    p: Da,
    d(t) {
      t && Y(e);
    }
  };
}
function ym(r) {
  let e, t = (
    /*queue_position*/
    r[2] + 1 + ""
  ), n, a, i, l;
  return {
    c() {
      e = Te("queue: "), n = Te(t), a = Te("/"), i = Te(
        /*queue_size*/
        r[3]
      ), l = Te(" |");
    },
    l(s) {
      e = Fe(s, "queue: "), n = Fe(s, t), a = Fe(s, "/"), i = Fe(
        s,
        /*queue_size*/
        r[3]
      ), l = Fe(s, " |");
    },
    m(s, o) {
      ne(s, e, o), ne(s, n, o), ne(s, a, o), ne(s, i, o), ne(s, l, o);
    },
    p(s, o) {
      o[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      s[2] + 1 + "") && qt(n, t), o[0] & /*queue_size*/
      8 && qt(
        i,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (Y(e), Y(n), Y(a), Y(i), Y(l));
    }
  };
}
function bm(r) {
  let e, t = _r(
    /*progress*/
    r[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Ll(ql(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = Bt();
    },
    l(a) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(a);
      e = Bt();
    },
    m(a, i) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, i);
      ne(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress*/
      128) {
        t = _r(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const s = ql(a, t, l);
          n[l] ? n[l].p(s, i) : (n[l] = Ll(s), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && Y(e), Ho(n, a);
    }
  };
}
function Nl(r) {
  let e, t = (
    /*p*/
    r[41].unit + ""
  ), n, a, i = " ", l;
  function s(m, p) {
    return (
      /*p*/
      m[41].length != null ? xm : wm
    );
  }
  let o = s(r), h = o(r);
  return {
    c() {
      h.c(), e = Et(), n = Te(t), a = Te(" | "), l = Te(i);
    },
    l(m) {
      h.l(m), e = Ct(m), n = Fe(m, t), a = Fe(m, " | "), l = Fe(m, i);
    },
    m(m, p) {
      h.m(m, p), ne(m, e, p), ne(m, n, p), ne(m, a, p), ne(m, l, p);
    },
    p(m, p) {
      o === (o = s(m)) && h ? h.p(m, p) : (h.d(1), h = o(m), h && (h.c(), h.m(e.parentNode, e))), p[0] & /*progress*/
      128 && t !== (t = /*p*/
      m[41].unit + "") && qt(n, t);
    },
    d(m) {
      m && (Y(e), Y(n), Y(a), Y(l)), h.d(m);
    }
  };
}
function wm(r) {
  let e = en(
    /*p*/
    r[41].index || 0
  ) + "", t;
  return {
    c() {
      t = Te(e);
    },
    l(n) {
      t = Fe(n, e);
    },
    m(n, a) {
      ne(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = en(
        /*p*/
        n[41].index || 0
      ) + "") && qt(t, e);
    },
    d(n) {
      n && Y(t);
    }
  };
}
function xm(r) {
  let e = en(
    /*p*/
    r[41].index || 0
  ) + "", t, n, a = en(
    /*p*/
    r[41].length
  ) + "", i;
  return {
    c() {
      t = Te(e), n = Te("/"), i = Te(a);
    },
    l(l) {
      t = Fe(l, e), n = Fe(l, "/"), i = Fe(l, a);
    },
    m(l, s) {
      ne(l, t, s), ne(l, n, s), ne(l, i, s);
    },
    p(l, s) {
      s[0] & /*progress*/
      128 && e !== (e = en(
        /*p*/
        l[41].index || 0
      ) + "") && qt(t, e), s[0] & /*progress*/
      128 && a !== (a = en(
        /*p*/
        l[41].length
      ) + "") && qt(i, a);
    },
    d(l) {
      l && (Y(t), Y(n), Y(i));
    }
  };
}
function Ll(r) {
  let e, t = (
    /*p*/
    r[41].index != null && Nl(r)
  );
  return {
    c() {
      t && t.c(), e = Bt();
    },
    l(n) {
      t && t.l(n), e = Bt();
    },
    m(n, a) {
      t && t.m(n, a), ne(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[41].index != null ? t ? t.p(n, a) : (t = Nl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && Y(e), t && t.d(n);
    }
  };
}
function Il(r) {
  let e, t = (
    /*eta*/
    r[0] ? `/${/*formatted_eta*/
    r[19]}` : ""
  ), n, a;
  return {
    c() {
      e = Te(
        /*formatted_timer*/
        r[20]
      ), n = Te(t), a = Te("s");
    },
    l(i) {
      e = Fe(
        i,
        /*formatted_timer*/
        r[20]
      ), n = Fe(i, t), a = Fe(i, "s");
    },
    m(i, l) {
      ne(i, e, l), ne(i, n, l), ne(i, a, l);
    },
    p(i, l) {
      l[0] & /*formatted_timer*/
      1048576 && qt(
        e,
        /*formatted_timer*/
        i[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && qt(n, t);
    },
    d(i) {
      i && (Y(e), Y(n), Y(a));
    }
  };
}
function km(r) {
  let e, t;
  return e = new tm({
    props: { margin: (
      /*variant*/
      r[8] === "default"
    ) }
  }), {
    c() {
      Io(e.$$.fragment);
    },
    l(n) {
      Lo(e.$$.fragment, n);
    },
    m(n, a) {
      Vo(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*variant*/
      256 && (i.margin = /*variant*/
      n[8] === "default"), e.$set(i);
    },
    i(n) {
      t || (Gt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      i0(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Po(e, n);
    }
  };
}
function Sm(r) {
  let e, t, n, a, i, l = `${/*last_progress_level*/
  r[15] * 100}%`, s = (
    /*progress*/
    r[7] != null && Ol(r)
  );
  return {
    c() {
      e = a0("div"), t = a0("div"), s && s.c(), n = Et(), a = a0("div"), i = a0("div"), this.h();
    },
    l(o) {
      e = r0(o, "DIV", { class: !0 });
      var h = n0(e);
      t = r0(h, "DIV", { class: !0 });
      var m = n0(t);
      s && s.l(m), m.forEach(Y), n = Ct(h), a = r0(h, "DIV", { class: !0 });
      var p = n0(a);
      i = r0(p, "DIV", { class: !0 }), n0(i).forEach(Y), p.forEach(Y), h.forEach(Y), this.h();
    },
    h() {
      Vt(t, "class", "progress-level-inner svelte-17v219f"), Vt(i, "class", "progress-bar svelte-17v219f"), T0(i, "width", l), Vt(a, "class", "progress-bar-wrap svelte-17v219f"), Vt(e, "class", "progress-level svelte-17v219f");
    },
    m(o, h) {
      ne(o, e, h), P0(e, t), s && s.m(t, null), P0(e, n), P0(e, a), P0(a, i), r[31](i);
    },
    p(o, h) {
      /*progress*/
      o[7] != null ? s ? s.p(o, h) : (s = Ol(o), s.c(), s.m(t, null)) : s && (s.d(1), s = null), h[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      o[15] * 100}%`) && T0(i, "width", l);
    },
    i: Da,
    o: Da,
    d(o) {
      o && Y(e), s && s.d(), r[31](null);
    }
  };
}
function Ol(r) {
  let e, t = _r(
    /*progress*/
    r[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Vl(Bl(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = Bt();
    },
    l(a) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(a);
      e = Bt();
    },
    m(a, i) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, i);
      ne(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = _r(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const s = Bl(a, t, l);
          n[l] ? n[l].p(s, i) : (n[l] = Vl(s), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && Y(e), Ho(n, a);
    }
  };
}
function Pl(r) {
  let e, t, n, a, i = (
    /*i*/
    r[43] !== 0 && $m()
  ), l = (
    /*p*/
    r[41].desc != null && Hl(r)
  ), s = (
    /*p*/
    r[41].desc != null && /*progress_level*/
    r[14] && /*progress_level*/
    r[14][
      /*i*/
      r[43]
    ] != null && Ul()
  ), o = (
    /*progress_level*/
    r[14] != null && Gl(r)
  );
  return {
    c() {
      i && i.c(), e = Et(), l && l.c(), t = Et(), s && s.c(), n = Et(), o && o.c(), a = Bt();
    },
    l(h) {
      i && i.l(h), e = Ct(h), l && l.l(h), t = Ct(h), s && s.l(h), n = Ct(h), o && o.l(h), a = Bt();
    },
    m(h, m) {
      i && i.m(h, m), ne(h, e, m), l && l.m(h, m), ne(h, t, m), s && s.m(h, m), ne(h, n, m), o && o.m(h, m), ne(h, a, m);
    },
    p(h, m) {
      /*p*/
      h[41].desc != null ? l ? l.p(h, m) : (l = Hl(h), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      h[41].desc != null && /*progress_level*/
      h[14] && /*progress_level*/
      h[14][
        /*i*/
        h[43]
      ] != null ? s || (s = Ul(), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*progress_level*/
      h[14] != null ? o ? o.p(h, m) : (o = Gl(h), o.c(), o.m(a.parentNode, a)) : o && (o.d(1), o = null);
    },
    d(h) {
      h && (Y(e), Y(t), Y(n), Y(a)), i && i.d(h), l && l.d(h), s && s.d(h), o && o.d(h);
    }
  };
}
function $m(r) {
  let e;
  return {
    c() {
      e = Te(" /");
    },
    l(t) {
      e = Fe(t, " /");
    },
    m(t, n) {
      ne(t, e, n);
    },
    d(t) {
      t && Y(e);
    }
  };
}
function Hl(r) {
  let e = (
    /*p*/
    r[41].desc + ""
  ), t;
  return {
    c() {
      t = Te(e);
    },
    l(n) {
      t = Fe(n, e);
    },
    m(n, a) {
      ne(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[41].desc + "") && qt(t, e);
    },
    d(n) {
      n && Y(t);
    }
  };
}
function Ul(r) {
  let e;
  return {
    c() {
      e = Te("-");
    },
    l(t) {
      e = Fe(t, "-");
    },
    m(t, n) {
      ne(t, e, n);
    },
    d(t) {
      t && Y(e);
    }
  };
}
function Gl(r) {
  let e = (100 * /*progress_level*/
  (r[14][
    /*i*/
    r[43]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = Te(e), n = Te("%");
    },
    l(a) {
      t = Fe(a, e), n = Fe(a, "%");
    },
    m(a, i) {
      ne(a, t, i), ne(a, n, i);
    },
    p(a, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[43]
      ] || 0)).toFixed(1) + "") && qt(t, e);
    },
    d(a) {
      a && (Y(t), Y(n));
    }
  };
}
function Vl(r) {
  let e, t = (
    /*p*/
    (r[41].desc != null || /*progress_level*/
    r[14] && /*progress_level*/
    r[14][
      /*i*/
      r[43]
    ] != null) && Pl(r)
  );
  return {
    c() {
      t && t.c(), e = Bt();
    },
    l(n) {
      t && t.l(n), e = Bt();
    },
    m(n, a) {
      t && t.m(n, a), ne(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[41].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[43]
      ] != null ? t ? t.p(n, a) : (t = Pl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && Y(e), t && t.d(n);
    }
  };
}
function Wl(r) {
  let e, t, n, a;
  const i = (
    /*#slots*/
    r[30]["additional-loading-text"]
  ), l = Oo(
    i,
    r,
    /*$$scope*/
    r[29],
    zl
  );
  return {
    c() {
      e = a0("p"), t = Te(
        /*loading_text*/
        r[9]
      ), n = Et(), l && l.c(), this.h();
    },
    l(s) {
      e = r0(s, "P", { class: !0 });
      var o = n0(e);
      t = Fe(
        o,
        /*loading_text*/
        r[9]
      ), o.forEach(Y), n = Ct(s), l && l.l(s), this.h();
    },
    h() {
      Vt(e, "class", "loading svelte-17v219f");
    },
    m(s, o) {
      ne(s, e, o), P0(e, t), ne(s, n, o), l && l.m(s, o), a = !0;
    },
    p(s, o) {
      (!a || o[0] & /*loading_text*/
      512) && qt(
        t,
        /*loading_text*/
        s[9]
      ), l && l.p && (!a || o[0] & /*$$scope*/
      536870912) && Wo(
        l,
        i,
        s,
        /*$$scope*/
        s[29],
        a ? Go(
          i,
          /*$$scope*/
          s[29],
          o,
          pm
        ) : Uo(
          /*$$scope*/
          s[29]
        ),
        zl
      );
    },
    i(s) {
      a || (Gt(l, s), a = !0);
    },
    o(s) {
      i0(l, s), a = !1;
    },
    d(s) {
      s && (Y(e), Y(n)), l && l.d(s);
    }
  };
}
function Dm(r) {
  let e, t, n, a, i;
  const l = [_m, gm], s = [];
  function o(h, m) {
    return (
      /*status*/
      h[4] === "pending" ? 0 : (
        /*status*/
        h[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = o(r)) && (n = s[t] = l[t](r)), {
    c() {
      e = a0("div"), n && n.c(), this.h();
    },
    l(h) {
      e = r0(h, "DIV", { class: !0 });
      var m = n0(e);
      n && n.l(m), m.forEach(Y), this.h();
    },
    h() {
      Vt(e, "class", a = "wrap " + /*variant*/
      r[8] + " " + /*show_progress*/
      r[6] + " svelte-17v219f"), Dt(e, "hide", !/*status*/
      r[4] || /*status*/
      r[4] === "complete" || /*show_progress*/
      r[6] === "hidden" || /*status*/
      r[4] == "streaming"), Dt(
        e,
        "translucent",
        /*variant*/
        r[8] === "center" && /*status*/
        (r[4] === "pending" || /*status*/
        r[4] === "error") || /*translucent*/
        r[11] || /*show_progress*/
        r[6] === "minimal"
      ), Dt(
        e,
        "generating",
        /*status*/
        r[4] === "generating" && /*show_progress*/
        r[6] === "full"
      ), Dt(
        e,
        "border",
        /*border*/
        r[12]
      ), T0(
        e,
        "position",
        /*absolute*/
        r[10] ? "absolute" : "static"
      ), T0(
        e,
        "padding",
        /*absolute*/
        r[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(h, m) {
      ne(h, e, m), ~t && s[t].m(e, null), r[33](e), i = !0;
    },
    p(h, m) {
      let p = t;
      t = o(h), t === p ? ~t && s[t].p(h, m) : (n && ($a(), i0(s[p], 1, 1, () => {
        s[p] = null;
      }), Sa()), ~t ? (n = s[t], n ? n.p(h, m) : (n = s[t] = l[t](h), n.c()), Gt(n, 1), n.m(e, null)) : n = null), (!i || m[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      h[8] + " " + /*show_progress*/
      h[6] + " svelte-17v219f")) && Vt(e, "class", a), (!i || m[0] & /*variant, show_progress, status, show_progress*/
      336) && Dt(e, "hide", !/*status*/
      h[4] || /*status*/
      h[4] === "complete" || /*show_progress*/
      h[6] === "hidden" || /*status*/
      h[4] == "streaming"), (!i || m[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Dt(
        e,
        "translucent",
        /*variant*/
        h[8] === "center" && /*status*/
        (h[4] === "pending" || /*status*/
        h[4] === "error") || /*translucent*/
        h[11] || /*show_progress*/
        h[6] === "minimal"
      ), (!i || m[0] & /*variant, show_progress, status, show_progress*/
      336) && Dt(
        e,
        "generating",
        /*status*/
        h[4] === "generating" && /*show_progress*/
        h[6] === "full"
      ), (!i || m[0] & /*variant, show_progress, border*/
      4416) && Dt(
        e,
        "border",
        /*border*/
        h[12]
      ), m[0] & /*absolute*/
      1024 && T0(
        e,
        "position",
        /*absolute*/
        h[10] ? "absolute" : "static"
      ), m[0] & /*absolute*/
      1024 && T0(
        e,
        "padding",
        /*absolute*/
        h[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(h) {
      i || (Gt(n), i = !0);
    },
    o(h) {
      i0(n), i = !1;
    },
    d(h) {
      h && Y(e), ~t && s[t].d(), r[33](null);
    }
  };
}
var Am = function(r, e, t, n) {
  function a(i) {
    return i instanceof t ? i : new t(function(l) {
      l(i);
    });
  }
  return new (t || (t = Promise))(function(i, l) {
    function s(m) {
      try {
        h(n.next(m));
      } catch (p) {
        l(p);
      }
    }
    function o(m) {
      try {
        h(n.throw(m));
      } catch (p) {
        l(p);
      }
    }
    function h(m) {
      m.done ? i(m.value) : a(m.value).then(s, o);
    }
    h((n = n.apply(r, e || [])).next());
  });
};
let er = [], ta = !1;
const Cm = typeof window < "u", jo = Cm ? window.requestAnimationFrame : (r) => {
};
function Em(r) {
  return Am(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (er.push(e), !ta) ta = !0;
      else return;
      yield hm(), jo(() => {
        let n = [0, 0];
        for (let a = 0; a < er.length; a++) {
          const l = er[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), ta = !1, er = [];
      });
    }
  });
}
function Fm(r, e, t) {
  let n, { $$slots: a = {}, $$scope: i } = e;
  this && this.__awaiter;
  const l = mm();
  let { i18n: s } = e, { eta: o = null } = e, { queue_position: h } = e, { queue_size: m } = e, { status: p } = e, { scroll_to_output: g = !1 } = e, { timer: _ = !0 } = e, { show_progress: C = "full" } = e, { message: T = null } = e, { progress: F = null } = e, { variant: M = "default" } = e, { loading_text: w = "Loading..." } = e, { absolute: v = !0 } = e, { translucent: x = !1 } = e, { border: $ = !1 } = e, { autoscroll: E } = e, A, q = !1, B = 0, z = 0, U = null, N = null, K = 0, ie = null, we, _e = null, Ue = !0;
  const ue = () => {
    t(0, o = t(27, U = t(19, re = null))), t(25, B = performance.now()), t(26, z = 0), q = !0, Me();
  };
  function Me() {
    jo(() => {
      t(26, z = (performance.now() - B) / 1e3), q && Me();
    });
  }
  function De() {
    t(26, z = 0), t(0, o = t(27, U = t(19, re = null))), q && (q = !1);
  }
  dm(() => {
    q && De();
  });
  let re = null;
  function ce(H) {
    Tl[H ? "unshift" : "push"](() => {
      _e = H, t(16, _e), t(7, F), t(14, ie), t(15, we);
    });
  }
  const he = () => {
    l("clear_status");
  };
  function Le(H) {
    Tl[H ? "unshift" : "push"](() => {
      A = H, t(13, A);
    });
  }
  return r.$$set = (H) => {
    "i18n" in H && t(1, s = H.i18n), "eta" in H && t(0, o = H.eta), "queue_position" in H && t(2, h = H.queue_position), "queue_size" in H && t(3, m = H.queue_size), "status" in H && t(4, p = H.status), "scroll_to_output" in H && t(22, g = H.scroll_to_output), "timer" in H && t(5, _ = H.timer), "show_progress" in H && t(6, C = H.show_progress), "message" in H && t(23, T = H.message), "progress" in H && t(7, F = H.progress), "variant" in H && t(8, M = H.variant), "loading_text" in H && t(9, w = H.loading_text), "absolute" in H && t(10, v = H.absolute), "translucent" in H && t(11, x = H.translucent), "border" in H && t(12, $ = H.border), "autoscroll" in H && t(24, E = H.autoscroll), "$$scope" in H && t(29, i = H.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (o === null && t(0, o = U), o != null && U !== o && (t(28, N = (performance.now() - B) / 1e3 + o), t(19, re = N.toFixed(1)), t(27, U = o))), r.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, K = N === null || N <= 0 || !z ? null : Math.min(z / N, 1)), r.$$.dirty[0] & /*progress*/
    128 && F != null && t(18, Ue = !1), r.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (F != null ? t(14, ie = F.map((H) => {
      if (H.index != null && H.length != null)
        return H.index / H.length;
      if (H.progress != null)
        return H.progress;
    })) : t(14, ie = null), ie ? (t(15, we = ie[ie.length - 1]), _e && (we === 0 ? t(16, _e.style.transition = "0", _e) : t(16, _e.style.transition = "150ms", _e))) : t(15, we = void 0)), r.$$.dirty[0] & /*status*/
    16 && (p === "pending" ? ue() : De()), r.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && A && g && (p === "pending" || p === "complete") && Em(A, E), r.$$.dirty[0] & /*status, message*/
    8388624, r.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = z.toFixed(1));
  }, [
    o,
    s,
    h,
    m,
    p,
    _,
    C,
    F,
    M,
    w,
    v,
    x,
    $,
    A,
    ie,
    we,
    _e,
    K,
    Ue,
    re,
    n,
    l,
    g,
    T,
    E,
    B,
    z,
    U,
    N,
    i,
    a,
    ce,
    he,
    Le
  ];
}
class Tm extends om {
  constructor(e) {
    super(), um(
      this,
      e,
      Fm,
      Dm,
      cm,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Xo,
  setPrototypeOf: jl,
  isFrozen: Mm,
  getPrototypeOf: zm,
  getOwnPropertyDescriptor: Bm
} = Object;
let {
  freeze: it,
  seal: Rt,
  create: Yo
} = Object, {
  apply: Aa,
  construct: Ca
} = typeof Reflect < "u" && Reflect;
it || (it = function(e) {
  return e;
});
Rt || (Rt = function(e) {
  return e;
});
Aa || (Aa = function(e, t, n) {
  return e.apply(t, n);
});
Ca || (Ca = function(e, t) {
  return new e(...t);
});
const tr = lt(Array.prototype.forEach), qm = lt(Array.prototype.lastIndexOf), Xl = lt(Array.prototype.pop), dn = lt(Array.prototype.push), Rm = lt(Array.prototype.splice), or = lt(String.prototype.toLowerCase), na = lt(String.prototype.toString), Yl = lt(String.prototype.match), mn = lt(String.prototype.replace), Nm = lt(String.prototype.indexOf), Lm = lt(String.prototype.trim), Ht = lt(Object.prototype.hasOwnProperty), nt = lt(RegExp.prototype.test), fn = Im(TypeError);
function lt(r) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      n[a - 1] = arguments[a];
    return Aa(r, e, n);
  };
}
function Im(r) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return Ca(r, t);
  };
}
function le(r, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : or;
  jl && jl(r, null);
  let n = e.length;
  for (; n--; ) {
    let a = e[n];
    if (typeof a == "string") {
      const i = t(a);
      i !== a && (Mm(e) || (e[n] = i), a = i);
    }
    r[a] = !0;
  }
  return r;
}
function Om(r) {
  for (let e = 0; e < r.length; e++)
    Ht(r, e) || (r[e] = null);
  return r;
}
function g0(r) {
  const e = Yo(null);
  for (const [t, n] of Xo(r))
    Ht(r, t) && (Array.isArray(n) ? e[t] = Om(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = g0(n) : e[t] = n);
  return e;
}
function pn(r, e) {
  for (; r !== null; ) {
    const n = Bm(r, e);
    if (n) {
      if (n.get)
        return lt(n.get);
      if (typeof n.value == "function")
        return lt(n.value);
    }
    r = zm(r);
  }
  function t() {
    return null;
  }
  return t;
}
const Zl = it(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), ra = it(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), aa = it(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Pm = it(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), ia = it(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Hm = it(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Kl = it(["#text"]), Ql = it(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), la = it(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Jl = it(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), nr = it(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Um = Rt(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Gm = Rt(/<%[\w\W]*|[\w\W]*%>/gm), Vm = Rt(/\$\{[\w\W]*/gm), Wm = Rt(/^data-[\-\w.\u00B7-\uFFFF]+$/), jm = Rt(/^aria-[\-\w]+$/), Zo = Rt(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Xm = Rt(/^(?:\w+script|data):/i), Ym = Rt(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Ko = Rt(/^html$/i), Zm = Rt(/^[a-z][.\w]*(-[.\w]+)+$/i);
var es = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: jm,
  ATTR_WHITESPACE: Ym,
  CUSTOM_ELEMENT: Zm,
  DATA_ATTR: Wm,
  DOCTYPE_NAME: Ko,
  ERB_EXPR: Gm,
  IS_ALLOWED_URI: Zo,
  IS_SCRIPT_OR_DATA: Xm,
  MUSTACHE_EXPR: Um,
  TMPLIT_EXPR: Vm
});
const gn = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Km = function() {
  return typeof window > "u" ? null : window;
}, Qm = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (n = t.getAttribute(a));
  const i = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(i, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + i + " could not be created."), null;
  }
}, ts = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Qo() {
  let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Km();
  const e = (X) => Qo(X);
  if (e.version = "3.2.6", e.removed = [], !r || !r.document || r.document.nodeType !== gn.document || !r.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = r;
  const n = t, a = n.currentScript, {
    DocumentFragment: i,
    HTMLTemplateElement: l,
    Node: s,
    Element: o,
    NodeFilter: h,
    NamedNodeMap: m = r.NamedNodeMap || r.MozNamedAttrMap,
    HTMLFormElement: p,
    DOMParser: g,
    trustedTypes: _
  } = r, C = o.prototype, T = pn(C, "cloneNode"), F = pn(C, "remove"), M = pn(C, "nextSibling"), w = pn(C, "childNodes"), v = pn(C, "parentNode");
  if (typeof l == "function") {
    const X = t.createElement("template");
    X.content && X.content.ownerDocument && (t = X.content.ownerDocument);
  }
  let x, $ = "";
  const {
    implementation: E,
    createNodeIterator: A,
    createDocumentFragment: q,
    getElementsByTagName: B
  } = t, {
    importNode: z
  } = n;
  let U = ts();
  e.isSupported = typeof Xo == "function" && typeof v == "function" && E && E.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: N,
    ERB_EXPR: K,
    TMPLIT_EXPR: ie,
    DATA_ATTR: we,
    ARIA_ATTR: _e,
    IS_SCRIPT_OR_DATA: Ue,
    ATTR_WHITESPACE: ue,
    CUSTOM_ELEMENT: Me
  } = es;
  let {
    IS_ALLOWED_URI: De
  } = es, re = null;
  const ce = le({}, [...Zl, ...ra, ...aa, ...ia, ...Kl]);
  let he = null;
  const Le = le({}, [...Ql, ...la, ...Jl, ...nr]);
  let H = Object.seal(Yo(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ge = null, ze = null, ke = !0, et = !0, Ie = !1, Ze = !0, ot = !1, ut = !0, We = !1, Ke = !1, wt = !1, xt = !1, L = !1, te = !1, fe = !0, de = !1;
  const Ae = "user-content-";
  let je = !0, ve = !1, kt = {}, u0 = null;
  const Nt = le({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Xe = null;
  const ct = le({}, ["audio", "video", "img", "source", "image", "track"]);
  let Tn = null;
  const Mn = le({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), pt = "http://www.w3.org/1998/Math/MathML", X0 = "http://www.w3.org/2000/svg", c0 = "http://www.w3.org/1999/xhtml";
  let Y0 = c0, Fr = !1, Tr = null;
  const r1 = le({}, [pt, X0, c0], na);
  let zn = le({}, ["mi", "mo", "mn", "ms", "mtext"]), Bn = le({}, ["annotation-xml"]);
  const a1 = le({}, ["title", "style", "font", "a", "script"]);
  let sn = null;
  const i1 = ["application/xhtml+xml", "text/html"], l1 = "text/html";
  let Ve = null, Z0 = null;
  const s1 = t.createElement("form"), ai = function(S) {
    return S instanceof RegExp || S instanceof Function;
  }, Mr = function() {
    let S = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Z0 && Z0 === S)) {
      if ((!S || typeof S != "object") && (S = {}), S = g0(S), sn = // eslint-disable-next-line unicorn/prefer-includes
      i1.indexOf(S.PARSER_MEDIA_TYPE) === -1 ? l1 : S.PARSER_MEDIA_TYPE, Ve = sn === "application/xhtml+xml" ? na : or, re = Ht(S, "ALLOWED_TAGS") ? le({}, S.ALLOWED_TAGS, Ve) : ce, he = Ht(S, "ALLOWED_ATTR") ? le({}, S.ALLOWED_ATTR, Ve) : Le, Tr = Ht(S, "ALLOWED_NAMESPACES") ? le({}, S.ALLOWED_NAMESPACES, na) : r1, Tn = Ht(S, "ADD_URI_SAFE_ATTR") ? le(g0(Mn), S.ADD_URI_SAFE_ATTR, Ve) : Mn, Xe = Ht(S, "ADD_DATA_URI_TAGS") ? le(g0(ct), S.ADD_DATA_URI_TAGS, Ve) : ct, u0 = Ht(S, "FORBID_CONTENTS") ? le({}, S.FORBID_CONTENTS, Ve) : Nt, Ge = Ht(S, "FORBID_TAGS") ? le({}, S.FORBID_TAGS, Ve) : g0({}), ze = Ht(S, "FORBID_ATTR") ? le({}, S.FORBID_ATTR, Ve) : g0({}), kt = Ht(S, "USE_PROFILES") ? S.USE_PROFILES : !1, ke = S.ALLOW_ARIA_ATTR !== !1, et = S.ALLOW_DATA_ATTR !== !1, Ie = S.ALLOW_UNKNOWN_PROTOCOLS || !1, Ze = S.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ot = S.SAFE_FOR_TEMPLATES || !1, ut = S.SAFE_FOR_XML !== !1, We = S.WHOLE_DOCUMENT || !1, xt = S.RETURN_DOM || !1, L = S.RETURN_DOM_FRAGMENT || !1, te = S.RETURN_TRUSTED_TYPE || !1, wt = S.FORCE_BODY || !1, fe = S.SANITIZE_DOM !== !1, de = S.SANITIZE_NAMED_PROPS || !1, je = S.KEEP_CONTENT !== !1, ve = S.IN_PLACE || !1, De = S.ALLOWED_URI_REGEXP || Zo, Y0 = S.NAMESPACE || c0, zn = S.MATHML_TEXT_INTEGRATION_POINTS || zn, Bn = S.HTML_INTEGRATION_POINTS || Bn, H = S.CUSTOM_ELEMENT_HANDLING || {}, S.CUSTOM_ELEMENT_HANDLING && ai(S.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (H.tagNameCheck = S.CUSTOM_ELEMENT_HANDLING.tagNameCheck), S.CUSTOM_ELEMENT_HANDLING && ai(S.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (H.attributeNameCheck = S.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), S.CUSTOM_ELEMENT_HANDLING && typeof S.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (H.allowCustomizedBuiltInElements = S.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ot && (et = !1), L && (xt = !0), kt && (re = le({}, Kl), he = [], kt.html === !0 && (le(re, Zl), le(he, Ql)), kt.svg === !0 && (le(re, ra), le(he, la), le(he, nr)), kt.svgFilters === !0 && (le(re, aa), le(he, la), le(he, nr)), kt.mathMl === !0 && (le(re, ia), le(he, Jl), le(he, nr))), S.ADD_TAGS && (re === ce && (re = g0(re)), le(re, S.ADD_TAGS, Ve)), S.ADD_ATTR && (he === Le && (he = g0(he)), le(he, S.ADD_ATTR, Ve)), S.ADD_URI_SAFE_ATTR && le(Tn, S.ADD_URI_SAFE_ATTR, Ve), S.FORBID_CONTENTS && (u0 === Nt && (u0 = g0(u0)), le(u0, S.FORBID_CONTENTS, Ve)), je && (re["#text"] = !0), We && le(re, ["html", "head", "body"]), re.table && (le(re, ["tbody"]), delete Ge.tbody), S.TRUSTED_TYPES_POLICY) {
        if (typeof S.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw fn('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof S.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw fn('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        x = S.TRUSTED_TYPES_POLICY, $ = x.createHTML("");
      } else
        x === void 0 && (x = Qm(_, a)), x !== null && typeof $ == "string" && ($ = x.createHTML(""));
      it && it(S), Z0 = S;
    }
  }, ii = le({}, [...ra, ...aa, ...Pm]), li = le({}, [...ia, ...Hm]), o1 = function(S) {
    let P = v(S);
    (!P || !P.tagName) && (P = {
      namespaceURI: Y0,
      tagName: "template"
    });
    const j = or(S.tagName), Se = or(P.tagName);
    return Tr[S.namespaceURI] ? S.namespaceURI === X0 ? P.namespaceURI === c0 ? j === "svg" : P.namespaceURI === pt ? j === "svg" && (Se === "annotation-xml" || zn[Se]) : !!ii[j] : S.namespaceURI === pt ? P.namespaceURI === c0 ? j === "math" : P.namespaceURI === X0 ? j === "math" && Bn[Se] : !!li[j] : S.namespaceURI === c0 ? P.namespaceURI === X0 && !Bn[Se] || P.namespaceURI === pt && !zn[Se] ? !1 : !li[j] && (a1[j] || !ii[j]) : !!(sn === "application/xhtml+xml" && Tr[S.namespaceURI]) : !1;
  }, jt = function(S) {
    dn(e.removed, {
      element: S
    });
    try {
      v(S).removeChild(S);
    } catch {
      F(S);
    }
  }, K0 = function(S, P) {
    try {
      dn(e.removed, {
        attribute: P.getAttributeNode(S),
        from: P
      });
    } catch {
      dn(e.removed, {
        attribute: null,
        from: P
      });
    }
    if (P.removeAttribute(S), S === "is")
      if (xt || L)
        try {
          jt(P);
        } catch {
        }
      else
        try {
          P.setAttribute(S, "");
        } catch {
        }
  }, si = function(S) {
    let P = null, j = null;
    if (wt)
      S = "<remove></remove>" + S;
    else {
      const Oe = Yl(S, /^[\r\n\t ]+/);
      j = Oe && Oe[0];
    }
    sn === "application/xhtml+xml" && Y0 === c0 && (S = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + S + "</body></html>");
    const Se = x ? x.createHTML(S) : S;
    if (Y0 === c0)
      try {
        P = new g().parseFromString(Se, sn);
      } catch {
      }
    if (!P || !P.documentElement) {
      P = E.createDocument(Y0, "template", null);
      try {
        P.documentElement.innerHTML = Fr ? $ : Se;
      } catch {
      }
    }
    const Qe = P.body || P.documentElement;
    return S && j && Qe.insertBefore(t.createTextNode(j), Qe.childNodes[0] || null), Y0 === c0 ? B.call(P, We ? "html" : "body")[0] : We ? P.documentElement : Qe;
  }, oi = function(S) {
    return A.call(
      S.ownerDocument || S,
      S,
      // eslint-disable-next-line no-bitwise
      h.SHOW_ELEMENT | h.SHOW_COMMENT | h.SHOW_TEXT | h.SHOW_PROCESSING_INSTRUCTION | h.SHOW_CDATA_SECTION,
      null
    );
  }, zr = function(S) {
    return S instanceof p && (typeof S.nodeName != "string" || typeof S.textContent != "string" || typeof S.removeChild != "function" || !(S.attributes instanceof m) || typeof S.removeAttribute != "function" || typeof S.setAttribute != "function" || typeof S.namespaceURI != "string" || typeof S.insertBefore != "function" || typeof S.hasChildNodes != "function");
  }, ui = function(S) {
    return typeof s == "function" && S instanceof s;
  };
  function h0(X, S, P) {
    tr(X, (j) => {
      j.call(e, S, P, Z0);
    });
  }
  const ci = function(S) {
    let P = null;
    if (h0(U.beforeSanitizeElements, S, null), zr(S))
      return jt(S), !0;
    const j = Ve(S.nodeName);
    if (h0(U.uponSanitizeElement, S, {
      tagName: j,
      allowedTags: re
    }), ut && S.hasChildNodes() && !ui(S.firstElementChild) && nt(/<[/\w!]/g, S.innerHTML) && nt(/<[/\w!]/g, S.textContent) || S.nodeType === gn.progressingInstruction || ut && S.nodeType === gn.comment && nt(/<[/\w]/g, S.data))
      return jt(S), !0;
    if (!re[j] || Ge[j]) {
      if (!Ge[j] && di(j) && (H.tagNameCheck instanceof RegExp && nt(H.tagNameCheck, j) || H.tagNameCheck instanceof Function && H.tagNameCheck(j)))
        return !1;
      if (je && !u0[j]) {
        const Se = v(S) || S.parentNode, Qe = w(S) || S.childNodes;
        if (Qe && Se) {
          const Oe = Qe.length;
          for (let ht = Oe - 1; ht >= 0; --ht) {
            const d0 = T(Qe[ht], !0);
            d0.__removalCount = (S.__removalCount || 0) + 1, Se.insertBefore(d0, M(S));
          }
        }
      }
      return jt(S), !0;
    }
    return S instanceof o && !o1(S) || (j === "noscript" || j === "noembed" || j === "noframes") && nt(/<\/no(script|embed|frames)/i, S.innerHTML) ? (jt(S), !0) : (ot && S.nodeType === gn.text && (P = S.textContent, tr([N, K, ie], (Se) => {
      P = mn(P, Se, " ");
    }), S.textContent !== P && (dn(e.removed, {
      element: S.cloneNode()
    }), S.textContent = P)), h0(U.afterSanitizeElements, S, null), !1);
  }, hi = function(S, P, j) {
    if (fe && (P === "id" || P === "name") && (j in t || j in s1))
      return !1;
    if (!(et && !ze[P] && nt(we, P))) {
      if (!(ke && nt(_e, P))) {
        if (!he[P] || ze[P]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(di(S) && (H.tagNameCheck instanceof RegExp && nt(H.tagNameCheck, S) || H.tagNameCheck instanceof Function && H.tagNameCheck(S)) && (H.attributeNameCheck instanceof RegExp && nt(H.attributeNameCheck, P) || H.attributeNameCheck instanceof Function && H.attributeNameCheck(P)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            P === "is" && H.allowCustomizedBuiltInElements && (H.tagNameCheck instanceof RegExp && nt(H.tagNameCheck, j) || H.tagNameCheck instanceof Function && H.tagNameCheck(j)))
          ) return !1;
        } else if (!Tn[P]) {
          if (!nt(De, mn(j, ue, ""))) {
            if (!((P === "src" || P === "xlink:href" || P === "href") && S !== "script" && Nm(j, "data:") === 0 && Xe[S])) {
              if (!(Ie && !nt(Ue, mn(j, ue, "")))) {
                if (j)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, di = function(S) {
    return S !== "annotation-xml" && Yl(S, Me);
  }, mi = function(S) {
    h0(U.beforeSanitizeAttributes, S, null);
    const {
      attributes: P
    } = S;
    if (!P || zr(S))
      return;
    const j = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: he,
      forceKeepAttr: void 0
    };
    let Se = P.length;
    for (; Se--; ) {
      const Qe = P[Se], {
        name: Oe,
        namespaceURI: ht,
        value: d0
      } = Qe, on = Ve(Oe), Br = d0;
      let Je = Oe === "value" ? Br : Lm(Br);
      if (j.attrName = on, j.attrValue = Je, j.keepAttr = !0, j.forceKeepAttr = void 0, h0(U.uponSanitizeAttribute, S, j), Je = j.attrValue, de && (on === "id" || on === "name") && (K0(Oe, S), Je = Ae + Je), ut && nt(/((--!?|])>)|<\/(style|title)/i, Je)) {
        K0(Oe, S);
        continue;
      }
      if (j.forceKeepAttr)
        continue;
      if (!j.keepAttr) {
        K0(Oe, S);
        continue;
      }
      if (!Ze && nt(/\/>/i, Je)) {
        K0(Oe, S);
        continue;
      }
      ot && tr([N, K, ie], (pi) => {
        Je = mn(Je, pi, " ");
      });
      const fi = Ve(S.nodeName);
      if (!hi(fi, on, Je)) {
        K0(Oe, S);
        continue;
      }
      if (x && typeof _ == "object" && typeof _.getAttributeType == "function" && !ht)
        switch (_.getAttributeType(fi, on)) {
          case "TrustedHTML": {
            Je = x.createHTML(Je);
            break;
          }
          case "TrustedScriptURL": {
            Je = x.createScriptURL(Je);
            break;
          }
        }
      if (Je !== Br)
        try {
          ht ? S.setAttributeNS(ht, Oe, Je) : S.setAttribute(Oe, Je), zr(S) ? jt(S) : Xl(e.removed);
        } catch {
          K0(Oe, S);
        }
    }
    h0(U.afterSanitizeAttributes, S, null);
  }, u1 = function X(S) {
    let P = null;
    const j = oi(S);
    for (h0(U.beforeSanitizeShadowDOM, S, null); P = j.nextNode(); )
      h0(U.uponSanitizeShadowNode, P, null), ci(P), mi(P), P.content instanceof i && X(P.content);
    h0(U.afterSanitizeShadowDOM, S, null);
  };
  return e.sanitize = function(X) {
    let S = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, P = null, j = null, Se = null, Qe = null;
    if (Fr = !X, Fr && (X = "<!-->"), typeof X != "string" && !ui(X))
      if (typeof X.toString == "function") {
        if (X = X.toString(), typeof X != "string")
          throw fn("dirty is not a string, aborting");
      } else
        throw fn("toString is not a function");
    if (!e.isSupported)
      return X;
    if (Ke || Mr(S), e.removed = [], typeof X == "string" && (ve = !1), ve) {
      if (X.nodeName) {
        const d0 = Ve(X.nodeName);
        if (!re[d0] || Ge[d0])
          throw fn("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (X instanceof s)
      P = si("<!---->"), j = P.ownerDocument.importNode(X, !0), j.nodeType === gn.element && j.nodeName === "BODY" || j.nodeName === "HTML" ? P = j : P.appendChild(j);
    else {
      if (!xt && !ot && !We && // eslint-disable-next-line unicorn/prefer-includes
      X.indexOf("<") === -1)
        return x && te ? x.createHTML(X) : X;
      if (P = si(X), !P)
        return xt ? null : te ? $ : "";
    }
    P && wt && jt(P.firstChild);
    const Oe = oi(ve ? X : P);
    for (; Se = Oe.nextNode(); )
      ci(Se), mi(Se), Se.content instanceof i && u1(Se.content);
    if (ve)
      return X;
    if (xt) {
      if (L)
        for (Qe = q.call(P.ownerDocument); P.firstChild; )
          Qe.appendChild(P.firstChild);
      else
        Qe = P;
      return (he.shadowroot || he.shadowrootmode) && (Qe = z.call(n, Qe, !0)), Qe;
    }
    let ht = We ? P.outerHTML : P.innerHTML;
    return We && re["!doctype"] && P.ownerDocument && P.ownerDocument.doctype && P.ownerDocument.doctype.name && nt(Ko, P.ownerDocument.doctype.name) && (ht = "<!DOCTYPE " + P.ownerDocument.doctype.name + `>
` + ht), ot && tr([N, K, ie], (d0) => {
      ht = mn(ht, d0, " ");
    }), x && te ? x.createHTML(ht) : ht;
  }, e.setConfig = function() {
    let X = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Mr(X), Ke = !0;
  }, e.clearConfig = function() {
    Z0 = null, Ke = !1;
  }, e.isValidAttribute = function(X, S, P) {
    Z0 || Mr({});
    const j = Ve(X), Se = Ve(S);
    return hi(j, Se, P);
  }, e.addHook = function(X, S) {
    typeof S == "function" && dn(U[X], S);
  }, e.removeHook = function(X, S) {
    if (S !== void 0) {
      const P = qm(U[X], S);
      return P === -1 ? void 0 : Rm(U[X], P, 1)[0];
    }
    return Xl(U[X]);
  }, e.removeHooks = function(X) {
    U[X] = [];
  }, e.removeAllHooks = function() {
    U = ts();
  }, e;
}
Qo();
const {
  HtmlTagHydration: yq,
  SvelteComponent: bq,
  add_render_callback: wq,
  append_hydration: xq,
  attr: kq,
  bubble: Sq,
  check_outros: $q,
  children: Dq,
  claim_component: Aq,
  claim_element: Cq,
  claim_html_tag: Eq,
  claim_space: Fq,
  claim_text: Tq,
  create_component: Mq,
  create_in_transition: zq,
  create_out_transition: Bq,
  destroy_component: qq,
  detach: Rq,
  element: Nq,
  get_svelte_dataset: Lq,
  group_outros: Iq,
  init: Oq,
  insert_hydration: Pq,
  listen: Hq,
  mount_component: Uq,
  run_all: Gq,
  safe_not_equal: Vq,
  set_data: Wq,
  space: jq,
  stop_propagation: Xq,
  text: Yq,
  toggle_class: Zq,
  transition_in: Kq,
  transition_out: Qq
} = window.__gradio__svelte__internal, { createEventDispatcher: Jq, onMount: eR } = window.__gradio__svelte__internal, {
  SvelteComponent: tR,
  append_hydration: nR,
  attr: rR,
  bubble: aR,
  check_outros: iR,
  children: lR,
  claim_component: sR,
  claim_element: oR,
  claim_space: uR,
  create_animation: cR,
  create_component: hR,
  destroy_component: dR,
  detach: mR,
  element: fR,
  ensure_array_like: pR,
  fix_and_outro_and_destroy_block: gR,
  fix_position: _R,
  group_outros: vR,
  init: yR,
  insert_hydration: bR,
  mount_component: wR,
  noop: xR,
  safe_not_equal: kR,
  set_style: SR,
  space: $R,
  transition_in: DR,
  transition_out: AR,
  update_keyed_each: CR
} = window.__gradio__svelte__internal, {
  SvelteComponent: ER,
  attr: FR,
  children: TR,
  claim_element: MR,
  detach: zR,
  element: BR,
  empty: qR,
  init: RR,
  insert_hydration: NR,
  noop: LR,
  safe_not_equal: IR,
  set_style: OR
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jm,
  append_hydration: Pe,
  assign: e4,
  attr: me,
  binding_callbacks: ns,
  check_outros: t4,
  children: Tt,
  claim_component: Jo,
  claim_element: Zt,
  claim_space: I0,
  claim_svg_element: vr,
  claim_text: H0,
  create_component: e1,
  destroy_component: t1,
  detach: qe,
  element: Kt,
  flush: rt,
  get_spread_object: n4,
  get_spread_update: r4,
  get_svelte_dataset: rs,
  group_outros: a4,
  init: i4,
  insert_hydration: v0,
  listen: Er,
  mount_component: n1,
  safe_not_equal: l4,
  set_data: ri,
  set_style: vn,
  space: O0,
  stop_propagation: s4,
  svg_element: yr,
  text: U0,
  transition_in: kn,
  transition_out: br
} = window.__gradio__svelte__internal, { tick: A0, onMount: o4 } = window.__gradio__svelte__internal;
function as(r) {
  let e, t;
  const n = [
    {
      autoscroll: (
        /*gradio*/
        r[10].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      r[10].i18n
    ) },
    /*loading_status*/
    r[6]
  ];
  let a = {};
  for (let i = 0; i < n.length; i += 1)
    a = e4(a, n[i]);
  return e = new Tm({ props: a }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    r[30]
  ), {
    c() {
      e1(e.$$.fragment);
    },
    l(i) {
      Jo(e.$$.fragment, i);
    },
    m(i, l) {
      n1(e, i, l), t = !0;
    },
    p(i, l) {
      const s = l[0] & /*gradio, loading_status*/
      1088 ? r4(n, [
        l[0] & /*gradio*/
        1024 && {
          autoscroll: (
            /*gradio*/
            i[10].autoscroll
          )
        },
        l[0] & /*gradio*/
        1024 && { i18n: (
          /*gradio*/
          i[10].i18n
        ) },
        l[0] & /*loading_status*/
        64 && n4(
          /*loading_status*/
          i[6]
        )
      ]) : {};
      e.$set(s);
    },
    i(i) {
      t || (kn(e.$$.fragment, i), t = !0);
    },
    o(i) {
      br(e.$$.fragment, i), t = !1;
    },
    d(i) {
      t1(e, i);
    }
  };
}
function is(r) {
  let e, t, n, a;
  return {
    c() {
      e = Kt("button"), t = U0(
        /*download_title*/
        r[15]
      ), this.h();
    },
    l(i) {
      e = Zt(i, "BUTTON", { class: !0, style: !0 });
      var l = Tt(e);
      t = H0(
        l,
        /*download_title*/
        r[15]
      ), l.forEach(qe), this.h();
    },
    h() {
      me(e, "class", "context-menu"), vn(
        e,
        "top",
        /*menuY*/
        r[18] + "px"
      ), vn(
        e,
        "left",
        /*menuX*/
        r[17] + "px"
      );
    },
    m(i, l) {
      v0(i, e, l), Pe(e, t), n || (a = Er(e, "click", s4(
        /*downloadFile*/
        r[20]
      )), n = !0);
    },
    p(i, l) {
      l[0] & /*download_title*/
      32768 && ri(
        t,
        /*download_title*/
        i[15]
      ), l[0] & /*menuY*/
      262144 && vn(
        e,
        "top",
        /*menuY*/
        i[18] + "px"
      ), l[0] & /*menuX*/
      131072 && vn(
        e,
        "left",
        /*menuX*/
        i[17] + "px"
      );
    },
    d(i) {
      i && qe(e), n = !1, a();
    }
  };
}
function ls(r) {
  let e, t, n, a, i;
  return {
    c() {
      e = Kt("button"), t = yr("svg"), n = yr("path"), this.h();
    },
    l(l) {
      e = Zt(l, "BUTTON", { class: !0, title: !0 });
      var s = Tt(e);
      t = vr(s, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var o = Tt(t);
      n = vr(o, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Tt(n).forEach(qe), o.forEach(qe), s.forEach(qe), this.h();
    },
    h() {
      me(n, "d", "M15 6L8 12L15 18"), me(n, "stroke-width", "2"), me(n, "stroke-linecap", "round"), me(n, "stroke-linejoin", "round"), me(t, "xmlns", "http://www.w3.org/2000/svg"), me(t, "width", "80%"), me(t, "height", "80%"), me(t, "viewBox", "0 0 24 24"), me(e, "class", "left-arrow"), me(
        e,
        "title",
        /*previous_file_title*/
        r[13]
      );
    },
    m(l, s) {
      v0(l, e, s), Pe(e, t), Pe(t, n), a || (i = Er(
        e,
        "click",
        /*previous_file*/
        r[22]
      ), a = !0);
    },
    p(l, s) {
      s[0] & /*previous_file_title*/
      8192 && me(
        e,
        "title",
        /*previous_file_title*/
        l[13]
      );
    },
    d(l) {
      l && qe(e), a = !1, i();
    }
  };
}
function u4(r) {
  let e, t, n = (
    /*value*/
    r[4].orig_name + ""
  ), a, i;
  return {
    c() {
      e = Kt("span"), t = U0("   "), a = U0(n), i = U0("   "), this.h();
    },
    l(l) {
      e = Zt(l, "SPAN", { class: !0 });
      var s = Tt(e);
      t = H0(s, "   "), a = H0(s, n), i = H0(s, "   "), s.forEach(qe), this.h();
    },
    h() {
      me(e, "class", "file-name");
    },
    m(l, s) {
      v0(l, e, s), Pe(e, t), Pe(e, a), Pe(e, i);
    },
    p(l, s) {
      s[0] & /*value*/
      16 && n !== (n = /*value*/
      l[4].orig_name + "") && ri(a, n);
    },
    d(l) {
      l && qe(e);
    }
  };
}
function c4(r) {
  let e, t, n = (
    /*value*/
    r[4][
      /*index_of_file_to_show*/
      r[0]
    ].orig_name + ""
  ), a, i;
  return {
    c() {
      e = Kt("span"), t = U0("   "), a = U0(n), i = U0("   "), this.h();
    },
    l(l) {
      e = Zt(l, "SPAN", { class: !0 });
      var s = Tt(e);
      t = H0(s, "   "), a = H0(s, n), i = H0(s, "   "), s.forEach(qe), this.h();
    },
    h() {
      me(e, "class", "file-name");
    },
    m(l, s) {
      v0(l, e, s), Pe(e, t), Pe(e, a), Pe(e, i);
    },
    p(l, s) {
      s[0] & /*value, index_of_file_to_show*/
      17 && n !== (n = /*value*/
      l[4][
        /*index_of_file_to_show*/
        l[0]
      ].orig_name + "") && ri(a, n);
    },
    d(l) {
      l && qe(e);
    }
  };
}
function ss(r) {
  let e, t, n, a, i;
  return {
    c() {
      e = Kt("button"), t = yr("svg"), n = yr("path"), this.h();
    },
    l(l) {
      e = Zt(l, "BUTTON", { class: !0, title: !0 });
      var s = Tt(e);
      t = vr(s, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var o = Tt(t);
      n = vr(o, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Tt(n).forEach(qe), o.forEach(qe), s.forEach(qe), this.h();
    },
    h() {
      me(n, "d", "M9 6L16 12L9 18"), me(n, "stroke-width", "2"), me(n, "stroke-linecap", "round"), me(n, "stroke-linejoin", "round"), me(t, "xmlns", "http://www.w3.org/2000/svg"), me(t, "width", "80%"), me(t, "height", "80%"), me(t, "viewBox", "0 0 24 24"), me(e, "class", "right-arrow"), me(
        e,
        "title",
        /*next_file_title*/
        r[14]
      );
    },
    m(l, s) {
      v0(l, e, s), Pe(e, t), Pe(t, n), a || (i = Er(
        e,
        "click",
        /*next_file*/
        r[21]
      ), a = !0);
    },
    p(l, s) {
      s[0] & /*next_file_title*/
      16384 && me(
        e,
        "title",
        /*next_file_title*/
        l[14]
      );
    },
    d(l) {
      l && qe(e), a = !1, i();
    }
  };
}
function h4(r) {
  let e, t, n, a = "<span>·</span><span>·</span><span>·</span>", i, l, s, o, h, m = Array.isArray(
    /*value*/
    r[4]
  ) && /*value*/
  r[4].length > 1, p, g, _, C = Array.isArray(
    /*value*/
    r[4]
  ) && /*value*/
  r[4].length > 1, T, F, M = `.viewer-container {
			position: relative;
			overflow: hidden;
			height: 100%;
			width: 100%;
			display: flex;
			flex-direction: column;
		}
		.viewer {
			display: flex;
			flex-direction: column;
			width: 100%;
			height: 100%;
			overflow: auto;
		}
		.error-message {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			text-align: center;
		}
		.viewer canvas {
			margin: .1vh 0;
		}
		.button-row {
			display: flex;
			flex-direction: row;
			width: 100%;
			justify-content: center;
			align-items: center;
		}
		.file-name {
			max-width: 90%;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
		}
		.viewer-blinker {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			color: var(--onepoint-blue);
			animation: blinker 1.5s cubic-bezier(.5, 0, 1, 1) infinite alternate;
			font-size: 3em;
		}
		.viewer-blinker span {
			opacity: 0;
			animation-name: blinker;
			animation-duration: 1.5s;
			animation-timing-function: cubic-bezier(.5, 0, 1, 1);
			animation-iteration-count: infinite;
		}
		.viewer-blinker span:nth-child(1) {
			animation-delay: 0s;
		}
		.viewer-blinker span:nth-child(2) {
			animation-delay: .5s; /* Délai pour le deuxième point */
		}
		.viewer-blinker span:nth-child(3) {
			animation-delay: 1s; /* Délai pour le troisième point */
		}
		.context-menu  {
			position:fixed;
			background-color:var(--button-secondary-background-fill) !important; 
			border-radius: var(--button-large-radius) !important;
			padding:var(--button-large-padding) !important;
			font-size:var(--button-large-text-size) !important;
			font-weight:var(--button-large-text-weight) !important;
			box-shadow: var(--button-secondary-shadow) !important;
			min-width: 190px;
			z-index:10000;
        }
		.left-arrow, .right-arrow {
			width: 22px;
			height: 22px;
			cursor: pointer;
			border-radius: 50%;
			fill: none;
			background-color:var(--button-secondary-background-fill) !important;
			display: flex;
			flex-shrink: 0;
			justify-content: center;
			align-items: center;
			stroke:var(--button-secondary-text-color);
			stroke-width: 17 !important;
			box-shadow: var(--button-secondary-shadow);
			z-index: var(--layer-1);
		}
		.textLayer {
			pointer-events: auto !important;
			user-select: text;
		}
		canvas {
			pointer-events: none;
		}`, w, v, x, $ = (
    /*loading_status*/
    r[6] && as(r)
  ), E = (
    /*showContextMenu*/
    r[16] && is(r)
  ), A = m && ls(r);
  function q(N, K) {
    if (K[0] & /*value*/
    16 && (g = null), g == null && (g = !!(Array.isArray(
      /*value*/
      N[4]
    ) && /*value*/
    N[4].length > 0)), g) return c4;
    if (typeof /*value*/
    N[4] == "string") return u4;
  }
  let B = q(r, [-1, -1]), z = B && B(r), U = C && ss(r);
  return {
    c() {
      $ && $.c(), e = O0(), t = Kt("div"), n = Kt("div"), n.innerHTML = a, i = O0(), l = Kt("div"), s = O0(), E && E.c(), o = O0(), h = Kt("div"), A && A.c(), p = O0(), z && z.c(), _ = O0(), U && U.c(), T = O0(), F = Kt("style"), F.textContent = M, this.h();
    },
    l(N) {
      $ && $.l(N), e = I0(N), t = Zt(N, "DIV", { class: !0 });
      var K = Tt(t);
      n = Zt(K, "DIV", {
        class: !0,
        style: !0,
        "data-svelte-h": !0
      }), rs(n) !== "svelte-1588yl4" && (n.innerHTML = a), i = I0(K), l = Zt(K, "DIV", { class: !0 }), Tt(l).forEach(qe), s = I0(K), E && E.l(K), o = I0(K), h = Zt(K, "DIV", { class: !0 });
      var ie = Tt(h);
      A && A.l(ie), p = I0(ie), z && z.l(ie), _ = I0(ie), U && U.l(ie), ie.forEach(qe), K.forEach(qe), T = I0(N), F = Zt(N, "STYLE", { "data-svelte-h": !0 }), rs(F) !== "svelte-1q5tal0" && (F.textContent = M), this.h();
    },
    h() {
      me(n, "class", "viewer-blinker"), vn(n, "display", "none"), me(l, "class", "viewer"), me(h, "class", "button-row"), me(t, "class", "viewer-container");
    },
    m(N, K) {
      $ && $.m(N, K), v0(N, e, K), v0(N, t, K), Pe(t, n), r[31](n), Pe(t, i), Pe(t, l), r[32](l), Pe(t, s), E && E.m(t, null), Pe(t, o), Pe(t, h), A && A.m(h, null), Pe(h, p), z && z.m(h, null), Pe(h, _), U && U.m(h, null), v0(N, T, K), v0(N, F, K), w = !0, v || (x = Er(
        l,
        "contextmenu",
        /*handleContextMenu*/
        r[19]
      ), v = !0);
    },
    p(N, K) {
      /*loading_status*/
      N[6] ? $ ? ($.p(N, K), K[0] & /*loading_status*/
      64 && kn($, 1)) : ($ = as(N), $.c(), kn($, 1), $.m(e.parentNode, e)) : $ && (a4(), br($, 1, 1, () => {
        $ = null;
      }), t4()), /*showContextMenu*/
      N[16] ? E ? E.p(N, K) : (E = is(N), E.c(), E.m(t, o)) : E && (E.d(1), E = null), K[0] & /*value*/
      16 && (m = Array.isArray(
        /*value*/
        N[4]
      ) && /*value*/
      N[4].length > 1), m ? A ? A.p(N, K) : (A = ls(N), A.c(), A.m(h, p)) : A && (A.d(1), A = null), B === (B = q(N, K)) && z ? z.p(N, K) : (z && z.d(1), z = B && B(N), z && (z.c(), z.m(h, _))), K[0] & /*value*/
      16 && (C = Array.isArray(
        /*value*/
        N[4]
      ) && /*value*/
      N[4].length > 1), C ? U ? U.p(N, K) : (U = ss(N), U.c(), U.m(h, null)) : U && (U.d(1), U = null);
    },
    i(N) {
      w || (kn($), w = !0);
    },
    o(N) {
      br($), w = !1;
    },
    d(N) {
      N && (qe(e), qe(t), qe(T), qe(F)), $ && $.d(N), r[31](null), r[32](null), E && E.d(), A && A.d(), z && z.d(), U && U.d(), v = !1, x();
    }
  };
}
function d4(r) {
  let e, t;
  return e = new B1({
    props: {
      visible: (
        /*visible*/
        r[3]
      ),
      elem_id: (
        /*elem_id*/
        r[1]
      ),
      elem_classes: (
        /*elem_classes*/
        r[2]
      ),
      container: (
        /*container*/
        r[7]
      ),
      scale: (
        /*scale*/
        r[8]
      ),
      min_width: (
        /*min_width*/
        r[9]
      ),
      height: (
        /*height*/
        r[5]
      ),
      $$slots: { default: [h4] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      e1(e.$$.fragment);
    },
    l(n) {
      Jo(e.$$.fragment, n);
    },
    m(n, a) {
      n1(e, n, a), t = !0;
    },
    p(n, a) {
      const i = {};
      a[0] & /*visible*/
      8 && (i.visible = /*visible*/
      n[3]), a[0] & /*elem_id*/
      2 && (i.elem_id = /*elem_id*/
      n[1]), a[0] & /*elem_classes*/
      4 && (i.elem_classes = /*elem_classes*/
      n[2]), a[0] & /*container*/
      128 && (i.container = /*container*/
      n[7]), a[0] & /*scale*/
      256 && (i.scale = /*scale*/
      n[8]), a[0] & /*min_width*/
      512 && (i.min_width = /*min_width*/
      n[9]), a[0] & /*height*/
      32 && (i.height = /*height*/
      n[5]), a[0] & /*next_file_title, value, index_of_file_to_show, previous_file_title, menuY, menuX, download_title, showContextMenu, viewer, blinking, gradio, loading_status*/
      523345 | a[1] & /*$$scope*/
      1048576 && (i.$$scope = { dirty: a, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (kn(e.$$.fragment, n), t = !0);
    },
    o(n) {
      br(e.$$.fragment, n), t = !1;
    },
    d(n) {
      t1(e, n);
    }
  };
}
function os(r, e) {
  const t = document.createElement("a");
  t.href = r, t.download = e, document.body.appendChild(t), t.click(), t.remove();
}
function m4(r, e) {
  return r && (r.url = e + "/gradio_api/file=" + r.path), r;
}
function f4(r) {
  return new Promise((e, t) => {
    const n = document.createElement("link");
    n.rel = "stylesheet", n.href = r, n.onload = () => e("Resource loaded successfully"), n.onerror = () => t(new Error(`Erreur lors du chargement du CSS : ${r}`)), document.head.appendChild(n);
  });
}
function p4(r, e, t) {
  var n = this && this.__awaiter || function(L, te, fe, de) {
    function Ae(je) {
      return je instanceof fe ? je : new fe(function(ve) {
        ve(je);
      });
    }
    return new (fe || (fe = Promise))(function(je, ve) {
      function kt(Xe) {
        try {
          Nt(de.next(Xe));
        } catch (ct) {
          ve(ct);
        }
      }
      function u0(Xe) {
        try {
          Nt(de.throw(Xe));
        } catch (ct) {
          ve(ct);
        }
      }
      function Nt(Xe) {
        Xe.done ? je(Xe.value) : Ae(Xe.value).then(kt, u0);
      }
      Nt((de = de.apply(L, te || [])).next());
    });
  };
  let { elem_id: a = "" } = e, { elem_classes: i = [] } = e, { visible: l = !0 } = e, { value: s } = e, { index_of_file_to_show: o } = e, { libre_office: h } = e, { max_size: m } = e, { max_pages: p } = e, { root: g } = e, { height: _ } = e, { loading_status: C } = e, { container: T = !0 } = e, { scale: F = null } = e, { min_width: M = void 0 } = e, { gradio: w } = e, v = null, x, $ = null, E = new AbortController(), A, q, B = !0, z = !0, U = !0, N = !0, K, ie, we, _e = !1, Ue = 0, ue = 0;
  navigator.language.startsWith("fr") ? (K = "Fichier précédent", ie = "Fichier suivant", we = "Télécharger le fichier") : (K = "Previous file", ie = "Next file", we = "Download file");
  function Me(L) {
    var te;
    if (console.log("Context menu triggered"), console.log("File to download:", x), !x) return;
    L.preventDefault();
    let fe = L.clientX, de = L.clientY;
    const Ae = q.querySelector("iframe");
    if (Ae && Ae.contentDocument === ((te = L.view) === null || te === void 0 ? void 0 : te.document)) {
      const ve = Ae.getBoundingClientRect();
      fe += ve.left, de += ve.top;
    }
    const je = q.getBoundingClientRect();
    t(17, Ue = fe - je.left), t(18, ue = de - je.top), t(16, _e = !0), console.log("Context menu position:", Ue, ue), console.log("Context menu visibility:", _e);
  }
  function De() {
    return n(this, void 0, void 0, function* () {
      if (x)
        try {
          if (he.some((L) => x.path.endsWith(L))) {
            const L = yield fetch(x.url);
            if (!L.ok) throw new Error(`HTTP ${L.status}`);
            const te = yield L.arrayBuffer(), fe = new Blob([te], { type: L.headers.get("Content-Type") }), de = URL.createObjectURL(fe);
            os(de, x.orig_name), URL.revokeObjectURL(de);
          } else {
            const L = new URL(x.url), te = L.pathname.split("/");
            te[te.length - 1] = encodeURIComponent(x.orig_name), L.pathname = te.join("/"), os(L.toString(), x.orig_name);
          }
        } catch (L) {
          console.error("Download failed:", L);
        } finally {
          t(16, _e = !1);
        }
    });
  }
  o4(() => {
    const L = () => t(16, _e = !1);
    return window.addEventListener("click", L), () => window.removeEventListener("click", L);
  });
  function re(L, te) {
    let fe;
    return Array.isArray(L) && L.length > 0 ? fe = L[te] : L instanceof _1 && (fe = L), fe;
  }
  const ce = [".html", ".svg"], he = [".png", ".jpg", ".jpeg"], Le = [".md", ".txt", ".csv", ".srt"], H = [".docx", ".pptx", ".xlsx", ".doc", ".ppt", ".xls"], Ge = [
    ".py",
    ".js",
    ".css",
    ".json",
    ".yaml",
    ".yml",
    ".xml",
    ".sh",
    ".bash",
    ".log",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".cpp"
  ];
  function ze() {
    return n(this, void 0, void 0, function* () {
      E.abort(), t(29, E = new AbortController()), yield A0(), t(11, A.style.display = "none", A), t(12, q.innerHTML = "", q);
    });
  }
  function ke(L) {
    return n(this, void 0, void 0, function* () {
      console.log("Show error"), t(29, E = new AbortController()), yield A0(), t(11, A.style.display = "none", A);
      let te;
      L == "format" ? te = navigator.language.startsWith("fr") ? "Format non pris en charge" : "Unsupported format" : L == "size" && (te = navigator.language.startsWith("fr") ? "Fichier trop volumineux pour être affiché" : "File too heavy to be displayed"), t(12, q.innerHTML = `<div class="error-message">${te}</div>`, q);
    });
  }
  function et(L) {
    return n(this, void 0, void 0, function* () {
      v || (v = yield import("./pdf-BFxemuZO.js").then((ve) => ve.p), v.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js", yield f4("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf_viewer.min.css")), N = !1, t(29, E = new AbortController()), yield A0(), t(12, q.innerHTML = "", q), t(11, A.style.display = "block", A);
      const fe = yield v.getDocument(L.url).promise;
      if (console.log("PDF loaded"), fe.numPages > p) {
        ke("size");
        return;
      }
      const de = document.createDocumentFragment(), Ae = (ve) => n(this, void 0, void 0, function* () {
        if (N) {
          console.log("Cancelled");
          return;
        }
        const kt = yield fe.getPage(ve);
        console.log(`Page ${ve} loaded`);
        const Nt = kt.getViewport({ scale: 1.5 }), Xe = document.createElement("div");
        Xe.className = "pageContainer", Xe.style.position = "relative", Xe.style.width = "100%", de.appendChild(Xe);
        const ct = document.createElement("canvas");
        ct.style.width = "100%", ct.width = Nt.width, ct.height = Nt.height, Xe.appendChild(ct);
        const Mn = { canvasContext: ct.getContext("2d"), viewport: Nt };
        yield kt.render(Mn).promise, console.log(`Page ${ve} rendered`);
        const pt = document.createElement("div");
        pt.className = "textLayer", pt.style.position = "absolute", pt.style.top = "0", pt.style.left = "0", pt.style.width = ct.width + "px", pt.style.height = ct.height + "px", Xe.appendChild(pt);
        const X0 = yield kt.getTextContent();
        yield v.renderTextLayer({
          textContentSource: X0,
          container: pt,
          viewport: Nt,
          textDivs: [],
          // tableau vide qui sera rempli par la fonction
          pageIndex: ve - 1,
          // indice de la page (0-indexé)
          enhanceTextSelection: !0
          // améliore la sélection du texte
        });
      }), je = [];
      for (let ve = 1; ve <= fe.numPages; ve++) {
        if (N) {
          console.log("Cancelled");
          break;
        }
        je.push(Ae(ve));
      }
      yield Promise.all(je), N ? console.log("append viewer with pdf cancelled") : q.appendChild(de), N = !0, t(11, A.style.display = "none", A);
    });
  }
  function Ie(L) {
    return n(this, void 0, void 0, function* () {
      U = !1, t(29, E = new AbortController()), yield A0(), t(12, q.innerHTML = "", q), t(11, A.style.display = "block", A);
      try {
        const te = yield fetch(L.url, { signal: E.signal });
        if (!te.ok)
          throw new Error(`HTTP error! status: ${te.status}`);
        const fe = yield te.text(), de = document.createElement("iframe");
        de.style.width = "100%", de.style.height = "100%", de.srcdoc = fe, de.addEventListener("load", () => {
          const Ae = de.contentDocument, je = new MouseEvent(
            "contextmenu",
            {
              bubbles: !0,
              // let the event bubble up the DOM hierarchy
              cancelable: !0,
              // allow handlers to call preventDefault()
              view: de.contentWindow
              // bind the event to the iframe's Window object
            }
          ), ve = !Ae.dispatchEvent(je);
          console.log("Context menu event was canceled:", ve), console.log("Context menu event injected:", Ae.__neoContextInjected), !ve && !Ae.__neoContextInjected && (Ae.addEventListener("contextmenu", Me, { passive: !1 }), Ae.__neoContextInjected = !0);
        }), U ? console.log("append viewer with iframe cancelled") : q.appendChild(de);
      } catch (te) {
        console.error("Error fetching HTML content:", te);
      }
      U = !0, t(11, A.style.display = "none", A);
    });
  }
  function Ze(L) {
    return n(this, void 0, void 0, function* () {
      B = !1, t(29, E = new AbortController()), yield A0(), t(12, q.innerHTML = "", q), t(11, A.style.display = "block", A);
      try {
        const te = yield fetch(L.url, { signal: E.signal });
        if (!te.ok)
          throw new Error(`HTTP error! status: ${te.status}`);
        const fe = yield te.blob(), de = URL.createObjectURL(fe), Ae = document.createElement("img");
        Ae.style.width = "100%", Ae.src = de, B ? console.log("append viewer with image cancelled") : q.appendChild(Ae);
      } catch (te) {
        console.error("Error fetching image content:", te);
      }
      B = !0, t(11, A.style.display = "none", A);
    });
  }
  function ot(L) {
    return n(this, void 0, void 0, function* () {
      z = !1, t(29, E = new AbortController()), yield A0(), t(12, q.innerHTML = "", q), t(11, A.style.display = "block", A);
      try {
        const te = yield fetch(L.url, { signal: E.signal });
        if (!te.ok)
          throw new Error(`HTTP error! status: ${te.status}`);
        let fe = yield te.text();
        const de = L.path.match(/\.(\w+)$/);
        if (de) {
          const Ae = de[1];
          console.log("fichier .", Ae), Ge.includes(`.${Ae}`) && (fe = `\`\`\`${Ae}
${fe}
\`\`\``);
        }
        z ? console.log("append viewer with markdown cancelled") : new $d({
          target: q,
          props: {
            message: fe,
            latex_delimiters: [],
            sanitize_html: !0,
            render_markdown: !0,
            line_breaks: !1,
            root: g
          }
        });
      } catch (te) {
        console.error("Error fetching Markdown content:", te);
      }
      z = !0, t(11, A.style.display = "none", A);
    });
  }
  function ut() {
    return n(this, void 0, void 0, function* () {
      yield A0(), t(11, A.style.display = "none", A), Array.isArray(s) && s.length > 1 && t(0, o = (o + 1) % s.length);
    });
  }
  function We() {
    return n(this, void 0, void 0, function* () {
      yield A0(), t(11, A.style.display = "none", A), t(0, o = (o - 1 + s.length) % s.length);
    });
  }
  const Ke = () => w.dispatch("clear_status", C);
  function wt(L) {
    ns[L ? "unshift" : "push"](() => {
      A = L, t(11, A);
    });
  }
  function xt(L) {
    ns[L ? "unshift" : "push"](() => {
      q = L, t(12, q);
    });
  }
  return r.$$set = (L) => {
    "elem_id" in L && t(1, a = L.elem_id), "elem_classes" in L && t(2, i = L.elem_classes), "visible" in L && t(3, l = L.visible), "value" in L && t(4, s = L.value), "index_of_file_to_show" in L && t(0, o = L.index_of_file_to_show), "libre_office" in L && t(23, h = L.libre_office), "max_size" in L && t(24, m = L.max_size), "max_pages" in L && t(25, p = L.max_pages), "root" in L && t(26, g = L.root), "height" in L && t(5, _ = L.height), "loading_status" in L && t(6, C = L.loading_status), "container" in L && t(7, T = L.container), "scale" in L && t(8, F = L.scale), "min_width" in L && t(9, M = L.min_width), "gradio" in L && t(10, w = L.gradio);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*value, visible, index_of_file_to_show, old_file, abortController, gradio, root, file, max_size, libre_office*/
    1031799833 && (s && (!Array.isArray(s) || s.length > 0) && l ? s && JSON.stringify(re(s, o)) !== JSON.stringify($) && (E.abort(), U = !0, B = !0, z = !0, N = !0, w.dispatch("change"), t(28, $ = re(s, o)), t(27, x = m4(re(s, o), g)), console.log(x.url), x.size > m ? (console.log("Fichier trop lourd"), ke("size")) : x.path.endsWith("pdf") || h && H.some((L) => x.path.endsWith(L)) ? (console.log("PDF ou MS"), et(x)) : ce.some((L) => x.path.endsWith(L)) ? (console.log("HTML"), x.size > m ? (console.log("HTML trop lourd"), ke("size")) : Ie(x)) : he.some((L) => x.path.endsWith(L)) ? (console.log("Image"), Ze(x)) : Le.some((L) => x.path.endsWith(L)) || Ge.some((L) => x.path.endsWith(L)) ? (console.log("Markdown"), x.size > m ? (console.log("Markdown trop lourd"), ke("size")) : ot(x)) : (console.log("Autre"), ke("format"))) : (ze(), t(28, $ = null)));
  }, [
    o,
    a,
    i,
    l,
    s,
    _,
    C,
    T,
    F,
    M,
    w,
    A,
    q,
    K,
    ie,
    we,
    _e,
    Ue,
    ue,
    Me,
    De,
    ut,
    We,
    h,
    m,
    p,
    g,
    x,
    $,
    E,
    Ke,
    wt,
    xt
  ];
}
class PR extends Jm {
  constructor(e) {
    super(), i4(
      this,
      e,
      p4,
      d4,
      l4,
      {
        elem_id: 1,
        elem_classes: 2,
        visible: 3,
        value: 4,
        index_of_file_to_show: 0,
        libre_office: 23,
        max_size: 24,
        max_pages: 25,
        root: 26,
        height: 5,
        loading_status: 6,
        container: 7,
        scale: 8,
        min_width: 9,
        gradio: 10
      },
      null,
      [-1, -1]
    );
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), rt();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), rt();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), rt();
  }
  get value() {
    return this.$$.ctx[4];
  }
  set value(e) {
    this.$$set({ value: e }), rt();
  }
  get index_of_file_to_show() {
    return this.$$.ctx[0];
  }
  set index_of_file_to_show(e) {
    this.$$set({ index_of_file_to_show: e }), rt();
  }
  get libre_office() {
    return this.$$.ctx[23];
  }
  set libre_office(e) {
    this.$$set({ libre_office: e }), rt();
  }
  get max_size() {
    return this.$$.ctx[24];
  }
  set max_size(e) {
    this.$$set({ max_size: e }), rt();
  }
  get max_pages() {
    return this.$$.ctx[25];
  }
  set max_pages(e) {
    this.$$set({ max_pages: e }), rt();
  }
  get root() {
    return this.$$.ctx[26];
  }
  set root(e) {
    this.$$set({ root: e }), rt();
  }
  get height() {
    return this.$$.ctx[5];
  }
  set height(e) {
    this.$$set({ height: e }), rt();
  }
  get loading_status() {
    return this.$$.ctx[6];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), rt();
  }
  get container() {
    return this.$$.ctx[7];
  }
  set container(e) {
    this.$$set({ container: e }), rt();
  }
  get scale() {
    return this.$$.ctx[8];
  }
  set scale(e) {
    this.$$set({ scale: e }), rt();
  }
  get min_width() {
    return this.$$.ctx[9];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), rt();
  }
  get gradio() {
    return this.$$.ctx[10];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), rt();
  }
}
export {
  PR as I,
  v4 as a,
  y4 as g
};
