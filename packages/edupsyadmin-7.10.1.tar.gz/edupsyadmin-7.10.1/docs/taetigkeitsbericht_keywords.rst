Mögliche Tätigkeitsbericht-Kategorien
=====================================

.. csv-table:: Keywords und Definition
   :file: ../src/edupsyadmin/data/taetigkeitsbericht_categories.csv
   :widths: 30, 70
   :header-rows: 1
