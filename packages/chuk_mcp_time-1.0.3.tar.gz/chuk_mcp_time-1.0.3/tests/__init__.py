"""Tests for chuk-mcp-time."""
