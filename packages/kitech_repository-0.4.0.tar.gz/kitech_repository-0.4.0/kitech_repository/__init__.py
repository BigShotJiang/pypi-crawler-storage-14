"""KITECH Manufacturing Data Repository Library and CLI."""

__version__ = "0.4.0"
__author__ = "KITECH Repository Team"

from kitech_repository.core.auth import AuthManager
from kitech_repository.core.client import KitechClient
from kitech_repository.core.config import Config


# Convenience functions for library usage
def download(repository_id: int, remote_path: str = "", local_path: str = None, app_key: str = None):
    """Download a file or directory from repository.

    Args:
        repository_id: The repository ID
        remote_path: Path to file/folder in repository.
                     - "" or "/" : Download entire repository (root)
                     - "file.txt" : Download single file
                     - "folder/" : Download folder (must end with /)
        local_path: Local directory to save (None for default download directory)
        app_key: API app key (None to use stored app key)

    Returns:
        Path: Path to downloaded file/directory
    """
    # Normalize: "/" or empty string = full repository download
    path = None if (not remote_path or remote_path == "/") else remote_path

    with KitechClient(app_key=app_key) as client:
        return client.download_file(
            repository_id=repository_id, path=path, output_dir=local_path, show_progress=True
        )


def upload(repository_id: int, local_path: str, remote_path: str = "", app_key: str = None, show_progress: bool = True):
    """Upload a file or folder to repository (auto-detects type).

    Args:
        repository_id: The repository ID
        local_path: Local file or folder path to upload
        remote_path: Remote path within repository (empty string for root).
                     Leading/trailing slashes are automatically removed.
        app_key: API app key (None to use stored app key)
        show_progress: Show progress messages during upload

    Returns:
        dict: Upload response data (for file) or upload statistics (for folder)

    Raises:
        UploadError: If user has VIEWER role (no upload permission)
    """
    with KitechClient(app_key=app_key) as client:
        return client.upload(
            repository_id=repository_id,
            local_path=local_path,
            remote_path=remote_path,
            show_progress=show_progress,
        )


def list_repositories(app_key: str = None):
    """List available repositories.

    Args:
        app_key: API app key (None to use stored app key)

    Returns:
        list: List of Repository objects
    """
    with KitechClient(app_key=app_key) as client:
        result = client.list_repositories()
        return result["repositories"]


def list_files(repository_id: int, path: str = "", app_key: str = None, page: int = 0, limit: int = 100):
    """List files in repository.

    Args:
        repository_id: The repository ID
        path: Path within repository (empty string for root)
        app_key: API app key (None to use stored app key)
        page: Page number (default: 0)
        limit: Number of files per page (default: 100)

    Returns:
        dict: Dictionary containing 'files' list and pagination metadata
    """
    with KitechClient(app_key=app_key) as client:
        return client.list_files(repository_id, prefix=path if path else "", page=page, limit=limit)


# Export main classes and functions
__all__ = [
    "KitechClient",
    "AuthManager",
    "Config",
    "download",
    "upload",
    "list_repositories",
    "list_files",
]
