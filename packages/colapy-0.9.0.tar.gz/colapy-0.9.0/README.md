# COLA-PY

Python обертка над фреймворком COLA

## Develop

```shell
pip install -e .
```

## Publish

```shell
python -m build --sdist
python -m twine upload dist/*
```
