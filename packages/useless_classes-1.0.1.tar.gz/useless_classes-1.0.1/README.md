# useless-classes
Classes to make yourt code cleaner, fault-proof and battle tested in real systems

## Skeleton
Copies the functions of the class you want, now you canuse it inplace. It's basically a mock, but most methods return `NullClass()`.

## NullClass
Because None is not enough, this comes in handy when things might be or not, and you don't want to constantly check if it's something.
Fools the type checkers pretty well.
