# HDL Source Files
This folder contains some SystemVerilog definitions that are useful collateral
to be used alongside this project.

These reference files are free to use for any purpose and are not covered by
this project's LGPLv3 license.

If for whatever reason you feel the need to reference a license when using
these, then lets go with the [MIT License](https://choosealicense.com/licenses/mit/)
