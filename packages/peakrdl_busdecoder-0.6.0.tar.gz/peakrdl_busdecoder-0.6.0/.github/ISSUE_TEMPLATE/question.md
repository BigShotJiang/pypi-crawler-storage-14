---
name: Question
about: I have a question
title: ''
labels: ''
assignees: ''

---

Please consider using the discussion board for more open-ended questions: https://github.com/orgs/SystemRDL/discussions
