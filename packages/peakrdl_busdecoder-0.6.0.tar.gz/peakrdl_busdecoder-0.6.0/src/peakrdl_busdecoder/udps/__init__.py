from systemrdl.udp import UDPDefinition

ALL_UDPS: list[type[UDPDefinition]] = []

__all__ = ["ALL_UDPS"]
