Non-ASCII characters
