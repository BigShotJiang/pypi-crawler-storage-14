Egg
===

.. currentmodule:: sphinx_automodapi.tests.example_module

.. autoclass:: Egg
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~Egg.weight

   .. rubric:: Methods Summary

   .. autosummary::

      ~Egg.buy
      ~Egg.eat

   .. rubric:: Attributes Documentation

   .. autoproperty:: weight

   .. rubric:: Methods Documentation

   .. automethod:: buy
   .. automethod:: eat
