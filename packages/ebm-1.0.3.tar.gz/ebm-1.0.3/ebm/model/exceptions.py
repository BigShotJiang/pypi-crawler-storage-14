
class AmbiguousDataError(Exception):
    """Custom exception raised when conflicting data is found."""
    pass
