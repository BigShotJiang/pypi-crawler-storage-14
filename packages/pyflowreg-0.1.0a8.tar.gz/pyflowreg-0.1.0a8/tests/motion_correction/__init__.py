"""Tests for motion correction module."""
