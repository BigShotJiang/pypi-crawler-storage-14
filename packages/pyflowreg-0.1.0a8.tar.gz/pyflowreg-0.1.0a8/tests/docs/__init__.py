"""
Tests for documentation code examples.

This module uses pytest-doctestplus to validate that all code examples
in the documentation (*.md files) execute correctly.
"""
