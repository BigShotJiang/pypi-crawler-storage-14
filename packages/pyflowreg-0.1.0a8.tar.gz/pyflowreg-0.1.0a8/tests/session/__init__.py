"""Tests for session-level multi-recording processing."""
