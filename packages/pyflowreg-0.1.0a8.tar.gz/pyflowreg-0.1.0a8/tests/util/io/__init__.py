"""Tests for pyflowreg.util.io module."""
