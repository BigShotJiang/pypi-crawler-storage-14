"""
PH Shorts Downloader - Download Shorts from PornHub with ease!

A lightweight and powerful alternative to yt-dlp for PornHub Shorts.
"""

__version__ = "1.0.3"
__author__ = "PH Shorts DL Team"
__description__ = "Download PornHub Shorts videos with a beautiful CLI interface"
