
class StateOverrideNotSupported(Exception):
    pass
