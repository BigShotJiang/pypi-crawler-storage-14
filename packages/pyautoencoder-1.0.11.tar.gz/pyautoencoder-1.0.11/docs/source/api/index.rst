API Reference
=============

Complete reference documentation for all models, losses, and utilities.

.. toctree::
   :maxdepth: 2

   base
   models
   losses
   stochastic
