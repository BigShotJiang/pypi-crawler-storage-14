# noqa: D100
from __future__ import annotations

__all__ = ("World",)

from tcod.ecs.registry import Registry as World

# This modules existence keeps backwards compatibly with tcod-ecs version <= 5.0.0
