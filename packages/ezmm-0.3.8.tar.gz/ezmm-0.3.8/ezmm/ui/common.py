from pathlib import Path

SEQ_PATH = Path("temp/sequences")
