from ezmm.common.items import Item


class Audio(Item):
    kind = "audio"
    # TODO: Implement
