"""
Publish Markdown files to Confluence wiki.

Copyright 2022-2025, Levente Hunyadi

:see: https://github.com/hunyadi/md2conf
"""

import re
import typing
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, TypeVar

import yaml

from .mermaid import MermaidConfigProperties
from .serializer import JsonType, json_to_object

T = TypeVar("T")


def extract_value(pattern: str, text: str) -> tuple[str | None, str]:
    values: list[str] = []

    def _repl_func(matchobj: re.Match[str]) -> str:
        values.append(matchobj.group(1))
        return ""

    text = re.sub(pattern, _repl_func, text, count=1, flags=re.ASCII)
    value = values[0] if values else None
    return value, text


def extract_frontmatter_block(text: str) -> tuple[str | None, str]:
    "Extracts the front-matter from a Markdown document as a blob of unparsed text."

    return extract_value(r"(?ms)\A---$(.+?)^---$", text)


def extract_frontmatter_properties(text: str) -> tuple[dict[str, JsonType] | None, str]:
    "Extracts the front-matter from a Markdown document as a dictionary."

    block, text = extract_frontmatter_block(text)

    properties: dict[str, Any] | None = None
    if block is not None:
        data = yaml.safe_load(block)
        if isinstance(data, dict):
            properties = typing.cast(dict[str, JsonType], data)

    return properties, text


@dataclass
class DocumentProperties:
    """
    An object that holds properties extracted from the front-matter of a Markdown document.

    :param page_id: Confluence page ID.
    :param space_key: Confluence space key.
    :param confluence_page_id: Confluence page ID. (Alternative name for JSON de-serialization.)
    :param confluence_space_key: Confluence space key. (Alternative name for JSON de-serialization.)
    :param generated_by: Text identifying the tool that generated the document.
    :param title: The title extracted from front-matter.
    :param tags: A list of tags (content labels) extracted from front-matter.
    :param synchronized: True if the document content is parsed and synchronized with Confluence.
    :param properties: A dictionary of key-value pairs extracted from front-matter to apply as page properties.
    :param alignment: Alignment for block-level images and formulas.
    """

    page_id: str | None = None
    space_key: str | None = None
    confluence_page_id: str | None = None
    confluence_space_key: str | None = None
    generated_by: str | None = None
    title: str | None = None
    tags: list[str] | None = None
    synchronized: bool | None = None
    properties: dict[str, JsonType] | None = None
    alignment: Literal["center", "left", "right"] | None = None


@dataclass
class ScannedDocument:
    """
    An object that holds properties extracted from a Markdown document, including remaining source text.

    :param page_id: Confluence page ID.
    :param space_key: Confluence space key.
    :param generated_by: Text identifying the tool that generated the document.
    :param title: The title extracted from front-matter.
    :param tags: A list of tags (content labels) extracted from front-matter.
    :param synchronized: True if the document content is parsed and synchronized with Confluence.
    :param properties: A dictionary of key-value pairs extracted from front-matter to apply as page properties.
    :param alignment: Alignment for block-level images and formulas.
    :param text: Text that remains after front-matter and inline properties have been extracted.
    """

    page_id: str | None
    space_key: str | None
    generated_by: str | None
    title: str | None
    tags: list[str] | None
    synchronized: bool | None
    properties: dict[str, JsonType] | None
    alignment: Literal["center", "left", "right"] | None
    text: str


class Scanner:
    def read(self, absolute_path: Path) -> ScannedDocument:
        """
        Extracts essential properties from a Markdown document.
        """

        # parse file
        with open(absolute_path, "r", encoding="utf-8") as f:
            text = f.read()

        # extract Confluence page ID
        page_id, text = extract_value(r"<!--\s+confluence[-_]page[-_]id:\s*(\d+)\s+-->", text)

        # extract Confluence space key
        space_key, text = extract_value(r"<!--\s+confluence[-_]space[-_]key:\s*(\S+)\s+-->", text)

        # extract 'generated-by' tag text
        generated_by, text = extract_value(r"<!--\s+generated[-_]by:\s*(.*)\s+-->", text)

        title: str | None = None
        tags: list[str] | None = None
        synchronized: bool | None = None
        properties: dict[str, JsonType] | None = None
        alignment: Literal["center", "left", "right"] | None = None

        # extract front-matter
        data, text = extract_frontmatter_properties(text)
        if data is not None:
            p = json_to_object(DocumentProperties, data)
            page_id = page_id or p.confluence_page_id or p.page_id
            space_key = space_key or p.confluence_space_key or p.space_key
            generated_by = generated_by or p.generated_by
            title = p.title
            tags = p.tags
            synchronized = p.synchronized
            properties = p.properties
            alignment = p.alignment

        return ScannedDocument(
            page_id=page_id,
            space_key=space_key,
            generated_by=generated_by,
            title=title,
            tags=tags,
            synchronized=synchronized,
            properties=properties,
            alignment=alignment,
            text=text,
        )


@dataclass
class MermaidProperties:
    """
    An object that holds the front-matter properties structure for Mermaid diagrams.

    :param title: The title of the diagram.
    :param config: Configuration options for rendering.
    """

    title: str | None = None
    config: MermaidConfigProperties | None = None


class MermaidScanner:
    """
    Extracts properties from the JSON/YAML front-matter of a Mermaid diagram.
    """

    def read(self, content: str) -> MermaidProperties:
        """
        Extracts rendering preferences from a Mermaid front-matter content.

        ```
        ---
        title: Tiny flow diagram
        config:
            scale: 1
        ---
        flowchart LR
            A[Component A] --> B[Component B]
            B --> C[Component C]
        ```
        """

        properties, _ = extract_frontmatter_properties(content)
        if properties is not None:
            front_matter = json_to_object(MermaidProperties, properties)
            config = front_matter.config or MermaidConfigProperties()

            return MermaidProperties(title=front_matter.title, config=config)

        return MermaidProperties()
