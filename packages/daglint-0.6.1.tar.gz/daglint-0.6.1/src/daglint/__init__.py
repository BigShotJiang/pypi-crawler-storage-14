"""DAGLint - A linting tool for Apache Airflow DAG files."""

__version__ = "0.6.1"
