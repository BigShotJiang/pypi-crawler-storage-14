class Painter:
    # === ANSI constants ===
    RESET = "\033[0m"

    BLACK   = "\033[30m"
    RED     = "\033[31m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    BLUE    = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN    = "\033[36m"
    WHITE   = "\033[37m"

    BRIGHT_BLACK   = "\033[90m"
    BRIGHT_RED     = "\033[91m"
    BRIGHT_GREEN   = "\033[92m"
    BRIGHT_YELLOW  = "\033[93m"
    BRIGHT_BLUE    = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN    = "\033[96m"
    BRIGHT_WHITE   = "\033[97m"

    BOLD       = "\033[1m"
    ITALIC     = "\033[3m"
    UNDERLINE  = "\033[4m"
    BLINK      = "\033[5m"
    THROUGH     = "\033[9m"  

    def __init__(self, text):
        self.text = text
        self.codes = []

    # === normal colors ===
    def blue(self):
        self.codes.append(self.BLUE)
        return self

    def red(self):
        self.codes.append(self.RED)
        return self

    def green(self):
        self.codes.append(self.GREEN)
        return self

    def yellow(self):
        self.codes.append(self.YELLOW)
        return self

    def black(self):
        self.codes.append(self.BLACK)
        return self

    def magenta(self):
        self.codes.append(self.MAGENTA)
        return self

    def cyan(self):
        self.codes.append(self.CYAN)
        return self

    def white(self):
        self.codes.append(self.WHITE)
        return self

    # === bright colors ===
    def bright_red(self):
        self.codes.append(self.BRIGHT_RED)
        return self

    def bright_black(self):
        self.codes.append(self.BRIGHT_BLACK)
        return self

    def bright_green(self):
        self.codes.append(self.BRIGHT_GREEN)
        return self

    def bright_yellow(self):
        self.codes.append(self.BRIGHT_YELLOW)
        return self

    def bright_blue(self):
        self.codes.append(self.BRIGHT_BLUE)
        return self

    def bright_magenta(self):
        self.codes.append(self.BRIGHT_MAGENTA)
        return self

    def bright_cyan(self):
        self.codes.append(self.BRIGHT_CYAN)
        return self

    def bright_white(self):
        self.codes.append(self.BRIGHT_WHITE)
        return self

    # === styles ===
    def bold(self):
        self.codes.append(self.BOLD)
        return self

    def italic(self):
        self.codes.append(self.ITALIC)
        return self

    def underline(self):
        self.codes.append(self.UNDERLINE)
        return self

    def blink(self):
        self.codes.append(self.BLINK)
        return self

    def through(self):
        self.codes.append(self.THROUGH)
        return self

    def __str__(self):
        codes = "".join(self.codes)
        return f"{codes}{self.text}{self.RESET}"


def paint(text):
    return Painter(text)
