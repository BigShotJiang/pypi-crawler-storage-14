class Class:
    """A class.
    
    ## ::: tests.fixtures.nesting.Class.method
        options:
            show_root_heading: true
    """

    def method(self) -> None:
        """A method."""
