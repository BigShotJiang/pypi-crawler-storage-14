def func(foo="<h1>HELLO</h1>"):
    """test"""
