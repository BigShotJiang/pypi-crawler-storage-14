=============
Physics guide
=============

The physics models implemented in Xsuite are documented in the guide available
at the following link:

https://xsuite.github.io/xsuite/docs/physics_manual/physics_man.pdf

.. raw:: html

   <iframe src="https://xsuite.github.io/xsuite/docs/physics_manual/physics_man.pdf" width="100%" height="800px"></iframe>