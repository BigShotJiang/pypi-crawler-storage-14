pdflatex physics_man.tex
bibtex physics_man
pdflatex physics_man.tex
pdflatex physics_man.tex