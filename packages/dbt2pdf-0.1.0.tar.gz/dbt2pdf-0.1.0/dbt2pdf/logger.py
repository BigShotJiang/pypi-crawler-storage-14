"""Pre-instanced logger to facilitate dealing with logging in Python."""

import logging

logger = logging.getLogger("dbt2pdf")
