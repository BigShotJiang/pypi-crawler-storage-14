"""Management package for the Telegram app."""
