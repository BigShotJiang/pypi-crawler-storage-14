# Portabilidade e Compatibilidade Multiplataforma

Este documento descreve as melhorias implementadas para garantir que o DaedalusPy funcione corretamente em diferentes ambientes e máquinas.

## ✅ Problemas Corrigidos

### 1. Hardcodes de Python Removidos

**Problema:** Scripts continham caminhos hardcoded específicos do desenvolvedor:
```bash
# ❌ Antes (hardcoded)
/AppData/Local/Programs/Python/Python313/python.exe

# ✅ Depois (portável)
python
```

**Solução:** 
- Todos os scripts agora usam `python` do PATH do sistema
- Detecção automática do Python correto com DaedalusPy instalado
- Fallback para `python3` e `py` quando necessário

### 2. Detecção Automática de Python (test.ps1)

O script PowerShell agora inclui uma função `Find-PythonWithDaedalusPy` que:

1. Testa comandos: `python`, `python3`, `py`
2. Verifica se cada um tem DaedalusPy instalado
3. Seleciona automaticamente o Python correto
4. Exibe mensagem de erro clara se não encontrar

```powershell
✓ Usando Python: python (Python 3.11.0)
```

### 3. Scripts Multiplataforma

**Windows (test.ps1):**
- Detecção automática de Python
- Comandos usando `& $PYTHON_CMD`
- Compatível com PowerShell 5.1+

**Unix/Linux/macOS (Makefile):**
- Usa `python` do PATH
- Comandos POSIX standard
- Compatível com bash, zsh, etc.

### 4. GitHub Actions

**Configuração multiplataforma:**
- Ubuntu, Windows, macOS
- Python 3.8, 3.9, 3.10, 3.11, 3.12
- Testes de compatibilidade automática
- Uso correto de `python` do ambiente virtual

## 🚀 Como Usar em Diferentes Ambientes

### Windows
```powershell
# Executa testes
.\test.ps1 test

# Com cobertura
.\test.ps1 test-cov
```

### Linux/macOS
```bash
# Executa testes
make test

# Com cobertura  
make test-cov
```

### Qualquer Sistema
```bash
# Direto com pytest
python -m pytest tests/ -v

# Com DaedalusPy CLI
python -m daedaluspy.cli --help
```

## 🛠️ Requisitos de Ambiente

### Mínimos:
- Python 3.8+
- pip package manager
- Git (para clonagem)

### Para Desenvolvimento:
```bash
# Instalar em modo desenvolvimento
pip install -e .

# Instalar dependências de teste
pip install -r requirements-test.txt
```

## 📁 Estrutura de Testes Portável

### Arquivos Principais:
- `tests/conftest.py` - Usa `sys.executable` (portável)
- `test.ps1` - Auto-detecção de Python
- `Makefile` - Comandos POSIX padrão
- `.github/workflows/test.yml` - CI multiplataforma

### Fixtures Portáveis:
- `temp_workspace` - Usa `tempfile.mkdtemp()` 
- `cli_runner` - Usa `sys.executable` para chamadas CLI
- Paths usando `pathlib.Path` (cross-platform)

## ✅ Validação de Portabilidade

### Testes Automatizados:
1. **CI/CD GitHub Actions:** 3 sistemas operacionais × 5 versões Python = 15 combinações
2. **Testes de Path:** Unix-style paths em Windows via normalização
3. **Workspace temporário:** Sempre limpo, funciona em qualquer FS
4. **Encoding:** UTF-8 explícito para compatibilidade

### Comandos de Validação:
```bash
# Testa detecção de Python
python -c "import daedaluspy; print('✓ DaedalusPy detectado')"

# Testa CLI básico
python -m daedaluspy.cli --help

# Testa criação básica
python -m daedaluspy.cli create-lib test_portability
```

## 🔧 Solução de Problemas

### "Python não encontrado"
```bash
# Verificar instalação
which python || where python

# Instalar se necessário (Ubuntu/Debian)
sudo apt update && sudo apt install python3

# Windows: baixar do python.org
```

### "DaedalusPy não encontrado"
```bash
# Instalar em modo desenvolvimento
pip install -e .

# Ou instalar do PyPI
pip install daedaluspy
```

### "Pytest não encontrado"
```bash
# Instalar dependências de teste
pip install -r requirements-test.txt
```

## 📊 Benefícios Implementados

✅ **Zero hardcodes** de ambiente específico  
✅ **Detecção automática** de Python correto  
✅ **Scripts multiplataforma** (Windows + Unix)  
✅ **CI/CD robusto** testando 15 combinações  
✅ **Mensagens de erro claras** para troubleshooting  
✅ **Compatibilidade regressiva** mantida  
✅ **Documentação completa** de portabilidade  

---

## 🎯 Resultado Final

O DaedalusPy agora funciona **out-of-the-box** em:
- ✅ Windows 10/11 (PowerShell/CMD)
- ✅ macOS (zsh/bash)  
- ✅ Ubuntu/Debian/CentOS (bash)
- ✅ Python 3.8 até 3.12
- ✅ Ambientes virtuais (venv, conda, pipenv)
- ✅ Docker containers
- ✅ GitHub Actions CI/CD

**Zero configuração manual necessária!** 🎉