# Entidades e Serviços no DaedalusPy

## O que são Entidades?
Entidades representam objetos de negócio (ex: Cliente, Produto, Pedido) e são criadas como classes Python, já com estrutura OOP, enums e validações. Elas centralizam regras, schemas e transformações para reuso em múltiplos pipelines.

### Como criar uma entidade
```bash
daedaluspy create-data ClienteEntity --tier raw --cloud azure
```
- O comando acima gera um arquivo base para a entidade, pronto para receber métodos, validações e lógica de negócio.
- O engenheiro de dados deve implementar os métodos de transformação, validação e integração conforme a necessidade do projeto.

## O que são Serviços?
Serviços representam integrações externas (APIs, bancos, sistemas legados) e são criados como classes Python, seguindo padrões de OOP e enums.

### Como criar um serviço
```bash
daedaluspy create-service Salesforce --type api
```
- O comando gera a estrutura do serviço, facilitando a implementação de métodos de conexão, autenticação e consumo de dados.
- O desenvolvedor deve implementar os métodos de integração e tratamento de dados conforme o contexto.

## Boas Práticas
- Sempre use o CLI para gerar entidades e serviços, garantindo padronização.
- Implemente toda a lógica de negócio, transformação e integração nos arquivos gerados.
- Documente métodos e regras de negócio diretamente nas classes.
- Reaproveite entidades e serviços em múltiplos pipelines para evitar duplicidade.

## 1. Entidades de Dados

Entidades representam tabelas, arquivos ou objetos de dados em diferentes tiers (raw, clear, model) e clouds (Azure, AWS, Google). Elas são a base para padronização e reuso em pipelines.

### Estrutura Recomendada
- **Classe Base:** Herde de `BaseEntity` para garantir métodos e atributos padrão.
- **Colunas:** Defina colunas, tipos, camada (tier) e provider cloud.
- **Métodos:** Implemente métodos de leitura, escrita e validação de dados.

**Exemplo de cenário:**
Uma entidade `ClienteEntity` pode ser usada em múltiplos pipelines, garantindo que todos usem a mesma definição de dados.

### Dicas de Modelagem
- Separe entidades por tier e cloud para facilitar manutenção e portabilidade.
- Documente cada atributo e método com docstrings.
- Utilize validações para garantir integridade dos dados.

Consulte também: [Boas Práticas](best_practices.md) | [Pipelines](pipeline_system.md)

## 2. Services de Integração

Services encapsulam integrações com APIs, bancos de dados ou outros sistemas externos, promovendo desacoplamento e reuso.

### Tipos de Service
- **API:** Integração REST, autenticação, transformação de dados.
- **Database:** Conexão, queries, autenticação, pooling.
- **Outros:** Arquivos, mensageria, etc.

**Exemplo de cenário:**
Um `SalesforceService` pode ser utilizado por diferentes pipelines para buscar dados de clientes, centralizando autenticação e lógica de acesso.

### Dicas de Implementação
- Separe lógica de autenticação e conexão em classes auxiliares.
- Utilize variáveis de ambiente para segredos e endpoints.
- Implemente tratamento de erros e logging.

## 3. Boas Práticas
- Separe entidades e services por tier e cloud.
- Documente cada entidade, atributo e service.
- Use autenticação segura e variáveis de ambiente.
- Implemente testes unitários para entidades e services (veja [Testes](tests.md)).

## 4. Links Úteis
- [Documentação da CLI](cli.md)
- [Boas Práticas](best_practices.md)
- [Sistema de Pipelines](pipeline_system.md)
