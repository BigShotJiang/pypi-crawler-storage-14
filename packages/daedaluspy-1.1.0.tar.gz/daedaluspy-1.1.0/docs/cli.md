# Documentação da CLI DaedalusPy

A CLI do DaedalusPy é a principal interface para criação, manutenção e expansão de bibliotecas de dados, pipelines, entidades e integrações. Ela foi desenhada para ser simples, padronizada e flexível, atendendo desde times técnicos até analistas de dados.

## 1. Visão Geral
A CLI permite:
- Criar bibliotecas de dados centralizadas
- Gerar pipelines modulares e multi-cloud
- Adicionar entidades e serviços de integração
- Automatizar setup e manutenção de projetos
- **Construir e distribuir pacotes wheel das bibliotecas**
- **Instalar bibliotecas em modo desenvolvimento ou produção**

> **Importante:** O CLI gera toda a estrutura base, arquivos e padrões, mas o engenheiro de dados deve implementar a lógica de negócio, transformações e integrações nos arquivos gerados.

Consulte também: [Boas Práticas](best_practices.md) | [Pipelines](pipeline_system.md)

## 2. Comandos Principais

| Comando | Descrição |
|---------|-----------|
| `daedaluspy create-lib <nome>` | Cria uma nova biblioteca base |
| `daedaluspy create-data <ClasseEntidade> --tier <raw|clear|model> --cloud <azure|aws|google>` | Cria uma nova entidade de dados |
| `daedaluspy create-service <NomeServico> --type <api|database>` | Cria um novo serviço de integração |
| `daedaluspy create-pipeline <domínio> <entidade> --tier <raw|clear|model> --output <pasta>` | Cria um novo pipeline modular |
| `daedaluspy build-wheel <caminho_biblioteca> [--install]` | **Constrói wheel da biblioteca** |
| `daedaluspy install-library <caminho_biblioteca> [--editable] [--force] [--test-import]` | **Instala biblioteca local** |

### Parâmetros e Opções Globais
- `--help, -h`: Mostra ajuda detalhada para qualquer comando
- `--output, -o`: Define o diretório de saída dos arquivos gerados
- `--cloud`: Define o provider cloud (`azure`, `aws`, `google`)
- `--tier`: Define a camada de dados (`raw`, `clear`, `model`)
- `--type`: Tipo de serviço (`api`, `database`)

### Parâmetros Específicos de Wheel e Instalação
- `--install`: Instala automaticamente o wheel após construção
- `--editable, -e`: Instalação editável (modo desenvolvimento)
- `--force`: Força reinstalação da biblioteca
- `--test-import`: Testa importação após instalação

## 3. Exemplos de Uso e Cenários

**Criar uma biblioteca de dados:**
```bash
daedaluspy create-lib MinhaLib
```

**Criar pipeline para clientes na camada clear:**
```bash
daedaluspy create-pipeline vendas ClienteEntity --tier clear --output .
```

**Adicionar entidade de dados para Azure:**
```bash
daedaluspy create-data ClienteEntity --tier raw --cloud azure
```

**Adicionar integração com API externa:**
```bash
daedaluspy create-service Salesforce --type api
```

**Construir wheel da biblioteca:**
```bash
daedaluspy build-wheel MinhaLib --install
```

**Instalar biblioteca em modo desenvolvimento:**
```bash
daedaluspy install-library MinhaLib --editable --test-import
```

**Workflow completo de desenvolvimento:**
```bash
# 1. Criar biblioteca
daedaluspy create-lib corp_data

# 2. Adicionar entidades
daedaluspy create-data ClienteEntity --tier raw --cloud azure

# 3. Construir e instalar para desenvolvimento
daedaluspy build-wheel corp_data
daedaluspy install-library corp_data --editable

# 4. Criar pipeline usando a biblioteca instalada
daedaluspy create-pipeline vendas ClienteEntity --tier clear --output .
```

## 4. Dicas e Boas Práticas
- Use o CLI para gerar a estrutura base e arquivos padronizados.
- Implemente a lógica de negócio, transformações e integrações nos arquivos gerados.
- Siga os padrões de OOP, enums e templates definidos pelo framework.
- Evite alterar manualmente a estrutura dos arquivos base gerados pelo CLI (exceto para lógica de negócio).
- Consulte a documentação de [Entidades e Services](entities_and_services.md) para detalhes de implementação.

## 5. Troubleshooting e Suporte
- Se um comando não funcionar, utilize a opção `--help` para ver exemplos e sintaxe correta.
- Verifique permissões de escrita no diretório de saída.
- Para dúvidas, consulte o README principal ou entre em contato com a equipe responsável.

## 6. Contribuição
- Sugestões e melhorias são bem-vindas via Pull Request.
- Mantenha a documentação dos comandos sempre atualizada.
