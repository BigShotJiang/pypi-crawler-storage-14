# Documentação de Build e Distribuição de Wheels

Esta documentação cobre as funcionalidades de construção e instalação de pacotes wheel no DaedalusPy, permitindo distribuição eficiente de bibliotecas de dados criadas.

## Visão Geral

O DaedalusPy oferece comandos integrados para:
- **Construir wheels** das bibliotecas criadas
- **Instalar bibliotecas** em modo desenvolvimento ou produção
- **Gerenciar dependências** automaticamente
- **Testar instalações** com verificação de imports

## Comandos Disponíveis

### 1. `build-wheel` - Construção de Wheels

Constrói um pacote wheel distribuível da biblioteca.

```bash
daedaluspy build-wheel <caminho_biblioteca> [--install]
```

**Parâmetros:**
- `<caminho_biblioteca>`: Caminho para o diretório da biblioteca (obrigatório)
- `--install`: Instala automaticamente o wheel após construção (opcional)

**Exemplos:**
```bash
# Construir wheel simples
daedaluspy build-wheel minha_lib

# Construir e instalar automaticamente
daedaluspy build-wheel minha_lib --install

# Construir biblioteca em outro diretório
daedaluspy build-wheel /path/to/corp_data --install
```

**Requisitos:**
- Biblioteca deve conter `setup.py` ou `pyproject.toml`
- Dependências de build são instaladas automaticamente

### 2. `install-library` - Instalação de Bibliotecas

Instala uma biblioteca local no ambiente Python.

```bash
daedaluspy install-library <caminho_biblioteca> [--editable] [--force] [--test-import]
```

**Parâmetros:**
- `<caminho_biblioteca>`: Caminho para o diretório da biblioteca (obrigatório)
- `--editable, -e`: Instalação editável para desenvolvimento (opcional)
- `--force`: Força reinstalação mesmo se já instalada (opcional)
- `--test-import`: Testa importação após instalação (opcional)

**Exemplos:**
```bash
# Instalação normal
daedaluspy install-library minha_lib

# Instalação editável (desenvolvimento)
daedaluspy install-library minha_lib --editable

# Instalação com teste e força
daedaluspy install-library minha_lib --editable --force --test-import

# Usando forma abreviada
daedaluspy install-library minha_lib -e
```

## Workflows de Uso

### Workflow para Desenvolvedores de Bibliotecas

```bash
# 1. Criar nova biblioteca
daedaluspy create-lib data_analytics_lib

# 2. Desenvolver entidades e serviços
daedaluspy create-data ProductEntity --tier raw --cloud azure
daedaluspy create-service DatabaseConnector --type database

# 3. Implementar lógica de negócio nos arquivos gerados
# ... desenvolvimento ...

# 4. Construir wheel para testes
daedaluspy build-wheel data_analytics_lib

# 5. Instalar em modo desenvolvimento
daedaluspy install-library data_analytics_lib --editable --test-import

# 6. Testar a biblioteca em pipelines
daedaluspy create-pipeline analytics ProductEntity --tier clear --output ./test_pipeline
```

### Workflow para Consumidores de Bibliotecas

```bash
# 1. Instalar biblioteca existente
daedaluspy install-library /shared/corp_data_lib --editable

# 2. Criar pipelines usando a biblioteca
daedaluspy create-pipeline sales CustomerEntity --tier model --output ./sales_pipeline

# 3. Desenvolver usando as entidades instaladas
# ... desenvolvimento de pipeline ...
```

### Workflow de Distribuição

```bash
# 1. Biblioteca finalizada
daedaluspy build-wheel prod_data_lib

# 2. Wheel gerado em prod_data_lib/dist/
# 3. Distribuir arquivo .whl para outros ambientes
# 4. Instalar em ambiente de produção:
pip install prod_data_lib/dist/prod_data_lib-1.0.0-py3-none-any.whl
```

## Estrutura Gerada

### Após `build-wheel`:
```
minha_lib/
├── dist/
│   └── minha_lib-0.1.0-py3-none-any.whl  # 📦 Wheel gerado
├── build/                                 # Arquivos temporários
├── minha_lib.egg-info/                   # Metadados
├── setup.py                              # Configuração de build
└── ... (resto da biblioteca)
```

### Setup.py Gerado Automaticamente:
```python
from setuptools import setup, find_packages

setup(
    name="minha_lib",
    version="0.1.0",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.0.0",
        # ... outras dependências
    ],
    # ... configurações completas
)
```

## Vantagens dos Wheels

### ✅ **Distribuição Eficiente**
- Pacotes pré-compilados e otimizados
- Instalação mais rápida que código fonte
- Compatibilidade com PyPI e repositórios privados

### ✅ **Versionamento e Dependências**
- Controle de versão automático
- Gerenciamento de dependências integrado
- Compatibilidade com pip e ferramentas padrão

### ✅ **Desenvolvimento Ágil**
- Modo editável para desenvolvimento iterativo
- Teste automático de importações
- Integração com IDEs e notebooks

### ✅ **Ambientes Isolados**
- Instalação em virtual environments
- Evita conflitos de dependências
- Facilita deploy em diferentes ambientes

## Troubleshooting

### Problemas Comuns

**Erro: "setup.py não encontrado"**
```bash
# Solução: Verificar se a biblioteca foi criada com DaedalusPy
daedaluspy create-lib minha_lib  # Recria com setup.py correto
```

**Erro: "Módulo build não encontrado"**
```bash
# Solução automática: DaedalusPy instala automaticamente
# Ou instalar manualmente:
pip install build
```

**Erro: "Importação falha após instalação"**
```bash
# Verificar instalação
pip list | grep minha_lib

# Reinstalar forçadamente
daedaluspy install-library minha_lib --force --editable
```

### Dicas de Performance

1. **Use `--editable` durante desenvolvimento** - Evita reinstalações constantes
2. **Construa wheels para distribuição** - Mais rápido que instalar do código fonte  
3. **Use `--test-import`** - Detecta problemas de importação cedo
4. **Versione suas bibliotecas** - Facilita o gerenciamento de dependências

## Integração com Ferramentas

### Jupyter Notebooks
```python
# Após instalação, use diretamente
from minha_lib.data.raw import ClienteEntity
from minha_lib.service import DatabaseConnector

# Desenvolvimento iterativo com --editable
```

### Azure Synapse / Databricks
```python
# Instale wheels no cluster
%pip install /path/to/wheel/minha_lib-1.0.0-py3-none-any.whl

# Use em notebooks Spark
from minha_lib import ProductEntity
```

### CI/CD Pipelines
```yaml
# Exemplo GitHub Actions
- name: Build and test library
  run: |
    daedaluspy build-wheel corp_data_lib
    daedaluspy install-library corp_data_lib --test-import
```

## Scripts de Demonstração

### Windows (PowerShell)
```powershell
# Executar demonstração completa
.\test.ps1 demo-wheel
```

### Unix/Linux (Makefile)
```bash
# Executar demonstração completa
make demo-wheel
```

## Próximos Passos

1. **Explore os exemplos** - Use os scripts de demonstração
2. **Crie sua primeira biblioteca** - Siga o workflow de desenvolvimento
3. **Integre com seus pipelines** - Use bibliotecas instaladas em projetos
4. **Configure CI/CD** - Automatize build e testes de wheels
5. **Consulte documentação adicional** - [CLI](cli.md) | [Boas Práticas](best_practices.md)