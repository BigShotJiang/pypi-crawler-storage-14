# Sistema de Pipelines AtlasPy

## 1. O que é um Pipeline AtlasPy?
Um pipeline AtlasPy é um projeto modular de processamento de dados, construído para garantir padronização, rastreabilidade e facilidade de manutenção. Ele consome entidades e integrações da biblioteca de dados, permitindo orquestrar fluxos complexos de ETL/ELT em múltiplos ambientes (clouds, bancos, APIs).

## 2. Estrutura e Organização
Ao criar um pipeline, a estrutura típica gerada é:

```
data_pipeline/
  config.py         # Configurações globais, variáveis de ambiente, serviços
  base.py           # Classes base para steps, entidades e configuração
  steps.py          # Steps de processamento (cada função/etapa do fluxo)
  flowbuilder.py    # Orquestração do pipeline, dependências e ordem de execução
  main.py           # Ponto de entrada do pipeline
  tests/            # Testes unitários e de integração
  README.md         # Documentação do pipeline
```

**Dicas:**
- Separe steps por função de negócio (ex: ingestão, transformação, carga).
- Utilize variáveis de ambiente para credenciais e parâmetros sensíveis.
- Documente cada etapa e mantenha exemplos de uso no README do pipeline.

## 3. Fluxo de Execução
1. O pipeline é iniciado pelo `main.py`, que carrega configurações e dependências.
2. O `flowbuilder.py` define a ordem e as dependências entre os steps.
3. Cada step em `steps.py` executa uma função específica (ex: leitura, transformação, gravação).
4. O logger integrado registra eventos, erros e métricas.
5. Resultados e logs são salvos conforme configuração (cloud, banco, arquivo).

## 4. Comandos e Geração
Para criar um pipeline:
- Use a CLI: `atlaspy create project <system> <data> <tier>`
- Consulte todos os comandos e parâmetros em [Documentação da CLI](cli.md)

**Exemplo de fluxo de criação:**
1. Crie a biblioteca de dados (se ainda não existir).
2. Gere o pipeline com o comando acima.
3. Implemente os steps e configure o flowbuilder.
4. Adapte o `config.py` para o ambiente desejado.
5. Execute e monitore o pipeline.

## 5. Nomenclatura e Organização
- Siga o padrão `[system_name]_[dataname]_[tier]` para nomear projetos e arquivos.
- Separe pipelines por domínio de negócio e camada de dados (raw, clear, model).

## 6. Multi-Cloud e Integrações
O AtlasPy suporta múltiplos provedores:
- Azure: Blob Storage, Data Lake, SQL, etc.
- AWS: S3, Glue, Redshift, etc.
- Google Cloud: GCS, BigQuery, etc.
- APIs e bancos relacionais.

Consulte [Entidades e Services](entities_and_services.md) para detalhes sobre integrações.

## 7. Testes e Validação
- Estruture testes unitários e de integração na pasta `tests/`.
- Use `pytest` para rodar os testes.
- Implemente mocks para dependências externas.
- Consulte [Boas Práticas](best_practices.md) e [Testes](tests.md) para exemplos e recomendações.

## 8. Boas Práticas
- Documente cada step, entidade e configuração.
- Use variáveis de ambiente para segredos.
- Separe lógica de negócio em steps reutilizáveis.
- Utilize o logger para rastreabilidade e auditoria.
- Mantenha README e exemplos atualizados.

## 9. Referências e Links Úteis
- [README AtlasPy](../README.md)
- [Documentação da CLI](cli.md)
- [Entidades e Services](entities_and_services.md)
- [Boas Práticas](best_practices.md)
- [Testes](tests.md)

# Sistema de Pipelines no DaedalusPy

## O que é um Pipeline?
Um pipeline é um fluxo modular de ingestão, transformação e entrega de dados, organizado por domínio, entidade e camada (tier). O DaedalusPy gera toda a estrutura base, mas o engenheiro de dados deve implementar a lógica de negócio nos steps.

### Como criar um pipeline
```bash
daedaluspy create-pipeline vendas ClienteEntity --tier clear --output .
```
- O comando gera uma pasta com arquivos essenciais (`main.py`, `steps.py`, `config.py`, etc), prontos para implementação.
- O desenvolvedor deve codificar os steps, transformações e integrações conforme o fluxo de dados desejado.

## Estrutura Gerada
```
vendas_ClienteEntity_clear/
  __init__.py
  base.py
  config.py
  flowbuilder.py
  main.py
  README.md
  requirements.txt
  steps.py
```

## Boas Práticas
- Use o CLI para garantir padronização estrutural.
- Implemente toda a lógica de negócio nos arquivos steps.py, main.py e demais arquivos gerados.
- Reaproveite entidades e serviços da biblioteca para evitar retrabalho.
- Documente o fluxo e as regras de negócio diretamente nos arquivos do pipeline.
