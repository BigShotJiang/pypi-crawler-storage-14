# Boas Práticas AtlasPy

Este guia reúne recomendações essenciais para garantir qualidade, segurança, escalabilidade e governança em projetos desenvolvidos com AtlasPy. Siga estas orientações para obter resultados profissionais e sustentáveis.

## 1. Organização de Projetos
- **Nomenclatura:** Use o padrão `[system_name]_[dataname]_[tier]` para pipelines (ex: `vendas_clientes_clear`). Isso facilita a identificação, manutenção e integração entre projetos.
- **Separação de responsabilidades:** Separe entidades e services por tier (raw, clear, model) e por provider cloud (Azure, AWS, Google). Isso garante modularidade e portabilidade.
- **Documentação interna:** Documente cada módulo, classe e função. Utilize docstrings e comentários claros, facilitando o onboarding de novos membros.

## 2. Versionamento e Governança
- **Controle de versão:** Utilize sistemas como Git para versionar bibliotecas e pipelines. Crie tags para releases estáveis e mantenha um changelog atualizado.
- **Revisão de código:** Implemente code review para garantir qualidade e padronização.

## 3. Segurança
- **Variáveis de ambiente:** Armazene credenciais, secrets e parâmetros sensíveis apenas em variáveis de ambiente. Nunca exponha informações confidenciais em código ou repositórios.
- **Acesso mínimo:** Conceda permissões mínimas necessárias para execução dos pipelines e integrações.

## 4. Testes e Qualidade
- **Cobertura de testes:** Implemente testes unitários e de integração para steps, entidades e services. Mantenha cobertura mínima definida pela equipe.
- **Ferramentas:** Utilize `pytest` para execução dos testes. Consulte [Testes](tests.md) para exemplos e estrutura recomendada.
- **Mocks:** Use mocks para dependências externas (APIs, bancos) e cenários de erro.

## 5. Multi-Cloud e Portabilidade
- **Abstração:** Implemente abstrações para facilitar a portabilidade entre provedores (Azure, AWS, Google). Separe lógica específica de cada cloud.
- **Configuração dinâmica:** Utilize arquivos de configuração e variáveis de ambiente para alternar entre ambientes e clouds.

## 6. Logging, Observabilidade e Auditoria
- **Logger integrado:** Utilize o logger padrão do AtlasPy para registrar eventos, execuções, warnings e erros.
- **Monitoramento:** Implemente métricas e alertas para identificar falhas e gargalos.
- **Auditoria:** Mantenha logs de execução e alterações relevantes para rastreabilidade.

## 7. Build e Distribuição de Wheels
- **Versionamento semântico:** Use versionamento semântico (1.0.0) nos setup.py das bibliotecas.
- **Modo desenvolvimento:** Use `--editable` durante desenvolvimento para evitar reinstalações constantes.
- **Testes de importação:** Sempre use `--test-import` ao instalar bibliotecas para detectar problemas cedo.
- **Ambientes isolados:** Construa e teste wheels em virtual environments isolados.
- **Dependências:** Mantenha requirements.txt atualizado - DaedalusPy usa automaticamente nas bibliotecas.
- **Distribuição:** Para produção, distribua wheels (.whl) ao invés de código fonte para instalação mais rápida.

## 8. Performance e Escalabilidade
- **Processamento em lote:** Para grandes volumes de dados, utilize processamento em lote e paralelismo quando possível.
- **Otimização:** Revise steps críticos para evitar gargalos e redundâncias.
- **Testes de carga:** Realize testes de performance em pipelines críticos.

## 9. Documentação e Compartilhamento
- **README e docs:** Mantenha o README e a documentação técnica sempre atualizados, explicando regras de negócio, decisões técnicas e exemplos de uso.
- **Links cruzados:** Referencie outros documentos relevantes, como [CLI](cli.md), [Entidades e Services](entities_and_services.md) e [Pipelines](pipeline_system.md).

## 10. Dicas para Equipes
- **Onboarding:** Crie guias de onboarding para novos membros, detalhando padrões, fluxos e boas práticas.
- **Comunicação:** Mantenha canais de comunicação abertos para dúvidas e sugestões de melhoria.

# Boas Práticas com DaedalusPy

## Estrutura e Padronização
- Sempre utilize o CLI para gerar bibliotecas, entidades, serviços e pipelines.
- Siga os padrões de OOP, enums e templates definidos pelo framework.
- Implemente a lógica de negócio, transformações e integrações nos arquivos gerados.
- Evite alterar manualmente a estrutura dos arquivos base (exceto para lógica de negócio).

## Versionamento e Governança
- Mantenha a biblioteca centralizada e versionada.
- Documente todas as alterações relevantes no código e nos arquivos de configuração.
- Utilize controle de versão (git) para rastrear mudanças e facilitar colaboração.

## Colaboração
- Compartilhe entidades e serviços entre times para evitar duplicidade.
- Documente métodos, regras e integrações diretamente nas classes e pipelines.
- Revise e atualize a documentação sempre que novos padrões ou comandos forem implementados.

## Extensibilidade
- Adapte templates conforme a necessidade do projeto ou padrão da empresa.
- Sugira melhorias e contribua para evolução do framework via Pull Request.

## Workflow com Wheels
- **Para desenvolvedores de bibliotecas:** Crie → Desenvolva → Build wheel → Instale editável → Teste
- **Para consumidores:** Instale biblioteca → Crie pipelines → Desenvolva lógica de negócio
- **Para produção:** Build wheel → Distribua → Instale em ambiente → Execute pipelines

---

Para mais detalhes, consulte também:
- [Documentação da CLI](cli.md)
- [Build e Distribuição de Wheels](wheel_distribution.md) ⭐ **NOVO**
- [Entidades e Services](entities_and_services.md)
- [Sistema de Pipelines](pipeline_system.md)
- [Testes](tests.md)
