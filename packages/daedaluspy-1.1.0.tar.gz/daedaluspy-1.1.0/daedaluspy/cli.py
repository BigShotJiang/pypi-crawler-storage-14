from daedaluspy.data_pipeline.template.complete_templates import get_template_set
from daedaluspy.data_pipeline.generator.pipeline_generator_oop import PipelineGenerator, PipelineTier, CloudProvider as PipelineCloudProvider
import argparse
import sys
from enum import Enum
from daedaluspy.data_lib.generator.library_generator import LibraryGenerator
from daedaluspy.data_lib.generator.data_entity_oop import DataEntityGenerator, CloudProvider
from daedaluspy.data_lib.generator.service_generator_oop import ServiceGenerator

class Tier(Enum):
    RAW = "raw"
    CLEAR = "clear"
    MODEL = "model"

class ServiceType(Enum):
    API = "api"
    DATABASE = "database"

class Command:
    def execute(self, args):
        raise NotImplementedError

class CreateLibCommand(Command):
    def execute(self, args):
        generator = LibraryGenerator(
            name=args.name,
            data_name=args.dataname,
            system_name=args.systemname
        )
        generator.generate()
        print(f"Estrutura da biblioteca '{args.name}' criada com sucesso!")

class CreateDataCommand(Command):
    def execute(self, args):
        if not args.tier:
            print("Erro: --tier é obrigatório (raw, clear, model)")
            sys.exit(1)
        tier = Tier(args.tier)
        extra_kwargs = {}
        if hasattr(args, 'output') and args.output:
            extra_kwargs['output_path'] = args.output
        if hasattr(args, 'lib') and args.lib:
            extra_kwargs['lib'] = args.lib
        generator = DataEntityGenerator(
            classname=args.name,
            tier=tier,
            cloud_provider=CloudProvider(args.cloud),
            columns=args.columns or [],
            **extra_kwargs
        )
        generator.generate()
        print(f"Entidade '{args.name}' criada com sucesso na camada {tier.value}.")

class CreateServiceCommand(Command):
    def execute(self, args):
        service_type = ServiceType(args.type)
        # Permite argumentos opcionais futuros
        extra_kwargs = {}
        if hasattr(args, 'output') and args.output:
            extra_kwargs['output_path'] = args.output
        if hasattr(args, 'lib') and args.lib:
            extra_kwargs['lib'] = args.lib
        # Converter models de lista de strings JSON para lista de dicts
        import json
        models = []
        if args.models:
            for m in args.models:
                if isinstance(m, dict):
                    models.append(m)
                else:
                    try:
                        models.append(json.loads(m))
                    except Exception:
                        pass
        generator = ServiceGenerator(
            service_name=args.name,
            service_type=service_type,
            models=models,
            **extra_kwargs
        )
        generator.generate()
        print(f"Serviço '{args.name}' ({service_type.value}) criado com sucesso.")

class CreatePipelineCommand(Command):
    def execute(self, args):
        tier = PipelineTier(args.tier)
        # Permitir todos os parâmetros opcionais igual ao create-pipeline-project
        def enum_from_value(enum_cls, value):
            # Normalizar o valor para corresponder aos valores do enum
            normalized = value.lower().replace("_", "").replace("-", "")
            for e in enum_cls:
                enum_value_normalized = e.value.lower().replace("_", "").replace("-", "")
                enum_name_normalized = e.name.lower().replace("_", "").replace("-", "")
                if (value == e.value or value == e.name or 
                    value.upper() == e.name or normalized == enum_value_normalized or
                    normalized == enum_name_normalized):
                    return e
            raise ValueError(f"{value} não é válido para {enum_cls.__name__}")

        generator = PipelineGenerator(
            system_name=args.system_name,
            dataname=args.dataname,
            tier=tier,
            output_path=args.output if args.output else ".",
            template_type=getattr(args, "template_type", "all"),
            lib_name=getattr(args, "lib_name", "atlaspy"),
            cloud_provider=enum_from_value(PipelineCloudProvider, getattr(args, "cloud_provider", "azure")),
            entity_target=getattr(args, "entity_target", None),
            entity_target_class=getattr(args, "entity_target_class", None)
        )
        generator.generate()
        print(f"Pipeline '{args.system_name}/{args.dataname}/{tier.value}' criado com sucesso.")


class BuildWheelCommand(Command):
    def execute(self, args):
        import os
        import subprocess
        import sys
        from pathlib import Path
        
        lib_path = Path(args.library_path)
        if not lib_path.exists():
            print(f"Erro: Biblioteca não encontrada em {lib_path}")
            sys.exit(1)
            
        if not (lib_path / "setup.py").exists() and not (lib_path / "pyproject.toml").exists():
            print(f"Erro: Biblioteca em {lib_path} não possui setup.py ou pyproject.toml")
            sys.exit(1)
            
        print(f"Construindo wheel para biblioteca em: {lib_path}")
        
        # Muda para o diretório da biblioteca
        original_dir = os.getcwd()
        try:
            os.chdir(lib_path)
            
            # Instala build se não estiver disponível
            try:
                subprocess.run([sys.executable, "-c", "import build"], check=True, capture_output=True)
            except subprocess.CalledProcessError:
                print("Instalando python build...")
                subprocess.run([sys.executable, "-m", "pip", "install", "build"], check=True)
            
            # Constrói o wheel
            print("Construindo wheel...")
            result = subprocess.run([sys.executable, "-m", "build", "--wheel"], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✓ Wheel construído com sucesso!")
                
                # Lista arquivos wheel criados
                dist_dir = lib_path / "dist"
                if dist_dir.exists():
                    wheel_files = list(dist_dir.glob("*.whl"))
                    if wheel_files:
                        print(f"Wheel criado: {wheel_files[-1]}")
                        
                        # Instalação automática se solicitada
                        if args.install:
                            self._install_wheel(wheel_files[-1])
            else:
                print(f"Erro ao construir wheel: {result.stderr}")
                
        finally:
            os.chdir(original_dir)
    
    def _install_wheel(self, wheel_path):
        import subprocess
        import sys
        
        print(f"Instalando wheel: {wheel_path}")
        try:
            result = subprocess.run([sys.executable, "-m", "pip", "install", str(wheel_path), "--force-reinstall"],
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✓ Wheel instalado com sucesso!")
            else:
                print(f"Erro na instalação: {result.stderr}")
                
        except Exception as e:
            print(f"Erro ao instalar wheel: {e}")

    def run(self, args):
        """Método para compatibilidade com testes"""
        return self.execute(args)


class InstallLibraryCommand(Command):
    def execute(self, args):
        import os
        import subprocess
        import sys
        from pathlib import Path
        
        lib_path = Path(args.library_path)
        if not lib_path.exists():
            print(f"Erro: Biblioteca não encontrada em {lib_path}")
            sys.exit(1)
            
        if not (lib_path / "setup.py").exists() and not (lib_path / "pyproject.toml").exists():
            print(f"Erro: Biblioteca em {lib_path} não possui setup.py ou pyproject.toml")
            sys.exit(1)
            
        print(f"Instalando biblioteca de: {lib_path}")
        
        # Determina tipo de instalação
        install_mode = "editable" if args.editable else "normal"
        
        try:
            if args.editable:
                # Instalação editável (desenvolvimento)
                cmd = [sys.executable, "-m", "pip", "install", "-e", str(lib_path)]
            else:
                # Instalação normal
                cmd = [sys.executable, "-m", "pip", "install", str(lib_path)]
                
            if args.force:
                cmd.append("--force-reinstall")
                
            print(f"Executando instalação {install_mode}...")
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"✓ Biblioteca instalada com sucesso ({install_mode})!")
                
                # Testa a importação se possível
                if args.test_import:
                    self._test_import(lib_path)
                    
            else:
                print(f"Erro na instalação: {result.stderr}")
                
        except Exception as e:
            print(f"Erro ao instalar biblioteca: {e}")
    
    def _test_import(self, lib_path):
        import subprocess
        import sys
        
        # Tenta descobrir o nome do pacote
        lib_name = lib_path.name.lower().replace("-", "_")
        
        try:
            result = subprocess.run([sys.executable, "-c", f"import {lib_name}; print('✓ Importação bem-sucedida!')"],
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print(result.stdout.strip())
            else:
                print(f"Aviso: Não foi possível testar importação de '{lib_name}'")
                
        except Exception:
            print("Aviso: Teste de importação não realizado")

    def run(self, args):
        """Método para compatibilidade com testes"""
        return self.execute(args)


def main():
    parser = argparse.ArgumentParser(description="DaedalusPy CLI")
    subparsers = parser.add_subparsers(dest="command")
    # create pipeline project (completo)
    parser_pipeline_project = subparsers.add_parser("create-pipeline-project")
    parser_pipeline_project.add_argument("system_name")
    parser_pipeline_project.add_argument("dataname")
    parser_pipeline_project.add_argument("tier", choices=["raw", "clear", "model"])
    parser_pipeline_project.add_argument("--output", "-o", default=".")
    parser_pipeline_project.add_argument("--template-type", "-t", choices=["essential", "dev", "all"], default="all")
    parser_pipeline_project.add_argument("--lib-name", default="atlaspy")
    parser_pipeline_project.add_argument("--cloud-provider", default="cloud_azure")
    parser_pipeline_project.add_argument("--entity-target", default="azure_sql_database")
    parser_pipeline_project.add_argument("--entity-target-class", default="AzureSQLDatabase")

    # create lib
    parser_lib = subparsers.add_parser("create-lib")
    parser_lib.add_argument("name")
    parser_lib.add_argument("--dataname")
    parser_lib.add_argument("--systemname")

    # create data
    parser_data = subparsers.add_parser("create-data")
    parser_data.add_argument("name")
    parser_data.add_argument("--tier", required=True, choices=[t.value for t in Tier])
    parser_data.add_argument("--cloud", required=True)
    parser_data.add_argument("--extension")
    parser_data.add_argument("--columns", nargs="*")
    parser_data.add_argument("--imports")
    parser_data.add_argument("--read_code")
    parser_data.add_argument("--write_code")
    parser_data.add_argument("--output")
    parser_data.add_argument("--lib")


    # create service
    parser_service = subparsers.add_parser("create-service")
    parser_service.add_argument("name")
    parser_service.add_argument("--type", required=True, choices=[t.value for t in ServiceType])
    parser_service.add_argument("--models", nargs="*")
    parser_service.add_argument("--output")

    # create pipeline
    parser_pipeline = subparsers.add_parser("create-pipeline")
    parser_pipeline.add_argument("system_name")
    parser_pipeline.add_argument("dataname")
    parser_pipeline.add_argument("--tier", required=True, choices=[t.value for t in PipelineTier])
    parser_pipeline.add_argument("--output", default=".")
    parser_pipeline.add_argument("--template_type", default="all")
    parser_pipeline.add_argument("--lib_name", default="atlaspy")
    parser_pipeline.add_argument("--cloud_provider", default="azure")
    parser_pipeline.add_argument("--entity_target", default="azure_sql_database")
    parser_pipeline.add_argument("--entity_target_class", default="AzureSQLDatabase")

    # build wheel
    parser_build_wheel = subparsers.add_parser("build-wheel", 
                                              help="Constrói wheel da biblioteca")
    parser_build_wheel.add_argument("library_path", 
                                   help="Caminho para a biblioteca (diretório com setup.py ou pyproject.toml)")
    parser_build_wheel.add_argument("--install", action="store_true", 
                                   help="Instala automaticamente o wheel após construção")

    # install library
    parser_install_lib = subparsers.add_parser("install-library", 
                                              help="Instala biblioteca local")
    parser_install_lib.add_argument("library_path", 
                                   help="Caminho para a biblioteca (diretório com setup.py ou pyproject.toml)")
    parser_install_lib.add_argument("--editable", "-e", action="store_true", 
                                   help="Instalação editável (desenvolvimento)")
    parser_install_lib.add_argument("--force", action="store_true", 
                                   help="Força reinstalação")
    parser_install_lib.add_argument("--test-import", action="store_true", 
                                   help="Testa importação após instalação")

    args = parser.parse_args()


    commands = {
        "create-lib": CreateLibCommand(),
        "create-data": CreateDataCommand(),
        "create-service": CreateServiceCommand(),
        "create-pipeline": CreatePipelineCommand(),
        "build-wheel": BuildWheelCommand(),
        "install-library": InstallLibraryCommand(),
    }

    if args.command in commands:
        commands[args.command].execute(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
