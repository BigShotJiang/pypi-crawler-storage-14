import pytest
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from nlptermux.tokenizer import Tokenizer, SentenceTokenizer

class TestTokenizer:
    def setup_method(self):
        self.tokenizer = Tokenizer()
        self.sent_tokenizer = SentenceTokenizer()
    
    def test_word_tokenize_basic(self):
        text = "Hello world! This is a test."
        tokens = self.tokenizer.tokenize(text)
        expected = ['hello', 'world', 'this', 'is', 'a', 'test']
        assert tokens == expected
    
    def test_word_tokenize_with_entities(self):
        text = "Contact me at test@example.com or visit http://example.com"
        tokens = self.tokenizer.tokenize(text, preserve_entities=True)
        assert "test@example.com" in tokens
        assert "http://example.com" in tokens
    
    def test_ngrams(self):
        text = "hello world test"
        bigrams = self.tokenizer.ngrams(text, 2)
        expected = [('hello', 'world'), ('world', 'test')]
        assert bigrams == expected
        
        trigrams = self.tokenizer.ngrams(text, 3)
        expected_trigrams = [('hello', 'world', 'test')]
        assert trigrams == expected_trigrams
    
    def test_character_ngrams(self):
        text = "hello"
        bigrams = self.tokenizer.character_ngrams(text, 2)
        expected = ['he', 'el', 'll', 'lo']
        assert bigrams == expected
    
    def test_sentence_tokenize(self):
        text = "Hello world! This is a test. How are you?"
        sentences = self.sent_tokenizer.tokenize(text)
        assert len(sentences) == 3
        assert "Hello world" in sentences[0]
        assert "This is a test" in sentences[1]
        assert "How are you" in sentences[2]
    
    def test_sentence_tokenize_with_abbreviations(self):
        text = "Hello Dr. Smith! How are you? This is a test."
        sentences = self.sent_tokenizer.tokenize(text)
        # Should handle Dr. as part of the sentence, not sentence end
        assert len(sentences) >= 2
    
    def test_get_tokenization_stats(self):
        text = "This is a test sentence."
        stats = self.tokenizer.get_tokenization_stats(text)
        
        assert "text_length" in stats
        assert "token_count" in stats
        assert "bigram_count" in stats
        assert "avg_token_length" in stats
        assert isinstance(stats["token_count"], int)
    
    def test_get_sentence_stats(self):
        text = "First sentence. Second sentence! Third sentence?"
        stats = self.sent_tokenizer.get_sentence_stats(text)
        
        assert "sentence_count" in stats
        assert "avg_sentence_length" in stats
        assert "avg_words_per_sentence" in stats
        assert stats["sentence_count"] == 3
