import pytest
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from nlptermux.sentiment import SentimentAnalyzer

class TestSentimentAnalyzer:
    def setup_method(self):
        self.analyzer = SentimentAnalyzer()
    
    def test_positive_sentiment(self):
        text = "I love this amazing product! It's great and wonderful."
        result = self.analyzer.analyze(text)
        assert result['label'] == 'positive'
        assert result['score'] > 0
        assert result['positive_words'] > 0
    
    def test_negative_sentiment(self):
        text = "I hate this terrible product. It's awful and bad."
        result = self.analyzer.analyze(text)
        assert result['label'] == 'negative'
        assert result['score'] < 0
        assert result['negative_words'] > 0
    
    def test_neutral_sentiment(self):
        text = "This is a product. It exists."
        result = self.analyzer.analyze(text)
        assert result['label'] == 'neutral'
        assert abs(result['score']) < 0.15
    
    def test_sentiment_with_negation(self):
        text_positive = "I love this product"
        text_negative = "I do not love this product"
        
        result_positive = self.analyzer.analyze(text_positive)
        result_negative = self.analyzer.analyze(text_negative)
        
        # Negation should reduce positivity or make it negative
        assert result_positive['score'] > result_negative['score']
    
    def test_sentiment_with_emojis(self):
        text_with_emoji = "I'm happy 😊"
        text_without_emoji = "I'm happy"
        
        result_with = self.analyzer.analyze(text_with_emoji, include_emojis=True)
        result_without = self.analyzer.analyze(text_without_emoji, include_emojis=True)
        
        # Emoji should boost positive sentiment
        assert result_with['score'] >= result_without['score']
        assert '😊' in result_with['emojis']
    
    def test_batch_analysis(self):
        texts = [
            "I love this!",
            "I hate this!",
            "This is okay."
        ]
        results = self.analyzer.analyze_batch(texts)
        
        assert len(results) == 3
        assert results[0]['label'] == 'positive'
        assert results[1]['label'] == 'negative'
        assert results[2]['label'] in ['neutral', 'positive']
    
    def test_lexicon_info(self):
        info = self.analyzer.get_lexicon_info()
        
        assert "total_words" in info
        assert "positive_words" in info
        assert "negative_words" in info
        assert info["total_words"] > 0
        assert info["positive_words"] > 0
        assert info["negative_words"] > 0
