import pytest
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from nlptermux.text_processor import TextProcessor

class TestTextProcessor:
    def setup_method(self):
        self.processor = TextProcessor()
    
    def test_clean_text_basic(self):
        text = "Hello, World! This is a TEST. 123"
        cleaned = self.processor.clean_text(text)
        assert "hello" in cleaned
        assert "world" in cleaned
        assert "123" not in cleaned
        assert "," not in cleaned
        assert "!" not in cleaned
    
    def test_clean_text_with_contractions(self):
        text = "I can't believe it's working!"
        cleaned = self.processor.clean_text(text, expand_contractions=True)
        assert "cannot" in cleaned or "can not" in cleaned
    
    def test_remove_stop_words(self):
        tokens = ["this", "is", "a", "test", "sentence"]
        filtered = self.processor.remove_stop_words(tokens)
        assert "test" in filtered
        assert "sentence" in filtered
        assert "this" not in filtered
        assert "is" not in filtered
        assert "a" not in filtered
    
    def test_normalize_text(self):
        text = "This is a TEST sentence! With 123 numbers."
        normalized = self.processor.normalize_text(text)
        assert "test" in normalized
        assert "sentence" in normalized
        assert "123" not in normalized
        assert "this" not in normalized  # stop word removed
    
    def test_empty_text(self):
        assert self.processor.clean_text("") == ""
        assert self.processor.remove_stop_words([]) == []
        assert self.processor.normalize_text("") == ""
    
    def test_get_processing_stats(self):
        text = "This is a test sentence with some words."
        stats = self.processor.get_processing_stats(text)
        
        assert "original_length" in stats
        assert "cleaned_length" in stats
        assert "normalized_length" in stats
        assert "token_count" in stats
        assert "filtered_token_count" in stats
        assert isinstance(stats["original_length"], int)
