import pytest
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from nlptermux.similarity import TextSimilarity

class TestTextSimilarity:
    def setup_method(self):
        self.similarity = TextSimilarity()
    
    def test_jaccard_similarity_identical(self):
        text1 = "hello world"
        text2 = "hello world"
        score = self.similarity.jaccard_similarity(text1, text2)
        assert score == 1.0
    
    def test_jaccard_similarity_different(self):
        text1 = "hello world"
        text2 = "goodbye world"
        score = self.similarity.jaccard_similarity(text1, text2)
        assert 0.0 < score < 1.0
        assert score == 0.5  # 'world' in common, 2 unique words total
    
    def test_cosine_similarity(self):
        text1 = "hello world"
        text2 = "hello world"
        score = self.similarity.cosine_similarity(text1, text2)
        assert score == 1.0
        
        text3 = "hello world"
        text4 = "hi planet" 
        score = self.similarity.cosine_similarity(text3, text4)
        assert score == 0.0
    
    def test_levenshtein_distance(self):
        text1 = "kitten"
        text2 = "sitting"
        distance = self.similarity.levenshtein_distance(text1, text2)
        assert distance == 3
        
        text3 = "book"
        text4 = "back"
        distance = self.similarity.levenshtein_distance(text3, text4)
        assert distance == 2
    
    def test_jaro_winkler_similarity(self):
        text1 = "MARTHA"
        text2 = "MARHTA"
        score = self.similarity.jaro_winkler_similarity(text1, text2)
        assert score > 0.9  # High similarity with transposition
    
    def test_ngram_similarity(self):
        text1 = "hello"
        text2 = "hello"
        score = self.similarity.ngram_similarity(text1, text2, 2)
        assert score == 1.0
        
        text3 = "hello"
        text4 = "helio"
        score = self.similarity.ngram_similarity(text3, text4, 2)
        assert 0.0 < score < 1.0
    
    def test_normalized_similarity_methods(self):
        text1 = "hello world"
        text2 = "hello world"
        
        methods = ['cosine', 'jaccard', 'levenshtein', 'jaro', 'ngram']
        for method in methods:
            score = self.similarity.normalized_similarity(text1, text2, method)
            assert 0.0 <= score <= 1.0
            if method != 'levenshtein':  # levenshtein might be less than 1 for identical short strings
                assert score == 1.0 or score > 0.9
    
    def test_compare_multiple(self):
        texts = ["hello", "world", "hello world"]
        matrix = self.similarity.compare_multiple(texts, 'jaccard')
        
        assert len(matrix) == 3
        assert len(matrix[0]) == 3
        assert matrix[0][0] == 1.0  # diagonal should be 1.0
        assert matrix[1][1] == 1.0
        assert matrix[2][2] == 1.0
    
    def test_find_most_similar(self):
        query = "machine learning"
        candidates = [
            "artificial intelligence",
            "deep learning", 
            "computer science",
            "data mining"
        ]
        
        results = self.similarity.find_most_similar(query, candidates, 'jaccard', top_k=2)
        
        assert len(results) == 2
        assert all(isinstance(result, tuple) and len(result) == 2 for result in results)
        assert all(0.0 <= score <= 1.0 for _, score in results)
    
    def test_similarity_report(self):
        text1 = "natural language processing"
        text2 = "human language understanding"
        
        report = self.similarity.get_similarity_report(text1, text2)
        
        expected_keys = ['jaccard', 'cosine', 'levenshtein', 'jaro_winkler', 'bigram', 'trigram', 'text1_length', 'text2_length', 'average_similarity']
        
        for key in expected_keys:
            assert key in report
        
        assert all(0.0 <= report[key] <= 1.0 for key in ['jaccard', 'cosine', 'levenshtein', 'jaro_winkler', 'bigram', 'trigram', 'average_similarity'])
