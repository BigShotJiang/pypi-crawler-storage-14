"""
Text similarity calculations.
Multiple similarity measures optimized for mobile performance.
"""

import re
import math
import logging
from collections import Counter
from typing import List, Set, Dict, Any, Tuple

logger = logging.getLogger('nlptermux.similarity')

class TextSimilarity:
    """
    Calculate similarity between texts using various methods.
    Mobile-optimized with efficient algorithms.
    """
    
    def __init__(self):
        """Initialize TextSimilarity calculator."""
        self.word_pattern = re.compile(r'\b\w+\b')
        logger.info("TextSimilarity initialized")
    
    @staticmethod
    def jaccard_similarity(text1: str, text2: str) -> float:
        """
        Calculate Jaccard similarity between two texts.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            float: Jaccard similarity score (0-1)
        """
        if not text1 or not text2:
            return 0.0
        
        words1 = set(re.findall(r'\b\w+\b', text1.lower()))
        words2 = set(re.findall(r'\b\w+\b', text2.lower()))
        
        if not words1 and not words2:
            return 1.0  # Both are empty
        elif not words1 or not words2:
            return 0.0  # One is empty
        
        intersection = len(words1.intersection(words2))
        union = len(words1.union(words2))
        
        similarity = intersection / union
        logger.debug(f"Jaccard similarity: {similarity:.3f}")
        return similarity
    
    @staticmethod
    def cosine_similarity(text1: str, text2: str) -> float:
        """
        Calculate cosine similarity between two texts.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            float: Cosine similarity score (0-1)
        """
        if not text1 or not text2:
            return 0.0
        
        words1 = re.findall(r'\b\w+\b', text1.lower())
        words2 = re.findall(r'\b\w+\b', text2.lower())
        
        if not words1 and not words2:
            return 1.0
        elif not words1 or not words2:
            return 0.0
        
        vec1 = Counter(words1)
        vec2 = Counter(words2)
        
        # Get all unique words
        all_words = set(vec1.keys()).union(set(vec2.keys()))
        
        # Calculate dot product
        dot_product = sum(vec1.get(word, 0) * vec2.get(word, 0) for word in all_words)
        
        # Calculate magnitudes
        mag1 = math.sqrt(sum(val ** 2 for val in vec1.values()))
        mag2 = math.sqrt(sum(val ** 2 for val in vec2.values()))
        
        if mag1 * mag2 == 0:
            return 0.0
        
        similarity = dot_product / (mag1 * mag2)
        logger.debug(f"Cosine similarity: {similarity:.3f}")
        return similarity
    
    @staticmethod
    def levenshtein_distance(text1: str, text2: str) -> int:
        """
        Calculate Levenshtein distance between two strings.
        
        Args:
            text1: First string
            text2: Second string
            
        Returns:
            int: Levenshtein distance
        """
        if len(text1) < len(text2):
            return TextSimilarity.levenshtein_distance(text2, text1)
        
        if len(text2) == 0:
            return len(text1)
        
        previous_row = list(range(len(text2) + 1))
        for i, c1 in enumerate(text1):
            current_row = [i + 1]
            for j, c2 in enumerate(text2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        distance = previous_row[-1]
        logger.debug(f"Levenshtein distance: {distance}")
        return distance
    
    def jaro_winkler_similarity(self, text1: str, text2: str, winkler_boost: bool = True) -> float:
        """
        Calculate Jaro-Winkler similarity between two strings.
        
        Args:
            text1: First string
            text2: Second string
            winkler_boost: Whether to apply Winkler boost for common prefixes
            
        Returns:
            float: Jaro-Winkler similarity (0-1)
        """
        # Jaro similarity
        s1, s2 = text1, text2
        len1, len2 = len(s1), len(s2)
        
        if len1 == 0 or len2 == 0:
            return 0.0
        
        match_distance = max(len1, len2) // 2 - 1
        matches1 = [False] * len1
        matches2 = [False] * len2
        
        matches = 0
        transpositions = 0
        
        for i in range(len1):
            start = max(0, i - match_distance)
            end = min(i + match_distance + 1, len2)
            
            for j in range(start, end):
                if not matches2[j] and s1[i] == s2[j]:
                    matches1[i] = True
                    matches2[j] = True
                    matches += 1
                    break
        
        if matches == 0:
            return 0.0
        
        k = 0
        for i in range(len1):
            if matches1[i]:
                while not matches2[k]:
                    k += 1
                if s1[i] != s2[k]:
                    transpositions += 1
                k += 1
        
        transpositions //= 2
        
        jaro_similarity = (
            matches / len1 +
            matches / len2 +
            (matches - transpositions) / matches
        ) / 3.0
        
        # Winkler boost for common prefix
        if winkler_boost:
            prefix = 0
            for i in range(min(len1, len2, 4)):
                if s1[i] == s2[i]:
                    prefix += 1
                else:
                    break
            
            jaro_similarity += 0.1 * prefix * (1 - jaro_similarity)
        
        similarity = max(0.0, min(1.0, jaro_similarity))
        logger.debug(f"Jaro-Winkler similarity: {similarity:.3f}")
        return similarity
    
    def ngram_similarity(self, text1: str, text2: str, n: int = 2) -> float:
        """
        Calculate n-gram similarity between two texts.
        
        Args:
            text1: First text
            text2: Second text
            n: Size of n-grams
            
        Returns:
            float: N-gram similarity (0-1)
        """
        def get_ngrams(text, n):
            return [text[i:i+n] for i in range(len(text)-n+1)]
        
        ngrams1 = set(get_ngrams(text1.lower(), n))
        ngrams2 = set(get_ngrams(text2.lower(), n))
        
        if not ngrams1 and not ngrams2:
            return 1.0
        elif not ngrams1 or not ngrams2:
            return 0.0
        
        intersection = len(ngrams1.intersection(ngrams2))
        union = len(ngrams1.union(ngrams2))
        
        similarity = intersection / union
        logger.debug(f"{n}-gram similarity: {similarity:.3f}")
        return similarity
    
    def normalized_similarity(self, text1: str, text2: str, method: str = 'cosine') -> float:
        """
        Calculate normalized similarity score.
        
        Args:
            text1: First text
            text2: Second text
            method: Similarity method ('cosine', 'jaccard', 'levenshtein', 'jaro', 'ngram')
            
        Returns:
            float: Normalized similarity score (0-1)
        """
        if method == 'cosine':
            return self.cosine_similarity(text1, text2)
        elif method == 'jaccard':
            return self.jaccard_similarity(text1, text2)
        elif method == 'levenshtein':
            distance = self.levenshtein_distance(text1, text2)
            max_len = max(len(text1), len(text2))
            return 1 - (distance / max_len) if max_len > 0 else 1.0
        elif method == 'jaro':
            return self.jaro_winkler_similarity(text1, text2)
        elif method == 'ngram':
            return self.ngram_similarity(text1, text2)
        else:
            raise ValueError("Method must be 'cosine', 'jaccard', 'levenshtein', 'jaro', or 'ngram'")
    
    def compare_multiple(self, texts: List[str], method: str = 'cosine') -> List[List[float]]:
        """
        Compare multiple texts and return similarity matrix.
        
        Args:
            texts: List of text strings
            method: Similarity method
            
        Returns:
            List of lists with similarity scores
        """
        n = len(texts)
        matrix = [[0.0] * n for _ in range(n)]
        
        for i in range(n):
            for j in range(i, n):
                if i == j:
                    matrix[i][j] = 1.0
                else:
                    similarity = self.normalized_similarity(texts[i], texts[j], method)
                    matrix[i][j] = similarity
                    matrix[j][i] = similarity
        
        logger.debug(f"Generated similarity matrix for {n} texts")
        return matrix
    
    def find_most_similar(self, query: str, candidates: List[str], method: str = 'cosine', 
                         top_k: int = 5) -> List[Tuple[str, float]]:
        """
        Find most similar texts to query from candidates.
        
        Args:
            query: Query text
            candidates: List of candidate texts
            method: Similarity method
            top_k: Number of top results to return
            
        Returns:
            List of tuples (text, similarity_score)
        """
        similarities = []
        
        for candidate in candidates:
            similarity = self.normalized_similarity(query, candidate, method)
            similarities.append((candidate, similarity))
        
        # Sort by similarity score (descending)
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        logger.debug(f"Found {len(similarities)} similar texts, returning top {top_k}")
        return similarities[:top_k]
    
    def get_similarity_report(self, text1: str, text2: str) -> Dict[str, Any]:
        """
        Generate comprehensive similarity report.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Dict with multiple similarity measures
        """
        return {
            "jaccard": self.jaccard_similarity(text1, text2),
            "cosine": self.cosine_similarity(text1, text2),
            "levenshtein": 1 - (self.levenshtein_distance(text1, text2) / max(len(text1), len(text2)) if max(len(text1), len(text2)) > 0 else 1.0),
            "jaro_winkler": self.jaro_winkler_similarity(text1, text2),
            "bigram": self.ngram_similarity(text1, text2, 2),
            "trigram": self.ngram_similarity(text1, text2, 3),
            "text1_length": len(text1),
            "text2_length": len(text2),
            "average_similarity": (
                self.jaccard_similarity(text1, text2) +
                self.cosine_similarity(text1, text2) +
                self.jaro_winkler_similarity(text1, text2)
            ) / 3
        }
