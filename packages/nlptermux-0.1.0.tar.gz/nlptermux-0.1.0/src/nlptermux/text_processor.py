"""
Text preprocessing and cleaning utilities.
Optimized for mobile performance and low memory usage.
"""

import re
import string
import logging
from typing import List, Set, Dict, Any

logger = logging.getLogger('nlptermux.text_processor')

class TextProcessor:
    """
    Text preprocessing class for cleaning and normalizing text.
    Mobile-optimized with configurable cleaning pipelines.
    """
    
    def __init__(self, language: str = 'english'):
        """
        Initialize TextProcessor.
        
        Args:
            language: Language for stop words (currently only English supported)
        """
        self.language = language
        self.stop_words = self._load_stop_words()
        self.contractions = self._load_contractions()
        logger.info(f"TextProcessor initialized for language: {language}")
    
    def _load_stop_words(self) -> Set[str]:
        """Load basic English stop words."""
        stop_words = {
            'a', 'an', 'the', 'and', 'or', 'but', 'if', 'while', 'of', 'at', 
            'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through',
            'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 
            'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further',
            'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
            'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such',
            'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very',
            's', 't', 'can', 'will', 'just', 'don', 'should', 'now', 'd', 'll', 'm', 
            'o', 're', 've', 'y', 'ain', 'aren', 'couldn', 'didn', 'doesn', 'hadn',
            'hasn', 'haven', 'isn', 'ma', 'mightn', 'mustn', 'needn', 'shan', 
            'shouldn', 'wasn', 'weren', 'won', 'wouldn'
        }
        logger.debug(f"Loaded {len(stop_words)} stop words")
        return stop_words
    
    def _load_contractions(self) -> Dict[str, str]:
        """Load common English contractions."""
        contractions = {
            "ain't": "am not", "aren't": "are not", "can't": "cannot", 
            "can't've": "cannot have", "'cause": "because", "could've": "could have",
            "couldn't": "could not", "couldn't've": "could not have",
            "didn't": "did not", "doesn't": "does not", "don't": "do not",
            "hadn't": "had not", "hadn't've": "had not have", "hasn't": "has not",
            "haven't": "have not", "he'd": "he would", "he'd've": "he would have",
            "he'll": "he will", "he'll've": "he will have", "he's": "he is",
            "how'd": "how did", "how'd'y": "how do you", "how'll": "how will",
            "how's": "how is", "i'd": "i would", "i'd've": "i would have",
            "i'll": "i will", "i'll've": "i will have", "i'm": "i am",
            "i've": "i have", "isn't": "is not", "it'd": "it would",
            "it'd've": "it would have", "it'll": "it will", "it'll've": "it will have",
            "it's": "it is", "let's": "let us", "ma'am": "madam", "mayn't": "may not",
            "might've": "might have", "mightn't": "might not", 
            "mightn't've": "might not have", "must've": "must have",
            "mustn't": "must not", "mustn't've": "must not have", "needn't": "need not",
            "needn't've": "need not have", "o'clock": "of the clock", "oughtn't": "ought not",
            "oughtn't've": "ought not have", "shan't": "shall not", "sha'n't": "shall not",
            "shan't've": "shall not have", "she'd": "she would", "she'd've": "she would have",
            "she'll": "she will", "she'll've": "she will have", "she's": "she is",
            "should've": "should have", "shouldn't": "should not",
            "shouldn't've": "should not have", "so've": "so have", "so's": "so is",
            "that'd": "that would", "that'd've": "that would have", "that's": "that is",
            "there'd": "there would", "there'd've": "there would have", "there's": "there is",
            "they'd": "they would", "they'd've": "they would have", "they'll": "they will",
            "they'll've": "they will have", "they're": "they are", "they've": "they have",
            "to've": "to have", "wasn't": "was not", "we'd": "we would",
            "we'd've": "we would have", "we'll": "we will", "we'll've": "we will have",
            "we're": "we are", "we've": "we have", "weren't": "were not",
            "what'll": "what will", "what'll've": "what will have", "what're": "what are",
            "what's": "what is", "what've": "what have", "when's": "when is",
            "when've": "when have", "where'd": "where did", "where's": "where is",
            "where've": "where have", "who'll": "who will", "who'll've": "who will have",
            "who's": "who is", "who've": "who have", "why's": "why is",
            "why've": "why have", "will've": "will have", "won't": "will not",
            "won't've": "will not have", "would've": "would have", "wouldn't": "would not",
            "wouldn't've": "would not have", "y'all": "you all", "y'all'd": "you all would",
            "y'all'd've": "you all would have", "y'all're": "you all are",
            "y'all've": "you all have", "you'd": "you would", "you'd've": "you would have",
            "you'll": "you will", "you'll've": "you will have", "you're": "you are",
            "you've": "you have"
        }
        logger.debug(f"Loaded {len(contractions)} contractions")
        return contractions
    
    def expand_contractions(self, text: str) -> str:
        """
        Expand contractions in text.
        
        Args:
            text: Input text with contractions
            
        Returns:
            str: Text with contractions expanded
        """
        # Create a pattern to match contractions
        contractions_pattern = re.compile('({})'.format('|'.join(self.contractions.keys())), 
                                        flags=re.IGNORECASE|re.DOTALL)
        
        def expand_match(contraction):
            match = contraction.group(0)
            expanded = self.contractions.get(match.lower())
            if not expanded:
                return match
            return expanded
        
        expanded_text = contractions_pattern.sub(expand_match, text)
        logger.debug("Expanded contractions in text")
        return expanded_text
    
    def clean_text(self, text: str, remove_punct: bool = True, 
                   remove_numbers: bool = True, lowercase: bool = True,
                   expand_contractions: bool = True) -> str:
        """
        Clean and normalize text with multiple options.
        
        Args:
            text: Input text to clean
            remove_punct: Whether to remove punctuation
            remove_numbers: Whether to remove numbers
            lowercase: Whether to convert to lowercase
            expand_contractions: Whether to expand contractions
            
        Returns:
            str: Cleaned text
        """
        if not text or not isinstance(text, str):
            logger.warning("Invalid text input for cleaning")
            return ""
        
        original_length = len(text)
        
        # Expand contractions first
        if expand_contractions:
            text = self.expand_contractions(text)
        
        # Convert to lowercase
        if lowercase:
            text = text.lower()
        
        # Remove punctuation
        if remove_punct:
            text = text.translate(str.maketrans('', '', string.punctuation))
        
        # Remove numbers
        if remove_numbers:
            text = re.sub(r'\d+', '', text)
        
        # Remove extra whitespace and trim
        text = re.sub(r'\s+', ' ', text).strip()
        
        logger.debug(f"Text cleaned: {original_length} -> {len(text)} characters")
        return text
    
    def remove_stop_words(self, tokens: List[str]) -> List[str]:
        """
        Remove stop words from token list.
        
        Args:
            tokens: List of tokens
            
        Returns:
            List[str]: Tokens with stop words removed
        """
        if not tokens:
            return []
        
        filtered_tokens = [token for token in tokens if token.lower() not in self.stop_words]
        removed_count = len(tokens) - len(filtered_tokens)
        logger.debug(f"Removed {removed_count} stop words from {len(tokens)} tokens")
        
        return filtered_tokens
    
    def normalize_text(self, text: str, remove_stopwords: bool = True) -> str:
        """
        Apply full normalization pipeline.
        
        Args:
            text: Input text
            remove_stopwords: Whether to remove stop words
            
        Returns:
            str: Fully normalized text
        """
        # Clean text
        text = self.clean_text(text)
        
        # Tokenize
        tokens = text.split()
        
        # Remove stop words if requested
        if remove_stopwords:
            tokens = self.remove_stop_words(tokens)
        
        normalized_text = ' '.join(tokens)
        logger.debug(f"Text normalized: {len(text)} -> {len(normalized_text)} characters")
        
        return normalized_text
    
    def get_processing_stats(self, text: str) -> Dict[str, Any]:
        """
        Get statistics about text processing.
        
        Args:
            text: Input text
            
        Returns:
            Dict with processing statistics
        """
        original_length = len(text)
        cleaned = self.clean_text(text)
        normalized = self.normalize_text(text)
        tokens = cleaned.split()
        filtered_tokens = self.remove_stop_words(tokens)
        
        return {
            "original_length": original_length,
            "cleaned_length": len(cleaned),
            "normalized_length": len(normalized),
            "token_count": len(tokens),
            "filtered_token_count": len(filtered_tokens),
            "stop_words_removed": len(tokens) - len(filtered_tokens),
            "cleaning_ratio": len(cleaned) / original_length if original_length > 0 else 0
        }
