"""
Tokenization utilities for text processing.
Mobile-optimized tokenizers for word and sentence segmentation.
"""

import re
import logging
from typing import List, Tuple, Generator, Dict, Any

logger = logging.getLogger('nlptermux.tokenizer')

class Tokenizer:
    """Word tokenizer implementation with mobile optimizations."""
    
    def __init__(self, language: str = 'english'):
        """
        Initialize Tokenizer.
        
        Args:
            language: Language for tokenization rules
        """
        self.language = language
        self.word_pattern = re.compile(r'\b\w+(?:-\w+)*\b')
        self.email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
        self.url_pattern = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
        logger.info(f"Tokenizer initialized for language: {language}")
    
    def tokenize(self, text: str, preserve_entities: bool = True) -> List[str]:
        """
        Tokenize text into words with entity preservation.
        
        Args:
            text: Input text
            preserve_entities: Whether to preserve emails and URLs as single tokens
            
        Returns:
            List[str]: List of tokens
        """
        if not text:
            return []
        
        # Preserve emails and URLs if requested
        if preserve_entities:
            # Replace emails and URLs with placeholders
            entity_map = {}
            text_to_tokenize = text
            
            # Find and replace emails
            email_matches = list(self.email_pattern.finditer(text))
            for i, match in enumerate(email_matches):
                placeholder = f"__EMAIL_{i}__"
                entity_map[placeholder] = match.group()
                text_to_tokenize = text_to_tokenize.replace(match.group(), placeholder)
            
            # Find and replace URLs
            url_matches = list(self.url_pattern.finditer(text_to_tokenize))
            for i, match in enumerate(url_matches):
                placeholder = f"__URL_{i}__"
                entity_map[placeholder] = match.group()
                text_to_tokenize = text_to_tokenize.replace(match.group(), placeholder)
            
            # Tokenize the modified text
            tokens = self.word_pattern.findall(text_to_tokenize.lower())
            
            # Restore entities
            final_tokens = []
            for token in tokens:
                if token in entity_map:
                    final_tokens.append(entity_map[token])
                else:
                    final_tokens.append(token)
            
            logger.debug(f"Tokenized {len(text)} characters into {len(final_tokens)} tokens with entity preservation")
            return final_tokens
        else:
            # Simple tokenization without entity preservation
            tokens = self.word_pattern.findall(text.lower())
            logger.debug(f"Tokenized {len(text)} characters into {len(tokens)} tokens")
            return tokens
    
    def ngrams(self, text: str, n: int = 2, preserve_entities: bool = True) -> List[Tuple[str, ...]]:
        """
        Generate n-grams from text.
        
        Args:
            text: Input text
            n: Size of n-grams
            preserve_entities: Whether to preserve emails and URLs
            
        Returns:
            List[Tuple]: List of n-grams
        """
        tokens = self.tokenize(text, preserve_entities=preserve_entities)
        
        if len(tokens) < n:
            logger.warning(f"Text too short for {n}-grams: {len(tokens)} tokens")
            return []
        
        ngrams_list = [tuple(tokens[i:i+n]) for i in range(len(tokens)-n+1)]
        logger.debug(f"Generated {len(ngrams_list)} {n}-grams from {len(tokens)} tokens")
        return ngrams_list
    
    def character_ngrams(self, text: str, n: int = 3) -> List[str]:
        """
        Generate character n-grams from text.
        
        Args:
            text: Input text
            n: Size of character n-grams
            
        Returns:
            List[str]: List of character n-grams
        """
        if len(text) < n:
            return []
        
        char_ngrams = [text[i:i+n] for i in range(len(text)-n+1)]
        logger.debug(f"Generated {len(char_ngrams)} character {n}-grams")
        return char_ngrams
    
    def get_tokenization_stats(self, text: str) -> Dict[str, Any]:
        """
        Get statistics about tokenization.
        
        Args:
            text: Input text
            
        Returns:
            Dict with tokenization statistics
        """
        tokens = self.tokenize(text)
        bigrams = self.ngrams(text, 2)
        trigrams = self.ngrams(text, 3)
        char_bigrams = self.character_ngrams(text, 2)
        char_trigrams = self.character_ngrams(text, 3)
        
        # Calculate average token length
        if tokens:
            avg_token_length = sum(len(token) for token in tokens) / len(tokens)
        else:
            avg_token_length = 0
        
        return {
            "text_length": len(text),
            "token_count": len(tokens),
            "bigram_count": len(bigrams),
            "trigram_count": len(trigrams),
            "char_bigram_count": len(char_bigrams),
            "char_trigram_count": len(char_trigrams),
            "avg_token_length": avg_token_length,
            "unique_tokens": len(set(tokens)),
            "vocabulary_richness": len(set(tokens)) / len(tokens) if tokens else 0
        }

class SentenceTokenizer:
    """Sentence tokenizer implementation."""
    
    def __init__(self, language: str = 'english'):
        """
        Initialize SentenceTokenizer.
        
        Args:
            language: Language for sentence segmentation rules
        """
        self.language = language
        # Pattern to split sentences at .!? followed by space and capital letter
        self.sentence_endings = re.compile(r'(?<=[.!?])\s+(?=[A-Z])')
        # Handle abbreviations that might end with period
        self.abbreviations = {'mr', 'mrs', 'ms', 'dr', 'prof', 'rev', 'gov', 'rep', 'sen', 
                             'jr', 'sr', 'vs', 'etc', 'eg', 'ie', 'approx', 'dept', 'univ'}
        logger.info(f"SentenceTokenizer initialized for language: {language}")
    
    def tokenize(self, text: str) -> List[str]:
        """
        Tokenize text into sentences.
        
        Args:
            text: Input text
            
        Returns:
            List[str]: List of sentences
        """
        if not text:
            return []
        
        # Initial split using sentence endings
        initial_sentences = self.sentence_endings.split(text)
        
        # Handle abbreviations and other edge cases
        sentences = []
        current_sentence = ""
        
        for segment in initial_sentences:
            if not segment.strip():
                continue
                
            if current_sentence:
                current_sentence += " " + segment
            else:
                current_sentence = segment
            
            # Check if the last word might be an abbreviation
            words = current_sentence.split()
            if words:
                last_word = words[-1].lower().rstrip('.')
                if last_word in self.abbreviations:
                    continue  # Continue building the sentence
            
            # If we get here, we have a complete sentence
            sentences.append(current_sentence.strip())
            current_sentence = ""
        
        # Don't forget the last sentence if any
        if current_sentence:
            sentences.append(current_sentence.strip())
        
        logger.debug(f"Tokenized {len(text)} characters into {len(sentences)} sentences")
        return sentences
    
    def stream_sentences(self, text: str) -> Generator[str, None, None]:
        """
        Generator that yields sentences one by one.
        Memory efficient for large texts.
        
        Args:
            text: Input text
            
        Yields:
            str: Individual sentences
        """
        sentences = self.tokenize(text)
        for sentence in sentences:
            yield sentence
    
    def get_sentence_stats(self, text: str) -> Dict[str, Any]:
        """
        Get statistics about sentences.
        
        Args:
            text: Input text
            
        Returns:
            Dict with sentence statistics
        """
        sentences = self.tokenize(text)
        
        if not sentences:
            return {
                "sentence_count": 0,
                "avg_sentence_length": 0,
                "avg_words_per_sentence": 0,
                "longest_sentence_length": 0,
                "shortest_sentence_length": 0
            }
        
        sentence_lengths = [len(sentence) for sentence in sentences]
        word_counts = [len(sentence.split()) for sentence in sentences]
        
        return {
            "sentence_count": len(sentences),
            "avg_sentence_length": sum(sentence_lengths) / len(sentence_lengths),
            "avg_words_per_sentence": sum(word_counts) / len(word_counts),
            "longest_sentence_length": max(sentence_lengths),
            "shortest_sentence_length": min(sentence_lengths),
            "longest_sentence_words": max(word_counts),
            "shortest_sentence_words": min(word_counts)
        }
