"""
Sentiment analysis implementation.
Lexicon-based approach optimized for mobile performance.
"""

import re
import logging
import json
from typing import Dict, List, Tuple, Any
from .utils import download_file

logger = logging.getLogger('nlptermux.sentiment')

class SentimentAnalyzer:
    """
    Lexicon-based sentiment analyzer with mobile optimizations.
    """
    
    def __init__(self, language: str = 'english'):
        """
        Initialize SentimentAnalyzer.
        
        Args:
            language: Language for sentiment analysis
        """
        self.language = language
        self.lexicon = self._load_lexicon()
        self.negation_words = {'not', 'no', 'never', 'nothing', 'nowhere', 'neither', 'nor', 
                              'cannot', "can't", "won't", "don't", "doesn't", "isn't", "aren't", 
                              "wasn't", "weren't", "haven't", "hasn't", "hadn't", "wouldn't", 
                              "shouldn't", "couldn't", "mightn't"}
        self.intensifiers = {
            'very': 1.3, 'extremely': 1.5, 'absolutely': 1.4, 'completely': 1.4, 
            'totally': 1.4, 'really': 1.2, 'highly': 1.3, 'utterly': 1.5,
            'quite': 1.1, 'somewhat': 0.8, 'slightly': 0.7, 'barely': 0.6
        }
        self.diminishers = {
            'slightly': 0.7, 'somewhat': 0.8, 'partially': 0.8, 'marginally': 0.7
        }
        logger.info(f"SentimentAnalyzer initialized for language: {language}")
    
    def _load_lexicon(self) -> Dict[str, float]:
        """Load sentiment lexicon with mobile-optimized vocabulary."""
        # Comprehensive sentiment lexicon
        lexicon = {
            # Positive words
            'good': 1.0, 'great': 1.5, 'excellent': 2.0, 'amazing': 1.8, 'awesome': 1.7,
            'wonderful': 1.6, 'fantastic': 1.7, 'brilliant': 1.6, 'outstanding': 1.8,
            'superb': 1.7, 'terrific': 1.5, 'marvelous': 1.6, 'perfect': 1.9,
            'love': 1.7, 'like': 1.0, 'enjoy': 1.2, 'adore': 1.8, 'prefer': 0.8,
            'happy': 1.3, 'joy': 1.4, 'pleased': 1.2, 'delighted': 1.5, 'ecstatic': 1.8,
            'beautiful': 1.4, 'gorgeous': 1.6, 'stunning': 1.5, 'breathtaking': 1.7,
            'nice': 0.8, 'pleasant': 0.9, 'satisfactory': 0.7, 'decent': 0.6,
            
            # Negative words
            'bad': -1.0, 'terrible': -1.8, 'awful': -1.5, 'horrible': -2.0, 'dreadful': -1.7,
            'poor': -1.2, 'unacceptable': -1.6, 'disappointing': -1.4, 'frustrating': -1.3,
            'hate': -1.7, 'dislike': -1.0, 'despise': -2.0, 'loathe': -1.9, 'detest': -1.8,
            'sad': -1.2, 'unhappy': -1.3, 'miserable': -1.6, 'depressed': -1.5, 'heartbroken': -1.8,
            'ugly': -1.2, 'disgusting': -1.5, 'repulsive': -1.7, 'revolting': -1.6,
            'wrong': -1.0, 'incorrect': -0.8, 'false': -0.9, 'inaccurate': -0.8,
            'angry': -1.4, 'furious': -1.7, 'enraged': -1.8, 'annoyed': -1.1,
            
            # Neutral/contextual words
            'okay': 0.3, 'fine': 0.2, 'average': 0.0, 'normal': 0.0, 'regular': 0.0,
            'interesting': 0.4, 'curious': 0.2, 'different': 0.1,
            
            # Intensifier context words
            'best': 1.8, 'worst': -1.8, 'better': 0.8, 'worse': -0.8,
        }
        logger.debug(f"Loaded sentiment lexicon with {len(lexicon)} words")
        return lexicon
    
    def _detect_emojis(self, text: str) -> Tuple[int, List[str]]:
        """
        Detect and score emojis in text.
        
        Args:
            text: Input text
            
        Returns:
            Tuple of (emoji_score, emoji_list)
        """
        # Emoji patterns (simplified)
        emoji_pattern = re.compile(
            "[\U0001F600-\U0001F64F"  # emoticons
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map symbols
            "\U0001F1E0-\U0001F1FF"  # flags (iOS)
            "]+", flags=re.UNICODE)
        
        emojis = emoji_pattern.findall(text)
        emoji_sentiment = {
            '😀': 1.0, '😃': 1.2, '😄': 1.3, '😁': 1.1, '😆': 1.4, '😅': 0.8, '😂': 1.0,
            '🤣': 1.5, '😊': 1.2, '😇': 1.1, '🙂': 0.7, '🙃': 0.3, '😉': 0.6, '😌': 0.5,
            '😍': 1.8, '🥰': 1.7, '😘': 1.5, '😗': 0.8, '😙': 0.9, '😚': 1.2, '😋': 1.1,
            '😛': 0.5, '😝': 0.4, '😜': 0.5, '🤪': 0.3, '🤨': -0.2, '🧐': -0.1,
            '🤓': 0.3, '😎': 0.8, '🤩': 1.4, '🥳': 1.3, '😏': -0.3, '😒': -0.8,
            '😞': -1.2, '😔': -1.1, '😟': -1.0, '😕': -0.5, '🙁': -0.7, '☹️': -1.0,
            '😣': -1.1, '😖': -1.3, '😫': -1.4, '😩': -1.3, '🥺': -0.8, '😢': -1.2,
            '😭': -1.6, '😤': -1.1, '😠': -1.3, '😡': -1.7, '🤬': -2.0, '🤯': -0.5,
            '😳': -0.3, '🥵': -0.4, '🥶': -0.5, '😱': -1.4, '😨': -1.2, '😰': -1.1,
            '😥': -0.9, '😓': -1.0, '🤗': 1.1, '🤔': 0.0, '🤭': 0.3, '🤫': 0.1,
            '🤥': -1.2, '😶': -0.2, '😐': -0.1, '😑': -0.3, '😬': -0.4, '🙄': -0.6,
            '😯': -0.2, '😦': -0.7, '😧': -1.0, '😮': -0.1, '😲': -0.2, '🥱': -0.4,
            '😴': -0.3, '🤤': -0.2, '😪': -0.5, '😵': -0.8, '🤐': -0.3, '🥴': -0.4,
            '🤢': -1.5, '🤮': -1.8, '🤧': -0.5, '😷': -0.4, '🤒': -0.7, '🤕': -0.8,
            '🤑': -0.2, '🤠': 0.6, '😈': -0.8, '👿': -1.5, '🤡': -0.3, '💩': -1.2,
            '👻': 0.2, '💀': -0.5, '☠️': -0.8, '👽': 0.1, '👾': 0.2, '🤖': 0.1,
            '🎃': 0.3, '😺': 1.0, '😸': 1.2, '😹': 1.1, '😻': 1.4, '😼': 0.3,
            '😽': 0.9, '🙀': -0.5, '😿': -1.0, '😾': -0.8
        }
        
        total_emoji_score = 0
        found_emojis = []
        
        for emoji in emojis:
            if emoji in emoji_sentiment:
                total_emoji_score += emoji_sentiment[emoji]
                found_emojis.append(emoji)
        
        return total_emoji_score, found_emojis
    
    def analyze(self, text: str, include_emojis: bool = True) -> Dict[str, Any]:
        """
        Analyze sentiment of text with comprehensive features.
        
        Args:
            text: Input text
            include_emojis: Whether to include emoji analysis
            
        Returns:
            Dict with sentiment scores and analysis
        """
        if not text:
            return {
                'score': 0.0,
                'label': 'neutral',
                'positive_words': 0,
                'negative_words': 0,
                'total_sentiment_words': 0,
                'confidence': 0.0,
                'emojis': []
            }
        
        words = text.lower().split()
        sentiment_score = 0.0
        positive_count = 0
        negative_count = 0
        negation_active = False
        intensifier_multiplier = 1.0
        processed_words = 0
        
        # Analyze emojis if requested
        emoji_score = 0.0
        found_emojis = []
        if include_emojis:
            emoji_score, found_emojis = self._detect_emojis(text)
        
        i = 0
        while i < len(words):
            word = words[i]
            
            # Check for negation patterns
            if word in self.negation_words:
                negation_active = True
                i += 1
                continue
            
            # Check for intensifiers
            if word in self.intensifiers:
                intensifier_multiplier = self.intensifiers[word]
                i += 1
                continue
            
            # Check for diminishers
            if word in self.diminishers:
                intensifier_multiplier = self.diminishers[word]
                i += 1
                continue
            
            # Reset modifiers after certain words
            if re.match(r'[.!?]', word):
                negation_active = False
                intensifier_multiplier = 1.0
            
            # Calculate sentiment for known words
            if word in self.lexicon:
                word_sentiment = self.lexicon[word]
                
                # Apply negation
                if negation_active:
                    word_sentiment = -word_sentiment * 0.7  # Reduced effect for negation
                
                # Apply intensifier/diminisher
                word_sentiment *= intensifier_multiplier
                
                sentiment_score += word_sentiment
                processed_words += 1
                
                if word_sentiment > 0:
                    positive_count += 1
                elif word_sentiment < 0:
                    negative_count += 1
                
                # Reset modifiers after processing a sentiment word
                negation_active = False
                intensifier_multiplier = 1.0
            
            i += 1
        
        # Add emoji score (weighted)
        if include_emojis:
            sentiment_score += emoji_score * 0.3  # Reduce emoji impact
        
        total_sentiment_words = positive_count + negative_count
        
        # Calculate normalized score
        if total_sentiment_words > 0:
            normalized_score = sentiment_score / total_sentiment_words
            # Confidence based on number of sentiment words
            confidence = min(total_sentiment_words / 10, 1.0)
        else:
            normalized_score = 0.0
            confidence = 0.0
        
        # Determine sentiment label with thresholds
        if normalized_score > 0.15:
            label = "positive"
        elif normalized_score < -0.15:
            label = "negative"
        else:
            label = "neutral"
        
        # Adjust confidence for neutral results with few words
        if label == "neutral" and total_sentiment_words < 3:
            confidence = max(confidence, 0.3)
        
        result = {
            'score': round(normalized_score, 3),
            'label': label,
            'positive_words': positive_count,
            'negative_words': negative_count,
            'total_sentiment_words': total_sentiment_words,
            'confidence': round(confidence, 3),
            'emojis': found_emojis,
            'emoji_score': round(emoji_score, 3),
            'processed_words': processed_words
        }
        
        logger.debug(f"Sentiment analysis: {label} (score: {normalized_score:.3f})")
        return result
    
    def analyze_batch(self, texts: List[str]) -> List[Dict[str, Any]]:
        """
        Analyze sentiment for multiple texts.
        
        Args:
            texts: List of text strings
            
        Returns:
            List of sentiment analysis results
        """
        return [self.analyze(text) for text in texts]
    
    def get_lexicon_info(self) -> Dict[str, Any]:
        """
        Get information about the sentiment lexicon.
        
        Returns:
            Dict with lexicon statistics
        """
        positive_words = [word for word, score in self.lexicon.items() if score > 0]
        negative_words = [word for word, score in self.lexicon.items() if score < 0]
        neutral_words = [word for word, score in self.lexicon.items() if score == 0]
        
        return {
            "total_words": len(self.lexicon),
            "positive_words": len(positive_words),
            "negative_words": len(negative_words),
            "neutral_words": len(neutral_words),
            "avg_positive_score": sum(score for score in self.lexicon.values() if score > 0) / len(positive_words) if positive_words else 0,
            "avg_negative_score": sum(score for score in self.lexicon.values() if score < 0) / len(negative_words) if negative_words else 0
        }
