"""
NLP Termux - A lightweight Natural Language Processing library for mobile development.
Optimized for Termux and Android environments.
"""

from .text_processor import TextProcessor
from .tokenizer import Tokenizer, SentenceTokenizer
from .sentiment import SentimentAnalyzer
from .similarity import TextSimilarity
from .utils import is_termux_environment, get_resource_path, download_file, get_system_info

__version__ = "0.1.0"
__all__ = [
    "TextProcessor",
    "Tokenizer", 
    "SentenceTokenizer",
    "SentimentAnalyzer",
    "TextSimilarity",
    "is_termux_environment",
    "get_resource_path",
    "download_file",
    "get_system_info"
]

# Check if we're in Termux and show welcome message
if is_termux_environment():
    print("NLP Termux library loaded in Termux environment! 📱")