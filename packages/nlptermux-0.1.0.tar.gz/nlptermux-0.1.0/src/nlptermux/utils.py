"""
Utility functions for NLP Termux library.
Termux-specific optimizations and environment detection.
"""

import os
import sys
import tempfile
import logging
from typing import Optional, Dict, Any

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('nlptermux')

def is_termux_environment() -> bool:
    """
    Check if running in Termux environment.
    
    Returns:
        bool: True if running in Termux, False otherwise
    """
    prefix = os.environ.get("PREFIX", "")
    termux_usr = os.environ.get("TERMUX_APP_PID", "")
    
    # Multiple checks for Termux environment
    termux_indicators = [
        "com.termux" in prefix,
        "/data/data/com.termux" in prefix,
        termux_usr != "",
        os.path.exists("/data/data/com.termux"),
        "TERMUX_VERSION" in os.environ
    ]
    
    return any(termux_indicators)

def get_resource_path() -> str:
    """
    Get appropriate resource path for Termux or standard environment.
    Creates the directory if it doesn't exist.
    
    Returns:
        str: Path to resource directory
    """
    if is_termux_environment():
        # Use Termux home directory
        home_dir = os.path.expanduser("~")
        resource_path = os.path.join(home_dir, ".nlptermux")
        logger.info(f"Using Termux resource path: {resource_path}")
    else:
        # Use standard temp directory
        resource_path = os.path.join(tempfile.gettempdir(), "nlptermux")
        logger.info(f"Using standard resource path: {resource_path}")
    
    # Create directory if it doesn't exist
    try:
        os.makedirs(resource_path, exist_ok=True)
        logger.debug(f"Resource directory created/verified: {resource_path}")
    except Exception as e:
        logger.error(f"Failed to create resource directory: {e}")
        # Fallback to current directory
        resource_path = os.path.join(os.getcwd(), ".nlptermux")
        os.makedirs(resource_path, exist_ok=True)
    
    return resource_path

def download_file(url: str, filename: str, timeout: int = 30) -> str:
    """
    Download file to resource directory with timeout management.
    
    Args:
        url: URL to download from
        filename: Name to save file as
        timeout: Timeout in seconds (important for mobile)
        
    Returns:
        str: Path to downloaded file
        
    Raises:
        Exception: If download fails
    """
    import requests
    
    resource_dir = get_resource_path()
    filepath = os.path.join(resource_dir, filename)
    
    # Check if file already exists
    if os.path.exists(filepath):
        logger.info(f"File already exists: {filepath}")
        return filepath
    
    logger.info(f"Downloading {url} to {filepath}")
    
    try:
        # Use timeout to prevent hanging on mobile networks
        response = requests.get(url, timeout=timeout)
        response.raise_for_status()
        
        with open(filepath, 'wb') as f:
            f.write(response.content)
        
        logger.info(f"Successfully downloaded: {filename}")
        return filepath
        
    except requests.exceptions.Timeout:
        logger.error(f"Download timeout after {timeout} seconds: {url}")
        raise
    except requests.exceptions.RequestException as e:
        logger.error(f"Download failed: {e}")
        raise

def get_system_info() -> Dict[str, Any]:
    """
    Get system information including Termux detection.
    
    Returns:
        Dict with system information
    """
    import platform
    
    return {
        "is_termux": is_termux_environment(),
        "python_version": platform.python_version(),
        "system": platform.system(),
        "machine": platform.machine(),
        "resource_path": get_resource_path(),
        "prefix": os.environ.get("PREFIX", "Not available")
    }

def optimize_for_mobile() -> Dict[str, Any]:
    """
    Apply mobile-specific optimizations.
    
    Returns:
        Dict with optimization results
    """
    optimizations = {}
    
    # Reduce memory usage by optimizing garbage collection
    import gc
    gc.set_threshold(700, 10, 10)
    optimizations["gc_threshold"] = "optimized"
    
    # Set mobile-friendly timeouts
    optimizations["default_timeout"] = 30
    
    logger.info("Mobile optimizations applied")
    return optimizations

# Apply optimizations when module is imported
if is_termux_environment():
    _ = optimize_for_mobile()
