# NLP Termux

A lightweight Natural Language Processing library optimized for Termux and mobile development.

## Features

- Text preprocessing and cleaning
- Tokenization (word and sentence)
- Sentiment analysis with emoji support
- Text similarity calculations (Jaccard, Cosine, Levenshtein, Jaro-Winkler)
- Stop words removal
- Mobile-optimized performance
- Batch processing capabilities
- Termux environment detection and optimization

## Installation

### From PyPI
```bash
pip install nlptermux