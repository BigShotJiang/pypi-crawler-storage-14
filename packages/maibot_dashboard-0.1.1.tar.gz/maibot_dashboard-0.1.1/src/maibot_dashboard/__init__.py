"""
MaiBot Dashboard - 前端资源包

这是 MaiBot 的 WebUI 前端资源包，包含预构建的静态文件。
"""

from pathlib import Path
from importlib.metadata import version, PackageNotFoundError

__all__ = ["get_dist_path", "get_version", "__version__"]


def get_dist_path() -> Path:
    """
    返回前端静态文件目录路径
    
    Returns:
        Path: 指向 dist 目录的路径
    
    Example:
        >>> from maibot_dashboard import get_dist_path
        >>> static_path = get_dist_path()
        >>> index_html = static_path / "index.html"
    """
    return Path(__file__).parent / "dist"


def get_version() -> str:
    """
    返回当前包版本
    
    Returns:
        str: 版本号字符串，如 "0.1.1"
    """
    try:
        return version("maibot-dashboard")
    except PackageNotFoundError:
        return "0.0.0"


# 便捷访问版本号
try:
    __version__ = version("maibot-dashboard")
except PackageNotFoundError:
    __version__ = "0.0.0"
