from ai_infra.llm.providers.models import Models
from ai_infra.llm.providers.providers import Providers

MODEL = str(Models.openai.default.value)
PROVIDER = str(Providers.openai)
