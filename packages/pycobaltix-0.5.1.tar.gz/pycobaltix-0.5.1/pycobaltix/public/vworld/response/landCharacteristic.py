


from dataclasses import dataclass


@dataclass
class LandCharacteristic:
    """토지특성 정보를 담는 데이터 클래스
    
    VWorld API의 토지특성정보 조회 결과를 나타냅니다.
    """
    
    # 예시 데이터
    EXAMPLE = {
        "pnu": "1111010100101234567",
        "ldCode": "11110",
        "ldCodeNm": "서울특별시 종로구",
        "regstrSeCode": 1,
        "regstrSeCodeNm": "일반",
        "mnnmSlno": "123-45",
        "ladSn": 1,
        "stdrYear": 2024,
        "stdrMt": "01",
        "lndcgrCode": "01",
        "lndcgrCodeNm": "대",
        "lndpclAr": "123.45",
        "prposArea1": 1,
        "prposArea1Nm": "주거지역",
        "prposArea2": 0,
        "prposArea2Nm": "지정되지않음",
        "ladUseSittn": 930,
        "ladUseSittnNm": "공원등",
        "tpgrphHgCode": 1,
        "tpgrphHgCodeNm": "평지",
        "tpgrphFrmCode": 1,
        "tpgrphFrmCodeNm": "정형",
        "roadSideCode": 1,
        "roadSideCodeNm": "각지",
        "pblntfPclnd": 0,
        "lastUpdtDt": "2017-08-02"
    }
    
    pnu: str  # 고유번호 (Parcel Number)
    ldCode: str  # 법정동코드
    ldCodeNm: str  # 법정동명
    regstrSeCode: int  # 등록구분코드
    regstrSeCodeNm: str  # 등록구분명
    mnnmSlno: str  # 본번-부번
    ladSn: int  # 토지일련번호
    stdrYear: int  # 기준년도
    stdrMt: str  # 기준월
    lndcgrCode: str  # 지목코드
    lndcgrCodeNm: str  # 지목명
    lndpclAr: str  # 토지면적(㎡)
    prposArea1: int  # 용도지역1코드
    prposArea1Nm: str  # 용도지역1명
    prposArea2: int  # 용도지역2코드
    prposArea2Nm: str  # 용도지역2명
    ladUseSittn: int  # 토지이용상황코드
    ladUseSittnNm: str  # 토지이용상황명
    tpgrphHgCode: int  # 지형높이코드
    tpgrphHgCodeNm: str  # 지형높이명
    tpgrphFrmCode: int  # 지형형상코드
    tpgrphFrmCodeNm: str  # 지형형상명
    roadSideCode: int  # 도로접면코드
    roadSideCodeNm: str  # 도로접면명
    pblntfPclnd:  int # 공시지가(원/㎡)
    lastUpdtDt: str  # 최종수정일시
    
    def to_dict(self):
        return {
            "pnu": self.pnu,
            "ldCode": self.ldCode,
            "ldCodeNm": self.ldCodeNm,
            "regstrSeCode": self.regstrSeCode,
            "regstrSeCodeNm": self.regstrSeCodeNm,
            "mnnmSlno": self.mnnmSlno,
            "ladSn": self.ladSn,
            "stdrYear": self.stdrYear,
            "stdrMt": self.stdrMt,
            "lndcgrCode": self.lndcgrCode,
            "lndcgrCodeNm": self.lndcgrCodeNm,
            "lndpclAr": self.lndpclAr,
            "prposArea1": self.prposArea1,
            "prposArea1Nm": self.prposArea1Nm,
            "prposArea2": self.prposArea2,
            "prposArea2Nm": self.prposArea2Nm,
            "ladUseSittn": self.ladUseSittn,
            "ladUseSittnNm": self.ladUseSittnNm,
            "tpgrphHgCode": self.tpgrphHgCode,
            "tpgrphHgCodeNm": self.tpgrphHgCodeNm,
            "tpgrphFrmCode": self.tpgrphFrmCode,
            "tpgrphFrmCodeNm": self.tpgrphFrmCodeNm,
            "roadSideCode": self.roadSideCode,
            "roadSideCodeNm": self.roadSideCodeNm,
            "pblntfPclnd": self.pblntfPclnd,
            "lastUpdtDt": self.lastUpdtDt,
        }
        
    @classmethod
    def create_example(cls) -> "LandCharacteristic":
        """예시 데이터로 LandCharacteristic 인스턴스를 생성합니다."""
        return cls.from_dict(cls.EXAMPLE)
    
    @classmethod
    def from_dict(cls, data: dict) -> "LandCharacteristic":
        return cls(
            pnu=data["pnu"],
            ldCode=data["ldCode"],
            ldCodeNm=data["ldCodeNm"],
            regstrSeCode=data["regstrSeCode"],
            regstrSeCodeNm=data["regstrSeCodeNm"],
            mnnmSlno=data["mnnmSlno"],
            ladSn=data["ladSn"],
            stdrYear=data["stdrYear"],
            stdrMt=data["stdrMt"],
            lndcgrCode=data["lndcgrCode"],
            lndcgrCodeNm=data["lndcgrCodeNm"],
            lndpclAr=data["lndpclAr"],
            prposArea1=data["prposArea1"],
            prposArea1Nm=data["prposArea1Nm"],
            prposArea2=data["prposArea2"],
            prposArea2Nm=data["prposArea2Nm"],
            ladUseSittn=data["ladUseSittn"],
            ladUseSittnNm=data["ladUseSittnNm"],
            tpgrphHgCode=data["tpgrphHgCode"],
            tpgrphHgCodeNm=data["tpgrphHgCodeNm"],
            tpgrphFrmCode=data["tpgrphFrmCode"],
            tpgrphFrmCodeNm=data["tpgrphFrmCodeNm"],
            roadSideCode=data["roadSideCode"],
            roadSideCodeNm=data["roadSideCodeNm"],
            pblntfPclnd=data["pblntfPclnd"],

            lastUpdtDt=data["lastUpdtDt"],
        )