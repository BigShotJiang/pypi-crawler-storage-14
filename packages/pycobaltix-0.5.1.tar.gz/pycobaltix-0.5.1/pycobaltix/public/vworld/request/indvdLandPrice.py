"""
개별공시지가 속성 조회 API Request 모델
"""

from pydantic import BaseModel, Field, field_validator


class IndvdLandPriceRequest(BaseModel):
    """개별공시지가 속성 조회 요청 모델

    개별토지의 단위면적당 가격정보에 대한 속성정보를 조회하는 기능
    """

    pnu: str = Field(
        ..., description="필지고유번호 (19자리)", min_length=19, max_length=19
    )
    stdrYear: str | None = Field(
        None, description="기준연도 (YYYY 형식). None인 경우 최근 데이터 조회"
    )
    numOfRows: int = Field(1000, description="검색건수 (최대 1000)", ge=1, le=1000)
    pageNo: int = Field(1, description="페이지 번호", ge=1)

    @field_validator("stdrYear")
    @classmethod
    def validate_stdr_year(cls, v: str | None) -> str | None:
        """기준연도 형식 검증"""
        if v is not None:
            if not v.isdigit() or len(v) != 4:
                raise ValueError("기준연도는 YYYY 형식의 4자리 숫자여야 합니다")
        return v

    class Config:
        """Pydantic 설정"""

        json_schema_extra = {
            "example": {
                "pnu": "1111010100100010000",
                "stdrYear": "2024",
                "numOfRows": 1000,
                "pageNo": 1,
            }
        }
