"""
건물실명조회 API Request 모델
"""

from pydantic import BaseModel, Field


class BuldRoomCoListRequest(BaseModel):
    """건물실명조회 요청 모델

    대지권이 설정된 토지의 건축물 정보 및 대지에 대한 권리비율, 대지권 말소 정보를 건물 실명 정보를 통해 조회하는 기능
    """

    pnu: str = Field(
        ..., description="필지고유번호 (19자리)", min_length=19, max_length=19
    )
    agbldgSn: str | None = Field(None, description="대지권 일련번호")
    buldDongNm: str | None = Field(None, description="건물동명")
    buldFloorNm: str | None = Field(None, description="건물층명")
    buldHoNm: str | None = Field(None, description="건물호명")
    buldRoomNm: str | None = Field(None, description="건물실명")
    numOfRows: int = Field(100, description="검색건수 (최대 1000)", ge=1, le=1000)
    pageNo: int = Field(1, description="페이지 번호", ge=1)

    class Config:
        """Pydantic 설정"""

        json_schema_extra = {
            "example": {
                "pnu": "1111010100100010000",
                "agbldgSn": "0001",
                "buldDongNm": "1",
                "buldFloorNm": "1",
                "buldHoNm": "111",
                "buldRoomNm": "0000",
                "numOfRows": 10,
                "pageNo": 1,
            }
        }
