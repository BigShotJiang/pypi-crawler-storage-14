"""
공유지연명목록조회 API Request 모델
"""

from pydantic import BaseModel, Field


class ShldgListRequest(BaseModel):
    """공유지연명목록조회 요청 모델

    소유자가 여러명일 경우 소유권 취득 주체에 따라 구분한 정보를 조회하는 기능
    """

    pnu: str = Field(
        ..., description="필지고유번호 (19자리)", min_length=19, max_length=19
    )
    numOfRows: int = Field(100, description="검색건수 (최대 1000)", ge=1, le=1000)
    pageNo: int = Field(1, description="페이지 번호", ge=1)

    class Config:
        """Pydantic 설정"""

        json_schema_extra = {
            "example": {
                "pnu": "1111010100100010000",
                "numOfRows": 10,
                "pageNo": 1,
            }
        }
