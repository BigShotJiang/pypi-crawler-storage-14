import json
import re
from typing import Any, Dict, List

import httpx

from pycobaltix.public.registration.registration import (
    PropertyType,
    RealEstateInfo,
    RegistrationStatus,
)
from pycobaltix.schemas.responses import PaginatedAPIResponse, PaginationInfo

REQUEST_URL = "https://www.iros.go.kr/biz/Pr20ViaRlrgSrchCtrl/retrieveSmplSrchList.do?IS_NMBR_LOGIN__=null"
DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "Content-Type": "application/json; charset=utf-8",
}
DEFAULT_TIMEOUT = 30.0


def clean_html_tags(text: str) -> str:
    """
    HTML 태그를 제거하고 순수한 텍스트만 반환합니다.

    Args:
        text (str): HTML 태그가 포함된 텍스트

    Returns:
        str: HTML 태그가 제거된 깔끔한 텍스트
    """
    if not text:
        return text

    # HTML 태그 제거 (정규식 사용)
    clean_text = re.sub(r"<[^>]+>", "", text)

    # 연속된 공백을 하나로 정리
    clean_text = re.sub(r"\s+", " ", clean_text)

    # 앞뒤 공백 제거
    return clean_text.strip()


def clean_real_estate_data(data: dict) -> dict:
    """
    부동산 데이터에서 HTML 태그를 제거합니다.

    Args:
        data (dict): 원본 부동산 데이터

    Returns:
        dict: HTML 태그가 제거된 부동산 데이터
    """
    # 주소 및 텍스트 관련 필드들에서 HTML 태그 제거 (원본 API 필드명 사용)
    text_fields = [
        "rd_addr_detail",  # full_address
        "rd_addr",  # road_address
        "buld_name",  # building_name
        "real_indi_cont_detail",  # detailed_land_address
        "real_indi_cont",  # land_address
        "addItem",  # additional_info
    ]

    cleaned_data = data.copy()
    for field in text_fields:
        if field in cleaned_data and cleaned_data[field]:
            cleaned_data[field] = clean_html_tags(cleaned_data[field])

    return cleaned_data


def _validate_pagination_params(page: int, page_size: int) -> None:
    """
    페이지네이션 파라미터를 검증하여 잘못된 요청을 사전에 차단합니다.
    """
    if not isinstance(page, int) or not isinstance(page_size, int):
        raise TypeError("page와 page_size는 정수여야 합니다.")
    if page < 1 or page_size < 1:
        raise ValueError("page와 page_size는 1 이상의 정수여야 합니다.")


def _build_request_body(
    keyword: str,
    rgs_rec_stat: RegistrationStatus,
    kind_cls: PropertyType,
    page: int,
    page_size: int,
) -> Dict[str, Any]:
    """
    동기/비동기 공통으로 사용할 요청 바디를 생성합니다.
    """
    if not isinstance(keyword, str):
        raise TypeError("keyword는 문자열이어야 합니다.")

    sanitized_keyword = keyword.strip()
    if not sanitized_keyword:
        raise ValueError("keyword는 공백이 아닌 문자열이어야 합니다.")

    _validate_pagination_params(page, page_size)

    return {
        "websquare_param": {
            "conn_menu_cls_cd": "01",
            "prgs_mode_cls_cd": "01",
            "inet_srch_cls_cd": "PR01",
            "prgs_stg_cd": "",
            "move_cls": "",
            "swrd": sanitized_keyword,
            "addr_cls": "3",
            "kind_cls": kind_cls.value,
            "land_bing_yn": "",
            "rgs_rec_stat": rgs_rec_stat.value,
            "admin_regn1": "all",
            "admin_regn2": "",
            "admin_regn3": "",
            "lot_no": "",
            "buld_name": "",
            "buld_no_buld": "",
            "buld_no_room": "",
            "rd_name": "",
            "rd_buld_no": "",
            "rd_buld_no2": "",
            "issue_cls": "5",
            "pageIndex": page,
            "pageUnit": page_size,
            "cmort_flag": "",
            "kap_seq_flag": "",
            "trade_seq_flag": "",
            "etdoc_sel_yn": "",
            "show_cls": "",
            "real_pin_con": "",
            "svc_cls_con": "",
            "item_cls_con": "",
            "judge_enr_cls_con": "",
            "cmort_cls_con": "",
            "trade_cls_con": "",
            "extend_srch": "",
            "usg_cls_con": "",
        }
    }


def _encode_request_payload(body: Dict[str, Any]) -> bytes:
    """
    요청 바디를 UTF-8 바이트로 직렬화합니다.
    """
    return json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _empty_paginated_response(
    error_message: str = "",
) -> PaginatedAPIResponse[RealEstateInfo]:
    """
    오류 발생 시에도 일관된 응답 형식을 제공하기 위한 헬퍼입니다.
    """
    if error_message:
        print(error_message)

    return PaginatedAPIResponse(
        data=[],
        pagination=PaginationInfo(
            currentPage=0,
            totalPages=0,
            totalCount=0,
            count=0,
            hasNext=False,
            hasPrevious=False,
        ),
    )


def _parse_paginated_response(
    json_response: Any,
) -> PaginatedAPIResponse[RealEstateInfo]:
    """
    API 응답(JSON)을 PaginatedAPIResponse 형태로 변환합니다.
    """
    if not isinstance(json_response, dict):
        raise ValueError("API 응답이 올바른 JSON 객체 형식이 아닙니다.")

    pagination_data = json_response.get("paginationInfo", {}) or {}
    real_estate_data = json_response.get("dataList", []) or []

    if not isinstance(pagination_data, dict) or not isinstance(real_estate_data, list):
        raise ValueError("API 응답 구조가 예상과 다릅니다.")

    real_estate_items: List[RealEstateInfo] = [
        RealEstateInfo.model_validate(clean_real_estate_data(item))
        for item in real_estate_data
        if isinstance(item, dict)
    ]

    pagination = PaginationInfo(
        currentPage=pagination_data.get("currentPageNo", 1),
        totalPages=pagination_data.get("totalPageCount", 1),
        totalCount=pagination_data.get("totalRecordCount", 0),
        count=pagination_data.get("recordCountPerPage", 10),
        hasNext=pagination_data.get("lastPageNoOnPageList", 1)
        > pagination_data.get("currentPageNo", 1),
        hasPrevious=pagination_data.get("firstPageNoOnPageList", 1)
        < pagination_data.get("currentPageNo", 1),
    )

    return PaginatedAPIResponse(data=real_estate_items, pagination=pagination)


def search_real_estate(
    keyword: str,
    rgs_rec_stat: RegistrationStatus = RegistrationStatus.CURRENT,
    kind_cls: PropertyType = PropertyType.ALL,
    page: int = 1,
    page_size: int = 10,
) -> PaginatedAPIResponse[RealEstateInfo]:
    """
    부동산 등기 정보 검색 API에 요청을 보내고 결과를 PaginatedAPIResponse 객체로 직접 파싱하여 반환합니다.

    Args:
        keyword (str): 검색할 주소 또는 키워드.

    Returns:
        PaginatedAPIResponse[RealEstateInfo]: API 응답을 파싱한 PaginatedAPIResponse 객체.
    """
    request_body = _build_request_body(
        keyword=keyword,
        rgs_rec_stat=rgs_rec_stat,
        kind_cls=kind_cls,
        page=page,
        page_size=page_size,
    )
    encoded_body = _encode_request_payload(request_body)

    try:
        # 동기 httpx 클라이언트로 API 호출을 수행
        with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
            response = client.post(
                REQUEST_URL, headers=DEFAULT_HEADERS, content=encoded_body
            )
            response.raise_for_status()

            # 공통 파서로 결과를 변환
            return _parse_paginated_response(response.json())
    except (httpx.HTTPError, ValueError) as exc:
        return _empty_paginated_response(f"부동산 검색 중 오류가 발생했습니다: {exc}")


async def async_search_real_estate(
    keyword: str,
    rgs_rec_stat: RegistrationStatus = RegistrationStatus.CURRENT,
    kind_cls: PropertyType = PropertyType.ALL,
    page: int = 1,
    page_size: int = 10,
) -> PaginatedAPIResponse[RealEstateInfo]:
    """
    부동산 등기 정보 검색 API에 비동기로 요청을 보냅니다.
    """
    request_body = _build_request_body(
        keyword=keyword,
        rgs_rec_stat=rgs_rec_stat,
        kind_cls=kind_cls,
        page=page,
        page_size=page_size,
    )
    encoded_body = _encode_request_payload(request_body)

    try:
        # 비동기 httpx 클라이언트로 API 호출 수행
        async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
            response = await client.post(
                REQUEST_URL, headers=DEFAULT_HEADERS, content=encoded_body
            )
            response.raise_for_status()

            # 공통 파서로 결과 변환
            return _parse_paginated_response(response.json())
    except (httpx.HTTPError, ValueError) as exc:
        return _empty_paginated_response(
            f"비동기 부동산 검색 중 오류가 발생했습니다: {exc}"
        )


if __name__ == "__main__":
    search_result: PaginatedAPIResponse[RealEstateInfo] = search_real_estate(
        "능동 242-21 ", page_size=100
    )
    if search_result:
        print("Request successful!")
        # 새로운 직관적인 필드명으로 데이터에 접근
        if search_result.data:
            for item in search_result.data:
                print(item.model_dump_json(indent=4, by_alias=True))
        else:
            print("No real estate data found.")
