﻿def check():
    msg = "[Integrity] Does this system operate consistently with moral and organizational values?"
    print(msg)
    return msg
