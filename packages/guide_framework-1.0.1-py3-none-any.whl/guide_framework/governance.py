﻿def check():
    msg = "[Governance] Who is accountable for this system's outcomes?"
    print(msg)
    return msg
