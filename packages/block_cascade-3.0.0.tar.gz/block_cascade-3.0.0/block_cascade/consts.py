SERVICE = "aiplatform.googleapis.com"
