"""Internal registry for ToolsService instances."""

services = []
