from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class AssignmentStrategy(StrEnum):
    """Assignment strategy types."""

    ROUND_ROBIN = "ROUND_ROBIN"


class AssignmentRoom(BaseModel):
    """Scope identifier for assignment configuration, rooms and logs."""

    company_id: str = Field(alias="companyId")
    funnel_id: Optional[str] = Field(default=None, alias="funnelId")
    area_id: Optional[str] = Field(default=None, alias="areaId")
    strategy: AssignmentStrategy = Field(default=AssignmentStrategy.ROUND_ROBIN)
    state: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(populate_by_name=True)

    """ 
    Su area o funnel son "null" la busqueda en mongo deberia buscar tambien que no existan como campos
     """
    def to_filter(self) -> Dict[str, Optional[str]]:
        """Return a Mongo-friendly filter for this room scope."""
        return {
            "companyId": self.company_id,
            "funnelId": self.funnel_id,
            "areaId": self.area_id,
        }


class AssignmentStrategyConfig(BaseModel):
    """Strategy selected for a room."""

    name: AssignmentStrategy = Field(default=AssignmentStrategy.ROUND_ROBIN)
    params: Dict[str, Any] = Field(default_factory=dict)


class AssignmentConfig(BaseModel):
    """Assignment configuration document stored in MongoDB."""

    company_id: str = Field(alias="companyId")
    funnel_id: Optional[str] = Field(default=None, alias="funnelId")
    area_id: Optional[str] = Field(default=None, alias="areaId")
    strategy: AssignmentStrategy = Field(default=AssignmentStrategy.ROUND_ROBIN)
    params: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(populate_by_name=True)

    @property
    def room(self) -> AssignmentRoom:
        return AssignmentRoom(
            company_id=self.company_id,
            funnel_id=self.funnel_id,
            area_id=self.area_id,
        )

    def strategy_config(self) -> AssignmentStrategyConfig:
        return AssignmentStrategyConfig(name=self.strategy, params=self.params or {})


class AssignmentLogEntry(BaseModel):
    """Immutable record inserted into assignment_log."""

    company_id: str = Field(alias="companyId")
    chat_id: str = Field(alias="chatId")
    agent_id: str = Field(alias="agentId")
    strategy: AssignmentStrategy
    room: AssignmentRoom

    model_config = ConfigDict(populate_by_name=True)
