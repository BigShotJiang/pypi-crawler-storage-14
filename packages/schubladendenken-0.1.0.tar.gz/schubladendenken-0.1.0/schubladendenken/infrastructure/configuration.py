from abc import ABC, abstractmethod
from os import environ
from pathlib import Path

from yaml import safe_load

from schubladendenken.core.label import LabelRepository
from schubladendenken.core.subject import SubjectRepository, Subject
from schubladendenken.core.types import JSONType
from schubladendenken.external_server.label.database import DatabaseLabelRepository
from schubladendenken.external_server.subject.contained import ContainedSubject
from schubladendenken.external_server.subject.database import DatabaseSubjectRepository

_DEFAULT_LABEL_REPO_TYPE_MAP: dict[str, type[LabelRepository]] = {"database": DatabaseLabelRepository}
_DEFAULT_SUBJECT_REPO_TYPE_MAP: dict[str, type[SubjectRepository]] = {"database": DatabaseSubjectRepository}
_CONFIG_FILE_PATH_ENV_VAR: str = "SCHUBLADENDENKEN_CONFIG_FILE_PATH"

class ConfigurationParser(ABC):
    def __init__(
            self,
            label_repo_type_map: dict[str, type[LabelRepository]],
            subject_repo_type_map: dict[str, type[SubjectRepository]],
            subject_type: type[Subject] = ContainedSubject
    ):
        self._label_repo_type_map: dict[str, type[LabelRepository]] = label_repo_type_map
        self._subject_repo_type_map: dict[str, type[SubjectRepository]] = subject_repo_type_map
        self._subject_type: type[Subject] = subject_type

    def label_repo(self) -> LabelRepository:
        """

        Returns:

        """
        match self._get_config_entry("label_repository"):
            case {"type": str(type_), "config": {**config}}:
                if type_ in self._label_repo_type_map:
                    return self._label_repo_type_map[type_].from_dict(config)
                else:
                    raise LookupError(f"No label repository type {type_} found")
            case other:
                    raise ValueError(f"Invalid label repository config {other}")

    def subject_repo(self) -> SubjectRepository:
        """

        Returns:

        """
        match self._get_config_entry("subject_repository"):
            case {"type": str(type_), "config": {**config}}:
                if type_ in self._subject_repo_type_map:
                    return self._subject_repo_type_map[type_].from_dict(config, self.label_repo())
                else:
                    raise LookupError(f"No subject repository type {type_} found")
            case other:
                    raise ValueError(f"Invalid subject repository config {other}")


    @property
    def subject_type(self) -> type[Subject]:
        return self._subject_type

    @abstractmethod
    def _get_config_entry(self, name: str) -> dict[str, JSONType] | None:
        """

        Args:
            name:

        Returns:

        """


class ConfigFileParser(ConfigurationParser):
    def __init__(
        self,
        config_file_path: str | None = None,
        label_repo_type_map: dict[str, type[LabelRepository]] | None = None,
        subject_repo_type_map: dict[str, type[SubjectRepository]] | None = None
    ):
        super().__init__(
            label_repo_type_map or _DEFAULT_LABEL_REPO_TYPE_MAP,
            subject_repo_type_map or _DEFAULT_SUBJECT_REPO_TYPE_MAP,
            ContainedSubject
        )
        self._config_file_path: Path = Path(
            config_file_path or environ.get("_CONFIG_FILE_PATH_ENV_VAR", "schubladendenken.yaml")
        )
        self._config_data: JSONType = safe_load(self._config_file_path.read_text(encoding="utf-8"))

    def _get_config_entry(self, name: str) -> dict[str, JSONType] | None:
        return self._config_data.get(name)



