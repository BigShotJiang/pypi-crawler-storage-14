"""Kirby client for provider-based API calls."""

import logging
from typing import Any, Optional

import requests
from minijinja import Environment
from openai import OpenAI

logger = logging.getLogger(__name__)


class Kirby:
    """Client for making provider-based API calls."""

    def __init__(
        self,
        provider: str,
        key: str,
        model: str,
        kirby_url: Optional[str] = None,
        kirby_user_id: Optional[str] = None,
    ):
        """Initialize the Kirby client.

        Args:
            provider: The provider name (e.g., 'openAI')
            key: The API key for the provider
            model: The model name to use
            kirby_url: The base URL for the Kirby API (can also be set via KIRBY_URL env var)
            kirby_user_id: The user ID for Kirby API (can also be set via KIRBY_USER_ID env var)
        """
        self.provider = provider
        self.key = key
        self.model = model
        self.kirby_url = kirby_url
        self.kirby_user_id = kirby_user_id

    def call(self, method_name: str, **kwargs: Any) -> Any:
        """Call a method with the given arguments.

        Args:
            method_name: The name of the method to call
            **kwargs: Keyword arguments to pass to the method

        Returns:
            The result of the OpenAI API call

        Raises:
            ValueError: If KIRBY_URL or KIRBY_USER_ID is not set, or if no prompt is found
        """
        import os

        # Get kirby_url and kirby_user_id from instance or environment
        kirby_url = self.kirby_url or os.getenv("KIRBY_URL")
        kirby_user_id = self.kirby_user_id or os.getenv("KIRBY_USER_ID")

        if not kirby_url:
            raise ValueError(
                "KIRBY_URL must be provided or set as environment variable"
            )
        if not kirby_user_id:
            raise ValueError(
                "KIRBY_USER_ID must be provided or set as environment variable"
            )

        # Call find_or_create endpoint
        url = f"{kirby_url}/api/functions/find_or_create"
        payload = {
            "userId": kirby_user_id,
            "name": method_name,
            "variables": kwargs,
        }

        try:
            response = requests.post(
                url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=30,
            )
            response.raise_for_status()
            function_result = response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error calling Kirby endpoint: {e}")
            if hasattr(e, "response") and e.response is not None:
                logger.error(f"Response status: {e.response.status_code}")
                logger.error(f"Response body: {e.response.text}")
            raise

        # Check if we have a version prompt
        version_prompt = function_result.get("versionPrompt")
        function_id = function_result.get("id")

        if not version_prompt:
            # Build the function URL
            function_url = f"{kirby_url}/functions/{function_id}" if function_id else kirby_url
            raise ValueError(
                f"No prompt found for this function. Please add a prompt at: {function_url}"
            )

        # Get variables from the function result metadata and merge with kwargs
        variables = function_result.get("metadata", {}).get("initialVariables", {})
        # Merge with kwargs passed to the function
        variables.update(kwargs)

        # Template the prompt using minijinja
        env = Environment()
        templated_prompt = env.render_str(version_prompt, **variables)
        logger.info(f"Templated prompt: {templated_prompt}")

        # Call OpenAI with the templated prompt
        openai_client = OpenAI(api_key=self.key)
        completion = openai_client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": templated_prompt}],
        )

        result = completion.choices[0].message.content

        # Create trace with the result
        function_version_id = function_result.get("versionId")
        if function_version_id:
            trace_url = f"{kirby_url}/api/functions/{function_id}/traces"
            trace_payload = {
                "functionVersionId": function_version_id,
                "result": result,
                "variables": variables,
                "provider": self.provider.lower(),
                "model": completion.model,
                "usage": (
                    completion.usage.model_dump()
                    if hasattr(completion.usage, "model_dump")
                    else (
                        {
                            "prompt_tokens": getattr(
                                completion.usage, "prompt_tokens", 0
                            ),
                            "completion_tokens": getattr(
                                completion.usage, "completion_tokens", 0
                            ),
                            "total_tokens": getattr(
                                completion.usage, "total_tokens", 0
                            ),
                        }
                        if completion.usage
                        else {}
                    )
                ),
            }

            try:
                trace_response = requests.post(
                    trace_url,
                    json=trace_payload,
                    headers={"Content-Type": "application/json"},
                    timeout=30,
                )
                trace_response.raise_for_status()
                logger.info(f"Trace created: {trace_response.json().get('id')}")
            except requests.exceptions.RequestException as e:
                logger.warning(f"Failed to create trace: {e}")
                # Don't fail the whole function call if trace creation fails

        return result
