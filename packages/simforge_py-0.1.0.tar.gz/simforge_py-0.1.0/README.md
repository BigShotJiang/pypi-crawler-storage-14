# Kirby

Kirby client for provider-based API calls.

## Installation

For local development:

```bash
cd kirby
poetry install
```

Or install as an editable package from the parent directory:

```bash
poetry add --editable ../kirby
```

## Usage

```python
from kirby import Kirby

client = Kirby(
    provider="openAI",
    key="your-api-key",
    model="gpt-4",
    kirby_url="https://your-kirby-instance.com",  # Optional, can use KIRBY_URL env var
    kirby_user_id="user-id",  # Optional, can use KIRBY_USER_ID env var
)

result = client.call("method_name", arg1="value1", arg2="value2")
```

## Configuration

The `kirby_url` and `kirby_user_id` can be provided either:
- As constructor arguments
- As environment variables (`KIRBY_URL` and `KIRBY_USER_ID`)
