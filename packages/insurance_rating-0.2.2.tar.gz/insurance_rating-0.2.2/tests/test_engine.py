# tests/test_engine.py
import pytest
from rating_pkg.engine import RatingEngine

def test_minimum_premium_enforced():
    engine = RatingEngine()
    assert engine.calculate_premium({}) >= 200

def test_young_driver_high_risk():
    engine = RatingEngine()
    data = {
        "age": 22,
        "years_licensed": 1,
        "ncb_years": 0,
        "cover_type": "COMP",
        "vehicle_year": 2000,
        "engine_band": "large",
        "value_band": "high",
        "annual_mileage": "high",
        "primary_use": "business",
        "anti_theft": False,
        "eircode_risk": "high",
        "overnight_parking": "street",
        "named_drivers": 2,
    }
    premium = engine.calculate_premium(data)
    assert premium > 1000  # sanity check for a high-risk profile

def test_tpft_and_garage_discount():
    engine = RatingEngine()
    data = {
        "cover_type": "TPFT",
        "anti_theft": True,
        "overnight_parking": "garage",
        "ncb_years": 5,
    }
    premium = engine.calculate_premium(data)
    assert premium < 500