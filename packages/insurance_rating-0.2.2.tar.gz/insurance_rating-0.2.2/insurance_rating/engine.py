from dataclasses import dataclass
from typing import Optional

@dataclass
class RatingConfig:
    base_premium: float = 500.0
    min_premium: float = 200.0

class RatingEngine:
    def __init__(self, config: Optional[RatingConfig] = None):
        self.config = config or RatingConfig()

    def calculate_premium(self, data: dict) -> float:
        premium = self.config.base_premium

        # Driver age
        age = int(data.get("age", 30))
        if age < 25:
            premium += 200
        elif age > 70:
            premium += 150

        # Years licensed
        years_licensed = int(data.get("years_licensed", 5))
        if years_licensed < 2:
            premium += 100

        # No claims bonus
        ncb_years = int(data.get("ncb_years", 0))
        premium -= ncb_years * 20

        # Cover type
        if data.get("cover_type", "COMP") == "TPFT":
            premium -= 50

        # Vehicle year
        vehicle_year = int(data.get("vehicle_year", 2015))
        if vehicle_year < 2005:
            premium += 100

        # Engine band
        if data.get("engine_band", "mid") == "large":
            premium += 150

        # Value band
        if data.get("value_band", "mid") == "high":
            premium += 100

        # Annual mileage
        if data.get("annual_mileage", "mid") == "high":
            premium += 75

        # Primary use
        if data.get("primary_use", "social") == "business":
            premium += 100

        # Anti-theft device
        if data.get("anti_theft", False):
            premium -= 50

        # Eircode risk
        risk = data.get("eircode_risk", "mid")
        if risk == "high":
            premium += 200
        elif risk == "low":
            premium -= 50

        # Overnight parking
        parking = data.get("overnight_parking", "street")
        if parking == "garage":
            premium -= 75
        elif parking == "driveway":
            premium -= 25

        # Named drivers
        premium += int(data.get("named_drivers", 0)) * 50

        return max(premium, self.config.min_premium)