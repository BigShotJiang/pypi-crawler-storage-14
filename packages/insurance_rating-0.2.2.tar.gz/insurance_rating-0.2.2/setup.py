import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="insurance-rating",              # unique package name
    version="0.2.2",                      # start small, bump with changes
    author="Gaurav Avinash Pandit",
    author_email="gauravpandit1998@gmail.com",
    description="A simple motor insurance rating engine",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/gpanda98/insurance-rating.git",  # update with repo URL
    packages=setuptools.find_packages(),
    install_requires=[],                  # add dependencies if needed
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9',
)
