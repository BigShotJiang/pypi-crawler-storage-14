# django_core_micha/auth/permissions.py
from rest_framework import permissions
from django.conf import settings


class IsInviteAdminOrSuperuser(permissions.BasePermission):
    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if user.is_superuser:
            return True

        profile = getattr(user, "profile", None)
        allowed = getattr(settings, "INVITE_ADMIN_ROLES", ("admin", "supervisor"))
        return bool(profile and getattr(profile, "role", None) in allowed)
