# django_core_micha/auth/views.py
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie


@ensure_csrf_cookie
def csrf_token_view(request):
    """
    Simple endpoint to set the CSRF cookie for frontend clients.
    Used by ui_core_micha (CSRF_URL = '/api/csrf/').
    """
    return JsonResponse({"detail": "CSRF cookie set"})
