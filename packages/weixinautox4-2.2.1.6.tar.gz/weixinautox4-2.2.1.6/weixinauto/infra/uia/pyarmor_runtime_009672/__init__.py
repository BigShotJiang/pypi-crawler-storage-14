# Pyarmor 9.2.0 (basic), 009672, 2025-12-02T00:09:17.489616
from .pyarmor_runtime import __pyarmor__
