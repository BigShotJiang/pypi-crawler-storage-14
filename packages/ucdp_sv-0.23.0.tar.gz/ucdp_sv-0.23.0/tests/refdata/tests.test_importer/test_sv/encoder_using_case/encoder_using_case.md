Port(UintType(4), 'binary_out', direction=OUT)
Port(UintType(16), 'encoder_in', direction=IN)
Port(BitType(), 'enable', direction=IN)
