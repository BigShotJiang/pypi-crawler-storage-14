Port(UintType(8), 'out', direction=OUT)
Port(BitType(), 'up_down', direction=IN)
Port(BitType(), 'clk', direction=IN)
Port(BitType(), 'reset', direction=IN)
