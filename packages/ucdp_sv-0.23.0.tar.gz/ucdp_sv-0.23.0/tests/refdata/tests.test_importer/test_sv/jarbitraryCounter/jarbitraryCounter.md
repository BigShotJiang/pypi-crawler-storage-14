Port(UintType(3), 'OUTPUT', direction=OUT)
Port(BitType(), 'clock', direction=IN)
Port(BitType(), 'reset', direction=IN)
