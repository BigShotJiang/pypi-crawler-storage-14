import sys
from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET
from docx import Document
from docx.text.paragraph import Paragraph as _Paragraph
from docx.table import Table as _Table
from docx.enum.text import WD_ALIGN_PARAGRAPH
import json

NS_W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
NS_REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
NS_A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
NS_WP = '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}'
NS_PKG = '{http://schemas.openxmlformats.org/package/2006/relationships}'
NS_VML = '{urn:schemas-microsoft-com:vml}'

def _resolve_target(target: str) -> str:
    t = (target or '').replace('\\','/').lstrip('/')
    if t.startswith('../'):
        return 'word/' + t[3:]
    if t.startswith('word/'):
        return t
    if t.startswith('media/'):
        return 'word/' + t
    return 'word/' + t

def _get_core_properties(doc: Document):
    cp = doc.core_properties
    return {
        'author': cp.author or '',
        'title': cp.title or '',
        'last_modified_by': cp.last_modified_by or '',
        'created': cp.created.isoformat() if cp.created else '',
        'modified': cp.modified.isoformat() if cp.modified else '',
    }

def _get_app_pages(docx_path: Path):
    try:
        with zipfile.ZipFile(str(docx_path), 'r') as z:
            app_xml = z.read('docProps/app.xml')
        root = ET.fromstring(app_xml)
        ns = '{http://schemas.openxmlformats.org/officeDocument/2006/extended-properties}'
        el = root.find('.//' + ns + 'Pages')
        return int(el.text) if el is not None and el.text and el.text.isdigit() else None
    except Exception:
        return None

def _align_str(a):
    if a == WD_ALIGN_PARAGRAPH.CENTER:
        return 'center'
    if a == WD_ALIGN_PARAGRAPH.RIGHT:
        return 'right'
    if a == WD_ALIGN_PARAGRAPH.LEFT:
        return 'left'
    if a == WD_ALIGN_PARAGRAPH.JUSTIFY:
        return 'justify'
    return 'default'

def _len_pt(x):
    try:
        return round(x.pt, 2)
    except Exception:
        return None

def _collect_image_order(docx_path: Path):
    with zipfile.ZipFile(str(docx_path), 'r') as z:
        body_xml = z.read('word/document.xml')
        rels_xml = z.read('word/_rels/document.xml.rels')
    root = ET.fromstring(body_xml)
    rels = ET.fromstring(rels_xml)
    rid_to_target = {}
    rid_to_external = {}
    header_ids = []
    footer_ids = []
    footnote_ids = []
    endnote_ids = []
    comment_ids = []
    for r in rels.findall('.//' + NS_PKG + 'Relationship'):
        rid = r.attrib.get('Id')
        tgt = r.attrib.get('Target')
        mode = r.attrib.get('TargetMode')
        typ = r.attrib.get('Type')
        if rid and tgt:
            if mode is None or mode != 'External':
                rid_to_target[rid] = tgt
            else:
                rid_to_external[rid] = tgt
            if typ and typ.endswith('/header'):
                header_ids.append((rid, tgt))
            elif typ and typ.endswith('/footer'):
                footer_ids.append((rid, tgt))
            elif typ and typ.endswith('/footnotes'):
                footnote_ids.append((rid, tgt))
            elif typ and typ.endswith('/endnotes'):
                endnote_ids.append((rid, tgt))
            elif typ and typ.endswith('/comments'):
                comment_ids.append((rid, tgt))
    body_order = []
    body_external = []
    # drawingML in body
    for blip in root.findall('.//' + NS_A + 'blip'):
        rid = blip.attrib.get(NS_REL + 'embed')
        if rid and rid in rid_to_target:
            body_order.append((rid, rid_to_target[rid]))
        rlink = blip.attrib.get(NS_REL + 'link')
        if rlink and rlink in rid_to_external:
            body_external.append(('body', rid_to_external[rlink]))
    # VML fallback in body
    for vimg in root.findall('.//' + NS_VML + 'imagedata'):
        rid = vimg.attrib.get(NS_REL + 'id')
        if rid and rid in rid_to_target:
            body_order.append((rid, rid_to_target[rid]))
        rlink = vimg.attrib.get(NS_REL + 'id')
        if rlink and rlink in rid_to_external:
            body_external.append(('body', rid_to_external[rlink]))

    def _collect_from_part(docx_path: Path, part_rel_target: str):
        with zipfile.ZipFile(str(docx_path), 'r') as z:
            part_xml = z.read(_resolve_target(part_rel_target))
            # header1.xml -> word/_rels/header1.xml.rels
            rels_name = 'word/_rels/' + Path(part_rel_target).name + '.rels'
            try:
                rels_xml_local = z.read(rels_name)
            except KeyError:
                rels_xml_local = b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'
        root_local = ET.fromstring(part_xml)
        rels_local = ET.fromstring(rels_xml_local)
        rid2t = {}
        rid2ext = {}
        for r in rels_local.findall('.//' + NS_PKG + 'Relationship'):
            rid = r.attrib.get('Id')
            tgt = r.attrib.get('Target')
            mode = r.attrib.get('TargetMode')
            if rid and tgt:
                if mode is None or mode != 'External':
                    rid2t[rid] = tgt
                else:
                    rid2ext[rid] = tgt
        out = []
        out_ext = []
        for blip in root_local.findall('.//' + NS_A + 'blip'):
            rid = blip.attrib.get(NS_REL + 'embed')
            if rid and rid in rid2t:
                out.append((rid, rid2t[rid]))
            rlink = blip.attrib.get(NS_REL + 'link')
            if rlink and rlink in rid2ext:
                out_ext.append(rid2ext[rlink])
        for vimg in root_local.findall('.//' + NS_VML + 'imagedata'):
            rid = vimg.attrib.get(NS_REL + 'id')
            if rid and rid in rid2t:
                out.append((rid, rid2t[rid]))
            if rid and rid in rid2ext:
                out_ext.append(rid2ext[rid])
        return out, out_ext

    header_order = []
    header_external = []
    for _, tgt in header_ids:
        o, oe = _collect_from_part(docx_path, tgt)
        header_order.extend(o)
        header_external.extend(oe)
    footer_order = []
    footer_external = []
    for _, tgt in footer_ids:
        o, oe = _collect_from_part(docx_path, tgt)
        footer_order.extend(o)
        footer_external.extend(oe)
    footnote_order = []
    footnote_external = []
    for _, tgt in footnote_ids:
        o, oe = _collect_from_part(docx_path, tgt)
        footnote_order.extend(o)
        footnote_external.extend(oe)
    endnote_order = []
    endnote_external = []
    for _, tgt in endnote_ids:
        o, oe = _collect_from_part(docx_path, tgt)
        endnote_order.extend(o)
        endnote_external.extend(oe)
    comment_order = []
    comment_external = []
    for _, tgt in comment_ids:
        o, oe = _collect_from_part(docx_path, tgt)
        comment_order.extend(o)
        comment_external.extend(oe)
    # deduplicate by resolved target path to avoid DrawingML/VML重复
    def _uniq(order):
        by_target = {}
        for rid, tgt in order:
            key = _resolve_target(tgt)
            if key not in by_target:
                by_target[key] = (rid, tgt)
        return list(by_target.values())

    body_order = _uniq(body_order)
    header_order = _uniq(header_order)
    footer_order = _uniq(footer_order)
    # footnote/endnote/comment dedup will be applied after collection below

    externals = (
        body_external
        + [('header', u) for u in header_external]
        + [('footer', u) for u in footer_external]
        + [('footnote', u) for u in footnote_external]
        + [('endnote', u) for u in endnote_external]
        + [('comment', u) for u in comment_external]
    )
    footnote_order = _uniq(footnote_order)
    endnote_order = _uniq(endnote_order)
    comment_order = _uniq(comment_order)
    return body_order, header_order, footer_order, footnote_order, endnote_order, comment_order, externals

def _extract_images_zip(docx_path: Path, out_zip: Path, body_order, header_order, footer_order, footnote_order, endnote_order, comment_order, externals, positions=None, para_formats=None):
    with zipfile.ZipFile(str(docx_path), 'r') as z, zipfile.ZipFile(str(out_zip), 'w', compression=zipfile.ZIP_DEFLATED) as zout:
        # body images
        for idx, ((_, target)) in enumerate(body_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'body/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # header images
        for idx, ((_, target)) in enumerate(header_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'header/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # footer images
        for idx, ((_, target)) in enumerate(footer_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'footer/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # footnote images
        for idx, ((_, target)) in enumerate(footnote_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'footnote/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # endnote images
        for idx, ((_, target)) in enumerate(endnote_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'endnote/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # comment images
        for idx, ((_, target)) in enumerate(comment_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'comment/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # manifest
        manifest = {
            'body': [f'body/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, ((_, t)) in enumerate(body_order)],
            'header': [f'header/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, ((_, t)) in enumerate(header_order)],
            'footer': [f'footer/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, ((_, t)) in enumerate(footer_order)],
            'footnote': [f'footnote/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, ((_, t)) in enumerate(footnote_order)],
            'endnote': [f'endnote/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, ((_, t)) in enumerate(endnote_order)],
            'comment': [f'comment/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, ((_, t)) in enumerate(comment_order)],
            'external': [{'section': sec, 'url': url} for (sec, url) in externals],
            'positions': positions or [],
            'paragraph_formats': para_formats or [],
        }
        zout.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))

def _paragraph_to_md(p: _Paragraph):
    txt = p.text or ''
    name = (p.style.name if p.style else '') or ''
    if name.startswith('Heading'):
        try:
            lvl = int(name.split()[-1])
        except Exception:
            lvl = 1
        return '#' * max(1, min(6, lvl)) + ' ' + txt.strip()
    if 'List Bullet' in name:
        return '- ' + txt.strip()
    if 'List Number' in name:
        return '1. ' + txt.strip()
    return txt

def _table_to_md(t: _Table):
    rows = [[c.text.replace('\n', ' ').strip() for c in row.cells] for row in t.rows]
    if not rows:
        return []
    header = rows[0]
    body = rows[1:] if len(rows) > 1 else []
    # alignment per column based on first row cells
    aligns = []
    for idx, c in enumerate(t.rows[0].cells):
        try:
            a = c.paragraphs[0].alignment
        except Exception:
            a = None
        if a == WD_ALIGN_PARAGRAPH.CENTER:
            aligns.append(':---:')
        elif a == WD_ALIGN_PARAGRAPH.RIGHT:
            aligns.append('---:')
        elif a == WD_ALIGN_PARAGRAPH.LEFT:
            aligns.append(':---')
        else:
            aligns.append('---')
    out = [
        '| ' + ' | '.join(header) + ' |',
        '| ' + ' | '.join(aligns) + ' |',
    ]
    for r in body:
        out.append('| ' + ' | '.join(r) + ' |')
    return out

def convert_docx_to_md(docx_path: Path, out_md: Path, strict: bool = False, fail_log=None, visual_order: str = 'off', keep_duplicates: bool = False, visual_debug=None):
    errors = []
    doc = Document(str(docx_path))
    md_lines = []
    seen_lines = set()
    def _append_line(line: str):
        s = (line or '').strip()
        if not s:
            return
        if (not keep_duplicates) and (s in seen_lines):
            return
        j = len(md_lines) - 1
        while j >= 0 and (md_lines[j] or '').strip() == '':
            j -= 1
        if j >= 0 and md_lines[j].strip() == s:
            return
        md_lines.append(s)
        md_lines.append('')
        if not keep_duplicates:
            seen_lines.add(s)
    # collect images first for indexing and header/footer listing
    try:
        body_order, header_order, footer_order, footnote_order, endnote_order, comment_order, externals = _collect_image_order(docx_path)
    except Exception as e:
        if strict:
            raise
        errors.append(f'collect_image_order: {type(e).__name__}: {e}')
        body_order, header_order, footer_order, footnote_order, endnote_order, comment_order, externals = ([], [], [], [], [], [], [])
    body_rid_to_target = {rid: tgt for rid, tgt in body_order}
    body_rid_to_index = {rid: idx for idx, (rid, _) in enumerate(body_order, start=1)}
    pos_lines = []
    props = _get_core_properties(doc)
    try:
        pages = _get_app_pages(docx_path)
    except Exception as e:
        if strict:
            raise
        errors.append(f'get_app_pages: {type(e).__name__}: {e}')
        pages = None
    if props.get('title') or props.get('author') or pages is not None:
        md_lines.append('文档属性:')
        if props.get('title'):
            md_lines.append(f'- 标题: {props["title"]}')
        if props.get('author'):
            md_lines.append(f'- 作者: {props["author"]}')
        if pages is not None:
            md_lines.append(f'- 页数: {pages}')
        if props.get('created'):
            md_lines.append(f'- 创建时间: {props["created"]}')
        if props.get('modified'):
            md_lines.append(f'- 修改时间: {props["modified"]}')
    if header_order:
        md_lines.append('页首图片位置:')
        for i, (_, t) in enumerate(header_order, start=1):
            ext = Path(t).suffix.lower() or '.bin'
            md_lines.append(f'- 页首-图{i}: header/image_{i:03d}{ext}')
    if footer_order:
        md_lines.append('页尾图片位置:')
        for i, (_, t) in enumerate(footer_order, start=1):
            ext = Path(t).suffix.lower() or '.bin'
            md_lines.append(f'- 页尾-图{i}: footer/image_{i:03d}{ext}')
    if footnote_order:
        md_lines.append('脚注图片位置:')
        for i, (_, t) in enumerate(footnote_order, start=1):
            ext = Path(t).suffix.lower() or '.bin'
            md_lines.append(f'- 脚注-图{i}: footnote/image_{i:03d}{ext}')
    if endnote_order:
        md_lines.append('尾注图片位置:')
        for i, (_, t) in enumerate(endnote_order, start=1):
            ext = Path(t).suffix.lower() or '.bin'
            md_lines.append(f'- 尾注-图{i}: endnote/image_{i:03d}{ext}')
    if comment_order:
        md_lines.append('批注图片位置:')
        for i, (_, t) in enumerate(comment_order, start=1):
            ext = Path(t).suffix.lower() or '.bin'
            md_lines.append(f'- 批注-图{i}: comment/image_{i:03d}{ext}')
    # collect positions of body images by paragraph index
    para_idx = 0
    positions_struct = []
    body = doc.element.body
    for child in body.iterchildren():
        tag = child.tag
        if tag == NS_W + 'p':
            para_idx += 1
            ptext = ''
            try:
                ptext = _Paragraph(child, doc).text or ''
            except Exception:
                ptext = ''
            snippet = ptext.strip().replace('\n',' ')[:30]
            img_seq = 0
            used_targets = set()
            for blip in child.findall('.//' + NS_A + 'blip'):
                rid = blip.attrib.get(NS_REL + 'embed')
                if rid and rid in body_rid_to_index:
                    idx = body_rid_to_index[rid]
                    tgt = body_rid_to_target.get(rid, '')
                    ext = Path(tgt).suffix.lower() or '.bin'
                    key = _resolve_target(tgt)
                    if key in used_targets:
                        continue
                    used_targets.add(key)
                    img_seq += 1
                    pos_lines.append(f'- 正文段落{para_idx}-图{img_seq}: body/image_{idx:03d}{ext} 段落文本: "{snippet}"')
                    positions_struct.append({'paragraph': para_idx, 'seq': img_seq, 'path': f'body/image_{idx:03d}{ext}', 'snippet': snippet})
            for vimg in child.findall('.//' + NS_VML + 'imagedata'):
                rid = vimg.attrib.get(NS_REL + 'id')
                if rid and rid in body_rid_to_index:
                    idx = body_rid_to_index[rid]
                    tgt = body_rid_to_target.get(rid, '')
                    ext = Path(tgt).suffix.lower() or '.bin'
                    key = _resolve_target(tgt)
                    if key in used_targets:
                        continue
                    used_targets.add(key)
                    img_seq += 1
                    pos_lines.append(f'- 正文段落{para_idx}-图{img_seq}: body/image_{idx:03d}{ext} 段落文本: "{snippet}"')
                    positions_struct.append({'paragraph': para_idx, 'seq': img_seq, 'path': f'body/image_{idx:03d}{ext}', 'snippet': snippet})
    if pos_lines:
        md_lines.append('正文图片位置:')
        md_lines.extend(pos_lines)
    if externals:
        md_lines.append('外链图片:')
        for sec, url in externals:
            md_lines.append(f'- {sec}: {url}')
    fmt_lines = []
    fmt_structs = []
    pindex = 0
    for child in doc.element.body.iterchildren():
        if child.tag == NS_W + 'p':
            pindex += 1
            p = _Paragraph(child, doc)
            pf = p.paragraph_format
            a = _align_str(p.alignment)
            sz_para = None
            try:
                sz_para = _len_pt(p.style.font.size)
            except Exception:
                sz_para = None
            sz_runs = []
            try:
                for r in p.runs:
                    sz_runs.append(_len_pt(r.font.size))
            except Exception:
                pass
            left = _len_pt(pf.left_indent)
            first = _len_pt(pf.first_line_indent)
            before = _len_pt(pf.space_before)
            after = _len_pt(pf.space_after)
            ls = pf.line_spacing if pf.line_spacing is not None else None
            name = p.style.name if p.style else ''
            line = f'- 段落{pindex}: 样式={name} 对齐={a}'
            if sz_para is not None:
                line += f' 段落字号={sz_para}pt'
            if any(x is not None for x in sz_runs):
                vals = [str(x)+'pt' if x is not None else 'default' for x in sz_runs]
                line += ' 运行字号=' + '/'.join(vals)
            if left is not None:
                line += f' 左缩进={left}pt'
            if first is not None:
                line += f' 首行缩进={first}pt'
            if before is not None:
                line += f' 段前间距={before}pt'
            if after is not None:
                line += f' 段后间距={after}pt'
            if ls is not None:
                try:
                    line += f' 行距={round(float(ls),2)}'
                except Exception:
                    pass
            fmt_lines.append(line)
            fmt_structs.append({
                'paragraph': pindex,
                'style': name,
                'align': a,
                'para_font_pt': sz_para,
                'run_fonts_pt': sz_runs,
                'indent_left_pt': left,
                'indent_first_pt': first,
                'space_before_pt': before,
                'space_after_pt': after,
                'line_spacing': float(ls) if isinstance(ls,(int,float)) else None,
            })
    if fmt_lines:
        md_lines.append('段落格式记录:')
        md_lines.extend(fmt_lines)
    if md_lines:
        md_lines.append('---')
    # build formal content
    def _get_anchor_pos(anchor):
        try:
            x = None; y = None
            z = None
            sp = anchor.find('.//' + NS_WP + 'simplePos')
            if sp is not None:
                try:
                    x = float(sp.attrib.get('x'))
                    y = float(sp.attrib.get('y'))
                except Exception:
                    x = x; y = y
            ph = anchor.find('.//' + NS_WP + 'positionH/' + NS_WP + 'posOffset')
            pv = anchor.find('.//' + NS_WP + 'positionV/' + NS_WP + 'posOffset')
            if ph is not None:
                try:
                    x = float(ph.text)
                except Exception:
                    pass
            if pv is not None:
                try:
                    y = float(pv.text)
                except Exception:
                    pass
            try:
                z = int(anchor.attrib.get('relativeHeight'))
            except Exception:
                z = None
            # fallback using distT/distL attributes (twips)
            if y is None:
                try:
                    y = float(anchor.attrib.get('distT'))
                except Exception:
                    pass
            if x is None:
                try:
                    x = float(anchor.attrib.get('distL'))
                except Exception:
                    pass
            return (x if x is not None else 0.0, y if y is not None else 0.0, z if z is not None else 0)
        except Exception:
            return (0.0, 0.0, 0)

    def _parse_vml_style(style: str):
        x = 0.0; y = 0.0; z = 0
        try:
            s = style or ''
            # parse margin-left/top in points or px
            import re as _re
            m = _re.search(r'margin-left\s*:\s*([\-\d\.]+)(pt|px)?', s)
            if m:
                val = float(m.group(1)); unit = (m.group(2) or '').lower()
                x = val if unit == 'pt' else (val if unit == 'px' else val)
            m = _re.search(r'margin-top\s*:\s*([\-\d\.]+)(pt|px)?', s)
            if m:
                val = float(m.group(1)); unit = (m.group(2) or '').lower()
                y = val if unit == 'pt' else (val if unit == 'px' else val)
            m = _re.search(r'z-index\s*:\s*(\d+)', s)
            if m:
                z = int(m.group(1))
        except Exception:
            pass
        return x, y, z

    items = []
    body = doc.element.body
    para_counter = 0
    for child in body.iterchildren():
        tag = child.tag
        if tag == NS_W + 'p':
            para_counter += 1
            p = _Paragraph(child, doc)
            items.append({'type': 'p', 'text': _paragraph_to_md(p), 'x': 0.0, 'y': float(para_counter), 'z': 0, 'para': para_counter})
            # DrawingML textboxes anchored here
            for anchor in child.findall('.//' + NS_WP + 'anchor'):
                ax, ay, az = _get_anchor_pos(anchor)
                for tp in anchor.findall('.//' + NS_W + 'txbxContent//' + NS_W + 'p'):
                    try:
                        p2 = _Paragraph(tp, doc)
                        items.append({'type': 'tx', 'text': _paragraph_to_md(p2), 'x': ax, 'y': ay, 'z': az, 'para': para_counter})
                    except Exception:
                        pass
            for inl in child.findall('.//' + NS_WP + 'inline'):
                try:
                    ix = 0.0; iy = float(para_counter); iz = 0
                    for tp in inl.findall('.//' + NS_W + 'txbxContent//' + NS_W + 'p'):
                        p2 = _Paragraph(tp, doc)
                        items.append({'type': 'tx', 'text': _paragraph_to_md(p2), 'x': ix, 'y': iy, 'z': iz, 'para': para_counter})
                except Exception:
                    pass
            # VML textboxes anchored here
            for shape in child.findall('.//' + NS_VML + 'shape'):
                ax, ay, az = _parse_vml_style(shape.attrib.get('style',''))
                for tp in shape.findall('.//' + NS_W + 'txbxContent//' + NS_W + 'p'):
                    try:
                        p2 = _Paragraph(tp, doc)
                        items.append({'type': 'tx', 'text': _paragraph_to_md(p2), 'x': ax, 'y': ay, 'z': az, 'para': para_counter})
                    except Exception:
                        pass
        elif tag == NS_W + 'tbl':
            t = _Table(child, doc)
            # 表格保持流式顺序
            items.append({'type': 'tbl', 'rows': _table_to_md(t), 'x': 0.0, 'y': float(para_counter) + 0.1, 'z': 0, 'para': para_counter})
        else:
            # ignore
            pass

    if visual_order in ('inline','absolute'):
        if visual_order == 'inline':
            items.sort(key=lambda it: (it['para'], 0 if it['type']=='p' else 1, it['y'], it['x'], it['z']))
        else:
            items.sort(key=lambda it: (it['y'], it['x'], it['z'], 0 if it['type']=='p' else 1))
    if visual_debug:
        try:
            import csv as _csv
            dbg = visual_debug if isinstance(visual_debug, Path) else Path(str(visual_debug))
            with dbg.open('w', newline='', encoding='utf-8') as fp:
                w = _csv.writer(fp)
                w.writerow(['type','para','x','y','z','text'])
                for it in items:
                    txt = (it.get('text','') or '').replace('\n',' ').strip()[:80]
                    w.writerow([it['type'], it.get('para',0), it['x'], it['y'], it['z'], txt])
        except Exception:
            pass
    for it in items:
        if it['type'] == 'p':
            _append_line(it['text'])
        elif it['type'] == 'tx':
            _append_line(it['text'])
        elif it['type'] == 'tbl':
            md_lines.extend(it['rows'])
            md_lines.append('')
    out_md.write_text('\n'.join(md_lines), encoding='utf-8')
    try:
        zip_path = out_md.with_suffix('.zip')
        _extract_images_zip(
            docx_path,
            zip_path,
            body_order,
            header_order,
            footer_order,
            footnote_order,
            endnote_order,
            comment_order,
            externals,
            positions=positions_struct,
            para_formats=fmt_structs,
        )
    except Exception as e:
        if strict:
            raise
        errors.append(f'extract_images_zip: {type(e).__name__}: {e}')
    if errors:
        try:
            import datetime as _dt
            flog = fail_log if fail_log else out_md.with_suffix('.fail.log')
            if isinstance(flog, Path):
                pass
            else:
                flog = Path(str(flog))
            ts = _dt.datetime.now().isoformat()
            suf = flog.suffix.lower()
            if suf in ['.jsonl', '.ndjson', '.json']:
                rec = {
                    'input': str(docx_path),
                    'output': str(out_md),
                    'errors': errors,
                    'timestamp': ts,
                }
                with flog.open('a', encoding='utf-8') as fp:
                    fp.write(json.dumps(rec, ensure_ascii=False) + '\n')
            else:
                with flog.open('a', encoding='utf-8') as fp:
                    fp.write(f'{docx_path} -> {out_md}:\n')
                    for er in errors:
                        fp.write('  - ' + er + '\n')
        except Exception:
            pass

def main():
    import argparse
    parser = argparse.ArgumentParser(
        prog='HOS_M2F.docx2md',
        description='DOCX 逆向为 Markdown，并按出现顺序打包图片到同名压缩包',
        epilog=(
            '示例:\n'
            '  HOS_M2F.docx2md input.docx output.md\n'
            '相关命令:\n'
            '  HOS_M2F.2docx input.md output.docx [-p paper|patent|softcopy] [-nm] [-nc] [-q]\n'
            '  HOS_M2F.batch input_dir output_dir [-p paper|patent|softcopy] [-nm] [-nc] [-q]\n'
        ),
    )
    parser.add_argument('input', help='输入 DOCX 文件路径')
    parser.add_argument('output', help='输出 Markdown 文件路径')
    parser.add_argument('-s','--strict', action='store_true', help='严格模式：遇到错误直接终止')
    parser.add_argument('--fail-log', help='失败日志输出路径（默认与输出同名 .fail.log）', default='')
    parser.add_argument('--visual-order', choices=['off','inline','absolute'], default='off', help='视觉排序模式')
    parser.add_argument('--visual-debug', help='输出视觉排序调试 CSV 路径')
    parser.add_argument('--keep-duplicates', action='store_true', help='保留重复文本行')
    args = parser.parse_args()
    inp = Path(args.input)
    outp = Path(args.output)
    flog = Path(args.fail_log) if args.fail_log else None
    vdbg = Path(args.visual_debug) if args.visual_debug else None
    convert_docx_to_md(inp, outp, strict=args.strict, fail_log=flog, visual_order=args.visual_order, keep_duplicates=args.keep_duplicates, visual_debug=vdbg)

if __name__ == '__main__':
    main()
