import sys
import os
from pathlib import Path
import tempfile
from .md2docx_mermaid import parse as parse_docx

def _print_progress(name: str, percent: int, idx: int, total: int):
    w = 30
    done = int(percent * w / 100)
    bar = '#' * done + '.' * (w - done)
    msg = f"[{bar}] {percent:3d}% | {idx}/{total} | {name}"
    sys.stdout.write('\r' + msg)
    sys.stdout.flush()

def _is_md(p: Path):
    return p.suffix.lower() in ['.md', '.markdown']

def main():
    import argparse
    parser = argparse.ArgumentParser(
        prog='HOS_M2F.batch',
        description='批量将文件夹中的 Markdown 转为 DOCX（带进度）',
        epilog=(
            '示例:\n'
            '  HOS_M2F.batch input_dir output_dir [-p paper|patent|softcopy] [-nm] [-nc] [-q]\n'
            '相关命令:\n'
            '  HOS_M2F.2docx input.md output.docx [-p paper|patent|softcopy] [-nm] [-nc] [-q]\n'
            '  HOS_M2F.2html input.md output.html [-p wx|csdn]\n'
            '  HOS_M2F.2pdf  input.md output.pdf\n'
            '  HOS_M2F.2json input.md output.json\n'
            '  HOS_M2F.2xml  input.md output.xml\n'
            '  HOS_M2F.2png  input.mmd output.png\n'
        ),
    )
    parser.add_argument('input_dir', help='输入文件夹路径')
    parser.add_argument('output_dir', help='输出文件夹路径')
    parser.add_argument('--format', choices=['docx','html','pdf'], default='docx', help='批量输出格式')
    parser.add_argument('--reverse', action='store_true', help='DOCX 批量转为 Markdown（生成同名 zip）')
    parser.add_argument('-s','--strict', action='store_true', help='严格模式：遇到错误直接终止（reverse 有效）')
    parser.add_argument('-j','--jobs', type=int, default=os.cpu_count() or 4, help='并发任务数')
    parser.add_argument('--log-json', default='', help='批量日志 JSON 路径（默认 output_dir/.hos_m2f_runs/run-<ts>/batch_log.json）')
    parser.add_argument('--group-output', action='store_true', help='将本次输出分组到 output_dir/run-<ts>/ 下，避免混乱')
    parser.add_argument('-p','--profile', choices=['paper','patent','softcopy'], default='', help='DOCX 样式配置')
    parser.add_argument('-nm','--no-mermaid', action='store_true', help='禁用 Mermaid 渲染')
    parser.add_argument('-nc','--no-run-code', action='store_true', help='禁用代码执行（Matplotlib/表格）')
    parser.add_argument('-q','--quiet', action='store_true', help='静默子进程输出')
    parser.add_argument('-c','--config', help='配置文件路径（JSON），未提供则尝试当前目录 HOS_M2F.config.json', default='')
    args = parser.parse_args()

    inp = Path(args.input_dir)
    outp = Path(args.output_dir)
    outp.mkdir(parents=True, exist_ok=True)
    def _is_docx(p: Path):
        return p.suffix.lower() == '.docx'
    files = [p for p in inp.rglob('*') if p.is_file() and (_is_md(p) if not args.reverse else _is_docx(p))]
    total = len(files)
    if total == 0:
        print('No markdown files found.')
        return
    import json as _json
    company_cfg = None
    if args.config:
        try:
            company_cfg = _json.loads(Path(args.config).read_text(encoding='utf-8'))
        except Exception:
            company_cfg = None
    else:
        p0 = Path.cwd() / 'HOS_M2F.config.json'
        if p0.exists():
            try:
                company_cfg = _json.loads(p0.read_text(encoding='utf-8'))
            except Exception:
                company_cfg = None
    from datetime import datetime
    run_id = datetime.now().strftime('%Y%m%d-%H%M%S')
    runs_dir = outp / '.hos_m2f_runs' / f'run-{run_id}'
    runs_dir.mkdir(parents=True, exist_ok=True)
    out_run = outp / f'run-{run_id}' if args.group_output else outp
    out_run.mkdir(parents=True, exist_ok=True)
    flog = Path(args.log_json) if args.log_json else (runs_dir / 'batch_log.json')
    per_file_fail = runs_dir / 'per_file_fail.jsonl'
    entries = []
    def _process_one(idx, f: Path):
        name = f.name
        def cb(pct):
            _print_progress(name, pct, idx, total)
        import time
        t0 = time.perf_counter()
        try:
            if args.reverse:
                from hos_m2f.docx2md import convert_docx_to_md
                tgt = out_run / (f.stem + '.md')
                convert_docx_to_md(f, tgt, strict=args.strict, fail_log=per_file_fail)
                _print_progress(name, 100, idx, total)
                sys.stdout.write('\n'); sys.stdout.flush()
                dur = int((time.perf_counter() - t0) * 1000)
                entries.append({
                    'input': str(f),
                    'output': str(tgt),
                    'format': 'md',
                    'reverse': True,
                    'status': 'ok',
                    'duration_ms': dur,
                })
                return True
            text = f.read_text(encoding='utf-8')
            if args.format == 'docx':
                with tempfile.TemporaryDirectory() as td:
                    doc = parse_docx(
                        text,
                        Path(td),
                        profile=args.profile,
                        run_code=(not args.no_run_code),
                        render_mermaid=(not args.no_mermaid),
                        quiet=args.quiet,
                        progress_cb=cb,
                        company_cfg=company_cfg,
                        source_md_path=f,
                    )
                    tgt = out_run / (f.stem + '.docx')
                    doc.save(str(tgt))
            elif args.format == 'html':
                import subprocess as sp, sys as _sys
                tgt = out_run / (f.stem + '.html')
                sp.run([_sys.executable, '-m', 'hos_m2f.md2html', str(f), str(tgt), '-p', 'wx'], check=True)
            elif args.format == 'pdf':
                import subprocess as sp, sys as _sys
                tgt = out_run / (f.stem + '.pdf')
                sp.run([_sys.executable, '-m', 'hos_m2f.md2pdf', str(f), str(tgt)], check=True)
            _print_progress(name, 100, idx, total)
            sys.stdout.write('\n')
            sys.stdout.flush()
            dur = int((time.perf_counter() - t0) * 1000)
            entries.append({
                'input': str(f),
                'output': str(tgt),
                'format': args.format,
                'reverse': False,
                'status': 'ok',
                'duration_ms': dur,
            })
            return True
        except Exception as e:
            dur = int((time.perf_counter() - t0) * 1000)
            entries.append({
                'input': str(f),
                'output': str((out_run / (f.stem + ('.md' if args.reverse else ('.' + args.format)) ))),
                'format': ('md' if args.reverse else args.format),
                'reverse': bool(args.reverse),
                'status': 'error',
                'error_type': type(e).__name__,
                'error_message': str(e),
                'duration_ms': dur,
            })
            if args.strict:
                raise
            _print_progress(name, 100, idx, total)
            sys.stdout.write('\n'); sys.stdout.flush()
            return False

    from concurrent.futures import ThreadPoolExecutor, as_completed
    ok_count = 0
    with ThreadPoolExecutor(max_workers=max(1, int(args.jobs))) as ex:
        futures = {ex.submit(_process_one, idx, f): f for idx, f in enumerate(files, start=1)}
        for fut in as_completed(futures):
            try:
                if fut.result():
                    ok_count += 1
            except Exception:
                # strict mode may bubble up
                pass
    try:
        import json as _json
        summary = {
            'run_id': run_id,
            'output_dir': str(out_run),
            'total': total,
            'ok': ok_count,
            'error': total - ok_count,
        }
        (runs_dir / 'summary.json').write_text(_json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
        flog.write_text(_json.dumps(entries, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception:
        pass
    print(f'Processed {ok_count}/{total} files -> {out_run}')

if __name__ == '__main__':
    main()
