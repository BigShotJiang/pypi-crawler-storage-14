"""
Main entry point for running the module as a script.
Example: python -m abacum.ai.mcp
"""

from .server import main

if __name__ == "__main__":
    main()