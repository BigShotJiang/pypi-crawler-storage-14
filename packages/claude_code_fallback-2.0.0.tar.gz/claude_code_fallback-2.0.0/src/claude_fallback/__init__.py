"""Claude Code Fallback - Automatic API fallback for Claude Code usage limits."""

__version__ = "2.0.0"
