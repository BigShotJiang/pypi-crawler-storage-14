"""Entry point for the package. Run e.g. via `uv run -m quickcrop`"""
from .gui import main


if __name__ == "__main__":
    main()
