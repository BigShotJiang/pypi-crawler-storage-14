def test_dummy():
    """Dummy test, so pipeline doesn't fail before first test is defined"""
    pass
