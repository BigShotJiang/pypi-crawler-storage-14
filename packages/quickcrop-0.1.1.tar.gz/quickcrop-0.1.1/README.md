# quickcrop

A minimal GUI app for image cropping.
