"""
Test Suite: Drivers (SQL, Graph, Analytics)
===========================================

Tests for all driver implementations: AsyncSQLAlchemyDriver, KuzuActor, DuckDBDriver.
"""

import os
import shutil
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncEngine

from malha import AsyncSQLAlchemyDriver, DuckDBDriver, KuzuActor

# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
async def temp_dir():
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


# ============================================================================
# Tests: AsyncSQLAlchemyDriver
# ============================================================================

class TestAsyncSQLAlchemyDriver:
    @pytest.mark.asyncio
    async def test_initialization_sqlite(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
        assert isinstance(driver.get_engine(), AsyncEngine)

    @pytest.mark.asyncio
    async def test_auto_fix_sqlite_url(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite:///{db_path}")
        url_str = str(driver.get_engine().url)
        assert "aiosqlite" in url_str

    @pytest.mark.asyncio
    async def test_auto_fix_postgresql_url(self):
        driver = AsyncSQLAlchemyDriver("postgresql://localhost/testdb")
        url_str = str(driver.get_engine().url)
        assert "asyncpg" in url_str

    @pytest.mark.asyncio
    async def test_create_tables(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
        await driver.create_tables()
        # Should not raise

    @pytest.mark.asyncio
    async def test_get_session(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
        await driver.create_tables()

        session = await driver.get_session()
        assert session is not None
        await session.close()

    @pytest.mark.asyncio
    async def test_memory_database(self):
        driver = AsyncSQLAlchemyDriver("sqlite+aiosqlite:///:memory:")
        await driver.create_tables()
        session = await driver.get_session()
        assert session is not None
        await session.close()


# ============================================================================
# Tests: KuzuActor
# ============================================================================

class TestKuzuActor:
    @pytest.mark.asyncio
    async def test_initialization(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        assert driver.path == graph_path
        await driver.close()

    @pytest.mark.asyncio
    async def test_qsize(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        assert driver.qsize() >= 0
        await driver.close()

    @pytest.mark.asyncio
    async def test_register_schema(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        class TestModel(BaseModel):
            rid: str
            name: str
            value: int = 0

        with patch("malha.malha.generate_ddl") as mock_ddl:
            mock_ddl.return_value = "CREATE NODE TABLE TestModel (rid STRING PRIMARY KEY, name STRING);"
            with patch.object(driver, "execute", new_callable=AsyncMock):
                await driver.register_schema(TestModel)
                mock_ddl.assert_called_once()

        await driver.close()

    @pytest.mark.asyncio
    async def test_upsert_node(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        with patch.object(driver, "execute", new_callable=AsyncMock) as mock_exec:
            await driver.upsert_node({"rid": "test-rid", "name": "Test"}, "TestModel")
            assert mock_exec.called

        await driver.close()

    @pytest.mark.asyncio
    async def test_upsert_node_without_rid(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        with pytest.raises(ValueError, match="must have an 'rid' field"):
            await driver.upsert_node({"name": "Test"}, "TestModel")

        await driver.close()

    @pytest.mark.asyncio
    async def test_delete_node(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        with patch.object(driver, "execute", new_callable=AsyncMock) as mock_exec:
            await driver.delete_node("test-rid", "TestModel")
            assert mock_exec.called

        await driver.close()

    @pytest.mark.asyncio
    async def test_create_edge(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        with patch.object(driver, "execute", new_callable=AsyncMock) as mock_exec:
            await driver.create_edge("src-rid", "dst-rid", "RELATED", {"weight": 1.0})
            assert mock_exec.called

        await driver.close()

    @pytest.mark.asyncio
    async def test_delete_edge(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        with patch.object(driver, "execute", new_callable=AsyncMock) as mock_exec:
            await driver.delete_edge("src-rid", "dst-rid", "RELATED")
            assert mock_exec.called

        await driver.close()

    @pytest.mark.asyncio
    async def test_query(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        mock_result = [{"name": "Test", "value": 42}]
        with patch.object(driver, "_execute_query", new_callable=AsyncMock) as mock_q:
            mock_q.return_value = mock_result
            result = await driver.query("MATCH (n) RETURN n", {})
            assert result == mock_result

        await driver.close()

    @pytest.mark.asyncio
    async def test_close(self, temp_dir):
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        await driver.close()
        assert driver._running is False


# ============================================================================
# Tests: DuckDBDriver
# ============================================================================

class TestDuckDBDriver:
    @pytest.mark.asyncio
    async def test_initialization_memory(self):
        driver = DuckDBDriver()
        assert driver.conn is not None
        assert driver.zero_copy is False
        driver.close()

    @pytest.mark.asyncio
    async def test_initialization_with_path(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        # Create a dummy file
        with open(db_path, "w") as f:
            f.write("")

        driver = DuckDBDriver(db_path)
        assert driver.conn is not None
        driver.close()

    @pytest.mark.asyncio
    async def test_register_view_zero_copy(self):
        driver = DuckDBDriver()
        driver.zero_copy = True

        with patch.object(driver, "query", new_callable=AsyncMock) as mock_query:
            await driver.register_view("test_view", "test_table")
            assert mock_query.called

        driver.close()

    @pytest.mark.asyncio
    async def test_register_view_no_zero_copy(self):
        driver = DuckDBDriver()
        driver.zero_copy = False

        # Should not call query when zero_copy is False
        with patch.object(driver, "query", new_callable=AsyncMock) as mock_query:
            await driver.register_view("test_view", "test_table")
            mock_query.assert_not_called()

        driver.close()

    @pytest.mark.asyncio
    async def test_ingest_arrow(self):
        mock_arrow_table = MagicMock()

        with patch("malha.malha.duckdb.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn

            driver = DuckDBDriver()
            await driver.ingest_arrow("test_table", mock_arrow_table)

            mock_conn.register.assert_called_once_with("test_table", mock_arrow_table)

    @pytest.mark.asyncio
    async def test_query(self):
        with patch("malha.malha.duckdb.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn

            mock_result = [(1, "test"), (2, "data")]
            mock_cursor = MagicMock()
            mock_cursor.fetchall.return_value = mock_result
            mock_conn.execute.return_value = mock_cursor

            driver = DuckDBDriver()
            result = await driver.query("SELECT * FROM test")

            assert result == mock_result

    @pytest.mark.asyncio
    async def test_close(self):
        driver = DuckDBDriver()
        driver.close()
        # Should not raise


# ============================================================================
# Tests: Driver Protocol Compliance
# ============================================================================

class TestDriverProtocols:
    @pytest.mark.asyncio
    async def test_sql_driver_protocol(self, temp_dir):
        """Test AsyncSQLAlchemyDriver implements SQLDriver protocol."""
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")

        # SQLDriver protocol methods
        assert hasattr(driver, "get_session")
        assert hasattr(driver, "create_tables")
        assert callable(driver.get_session)
        assert callable(driver.create_tables)

    @pytest.mark.asyncio
    async def test_graph_driver_protocol(self, temp_dir):
        """Test KuzuActor implements GraphDriver protocol."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        # GraphDriver protocol methods
        assert hasattr(driver, "register_schema")
        assert hasattr(driver, "upsert_node")
        assert hasattr(driver, "delete_node")
        assert hasattr(driver, "create_edge")
        assert hasattr(driver, "delete_edge")
        assert hasattr(driver, "query")

        await driver.close()

    @pytest.mark.asyncio
    async def test_analytics_driver_protocol(self):
        """Test DuckDBDriver implements AnalyticsDriver protocol."""
        driver = DuckDBDriver()

        # AnalyticsDriver protocol methods
        assert hasattr(driver, "register_view")
        assert hasattr(driver, "ingest_arrow")
        assert hasattr(driver, "query")

        driver.close()
