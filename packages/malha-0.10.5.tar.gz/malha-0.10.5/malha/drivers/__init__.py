"""
Malha Drivers Package
=====================

This package contains pluggable drivers for extending Malha's capabilities:

- synapse: P2P mesh replication driver for distributed synchronization
- alembic: Embedded Alembic driver for programmatic schema migrations

Usage:
    from malha.drivers.synapse import SynapseDriver
    from malha.drivers.alembic import AlembicDriver
"""

__all__ = ["SynapseDriver", "AlembicDriver", "MigrationResult", "MigrationInfo"]

try:
    from .synapse import SynapseDriver
except ImportError:
    # gRPC dependencies not installed
    SynapseDriver = None

try:
    from .alembic import AlembicDriver, MigrationResult, MigrationInfo
except ImportError:
    # Alembic not installed
    AlembicDriver = None
    MigrationResult = None
    MigrationInfo = None
