#!/usr/bin/env python3
"""
Distributed Malha Cluster Example
==================================

This example demonstrates how to set up a 3-node Malha cluster with
P2P replication using the Synapse driver.

Requirements:
    pip install malha[synapse]
    python scripts/compile_protos.py

Usage:
    # Terminal 1 (Node 1)
    python examples/distributed_cluster.py --node-id node-1 --port 50051 --peers 127.0.0.1:50052,127.0.0.1:50053
    
    # Terminal 2 (Node 2)
    python examples/distributed_cluster.py --node-id node-2 --port 50052 --peers 127.0.0.1:50051,127.0.0.1:50053
    
    # Terminal 3 (Node 3)
    python examples/distributed_cluster.py --node-id node-3 --port 50053 --peers 127.0.0.1:50051,127.0.0.1:50052
"""

import asyncio
import argparse
import logging
import sys
from pathlib import Path

# Add parent directory to path for local development
sys.path.insert(0, str(Path(__file__).parent.parent))

from malha import connect
from registro import Resource

# Optional: Import Synapse driver if available
try:
    from malha.drivers.synapse import SynapseDriver
    SYNAPSE_AVAILABLE = True
except ImportError:
    SYNAPSE_AVAILABLE = False
    print("Warning: Synapse driver not available. Install with: pip install malha[synapse]")


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(name)s | %(levelname)s | %(message)s',
    datefmt='%H:%M:%S'
)


async def run_node(node_id: str, port: int, peers: list[str]):
    """Run a single Malha node with replication."""
    
    print(f"\n{'='*60}")
    print(f"Starting Malha Node: {node_id}")
    print(f"Port: {port}")
    print(f"Peers: {peers}")
    print(f"{'='*60}\n")
    
    # Create Synapse driver if available
    replication_driver = None
    if SYNAPSE_AVAILABLE and peers:
        replication_driver = SynapseDriver(
            kernel_ref=None,  # Will be set by connect()
            node_id=node_id,
            port=port,
            peers=peers
        )
    
    # Connect to Malha kernel
    manager = await connect(
        url=f"sqlite+aiosqlite:///data/{node_id}.db",
        kuzu_path=f"data/kuzu_{node_id}",
        reset=True,  # Fresh start for demo
        replication_driver=replication_driver
    )
    
    # Register a sample model
    from registro import Resource as RegistroResource
    await manager.register_model(RegistroResource)
    
    print(f"✓ Node {node_id} is ready!")
    print(f"  - SQL: data/{node_id}.db")
    print(f"  - Graph: data/kuzu_{node_id}")
    if replication_driver:
        print(f"  - Synapse: Listening on port {port}")
        print(f"  - Peers: {len(peers)} configured")
    print()
    
    # Demo: Create some test data
    if node_id == "node-1":
        print(f"[{node_id}] Creating test resources...")
        
        for i in range(3):
            resource = RegistroResource(
                data={
                    "name": f"Resource {i}",
                    "created_by": node_id,
                    "index": i
                }
            )
            
            saved = await manager.save_versioned(resource)
            print(f"  ✓ Created: {saved.rid}")
            await asyncio.sleep(1)  # Give time for replication
    
    # Keep running
    print(f"\n[{node_id}] Node is running. Press Ctrl+C to stop.\n")
    
    try:
        # Monitor outbox status periodically
        while True:
            await asyncio.sleep(10)
            
            # Check outbox status
            from sqlmodel import select
            from malha.malha import SysOutbox
            
            async with manager.sql.get_session() as session:
                pending = await session.execute(
                    select(SysOutbox).where(SysOutbox.status == "PENDING")
                )
                pending_count = len(pending.scalars().all())
                
                done = await session.execute(
                    select(SysOutbox).where(SysOutbox.status == "DONE")
                )
                done_count = len(done.scalars().all())
                
                dlq = await session.execute(
                    select(SysOutbox).where(SysOutbox.status == "DEAD_LETTER")
                )
                dlq_count = len(dlq.scalars().all())
            
            print(
                f"[{node_id}] Outbox Status: "
                f"Pending={pending_count}, Done={done_count}, DLQ={dlq_count}"
            )
    
    except KeyboardInterrupt:
        print(f"\n[{node_id}] Shutting down...")
        await manager.close()
        print(f"[{node_id}] Goodbye!")


def main():
    """Parse arguments and run the node."""
    
    parser = argparse.ArgumentParser(description="Run a Malha node in a distributed cluster")
    parser.add_argument(
        "--node-id",
        type=str,
        required=True,
        help="Unique identifier for this node (e.g., node-1)"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=50051,
        help="Port to listen on for Synapse replication (default: 50051)"
    )
    parser.add_argument(
        "--peers",
        type=str,
        default="",
        help="Comma-separated list of peer addresses (e.g., 127.0.0.1:50052,127.0.0.1:50053)"
    )
    
    args = parser.parse_args()
    
    # Parse peer list
    peers = [p.strip() for p in args.peers.split(",") if p.strip()]
    
    # Run the node
    asyncio.run(run_node(args.node_id, args.port, peers))


if __name__ == "__main__":
    main()
