######
States
######

.. currentmodule:: gwsumm.state

.. automodule:: gwsumm.state
   :no-members:
