#######
Tab API
#######

.. automodapi:: gwsumm.tabs
