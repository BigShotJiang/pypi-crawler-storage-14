.. automodapi:: gwsumm.mode
