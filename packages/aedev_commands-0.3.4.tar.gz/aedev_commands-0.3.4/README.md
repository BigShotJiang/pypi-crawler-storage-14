<!-- THIS FILE IS EXCLUSIVELY MAINTAINED by the project aedev.aedev v0.3.28 -->
<!-- THIS FILE IS EXCLUSIVELY MAINTAINED by the project aedev.namespace_root_tpls v0.3.21 -->
# commands 0.3.4

[![GitLab develop](https://img.shields.io/gitlab/pipeline/aedev-group/aedev_commands/develop?logo=python)](
    https://gitlab.com/aedev-group/aedev_commands)
[![LatestPyPIrelease](
    https://img.shields.io/gitlab/pipeline/aedev-group/aedev_commands/release0.3.4?logo=python)](
    https://gitlab.com/aedev-group/aedev_commands/-/tree/release0.3.4)
[![PyPIVersions](https://img.shields.io/pypi/v/aedev_commands)](
    https://pypi.org/project/aedev-commands/#history)

>aedev namespace module portion commands: software development operation commands helpers.

[![Coverage](https://aedev-group.gitlab.io/aedev_commands/coverage.svg)](
    https://aedev-group.gitlab.io/aedev_commands/coverage/index.html)
[![MyPyPrecision](https://aedev-group.gitlab.io/aedev_commands/mypy.svg)](
    https://aedev-group.gitlab.io/aedev_commands/lineprecision.txt)
[![PyLintScore](https://aedev-group.gitlab.io/aedev_commands/pylint.svg)](
    https://aedev-group.gitlab.io/aedev_commands/pylint.log)

[![PyPIImplementation](https://img.shields.io/pypi/implementation/aedev_commands)](
    https://gitlab.com/aedev-group/aedev_commands/)
[![PyPIPyVersions](https://img.shields.io/pypi/pyversions/aedev_commands)](
    https://gitlab.com/aedev-group/aedev_commands/)
[![PyPIWheel](https://img.shields.io/pypi/wheel/aedev_commands)](
    https://gitlab.com/aedev-group/aedev_commands/)
[![PyPIFormat](https://img.shields.io/pypi/format/aedev_commands)](
    https://pypi.org/project/aedev-commands/)
[![PyPILicense](https://img.shields.io/pypi/l/aedev_commands)](
    https://gitlab.com/aedev-group/aedev_commands/-/blob/develop/LICENSE.md)
[![PyPIStatus](https://img.shields.io/pypi/status/aedev_commands)](
    https://libraries.io/pypi/aedev-commands)
[![PyPIDownloads](https://img.shields.io/pypi/dm/aedev_commands)](
    https://pypi.org/project/aedev-commands/#files)


## installation


execute the following command to install the
aedev.commands module
in the currently active virtual environment:
 
```shell script
pip install aedev-commands
```

if you want to contribute to this portion then first fork
[the aedev_commands repository at GitLab](
https://gitlab.com/aedev-group/aedev_commands "aedev.commands code repository").
after that pull it to your machine and finally execute the
following command in the root folder of this repository
(aedev_commands):

```shell script
pip install -e .[dev]
```

the last command will install this module portion, along with the tools you need
to develop and run tests or to extend the portion documentation. to contribute only to the unit tests or to the
documentation of this portion, replace the setup extras key `dev` in the above command with `tests` or `docs`
respectively.

more detailed explanations on how to contribute to this project
[are available here](
https://gitlab.com/aedev-group/aedev_commands/-/blob/develop/CONTRIBUTING.rst)


## namespace portion documentation

information on the features and usage of this portion are available at
[ReadTheDocs](
https://aedev.readthedocs.io/en/latest/_autosummary/aedev.commands.html
"aedev_commands documentation").
