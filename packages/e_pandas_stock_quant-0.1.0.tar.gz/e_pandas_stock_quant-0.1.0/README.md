# E-Pandas Stock Quant

A pandas-based stock quantitative analysis library for feature extraction from stock market data.

## Features

- Intraday basic feature calculation
- Cross-day trend feature extraction  
- Multi-process support for large datasets

## Installation