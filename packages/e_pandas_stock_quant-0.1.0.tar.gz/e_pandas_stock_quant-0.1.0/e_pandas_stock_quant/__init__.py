"""
E-Pandas Stock Quant - A pandas-based stock quantitative analysis library
"""

from .core import (
    calculate_intraday_basic_features,
    calculate_cross_day_trend_features_for_day,
    extract_features_from_all_files_multiprocess,
    extract_features_from_all_files_single_process
)

__version__ = "0.1.0"
__author__ = "rtc2475592453"
__email__ = "18817223083@163.com"

__all__ = [
    'calculate_intraday_basic_features',
    'calculate_cross_day_trend_features_for_day',
    'extract_features_from_all_files_multiprocess',
    'extract_features_from_all_files_single_process'
]