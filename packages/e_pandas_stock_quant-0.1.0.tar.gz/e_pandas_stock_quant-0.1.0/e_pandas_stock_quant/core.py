import pandas as pd
import numpy as np
import os
import glob
from sklearn.linear_model import LinearRegression
from tqdm import tqdm
import multiprocessing as mp
from multiprocessing import Pool, Manager, cpu_count
import warnings
warnings.filterwarnings('ignore')

#by ruchenz
# 定义特征计算函数
def calculate_intraday_basic_features(df):
    """计算日内基础量价关系特征"""
    features = {}
    
    # 确保数据按分钟排序（使用正确的时间格式排序）
    df['time_obj'] = pd.to_datetime(df['time'], format='%H:%M')
    df = df.sort_values(by='time_obj')
    
    # 当日收盘价/当日开盘价-1
    if len(df) > 0:
        open_price = df['price'].iloc[0]
        close_price = df['price'].iloc[-1]
        features['日内整体涨跌1'] = close_price / open_price - 1 if open_price != 0 else 0
    else:
        features['日内整体涨跌1'] = 0
    
    # 当日开盘价/当日收盘价-1
    if len(df) > 0:
        open_price = df['price'].iloc[0]
        close_price = df['price'].iloc[-1]
        features['日内整体涨跌2'] = open_price / close_price - 1 if close_price != 0 else 0
    else:
        features['日内整体涨跌2'] = 0
    
    # 当日收盘价
    features['当日收盘价'] = df['price'].iloc[-1] if len(df) > 0 else 0
    
    # 每日均价
    total_volume = df['volume'].sum()
    avg_price = (df['price'] * df['volume']).sum() / total_volume if total_volume != 0 else 0
    features['每日均价'] = df['volume'].mean()
    
    # 每日Vwap
    vwap = avg_price
    features['每日Vwap'] = vwap
    
    # 14:55-15:00Vwap/每日Vwap
    end_df = df[(df['time_obj'].dt.time >= pd.to_datetime('14:55', format='%H:%M').time()) & 
                (df['time_obj'].dt.time <= pd.to_datetime('15:00', format='%H:%M').time())]
    end_total_volume = end_df['volume'].sum()
    end_vwap = (end_df['price'] * end_df['volume']).sum() / end_total_volume if end_total_volume != 0 else 0
    features['尾盘拉抬_打压线索'] = end_vwap / vwap if vwap != 0 and not np.isnan(vwap) else 0
    
    # 每日总成交量
    features['每日总成交量'] = total_volume
    
    # 每日总成交额
    features['每日总成交额'] = (df['price'] * df['volume']).sum()
    
    # 每日涨跌幅
    if len(df) > 0:
        open_price = df['price'].iloc[0]
        close_price = df['price'].iloc[-1]
        features['每日涨跌幅'] = (close_price - open_price) / open_price if open_price != 0 else 0
    else:
        features['每日涨跌幅'] = 0
    
    # 添加开盘价、最高价、最低价特征，用于后续计算振幅
    if len(df) > 0:
        features['当日开盘价'] = df['price'].iloc[0]
        features['当日收盘价'] = df['price'].iloc[-1]
        features['当日最高价'] = df['price'].max()
        features['当日最低价'] = df['price'].min()
        # 计算真实振幅
        daily_amplitude = (df['price'].max() - df['price'].min()) / df['price'].iloc[0] if df['price'].iloc[0] != 0 else 0
        features['每日振幅'] = daily_amplitude
    else:
        features['当日开盘价'] = 0
        features['当日收盘价'] = 0
        features['当日最高价'] = 0
        features['当日最低价'] = 0
        features['每日振幅'] = 0
    
    # 每日最高价_每日Vwap
    features['每日最高价_每日Vwap'] = df['price'].max() / vwap if vwap != 0 and not np.isnan(vwap) else 0
    
    # 每日最低价_每日Vwap
    features['每日最低价_每日Vwap'] = df['price'].min() / vwap if vwap != 0 and not np.isnan(vwap) else 0
    
    # 每日价格中位数_每日Vwap
    features['每日价格中位数_每日Vwap'] = df['price'].median() / vwap if vwap != 0 and not np.isnan(vwap) else 0
    
    # 每日价格标准差_每日Vwap
    price_std = df['price'].std()
    features['每日价格标准差_每日Vwap'] = price_std / vwap if vwap != 0 and not np.isnan(vwap) else 0
    
    # 计算分钟级涨跌幅和持续时间特征
    if len(df) > 1:
        # 计算每分钟的涨跌幅（相对于前一分钟）
        df['price_change_pct'] = df['price'].pct_change()
        
        # 计算达到不同阈值的持续时间（连续超过阈值的分钟数）
        # 交易时间内股价涨跌幅≥±9.7%持续时间
        mask_97 = (df['price_change_pct'].abs() >= 0.01)
        features['交易时间内股价涨跌幅≥±9.7%持续时间'] = mask_97.sum()  # 以分钟为单位
        
        # 交易时间内股价涨跌幅≥±19.7%持续时间
        mask_197 = (df['price_change_pct'].abs() >= 0.03)
        features['交易时间内股价涨跌幅≥±19.7%持续时间'] = mask_197.sum()  # 以分钟为单位
        
        # 交易时间内股价涨跌幅≥±4.7%持续时间
        mask_47 = (df['price_change_pct'].abs() >= 0.05)
        features['交易时间内股价涨跌幅≥±4.7%持续时间'] = mask_47.sum()  # 以分钟为单位


        
        # 计算达到不同阈值的触及次数（跨越阈值的次数）
        # 交易时间内股价涨跌幅≥±9.7%触及次数
        threshold_97_crossings = 0
        prev_price_change = df['price_change_pct'].iloc[0] if not pd.isna(df['price_change_pct'].iloc[0]) else 0
        for i in range(1, len(df)):
            curr_price_change = df['price_change_pct'].iloc[i] if not pd.isna(df['price_change_pct'].iloc[i]) else 0
            if abs(curr_price_change) >= 0.01:
                threshold_97_crossings += 1
        features['交易时间内股价涨跌幅≥±9.7%触及次数'] = threshold_97_crossings
        
        # 交易时间内涨跌幅≥±19.7%触及次数
        threshold_197_crossings = 0
        for i in range(len(df)):
            curr_price_change = df['price_change_pct'].iloc[i] if not pd.isna(df['price_change_pct'].iloc[i]) else 0
            if abs(curr_price_change) >= 0.03:
                threshold_197_crossings += 1
        features['交易时间内涨跌幅≥±19.7%触及次数'] = threshold_197_crossings
        
        # 交易时间内涨跌幅≥±4.7%触及次数
        threshold_47_crossings = 0
        for i in range(len(df)):
            curr_price_change = df['price_change_pct'].iloc[i] if not pd.isna(df['price_change_pct'].iloc[i]) else 0
            if abs(curr_price_change) >= 0.05:
                threshold_47_crossings += 1
        features['交易时间内涨跌幅≥±4.7%触及次数'] = threshold_47_crossings
    else:
        # 如果数据点少于2个，无法计算涨跌幅
        features['交易时间内股价涨跌幅≥±9.7%持续时间'] = 0
        features['交易时间内股价涨跌幅≥±19.7%持续时间'] = 0
        features['交易时间内股价涨跌幅≥±4.7%持续时间'] = 0
        features['交易时间内股价涨跌幅≥±9.7%触及次数'] = 0
        features['交易时间内涨跌幅≥±19.7%触及次数'] = 0
        features['交易时间内涨跌幅≥±4.7%触及次数'] = 0
    
    return features

def calculate_cross_day_trend_features_for_day(current_data, historical_data):
    """为单个交易日计算跨交易日趋势与惯性特征"""
    features = {}
    
    # 获取当前交易日的数据
    current_day = current_data['day']
    
    # 如果没有历史数据（第一个交易日）
    if not historical_data or len(historical_data) == 0:
        # 1. 距离上一交易日的自然日间隔（第0个自然日填0）
        features['距离上一交易日的自然日间隔'] = 0
        
        # 其他需要历史数据的特征设为0（避免NaN）
        excel_defined_features = [
            '跳空幅度', '每日涨跌幅', '每日振幅', 
            '交易时间内股价涨跌幅≥±9.7%持续时间', 
            '交易时间内股价涨跌幅≥±19.7%持续时间', 
            '交易时间内股价涨跌幅≥±4.7%持续时间', 
            '交易时间内股价涨跌幅≥±9.7%触及次数', 
            '交易时间内涨跌幅≥±19.7%触及次数', 
            '交易时间内涨跌幅≥±4.7%触及次数', 
            '最近3个交易日累计涨跌幅绝对值', 
            '最近5个交易日累计涨跌幅绝对值', 
            '最近3个交易日累计涨跌幅', 
            '最近5个交易日累计涨跌幅', 
            '最近3个交易日累计振幅', 
            '最近5个交易日累计振幅', 
            '累积至当日连续上涨天数', 
            '累积至当日连续下跌天数', 
            '当日总成交量/前一交易日总成交量', 
            '(近3日日均总成交量)/(前5日日均总成交量)', 
            '近5个交易日每日涨跌幅标准差', 
            '近10个交易日每日涨跌幅标准差', 
            '近5个交易日收盘价线性回归斜率', 
            '近5个交易日收盘价线性回归R^2', 
            '对近10个交易日收盘价线性回归斜率', 
            '近10个交易日收盘价线性回归R^2', 
            '近5个交易日 分钟涨跌幅≥±1% 的次数均值', 
            '累积至当日 每日涨跌幅≥±4.7%的连续天数', 
            '累积至当日 每日涨跌幅≥±9.7%的连续天数', 
            '累积至当日 每日涨跌幅≥±19.7%的连续天数', 
            '近5个交易日每日Vwap标准差', 
            '近10个交易日每日Vwap标准差', 
            '近5个交易日每日Vwap线性回归斜率', 
            '近5个交易日每日Vwap线性回归R^2', 
            '对近10个交易日每日Vwap线性回归斜率', 
            '近10个交易日每日Vwap线性回归R^2', 
            '近5个交易日每日总成交额标准差', 
            '近10个交易日每日总成交额标准差', 
            '近5个交易日每日总成交额回归斜率', 
            '近5个交易日每日总成交额回归R^2', 
            '对近10个交易日每日总成交额线性回归斜率', 
            '近10个交易日每日总成交额线性回归R^2', 
            '近5个交易日每日振幅标准差', 
            '近10个交易日每日涨跌幅绝对值的标准差', 
            '近5个交易日每日振幅线性回归斜率', 
            '近5个交易日每日涨跌幅绝对值线性回归R^2', 
            '近10个交易日每日振幅线性回归斜率', 
            '近10个交易日每日涨跌幅绝对值线性回归R^2'
        ]
        
        for feat in excel_defined_features:
            features[feat] = 0  # 使用0而不是NaN作为默认值
        
        return features
    
    # 获取上一交易日的数据
    previous_data = historical_data[-1]
    previous_day = previous_data['day']
    
    # 1. 距离上一交易日的自然日间隔
    features['距离上一交易日的自然日间隔'] = current_day - previous_day
    
    # 2. 跳空幅度 (今日第一笔价格-上一交易日最后一笔价格)/上一交易日收盘价
    # 使用开盘价代替第一笔价格，收盘价代替最后一笔价格
    if '当日收盘价' in previous_data and not np.isnan(previous_data['当日收盘价']) and previous_data['当日收盘价'] != 0 and '当日开盘价' in current_data and not np.isnan(current_data['当日开盘价']) and current_data['当日开盘价'] != 0:
        # 假设开盘价是当日收盘价（这里需要更好的估算）
        jump_gap =  current_data['当日开盘价']/previous_data['当日收盘价']-1 # 简化处理，实际需要分钟级数据
        features['跳空幅度'] = jump_gap
    else:
        features['跳空幅度'] = 0


    # Get daily amplitude from the intraday features

    if '当日收盘价' in previous_data and not np.isnan(previous_data['当日收盘价']) and previous_data['当日收盘价'] != 0 and '当日收盘价' in current_data and not np.isnan(current_data['当日收盘价']) and current_data['当日收盘价'] != 0:
       # 假设开盘价是当日收盘价（这里需要更好的估算）
        j_gap =  current_data['当日收盘价']/previous_data['当日收盘价']-1 # 简化处理，实际需要分钟级数据
        features['每日涨跌幅'] = j_gap
    else:
        features['每日涨跌幅'] = 0

 




    # 4. 每日振幅 (当日最高价-当日最低价)/当日开盘价
    # Get daily amplitude from the intraday features
    if '当日开盘价' in current_data and '当日最高价' in current_data and '当日最低价' in current_data:
        open_price = current_data['当日开盘价']
        high_price = current_data['当日最高价']
        low_price = current_data['当日最低价']
        if open_price != 0 and not np.isnan(open_price):
            daily_range = (high_price - low_price) / open_price
            features['每日振幅'] = daily_range
        else:
            features['每日振幅'] = 0
    else:
        # If specific amplitude-related features are not available, calculate from other available data
        # For now set to 0, but we should enhance calculate_intraday_basic_features to compute these
        features['每日振幅'] = 0
    
    # 5-7. 交易时间内股价涨跌幅≥±X%持续时间
    # 从日内特征中获取计算好的值
    if '交易时间内股价涨跌幅≥±9.7%持续时间' in current_data and not np.isnan(current_data['交易时间内股价涨跌幅≥±9.7%持续时间']):
        features['交易时间内股价涨跌幅≥±9.7%持续时间'] = current_data['交易时间内股价涨跌幅≥±9.7%持续时间']
    else:
        features['交易时间内股价涨跌幅≥±9.7%持续时间'] = 0
        
    if '交易时间内股价涨跌幅≥±19.7%持续时间' in current_data and not np.isnan(current_data['交易时间内股价涨跌幅≥±19.7%持续时间']):
        features['交易时间内股价涨跌幅≥±19.7%持续时间'] = current_data['交易时间内股价涨跌幅≥±19.7%持续时间']
    else:
        features['交易时间内股价涨跌幅≥±19.7%持续时间'] = 0
        
    if '交易时间内股价涨跌幅≥±4.7%持续时间' in current_data and not np.isnan(current_data['交易时间内股价涨跌幅≥±4.7%持续时间']):
        features['交易时间内股价涨跌幅≥±4.7%持续时间'] = current_data['交易时间内股价涨跌幅≥±4.7%持续时间']
    else:
        features['交易时间内股价涨跌幅≥±4.7%持续时间'] = 0
    
    # 8-10. 交易时间内股价涨跌幅≥±X%触及次数 (已从日内特征中计算)
    # 从日内特征中获取计算好的值
    if '交易时间内股价涨跌幅≥±9.7%触及次数' in current_data and not np.isnan(current_data['交易时间内股价涨跌幅≥±9.7%触及次数']):
        features['交易时间内股价涨跌幅≥±9.7%触及次数'] = current_data['交易时间内股价涨跌幅≥±9.7%触及次数']
    else:
        features['交易时间内股价涨跌幅≥±9.7%触及次数'] = 0
        
    if '交易时间内涨跌幅≥±19.7%触及次数' in current_data and not np.isnan(current_data['交易时间内涨跌幅≥±19.7%触及次数']):
        features['交易时间内涨跌幅≥±19.7%触及次数'] = current_data['交易时间内涨跌幅≥±19.7%触及次数']
    else:
        features['交易时间内涨跌幅≥±19.7%触及次数'] = 0
        
    if '交易时间内涨跌幅≥±4.7%触及次数' in current_data and not np.isnan(current_data['交易时间内涨跌幅≥±4.7%触及次数']):
        features['交易时间内涨跌幅≥±4.7%触及次数'] = current_data['交易时间内涨跌幅≥±4.7%触及次数']
    else:
        features['交易时间内涨跌幅≥±4.7%触及次数'] = 0
    
    # 获取历史数据用于计算其他特征
    # 取当前交易日及之前的所有历史数据
    all_historical_data = historical_data + [current_data]
    
    # 提取每日涨跌幅、收盘价、Vwap、总成交额等数据
    daily_returns = []
    closing_prices = []
    vwap_values = []
    total_turnovers = []
    daily_ranges = []  # 真实的每日振幅
    
    for data in all_historical_data:
        if '每日涨跌幅' in data and not np.isnan(data['每日涨跌幅']):
            daily_returns.append(data['每日涨跌幅'])
        if '当日收盘价' in data and not np.isnan(data['当日收盘价']):
            closing_prices.append(data['当日收盘价'])
        if '每日Vwap' in data and not np.isnan(data['每日Vwap']):
            vwap_values.append(data['每日Vwap'])
        if '每日总成交额' in data and not np.isnan(data['每日总成交额']):
            total_turnovers.append(data['每日总成交额'])
        if '每日振幅' in data and not np.isnan(data['每日振幅']):
            daily_ranges.append(data['每日振幅'])
        else:
            daily_ranges.append(0)  # 如果没有振幅数据，则为0
    
    # 11-16. 最近N个交易日累计涨跌幅和涨跌幅绝对值、振幅
    if len(daily_returns) >= 3:
        features['最近3个交易日累计涨跌幅绝对值'] = sum([abs(r) for r in daily_returns[-3:]])
        features['最近3个交易日累计涨跌幅'] = sum(daily_returns[-3:])
    else:
        features['最近3个交易日累计涨跌幅绝对值'] = 0
        features['最近3个交易日累计涨跌幅'] = 0
        
    if len(daily_returns) >= 5:
        features['最近5个交易日累计涨跌幅绝对值'] = sum([abs(r) for r in daily_returns[-5:]])
        features['最近5个交易日累计涨跌幅'] = sum(daily_returns[-5:])
    else:
        features['最近5个交易日累计涨跌幅绝对值'] = 0
        features['最近5个交易日累计涨跌幅'] = 0
    
    if len(daily_ranges) >= 3:
        features['最近3个交易日累计振幅'] = sum([r for r in daily_ranges[-3:]])
    else:
        features['最近3个交易日累计振幅'] = sum([r for r in daily_ranges])
        
    if len(daily_ranges) >= 5:
        features['最近5个交易日累计振幅'] = sum([r for r in daily_ranges[-5:]])
    else:
        features['最近5个交易日累计振幅'] = sum([r for r in daily_ranges])
    
    # 17-18. 累积至当日连续上涨/下跌天数
    consecutive_up = 0
    consecutive_down = 0
    for r in reversed(daily_returns):
        if r > 0:
            consecutive_up += 1
            consecutive_down = 0
        elif r < 0:
            consecutive_down += 1
            consecutive_up = 0
        else:
            break
    features['累积至当日连续上涨天数'] = consecutive_up
    features['累积至当日连续下跌天数'] = consecutive_down
    
    # 19. 当日总成交量/前一交易日总成交量
    if '每日总成交量' in previous_data and '每日总成交量' in current_data:
        if previous_data['每日总成交量'] != 0 and not np.isnan(previous_data['每日总成交量']):
            volume_ratio = current_data['每日总成交量'] / previous_data['每日总成交量']
            features['当日总成交量/前一交易日总成交量'] = volume_ratio
        else:
            features['当日总成交量/前一交易日总成交量'] = 1
    else:
        features['当日总成交量/前一交易日总成交量'] = 1
    
    # 20. (近3日日均总成交量)/(前5日日均总成交量)
    if len(all_historical_data) >= 5:
        recent_3_days_volume = [data['每日总成交量'] for data in all_historical_data[-3:] if '每日总成交量' in data and not np.isnan(data['每日总成交量'])]
        previous_5_days_volume = [data['每日总成交量'] for data in all_historical_data[-5:-3] if '每日总成交量' in data and not np.isnan(data['每日总成交量'])]
        
        if recent_3_days_volume and previous_5_days_volume:
            avg_recent_3 = sum(recent_3_days_volume) / len(recent_3_days_volume)
            avg_previous_5 = sum(previous_5_days_volume) / len(previous_5_days_volume)
            if avg_previous_5 != 0:
                features['(近3日日均总成交量)/(前5日日均总成交量)'] = avg_recent_3 / avg_previous_5
            else:
                features['(近3日日均总成交量)/(前5日日均总成交量)'] = 1
        else:
            features['(近3日日均总成交量)/(前5日日均总成交量)'] = 1
    else:
        features['(近3日日均总成交量)/(前5日日均总成交量)'] = 1
    
    # 21-22. 近N个交易日每日涨跌幅标准差
    if len(daily_returns) >= 5:
        features['近5个交易日每日涨跌幅标准差'] = np.std(daily_returns[-5:]) if len(daily_returns[-5:]) > 1 else 0
    else:
        features['近5个交易日每日涨跌幅标准差'] = 0
        
    if len(daily_returns) >= 10:
        features['近10个交易日每日涨跌幅标准差'] = np.std(daily_returns[-10:]) if len(daily_returns[-10:]) > 1 else 0
    else:
        features['近10个交易日每日涨跌幅标准差'] = 0
    
    # 23-26. 收盘价线性回归斜率和R^2
    if len(closing_prices) >= 5:
        X = np.array(range(len(closing_prices[-5:]))).reshape(-1, 1)
        y = np.array(closing_prices[-5:])
        # 过滤掉NaN值
        valid_indices = ~np.isnan(y)
        if np.sum(valid_indices) > 1:
            X_valid = X[valid_indices]
            y_valid = y[valid_indices]
            model = LinearRegression().fit(X_valid, y_valid)
            features['近5个交易日收盘价线性回归斜率'] = model.coef_[0]
            features['近5个交易日收盘价线性回归R^2'] = model.score(X_valid, y_valid)
        else:
            features['近5个交易日收盘价线性回归斜率'] = 0
            features['近5个交易日收盘价线性回归R^2'] = 0
    else:
        features['近5个交易日收盘价线性回归斜率'] = 0
        features['近5个交易日收盘价线性回归R^2'] = 0
        
    if len(closing_prices) >= 10:
        X = np.array(range(len(closing_prices[-10:]))).reshape(-1, 1)
        y = np.array(closing_prices[-10:])
        # 过滤掉NaN值
        valid_indices = ~np.isnan(y)
        if np.sum(valid_indices) > 1:
            X_valid = X[valid_indices]
            y_valid = y[valid_indices]
            model = LinearRegression().fit(X_valid, y_valid)
            features['对近10个交易日收盘价线性回归斜率'] = model.coef_[0]
            features['近10个交易日收盘价线性回归R^2'] = model.score(X_valid, y_valid)
        else:
            features['对近10个交易日收盘价线性回归斜率'] = 0
            features['近10个交易日收盘价线性回归R^2'] = 0
    else:
        features['对近10个交易日收盘价线性回归斜率'] = 0
        features['近10个交易日收盘价线性回归R^2'] = 0
    
    # 27. 近5个交易日 分钟涨跌幅≥±1% 的次数均值
    features['近5个交易日 分钟涨跌幅≥±1% 的次数均值'] = 0  # 需要分钟级数据
    
    # 28-30. 累积至当日 每日涨跌幅≥±X%的连续天数
    # 计算连续满足条件的天数
    consecutive_47 = 0
    consecutive_97 = 0
    consecutive_197 = 0
    
    for r in reversed(daily_returns):
        if abs(r) >= 0.047:
            consecutive_47 += 1
        else:
            break
            
    for r in reversed(daily_returns):
        if abs(r) >= 0.097:
            consecutive_97 += 1
        else:
            break
            
    for r in reversed(daily_returns):
        if abs(r) >= 0.197:
            consecutive_197 += 1
        else:
            break
    
    features['累积至当日 每日涨跌幅≥±4.7%的连续天数'] = consecutive_47
    features['累积至当日 每日涨跌幅≥±9.7%的连续天数'] = consecutive_97
    features['累积至当日 每日涨跌幅≥±19.7%的连续天数'] = consecutive_197
    
    # 31-32. 近N个交易日每日Vwap标准差
    if len(vwap_values) >= 5:
        features['近5个交易日每日Vwap标准差'] = np.std(vwap_values[-5:]) if len(vwap_values[-5:]) > 1 else 0
    else:
        features['近5个交易日每日Vwap标准差'] = 0
        
    if len(vwap_values) >= 10:
        features['近10个交易日每日Vwap标准差'] = np.std(vwap_values[-10:]) if len(vwap_values[-10:]) > 1 else 0
    else:
        features['近10个交易日每日Vwap标准差'] = 0
    
    # 33-36. 每日Vwap线性回归斜率和R^2
    if len(vwap_values) >= 5:
        X = np.array(range(len(vwap_values[-5:]))).reshape(-1, 1)
        y = np.array(vwap_values[-5:])
        # 过滤掉NaN值
        valid_indices = ~np.isnan(y)
        if np.sum(valid_indices) > 1:
            X_valid = X[valid_indices]
            y_valid = y[valid_indices]
            model = LinearRegression().fit(X_valid, y_valid)
            features['近5个交易日每日Vwap线性回归斜率'] = model.coef_[0]
            features['近5个交易日每日Vwap线性回归R^2'] = model.score(X_valid, y_valid)
        else:
            features['近5个交易日每日Vwap线性回归斜率'] = 0
            features['近5个交易日每日Vwap线性回归R^2'] = 0
    else:
        features['近5个交易日每日Vwap线性回归斜率'] = 0
        features['近5个交易日每日Vwap线性回归R^2'] = 0
        
    if len(vwap_values) >= 10:
        X = np.array(range(len(vwap_values[-10:]))).reshape(-1, 1)
        y = np.array(vwap_values[-10:])
        # 过滤掉NaN值
        valid_indices = ~np.isnan(y)
        if np.sum(valid_indices) > 1:
            X_valid = X[valid_indices]
            y_valid = y[valid_indices]
            model = LinearRegression().fit(X_valid, y_valid)
            features['对近10个交易日每日Vwap线性回归斜率'] = model.coef_[0]
            features['近10个交易日每日Vwap线性回归R^2'] = model.score(X_valid, y_valid)
        else:
            features['对近10个交易日每日Vwap线性回归斜率'] = 0
            features['近10个交易日每日Vwap线性回归R^2'] = 0
    else:
        features['对近10个交易日每日Vwap线性回归斜率'] = 0
        features['近10个交易日每日Vwap线性回归R^2'] = 0
    
    # 37-38. 近N个交易日每日总成交额标准差
    if len(total_turnovers) >= 5:
        features['近5个交易日每日总成交额标准差'] = np.std(total_turnovers[-5:]) if len(total_turnovers[-5:]) > 1 else 0
    else:
        features['近5个交易日每日总成交额标准差'] = 0
        
    if len(total_turnovers) >= 10:
        features['近10个交易日每日总成交额标准差'] = np.std(total_turnovers[-10:]) if len(total_turnovers[-10:]) > 1 else 0
    else:
        features['近10个交易日每日总成交额标准差'] = 0
    
    # 39-42. 每日总成交额回归分析
    if len(total_turnovers) >= 5:
        X = np.array(range(len(total_turnovers[-5:]))).reshape(-1, 1)
        y = np.array(total_turnovers[-5:])
        # 过滤掉NaN值
        valid_indices = ~np.isnan(y)
        if np.sum(valid_indices) > 1:
            X_valid = X[valid_indices]
            y_valid = y[valid_indices]
            model = LinearRegression().fit(X_valid, y_valid)
            features['近5个交易日每日总成交额回归斜率'] = model.coef_[0]
            features['近5个交易日每日总成交额回归R^2'] = model.score(X_valid, y_valid)
        else:
            features['近5个交易日每日总成交额回归斜率'] = 0
            features['近5个交易日每日总成交额回归R^2'] = 0
    else:
        features['近5个交易日每日总成交额回归斜率'] = 0
        features['近5个交易日每日总成交额回归R^2'] = 0
        
    if len(total_turnovers) >= 10:
        X = np.array(range(len(total_turnovers[-10:]))).reshape(-1, 1)
        y = np.array(total_turnovers[-10:])
        # 过滤掉NaN值
        valid_indices = ~np.isnan(y)
        if np.sum(valid_indices) > 1:
            X_valid = X[valid_indices]
            y_valid = y[valid_indices]
            model = LinearRegression().fit(X_valid, y_valid)
            features['对近10个交易日每日总成交额线性回归斜率'] = model.coef_[0]
            features['近10个交易日每日总成交额线性回归R^2'] = model.score(X_valid, y_valid)
        else:
            features['对近10个交易日每日总成交额线性回归斜率'] = 0
            features['近10个交易日每日总成交额线性回归R^2'] = 0
    else:
        features['对近10个交易日每日总成交额线性回归斜率'] = 0
        features['近10个交易日每日总成交额线性回归R^2'] = 0
    
    # 43. 近5个交易日每日振幅标准差
    if len(daily_ranges) >= 5:
        valid_ranges = [r for r in daily_ranges[-5:] if not np.isnan(r)]
        if valid_ranges:
            features['近5个交易日每日振幅标准差'] = np.std(valid_ranges) if len(valid_ranges) > 1 else 0
        else:
            features['近5个交易日每日振幅标准差'] = 0
    else:
        features['近5个交易日每日振幅标准差'] = 0
        
    # 44. 近10个交易日每日涨跌幅绝对值的标准差
    if len(daily_returns) >= 10:
        abs_returns = [abs(r) for r in daily_returns[-10:]]
        features['近10个交易日每日涨跌幅绝对值的标准差'] = np.std(abs_returns) if len(abs_returns) > 1 else 0
    else:
        features['近10个交易日每日涨跌幅绝对值的标准差'] = 0
    
    # 45-48. 每日振幅和涨跌幅绝对值线性回归
    if len(daily_ranges) >= 5:
        valid_ranges = [r for r in daily_ranges[-5:] if not np.isnan(r)]
        if len(valid_ranges) > 1:
            X = np.array(range(len(valid_ranges))).reshape(-1, 1)
            y = np.array(valid_ranges)
            model = LinearRegression().fit(X, y)
            features['近5个交易日每日振幅线性回归斜率'] = model.coef_[0]
            features['近5个交易日每日涨跌幅绝对值线性回归R^2'] = model.score(X, y)
        else:
            features['近5个交易日每日振幅线性回归斜率'] = 0
            features['近5个交易日每日涨跌幅绝对值线性回归R^2'] = 0
    else:
        features['近5个交易日每日振幅线性回归斜率'] = 0
        features['近5个交易日每日涨跌幅绝对值线性回归R^2'] = 0
        
    if len(daily_ranges) >= 10:
        valid_ranges = [r for r in daily_ranges[-10:] if not np.isnan(r)]
        if len(valid_ranges) > 1:
            X = np.array(range(len(valid_ranges))).reshape(-1, 1)
            y = np.array(valid_ranges)
            model = LinearRegression().fit(X, y)
            features['近10个交易日每日振幅线性回归斜率'] = model.coef_[0]
            features['近10个交易日每日涨跌幅绝对值线性回归R^2'] = model.score(X, y)
        else:
            features['近10个交易日每日振幅线性回归斜率'] = 0
            features['近10个交易日每日涨跌幅绝对值线性回归R^2'] = 0
    else:
        features['近10个交易日每日振幅线性回归斜率'] = 0
        features['近10个交易日每日涨跌幅绝对值线性回归R^2'] = 0
    
    return features
'''
def extract_features_from_all_files():
    """从所有原始数据文件中提取跨交易日趋势与惯性特征"""
    # 读取训练集和测试集标签
    train_labels = pd.read_csv('train.csv')
    testa_labels = pd.read_csv('testa.csv')
    
    # 合并训练集和测试集
    all_labels = pd.concat([train_labels, testa_labels], ignore_index=True)
    
    # 获取所有股票代码
    stock_codes = all_labels['code'].unique()
    
    # 特征列表
    all_features = []
    
    # 处理每个股票
    for code in tqdm(stock_codes, desc="处理股票"):
        # 获取该股票的所有交易日数据（合并train和testa目录）
        csv_files = []
        train_dir = f'train/{code}'
        testa_dir = f'testa/{code}'
        
        # 从train目录获取CSV文件
        if os.path.exists(train_dir):
            train_files = glob.glob(f'{train_dir}/*.csv')
            csv_files.extend(train_files)
        
        # 从testa目录获取CSV文件
        if os.path.exists(testa_dir):
            testa_files = glob.glob(f'{testa_dir}/*.csv')
            csv_files.extend(testa_files)
        
        if not csv_files:
            print(f"股票 {code} 没有找到CSV文件")
            continue
        
        # 按文件名排序（按交易日排序）
        csv_files.sort(key=lambda x: int(os.path.basename(x).split('.')[0]))
        
        # 为每个交易日计算日内特征
        daily_features_list = []
        for csv_file in csv_files:
            try:
                # 读取数据
                day_df = pd.read_csv(csv_file)
                
                # 检查必要列
                required_columns = ['time', 'price', 'volume']
                if not all(col in day_df.columns for col in required_columns):
                    print(f"文件 {csv_file} 缺少必要的列")
                    continue
                
                # 获取交易日
                day = int(os.path.basename(csv_file).split('.')[0])
                
                # 计算日内基础特征
                intraday_basic_features = calculate_intraday_basic_features(day_df)
                
                # 合并特征
                day_features = {
                    'code': code,
                    'day': day
                }
                day_features.update(intraday_basic_features)
                
                daily_features_list.append(day_features)
            except Exception as e:
                print(f"处理文件 {csv_file} 时出错: {e}")
                continue
        
        # 按日期排序
        daily_features_list = sorted(daily_features_list, key=lambda x: x['day'])
        
        # 为每个交易日计算跨交易日特征
        if daily_features_list:
            historical_data = []
            for i in range(len(daily_features_list)):
                # 取当前交易日的数据
                current_data = daily_features_list[i]
                
                # 计算跨交易日特征
                cross_day_features = calculate_cross_day_trend_features_for_day(current_data, historical_data)
                
                # 更新当前交易日的特征（保留原有特征并添加跨交易日特征）
                # 创建一个新的字典，复制current_data的所有字段
                updated_features = current_data.copy()
                # 更新跨交易日特征
                updated_features.update(cross_day_features)
                # 更新daily_features_list中的条目
                daily_features_list[i] = updated_features
                
                # 将当前交易日添加到历史数据中
                historical_data.append(current_data)
        
        # 将该股票的特征添加到总特征列表
        all_features.extend(daily_features_list)
    
    # 将所有特征转换为DataFrame（只包含跨交易日特征）
    features_df = pd.DataFrame(all_features)
    
    # 保存特征到CSV文件
    features_df.to_csv('extracted_features_cross_day_trend_only_all_files_new.csv', index=False)
    
    # 根据code分割训练集和测试集特征
    train_codes = set(train_labels['code'].unique())
    testa_codes = set(testa_labels['code'].unique())
    
    # 分割特征
    train_features = features_df[features_df['code'].isin(train_codes)]
    testa_features = features_df[features_df['code'].isin(testa_codes)]
    
    # 保存分割后的特征
    train_features.to_csv('train_extracted_features_cross_day_trend_only_all_files_new.csv', index=False)
    testa_features.to_csv('testa_extracted_features_cross_day_trend_only_all_files_new.csv', index=False)
    
    print("特征提取完成")
    print(f"总特征数: {len(features_df)}")
    print(f"训练集特征数: {len(train_features)}")
    print(f"测试集特征数: {len(testa_features)}")
    
    return features_df, train_features, testa_features

if __name__ == "__main__":
    # 运行特征提取
    features_df, train_features, testa_features = extract_features_from_all_files()
'''


def process_single_stock(args):
    """处理单个股票的跨交易日特征（多进程版本）"""
    stock_code, train_dir, testa_dir = args

    try:
        # 获取该股票的所有交易日数据
        csv_files = []
        train_path = os.path.join(train_dir, stock_code)
        testa_path = os.path.join(testa_dir, stock_code)

        # 从train目录获取CSV文件
        if os.path.exists(train_path):
            train_files = glob.glob(f'{train_path}/*.csv')
            csv_files.extend(train_files)

        # 从testa目录获取CSV文件
        if os.path.exists(testa_path):
            testa_files = glob.glob(f'{testa_path}/*.csv')
            csv_files.extend(testa_files)

        if not csv_files:
            print(f"股票 {stock_code} 没有找到CSV文件")
            return []

        # 按文件名排序（按交易日排序）
        csv_files.sort(key=lambda x: int(os.path.basename(x).split('.')[0]))

        # 为每个交易日计算日内特征
        daily_features_list = []
        for csv_file in csv_files:
            try:
                # 读取数据
                day_df = pd.read_csv(csv_file)

                # 检查必要列
                required_columns = ['time', 'price', 'volume']
                if not all(col in day_df.columns for col in required_columns):
                    print(f"文件 {csv_file} 缺少必要的列")
                    continue

                # 获取交易日
                day = int(os.path.basename(csv_file).split('.')[0])

                # 计算日内基础特征
                intraday_basic_features = calculate_intraday_basic_features(day_df)

                # 合并特征
                day_features = {
                    'code': stock_code,
                    'day': day
                }
                day_features.update(intraday_basic_features)

                daily_features_list.append(day_features)
            except Exception as e:
                print(f"处理文件 {csv_file} 时出错: {e}")
                continue

        # 按日期排序
        daily_features_list = sorted(daily_features_list, key=lambda x: x['day'])

        # 为每个交易日计算跨交易日特征
        if daily_features_list:
            historical_data = []
            for i in range(len(daily_features_list)):
                # 取当前交易日的数据
                current_data = daily_features_list[i]

                # 计算跨交易日特征
                cross_day_features = calculate_cross_day_trend_features_for_day(current_data, historical_data)

                # 更新当前交易日的特征（保留原有特征并添加跨交易日特征）
                updated_features = current_data.copy()
                updated_features.update(cross_day_features)
                daily_features_list[i] = updated_features

                # 将当前交易日添加到历史数据中
                historical_data.append(current_data)

        return daily_features_list

    except Exception as e:
        print(f"处理股票 {stock_code} 时出错: {e}")
        return []


def extract_features_from_all_files_multiprocess(num_processes=None):
    """从所有原始数据文件中提取跨交易日趋势与惯性特征（多进程版本）"""
    if num_processes is None:
        num_processes = cpu_count()

    # 读取训练集和测试集标签
    train_labels = pd.read_csv('train.csv')
    testa_labels = pd.read_csv('testa.csv')

    # 合并训练集和测试集
    all_labels = pd.concat([train_labels, testa_labels], ignore_index=True)

    # 获取所有股票代码
    stock_codes = all_labels['code'].unique()

    # 定义目录路径
    train_dir = 'train'
    testa_dir = 'testa'

    print(f"开始处理 {len(stock_codes)} 个股票，使用 {num_processes} 个进程")

    # 准备参数
    args_list = [(code, train_dir, testa_dir) for code in stock_codes]

    # 使用多进程池并行处理
    all_features = []

    with Pool(processes=num_processes) as pool:
        # 使用tqdm显示进度
        results = list(tqdm(pool.imap(process_single_stock, args_list),
                            total=len(stock_codes),
                            desc="处理股票"))

    # 收集所有结果
    for result in results:
        if result:
            all_features.extend(result)

    # 将所有特征转换为DataFrame
    features_df = pd.DataFrame(all_features)

    # 保存特征到CSV文件
    features_df.to_csv(
        'extracted_features_cross_day_trend_only_all_files_multiprocess.csv',
        index=False)

    # 根据code分割训练集和测试集特征
    train_codes = set(train_labels['code'].unique())
    testa_codes = set(testa_labels['code'].unique())

    # 分割特征
    train_features = features_df[features_df['code'].isin(train_codes)]
    testa_features = features_df[features_df['code'].isin(testa_codes)]

    # 保存分割后的特征
    train_features.to_csv(
        'train_extracted_features_cross_day_trend_only_all_files_multiprocess.csv',
        index=False)
    testa_features.to_csv(
        'testa_extracted_features_cross_day_trend_only_all_files_multiprocess.csv',
        index=False)

    print("多进程特征提取完成")
    print(f"总特征数: {len(features_df)}")
    print(f"训练集特征数: {len(train_features)}")
    print(f"测试集特征数: {len(testa_features)}")

    return features_df, train_features, testa_features


def extract_features_from_all_files_single_process():
    """单进程版本（用于对比性能）"""
    # 读取训练集和测试集标签
    train_labels = pd.read_csv('train.csv')
    testa_labels = pd.read_csv('testa.csv')

    # 合并训练集和测试集
    all_labels = pd.concat([train_labels, testa_labels], ignore_index=True)

    # 获取所有股票代码
    stock_codes = all_labels['code'].unique()

    # 特征列表
    all_features = []

    # 定义目录路径
    train_dir = 'train'
    testa_dir = 'testa'

    # 处理每个股票
    for code in tqdm(stock_codes, desc="处理股票"):
        # 获取该股票的所有交易日数据
        csv_files = []
        train_path = os.path.join(train_dir, code)
        testa_path = os.path.join(testa_dir, code)

        # 从train目录获取CSV文件
        if os.path.exists(train_path):
            train_files = glob.glob(f'{train_path}/*.csv')
            csv_files.extend(train_files)

        # 从testa目录获取CSV文件
        if os.path.exists(testa_path):
            testa_files = glob.glob(f'{testa_path}/*.csv')
            csv_files.extend(testa_files)

        if not csv_files:
            print(f"股票 {code} 没有找到CSV文件")
            continue

        # 按文件名排序（按交易日排序）
        csv_files.sort(key=lambda x: int(os.path.basename(x).split('.')[0]))

        # 为每个交易日计算日内特征
        daily_features_list = []
        for csv_file in csv_files:
            try:
                # 读取数据
                day_df = pd.read_csv(csv_file)

                # 检查必要列
                required_columns = ['time', 'price', 'volume']
                if not all(col in day_df.columns for col in required_columns):
                    print(f"文件 {csv_file} 缺少必要的列")
                    continue

                # 获取交易日
                day = int(os.path.basename(csv_file).split('.')[0])

                # 计算日内基础特征
                intraday_basic_features = calculate_intraday_basic_features(day_df)

                # 合并特征
                day_features = {
                    'code': code,
                    'day': day
                }
                day_features.update(intraday_basic_features)

                daily_features_list.append(day_features)
            except Exception as e:
                print(f"处理文件 {csv_file} 时出错: {e}")
                continue

        # 按日期排序
        daily_features_list = sorted(daily_features_list, key=lambda x: x['day'])

        # 为每个交易日计算跨交易日特征
        if daily_features_list:
            historical_data = []
            for i in range(len(daily_features_list)):
                # 取当前交易日的数据
                current_data = daily_features_list[i]

                # 计算跨交易日特征
                cross_day_features = calculate_cross_day_trend_features_for_day(current_data, historical_data)

                # 更新当前交易日的特征（保留原有特征并添加跨交易日特征）
                updated_features = current_data.copy()
                updated_features.update(cross_day_features)
                daily_features_list[i] = updated_features

                # 将当前交易日添加到历史数据中
                historical_data.append(current_data)

        # 将该股票的特征添加到总特征列表
        all_features.extend(daily_features_list)

    # 将所有特征转换为DataFrame
    features_df = pd.DataFrame(all_features)

    # 保存特征到CSV文件
    features_df.to_csv(
        'extracted_features_cross_day_trend_only_all_files_single_process.csv',
        index=False)

    # 根据code分割训练集和测试集特征
    train_codes = set(train_labels['code'].unique())
    testa_codes = set(testa_labels['code'].unique())

    # 分割特征
    train_features = features_df[features_df['code'].isin(train_codes)]
    testa_features = features_df[features_df['code'].isin(testa_codes)]

    # 保存分割后的特征
    train_features.to_csv(
        'train_extracted_features_cross_day_trend_only_all_files_single_process.csv',
        index=False)
    testa_features.to_csv(
        'testa_extracted_features_cross_day_trend_only_all_files_single_process.csv',
        index=False)

    print("单进程特征提取完成")
    print(f"总特征数: {len(features_df)}")
    print(f"训练集特征数: {len(train_features)}")
    print(f"测试集特征数: {len(testa_features)}")

    return features_df, train_features, testa_features


if __name__ == "__main__":
    import time

    # 运行多进程版本
    print("=== 多进程跨交易日特征提取 ===")
    start_time = time.time()
    features_multi, train_multi, testa_multi = extract_features_from_all_files_multiprocess(num_processes=8)
    multi_time = time.time() - start_time

    print(f"多进程耗时: {multi_time:.2f}秒")

    # 如果需要性能对比，可以取消注释下面的代码
    """
    print(f"\n=== 单进程版本 ===")
    start_time = time.time()
    features_single, train_single, testa_single = extract_features_from_all_files_single_process()
    single_time = time.time() - start_time

    print(f"\n=== 性能对比 ===")
    print(f"多进程耗时: {multi_time:.2f}秒")
    print(f"单进程耗时: {single_time:.2f}秒")
    print(f"加速比: {single_time/multi_time:.2f}x")
    """