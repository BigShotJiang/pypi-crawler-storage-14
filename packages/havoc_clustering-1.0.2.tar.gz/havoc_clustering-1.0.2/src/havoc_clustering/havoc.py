import os
import shutil
from dataclasses import dataclass, field
import cv2
import ast
import pathlib
import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import matplotlib as mpl
from scipy.cluster.hierarchy import dendrogram, linkage
import pandas as pd

from havoc_clustering.general_utility.ai.tileextractor import TileExtractor
from havoc_clustering import correlation_of_dlfv_groups
from havoc_clustering.general_utility import unique_colors
from havoc_clustering.feature_extractor import FeatureExtractor


# from general_utility.ai.tileextractor import TileExtractor
# import correlation_of_dlfv_groups
# from general_utility import unique_colors
# from feature_extractor import FeatureExtractor


@dataclass(slots=True)
class HAVOCConfig:
    out_dir: str = './'
    k_vals: list[int] = field(default_factory=lambda: [7, 8, 9])
    save_tiles_k_vals: list[int] = field(default_factory=list)

    tile_size: int = 512
    desired_tile_mpp: float = 0.504
    safe_mpp: bool = False

    min_tissue_amt: float = 0.5

    extra_metrics: list[str] = field(default_factory=lambda: ['tsne', 'dendrogram', 'corr_clustmap'])

    def __post_init__(self):
        if not set(self.save_tiles_k_vals).issubset(self.k_vals):
            raise ValueError("save_tiles_k_vals must be a subset of k_vals")


class HAVOC:

    def __init__(self, havoc_config):
        self.config = havoc_config
        self.feature_extractor = FeatureExtractor()
        self.save_tiles = bool(havoc_config.save_tiles_k_vals)

        pathlib.Path(havoc_config.out_dir).mkdir(parents=True, exist_ok=True)

    def run(self, slide):

        curr_out_dir = os.path.join(self.config.out_dir, slide.name)
        pathlib.Path(curr_out_dir).mkdir(parents=True, exist_ok=True)

        df, thumbnail = self.process_dlfvs(slide, curr_out_dir=curr_out_dir)
        df['Coor'] = df['Coor'].apply(ast.literal_eval)

        for k in self.config.k_vals:
            cluster_info_df = self.create_cluster_info_df(
                df[[str(x) for x in range(1, self.feature_extractor.num_features + 1)]], k, linkage_method='ward')
            df = pd.concat([cluster_info_df, df], axis=1)

        df.to_csv(os.path.join(curr_out_dir, 'cluster_info_df.csv'), index=None)

        for k in self.config.k_vals:
            self.create_colortiled_slide(df, thumbnail, target_k=k, curr_out_dir=curr_out_dir)

            if 'dendrogram' in self.config.extra_metrics:
                self.make_dendrogram(df, target_k=k, curr_out_dir=curr_out_dir)
            if 'tsne' in self.config.extra_metrics:
                self.make_tsne(df, target_k=k, curr_out_dir=curr_out_dir)
            if 'corr_clustmap' in self.config.extra_metrics:
                correlation_of_dlfv_groups.create_correlation_clustermap_single_slide(curr_out_dir, target_k=k)

        if self.save_tiles:
            # done copying to k color folders
            shutil.rmtree(os.path.join(curr_out_dir, 'tiles', 'tmp'))

    def process_dlfvs(self, slide, curr_out_dir):

        if self.save_tiles:
            # we save all the tiles to a tmp folder and then copy the tiles into color folders when we do colortiling
            pathlib.Path(os.path.join(curr_out_dir, 'tiles', 'tmp')).mkdir(parents=True, exist_ok=True)

        print(f'Processing {slide.name}...')

        te = TileExtractor(slide, self.config.tile_size, desired_tile_mpp=self.config.desired_tile_mpp,
                           safe_mpp=self.config.safe_mpp)
        gen = te.iterate_tiles2(min_tissue_amt=self.config.min_tissue_amt, batch_size=4)

        coors = []
        coors_raw = []
        dlfvs = []
        amt_tissues = []
        for res in gen:
            tiles, currcoors, currcoors_raw, amt_tissue = res['tiles'], res['coordinates'], res['coordinates_raw'], res[
                'amt_tissue']

            currdlfvs = self.feature_extractor.process(tiles)

            coors.append(currcoors)
            coors_raw.append(currcoors_raw)
            dlfvs.append(currdlfvs)
            amt_tissues.append(amt_tissue)

            if self.save_tiles:
                # each iteration contains a batch of tiles
                for pos in range(len(tiles)):
                    curr_sp = os.path.join(curr_out_dir, 'tiles', 'tmp', str(tuple(currcoors[pos].tolist())) + '.jpg')
                    cv2.imwrite(curr_sp, tiles[pos])

        # we go through the whole slide so the extraction map is slide's thumbnail
        cv2.imwrite(os.path.join(curr_out_dir, 'thumbnail.jpg'), te.extraction_map.image)

        dlfvs = np.concatenate(dlfvs)
        coors = np.concatenate(coors)
        coors_raw = np.concatenate(coors_raw)
        amt_tissues = np.concatenate(amt_tissues)

        df = pd.DataFrame(dlfvs, columns=[str(x) for x in range(1, self.feature_extractor.num_features + 1)])
        df['Slide'] = [slide.name] * len(df)
        df['Coor'] = [str(x) for x in coors.tolist()]
        df['Coor_Raw'] = [str(x) for x in coors_raw.tolist()]
        df['AmtTissue'] = [round(x, 4) for x in amt_tissues]

        return df, te.extraction_map

    # cluster the data into k groups and assign each a color
    def create_cluster_info_df(self, X, k, linkage_method='ward'):

        cluster = AgglomerativeClustering(n_clusters=k, linkage=linkage_method)
        cluster_labels = cluster.fit_predict(X)

        temp_df = pd.DataFrame({f'Cluster_{k}': cluster_labels})

        color_gen = unique_colors.next_color_generator(scaled=False, mode='rgb', shuffle=False)
        cluster_to_color = {c: next(color_gen) for c in sorted(np.unique(cluster_labels))}
        temp_df[f'Cluster_color_name_{k}'] = temp_df[f'Cluster_{k}'].apply(lambda x: cluster_to_color[x]['name'])
        temp_df[f'Cluster_color_rgb_{k}'] = temp_df[f'Cluster_{k}'].apply(lambda x: cluster_to_color[x]['val'])

        return temp_df

    def create_colortiled_slide(self, cluster_info_df, thumbnail, target_k, curr_out_dir):
        '''
        Using a dict mapping cluster to coordinates, creates bordered boxes all throughout the image.
        Optionally, save the tiles belonging to each color cluster
        '''

        # make the color folders for saving the actual tiles
        if target_k in self.config.save_tiles_k_vals:
            for c in cluster_info_df[f'Cluster_color_name_{target_k}'].unique():
                pathlib.Path(os.path.join(curr_out_dir, 'tiles', str(target_k), c)).mkdir(parents=True, exist_ok=True)

                coords = cluster_info_df['Coor'][cluster_info_df[f'Cluster_color_name_{target_k}'] == c]
                for _, coord in coords.items():
                    fname = str(tuple(coord)) + '.jpg'
                    try:
                        shutil.copy2(os.path.join(curr_out_dir, 'tiles', 'tmp', fname),
                                     os.path.join(curr_out_dir, 'tiles', str(target_k), c, fname))
                    except FileNotFoundError:
                        print(f'Tile for coordinate {coord} not found')

        # group on cluster color and get all the associated coordinates
        for color, coors in cluster_info_df.groupby(f'Cluster_color_rgb_{target_k}')['Coor'].apply(
                list).to_dict().items():
            # change rgb to bgr
            thumbnail.add_borders(coors, color=color[::-1], border_thickness=0.1)

        cv2.imwrite(
            os.path.join(curr_out_dir, 'k{}_colortiled.jpg'.format(target_k)),
            thumbnail.image
        )

    def make_tsne(self, cluster_info_df, target_k, curr_out_dir):
        print('Generating TSNE')

        res = TSNE(2).fit_transform(
            cluster_info_df[[str(x) for x in range(1, self.feature_extractor.num_features + 1)]])

        tsne_df = pd.DataFrame({'TSNE_X': res[:, 0], 'TSNE_Y': res[:, 1]})

        tsne_df['Cluster_color_hex'] = cluster_info_df[f'Cluster_color_rgb_{target_k}'].apply(
            lambda rgb_tuple: mpl.colors.rgb2hex([x / 255. for x in rgb_tuple]))

        # go through each cluster and get the data belonging to it. plot it with its corresponding color
        plt.close('all')
        for hex, rows in tsne_df.groupby('Cluster_color_hex'):
            plt.scatter(
                rows['TSNE_X'],
                rows['TSNE_Y'],
                s=20,
                c=[hex] * len(rows)
            )

        sp = os.path.join(curr_out_dir, 'k{}_tsne.jpg'.format(target_k))
        plt.savefig(sp, dpi=200, bbox_inches='tight')

    def make_dendrogram(self, cluster_info_df, target_k, curr_out_dir):
        print('Generating dendrogram')

        cluster_color_hex = cluster_info_df[f'Cluster_color_rgb_{target_k}'].apply(
            lambda rgb_tuple: mpl.colors.rgb2hex([x / 255. for x in rgb_tuple]))
        Z = linkage(cluster_info_df[[str(x) for x in range(1, self.feature_extractor.num_features + 1)]], 'ward')

        # NOTE: THIS IS FOR MAKING DENDROGRAM COLORS MATCH THE COLORTILE SLIDE
        link_cols = {}
        for i, i12 in enumerate(Z[:, :2].astype(int)):
            c1, c2 = (link_cols[x] if x > len(Z) else cluster_color_hex.loc[x]
                      for x in i12)
            link_cols[i + 1 + len(Z)] = c1 if c1 == c2 else '#0000FF'

        plt.close('all')
        plt.title('Hierarchical Clustering Dendrogram')
        plt.ylabel('distance')

        dendrogram(
            Z,
            no_labels=True,
            color_threshold=None,
            link_color_func=lambda x: link_cols[x]
        )

        sp = os.path.join(curr_out_dir, 'k{}_dendrogram.jpg'.format(target_k))
        plt.savefig(sp, dpi=200, bbox_inches='tight')
