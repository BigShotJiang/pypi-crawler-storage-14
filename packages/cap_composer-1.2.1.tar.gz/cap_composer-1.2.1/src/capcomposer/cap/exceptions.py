class CAPAlertImportError(Exception):
    pass
