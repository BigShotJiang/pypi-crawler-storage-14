import setuptools

setuptools.setup(
    name='jsppy',
    version='1.2.9',
    description='jsppy数据接口',
    author='jsppy数据接口',
    packages=setuptools.find_packages(),
    package_data={
        'cmes': ['*.csv','*.pyc','*.dll']
    },
    install_requires=[
            'click',
            'six',
            'cryptography',
        "beautifulsoup4>=4.9.1",
        "lxml>=4.2.1",
        "pandas>=0.25",
        "requests>=2.22.0",
        "pypinyin>=0.35.0",
        "html5lib>=1.0.1",
        "xlrd>=1.2.0",
        "urllib3>=1.25.8",
        "tqdm>=4.43.0",
        "openpyxl>=3.0.3",
        "jsonpath>=0.82",
        "tabulate>=0.8.6",
        "decorator>=4.4.2",
    ]
)
