from mcp.server.fastmcp import FastMCP
import ffmpeg
import os
import tempfile
import shutil
import subprocess
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

# 配置日志输出到stderr，避免干扰MCP通信
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

package = "video-cover-mcp"

# 使用用户临时目录存放日志文件
log_dir = Path(tempfile.gettempdir()) / package
log_dir.mkdir(exist_ok=True)
log_file = log_dir / "debug.log"

file_handler = RotatingFileHandler(
    str(log_file), maxBytes=5_000_000, backupCount=3, encoding="utf-8"
)
file_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
)
logger.addHandler(file_handler)
logger.propagate = False

# 支持自定义 FFmpeg 路径
FFMPEG_BINARY = os.environ.get("FFMPEG_BINARY", "ffmpeg")
FFPROBE_BINARY = os.environ.get("FFPROBE_BINARY", "ffprobe")


def _ffmpeg_run(stream_spec, **kwargs):
    if "overwrite_output" not in kwargs:
        kwargs["overwrite_output"] = True
    return ffmpeg.run(stream_spec, cmd=FFMPEG_BINARY, **kwargs)


def _ffprobe_probe(path: str, **kwargs):
    return ffmpeg.probe(path, cmd=FFPROBE_BINARY, **kwargs)


def _get_media_properties(media_path: str) -> dict:
    try:
        probe = _ffprobe_probe(media_path)
        video_stream_info = next(
            (s for s in probe["streams"] if s["codec_type"] == "video"), None
        )
        audio_stream_info = next(
            (s for s in probe["streams"] if s["codec_type"] == "audio"), None
        )

        props = {
            "duration": float(probe["format"].get("duration", 0.0)),
            "has_video": video_stream_info is not None,
            "has_audio": audio_stream_info is not None,
            "width": int(video_stream_info["width"])
            if video_stream_info and "width" in video_stream_info
            else 0,
            "height": int(video_stream_info["height"])
            if video_stream_info and "height" in video_stream_info
            else 0,
            "avg_fps": 0,
            "sample_rate": int(audio_stream_info["sample_rate"])
            if audio_stream_info and "sample_rate" in audio_stream_info
            else 44100,
            "channels": int(audio_stream_info["channels"])
            if audio_stream_info and "channels" in audio_stream_info
            else 2,
        }
        if (
            video_stream_info
            and "avg_frame_rate" in video_stream_info
            and video_stream_info["avg_frame_rate"] != "0/0"
        ):
            num, den = map(int, video_stream_info["avg_frame_rate"].split("/"))
            if den > 0:
                props["avg_fps"] = num / den
            else:
                props["avg_fps"] = 30
        else:
            props["avg_fps"] = 30
        return props
    except ffmpeg.Error as e:
        raise RuntimeError(
            f"Error probing file {media_path}: {e.stderr.decode('utf8') if e.stderr else str(e)}"
        )
    except Exception as e:
        raise RuntimeError(f"Unexpected error probing file {media_path}: {str(e)}")


def _prepare_path(input_path: str, output_path: str) -> None:
    if not os.path.exists(input_path):
        raise RuntimeError(f"Error: Input file not found at {input_path}")
    try:
        parent_dir = os.path.dirname(output_path)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
    except Exception as e:
        raise RuntimeError(
            f"Error creating output directory for {output_path}: {str(e)}"
        )
    if os.path.exists(output_path):
        raise RuntimeError(
            f"Error: Output file already exists at {output_path}. Please choose a different path or delete the existing file."
        )


mcp = FastMCP("VideoCoverServer")


@mcp.tool()
def add_cover_image(
    video_path: str,
    cover_image_path: str,
    output_video_path: str,
    cover_duration: float = 3.0,
    fade_duration: float = 0.5,
) -> str:
    """为视频添加封面图片（作为首帧/片头）。

    Args:
        video_path: 输入视频文件路径。
        cover_image_path: 封面图片文件路径（支持 PNG、JPG 等格式）。
        output_video_path: 输出视频文件路径。
        cover_duration: 封面图片显示时长（秒，默认 3.0）。
        fade_duration: 淡入淡出过渡时长（秒，默认 0.5）。

    Returns:
        成功或失败的状态消息。
    """
    _prepare_path(video_path, output_video_path)

    if not os.path.exists(cover_image_path):
        raise RuntimeError(f"Error: Cover image file not found at {cover_image_path}")

    if cover_duration <= 0:
        raise RuntimeError("Error: Cover duration must be positive.")
    if fade_duration < 0:
        raise RuntimeError("Error: Fade duration cannot be negative.")
    if fade_duration > cover_duration:
        raise RuntimeError("Error: Fade duration cannot exceed cover duration.")

    temp_dir = tempfile.mkdtemp()
    try:
        # 获取视频属性
        props = _get_media_properties(video_path)
        if not props["has_video"]:
            raise RuntimeError("Error: Input file has no video stream.")

        video_width = props["width"]
        video_height = props["height"]
        video_fps = props["avg_fps"] if props["avg_fps"] > 0 else 30
        sample_rate = props["sample_rate"]
        channels = props["channels"]

        # 创建封面视频片段（从图片生成）
        cover_video_path = os.path.join(temp_dir, "cover.mp4")

        # 使用 FFmpeg 将图片转换为视频，并添加淡出效果
        fade_out_start = cover_duration - fade_duration

        try:
            # 生成封面视频：缩放图片到视频尺寸，添加淡出效果，生成静音音轨
            cmd = [
                FFMPEG_BINARY,
                "-loop", "1",
                "-i", cover_image_path,
                "-f", "lavfi",
                "-i", f"anullsrc=channel_layout=stereo:sample_rate={sample_rate}",
                "-vf", f"scale={video_width}:{video_height}:force_original_aspect_ratio=decrease,pad={video_width}:{video_height}:(ow-iw)/2:(oh-ih)/2,fade=t=out:st={fade_out_start}:d={fade_duration}",
                "-c:v", "libx264",
                "-pix_fmt", "yuv420p",
                "-c:a", "aac",
                "-t", str(cover_duration),
                "-r", str(video_fps),
                "-y",
                cover_video_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Error creating cover video: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )

        # 标准化主视频（确保格式一致）
        normalized_video_path = os.path.join(temp_dir, "normalized.mp4")
        try:
            # 为主视频添加淡入效果
            cmd = [
                FFMPEG_BINARY,
                "-i", video_path,
                "-vf", f"fade=t=in:st=0:d={fade_duration}",
                "-c:v", "libx264",
                "-pix_fmt", "yuv420p",
                "-c:a", "aac",
                "-r", str(video_fps),
                "-y",
                normalized_video_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Error normalizing video: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )

        # 创建 concat 文件列表
        concat_list_path = os.path.join(temp_dir, "concat_list.txt")
        with open(concat_list_path, "w") as f:
            f.write(f"file '{cover_video_path}'\n")
            f.write(f"file '{normalized_video_path}'\n")

        # 拼接封面和主视频
        try:
            cmd = [
                FFMPEG_BINARY,
                "-f", "concat",
                "-safe", "0",
                "-i", concat_list_path,
                "-c", "copy",
                "-y",
                output_video_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Error concatenating videos: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )

        return f"Cover image added successfully. Output saved to {output_video_path}"

    except Exception as e:
        raise RuntimeError(f"An unexpected error occurred: {str(e)}")
    finally:
        shutil.rmtree(temp_dir)


@mcp.tool()
def add_basic_transitions(
    video_path: str,
    output_video_path: str,
    transition_type: str,
    duration_seconds: float,
) -> str:
    """为整段视频添加淡入或淡出过渡效果。

    Args:
        video_path: 输入视频文件路径。
        output_video_path: 输出视频文件路径。
        transition_type: 过渡类型，'fade_in' 或 'fade_out'。
        duration_seconds: 过渡时长（秒，>0）。

    Returns:
        A status message indicating success or failure.
    """
    _prepare_path(video_path, output_video_path)
    if duration_seconds <= 0:
        raise RuntimeError("Error: Transition duration must be positive.")
    try:
        props = _get_media_properties(video_path)
        video_total_duration = props["duration"]
        if duration_seconds > video_total_duration:
            raise RuntimeError(
                f"Error: Transition duration ({duration_seconds}s) cannot exceed video duration ({video_total_duration}s)."
            )
        input_stream = ffmpeg.input(video_path)
        video_stream = input_stream.video
        audio_stream = input_stream.audio
        if transition_type == "fade_in" or transition_type == "crossfade_from_black":
            processed_video = video_stream.filter(
                "fade", type="in", start_time=0, duration=duration_seconds
            )
        elif transition_type == "fade_out" or transition_type == "crossfade_to_black":
            fade_start_time = video_total_duration - duration_seconds
            processed_video = video_stream.filter(
                "fade",
                type="out",
                start_time=fade_start_time,
                duration=duration_seconds,
            )
        else:
            raise RuntimeError(
                f"Error: Unsupported transition_type '{transition_type}'. Supported: 'fade_in', 'fade_out'."
            )

        output_streams = []
        if props["has_video"]:
            output_streams.append(processed_video)
        if props["has_audio"]:
            output_streams.append(audio_stream)
        if not output_streams:
            raise RuntimeError(
                "Error: No suitable video or audio streams found to apply transition."
            )
        try:
            output_kwargs = {"vcodec": "libx264", "pix_fmt": "yuv420p"}
            if props["has_audio"]:
                output_kwargs["acodec"] = "copy"
            _ffmpeg_run(
                ffmpeg.output(*output_streams, output_video_path, **output_kwargs),
                capture_stdout=True,
                capture_stderr=True,
            )
            return f"Transition '{transition_type}' applied successfully. Output: {output_video_path}"
        except ffmpeg.Error as e_acopy:
            try:
                _ffmpeg_run(
                    ffmpeg.output(
                        *output_streams,
                        output_video_path,
                        vcodec="libx264",
                        pix_fmt="yuv420p",
                    ),
                    capture_stdout=True,
                    capture_stderr=True,
                )
                return f"Transition '{transition_type}' applied successfully. Output: {output_video_path}"
            except ffmpeg.Error as e_recode:
                err_acopy = (
                    e_acopy.stderr.decode("utf8") if e_acopy.stderr else str(e_acopy)
                )
                err_recode = (
                    e_recode.stderr.decode("utf8") if e_recode.stderr else str(e_recode)
                )
                raise RuntimeError(
                    f"Error applying transition. Audio copy failed: {err_acopy}. Full re-encode failed: {err_recode}."
                )
    except ffmpeg.Error as e:
        error_message = e.stderr.decode("utf8") if e.stderr else str(e)
        raise RuntimeError(f"Error applying basic transition: {error_message}")
    except ValueError as e:
        raise RuntimeError(f"Error with input values: {str(e)}")
    except RuntimeError as e:
        raise RuntimeError(f"Runtime error during transition processing: {str(e)}")
    except Exception as e:
        raise RuntimeError(
            f"An unexpected error occurred in add_basic_transitions: {str(e)}"
        )


def main():
    """Main entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
