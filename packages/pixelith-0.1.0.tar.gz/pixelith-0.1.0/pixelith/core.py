def hello(name: str):
    return f"Selam {name}, Pixelith modülü başarıyla çalışıyor!"

def add(a, b):
    return a + b

def reverse(text: str):
    return text[::-1]