# Scripts

These scripts can be used to enhance GAM's capabilities; all are supported with GAM7,
many are supported with Legacy GAM. They require that Python 3.10 or higher be installed on your computer.

* https://github.com/taers232c/GAM-Scripts3
* https://www.python.org/
