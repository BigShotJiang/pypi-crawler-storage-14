from mitsuki.cli.bootstrap import main

__all__ = ["main"]
