"""Robust Python."""
