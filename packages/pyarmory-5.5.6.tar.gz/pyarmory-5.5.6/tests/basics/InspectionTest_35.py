#     Copyright 2025, QutaYba, nasr2python@gmail.com find license text at end of file


"""Tests uncompiled functions and compiled functions responses to inspect and isistance.  """

import inspect
import types

# qutayba-project: --python-flag=no_warnings


async def someCoroutine():
    async with _x:
        pass


print("Function 'someCoroutine' has result type:", type(someCoroutine()))

assert inspect.isfunction(someCoroutine) is True
assert inspect.isfunction(someCoroutine()) is False
assert inspect.isgeneratorfunction(someCoroutine) is False
assert inspect.isgeneratorfunction(someCoroutine()) is False
assert inspect.iscoroutinefunction(someCoroutine) is True
assert inspect.iscoroutinefunction(someCoroutine()) is False
assert inspect.isawaitable(someCoroutine) is False
assert inspect.isawaitable(someCoroutine()) is True

assert isinstance(someCoroutine(), types.GeneratorType) is False
assert isinstance(someCoroutine(), types.CoroutineType) is True
assert type(someCoroutine()) == types.CoroutineType, type(someCoroutine())
assert isinstance(someCoroutine, types.CoroutineType) is False

print("OK.")

#     Python tests originally created or extracted from other peoples work. The
#     parts were too small to be protected.
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
