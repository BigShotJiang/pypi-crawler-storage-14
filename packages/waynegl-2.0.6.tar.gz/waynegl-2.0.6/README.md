# Wayne Graphics

**Wayne Graphics** is a custom graphics engine inspired by CMU‑style graphics, rewritten with its own pixel renderer.  
It also includes two CLI tools: an **AI explainer** and an **API server** for remote shape creation and control.

---

## ✨ Features

- 🎨 **Custom Renderer** — pixel‑based graphics engine with shapes, groups, events, and widgets.
- 🟢 **Shapes** — Arc, Circle, Polygon, Rectangle, Star, Line, Image, Point.
- 📦 **Groups** — combine shapes into reusable containers with transformations.
- 🖱️ **Events** — mouse, keyboard, and step callbacks via a clean event bus.
- 🧩 **Widgets** — buttons, sliders, labels, and more built on top of shapes.
- 🌐 **API Router** — HTTP server to create and manipulate shapes remotely.
- 🤖 **AI Explainer** — CLI tool that provides code explanations and tutoring.

---

## 📦 Installation

```bash
pip install wayneGL

