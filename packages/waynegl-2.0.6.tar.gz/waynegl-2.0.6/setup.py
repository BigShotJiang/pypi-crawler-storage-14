from setuptools import setup, find_packages
import pathlib

# Read the README file safely
here = pathlib.Path(__file__).parent
long_description = (here / "README.md").read_text(encoding="utf-8")

setup(
    name="wayneGL",
    version="2.0.6",
    packages=find_packages(include=["graphics", "graphics.*"]),
    install_requires=[
        # Add any dependencies your custom renderer needs, e.g.:
        # "pygame>=2.5.0",
    ],
    description="Custom CMU-style graphics engine with own renderer",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Wayne Durbin",
    author_email="your.email@example.com",  # optional but recommended
    url="https://github.com/yourusername/wayneGL",  # optional project URL
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "Topic :: Multimedia :: Graphics",
    ],
    python_requires=">=3.9",
)