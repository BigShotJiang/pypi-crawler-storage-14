import subprocess
import sys
import shutil

OLLAMA_URL = "https://ollama.com/download/ollama-installer"
DEEPSEEK_URL = "https://deepseek-model-url.com/deepseek_32b.tar.gz"

def run_command(cmd, desc="Running command"):
    print(f"{desc}: {' '.join(cmd)}")
    result = subprocess.run(cmd, check=False)
    if result.returncode != 0:
        print(f"Error during {desc}!")
        sys.exit(result.returncode)

def install_ollama():
    print("Downloading Ollama...")
    run_command(["curl", "-sSL", OLLAMA_URL, "-o", "ollama-installer.sh"], "Downloading Ollama")
    run_command(["bash", "ollama-installer.sh"], "Installing Ollama")
    print("Ollama installed successfully.")

def install_deepseek():
    print("Downloading DeepSeek 32B...")
    run_command(["curl", "-sSL", DEEPSEEK_URL, "-o", "deepseek_32b.tar.gz"], "Downloading DeepSeek")
    run_command(["tar", "-xzvf", "deepseek_32b.tar.gz"], "Extracting DeepSeek")
    print("DeepSeek 32B installed successfully.")

def main():
    print("=== LMMH Installer ===")
    if shutil.which("curl") is None:
        print("Error: curl is required but not installed.")
        sys.exit(1)
    install_ollama()
    install_deepseek()
    print("Done!")

if __name__ == "__main__":
    main()

