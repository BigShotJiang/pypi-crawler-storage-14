__all__ = ["Check_Internet_Connection_LMMH"]



import socket

def Check_Internet_Connection_LMMH():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

