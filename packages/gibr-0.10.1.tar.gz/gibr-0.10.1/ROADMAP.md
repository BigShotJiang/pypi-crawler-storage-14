# 🧭 gibr Roadmap

This roadmap outlines upcoming features and priorities for the gibr CLI.

## ✅ Recently Completed
- [x] Support for Monday.com (#22)
- [x] Support for YouTrack (#50)

## 🧩 Planned new issue tracker plugins
- [ ] Support for Forgejo (#44)

## 🚧 Planned features
- [ ] Support dry run flag (#39)
- [ ] Issue types derived from labels (#38)

## 🔮 Future
- [ ] If issue is unassigned, assign to current user
- [ ] Allow user to specify branch format during `init`
- [ ] Add support for integration with git repo hosts (GitHub, GitLab, Bitbucket, etc.)
- [ ] `gibr pr` / `gibr mr` command to create pull/merge requests
- [ ] `gibr config` command to manage settings interactively
- [ ] Autocomplete (preview)


## 💡 Ideas (Open for Discussion)
- [ ] Allow multiple issue trackers for the same project
