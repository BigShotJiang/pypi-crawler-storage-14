from pydantic import BaseModel

from .currency import Currency


class SalePrice(BaseModel):
    value: float
    currency: Currency
