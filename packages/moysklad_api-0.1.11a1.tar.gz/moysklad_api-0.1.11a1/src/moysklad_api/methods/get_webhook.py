from pydantic import Field

from moysklad_api.methods import MSMethod
from moysklad_api.types import Webhook


class GetWebhook(MSMethod):
    """
    Метод для получения вебхука по id.

    Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/workbook/workbook-webhooks#3-chto-takoe-vebhuk
    """

    __return__ = Webhook
    __api_method__ = "entity/webhook"

    id: str = Field(..., alias="webhook_id")
