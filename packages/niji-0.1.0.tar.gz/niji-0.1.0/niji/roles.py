from enum import Enum


class ColorRole(Enum):
    FOREGROUND = 0
    BACKGROUND = 10
