"""Event types for streaming."""

from dataclasses import dataclass
from typing import Literal, Optional


@dataclass
class StdoutEvent:
    """Stdout event."""
    data: str
    type: Literal['stdout'] = 'stdout'


@dataclass
class StderrEvent:
    """Stderr event."""
    data: str
    type: Literal['stderr'] = 'stderr'


@dataclass
class UpdateEvent:
    """Update event (JSON metadata)."""
    data: str
    type: Literal['update'] = 'update'


@dataclass
class ErrorEvent:
    """Error event."""
    error: str
    type: Literal['error'] = 'error'


@dataclass
class CompleteEvent:
    """Stream completion event.

    Note: For background commands, exit_code=0 indicates the command started successfully (not completed).
    """
    status: Literal['success', 'error']
    exit_code: Optional[int]
    sandbox_id: Optional[str]
    error: Optional[str] = None
    type: Literal['complete'] = 'complete'


# Union type for all events
Event = StdoutEvent | StderrEvent | UpdateEvent | ErrorEvent | CompleteEvent
