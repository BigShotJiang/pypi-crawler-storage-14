"""TypeScript bridge for SwarmKit Python SDK.

This package contains the Node.js/TypeScript bridge that provides
JSON-RPC access to the SwarmKit TypeScript SDK.
"""
