
from setuptools import setup

setup(
    name="acx",
    version="0.0.1",
    description="Reserved package name for upcoming ACX framework by AryCodes.",
    packages=["acx"],
)
