import logging

logger = logging.getLogger(__name__)

CUSTOM_CONFIG_PATH = ".config/ttcli/ttcli.cfg"
TOKEN_PATH = ".config/ttcli/.session"
VERSION = "1.1.0"
__version__ = VERSION
