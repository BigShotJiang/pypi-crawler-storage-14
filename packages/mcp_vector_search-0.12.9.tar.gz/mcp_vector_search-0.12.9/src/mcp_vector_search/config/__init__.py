"""Configuration management for MCP Vector Search."""
