"""CLI module for MCP Vector Search."""
