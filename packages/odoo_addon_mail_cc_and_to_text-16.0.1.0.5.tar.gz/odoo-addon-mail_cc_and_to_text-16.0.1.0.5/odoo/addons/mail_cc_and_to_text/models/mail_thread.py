# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, models, tools
import email

try:
    from xmlrpc import client as xmlrpclib
except ImportError:
    import xmlrpclib


MESSAGE_HEADER_FIELD_MAP = {
    "To": "email_to",
    "Delivered-To": "delivered_to",
}


class MailThread(models.AbstractModel):
    _inherit = "mail.thread"

    def _get_email_address_field_from_header(self, message, header_name):
        """
        Extract and format email addresses from the specified header in the message.
        Only headers defined in MESSAGE_HEADER_FIELD_MAP are supported!!!

        Returns a comma-separated string of email addresses.

        :param message: The email message object.
        :param header_name: The name of the header to extract email addresses from.
        :return: Comma-separated string of formatted email addresses.
        """
        if header_name not in MESSAGE_HEADER_FIELD_MAP.keys():
            return False

        return ",".join(
            set(
                formatted_email
                for address in [
                    tools.decode_message_header(message, header_name, separator=",")
                ]
                if address
                for formatted_email in tools.email_split_and_format(address)
            )
        )

    @api.model
    def message_process(
        self,
        model,
        message,
        custom_values=None,
        save_original=False,
        strip_attachments=False,
        thread_id=None,
    ):
        thread_id = super(MailThread, self).message_process(
            model, message, custom_values, save_original, strip_attachments, thread_id
        )
        # extract message bytes - we are forced to pass the message as binary because
        # we don't know its encoding until we parse its headers and hence can't
        # convert it to utf-8 for transport between the mailgate script and here.
        if isinstance(message, xmlrpclib.Binary):
            message = bytes(message.data)
        if isinstance(message, str):
            message = message.encode("utf-8")
        message = email.message_from_bytes(message, policy=email.policy.SMTP)
        msg_dict = self.message_parse(message, save_original=save_original)

        mail_message = self.env["mail.message"].search(
            [("message_id", "=", msg_dict.get("message_id"))]
        )
        if mail_message and mail_message.model == "helpdesk.ticket":
            for header_name, field_name in MESSAGE_HEADER_FIELD_MAP.items():
                field_value = self._get_email_address_field_from_header(
                    message, header_name
                )
                if field_value:
                    setattr(mail_message, field_name, field_value)

            ticket = self.env[mail_message.model].browse(mail_message.res_id)
            if ticket:
                ticket.delivered_to = mail_message.delivered_to

        return thread_id
