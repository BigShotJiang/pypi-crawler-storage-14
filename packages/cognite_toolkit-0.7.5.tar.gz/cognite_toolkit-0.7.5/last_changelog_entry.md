## Changelog 

### Improved

- If deployment of transformations fails with ` Failed to bind session
using nonce for`, Toolkit now tries to deploy one-by-one.