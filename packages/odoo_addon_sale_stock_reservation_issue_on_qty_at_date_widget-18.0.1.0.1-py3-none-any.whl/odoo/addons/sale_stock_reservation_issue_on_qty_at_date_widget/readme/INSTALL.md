In order to use this module, you need to install the next module:

- sale_management
