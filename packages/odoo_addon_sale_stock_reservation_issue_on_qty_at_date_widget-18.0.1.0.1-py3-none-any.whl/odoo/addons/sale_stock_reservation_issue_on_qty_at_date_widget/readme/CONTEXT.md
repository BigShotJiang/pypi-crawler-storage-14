This module was developed because Qty At Date Widget doesn't warn when you are going to sell more quantity than you have in stock with all planned operations included (free quantity today).

It will be useful for you if you want to avoid unreservations to fulfill another orders that were planned earlier.
