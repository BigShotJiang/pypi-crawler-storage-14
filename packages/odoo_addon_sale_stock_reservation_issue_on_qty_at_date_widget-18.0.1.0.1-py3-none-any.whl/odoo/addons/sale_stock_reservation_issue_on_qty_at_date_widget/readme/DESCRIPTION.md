This module extends the functionality of Qty at Date Widget changing the color of the widget icon to yellow (warning color) when you are going to sell more quantities than Free Quantity Today.
