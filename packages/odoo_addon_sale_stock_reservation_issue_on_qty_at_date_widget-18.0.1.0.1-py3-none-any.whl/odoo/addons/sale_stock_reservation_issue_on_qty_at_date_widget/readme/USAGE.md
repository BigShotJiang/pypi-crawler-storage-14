Example of use:

1. Create an Storable product and update available quantity for 20 units.
1. Create a new Sale and select the product you've created previously.
1. Sell an order for tomorrow for 10 units. Ensure picking is reserved.
1. Create an order for tomorrow for 20 units.
1. Check the Qty At Date icon is in yellow (warning color) because you are going to sell 10 units that are reserved for another order.

![Reservation Issue widget color](../static/description/reservation_issue_color.png)
