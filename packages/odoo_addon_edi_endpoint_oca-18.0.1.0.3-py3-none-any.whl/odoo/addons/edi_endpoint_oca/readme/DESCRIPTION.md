Base module allowing configuration of custom endpoints for EDI
framework.
