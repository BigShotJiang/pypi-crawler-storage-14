#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:38:04
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""

from typing import List, Type, Optional
from fastapi import APIRouter
from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession

from .models import get_rbac_models
from .routers import create_rbac_router
from .serializers import UserSerializer, RoleSerializer, PermissionSerializer
from .config import RBACConfig
from .dependencies import RBACMiddleware, require_permissions

import inspect
from fastapi.routing import APIRoute
from fastapi import FastAPI
from .schemas.permission_schemas import PermissionCreate


async def auto_generate_permissions_from_app(app: FastAPI, session: AsyncSession):
    """
    Automatically extract all require_permissions dependencies from FastAPI app routes,
    and insert missing permissions into the database.

    Args:
        app: FastAPI application instance
        session: AsyncSession database session
    """
    from .serializers.permission_serializer import PermissionSerializer
    from fastapi.params import Depends

    permission_codes = set()
    # 1. Iterate through all APIRoute
    for route in app.routes:
        if not isinstance(route, APIRoute):
            continue
        endpoint = route.endpoint
        # 2. Check endpoint parameter annotations and default values
        sig = inspect.signature(endpoint)
        for param in sig.parameters.values():
            default = param.default
            # 3. Check if it's Depends and depends on require_permissions
            if isinstance(default, Depends):
                dep = default.dependency
                # require_permissions returns a closure function, need further judgment
                if hasattr(dep, "__name__") and dep.__name__ == "permission_dependency":  # type: ignore
                    # Get permission_codes (closure variable)
                    closure = dep.__closure__  # type: ignore
                    if closure:
                        for cell in closure:
                            value = cell.cell_contents
                            # Find permission_codes tuple
                            if isinstance(value, tuple) and all(
                                isinstance(x, str) for x in value
                            ):
                                for code in value:
                                    permission_codes.add(code)
    if not permission_codes:
        print(
            "[auto_generate_permissions_from_app] No permissions found in app routes."
        )
        return

    # 4. Query existing permissions in database
    serializer = PermissionSerializer(session)
    existing = set()
    for code in permission_codes:
        perm = await serializer._get_permission_by_code(code)
        if perm:
            existing.add(code)
    missing = permission_codes - existing

    # 5. Insert missing permissions
    for code in missing:
        # Try to automatically split resource/action
        if ":" in code:
            resource, action = code.split(":", 1)
        else:
            resource, action = code, "access"
        perm_data = PermissionCreate(
            code=code,
            name=code,
            description=f"Auto-generated permission for {code}",
            resource=resource,
            action=action,
            permission_type="function",
            is_active=True,
            is_system=False,
        )
        try:
            await serializer.create_permission(perm_data)
            print(f"[auto_generate_permissions_from_app] Created permission: {code}")
        except Exception as e:
            print(f"[auto_generate_permissions_from_app] Failed to create {code}: {e}")
    print(
        f"[auto_generate_permissions_from_app] Done. Total: {len(permission_codes)}, Created: {len(missing)}"
    )


class RBACPlugin:
    """
    RBAC Plugin

    Manage all RBAC-related functionality, including models, routes, serializers, etc.
    """

    def __init__(self, app: FastAPI, config: RBACConfig):
        """
        Initialize RBAC Plugin

        Args:
            config: Plugin configuration, if None, use default configuration
        """
        self.config = config
        self.app = app
        # self._router: Optional[APIRouter] = None
        self._rbac_middleware: Optional[RBACMiddleware] = None
        self.register_app()

    def register_app(self):
        """
        Register app to RBAC plugin
        """
        from .config import register_rbac_config

        # Initialize RBAC middleware and set it in app state
        rbac_middleware = self.get_rbac_middleware()
        self.app.state.rbac_middleware = rbac_middleware
        register_rbac_config(self.app, self.config)
        self._router: APIRouter = create_rbac_router(
            self.config.custom_session_maker, self.config.api_prefix
        )
        self.app.include_router(self._router, tags=["RBAC Management"])
        if self.config.need_frontend:
            from .routers.frontend_router import create_frontend_router
            from fastapi.staticfiles import StaticFiles
            from pathlib import Path

            frontend_router = create_frontend_router(
                self.config.custom_session_maker,
                self.config.api_prefix,
                self.config.frontend_prefix,
            )
            self.app.include_router(frontend_router, tags=["RBAC Management Frontend"])

            # Mount static files for frontend templates
            # This is required for url_for('static', path='...') to work in templates
            static_dir = Path(__file__).parent / "frontend" / "static"
            if static_dir.exists():
                self.app.mount(
                    "/static", StaticFiles(directory=str(static_dir)), name="static"
                )

    def get_models(self) -> List[Type[SQLModel]]:
        """
        Get all RBAC-related data models

        Returns:
            List of data model classes
        """
        return get_rbac_models()

    def get_router(self) -> APIRouter:
        """
        Get RBAC routes

        Args:
            get_db_session: Database session dependency function

        Returns:
            Configured RBAC routes
        """
        # if self._router is None:
        #     self._router = create_rbac_router(get_db_session)

        return self._router

    def get_user_serializer(self, db_session: AsyncSession) -> UserSerializer:
        """
        Get user serializer instance

        Args:
            db_session: Database session

        Returns:
            User serializer instance
        """
        return UserSerializer(db_session)

    def get_role_serializer(self, db_session: AsyncSession) -> RoleSerializer:
        """
        Get role serializer instance

        Args:
            db_session: Database session

        Returns:
            Role serializer instance
        """
        return RoleSerializer(db_session)

    def get_permission_serializer(
        self, db_session: AsyncSession
    ) -> PermissionSerializer:
        """
        Get permission serializer instance

        Args:
            db_session: Database session

        Returns:
            Permission serializer instance
        """
        return PermissionSerializer(db_session)

    def get_rbac_middleware(self) -> RBACMiddleware:
        """
        Get RBAC middleware instance

        Returns:
            RBAC middleware instance
        """
        if self._rbac_middleware is None:
            self._rbac_middleware = RBACMiddleware(self)
        return self._rbac_middleware

    def get_permission_dependency(self, *permission_codes: str):
        """
        Get permission dependency function

        Args:
            *permission_codes: Permission code list

        Returns:
            Permission dependency function

        Usage:
            # In upper-level application
            rbac_plugin = RBACPlugin()
            require_user_read = rbac_plugin.get_permission_dependency("user:read", "user:write")

            @app.get("/users")
            async def get_users(_: bool = Depends(require_user_read)):
                return {"users": []}
        """
        return require_permissions(*permission_codes)

    @property
    def plugin_info(self) -> dict:
        """
        Get plugin information

        Returns:
            Plugin information dictionary
        """
        return {
            "name": "RBAC Plugin",
            "version": "1.1.0",
            "description": "RBAC Plugin based on roles and permissions",
            "models": [model.__name__ for model in self.get_models()],
            "routes": {
                "api_prefix": self.config.api_prefix,
                "frontend_prefix": self.config.frontend_prefix,
                "endpoints": [
                    f"{self.config.api_prefix}/users",
                    f"{self.config.api_prefix}/users/{{user_id}}",
                    f"{self.config.api_prefix}/users/{{user_id}}/roles",
                    f"{self.config.api_prefix}/users/search",
                    f"{self.config.api_prefix}/roles",
                    f"{self.config.api_prefix}/roles/{{role_id}}",
                    f"{self.config.api_prefix}/roles/{{role_id}}/users",
                    f"{self.config.api_prefix}/permissions",
                    f"{self.config.api_prefix}/permissions/{{permission_id}}",
                    f"{self.config.api_prefix}/permissions/{{permission_id}}/roles",
                ],
            },
            "features": {
                "role_based_access": True,
                "permission_based_access": True,
                "middleware_support": True,
                "dependency_injection": True,
            },
            "config": {
                "api_prefix": self.config.api_prefix,
                "frontend_prefix": self.config.frontend_prefix,
                "cache_ttl": self.config.cache_ttl,
            },
        }

    def setup_database_tables(self, engine) -> None:
        """
        Set up database tables

        Args:
            engine: Database engine

        Note:
            This method should be called when the application starts, for creating database tables
        """
        # Get all model metadata
        self.get_models()

    async def initialize_default_data(self, db_session: AsyncSession) -> None:
        """
        Initialize default data

        Args:
            db_session: Database session

        Note:
            Create default role and user data
        """
        role_serializer = self.get_role_serializer(db_session)

        # Create default roles
        default_roles = [
            {
                "name": "Super Admin",
                "description": "System super admin",
                "is_system": True,
            },
            {"name": "Admin", "description": "System admin", "is_system": True},
            {"name": "User", "description": "User role", "is_system": True},
        ]

        try:
            for role_data in default_roles:
                # Check if role already exists
                existing_role = await role_serializer._get_role_by_name(
                    role_data["name"]
                )
                if not existing_role:
                    from schemas.role_schemas import RoleCreate

                    await role_serializer.create_role(RoleCreate(**role_data))

        except Exception as e:
            # Record error but do not interrupt initialization process
            print(f"Error initializing default data: {str(e)}")


def create_rbac_plugin(app: FastAPI, config: RBACConfig) -> RBACPlugin:
    """
    Factory function for creating RBAC plugin instance

    Args:
        app: FastAPI application instance
        config: Plugin configuration

    Returns:
        RBAC plugin instance
    """
    return RBACPlugin(app, config)


# Plugin metadata
PLUGIN_METADATA = {
    "name": "rbac-plugin",
    "version": "1.0.0",
    "description": "FastAPI RBAC Plugin",
    "author": "AI Assistant",
    "dependencies": [
        "fastapi",
        "sqlmodel",
        "pydantic>=2.0",
        "sqlalchemy[asyncio]",
    ],
    "supported_databases": ["mysql", "postgresql", "sqlite"],
}
