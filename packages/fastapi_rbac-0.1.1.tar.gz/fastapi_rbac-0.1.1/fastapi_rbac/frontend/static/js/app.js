/**
 * RBAC Management System - Main Application JavaScript
 * Provides dynamic interactions and enhanced user experience
 */

// Global RBAC App Object
window.RBACApp = {
  // Configuration
  config: {
    apiPrefix: "/rbac",
    adminPrefix: "/admin",
    confirmationDelay: 300,
    toastDuration: 3000,
  },

  // Initialize the application
  init: function () {
    this.initTooltips();
    this.initFormValidation();
    this.initTableFeatures();
    this.initNotifications();
    this.initModalEnhancements();
    console.log("RBAC Management System initialized");
  },

  // Initialize Bootstrap tooltips
  initTooltips: function () {
    const tooltipTriggerList = [].slice.call(
      document.querySelectorAll('[data-bs-toggle="tooltip"]')
    );
    tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Add tooltips to action buttons
    document.querySelectorAll(".btn-action").forEach((btn) => {
      if (!btn.hasAttribute("data-bs-toggle")) {
        const title = btn.getAttribute("title");
        if (title) {
          btn.setAttribute("data-bs-toggle", "tooltip");
          new bootstrap.Tooltip(btn);
        }
      }
    });
  },

  // Form validation enhancements
  initFormValidation: function () {
    const forms = document.querySelectorAll(".needs-validation");

    forms.forEach((form) => {
      form.addEventListener("submit", (event) => {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
          this.showNotification(
            "Please fill in all required fields correctly",
            "warning"
          );
        }
        form.classList.add("was-validated");
      });
    });

    // Real-time validation for inputs
    document
      .querySelectorAll("input[required], select[required], textarea[required]")
      .forEach((input) => {
        input.addEventListener("blur", () => {
          this.validateField(input);
        });

        input.addEventListener("input", () => {
          if (input.classList.contains("is-invalid")) {
            this.validateField(input);
          }
        });
      });
  },

  // Validate individual form field
  validateField: function (field) {
    const isValid = field.checkValidity();

    if (isValid) {
      field.classList.remove("is-invalid");
      field.classList.add("is-valid");
    } else {
      field.classList.remove("is-valid");
      field.classList.add("is-invalid");
    }

    return isValid;
  },

  // Table features initialization
  initTableFeatures: function () {
    // Enhanced table row highlighting
    document.querySelectorAll(".table-hover tbody tr").forEach((row) => {
      row.addEventListener("mouseenter", () => {
        row.style.transform = "scale(1.01)";
        row.style.transition = "transform 0.2s ease";
      });

      row.addEventListener("mouseleave", () => {
        row.style.transform = "scale(1)";
      });
    });

    // Table sorting (if headers are clickable)
    document.querySelectorAll(".table th[data-sort]").forEach((header) => {
      header.style.cursor = "pointer";
      header.addEventListener("click", () => {
        this.sortTable(header);
      });
    });

    // Checkbox selection state management
    this.initCheckboxSelection();
  },

  // Initialize checkbox selection features
  initCheckboxSelection: function () {
    const selectAllCheckbox = document.getElementById("selectAllCheckbox");
    const itemCheckboxes = document.querySelectorAll(
      ".user-checkbox, .role-checkbox, .permission-checkbox"
    );

    if (selectAllCheckbox && itemCheckboxes.length > 0) {
      // Update select all state when individual checkboxes change
      itemCheckboxes.forEach((checkbox) => {
        checkbox.addEventListener("change", () => {
          this.updateSelectAllState();
          this.updateBulkActions();
        });
      });

      // Handle select all checkbox
      selectAllCheckbox.addEventListener("change", () => {
        const isChecked = selectAllCheckbox.checked;
        itemCheckboxes.forEach((checkbox) => {
          checkbox.checked = isChecked;
        });
        this.updateBulkActions();
      });
    }
  },

  // Update select all checkbox state
  updateSelectAllState: function () {
    const selectAllCheckbox = document.getElementById("selectAllCheckbox");
    const itemCheckboxes = document.querySelectorAll(
      ".user-checkbox, .role-checkbox, .permission-checkbox"
    );

    if (selectAllCheckbox && itemCheckboxes.length > 0) {
      const checkedCount = Array.from(itemCheckboxes).filter(
        (cb) => cb.checked
      ).length;

      if (checkedCount === 0) {
        selectAllCheckbox.indeterminate = false;
        selectAllCheckbox.checked = false;
      } else if (checkedCount === itemCheckboxes.length) {
        selectAllCheckbox.indeterminate = false;
        selectAllCheckbox.checked = true;
      } else {
        selectAllCheckbox.indeterminate = true;
        selectAllCheckbox.checked = false;
      }
    }
  },

  // Update bulk action buttons based on selection
  updateBulkActions: function () {
    const checkedItems = document.querySelectorAll(
      ".user-checkbox:checked, .role-checkbox:checked, .permission-checkbox:checked"
    );
    const bulkActionBtns = document.querySelectorAll("[data-bulk-action]");

    bulkActionBtns.forEach((btn) => {
      btn.disabled = checkedItems.length === 0;
      btn.textContent = btn.textContent.replace(
        /\(\d+\)/,
        `(${checkedItems.length})`
      );
    });
  },

  // Notification system
  initNotifications: function () {
    // Create toast container if it doesn't exist
    if (!document.getElementById("toastContainer")) {
      const toastContainer = document.createElement("div");
      toastContainer.id = "toastContainer";
      toastContainer.className =
        "toast-container position-fixed top-0 end-0 p-3";
      toastContainer.style.zIndex = "1050";
      document.body.appendChild(toastContainer);
    }
  },

  // Show notification toast
  showNotification: function (message, type = "info", duration = null) {
    const toastContainer = document.getElementById("toastContainer");
    const toastId = "toast-" + Date.now();

    const typeClass =
      {
        success: "text-bg-success",
        error: "text-bg-danger",
        warning: "text-bg-warning",
        info: "text-bg-info",
      }[type] || "text-bg-info";

    const toastHtml = `
            <div id="${toastId}" class="toast ${typeClass}" role="alert">
                <div class="toast-header">
                    <i class="bi bi-info-circle me-2"></i>
                    <strong class="me-auto">RBAC System</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;

    toastContainer.insertAdjacentHTML("beforeend", toastHtml);

    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
      delay: duration || this.config.toastDuration,
    });

    toast.show();

    // Remove toast element after it's hidden
    toastElement.addEventListener("hidden.bs.toast", () => {
      toastElement.remove();
    });
  },

  // Modal enhancements
  initModalEnhancements: function () {
    // Auto-focus first input in modals
    document.querySelectorAll(".modal").forEach((modal) => {
      modal.addEventListener("shown.bs.modal", () => {
        const firstInput = modal.querySelector("input, select, textarea");
        if (firstInput) {
          firstInput.focus();
        }
      });

      // Clear form validation when modal is hidden
      modal.addEventListener("hidden.bs.modal", () => {
        const form = modal.querySelector("form");
        if (form) {
          form.classList.remove("was-validated");
          form.querySelectorAll(".is-valid, .is-invalid").forEach((field) => {
            field.classList.remove("is-valid", "is-invalid");
          });
        }
      });
    });
  },

  // Table sorting functionality
  sortTable: function (header) {
    const table = header.closest("table");
    const tbody = table.querySelector("tbody");
    const rows = Array.from(tbody.querySelectorAll("tr"));
    const columnIndex = Array.from(header.parentNode.children).indexOf(header);
    const sortDirection =
      header.dataset.sortDirection === "asc" ? "desc" : "asc";

    // Update sort direction
    table.querySelectorAll("th").forEach((th) => {
      th.removeAttribute("data-sort-direction");
      th.classList.remove("sorted-asc", "sorted-desc");
    });

    header.dataset.sortDirection = sortDirection;
    header.classList.add(`sorted-${sortDirection}`);

    // Sort rows
    rows.sort((a, b) => {
      const aValue = a.children[columnIndex].textContent.trim();
      const bValue = b.children[columnIndex].textContent.trim();

      const comparison = isNaN(aValue)
        ? aValue.localeCompare(bValue)
        : parseFloat(aValue) - parseFloat(bValue);

      return sortDirection === "asc" ? comparison : -comparison;
    });

    // Re-append sorted rows
    rows.forEach((row) => tbody.appendChild(row));

    this.showNotification(
      `Table sorted by ${header.textContent} (${sortDirection})`,
      "info",
      1500
    );
  },

  // Loading states
  showLoading: function (element, text = "Loading...") {
    if (typeof element === "string") {
      element = document.querySelector(element);
    }

    if (element) {
      element.classList.add("loading");
      const originalContent = element.innerHTML;
      element.dataset.originalContent = originalContent;
      element.innerHTML = `
                <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                ${text}
            `;
      element.disabled = true;
    }
  },

  hideLoading: function (element) {
    if (typeof element === "string") {
      element = document.querySelector(element);
    }

    if (element && element.classList.contains("loading")) {
      element.classList.remove("loading");
      element.innerHTML = element.dataset.originalContent || element.innerHTML;
      element.disabled = false;
      delete element.dataset.originalContent;
    }
  },

  // API utilities
  api: {
    // Generic API request method
    request: async function (url, options = {}) {
      const defaultOptions = {
        headers: {
          "Content-Type": "application/json",
        },
      };

      const config = { ...defaultOptions, ...options };
      // Attach JWT if available
      try {
        const token = sessionStorage.getItem("rbac_token");
        if (token) {
          config.headers = config.headers || {};
          if (config.headers instanceof Headers) {
            if (!config.headers.has("Authorization"))
              config.headers.set("Authorization", "Bearer " + token);
          } else {
            if (!("Authorization" in config.headers))
              config.headers["Authorization"] = "Bearer " + token;
          }
        }
      } catch (_) {}

      try {
        const response = await fetch(url, config);
        let data = null;
        try {
          data = await response.json();
        } catch (_) {
          data = null;
        }

        if (!response.ok) {
          // Redirect to login on 401
          if (response.status === 401) {
            window.location.href = "/login.html";
            return Promise.reject(new Error("Unauthorized"));
          }
          const message =
            (data && (data.detail || data.message)) || "Request failed";
          throw new Error(message);
        }

        return data;
      } catch (error) {
        RBACApp.showNotification(error.message, "error");
        throw error;
      }
    },

    // Get request
    get: function (url) {
      return this.request(url, { method: "GET" });
    },

    // Post request
    post: function (url, data) {
      return this.request(url, {
        method: "POST",
        body: JSON.stringify(data),
      });
    },

    // Put request
    put: function (url, data) {
      return this.request(url, {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },

    // Delete request
    delete: function (url) {
      return this.request(url, { method: "DELETE" });
    },
  },

  // Utility functions
  utils: {
    // Debounce function
    debounce: function (func, wait) {
      let timeout;
      return function executedFunction(...args) {
        const later = () => {
          clearTimeout(timeout);
          func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
      };
    },

    // Format date
    formatDate: function (date, options = {}) {
      const defaultOptions = {
        year: "numeric",
        month: "short",
        day: "numeric",
      };

      return new Date(date).toLocaleDateString("en-US", {
        ...defaultOptions,
        ...options,
      });
    },

    // Escape HTML
    escapeHtml: function (text) {
      const div = document.createElement("div");
      div.textContent = text;
      return div.innerHTML;
    },
  },
};

// Initialize the application when DOM is ready
document.addEventListener("DOMContentLoaded", function () {
  RBACApp.init();
});

// Export for potential module use
if (typeof module !== "undefined" && module.exports) {
  module.exports = RBACApp;
}
