#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FastAPI RBAC - CLI Entrypoint

Usage:
    # Initialize admin data
    python -m fastapi_rbac init_data --email admin@example.com --password admin123 --app main:app

    # Sync route permissions to database
    python -m fastapi_rbac sync_permission --app main:app

Commands:
    init_data:
        - Load FastAPI application from --app (module:var, like uvicorn)
        - Retrieve RBAC configuration from the loaded app
        - Ensure tables exist
        - Initialize one permission (admin_permission_code from config)
        - Initialize one role named "admin"
        - Initialize one admin user with the given email (others minimal)
        - Bind permission -> role, and user -> role

    sync_permission:
        - Load FastAPI application from --app (module:var, like uvicorn)
        - Extract permission codes from routes using require_permissions dependencies
        - Add missing permissions to database (incremental sync)
        - Existing permissions are left unchanged
"""

import argparse
import asyncio
import importlib
import sys
from typing import Optional, Tuple

from fastapi import FastAPI
from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession


def _load_app(app_path: str) -> Tuple[str, FastAPI]:
    if ":" not in app_path:
        raise ValueError("--app must be in format 'module:var', e.g. main:app")
    module_name, app_var = app_path.split(":", 1)
    try:
        module = importlib.import_module(module_name)
    except Exception as e:
        raise RuntimeError(f"Failed to import module '{module_name}': {e}") from e

    if not hasattr(module, app_var):
        raise RuntimeError(
            f"Module '{module_name}' does not define '{app_var}'. "
            "Please expose a FastAPI instance at module level (e.g., app = FastAPI(...))"
        )
    app = getattr(module, app_var)
    if not isinstance(app, FastAPI):
        raise RuntimeError(
            f"Attribute '{app_var}' in module '{module_name}' is not a FastAPI instance"
        )
    return module_name, app


async def _ensure_tables_from_session(session: AsyncSession) -> None:
    # Ensure all tables exist using the current metadata
    bind = session.get_bind()
    engine = getattr(bind, "engine", None)
    if engine is None:
        # SQLAlchemy 2.0 AsyncSession.bind is the engine
        engine = bind
    if engine is None:
        raise RuntimeError("Failed to resolve engine from session")

    async with engine.begin() as conn:  # type: ignore[attr-defined]
        await conn.run_sync(SQLModel.metadata.create_all)


async def _sync_permissions(app_path: str) -> int:
    """
    Sync permissions defined in application routes to database

    Args:
        app_path: FastAPI application path in format 'module:var'

    Returns:
        Exit code: 0 for success, non-zero for failure
    """
    # Load application
    _, app = _load_app(app_path)

    # Try to get RBAC configuration
    rbac_config = None
    custom_session_maker = None

    rbac_mw = getattr(getattr(app, "state", None), "rbac_middleware", None)
    if rbac_mw and getattr(rbac_mw, "rbac_plugin", None):
        rbac_config = rbac_mw.rbac_plugin.config
        custom_session_maker = rbac_config.custom_session_maker
    else:
        # Try to get from global configuration
        try:
            from fastapi_rbac.config import get_rbac_config

            rbac_config = get_rbac_config()
            custom_session_maker = rbac_config.custom_session_maker
        except Exception:
            pass

    if rbac_config is None or custom_session_maker is None:
        print(
            "[fastapi-rbac] Missing RBAC configuration. Please ensure:\n"
            "  1) Your FastAPI module constructs the app at module level (not only in main())\n"
            "  2) RBACPlugin(app, RBACConfig(...)) is instantiated during module import,\n"
            "     so that app.state.rbac_middleware and global config are registered.\n"
            "  3) RBACConfig.custom_session_maker is set (e.g., gen_rbac_async_session)."
        )
        return 2

    # Get session
    session_gen = custom_session_maker()
    session = await session_gen.__anext__()

    try:
        # Use existing auto-generate permissions function
        from fastapi_rbac.plugin import auto_generate_permissions_from_app

        await auto_generate_permissions_from_app(app, session)
        await session.commit()
        print("[fastapi-rbac] Permission sync completed")
        return 0
    except Exception as e:
        print(f"[fastapi-rbac] Permission sync failed: {e}")
        return 1
    finally:
        # Ensure session is properly closed
        try:
            await session.close()
        except Exception as e:
            print(f"Warning: Error closing session: {e}")


async def _init_data(email: str, password: Optional[str], app_path: str) -> int:
    # Load app
    _, app = _load_app(app_path)

    # Try to get RBAC config
    # Priority 1: app.state.rbac_middleware -> rbac_plugin.config
    rbac_config = None
    custom_session_maker = None

    rbac_mw = getattr(getattr(app, "state", None), "rbac_middleware", None)
    if rbac_mw and getattr(rbac_mw, "rbac_plugin", None):
        rbac_config = rbac_mw.rbac_plugin.config
        custom_session_maker = rbac_config.custom_session_maker
    else:
        # Priority 2: global config (if app already called register_rbac_config)
        try:
            from fastapi_rbac.config import get_rbac_config

            rbac_config = get_rbac_config()
            custom_session_maker = rbac_config.custom_session_maker
        except Exception:
            pass

    if rbac_config is None or custom_session_maker is None:
        print(
            "[fastapi-rbac] Missing RBAC configuration. Please ensure: \n"
            "  1) Your FastAPI module constructs the app at module level (not only in main())\n"
            "  2) RBACPlugin(app, RBACConfig(...)) is instantiated during module import,\n"
            "     so that app.state.rbac_middleware and global config are registered.\n"
            "  3) RBACConfig.custom_session_maker is set (e.g., gen_rbac_async_session)."
        )
        return 2

    # Get session
    session_gen = custom_session_maker()
    session = await session_gen.__anext__()

    try:
        # assert table has been created
        # await _ensure_tables_from_session(session)

        # Serializers and Schemas
        from fastapi_rbac.serializers import (
            UserSerializer,
            RoleSerializer,
            PermissionSerializer,
        )
        from fastapi_rbac.schemas import (
            RoleCreate,
            PermissionCreate,
            PermissionRoleAssignment,
            UserRoleAssignment,
        )
        from fastapi_rbac.models import get_user_model

        user_s = UserSerializer(session)
        role_s = RoleSerializer(session)
        perm_s = PermissionSerializer(session)

        # Ensure admin permission (from config)
        code = rbac_config.admin_permission_code
        if ":" in code:
            resource, action = code.split(":", 1)
        else:
            resource, action = code, "access"

        existing_perm = await perm_s._get_permission_by_code(code)
        if not existing_perm:
            perm = await perm_s.create_permission(
                PermissionCreate(
                    code=code,
                    name=code,
                    description="Admin full access",
                    resource=resource,
                    action=action,
                    permission_type="function",
                    is_active=True,
                    is_system=True,
                )
            )
        else:
            perm = existing_perm

        # Ensure admin role
        admin_role = await role_s._get_role_by_name("admin")
        if not admin_role:
            admin_role = await role_s.create_role(
                RoleCreate(
                    name="admin",
                    description="Administrator",
                    is_system=True,
                    is_active=True,
                )
            )

        # Bind permission -> role
        await role_s.assign_permissions(
            admin_role.id,
            PermissionRoleAssignment(
                permission_ids=[perm.id], assigned_by=0, expires_at=None
            ),
        )

        # Ensure admin user by email
        from sqlmodel import select

        UserModel = user_s.user_model  # type: ignore[attr-defined]
        result = await session.exec(select(UserModel).where(UserModel.email == email))
        admin_user = result.first()
        if not admin_user:
            # Minimal valid fields per schema
            User = get_user_model()
            admin_user = await user_s.create_user(
                User(
                    name="admin",
                    en_name="admin",
                    email=email,
                    mobile="",
                    user_id=None,
                    status=1,
                    locked=0,
                )
            )
            await session.commit()
            await session.refresh(admin_user)

        if password:
            User = get_user_model()
            await user_s.update_user_password(admin_user.id, User(password=password))
            await session.commit()

        # Bind user -> role
        await role_s.assign_users(
            admin_role.id,
            UserRoleAssignment(
                user_ids=[admin_user.id], assigned_by=0, expires_at=None
            ),
        )

        await session.commit()
        print(
            "[fastapi-rbac] Initialized: user(email), role 'admin', permission '"
            + code
            + "'"
        )
        return 0
    finally:
        # Ensure session is properly closed
        try:
            await session.close()
        except Exception as e:
            print(f"Warning: Error closing session: {e}")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="fastapi_rbac")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # init_data
    p_init = subparsers.add_parser(
        "init_data", help="Initialize admin user, role, and admin permission"
    )
    p_init.add_argument("--email", required=True, help="Admin user email address")
    p_init.add_argument(
        "--password",
        required=False,
        help="Admin user password, if you use password model.",
    )
    p_init.add_argument(
        "--app",
        required=True,
        help="FastAPI app path in format module:var (e.g., main:app)",
    )

    # sync_permission
    p_sync = subparsers.add_parser(
        "sync_permission", help="Sync permissions from app routes to database"
    )
    p_sync.add_argument(
        "--app",
        required=True,
        help="FastAPI app path in format module:var (e.g., main:app)",
    )

    args = parser.parse_args(argv)

    if args.command == "init_data":
        return asyncio.run(_init_data(args.email, args.password, args.app))
    elif args.command == "sync_permission":
        return asyncio.run(_sync_permissions(args.app))

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
