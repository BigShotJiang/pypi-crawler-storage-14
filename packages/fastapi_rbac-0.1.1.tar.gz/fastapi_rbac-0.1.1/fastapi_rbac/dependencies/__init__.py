"""
Permission Dependencies

This module provides dependency injection functions for permission-based access control.
"""

from .permission_dependencies import require_permissions, admin_page_permission
from .rbac_middleware import RBACMiddleware

__all__ = [
    "require_permissions",
    "admin_page_permission",
    "RBACMiddleware",
]
