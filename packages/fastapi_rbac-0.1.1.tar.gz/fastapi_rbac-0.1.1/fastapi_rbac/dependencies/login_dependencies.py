"""
Login Dependencies

This module provides a dependency that validates user login status only.

Usage:
    from fastapi import Depends
    from fastapi_rbac.dependencies.login_dependencies import require_login

    @app.get("/protected")
    async def protected(_: bool = Depends(require_login())):
        return {"ok": True}
"""

from typing import Callable
from fastapi import HTTPException, Request, Depends
from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession


def require_login() -> Callable:
    """
    Create a dependency that verifies user login status only.

    Success if a valid user_id is returned from RBAC middleware.
    Otherwise, raises 401 HTTPException.
    """

    async def login_dependency(request: Request) -> int:
        # Get the RBAC middleware instance
        rbac_middleware = getattr(request.app.state, "rbac_middleware", None)

        if not rbac_middleware:
            # Keep behavior aligned with permission dependency for missing middleware
            raise HTTPException(
                status_code=500,
                detail={
                    "error": "configuration_error",
                    "message": "RBAC middleware not configured properly. Please ensure app.state.rbac_middleware is set during application startup.",
                    "endpoint": str(request.url.path),
                },
            )

        # Verify user is authenticated
        user_id = await rbac_middleware.get_current_user_id(request)
        if not user_id:
            raise HTTPException(
                status_code=401,
                detail={
                    "error": "authentication_required",
                    "message": "User authentication required. Please login first.",
                    "endpoint": str(request.url.path),
                },
            )

        return user_id

    return login_dependency


def require_external_login() -> Callable:
    """
    Create a dependency that verifies user login status only.
    """
    from ..config import get_rbac_config

    rbac_config = get_rbac_config()

    async def external_login_dependency(
        request: Request,
        db_session: AsyncSession = Depends(rbac_config.custom_session_maker),
    ) -> SQLModel:
        # Get the RBAC middleware instance
        rbac_middleware = getattr(request.app.state, "rbac_middleware", None)

        if not rbac_middleware:
            raise HTTPException(
                status_code=500,
                detail={
                    "error": "configuration_error",
                    "message": "RBAC middleware not configured properly. Please ensure app.state.rbac_middleware is set during application startup.",
                    "endpoint": str(request.url.path),
                },
            )
        auth_type = request.headers.get("X-Auth-Type")
        auth_token = request.headers.get("X-Auth-Token")

        if not auth_type and not auth_token:
            if request.query_params.get("auth_type") and request.query_params.get(
                "auth_token"
            ):
                auth_type = request.query_params.get("auth_type")
                auth_token = request.query_params.get("auth_token")

        if auth_type and auth_token:
            # Verify user is authenticated
            request.state.auth_type = auth_type
            request.state.auth_token = auth_token
            try:
                user_ins = (
                    await rbac_middleware.get_current_user_ins_with_external_auth(
                        request, db_session
                    )
                )
            except Exception as e:
                raise HTTPException(
                    status_code=401,
                    detail={
                        "error": "external_auth_validate_failed",
                        "message": "validate external auth headers failed, error: "
                        + str(e),
                        "endpoint": str(request.url.path),
                    },
                )
        else:
            raise HTTPException(
                status_code=401,
                detail={
                    "error": "external_auth_required",
                    "message": "User authentication required. Please login first or provide external auth headers.",
                    "endpoint": str(request.url.path),
                },
            )
        if not user_ins:
            raise HTTPException(
                status_code=401,
                detail={
                    "error": "authentication_required",
                    "message": "User authentication required. Please login first.",
                    "endpoint": str(request.url.path),
                },
            )

        request.state.user_id = user_ins.id

        return user_ins.id

    return external_login_dependency


__all__ = ["require_login", "require_external_login"]
