#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:35:52
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Password User Serializer
    Serializer for user model with password functionality.
    Inherits from BaseUserSerializer and provides password-specific logic.

All Rights Reserved.
"""


from .base_user_serializer import BaseUserSerializer
from ..models.pwd_user_model import UserWithPassword


class PasswordUserSerializer(BaseUserSerializer):
    """
    Password user serializer for UserWithPassword model

    This serializer handles the user model that includes password fields
    and provides password hashing and verification functionality.
    """

    user_model = UserWithPassword
