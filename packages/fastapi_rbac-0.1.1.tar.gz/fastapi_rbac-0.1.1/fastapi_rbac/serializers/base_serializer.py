#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:30:51
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Base serializer
    Provide common database operation methods, exception handling, and logging functions.

All Rights Reserved.
"""


import logging
from typing import Set, Type, TypeVar, Generic, Optional, List, Any
from datetime import datetime
from sqlmodel import SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.exc import SQLAlchemyError
from pydantic import BaseModel

from ..schemas.common_schemas import PaginationParams, PaginatedResponse
from .exceptions import create_base_error, create_base_not_found

# Legacy exception classes moved to exceptions.py
# Import them here for backward compatibility
from .exceptions import NotFoundError

T = TypeVar("T", bound=SQLModel)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)

logger = logging.getLogger(__name__)


def filter_user_for_response(model_ins: Any, sensitive_fields: Set[str]) -> dict:
    """
    Filter model object for API response, removing sensitive fields

    Args:
        model_ins: Model instance

    Returns:
        Dictionary with sensitive fields removed
    """
    if not model_ins:
        return {}

    # Get user data as dictionary
    if hasattr(model_ins, "model_dump"):
        model_dict = model_ins.model_dump()
    elif hasattr(model_ins, "__dict__"):
        model_dict = model_ins.__dict__.copy()
    else:
        return {}

    # Remove sensitive fields
    for field in sensitive_fields:
        model_dict.pop(field, None)

    return model_dict


class BaseSerializer(Generic[T, CreateSchemaType, UpdateSchemaType]):
    """
    Base serializer class

    Provide common CRUD operations and exception handling.
    """

    EXCLUDED_FIELDS: Set[str] = set()

    def __init__(self, db_session: AsyncSession, model_class: Type[T]):
        self.db_session = db_session
        self.model_class = model_class
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")

    async def create(self, create_data: CreateSchemaType) -> T:
        """
        Create new record

        Args:
            create_data: Create data

        Returns:
            Created model instance

        Raises:
            DatabaseError: Database operation failed
        """
        try:
            # Convert Pydantic model to dictionary
            create_dict = create_data.model_dump(exclude_unset=True)

            # Create model instance
            db_obj = self.model_class(**create_dict)

            # Add to database session
            self.db_session.add(db_obj)
            await self.db_session.commit()
            await self.db_session.refresh(db_obj)

            self.logger.info(
                f"Successfully created {self.model_class.__name__} record, ID: {db_obj.id}"
            )
            return db_obj

        except SQLAlchemyError as e:
            try:
                await self.db_session.rollback()
            except Exception as rollback_error:
                self.logger.warning(f"Error occurred during transaction rollback: {rollback_error}")
            self.logger.exception(
                f"Failed to create {self.model_class.__name__} record: {str(e)}"
            )
            raise create_base_error(
                "CREATE_FAILED", {"error": str(e)}, model_name=self.model_class.__name__
            )
        except Exception as e:
            try:
                await self.db_session.rollback()
            except Exception as rollback_error:
                self.logger.warning(f"Error occurred during transaction rollback: {rollback_error}")
            self.logger.error(
                f"Failed to create {self.model_class.__name__} record: {str(e)}"
            )
            raise create_base_error(
                "CREATE_FAILED", {"error": str(e)}, model_name=self.model_class.__name__
            )

    async def get_by_id(self, obj_id: int) -> Optional[T]:
        """
        Get record by ID

        Args:
            obj_id: Record ID

        Returns:
            Model instance or None
        """
        try:
            statement = select(self.model_class).where(self.model_class.id == obj_id)
            result = await self.db_session.exec(statement)
            return result.first()
            # return self._filter_sensitive_fields(model_ins)
        except SQLAlchemyError as e:
            self.logger.error(
                f"Failed to get {self.model_class.__name__} record by ID {obj_id}: {str(e)}"
            )
            raise create_base_error(
                "GET_FAILED",
                {"error": str(e)},
                model_name=self.model_class.__name__,
                obj_id=obj_id,
            )

    async def get_by_id_or_404(self, obj_id: int) -> T:
        """
        Get record by ID, if not found, raise exception

        Args:
            obj_id: Record ID

        Returns:
            Model instance

        Raises:
            NotFoundError: Record not found
        """
        obj = await self.get_by_id(obj_id)
        if obj is None:
            raise create_base_not_found(
                resource=self.model_class.__name__, identifier=obj_id
            )
        return obj

    async def update(self, obj_id: int, update_data: UpdateSchemaType) -> T:
        """
        Update record

        Args:
            obj_id: Record ID
            update_data: Update data

        Returns:
            Updated model instance

        Raises:
            NotFoundError: Record not found
            DatabaseError: Database operation failed
        """
        try:
            # Get existing record
            db_obj = await self.get_by_id_or_404(obj_id)

            # Get update data
            update_dict = update_data.model_dump(exclude_unset=True)

            # Update fields
            for field, value in update_dict.items():
                setattr(db_obj, field, value)

            # Set update time
            if hasattr(db_obj, "updated_at"):
                db_obj.updated_at = datetime.now()

            # Commit changes
            self.db_session.add(db_obj)
            await self.db_session.commit()
            await self.db_session.refresh(db_obj)

            self.logger.info(
                f"Successfully updated {self.model_class.__name__} record, ID: {obj_id}"
            )
            return db_obj

        except NotFoundError:
            raise
        except SQLAlchemyError as e:
            await self.db_session.rollback()
            self.logger.error(
                f"Failed to update {self.model_class.__name__} record by ID {obj_id}: {str(e)}"
            )
            raise create_base_error(
                "UPDATE_FAILED",
                {"error": str(e)},
                model_name=self.model_class.__name__,
                obj_id=obj_id,
            )
        except Exception as e:
            await self.db_session.rollback()
            self.logger.error(
                f"Failed to update {self.model_class.__name__} record by ID {obj_id}: {str(e)}"
            )
            raise create_base_error(
                "UPDATE_FAILED",
                {"error": str(e)},
                model_name=self.model_class.__name__,
                obj_id=obj_id,
            )

    async def delete(self, obj_id: int) -> bool:
        """
        Delete record

        Args:
            obj_id: Record ID

        Returns:
            Whether deletion is successful

        Raises:
            NotFoundError: Record not found
            DatabaseError: Database operation failed
        """
        try:
            # Get existing record
            db_obj = await self.get_by_id_or_404(obj_id)

            # Delete
            await self.db_session.delete(db_obj)
            await self.db_session.commit()

            self.logger.info(
                f"Successfully deleted {self.model_class.__name__} record, ID: {obj_id}"
            )
            return True

        except NotFoundError:
            raise
        except SQLAlchemyError as e:
            await self.db_session.rollback()
            self.logger.error(
                f"Failed to delete {self.model_class.__name__} record by ID {obj_id}: {str(e)}"
            )
            raise create_base_error(
                "DELETE_FAILED",
                {"error": str(e)},
                model_name=self.model_class.__name__,
                obj_id=obj_id,
            )
        except Exception as e:
            await self.db_session.rollback()
            self.logger.error(
                f"Failed to delete {self.model_class.__name__} record by ID {obj_id}: {str(e)}"
            )
            raise create_base_error(
                "DELETE_FAILED",
                {"error": str(e)},
                model_name=self.model_class.__name__,
                obj_id=obj_id,
            )

    async def get_paginated(
        self,
        pagination: PaginationParams,
        filters: Optional[List] = None,
        order_by: Optional[List] = None,
    ) -> PaginatedResponse[T]:
        """
        Paginate query record

        Args:
            pagination: Pagination parameters
            filters: Filter conditions list
            order_by: Order conditions list

        Returns:
            Paginated response
        """
        try:
            # Build base query
            statement = select(self.model_class)

            # Apply filter conditions
            if filters:
                for filter_condition in filters:
                    statement = statement.where(filter_condition)

            # Apply sorting
            if order_by:
                for order_condition in order_by:
                    statement = statement.order_by(order_condition)

            # Calculate total
            count_statement = select(self.model_class.id)
            if filters:
                for filter_condition in filters:
                    count_statement = count_statement.where(filter_condition)

            count_result = await self.db_session.exec(count_statement)
            total = len(count_result.all())

            # Apply pagination
            statement = statement.offset(pagination.offset).limit(pagination.size)

            # Execute query
            result = await self.db_session.exec(statement)
            items = result.all()

            return PaginatedResponse.create(
                items=items, total=total, page=pagination.page, size=pagination.size
            )

        except SQLAlchemyError as e:
            self.logger.error(
                f"Failed to paginate query {self.model_class.__name__}: {str(e)}"
            )
            raise create_base_error(
                "PAGINATE_FAILED",
                {"error": str(e)},
                model_name=self.model_class.__name__,
            )

    def _filter_sensitive_fields(self, model_ins: Any) -> Any:
        """
        Filter sensitive fields from model object for API responses

        Args:
            model_ins: Model instance

        Returns:
            Model instance with sensitive fields removed or set to None
        """
        if not self.EXCLUDED_FIELDS or not model_ins:
            return model_ins

        # Use the utility function to filter sensitive fields
        filtered_dict = filter_user_for_response(model_ins, self.EXCLUDED_FIELDS)

        # Create a new instance with filtered data
        if hasattr(model_ins, "model_validate"):
            return model_ins.__class__.model_validate(filtered_dict)
        else:
            # For SQLModel instances, create a new instance
            filtered_user = model_ins.__class__()
            for key, value in filtered_dict.items():
                if hasattr(filtered_user, key):
                    setattr(filtered_user, key, value)
            return filtered_user
