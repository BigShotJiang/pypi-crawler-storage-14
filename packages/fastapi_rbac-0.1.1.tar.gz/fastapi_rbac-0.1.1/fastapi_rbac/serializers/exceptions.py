#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-01-16 12:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Enhanced exception classes
    Extended exception classes with message key support and backward compatibility.

All Rights Reserved.
"""

from typing import Dict, Any, Optional
from .messages import ErrorMessages


class EnhancedDatabaseError(Exception):
    """Enhanced database operation exception with message key support"""

    def __init__(
        self,
        message: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        message_key: Optional[str] = None,
        message_category: str = "BASE",
        message_params: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize enhanced database error

        Args:
            message: Direct error message (for backward compatibility)
            details: Additional error details
            message_key: Message key for centralized message management
            message_category: Message category (BASE, USER, ROLE, PERMISSION)
            message_params: Parameters for message formatting
        """
        self.details = details or {}
        self.message_key = message_key
        self.message_category = message_category
        self.message_params = message_params or {}

        # Generate message based on input type
        if message:
            # Direct message provided (backward compatibility)
            self.message = message
        elif message_key:
            # Use centralized message management
            try:
                self.message = ErrorMessages.get_message(
                    message_category, message_key, **self.message_params
                )
            except KeyError as e:
                self.message = f"Message generation error: {str(e)}"
        else:
            self.message = "Database operation failed"

        super().__init__(self.message)

    def __str__(self) -> str:
        return self.message

    def get_message_info(self) -> Dict[str, Any]:
        """Get complete message information for debugging"""
        return {
            "message": self.message,
            "message_key": self.message_key,
            "message_category": self.message_category,
            "message_params": self.message_params,
            "details": self.details,
        }


class EnhancedNotFoundError(Exception):
    """Enhanced resource not found exception with message key support"""

    def __init__(
        self,
        resource: Optional[str] = None,
        identifier: Optional[Any] = None,
        message: Optional[str] = None,
        message_key: str = "NOT_FOUND",
        message_category: str = "BASE",
        message_params: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize enhanced not found error

        Args:
            resource: Resource name (for backward compatibility)
            identifier: Resource identifier (for backward compatibility)
            message: Direct error message (for backward compatibility)
            message_key: Message key for centralized message management
            message_category: Message category (BASE, USER, ROLE, PERMISSION)
            message_params: Parameters for message formatting
        """
        self.resource = resource
        self.identifier = identifier
        self.message_key = message_key
        self.message_category = message_category
        self.message_params = message_params or {}

        # Generate message based on input type
        if message:
            # Direct message provided (backward compatibility)
            self.message = message
        elif resource and identifier is not None:
            # Legacy format for backward compatibility
            self.message = f"{resource} with identifier {identifier} not found"
        elif message_key:
            # Use centralized message management
            try:
                self.message = ErrorMessages.get_message(
                    message_category, message_key, **self.message_params
                )
            except KeyError as e:
                self.message = f"Message generation error: {str(e)}"
        else:
            self.message = "Resource not found"

        super().__init__(self.message)

    def __str__(self) -> str:
        return self.message

    def get_message_info(self) -> Dict[str, Any]:
        """Get complete message information for debugging"""
        return {
            "message": self.message,
            "resource": self.resource,
            "identifier": self.identifier,
            "message_key": self.message_key,
            "message_category": self.message_category,
            "message_params": self.message_params,
        }


# Factory functions for creating enhanced exceptions with message keys
def create_database_error(
    category: str, key: str, details: Optional[Dict[str, Any]] = None, **kwargs
) -> EnhancedDatabaseError:
    """
    Create database error using message key

    Args:
        category: Message category (BASE, USER, ROLE, PERMISSION)
        key: Message key
        details: Additional error details
        **kwargs: Parameters for message formatting

    Returns:
        EnhancedDatabaseError instance
    """
    return EnhancedDatabaseError(
        message_key=key,
        message_category=category,
        message_params=kwargs,
        details=details,
    )


def create_not_found_error(category: str, key: str, **kwargs) -> EnhancedNotFoundError:
    """
    Create not found error using message key

    Args:
        category: Message category (BASE, USER, ROLE, PERMISSION)
        key: Message key
        **kwargs: Parameters for message formatting

    Returns:
        EnhancedNotFoundError instance
    """
    return EnhancedNotFoundError(
        message_key=key, message_category=category, message_params=kwargs
    )


# Convenience factory functions for specific categories
def create_base_error(key: str, details: Optional[Dict[str, Any]] = None, **kwargs):
    """Create base category database error"""
    return create_database_error("BASE", key, details, **kwargs)


def create_user_error(key: str, details: Optional[Dict[str, Any]] = None, **kwargs):
    """Create user category database error"""
    return create_database_error("USER", key, details, **kwargs)


def create_role_error(key: str, details: Optional[Dict[str, Any]] = None, **kwargs):
    """Create role category database error"""
    return create_database_error("ROLE", key, details, **kwargs)


def create_permission_error(
    key: str, details: Optional[Dict[str, Any]] = None, **kwargs
):
    """Create permission category database error"""
    return create_database_error("PERMISSION", key, details, **kwargs)


def create_base_not_found(key: str = "NOT_FOUND", **kwargs):
    """Create base category not found error"""
    return create_not_found_error("BASE", key, **kwargs)


def create_user_not_found(key: str, **kwargs):
    """Create user category not found error"""
    return create_not_found_error("USER", key, **kwargs)


def create_role_not_found(key: str, **kwargs):
    """Create role category not found error"""
    return create_not_found_error("ROLE", key, **kwargs)


def create_permission_not_found(key: str, **kwargs):
    """Create permission category not found error"""
    return create_not_found_error("PERMISSION", key, **kwargs)


# Backward compatibility aliases
DatabaseError = EnhancedDatabaseError
NotFoundError = EnhancedNotFoundError
