#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.net
@Create Time: 2025-01-27 10:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: GitHub User Serializer
All Rights Reserved.
"""

from typing import Any, Optional
from ..serializers.base_user_serializer import BaseUserSerializer
from sqlmodel.ext.asyncio.session import AsyncSession
from loguru import logger

from ..external_auth.clients.github_client import GitHubOAuthClient
from ..models.default_user_model import User
from ..models.github_user_model import GitHubUserModel


class GitHubUserSerializer(BaseUserSerializer):
    """
    GitHub User Serializer

    Handles GitHub user creation, update and validation logic
    """

    user_model = GitHubUserModel

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session)

    def _hash_password(self, password: str) -> str:
        """
        Hash password (GitHub users usually don't need passwords, but keep this method for base class compatibility)

        Args:
            password: Plain text password

        Returns:
            str: Hashed password
        """
        import bcrypt

        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    async def validate_user_from_github(self, auth_token: str) -> GitHubUserModel:
        """
        Validate user from GitHub

        Args:
            auth_token: GitHub access token

        Returns:
            GitHubUserModel: GitHub user model object
        """
        try:
            # Create GitHub OAuth client
            from ..config import get_rbac_config

            config = get_rbac_config()

            github_client = GitHubOAuthClient(config)

            # Validate token and get user information
            if await github_client.validate_token(auth_token):
                # Here we need to mock Request object, in actual use should get from dependency injection
                from fastapi import Request
                from unittest.mock import Mock

                mock_request = Mock(spec=Request)
                mock_request.headers = {"X-Auth-Token": auth_token}

                github_user = await github_client.get_user_info(
                    mock_request, self.db_session
                )
                return github_user
            else:
                raise ValueError("GitHub token validation failed")

        except Exception as e:
            logger.error(f"GitHub user validation failed: {str(e)}")
            raise

    async def create_user(self, auth_token: str) -> Any:
        """
        Create GitHub user

        Args:
            auth_token: GitHub access token

        Returns:
            GitHubUserModel: Created user instance
        """
        try:
            # Validate GitHub user
            github_user_data = await self.validate_user_from_github(auth_token)

            # Check if user already exists
            existing_user = await self._get_user_by_github_id(
                github_user_data.github_id
            )
            if existing_user:
                logger.info(f"GitHub user already exists: {existing_user.github_login}")
                return existing_user

            # Check if email already exists
            if github_user_data.email:
                existing_user_by_email = await self._get_user_by_email(
                    github_user_data.email
                )
                if existing_user_by_email:
                    logger.warning(
                        f"Email {github_user_data.email} is already used by another user"
                    )
                    # Can choose to update existing user or throw exception
                    # Here we choose to update existing user's GitHub information
                    existing_user_by_email.update_github_info(
                        github_user_data.model_dump()
                    )
                    await self.update(existing_user_by_email.id, existing_user_by_email)
                    return existing_user_by_email

            # Create new user
            user_data = GitHubUserModel(
                email=github_user_data.email,
                name=github_user_data.name,
                en_name=github_user_data.en_name,
                mobile=github_user_data.mobile,
                user_id=github_user_data.user_id,
                status=github_user_data.status,
                locked=github_user_data.locked,
            )

            user = await self.create(user_data)

            # Update GitHub specific information
            user.update_github_info(github_user_data.model_dump())
            await self.update(user.id, user)

            logger.info(f"Successfully created GitHub user: {user.github_login}")
            return user

        except Exception as e:
            logger.error(f"Failed to create GitHub user: {str(e)}")
            raise

    async def update_user(self, user_id: int, user_data: GitHubUserModel) -> Any:
        """
        Update GitHub user

        Args:
            user_id: User ID
            user_data: User update data

        Returns:
            GitHubUserModel: Updated user instance
        """
        try:
            # If updating email, check if email already exists
            if user_data.email:
                existing_user = await self._get_user_by_email(user_data.email)
                if existing_user and existing_user.id != user_id:
                    raise ValueError(
                        f"Email {user_data.email} is already used by another user"
                    )

            # Create update data dictionary
            update_dict = user_data.model_dump(exclude_unset=True)

            # Handle password update (GitHub users usually don't need)
            if hasattr(user_data, "password") and user_data.password:
                update_dict["password"] = self._hash_password(user_data.password)

            # Update user
            user = await self.update(user_id, GitHubUserModel(**update_dict))

            logger.info(f"Successfully updated GitHub user: {user.github_login}")
            return user

        except Exception as e:
            logger.error(f"Failed to update GitHub user: {str(e)}")
            raise

    async def _get_user_by_github_id(self, github_id: int) -> Optional[GitHubUserModel]:
        """
        Get user by GitHub ID

        Args:
            github_id: GitHub user ID

        Returns:
            Optional[GitHubUserModel]: User instance or None
        """
        try:
            from sqlmodel import select

            statement = select(GitHubUserModel).where(
                GitHubUserModel.github_id == github_id
            )
            result = await self.db_session.exec(statement)
            return result.first()

        except Exception as e:
            logger.error(f"Failed to get user by GitHub ID: {str(e)}")
            return None

    async def _get_user_by_github_login(
        self, github_login: str
    ) -> Optional[GitHubUserModel]:
        """
        Get user by GitHub username

        Args:
            github_login: GitHub username

        Returns:
            Optional[GitHubUserModel]: User instance or None
        """
        try:
            from sqlmodel import select

            statement = select(GitHubUserModel).where(
                GitHubUserModel.github_login == github_login
            )
            result = await self.db_session.exec(statement)
            return result.first()

        except Exception as e:
            logger.error(f"Failed to get user by GitHub username: {str(e)}")
            return None

    async def sync_github_user_info(
        self, user_id: int, auth_token: str
    ) -> GitHubUserModel:
        """
        Sync GitHub user information

        Args:
            user_id: User ID
            auth_token: GitHub access token

        Returns:
            GitHubUserModel: Updated user instance
        """
        try:
            # Get user
            user = await self.get_by_id(user_id)
            if not user:
                raise ValueError(f"User does not exist: {user_id}")

            # Get latest GitHub information
            github_user_data = await self.validate_user_from_github(auth_token)

            # Update GitHub information
            user.update_github_info(github_user_data.model_dump())
            await self.update(user.id, user)

            logger.info(
                f"Successfully synced GitHub user information: {user.github_login}"
            )
            return user

        except Exception as e:
            logger.error(f"Failed to sync GitHub user information: {str(e)}")
            raise
