#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 14:21:55
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Model test
    Test user, role and relation model functions.
All Rights Reserved.
"""

import asyncio
import pytest
from datetime import datetime, timedelta
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
import uuid

from ..models import Role, UserRoleRelation, Permission, RolePermissionRelation
from ..models.pwd_user_model import UserWithPassword


class TestUserModel:
    """UserWithPassword model test"""

    @pytest.mark.asyncio
    async def test_create_user(self, db_session: AsyncSession):
        """Test create user"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        user = UserWithPassword(
            name="Test UserWithPassword",
            en_name="Test UserWithPassword",
            email=f"test_{unique_suffix}@example.com",
            mobile=f"1380013800{unique_suffix[:1]}",
            user_id=f"test_user_{unique_suffix}",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        db_session.add(user)
        await db_session.commit()
        await db_session.refresh(user)

        assert user.id is not None
        assert user.name == "Test UserWithPassword"
        assert user.en_name == "Test UserWithPassword"
        assert user.email == f"test_{unique_suffix}@example.com"
        assert user.mobile == f"1380013800{unique_suffix[:1]}"
        assert user.user_id == f"test_user_{unique_suffix}"
        assert user.status == 1
        assert user.locked == 0
        assert user.created_at is not None
        assert user.updated_at is not None

    @pytest.mark.asyncio
    async def test_user_defaults(self, db_session: AsyncSession):
        """Test user defaults"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        user = UserWithPassword(
            name="Default UserWithPassword",
            en_name="Default UserWithPassword",
            email=f"default_{unique_suffix}@example.com",
            mobile=f"1380013801{unique_suffix[:1]}",
            password="y6ZreZqlZeBeIl",
        )

        db_session.add(user)
        await db_session.commit()
        await db_session.refresh(user)

        assert user.status == 0  # Default status
        assert user.locked == 0  # Default not locked
        assert user.user_id is None  # Default is None
        assert user.last_login is None  # Default is None

    @pytest.mark.asyncio
    async def test_user_update_timestamps(self, db_session: AsyncSession):
        """Test user timestamp update"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        user = UserWithPassword(
            name="Timestamp UserWithPassword",
            en_name="Timestamp UserWithPassword",
            email=f"timestamp_{unique_suffix}@example.com",
            mobile=f"1380013802{unique_suffix[:1]}",
            password="y6ZreZqlZeBeIl",
        )

        db_session.add(user)
        await db_session.commit()
        await db_session.refresh(user)

        original_created_at = user.created_at
        original_updated_at = user.updated_at

        await asyncio.sleep(0.1)

        # Update user
        user.name = "Updated UserWithPassword"
        await db_session.commit()
        await db_session.refresh(user)

        assert user.created_at == original_created_at  # Created time unchanged
        assert user.updated_at > original_updated_at  # Updated time changed


class TestRoleModel:
    """Role model test"""

    @pytest.mark.asyncio
    async def test_create_role(self, db_session: AsyncSession):
        """Test create role"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        role = Role(
            name=f"Test Role_{unique_suffix}",
            description="This is a test role",
            is_active=True,
            is_system=False,
        )

        db_session.add(role)
        await db_session.commit()
        await db_session.refresh(role)

        assert role.id is not None
        assert role.name == f"Test Role_{unique_suffix}"
        assert role.description == "This is a test role"
        assert role.is_active is True
        assert role.is_system is False
        assert role.created_at is not None
        assert role.updated_at is not None

    @pytest.mark.asyncio
    async def test_role_defaults(self, db_session: AsyncSession):
        """Test role defaults"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        role = Role(name=f"Default Role_{unique_suffix}")

        db_session.add(role)
        await db_session.commit()
        await db_session.refresh(role)

        assert role.description is None  # Default is None
        assert role.is_active is True  # Default active
        assert role.is_system is False  # Default not system role

    @pytest.mark.asyncio
    async def test_system_role(self, db_session: AsyncSession):
        """Test system role"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        role = Role(
            name=f"System Admin_{unique_suffix}",
            description="System admin role",
            is_system=True,
        )

        db_session.add(role)
        await db_session.commit()
        await db_session.refresh(role)

        assert role.is_system is True
        assert role.is_active is True  # Default active


class TestPermissionModel:
    """Permission model test"""

    @pytest.mark.asyncio
    async def test_create_permission(self, db_session: AsyncSession):
        """Test create permission"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        permission = Permission(
            code=f"user:read:{unique_suffix}",
            name="UserWithPassword read permission",
            description="Allow read user information",
            resource="user",
            action="read",
            permission_type="function",
            is_active=True,
            is_system=False,
        )

        db_session.add(permission)
        await db_session.commit()
        await db_session.refresh(permission)

        assert permission.id is not None
        assert permission.code == f"user:read:{unique_suffix}"
        assert permission.name == "UserWithPassword read permission"
        assert permission.description == "Allow read user information"
        assert permission.resource == "user"
        assert permission.action == "read"
        assert permission.permission_type == "function"
        assert permission.is_active is True
        assert permission.is_system is False
        assert permission.created_at is not None
        assert permission.updated_at is not None

    @pytest.mark.asyncio
    async def test_permission_defaults(self, db_session: AsyncSession):
        """Test permission defaults"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        permission = Permission(
            code=f"default:permission:{unique_suffix}",
            name="Default permission",
        )

        db_session.add(permission)
        await db_session.commit()
        await db_session.refresh(permission)

        assert permission.description is None  # Default is None
        assert permission.resource is None  # Default is None
        assert permission.action is None  # Default is None
        assert permission.permission_type == "function"  # Default value
        assert permission.is_active is True  # Default active
        assert permission.is_system is False  # Default not system permission

    @pytest.mark.asyncio
    async def test_system_permission(self, db_session: AsyncSession):
        """Test system permission"""
        # Use unique identifier to avoid conflict
        unique_suffix = str(uuid.uuid4())[:8]
        permission = Permission(
            code=f"system:admin:{unique_suffix}",
            name="System admin permission",
            description="System admin permission",
            is_system=True,
        )

        db_session.add(permission)
        await db_session.commit()
        await db_session.refresh(permission)

        assert permission.is_system is True
        assert permission.is_active is True  # Default active


class TestRolePermissionRelationModel:
    """Role permission relation model test"""

    @pytest.mark.asyncio
    async def test_create_role_permission_relation(
        self,
        db_session: AsyncSession,
        sample_roles: list[Role],
        sample_permissions: list[Permission],
    ):
        """Test create role permission relation"""
        role = sample_roles[0]
        permission = sample_permissions[0]

        relation = RolePermissionRelation(
            role_id=role.id,
            permission_id=permission.id,
            assigned_by=1,
            is_active=True,
            updated_at=datetime.now(),
        )

        db_session.add(relation)
        await db_session.commit()
        await db_session.refresh(relation)

        assert relation.id is not None
        assert relation.role_id == role.id
        assert relation.permission_id == permission.id
        assert relation.assigned_by == 1
        assert relation.is_active is True
        assert relation.assigned_at is not None
        assert relation.expires_at is None

    @pytest.mark.asyncio
    async def test_role_permission_relation_defaults(
        self,
        db_session: AsyncSession,
        sample_roles: list[Role],
        sample_permissions: list[Permission],
    ):
        """Test role permission relation defaults"""
        role = sample_roles[0]
        permission = sample_permissions[0]

        relation = RolePermissionRelation(
            role_id=role.id,
            permission_id=permission.id,
        )

        db_session.add(relation)
        await db_session.commit()
        await db_session.refresh(relation)

        assert relation.assigned_by is None  # Default is None
        assert relation.expires_at is None  # Default is None
        assert relation.is_active is True  # Default active

    @pytest.mark.asyncio
    async def test_role_permission_relation_with_expiry(
        self,
        db_session: AsyncSession,
        sample_roles: list[Role],
        sample_permissions: list[Permission],
    ):
        """Test role permission relation with expiry"""
        role = sample_roles[0]
        permission = sample_permissions[0]
        expires_at = datetime.now() + timedelta(days=30)

        relation = RolePermissionRelation(
            role_id=role.id,
            permission_id=permission.id,
            assigned_by=1,
            expires_at=expires_at,
        )

        db_session.add(relation)
        await db_session.commit()
        await db_session.refresh(relation)

        assert relation.expires_at is not None
        assert relation.expires_at.date() == expires_at.date()

    @pytest.mark.asyncio
    async def test_multiple_permissions_for_role(
        self,
        db_session: AsyncSession,
        sample_roles: list[Role],
        sample_permissions: list[Permission],
    ):
        """Test one role has multiple permissions"""
        role = sample_roles[0]

        # Assign multiple permissions to role
        for permission in sample_permissions[:3]:
            relation = RolePermissionRelation(
                role_id=role.id,
                permission_id=permission.id,
                assigned_by=1,
            )
            db_session.add(relation)

        await db_session.commit()

        # Validate relation
        statement = select(RolePermissionRelation).where(
            RolePermissionRelation.role_id == role.id
        )
        result = await db_session.exec(statement)
        relations = result.all()

        assert len(relations) == 3
        permission_ids = {rel.permission_id for rel in relations}
        expected_permission_ids = {perm.id for perm in sample_permissions[:3]}
        assert permission_ids == expected_permission_ids

    @pytest.mark.asyncio
    async def test_multiple_roles_for_permission(
        self,
        db_session: AsyncSession,
        sample_roles: list[Role],
        sample_permissions: list[Permission],
    ):
        """Test one permission has multiple roles"""
        permission = sample_permissions[0]

        # Assign multiple roles to permission
        for role in sample_roles[:2]:
            relation = RolePermissionRelation(
                role_id=role.id,
                permission_id=permission.id,
                assigned_by=1,
            )
            db_session.add(relation)

        await db_session.commit()

        # Validate relation
        statement = select(RolePermissionRelation).where(
            RolePermissionRelation.permission_id == permission.id
        )
        result = await db_session.exec(statement)
        relations = result.all()

        assert len(relations) == 2
        role_ids = {rel.role_id for rel in relations}
        expected_role_ids = {role.id for role in sample_roles[:2]}
        assert role_ids == expected_role_ids


class TestUserRoleRelationModel:
    """UserWithPassword role relation model test"""

    @pytest.mark.asyncio
    async def test_create_user_role_relation(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test create user role relation"""
        user = sample_users[0]
        role = sample_roles[0]

        relation = UserRoleRelation(
            user_id=user.id, role_id=role.id, assigned_by=1, is_active=True
        )

        db_session.add(relation)
        await db_session.commit()
        await db_session.refresh(relation)

        assert relation.id is not None
        assert relation.user_id == user.id
        assert relation.role_id == role.id
        assert relation.assigned_by == 1
        assert relation.is_active is True
        assert relation.assigned_at is not None
        assert relation.expires_at is None

    @pytest.mark.asyncio
    async def test_user_role_relation_defaults(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test user role relation defaults"""
        user = sample_users[1]
        role = sample_roles[1]

        relation = UserRoleRelation(user_id=user.id, role_id=role.id)

        db_session.add(relation)
        await db_session.commit()
        await db_session.refresh(relation)

        assert relation.assigned_by is None  # Default is None
        assert relation.is_active is True  # Default active
        assert relation.expires_at is None  # Default not expired

    @pytest.mark.asyncio
    async def test_user_role_relation_with_expiry(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test user role relation with expiry"""
        user = sample_users[2]
        role = sample_roles[2]
        expiry_time = datetime.now()

        relation = UserRoleRelation(
            user_id=user.id,
            role_id=role.id,
            assigned_by=1,
            expires_at=expiry_time,
            is_active=True,
        )

        db_session.add(relation)
        await db_session.commit()
        await db_session.refresh(relation)

        assert relation.expires_at == expiry_time

    @pytest.mark.asyncio
    async def test_multiple_roles_for_user(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test user has multiple roles"""
        user = sample_users[0]

        # Assign multiple roles to user
        relations = []
        for role in sample_roles[:3]:  # First 3 roles
            relation = UserRoleRelation(
                user_id=user.id, role_id=role.id, assigned_by=1, is_active=True
            )
            relations.append(relation)
            db_session.add(relation)

        await db_session.commit()

        for relation in relations:
            await db_session.refresh(relation)
            assert relation.user_id == user.id
            assert relation.is_active is True

    @pytest.mark.asyncio
    async def test_multiple_users_for_role(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test role has multiple users"""
        role = sample_roles[0]

        # Assign multiple users to role
        relations = []
        for user in sample_users:
            relation = UserRoleRelation(
                user_id=user.id, role_id=role.id, assigned_by=1, is_active=True
            )
            relations.append(relation)
            db_session.add(relation)

        await db_session.commit()

        for relation in relations:
            await db_session.refresh(relation)
            assert relation.role_id == role.id
            assert relation.is_active is True
