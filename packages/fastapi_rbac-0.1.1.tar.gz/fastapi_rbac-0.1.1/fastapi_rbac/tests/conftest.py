#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:43:06
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""


import asyncio
import pytest
import pytest_asyncio
from typing import AsyncGenerator, Generator
from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi import FastAPI
from fastapi.testclient import TestClient
from unittest.mock import patch

from ..models import Role, UserRoleRelation, Permission
from ..models.pwd_user_model import UserWithPassword
from ..plugin import RBACPlugin
from ..config import RBACConfig, register_rbac_config, _global_config


@pytest.fixture(scope="session")
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    """Create event loop"""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def async_engine():
    """Asynchronous database engine with preloaded base data"""
    # Use in-memory SQLite database for testing
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        echo=False,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )

    # Create tables
    async with engine.begin() as conn:
        # await conn.run_sync(SQLModel.metadata.drop_all)
        await conn.run_sync(SQLModel.metadata.create_all)

    # Preload base data that will persist across test sessions
    from .init_data import initialize_base_data

    async with AsyncSession(engine) as session:
        await initialize_base_data(session)

    yield engine

    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(async_engine) -> AsyncGenerator[AsyncSession, None]:
    """Database session - use transaction isolation to ensure test independence"""
    # Create a connection and transaction
    connection = await async_engine.connect()
    transaction = await connection.begin()

    # Create a session based on the transaction
    session = AsyncSession(bind=connection, expire_on_commit=False)

    try:
        yield session
    finally:
        # Clean up: close session, rollback transaction, close connection
        await session.close()
        await transaction.rollback()
        await connection.close()


@pytest.fixture(autouse=True, scope="function")
def mock_gen_rbac_async_session(db_session):
    """Mock gen_rbac_async_session to return the test db_session"""

    async def mock_gen_rbac_async_session():
        yield db_session

    import fastapi_rbac.config as config_module

    with patch.object(
        config_module, "gen_rbac_async_session", mock_gen_rbac_async_session
    ):
        yield mock_gen_rbac_async_session


@pytest.fixture
def app(db_session, mock_gen_rbac_async_session) -> FastAPI:
    """FastAPI application instance"""
    from ..serializers.password_user_serializer import PasswordUserSerializer

    # Simulate database session dependency
    async def get_test_db_session():
        return db_session

    test_config = RBACConfig(
        # database_url="sqlite+aiosqlite:///:memory:",
        user_serializer=PasswordUserSerializer,
        # enable_soft_delete=True,
        cache_ttl=300,
        enable_cache=True,
        default_user_role="User",
        system_roles=["Super Admin", "Admin", "User"],
        log_level="INFO",
        enable_audit_log=True,
        jwt_secret="test-secret",
        custom_session_maker=mock_gen_rbac_async_session,
        api_prefix="/rbac",
        frontend_prefix="/rbac-frontend/admin",
    )
    app = FastAPI(title="RBAC Test App")
    rbac_plugin = RBACPlugin(app, test_config)

    # Mock rbac_middleware methods for tests
    if hasattr(app.state, "rbac_middleware"):
        from unittest.mock import AsyncMock

        # Mock get_current_user_id to return a valid user ID (1)
        app.state.rbac_middleware.get_current_user_id = AsyncMock(return_value=1)
        # Mock check_user_permissions to always return True
        app.state.rbac_middleware.check_user_permissions = AsyncMock(return_value=True)

    return app


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    """Test client"""
    return TestClient(app)


@pytest_asyncio.fixture(scope="session")
async def sample_users(async_engine) -> list[UserWithPassword]:
    """Get preloaded base users"""
    from sqlmodel import select
    from .init_data import create_base_users

    async with AsyncSession(async_engine) as session:
        # Query the preloaded base users
        from sqlmodel import or_

        statement = select(UserWithPassword).where(
            or_(
                UserWithPassword.name == "Saber",
                UserWithPassword.name == "Acher",
                UserWithPassword.name == "Caster",
            )
        )
        result = await session.exec(statement)
        users = list(result.all())

        # If base users don't exist, create them (fallback)
        if not users:
            users = create_base_users()
            session.add_all(users)
            await session.commit()
            for user in users:
                await session.refresh(user)

        return users


@pytest_asyncio.fixture(scope="session")
async def sample_roles(async_engine) -> list[Role]:
    """Get preloaded base roles"""
    from sqlmodel import select
    from .init_data import create_base_roles

    async with AsyncSession(async_engine) as session:
        # Query the preloaded base roles
        statement = select(Role).where(Role.name.startswith("Base"))
        result = await session.exec(statement)
        roles = list(result.all())

        # If base roles don't exist, create them (fallback)
        if not roles:
            roles = create_base_roles()
            session.add_all(roles)
            await session.commit()
            for role in roles:
                await session.refresh(role)

        return roles


@pytest_asyncio.fixture(scope="session")
async def sample_user_roles(
    async_engine,
    sample_users: list[UserWithPassword],
    sample_roles: list[Role],
) -> list[UserRoleRelation]:
    """Get preloaded base user role relations"""
    from sqlmodel import select
    from .init_data import create_base_user_role_relations

    async with AsyncSession(async_engine) as session:
        # Query the preloaded base user role relations
        from sqlmodel import or_

        statement = (
            select(UserRoleRelation)
            .join(UserWithPassword, UserRoleRelation.user_id == UserWithPassword.id)
            .where(
                or_(
                    UserWithPassword.name == "Saber",
                    UserWithPassword.name == "Acher",
                    UserWithPassword.name == "Caster",
                )
            )
        )
        result = await session.exec(statement)
        relations = list(result.all())

        # If base relations don't exist, create them (fallback)
        if not relations:
            relations = create_base_user_role_relations(sample_users, sample_roles)
            session.add_all(relations)
            await session.commit()
            for relation in relations:
                await session.refresh(relation)

        return relations


@pytest_asyncio.fixture(scope="session")
async def sample_permissions(async_engine) -> list[Permission]:
    """Get preloaded base permissions"""
    from sqlmodel import select
    from .init_data import create_base_permissions

    async with AsyncSession(async_engine) as session:
        # Query the preloaded base permissions
        statement = select(Permission).where(Permission.code.startswith("base:"))
        result = await session.exec(statement)
        permissions = list(result.all())

        # If base permissions don't exist, create them (fallback)
        if not permissions:
            permissions = create_base_permissions()
            session.add_all(permissions)
            await session.commit()
            for permission in permissions:
                await session.refresh(permission)

        return permissions


@pytest_asyncio.fixture(scope="function")
async def dynamic_test_data(db_session: AsyncSession) -> dict:
    """Create dynamic test data for tests that need unique data per test"""
    import uuid
    from .init_data import create_dynamic_test_data

    unique_suffix = str(uuid.uuid4())[:8]
    return await create_dynamic_test_data(db_session, unique_suffix)


# # Test tags
# pytest.mark.asyncio = pytest.mark.asyncio
# pytest.mark.integration = pytest.mark.integration
# pytest.mark.unit = pytest.mark.unit
