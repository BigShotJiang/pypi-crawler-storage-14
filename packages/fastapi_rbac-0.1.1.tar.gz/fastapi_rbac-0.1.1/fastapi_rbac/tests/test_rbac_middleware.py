"""
RBAC Middleware Tests

Unit tests for RBAC middleware functionality including authentication,
authorization, JWT handling, and permission checking.
"""

import pytest
import pytest_asyncio
import jwt
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timedelta, timezone
from fastapi import Request
from sqlmodel.ext.asyncio.session import AsyncSession

from ..dependencies.rbac_middleware import (
    BaseRBACMiddleware,
    RBACMiddleware,
    clear_user_permissions_cache,
)
from ..config import RBACConfig


class TestBaseRBACMiddleware:
    """Test the BaseRBACMiddleware class"""

    @pytest_asyncio.fixture(autouse=True)
    async def _reset_permission_cache(self):
        """Ensure permission cache is cleared between tests"""
        await clear_user_permissions_cache()
        yield
        await clear_user_permissions_cache()

    @pytest.fixture
    def mock_rbac_plugin(self):
        """Create a mock RBAC plugin"""
        plugin = Mock()
        plugin.get_user_serializer = Mock()
        return plugin

    @pytest.fixture
    def base_middleware(self, mock_rbac_plugin):
        """Create a BaseRBACMiddleware instance"""
        return BaseRBACMiddleware(mock_rbac_plugin)

    @pytest.fixture
    def mock_request(self):
        """Create a mock FastAPI request"""
        return Mock(spec=Request)

    @pytest.fixture
    def mock_db_session(self):
        """Create a mock database session"""
        return Mock(spec=AsyncSession)

    @pytest.fixture
    def mock_user_serializer(self):
        """Create a mock user serializer"""
        serializer = Mock()
        serializer.get_user_roles = AsyncMock()
        serializer.get_user_permissions = AsyncMock()
        return serializer

    def test_base_middleware_init(self, mock_rbac_plugin):
        """Test BaseRBACMiddleware initialization"""
        middleware = BaseRBACMiddleware(mock_rbac_plugin)
        assert middleware.rbac_plugin == mock_rbac_plugin

    @pytest.mark.asyncio
    async def test_get_current_user_id_not_implemented(
        self, base_middleware, mock_request
    ):
        """Test that get_current_user_id is not implemented in base class"""
        result = await base_middleware.get_current_user_id(mock_request)
        assert result is None

    @pytest.mark.asyncio
    async def test_check_permission_user_not_authenticated(
        self, base_middleware, mock_request, mock_db_session
    ):
        """Test permission check when user is not authenticated"""
        with patch.object(
            base_middleware, "get_current_user_id", return_value=None
        ) as mock_get_user_id:
            result = await base_middleware.check_permission(
                mock_request, ["admin"], mock_db_session
            )

            assert result is False
            mock_get_user_id.assert_called_once_with(mock_request)

    @pytest.mark.asyncio
    async def test_check_permission_user_has_required_role(
        self,
        base_middleware,
        mock_request,
        mock_db_session,
        mock_user_serializer,
    ):
        """Test successful permission check when user has required role"""
        # Setup
        mock_role_admin = Mock()
        mock_role_admin.name = "admin"
        mock_role_user = Mock()
        mock_role_user.name = "user"
        mock_roles = [mock_role_admin, mock_role_user]
        mock_user_serializer.get_user_roles.return_value = mock_roles
        base_middleware.rbac_plugin.get_user_serializer.return_value = (
            mock_user_serializer
        )

        with patch.object(
            base_middleware, "get_current_user_id", return_value=1
        ) as mock_get_user_id:
            result = await base_middleware.check_permission(
                mock_request, ["admin", "moderator"], mock_db_session
            )

            assert result is True
            mock_get_user_id.assert_called_once_with(mock_request)
            base_middleware.rbac_plugin.get_user_serializer.assert_called_once_with(
                mock_db_session
            )
            mock_user_serializer.get_user_roles.assert_called_once_with(1)

    @pytest.mark.asyncio
    async def test_check_permission_user_lacks_required_role(
        self,
        base_middleware,
        mock_request,
        mock_db_session,
        mock_user_serializer,
    ):
        """Test permission check failure when user lacks required role"""
        # Setup
        mock_role_user = Mock()
        mock_role_user.name = "user"
        mock_role_guest = Mock()
        mock_role_guest.name = "guest"
        mock_roles = [mock_role_user, mock_role_guest]
        mock_user_serializer.get_user_roles.return_value = mock_roles
        base_middleware.rbac_plugin.get_user_serializer.return_value = (
            mock_user_serializer
        )

        with patch.object(
            base_middleware, "get_current_user_id", return_value=1
        ) as mock_get_user_id:
            result = await base_middleware.check_permission(
                mock_request, ["admin", "moderator"], mock_db_session
            )

            assert result is False

    @pytest.mark.asyncio
    async def test_check_user_permissions_user_not_authenticated(
        self, base_middleware, mock_request, mock_db_session
    ):
        """Test user permission check when user is not authenticated"""
        with patch.object(
            base_middleware, "get_current_user_id", return_value=None
        ) as mock_get_user_id:
            result = await base_middleware.check_user_permissions(
                mock_request, ["user:read"], mock_db_session
            )

            assert result is False
            mock_get_user_id.assert_called_once_with(mock_request)

    @pytest.mark.asyncio
    async def test_check_user_permissions_user_has_admin_permission(
        self,
        base_middleware,
        mock_request,
        mock_db_session,
        mock_user_serializer,
    ):
        """Test user permission check when user has admin permission"""
        # Setup
        mock_user_serializer.get_user_permissions.return_value = [
            "admin:full_access",
            "user:read",
        ]
        base_middleware.rbac_plugin.get_user_serializer.return_value = (
            mock_user_serializer
        )

        with (
            patch.object(base_middleware, "get_current_user_id", return_value=1),
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
            ) as mock_get_config,
        ):
            # Setup config mock
            mock_config = Mock()
            mock_config.admin_permission_code = "admin:full_access"
            mock_get_config.return_value = mock_config

            result = await base_middleware.check_user_permissions(
                mock_request, ["user:write"], mock_db_session
            )

            assert result is True
            mock_user_serializer.get_user_permissions.assert_called_once_with(1)

    @pytest.mark.asyncio
    async def test_check_user_permissions_user_has_specific_permission(
        self,
        base_middleware,
        mock_request,
        mock_db_session,
        mock_user_serializer,
    ):
        """Test user permission check when user has specific required permission"""
        # Setup
        mock_user_serializer.get_user_permissions.return_value = [
            "user:read",
            "user:write",
        ]
        base_middleware.rbac_plugin.get_user_serializer.return_value = (
            mock_user_serializer
        )

        with (
            patch.object(base_middleware, "get_current_user_id", return_value=1),
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
            ) as mock_get_config,
        ):
            # Setup config mock
            mock_config = Mock()
            mock_config.admin_permission_code = "admin:full_access"
            mock_get_config.return_value = mock_config

            result = await base_middleware.check_user_permissions(
                mock_request, ["user:read", "admin:manage"], mock_db_session
            )

            assert result is True

    @pytest.mark.asyncio
    async def test_check_user_permissions_user_lacks_permissions(
        self,
        base_middleware,
        mock_request,
        mock_db_session,
        mock_user_serializer,
    ):
        """Test user permission check when user lacks required permissions"""
        # Setup
        mock_user_serializer.get_user_permissions.return_value = ["user:read"]
        base_middleware.rbac_plugin.get_user_serializer.return_value = (
            mock_user_serializer
        )

        with (
            patch.object(base_middleware, "get_current_user_id", return_value=1),
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
            ) as mock_get_config,
        ):
            # Setup config mock
            mock_config = Mock()
            mock_config.admin_permission_code = "admin:full_access"
            mock_get_config.return_value = mock_config

            result = await base_middleware.check_user_permissions(
                mock_request, ["user:write", "admin:manage"], mock_db_session
            )

            assert result is False

    @pytest.mark.asyncio
    async def test_get_user_permissions_cached_result(
        self, base_middleware, mock_db_session, mock_user_serializer
    ):
        """Test that get_user_permissions caches results per user"""
        await clear_user_permissions_cache()

        base_middleware.rbac_plugin.get_user_serializer.return_value = (
            mock_user_serializer
        )
        mock_user_serializer.get_user_permissions.return_value = ["user:read"]

        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.enable_cache = True
            mock_config.cache_ttl = 60
            mock_get_config.return_value = mock_config

            first_permissions = await base_middleware.get_user_permissions(
                1, mock_db_session
            )
            second_permissions = await base_middleware.get_user_permissions(
                1, mock_db_session
            )

        assert first_permissions == ["user:read"]
        assert second_permissions == ["user:read"]
        mock_user_serializer.get_user_permissions.assert_awaited_once_with(1)


class TestRBACMiddleware:
    """Test the RBACMiddleware class"""

    @pytest.fixture
    def mock_rbac_plugin(self):
        """Create a mock RBAC plugin"""
        return Mock()

    @pytest.fixture
    def rbac_middleware(self, mock_rbac_plugin):
        """Create an RBACMiddleware instance"""
        return RBACMiddleware(mock_rbac_plugin)

    @pytest.fixture
    def mock_request(self):
        """Create a mock FastAPI request"""
        request = Mock(spec=Request)
        request.headers = {}
        request.cookies = {}
        return request

    def test_rbac_middleware_init(self, mock_rbac_plugin):
        """Test RBACMiddleware initialization"""
        middleware = RBACMiddleware(mock_rbac_plugin)
        assert middleware.rbac_plugin == mock_rbac_plugin

    @pytest.mark.asyncio
    async def test_get_current_user_id_from_authorization_header(
        self, rbac_middleware, mock_request
    ):
        """Test getting user ID from Authorization header"""
        # Create a valid JWT token
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            # Create token
            payload = {
                "sub": "123",
                "exp": datetime.now(timezone.utc) + timedelta(hours=1),
            }
            token = jwt.encode(payload, "test-secret", algorithm="HS256")

            # Setup request with Authorization header
            # mock_request.headers = {"Authorization": f"Bearer {token}"}
            mock_request.cookies = {"rbac_token": token}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result == 123

    @pytest.mark.asyncio
    async def test_get_current_user_id_from_user_id_field(
        self, rbac_middleware, mock_request
    ):
        """Test getting user ID from user_id field in JWT"""
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            # Create token with user_id instead of sub
            payload = {
                "user_id": "456",
                "exp": datetime.now(timezone.utc) + timedelta(hours=1),
            }
            token = jwt.encode(payload, "test-secret", algorithm="HS256")

            # mock_request.headers = {"Authorization": f"Bearer {token}"}
            mock_request.cookies = {"rbac_token": token}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result == 456

    @pytest.mark.asyncio
    async def test_get_current_user_id_from_cookie(self, rbac_middleware, mock_request):
        """Test getting user ID from cookie fallback"""
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            # Create token
            payload = {
                "sub": "789",
                "exp": datetime.now(timezone.utc) + timedelta(hours=1),
            }
            token = jwt.encode(payload, "test-secret", algorithm="HS256")

            # Setup request with cookie (no Authorization header)
            mock_request.cookies = {"rbac_token": token}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result == 789

    @pytest.mark.asyncio
    async def test_get_current_user_id_no_token(self, rbac_middleware, mock_request):
        """Test getting user ID when no token is provided"""
        result = await rbac_middleware.get_current_user_id(mock_request)

        assert result is None

    @pytest.mark.asyncio
    async def test_get_current_user_id_invalid_token(
        self, rbac_middleware, mock_request
    ):
        """Test getting user ID with invalid token"""
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            # Setup request with invalid token
            mock_request.headers = {"Authorization": "Bearer invalid.token.here"}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result is None

    @pytest.mark.asyncio
    async def test_get_current_user_id_expired_token(
        self, rbac_middleware, mock_request
    ):
        """Test getting user ID with expired token"""
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            # Create expired token
            payload = {
                "sub": "123",
                "exp": datetime.now(timezone.utc) - timedelta(hours=1),
            }
            token = jwt.encode(payload, "test-secret", algorithm="HS256")

            mock_request.headers = {"Authorization": f"Bearer {token}"}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result is None

    @pytest.mark.asyncio
    async def test_get_current_user_id_malformed_authorization_header(
        self, rbac_middleware, mock_request
    ):
        """Test getting user ID with malformed Authorization header"""
        mock_request.headers = {"Authorization": "InvalidFormat token"}

        result = await rbac_middleware.get_current_user_id(mock_request)

        assert result is None

    @pytest.mark.asyncio
    async def test_get_current_user_id_invalid_user_id_format(
        self, rbac_middleware, mock_request
    ):
        """Test getting user ID when token contains invalid user ID format"""
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            # Create token with invalid user ID
            payload = {
                "sub": "invalid_user_id",
                "exp": datetime.now(timezone.utc) + timedelta(hours=1),
            }
            token = jwt.encode(payload, "test-secret", algorithm="HS256")

            mock_request.headers = {"Authorization": f"Bearer {token}"}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result is None

    @pytest.mark.asyncio
    async def test_get_current_user_id_no_user_id_in_token(
        self, rbac_middleware, mock_request
    ):
        """Test getting user ID when token doesn't contain user ID"""
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            # Create token without sub or user_id
            payload = {"exp": datetime.now(timezone.utc) + timedelta(hours=1)}
            token = jwt.encode(payload, "test-secret", algorithm="HS256")

            mock_request.headers = {"Authorization": f"Bearer {token}"}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result is None

    def test_create_access_token_basic(self, rbac_middleware):
        """Test creating a basic access token"""
        with (
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
            ) as mock_get_config,
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.datetime"
            ) as mock_datetime,
        ):

            # Setup mocks
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_config.access_token_expire_minutes = 60
            mock_get_config.return_value = mock_config

            fixed_now = datetime(2023, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
            mock_datetime.now.return_value = fixed_now

            # Create token
            token = rbac_middleware.create_access_token(subject=123)

            # Verify token can be decoded with options to ignore expiration
            payload = jwt.decode(
                token,
                "test-secret",
                algorithms=["HS256"],
                options={"verify_exp": False},
            )
            assert payload["sub"] == "123"
            assert payload["type"] == "access"
            assert "iat" in payload
            assert "exp" in payload

    def test_create_access_token_with_extra_claims(self, rbac_middleware):
        """Test creating access token with extra claims"""
        with (
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
            ) as mock_get_config,
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.datetime"
            ) as mock_datetime,
        ):

            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_config.access_token_expire_minutes = 60
            mock_get_config.return_value = mock_config

            fixed_now = datetime(2023, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
            mock_datetime.now.return_value = fixed_now

            extra_claims = {"role": "admin", "permissions": ["read", "write"]}
            token = rbac_middleware.create_access_token(
                subject=123, extra_claims=extra_claims
            )

            # Verify token contains extra claims
            payload = jwt.decode(
                token,
                "test-secret",
                algorithms=["HS256"],
                options={"verify_exp": False},
            )
            assert payload["sub"] == "123"
            assert payload["role"] == "admin"
            assert payload["permissions"] == ["read", "write"]

    def test_create_access_token_bytes_return_type(self, rbac_middleware):
        """Test handling when JWT encode returns bytes"""
        with (
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
            ) as mock_get_config,
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.datetime"
            ) as mock_datetime,
            patch(
                "fastapi_rbac.dependencies.rbac_middleware.jwt.encode"
            ) as mock_jwt_encode,
        ):

            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_config.access_token_expire_minutes = 60
            mock_get_config.return_value = mock_config

            fixed_now = datetime(2023, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
            mock_datetime.now.return_value = fixed_now

            # Mock jwt.encode to return bytes
            mock_jwt_encode.return_value = b"encoded.jwt.token"

            token = rbac_middleware.create_access_token(subject=123)

            # Verify bytes are converted to string
            assert token == "encoded.jwt.token"
            assert isinstance(token, str)

    @pytest.mark.asyncio
    async def test_get_current_user_id_bearer_with_extra_spaces(
        self, rbac_middleware, mock_request
    ):
        """Test handling Authorization header with extra spaces"""
        with patch(
            "fastapi_rbac.dependencies.rbac_middleware.get_rbac_config"
        ) as mock_get_config:
            mock_config = Mock()
            mock_config.jwt_secret = "test-secret"
            mock_config.jwt_algorithm = "HS256"
            mock_get_config.return_value = mock_config

            payload = {
                "sub": "123",
                "exp": datetime.now(timezone.utc) + timedelta(hours=1),
            }
            token = jwt.encode(payload, "test-secret", algorithm="HS256")

            # Authorization header with extra spaces
            # mock_request.headers = {"Authorization": f"Bearer   {token}   "}
            mock_request.cookies = {"rbac_token": token}

            result = await rbac_middleware.get_current_user_id(mock_request)

            assert result == 123
