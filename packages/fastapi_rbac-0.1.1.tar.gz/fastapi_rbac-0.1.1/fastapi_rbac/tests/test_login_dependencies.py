"""
Login Dependencies Tests

Unit tests for login-based dependency injection functionality.
"""

import pytest
from unittest.mock import Mock, AsyncMock
from fastapi import HTTPException, Request
from sqlmodel.ext.asyncio.session import AsyncSession

from ..dependencies.login_dependencies import require_login
from ..dependencies.rbac_middleware import RBACMiddleware


class TestRequireLogin:
    """Test the require_login function"""

    def test_require_login_returns_callable(self):
        """Test that require_login returns a callable dependency function"""
        dependency = require_login()

        assert callable(dependency)
        assert hasattr(dependency, "__call__")

    def test_require_login_function_name(self):
        """Test that the returned function has the expected name"""
        dependency = require_login()

        assert dependency.__name__ == "login_dependency"


class TestLoginDependency:
    """Test the login dependency function behavior"""

    @pytest.fixture
    def mock_request(self):
        """Create a mock FastAPI request"""
        mock_request = Mock(spec=Request)
        mock_request.url.path = "/test-endpoint"
        mock_request.app = Mock()
        mock_request.app.state = Mock()
        return mock_request

    @pytest.fixture
    def mock_rbac_middleware(self):
        """Create a mock RBAC middleware"""
        middleware = Mock(spec=RBACMiddleware)
        middleware.get_current_user_id = AsyncMock()
        return middleware

    @pytest.mark.asyncio
    async def test_login_dependency_success(self, mock_request, mock_rbac_middleware):
        """Test successful login validation"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = 1

        # Create dependency
        dependency = require_login()

        # Execute
        result = await dependency(mock_request)

        # Verify
        assert result == 1
        mock_rbac_middleware.get_current_user_id.assert_called_once_with(mock_request)

    @pytest.mark.asyncio
    async def test_login_dependency_authenticated_user_string_id(
        self, mock_request, mock_rbac_middleware
    ):
        """Test successful login validation with string user ID"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = "123"

        # Create dependency
        dependency = require_login()

        # Execute
        result = await dependency(mock_request)

        # Verify
        assert result == "123"
        mock_rbac_middleware.get_current_user_id.assert_called_once_with(mock_request)

    @pytest.mark.asyncio
    async def test_login_dependency_authenticated_user_zero_id(
        self, mock_request, mock_rbac_middleware
    ):
        """Test that user ID 0 is considered valid (some systems use 0 as valid ID)"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = 0

        # Create dependency
        dependency = require_login()

        # Execute and verify exception (0 is falsy and treated as not authenticated)
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request)

        assert exc_info.value.status_code == 401
        assert exc_info.value.detail["error"] == "authentication_required"

    @pytest.mark.asyncio
    async def test_login_dependency_not_authenticated(
        self, mock_request, mock_rbac_middleware
    ):
        """Test authentication required when user is not authenticated"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = None

        # Create dependency
        dependency = require_login()

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request)

        assert exc_info.value.status_code == 401
        assert exc_info.value.detail["error"] == "authentication_required"
        assert "User authentication required" in exc_info.value.detail["message"]
        assert exc_info.value.detail["endpoint"] == "/test-endpoint"

    @pytest.mark.asyncio
    async def test_login_dependency_empty_string_user_id(
        self, mock_request, mock_rbac_middleware
    ):
        """Test that empty string user ID is treated as not authenticated"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = ""

        # Create dependency
        dependency = require_login()

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request)

        assert exc_info.value.status_code == 401
        assert exc_info.value.detail["error"] == "authentication_required"

    @pytest.mark.asyncio
    async def test_login_dependency_rbac_middleware_not_configured(self, mock_request):
        """Test configuration error when RBAC middleware is not configured"""
        # Setup - no rbac_middleware in app state
        mock_request.app.state.rbac_middleware = None

        # Create dependency
        dependency = require_login()

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request)

        assert exc_info.value.status_code == 500
        assert exc_info.value.detail["error"] == "configuration_error"
        assert (
            "RBAC middleware not configured properly"
            in exc_info.value.detail["message"]
        )
        assert exc_info.value.detail["endpoint"] == "/test-endpoint"

    @pytest.mark.asyncio
    async def test_login_dependency_middleware_missing_from_state(self, mock_request):
        """Test when app.state doesn't have rbac_middleware attribute"""
        # Setup - app.state doesn't have rbac_middleware attribute
        mock_request.app.state = Mock()
        # Explicitly remove any rbac_middleware attribute to simulate missing attribute
        if hasattr(mock_request.app.state, "rbac_middleware"):
            delattr(mock_request.app.state, "rbac_middleware")

        # Create dependency
        dependency = require_login()

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request)

        assert exc_info.value.status_code == 500
        assert exc_info.value.detail["error"] == "configuration_error"

    @pytest.mark.asyncio
    async def test_login_dependency_middleware_get_user_id_exception(
        self, mock_request, mock_rbac_middleware
    ):
        """Test handling when middleware's get_current_user_id raises exception"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.side_effect = Exception(
            "Token validation error"
        )

        # Create dependency
        dependency = require_login()

        # Execute - should re-raise the exception (no explicit handling in the code)
        with pytest.raises(Exception) as exc_info:
            await dependency(mock_request)

        assert "Token validation error" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_login_dependency_complex_url_path(self, mock_rbac_middleware):
        """Test with complex URL path in error message"""
        # Setup
        mock_request = Mock(spec=Request)
        mock_request.url.path = "/api/v1/users/123/profile"
        mock_request.app = Mock()
        mock_request.app.state = Mock()
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = None

        # Create dependency
        dependency = require_login()

        # Execute and verify exception with correct endpoint
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request)

        assert exc_info.value.detail["endpoint"] == "/api/v1/users/123/profile"

    @pytest.mark.asyncio
    async def test_login_dependency_boolean_user_id(
        self, mock_request, mock_rbac_middleware
    ):
        """Test with boolean user ID (edge case)"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = True

        # Create dependency
        dependency = require_login()

        # Execute
        result = await dependency(mock_request)

        # Verify - True is truthy so should pass
        assert result is True

    @pytest.mark.asyncio
    async def test_login_dependency_false_user_id(
        self, mock_request, mock_rbac_middleware
    ):
        """Test with False user ID"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = False

        # Create dependency
        dependency = require_login()

        # Execute and verify exception (False is falsy)
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request)

        assert exc_info.value.status_code == 401
        assert exc_info.value.detail["error"] == "authentication_required"
