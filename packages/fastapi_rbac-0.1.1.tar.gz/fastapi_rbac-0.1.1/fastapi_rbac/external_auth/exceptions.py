"""
External Authentication Exceptions

This module defines custom exceptions for external authentication operations.
"""

from typing import Optional, Dict, Any


class ExternalAuthError(Exception):
    """Base exception for external authentication errors"""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class ExternalAuthConfigError(ExternalAuthError):
    """Exception raised when external authentication configuration is invalid"""

    pass


class ExternalAuthUserNotFound(ExternalAuthError):
    """Exception raised when user is not found in external system"""

    pass


class ExternalAuthTokenInvalid(ExternalAuthError):
    """Exception raised when external authentication token is invalid"""

    pass


class ExternalAuthServiceUnavailable(ExternalAuthError):
    """Exception raised when external authentication service is unavailable"""

    pass
