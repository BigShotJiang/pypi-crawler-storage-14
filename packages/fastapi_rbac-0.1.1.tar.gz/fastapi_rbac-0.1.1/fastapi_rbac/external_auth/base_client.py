"""
Base External Authentication Client

This module defines the base class for implementing third-party authentication clients.
All external authentication clients should inherit from this base class.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any
from fastapi import Request
from sqlmodel.ext.asyncio.session import AsyncSession


class BaseExternalAuthClient(ABC):
    """
    Abstract base class for external authentication clients

    This class defines the standard interface that all external authentication
    clients must implement. It provides a consistent way to integrate with
    various third-party authentication systems.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize external authentication client

        Args:
            config: Configuration dictionary containing client-specific settings
        """
        self.config = config
        self._validate_config()

    @abstractmethod
    def _validate_config(self) -> None:
        """
        Validate client configuration

        Raises:
            ExternalAuthConfigError: If configuration is invalid
        """
        pass

    @abstractmethod
    async def get_user_info(self, request: Request, session: AsyncSession):
        """
        Get user information from external authentication system

        Args:
            auth_token: Authentication token from external system

        Returns:
            ExternalUserInfo: User Model in UserSerializer

        Raises:
            ExternalAuthUserNotFound: If user is not found
            ExternalAuthTokenInvalid: If token is invalid
            ExternalAuthServiceUnavailable: If external service is unavailable
        """
        pass

    @abstractmethod
    async def validate_token(self, auth_token: str) -> bool:
        """
        Validate authentication token with external system

        Args:
            auth_token: Authentication token to validate

        Returns:
            bool: True if token is valid, False otherwise
        """
        pass

    @abstractmethod
    def get_provider_name(self) -> str:
        """
        Get the name of this authentication provider

        Returns:
            str: Provider name (e.g., "google", "microsoft", "okta")
        """
        pass

    async def health_check(self) -> bool:
        """
        Check if external authentication service is available

        Returns:
            bool: True if service is available, False otherwise
        """
        try:
            # Default implementation - can be overridden by subclasses
            return True
        except Exception:
            return False
