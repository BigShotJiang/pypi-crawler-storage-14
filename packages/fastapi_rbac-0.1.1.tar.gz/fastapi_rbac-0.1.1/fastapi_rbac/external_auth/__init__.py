"""
External Authentication Module

This module provides support for third-party authentication systems like SSO.
It includes base classes for implementing custom authentication clients and
utilities for managing external user authentication.
"""

from .base_client import BaseExternalAuthClient
from .exceptions import (
    ExternalAuthError,
    ExternalAuthConfigError,
    ExternalAuthUserNotFound,
)

__all__ = [
    "BaseExternalAuthClient",
    "ExternalAuthError",
    "ExternalAuthConfigError",
    "ExternalAuthUserNotFound",
]
