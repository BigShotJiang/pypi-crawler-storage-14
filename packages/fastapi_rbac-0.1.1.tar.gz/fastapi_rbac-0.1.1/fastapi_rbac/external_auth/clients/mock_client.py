"""
Mock External Authentication Client

This is a mock implementation for testing and development purposes.
It simulates external authentication without making real API calls.
"""

from typing import Dict, Any
from datetime import datetime, timezone

from fastapi import Request
from sqlmodel.ext.asyncio.session import AsyncSession
from ..base_client import BaseExternalAuthClient
from ..exceptions import (
    ExternalAuthUserNotFound,
    ExternalAuthTokenInvalid,
)


class MockExternalAuthClient(BaseExternalAuthClient):
    """
    Mock external authentication client for testing and development

    This client simulates external authentication by validating tokens
    against a predefined set of mock users.
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._mock_users = {
            "valid_token_1": {
                "external_id": "mock_user_001",
                "email": "john.doe@example.com",
                "name": "John Doe",
                "username": "johndoe",
                "first_name": "John",
                "last_name": "Doe",
                "phone": "+1234567890",
                "is_active": True,
                "is_verified": True,
                "last_login": datetime.now(timezone.utc),
            },
            "valid_token_2": {
                "external_id": "mock_user_002",
                "email": "jane.smith@example.com",
                "name": "Jane Smith",
                "username": "janesmith",
                "first_name": "Jane",
                "last_name": "Smith",
                "phone": "+0987654321",
                "is_active": True,
                "is_verified": True,
                "last_login": datetime.now(timezone.utc),
            },
            "inactive_token": {
                "external_id": "mock_user_003",
                "email": "inactive@example.com",
                "name": "Inactive User",
                "username": "inactive",
                "first_name": "Inactive",
                "last_name": "User",
                "phone": "+1111111111",
                "is_active": False,
                "is_verified": False,
                "last_login": None,
            },
        }

    def _validate_config(self) -> None:
        """Validate mock client configuration"""
        # Mock client doesn't require any specific configuration
        pass

    async def get_user_info(self, request: Request, session: AsyncSession):
        """
        Get user information from mock external system

        Args:
            request: FastAPI request
            session: SQLModel session

        Returns:
            User Model instance: Mock user information

        Raises:
            ExternalAuthUserNotFound: If token is not found
            ExternalAuthTokenInvalid: If token is invalid
        """
        auth_token = request.state.auth_token
        if auth_token not in self._mock_users:
            if auth_token.startswith("invalid_"):
                raise ExternalAuthTokenInvalid("Invalid token format")
            else:
                raise ExternalAuthUserNotFound("User not found in mock system")

        user_data = self._mock_users[auth_token]

        # Import here to avoid circular imports
        from ...models import get_user_model

        UserModel = get_user_model()

        # Create User model instance from mock data
        user = UserModel(
            name=user_data["name"],
            en_name=user_data["name"],  # Use name as en_name for mock
            email=user_data["email"],
            mobile=user_data["phone"],
            user_id=user_data["external_id"],  # external_id
            status=1 if user_data["is_active"] else 0,
            locked=0 if user_data["is_verified"] else 1,
        )

        return user

    async def validate_token(self, auth_token: str) -> bool:
        """
        Validate mock authentication token

        Args:
            auth_token: Mock authentication token

        Returns:
            bool: True if token is valid, False otherwise
        """
        return auth_token in self._mock_users

    def get_provider_name(self) -> str:
        """Get the name of this authentication provider"""
        return "mock"

    async def health_check(self) -> bool:
        """Check if mock service is available"""
        return True
