"""
User Model Definition

This module defines the user model in the RBAC system. It introduces an abstract
`BaseUser` for permission checks and a concrete `User` model for persistence.
The `User.password` stores a hash, never plaintext.
"""

from typing import Optional, TYPE_CHECKING

from sqlmodel import Field

from .base_model import AsyncModel

if TYPE_CHECKING:
    # For type checking only; avoids runtime import cycles
    from .user_role_relation import UserRoleRelation  # noqa: F401


class BaseUser(AsyncModel):
    """
    Abstract user base for permission checks.

    Only contains the minimal fields required by permission logic.

    ATTENTION:
        you must define user_roles field in the subclass of BaseUser, e.g.
        class User(BaseUser, table=True):
            user_roles: List["UserRoleRelation"] = Relationship(
                back_populates="user",
                sa_relationship_kwargs={
                    "primaryjoin": "User.id==UserRoleRelation.user_id",
                    "foreign_keys": "[UserRoleRelation.user_id]",
                    "cascade": "all, delete-orphan",
                },
            )
    """

    id: Optional[int] = Field(default=None, primary_key=True, description="User ID")
    email: str = Field(
        index=True, unique=True, max_length=100, description="Email address"
    )

    # ATTENTION: Only for password super user login
    #             If you need the full password function, you should use the UserWithPassword model
    password: Optional[str] = Field(default=None, description="Password.")

    class Config:
        """Model configuration"""

        from_attributes = True
        str_strip_whitespace = True
        arbitrary_types_allowed = True
