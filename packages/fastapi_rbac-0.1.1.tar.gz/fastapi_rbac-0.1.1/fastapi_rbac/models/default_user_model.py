"""
User Model Definition

This module defines the user model in the RBAC system. It introduces an abstract
`BaseUser` for permission checks and a concrete `User` model for persistence.
The `User.password` stores a hash, never plaintext.
"""

from typing import List, Optional
from sqlmodel import Field, Relationship
from datetime import datetime

from .base_user_model import BaseUser
from .user_role_relation import UserRoleRelation


class User(BaseUser, table=True):
    """
    Concrete user model.

    Extends `BaseUser` with application-specific fields and relationships.
    """

    __tablename__: str = "t_users"

    name: str = Field(index=True, max_length=50, min_length=5, description="Username")
    en_name: str = Field(index=True, max_length=50, description="English name")

    mobile: str = Field(index=True, max_length=100, description="Mobile phone")

    # External system integration fields
    user_id: Optional[str] = Field(
        default=None,
        index=True,
        max_length=100,
        description="External system user ID for SSO integration",
    )

    # Status management
    status: int = Field(default=0, description="User status")
    locked: int = Field(default=0, description="User lock status")

    # Timestamp fields
    created_at: datetime = Field(
        default_factory=datetime.now, description="Creation time"
    )
    updated_at: datetime = Field(
        default_factory=datetime.now,
        description="Update time",
        sa_column_kwargs={"onupdate": datetime.now},
    )
    last_login: Optional[datetime] = Field(default=None, description="Last login time")

    def __str__(self) -> str:
        return f"User(id={self.id}, name='{self.name}', email='{self.email}')"

    def __repr__(self) -> str:
        return f"User(id={self.id}, name='{self.name}', email='{self.email}', status={self.status})"

    # Relationship definitions
    user_roles: List["UserRoleRelation"] = Relationship(
        # back_populates="user",
        sa_relationship_kwargs={
            "primaryjoin": "User.id==UserRoleRelation.user_id",
            "foreign_keys": "[UserRoleRelation.user_id]",
            "cascade": "all, delete-orphan",
        },
    )

    class Config:
        """Model configuration"""

        from_attributes = True
        str_strip_whitespace = True
        arbitrary_types_allowed = True
