"""
Models Module Initialization

Export all RBAC-related data models and provide dynamic model factory.
"""

from typing import List, Type, Dict, Any
from sqlmodel import SQLModel

from .role_model import Role
from .base_user_model import BaseUser as User
from .user_role_relation import UserRoleRelation
from .permission_model import Permission
from .role_permission_relation import RolePermissionRelation
from .model_factory import (
    ModelFactory,
    get_user_model,
    get_role_model,
    get_permission_model,
    get_user_role_relation_model,
    get_role_permission_relation_model,
    get_all_models,
)

# Global variable to store current models
_current_models: Dict[str, Type[SQLModel]] = {}


def create_dynamic_models(
    custom_user_model: Type[SQLModel],
) -> Dict[str, Type[SQLModel]]:
    """
    Create dynamic RBAC models with optional custom User model

    Args:
        custom_user_model: Custom User model class (must inherit from base User)

    Returns:
        Dictionary containing all RBAC model classes
    """
    global _current_models

    # Use custom user model or default
    user_model = custom_user_model

    # Validate custom user model
    if custom_user_model and not issubclass(custom_user_model, User):
        raise ValueError("Custom user model must inherit from base User model")

    # Update global models registry
    models = {
        "User": user_model,
        "Role": Role,
        "UserRoleRelation": UserRoleRelation,
        "Permission": Permission,
        "RolePermissionRelation": RolePermissionRelation,
    }

    _current_models.update(models)
    return models


def get_current_models() -> Dict[str, Type[SQLModel]]:
    """
    Get currently active models
    """
    if not _current_models:
        # Initialize with default models
        from ..config import get_rbac_config

        rbac_config = get_rbac_config()
        create_dynamic_models(rbac_config.user_serializer.user_model)
    return _current_models


def get_rbac_models() -> List[Type[SQLModel]]:
    """
    Get list of all RBAC models for database operations
    """
    models = get_current_models()
    return list(models.values())


def get_rbac_metadata() -> Any:
    """
    Get SQLModel metadata for database operations
    """
    # Only include the currently active user model in metadata
    models = get_current_models()
    user_model = models.get("User")

    if not user_model:
        raise RuntimeError("User model not initialized")

    # Create a new metadata instance with only the active models
    from sqlmodel import SQLModel

    metadata = SQLModel.metadata

    return metadata


# Export models for backward compatibility
__all__ = [
    "Role",
    "User",  # This will be the dynamically selected user model
    "UserRoleRelation",
    "Permission",
    "RolePermissionRelation",
    "ModelFactory",
    "get_user_model",
    "get_role_model",
    "get_permission_model",
    "get_user_role_relation_model",
    "get_role_permission_relation_model",
    "get_all_models",
    "create_dynamic_models",
    "get_current_models",
    "get_rbac_models",
    "get_rbac_metadata",
]
