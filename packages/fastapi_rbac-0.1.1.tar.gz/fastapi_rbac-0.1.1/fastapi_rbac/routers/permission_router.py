#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-27 09:58:16
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""
from typing import List, Optional, Callable
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlmodel.ext.asyncio.session import AsyncSession

from ..schemas import (
    PermissionCreate,
    PermissionUpdate,
    PermissionResponse,
    RoleInfo,
    PermissionSearchParams,
    RolePermissionAssignment,
    PaginationParams,
    PaginatedResponse,
)
from ..serializers import PermissionSerializer
from ..dependencies.permission_dependencies import require_permissions


def create_permission_router(get_db_session: Callable) -> APIRouter:
    """
    Create permission router

    Args:
        get_db_session: The database session dependency function

    Returns:
        Configured permission router
    """
    router = APIRouter(prefix="/permissions", tags=["Permission Management"])

    @router.get(
        "",
        response_model=PaginatedResponse[PermissionResponse],
        summary="Get permission list",
        description="Paginated query permission list, support multiple search conditions",
    )
    async def get_permissions(
        page: int = Query(1, ge=1, description="Page number"),
        size: int = Query(20, ge=1, le=100, description="Page size"),
        code: Optional[str] = Query(None, description="Permission code search"),
        name: Optional[str] = Query(None, description="Permission name search"),
        description: Optional[str] = Query(
            None, description="Permission description search"
        ),
        resource: Optional[str] = Query(None, description="Permission resource search"),
        action: Optional[str] = Query(
            None, description="Permission action type search"
        ),
        permission_type: Optional[str] = Query(
            None, description="Permission type search"
        ),
        is_active: Optional[bool] = Query(None, description="Active status filter"),
        is_system: Optional[bool] = Query(None, description="System permission filter"),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:permissions")),
    ):
        """Get permission list"""
        # Build pagination parameters
        pagination = PaginationParams(page=page, size=size)

        # Build search parameters
        search_params = PermissionSearchParams(
            code=code,
            name=name,
            description=description,
            resource=resource,
            action=action,
            permission_type=permission_type,
            is_active=is_active,
            is_system=is_system,
            created_after=None,
            created_before=None,
        )

        # Query permission list
        permission_serializer = PermissionSerializer(db_session)
        result = await permission_serializer.get_permissions(
            pagination=pagination,
            search_params=search_params,
        )

        return result

    @router.post(
        "",
        response_model=PermissionResponse,
        status_code=status.HTTP_201_CREATED,
        summary="Create permission",
        description="Create a new permission",
    )
    async def create_permission(
        permission_data: PermissionCreate,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("permission:create")),
    ):
        """Create permission"""
        permission_serializer = PermissionSerializer(db_session)
        permission = await permission_serializer.create_permission(permission_data)

        return permission

    @router.get(
        "/{permission_id}",
        response_model=PermissionResponse,
        summary="Get permission details",
        description="Get detailed information for a single permission by ID",
    )
    async def get_permission(
        permission_id: int,
        include_roles: bool = Query(
            False, description="Whether to include role information"
        ),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:permissions")),
    ):
        """Get single permission details"""
        permission_serializer = PermissionSerializer(db_session)
        permission = await permission_serializer.get_permission(
            permission_id, include_roles=include_roles
        )

        if not permission:
            raise HTTPException(
                status_code=404,
                detail=f"Permission with ID {permission_id} not found",
            )

        return permission

    @router.put(
        "/{permission_id}",
        response_model=PermissionResponse,
        summary="Update permission",
        description="Update the information of the specified permission",
    )
    async def update_permission(
        permission_id: int,
        permission_data: PermissionUpdate,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("permission:edit")),
    ):
        """Update permission"""
        permission_serializer = PermissionSerializer(db_session)
        permission = await permission_serializer.update_permission(
            permission_id, permission_data
        )

        return permission

    @router.delete(
        "/{permission_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        summary="Delete permission",
        description="Delete the specified permission",
    )
    async def delete_permission(
        permission_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("permission:delete")),
    ):
        """Delete permission"""
        permission_serializer = PermissionSerializer(db_session)
        success = await permission_serializer.delete_permission(permission_id)

        if not success:
            raise HTTPException(
                status_code=500,
                detail="Failed to delete permission",
            )

        return None

    @router.get(
        "/{permission_id}/roles",
        response_model=List[RoleInfo],
        summary="Get permission role list",
        description="Get all role information for the specified permission",
    )
    async def get_permission_roles(
        permission_id: int, db_session: AsyncSession = Depends(get_db_session)
    ):
        """Get permission role list"""
        permission_serializer = PermissionSerializer(db_session)
        roles = await permission_serializer.get_permission_roles(permission_id)

        return roles

    @router.post(
        "/{permission_id}/roles",
        response_model=dict,
        summary="Assign roles to permission",
        description="Assign roles to the specified permission",
    )
    async def assign_roles_to_permission(
        permission_id: int,
        assignment_data: RolePermissionAssignment,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("permission:assign_roles")),
    ):
        """Assign roles to permission"""
        permission_serializer = PermissionSerializer(db_session)
        relations = await permission_serializer.assign_roles(
            permission_id, assignment_data
        )

        return {
            "message": f"Successfully assigned {len(relations)} roles",
            "assigned_count": len(relations),
            "relations": [
                {
                    "id": rel.id,
                    "role_id": rel.role_id,
                    "permission_id": rel.permission_id,
                    "assigned_at": rel.assigned_at,
                }
                for rel in relations
            ],
        }

    @router.delete(
        "/{permission_id}/roles/{role_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        summary="Remove role from permission",
        description="Remove role from the specified permission",
    )
    async def remove_role_from_permission(
        permission_id: int,
        role_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("permission:assign_roles")),
    ):
        """Remove role from permission"""
        permission_serializer = PermissionSerializer(db_session)
        success = await permission_serializer.remove_role(permission_id, role_id)

        if not success:
            raise HTTPException(
                status_code=500, detail="Failed to remove role from permission"
            )

        return None

    return router
