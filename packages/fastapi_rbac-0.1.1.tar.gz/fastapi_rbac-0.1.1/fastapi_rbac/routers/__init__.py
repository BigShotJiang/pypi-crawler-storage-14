#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:41:59
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""

from typing import Callable, List, Dict, Any
from fastapi import APIRouter

from .user_router import create_user_router
from .role_router import create_role_router
from .permission_router import create_permission_router


def create_rbac_router(
    get_db_session: Callable, api_prefix: str = "/rbac"
) -> APIRouter:
    """
    Create complete RBAC routes

    Args:
        get_db_session: Database session dependency function
        api_prefix: API routes prefix

    Returns:
        Main router containing all RBAC routes
    """
    # Create main router
    main_router = APIRouter(prefix=api_prefix, tags=["RBAC permission management"])

    # Create sub-routes
    user_router = create_user_router(get_db_session)
    role_router = create_role_router(get_db_session)
    permission_router = create_permission_router(get_db_session)

    # Register sub-routes
    main_router.include_router(user_router)
    main_router.include_router(role_router)
    main_router.include_router(permission_router)

    return main_router


def get_available_routers() -> List[Dict[str, Any]]:
    """
    Get available router list

    Returns:
        Router information list
    """
    return [
        {
            "name": "users",
            "description": "User management routes",
            "prefix": "/users",
            "factory": create_user_router,
        },
        {
            "name": "roles",
            "description": "Role management routes",
            "prefix": "/roles",
            "factory": create_role_router,
        },
        {
            "name": "permissions",
            "description": "Permission management routes",
            "prefix": "/permissions",
            "factory": create_permission_router,
        },
    ]


# Export router creation functions
__all__ = [
    "create_rbac_router",
    "create_user_router",
    "create_role_router",
    "create_permission_router",
    "get_available_routers",
]
