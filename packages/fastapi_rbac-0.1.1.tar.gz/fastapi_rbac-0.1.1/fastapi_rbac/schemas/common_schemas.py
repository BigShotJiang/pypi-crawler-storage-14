"""
Common Data Transfer Objects (DTOs)

Defines common input and output data structures such as pagination, response formats, etc.
"""

from typing import Generic, TypeVar, List, Optional, Any
from pydantic import BaseModel, Field


T = TypeVar("T")


class PaginationParams(BaseModel):
    """Pagination parameters"""

    page: int = Field(default=1, ge=1, description="Page number")
    size: int = Field(default=20, ge=1, le=100, description="Page size")

    @property
    def offset(self) -> int:
        """Calculate offset"""
        return (self.page - 1) * self.size


class PaginatedResponse(BaseModel, Generic[T]):
    """Paginated response"""

    items: List[T] = Field(..., description="Data list")
    total: int = Field(..., description="Total records")
    page: int = Field(..., description="Current page number")
    size: int = Field(..., description="Page size")
    pages: int = Field(..., description="Total pages")
    has_next: bool = Field(..., description="Has next page")
    has_prev: bool = Field(..., description="Has previous page")

    @classmethod
    def create(
        cls, items: List[T], total: int, page: int, size: int
    ) -> "PaginatedResponse[T]":
        """Create paginated response"""
        pages = (total + size - 1) // size  # Round up
        return cls(
            items=items,
            total=total,
            page=page,
            size=size,
            pages=pages,
            has_next=page < pages,
            has_prev=page > 1,
        )


class ErrorResponse(BaseModel):
    """Error response"""

    detail: str = Field(..., description="Error details")
    error_code: Optional[str] = Field(None, description="Error code")
    timestamp: Optional[str] = Field(None, description="Error timestamp")
    path: Optional[str] = Field(None, description="Request path")
    extra: Optional[dict] = Field(None, description="Additional information")


class SuccessResponse(BaseModel):
    """Success response"""

    message: str = Field(..., description="Success message")
    data: Optional[Any] = Field(None, description="Response data")
    timestamp: Optional[str] = Field(None, description="Response timestamp")


class BulkOperationResult(BaseModel):
    """Bulk operation result"""

    success_count: int = Field(..., description="Success count")
    failed_count: int = Field(..., description="Failed count")
    failed_items: List[dict] = Field(
        default_factory=list, description="Failed items details"
    )
    total_count: int = Field(..., description="Total operation count")

    @property
    def is_partial_success(self) -> bool:
        """Is partially successful"""
        return self.failed_count > 0 and self.success_count > 0

    @property
    def is_all_success(self) -> bool:
        """Is all successful"""
        return self.failed_count == 0 and self.success_count > 0

    @property
    def is_all_failed(self) -> bool:
        """Is all failed"""
        return self.success_count == 0 and self.failed_count > 0
