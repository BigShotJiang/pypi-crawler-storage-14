"""
Role-related Data Transfer Objects (DTOs)

Defines input and output data structures for role-related operations.
"""

from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class RoleBase(BaseModel):
    """Role base information"""

    name: str = Field(..., min_length=1, max_length=50, description="Role name")
    description: Optional[str] = Field(
        None, max_length=200, description="Role description"
    )


class RoleCreate(RoleBase):
    """Role creation data"""

    is_active: bool = Field(True, description="Role active status")
    is_system: bool = Field(False, description="System built-in role")


class RoleUpdate(BaseModel):
    """Role update data"""

    name: Optional[str] = Field(
        None, min_length=1, max_length=50, description="Role name"
    )
    description: Optional[str] = Field(
        None, max_length=200, description="Role description"
    )
    is_active: Optional[bool] = Field(None, description="Role active status")


class RoleResponse(RoleBase):
    """Role response data"""

    model_config = ConfigDict(from_attributes=True)

    id: int = Field(..., description="Role ID")
    is_active: bool = Field(..., description="Role active status")
    is_system: bool = Field(..., description="System built-in role")
    created_at: datetime = Field(..., description="Creation time")
    updated_at: datetime = Field(..., description="Update time")


class UserInfo(BaseModel):
    """Brief user information"""

    model_config = ConfigDict(from_attributes=True)

    id: int = Field(..., description="User ID")
    name: str = Field(..., description="Username")
    en_name: str = Field(..., description="English name")
    email: str = Field(..., description="Email address")
    mobile: str = Field(..., description="Mobile phone")
    status: int = Field(..., description="User status")


class RoleWithUsers(RoleResponse):
    """Role information with users"""

    users: List[UserInfo] = Field(default_factory=list, description="Role user list")


class UserRoleAssignment(BaseModel):
    """User role assignment data"""

    user_ids: List[int] = Field(..., min_length=1, description="User ID list")
    assigned_by: Optional[int] = Field(None, description="Assignor ID")
    expires_at: Optional[datetime] = Field(None, description="Role expiration time")


class PermissionRoleAssignment(BaseModel):
    """Permission role assignment data - for assigning permissions to a role"""

    permission_ids: List[int] = Field(
        ..., min_length=1, description="Permission ID list"
    )
    assigned_by: Optional[int] = Field(None, description="Assignor ID")
    expires_at: Optional[datetime] = Field(
        None, description="Permission expiration time"
    )


class RoleSearchParams(BaseModel):
    """Role search parameters"""

    name: Optional[str] = Field(None, description="Role name search")
    description: Optional[str] = Field(None, description="Role description search")
    is_active: Optional[bool] = Field(None, description="Active status filter")
    is_system: Optional[bool] = Field(None, description="System role filter")
    created_after: Optional[datetime] = Field(None, description="Creation time start")
    created_before: Optional[datetime] = Field(None, description="Creation time end")
