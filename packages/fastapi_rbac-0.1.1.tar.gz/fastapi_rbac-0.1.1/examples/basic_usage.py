#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RBAC Frontend Management System - Basic Usage Example

This example demonstrates how to:
1. Setup FastAPI application with RBAC frontend management
2. Initialize database with sample data
3. Use the web interface for managing users, roles, and permissions
4. Integrate with existing API endpoints
5. **NEW**: Use custom User models with additional fields
6. **NEW**: Permission demo with Index Page showing permission checking functionality

CUSTOM USER MODEL USAGE:
    To use a custom User model with additional fields:

    1. Create your extended User model:
    ```python
    from models import User
    from sqlmodel import Field

    class MyCustomUser(User, table=True):
        __tablename__ = "t_users"  # Use same table

        # Add your custom fields
        department: Optional[str] = Field(default=None, max_length=100)
        employee_id: Optional[str] = Field(default=None, max_length=50)
    ```

    2. Configure the Settings:
    ```python
    settings = Settings(custom_user_model=MyCustomUser)
    ```

    3. Use in your application:
    ```python
    app = create_app(rbac_settings)
    await init_rbac(engine, rbac_settings, app, seed_sample_data=True, reset_schema=True)
    ```

Usage:
    # Install dependencies first
    uv sync

    # Run the example
    uv run python examples/basic_usage.py

    # Then visit:
    # - Index Page (Permission Demo): http://localhost:8000/index
    # - Frontend Dashboard: http://localhost:8000/admin/
    # - API Documentation: http://localhost:8000/docs
    # - User Management: http://localhost:8000/admin/users
    # - Role Management: http://localhost:8000/admin/roles
    # - Permission Management: http://localhost:8000/admin/permissions
"""
import sys
import os

from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.asyncio import create_async_engine

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


import asyncio
import os
import logging
import uvicorn
from fastapi import FastAPI, Depends, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import (
    RedirectResponse,
    HTMLResponse,
    JSONResponse,
    PlainTextResponse,
)
from sqlmodel.ext.asyncio.session import AsyncSession

# Import your existing RBAC components

from fastapi_rbac.config import (
    RBACConfig,
    gen_rbac_async_session,
    set_rbac_db_config,
)
from fastapi_rbac.dependencies.permission_dependencies import require_permissions

from fastapi_rbac.plugin import RBACPlugin
from examples.init_rbac_data import init_rbac


# Import necessary schemas for the fixes
from fastapi_rbac.dependencies.login_dependencies import require_login

from datetime import datetime

from dotenv import load_dotenv

if os.path.exists(os.path.join(os.path.dirname(__file__), ".env")):
    load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))


database_url = os.getenv("RBAC_DATABASE_URL", "sqlite+aiosqlite:///rbac.db")

database_params = {
    #     "echo": False,
    #     "future": True,
    #     "pool_recycle": 60 * 5,
    #     "pool_pre_ping": True,
    #     "pool_size": 10,
    #     "max_overflow": 20,
}


def create_app(rbac_settings) -> FastAPI:
    """Create and configure the FastAPI application"""
    # Initialize dynamic models with custom user model if provided

    # Create FastAPI app
    app = FastAPI(
        title="RBAC Management System",
        description="Role-Based Access Control system with web interface",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
    )
    RBACPlugin(app, rbac_settings)

    # Catch-all exception handler to ensure stacktraces are logged and appropriate responses are returned
    @app.exception_handler(Exception)
    async def unhandled_exception_logger(request: Request, exc: Exception):
        logging.getLogger("uvicorn.error").exception(
            "Unhandled server error on %s %s", request.method, request.url
        )
        accept = request.headers.get("accept", "")
        if "text/html" in accept or "*/*" in accept:
            return PlainTextResponse("Internal Server Error", status_code=500)
        return JSONResponse(
            status_code=500, content={"detail": "Internal Server Error"}
        )

    # Register RBAC routes
    # rbac_router = rbac_plugin.get_router()
    # app.include_router(rbac_router, tags=["RBAC Management"])
    # frontend_router = create_frontend_router(gen_rbac_async_session)
    # app.include_router(frontend_router)

    # Legacy path support: redirect old admin login path to unified /login.html
    @app.get("/admin/login.html", include_in_schema=False)
    async def legacy_login_redirect():
        return RedirectResponse(url="/login.html")

    # Client-side login helper endpoint to test 401 redirect
    @app.get("/protected-demo", include_in_schema=False)
    async def protected_demo(_: bool = Depends(require_permissions("user:read"))):
        return {"ok": True}

    # Mount static files at application level for template url_for compatibility
    from pathlib import Path

    static_dir = Path(__file__).parent.parent / "fastapi_rbac" / "frontend" / "static"
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Index Page - Demo for permission checking
    @app.get("/index", response_class=HTMLResponse)
    async def index_page(_: bool = Depends(require_login())):
        """Index page with permission demo buttons"""
        html_content = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>RBAC Permission Demo</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>
                body { padding: 20px; background-color: #f8f9fa; }
                .demo-container { max-width: 600px; margin: 0 auto; }
                .btn-demo { margin: 10px; min-width: 200px; }
                .result-box { 
                    margin-top: 20px; 
                    padding: 15px; 
                    border-radius: 5px; 
                    min-height: 100px;
                }
                .success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
                .error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
                .info { background-color: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; }
            </style>
        </head>
        <body>
            <div class="demo-container">
                <div class="text-center mb-4">
                    <h1 class="display-4">🔐 RBAC Permission Demo</h1>
                    <p class="lead">Test permission-based access control functionality</p>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5>Permission Testing</h5>
                    </div>
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <p><strong>Instructions:</strong></p>
                            <p>1. Click "Free Permission" to test an endpoint that doesn't require authentication</p>
                            <p>2. Click "Need 'user:read' Permission" to test an endpoint that requires the 'user:read' permission</p>
                            <p>3. If not logged in, you will be redirected to the login page automatically</p>
                        </div>
                        
                        <div class="mb-3">
                            <button class="btn btn-success btn-demo" onclick="testFreePermission()">
                                🟢 Free Permission
                            </button>
                            <button class="btn btn-warning btn-demo" onclick="testUserReadPermission()">
                                🟡 Need 'user:read' Permission
                            </button>
                        </div>
                        <div class="mb-3">
                            <button class="btn btn-secondary btn-demo" onclick="doLogout()">
                                🚪 Logout
                            </button>
                            <button class="btn btn-info btn-demo" onclick="window.location.href='/api/rbac-frontend/admin'">
                                🔧 Go to Permission Configuration
                            </button>
                        </div>
                        
                        <div class="mb-3">
                            <label for="userId" class="form-label">Simulate User ID:</label>
                            <input type="number" id="userId" class="form-control" value="1" style="max-width: 200px; margin: 0 auto;">
                        </div>
                    </div>
                </div>
                
                <div id="result" class="result-box" style="display: none;"></div>
                
                <div class="mt-4 text-center">
                    <a href="/api/rbac-frontend/admin/" class="btn btn-primary">Go to Admin Dashboard</a>
                    <a href="/docs" class="btn btn-secondary">API Documentation</a>
                </div>
            </div>

            <script>
                function showResult(content, type) {
                    const resultDiv = document.getElementById('result');
                    resultDiv.className = 'result-box ' + type;
                    resultDiv.innerHTML = content;
                    resultDiv.style.display = 'block';
                }

                async function testFreePermission() {
                    try {
                        const response = await fetch('/api/free-permission');
                        const data = await response.json();
                        
                        if (response.ok) {
                            showResult(`
                                <h5>✅ Success!</h5>
                                <p><strong>Status:</strong> ${response.status}</p>
                                <p><strong>Message:</strong> ${data.message}</p>
                                <p><strong>Timestamp:</strong> ${data.timestamp}</p>
                            `, 'success');
                        } else {
                            showResult(`
                                <h5>❌ Error!</h5>
                                <p><strong>Status:</strong> ${response.status}</p>
                                <p><strong>Error:</strong> ${data.detail || data.message}</p>
                            `, 'error');
                        }
                    } catch (error) {
                        showResult(`
                            <h5>❌ Network Error!</h5>
                            <p><strong>Error:</strong> ${error.message}</p>
                        `, 'error');
                    }
                }

                async function testUserReadPermission() {
                    const userId = document.getElementById('userId').value;
                    const headers = {};
                    
                    if (userId) {
                        headers['X-User-ID'] = userId;
                    }
                    
                    try {
                        const response = await fetch('/api/need-user-read-permission');
                        const data = await response.json();
                        
                        if (response.ok) {
                            showResult(`
                                <h5>✅ Success!</h5>
                                <p><strong>Status:</strong> ${response.status}</p>
                                <p><strong>Message:</strong> ${data.message}</p>
                                <p><strong>User ID:</strong> ${data.user_id}</p>
                                <p><strong>Timestamp:</strong> ${data.timestamp}</p>
                            `, 'success');
                        } else {
                            let errorMessage = data.detail || data.message;
                            if (typeof errorMessage === 'object') {
                                errorMessage = errorMessage.message || JSON.stringify(errorMessage);
                            }
                            
                            showResult(`
                                <h5>❌ Permission Denied!</h5>
                                <p><strong>Status:</strong> ${response.status}</p>
                                <p><strong>Error:</strong> ${errorMessage}</p>
                                <p><strong>User ID:</strong> ${userId || 'None'}</p>
                                <p><em>💡 Try changing the User ID to a user that has the 'user:read' permission</em></p>
                            `, 'error');
                        }
                    } catch (error) {
                        showResult(`
                            <h5>❌ Network Error!</h5>
                            <p><strong>Error:</strong> ${error.message}</p>
                        `, 'error');
                    }
                }

                async function doLogout() {
                    try {
                        await fetch('/rbac/users/logout', { method: 'POST' });
                    } catch (_) {}
                    try { sessionStorage.removeItem('rbac_token'); } catch (_) {}
                    window.location.href = '/login.html';
                }
            </script>
        </body>
        </html>
        """
        return HTMLResponse(content=html_content)

    # Demo API endpoints for permission testing
    @app.get("/api/free-permission")
    async def free_permission_endpoint():
        """Free endpoint that doesn't require any permissions"""

        return {
            "message": "This endpoint is free and doesn't require any permissions!",
            "timestamp": datetime.now().isoformat(),
            "status": "success",
        }

    @app.get("/api/need-user-read-permission")
    async def need_user_read_permission_endpoint(
        request: Request,
        db_session: AsyncSession = Depends(gen_rbac_async_session),
        _: bool = Depends(require_permissions("user:read")),
    ):
        """Endpoint that requires 'user:read' permission"""

        # Check if user has permission
        user_id = request.headers.get("X-User-ID")
        if not user_id:
            return {
                "message": "Authentication required. Please provide X-User-ID header.",
                "user_id": None,
                "timestamp": datetime.now().isoformat(),
                "status": "error",
            }

        # if not has_permission:
        #     return {
        #         "message": "Access denied. You don't have the 'user:read' permission.",
        #         "user_id": user_id,
        #         "timestamp": datetime.now().isoformat(),
        #         "status": "error"
        #     }

        # If we get here, user has permission
        return {
            "message": "Access granted! You have the 'user:read' permission.",
            "user_id": user_id,
            "timestamp": datetime.now().isoformat(),
            "status": "success",
        }

    # Root redirect to index page instead of admin dashboard
    @app.get("/")
    async def root():
        """Redirect root URL to index page"""
        from fastapi.responses import RedirectResponse

        return RedirectResponse(url="/index")

    # Health check endpoint
    @app.get("/health")
    async def health_check():
        """Health check endpoint"""
        return {"status": "healthy", "message": "RBAC Management System is running"}

    return app


async def main():
    """Main function to setup and run the application"""
    # from fastapi_rbac.models import create_dynamic_models
    from fastapi_rbac.serializers.password_user_serializer import PasswordUserSerializer

    print("🚀 Starting RBAC Management System...")
    print(f"🔗 Database URL: {database_url}")
    print("=" * 50)

    set_rbac_db_config(database_url, database_params)

    # Create settings with optional custom user model
    # Example: Use ExtendedUser with additional fields
    # settings = Settings(custom_user_model=ExtendedUser)

    rbac_settings = RBACConfig(
        # database_url=database_url,
        # database_params=database_params,
        user_serializer=PasswordUserSerializer,
        need_frontend=True,
        custom_session_maker=gen_rbac_async_session,
    )
    # models_dict = create_dynamic_models(rbac_settings.user_model)

    # Create app with settings first
    app = create_app(rbac_settings)

    # Initialize RBAC permissions/roles via reusable initializer
    engine = create_async_engine(database_url, **database_params)

    # 判断当前库中是否有表，如果有，则跳过数据初始化的步骤
    from sqlalchemy import inspect as sa_inspect

    async def has_any_tables(engine):
        # engine为异步engine
        def _get_tables(connection):
            inspector = sa_inspect(connection)
            return inspector.get_table_names()

        async with engine.begin() as conn:
            return await conn.run_sync(_get_tables)

    existing_tables = await has_any_tables(engine)
    if existing_tables:
        print(
            f"⚠️ Database already initialized with tables: {existing_tables}, skip RBAC data initialization."
        )
    else:
        try:
            await init_rbac(
                engine,
                rbac_settings,
                app,
                seed_sample_data=True,
                reset_schema=True,
            )

        except OperationalError as e:
            print(f"❌ Error initializing RBAC: {e}")
            print(
                "Please check if the database is running and the connection string is correct."
            )
            print(
                "If you are using a MySQL database, make sure the database exists and the user has the necessary permissions."
            )
            return
        except Exception as e:
            print(f"❌ Error initializing RBAC: {e}")
            raise

    # Global 401 -> /login.html redirect for HTML page requests
    from fastapi import HTTPException
    from fastapi.responses import JSONResponse

    @app.exception_handler(HTTPException)
    async def http_exception_to_login(request: Request, exc: HTTPException):
        accept = request.headers.get("accept", "")
        if exc.status_code == 401 and ("text/html" in accept or "*/*" in accept):
            return RedirectResponse(url="/login.html")
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

    print("\n🌐 Starting web server...")
    print("   🏠 Index Page (Permission Demo): http://localhost:8000/index")
    print("   📱 Frontend Dashboard: http://localhost:8000/admin/")
    print("   📚 API Documentation: http://localhost:8000/docs")
    print("   👥 User Management: http://localhost:8000/admin/users")
    print("   🏷️  Role Management: http://localhost:8000/admin/roles")
    print("   🔑 Permission Management: http://localhost:8000/admin/permissions")
    print("\n💡 Frontend Features:")
    print("   • Search and filter users, roles, permissions")
    print("   • View detailed information for each entity")
    print("   • Manage user-role and role-permission assignments")
    print("   • Responsive design for mobile and desktop")
    print("   • Real-time notifications and confirmations")
    print("\n🔧 API Features:")
    print("   • RESTful API endpoints for all operations")
    print("   • Comprehensive search and pagination")
    print("   • Async/await support for high performance")
    print("   • Automatic API documentation")

    print("\n" + "=" * 50)
    print("Press Ctrl+C to stop the server")

    # Configure logging for richer output
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )

    # Run the server with more verbose logging so exceptions include tracebacks
    config = uvicorn.Config(
        app=app, host="0.0.0.0", port=8001, reload=False, log_level="debug"
    )
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    """
    Frontend Management Usage Guide:

    1. Index Page (http://localhost:8000/index):
       - Permission demo with two test buttons
       - "Free Permission" button: Tests endpoint without permission requirements
       - "Need 'user:read' Permission" button: Tests endpoint requiring 'user:read' permission
       - Simulate different users by changing the User ID
       - Demonstrates permission checking functionality

    2. Dashboard (http://localhost:8000/admin/):
       - View system statistics and overview
       - Quick access to all management sections
       - System status and information

    3. User Management (http://localhost:8000/admin/users):
       - Browse all users with pagination
       - Search users by name, email, or username
       - View user details and assigned roles
       - Manage user status (active/inactive/locked)

    4. Role Management (http://localhost:8000/admin/roles):
       - Browse all roles with user counts
       - Search roles by name or description
       - View role details and assigned users
       - Distinguish between system and custom roles

    5. Permission Management (http://localhost:8000/admin/permissions):
       - Browse all permissions with role assignments
       - Filter by permission type and resource
       - View permission details and assigned roles
       - Manage permission-role relationships

    6. Interactive Features:
       - Bulk selection and operations
       - Modal confirmations for destructive actions
       - Real-time search and filtering
       - Responsive mobile-friendly design
       - Toast notifications for user feedback

    Sample Accounts for Permission Testing:
    - admin (User ID: 1): System administrator with full access including 'user:read'
    - john_doe (User ID: 2): User manager with user/role management permissions including 'user:read'
    - jane_smith (User ID: 3): Editor with basic read/write permissions including 'user:read'
    - bob_wilson (User ID: 4): Viewer with read-only access (inactive)
    - alice_brown (User ID: 5): Viewer with read-only access (locked)

    Permission Demo Instructions:
    1. Visit http://localhost:8000/index
    2. Click "Free Permission" to test unrestricted access
    3. Click "Need 'user:read' Permission" with different User IDs:
       - User ID 1, 2, 3: Should succeed (have 'user:read' permission)
       - User ID 4, 5: Should fail (no 'user:read' permission)
       - No User ID: Should fail (authentication required)
    """
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Server stopped by user")
    except Exception as e:
        print(f"\n❌ Error starting server: {e}")
        raise
