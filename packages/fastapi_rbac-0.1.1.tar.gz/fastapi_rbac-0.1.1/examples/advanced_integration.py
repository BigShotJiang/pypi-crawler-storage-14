#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:40:32
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""

import os
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlmodel import SQLModel

# Import RBAC plugin
from fastapi_rbac.plugin import RBACPlugin
from fastapi_rbac.config import RBACConfig


class RBACMiddleware:
    """RBAC permission middleware"""

    def __init__(self, rbac_plugin: RBACPlugin):
        self.rbac_plugin = rbac_plugin

    async def get_current_user_id(self, request: Request) -> Optional[int]:
        """
        Get current user ID from request

        In actual application, here should parse JWT token or verify session
        """
        # Simulate getting user ID from Header
        user_id = request.headers.get("X-User-ID")
        if user_id:
            try:
                return int(user_id)
            except ValueError:
                return None
        return None

    async def check_permission(
        self, request: Request, required_roles: list[str], db_session: AsyncSession
    ) -> bool:
        """Check user permissions"""
        user_id = await self.get_current_user_id(request)
        if not user_id:
            return False

        # Get user roles
        user_serializer = self.rbac_plugin.get_user_serializer(db_session)
        user_roles = await user_serializer.get_user_roles(user_id)

        # Check if user has required roles
        user_role_names = {role.name for role in user_roles}
        return any(role in user_role_names for role in required_roles)


# Environment configuration
class Settings:
    """Application configuration"""

    def __init__(self):
        self.database_url = os.getenv(
            "RBAC_DATABASE_URL",
            "mysql+aiomysql://root:password@localhost:3306/advanced_rbac",
        )
        self.debug = os.getenv("DEBUG", "false").lower() == "true"
        self.cors_origins = os.getenv("CORS_ORIGINS", "*").split(",")
        self.trusted_hosts = os.getenv("TRUSTED_HOSTS", "*").split(",")


settings = Settings()


# Create FastAPI application
app = FastAPI(
    title="Advanced RBAC integration example",
    description="Show how to integrate RBAC plugin in complex projects, including custom configuration, permission middleware, etc.",
    version="2.0.0",
    debug=settings.debug,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add trusted host middleware
app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.trusted_hosts)

# Database configuration
engine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    pool_size=20,
    max_overflow=0,
    pool_pre_ping=True,
    pool_recycle=3600,
)

SessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def get_db_session():
    """Database session dependency"""
    async with SessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


# Custom RBAC configuration
rbac_config = RBACConfig(
    table_prefix="enterprise_rbac_",
    enable_soft_delete=True,
    cache_ttl=600,  # 10 minutes cache
    default_page_size=30,
    max_page_size=200,
)

# Initialize RBAC plugin
rbac_plugin = RBACPlugin(rbac_config)
rbac_middleware = RBACMiddleware(rbac_plugin)

# Register RBAC routes (add prefix and tags)
rbac_router = rbac_plugin.get_router()
app.include_router(rbac_router, prefix="/api/v2/rbac", tags=["RBAC management"])


# Permission dependency factory
def require_roles(*roles: str):
    """Create permission check dependency"""

    async def permission_dependency(
        request: Request, db_session: AsyncSession = Depends(get_db_session)
    ):
        has_permission = await rbac_middleware.check_permission(
            request, list(roles), db_session
        )
        if not has_permission:
            raise HTTPException(
                status_code=403,
                detail="Permission denied, need one of the following roles: "
                + ", ".join(roles),
            )
        return True

    return permission_dependency


# Get current user dependency
async def get_current_user(
    request: Request, db_session: AsyncSession = Depends(get_db_session)
):
    """Get current user information"""
    user_id = await rbac_middleware.get_current_user_id(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Not logged in")

    user_serializer = rbac_plugin.get_user_serializer(db_session)
    user = await user_serializer.get_user(user_id, include_roles=True)

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user


# Business interface example


@app.get("/api/v2/admin/dashboard")
async def admin_dashboard(
    _: bool = Depends(require_roles("Admin")), current_user=Depends(get_current_user)
):
    """Admin dashboard - need admin permission"""
    return {
        "message": "Welcome to admin dashboard",
        "user": current_user.name,
        "features": [
            "User management",
            "Role management",
            "Permission configuration",
            "System monitoring",
        ],
    }


@app.get("/api/v2/editor/content")
async def content_management(
    _: bool = Depends(require_roles("Admin", "Editor")),
    current_user=Depends(get_current_user),
):
    """Content management - need admin or editor permission"""
    return {
        "message": "Content management interface",
        "user": current_user.name,
        "permissions": ["Create content", "Edit content", "Publish content"],
    }


@app.get("/api/v2/user/profile")
async def user_profile(current_user=Depends(get_current_user)):
    """User profile - need login"""
    return {
        "message": "User profile",
        "user": current_user,
        "last_login": current_user.last_login,
    }


@app.post("/api/v2/admin/sync-users")
async def sync_users_from_sso(
    _: bool = Depends(require_roles("Admin")),
    db_session: AsyncSession = Depends(get_db_session),
):
    """
    Sync users from SSO system
    Admin-only feature
    """
    # Simulate syncing users from external SSO system
    user_serializer = rbac_plugin.get_user_serializer(db_session)

    # Simulate SSO user data
    sso_users = [
        {
            "name": "New User 1",
            "en_name": "New User 1",
            "email": "newuser1@company.com",
            "mobile": "13800000001",
            "user_id": "sso_001",
        },
        {
            "name": "New User 2",
            "en_name": "New User 2",
            "email": "newuser2@company.com",
            "mobile": "13800000002",
            "user_id": "sso_002",
        },
    ]

    # Sync user data
    synced_count = 0
    for sso_user in sso_users:
        # Check if user already exists
        existing_users = await user_serializer.search_users(
            query=sso_user["user_id"], limit=1
        )

        if not existing_users:
            # Create new user

            # User = get_user_model()
            # user_data = User(**sso_user)
            # Here should call internal create method, but in this example we directly create
            synced_count += 1

    return {
        "message": f"Successfully synced {synced_count} users",
        "total_sso_users": len(sso_users),
    }


# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    """Application startup event"""
    print("🚀 Starting advanced RBAC application...")

    # Create database tables
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

    # Initialize default data
    async with SessionLocal() as session:
        await rbac_plugin.initialize_default_data(session)

    print("✅ Application started")


@app.on_event("shutdown")
async def shutdown_event():
    """Application shutdown event"""
    print("🔄 Shutting down application...")
    await engine.dispose()
    print("✅ Application shutdown")


# Health check (with permission verification)
@app.get("/health")
async def health_check():
    """Public health check"""
    return {"status": "healthy", "version": "2.0.0"}


@app.get("/api/v2/admin/health")
async def admin_health_check(_: bool = Depends(require_roles("Admin"))):
    """Admin-only detailed health check"""
    return {
        "status": "healthy",
        "version": "2.0.0",
        "database": "connected",
        "rbac_plugin": "active",
        "cache_status": "enabled",
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "advanced_integration:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        workers=1 if settings.debug else 4,
    )
