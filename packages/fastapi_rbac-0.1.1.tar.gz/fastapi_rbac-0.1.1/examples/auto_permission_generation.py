#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Auto Permission Generation Example

This example demonstrates how to use the auto_generate_permissions_from_app function
from fastapi_rbac.plugin to automatically extract and insert permissions used in routes.

Usage:
    uv run python examples/auto_permission_generation.py
"""
import os
import asyncio
from fastapi import FastAPI, Depends
from fastapi_rbac.config import RBACConfig, register_rbac_config
from fastapi_rbac.config import get_rbac_async_session
from fastapi_rbac.dependencies.permission_dependencies import require_permissions
from fastapi_rbac.plugin import RBACPlugin, auto_generate_permissions_from_app
from sqlmodel import SQLModel
from dotenv import load_dotenv

if os.path.exists(os.path.join(os.path.dirname(__file__), ".env")):
    load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

# Database config (use SQLite for demo)
DATABASE_URL = os.getenv(
    "RBAC_DATABASE_URL",
    "mysql+aiomysql://root:root@localhost:3306/siduri-example",
)


# Create FastAPI app
def create_app() -> FastAPI:
    from fastapi_rbac.serializers.password_user_serializer import PasswordUserSerializer

    app = FastAPI(title="Auto Permission Generation Demo")

    rbac_config = RBACConfig(
        cache_ttl=300,  # 5 minutes cache
        database_url=DATABASE_URL,
        database_params={
            "echo": True,
            "future": True,
            "pool_recycle": 60 * 5,
            "pool_pre_ping": True,
            "pool_size": 10,
            "max_overflow": 20,
        },
        user_serializer=PasswordUserSerializer,
    )
    register_rbac_config(app, rbac_config)

    rbac_plugin = RBACPlugin(rbac_config)

    # Register RBAC routes
    rbac_router = rbac_plugin.get_router()
    app.include_router(rbac_router, tags=["RBAC Management"])

    @app.get("/public")
    async def public_endpoint():
        return {"message": "No permission required"}

    @app.get("/user-read")
    async def user_read_endpoint(
        _: bool = Depends(require_permissions("user:read:test-auto-permission")),
    ):
        return {"message": "You have user:read permission"}

    @app.get("/user-write")
    async def user_write_endpoint(
        _: bool = Depends(require_permissions("user:write:test-auto-permission")),
    ):
        return {"message": "You have user:write permission"}

    @app.get("/admin-access")
    async def admin_access_endpoint(
        _: bool = Depends(require_permissions("admin:access:test-auto-permission")),
    ):
        return {"message": "You have admin:access permission"}

    return app


async def main():
    print("\n=== Auto Permission Generation Demo ===\n")
    # 1. 创建表
    async_session = get_rbac_async_session()
    async with async_session() as session:
        await session.run_sync(SQLModel.metadata.create_all)
    print("[main] Database tables created.")

    # 2. 创建 app
    app = create_app()

    # 3. 自动生成权限
    async with async_session() as session:
        await auto_generate_permissions_from_app(app, session)

    print("[main] Permission auto-generation complete.")
    print("You can now inspect the database for generated permissions.")


if __name__ == "__main__":
    asyncio.run(main())
