#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.net
@Create Time: 2025-01-27 10:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: GitHub OAuth集成示例应用
All Rights Reserved.
"""

from contextlib import asynccontextmanager
import os
from fastapi import Depends, FastAPI, HTTPException, Request, Query, Response
from fastapi.responses import RedirectResponse
from sqlmodel.ext.asyncio.session import AsyncSession
from fastapi_rbac.config import RBACConfig, gen_rbac_async_session, set_rbac_db_config
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel import SQLModel
from fastapi_rbac.serializers.github_user_serializer import GitHubUserSerializer
from fastapi_rbac.external_auth.clients.github_client import GitHubOAuthClient

from fastapi_rbac.dependencies.login_dependencies import require_external_login
from fastapi_rbac.plugin import RBACPlugin

# 数据库配置
database_url = os.getenv(
    "RBAC_DATABASE_URL",
    "mysql+aiomysql://root:zxjzxj233@localhost:3306/sso-example",
)

database_params = {
    "echo": False,
    "future": True,
    "pool_recycle": 60 * 5,
    "pool_pre_ping": True,
    "pool_size": 10,
    "max_overflow": 20,
}
set_rbac_db_config(database_url, database_params)


# GitHub OAuth配置
github_client_id = os.getenv("GITHUB_CLIENT_ID")
github_client_secret = os.getenv("GITHUB_CLIENT_SECRET")
github_redirect_uri = os.getenv("GITHUB_REDIRECT_URI")
if not all([github_client_id, github_client_secret, github_redirect_uri]):
    raise ValueError(
        "GITHUB_CLIENT_ID, GITHUB_CLIENT_SECRET, and GITHUB_REDIRECT_URI must be set"
    )

# RBAC配置
rbac_settings = RBACConfig(
    user_serializer=GitHubUserSerializer,
    enable_external_auth=True,
    external_auth_clients={
        "github": GitHubOAuthClient,
    },
    custom_session_maker=gen_rbac_async_session,
)

# 创建数据库引擎
engine = create_async_engine(
    database_url,
    **database_params,
)

# GitHub OAuth客户端实例
github_client = GitHubOAuthClient(rbac_settings)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.drop_all)
        await conn.run_sync(SQLModel.metadata.create_all)
    yield
    await engine.dispose()


# 创建FastAPI应用
app = FastAPI(
    title="GitHub OAuth集成示例",
    description="基于FastAPI-RBAC的GitHub OAuth登录示例",
    version="1.0.0",
    lifespan=lifespan,
)

# 初始化RBAC插件
RBACPlugin(app, rbac_settings)


@app.get("/")
async def read_root():
    """根路径，提供登录链接"""
    return {
        "message": "欢迎使用GitHub OAuth登录示例",
        "login_url": "/auth/github",
        "protected_url": "/protected",
    }


@app.get("/auth/github")
async def github_login(
    state: str = Query(None, description="状态参数，用于防止CSRF攻击")
):
    """
    发起GitHub OAuth登录

    Args:
        state: 状态参数，用于防止CSRF攻击

    Returns:
        RedirectResponse: 重定向到GitHub授权页面
    """
    try:
        # 生成授权URL
        auth_url = github_client.get_authorization_url(state)

        return RedirectResponse(url=auth_url)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"GitHub登录初始化失败: {str(e)}")


@app.get("/auth/github/callback")
async def github_callback(
    code: str = Query(..., description="GitHub授权码"),
    state: str = Query(None, description="状态参数"),
    error: str = Query(None, description="错误信息"),
):
    """
    GitHub OAuth回调处理

    Args:
        code: GitHub授权码
        state: 状态参数
        error: 错误信息

    Returns:
        dict: 登录结果
    """
    try:
        if error:
            raise HTTPException(status_code=400, detail=f"GitHub授权失败: {error}")

        if not code:
            raise HTTPException(status_code=400, detail="缺少授权码")

        # 交换访问令牌
        token_data = await github_client.exchange_code_for_token(code)
        access_token = token_data.get("access_token")

        if not access_token:
            raise HTTPException(status_code=400, detail="获取访问令牌失败")

        return RedirectResponse(
            url=f"/protected?auth_type=github&auth_token={access_token}",
            headers={
                "Content-Type": "application/json",
                "X-Auth-Type": "github",
                "X-Auth-Token": access_token,
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"GitHub登录处理失败: {str(e)}")


@app.get("/protected")
async def protected_endpoint(
    request: Request,
    db_session: AsyncSession = Depends(gen_rbac_async_session),
    _: bool = Depends(require_external_login()),
):
    """
    受保护的端点，需要GitHub OAuth认证

    Returns:
        dict: 受保护的内容
    """
    user_id = request.state.user_id
    github_user = await GitHubUserSerializer(db_session).get_user(user_id)
    
    if not github_user:
        raise HTTPException(status_code=404, detail="User not found")

    return {
        "message": "恭喜！您已成功通过GitHub OAuth认证",
        "status": "authenticated",
        "provider": "github",
        "user": github_user.model_dump(),
    }


@app.get("/user/info")
async def get_user_info(_: bool = Depends(require_external_login())):
    """
    获取当前用户信息

    Returns:
        dict: 用户信息
    """
    # 这里需要从请求中获取用户信息
    # 实际实现中，用户信息会通过中间件注入到请求中
    return {"message": "用户信息端点", "note": "用户信息需要通过中间件获取"}


@app.get("/health")
async def health_check():
    """
    健康检查端点

    Returns:
        dict: 健康状态
    """
    github_health = await github_client.health_check()

    return {
        "status": "healthy",
        "services": {"github_api": "healthy" if github_health else "unhealthy"},
    }


if __name__ == "__main__":
    import uvicorn

    print("启动GitHub OAuth示例应用...")
    print("请确保已配置以下环境变量:")
    print("- GITHUB_CLIENT_ID: GitHub OAuth应用客户端ID")
    print("- GITHUB_CLIENT_SECRET: GitHub OAuth应用客户端密钥")
    print("- GITHUB_REDIRECT_URI: GitHub OAuth回调URL")
    print("- RBAC_DATABASE_URL: 数据库连接URL")

    uvicorn.run("github_main:app", host="0.0.0.0", port=8000, reload=True)
