#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Initialize/Update RBAC permissions (auto-discovered) and super_admin role

Usage:
    uv run python examples/init_rbac_data.py

This script will:
  - Analyze project routes to dynamically discover permissions used by `require_permissions`
  - Upsert (create missing) permissions into the database
  - Ensure a `super_admin` role exists and grant all discovered permissions to it
  - Ensure a default admin user exists and bind it to `super_admin`
"""

import os
import sys
from typing import Optional, Set, List, Type, Dict
import logging

from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from fastapi_rbac.schemas.permission_schemas import RolePermissionAssignment

# Ensure project root is on sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi_rbac.config import RBACConfig
from fastapi_rbac.models import create_dynamic_models, Role
from fastapi_rbac.serializers import (
    UserSerializer,
    RoleSerializer,
    PermissionSerializer,
)
from fastapi_rbac.schemas import (
    RoleCreate,
    PermissionCreate,
    PermissionRoleAssignment,
    UserRoleAssignment,
)
from fastapi_rbac.models import get_user_model
from fastapi import FastAPI
from fastapi.params import Depends
from fastapi.routing import APIRoute
import inspect

logger = logging.getLogger(__name__)


async def init_engine(database_url: Optional[str] = None, database_params: dict = {}):
    engine = create_async_engine(
        database_url,
        **database_params,
    )
    return engine


async def ensure_tables(engine, user_model: Type[SQLModel]) -> None:
    # Ensure dynamic models are registered
    create_dynamic_models(user_model)
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

        # Backward compatibility: ensure missing columns exist (e.g., password on t_users)
        def _get_columns(connection, table_name: str):
            from sqlalchemy import inspect

            inspector = inspect(connection)
            return [col["name"] for col in inspector.get_columns(table_name)]

        try:
            user_columns = await conn.run_sync(lambda c: _get_columns(c, "t_users"))
            if "password" not in user_columns:
                await conn.exec_driver_sql(
                    "ALTER TABLE t_users ADD COLUMN password VARCHAR(255) NULL"
                )
        except Exception:
            # Ignore if inspection fails; table may not exist yet on first run
            pass


def extract_permission_codes_from_app(app: FastAPI) -> Set[str]:
    """Extract permission codes from routes that depend on require_permissions."""
    permission_codes: Set[str] = set()
    for route in app.routes:
        if not isinstance(route, APIRoute):
            continue
        endpoint = route.endpoint
        sig = inspect.signature(endpoint)
        for param in sig.parameters.values():
            default = param.default
            if isinstance(default, Depends):
                dep = default.dependency
                if hasattr(dep, "__name__") and dep.__name__ == "permission_dependency":  # type: ignore
                    closure = getattr(dep, "__closure__", None)  # type: ignore
                    if closure:
                        for cell in closure:
                            value = cell.cell_contents
                            if isinstance(value, tuple) and all(
                                isinstance(x, str) for x in value
                            ):
                                for code in value:
                                    permission_codes.add(code)
    return permission_codes


def build_permission_payload(code: str) -> PermissionCreate:
    """Build a PermissionCreate payload from a permission code."""
    if ":" in code:
        resource, action = code.split(":", 1)
    else:
        resource, action = code, "access"
    return PermissionCreate(
        code=code,
        name=code,
        description=f"Auto-discovered permission for {code}",
        resource=resource,
        action=action,
        permission_type="function",
        is_active=True,
        is_system=False,
    )


async def init_rbac(
    engine,
    rbac_settings: RBACConfig,
    app: FastAPI = None,
    session: Optional[AsyncSession] = None,
    *,
    seed_sample_data: bool = False,
    reset_schema: bool = False,
) -> None:
    if engine is None and session is None:
        raise ValueError("Either engine or session must be provided.")

    own_engine = engine
    own_session = False

    try:
        if session is None:
            if own_engine is None:
                raise ValueError("Engine is required when session is not provided.")
            if reset_schema:
                await reset_rbac_schema(own_engine)
            await ensure_tables(own_engine, rbac_settings.user_serializer.user_model)
            SessionLocal = async_sessionmaker(
                own_engine, class_=AsyncSession, expire_on_commit=False
            )
            session = SessionLocal()  # type: ignore[assignment]
            own_session = True
        else:
            bind = session.get_bind()
            bound_engine = getattr(bind, "engine", None)
            if bound_engine is None:
                raise RuntimeError("Provided session is not bound to an engine.")
            if reset_schema:
                raise ValueError(
                    "reset_schema=True is only supported when init_rbac manages the session."
                )
            await ensure_tables(bound_engine, rbac_settings.user_serializer.user_model)

        user_s = UserSerializer(session)
        role_s = RoleSerializer(session)
        perm_s = PermissionSerializer(session)

        discovered_codes: Set[str] = set()
        if app is not None:
            discovered_codes = extract_permission_codes_from_app(app)

        created_permission_ids: List[int] = []
        for code in sorted(discovered_codes):
            existing = await perm_s._get_permission_by_code(code)
            if existing:
                created_permission_ids.append(existing.id)
                continue
            payload = build_permission_payload(code)
            created = await perm_s.create_permission(payload)
            created_permission_ids.append(created.id)

        from sqlmodel import select

        result = await session.exec(select(Role).where(Role.name == "super_admin"))
        super_role = result.first()
        if not super_role:
            super_role = await role_s.create_role(
                RoleCreate(
                    name="super_admin",
                    description="Super administrator",
                    is_system=True,
                    is_active=True,
                )
            )

        if created_permission_ids:
            await role_s.assign_permissions(
                super_role.id,
                PermissionRoleAssignment(
                    permission_ids=created_permission_ids,
                    assigned_by=0,
                    expires_at=None,
                ),
            )

        User = rbac_settings.user_serializer.user_model
        result = await session.exec(
            select(User).where(User.email == "admin@example.com")
        )
        admin = result.first()
        if not admin:
            ModelUser = get_user_model()
            admin = await user_s.create_user(
                ModelUser(
                    name="admin",
                    en_name="Admin",
                    email="admin@example.com",
                    mobile="00000000000",
                    user_id="ADMIN",
                    status=1,
                    locked=0,
                    password="y6ZreZqlZeBeIl",
                )
            )

        await role_s.assign_users(
            super_role.id,
            UserRoleAssignment(
                user_ids=[admin.id],
                assigned_by=0,
                expires_at=None,
            ),
        )

        if seed_sample_data:
            await seed_sample_data_records(session, user_s, role_s, perm_s)

        await session.commit()
        if seed_sample_data:
            print(
                "Initialized permissions, super_admin role, admin user, and sample data."
            )
        else:
            print("Initialized permissions, super_admin role, and admin user.")
    except Exception:
        if session is not None:
            await session.rollback()
        raise
    finally:
        if own_session and session is not None:
            await session.close()
        if own_engine is not None:
            await own_engine.dispose()


async def reset_rbac_schema(engine) -> None:
    """Drop all RBAC tables and recreate them using the latest metadata."""
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.drop_all)
        from fastapi_rbac.models import get_rbac_metadata

        rbac_metadata = get_rbac_metadata()
        await conn.run_sync(rbac_metadata.create_all)


async def seed_sample_data_records(
    session: AsyncSession,
    user_serializer: UserSerializer,
    role_serializer: RoleSerializer,
    permission_serializer: PermissionSerializer,
) -> None:
    """Populate the database with demonstration permissions, roles, and users."""
    print("Creating sample data...")

    permissions_data = [
        {
            "code": "user:read",
            "name": "Read Users",
            "description": "View user information",
            "resource": "user",
            "action": "read",
        },
        {
            "code": "user:write",
            "name": "Write Users",
            "description": "Create and update users",
            "resource": "user",
            "action": "write",
        },
        {
            "code": "user:delete",
            "name": "Delete Users",
            "description": "Delete user accounts",
            "resource": "user",
            "action": "delete",
        },
        {
            "code": "role:read",
            "name": "Read Roles",
            "description": "View role information",
            "resource": "role",
            "action": "read",
        },
        {
            "code": "role:write",
            "name": "Write Roles",
            "description": "Create and update roles",
            "resource": "role",
            "action": "write",
        },
        {
            "code": "role:delete",
            "name": "Delete Roles",
            "description": "Delete roles",
            "resource": "role",
            "action": "delete",
        },
        {
            "code": "permission:read",
            "name": "Read Permissions",
            "description": "View permissions",
            "resource": "permission",
            "action": "read",
        },
        {
            "code": "permission:write",
            "name": "Write Permissions",
            "description": "Create and update permissions",
            "resource": "permission",
            "action": "write",
        },
        {
            "code": "admin:full_access",
            "name": "Full Admin Access",
            "description": "Complete system administration",
            "resource": "system",
            "action": "admin",
            "is_system": True,
        },
    ]

    created_permissions = []
    for perm_data in permissions_data:
        perm_data_ins = PermissionCreate(**perm_data)
        existing_perm = await permission_serializer._get_permission_by_code(
            perm_data["code"]
        )
        if not existing_perm:
            permission = await permission_serializer.create_permission(perm_data_ins)
            created_permissions.append(permission)
            print(f"✓ Created permission: {permission.code}")
        else:
            created_permissions.append(existing_perm)
            print(f"- Permission already exists: {existing_perm.code}")

    permission_lookup: Dict[str, int] = {
        perm.code: perm.id for perm in created_permissions
    }

    roles_data = [
        {
            "name": "Administrator",
            "description": "System administrator with full access",
            "is_system": True,
        },
        {
            "name": "User Manager",
            "description": "Manages user accounts and roles",
        },
        {
            "name": "Viewer",
            "description": "Read-only access to system information",
        },
        {"name": "Editor", "description": "Can create and edit content"},
    ]

    created_roles = []
    for role_data in roles_data:
        role_data_ins = RoleCreate(**role_data)
        existing_role = await role_serializer._get_role_by_name(role_data["name"])
        if not existing_role:
            role = await role_serializer.create_role(role_data_ins)
            created_roles.append(role)
            print(f"✓ Created role: {role.name}")
        else:
            created_roles.append(existing_role)
            print(f"- Role already exists: {existing_role.name}")

    role_lookup: Dict[str, int] = {role.name: role.id for role in created_roles}

    role_permission_mapping = {
        "Administrator": ["admin:full_access"],
        "User Manager": [
            "user:read",
            "user:write",
            "user:delete",
            "role:read",
            "role:write",
        ],
        "Viewer": ["user:read", "role:read", "permission:read"],
        "Editor": ["user:read", "user:write", "role:read"],
    }

    for role_name, permission_codes in role_permission_mapping.items():
        role_id = role_lookup.get(role_name)
        if role_id is None:
            continue
        for perm_code in permission_codes:
            permission_id = permission_lookup.get(perm_code)
            if permission_id is None:
                continue
            try:
                assignment_data = RolePermissionAssignment(
                    role_ids=[role_id],
                    assigned_by=1,
                    expires_at=None,
                )
                await permission_serializer.assign_roles(permission_id, assignment_data)
                print(f"✓ Assigned {perm_code} to {role_name}")
            except Exception as e:
                if "already" in str(e).lower():
                    print(f"- Permission {perm_code} already assigned to {role_name}")
                else:
                    print(
                        f"⚠ Warning: Could not assign {perm_code} to {role_name}: {e}"
                    )

    users_data = [
        {
            "name": "admin",
            "en_name": "Admin User",
            "email": "admin@example.com",
            "password": "y6ZreZqlZeBeIl",
            "mobile": "13800138000",
            "user_id": "ADMIN001",
            "status": 1,
            "locked": 0,
        },
        {
            "name": "john_doe",
            "en_name": "John Doe",
            "email": "john.doe@example.com",
            "password": "y6ZreZqlZeBeIl",
            "mobile": "13800138001",
            "user_id": "USER001",
            "status": 1,
            "locked": 0,
        },
        {
            "name": "jane_smith",
            "en_name": "Jane Smith",
            "email": "jane.smith@example.com",
            "password": "y6ZreZqlZeBeIl",
            "mobile": "13800138002",
            "user_id": "USER002",
            "status": 1,
            "locked": 0,
        },
        {
            "name": "bob_wilson",
            "en_name": "Bob Wilson",
            "email": "bob.wilson@example.com",
            "password": "y6ZreZqlZeBeIl",
            "mobile": "13800138003",
            "user_id": "USER003",
            "status": 0,
            "locked": 0,
        },
        {
            "name": "alice_brown",
            "en_name": "Alice Brown",
            "email": "alice.brown@example.com",
            "password": "y6ZreZqlZeBeIl",
            "mobile": "13800138004",
            "user_id": "USER004",
            "status": 1,
            "locked": 1,
        },
    ]

    created_users = []
    ModelUser = get_user_model()
    for user_data in users_data:
        user_data_ins = ModelUser(**user_data)
        existing_user = None
        try:
            existing_users = await user_serializer.search_users(  # type: ignore[attr-defined]
                user_data["name"], limit=1
            )
            if existing_users:
                existing_user = existing_users[0]
        except Exception as e:
            logger.error(f"Failed to search users: {e}")

        if not existing_user:
            user = await user_serializer.create_user(user_data_ins)  # type: ignore[attr-defined]
            created_users.append(user)
            print(f"✓ Created user: {user.name}")
        else:
            created_users.append(existing_user)
            print(f"- User already exists: {existing_user.name}")

    user_lookup: Dict[str, int] = {user.name: user.id for user in created_users}

    user_role_mapping = {
        "admin": ["Administrator"],
        "john_doe": ["User Manager"],
        "jane_smith": ["Editor"],
        "bob_wilson": ["Viewer"],
        "alice_brown": ["Viewer"],
    }

    for username, role_names in user_role_mapping.items():
        user_id = user_lookup.get(username)
        if user_id is None:
            continue
        for role_name in role_names:
            role_id = role_lookup.get(role_name)
            if role_id is None:
                continue
            try:
                assignment_data = UserRoleAssignment(
                    user_ids=[user_id],
                    assigned_by=1,
                    expires_at=None,
                )
                await role_serializer.assign_users(role_id, assignment_data)
                print(f"✓ Assigned {role_name} to {username}")
            except Exception as e:
                if "already" in str(e).lower() or "exists" in str(e).lower():
                    print(f"- Role {role_name} already assigned to {username}")
                else:
                    print(f"⚠ Warning: Could not assign {role_name} to {username}: {e}")

    print("\n📊 Summary:")
    print(f"   • {len(created_permissions)} permissions")
    print(f"   • {len(created_roles)} roles")
    print(f"   • {len(created_users)} users")
    print("\n🎉 Sample data created successfully!")


async def create_sample_data(engine, rbac_settings: RBACConfig, app: FastAPI = None):
    """Backward-compatible wrapper that seeds the database with demo data."""
    await init_rbac(
        engine,
        rbac_settings,
        app=app,
        seed_sample_data=True,
        reset_schema=True,
    )
