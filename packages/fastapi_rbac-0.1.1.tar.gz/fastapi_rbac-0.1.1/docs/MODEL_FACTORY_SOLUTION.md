# RBAC 模型工厂解决方案

## 问题描述

在原始的 RBAC 实现中，序列化器和路由器直接导入 `User` 模型：

```python
from ..models import User, Role, Permission
```

这导致了以下问题：

1. **动态模型冲突**: `User` 模型是通过 `create_dynamic_models()` 动态创建的，在运行时才会确定具体的类
2. **SQLAlchemy 错误**: 当执行 `select(User)` 时，SQLAlchemy 无法正确处理这个动态类，抛出错误：

   ```
   Column expression, FROM clause, or other columns clause element expected, got <class 'fastapi_rbac.models.base_user_model.BaseUser'>
   ```

## 解决方案设计

### 1. 模型工厂模块 (`fastapi_rbac/models/model_factory.py`)

创建了一个统一的模型工厂模块，提供以下功能：

- **动态模型获取**: 在运行时获取当前配置的模型类
- **类型安全**: 提供类型提示和错误处理
- **向后兼容**: 保持现有 API 的兼容性

#### 核心类：`ModelFactory`

```python
class ModelFactory:
    @staticmethod
    def get_user_model() -> Type[SQLModel]:
        """获取当前 User 模型"""
        models = get_current_models()
        user_model = models.get("User")
        if not user_model:
            raise RuntimeError("User model is not available. Make sure RBAC is properly initialized.")
        return user_model
    
    # 其他模型获取方法...
```

#### 便利函数

```python
def get_user_model() -> Type[SQLModel]:
    """获取当前 User 模型"""
    return ModelFactory.get_user_model()

def get_role_model() -> Type[SQLModel]:
    """获取 Role 模型"""
    return ModelFactory.get_role_model()
```

### 2. 序列化器更新

将所有序列化器中的直接 `User` 导入替换为动态获取：

#### 修改前

```python
from ..models import User, Role, Permission

class RoleSerializer:
    async def get_role_users(self, role_id: int) -> List[User]:
        statement = select(User).where(User.id == user_id)
        # ...
```

#### 修改后

```python
from ..models import Role, Permission, get_user_model

class RoleSerializer:
    async def get_role_users(self, role_id: int) -> List[Any]:
        User = get_user_model()
        statement = select(User).where(User.id == user_id)
        # ...
```

### 3. 类定义更新

对于序列化器类定义，需要更新泛型类型参数：

#### 修改前

```python
class UserSerializer(BaseSerializer[User, BaseModel, BaseModel]):
    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session, User)
```

#### 修改后

```python
class UserSerializer(BaseSerializer[Any, BaseModel, BaseModel]):
    def __init__(self, db_session: AsyncSession):
        User = get_user_model()
        super().__init__(db_session, User)
```

### 4. 路由器更新

同样更新路由器中的模型使用：

```python
from ..models import get_user_model

@router.post("/login")
async def login(payload: LoginRequest, db_session: AsyncSession):
    User = get_user_model()
    result = await db_session.exec(select(User).where(User.email == payload.email))
    # ...
```

## 使用方法

### 1. 在序列化器中使用

```python
from fastapi_rbac.models import get_user_model, get_role_model

class MySerializer:
    async def some_method(self):
        # 动态获取模型
        User = get_user_model()
        Role = get_role_model()
        
        # 使用模型进行查询
        statement = select(User).join(Role, User.role_id == Role.id)
        # ...
```

### 2. 在路由器中使用

```python
from fastapi_rbac.models import get_user_model

@router.get("/users/{user_id}")
async def get_user(user_id: int):
    User = get_user_model()
    # 使用动态获取的模型
    # ...
```

### 3. 错误处理

```python
try:
    User = get_user_model()
except RuntimeError as e:
    # 处理模型未初始化的情况
    logger.error(f"User model not available: {e}")
    raise HTTPException(status_code=500, detail="System not properly initialized")
```

## 优势

1. **解决动态模型问题**: 完全避免了 SQLAlchemy 的类型错误
2. **保持灵活性**: 支持运行时配置不同的用户模型
3. **类型安全**: 提供完整的类型提示和错误处理
4. **向后兼容**: 不影响现有的配置和初始化流程
5. **统一接口**: 所有模型访问都通过同一个工厂接口

## 注意事项

1. **初始化顺序**: 确保在使用模型工厂之前已经调用了 `create_dynamic_models()`
2. **错误处理**: 模型工厂会在模型不可用时抛出 `RuntimeError`
3. **性能**: 每次调用都会查询模型注册表，但开销很小
4. **类型注解**: 返回类型使用 `Any` 来避免类型检查问题

## 测试

运行测试脚本来验证解决方案：

```bash
python test_model_factory.py
```

## 总结

这个解决方案通过引入模型工厂模式，优雅地解决了动态模型导入的问题，同时保持了系统的灵活性和类型安全性。所有使用 `User` 模型的地方现在都可以正确地获取到运行时配置的模型类，避免了 SQLAlchemy 的类型错误。

## 修改的文件

1. `fastapi_rbac/models/model_factory.py` - 新建的模型工厂模块
2. `fastapi_rbac/models/__init__.py` - 导出新的工厂函数
3. `fastapi_rbac/serializers/role_serializer.py` - 更新所有 User 模型使用
4. `fastapi_rbac/serializers/user_serializer.py` - 修复类定义和所有 User 模型使用
5. `fastapi_rbac/serializers/frontend_serializer.py` - 更新 User 模型使用
6. `fastapi_rbac/routers/user_router.py` - 更新 User 模型使用

## 关键修复点

### UserSerializer 类定义修复

`user_serializer.py` 中存在一个特殊问题：类定义时使用了静态的 `User` 类型，这会导致类型不匹配。修复方法：

1. **泛型类型参数**: 将 `BaseSerializer[User, UserCreate, UserUpdate]` 改为 `BaseSerializer[Any, BaseModel, BaseModel]`
2. **构造函数**: 在 `__init__` 方法中动态获取 `User` 模型
3. **返回类型**: 将所有返回类型从 `User` 改为 `Any`
4. **方法内使用**: 在每个需要使用 `User` 模型的方法中调用 `get_user_model()`

这种修复确保了类型系统的一致性，同时保持了运行时的灵活性。
