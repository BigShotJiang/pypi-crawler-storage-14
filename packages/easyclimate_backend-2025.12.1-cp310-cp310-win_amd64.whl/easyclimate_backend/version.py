# easyclimate_backend/version.py
__version__ = "2025.12.1"
