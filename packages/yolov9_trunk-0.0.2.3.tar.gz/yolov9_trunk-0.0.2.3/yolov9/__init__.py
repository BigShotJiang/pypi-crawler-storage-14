import logging

from yolov9.helpers import load_model as load

# Suppress matplotlib font manager debug messages
logging.getLogger('matplotlib.font_manager').setLevel(logging.WARNING)

__version__ = "0.0.2.3"
__author__ = 'cvan-tt'
__license__ = 'Apache License 2.0'