# BHMS

Boss Hiding Messaging System - 办公室隐私聊天工具

## 安装

```bash
pip install bhms
```

## 使用

```bash
# 直接启动
bhms

# 指定服务器
bhms --server ws://YOUR_IP:PORT

# 查看帮助
bhms --help
```

## 配置

三种方式任选:

1. 环境变量
```bash
export BHMS_SERVER=ws://YOUR_IP:PORT
export BHMS_ROOM=default_room
export BHMS_NICKNAME=YourName
```

2. 配置文件 `~/.bhms.conf`
```json
{
  "server": "ws://YOUR_IP:PORT",
  "room": "default_room",
  "nickname": "YourName"
}
```

3. 命令行参数
```bash
bhms --server ws://IP:PORT --room myroom --nickname John
```

## 聊天操作

- 发消息: 直接输入
- 看历史: 输入 `qwe`
- 应急模式: 连按两次回车 (显示假 git 输出)
- 退出: Ctrl+C

## 发布到 PyPI

```bash
pip install build twine
python -m build
twine upload dist/*
```

## 许可证

WTFPL - 随便用
