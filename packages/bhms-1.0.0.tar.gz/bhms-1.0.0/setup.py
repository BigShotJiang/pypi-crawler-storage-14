#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='bhms',
    version='1.0.0',
    description='BHMS - Boss Hiding Messaging System: Privacy-focused CLI chat tool',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='BHMS Contributors',
    author_email='',
    url='https://github.com/stealth-chat/bhms',
    license='WTFPL',
    
    # 包配置
    py_modules=['client'],
    
    # 依赖
    install_requires=[
        'websockets>=15.0.1',
    ],
    
    # Python 版本要求
    python_requires='>=3.7',
    
    # 命令行入口点
    entry_points={
        'console_scripts': [
            'bhms=client:cli_main',
        ],
    },
    
    # 分类信息
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: End Users/Desktop',
        'Topic :: Communications :: Chat',
        'License :: Other/Proprietary License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
        'Environment :: Console',
    ],
    
    # 关键词
    keywords='chat cli privacy stealth communication websocket',
    
    # 项目链接
    project_urls={
        'Bug Reports': 'https://github.com/stealth-chat/bhms/issues',
        'Source': 'https://github.com/stealth-chat/bhms',
    },
)
