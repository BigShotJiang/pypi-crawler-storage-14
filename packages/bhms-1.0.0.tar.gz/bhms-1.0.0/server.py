import asyncio
import websockets
import uuid
import json

# 房间信息：所有用户列表
rooms = {}

async def handle_client(websocket):
    # 获取房间ID
    room_id = await websocket.recv()

    # 初始化房间
    if room_id not in rooms:
        rooms[room_id] = []

    # 将用户加入房间
    rooms[room_id].append(websocket)

    try:
        while True:
            message = await websocket.recv()
            # 广播消息给房间内所有其他客户端
            for user in rooms[room_id]:
                if user != websocket:
                    await user.send(message)
    except websockets.exceptions.ConnectionClosed:
        # 客户端断开后从房间移除
        if websocket in rooms[room_id]:
            rooms[room_id].remove(websocket)

async def main():
    server = await websockets.serve(handle_client, "0.0.0.0", 8765)
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())
