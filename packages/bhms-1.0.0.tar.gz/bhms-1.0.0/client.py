import websockets
import asyncio
import subprocess
import os
import sys
import argparse
import json
from datetime import datetime
from pathlib import Path

# 配置变量 - 从环境变量或命令行参数设置
server_url = os.getenv('BHMS_SERVER', 'ws://localhost:8765')
room_id = os.getenv('BHMS_ROOM', 'default_room')
nickname = os.getenv('BHMS_NICKNAME', '')

# 版本信息
__version__ = '1.0.0'

# 模板配置方法 - 三部分模板配置
def get_template_config():
    """模板配置 - 必须启用，三部分模板在同一函数中"""
    return {
        # ============================================
        # 模板1: 每次对话消息显示
        # Template 1: Regular chat message display
        # ============================================
        'message_display_template': 'git commit -m "{msg}"',
        
        # ============================================
        # 模板2: 应急清屏 (双回车)
        # Template 2: Panic/Emergency clear (double-enter)
        # ============================================
        'panic_template': '''On branch main
Your branch is up to date with 'origin/main'.

nothing to commit, working tree clean''',
        
        # ============================================
        # 模板3: 历史回看 (qwe)
        # Template 3: History view (qwe)
        # ============================================
        'history_view_template': '''commit log:{msg}''',

        # ============================================
        # 模板4: 清屏后显示
        # Template 4: Panic log (panic)
        # ============================================
        'clear_screen_template': '''Project/miniproject/> ''',
    }

# 随机混淆日志
def generate_git_log():
    config = get_template_config()
    return config['panic_template']

# 清屏函数
def clear_screen():
    os.system('clear' if os.name != 'nt' else 'cls')

# Message buffer to collect messages within time window
message_buffer = []
# Persistent history storage for qwe command
message_history = []
buffer_lock = asyncio.Lock()
history_lock = asyncio.Lock()
last_input_empty = False  # Track empty input for double-enter trigger
viewing_history = False  # Track if currently viewing history
clear_task = None  # Track the current clear task to cancel it when new messages arrive

# Clear screen and buffer after delay
async def clear_after_delay(seconds):
    global message_buffer
    await asyncio.sleep(seconds)
    async with buffer_lock:
        message_buffer.clear()
    clear_screen()
    # Reprint the prompt after clearing
    config = get_template_config()
    print(config['clear_screen_template'], end='')

# Auto clear history view after 5 seconds
async def clear_history_after_delay():
    global viewing_history
    await asyncio.sleep(5)
    if viewing_history:
        viewing_history = False
        clear_screen()
        # Reprint the prompt after clearing
        config = get_template_config()
        print(config['clear_screen_template'], end='')

# 处理接收到的消息
async def receive_messages(websocket):
    global message_buffer, message_history, clear_task
    config = get_template_config()
    
    while True:
        try:
            message = await websocket.recv()
            
            # 使用模板显示 (模板必须启用)
            async with buffer_lock:
                display_msg = config['message_display_template'].format(msg=message)
                message_buffer.append(display_msg)
                # 限制最多显示3条消息，超过则移除最早的
                if len(message_buffer) > 3:
                    message_buffer.pop(0)
            
            # 保存到历史记录
            async with history_lock:
                message_history.append(message)
                # 限制历史记录数量，保留最近50条
                if len(message_history) > 50:
                    message_history.pop(0)
            
            # 取消之前的清屏任务
            if clear_task and not clear_task.done():
                clear_task.cancel()
            
            # Display all messages in buffer
            clear_screen()
            async with buffer_lock:
                for msg in message_buffer:
                    print(msg)
            
            # 重新开始3秒倒计时
            clear_task = asyncio.create_task(clear_after_delay(3))
            
        except websockets.exceptions.ConnectionClosed:
            break

# 处理用户输入
async def handle_input(websocket):
    global last_input_empty, viewing_history
    config = get_template_config()
    
    while True:
        try:
            # 使用 asyncio.to_thread 来异步获取输入
            msg = await asyncio.to_thread(input, config['clear_screen_template'])
            
            # Check for double empty input (two consecutive enters)
            if not msg.strip():
                if last_input_empty:
                    # Double enter detected
                    if viewing_history:
                        # If viewing history, exit immediately
                        viewing_history = False
                        clear_screen()
                        last_input_empty = False
                        continue
                    else:
                        # Otherwise trigger panic mode
                        clear_screen()
                        log = generate_git_log()
                        print(log)
                        last_input_empty = False
                        continue
                else:
                    last_input_empty = True
                    continue
            else:
                last_input_empty = False
            
            if msg.lower() == "qwe":
                # 回看历史消息 - 显示5秒或直到双回车
                clear_screen()
                async with history_lock:
                    if message_history:
                        # 显示最近的历史消息
                        history_text = "\n".join(message_history[-10:])  # 显示最近10条
                        print(config['history_view_template'].format(msg=history_text))
                    else:
                        print(config['history_view_template'].format(msg="No messages yet"))
                
                # 设置标志并启动5秒自动清屏
                viewing_history = True
                asyncio.create_task(clear_history_after_delay())
            
            elif msg.strip():
                # 发送普通消息（带昵称）
                timestamp = datetime.now().strftime("%H:%M:%S")
                formatted_msg = f"{nickname}: {msg}"
                await websocket.send(formatted_msg)
                
                # 保存自己发送的消息到历史记录
                async with history_lock:
                    message_history.append(formatted_msg)
                    # 限制历史记录数量，保留最近50条
                    if len(message_history) > 50:
                        message_history.pop(0)
                
                # 使用模板显示 (模板必须启用)
                async with buffer_lock:
                    display_msg = config['message_display_template'].format(msg=formatted_msg)
                    message_buffer.append(display_msg)
                    # 限制最多显示3条消息，超过则移除最早的
                    if len(message_buffer) > 3:
                        message_buffer.pop(0)
                
                # 取消之前的清屏任务
                global clear_task
                if clear_task and not clear_task.done():
                    clear_task.cancel()
                
                clear_screen()
                async with buffer_lock:
                    for msg_log in message_buffer:
                        print(msg_log)
                
                # 重新开始3秒倒计时
                clear_task = asyncio.create_task(clear_after_delay(3))
                
        except EOFError:
            break
        except Exception as e:
            break

# 主函数
async def main(server_url_arg=None):
    global nickname, server_url
    
    # 使用传入的服务器地址或默认值
    ws_server = server_url_arg or server_url
    
    clear_screen()
    
    # 输入昵称
    while True:
        nickname_input = input("Nickname: ").strip()
        if nickname_input:
            nickname = nickname_input
            break
    
    clear_screen()
    
    try:
        async with websockets.connect(ws_server) as websocket:
            # 自动加入房间
            await websocket.send(room_id)
            
            clear_screen()
            
            # 创建任务
            receive_task = asyncio.create_task(receive_messages(websocket))
            input_task = asyncio.create_task(handle_input(websocket))
            
            # 等待任何一个任务完成
            done, pending = await asyncio.wait(
                [receive_task, input_task],
                return_when=asyncio.FIRST_COMPLETED
            )
            
            # 取消剩余任务
            for task in pending:
                task.cancel()
            
    except Exception as e:
        clear_screen()
        print(f"Connection error: {e}")
        sys.exit(1)

def load_config_file(config_path):
    """从配置文件加载配置"""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError:
        print(f"Warning: Invalid JSON in config file: {config_path}")
        return {}

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='BHMS - Privacy-focused command-line chat tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  bhms                                    # Use default settings
  bhms --server ws://106.13.145.206:22222 # Custom server
  bhms --room myroom --nickname John      # Custom room and nickname
  bhms --config ~/.bhms.conf              # Load from config file

Environment Variables:
  BHMS_SERVER    WebSocket server URL
  BHMS_ROOM      Room ID to join
  BHMS_NICKNAME  Your nickname
        '''
    )
    
    parser.add_argument(
        '--server',
        type=str,
        help='WebSocket server URL (default: from env or ws://localhost:8765)'
    )
    
    parser.add_argument(
        '--room',
        type=str,
        help='Room ID to join (default: from env or "default_room")'
    )
    
    parser.add_argument(
        '--nickname',
        type=str,
        help='Your nickname (will prompt if not provided)'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        help='Path to configuration file (JSON format)'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version=f'BHMS v{__version__}'
    )
    
    return parser.parse_args()

def cli_main():
    """命令行入口函数 (用于 pip 安装后的命令)"""
    global server_url, room_id, nickname
    
    # 解析命令行参数
    args = parse_arguments()
    
    # 加载配置文件 (如果指定)
    config = {}
    if args.config:
        config = load_config_file(args.config)
    else:
        # 尝试加载默认配置文件
        default_config_path = Path.home() / '.bhms.conf'
        if default_config_path.exists():
            config = load_config_file(default_config_path)
    
    # 优先级: 命令行参数 > 配置文件 > 环境变量 > 默认值
    server_url = args.server or config.get('server') or server_url
    room_id = args.room or config.get('room') or room_id
    nickname = args.nickname or config.get('nickname') or nickname
    
    # 运行主程序
    try:
        asyncio.run(main(server_url))
    except KeyboardInterrupt:
        clear_screen()
        sys.exit(0)

if __name__ == "__main__":
    cli_main()

