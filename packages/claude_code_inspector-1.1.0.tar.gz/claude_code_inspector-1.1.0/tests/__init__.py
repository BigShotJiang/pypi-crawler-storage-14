"""Tests for Claude-Code-Inspector."""

