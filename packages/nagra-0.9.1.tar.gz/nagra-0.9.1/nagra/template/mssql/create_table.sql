CREATE TABLE [{{ table.name }}] (
  [{{ table.primary_key }}] {{ pk_type or "BIGINT IDENTITY(1,1)" }} PRIMARY KEY
  {%- if fk_table %}
  , CONSTRAINT fk_{{ fk_table.name }} FOREIGN KEY ([{{ table.primary_key }}])
    REFERENCES [{{ fk_table.name }}] ([{{ fk_table.primary_key }}])
    ON DELETE CASCADE
  {%- endif %}
);
