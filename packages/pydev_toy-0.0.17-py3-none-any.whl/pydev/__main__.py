"""pydev command line"""

from .program import main

if __name__ == '__main__':
    main()
