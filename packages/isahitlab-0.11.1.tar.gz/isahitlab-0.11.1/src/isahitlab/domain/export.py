"""Export domain"""
from typing import Literal

ExportFormat = Literal["kili", "lab", "yolo", "mask"]
