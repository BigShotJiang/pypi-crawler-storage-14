# Task module

::: isahitlab.actions.task
::: isahitlab.domain.task    
    options:
        members:
            - TaskPayload