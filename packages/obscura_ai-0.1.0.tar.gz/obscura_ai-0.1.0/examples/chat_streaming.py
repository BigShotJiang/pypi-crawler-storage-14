"""Streaming chat completion example"""

from obscura import Obscura

# Initialize client
client = Obscura(api_key="obscura_xxx")

# Create streaming chat completion
print("AI: ", end="", flush=True)

for chunk in client.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "system", "content": "You are a creative storyteller."},
        {"role": "user", "content": "Tell me a very short story about a robot learning to dance."}
    ],
    stream=True,
    temperature=0.8
):
    # Extract content from delta
    content = chunk.choices[0].delta.get("content", "")
    print(content, end="", flush=True)

print("\n")  # New line after streaming completes
