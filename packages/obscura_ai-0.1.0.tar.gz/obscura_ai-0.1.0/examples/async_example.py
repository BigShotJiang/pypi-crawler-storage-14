"""Async usage example"""

import asyncio
from obscura import AsyncObscura

async def main():
    # Use async context manager for automatic cleanup
    async with AsyncObscura(api_key="obscura_xxx") as client:
        
        # Example 1: Basic chat completion
        print("Example 1: Basic Chat")
        response = await client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Say hello in 3 languages"}],
            temperature=0.7
        )
        print(response.choices[0].message.content)
        print()
        
        # Example 2: Streaming chat
        print("Example 2: Streaming Chat")
        print("AI: ", end="", flush=True)
        async for chunk in await client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Count from 1 to 5"}],
            stream=True
        ):
            content = chunk.choices[0].delta.get("content", "")
            print(content, end="", flush=True)
        print("\n")
        
        # Example 3: Embeddings
        print("Example 3: Embeddings")
        emb_response = await client.embeddings.create(
            input="Hello world",
            model="text-embedding-3-small"
        )
        print(f"Generated embedding with {len(emb_response.data[0].embedding)} dimensions")
        print()
        
        # Example 4: List models
        print("Example 4: Available Models")
        models = await client.models.list()
        print(f"Found {len(models)} models:")
        for model in models[:5]:  # Show first 5
            print(f"  - {model.id}")

# Run async main
if __name__ == "__main__":
    asyncio.run(main())
