"""Basic chat completion example"""

from obscura import Obscura

# Initialize client with your API key
client = Obscura(api_key="obscura_xxx")

# Create a simple chat completion
response = client.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What is the capital of France?"}
    ],
    temperature=0.7,
    max_tokens=100
)

# Print the response
print("AI:", response.choices[0].message.content)
print(f"\nUsage: {response.usage.total_tokens} tokens")
