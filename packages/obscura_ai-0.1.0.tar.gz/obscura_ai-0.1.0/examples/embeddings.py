"""Embeddings example"""

from obscura import Obscura

# Initialize client
client = Obscura(api_key="obscura_xxx")

# Create embeddings for multiple texts
texts = [
    "The quick brown fox jumps over the lazy dog",
    "Machine learning is fascinating",
    "Python is a great programming language"
]

response = client.embeddings.create(
    input=texts,
    model="text-embedding-3-small"
)

# Print results
print(f"Generated {len(response.data)} embeddings:")
for item in response.data:
    print(f"  - Text {item.index}: {len(item.embedding)} dimensions")

print(f"\nTotal tokens used: {response.usage['total_tokens']}")

# Example: Calculate cosine similarity between first two embeddings
import numpy as np

def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

emb1 = np.array(response.data[0].embedding)
emb2 = np.array(response.data[1].embedding)
similarity = cosine_similarity(emb1, emb2)

print(f"\nSimilarity between first two texts: {similarity:.4f}")
