"""Embeddings resource"""

from typing import List, Union
import httpx
from ..types import Embedding, EmbeddingData
from ..exceptions import AuthenticationError, RateLimitError, APIError


class Embeddings:
    """Embeddings API"""
    
    def __init__(self, client: httpx.Client):
        self._client = client
    
    def create(
        self,
        input: Union[str, List[str]],
        model: str,
        **kwargs,
    ) -> Embedding:
        """
        Create embeddings
        
        Args:
            input: Text or list of texts to embed
            model: Embedding model identifier
            **kwargs: Additional parameters
            
        Returns:
            Embedding response
        """
        payload = {
            "model": model,
            "input": input,
            **kwargs,
        }
        
        response = self._client.post("/embeddings", json=payload)
        self._handle_response(response)
        
        data = response.json()
        return Embedding(
            object=data["object"],
            data=[EmbeddingData(**item) for item in data["data"]],
            model=data["model"],
            usage=data["usage"],
        )
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code == 429:
            raise RateLimitError("Rate limit exceeded", status_code=429)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)


class AsyncEmbeddings:
    """Async embeddings API"""
    
    def __init__(self, client: httpx.AsyncClient):
        self._client = client
    
    async def create(
        self,
        input: Union[str, List[str]],
        model: str,
        **kwargs,
    ) -> Embedding:
        """Create embeddings (async)"""
        payload = {
            "model": model,
            "input": input,
            **kwargs,
        }
        
        response = await self._client.post("/embeddings", json=payload)
        self._handle_response(response)
        
        data = response.json()
        return Embedding(
            object=data["object"],
            data=[EmbeddingData(**item) for item in data["data"]],
            model=data["model"],
            usage=data["usage"],
        )
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code == 429:
            raise RateLimitError("Rate limit exceeded", status_code=429)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)
