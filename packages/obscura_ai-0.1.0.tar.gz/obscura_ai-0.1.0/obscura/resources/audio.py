"""Audio resource"""

from typing import BinaryIO
import httpx
from ..types import TranscriptionResponse
from ..exceptions import AuthenticationError, APIError


class AudioTranscriptions:
    """Audio transcriptions API"""
    
    def __init__(self, client: httpx.Client):
        self._client = client
    
    def create(
        self,
        file: BinaryIO,
        model: str = "whisper-1",
        **kwargs,
    ) -> TranscriptionResponse:
        """
        Transcribe audio file
        
        Args:
            file: Audio file object (opened in binary mode)
            model: Transcription model
            **kwargs: Additional parameters
            
        Returns:
            TranscriptionResponse with text
        """
        files = {"file": file}
        data = {"model": model, **kwargs}
        
        response = self._client.post("/transcribe-audio", files=files, data=data)
        self._handle_response(response)
        
        result = response.json()
        return TranscriptionResponse(text=result["text"])
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)


class AsyncAudioTranscriptions:
    """Async audio transcriptions API"""
    
    def __init__(self, client: httpx.AsyncClient):
        self._client = client
    
    async def create(
        self,
        file: BinaryIO,
        model: str = "whisper-1",
        **kwargs,
    ) -> TranscriptionResponse:
        """Transcribe audio file (async)"""
        files = {"file": file}
        data = {"model": model, **kwargs}
        
        response = await self._client.post("/transcribe-audio", files=files, data=data)
        self._handle_response(response)
        
        result = response.json()
        return TranscriptionResponse(text=result["text"])
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)


class Audio:
    """Audio resource"""
    
    def __init__(self, client: httpx.Client):
        self.transcriptions = AudioTranscriptions(client)


class AsyncAudio:
    """Async audio resource"""
    
    def __init__(self, client: httpx.AsyncClient):
        self.transcriptions = AsyncAudioTranscriptions(client)
