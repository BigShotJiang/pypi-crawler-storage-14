"""Models resource"""

from typing import List
import httpx
from ..types import Model
from ..exceptions import AuthenticationError, APIError


class Models:
    """Models API"""
    
    def __init__(self, client: httpx.Client):
        self._client = client
    
    def list(self) -> List[Model]:
        """
        List available models
        
        Returns:
            List of Model objects
        """
        response = self._client.get("/models")
        self._handle_response(response)
        
        data = response.json()
        return [Model(**item) for item in data.get("data", [])]
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)


class AsyncModels:
    """Async models API"""
    
    def __init__(self, client: httpx.AsyncClient):
        self._client = client
    
    async def list(self) -> List[Model]:
        """List available models (async)"""
        response = await self._client.get("/models")
        self._handle_response(response)
        
        data = response.json()
        return [Model(**item) for item in data.get("data", [])]
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)
