"""Images resource"""

import httpx
from ..types import ImageGenerationResponse
from ..exceptions import AuthenticationError, APIError


class Images:
    """Images API"""
    
    def __init__(self, client: httpx.Client):
        self._client = client
    
    def generate(
        self,
        prompt: str,
        model: str = "dall-e-3",
        **kwargs,
    ) -> ImageGenerationResponse:
        """
        Generate image from prompt
        
        Args:
            prompt: Text description of desired image
            model: Image generation model
            **kwargs: Additional parameters
            
        Returns:
            ImageGenerationResponse with image URLs
        """
        payload = {
            "prompt": prompt,
            "model": model,
            **kwargs,
        }
        
        response = self._client.post("/ai-image-generate", json=payload)
        self._handle_response(response)
        
        data = response.json()
        return ImageGenerationResponse(
            created=data.get("created", 0),
            data=data.get("data", []),
        )
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)


class AsyncImages:
    """Async images API"""
    
    def __init__(self, client: httpx.AsyncClient):
        self._client = client
    
    async def generate(
        self,
        prompt: str,
        model: str = "dall-e-3",
        **kwargs,
    ) -> ImageGenerationResponse:
        """Generate image from prompt (async)"""
        payload = {
            "prompt": prompt,
            "model": model,
            **kwargs,
        }
        
        response = await self._client.post("/ai-image-generate", json=payload)
        self._handle_response(response)
        
        data = response.json()
        return ImageGenerationResponse(
            created=data.get("created", 0),
            data=data.get("data", []),
        )
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code >= 400:
            raise APIError(f"API error: {response.text}", status_code=response.status_code)
