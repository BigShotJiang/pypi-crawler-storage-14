"""Chat completions resource"""

from typing import List, Optional, Iterator, Union, Dict, Any, AsyncIterator
import httpx
from ..types import ChatCompletion, ChatCompletionChunk
from ..exceptions import AuthenticationError, RateLimitError, QuotaExceededError, APIError
from .._utils.streaming import SSEDecoder


class ChatCompletions:
    """Chat completions API"""
    
    def __init__(self, client: httpx.Client):
        self._client = client
    
    def create(
        self,
        messages: List[Dict[str, str]],
        model: str,
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        stream: bool = False,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        **kwargs,
    ) -> Union[ChatCompletion, Iterator[ChatCompletionChunk]]:
        """
        Create a chat completion
        
        Args:
            messages: List of messages (role, content)
            model: Model identifier (e.g., "gpt-4", "claude-3-opus")
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            top_p: Nucleus sampling parameter
            stream: Enable streaming response
            frequency_penalty: Frequency penalty (-2.0 to 2.0)
            presence_penalty: Presence penalty (-2.0 to 2.0)
            **kwargs: Additional model-specific parameters
            
        Returns:
            ChatCompletion or streaming iterator
        """
        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": stream,
            **kwargs,
        }
        
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if top_p is not None:
            payload["top_p"] = top_p
        if frequency_penalty is not None:
            payload["frequency_penalty"] = frequency_penalty
        if presence_penalty is not None:
            payload["presence_penalty"] = presence_penalty
        
        if stream:
            return self._stream(payload)
        
        response = self._client.post("/chat-completions", json=payload)
        self._handle_response(response)
        
        data = response.json()
        return ChatCompletion(
            id=data["id"],
            object=data["object"],
            created=data["created"],
            model=data["model"],
            choices=data["choices"],
            usage=data["usage"],
        )
    
    def _stream(self, payload: Dict[str, Any]) -> Iterator[ChatCompletionChunk]:
        """Handle SSE streaming response"""
        with self._client.stream("POST", "/chat-completions", json=payload) as response:
            self._handle_response(response)
            decoder = SSEDecoder()
            
            for event in decoder.iter_events(response.iter_lines()):
                if event.data == "[DONE]":
                    break
                
                data = event.json()
                yield ChatCompletionChunk(
                    id=data["id"],
                    object=data["object"],
                    created=data["created"],
                    model=data["model"],
                    choices=data["choices"],
                )
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code == 429:
            raise RateLimitError("Rate limit exceeded", status_code=429, retry_after=60)
        elif response.status_code == 402:
            raise QuotaExceededError("Quota exceeded", status_code=402)
        elif response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get("error", response.text)
            except:
                message = response.text
            raise APIError(f"API error: {message}", status_code=response.status_code)


class AsyncChatCompletions:
    """Async chat completions API"""
    
    def __init__(self, client: httpx.AsyncClient):
        self._client = client
    
    async def create(
        self,
        messages: List[Dict[str, str]],
        model: str,
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        stream: bool = False,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        **kwargs,
    ) -> Union[ChatCompletion, AsyncIterator[ChatCompletionChunk]]:
        """Create a chat completion (async)"""
        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": stream,
            **kwargs,
        }
        
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if top_p is not None:
            payload["top_p"] = top_p
        if frequency_penalty is not None:
            payload["frequency_penalty"] = frequency_penalty
        if presence_penalty is not None:
            payload["presence_penalty"] = presence_penalty
        
        if stream:
            return self._stream(payload)
        
        response = await self._client.post("/chat-completions", json=payload)
        self._handle_response(response)
        
        data = response.json()
        return ChatCompletion(
            id=data["id"],
            object=data["object"],
            created=data["created"],
            model=data["model"],
            choices=data["choices"],
            usage=data["usage"],
        )
    
    async def _stream(self, payload: Dict[str, Any]) -> AsyncIterator[ChatCompletionChunk]:
        """Handle SSE streaming response (async)"""
        async with self._client.stream("POST", "/chat-completions", json=payload) as response:
            self._handle_response(response)
            decoder = SSEDecoder()
            
            async for event in decoder.aiter_events(response.aiter_lines()):
                if event.data == "[DONE]":
                    break
                
                data = event.json()
                yield ChatCompletionChunk(
                    id=data["id"],
                    object=data["object"],
                    created=data["created"],
                    model=data["model"],
                    choices=data["choices"],
                )
    
    def _handle_response(self, response: httpx.Response):
        """Handle HTTP response errors"""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code == 429:
            raise RateLimitError("Rate limit exceeded", status_code=429, retry_after=60)
        elif response.status_code == 402:
            raise QuotaExceededError("Quota exceeded", status_code=402)
        elif response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get("error", response.text)
            except:
                message = response.text
            raise APIError(f"API error: {message}", status_code=response.status_code)


class Chat:
    """Chat resource"""
    
    def __init__(self, client: httpx.Client):
        self.completions = ChatCompletions(client)


class AsyncChat:
    """Async chat resource"""
    
    def __init__(self, client: httpx.AsyncClient):
        self.completions = AsyncChatCompletions(client)
