"""Server-Sent Events (SSE) streaming utilities"""

import json
from dataclasses import dataclass
from typing import Iterator, AsyncIterator


@dataclass
class SSEEvent:
    """Server-Sent Event"""
    data: str
    event: str = None
    
    def json(self):
        """Parse data as JSON"""
        return json.loads(self.data)


class SSEDecoder:
    """Decoder for Server-Sent Events streams"""
    
    def iter_events(self, lines: Iterator[str]) -> Iterator[SSEEvent]:
        """
        Parse SSE stream into events (synchronous)
        
        Args:
            lines: Iterator of text lines from response
            
        Yields:
            SSEEvent objects
        """
        data_buffer = []
        event_type = None
        
        for line in lines:
            line = line.strip()
            
            # Skip comments
            if line.startswith(":"):
                continue
            
            # Empty line = event boundary
            if line == "":
                if data_buffer:
                    yield SSEEvent(
                        data="\n".join(data_buffer),
                        event=event_type
                    )
                    data_buffer = []
                    event_type = None
                continue
            
            # Parse SSE fields
            if line.startswith("data: "):
                data_buffer.append(line[6:])
            elif line.startswith("event: "):
                event_type = line[7:]
        
        # Flush remaining data
        if data_buffer:
            yield SSEEvent(
                data="\n".join(data_buffer),
                event=event_type
            )
    
    async def aiter_events(self, lines: AsyncIterator[str]) -> AsyncIterator[SSEEvent]:
        """
        Parse SSE stream into events (asynchronous)
        
        Args:
            lines: Async iterator of text lines from response
            
        Yields:
            SSEEvent objects
        """
        data_buffer = []
        event_type = None
        
        async for line in lines:
            line = line.strip()
            
            # Skip comments
            if line.startswith(":"):
                continue
            
            # Empty line = event boundary
            if line == "":
                if data_buffer:
                    yield SSEEvent(
                        data="\n".join(data_buffer),
                        event=event_type
                    )
                    data_buffer = []
                    event_type = None
                continue
            
            # Parse SSE fields
            if line.startswith("data: "):
                data_buffer.append(line[6:])
            elif line.startswith("event: "):
                event_type = line[7:]
        
        # Flush remaining data
        if data_buffer:
            yield SSEEvent(
                data="\n".join(data_buffer),
                event=event_type
            )
