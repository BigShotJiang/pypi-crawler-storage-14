"""HTTP client utilities"""

import httpx
from typing import Optional


def create_client(
    api_key: str,
    base_url: str,
    timeout: float = 60.0,
) -> httpx.Client:
    """
    Create configured HTTP client
    
    Args:
        api_key: API authentication key
        base_url: Base URL for API endpoints
        timeout: Request timeout in seconds
        
    Returns:
        Configured httpx.Client
    """
    return httpx.Client(
        base_url=base_url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        timeout=timeout,
    )


def create_async_client(
    api_key: str,
    base_url: str,
    timeout: float = 60.0,
) -> httpx.AsyncClient:
    """
    Create configured async HTTP client
    
    Args:
        api_key: API authentication key
        base_url: Base URL for API endpoints
        timeout: Request timeout in seconds
        
    Returns:
        Configured httpx.AsyncClient
    """
    return httpx.AsyncClient(
        base_url=base_url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        timeout=timeout,
    )
