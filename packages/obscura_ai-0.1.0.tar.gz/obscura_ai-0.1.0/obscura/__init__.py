"""
Obscura Python SDK

Official Python SDK for Obscura AI Gateway.
"""

from .client import Obscura, AsyncObscura
from .types import (
    Message,
    ChatCompletion,
    ChatCompletionChunk,
    Embedding,
    Model,
    Usage,
    Choice,
    TranscriptionResponse,
    ImageGenerationResponse,
)
from .exceptions import (
    ObscuraError,
    AuthenticationError,
    RateLimitError,
    QuotaExceededError,
    APIError,
    ModelNotFoundError,
)

__version__ = "0.1.0"
__all__ = [
    "Obscura",
    "AsyncObscura",
    "Message",
    "ChatCompletion",
    "ChatCompletionChunk",
    "Embedding",
    "Model",
    "Usage",
    "Choice",
    "TranscriptionResponse",
    "ImageGenerationResponse",
    "ObscuraError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "APIError",
    "ModelNotFoundError",
]
