"""Custom exceptions for Obscura SDK"""


class ObscuraError(Exception):
    """Base exception for Obscura SDK"""
    
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(message)


class AuthenticationError(ObscuraError):
    """Authentication failed (401)"""
    pass


class RateLimitError(ObscuraError):
    """Rate limit exceeded (429)"""
    
    def __init__(self, message: str, retry_after: int = 60, **kwargs):
        self.retry_after = retry_after
        super().__init__(message, **kwargs)


class QuotaExceededError(ObscuraError):
    """Quota exceeded (402)"""
    pass


class APIError(ObscuraError):
    """General API error"""
    pass


class ModelNotFoundError(ObscuraError):
    """Model not found"""
    pass


class ValidationError(ObscuraError):
    """Request validation error"""
    pass
