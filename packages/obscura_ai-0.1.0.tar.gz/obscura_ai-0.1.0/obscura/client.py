"""Main client classes for Obscura SDK"""

import httpx
from typing import Optional
from .resources.chat import Chat, AsyncChat
from .resources.embeddings import Embeddings, AsyncEmbeddings
from .resources.models import Models, AsyncModels
from .resources.audio import Audio, AsyncAudio
from .resources.images import Images, AsyncImages


class Obscura:
    """Obscura API synchronous client"""
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://emorprdwdukhmrgeclyg.supabase.co/functions/v1",
        timeout: float = 60.0,
        max_retries: int = 2,
    ):
        """
        Initialize Obscura client
        
        Args:
            api_key: Your Obscura API token (obscura_xxx format)
            base_url: API base URL
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
        """
        self.api_key = api_key
        self.base_url = base_url
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        
        # Initialize resources
        self.chat = Chat(self._client)
        self.embeddings = Embeddings(self._client)
        self.models = Models(self._client)
        self.audio = Audio(self._client)
        self.images = Images(self._client)
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self._client.close()
    
    def close(self):
        """Close the HTTP client"""
        self._client.close()


class AsyncObscura:
    """Obscura API asynchronous client"""
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://emorprdwdukhmrgeclyg.supabase.co/functions/v1",
        timeout: float = 60.0,
        max_retries: int = 2,
    ):
        """
        Initialize async Obscura client
        
        Args:
            api_key: Your Obscura API token
            base_url: API base URL
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
        """
        self.api_key = api_key
        self.base_url = base_url
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        
        # Initialize async resources
        self.chat = AsyncChat(self._client)
        self.embeddings = AsyncEmbeddings(self._client)
        self.models = AsyncModels(self._client)
        self.audio = AsyncAudio(self._client)
        self.images = AsyncImages(self._client)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, *args):
        await self._client.aclose()
    
    async def close(self):
        """Close the HTTP client"""
        await self._client.aclose()
