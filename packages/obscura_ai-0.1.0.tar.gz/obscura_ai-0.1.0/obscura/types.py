"""Type definitions for Obscura SDK"""

from dataclasses import dataclass
from typing import List, Optional, Literal, Dict, Any


@dataclass
class Message:
    """Chat message"""
    role: Literal["system", "user", "assistant"]
    content: str


@dataclass
class Usage:
    """Token usage information"""
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class Choice:
    """Chat completion choice"""
    index: int
    message: Message
    finish_reason: Optional[str]


@dataclass
class ChatCompletion:
    """Chat completion response"""
    id: str
    object: str
    created: int
    model: str
    choices: List[Choice]
    usage: Usage


@dataclass
class ChatCompletionChunk:
    """Streaming chat completion chunk"""
    id: str
    object: str
    created: int
    model: str
    choices: List[Dict[str, Any]]


@dataclass
class EmbeddingData:
    """Single embedding data"""
    object: str
    embedding: List[float]
    index: int


@dataclass
class Embedding:
    """Embedding response"""
    object: str
    data: List[EmbeddingData]
    model: str
    usage: Dict[str, int]


@dataclass
class Model:
    """Model information"""
    id: str
    object: str
    created: int
    owned_by: str
    provider: Optional[str] = None


@dataclass
class TranscriptionResponse:
    """Audio transcription response"""
    text: str


@dataclass
class ImageGenerationResponse:
    """Image generation response"""
    created: int
    data: List[Dict[str, str]]
