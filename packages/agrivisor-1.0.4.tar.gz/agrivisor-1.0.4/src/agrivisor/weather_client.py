import requests
from typing import Optional, Dict, Any, List
from datetime import datetime

from agrivisor.models import (
    CurrentWeather,
    HourlyForecast,
    DailyForecast,
    AirPollution,
    GeocodingResult,
)
from agrivisor.exceptions import (
    OpenWeatherAPIError,
    InvalidAPIKeyError,
    LocationNotFoundError,
    APIRequestError,
)

# client = OpenWeatherClient(api_key="your_api_key_here")
# weather = client.get_current_weather(lat=53.3498, lon=-6.2603)
# weather = client.get_current_weather(city_name="Dublin", country_code="IE")
# print(weather.temperature)
class OpenWeatherClient:
    BASE_URL = "https://api.openweathermap.org"
    
    def __init__(
        self,
        api_key: str,
        units: str = "metric",
        language: str = "en"
    ):
        if not api_key or not api_key.strip():
            raise InvalidAPIKeyError("API key is required and cannot be empty")
        
        self.api_key = api_key.strip()
        self.units = units
        self.language = language
        self.session = requests.Session()
    
    def api_request(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None
    ):
        url = f"{self.BASE_URL}{endpoint}"
        
        request_params = {
            "appid": self.api_key,
            "units": self.units,
            "lang": self.language,
        }
        
        if params:
            request_params.update(params)
        
        try:
            response = self.session.get(url, params=request_params, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if response.status_code == 401:
                raise InvalidAPIKeyError("Invalid API key. Please check your OpenWeather API key.")
            elif response.status_code == 404:
                error_data = response.json() if response.content else {}
                if "message" in error_data:
                    raise LocationNotFoundError(f"Location not found: {error_data['message']}")
                raise LocationNotFoundError("Location not found")
            elif response.status_code == 429:
                raise APIRequestError("API rate limit exceeded. Please try again later.")
            else:
                error_data = response.json() if response.content else {}
                message = error_data.get("message", str(e))
                raise OpenWeatherAPIError(f"API error: {message}")
        except requests.exceptions.RequestException as e:
            raise APIRequestError(f"Request failed: {str(e)}")
    
    def validate_cords(self, lat: float, lon: float):
        if not -90 <= lat <= 90:
            raise ValueError(f"Latitude must be between -90 and 90, got {lat}")
        if not -180 <= lon <= 180:
            raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
    
    def get_current_weather(
        self,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        city_name: Optional[str] = None,
        country_code: Optional[str] = None
    ) -> CurrentWeather:
        if city_name:
            results = self.geocode(city_name, country_code=country_code, limit=1)
            if not results:
                raise LocationNotFoundError(f"City '{city_name}' not found")
            lat = results[0].lat
            lon = results[0].lon
        
        if lat is None or lon is None:
            raise ValueError("Either coordinates (lat, lon) or city_name must be provided")

        self.validate_cords(lat, lon)
        
        params = {
            "lat": lat,
            "lon": lon,
        }
        
        data = self.api_request("/data/2.5/weather", params)
        return CurrentWeather.from_openweather_dict(data)
    
    def get_weather_snapshot(
        self,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        city_name: Optional[str] = None,
        country_code: Optional[str] = None
    ) -> Dict[str, Any]:
        weather = self.get_current_weather(lat=lat, lon=lon, city_name=city_name, country_code=country_code)
        return {
            "temp": round(weather.temperature, 1),
            "humidity": round(weather.humidity, 1),
            "rain": weather.rain_1h is not None and weather.rain_1h > 0,
            "wind": round(weather.wind_speed, 1),
            "updatedAt": weather.timestamp.isoformat(),
        }
    
    def get_hourly_forecast(
        self,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        city_name: Optional[str] = None,
        country_code: Optional[str] = None,
        cnt: Optional[int] = None
    ) -> List[HourlyForecast]:
        if city_name:
            results = self.geocode(city_name, country_code=country_code, limit=1)
            if not results:
                raise LocationNotFoundError(f"City '{city_name}' not found")
            lat = results[0].lat
            lon = results[0].lon
        
        if lat is None or lon is None:
            raise ValueError("Either coordinates (lat, lon) or city_name must be provided")
        
        self.validate_cords(lat, lon)
        
        params = {
            "lat": lat,
            "lon": lon,
        }
        
        if cnt:
            params["cnt"] = cnt
        
        data = self.api_request("/data/2.5/forecast", params)
        
        forecasts = []
        for item in data.get("list", []):
            forecasts.append(HourlyForecast.from_openweather_dict(item))
        
        return forecasts
    
    def get_daily_forecast(
        self,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        city_name: Optional[str] = None,
        country_code: Optional[str] = None,
        cnt: Optional[int] = None
    ) -> List[DailyForecast]:
        if city_name:
            results = self.geocode(city_name, country_code=country_code, limit=1)
            if not results:
                raise LocationNotFoundError(f"City '{city_name}' not found")
            lat = results[0].lat
            lon = results[0].lon
        
        if lat is None or lon is None:
            raise ValueError("Either coordinates (lat, lon) or city_name must be provided")
        
        self.validate_cords(lat, lon)
        
        params = {
            "lat": lat,
            "lon": lon,
        }
        
        try:
            params["exclude"] = "minutely,alerts"
            data = self.api_request("/data/3.0/onecall", params)
            forecasts = []
            for item in data.get("daily", []):
                forecasts.append(DailyForecast.from_openweather_dict(item))
            
            if cnt:
                forecasts = forecasts[:cnt]
            
            return forecasts
        except Exception as e:
            hourly = self.get_hourly_forecast(lat, lon)
            return self.hourly_to_daily(hourly, cnt)
    
    def get_air_pollution(
        self,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        city_name: Optional[str] = None,
        country_code: Optional[str] = None
    ) -> AirPollution:
        if city_name:
            results = self.geocode(city_name, country_code=country_code, limit=1)
            
            if not results:
                raise LocationNotFoundError(f"City '{city_name}' not found")
            lat = results[0].lat
            lon = results[0].lon
        
        if lat is None or lon is None:
            raise ValueError("Either coordinates (lat, lon) or city_name must be provided")
        
        self.validate_cords(lat, lon)
        
        params = {
            "lat": lat,
            "lon": lon,
        }
        
        data = self.api_request("/data/2.5/air_pollution", params)
        
        if "list" in data and len(data["list"]) > 0:
            return AirPollution.from_openweather_dict(data["list"][0])
        else:
            raise OpenWeatherAPIError("No air pollution data available")
    
    def geocode(
        self,
        city_name: str,
        state_code: Optional[str] = None,
        country_code: Optional[str] = None,
        limit: int = 5
    ) -> List[GeocodingResult]:
        query = city_name
        if state_code:
            query += f",{state_code}"
        if country_code:
            query += f",{country_code}"
        
        params = {
            "q": query,
            "limit": limit,
        }
        
        data = self.api_request("/geo/1.0/direct", params)
        
        results = []
        for item in data:
            results.append(GeocodingResult.from_openweather_dict(item))

        return results
    
    def reverse_geocode(
        self,
        lat: float,
        lon: float,
        limit: int = 5
    ) -> List[GeocodingResult]:
        params = {
            "lat": lat,
            "lon": lon,
            "limit": limit,
        }
        
        data = self.api_request("/geo/1.0/reverse", params)
        
        results = []
        for item in data:
            results.append(GeocodingResult.from_openweather_dict(item))
        
        return results
    
    def hourly_to_daily(
        self,
        hourly_forecasts: List[HourlyForecast],
        cnt: Optional[int] = None
    ) -> List[DailyForecast]:
        if not hourly_forecasts:
            return []
        daily_data: Dict[str, List[HourlyForecast]] = {}
        for forecast in hourly_forecasts:
            date_key = forecast.timestamp.date().isoformat()
            if date_key not in daily_data:
                daily_data[date_key] = []
            daily_data[date_key].append(forecast)
        daily_forecasts = []
        for date_key in sorted(daily_data.keys()):
            day_forecasts = daily_data[date_key]
            
            temps = [f.temperature for f in day_forecasts]
            feels_like = [f.feels_like for f in day_forecasts]
            humidity = [f.humidity for f in day_forecasts]
            pressure = [f.pressure for f in day_forecasts]
            wind_speed = [f.wind_speed for f in day_forecasts]
            
            main_weather = day_forecasts[0].weather_main
            description = day_forecasts[0].weather_description
            daily_forecast = DailyForecast(
                forecast_date=datetime.fromisoformat(date_key).date(),
                temp_min=min(temps),
                temp_day=temps[len(temps)//2] if temps else 0,
                wind_speed=sum(wind_speed) / len(wind_speed) if wind_speed else 0,
                temp_night=temps[-1] if temps else 0,
                temp_max=max(temps),
                temp_eve=temps[len(temps)*3//4] if temps else 0,
                temp_morn=temps[0] if temps else 0,
                feels_like_day=feels_like[len(feels_like)//2] if feels_like else 0,
                feels_like_morn=feels_like[0] if feels_like else 0,
                humidity=sum(humidity) / len(humidity) if humidity else 0,
                feels_like_night=feels_like[-1] if feels_like else 0,
                pressure=sum(pressure) / len(pressure) if pressure else 0,
                feels_like_eve=feels_like[len(feels_like)*3//4] if feels_like else 0,
                weather_description=description,
                clouds=day_forecasts[0].clouds,
                weather_main=main_weather,
                uvi=0,
                pop=0,
            )
            
            daily_forecasts.append(daily_forecast)
        
        if cnt:
            daily_forecasts = daily_forecasts[:cnt]
        return daily_forecasts
    
    def is_raining(
        self,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        city_name: Optional[str] = None,
        country_code: Optional[str] = None
    ) -> bool:
        weather = self.get_current_weather(lat=lat, lon=lon, city_name=city_name, country_code=country_code)
        return weather.rain_1h is not None and weather.rain_1h > 0
    
    def get_weather_summary(
        self,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        city_name: Optional[str] = None,
        country_code: Optional[str] = None
    ):
        
        weather = self.get_current_weather(lat=lat, lon=lon, city_name=city_name, country_code=country_code)
        summary_parts = [
            f"{weather.location_name}, {weather.country}",
            f"{weather.temperature}°C",
            weather.weather_description.title(),
        ]
        if weather.humidity:
            summary_parts.append(f"Humidity: {weather.humidity}%")
        
        if weather.wind_speed:
            summary_parts.append(f"Wind: {weather.wind_speed} m/s")
        
        if weather.rain_1h and weather.rain_1h > 0:
            summary_parts.append(f"Rain: {weather.rain_1h}mm")
            
        if weather.snow_1h and weather.snow_1h > 0:
            summary_parts.append(f"Snow: {weather.snow_1h}mm")
        
        return ", ".join(summary_parts)

