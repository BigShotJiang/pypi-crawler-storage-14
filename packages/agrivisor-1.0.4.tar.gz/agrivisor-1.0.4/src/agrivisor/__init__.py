from agrivisor.weather_client import OpenWeatherClient
from agrivisor.models import (
    CurrentWeather,
    HourlyForecast,
    DailyForecast,
    AirPollution,
    GeocodingResult,
    WeatherData,
    CropRecommendation,
    AdvisoryResult,
)
from agrivisor.exceptions import (
    AgriVisorError,
    OpenWeatherAPIError,
    InvalidAPIKeyError,
    LocationNotFoundError,
    APIRequestError,
    InvalidWeatherDataError,
    NoRecommendationsError,
)

__version__ = "1.0.4"
__all__ = [
    "OpenWeatherClient",
    "CurrentWeather",
    "HourlyForecast",
    "DailyForecast",
    "AirPollution",
    "GeocodingResult",
    "WeatherData",
    "CropRecommendation",
    "AdvisoryResult",
    "AgriVisorError",
    "OpenWeatherAPIError",
    "InvalidAPIKeyError",
    "LocationNotFoundError",
    "APIRequestError",
    "InvalidWeatherDataError",
    "NoRecommendationsError",
]

