class AgriVisorError(Exception):
    pass


class OpenWeatherAPIError(AgriVisorError):
    pass


class InvalidAPIKeyError(AgriVisorError):
    pass


class LocationNotFoundError(AgriVisorError):
    pass


class APIRequestError(AgriVisorError):
    pass


class InvalidWeatherDataError(AgriVisorError):
    pass


class NoRecommendationsError(AgriVisorError):
    pass

