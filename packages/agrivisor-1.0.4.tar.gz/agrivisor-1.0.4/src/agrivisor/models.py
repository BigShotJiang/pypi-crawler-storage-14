from doctest import Example
from typing import Optional, List, Dict, Any
from datetime import datetime, date
from pydantic import BaseModel, Field, validator

class CurrentWeather(BaseModel):
    temperature: float = Field(...)
    feels_like: float = Field(...)
    pressure: float = Field(...)
    humidity: float = Field(...)
    visibility: Optional[float] = Field(None)
    wind_speed: float = Field(...)
    wind_direction: Optional[float] = Field(None)
    wind_gust: Optional[float] = Field(None)
    clouds: float = Field(...)
    rain_1h: Optional[float] = Field(None)
    rain_3h: Optional[float] = Field(None)
    snow_1h: Optional[float] = Field(None)
    snow_3h: Optional[float] = Field(None)
    weather_main: str = Field(...)
    weather_description: str = Field(...)
    weather_icon: str = Field(...)
    sunrise: Optional[datetime] = Field(None)
    sunset: Optional[datetime] = Field(None)
    timestamp: datetime = Field(...)
    location_name: str = Field(...)
    country: str = Field(...)
    lat: float = Field(...)
    lon: float = Field(...)
    
    @classmethod
    def from_openweather_dict(cls, data: Dict[str, Any]) -> "CurrentWeather":
        main = data.get("main", {})
        weather = data.get("weather", [{}])[0]
        wind = data.get("wind", {})
        rain = data.get("rain", {})
        snow = data.get("snow", {})
        sys = data.get("sys", {})
        coord = data.get("coord", {})
        
        return cls(
            temperature=main.get("temp", 0),
            feels_like=main.get("feels_like", 0),
            pressure=main.get("pressure", 0),
            humidity=main.get("humidity", 0),
            visibility=data.get("visibility"),
            wind_speed=wind.get("speed", 0),
            wind_direction=wind.get("deg"),
            wind_gust=wind.get("gust"),
            clouds=data.get("clouds", {}).get("all", 0),
            rain_1h=rain.get("1h"),
            rain_3h=rain.get("3h"),
            snow_1h=snow.get("1h"),
            snow_3h=snow.get("3h"),
            weather_main=weather.get("main", ""),
            weather_description=weather.get("description", ""),
            weather_icon=weather.get("icon", ""),
            sunrise=datetime.fromtimestamp(sys.get("sunrise", 0)) if sys.get("sunrise") else None,
            sunset=datetime.fromtimestamp(sys.get("sunset", 0)) if sys.get("sunset") else None,
            timestamp=datetime.fromtimestamp(data.get("dt", 0)),
            location_name=data.get("name", ""),
            country=sys.get("country", ""),
            lat=coord.get("lat", 0),
            lon=coord.get("lon", 0),
        )


class HourlyForecast(BaseModel):
    timestamp: datetime = Field(..., description="forecast time")
    temperature: float = Field(...)
    feels_like: float = Field(...)
    pressure: float = Field(...)
    humidity: float = Field(...)
    wind_speed: float = Field(...)
    wind_direction: Optional[float] = Field(None)
    wind_gust: Optional[float] = Field(None)
    clouds: float = Field(...)
    rain_3h: Optional[float] = Field(None)
    snow_3h: Optional[float] = Field(None)
    weather_main: str = Field(..., description="weather condition")
    weather_description: str = Field(...)
    weather_icon: str = Field(..., description="icon code")
    pop: float = Field(0, description="probability of precipitation (0-1)")
    visibility: Optional[float] = Field(None, description="visibility in meters")
    
    @classmethod
    def from_openweather_dict(cls, data: Dict[str, Any]) -> "HourlyForecast":
        main = data.get("main", {})
        weather = data.get("weather", [{}])[0]
        wind = data.get("wind", {})
        rain = data.get("rain", {})
        snow = data.get("snow", {})
        
        return cls(
            timestamp=datetime.fromtimestamp(data.get("dt", 0)),
            temperature=main.get("temp", 0),
            feels_like=main.get("feels_like", 0),
            pressure=main.get("pressure", 0),
            humidity=main.get("humidity", 0),
            wind_speed=wind.get("speed", 0),
            wind_direction=wind.get("deg"),
            wind_gust=wind.get("gust"),
            clouds=data.get("clouds", {}).get("all", 0),
            rain_3h=rain.get("3h"),
            snow_3h=snow.get("3h"),
            weather_main=weather.get("main", ""),
            weather_description=weather.get("description", ""),
            weather_icon=weather.get("icon", ""),
            pop=data.get("pop", 0),
            visibility=data.get("visibility"),
        )


class DailyForecast(BaseModel):
    forecast_date: date = Field(...)
    temp_min: float = Field(...)
    temp_max: float = Field(...)
    temp_day: float = Field(...)
    temp_night: float = Field(...)
    temp_eve: float = Field(...)
    temp_morn: float = Field(...)
    feels_like_day: float = Field(...)
    feels_like_night: float = Field(...)
    feels_like_eve: float = Field(...)
    feels_like_morn: float = Field(...)
    pressure: float = Field(...)
    humidity: float = Field(...)
    wind_speed: float = Field(...)
    wind_direction: Optional[float] = Field(None)
    wind_gust: Optional[float] = Field(None)
    clouds: float = Field(...)
    weather_main: str = Field(...)
    weather_description: str = Field(...)
    weather_icon: str = Field(...)
    pop: float = Field(0)
    rain: Optional[float] = Field(None, description="volume in mm")
    snow: Optional[float] = Field(None, description="volume in mm")
    uvi: float = Field(0, description="uv index")
    sunrise: Optional[datetime] = Field(None, description="sunrise time")
    sunset: Optional[datetime] = Field(None, description="sunset time")
    
    @classmethod
    def from_openweather_dict(cls, data: Dict[str, Any]) -> "DailyForecast":
        temp = data.get("temp", {})
        feels_like = data.get("feels_like", {})
        weather = data.get("weather", [{}])[0]
        wind = data.get("wind", {})
        rain = data.get("rain", {})
        snow = data.get("snow", {})
        
        return cls(
            forecast_date=datetime.fromtimestamp(data.get("dt", 0)).date(),
            temp_min=temp.get("min", 0),
            temp_max=temp.get("max", 0),
            temp_day=temp.get("day", 0),
            temp_night=temp.get("night", 0),
            temp_eve=temp.get("eve", 0),
            temp_morn=temp.get("morn", 0),
            feels_like_day=feels_like.get("day", 0),
            feels_like_night=feels_like.get("night", 0),
            feels_like_eve=feels_like.get("eve", 0),
            feels_like_morn=feels_like.get("morn", 0),
            pressure=data.get("pressure", 0),
            humidity=data.get("humidity", 0),
            wind_speed=wind.get("speed", 0),
            wind_direction=wind.get("deg"),
            wind_gust=wind.get("gust"),
            clouds=data.get("clouds", 0),
            weather_main=weather.get("main", ""),
            weather_description=weather.get("description", ""),
            weather_icon=weather.get("icon", ""),
            pop=data.get("pop", 0),
            rain=rain.get("1h") if isinstance(rain, dict) else rain,
            snow=snow.get("1h") if isinstance(snow, dict) else snow,
            uvi=data.get("uvi", 0),
            sunrise=datetime.fromtimestamp(data.get("sunrise", 0)) if data.get("sunrise") else None,
            sunset=datetime.fromtimestamp(data.get("sunset", 0)) if data.get("sunset") else None,
        )


class AirPollution(BaseModel):
    timestamp: datetime = Field(..., description="time of data")
    aqi: int = Field(..., description="air quality index (1-5)")
    co: float = Field(..., description="carbon monoxide concentration")
    no: float = Field(..., description="nitrogen monoxide con")
    no2: float = Field(..., description="nitrogen dioxide con")
    o3: float = Field(..., description="ozone con")
    so2: float = Field(..., description="sulphur dioxide con")
    pm2_5: float = Field(..., description="pm2.5 con")
    pm10: float = Field(..., description="pm10 con")
    nh3: Optional[float] = Field(None, description="ammonia con")
    
    @classmethod
    def from_openweather_dict(cls, data: Dict[str, Any]) -> "AirPollution":
        components = data.get("components", {})
        main = data.get("main", {})
        
        return cls(
            timestamp=datetime.fromtimestamp(data.get("dt", 0)),
            aqi=main.get("aqi", 1),
            co=components.get("co", 0),
            no=components.get("no", 0),
            no2=components.get("no2", 0),
            o3=components.get("o3", 0),
            so2=components.get("so2", 0),
            pm2_5=components.get("pm2_5", 0),
            pm10=components.get("pm10", 0),
            nh3=components.get("nh3"),
        )
    
    @property
    def aqi_description(self) -> str:
        aqi_map = {
            1: "Good",
            2: "Fair",
            3: "Moderate",
            4: "Poor",
            5: "Very Poor"
        }
        return aqi_map.get(self.aqi, "Unknown")


class GeocodingResult(BaseModel):
    name: str = Field(...)
    lat: float = Field(...)
    lon: float = Field(...)
    country: str = Field(...)
    state: Optional[str] = Field(None)
    local_names: Optional[Dict[str, str]] = Field(None)
    
    @classmethod
    def from_openweather_dict(cls, data: Dict[str, Any]):
        return cls(
            name=data.get("name", ""),
            lat=data.get("lat", 0),
            lon=data.get("lon", 0),
            country=data.get("country", ""),
            state=data.get("state"),
            local_names=data.get("local_names"),
        )

class WeatherData(BaseModel):
    temperature: float = Field(..., description="temp in celsius", ge=-50, le=60)
    humidity: float = Field(..., ge=0, le=100)
    rainfall: float = Field(..., description="rain in mm", ge=0)
    wind_speed: float = Field(..., description="wind in km/h", ge=0)
    pressure: Optional[float] = Field(None, description="pressure in hpa")
    date: Optional[datetime] = Field(default_factory=datetime.now)
    
    @validator('temperature')
    def validate_temperature(cls, v):
        if v < -50 or v > 60:
            raise ValueError("Temperature must be between -50 and 60 Celsius")
        return v

# Example
# "temperature": 25.5,
# "humidity": 65.0,
# "rainfall": 10.0,
# "wind_speed": 15.0,
# "pressure": 1013.25


class CropRecommendation(BaseModel):
    crop_name: str = Field(...)
    confidence: float = Field(..., description="score (0-1)", ge=0, le=1)
    reasoning: str = Field(...)
    optimal_conditions: dict = Field(...)
    
# Example
# "crop_name": "Wheat",
# "confidence": 0.85,
# "reasoning": "Current weather conditions are optimal for wheat cultivation",
# "optimal_conditions": {
#     "temperature_range": "15-25°C",
#     "humidity_range": "50-70%",
#     "rainfall_range": "500-900mm"
# }


class AdvisoryResult(BaseModel):
    recommendation: str = Field(...)
    risk_level: str = Field(..., description="low, medium, high")
    crop_recommendations: List[CropRecommendation] = Field(default_factory=list)
    weather_analysis: dict = Field(...)
    timestamp: datetime = Field(default_factory=datetime.now)
    
    @validator('risk_level')
    def validate_risk_level(cls, v):
        if v.lower() not in ['low', 'medium', 'high']:
            raise ValueError("Risk level must be 'low', 'medium', or 'high'")
        return v.lower()
 
# Example
# "recommendation": "Proceed with planting. Weather conditions are favorable.",
# "risk_level": "low",
# "crop_recommendations": [],
# "weather_analysis": {
#     "temperature_status": "optimal",
#     "humidity_status": "optimal",
#     "rainfall_status": "adequate"
# } 