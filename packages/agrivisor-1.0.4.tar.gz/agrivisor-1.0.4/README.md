# AgriVisor - OpenWeather API Integration Library

A library for fetching weather data from OpenWeather APIs, designed for ease of use and to provide easy details

## Features

- **Current Weather** - Get real-time weather data for any location
- **Hourly Forecast** - 4-day hourly weather forecast (96 hours)
- **Daily Forecast** - 16-day daily weather forecast
- **Air Pollution** - Current air quality and pollution data
- **Geocoding** - Convert city names to coordinates and vice versa

## Installation

```bash
pip install agrivisor
```

## Quick Start

```python
from agrivisor import OpenWeatherClient

# Initialize the client with your API key
client = OpenWeatherClient(api_key="your_api_key_here")

# Get current weather for Dublin, Ireland
weather = client.get_current_weather(lat=53.3498, lon=-6.2603)
print(f"Temperature: {weather.temperature}°C")
print(f"Humidity: {weather.humidity}%")
print(f"Weather: {weather.weather_description}")
```

**Key Methods:**

All methods support both coordinate-based and city name-based lookups:

- `get_current_weather(lat, lon)` or `get_current_weather(city_name, country_code)` - Get current weather
- `get_hourly_forecast(lat, lon, cnt)` or `get_hourly_forecast(city_name, country_code, cnt)` - Get hourly forecast (4 days)
- `get_daily_forecast(lat, lon, cnt)` or `get_daily_forecast(city_name, country_code, cnt)` - Get daily forecast (16 days)
- `get_air_pollution(lat, lon)` or `get_air_pollution(city_name, country_code)` - Get air pollution data
- `geocode(city_name, state_code, country_code, limit)` - Convert city name to coordinates
- `reverse_geocode(lat, lon, limit)` - Convert coordinates to city name
- `get_weather_snapshot(lat, lon)` or `get_weather_snapshot(city_name, country_code)` - Get simplified weather for quick view dashboard or cards
- `is_raining(lat, lon)` or `is_raining(city_name, country_code)` - Check if it's raining, returns a boolean
- `get_weather_summary(lat, lon)` or `get_weather_summary(city_name, country_code)` - Get human-readable summary in a text comma separated


## API Endpoints Used

- **Current Weather**: `/data/2.5/weather`
- **Hourly Forecast (4 days)**: `/data/2.5/forecast`
- **Daily Forecast (16 days)**: `/data/3.0/onecall`
- **Air Pollution**: `/data/2.5/air_pollution`
- **Geocoding**: `/geo/1.0/direct` and `/geo/1.0/reverse`

