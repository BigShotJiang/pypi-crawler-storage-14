﻿import torch
import torch.nn as nn
import warnings
import logging
from typing import Optional, Dict, Any


# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



class Reversible(nn.Module):
    """AUREON: Universal Reversible Learning Framework - PRODUCTION GRADE"""

    K_CHARGE = 0.56
    K_DISCHARGE = 0.337
    K_RECHARGE = 0.57

    def __init__(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        device: str = 'cuda',
        use_holonomy: bool = True,
        validate_on_init: bool = True
    ):
        """
        Initialize AUREON reversible learning framework.

        Args:
            model: PyTorch model (any architecture)
            optimizer: Optimizer (auto-created if None)
            device: 'cuda' or 'cpu'
            use_holonomy: Enable advanced physics
            validate_on_init: Validate inputs

        Raises:
            TypeError: If model is not nn.Module
            RuntimeError: If device is invalid
        """
        super().__init__()

        # Input validation
        if not isinstance(model, nn.Module):
            raise TypeError(f"model must be nn.Module, got {type(model)}")

        # Device validation
        if device == 'cuda' and not torch.cuda.is_available():
            logger.warning("CUDA requested but not available, falling back to CPU")
            device = 'cpu'

        if device not in ['cuda', 'cpu']:
            raise ValueError(f"device must be 'cuda' or 'cpu', got {device}")

        self.model = model.to(device)
        self.device = device
        self.optimizer = optimizer or torch.optim.AdamW(model.parameters(), lr=1e-4)
        self.criterion = nn.CrossEntropyLoss()
        self.k_current = self.K_CHARGE
        self.phase = 'IDLE'
        self.metrics = {'before': {}, 'after': {}, 'recovery_ratio': 0.0}

        # NEW: Auto-detect architecture (v0.2.8)
        self.is_cnn = any(isinstance(m, (nn.Conv2d, nn.Conv1d, nn.Conv3d))
                          for m in model.modules())

        # Validation flags
        self._has_trained = False
        self._has_unlearned = False
        self._convergence_threshold = 0.01

        print(f'✓ Reversible initialized')
        print(f'  k_charge={self.K_CHARGE}')
        print(f'  k_discharge={self.K_DISCHARGE}')
        print(f'  k_recharge={self.K_RECHARGE}')

    def _validate_dataloader(self, dataloader, name: str = "dataloader"):
        """Validate dataloader is not empty and has correct format"""
        try:
            iterator = iter(dataloader)
            batch = next(iterator)

            if isinstance(batch, dict):
                if 'input_ids' not in batch or 'label' not in batch:
                    raise ValueError(f"{name}: Dict batch missing required keys")
            elif isinstance(batch, (tuple, list)):
                if len(batch) != 2:
                    raise ValueError(f"{name}: Tuple batch must have exactly 2 elements")
            else:
                raise TypeError(f"{name}: Batch must be dict or tuple, got {type(batch)}")

            logger.debug(f"{name} validated: {type(batch).__name__} format")
            return True

        except StopIteration:
            raise ValueError(f"{name} is empty!")
        except Exception as e:
            raise RuntimeError(f"{name} validation failed: {str(e)}")

    def _check_convergence(self, loss_history, threshold=None):
        """Check if model is learning (loss decreasing)"""
        if len(loss_history) < 2:
            return True

        threshold = threshold or self._convergence_threshold
        improvement = (loss_history[-2] - loss_history[-1]) / max(loss_history[-2], 1e-8)

        if improvement < -0.1:  # Loss increasing
            logger.warning(f"⚠️  Loss diverging: {improvement:.4f}")
            return False

        return True

    def _safe_forward(self, inputs, is_dict=False):
        """Safely run forward pass with error handling"""
        try:
            if is_dict:
                return self.model(**inputs)
            else:
                return self.model(inputs)
        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                raise RuntimeError(f"GPU out of memory! Try smaller batch size or model")
            raise

    def charge(self, dataloader, num_epochs=1, verbose=True) -> float:
        """
        CHARGE PHASE: Standard training

        Args:
            dataloader: Training data
            num_epochs: Number of epochs
            verbose: Print progress

        Returns:
            Accuracy on training set
        """
        # Validate
        self._validate_dataloader(dataloader, "charge dataloader")

        print(f'\n🔋 CHARGE PHASE')
        self.phase = 'CHARGE'
        self.model.train()

        total_loss = total_correct = total_samples = 0
        loss_history = []

        try:
            for epoch in range(num_epochs):
                epoch_loss = 0
                for batch_idx, batch in enumerate(dataloader):
                    # Handle batch format
                    if isinstance(batch, dict):
                        inputs = {
                            'input_ids': batch['input_ids'].to(self.device),
                            'attention_mask': batch['attention_mask'].to(self.device)
                        }
                        labels = batch['label'].to(self.device)
                        is_dict = True
                    else:
                        inputs, labels = batch
                        inputs, labels = inputs.to(self.device), labels.to(self.device)
                        is_dict = False

                    self.optimizer.zero_grad()

                    # Forward pass
                    outputs = self._safe_forward(inputs, is_dict)
                    logits = outputs.logits if hasattr(outputs, 'logits') else outputs

                    # Loss & backward
                    loss = self.criterion(logits, labels)
                    if torch.isnan(loss):
                        raise ValueError("NaN loss detected in CHARGE phase!")

                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    self.optimizer.step()

                    # Metrics
                    epoch_loss += loss.item()
                    total_loss += loss.item()
                    pred = logits.argmax(1)
                    total_correct += (pred == labels).sum().item()
                    total_samples += labels.size(0)

                loss_history.append(epoch_loss / len(dataloader))
                self._check_convergence(loss_history)

        except Exception as e:
            logger.error(f"CHARGE phase failed: {str(e)}")
            raise

        acc = 100 * total_correct / total_samples
        if verbose:
            print(f'  Epochs: {num_epochs}, Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%')

        self.metrics['before']['acc'] = acc
        self._has_trained = True
        return acc

    def discharge(self, dataloader, num_epochs=1, verbose=False):
        """DISCHARGE phase: Unlearn specific data"""
        self._validate_dataloader(dataloader, "discharge dataloader")

        print(f'\n⚡ DISCHARGE PHASE')
        self.phase = 'DISCHARGE'
        self.model.train()

        total_loss = total_correct = total_samples = 0

        try:
            for epoch in range(num_epochs):
                for batch in dataloader:
                    # Handle batch format
                    if isinstance(batch, dict):
                        inputs = {
                            'input_ids': batch['input_ids'].to(self.device),
                            'attention_mask': batch['attention_mask'].to(self.device)
                        }
                        labels = batch['label'].to(self.device)
                        is_dict = True
                    else:
                        inputs, labels = batch
                        inputs, labels = inputs.to(self.device), labels.to(self.device)
                        is_dict = False

                    self.optimizer.zero_grad()

                    # Forward pass
                    outputs = self._safe_forward(inputs, is_dict)
                    logits = outputs.logits if hasattr(outputs, 'logits') else outputs

                    loss = self.criterion(logits, labels)
                    if torch.isnan(loss):
                        raise ValueError("NaN loss detected in DISCHARGE phase!")

                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)

                    # Apply k_discharge (v0.2.8: gentler for CNN)
                    scale = 0.5 if self.is_cnn else 1.0  # NEW: CNN-aware scaling
                    for param in self.model.parameters():
                        if param.grad is not None:
                            param.grad *= -1 * self.K_DISCHARGE * scale  # CHANGED: added scale

                    self.optimizer.step()

                    # Metrics
                    total_loss += loss.item()
                    pred = logits.argmax(1)
                    total_correct += (pred == labels).sum().item()
                    total_samples += labels.size(0)

        except Exception as e:
            logger.error(f"DISCHARGE phase failed: {str(e)}")
            raise

        acc = 100 * total_correct / total_samples
        if verbose:
            print(f'  Epochs: {num_epochs}, Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%')

        self.metrics['after']['acc'] = acc
        self._has_unlearned = True
        return acc


    def recharge(self, dataloader, num_epochs=1, verbose=True) -> float:
        """
        RECHARGE PHASE: Recovery training

        Args:
            dataloader: Training data for recovery
            num_epochs: Number of epochs
            verbose: Print progress

        Returns:
            Accuracy after recovery
        """
        if not self._has_unlearned:
            warnings.warn("RECHARGE without DISCHARGE may not be meaningful")

        self._validate_dataloader(dataloader, "recharge dataloader")

        print(f'\n🔌 RECHARGE PHASE (k={self.K_RECHARGE})')
        self.phase = 'RECHARGE'
        self.model.train()

        total_loss = total_correct = total_samples = 0

        try:
            for epoch in range(num_epochs):
                for batch in dataloader:
                    # Handle batch format
                    if isinstance(batch, dict):
                        inputs = {
                            'input_ids': batch['input_ids'].to(self.device),
                            'attention_mask': batch['attention_mask'].to(self.device)
                        }
                        labels = batch['label'].to(self.device)
                        is_dict = True
                    else:
                        inputs, labels = batch
                        inputs, labels = inputs.to(self.device), labels.to(self.device)
                        is_dict = False

                    self.optimizer.zero_grad()

                    # Forward pass
                    outputs = self._safe_forward(inputs, is_dict)
                    logits = outputs.logits if hasattr(outputs, 'logits') else outputs

                    loss = self.criterion(logits, labels)
                    if torch.isnan(loss):
                        raise ValueError("NaN loss detected in RECHARGE phase!")

                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    self.optimizer.step()

                    # Metrics
                    total_loss += loss.item()
                    pred = logits.argmax(1)
                    total_correct += (pred == labels).sum().item()
                    total_samples += labels.size(0)

        except Exception as e:
            logger.error(f"RECHARGE phase failed: {str(e)}")
            raise

        acc = 100 * total_correct / total_samples
        if verbose:
            print(f'  Epochs: {num_epochs}, Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%')
            print(f'  ✓ Recharging complete')

        return acc

    def verify(self, test_dataloader, verbose=True) -> Dict[str, float]:
        """
        VERIFY PHASE: Measure recovery

        Args:
            test_dataloader: Test data
            verbose: Print progress

        Returns:
            Dictionary with before_acc, after_acc, test_acc, recovery_ratio
        """
        self._validate_dataloader(test_dataloader, "verify dataloader")

        print(f'\n✅ VERIFICATION PHASE')
        self.model.eval()

        total_correct = total_samples = 0

        try:
            with torch.no_grad():
                for batch in test_dataloader:
                    # Handle batch format
                    if isinstance(batch, dict):
                        inputs = {
                            'input_ids': batch['input_ids'].to(self.device),
                            'attention_mask': batch['attention_mask'].to(self.device)
                        }
                        labels = batch['label'].to(self.device)
                        is_dict = True
                    else:
                        inputs, labels = batch
                        inputs, labels = inputs.to(self.device), labels.to(self.device)
                        is_dict = False

                    outputs = self._safe_forward(inputs, is_dict)
                    logits = outputs.logits if hasattr(outputs, 'logits') else outputs
                    pred = logits.argmax(1)
                    total_correct += (pred == labels).sum().item()
                    total_samples += labels.size(0)

        except Exception as e:
            logger.error(f"VERIFY phase failed: {str(e)}")
            raise

        test_acc = 100 * total_correct / total_samples
        before_acc = self.metrics['before'].get('acc', 0)
        after_acc = self.metrics['after'].get('acc', 0)

        # Calculate recovery ratio with safeguards
        if before_acc > after_acc and before_acc > 0:
            denominator = before_acc - after_acc
            recovery_ratio = (test_acc - after_acc) / denominator
            # Clamp to valid range
            recovery_ratio = max(0, min(recovery_ratio, 1.0))
        else:
            logger.warning("⚠️  Invalid recovery (before_acc <= after_acc)")
            recovery_ratio = 0.0

        if verbose:
            print(f'  Before: {before_acc:.2f}%, After: {after_acc:.2f}%, Test: {test_acc:.2f}%')
            print(f'  Recovery Ratio: {recovery_ratio:.4f}')

        self.metrics['recovery_ratio'] = recovery_ratio

        return {
            'before_acc': before_acc,
            'after_acc': after_acc,
            'test_acc': test_acc,
            'recovery_ratio': recovery_ratio
        }