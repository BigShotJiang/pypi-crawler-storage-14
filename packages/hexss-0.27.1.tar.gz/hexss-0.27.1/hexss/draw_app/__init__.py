import hexss

hexss.check_packages('Flask', 'opencv-python', 'numpy', auto_install=True)
