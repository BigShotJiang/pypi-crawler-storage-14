import hexss
from hexss.env import unset_proxy, set_proxy

unset_proxy()
hexss.check_packages('fastapi', 'uvicorn', 'asyncssh', auto_install=True)

import asyncio
import json
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import asyncssh
import os

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
async def index():
    return HTMLResponse(open("static/index.html", "r", encoding="utf-8").read())


async def bridge_process_ws(proc, websocket: WebSocket):
    """
    Read stdout from SSH process and send to websocket.
    Also read messages from websocket and write to proc.stdin.
    """

    async def read_stdout():
        try:
            while True:
                data = await proc.stdout.read(1024)
                if not data:
                    break
                # Send binary/text as-is to frontend (xterm expects text)
                await websocket.send_text(data)
        except Exception:
            pass

    async def read_ws():
        try:
            while True:
                msg = await websocket.receive_text()
                # msg will be JSON with action/key (see client)
                try:
                    payload = json.loads(msg)
                except Exception:
                    payload = {"action": "input", "data": msg}

                action = payload.get("action", "input")
                if action == "input":
                    data = payload.get("data", "")
                    # write bytes
                    proc.stdin.write(data)
                    await proc.stdin.drain()
                elif action == "resize":
                    cols = int(payload.get("cols", 80))
                    rows = int(payload.get("rows", 24))
                    try:
                        await proc.set_pty_size(cols, rows)
                    except Exception:
                        # not all process objects support this; ignore
                        pass
                else:
                    # unknown action
                    pass
        except WebSocketDisconnect:
            pass
        except Exception:
            pass

    t1 = asyncio.create_task(read_stdout())
    t2 = asyncio.create_task(read_ws())
    done, pending = await asyncio.wait([t1, t2], return_when=asyncio.FIRST_COMPLETED)
    for p in pending:
        p.cancel()


@app.websocket("/ws/ssh")
async def websocket_ssh(ws: WebSocket):
    """
    WebSocket endpoint that expects a JSON connect message first:
      {"host":"1.2.3.4","username":"user","password":"secret","cols":80,"rows":24}
    (You can also use key auth — see comments below.)
    """
    await ws.accept()
    try:
        msg = await ws.receive_text()
    except WebSocketDisconnect:
        return

    try:
        connect_info = json.loads(msg)
        host = connect_info["host"]
        username = connect_info.get("username")
        password = connect_info.get("password")
        port = int(connect_info.get("port", 22))
        cols = int(connect_info.get("cols", 80))
        rows = int(connect_info.get("rows", 24))
        # optional: path to private key (PEM) content or file
        pkey = connect_info.get("pkey")  # string of private key (optional)
    except Exception:
        await ws.send_text("Invalid connect message. Expected JSON with host/username.")
        await ws.close()
        return

    conn = None
    proc = None
    try:
        # If using private key string, write temp file (optional)
        conn_kwargs = {"host": host, "port": port, "username": username}
        if password:
            conn_kwargs["password"] = password
        elif pkey:
            # write temporary key file (safer to use file-based key in production)
            key_path = ".temp_key.pem"
            with open(key_path, "w", encoding="utf-8") as f:
                f.write(pkey)
            os.chmod(key_path, 0o600)
            conn_kwargs["client_keys"] = [key_path]
        else:
            # try agent or default keys
            conn_kwargs["known_hosts"] = None  # skip known_hosts check (dev only)
            # may still need agent or default key file

        # Connect
        conn = await asyncssh.connect(**conn_kwargs)
        # Start interactive shell with PTY
        proc = await conn.create_process(term_type="xterm", term_size=(cols, rows))
        # Bridge asyncssh process and websocket
        await bridge_process_ws(proc, ws)

    except Exception as e:
        await ws.send_text(f"\r\n*** SSH ERROR: {e}\r\n")
    finally:
        try:
            if proc:
                proc.stdin.close()
                proc.stdout.close()
        except Exception:
            pass
        if conn:
            conn.close()
            try:
                await conn.wait_closed()
            except Exception:
                pass
        await ws.close()


