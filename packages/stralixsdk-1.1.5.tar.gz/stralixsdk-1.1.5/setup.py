from setuptools import setup, find_packages

setup(
    name="stralixsdk",
    version="1.1.5",
    description="Official Python SDK for Stralix Cloud SCNAC API",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Stralix Cloud",
    author_email="support@stralix.cloud",
    url="https://stralix.cloud",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
