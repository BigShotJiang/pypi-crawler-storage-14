import logging
import os
import shutil
import subprocess
from py_node_manager import get_logger, NodeManager
from typing import Any, Dict, List, Literal, Optional
from typing_extensions import Self


logger = get_logger(logging.getLogger(__name__))


def dict_to_js_object(d: Dict[Any, Any], indent: int = 0) -> str:
    """
    Convert a Python dictionary to a JavaScript object string representation.

    Args:
        d (Dict[Any, Any]): Dictionary to convert
        indent (int): Current indentation level

    Returns:
        str: JavaScript object string representation
    """
    if not d:
        return '{}'

    indent_str = '  ' * indent
    next_indent_str = '  ' * (indent + 1)

    items = []
    for key, value in d.items():
        if isinstance(value, dict):
            items.append(f'{next_indent_str}{key}: {dict_to_js_object(value, indent + 1)}')
        elif isinstance(value, str):
            items.append(f'{next_indent_str}{key}: "{value}"')
        elif isinstance(value, bool):
            items.append(f'{next_indent_str}{key}: {"true" if value else "false"}')
        elif isinstance(value, (int, float)):
            items.append(f'{next_indent_str}{key}: {value}')
        elif isinstance(value, list):
            # Convert list to JavaScript array
            array_items = []
            for item in value:
                if isinstance(item, dict):
                    array_items.append(dict_to_js_object(item, indent + 2))
                elif isinstance(item, str):
                    array_items.append(f'"{item}"')
                elif isinstance(item, bool):
                    array_items.append('true' if item else 'false')
                elif isinstance(item, (int, float)):
                    array_items.append(str(item))
                else:
                    array_items.append(str(item))
            items.append(f'{next_indent_str}{key}: [{", ".join(array_items)}]')
        else:
            items.append(f'{next_indent_str}{key}: {value}')

    return '{\n' + ',\n'.join(items) + f'\n{indent_str}}}'


class TailwindCommand:
    def __init__(
        self,
        tailwind_version: Literal['3', '4'],
        content_path: List[str],
        plugin_tmp_dir: str,
        input_css_path: str,
        output_css_path: str,
        config_js_path: str,
        is_cli: bool,
        download_node: bool,
        node_version: str,
        theme_config: Optional[Dict[Any, Any]] = None,
    ):
        """
        Initialize the TailwindCommand class

        Args:
            tailwind_version (Literal['3', '4']): Version of Tailwind CSS
            content_path (List[str]): List of paths to content files
            input_css_path (str): Path to input CSS file
            output_css_path (str): Path to output CSS file
            config_js_path (str): Path to Tailwind config file
            is_cli (bool): Whether the command is being run from the CLI
            download_node (bool): Whether to download Node.js if not found
            node_version (str): Node.js version to download if download_node is True
            theme_config (Optional[Dict[Any, Any]]): Custom theme configuration for Tailwind CSS
        """
        node_manager = NodeManager(download_node=download_node, node_version=node_version, is_cli=is_cli)
        self.node_path = node_manager.node_path
        self.node_env = node_manager.node_env
        self.npm_path = node_manager.npm_path
        self.npx_path = node_manager.npx_path
        self.tailwind_version = tailwind_version
        self.content_path = content_path
        self.input_css_path = input_css_path
        self.output_css_path = output_css_path
        self.config_js_path = config_js_path
        self.is_cli = is_cli
        self.theme_config = theme_config or {}
        # Ensure the tailwind_plugin directory exists
        self.plugin_tmp_dir = plugin_tmp_dir
        if not os.path.exists(self.plugin_tmp_dir):
            os.makedirs(self.plugin_tmp_dir)

    def create_default_input_tailwindcss(self):
        """
        Create a default input CSS file

        Returns:
            None
        """
        # Ensure assets directory exists
        assets_dir = os.path.dirname(self.input_css_path)
        if assets_dir and not os.path.exists(assets_dir):
            os.makedirs(assets_dir)

        if self.tailwind_version == '3':
            input_css_content = """@tailwind base;
@tailwind components;
@tailwind utilities;
"""
        else:
            input_css_content = """@import "tailwindcss";"""
        with open(self.input_css_path, 'w') as f:
            f.write(input_css_content)

    def create_default_tailwindcss_config(self):
        """
        Create a default Tailwind config file

        Returns:
            None
        """
        # Convert list of content paths to JSON array format
        content_paths_str = ', '.join([f'"{path}"' for path in self.content_path])

        # Handle theme configuration
        if self.theme_config:
            theme_str = dict_to_js_object(self.theme_config, 2)
            # Ensure theme_str is properly indented within the config
            theme_lines = theme_str.split('\n')
            indented_theme_lines = ['    ' + line if line.strip() else line for line in theme_lines]
            theme_str = '\n'.join(indented_theme_lines)
        else:
            theme_str = '{}'

        config_content = f"""module.exports = {{
    content: [{content_paths_str}],
    theme: {{
        extend: {theme_str},
    }},
    plugins: [],
}}
"""

        # Ensure config directory exists
        config_dir = os.path.dirname(self.config_js_path)
        if config_dir and not os.path.exists(config_dir):
            os.makedirs(config_dir)

        with open(self.config_js_path, 'w') as f:
            f.write(config_content)

    @property
    def _tailwind_cli(self) -> Literal['tailwindcss', '@tailwindcss/cli']:
        """
        Get the name of the Tailwind CSS command to use

        Returns:
            Literal['tailwindcss', '@tailwindcss/cli']: Name of the Tailwind CSS command to use
        """
        if self.tailwind_version == '3':
            return 'tailwindcss'
        else:
            return '@tailwindcss/cli'

    @property
    def _tailwind_package(self) -> List[str]:
        """
        Get the name of the Tailwind CSS package to use

        Returns:
            List[str]: Name of the Tailwind CSS package to use
        """
        if self.tailwind_version == '3':
            return ['tailwindcss@3']
        else:
            return ['tailwindcss', '@tailwindcss/cli']

    def _check_npm_init(self) -> bool:
        """
        Check if npm init has been run

        Returns:
            bool: True if npm init has been run, False otherwise
        """
        return os.path.exists(f'{self.plugin_tmp_dir}/package.json')

    def _check_tailwindcss(self) -> bool:
        """
        Check if Tailwind CSS is installed

        Returns:
            bool: True if Tailwind CSS is installed, False otherwise
        """
        check_cmd = [self.npx_path, f'{self._tailwind_cli} --help']

        result = subprocess.run(check_cmd, capture_output=True, text=True, cwd=self.plugin_tmp_dir, env=self.node_env)
        return result.returncode == 0

    def init(self) -> Self:
        """
        Initialize Tailwind CSS

        Returns:
            Self: The TailwindCommand instance
        """
        logger.info('🚀 Start initializing Tailwind CSS...')
        try:
            # Create default config if it doesn't exist
            if self.is_cli:
                logger.info('📄 Creating input CSS file...')

            if not os.path.exists(self.input_css_path):
                if self.is_cli:
                    logger.info(
                        f'🔍 Input CSS file {self.input_css_path} not found. Creating default input CSS file...'
                    )

                self.create_default_input_tailwindcss()

                if self.is_cli:
                    logger.info(f'💾 Default input CSS file created at: {self.input_css_path}')

            # Create default input Tailwind CSS file if it doesn't exist
            if self.is_cli:
                logger.info('⚙️ Creating Tailwind config...')

            if not os.path.exists(self.config_js_path):
                if self.is_cli:
                    logger.info(f'🔍 Config file {self.config_js_path} not found. Creating default config file...')

                self.create_default_tailwindcss_config()

                if self.is_cli:
                    logger.info(f'💾 Default config file created at: {self.config_js_path}')

            if not self._check_npm_init():
                init_cmd = [self.npm_path, 'init', '-y']
                result = subprocess.run(
                    init_cmd, capture_output=True, text=True, cwd=self.plugin_tmp_dir, env=self.node_env
                )
                if result.returncode != 0:
                    raise RuntimeError(result.stderr)

            logger.info('✅ Tailwind CSS initialized successfully!')

        except Exception as e:
            logger.error(f'❌ Error initializing Tailwind CSS: {e}')
            raise e

        return self

    def install(self) -> Self:
        """
        Install Tailwind CSS

        Returns:
            Self: The TailwindCommand instance
        """
        logger.info('📥 Start installing Tailwind CSS...')
        try:
            if not self._check_tailwindcss():
                install_cmd = [
                    self.npm_path,
                    'install',
                    '-D',
                    *self._tailwind_package,
                ]
                result = subprocess.run(
                    install_cmd, capture_output=True, text=True, cwd=self.plugin_tmp_dir, env=self.node_env
                )
                if result.returncode != 0:
                    raise RuntimeError(result.stderr)

            logger.info('✅ Tailwind CSS installed successfully!')

        except Exception as e:
            logger.error(f'❌ Error installing Tailwind CSS: {e}')
            raise e

        return self

    def build(self) -> Self:
        """
        Build the Tailwind CSS

        Returns:
            Self: The TailwindCommand instance
        """
        logger.info(f'🔨 Building Tailwind CSS from {self.input_css_path} to {self.output_css_path}...')
        try:
            build_cmd: list[str] = [
                self.npx_path,
                f'{self.plugin_tmp_dir}/node_modules/{self._tailwind_cli}',
                '-i',
                self.input_css_path,
                '-o',
                self.output_css_path,
                '-c',
                self.config_js_path,
            ]

            result = subprocess.run(build_cmd, capture_output=True, text=True, env=self.node_env)

            if result.returncode != 0:
                raise RuntimeError(result.stderr)

            logger.info('✅ Build completed successfully!')
            logger.info(f'🎨 Tailwind CSS built successfully to {self.output_css_path}')

        except Exception as e:
            logger.error(f'❌ Error building Tailwind CSS: {e}')
            raise e

        return self

    def watch(self) -> Self:
        """
        Watch for changes in the input CSS file and rebuild Tailwind CSS

        Returns:
            Self: The TailwindCommand instance
        """
        logger.info(f'👀 Watching for changes in {self.input_css_path}...')
        try:
            watch_cmd = [
                self.npx_path,
                f'{self.plugin_tmp_dir}/node_modules/{self._tailwind_cli}',
                '-i',
                self.input_css_path,
                '-o',
                self.output_css_path,
                '-c',
                self.config_js_path,
                '--watch',
            ]
            subprocess.run(watch_cmd, env=self.node_env)

        except KeyboardInterrupt:
            logger.info('👋 Watch stopped.')

        except Exception as e:
            logger.error(f'❌ Error watching for changes: {e}')
            raise e

        return self

    def clean(self) -> Self:
        """
        Clean up generated files to keep directory clean

        Returns:
            Self: The TailwindCommand instance
        """
        logger.info('🧹 Cleaning up generated files...')
        try:
            files_to_remove = [
                self.config_js_path,
                f'{self.plugin_tmp_dir}/package.json',
                f'{self.plugin_tmp_dir}/package-lock.json',
                self.input_css_path,
            ]

            directories_to_remove = [f'{self.plugin_tmp_dir}/node_modules']

            # Remove files
            for file_path in files_to_remove:
                if os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                        if self.is_cli:
                            logger.info(f'🗑️ Removed {file_path}')
                    except Exception as e:
                        logger.warning(f'⚠️ Warning: Could not remove {file_path}: {e}')

            # Remove directories
            for dir_path in directories_to_remove:
                if os.path.exists(dir_path):
                    try:
                        shutil.rmtree(dir_path)
                        if self.is_cli:
                            logger.info(f'🗑️ Removed {dir_path}')
                    except Exception as e:
                        logger.warning(f'⚠️ Warning: Could not remove {dir_path}: {e}')

            logger.info('✅ Cleanup completed.')

        except Exception as e:
            logger.error(f'❌ Error cleaning up: {e}')
            raise e

        return self
