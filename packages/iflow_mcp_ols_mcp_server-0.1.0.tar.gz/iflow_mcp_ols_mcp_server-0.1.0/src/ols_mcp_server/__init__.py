"""OLS MCP Server - Model Context Protocol server for Ontology Lookup Service."""

__version__ = "0.1.0"
