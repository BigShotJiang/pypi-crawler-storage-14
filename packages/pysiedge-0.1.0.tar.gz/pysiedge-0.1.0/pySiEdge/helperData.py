# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

import numpy as np

__all__ = ["speedFromAngleSP1"]

def speedFromAngleSP1(angle, fs, fitElem=10):
	"""
	Errechne Spindelgeschwindigkeit (in rpm) aus Winkelposition (in °) und Samplingfrequenz (in 1/s).
	Parameters
	----------
	angle : np.ndarray
		1D-Array mit Winkelpositionen in Grad
	fs : float
		Samplingfrequenz in 1/s
	fitElem : int, optional
		Anzahl der Messpunkte, aus denen die Geschwindigkeit für t=0 extrapoliert wird

	Returns
	-------
	np.ndarray
		1D-Array mit Spindelgeschwindigkeit in rpm
	"""

	speedSP1 = np.concat((np.atleast_1d(0), np.diff(angle)))	# Spindelgeschwindigkeit in Grad pro Zyklustick
	speedSP1 = speedSP1 * fs / 360 * 60							#	umrechnen in rpm

	coeff = np.polynomial.polynomial.polyfit(np.arange(1,fitElem+1), speedSP1[1:fitElem + 1], 1)	# Koeffizienten für linearen Fit aus ersten "fitElem" Werten ermitteln
	speedSP1[0] =np.polynomial.polynomial.polyval(0, coeff)	# ersten Geschwindigkeitswert mit gefundenen Koeffizienten extrapolieren

	idxOutlier = np.where(np.diff(np.sign(speedSP1)))[0]			# Indizes des jeweils letzten Werts vor einer Geschwindigkeitsänderung ermitteln
	for a in range(idxOutlier.size):
		if np.isin((idxOutlier[a]+1), idxOutlier, kind='table'):	#	und für jeden dieser Indizes prüfen, ob im nächsten Zyklustick eine Geschwindigkeitsänderung mit anderem Vorzeichen erfolgt
			speedSP1[idxOutlier[a] + 1] = speedSP1[idxOutlier[a]]	#	falls ja, den Geschwindigkeitsausreißer mit dem Geschwindigkeitswert des vorherigen Zyklusticks überschreiben
	return speedSP1
