# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zur Kommunikation mit 'Analyze MyWorkpiece /Capture4Analysis' mittels HTTP-Requests."""

import requests

import warnings
from urllib3.exceptions import InsecureRequestWarning

__all__ = ["_helperGET", "_helperDELETE"]

def _filterCertWarning(helperFun):
	"""Decorator-Funktion zum Filtern von Zertifikatswarnungen der HTTP-Requests."""
	def wrapper(*args, **kwargs):
		with warnings.catch_warnings():
			if ('certVerify' in kwargs) and (kwargs['certVerify'] is False):
				warnings.simplefilter('ignore', category=InsecureRequestWarning)
			return helperFun(*args, **kwargs)
	return wrapper


@_filterCertWarning
def _helperGET(query: str,
			   certPath: str,
			   certVerify: str | bool = True,
			   json: bool = True,
			   session: requests.Session | None = None
) -> bytes | list[dict]:
	"""
	Schickt eine "HTTP GET"-Anfrage mit Zertifikatsauthentifizierung und gibt die Antwort zurück.

	Parameters
	----------
	query : str
		Inhalt der zu sendenden Anfrage
	certPath : str
		Pfad zum Nutzerzertifikat für die Authentifizierung
	certVerify : str | bool, default=True
		(De-)aktiviert Verifikation des Serverzertifikats. Pfad zum CA-Zertifikat des Siemens Industrial Edge Device
		als ``str``, ``True`` für Verifikation durch interne CA-Zertifikate von ``request`` oder ``False`` zum
		Deaktivieren der Zertifikatsprüfung.
		Standardwert ist ``True``
	json : bool, default=True
		Ausgabe als JSON parsen und als ``list[dict]`` ausgeben. Falls ``json=False`` ist der Ausgabetyp ``bytes``.
		Standardwert ist ``True``
	session : requests.Session | None, default=None
		Aktive ``requests.Session`` nutzen. Falls ``None`` wird eine temporäre Session für die Anfrage erstellt.
		Standardwert ist ``None``

	Returns
	-------
	bytes | list[dict]
		Die Antwort auf die Anfrage. Gibt eine ``list[dict]`` zurück, wenn ``json=True``. Gibt ``bytes`` zurück,
		wenn ``json=False``
	"""

	if session is None:	# neue temporäre Session öffnen
		responseRaw = requests.get(query, cert=certPath, verify=certVerify)
	else:	# bestehende Session nutzen
		responseRaw = session.get(query, cert=certPath, verify=certVerify)
	responseRaw.raise_for_status()	# prüfen, ob request ohne Fehler abgeschlossen wurde

	if json:
		responseJson = responseRaw.json()	# response als JSON parsen
		if isinstance(responseJson, dict):	# response immer als list[dict] ausgeben
			responseJson = [responseJson]
		return responseJson
	else:
		return responseRaw.content	# response als Bytes ausgeben


@_filterCertWarning
def _helperDELETE(query: str,
				  certPath: str,
				  certVerify: str | bool = True,
				  session: requests.Session | None = None
) -> None:
	"""
	Schickt eine "HTTP DELETE"-Anfrage mit Zertifikatsauthentifizierung.

	Parameters
	----------
	query : str
		Inhalt der zu sendenden Anfrage
	certPath : str
		Pfad zum Nutzerzertifikat für die Authentifizierung
	certVerify : str | bool, default=True
		(De-)aktiviert Verifikation des Serverzertifikats. Pfad zum CA-Zertifikat des Siemens Industrial Edge Device
		als ``str``, ``True`` für Verifikation durch interne CA-Zertifikate von ``request`` oder ``False`` zum
		Deaktivieren der Zertifikatsprüfung.
		Standardwert ist ``True``
	session : requests.Session | None, default=None
		Aktive ``requests.Session`` nutzen. Falls ``None`` wird eine temporäre Session für die Anfrage erstellt.
		Standardwert ist ``None``

	Returns
	-------
	None
	"""

	if session is None:	# neue temporäre Session öffnen
		responseRaw = requests.delete(query, cert=certPath, verify=certVerify)	# Löschen ausführen
	else:	# bestehende Session nutzen
		responseRaw = session.delete(query, cert=certPath, verify=certVerify)
	responseRaw.raise_for_status()	# prüfen, ob request ohne Fehler abgeschlossen wurde
