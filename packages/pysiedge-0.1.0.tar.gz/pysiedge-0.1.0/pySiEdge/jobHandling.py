# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zum Abruf der Jobs von 'Analyze MyWorkpiece /Capture4Analysis' sowie deren Dateien."""

import hashlib
import logging
import math
import requests
from io import BytesIO
from os.path import join as pjoin

from .helperHTTP import *
from .helperFiles import fixC4AFileTime

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.WARNING)

__all__ = ["getAvailableJobs", "selectJobs", "getJobFiles"]

def getAvailableJobs(edgeAddress: str,
					 certPath: str,
					 certVerify: str | bool = True,
					 session: requests.Session | None = None,
					 verbose: bool = False,
) -> list[dict]:
	"""
	Fragt die auf dem Siemens Industrial Edge Device in "Analyze MyWorkpiece /Capture4Analysis" existierenden Jobs ab.

	Parameters
	----------
	edgeAddress : str
		Adresse des Siemens Industrial Edge Device im Netzwerk
	certPath : str
		Pfad zum Nutzerzertifikat für die Authentifizierung
	certVerify : str | bool, default=True
		(De-)aktiviert Verifikation des Serverzertifikats. Pfad zum CA-Zertifikat des Siemens Industrial Edge Device
		als ``str``, ``True`` für Verifikation durch interne CA-Zertifikate von ``request`` oder ``False`` zum
		Deaktivieren der Zertifikatsprüfung.
		Standardwert ist ``True``
	session : requests.Session | None, default=None
		Aktive ``requests.Session`` nutzen. Falls ``None`` wird eine temporäre Session für die Anfrage erstellt.
		Standardwert ist ``None``
	verbose : bool, default=False
		Aktiviert die Ausgabe der vorhandenen Jobs in der Konsole.
		Standardwert ist ``False``

	Returns
	-------
	list[dict[str, str|int]]
		auf dem Siemens Industrial Edge Device existierende Jobs, mit jeweils deren "jobId" sowie Anzahl der Runs

	Notes
	-----
	Von der REST API werden nur Jobs gemeldet, die dazugehörige Daten besitzen, also bereits mindestens einmal ausgeführt wurden.
	"""

	query = f"https://{edgeAddress}:5444/amw4analysis/job"
	availableJobs = _helperGET(query, certPath=certPath, certVerify=certVerify, json=True, session=session)

	if verbose:
		for job in availableJobs:
			print(f"ID: {job["id"]}\t{job["name"]}, {job["numberOfRuns"]} run(s)")

	return availableJobs


def selectJobs(availableJobs: list[dict[str, str | int]],
			   jobName: list[dict] | str | None = None,
) -> list[dict]:
	"""

	Parameters
	----------
	availableJobs : list[dict[str, str|int]]
		Ausgabe der Funktion ``getAvailableJobs``; auf dem Siemens Industrial Edge Device existierende Jobs
	jobName : list[dict] | str | None, default=None
		Namen der Jobs, deren Metadaten ausgegeben werden sollen. Wenn ``None`` oder leerer ``str`` werden alle Jobs berücksichtigt.
		Ein einzelner Jobname kann als ``str`` übergeben werden, mehrere Jobnamen als ``list[str]``.
		Standardwert ist ``None``

	Returns
	-------
	list[dict]
		zu den angegebenen Jobnamen gehörige Metadaten aus ``availableJobs``
	"""

	if not jobName:  # wenn kein Job spezifiziert; leerer String oder `None`
		selectedJobs = availableJobs
	else:
		selectedJobs = list()
		if isinstance(jobName, str):
			jobName = [jobName]

		for job in jobName:
			for j in range(len(availableJobs)):
				if availableJobs[j]["name"] == job:
					selectedJobs.append(availableJobs[j])
					break
				elif j == (len(availableJobs)-1):
					raise ValueError(f"Job \"{job}\" not found.")

	if isinstance(selectedJobs, dict):
		return [selectedJobs]
	else:
		return selectedJobs


def getJobFiles(edgeAddress: str,
				jobMeta: dict,
				certPath: str,
				certVerify: str | bool = True,
				filePath: str | None = None,
				fileCheck: bool = True,
				fileCheckAlgo: str | None = None,
				fixModifyDate: bool = True,
				fileDelete: bool = False,
				pageSize: int = 50,
) -> None:

	"""
	Ruft die Daten der ausgewählten Jobs vom Siemens Industrial Edge Device ab.

	Parameters
	----------
	edgeAddress : str
		Adresse des Siemens Industrial Edge Device im Netzwerk
	jobMeta : dict
		Metadaten *eines* Jobs; ein Element der Ausgabe von ``getAvailableJobs`` oder ``selectJobs``
	certPath: str
		Pfad zum Nutzerzertifikat für die Authentifizierung
	certVerify : str | bool, default=True
		(De-)aktiviert Verifikation des Serverzertifikats. Pfad zum CA-Zertifikat des Siemens Industrial Edge Device
		als ``str``, ``True`` für Verifikation durch interne CA-Zertifikate von ``request`` oder ``False`` zum
		Deaktivieren der Zertifikatsprüfung.
		Standardwert ist ``True``
	filePath : str | None, default=None
		(Ordner-)Pfad, in dem die abgerufenen Dateien abgelegt werden. Falls kein Pfad übergeben wird, werden die Dateien im aktuellen Ordner gespeichert.
		Standardwert ist ``None``
	fileCheck : bool, default=True
		(de-)aktiviert Prüfung der Prüfsumme der übertragenen Datei.
		Standardwert ist ``True``
	fileCheckAlgo : str | None, default=None
		Algorithmus der Datei-Prüfsumme. ``None`` aktiviert die automatische Erkennung, für mögliche Algorithmen siehe die Namen der Konstruktoren in der Dokumentation von `hashlib`.
		Standardwert ist ``None``
	fixModifyDate : bool, default=True
		Setzt das Änderungsdatum der abgerufenen Datei auf den im Dateinamen angegebenen Zeitpunkt (Edge-Zeit).
		Falls ``False`` entspricht das Änderungsdatum dem Zeitpunkt des Abrufs (Zeit des abrufenden Rechners).
		Das Erstelldatum entspricht in jedem Fall dem Zeitpunkt des Abrufs.
		Standardwert ist ``True``
	fileDelete : bool, default=False
		Dateien nach dem Abruf auf dem Siemens Industrial Edge Device löschen.
		Standardwert ist ``False``
	pageSize : int, default=50
		Anzahl der pro Anfrage zurückzugebenden Job- und Dateinamen. Der Wert muss zwischen 5 und 50 (einschließlich) liegen, ansonsten wird ein ValueError ausgelöst.
		Standardwert ist ``50``

	Returns
	-------
	None
	"""

	if not 5<=pageSize<=50:
		raise ValueError(f"The value of \"pageSize\" must be in the range of 5 to 50.")	# siehe Doku `A5E49004592A AH`, Seite 100
	emptyRuns = list()

	with requests.Session() as reqSess: # nicht für jede Anfrage eine neue Sitzung aushandeln
		numPagesRuns = math.ceil(jobMeta["numberOfRuns"] / pageSize)	# Anzahl der Seiten von Runs des aktuellen Jobs
		for b in reversed(range(numPagesRuns)): # absteigende Reihenfolge verhindert Überspringen von Runs,
												#	wenn eine Seite gelöscht und dann die darauffolgende angefragt wird
			query = f"https://{edgeAddress}:5444/amw4analysis/job/{jobMeta["id"]}/jobruns?page={b}&size={pageSize}"
			pageRuns = _helperGET(query, certPath=certPath, certVerify=certVerify, session=reqSess)	# Seite mit Runs abrufen

			for runMeta in pageRuns[0]["data"]:	# für jeden Run auf der aktuellen Seite mit Runs des aktuellen Jobs
				try:
					numPagesFiles = math.ceil(runMeta["numberOfFiles"] / pageSize)	# Anzahl der Seiten mit dem Run zugeordneten Dateien ermitteln
				except KeyError:	# bei Run ohne Datei fehlt auch der Key "numberOfFiles" in `page["data"]`
					tempRunId = runMeta["jobRunId"]
					if tempRunId not in emptyRuns:
						emptyRuns.append(tempRunId)
						logging.warning(f"Run \"{tempRunId}\" of Job \"{jobMeta["name"]}\" did not produce any file and will be omitted.")
						if fileDelete:	# leeren Run löschen
							_deleteRunC4A(edgeAddress=edgeAddress, jobId=jobMeta["id"], jobRunId=tempRunId, certPath=certPath, certVerify=certVerify, session=reqSess)
					continue

				for c in range(numPagesFiles):	# für jede Seite mit Dateien des aktuellen Runs
					query = f"https://{edgeAddress}:5444/amw4analysis/job/{jobMeta["id"]}/jobruns/{runMeta["jobRunId"]}/files?page={c}&size={pageSize}"
					respRunFiles = _helperGET(query, certPath=certPath, certVerify=certVerify, session=reqSess)	# Dateinamen ermitteln

					for runFile in respRunFiles[0]["data"]:	# für jede Datei auf der aktuellen Seite mit Dateien des aktuellen Runs
						query = f"https://{edgeAddress}:5444/amw4analysis/job/file?fileName={runFile["fileName"]}"
						respFile = _helperGET(query, certPath=certPath, certVerify=certVerify, json=False, session=reqSess)	# Datei abrufen

						if fileCheck:
							try:
								if not fileCheckAlgo:	# kein Prüfsummenalgorithmus übergeben
									fileCheckAlgo = runFile["checksumAlgorithm"].replace("-", "").lower()	# versuchen, Algorithmus aus Metadaten zu erkennen

								isHash = hashlib.file_digest(BytesIO(respFile), fileCheckAlgo).hexdigest()	# Prüfsumme der übertragenen Datei berechnen

								if isHash != runFile["checksum"]:
									raise IOError("Checksum mismatch.")
							except ValueError:	# wenn Algorithmus nicht erkannt werden konnte
								raise ValueError(f"The reported checksum algorithm for the file is \"{runFile["checksumAlgorithm"]}\", but the checksum algorithm could not be set automatically. "
												 "Please refer to the hashlib documentation and set \"fileCheckAlgo\" accordingly or disable checksum verification.")

						dateipfad = pjoin(filePath, f"{runFile["fileName"]}")
						with open(dateipfad, "wb") as f:	# Pfad verwenden, um Datei zu schreiben
							f.write(respFile)

						if fixModifyDate:
							fixC4AFileTime(dateipfad)	# Änderungsdatum der Datei auf Erstellzeit in der Edge setzen

				if fileDelete:	# alle Dateien des aktuellen Runs löschen
					_deleteRunC4A(edgeAddress=edgeAddress, jobId=jobMeta["id"], jobRunId=runMeta["jobRunId"], certPath=certPath, certVerify=certVerify, session=reqSess)


def _deleteRunC4A(edgeAddress: str,
				  jobId: str,
				  jobRunId: str,
				  certPath: str,
				  certVerify: str | bool = True,
				  session: requests.Session | None = None
) -> None:
	"""
	Löscht alle Dateien eines JobRuns von "Analyze MyWorkpiece /Capture4Analysis" auf dem Siemens Industrial Edge Device.

	Parameters
	----------
	edgeAddress : str
		Adresse des Siemens Industrial Edge Device im Netzwerk
	jobId : str
		ID des Jobs, dessen JobRun gelöscht werden soll. Die ID ist eigentlich ein ``int``,
		wird aber bei der Abfrage aller Jobs als ``str`` ausgegeben und auch so weiterverwendet
	jobRunId : str
		ID des JobRuns, der gelöscht werden soll.
	certPath : str
		Pfad zum Nutzerzertifikat für die Authentifizierung
	certVerify : str | bool, default=True
		(De-)aktiviert Verifikation des Serverzertifikats. Pfad zum CA-Zertifikat des Siemens Industrial Edge Device
		als ``str``, ``True`` für Verifikation durch interne CA-Zertifikate von ``request`` oder ``False`` zum
		Deaktivieren der Zertifikatsprüfung.
		Standardwert ist ``True``
	session : requests.Session | None, default=None
		Aktive ``requests.Session`` nutzen. Falls ``None`` wird eine temporäre Session für die Anfrage erstellt.
		Standardwert ist ``None``

	Returns
	-------
	None
	"""

	query = f"https://{edgeAddress}:5444/amw4analysis/job/{jobId}/run/{jobRunId}"	# request zusammenstellen
	_helperDELETE(query, certPath=certPath, certVerify=certVerify, session=session)	# request zur Ausführung übergeben
