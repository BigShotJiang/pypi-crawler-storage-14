# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zum Einlesen der Struktur von HDF5-Dateien"""

import h5py
from os import path

__all__ = ["getPathsAll", "getPathsLowest"]

def getPathsAll(fileHandle: h5py.File,
				filterPath: str = "/",
				groups: bool = False,
				datasets: bool = False,
				absolutePaths: bool = True,
) -> list[str]:
	"""
	Pfade aller Unter-Groups und/oder Datasets einer HDF5-Group ermitteln.

	Parameters
	----------
	fileHandle : h5py.File
		File handle der geöffneten Datei oder Handle einer Unter-Group.
	filterPath : str, default="/"
		Pfad in `fileHandle`, dessen Unter-Groups und/oder Datasets ermittelt werden sollen.
		Standardwert ist ``"/"``
	groups : bool, default=False
		Wenn ``True`` werden die Pfade aller Groups der Liste hinzugefügt.
		Standardwert ist ``False``
	datasets : bool, default=False
		Wenn ``True`` werden die Pfade aller Datasets der Liste hinzugefügt.
		Standardwert ist ``False``
	absolutePaths : bool, default=True
		Wenn ``True`` sind die Pfade innerhalb von `fileHandle` absolut, andernfalls sind sie relativ zu `filterPath`.
		Standardwert ist ``True``

	Returns
	-------
	list[str]
		Liste aller Pfade in `fileHandle`.
	"""
	pathList = list()	#initialisieren
	try:
		fileHandle[filterPath].visititems(lambda name, obj: _pathFromVisit(name, obj, pathList, groups=groups, datasets=datasets))	# Pfade ermitteln
	except KeyError:	# Pfad existiert nicht
		raise KeyError("Ungültige Angabe in `filterPath`.")
	if absolutePaths:
		pathList = [path.join(filterPath, p).replace(path.sep, "/") for p in pathList]	# `filterPath` jedem Pfad voranstellen und "/" als Trennzeichen sicherstellen

	return pathList


def getPathsLowest(pathList: list[str]
) -> list[str]:
	"""
	Pfade aller Unter-Groups und/oder Datasets einer HDF5-Group auf Pfade der untersten Ebene filtern.

	Parameters
	----------
	pathList : list[str]
		Liste aller Pfade in `fileHandle`. Normalerweise erstellt durch `getPathsAll`.

	Returns
	-------
	list[str]
		Liste aller Pfade der untersten Ebene in `fileHandle`.
	"""
	pathLowest = [s for s in pathList if not any((s in other) and (s != other) for other in pathList)]

	return pathLowest


def _pathFromVisit(name: str,
				   obj: h5py.Dataset | h5py.Group,
				   listNames: list[str],
				   groups: bool = False,
				   datasets: bool = False,
) -> None:
	"""
	Pfad der Group oder des Datasets `obj` ermitteln. Funktion ist zum Aufruf durch ``h5py.Group.visititems()`` mittels ``lambda`` vorgesehen, siehe Examples.

	Parameters
	----------
	name : str
		Name des Objekts, wird immer durch ``visititems()`` übergeben.
	obj : h5py.Dataset | h5py.Group
		Objekt, wird immer durch ``visititems()`` übergeben
	listNames : list[str]
		Liste, der die Pfade hinzugefügt werden.
	groups : bool, default=False
		Wenn ``True`` wird der Pfad der Liste hinzugefügt, wenn es sich um eine Group handelt.
		Standardwert ist ``False``
	datasets : bool, default=False
		Wenn ``True`` wird der Pfad der Liste hinzugefügt, wenn es sich um ein Dataset handelt.
		Standardwert ist ``False``

	Returns
	-------
	None

	Examples
	--------
	Alle in einer HDF5-Datei enthaltenen Groups ermitteln.

	>>> f = h5py.File('myfile.hdf5','r')
	>>> pathList = list()
	>>> f.visititems(lambda name, obj: _pathFromVisit(name, obj, pathList, groups=True))

	Ausgabe nur der untersten Ebene.

	>>> pathLowest = [s for s in pathList if not any((s in other) and (s != other) for other in pathList)]
	"""
	if datasets and isinstance(obj, h5py.Dataset):
		listNames.append(name)
	if groups and isinstance(obj, h5py.Group):
		listNames.append(name)
