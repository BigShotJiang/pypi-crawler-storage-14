
# versapy

### The python module versapy is the main structure of [Versapy](https://github.com/Soli-64/VersaPy), a python desktop app framework.

## <u> About </u>

#### This module manages backend server using FastAPI, Uvicorn and SocketIO. <br/> It reads configs, and run the app using PyWebVIew. <br/> The Building functionnality is only available on Windows for now. 

## <u> Usage </u>

#### This module is auto-installed in your project by the cli [create-versapy](https://github.com/Soli-64/VersaPy/tree/main/cli) while creating your versapy project. <br/> See the [github repo](https://github.com/Soli-64/VersaPy) for more infos and exemples.