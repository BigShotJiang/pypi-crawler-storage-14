'''Generic class for models that take the form of a list of rules.
'''