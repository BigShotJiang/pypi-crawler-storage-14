'''Generic class for models that take the form of a tree of rules.
'''