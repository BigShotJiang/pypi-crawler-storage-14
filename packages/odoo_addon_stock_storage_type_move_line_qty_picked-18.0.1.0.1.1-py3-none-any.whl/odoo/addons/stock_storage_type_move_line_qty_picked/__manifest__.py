# Copyright 2025 Camptocamp SA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl)

{
    "name": "stock storage type move line quantity picked",
    "version": "18.0.1.0.1",
    "development_status": "Beta",
    "category": "Warehouse Management",
    "website": "https://github.com/OCA/stock-logistics-putaway",
    "author": "Camptocamp, Odoo Community Association (OCA)",
    "maintainers": ["mmequignon"],
    "license": "AGPL-3",
    "installable": True,
    "auto_install": True,
    "depends": [
        "stock_storage_type",
        "stock_move_line_qty_picked",
    ],
}
