Glue module between `stock_storage_type` and `stock_move_line_qty_picked`,
allowing to use `stock.move.line.qty_picked` in computations.
