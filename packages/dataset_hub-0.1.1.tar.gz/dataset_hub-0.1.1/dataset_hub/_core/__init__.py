from .get_data import get_data

__all__ = ["get_data"]
