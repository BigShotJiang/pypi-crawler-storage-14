from .rustcore import *

__doc__ = rustcore.__doc__
if hasattr(rustcore, "__all__"):
    __all__ = rustcore.__all__