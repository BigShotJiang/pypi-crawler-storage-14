# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.3] - 2025-11-28

### Changed

- Match color scheme to terminal theme.

## [0.1.2] - 2025-07-25

### Added

- CHANGELOG.md

### Changed

- Better installation instructions in README, including a
recommendation to use pipx for installation.
- Screenshots zoomed-in for clock readability in the README file.

## [0.1.1] - 2025-07-25

### Added

- More screenshots in README, specifically for the Timer,
Stopwatch, and Load Clock Without Starting sections.

### Fixed

- Missing headings in README.
- Better organization of public methods in Timer class.
