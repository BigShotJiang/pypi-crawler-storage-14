"""Tests for CLI commands."""

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from typer.testing import CliRunner

from skysnoop.cli import app
from skysnoop.models.response import APIResponse

runner = CliRunner()


@pytest.fixture
def api_responses_dir():
    """Get path to API response fixtures directory."""
    return Path(__file__).parent / "fixtures" / "api_responses"


@pytest.fixture
def circle_response(api_responses_dir):
    """Load circle query response fixture."""
    with open(api_responses_dir / "circle_multiple_aircraft.json") as f:
        data = json.load(f)
    return APIResponse(**data)


@pytest.fixture
def single_aircraft_response(api_responses_dir):
    """Load single aircraft response fixture."""
    with open(api_responses_dir / "circle_single_aircraft.json") as f:
        data = json.load(f)
    return APIResponse(**data)


@pytest.fixture
def empty_response():
    """Create empty response fixture."""
    return APIResponse(now=1234567890.0, resultCount=0, ptime=0.01, aircraft=[])


def test_version_command():
    """Test version command."""
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert "skysnoop" in result.stdout


@patch("skysnoop.cli.SkySnoop")
def test_circle_command_table_output(mock_client_class, skydata_response):
    """Test circle command with table output (defaults to auto backend)."""
    mock_client = AsyncMock()
    mock_client.get_in_circle.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--", "37.7749", "-122.4194", "200"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    assert "aircraft" in result.stdout
    mock_client.get_in_circle.assert_called_once()


@patch("skysnoop.cli.SkySnoop")
def test_circle_command_json_output(mock_client_class, skydata_response):
    """Test circle command with JSON output (defaults to auto backend)."""
    mock_client = AsyncMock()
    mock_client.get_in_circle.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--json", "--", "37.7749", "-122.4194", "200"])

    assert result.exit_code == 0
    # Verify it's valid JSON
    output = json.loads(result.stdout)
    assert "aircraft" in output
    assert "result_count" in output


@patch("skysnoop.cli.SkySnoop")
def test_circle_command_with_filters(mock_client_class, skydata_response):
    """Test circle command with altitude filter."""
    mock_client = AsyncMock()
    mock_client.get_in_circle.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(
        app,
        ["circle", "--type", "A321", "--above-alt", "20000", "--", "37.7749", "-122.4194", "200"],
    )

    assert result.exit_code == 0
    # Verify filters were passed
    call_args = mock_client.get_in_circle.call_args
    assert call_args.kwargs["filters"] is not None
    assert call_args.kwargs["filters"].type_code == "A321"
    assert call_args.kwargs["filters"].above_alt_baro == 20000


@patch("skysnoop.cli.SkySnoop")
def test_circle_command_empty_results(mock_client_class, empty_skydata_response):
    """Test circle command with no results."""
    mock_client = AsyncMock()
    mock_client.get_in_circle.return_value = empty_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--", "37.7749", "-122.4194", "200"])

    assert result.exit_code == 0
    assert "No aircraft found" in result.stdout


@patch("skysnoop.cli.SkySnoop")
def test_closest_command(mock_client_class, single_skydata_response):
    """Test closest command."""
    mock_client = AsyncMock()
    mock_client.get_closest.return_value = single_skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["closest", "--", "37.7749", "-122.4194", "500"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    mock_client.get_closest.assert_called_once()


@patch("skysnoop.cli.SkySnoop")
def test_box_command(mock_client_class, skydata_response):
    """Test box command."""
    mock_client = AsyncMock()
    mock_client.get_in_box.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["box", "--", "37.0", "38.5", "-123.0", "-121.0"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    mock_client.get_in_box.assert_called_once()


@patch("skysnoop.cli.SkySnoop")
def test_find_hex_command(mock_client_class, single_skydata_response):
    """Test find-hex command."""
    mock_client = AsyncMock()
    mock_client.get_by_hex.return_value = single_skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["find-hex", "a12345"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    mock_client.get_by_hex.assert_called_once_with("a12345")


@patch("skysnoop.cli.SkySnoop")
def test_find_callsign_command(mock_client_class, skydata_response):
    """Test find-callsign command."""
    mock_client = AsyncMock()
    mock_client.get_by_callsign.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["find-callsign", "UAL123"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    mock_client.get_by_callsign.assert_called_once_with("UAL123")


@patch("skysnoop.cli.SkySnoop")
def test_find_reg_command(mock_client_class, single_skydata_response):
    """Test find-reg command."""
    mock_client = AsyncMock()
    mock_client.get_by_registration.return_value = single_skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["find-reg", "N12345"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    mock_client.get_by_registration.assert_called_once_with("N12345")


@patch("skysnoop.cli.SkySnoop")
def test_find_type_command(mock_client_class, skydata_response):
    """Test find-type command."""
    mock_client = AsyncMock()
    mock_client.get_by_type.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["find-type", "A321"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    mock_client.get_by_type.assert_called_once_with("A321")


@patch("skysnoop.cli.SkySnoop")
def test_all_aircraft_command_with_position(mock_client_class, skydata_response):
    """Test all-aircraft command (default: with position only)."""
    mock_client = AsyncMock()
    mock_client.get_all_with_pos.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["all-aircraft"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    mock_client.get_all_with_pos.assert_called_once()
    mock_client.all.assert_not_called()


@patch("skysnoop.cli.SkySnoop")
def test_all_aircraft_command_include_no_position(mock_client_class, skydata_response):
    """Test all-aircraft command with --include-no-position flag (shows warning with SkySnoop)."""
    mock_client = AsyncMock()
    mock_client.get_all_with_pos.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["all-aircraft", "--include-no-position"])

    assert result.exit_code == 0
    assert "Found" in result.stdout
    # SkySnoop shows warning and falls back to get_all_with_pos
    assert "Warning" in result.stderr or "include-no-position not supported" in result.stderr
    mock_client.get_all_with_pos.assert_called_once()


@patch("skysnoop.cli.SkySnoop")
def test_all_aircraft_command_with_filters(mock_client_class, skydata_response):
    """Test all-aircraft command with filters."""
    mock_client = AsyncMock()
    mock_client.get_all_with_pos.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["all-aircraft", "--type", "B738", "--callsign-prefix", "UAL"])

    assert result.exit_code == 0
    call_args = mock_client.get_all_with_pos.call_args
    assert call_args.kwargs["filters"] is not None
    assert call_args.kwargs["filters"].type_code == "B738"
    assert call_args.kwargs["filters"].callsign_prefix == "UAL"


@patch("skysnoop.cli.SkySnoop")
def test_error_handling_api_error(mock_client_class):
    """Test error handling for API errors."""
    from skysnoop.exceptions import APIError

    mock_client = AsyncMock()
    mock_client.get_in_circle.side_effect = APIError("API request failed")
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--", "37.7749", "-122.4194", "200"])

    assert result.exit_code == 1
    # Error messages appear in result.output (combined stdout + stderr from typer.echo)
    assert isinstance(result.exception, SystemExit)


@patch("skysnoop.cli.SkySnoop")
def test_error_handling_timeout(mock_client_class):
    """Test error handling for timeout errors."""
    from skysnoop.exceptions import TimeoutError

    mock_client = AsyncMock()
    mock_client.get_in_circle.side_effect = TimeoutError("Request timed out")
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--", "37.7749", "-122.4194", "200"])

    assert result.exit_code == 1
    assert isinstance(result.exception, SystemExit)


@patch("skysnoop.cli.SkySnoop")
def test_error_handling_validation_error(mock_client_class):
    """Test error handling for validation errors."""
    from skysnoop.exceptions import ValidationError

    mock_client = AsyncMock()
    mock_client.get_in_circle.side_effect = ValidationError("Invalid parameters")
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--", "37.7749", "-122.4194", "200"])

    assert result.exit_code == 1
    assert isinstance(result.exception, SystemExit)


# Backend parameter tests


@patch("skysnoop.cli.SkySnoop")
def test_circle_command_with_backend_auto(mock_skysnoop_class, skydata_response):
    """Test circle command with --backend auto."""
    mock_client = AsyncMock()
    mock_client.get_in_circle.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_skysnoop_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--backend", "auto", "--", "37.7749", "-122.4194", "50"])

    assert result.exit_code == 0
    mock_skysnoop_class.assert_called_once()
    mock_client.get_in_circle.assert_called_once()


@patch("skysnoop.cli.SkySnoop")
def test_find_hex_command_with_backend_openapi(mock_skysnoop_class, single_skydata_response):
    """Test find_hex command with --backend openapi."""
    mock_client = AsyncMock()
    mock_client.get_by_hex.return_value = single_skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_skysnoop_class.return_value = mock_client

    result = runner.invoke(app, ["find-hex", "--backend", "openapi", "a12345"])

    assert result.exit_code == 0
    mock_skysnoop_class.assert_called_once()
    mock_client.get_by_hex.assert_called_once_with("a12345")


@patch("skysnoop.cli.SkySnoop")
def test_backend_reapi_explicit(mock_skysnoop_class, skydata_response):
    """Test explicit reapi backend selection."""
    mock_client = AsyncMock()
    mock_client.get_in_circle.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_skysnoop_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--backend", "reapi", "--", "37.7749", "-122.4194", "50"])

    assert result.exit_code == 0
    # Verify SkySnoop was instantiated with backend="reapi"
    call_kwargs = mock_skysnoop_class.call_args[1]
    assert call_kwargs["backend"] == "reapi"


@patch("skysnoop.cli.SkySnoop")
def test_default_auto_backend(mock_client_class, skydata_response):
    """Test that commands default to 'auto' backend when --backend flag is omitted."""
    mock_client = AsyncMock()
    mock_client.get_in_circle.return_value = skydata_response
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client_class.return_value = mock_client

    result = runner.invoke(app, ["circle", "--", "37.7749", "-122.4194", "50"])

    assert result.exit_code == 0
    # Should use SkySnoop with 'auto' backend by default
    mock_client_class.assert_called_once()
    # Verify backend='auto' was passed
    call_kwargs = mock_client_class.call_args[1]
    assert call_kwargs["backend"] == "auto"
    mock_client.get_in_circle.assert_called_once()


@patch("skysnoop.cli.SkySnoop")
def test_unsupported_operation_error_handling(mock_skysnoop_class):
    """Test that UnsupportedOperationError is handled gracefully."""
    from skysnoop.exceptions import UnsupportedOperationError

    mock_client = AsyncMock()
    mock_client.get_all_with_pos.side_effect = UnsupportedOperationError("Operation not supported by OpenAPI backend")
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_skysnoop_class.return_value = mock_client

    result = runner.invoke(app, ["all-aircraft", "--backend", "openapi"])

    assert result.exit_code == 1
    assert "Unsupported operation" in result.stderr
    assert "--backend" in result.stderr
