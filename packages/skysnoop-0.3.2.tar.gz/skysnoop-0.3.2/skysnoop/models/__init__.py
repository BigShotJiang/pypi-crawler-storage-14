"""Data models for adsb.lol API responses."""

from .aircraft import Aircraft
from .response import APIResponse
from .skydata import SkyData

# OpenAPI models available in skysnoop.models.openapi submodule

__all__ = ["Aircraft", "APIResponse", "SkyData"]
