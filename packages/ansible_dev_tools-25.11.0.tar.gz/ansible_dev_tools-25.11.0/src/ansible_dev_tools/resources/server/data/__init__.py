"""Data package for Ansible Devtools server."""
