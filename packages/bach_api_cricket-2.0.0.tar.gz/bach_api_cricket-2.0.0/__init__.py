"""MCP Server for Api Cricket"""
