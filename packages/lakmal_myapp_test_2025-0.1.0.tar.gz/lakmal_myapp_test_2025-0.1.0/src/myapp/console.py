import click
from myapp.hello import hello

@click.command()
@click.argument("name", default="Friend")
def say_hello(name: str):
    
    hello(name)

if __name__ == "__main__":
    say_hello()