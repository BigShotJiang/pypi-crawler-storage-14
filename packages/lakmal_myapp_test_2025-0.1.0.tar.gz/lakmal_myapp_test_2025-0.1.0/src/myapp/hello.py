def hello(name: str = "World") -> None:
    print(f"Hello from Poetry, {name}!")