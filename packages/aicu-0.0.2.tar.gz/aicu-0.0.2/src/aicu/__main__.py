from aicuflow.main import main
main()
