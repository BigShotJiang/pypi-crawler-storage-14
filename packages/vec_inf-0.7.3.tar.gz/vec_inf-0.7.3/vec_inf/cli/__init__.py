"""vec_inf cli package."""
