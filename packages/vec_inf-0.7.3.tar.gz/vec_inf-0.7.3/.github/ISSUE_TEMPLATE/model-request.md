---
name: Model request
about: Request for new model weights or model config
title: New model request for [MODEL_NAME]
labels: new model
assignees: XkunW

---

### Request Type
Model weights | Model config | Both

### Model Name
Name of the model requested
