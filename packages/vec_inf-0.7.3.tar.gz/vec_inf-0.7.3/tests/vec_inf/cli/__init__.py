"""Unit tests for vec_inf.cli subpackage."""
