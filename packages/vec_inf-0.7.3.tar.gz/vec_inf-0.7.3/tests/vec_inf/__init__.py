"""Unit tests for vec_inf package."""
