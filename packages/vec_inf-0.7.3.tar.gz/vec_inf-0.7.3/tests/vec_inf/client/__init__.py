"""Tests for the Vector Inference API."""
