"""Django Admin Advanced Search Package

This package provides advanced search functionality for Django Admin interface.
"""

__version__ = '0.1.0'
__author__ = 'shifenhutu'
__email__ = 'shifenhutu@example.com'
__license__ = 'MIT'