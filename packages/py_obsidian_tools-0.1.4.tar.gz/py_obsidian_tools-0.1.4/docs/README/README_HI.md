🌐 **Language / 言語**: [English](../../README.md) | [简体中文](README_ZH.md) | [繁體中文](README_TW.md) | [Español](README_ES.md) | [Français](README_FR.md) | [Português](README_PT.md) | [Deutsch](README_DE.md) | [Русский](README_RU.md) | [日本語](README_JA.md) | [한국어](README_KO.md) | [हिन्दी](README_HI.md)

[![Python](https://img.shields.io/badge/python-3.13+-blue?style=flat&logo=python&logoColor=white)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green?style=flat)](../../LICENSE)
[![MCP](https://img.shields.io/badge/MCP-Model%20Context%20Protocol-blueviolet?style=flat)](https://modelcontextprotocol.io/)
[![GitHub stars](https://img.shields.io/github/stars/rmc8/PyObsidianMCP?style=flat)](https://github.com/rmc8/PyObsidianMCP/stargazers)
[![GitHub issues](https://img.shields.io/github/issues/rmc8/PyObsidianMCP?style=flat)](https://github.com/rmc8/PyObsidianMCP/issues)
[![Last Commit](https://img.shields.io/github/last-commit/rmc8/PyObsidianMCP?style=flat)](https://github.com/rmc8/PyObsidianMCP/commits)

# PyObsidianMCP

Local REST API कम्युनिटी प्लगइन के माध्यम से Obsidian के साथ इंटरैक्ट करने के लिए MCP सर्वर।

## कॉम्पोनेन्ट्स

### टूल्स

सर्वर Obsidian के साथ इंटरैक्ट करने के लिए कई टूल्स इम्प्लीमेंट करता है:

| टूल | विवरण |
|-----|-------|
| `list_notes` | वॉल्ट या किसी विशेष डायरेक्टरी में सभी नोट्स की सूची |
| `read_note` | किसी विशेष नोट की सामग्री पढ़ें |
| `search_notes` | विशेष टेक्स्ट वाले नोट्स खोजें |
| `create_note` | वैकल्पिक frontmatter के साथ नया नोट बनाएं |
| `update_note` | नोट की पूरी सामग्री अपडेट (रिप्लेस) करें |
| `append_note` | नोट के अंत में सामग्री जोड़ें |
| `delete_note` | वॉल्ट से नोट हटाएं |
| `patch_note` | किसी विशेष सेक्शन (हेडिंग/ब्लॉक/frontmatter) को अपडेट करें |
| `list_commands` | सभी उपलब्ध Obsidian कमांड्स की सूची |
| `execute_command` | Obsidian कमांड निष्पादित करें |
| `batch_read_notes` | एक साथ कई नोट्स पढ़ें |
| `complex_search` | उन्नत फ़िल्टरिंग के लिए JsonLogic क्वेरीज़ के साथ खोज |
| `get_recent_changes` | हाल ही में संशोधित फ़ाइलें प्राप्त करें (Dataview प्लगइन आवश्यक) |
| `get_periodic_note` | आज का दैनिक/साप्ताहिक/मासिक नोट प्राप्त करें (Periodic Notes प्लगइन आवश्यक) |
| `get_periodic_note_by_date` | किसी विशेष तिथि का पीरियोडिक नोट प्राप्त करें (Periodic Notes प्लगइन आवश्यक) |
| `get_recent_periodic_notes` | हाल के पीरियोडिक नोट्स प्राप्त करें (Dataview प्लगइन आवश्यक) |
| `open_note` | Obsidian UI में नोट खोलें |
| `get_active_note` | वर्तमान में सक्रिय नोट प्राप्त करें |
| `update_active_note` | सक्रिय नोट की सामग्री अपडेट करें |
| `append_active_note` | सक्रिय नोट में सामग्री जोड़ें |
| `patch_active_note` | सक्रिय नोट के किसी विशेष सेक्शन को अपडेट करें |
| `delete_active_note` | वर्तमान में सक्रिय नोट हटाएं |
| `server_status` | Obsidian Local REST API सर्वर की स्थिति प्राप्त करें |
| `dataview_query` | Dataview DQL क्वेरीज़ निष्पादित करें (Dataview प्लगइन आवश्यक) |
| `vector_search` | प्राकृतिक भाषा का उपयोग करके सेमांटिक खोज (vector extras आवश्यक) |
| `find_similar_notes` | निर्दिष्ट नोट से मिलते-जुलते नोट्स खोजें (vector extras आवश्यक) |
| `vector_status` | वेक्टर सर्च इंडेक्स की स्थिति प्राप्त करें (vector extras आवश्यक) |

### उदाहरण प्रॉम्प्ट्स

पहले Claude को Obsidian का उपयोग करने का निर्देश देना अच्छा है। फिर यह हमेशा टूल को कॉल करेगा।

आप इस तरह के प्रॉम्प्ट्स का उपयोग कर सकते हैं:
- "'Daily' फ़ोल्डर में सभी नोट्स की सूची दें"
- "'Project X' का उल्लेख करने वाले सभी नोट्स खोजें और उनका सारांश दें"
- "हमारी चर्चा की सामग्री के साथ 'Meeting Notes' नाम का एक नया नोट बनाएं"
- "मेरे दैनिक नोट में 'TODO: PR समीक्षा करें' जोड़ें"
- "सक्रिय नोट की सामग्री प्राप्त करें और उसकी समीक्षा करें"
- "complex search का उपयोग करके Work फ़ोल्डर में सभी markdown फ़ाइलें खोजें"
- "सेमांटिक सर्च का उपयोग करके मशीन लर्निंग पर नोट्स खोजें"
- "मेरे प्रोजेक्ट प्लान के समान नोट्स खोजें"

## कॉन्फ़िगरेशन

### Obsidian REST API कुंजी

Obsidian REST API कुंजी के साथ एनवायरनमेंट को कॉन्फ़िगर करने के दो तरीके हैं।

1. सर्वर कॉन्फ़िग में जोड़ें (अनुशंसित)

```json
{
  "mcpServers": {
    "obsidian-tools": {
      "command": "uvx",
      "args": ["py-obsidian-tools"],
      "env": {
        "OBSIDIAN_API_KEY": "<your_api_key_here>",
        "OBSIDIAN_HOST": "127.0.0.1",
        "OBSIDIAN_PORT": "27124"
      }
    }
  }
}
```

2. वर्किंग डायरेक्टरी में निम्नलिखित आवश्यक वेरिएबल्स के साथ `.env` फ़ाइल बनाएं:

```
OBSIDIAN_API_KEY=your_api_key_here
OBSIDIAN_HOST=127.0.0.1
OBSIDIAN_PORT=27124
```

नोट:
- आप Obsidian प्लगइन कॉन्फ़िग में API कुंजी पा सकते हैं (Settings > Local REST API > Security)
- डिफ़ॉल्ट पोर्ट 27124 है
- डिफ़ॉल्ट होस्ट 127.0.0.1 (localhost) है

## क्विक स्टार्ट

### इंस्टॉलेशन

#### Obsidian REST API

आपको Obsidian REST API कम्युनिटी प्लगइन चलाने की आवश्यकता है: https://github.com/coddingtonbear/obsidian-local-rest-api

सेटिंग्स में इसे इंस्टॉल और इनेबल करें और API कुंजी कॉपी करें।

#### Claude Desktop

MacOS पर: `~/Library/Application\ Support/Claude/claude_desktop_config.json`

Windows पर: `%APPDATA%/Claude/claude_desktop_config.json`

**अनुशंसित: PyPI से इंस्टॉल करें (uvx)**

```json
{
  "mcpServers": {
    "obsidian-tools": {
      "command": "uvx",
      "args": ["py-obsidian-tools"],
      "env": {
        "OBSIDIAN_API_KEY": "<your_api_key_here>",
        "OBSIDIAN_HOST": "127.0.0.1",
        "OBSIDIAN_PORT": "27124"
      }
    }
  }
}
```

<details>
  <summary>डेवलपमेंट/अनपब्लिश्ड सर्वर्स कॉन्फ़िगरेशन</summary>

```json
{
  "mcpServers": {
    "obsidian-tools": {
      "command": "uv",
      "args": [
        "--directory",
        "/path/to/py-obsidian-tools",
        "run",
        "py-obsidian-tools"
      ],
      "env": {
        "OBSIDIAN_API_KEY": "<your_api_key_here>"
      }
    }
  }
}
```
</details>

<details>
  <summary>GitHub से इंस्टॉल करें (uvx)</summary>

```json
{
  "mcpServers": {
    "obsidian-tools": {
      "command": "uvx",
      "args": [
        "--from",
        "git+https://github.com/rmc8/PyObsidianMCP",
        "py-obsidian-tools"
      ],
      "env": {
        "OBSIDIAN_API_KEY": "<your_api_key_here>"
      }
    }
  }
}
```
</details>

## वेक्टर सर्च (वैकल्पिक)

ChromaDB का उपयोग करके सेमांटिक सर्च फंक्शनैलिटी। यह फीचर आपके पूरे वॉल्ट में प्राकृतिक भाषा क्वेरीज़ को सक्षम करता है।

### इंस्टॉलेशन

```bash
# बेसिक (लोकल एम्बेडिंग्स - API कुंजी आवश्यक नहीं)
pip install "py-obsidian-tools[vector]"

# बाहरी एम्बेडिंग प्रोवाइडर्स के साथ
pip install "py-obsidian-tools[vector-openai]"
pip install "py-obsidian-tools[vector-google]"
pip install "py-obsidian-tools[vector-cohere]"
pip install "py-obsidian-tools[vector-all]"
```

### इंडेक्स बनाएं

वेक्टर सर्च का उपयोग करने से पहले, आपको अपने वॉल्ट का इंडेक्स बनाना होगा:

```bash
# विधि 1: यदि पहले से स्थापित हो
pyobsidian-index full --verbose

# विधि 2: uvx का उपयोग (इंस्टॉलेशन आवश्यक नहीं)
uvx --from py-obsidian-tools pyobsidian-index full --verbose
```

### CLI कमांड्स

| कमांड | विवरण |
|-------|-------|
| `pyobsidian-index full` | वॉल्ट के सभी नोट्स को इंडेक्स करें |
| `pyobsidian-index update` | इंक्रीमेंटल अपडेट (केवल नए/संशोधित नोट्स) |
| `pyobsidian-index clear` | पूरा इंडेक्स साफ़ करें |
| `pyobsidian-index status` | इंडेक्स स्थिति दिखाएं |

### एनवायरनमेंट वेरिएबल्स

```bash
VECTOR_PROVIDER=default          # default, ollama, openai, google, cohere
VECTOR_CHROMA_PATH=~/.obsidian-vector
VECTOR_CHUNK_SIZE=512

# Ollama के लिए
VECTOR_OLLAMA_HOST=http://localhost:11434
VECTOR_OLLAMA_MODEL=nomic-embed-text

# OpenAI के लिए
VECTOR_OPENAI_API_KEY=sk-xxx
VECTOR_OPENAI_MODEL=text-embedding-3-small

# Google के लिए
VECTOR_GOOGLE_API_KEY=xxx
VECTOR_GOOGLE_MODEL=embedding-001

# Cohere के लिए
VECTOR_COHERE_API_KEY=xxx
VECTOR_COHERE_MODEL=embed-multilingual-v3.0
```

### एम्बेडिंग प्रोवाइडर्स

| प्रोवाइडर | मॉडल | सर्वोत्तम उपयोग |
|-----------|------|-----------------|
| default | all-MiniLM-L6-v2 | तेज़, मुफ्त, पूरी तरह लोकल |
| ollama | nomic-embed-text | उच्च गुणवत्ता, लोकल |
| openai | text-embedding-3-small | सर्वोत्तम गुणवत्ता, बहुभाषी |
| google | embedding-001 | Google AI इंटीग्रेशन |
| cohere | embed-multilingual-v3.0 | बहुभाषी विशेषज्ञता |

## डेवलपमेंट

### बिल्डिंग

पैकेज को डिस्ट्रीब्यूशन के लिए तैयार करने के लिए:

1. डिपेंडेंसीज़ सिंक करें और लॉकफ़ाइल अपडेट करें:
```bash
uv sync
```

### डिबगिंग

चूंकि MCP सर्वर stdio पर चलते हैं, डिबगिंग चुनौतीपूर्ण हो सकती है। सर्वोत्तम डिबगिंग अनुभव के लिए, हम [MCP Inspector](https://github.com/modelcontextprotocol/inspector) का उपयोग करने की दृढ़ता से अनुशंसा करते हैं।

आप इस कमांड के साथ `npx` के माध्यम से MCP Inspector लॉन्च कर सकते हैं:

```bash
npx @modelcontextprotocol/inspector uv --directory /path/to/py-obsidian-tools run py-obsidian-tools
```

लॉन्च होने पर, Inspector एक URL प्रदर्शित करेगा जिसे आप डिबगिंग शुरू करने के लिए अपने ब्राउज़र में एक्सेस कर सकते हैं।

आप सर्वर लॉग्स भी देख सकते हैं (यदि कॉन्फ़िगर किया गया हो) या स्टैंडर्ड Python लॉगिंग का उपयोग कर सकते हैं।
