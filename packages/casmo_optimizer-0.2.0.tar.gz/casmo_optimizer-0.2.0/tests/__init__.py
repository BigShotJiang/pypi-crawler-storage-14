"""
CASMO Unit Tests

Test suite for the Confident Adaptive Selective Momentum Optimizer (CASMO).
"""

__version__ = "0.1.0"
