# Interactive Optimizer Trajectory Visualization

A beautiful, interactive visualization comparing CASMO vs AdamW optimizer behavior during conflicting task training.

## Features

✨ **3D Loss Landscapes** - WebGL-rendered loss surfaces with smooth shading  
🎨 **Animated Trajectories** - Watch optimizers navigate the loss landscape in real-time  
🌈 **Confidence Visualization** - Color-coded paths show CASMO's adaptive behavior  
🎮 **Interactive Controls** - Play/pause, speed control, and timeline scrubbing  
💎 **Modern UI** - Glassmorphic design with vibrant gradients and smooth animations  
📊 **Side-by-Side Comparison** - Direct visual comparison of optimizer behavior  

## Quick Start

### 1. Generate Trajectory Data

First, run the enhanced ablation script to collect optimizer trajectory data:

```bash
cd c:\Users\wwwab\Development\CASMO\benchmarks\b7_continual_learning\viz
python visualize_ablation.py
```

This will:
- Train both CASMO and AdamW on conflicting tasks
- Log detailed trajectories (weights, gradients, confidence)
- Compute 2D loss landscapes using PCA projection
- Export data to `trajectory_data.json` (in the viz directory)

**Note:** Training takes ~15-30 minutes depending on your GPU.

### 2. Launch Visualization

Open the visualization in your browser:

```bash
# Option 1: Open directly (if you have file:// access)
start viz/index.html

# Option 2: Use a local server (recommended)
cd viz
python -m http.server 8000
# Then open http://localhost:8000 in your browser
```

### 3. Interact with the Visualization

- **Play/Pause**: Watch optimizers navigate the landscape
- **Speed Slider**: Control animation speed (0.1x - 3.0x)
- **Step Scrubber**: Jump to any point in training
- **3D Rotation**: Drag to rotate the loss landscape
- **Zoom**: Scroll to zoom in/out

## Understanding the Visualization

### Color Coding

| Color | Meaning |
|-------|---------|
| 🟢 **Green Path** | High confidence (CASMO trusts gradients) |
| 🔴 **Red Path** | Low confidence (CASMO detects noise/conflict) |
| 🟣 **Purple Path** | AdamW trajectory (fixed confidence) |

### Loss Landscape

- **Blue valleys**: Low loss regions (good)
- **Red peaks**: High loss regions (bad)
- **Height**: Represents loss magnitude

### Key Insights to Watch For

1. **CASMO's Cautiousness**: Watch for red segments where CASMO slows down due to conflicting gradients
2. **AdamW's Noise Following**: Observe AdamW making aggressive updates even in noisy regions
3. **Final Stability**: Compare forgetting metrics to see which optimizer better preserves knowledge

## Files

```
viz/
├── index.html              # Main HTML structure
├── style.css               # Modern styling with glassmorphism
├── main.js                 # Three.js visualization logic
├── visualize_ablation.py   # Enhanced training script with logging
└── trajectory_data.json    # Generated data (after running script)
```

## Technical Details

### Data Collection

- **PCA Projection**: High-dimensional LoRA weights → 2D visualization space
- **Loss Sampling**: 25×25 grid evaluated around trajectory (625 points)
- **Logging Frequency**: Every 5 steps (configurable)
- **Metrics Tracked**: Loss, AGAR, confidence, gradient norms

### Rendering

- **Library**: Three.js (WebGL)
- **Performance**: 60 FPS rendering target
- **Resolution**: Adaptive based on screen size
- **Compatibility**: Modern browsers (Chrome, Edge, Firefox, Safari)

## Browser Compatibility

✅ Chrome/Edge (recommended)  
✅ Firefox  
✅ Safari (macOS/iOS)  
⚠️ Requires WebGL support

## Troubleshooting

### Data Not Loading

- Make sure `trajectory_data.json` exists in the `viz/` directory
- Check browser console for errors
- Try using a local server instead of `file://` protocol

### Slow Performance

- Close other browser tabs
- Reduce loss landscape resolution (edit `grid_size` in `visualize_ablation.py`)
- Use Chrome/Edge for best WebGL performance

### Visualization Looks Wrong

- Clear browser cache and reload
- Check that training completed successfully
- Verify `trajectory_data.json` is valid JSON

## Customization

Want to modify the visualization? Key parameters:

**In `visualize_ablation.py`:**
- `log_every`: Logging frequency (default: 5 steps)
- `grid_size`: Loss landscape resolution (default: 25×25)
- `extent`: How far from trajectory to sample (default: 2.0 std devs)

**In `main.js`:**
- `stepsPerSecond`: Animation speed multiplier
- Color schemes in `updateTrajectory()`
- Camera position and FOV

**In `style.css`:**
- Color palette (`:root` variables)
- Layout dimensions
- Animation timings

## Credits

Created as part of the CASMO (Confident Adaptive Selective Momentum Optimizer) project.

**Technologies:**
- [Three.js](https://threejs.org/) - 3D rendering
- [scikit-learn](https://scikit-learn.org/) - PCA projection
- Modern Web APIs (WebGL, ES6+)
