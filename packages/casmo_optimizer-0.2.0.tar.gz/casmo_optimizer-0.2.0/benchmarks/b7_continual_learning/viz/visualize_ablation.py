"""
B7 Ablation Study: Enhanced with Trajectory Visualization

Creates detailed optimizer trajectory data for interactive visualization.
Logs weight snapshots, gradients, AGAR/confidence, and computes loss landscapes.
"""

import sys
import os
import argparse
import random
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import torch
from torch.utils.data import Dataset, DataLoader
import warnings
import json
from sklearn.decomposition import PCA

# Add parent directories to path to import casmo (now in viz subdirectory)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from casmo import CASMO

# -----------------------------------------------------------------------------
# Trajectory Logger
# -----------------------------------------------------------------------------

class TrajectoryLogger:
    """
    Logs optimizer trajectories for visualization.
    Captures weight snapshots, metrics, and computes loss landscapes.
    """
    def __init__(self, log_every=5):
        self.log_every = log_every
        self.step = 0
        self.weights = []
        self.losses = []
        self.agar_values = []
        self.confidence_values = []
        self.grad_norms = []
        
    def log_step(self, model, optimizer, loss_value):
        """Log current optimizer state."""
        if self.step % self.log_every != 0:
            self.step += 1
            return
            
        # Get LoRA weights (flat vector)
        weights = []
        for name, param in model.named_parameters():
            if param.requires_grad and 'lora' in name.lower():
                weights.append(param.data.cpu().flatten().numpy())
        
        if weights:
            weight_vector = np.concatenate(weights)
            self.weights.append(weight_vector)
            
        self.losses.append(loss_value)
        
        # Get CASMO metrics if available
        if hasattr(optimizer, '_group_states'):
            group_state = optimizer._group_states.get(0, {})
            agar = group_state.get('current_agar', 0)
            conf = group_state.get('current_confidence', 1.0)
            self.agar_values.append(agar if agar is not None else 0)
            self.confidence_values.append(conf if conf is not None else 1.0)
        else:
            self.agar_values.append(None)
            self.confidence_values.append(1.0)
            
        # Compute gradient norm
        grad_norm = 0
        for param in model.parameters():
            if param.grad is not None and param.requires_grad:
                grad_norm += param.grad.norm().item() ** 2
        self.grad_norms.append(np.sqrt(grad_norm))
        
        self.step += 1
    
    def compute_landscape(self, model, dataloader, device, grid_size=15, extent=2.0):
        """
        Compute 2D loss landscape using PCA projection.
        
        Args:
            model: The model to evaluate
            dataloader: Data to compute loss on
            device: Device for computation
            grid_size: Resolution of landscape grid
            extent: How far from trajectory to sample (in std devs)
        
        Returns:
            dict with landscape data
        """
        if len(self.weights) < 2:
            return None
            
        print(f"\n🎨 Computing loss landscape (this may take a few minutes)...")
        
        # Get weight trajectory as numpy array
        weight_matrix = np.array(self.weights)  # Shape: (steps, dim)
        
        # Use PCA to project to 2D
        pca = PCA(n_components=2)
        trajectory_2d = pca.fit_transform(weight_matrix)
        
        # Create grid around trajectory
        x_min, x_max = trajectory_2d[:, 0].min(), trajectory_2d[:, 0].max()
        y_min, y_max = trajectory_2d[:, 1].min(), trajectory_2d[:, 1].max()
        
        x_range = (x_max - x_min) or 1.0
        y_range = (y_max - y_min) or 1.0
        
        x_grid = np.linspace(x_min - extent * x_range, x_max + extent * x_range, grid_size)
        y_grid = np.linspace(y_min - extent * y_range, y_max + extent * y_range, grid_size)
        
        # Sample loss at grid points
        loss_grid = np.zeros((grid_size, grid_size))
        
        # Get reference weights (use middle of trajectory)
        ref_weights = weight_matrix[len(weight_matrix) // 2]
        
        model.eval()
        with torch.no_grad():
            for i, x in enumerate(tqdm(x_grid, desc="Computing landscape")):
                for j, y in enumerate(y_grid):
                    # Project 2D point back to weight space
                    point_2d = np.array([[x, y]])
                    point_weights = pca.inverse_transform(point_2d)[0]
                    
                    # Set model weights
                    self._set_lora_weights(model, point_weights)
                    
                    # Compute loss
                    total_loss = 0
                    count = 0
                    for batch_idx, batch in enumerate(dataloader):
                        if batch_idx >= 10:  # Limit batches for speed
                            break
                        input_ids = batch['input_ids'].to(device)
                        attention_mask = batch['attention_mask'].to(device)
                        labels = batch['labels'].to(device)
                        outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                        total_loss += outputs.loss.item()
                        count += 1
                    
                    loss_grid[j, i] = total_loss / count if count > 0 else 0
        
        # Restore original weights
        self._set_lora_weights(model, ref_weights)
        
        # CRITICAL: Clear weights array after computing landscape to save memory
        # We only needed them for PCA, not for the final JSON export
        self.weights = []
        
        return {
            'x_grid': x_grid.tolist(),
            'y_grid': y_grid.tolist(),
            'loss_grid': loss_grid.tolist(),
            'trajectory_2d': trajectory_2d.tolist()
            # Removed pca_components and pca_mean - too large and not needed for viz
        }
    
    def _set_lora_weights(self, model, weight_vector):
        """Set LoRA weights from flat vector."""
        offset = 0
        for name, param in model.named_parameters():
            if param.requires_grad and 'lora' in name.lower():
                numel = param.numel()
                # Create tensor on same device and dtype as param to avoid transfers
                new_weights = torch.from_numpy(weight_vector[offset:offset+numel]).to(
                    device=param.device, dtype=param.dtype
                ).reshape(param.shape)
                param.data.copy_(new_weights)
                offset += numel
    
    def to_dict(self):
        """Export trajectory data as dictionary."""
        return {
            'losses': self.losses,
            'agar': self.agar_values,
            'confidence': self.confidence_values,
            'num_steps': len(self.losses)
            # Removed grad_norms - not used in visualization
        }

# -----------------------------------------------------------------------------
# Synthetic Data (same as ablation_conflict_test.py)
# -----------------------------------------------------------------------------

class ConflictingMathDataset(Dataset):
    def __init__(self, tokenizer, task_id, num_samples=200, max_length=64):
        self.tokenizer = tokenizer
        self.task_id = task_id
        self.max_length = max_length
        self.samples = self._generate_samples(num_samples)

    def _generate_samples(self, num_samples):
        samples = []
        for i in range(num_samples):
            a = random.randint(1, 100)
            b = random.randint(1, 100)
            op = random.choice(['+', '-', '*'])
            
            if op == '+': ans = a + b
            elif op == '-': ans = a - b
            else: ans = a * b
            
            question = f"{a} {op} {b} = ?"
            
            if self.task_id == 0:
                text = f"Question: {question}\nAnswer: {ans}"
            else:
                text = f"Input: {question}\nOutput: The solution is {ans}"
                
            samples.append(text)
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        text = self.samples[idx]
        encodings = self.tokenizer(
            text,
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt"
        )
        
        input_ids = encodings['input_ids'].squeeze()
        attention_mask = encodings['attention_mask'].squeeze()
        labels = input_ids.clone()
        
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels
        }

# -----------------------------------------------------------------------------
# Setup
# -----------------------------------------------------------------------------

def get_model_and_tokenizer():
    model_name = "unsloth/gemma-2-2b-bnb-4bit"
    print(f"Loading {model_name}...")
    
    warnings.filterwarnings('ignore')
    
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        device_map="auto",
        trust_remote_code=True
    )
    
    model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True)
    model.config.use_cache = False
    
    peft_config = LoraConfig(
        r=16,
        lora_alpha=32,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    
    model = get_peft_model(model, peft_config)
    return model, tokenizer

# -----------------------------------------------------------------------------
# Training with Logging
# -----------------------------------------------------------------------------

def train_task(model, optimizer, dataloader, task_name, logger, epochs=2):
    model.train()
    
    print(f"\nTraining {task_name}...")
    
    for epoch in range(epochs):
        pbar = tqdm(dataloader, desc=f"Epoch {epoch+1}")
        for batch in pbar:
            optimizer.zero_grad()
            
            input_ids = batch['input_ids'].to(model.device)
            attention_mask = batch['attention_mask'].to(model.device)
            labels = batch['labels'].to(model.device)
            
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            
            # Log trajectory
            logger.log_step(model, optimizer, loss.item())
            
            pbar.set_postfix({'loss': f"{loss.item():.4f}"})

def evaluate(model, dataloader):
    model.eval()
    total_loss = 0
    count = 0
    with torch.no_grad():
        for batch in dataloader:
            input_ids = batch['input_ids'].to(model.device)
            attention_mask = batch['attention_mask'].to(model.device)
            labels = batch['labels'].to(model.device)
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            total_loss += outputs.loss.item()
            count += 1
    return np.exp(total_loss / count)

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main():
    # Save results in the viz directory (current directory)
    results_dir = os.path.dirname(__file__)
    if not results_dir:
        results_dir = '.'
    
    # Setup datasets
    print("Setting up datasets...")
    model, tokenizer = get_model_and_tokenizer()
    
    ds_a_train = ConflictingMathDataset(tokenizer, task_id=0, num_samples=200)
    ds_a_test = ConflictingMathDataset(tokenizer, task_id=0, num_samples=50)
    dl_a_train = DataLoader(ds_a_train, batch_size=4, shuffle=True)
    dl_a_test = DataLoader(ds_a_test, batch_size=4)
    
    ds_b_train = ConflictingMathDataset(tokenizer, task_id=1, num_samples=200)
    dl_b_train = DataLoader(ds_b_train, batch_size=4, shuffle=True)
    
    # -------------------------------------------------------------------------
    # Run 1: CASMO
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("🔵 RUNNING CASMO (Confident Adaptive Optimizer)")
    print("="*70)
    
    optimizer = CASMO(model.parameters(), lr=2e-4, tau_init_steps=50)
    logger_casmo = TrajectoryLogger(log_every=5)
    
    # Train Task A
    train_task(model, optimizer, dl_a_train, "Task A (Format 1)", logger_casmo)
    perp_a_initial = evaluate(model, dl_a_test)
    print(f"✓ Task A Initial Perplexity: {perp_a_initial:.2f}")
    
    # Train Task B (Conflict)
    train_task(model, optimizer, dl_b_train, "Task B (Conflicting Format)", logger_casmo)
    perp_a_final_casmo = evaluate(model, dl_a_test)
    print(f"✓ Task A Final Perplexity: {perp_a_final_casmo:.2f}")
    
    # Compute loss landscape for CASMO
    landscape_casmo = logger_casmo.compute_landscape(model, dl_b_train, model.device)
    
    # -------------------------------------------------------------------------
    # Reset & Run 2: AdamW
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("🔴 RUNNING ADAMW (Standard Optimizer)")
    print("="*70)
    
    del model, optimizer
    import gc; gc.collect(); torch.cuda.empty_cache()
    
    model, _ = get_model_and_tokenizer()
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-4)
    logger_adamw = TrajectoryLogger(log_every=5)
    
    # Train Task A
    train_task(model, optimizer, dl_a_train, "Task A (Format 1)", logger_adamw)
    perp_a_initial_adamw = evaluate(model, dl_a_test)
    print(f"✓ Task A Initial Perplexity: {perp_a_initial_adamw:.2f}")
    
    # Train Task B
    train_task(model, optimizer, dl_b_train, "Task B (Conflicting Format)", logger_adamw)
    perp_a_final_adamw = evaluate(model, dl_a_test)
    print(f"✓ Task A Final Perplexity: {perp_a_final_adamw:.2f}")
    
    # Compute loss landscape for AdamW
    landscape_adamw = logger_adamw.compute_landscape(model, dl_b_train, model.device)
    
    # -------------------------------------------------------------------------
    # Results & Export
    # -------------------------------------------------------------------------
    casmo_forgetting = perp_a_final_casmo - perp_a_initial
    adamw_forgetting = perp_a_final_adamw - perp_a_initial_adamw
    
    print("\n" + "="*70)
    print("📊 FINAL RESULTS")
    print("="*70)
    print(f"CASMO Forgetting:  {casmo_forgetting:+.2f} perplexity")
    print(f"AdamW Forgetting:  {adamw_forgetting:+.2f} perplexity")
    print(f"\n🏆 Winner: {'CASMO' if casmo_forgetting < adamw_forgetting else 'AdamW'}")
    print(f"   CASMO is {adamw_forgetting / casmo_forgetting:.2f}x more stable!")
    
    # Export data for visualization
    viz_data = {
        'casmo': {
            'trajectory': logger_casmo.to_dict(),
            'landscape': landscape_casmo,
            'forgetting': float(casmo_forgetting),
            'perplexity_initial': float(perp_a_initial),
            'perplexity_final': float(perp_a_final_casmo)
        },
        'adamw': {
            'trajectory': logger_adamw.to_dict(),
            'landscape': landscape_adamw,
            'forgetting': float(adamw_forgetting),
            'perplexity_initial': float(perp_a_initial_adamw),
            'perplexity_final': float(perp_a_final_adamw)
        },
        'metadata': {
            'winner': 'CASMO' if casmo_forgetting < adamw_forgetting else 'AdamW',
            'improvement_factor': float(adamw_forgetting / casmo_forgetting)
        }
    }
    
    output_path = os.path.join(results_dir, 'trajectory_data.json')
    with open(output_path, 'w') as f:
        json.dump(viz_data, f, indent=2)
    
    print(f"\n✅ Visualization data saved to: {output_path}")
    print(f"📂 Open viz/index.html to view the interactive visualization!")

if __name__ == '__main__':
    main()
