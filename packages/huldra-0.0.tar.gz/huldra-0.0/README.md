# Huldra

Huldra is an automated vulnerability remediation tool. It leverages existing `audit tools` to identify vulnerabilities in Language dependencies and uses an LLM orchestrator `(TensorZero)` to intelligently suggest and apply fixes.
