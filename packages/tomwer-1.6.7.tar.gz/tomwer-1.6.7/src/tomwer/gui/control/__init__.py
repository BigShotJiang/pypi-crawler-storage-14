"""Widgets related to 'control' tasks (select a scan, convert a scan with nxtomomill...)"""
