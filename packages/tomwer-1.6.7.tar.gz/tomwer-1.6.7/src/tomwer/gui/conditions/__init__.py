"""Widgets for conditions (filters to let a scan continue processing or not)"""
