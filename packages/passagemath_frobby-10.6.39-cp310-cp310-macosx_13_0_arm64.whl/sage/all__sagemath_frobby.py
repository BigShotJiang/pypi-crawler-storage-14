# sage_setup: distribution = sagemath-frobby
# delvewheel: patch

from sage.all__sagemath_categories import *
from sage.all__sagemath_graphs import *
from sage.all__sagemath_singular import *
