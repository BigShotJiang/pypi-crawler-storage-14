class QueuedDataDTO:
    def __init__(self, status_url: str) -> None:
        self.status_url: str = status_url
