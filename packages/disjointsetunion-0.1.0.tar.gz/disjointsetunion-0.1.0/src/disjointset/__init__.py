"""Disjoint Set (Union Find) Data Structure."""

from .disjointset import DisjointSet

__all__ = ["DisjointSet"]
