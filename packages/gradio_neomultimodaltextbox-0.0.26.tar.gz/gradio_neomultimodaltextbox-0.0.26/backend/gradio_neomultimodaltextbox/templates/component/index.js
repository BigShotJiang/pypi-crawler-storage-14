var Iu = Object.defineProperty;
var sl = (n) => {
  throw TypeError(n);
};
var Lu = (n, e, t) => e in n ? Iu(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var Ne = (n, e, t) => Lu(n, typeof e != "symbol" ? e + "" : e, t), xa = (n, e, t) => e.has(n) || sl("Cannot " + t);
var Sn = (n, e, t) => (xa(n, e, "read from private field"), t ? t.call(n) : e.get(n)), Fa = (n, e, t) => e.has(n) ? sl("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t), ol = (n, e, t, r) => (xa(n, e, "write to private field"), r ? r.call(n, t) : e.set(n, t), t), Er = (n, e, t) => (xa(n, e, "access private method"), t);
new Intl.Collator(0, { numeric: 1 }).compare;
async function Ou(n, e) {
  return n.map(
    (t) => new Pu({
      path: t.name,
      orig_name: t.name,
      blob: t,
      size: t.size,
      mime_type: t.type,
      is_stream: e
    })
  );
}
class Pu {
  constructor({
    path: e,
    url: t,
    orig_name: r,
    size: a,
    blob: i,
    is_stream: l,
    mime_type: s,
    alt_text: o,
    b64: d
  }) {
    this.meta = { _type: "gradio.FileData" }, this.path = e, this.url = t, this.orig_name = r, this.size = a, this.blob = t ? void 0 : i, this.is_stream = l, this.mime_type = s, this.alt_text = o, this.b64 = d;
  }
}
typeof process < "u" && process.versions && process.versions.node;
var k0;
class Qm extends TransformStream {
  /** Constructs a new instance. */
  constructor(t = { allowCR: !1 }) {
    super({
      transform: (r, a) => {
        for (r = Sn(this, k0) + r; ; ) {
          const i = r.indexOf(`
`), l = t.allowCR ? r.indexOf("\r") : -1;
          if (l !== -1 && l !== r.length - 1 && (i === -1 || i - 1 > l)) {
            a.enqueue(r.slice(0, l)), r = r.slice(l + 1);
            continue;
          }
          if (i === -1)
            break;
          const s = r[i - 1] === "\r" ? i - 1 : i;
          a.enqueue(r.slice(0, s)), r = r.slice(i + 1);
        }
        ol(this, k0, r);
      },
      flush: (r) => {
        if (Sn(this, k0) === "")
          return;
        const a = t.allowCR && Sn(this, k0).endsWith("\r") ? Sn(this, k0).slice(0, -1) : Sn(this, k0);
        r.enqueue(a);
      }
    });
    Fa(this, k0, "");
  }
}
k0 = new WeakMap();
const {
  SvelteComponent: $u,
  append_hydration: yt,
  attr: J0,
  children: en,
  claim_element: tn,
  claim_space: ni,
  claim_text: Fn,
  detach: w0,
  element: nn,
  init: Hu,
  insert_hydration: Qs,
  noop: ul,
  safe_not_equal: Uu,
  set_data: Kr,
  set_style: Ea,
  space: ri,
  text: En,
  toggle_class: cl
} = window.__gradio__svelte__internal, { onMount: Vu, createEventDispatcher: Gu, onDestroy: ju } = window.__gradio__svelte__internal;
function dl(n) {
  let e, t, r, a, i = ar(
    /*file_to_display*/
    n[2]
  ) + "", l, s, o, d, h = (
    /*file_to_display*/
    n[2].orig_name + ""
  ), f;
  return {
    c() {
      e = nn("div"), t = nn("span"), r = nn("div"), a = nn("progress"), l = En(i), o = ri(), d = nn("span"), f = En(h), this.h();
    },
    l(p) {
      e = tn(p, "DIV", { class: !0 });
      var _ = en(e);
      t = tn(_, "SPAN", {});
      var y = en(t);
      r = tn(y, "DIV", { class: !0 });
      var S = en(r);
      a = tn(S, "PROGRESS", { style: !0, max: !0, class: !0 });
      var E = en(a);
      l = Fn(E, i), E.forEach(w0), S.forEach(w0), y.forEach(w0), o = ni(_), d = tn(_, "SPAN", { class: !0 });
      var A = en(d);
      f = Fn(A, h), A.forEach(w0), _.forEach(w0), this.h();
    },
    h() {
      Ea(a, "visibility", "hidden"), Ea(a, "height", "0"), Ea(a, "width", "0"), a.value = s = ar(
        /*file_to_display*/
        n[2]
      ), J0(a, "max", "100"), J0(a, "class", "svelte-cr2edf"), J0(r, "class", "progress-bar svelte-cr2edf"), J0(d, "class", "file-name svelte-cr2edf"), J0(e, "class", "file svelte-cr2edf");
    },
    m(p, _) {
      Qs(p, e, _), yt(e, t), yt(t, r), yt(r, a), yt(a, l), yt(e, o), yt(e, d), yt(d, f);
    },
    p(p, _) {
      _ & /*file_to_display*/
      4 && i !== (i = ar(
        /*file_to_display*/
        p[2]
      ) + "") && Kr(l, i), _ & /*file_to_display*/
      4 && s !== (s = ar(
        /*file_to_display*/
        p[2]
      )) && (a.value = s), _ & /*file_to_display*/
      4 && h !== (h = /*file_to_display*/
      p[2].orig_name + "") && Kr(f, h);
    },
    d(p) {
      p && w0(e);
    }
  };
}
function Wu(n) {
  let e, t, r, a = (
    /*files_with_progress*/
    n[0].length + ""
  ), i, l, s = (
    /*files_with_progress*/
    n[0].length > 1 ? "files" : "file"
  ), o, d, h, f = (
    /*file_to_display*/
    n[2] && dl(n)
  );
  return {
    c() {
      e = nn("div"), t = nn("span"), r = En("Uploading "), i = En(a), l = ri(), o = En(s), d = En("..."), h = ri(), f && f.c(), this.h();
    },
    l(p) {
      e = tn(p, "DIV", { class: !0 });
      var _ = en(e);
      t = tn(_, "SPAN", { class: !0 });
      var y = en(t);
      r = Fn(y, "Uploading "), i = Fn(y, a), l = ni(y), o = Fn(y, s), d = Fn(y, "..."), y.forEach(w0), h = ni(_), f && f.l(_), _.forEach(w0), this.h();
    },
    h() {
      J0(t, "class", "uploading svelte-cr2edf"), J0(e, "class", "wrap svelte-cr2edf"), cl(
        e,
        "progress",
        /*progress*/
        n[1]
      );
    },
    m(p, _) {
      Qs(p, e, _), yt(e, t), yt(t, r), yt(t, i), yt(t, l), yt(t, o), yt(t, d), yt(e, h), f && f.m(e, null);
    },
    p(p, [_]) {
      _ & /*files_with_progress*/
      1 && a !== (a = /*files_with_progress*/
      p[0].length + "") && Kr(i, a), _ & /*files_with_progress*/
      1 && s !== (s = /*files_with_progress*/
      p[0].length > 1 ? "files" : "file") && Kr(o, s), /*file_to_display*/
      p[2] ? f ? f.p(p, _) : (f = dl(p), f.c(), f.m(e, null)) : f && (f.d(1), f = null), _ & /*progress*/
      2 && cl(
        e,
        "progress",
        /*progress*/
        p[1]
      );
    },
    i: ul,
    o: ul,
    d(p) {
      p && w0(e), f && f.d();
    }
  };
}
function ar(n) {
  return n.progress * 100 / (n.size || 0) || 0;
}
function Yu(n) {
  let e = 0;
  return n.forEach((t) => {
    e += ar(t);
  }), document.documentElement.style.setProperty("--upload-progress-width", (e / n.length).toFixed(2) + "%"), e / n.length;
}
function Xu(n, e, t) {
  var r = this && this.__awaiter || function(S, E, A, b) {
    function v(w) {
      return w instanceof A ? w : new A(function(C) {
        C(w);
      });
    }
    return new (A || (A = Promise))(function(w, C) {
      function T(z) {
        try {
          $(b.next(z));
        } catch (N) {
          C(N);
        }
      }
      function B(z) {
        try {
          $(b.throw(z));
        } catch (N) {
          C(N);
        }
      }
      function $(z) {
        z.done ? w(z.value) : v(z.value).then(T, B);
      }
      $((b = b.apply(S, E || [])).next());
    });
  };
  let { upload_id: a } = e, { root: i } = e, { files: l } = e, { stream_handler: s } = e, o, d = !1, h, f, p = l.map((S) => Object.assign(Object.assign({}, S), { progress: 0 }));
  const _ = Gu();
  function y(S, E) {
    t(0, p = p.map((A) => (A.orig_name === S && (A.progress += E), A)));
  }
  return Vu(() => r(void 0, void 0, void 0, function* () {
    if (o = yield s(new URL(`${i}/gradio_api/upload_progress?upload_id=${a}`)), o == null)
      throw new Error("Event source is not defined");
    o.onmessage = function(S) {
      return r(this, void 0, void 0, function* () {
        const E = JSON.parse(S.data);
        d || t(1, d = !0), E.msg === "done" ? (o == null || o.close(), _("done")) : (t(7, h = E), y(E.orig_name, E.chunk_size));
      });
    };
  })), ju(() => {
    (o != null || o != null) && o.close();
  }), n.$$set = (S) => {
    "upload_id" in S && t(3, a = S.upload_id), "root" in S && t(4, i = S.root), "files" in S && t(5, l = S.files), "stream_handler" in S && t(6, s = S.stream_handler);
  }, n.$$.update = () => {
    n.$$.dirty & /*files_with_progress*/
    1 && Yu(p), n.$$.dirty & /*current_file_upload, files_with_progress*/
    129 && t(2, f = h || p[0]);
  }, [
    p,
    d,
    f,
    a,
    i,
    l,
    s,
    h
  ];
}
class Zu extends $u {
  constructor(e) {
    super(), Hu(this, e, Xu, Wu, Uu, {
      upload_id: 3,
      root: 4,
      files: 5,
      stream_handler: 6
    });
  }
}
const {
  SvelteComponent: Ku,
  append_hydration: hl,
  attr: ot,
  binding_callbacks: Qu,
  bubble: Y0,
  check_outros: Js,
  children: eo,
  claim_component: Ju,
  claim_element: ai,
  claim_space: e1,
  create_component: t1,
  create_slot: to,
  destroy_component: n1,
  detach: Nn,
  element: ii,
  empty: Qr,
  get_all_dirty_from_scope: no,
  get_slot_changes: ro,
  group_outros: ao,
  init: r1,
  insert_hydration: da,
  listen: At,
  mount_component: a1,
  prevent_default: X0,
  run_all: i1,
  safe_not_equal: l1,
  set_style: io,
  space: s1,
  stop_propagation: Z0,
  toggle_class: nt,
  transition_in: O0,
  transition_out: hn,
  update_slot_base: lo
} = window.__gradio__svelte__internal, { createEventDispatcher: o1, tick: u1 } = window.__gradio__svelte__internal;
function c1(n) {
  let e, t, r, a, i, l, s, o, d, h, f;
  const p = (
    /*#slots*/
    n[27].default
  ), _ = to(
    p,
    n,
    /*$$scope*/
    n[26],
    null
  );
  return {
    c() {
      e = ii("button"), _ && _.c(), t = s1(), r = ii("input"), this.h();
    },
    l(y) {
      e = ai(y, "BUTTON", { tabindex: !0, class: !0 });
      var S = eo(e);
      _ && _.l(S), t = e1(S), r = ai(S, "INPUT", {
        "aria-label": !0,
        "data-testid": !0,
        type: !0,
        accept: !0,
        webkitdirectory: !0,
        mozdirectory: !0,
        class: !0
      }), S.forEach(Nn), this.h();
    },
    h() {
      ot(r, "aria-label", "file upload"), ot(r, "data-testid", "file-upload"), ot(r, "type", "file"), ot(r, "accept", a = /*accept_file_types*/
      n[16] || void 0), r.multiple = i = /*file_count*/
      n[6] === "multiple" || void 0, ot(r, "webkitdirectory", l = /*file_count*/
      n[6] === "directory" || void 0), ot(r, "mozdirectory", s = /*file_count*/
      n[6] === "directory" || void 0), ot(r, "class", "svelte-ks67v6"), ot(e, "tabindex", o = /*hidden*/
      n[9] ? -1 : 0), ot(e, "class", "svelte-ks67v6"), nt(
        e,
        "hidden",
        /*hidden*/
        n[9]
      ), nt(
        e,
        "center",
        /*center*/
        n[4]
      ), nt(
        e,
        "boundedheight",
        /*boundedheight*/
        n[3]
      ), nt(
        e,
        "flex",
        /*flex*/
        n[5]
      ), nt(
        e,
        "disable_click",
        /*disable_click*/
        n[7]
      ), io(e, "height", "100%");
    },
    m(y, S) {
      da(y, e, S), _ && _.m(e, null), hl(e, t), hl(e, r), n[35](r), d = !0, h || (f = [
        At(
          r,
          "change",
          /*load_files_from_upload*/
          n[18]
        ),
        At(e, "drag", Z0(X0(
          /*drag_handler*/
          n[28]
        ))),
        At(e, "dragstart", Z0(X0(
          /*dragstart_handler*/
          n[29]
        ))),
        At(e, "dragend", Z0(X0(
          /*dragend_handler*/
          n[30]
        ))),
        At(e, "dragover", Z0(X0(
          /*dragover_handler*/
          n[31]
        ))),
        At(e, "dragenter", Z0(X0(
          /*dragenter_handler*/
          n[32]
        ))),
        At(e, "dragleave", Z0(X0(
          /*dragleave_handler*/
          n[33]
        ))),
        At(e, "drop", Z0(X0(
          /*drop_handler*/
          n[34]
        ))),
        At(
          e,
          "click",
          /*open_file_upload*/
          n[13]
        ),
        At(
          e,
          "drop",
          /*loadFilesFromDrop*/
          n[19]
        ),
        At(
          e,
          "dragenter",
          /*updateDragging*/
          n[17]
        ),
        At(
          e,
          "dragleave",
          /*updateDragging*/
          n[17]
        )
      ], h = !0);
    },
    p(y, S) {
      _ && _.p && (!d || S[0] & /*$$scope*/
      67108864) && lo(
        _,
        p,
        y,
        /*$$scope*/
        y[26],
        d ? ro(
          p,
          /*$$scope*/
          y[26],
          S,
          null
        ) : no(
          /*$$scope*/
          y[26]
        ),
        null
      ), (!d || S[0] & /*accept_file_types*/
      65536 && a !== (a = /*accept_file_types*/
      y[16] || void 0)) && ot(r, "accept", a), (!d || S[0] & /*file_count*/
      64 && i !== (i = /*file_count*/
      y[6] === "multiple" || void 0)) && (r.multiple = i), (!d || S[0] & /*file_count*/
      64 && l !== (l = /*file_count*/
      y[6] === "directory" || void 0)) && ot(r, "webkitdirectory", l), (!d || S[0] & /*file_count*/
      64 && s !== (s = /*file_count*/
      y[6] === "directory" || void 0)) && ot(r, "mozdirectory", s), (!d || S[0] & /*hidden*/
      512 && o !== (o = /*hidden*/
      y[9] ? -1 : 0)) && ot(e, "tabindex", o), (!d || S[0] & /*hidden*/
      512) && nt(
        e,
        "hidden",
        /*hidden*/
        y[9]
      ), (!d || S[0] & /*center*/
      16) && nt(
        e,
        "center",
        /*center*/
        y[4]
      ), (!d || S[0] & /*boundedheight*/
      8) && nt(
        e,
        "boundedheight",
        /*boundedheight*/
        y[3]
      ), (!d || S[0] & /*flex*/
      32) && nt(
        e,
        "flex",
        /*flex*/
        y[5]
      ), (!d || S[0] & /*disable_click*/
      128) && nt(
        e,
        "disable_click",
        /*disable_click*/
        y[7]
      );
    },
    i(y) {
      d || (O0(_, y), d = !0);
    },
    o(y) {
      hn(_, y), d = !1;
    },
    d(y) {
      y && Nn(e), _ && _.d(y), n[35](null), h = !1, i1(f);
    }
  };
}
function d1(n) {
  let e, t, r = !/*hidden*/
  n[9] && ml(n);
  return {
    c() {
      r && r.c(), e = Qr();
    },
    l(a) {
      r && r.l(a), e = Qr();
    },
    m(a, i) {
      r && r.m(a, i), da(a, e, i), t = !0;
    },
    p(a, i) {
      /*hidden*/
      a[9] ? r && (ao(), hn(r, 1, 1, () => {
        r = null;
      }), Js()) : r ? (r.p(a, i), i[0] & /*hidden*/
      512 && O0(r, 1)) : (r = ml(a), r.c(), O0(r, 1), r.m(e.parentNode, e));
    },
    i(a) {
      t || (O0(r), t = !0);
    },
    o(a) {
      hn(r), t = !1;
    },
    d(a) {
      a && Nn(e), r && r.d(a);
    }
  };
}
function h1(n) {
  let e, t, r, a, i;
  const l = (
    /*#slots*/
    n[27].default
  ), s = to(
    l,
    n,
    /*$$scope*/
    n[26],
    null
  );
  return {
    c() {
      e = ii("button"), s && s.c(), this.h();
    },
    l(o) {
      e = ai(o, "BUTTON", { tabindex: !0, class: !0 });
      var d = eo(e);
      s && s.l(d), d.forEach(Nn), this.h();
    },
    h() {
      ot(e, "tabindex", t = /*hidden*/
      n[9] ? -1 : 0), ot(e, "class", "svelte-ks67v6"), nt(
        e,
        "hidden",
        /*hidden*/
        n[9]
      ), nt(
        e,
        "center",
        /*center*/
        n[4]
      ), nt(
        e,
        "boundedheight",
        /*boundedheight*/
        n[3]
      ), nt(
        e,
        "flex",
        /*flex*/
        n[5]
      ), io(e, "height", "100%");
    },
    m(o, d) {
      da(o, e, d), s && s.m(e, null), r = !0, a || (i = At(
        e,
        "click",
        /*paste_clipboard*/
        n[12]
      ), a = !0);
    },
    p(o, d) {
      s && s.p && (!r || d[0] & /*$$scope*/
      67108864) && lo(
        s,
        l,
        o,
        /*$$scope*/
        o[26],
        r ? ro(
          l,
          /*$$scope*/
          o[26],
          d,
          null
        ) : no(
          /*$$scope*/
          o[26]
        ),
        null
      ), (!r || d[0] & /*hidden*/
      512 && t !== (t = /*hidden*/
      o[9] ? -1 : 0)) && ot(e, "tabindex", t), (!r || d[0] & /*hidden*/
      512) && nt(
        e,
        "hidden",
        /*hidden*/
        o[9]
      ), (!r || d[0] & /*center*/
      16) && nt(
        e,
        "center",
        /*center*/
        o[4]
      ), (!r || d[0] & /*boundedheight*/
      8) && nt(
        e,
        "boundedheight",
        /*boundedheight*/
        o[3]
      ), (!r || d[0] & /*flex*/
      32) && nt(
        e,
        "flex",
        /*flex*/
        o[5]
      );
    },
    i(o) {
      r || (O0(s, o), r = !0);
    },
    o(o) {
      hn(s, o), r = !1;
    },
    d(o) {
      o && Nn(e), s && s.d(o), a = !1, i();
    }
  };
}
function ml(n) {
  let e, t;
  return e = new Zu({
    props: {
      root: (
        /*root*/
        n[8]
      ),
      upload_id: (
        /*upload_id*/
        n[14]
      ),
      files: (
        /*file_data*/
        n[15]
      ),
      stream_handler: (
        /*stream_handler*/
        n[11]
      )
    }
  }), {
    c() {
      t1(e.$$.fragment);
    },
    l(r) {
      Ju(e.$$.fragment, r);
    },
    m(r, a) {
      a1(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*root*/
      256 && (i.root = /*root*/
      r[8]), a[0] & /*upload_id*/
      16384 && (i.upload_id = /*upload_id*/
      r[14]), a[0] & /*file_data*/
      32768 && (i.files = /*file_data*/
      r[15]), a[0] & /*stream_handler*/
      2048 && (i.stream_handler = /*stream_handler*/
      r[11]), e.$set(i);
    },
    i(r) {
      t || (O0(e.$$.fragment, r), t = !0);
    },
    o(r) {
      hn(e.$$.fragment, r), t = !1;
    },
    d(r) {
      n1(e, r);
    }
  };
}
function m1(n) {
  let e, t, r, a;
  const i = [h1, d1, c1], l = [];
  function s(o, d) {
    return (
      /*filetype*/
      o[0] === "clipboard" ? 0 : (
        /*uploading*/
        o[1] && /*show_progress*/
        o[10] ? 1 : 2
      )
    );
  }
  return e = s(n), t = l[e] = i[e](n), {
    c() {
      t.c(), r = Qr();
    },
    l(o) {
      t.l(o), r = Qr();
    },
    m(o, d) {
      l[e].m(o, d), da(o, r, d), a = !0;
    },
    p(o, d) {
      let h = e;
      e = s(o), e === h ? l[e].p(o, d) : (ao(), hn(l[h], 1, 1, () => {
        l[h] = null;
      }), Js(), t = l[e], t ? t.p(o, d) : (t = l[e] = i[e](o), t.c()), O0(t, 1), t.m(r.parentNode, r));
    },
    i(o) {
      a || (O0(t), a = !0);
    },
    o(o) {
      hn(t), a = !1;
    },
    d(o) {
      o && Nn(r), l[e].d(o);
    }
  };
}
function f1(n, e, t) {
  if (!n || n === "*" || n === "file/*" || Array.isArray(n) && n.some((a) => a === "*" || a === "file/*"))
    return !0;
  let r;
  if (typeof n == "string")
    r = n.split(",").map((a) => a.trim());
  else if (Array.isArray(n))
    r = n;
  else
    return !1;
  return r.includes(e) || r.some((a) => {
    const [i] = a.split("/").map((l) => l.trim());
    return a.endsWith("/*") && t.startsWith(i + "/");
  });
}
function p1(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e;
  var l = this && this.__awaiter || function(R, te, ae, ue) {
    function _e(Le) {
      return Le instanceof ae ? Le : new ae(function(je) {
        je(Le);
      });
    }
    return new (ae || (ae = Promise))(function(Le, je) {
      function ze(pt) {
        try {
          Oe(ue.next(pt));
        } catch (Qt) {
          je(Qt);
        }
      }
      function Xe(pt) {
        try {
          Oe(ue.throw(pt));
        } catch (Qt) {
          je(Qt);
        }
      }
      function Oe(pt) {
        pt.done ? Le(pt.value) : _e(pt.value).then(ze, Xe);
      }
      Oe((ue = ue.apply(R, te || [])).next());
    });
  };
  let { filetype: s = null } = e, { dragging: o = !1 } = e, { boundedheight: d = !0 } = e, { center: h = !0 } = e, { flex: f = !0 } = e, { file_count: p = "single" } = e, { disable_click: _ = !1 } = e, { root: y } = e, { hidden: S = !1 } = e, { format: E = "file" } = e, { uploading: A = !1 } = e, { hidden_upload: b = null } = e, { show_progress: v = !0 } = e, { max_file_size: w = null } = e, { upload: C } = e, { stream_handler: T } = e, B, $, z, N = null;
  const j = () => {
    if (typeof navigator < "u") {
      const R = navigator.userAgent.toLowerCase();
      return R.indexOf("iphone") > -1 || R.indexOf("ipad") > -1;
    }
    return !1;
  }, W = o1(), ye = ["image", "video", "audio", "text", "file"], Z = (R) => r && R.startsWith(".") ? (N = !0, R) : r && R.includes("file/*") ? "*" : R.startsWith(".") || R.endsWith("/*") ? R : ye.includes(R) ? R + "/*" : "." + R;
  function pe() {
    t(20, o = !o);
  }
  function ke() {
    navigator.clipboard.read().then((R) => l(this, void 0, void 0, function* () {
      for (let te = 0; te < R.length; te++) {
        const ae = R[te].types.find((ue) => ue.startsWith("image/"));
        if (ae) {
          R[te].getType(ae).then((ue) => l(this, void 0, void 0, function* () {
            const _e = new File([ue], `clipboard.${ae.replace("image/", "")}`);
            yield Ae([_e]);
          }));
          break;
        }
      }
    }));
  }
  function Re() {
    _ || b && (t(2, b.value = "", b), b.click());
  }
  function se(R) {
    return l(this, void 0, void 0, function* () {
      yield u1(), t(14, B = Math.random().toString(36).substring(2, 15)), t(1, A = !0);
      try {
        const te = yield C(R, y, B, w ?? 1 / 0);
        return W("load", p === "single" ? te == null ? void 0 : te[0] : te), t(1, A = !1), te || [];
      } catch (te) {
        return W("error", te.message), t(1, A = !1), [];
      }
    });
  }
  function Ae(R) {
    return l(this, void 0, void 0, function* () {
      if (!R.length)
        return;
      let te = R.map((ae) => new File([ae], ae instanceof File ? ae.name : "file", { type: ae.type }));
      return r && N && (te = te.filter((ae) => xe(ae) ? !0 : (W("error", `Invalid file type: ${ae.name}. Only ${s} allowed.`), !1)), te.length === 0) ? [] : (t(15, $ = yield Ou(te)), yield se($));
    });
  }
  function xe(R) {
    return s ? (Array.isArray(s) ? s : [s]).some((ae) => {
      const ue = Z(ae);
      if (ue.startsWith("."))
        return R.name.toLowerCase().endsWith(ue.toLowerCase());
      if (ue === "*")
        return !0;
      if (ue.endsWith("/*")) {
        const [_e] = ue.split("/");
        return R.type.startsWith(_e + "/");
      }
      return R.type === ue;
    }) : !0;
  }
  function ie(R) {
    return l(this, void 0, void 0, function* () {
      const te = R.target;
      if (te.files)
        if (E != "blob")
          yield Ae(Array.from(te.files));
        else {
          if (p === "single") {
            W("load", te.files[0]);
            return;
          }
          W("load", te.files);
        }
    });
  }
  function ce(R) {
    return l(this, void 0, void 0, function* () {
      var te;
      if (t(20, o = !1), !(!((te = R.dataTransfer) === null || te === void 0) && te.files)) return;
      const ae = Array.from(R.dataTransfer.files).filter((ue) => {
        const _e = "." + ue.name.split(".").pop();
        return _e && f1(z, _e, ue.type) || (_e && Array.isArray(s) ? s.includes(_e) : _e === s) ? !0 : (W("error", `Invalid file type only ${s} allowed.`), !1);
      });
      if (E != "blob")
        yield Ae(ae);
      else {
        if (p === "single") {
          W("load", ae[0]);
          return;
        }
        W("load", ae);
      }
    });
  }
  function de(R) {
    Y0.call(this, n, R);
  }
  function ge(R) {
    Y0.call(this, n, R);
  }
  function P(R) {
    Y0.call(this, n, R);
  }
  function Ie(R) {
    Y0.call(this, n, R);
  }
  function Ee(R) {
    Y0.call(this, n, R);
  }
  function L(R) {
    Y0.call(this, n, R);
  }
  function he(R) {
    Y0.call(this, n, R);
  }
  function we(R) {
    Qu[R ? "unshift" : "push"](() => {
      b = R, t(2, b);
    });
  }
  return n.$$set = (R) => {
    "filetype" in R && t(0, s = R.filetype), "dragging" in R && t(20, o = R.dragging), "boundedheight" in R && t(3, d = R.boundedheight), "center" in R && t(4, h = R.center), "flex" in R && t(5, f = R.flex), "file_count" in R && t(6, p = R.file_count), "disable_click" in R && t(7, _ = R.disable_click), "root" in R && t(8, y = R.root), "hidden" in R && t(9, S = R.hidden), "format" in R && t(21, E = R.format), "uploading" in R && t(1, A = R.uploading), "hidden_upload" in R && t(2, b = R.hidden_upload), "show_progress" in R && t(10, v = R.show_progress), "max_file_size" in R && t(22, w = R.max_file_size), "upload" in R && t(23, C = R.upload), "stream_handler" in R && t(11, T = R.stream_handler), "$$scope" in R && t(26, i = R.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*filetype, ios*/
    33554433 && (s == null ? t(16, z = null) : typeof s == "string" ? t(16, z = Z(s)) : r && s.includes("file/*") ? t(16, z = "*") : (t(0, s = s.map(Z)), t(16, z = s.join(", "))));
  }, t(25, r = j()), [
    s,
    A,
    b,
    d,
    h,
    f,
    p,
    _,
    y,
    S,
    v,
    T,
    ke,
    Re,
    B,
    $,
    z,
    pe,
    ie,
    ce,
    o,
    E,
    w,
    C,
    Ae,
    r,
    i,
    a,
    de,
    ge,
    P,
    Ie,
    Ee,
    L,
    he,
    we
  ];
}
class _1 extends Ku {
  constructor(e) {
    super(), r1(
      this,
      e,
      p1,
      m1,
      l1,
      {
        filetype: 0,
        dragging: 20,
        boundedheight: 3,
        center: 4,
        flex: 5,
        file_count: 6,
        disable_click: 7,
        root: 8,
        hidden: 9,
        format: 21,
        uploading: 1,
        hidden_upload: 2,
        show_progress: 10,
        max_file_size: 22,
        upload: 23,
        stream_handler: 11,
        paste_clipboard: 12,
        open_file_upload: 13,
        load_files: 24
      },
      null,
      [-1, -1]
    );
  }
  get paste_clipboard() {
    return this.$$.ctx[12];
  }
  get open_file_upload() {
    return this.$$.ctx[13];
  }
  get load_files() {
    return this.$$.ctx[24];
  }
}
const {
  SvelteComponent: g1,
  assign: v1,
  children: b1,
  claim_element: y1,
  create_slot: w1,
  detach: fl,
  element: k1,
  get_all_dirty_from_scope: D1,
  get_slot_changes: S1,
  get_spread_update: A1,
  init: x1,
  insert_hydration: F1,
  safe_not_equal: E1,
  set_dynamic_element_data: pl,
  set_style: at,
  toggle_class: Tt,
  transition_in: so,
  transition_out: oo,
  update_slot_base: C1
} = window.__gradio__svelte__internal;
function T1(n) {
  let e, t, r;
  const a = (
    /*#slots*/
    n[22].default
  ), i = w1(
    a,
    n,
    /*$$scope*/
    n[21],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      n[10]
    ) },
    { id: (
      /*elem_id*/
      n[5]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      n[6].join(" ") + " svelte-1ezsyiy"
    }
  ], s = {};
  for (let o = 0; o < l.length; o += 1)
    s = v1(s, l[o]);
  return {
    c() {
      e = k1(
        /*tag*/
        n[18]
      ), i && i.c(), this.h();
    },
    l(o) {
      e = y1(
        o,
        /*tag*/
        (n[18] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0
        }
      );
      var d = b1(e);
      i && i.l(d), d.forEach(fl), this.h();
    },
    h() {
      pl(
        /*tag*/
        n[18]
      )(e, s), Tt(
        e,
        "hidden",
        /*visible*/
        n[13] === !1
      ), Tt(
        e,
        "padded",
        /*padding*/
        n[9]
      ), Tt(
        e,
        "flex",
        /*flex*/
        n[0]
      ), Tt(
        e,
        "border_focus",
        /*border_mode*/
        n[8] === "focus"
      ), Tt(
        e,
        "border_contrast",
        /*border_mode*/
        n[8] === "contrast"
      ), Tt(e, "hide-container", !/*explicit_call*/
      n[11] && !/*container*/
      n[12]), at(
        e,
        "height",
        /*get_dimension*/
        n[19](
          /*height*/
          n[1]
        )
      ), at(
        e,
        "min-height",
        /*get_dimension*/
        n[19](
          /*min_height*/
          n[2]
        )
      ), at(
        e,
        "max-height",
        /*get_dimension*/
        n[19](
          /*max_height*/
          n[3]
        )
      ), at(e, "width", typeof /*width*/
      n[4] == "number" ? `calc(min(${/*width*/
      n[4]}px, 100%))` : (
        /*get_dimension*/
        n[19](
          /*width*/
          n[4]
        )
      )), at(
        e,
        "border-style",
        /*variant*/
        n[7]
      ), at(
        e,
        "overflow",
        /*allow_overflow*/
        n[14] ? (
          /*overflow_behavior*/
          n[15]
        ) : "hidden"
      ), at(
        e,
        "flex-grow",
        /*scale*/
        n[16]
      ), at(e, "min-width", `calc(min(${/*min_width*/
      n[17]}px, 100%))`), at(e, "border-width", "var(--block-border-width)");
    },
    m(o, d) {
      F1(o, e, d), i && i.m(e, null), r = !0;
    },
    p(o, d) {
      i && i.p && (!r || d & /*$$scope*/
      2097152) && C1(
        i,
        a,
        o,
        /*$$scope*/
        o[21],
        r ? S1(
          a,
          /*$$scope*/
          o[21],
          d,
          null
        ) : D1(
          /*$$scope*/
          o[21]
        ),
        null
      ), pl(
        /*tag*/
        o[18]
      )(e, s = A1(l, [
        (!r || d & /*test_id*/
        1024) && { "data-testid": (
          /*test_id*/
          o[10]
        ) },
        (!r || d & /*elem_id*/
        32) && { id: (
          /*elem_id*/
          o[5]
        ) },
        (!r || d & /*elem_classes*/
        64 && t !== (t = "block " + /*elem_classes*/
        o[6].join(" ") + " svelte-1ezsyiy")) && { class: t }
      ])), Tt(
        e,
        "hidden",
        /*visible*/
        o[13] === !1
      ), Tt(
        e,
        "padded",
        /*padding*/
        o[9]
      ), Tt(
        e,
        "flex",
        /*flex*/
        o[0]
      ), Tt(
        e,
        "border_focus",
        /*border_mode*/
        o[8] === "focus"
      ), Tt(
        e,
        "border_contrast",
        /*border_mode*/
        o[8] === "contrast"
      ), Tt(e, "hide-container", !/*explicit_call*/
      o[11] && !/*container*/
      o[12]), d & /*height*/
      2 && at(
        e,
        "height",
        /*get_dimension*/
        o[19](
          /*height*/
          o[1]
        )
      ), d & /*min_height*/
      4 && at(
        e,
        "min-height",
        /*get_dimension*/
        o[19](
          /*min_height*/
          o[2]
        )
      ), d & /*max_height*/
      8 && at(
        e,
        "max-height",
        /*get_dimension*/
        o[19](
          /*max_height*/
          o[3]
        )
      ), d & /*width*/
      16 && at(e, "width", typeof /*width*/
      o[4] == "number" ? `calc(min(${/*width*/
      o[4]}px, 100%))` : (
        /*get_dimension*/
        o[19](
          /*width*/
          o[4]
        )
      )), d & /*variant*/
      128 && at(
        e,
        "border-style",
        /*variant*/
        o[7]
      ), d & /*allow_overflow, overflow_behavior*/
      49152 && at(
        e,
        "overflow",
        /*allow_overflow*/
        o[14] ? (
          /*overflow_behavior*/
          o[15]
        ) : "hidden"
      ), d & /*scale*/
      65536 && at(
        e,
        "flex-grow",
        /*scale*/
        o[16]
      ), d & /*min_width*/
      131072 && at(e, "min-width", `calc(min(${/*min_width*/
      o[17]}px, 100%))`);
    },
    i(o) {
      r || (so(i, o), r = !0);
    },
    o(o) {
      oo(i, o), r = !1;
    },
    d(o) {
      o && fl(e), i && i.d(o);
    }
  };
}
function M1(n) {
  let e, t = (
    /*tag*/
    n[18] && T1(n)
  );
  return {
    c() {
      t && t.c();
    },
    l(r) {
      t && t.l(r);
    },
    m(r, a) {
      t && t.m(r, a), e = !0;
    },
    p(r, [a]) {
      /*tag*/
      r[18] && t.p(r, a);
    },
    i(r) {
      e || (so(t, r), e = !0);
    },
    o(r) {
      oo(t, r), e = !1;
    },
    d(r) {
      t && t.d(r);
    }
  };
}
function z1(n, e, t) {
  let { $$slots: r = {}, $$scope: a } = e, { height: i = void 0 } = e, { min_height: l = void 0 } = e, { max_height: s = void 0 } = e, { width: o = void 0 } = e, { elem_id: d = "" } = e, { elem_classes: h = [] } = e, { variant: f = "solid" } = e, { border_mode: p = "base" } = e, { padding: _ = !0 } = e, { type: y = "normal" } = e, { test_id: S = void 0 } = e, { explicit_call: E = !1 } = e, { container: A = !0 } = e, { visible: b = !0 } = e, { allow_overflow: v = !0 } = e, { overflow_behavior: w = "auto" } = e, { scale: C = null } = e, { min_width: T = 0 } = e, { flex: B = !1 } = e;
  b || (B = !1);
  let $ = y === "fieldset" ? "fieldset" : "div";
  const z = (N) => {
    if (N !== void 0) {
      if (typeof N == "number")
        return N + "px";
      if (typeof N == "string")
        return N;
    }
  };
  return n.$$set = (N) => {
    "height" in N && t(1, i = N.height), "min_height" in N && t(2, l = N.min_height), "max_height" in N && t(3, s = N.max_height), "width" in N && t(4, o = N.width), "elem_id" in N && t(5, d = N.elem_id), "elem_classes" in N && t(6, h = N.elem_classes), "variant" in N && t(7, f = N.variant), "border_mode" in N && t(8, p = N.border_mode), "padding" in N && t(9, _ = N.padding), "type" in N && t(20, y = N.type), "test_id" in N && t(10, S = N.test_id), "explicit_call" in N && t(11, E = N.explicit_call), "container" in N && t(12, A = N.container), "visible" in N && t(13, b = N.visible), "allow_overflow" in N && t(14, v = N.allow_overflow), "overflow_behavior" in N && t(15, w = N.overflow_behavior), "scale" in N && t(16, C = N.scale), "min_width" in N && t(17, T = N.min_width), "flex" in N && t(0, B = N.flex), "$$scope" in N && t(21, a = N.$$scope);
  }, [
    B,
    i,
    l,
    s,
    o,
    d,
    h,
    f,
    p,
    _,
    S,
    E,
    A,
    b,
    v,
    w,
    C,
    T,
    $,
    z,
    y,
    a,
    r
  ];
}
class B1 extends g1 {
  constructor(e) {
    super(), x1(this, e, z1, M1, E1, {
      height: 1,
      min_height: 2,
      max_height: 3,
      width: 4,
      elem_id: 5,
      elem_classes: 6,
      variant: 7,
      border_mode: 8,
      padding: 9,
      type: 20,
      test_id: 10,
      explicit_call: 11,
      container: 12,
      visible: 13,
      allow_overflow: 14,
      overflow_behavior: 15,
      scale: 16,
      min_width: 17,
      flex: 0
    });
  }
}
class Ei {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, r) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = r;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new Ei(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class Ci {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new Ci(t, Ei.range(this, e));
  }
}
class J {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var r = "KaTeX parse error: " + e, a, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var s = l.lexer.input;
      a = l.start, i = l.end, a === s.length ? r += " at end of input: " : r += " at position " + (a + 1) + ": ";
      var o = s.slice(a, i).replace(/[^]/g, "$&̲"), d;
      a > 15 ? d = "…" + s.slice(a - 15, a) : d = s.slice(0, a);
      var h;
      i + 15 < s.length ? h = s.slice(i, i + 15) + "…" : h = s.slice(i), r += d + o + h;
    }
    var f = new Error(r);
    return f.name = "ParseError", f.__proto__ = J.prototype, f.position = a, a != null && i != null && (f.length = i - a), f.rawMessage = e, f;
  }
}
J.prototype.__proto__ = Error.prototype;
var q1 = function(e, t) {
  return e === void 0 ? t : e;
}, N1 = /([A-Z])/g, R1 = function(e) {
  return e.replace(N1, "-$1").toLowerCase();
}, I1 = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, L1 = /[&><"']/g;
function O1(n) {
  return String(n).replace(L1, (e) => I1[e]);
}
var uo = function n(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? n(e.body[0]) : e : e.type === "font" ? n(e.body) : e;
}, P1 = function(e) {
  var t = uo(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, $1 = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, H1 = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, Fe = {
  deflt: q1,
  escape: O1,
  hyphenate: R1,
  getBaseElem: uo,
  isCharacterBox: P1,
  protocolFromUrl: H1
};
class B0 {
  constructor(e, t, r) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = r;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return t0[U1[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return t0[V1[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return t0[G1[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return t0[j1[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return t0[W1[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return t0[Y1[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var Ti = 0, Jr = 1, Bn = 2, S0 = 3, fr = 4, qt = 5, Rn = 6, dt = 7, t0 = [new B0(Ti, 0, !1), new B0(Jr, 0, !0), new B0(Bn, 1, !1), new B0(S0, 1, !0), new B0(fr, 2, !1), new B0(qt, 2, !0), new B0(Rn, 3, !1), new B0(dt, 3, !0)], U1 = [fr, qt, fr, qt, Rn, dt, Rn, dt], V1 = [qt, qt, qt, qt, dt, dt, dt, dt], G1 = [Bn, S0, fr, qt, Rn, dt, Rn, dt], j1 = [S0, S0, qt, qt, dt, dt, dt, dt], W1 = [Jr, Jr, S0, S0, qt, qt, dt, dt], Y1 = [Ti, Jr, Bn, S0, Bn, S0, Bn, S0], re = {
  DISPLAY: t0[Ti],
  TEXT: t0[Bn],
  SCRIPT: t0[fr],
  SCRIPTSCRIPT: t0[Rn]
}, li = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function X1(n) {
  for (var e = 0; e < li.length; e++)
    for (var t = li[e], r = 0; r < t.blocks.length; r++) {
      var a = t.blocks[r];
      if (n >= a[0] && n <= a[1])
        return t.name;
    }
  return null;
}
var jr = [];
li.forEach((n) => n.blocks.forEach((e) => jr.push(...e)));
function Z1(n) {
  for (var e = 0; e < jr.length; e += 2)
    if (n >= jr[e] && n <= jr[e + 1])
      return !0;
  return !1;
}
var An = 80, K1 = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, Q1 = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, J1 = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, ec = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, tc = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, nc = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, rc = function(e, t, r) {
  var a = r - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, ac = function(e, t, r) {
  t = 1e3 * t;
  var a = "";
  switch (e) {
    case "sqrtMain":
      a = K1(t, An);
      break;
    case "sqrtSize1":
      a = Q1(t, An);
      break;
    case "sqrtSize2":
      a = J1(t, An);
      break;
    case "sqrtSize3":
      a = ec(t, An);
      break;
    case "sqrtSize4":
      a = tc(t, An);
      break;
    case "sqrtTall":
      a = rc(t, An, r);
  }
  return a;
}, ic = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, _l = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, lc = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class vr {
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var D0 = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, gl = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function Mi(n, e, t) {
  if (!D0[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var r = n.charCodeAt(0), a = D0[e][r];
  if (!a && n[0] in gl && (r = gl[n[0]].charCodeAt(0), a = D0[e][r]), !a && t === "text" && Z1(r) && (a = D0[e][77]), a)
    return {
      depth: a[0],
      height: a[1],
      italic: a[2],
      skew: a[3],
      width: a[4]
    };
}
var si = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, sc = {
  ex: !0,
  em: !0,
  mu: !0
}, oc = function(e) {
  return typeof e != "string" && (e = e.unit), e in si || e in sc || e === "ex";
}, Ue = function(e, t) {
  var r;
  if (e.unit in si)
    r = si[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    r = t.fontMetrics().cssEmPerMu;
  else {
    var a;
    if (t.style.isTight() ? a = t.havingStyle(t.style.text()) : a = t, e.unit === "ex")
      r = a.fontMetrics().xHeight;
    else if (e.unit === "em")
      r = a.fontMetrics().quad;
    else
      throw new J("Invalid unit: '" + e.unit + "'");
    a !== t && (r *= a.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * r, t.maxSize);
}, V = function(e) {
  return +e.toFixed(4) + "em";
}, P0 = function(e) {
  return e.filter((t) => t).join(" ");
}, co = function(e, t, r) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = r || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var a = t.getColor();
    a && (this.style.color = a);
  }
}, ho = function(e) {
  var t = document.createElement(e);
  t.className = P0(this.classes);
  for (var r in this.style)
    this.style.hasOwnProperty(r) && (t.style[r] = this.style[r]);
  for (var a in this.attributes)
    this.attributes.hasOwnProperty(a) && t.setAttribute(a, this.attributes[a]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, uc = /[\s"'>/=\x00-\x1f]/, mo = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + Fe.escape(P0(this.classes)) + '"');
  var r = "";
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (r += Fe.hyphenate(a) + ":" + this.style[a] + ";");
  r && (t += ' style="' + Fe.escape(r) + '"');
  for (var i in this.attributes)
    if (this.attributes.hasOwnProperty(i)) {
      if (uc.test(i))
        throw new J("Invalid attribute name '" + i + "'");
      t += " " + i + '="' + Fe.escape(this.attributes[i]) + '"';
    }
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class ha {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, co.call(this, e, r, a), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  toNode() {
    return ho.call(this, "span");
  }
  toMarkup() {
    return mo.call(this, "span");
  }
}
class fo {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, co.call(this, t, a), this.children = r || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  toNode() {
    return ho.call(this, "a");
  }
  toMarkup() {
    return mo.call(this, "a");
  }
}
class cc {
  constructor(e, t, r) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = r;
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + Fe.escape(this.src) + '"' + (' alt="' + Fe.escape(this.alt) + '"'), t = "";
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t += Fe.hyphenate(r) + ":" + this.style[r] + ";");
    return t && (e += ' style="' + Fe.escape(t) + '"'), e += "'/>", e;
  }
}
var dc = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class m0 {
  constructor(e, t, r, a, i, l, s, o) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = r || 0, this.italic = a || 0, this.skew = i || 0, this.width = l || 0, this.classes = s || [], this.style = o || {}, this.maxFontSize = 0;
    var d = X1(this.text.charCodeAt(0));
    d && this.classes.push(d + "_fallback"), /[îïíì]/.test(this.text) && (this.text = dc[this.text]);
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = V(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = P0(this.classes));
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t = t || document.createElement("span"), t.style[r] = this.style[r]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += Fe.escape(P0(this.classes)), t += '"');
    var r = "";
    this.italic > 0 && (r += "margin-right:" + this.italic + "em;");
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (r += Fe.hyphenate(a) + ":" + this.style[a] + ";");
    r && (e = !0, t += ' style="' + Fe.escape(r) + '"');
    var i = Fe.escape(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class $0 {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    for (var a = 0; a < this.children.length; a++)
      t.appendChild(this.children[a].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + Fe.escape(this.attributes[t]) + '"');
    e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</svg>", e;
  }
}
class mn {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", _l[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + Fe.escape(this.alternate) + '"/>' : '<path d="' + Fe.escape(_l[this.pathName]) + '"/>';
  }
}
class vl {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + Fe.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function bl(n) {
  if (n instanceof m0)
    return n;
  throw new Error("Expected symbolNode but got " + String(n) + ".");
}
function hc(n) {
  if (n instanceof ha)
    return n;
  throw new Error("Expected span<HtmlDomNode> but got " + String(n) + ".");
}
var mc = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, Ke = {
  math: {},
  text: {}
};
function u(n, e, t, r, a, i) {
  Ke[n][a] = {
    font: e,
    group: t,
    replace: r
  }, i && r && (Ke[n][r] = Ke[n][a]);
}
var c = "math", I = "text", m = "main", k = "ams", $e = "accent-token", Y = "bin", ft = "close", Hn = "inner", ne = "mathord", et = "op-token", Et = "open", ma = "punct", D = "rel", F0 = "spacing", F = "textord";
u(c, m, D, "≡", "\\equiv", !0);
u(c, m, D, "≺", "\\prec", !0);
u(c, m, D, "≻", "\\succ", !0);
u(c, m, D, "∼", "\\sim", !0);
u(c, m, D, "⊥", "\\perp");
u(c, m, D, "⪯", "\\preceq", !0);
u(c, m, D, "⪰", "\\succeq", !0);
u(c, m, D, "≃", "\\simeq", !0);
u(c, m, D, "∣", "\\mid", !0);
u(c, m, D, "≪", "\\ll", !0);
u(c, m, D, "≫", "\\gg", !0);
u(c, m, D, "≍", "\\asymp", !0);
u(c, m, D, "∥", "\\parallel");
u(c, m, D, "⋈", "\\bowtie", !0);
u(c, m, D, "⌣", "\\smile", !0);
u(c, m, D, "⊑", "\\sqsubseteq", !0);
u(c, m, D, "⊒", "\\sqsupseteq", !0);
u(c, m, D, "≐", "\\doteq", !0);
u(c, m, D, "⌢", "\\frown", !0);
u(c, m, D, "∋", "\\ni", !0);
u(c, m, D, "∝", "\\propto", !0);
u(c, m, D, "⊢", "\\vdash", !0);
u(c, m, D, "⊣", "\\dashv", !0);
u(c, m, D, "∋", "\\owns");
u(c, m, ma, ".", "\\ldotp");
u(c, m, ma, "⋅", "\\cdotp");
u(c, m, F, "#", "\\#");
u(I, m, F, "#", "\\#");
u(c, m, F, "&", "\\&");
u(I, m, F, "&", "\\&");
u(c, m, F, "ℵ", "\\aleph", !0);
u(c, m, F, "∀", "\\forall", !0);
u(c, m, F, "ℏ", "\\hbar", !0);
u(c, m, F, "∃", "\\exists", !0);
u(c, m, F, "∇", "\\nabla", !0);
u(c, m, F, "♭", "\\flat", !0);
u(c, m, F, "ℓ", "\\ell", !0);
u(c, m, F, "♮", "\\natural", !0);
u(c, m, F, "♣", "\\clubsuit", !0);
u(c, m, F, "℘", "\\wp", !0);
u(c, m, F, "♯", "\\sharp", !0);
u(c, m, F, "♢", "\\diamondsuit", !0);
u(c, m, F, "ℜ", "\\Re", !0);
u(c, m, F, "♡", "\\heartsuit", !0);
u(c, m, F, "ℑ", "\\Im", !0);
u(c, m, F, "♠", "\\spadesuit", !0);
u(c, m, F, "§", "\\S", !0);
u(I, m, F, "§", "\\S");
u(c, m, F, "¶", "\\P", !0);
u(I, m, F, "¶", "\\P");
u(c, m, F, "†", "\\dag");
u(I, m, F, "†", "\\dag");
u(I, m, F, "†", "\\textdagger");
u(c, m, F, "‡", "\\ddag");
u(I, m, F, "‡", "\\ddag");
u(I, m, F, "‡", "\\textdaggerdbl");
u(c, m, ft, "⎱", "\\rmoustache", !0);
u(c, m, Et, "⎰", "\\lmoustache", !0);
u(c, m, ft, "⟯", "\\rgroup", !0);
u(c, m, Et, "⟮", "\\lgroup", !0);
u(c, m, Y, "∓", "\\mp", !0);
u(c, m, Y, "⊖", "\\ominus", !0);
u(c, m, Y, "⊎", "\\uplus", !0);
u(c, m, Y, "⊓", "\\sqcap", !0);
u(c, m, Y, "∗", "\\ast");
u(c, m, Y, "⊔", "\\sqcup", !0);
u(c, m, Y, "◯", "\\bigcirc", !0);
u(c, m, Y, "∙", "\\bullet", !0);
u(c, m, Y, "‡", "\\ddagger");
u(c, m, Y, "≀", "\\wr", !0);
u(c, m, Y, "⨿", "\\amalg");
u(c, m, Y, "&", "\\And");
u(c, m, D, "⟵", "\\longleftarrow", !0);
u(c, m, D, "⇐", "\\Leftarrow", !0);
u(c, m, D, "⟸", "\\Longleftarrow", !0);
u(c, m, D, "⟶", "\\longrightarrow", !0);
u(c, m, D, "⇒", "\\Rightarrow", !0);
u(c, m, D, "⟹", "\\Longrightarrow", !0);
u(c, m, D, "↔", "\\leftrightarrow", !0);
u(c, m, D, "⟷", "\\longleftrightarrow", !0);
u(c, m, D, "⇔", "\\Leftrightarrow", !0);
u(c, m, D, "⟺", "\\Longleftrightarrow", !0);
u(c, m, D, "↦", "\\mapsto", !0);
u(c, m, D, "⟼", "\\longmapsto", !0);
u(c, m, D, "↗", "\\nearrow", !0);
u(c, m, D, "↩", "\\hookleftarrow", !0);
u(c, m, D, "↪", "\\hookrightarrow", !0);
u(c, m, D, "↘", "\\searrow", !0);
u(c, m, D, "↼", "\\leftharpoonup", !0);
u(c, m, D, "⇀", "\\rightharpoonup", !0);
u(c, m, D, "↙", "\\swarrow", !0);
u(c, m, D, "↽", "\\leftharpoondown", !0);
u(c, m, D, "⇁", "\\rightharpoondown", !0);
u(c, m, D, "↖", "\\nwarrow", !0);
u(c, m, D, "⇌", "\\rightleftharpoons", !0);
u(c, k, D, "≮", "\\nless", !0);
u(c, k, D, "", "\\@nleqslant");
u(c, k, D, "", "\\@nleqq");
u(c, k, D, "⪇", "\\lneq", !0);
u(c, k, D, "≨", "\\lneqq", !0);
u(c, k, D, "", "\\@lvertneqq");
u(c, k, D, "⋦", "\\lnsim", !0);
u(c, k, D, "⪉", "\\lnapprox", !0);
u(c, k, D, "⊀", "\\nprec", !0);
u(c, k, D, "⋠", "\\npreceq", !0);
u(c, k, D, "⋨", "\\precnsim", !0);
u(c, k, D, "⪹", "\\precnapprox", !0);
u(c, k, D, "≁", "\\nsim", !0);
u(c, k, D, "", "\\@nshortmid");
u(c, k, D, "∤", "\\nmid", !0);
u(c, k, D, "⊬", "\\nvdash", !0);
u(c, k, D, "⊭", "\\nvDash", !0);
u(c, k, D, "⋪", "\\ntriangleleft");
u(c, k, D, "⋬", "\\ntrianglelefteq", !0);
u(c, k, D, "⊊", "\\subsetneq", !0);
u(c, k, D, "", "\\@varsubsetneq");
u(c, k, D, "⫋", "\\subsetneqq", !0);
u(c, k, D, "", "\\@varsubsetneqq");
u(c, k, D, "≯", "\\ngtr", !0);
u(c, k, D, "", "\\@ngeqslant");
u(c, k, D, "", "\\@ngeqq");
u(c, k, D, "⪈", "\\gneq", !0);
u(c, k, D, "≩", "\\gneqq", !0);
u(c, k, D, "", "\\@gvertneqq");
u(c, k, D, "⋧", "\\gnsim", !0);
u(c, k, D, "⪊", "\\gnapprox", !0);
u(c, k, D, "⊁", "\\nsucc", !0);
u(c, k, D, "⋡", "\\nsucceq", !0);
u(c, k, D, "⋩", "\\succnsim", !0);
u(c, k, D, "⪺", "\\succnapprox", !0);
u(c, k, D, "≆", "\\ncong", !0);
u(c, k, D, "", "\\@nshortparallel");
u(c, k, D, "∦", "\\nparallel", !0);
u(c, k, D, "⊯", "\\nVDash", !0);
u(c, k, D, "⋫", "\\ntriangleright");
u(c, k, D, "⋭", "\\ntrianglerighteq", !0);
u(c, k, D, "", "\\@nsupseteqq");
u(c, k, D, "⊋", "\\supsetneq", !0);
u(c, k, D, "", "\\@varsupsetneq");
u(c, k, D, "⫌", "\\supsetneqq", !0);
u(c, k, D, "", "\\@varsupsetneqq");
u(c, k, D, "⊮", "\\nVdash", !0);
u(c, k, D, "⪵", "\\precneqq", !0);
u(c, k, D, "⪶", "\\succneqq", !0);
u(c, k, D, "", "\\@nsubseteqq");
u(c, k, Y, "⊴", "\\unlhd");
u(c, k, Y, "⊵", "\\unrhd");
u(c, k, D, "↚", "\\nleftarrow", !0);
u(c, k, D, "↛", "\\nrightarrow", !0);
u(c, k, D, "⇍", "\\nLeftarrow", !0);
u(c, k, D, "⇏", "\\nRightarrow", !0);
u(c, k, D, "↮", "\\nleftrightarrow", !0);
u(c, k, D, "⇎", "\\nLeftrightarrow", !0);
u(c, k, D, "△", "\\vartriangle");
u(c, k, F, "ℏ", "\\hslash");
u(c, k, F, "▽", "\\triangledown");
u(c, k, F, "◊", "\\lozenge");
u(c, k, F, "Ⓢ", "\\circledS");
u(c, k, F, "®", "\\circledR");
u(I, k, F, "®", "\\circledR");
u(c, k, F, "∡", "\\measuredangle", !0);
u(c, k, F, "∄", "\\nexists");
u(c, k, F, "℧", "\\mho");
u(c, k, F, "Ⅎ", "\\Finv", !0);
u(c, k, F, "⅁", "\\Game", !0);
u(c, k, F, "‵", "\\backprime");
u(c, k, F, "▲", "\\blacktriangle");
u(c, k, F, "▼", "\\blacktriangledown");
u(c, k, F, "■", "\\blacksquare");
u(c, k, F, "⧫", "\\blacklozenge");
u(c, k, F, "★", "\\bigstar");
u(c, k, F, "∢", "\\sphericalangle", !0);
u(c, k, F, "∁", "\\complement", !0);
u(c, k, F, "ð", "\\eth", !0);
u(I, m, F, "ð", "ð");
u(c, k, F, "╱", "\\diagup");
u(c, k, F, "╲", "\\diagdown");
u(c, k, F, "□", "\\square");
u(c, k, F, "□", "\\Box");
u(c, k, F, "◊", "\\Diamond");
u(c, k, F, "¥", "\\yen", !0);
u(I, k, F, "¥", "\\yen", !0);
u(c, k, F, "✓", "\\checkmark", !0);
u(I, k, F, "✓", "\\checkmark");
u(c, k, F, "ℶ", "\\beth", !0);
u(c, k, F, "ℸ", "\\daleth", !0);
u(c, k, F, "ℷ", "\\gimel", !0);
u(c, k, F, "ϝ", "\\digamma", !0);
u(c, k, F, "ϰ", "\\varkappa");
u(c, k, Et, "┌", "\\@ulcorner", !0);
u(c, k, ft, "┐", "\\@urcorner", !0);
u(c, k, Et, "└", "\\@llcorner", !0);
u(c, k, ft, "┘", "\\@lrcorner", !0);
u(c, k, D, "≦", "\\leqq", !0);
u(c, k, D, "⩽", "\\leqslant", !0);
u(c, k, D, "⪕", "\\eqslantless", !0);
u(c, k, D, "≲", "\\lesssim", !0);
u(c, k, D, "⪅", "\\lessapprox", !0);
u(c, k, D, "≊", "\\approxeq", !0);
u(c, k, Y, "⋖", "\\lessdot");
u(c, k, D, "⋘", "\\lll", !0);
u(c, k, D, "≶", "\\lessgtr", !0);
u(c, k, D, "⋚", "\\lesseqgtr", !0);
u(c, k, D, "⪋", "\\lesseqqgtr", !0);
u(c, k, D, "≑", "\\doteqdot");
u(c, k, D, "≓", "\\risingdotseq", !0);
u(c, k, D, "≒", "\\fallingdotseq", !0);
u(c, k, D, "∽", "\\backsim", !0);
u(c, k, D, "⋍", "\\backsimeq", !0);
u(c, k, D, "⫅", "\\subseteqq", !0);
u(c, k, D, "⋐", "\\Subset", !0);
u(c, k, D, "⊏", "\\sqsubset", !0);
u(c, k, D, "≼", "\\preccurlyeq", !0);
u(c, k, D, "⋞", "\\curlyeqprec", !0);
u(c, k, D, "≾", "\\precsim", !0);
u(c, k, D, "⪷", "\\precapprox", !0);
u(c, k, D, "⊲", "\\vartriangleleft");
u(c, k, D, "⊴", "\\trianglelefteq");
u(c, k, D, "⊨", "\\vDash", !0);
u(c, k, D, "⊪", "\\Vvdash", !0);
u(c, k, D, "⌣", "\\smallsmile");
u(c, k, D, "⌢", "\\smallfrown");
u(c, k, D, "≏", "\\bumpeq", !0);
u(c, k, D, "≎", "\\Bumpeq", !0);
u(c, k, D, "≧", "\\geqq", !0);
u(c, k, D, "⩾", "\\geqslant", !0);
u(c, k, D, "⪖", "\\eqslantgtr", !0);
u(c, k, D, "≳", "\\gtrsim", !0);
u(c, k, D, "⪆", "\\gtrapprox", !0);
u(c, k, Y, "⋗", "\\gtrdot");
u(c, k, D, "⋙", "\\ggg", !0);
u(c, k, D, "≷", "\\gtrless", !0);
u(c, k, D, "⋛", "\\gtreqless", !0);
u(c, k, D, "⪌", "\\gtreqqless", !0);
u(c, k, D, "≖", "\\eqcirc", !0);
u(c, k, D, "≗", "\\circeq", !0);
u(c, k, D, "≜", "\\triangleq", !0);
u(c, k, D, "∼", "\\thicksim");
u(c, k, D, "≈", "\\thickapprox");
u(c, k, D, "⫆", "\\supseteqq", !0);
u(c, k, D, "⋑", "\\Supset", !0);
u(c, k, D, "⊐", "\\sqsupset", !0);
u(c, k, D, "≽", "\\succcurlyeq", !0);
u(c, k, D, "⋟", "\\curlyeqsucc", !0);
u(c, k, D, "≿", "\\succsim", !0);
u(c, k, D, "⪸", "\\succapprox", !0);
u(c, k, D, "⊳", "\\vartriangleright");
u(c, k, D, "⊵", "\\trianglerighteq");
u(c, k, D, "⊩", "\\Vdash", !0);
u(c, k, D, "∣", "\\shortmid");
u(c, k, D, "∥", "\\shortparallel");
u(c, k, D, "≬", "\\between", !0);
u(c, k, D, "⋔", "\\pitchfork", !0);
u(c, k, D, "∝", "\\varpropto");
u(c, k, D, "◀", "\\blacktriangleleft");
u(c, k, D, "∴", "\\therefore", !0);
u(c, k, D, "∍", "\\backepsilon");
u(c, k, D, "▶", "\\blacktriangleright");
u(c, k, D, "∵", "\\because", !0);
u(c, k, D, "⋘", "\\llless");
u(c, k, D, "⋙", "\\gggtr");
u(c, k, Y, "⊲", "\\lhd");
u(c, k, Y, "⊳", "\\rhd");
u(c, k, D, "≂", "\\eqsim", !0);
u(c, m, D, "⋈", "\\Join");
u(c, k, D, "≑", "\\Doteq", !0);
u(c, k, Y, "∔", "\\dotplus", !0);
u(c, k, Y, "∖", "\\smallsetminus");
u(c, k, Y, "⋒", "\\Cap", !0);
u(c, k, Y, "⋓", "\\Cup", !0);
u(c, k, Y, "⩞", "\\doublebarwedge", !0);
u(c, k, Y, "⊟", "\\boxminus", !0);
u(c, k, Y, "⊞", "\\boxplus", !0);
u(c, k, Y, "⋇", "\\divideontimes", !0);
u(c, k, Y, "⋉", "\\ltimes", !0);
u(c, k, Y, "⋊", "\\rtimes", !0);
u(c, k, Y, "⋋", "\\leftthreetimes", !0);
u(c, k, Y, "⋌", "\\rightthreetimes", !0);
u(c, k, Y, "⋏", "\\curlywedge", !0);
u(c, k, Y, "⋎", "\\curlyvee", !0);
u(c, k, Y, "⊝", "\\circleddash", !0);
u(c, k, Y, "⊛", "\\circledast", !0);
u(c, k, Y, "⋅", "\\centerdot");
u(c, k, Y, "⊺", "\\intercal", !0);
u(c, k, Y, "⋒", "\\doublecap");
u(c, k, Y, "⋓", "\\doublecup");
u(c, k, Y, "⊠", "\\boxtimes", !0);
u(c, k, D, "⇢", "\\dashrightarrow", !0);
u(c, k, D, "⇠", "\\dashleftarrow", !0);
u(c, k, D, "⇇", "\\leftleftarrows", !0);
u(c, k, D, "⇆", "\\leftrightarrows", !0);
u(c, k, D, "⇚", "\\Lleftarrow", !0);
u(c, k, D, "↞", "\\twoheadleftarrow", !0);
u(c, k, D, "↢", "\\leftarrowtail", !0);
u(c, k, D, "↫", "\\looparrowleft", !0);
u(c, k, D, "⇋", "\\leftrightharpoons", !0);
u(c, k, D, "↶", "\\curvearrowleft", !0);
u(c, k, D, "↺", "\\circlearrowleft", !0);
u(c, k, D, "↰", "\\Lsh", !0);
u(c, k, D, "⇈", "\\upuparrows", !0);
u(c, k, D, "↿", "\\upharpoonleft", !0);
u(c, k, D, "⇃", "\\downharpoonleft", !0);
u(c, m, D, "⊶", "\\origof", !0);
u(c, m, D, "⊷", "\\imageof", !0);
u(c, k, D, "⊸", "\\multimap", !0);
u(c, k, D, "↭", "\\leftrightsquigarrow", !0);
u(c, k, D, "⇉", "\\rightrightarrows", !0);
u(c, k, D, "⇄", "\\rightleftarrows", !0);
u(c, k, D, "↠", "\\twoheadrightarrow", !0);
u(c, k, D, "↣", "\\rightarrowtail", !0);
u(c, k, D, "↬", "\\looparrowright", !0);
u(c, k, D, "↷", "\\curvearrowright", !0);
u(c, k, D, "↻", "\\circlearrowright", !0);
u(c, k, D, "↱", "\\Rsh", !0);
u(c, k, D, "⇊", "\\downdownarrows", !0);
u(c, k, D, "↾", "\\upharpoonright", !0);
u(c, k, D, "⇂", "\\downharpoonright", !0);
u(c, k, D, "⇝", "\\rightsquigarrow", !0);
u(c, k, D, "⇝", "\\leadsto");
u(c, k, D, "⇛", "\\Rrightarrow", !0);
u(c, k, D, "↾", "\\restriction");
u(c, m, F, "‘", "`");
u(c, m, F, "$", "\\$");
u(I, m, F, "$", "\\$");
u(I, m, F, "$", "\\textdollar");
u(c, m, F, "%", "\\%");
u(I, m, F, "%", "\\%");
u(c, m, F, "_", "\\_");
u(I, m, F, "_", "\\_");
u(I, m, F, "_", "\\textunderscore");
u(c, m, F, "∠", "\\angle", !0);
u(c, m, F, "∞", "\\infty", !0);
u(c, m, F, "′", "\\prime");
u(c, m, F, "△", "\\triangle");
u(c, m, F, "Γ", "\\Gamma", !0);
u(c, m, F, "Δ", "\\Delta", !0);
u(c, m, F, "Θ", "\\Theta", !0);
u(c, m, F, "Λ", "\\Lambda", !0);
u(c, m, F, "Ξ", "\\Xi", !0);
u(c, m, F, "Π", "\\Pi", !0);
u(c, m, F, "Σ", "\\Sigma", !0);
u(c, m, F, "Υ", "\\Upsilon", !0);
u(c, m, F, "Φ", "\\Phi", !0);
u(c, m, F, "Ψ", "\\Psi", !0);
u(c, m, F, "Ω", "\\Omega", !0);
u(c, m, F, "A", "Α");
u(c, m, F, "B", "Β");
u(c, m, F, "E", "Ε");
u(c, m, F, "Z", "Ζ");
u(c, m, F, "H", "Η");
u(c, m, F, "I", "Ι");
u(c, m, F, "K", "Κ");
u(c, m, F, "M", "Μ");
u(c, m, F, "N", "Ν");
u(c, m, F, "O", "Ο");
u(c, m, F, "P", "Ρ");
u(c, m, F, "T", "Τ");
u(c, m, F, "X", "Χ");
u(c, m, F, "¬", "\\neg", !0);
u(c, m, F, "¬", "\\lnot");
u(c, m, F, "⊤", "\\top");
u(c, m, F, "⊥", "\\bot");
u(c, m, F, "∅", "\\emptyset");
u(c, k, F, "∅", "\\varnothing");
u(c, m, ne, "α", "\\alpha", !0);
u(c, m, ne, "β", "\\beta", !0);
u(c, m, ne, "γ", "\\gamma", !0);
u(c, m, ne, "δ", "\\delta", !0);
u(c, m, ne, "ϵ", "\\epsilon", !0);
u(c, m, ne, "ζ", "\\zeta", !0);
u(c, m, ne, "η", "\\eta", !0);
u(c, m, ne, "θ", "\\theta", !0);
u(c, m, ne, "ι", "\\iota", !0);
u(c, m, ne, "κ", "\\kappa", !0);
u(c, m, ne, "λ", "\\lambda", !0);
u(c, m, ne, "μ", "\\mu", !0);
u(c, m, ne, "ν", "\\nu", !0);
u(c, m, ne, "ξ", "\\xi", !0);
u(c, m, ne, "ο", "\\omicron", !0);
u(c, m, ne, "π", "\\pi", !0);
u(c, m, ne, "ρ", "\\rho", !0);
u(c, m, ne, "σ", "\\sigma", !0);
u(c, m, ne, "τ", "\\tau", !0);
u(c, m, ne, "υ", "\\upsilon", !0);
u(c, m, ne, "ϕ", "\\phi", !0);
u(c, m, ne, "χ", "\\chi", !0);
u(c, m, ne, "ψ", "\\psi", !0);
u(c, m, ne, "ω", "\\omega", !0);
u(c, m, ne, "ε", "\\varepsilon", !0);
u(c, m, ne, "ϑ", "\\vartheta", !0);
u(c, m, ne, "ϖ", "\\varpi", !0);
u(c, m, ne, "ϱ", "\\varrho", !0);
u(c, m, ne, "ς", "\\varsigma", !0);
u(c, m, ne, "φ", "\\varphi", !0);
u(c, m, Y, "∗", "*", !0);
u(c, m, Y, "+", "+");
u(c, m, Y, "−", "-", !0);
u(c, m, Y, "⋅", "\\cdot", !0);
u(c, m, Y, "∘", "\\circ", !0);
u(c, m, Y, "÷", "\\div", !0);
u(c, m, Y, "±", "\\pm", !0);
u(c, m, Y, "×", "\\times", !0);
u(c, m, Y, "∩", "\\cap", !0);
u(c, m, Y, "∪", "\\cup", !0);
u(c, m, Y, "∖", "\\setminus", !0);
u(c, m, Y, "∧", "\\land");
u(c, m, Y, "∨", "\\lor");
u(c, m, Y, "∧", "\\wedge", !0);
u(c, m, Y, "∨", "\\vee", !0);
u(c, m, F, "√", "\\surd");
u(c, m, Et, "⟨", "\\langle", !0);
u(c, m, Et, "∣", "\\lvert");
u(c, m, Et, "∥", "\\lVert");
u(c, m, ft, "?", "?");
u(c, m, ft, "!", "!");
u(c, m, ft, "⟩", "\\rangle", !0);
u(c, m, ft, "∣", "\\rvert");
u(c, m, ft, "∥", "\\rVert");
u(c, m, D, "=", "=");
u(c, m, D, ":", ":");
u(c, m, D, "≈", "\\approx", !0);
u(c, m, D, "≅", "\\cong", !0);
u(c, m, D, "≥", "\\ge");
u(c, m, D, "≥", "\\geq", !0);
u(c, m, D, "←", "\\gets");
u(c, m, D, ">", "\\gt", !0);
u(c, m, D, "∈", "\\in", !0);
u(c, m, D, "", "\\@not");
u(c, m, D, "⊂", "\\subset", !0);
u(c, m, D, "⊃", "\\supset", !0);
u(c, m, D, "⊆", "\\subseteq", !0);
u(c, m, D, "⊇", "\\supseteq", !0);
u(c, k, D, "⊈", "\\nsubseteq", !0);
u(c, k, D, "⊉", "\\nsupseteq", !0);
u(c, m, D, "⊨", "\\models");
u(c, m, D, "←", "\\leftarrow", !0);
u(c, m, D, "≤", "\\le");
u(c, m, D, "≤", "\\leq", !0);
u(c, m, D, "<", "\\lt", !0);
u(c, m, D, "→", "\\rightarrow", !0);
u(c, m, D, "→", "\\to");
u(c, k, D, "≱", "\\ngeq", !0);
u(c, k, D, "≰", "\\nleq", !0);
u(c, m, F0, " ", "\\ ");
u(c, m, F0, " ", "\\space");
u(c, m, F0, " ", "\\nobreakspace");
u(I, m, F0, " ", "\\ ");
u(I, m, F0, " ", " ");
u(I, m, F0, " ", "\\space");
u(I, m, F0, " ", "\\nobreakspace");
u(c, m, F0, null, "\\nobreak");
u(c, m, F0, null, "\\allowbreak");
u(c, m, ma, ",", ",");
u(c, m, ma, ";", ";");
u(c, k, Y, "⊼", "\\barwedge", !0);
u(c, k, Y, "⊻", "\\veebar", !0);
u(c, m, Y, "⊙", "\\odot", !0);
u(c, m, Y, "⊕", "\\oplus", !0);
u(c, m, Y, "⊗", "\\otimes", !0);
u(c, m, F, "∂", "\\partial", !0);
u(c, m, Y, "⊘", "\\oslash", !0);
u(c, k, Y, "⊚", "\\circledcirc", !0);
u(c, k, Y, "⊡", "\\boxdot", !0);
u(c, m, Y, "△", "\\bigtriangleup");
u(c, m, Y, "▽", "\\bigtriangledown");
u(c, m, Y, "†", "\\dagger");
u(c, m, Y, "⋄", "\\diamond");
u(c, m, Y, "⋆", "\\star");
u(c, m, Y, "◃", "\\triangleleft");
u(c, m, Y, "▹", "\\triangleright");
u(c, m, Et, "{", "\\{");
u(I, m, F, "{", "\\{");
u(I, m, F, "{", "\\textbraceleft");
u(c, m, ft, "}", "\\}");
u(I, m, F, "}", "\\}");
u(I, m, F, "}", "\\textbraceright");
u(c, m, Et, "{", "\\lbrace");
u(c, m, ft, "}", "\\rbrace");
u(c, m, Et, "[", "\\lbrack", !0);
u(I, m, F, "[", "\\lbrack", !0);
u(c, m, ft, "]", "\\rbrack", !0);
u(I, m, F, "]", "\\rbrack", !0);
u(c, m, Et, "(", "\\lparen", !0);
u(c, m, ft, ")", "\\rparen", !0);
u(I, m, F, "<", "\\textless", !0);
u(I, m, F, ">", "\\textgreater", !0);
u(c, m, Et, "⌊", "\\lfloor", !0);
u(c, m, ft, "⌋", "\\rfloor", !0);
u(c, m, Et, "⌈", "\\lceil", !0);
u(c, m, ft, "⌉", "\\rceil", !0);
u(c, m, F, "\\", "\\backslash");
u(c, m, F, "∣", "|");
u(c, m, F, "∣", "\\vert");
u(I, m, F, "|", "\\textbar", !0);
u(c, m, F, "∥", "\\|");
u(c, m, F, "∥", "\\Vert");
u(I, m, F, "∥", "\\textbardbl");
u(I, m, F, "~", "\\textasciitilde");
u(I, m, F, "\\", "\\textbackslash");
u(I, m, F, "^", "\\textasciicircum");
u(c, m, D, "↑", "\\uparrow", !0);
u(c, m, D, "⇑", "\\Uparrow", !0);
u(c, m, D, "↓", "\\downarrow", !0);
u(c, m, D, "⇓", "\\Downarrow", !0);
u(c, m, D, "↕", "\\updownarrow", !0);
u(c, m, D, "⇕", "\\Updownarrow", !0);
u(c, m, et, "∐", "\\coprod");
u(c, m, et, "⋁", "\\bigvee");
u(c, m, et, "⋀", "\\bigwedge");
u(c, m, et, "⨄", "\\biguplus");
u(c, m, et, "⋂", "\\bigcap");
u(c, m, et, "⋃", "\\bigcup");
u(c, m, et, "∫", "\\int");
u(c, m, et, "∫", "\\intop");
u(c, m, et, "∬", "\\iint");
u(c, m, et, "∭", "\\iiint");
u(c, m, et, "∏", "\\prod");
u(c, m, et, "∑", "\\sum");
u(c, m, et, "⨂", "\\bigotimes");
u(c, m, et, "⨁", "\\bigoplus");
u(c, m, et, "⨀", "\\bigodot");
u(c, m, et, "∮", "\\oint");
u(c, m, et, "∯", "\\oiint");
u(c, m, et, "∰", "\\oiiint");
u(c, m, et, "⨆", "\\bigsqcup");
u(c, m, et, "∫", "\\smallint");
u(I, m, Hn, "…", "\\textellipsis");
u(c, m, Hn, "…", "\\mathellipsis");
u(I, m, Hn, "…", "\\ldots", !0);
u(c, m, Hn, "…", "\\ldots", !0);
u(c, m, Hn, "⋯", "\\@cdots", !0);
u(c, m, Hn, "⋱", "\\ddots", !0);
u(c, m, F, "⋮", "\\varvdots");
u(I, m, F, "⋮", "\\varvdots");
u(c, m, $e, "ˊ", "\\acute");
u(c, m, $e, "ˋ", "\\grave");
u(c, m, $e, "¨", "\\ddot");
u(c, m, $e, "~", "\\tilde");
u(c, m, $e, "ˉ", "\\bar");
u(c, m, $e, "˘", "\\breve");
u(c, m, $e, "ˇ", "\\check");
u(c, m, $e, "^", "\\hat");
u(c, m, $e, "⃗", "\\vec");
u(c, m, $e, "˙", "\\dot");
u(c, m, $e, "˚", "\\mathring");
u(c, m, ne, "", "\\@imath");
u(c, m, ne, "", "\\@jmath");
u(c, m, F, "ı", "ı");
u(c, m, F, "ȷ", "ȷ");
u(I, m, F, "ı", "\\i", !0);
u(I, m, F, "ȷ", "\\j", !0);
u(I, m, F, "ß", "\\ss", !0);
u(I, m, F, "æ", "\\ae", !0);
u(I, m, F, "œ", "\\oe", !0);
u(I, m, F, "ø", "\\o", !0);
u(I, m, F, "Æ", "\\AE", !0);
u(I, m, F, "Œ", "\\OE", !0);
u(I, m, F, "Ø", "\\O", !0);
u(I, m, $e, "ˊ", "\\'");
u(I, m, $e, "ˋ", "\\`");
u(I, m, $e, "ˆ", "\\^");
u(I, m, $e, "˜", "\\~");
u(I, m, $e, "ˉ", "\\=");
u(I, m, $e, "˘", "\\u");
u(I, m, $e, "˙", "\\.");
u(I, m, $e, "¸", "\\c");
u(I, m, $e, "˚", "\\r");
u(I, m, $e, "ˇ", "\\v");
u(I, m, $e, "¨", '\\"');
u(I, m, $e, "˝", "\\H");
u(I, m, $e, "◯", "\\textcircled");
var po = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
u(I, m, F, "–", "--", !0);
u(I, m, F, "–", "\\textendash");
u(I, m, F, "—", "---", !0);
u(I, m, F, "—", "\\textemdash");
u(I, m, F, "‘", "`", !0);
u(I, m, F, "‘", "\\textquoteleft");
u(I, m, F, "’", "'", !0);
u(I, m, F, "’", "\\textquoteright");
u(I, m, F, "“", "``", !0);
u(I, m, F, "“", "\\textquotedblleft");
u(I, m, F, "”", "''", !0);
u(I, m, F, "”", "\\textquotedblright");
u(c, m, F, "°", "\\degree", !0);
u(I, m, F, "°", "\\degree");
u(I, m, F, "°", "\\textdegree", !0);
u(c, m, F, "£", "\\pounds");
u(c, m, F, "£", "\\mathsterling", !0);
u(I, m, F, "£", "\\pounds");
u(I, m, F, "£", "\\textsterling", !0);
u(c, k, F, "✠", "\\maltese");
u(I, k, F, "✠", "\\maltese");
var yl = '0123456789/@."';
for (var Ca = 0; Ca < yl.length; Ca++) {
  var wl = yl.charAt(Ca);
  u(c, m, F, wl, wl);
}
var kl = '0123456789!@*()-=+";:?/.,';
for (var Ta = 0; Ta < kl.length; Ta++) {
  var Dl = kl.charAt(Ta);
  u(I, m, F, Dl, Dl);
}
var ea = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Ma = 0; Ma < ea.length; Ma++) {
  var Cr = ea.charAt(Ma);
  u(c, m, ne, Cr, Cr), u(I, m, F, Cr, Cr);
}
u(c, k, F, "C", "ℂ");
u(I, k, F, "C", "ℂ");
u(c, k, F, "H", "ℍ");
u(I, k, F, "H", "ℍ");
u(c, k, F, "N", "ℕ");
u(I, k, F, "N", "ℕ");
u(c, k, F, "P", "ℙ");
u(I, k, F, "P", "ℙ");
u(c, k, F, "Q", "ℚ");
u(I, k, F, "Q", "ℚ");
u(c, k, F, "R", "ℝ");
u(I, k, F, "R", "ℝ");
u(c, k, F, "Z", "ℤ");
u(I, k, F, "Z", "ℤ");
u(c, m, ne, "h", "ℎ");
u(I, m, ne, "h", "ℎ");
var le = "";
for (var ut = 0; ut < ea.length; ut++) {
  var We = ea.charAt(ut);
  le = String.fromCharCode(55349, 56320 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56372 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56424 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56580 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56684 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56736 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56788 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56840 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56944 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), ut < 26 && (le = String.fromCharCode(55349, 56632 + ut), u(c, m, ne, We, le), u(I, m, F, We, le), le = String.fromCharCode(55349, 56476 + ut), u(c, m, ne, We, le), u(I, m, F, We, le));
}
le = "𝕜";
u(c, m, ne, "k", le);
u(I, m, F, "k", le);
for (var K0 = 0; K0 < 10; K0++) {
  var q0 = K0.toString();
  le = String.fromCharCode(55349, 57294 + K0), u(c, m, ne, q0, le), u(I, m, F, q0, le), le = String.fromCharCode(55349, 57314 + K0), u(c, m, ne, q0, le), u(I, m, F, q0, le), le = String.fromCharCode(55349, 57324 + K0), u(c, m, ne, q0, le), u(I, m, F, q0, le), le = String.fromCharCode(55349, 57334 + K0), u(c, m, ne, q0, le), u(I, m, F, q0, le);
}
var Sl = "ÐÞþ";
for (var za = 0; za < Sl.length; za++) {
  var Tr = Sl.charAt(za);
  u(c, m, ne, Tr, Tr), u(I, m, F, Tr, Tr);
}
var Mr = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], Al = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], fc = function(e, t) {
  var r = e.charCodeAt(0), a = e.charCodeAt(1), i = (r - 55296) * 1024 + (a - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var s = Math.floor((i - 119808) / 26);
    return [Mr[s][2], Mr[s][l]];
  } else if (120782 <= i && i <= 120831) {
    var o = Math.floor((i - 120782) / 10);
    return [Al[o][2], Al[o][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [Mr[0][2], Mr[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new J("Unsupported character: " + e);
  }
}, fa = function(e, t, r) {
  return Ke[r][e] && Ke[r][e].replace && (e = Ke[r][e].replace), {
    value: e,
    metrics: Mi(e, t, r)
  };
}, Yt = function(e, t, r, a, i) {
  var l = fa(e, t, r), s = l.metrics;
  e = l.value;
  var o;
  if (s) {
    var d = s.italic;
    (r === "text" || a && a.font === "mathit") && (d = 0), o = new m0(e, s.height, s.depth, d, s.skew, s.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + r + "'")), o = new m0(e, 0, 0, 0, 0, 0, i);
  if (a) {
    o.maxFontSize = a.sizeMultiplier, a.style.isTight() && o.classes.push("mtight");
    var h = a.getColor();
    h && (o.style.color = h);
  }
  return o;
}, pc = function(e, t, r, a) {
  return a === void 0 && (a = []), r.font === "boldsymbol" && fa(e, "Main-Bold", t).metrics ? Yt(e, "Main-Bold", t, r, a.concat(["mathbf"])) : e === "\\" || Ke[t][e].font === "main" ? Yt(e, "Main-Regular", t, r, a) : Yt(e, "AMS-Regular", t, r, a.concat(["amsrm"]));
}, _c = function(e, t, r, a, i) {
  return i !== "textord" && fa(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, gc = function(e, t, r) {
  var a = e.mode, i = e.text, l = ["mord"], s = a === "math" || a === "text" && t.font, o = s ? t.font : t.fontFamily, d = "", h = "";
  if (i.charCodeAt(0) === 55349 && ([d, h] = fc(i, a)), d.length > 0)
    return Yt(i, d, a, t, l.concat(h));
  if (o) {
    var f, p;
    if (o === "boldsymbol") {
      var _ = _c(i, a, t, l, r);
      f = _.fontName, p = [_.fontClass];
    } else s ? (f = vo[o].fontName, p = [o]) : (f = zr(o, t.fontWeight, t.fontShape), p = [o, t.fontWeight, t.fontShape]);
    if (fa(i, f, a).metrics)
      return Yt(i, f, a, t, l.concat(p));
    if (po.hasOwnProperty(i) && f.slice(0, 10) === "Typewriter") {
      for (var y = [], S = 0; S < i.length; S++)
        y.push(Yt(i[S], f, a, t, l.concat(p)));
      return go(y);
    }
  }
  if (r === "mathord")
    return Yt(i, "Math-Italic", a, t, l.concat(["mathnormal"]));
  if (r === "textord") {
    var E = Ke[a][i] && Ke[a][i].font;
    if (E === "ams") {
      var A = zr("amsrm", t.fontWeight, t.fontShape);
      return Yt(i, A, a, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (E === "main" || !E) {
      var b = zr("textrm", t.fontWeight, t.fontShape);
      return Yt(i, b, a, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var v = zr(E, t.fontWeight, t.fontShape);
      return Yt(i, v, a, t, l.concat(v, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + r + " in makeOrd");
}, vc = (n, e) => {
  if (P0(n.classes) !== P0(e.classes) || n.skew !== e.skew || n.maxFontSize !== e.maxFontSize)
    return !1;
  if (n.classes.length === 1) {
    var t = n.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var r in n.style)
    if (n.style.hasOwnProperty(r) && n.style[r] !== e.style[r])
      return !1;
  for (var a in e.style)
    if (e.style.hasOwnProperty(a) && n.style[a] !== e.style[a])
      return !1;
  return !0;
}, bc = (n) => {
  for (var e = 0; e < n.length - 1; e++) {
    var t = n[e], r = n[e + 1];
    t instanceof m0 && r instanceof m0 && vc(t, r) && (t.text += r.text, t.height = Math.max(t.height, r.height), t.depth = Math.max(t.depth, r.depth), t.italic = r.italic, n.splice(e + 1, 1), e--);
  }
  return n;
}, zi = function(e) {
  for (var t = 0, r = 0, a = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > r && (r = l.depth), l.maxFontSize > a && (a = l.maxFontSize);
  }
  e.height = t, e.depth = r, e.maxFontSize = a;
}, bt = function(e, t, r, a) {
  var i = new ha(e, t, r, a);
  return zi(i), i;
}, _o = (n, e, t, r) => new ha(n, e, t, r), yc = function(e, t, r) {
  var a = bt([e], [], t);
  return a.height = Math.max(r || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), a.style.borderBottomWidth = V(a.height), a.maxFontSize = 1, a;
}, wc = function(e, t, r, a) {
  var i = new fo(e, t, r, a);
  return zi(i), i;
}, go = function(e) {
  var t = new vr(e);
  return zi(t), t;
}, kc = function(e, t) {
  return e instanceof vr ? bt([], [e], t) : e;
}, Dc = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, r = [t[0]], a = -t[0].shift - t[0].elem.depth, i = a, l = 1; l < t.length; l++) {
      var s = -t[l].shift - i - t[l].elem.depth, o = s - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + s, r.push({
        type: "kern",
        size: o
      }), r.push(t[l]);
    }
    return {
      children: r,
      depth: a
    };
  }
  var d;
  if (e.positionType === "top") {
    for (var h = e.positionData, f = 0; f < e.children.length; f++) {
      var p = e.children[f];
      h -= p.type === "kern" ? p.size : p.elem.height + p.elem.depth;
    }
    d = h;
  } else if (e.positionType === "bottom")
    d = -e.positionData;
  else {
    var _ = e.children[0];
    if (_.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      d = -_.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      d = -_.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: d
  };
}, Sc = function(e, t) {
  for (var {
    children: r,
    depth: a
  } = Dc(e), i = 0, l = 0; l < r.length; l++) {
    var s = r[l];
    if (s.type === "elem") {
      var o = s.elem;
      i = Math.max(i, o.maxFontSize, o.height);
    }
  }
  i += 2;
  var d = bt(["pstrut"], []);
  d.style.height = V(i);
  for (var h = [], f = a, p = a, _ = a, y = 0; y < r.length; y++) {
    var S = r[y];
    if (S.type === "kern")
      _ += S.size;
    else {
      var E = S.elem, A = S.wrapperClasses || [], b = S.wrapperStyle || {}, v = bt(A, [d, E], void 0, b);
      v.style.top = V(-i - _ - E.depth), S.marginLeft && (v.style.marginLeft = S.marginLeft), S.marginRight && (v.style.marginRight = S.marginRight), h.push(v), _ += E.height + E.depth;
    }
    f = Math.min(f, _), p = Math.max(p, _);
  }
  var w = bt(["vlist"], h);
  w.style.height = V(p);
  var C;
  if (f < 0) {
    var T = bt([], []), B = bt(["vlist"], [T]);
    B.style.height = V(-f);
    var $ = bt(["vlist-s"], [new m0("​")]);
    C = [bt(["vlist-r"], [w, $]), bt(["vlist-r"], [B])];
  } else
    C = [bt(["vlist-r"], [w])];
  var z = bt(["vlist-t"], C);
  return C.length === 2 && z.classes.push("vlist-t2"), z.height = p, z.depth = -f, z;
}, Ac = (n, e) => {
  var t = bt(["mspace"], [], e), r = Ue(n, e);
  return t.style.marginRight = V(r), t;
}, zr = function(e, t, r) {
  var a = "";
  switch (e) {
    case "amsrm":
      a = "AMS";
      break;
    case "textrm":
      a = "Main";
      break;
    case "textsf":
      a = "SansSerif";
      break;
    case "texttt":
      a = "Typewriter";
      break;
    default:
      a = e;
  }
  var i;
  return t === "textbf" && r === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", a + "-" + i;
}, vo = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  mathsfit: {
    variant: "sans-serif-italic",
    fontName: "SansSerif-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, bo = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, xc = function(e, t) {
  var [r, a, i] = bo[e], l = new mn(r), s = new $0([l], {
    width: V(a),
    height: V(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + V(a),
    viewBox: "0 0 " + 1e3 * a + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), o = _o(["overlay"], [s], t);
  return o.height = i, o.style.height = V(i), o.style.width = V(a), o;
}, M = {
  fontMap: vo,
  makeSymbol: Yt,
  mathsym: pc,
  makeSpan: bt,
  makeSvgSpan: _o,
  makeLineSpan: yc,
  makeAnchor: wc,
  makeFragment: go,
  wrapFragment: kc,
  makeVList: Sc,
  makeOrd: gc,
  makeGlue: Ac,
  staticSvg: xc,
  svgData: bo,
  tryCombineChars: bc
}, He = {
  number: 3,
  unit: "mu"
}, Q0 = {
  number: 4,
  unit: "mu"
}, v0 = {
  number: 5,
  unit: "mu"
}, Fc = {
  mord: {
    mop: He,
    mbin: Q0,
    mrel: v0,
    minner: He
  },
  mop: {
    mord: He,
    mop: He,
    mrel: v0,
    minner: He
  },
  mbin: {
    mord: Q0,
    mop: Q0,
    mopen: Q0,
    minner: Q0
  },
  mrel: {
    mord: v0,
    mop: v0,
    mopen: v0,
    minner: v0
  },
  mopen: {},
  mclose: {
    mop: He,
    mbin: Q0,
    mrel: v0,
    minner: He
  },
  mpunct: {
    mord: He,
    mop: He,
    mrel: v0,
    mopen: He,
    mclose: He,
    mpunct: He,
    minner: He
  },
  minner: {
    mord: He,
    mop: He,
    mbin: Q0,
    mrel: v0,
    mopen: He,
    mpunct: He,
    minner: He
  }
}, Ec = {
  mord: {
    mop: He
  },
  mop: {
    mord: He,
    mop: He
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: He
  },
  mpunct: {},
  minner: {
    mop: He
  }
}, yo = {}, ta = {}, na = {};
function G(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, s = {
    type: e,
    numArgs: r.numArgs,
    argTypes: r.argTypes,
    allowedInArgument: !!r.allowedInArgument,
    allowedInText: !!r.allowedInText,
    allowedInMath: r.allowedInMath === void 0 ? !0 : r.allowedInMath,
    numOptionalArgs: r.numOptionalArgs || 0,
    infix: !!r.infix,
    primitive: !!r.primitive,
    handler: a
  }, o = 0; o < t.length; ++o)
    yo[t[o]] = s;
  e && (i && (ta[e] = i), l && (na[e] = l));
}
function _n(n) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: r
  } = n;
  G({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: r
  });
}
var ra = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, Ze = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, In = M.makeSpan, Cc = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], Tc = ["rightmost", "mrel", "mclose", "mpunct"], Mc = {
  display: re.DISPLAY,
  text: re.TEXT,
  script: re.SCRIPT,
  scriptscript: re.SCRIPTSCRIPT
}, zc = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, lt = function(e, t, r, a) {
  a === void 0 && (a = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var s = Se(e[l], t);
    if (s instanceof vr) {
      var o = s.children;
      i.push(...o);
    } else
      i.push(s);
  }
  if (M.tryCombineChars(i), !r)
    return i;
  var d = t;
  if (e.length === 1) {
    var h = e[0];
    h.type === "sizing" ? d = t.havingSize(h.size) : h.type === "styling" && (d = t.havingStyle(Mc[h.style]));
  }
  var f = In([a[0] || "leftmost"], [], t), p = In([a[1] || "rightmost"], [], t), _ = r === "root";
  return xl(i, (y, S) => {
    var E = S.classes[0], A = y.classes[0];
    E === "mbin" && Tc.includes(A) ? S.classes[0] = "mord" : A === "mbin" && Cc.includes(E) && (y.classes[0] = "mord");
  }, {
    node: f
  }, p, _), xl(i, (y, S) => {
    var E = oi(S), A = oi(y), b = E && A ? y.hasClass("mtight") ? Ec[E][A] : Fc[E][A] : null;
    if (b)
      return M.makeGlue(b, d);
  }, {
    node: f
  }, p, _), i;
}, xl = function n(e, t, r, a, i) {
  a && e.push(a);
  for (var l = 0; l < e.length; l++) {
    var s = e[l], o = wo(s);
    if (o) {
      n(o.children, t, r, null, i);
      continue;
    }
    var d = !s.hasClass("mspace");
    if (d) {
      var h = t(s, r.node);
      h && (r.insertAfter ? r.insertAfter(h) : (e.unshift(h), l++));
    }
    d ? r.node = s : i && s.hasClass("newline") && (r.node = In(["leftmost"])), r.insertAfter = /* @__PURE__ */ ((f) => (p) => {
      e.splice(f + 1, 0, p), l++;
    })(l);
  }
  a && e.pop();
}, wo = function(e) {
  return e instanceof vr || e instanceof fo || e instanceof ha && e.hasClass("enclosing") ? e : null;
}, Bc = function n(e, t) {
  var r = wo(e);
  if (r) {
    var a = r.children;
    if (a.length) {
      if (t === "right")
        return n(a[a.length - 1], "right");
      if (t === "left")
        return n(a[0], "left");
    }
  }
  return e;
}, oi = function(e, t) {
  return e ? (t && (e = Bc(e, t)), zc[e.classes[0]] || null) : null;
}, pr = function(e, t) {
  var r = ["nulldelimiter"].concat(e.baseSizingClasses());
  return In(t.concat(r));
}, Se = function(e, t, r) {
  if (!e)
    return In();
  if (ta[e.type]) {
    var a = ta[e.type](e, t);
    if (r && t.size !== r.size) {
      a = In(t.sizingClasses(r), [a], t);
      var i = t.sizeMultiplier / r.sizeMultiplier;
      a.height *= i, a.depth *= i;
    }
    return a;
  } else
    throw new J("Got group of unknown type: '" + e.type + "'");
};
function ko(n) {
  return new vr(n);
}
class Bt {
  constructor(e, t, r) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = r || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = P0(this.classes));
    for (var r = 0; r < this.children.length; r++)
      if (this.children[r] instanceof i0 && this.children[r + 1] instanceof i0) {
        for (var a = this.children[r].toText() + this.children[++r].toText(); this.children[r + 1] instanceof i0; )
          a += this.children[++r].toText();
        e.appendChild(new i0(a).toNode());
      } else
        e.appendChild(this.children[r].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += Fe.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + Fe.escape(P0(this.classes)) + '"'), e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class i0 {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return Fe.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class qc {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", V(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + V(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var H = {
  MathNode: Bt,
  TextNode: i0,
  SpaceNode: qc,
  newDocumentFragment: ko
}, Lt = function(e, t, r) {
  return Ke[t][e] && Ke[t][e].replace && e.charCodeAt(0) !== 55349 && !(po.hasOwnProperty(e) && r && (r.fontFamily && r.fontFamily.slice(4, 6) === "tt" || r.font && r.font.slice(4, 6) === "tt")) && (e = Ke[t][e].replace), new H.TextNode(e);
}, Bi = function(e) {
  return e.length === 1 ? e[0] : new H.MathNode("mrow", e);
}, qi = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var r = t.font;
  if (!r || r === "mathnormal")
    return null;
  var a = e.mode;
  if (r === "mathit")
    return "italic";
  if (r === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (r === "mathbf")
    return "bold";
  if (r === "mathbb")
    return "double-struck";
  if (r === "mathsfit")
    return "sans-serif-italic";
  if (r === "mathfrak")
    return "fraktur";
  if (r === "mathscr" || r === "mathcal")
    return "script";
  if (r === "mathsf")
    return "sans-serif";
  if (r === "mathtt")
    return "monospace";
  var i = e.text;
  if (["\\imath", "\\jmath"].includes(i))
    return null;
  Ke[a][i] && Ke[a][i].replace && (i = Ke[a][i].replace);
  var l = M.fontMap[r].fontName;
  return Mi(i, l, a) ? M.fontMap[r].variant : null;
};
function Ba(n) {
  if (!n)
    return !1;
  if (n.type === "mi" && n.children.length === 1) {
    var e = n.children[0];
    return e instanceof i0 && e.text === ".";
  } else if (n.type === "mo" && n.children.length === 1 && n.getAttribute("separator") === "true" && n.getAttribute("lspace") === "0em" && n.getAttribute("rspace") === "0em") {
    var t = n.children[0];
    return t instanceof i0 && t.text === ",";
  } else
    return !1;
}
var Ct = function(e, t, r) {
  if (e.length === 1) {
    var a = Be(e[0], t);
    return r && a instanceof Bt && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
  }
  for (var i = [], l, s = 0; s < e.length; s++) {
    var o = Be(e[s], t);
    if (o instanceof Bt && l instanceof Bt) {
      if (o.type === "mtext" && l.type === "mtext" && o.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...o.children);
        continue;
      } else if (o.type === "mn" && l.type === "mn") {
        l.children.push(...o.children);
        continue;
      } else if (Ba(o) && l.type === "mn") {
        l.children.push(...o.children);
        continue;
      } else if (o.type === "mn" && Ba(l))
        o.children = [...l.children, ...o.children], i.pop();
      else if ((o.type === "msup" || o.type === "msub") && o.children.length >= 1 && (l.type === "mn" || Ba(l))) {
        var d = o.children[0];
        d instanceof Bt && d.type === "mn" && (d.children = [...l.children, ...d.children], i.pop());
      } else if (l.type === "mi" && l.children.length === 1) {
        var h = l.children[0];
        if (h instanceof i0 && h.text === "̸" && (o.type === "mo" || o.type === "mi" || o.type === "mn")) {
          var f = o.children[0];
          f instanceof i0 && f.text.length > 0 && (f.text = f.text.slice(0, 1) + "̸" + f.text.slice(1), i.pop());
        }
      }
    }
    i.push(o), l = o;
  }
  return i;
}, H0 = function(e, t, r) {
  return Bi(Ct(e, t, r));
}, Be = function(e, t) {
  if (!e)
    return new H.MathNode("mrow");
  if (na[e.type]) {
    var r = na[e.type](e, t);
    return r;
  } else
    throw new J("Got group of unknown type: '" + e.type + "'");
}, Nc = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, Rc = function(e) {
  var t = new H.MathNode("mo", [new H.TextNode(Nc[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, Ic = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, Lc = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, Oc = function(e, t) {
  function r() {
    var s = 4e5, o = e.label.slice(1);
    if (["widehat", "widecheck", "widetilde", "utilde"].includes(o)) {
      var d = e, h = Lc(d.base), f, p, _;
      if (h > 5)
        o === "widehat" || o === "widecheck" ? (f = 420, s = 2364, _ = 0.42, p = o + "4") : (f = 312, s = 2340, _ = 0.34, p = "tilde4");
      else {
        var y = [1, 1, 2, 2, 3, 3][h];
        o === "widehat" || o === "widecheck" ? (s = [0, 1062, 2364, 2364, 2364][y], f = [0, 239, 300, 360, 420][y], _ = [0, 0.24, 0.3, 0.3, 0.36, 0.42][y], p = o + y) : (s = [0, 600, 1033, 2339, 2340][y], f = [0, 260, 286, 306, 312][y], _ = [0, 0.26, 0.286, 0.3, 0.306, 0.34][y], p = "tilde" + y);
      }
      var S = new mn(p), E = new $0([S], {
        width: "100%",
        height: V(_),
        viewBox: "0 0 " + s + " " + f,
        preserveAspectRatio: "none"
      });
      return {
        span: M.makeSvgSpan([], [E], t),
        minWidth: 0,
        height: _
      };
    } else {
      var A = [], b = Ic[o], [v, w, C] = b, T = C / 1e3, B = v.length, $, z;
      if (B === 1) {
        var N = b[3];
        $ = ["hide-tail"], z = [N];
      } else if (B === 2)
        $ = ["halfarrow-left", "halfarrow-right"], z = ["xMinYMin", "xMaxYMin"];
      else if (B === 3)
        $ = ["brace-left", "brace-center", "brace-right"], z = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + B + " children.");
      for (var j = 0; j < B; j++) {
        var W = new mn(v[j]), ye = new $0([W], {
          width: "400em",
          height: V(T),
          viewBox: "0 0 " + s + " " + C,
          preserveAspectRatio: z[j] + " slice"
        }), Z = M.makeSvgSpan([$[j]], [ye], t);
        if (B === 1)
          return {
            span: Z,
            minWidth: w,
            height: T
          };
        Z.style.height = V(T), A.push(Z);
      }
      return {
        span: M.makeSpan(["stretchy"], A, t),
        minWidth: w,
        height: T
      };
    }
  }
  var {
    span: a,
    minWidth: i,
    height: l
  } = r();
  return a.height = l, a.style.height = V(l), i > 0 && (a.style.minWidth = V(i)), a;
}, Pc = function(e, t, r, a, i) {
  var l, s = e.height + e.depth + r + a;
  if (/fbox|color|angl/.test(t)) {
    if (l = M.makeSpan(["stretchy", t], [], i), t === "fbox") {
      var o = i.color && i.getColor();
      o && (l.style.borderColor = o);
    }
  } else {
    var d = [];
    /^[bx]cancel$/.test(t) && d.push(new vl({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && d.push(new vl({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var h = new $0(d, {
      width: "100%",
      height: V(s)
    });
    l = M.makeSvgSpan([], [h], i);
  }
  return l.height = s, l.style.height = V(s), l;
}, x0 = {
  encloseSpan: Pc,
  mathMLnode: Rc,
  svgSpan: Oc
};
function me(n, e) {
  if (!n || n.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (n ? "node of type " + n.type : String(n)));
  return n;
}
function Ni(n) {
  var e = pa(n);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (n ? "node of type " + n.type : String(n)));
  return e;
}
function pa(n) {
  return n && (n.type === "atom" || mc.hasOwnProperty(n.type)) ? n : null;
}
var Ri = (n, e) => {
  var t, r, a;
  n && n.type === "supsub" ? (r = me(n.base, "accent"), t = r.base, n.base = t, a = hc(Se(n, e)), n.base = r) : (r = me(n, "accent"), t = r.base);
  var i = Se(t, e.havingCrampedStyle()), l = r.isShifty && Fe.isCharacterBox(t), s = 0;
  if (l) {
    var o = Fe.getBaseElem(t), d = Se(o, e.havingCrampedStyle());
    s = bl(d).skew;
  }
  var h = r.label === "\\c", f = h ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), p;
  if (r.isStretchy)
    p = x0.svgSpan(r, e), p = M.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: p,
        wrapperClasses: ["svg-align"],
        wrapperStyle: s > 0 ? {
          width: "calc(100% - " + V(2 * s) + ")",
          marginLeft: V(2 * s)
        } : void 0
      }]
    }, e);
  else {
    var _, y;
    r.label === "\\vec" ? (_ = M.staticSvg("vec", e), y = M.svgData.vec[1]) : (_ = M.makeOrd({
      mode: r.mode,
      text: r.label
    }, e, "textord"), _ = bl(_), _.italic = 0, y = _.width, h && (f += _.depth)), p = M.makeSpan(["accent-body"], [_]);
    var S = r.label === "\\textcircled";
    S && (p.classes.push("accent-full"), f = i.height);
    var E = s;
    S || (E -= y / 2), p.style.left = V(E), r.label === "\\textcircled" && (p.style.top = ".2em"), p = M.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -f
      }, {
        type: "elem",
        elem: p
      }]
    }, e);
  }
  var A = M.makeSpan(["mord", "accent"], [p], e);
  return a ? (a.children[0] = A, a.height = Math.max(A.height, a.height), a.classes[0] = "mord", a) : A;
}, Do = (n, e) => {
  var t = n.isStretchy ? x0.mathMLnode(n.label) : new H.MathNode("mo", [Lt(n.label, n.mode)]), r = new H.MathNode("mover", [Be(n.base, e), t]);
  return r.setAttribute("accent", "true"), r;
}, $c = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((n) => "\\" + n).join("|"));
G({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var t = ra(e[0]), r = !$c.test(n.funcName), a = !r || n.funcName === "\\widehat" || n.funcName === "\\widetilde" || n.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: n.parser.mode,
      label: n.funcName,
      isStretchy: r,
      isShifty: a,
      base: t
    };
  },
  htmlBuilder: Ri,
  mathmlBuilder: Do
});
G({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = e[0], r = n.parser.mode;
    return r === "math" && (n.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + n.funcName + " works only in text mode"), r = "text"), {
      type: "accent",
      mode: r,
      label: n.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: Ri,
  mathmlBuilder: Do
});
G({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: r,
      base: a
    };
  },
  htmlBuilder: (n, e) => {
    var t = Se(n.base, e), r = x0.svgSpan(n, e), a = n.label === "\\utilde" ? 0.12 : 0, i = M.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: r,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return M.makeSpan(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = x0.mathMLnode(n.label), r = new H.MathNode("munder", [Be(n.base, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
var Br = (n) => {
  var e = new H.MathNode("mpadded", n ? [n] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
G({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n;
    return {
      type: "xArrow",
      mode: r.mode,
      label: a,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(n, e) {
    var t = e.style, r = e.havingStyle(t.sup()), a = M.wrapFragment(Se(n.body, r, e), e), i = n.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(i + "-arrow-pad");
    var l;
    n.below && (r = e.havingStyle(t.sub()), l = M.wrapFragment(Se(n.below, r, e), e), l.classes.push(i + "-arrow-pad"));
    var s = x0.svgSpan(n, e), o = -e.fontMetrics().axisHeight + 0.5 * s.height, d = -e.fontMetrics().axisHeight - 0.5 * s.height - 0.111;
    (a.depth > 0.25 || n.label === "\\xleftequilibrium") && (d -= a.depth);
    var h;
    if (l) {
      var f = -e.fontMetrics().axisHeight + l.height + 0.5 * s.height + 0.111;
      h = M.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: d
        }, {
          type: "elem",
          elem: s,
          shift: o
        }, {
          type: "elem",
          elem: l,
          shift: f
        }]
      }, e);
    } else
      h = M.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: d
        }, {
          type: "elem",
          elem: s,
          shift: o
        }]
      }, e);
    return h.children[0].children[0].children[1].classes.push("svg-align"), M.makeSpan(["mrel", "x-arrow"], [h], e);
  },
  mathmlBuilder(n, e) {
    var t = x0.mathMLnode(n.label);
    t.setAttribute("minsize", n.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var r;
    if (n.body) {
      var a = Br(Be(n.body, e));
      if (n.below) {
        var i = Br(Be(n.below, e));
        r = new H.MathNode("munderover", [t, i, a]);
      } else
        r = new H.MathNode("mover", [t, a]);
    } else if (n.below) {
      var l = Br(Be(n.below, e));
      r = new H.MathNode("munder", [t, l]);
    } else
      r = Br(), r = new H.MathNode("mover", [t, r]);
    return r;
  }
});
var Hc = M.makeSpan;
function So(n, e) {
  var t = lt(n.body, e, !0);
  return Hc([n.mclass], t, e);
}
function Ao(n, e) {
  var t, r = Ct(n.body, e);
  return n.mclass === "minner" ? t = new H.MathNode("mpadded", r) : n.mclass === "mord" ? n.isCharacterBox ? (t = r[0], t.type = "mi") : t = new H.MathNode("mi", r) : (n.isCharacterBox ? (t = r[0], t.type = "mo") : t = new H.MathNode("mo", r), n.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : n.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : n.mclass === "mopen" || n.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : n.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
G({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + r.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: Ze(a),
      isCharacterBox: Fe.isCharacterBox(a)
    };
  },
  htmlBuilder: So,
  mathmlBuilder: Ao
});
var _a = (n) => {
  var e = n.type === "ordgroup" && n.body.length ? n.body[0] : n;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
G({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: _a(e[0]),
      body: Ze(e[1]),
      isCharacterBox: Fe.isCharacterBox(e[1])
    };
  }
});
G({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[1], i = e[0], l;
    r !== "\\stackrel" ? l = _a(a) : l = "mrel";
    var s = {
      type: "op",
      mode: a.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: r !== "\\stackrel",
      body: Ze(a)
    }, o = {
      type: "supsub",
      mode: i.mode,
      base: s,
      sup: r === "\\underset" ? null : i,
      sub: r === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [o],
      isCharacterBox: Fe.isCharacterBox(o)
    };
  },
  htmlBuilder: So,
  mathmlBuilder: Ao
});
G({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: _a(e[0]),
      body: Ze(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = lt(n.body, e, !0), r = M.makeSpan([n.mclass], t, e);
    return r.style.textShadow = "0.02em 0.01em 0.04px", r;
  },
  mathmlBuilder(n, e) {
    var t = Ct(n.body, e), r = new H.MathNode("mstyle", t);
    return r.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), r;
  }
});
var Uc = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, Fl = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), El = (n) => n.type === "textord" && n.text === "@", Vc = (n, e) => (n.type === "mathord" || n.type === "atom") && n.text === e;
function Gc(n, e, t) {
  var r = Uc[n];
  switch (r) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(r, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var a = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: r,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), s = t.callFunction("\\\\cdright", [e[1]], []), o = {
        type: "ordgroup",
        mode: "math",
        body: [a, l, s]
      };
      return t.callFunction("\\\\cdparent", [o], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var d = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [d], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function jc(n) {
  var e = [];
  for (n.gullet.beginGroup(), n.gullet.macros.set("\\cr", "\\\\\\relax"), n.gullet.beginGroup(); ; ) {
    e.push(n.parseExpression(!1, "\\\\")), n.gullet.endGroup(), n.gullet.beginGroup();
    var t = n.fetch().text;
    if (t === "&" || t === "\\\\")
      n.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new J("Expected \\\\ or \\cr or \\end", n.nextToken);
  }
  for (var r = [], a = [r], i = 0; i < e.length; i++) {
    for (var l = e[i], s = Fl(), o = 0; o < l.length; o++)
      if (!El(l[o]))
        s.body.push(l[o]);
      else {
        r.push(s), o += 1;
        var d = Ni(l[o]).text, h = new Array(2);
        if (h[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, h[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(d) > -1)) if ("<>AV".indexOf(d) > -1)
          for (var f = 0; f < 2; f++) {
            for (var p = !0, _ = o + 1; _ < l.length; _++) {
              if (Vc(l[_], d)) {
                p = !1, o = _;
                break;
              }
              if (El(l[_]))
                throw new J("Missing a " + d + " character to complete a CD arrow.", l[_]);
              h[f].body.push(l[_]);
            }
            if (p)
              throw new J("Missing a " + d + " character to complete a CD arrow.", l[o]);
          }
        else
          throw new J('Expected one of "<>AV=|." after @', l[o]);
        var y = Gc(d, h, n), S = {
          type: "styling",
          body: [y],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        r.push(S), s = Fl();
      }
    i % 2 === 0 ? r.push(s) : r.shift(), r = [], a.push(r);
  }
  n.gullet.endGroup(), n.gullet.endGroup();
  var E = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: E,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
G({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: r.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = e.havingStyle(e.style.sup()), r = M.wrapFragment(Se(n.label, t, e), e);
    return r.classes.push("cd-label-" + n.side), r.style.bottom = V(0.8 - r.depth), r.height = 0, r.depth = 0, r;
  },
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mrow", [Be(n.label, e)]);
    return t = new H.MathNode("mpadded", [t]), t.setAttribute("width", "0"), n.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new H.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
G({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = M.wrapFragment(Se(n.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(n, e) {
    return new H.MathNode("mrow", [Be(n.fragment, e)]);
  }
});
G({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    for (var {
      parser: t
    } = n, r = me(e[0], "ordgroup"), a = r.body, i = "", l = 0; l < a.length; l++) {
      var s = me(a[l], "textord");
      i += s.text;
    }
    var o = parseInt(i), d;
    if (isNaN(o))
      throw new J("\\@char has non-numeric argument " + i);
    if (o < 0 || o >= 1114111)
      throw new J("\\@char with invalid code point " + i);
    return o <= 65535 ? d = String.fromCharCode(o) : (o -= 65536, d = String.fromCharCode((o >> 10) + 55296, (o & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: d
    };
  }
});
var xo = (n, e) => {
  var t = lt(n.body, e.withColor(n.color), !1);
  return M.makeFragment(t);
}, Fo = (n, e) => {
  var t = Ct(n.body, e.withColor(n.color)), r = new H.MathNode("mstyle", t);
  return r.setAttribute("mathcolor", n.color), r;
};
G({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = me(e[0], "color-token").color, a = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: r,
      body: Ze(a)
    };
  },
  htmlBuilder: xo,
  mathmlBuilder: Fo
});
G({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(n, e) {
    var {
      parser: t,
      breakOnTokenText: r
    } = n, a = me(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", a);
    var i = t.parseExpression(!0, r);
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: i
    };
  },
  htmlBuilder: xo,
  mathmlBuilder: Fo
});
G({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = r.gullet.future().text === "[" ? r.parseSizeGroup(!0) : null, i = !r.settings.displayMode || !r.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: r.mode,
      newLine: i,
      size: a && me(a, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(n, e) {
    var t = M.makeSpan(["mspace"], [], e);
    return n.newLine && (t.classes.push("newline"), n.size && (t.style.marginTop = V(Ue(n.size, e)))), t;
  },
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mspace");
    return n.newLine && (t.setAttribute("linebreak", "newline"), n.size && t.setAttribute("height", V(Ue(n.size, e)))), t;
  }
});
var ui = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, Eo = (n) => {
  var e = n.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new J("Expected a control sequence", n);
  return e;
}, Wc = (n) => {
  var e = n.gullet.popToken();
  return e.text === "=" && (e = n.gullet.popToken(), e.text === " " && (e = n.gullet.popToken())), e;
}, Co = (n, e, t, r) => {
  var a = n.gullet.macros.get(t.text);
  a == null && (t.noexpand = !0, a = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !n.gullet.isExpandable(t.text)
  }), n.gullet.macros.set(e, a, r);
};
G({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    e.consumeSpaces();
    var r = e.fetch();
    if (ui[r.text])
      return (t === "\\global" || t === "\\\\globallong") && (r.text = ui[r.text]), me(e.parseFunction(), "internal");
    throw new J("Invalid token after macro prefix", r);
  }
});
G({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = e.gullet.popToken(), a = r.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a))
      throw new J("Expected a control sequence", r);
    for (var i = 0, l, s = [[]]; e.gullet.future().text !== "{"; )
      if (r = e.gullet.popToken(), r.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), s[i].push("{");
          break;
        }
        if (r = e.gullet.popToken(), !/^[1-9]$/.test(r.text))
          throw new J('Invalid argument number "' + r.text + '"');
        if (parseInt(r.text) !== i + 1)
          throw new J('Argument number "' + r.text + '" out of order');
        i++, s.push([]);
      } else {
        if (r.text === "EOF")
          throw new J("Expected a macro definition");
        s[i].push(r.text);
      }
    var {
      tokens: o
    } = e.gullet.consumeArg();
    return l && o.unshift(l), (t === "\\edef" || t === "\\xdef") && (o = e.gullet.expandTokens(o), o.reverse()), e.gullet.macros.set(a, {
      tokens: o,
      numArgs: i,
      delimiters: s
    }, t === ui[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
G({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = Eo(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var a = Wc(e);
    return Co(e, r, a, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
G({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = Eo(e.gullet.popToken()), a = e.gullet.popToken(), i = e.gullet.popToken();
    return Co(e, r, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(a), {
      type: "internal",
      mode: e.mode
    };
  }
});
var ir = function(e, t, r) {
  var a = Ke.math[e] && Ke.math[e].replace, i = Mi(a || e, t, r);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, Ii = function(e, t, r, a) {
  var i = r.havingBaseStyle(t), l = M.makeSpan(a.concat(i.sizingClasses(r)), [e], r), s = i.sizeMultiplier / r.sizeMultiplier;
  return l.height *= s, l.depth *= s, l.maxFontSize = i.sizeMultiplier, l;
}, To = function(e, t, r) {
  var a = t.havingBaseStyle(r), i = (1 - t.sizeMultiplier / a.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = V(i), e.height -= i, e.depth += i;
}, Yc = function(e, t, r, a, i, l) {
  var s = M.makeSymbol(e, "Main-Regular", i, a), o = Ii(s, t, a, l);
  return r && To(o, a, t), o;
}, Xc = function(e, t, r, a) {
  return M.makeSymbol(e, "Size" + t + "-Regular", r, a);
}, Mo = function(e, t, r, a, i, l) {
  var s = Xc(e, t, i, a), o = Ii(M.makeSpan(["delimsizing", "size" + t], [s], a), re.TEXT, a, l);
  return r && To(o, a, re.TEXT), o;
}, qa = function(e, t, r) {
  var a;
  t === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
  var i = M.makeSpan(["delimsizinginner", a], [M.makeSpan([], [M.makeSymbol(e, t, r)])]);
  return {
    type: "elem",
    elem: i
  };
}, Na = function(e, t, r) {
  var a = D0["Size4-Regular"][e.charCodeAt(0)] ? D0["Size4-Regular"][e.charCodeAt(0)][4] : D0["Size1-Regular"][e.charCodeAt(0)][4], i = new mn("inner", ic(e, Math.round(1e3 * t))), l = new $0([i], {
    width: V(a),
    height: V(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + V(a),
    viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), s = M.makeSvgSpan([], [l], r);
  return s.height = t, s.style.height = V(t), s.style.width = V(a), {
    type: "elem",
    elem: s
  };
}, ci = 8e-3, qr = {
  type: "kern",
  size: -1 * ci
}, Zc = ["|", "\\lvert", "\\rvert", "\\vert"], Kc = ["\\|", "\\lVert", "\\rVert", "\\Vert"], zo = function(e, t, r, a, i, l) {
  var s, o, d, h, f = "", p = 0;
  s = d = h = e, o = null;
  var _ = "Size1-Regular";
  e === "\\uparrow" ? d = h = "⏐" : e === "\\Uparrow" ? d = h = "‖" : e === "\\downarrow" ? s = d = "⏐" : e === "\\Downarrow" ? s = d = "‖" : e === "\\updownarrow" ? (s = "\\uparrow", d = "⏐", h = "\\downarrow") : e === "\\Updownarrow" ? (s = "\\Uparrow", d = "‖", h = "\\Downarrow") : Zc.includes(e) ? (d = "∣", f = "vert", p = 333) : Kc.includes(e) ? (d = "∥", f = "doublevert", p = 556) : e === "[" || e === "\\lbrack" ? (s = "⎡", d = "⎢", h = "⎣", _ = "Size4-Regular", f = "lbrack", p = 667) : e === "]" || e === "\\rbrack" ? (s = "⎤", d = "⎥", h = "⎦", _ = "Size4-Regular", f = "rbrack", p = 667) : e === "\\lfloor" || e === "⌊" ? (d = s = "⎢", h = "⎣", _ = "Size4-Regular", f = "lfloor", p = 667) : e === "\\lceil" || e === "⌈" ? (s = "⎡", d = h = "⎢", _ = "Size4-Regular", f = "lceil", p = 667) : e === "\\rfloor" || e === "⌋" ? (d = s = "⎥", h = "⎦", _ = "Size4-Regular", f = "rfloor", p = 667) : e === "\\rceil" || e === "⌉" ? (s = "⎤", d = h = "⎥", _ = "Size4-Regular", f = "rceil", p = 667) : e === "(" || e === "\\lparen" ? (s = "⎛", d = "⎜", h = "⎝", _ = "Size4-Regular", f = "lparen", p = 875) : e === ")" || e === "\\rparen" ? (s = "⎞", d = "⎟", h = "⎠", _ = "Size4-Regular", f = "rparen", p = 875) : e === "\\{" || e === "\\lbrace" ? (s = "⎧", o = "⎨", h = "⎩", d = "⎪", _ = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (s = "⎫", o = "⎬", h = "⎭", d = "⎪", _ = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (s = "⎧", h = "⎩", d = "⎪", _ = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (s = "⎫", h = "⎭", d = "⎪", _ = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (s = "⎧", h = "⎭", d = "⎪", _ = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (s = "⎫", h = "⎩", d = "⎪", _ = "Size4-Regular");
  var y = ir(s, _, i), S = y.height + y.depth, E = ir(d, _, i), A = E.height + E.depth, b = ir(h, _, i), v = b.height + b.depth, w = 0, C = 1;
  if (o !== null) {
    var T = ir(o, _, i);
    w = T.height + T.depth, C = 2;
  }
  var B = S + v + w, $ = Math.max(0, Math.ceil((t - B) / (C * A))), z = B + $ * C * A, N = a.fontMetrics().axisHeight;
  r && (N *= a.sizeMultiplier);
  var j = z / 2 - N, W = [];
  if (f.length > 0) {
    var ye = z - S - v, Z = Math.round(z * 1e3), pe = lc(f, Math.round(ye * 1e3)), ke = new mn(f, pe), Re = (p / 1e3).toFixed(3) + "em", se = (Z / 1e3).toFixed(3) + "em", Ae = new $0([ke], {
      width: Re,
      height: se,
      viewBox: "0 0 " + p + " " + Z
    }), xe = M.makeSvgSpan([], [Ae], a);
    xe.height = Z / 1e3, xe.style.width = Re, xe.style.height = se, W.push({
      type: "elem",
      elem: xe
    });
  } else {
    if (W.push(qa(h, _, i)), W.push(qr), o === null) {
      var ie = z - S - v + 2 * ci;
      W.push(Na(d, ie, a));
    } else {
      var ce = (z - S - v - w) / 2 + 2 * ci;
      W.push(Na(d, ce, a)), W.push(qr), W.push(qa(o, _, i)), W.push(qr), W.push(Na(d, ce, a));
    }
    W.push(qr), W.push(qa(s, _, i));
  }
  var de = a.havingBaseStyle(re.TEXT), ge = M.makeVList({
    positionType: "bottom",
    positionData: j,
    children: W
  }, de);
  return Ii(M.makeSpan(["delimsizing", "mult"], [ge], de), re.TEXT, a, l);
}, Ra = 80, Ia = 0.08, La = function(e, t, r, a, i) {
  var l = ac(e, a, r), s = new mn(e, l), o = new $0([s], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: V(t),
    viewBox: "0 0 400000 " + r,
    preserveAspectRatio: "xMinYMin slice"
  });
  return M.makeSvgSpan(["hide-tail"], [o], i);
}, Qc = function(e, t) {
  var r = t.havingBaseSizing(), a = Ro("\\surd", e * r.sizeMultiplier, No, r), i = r.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), s, o = 0, d = 0, h = 0, f;
  return a.type === "small" ? (h = 1e3 + 1e3 * l + Ra, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), o = (1 + l + Ia) / i, d = (1 + l) / i, s = La("sqrtMain", o, h, l, t), s.style.minWidth = "0.853em", f = 0.833 / i) : a.type === "large" ? (h = (1e3 + Ra) * or[a.size], d = (or[a.size] + l) / i, o = (or[a.size] + l + Ia) / i, s = La("sqrtSize" + a.size, o, h, l, t), s.style.minWidth = "1.02em", f = 1 / i) : (o = e + l + Ia, d = e + l, h = Math.floor(1e3 * e + l) + Ra, s = La("sqrtTall", o, h, l, t), s.style.minWidth = "0.742em", f = 1.056), s.height = d, s.style.height = V(o), {
    span: s,
    advanceWidth: f,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, Bo = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], Jc = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], qo = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], or = [0, 1.2, 1.8, 2.4, 3], e4 = function(e, t, r, a, i) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), Bo.includes(e) || qo.includes(e))
    return Mo(e, t, !1, r, a, i);
  if (Jc.includes(e))
    return zo(e, or[t], !1, r, a, i);
  throw new J("Illegal delimiter: '" + e + "'");
}, t4 = [{
  type: "small",
  style: re.SCRIPTSCRIPT
}, {
  type: "small",
  style: re.SCRIPT
}, {
  type: "small",
  style: re.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], n4 = [{
  type: "small",
  style: re.SCRIPTSCRIPT
}, {
  type: "small",
  style: re.SCRIPT
}, {
  type: "small",
  style: re.TEXT
}, {
  type: "stack"
}], No = [{
  type: "small",
  style: re.SCRIPTSCRIPT
}, {
  type: "small",
  style: re.SCRIPT
}, {
  type: "small",
  style: re.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], r4 = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, Ro = function(e, t, r, a) {
  for (var i = Math.min(2, 3 - a.style.size), l = i; l < r.length && r[l].type !== "stack"; l++) {
    var s = ir(e, r4(r[l]), "math"), o = s.height + s.depth;
    if (r[l].type === "small") {
      var d = a.havingBaseStyle(r[l].style);
      o *= d.sizeMultiplier;
    }
    if (o > t)
      return r[l];
  }
  return r[r.length - 1];
}, Io = function(e, t, r, a, i, l) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var s;
  qo.includes(e) ? s = t4 : Bo.includes(e) ? s = No : s = n4;
  var o = Ro(e, t, s, a);
  return o.type === "small" ? Yc(e, o.style, r, a, i, l) : o.type === "large" ? Mo(e, o.size, r, a, i, l) : zo(e, t, r, a, i, l);
}, a4 = function(e, t, r, a, i, l) {
  var s = a.fontMetrics().axisHeight * a.sizeMultiplier, o = 901, d = 5 / a.fontMetrics().ptPerEm, h = Math.max(t - s, r + s), f = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    h / 500 * o,
    2 * h - d
  );
  return Io(e, f, !0, a, i, l);
}, A0 = {
  sqrtImage: Qc,
  sizedDelim: e4,
  sizeToMaxHeight: or,
  customSizedDelim: Io,
  leftRightDelim: a4
}, Cl = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, i4 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function ga(n, e) {
  var t = pa(n);
  if (t && i4.includes(t.text))
    return t;
  throw t ? new J("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", n) : new J("Invalid delimiter type '" + n.type + "'", n);
}
G({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = ga(e[0], n);
    return {
      type: "delimsizing",
      mode: n.parser.mode,
      size: Cl[n.funcName].size,
      mclass: Cl[n.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => n.delim === "." ? M.makeSpan([n.mclass]) : A0.sizedDelim(n.delim, n.size, e, n.mode, [n.mclass]),
  mathmlBuilder: (n) => {
    var e = [];
    n.delim !== "." && e.push(Lt(n.delim, n.mode));
    var t = new H.MathNode("mo", e);
    n.mclass === "mopen" || n.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var r = V(A0.sizeToMaxHeight[n.size]);
    return t.setAttribute("minsize", r), t.setAttribute("maxsize", r), t;
  }
});
function Tl(n) {
  if (!n.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
G({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = n.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new J("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: n.parser.mode,
      delim: ga(e[0], n).text,
      color: t
      // undefined if not set via \color
    };
  }
});
G({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = ga(e[0], n), r = n.parser;
    ++r.leftrightDepth;
    var a = r.parseExpression(!1);
    --r.leftrightDepth, r.expect("\\right", !1);
    var i = me(r.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: r.mode,
      body: a,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (n, e) => {
    Tl(n);
    for (var t = lt(n.body, e, !0, ["mopen", "mclose"]), r = 0, a = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (r = Math.max(t[l].height, r), a = Math.max(t[l].depth, a));
    r *= e.sizeMultiplier, a *= e.sizeMultiplier;
    var s;
    if (n.left === "." ? s = pr(e, ["mopen"]) : s = A0.leftRightDelim(n.left, r, a, e, n.mode, ["mopen"]), t.unshift(s), i)
      for (var o = 1; o < t.length; o++) {
        var d = t[o], h = d.isMiddle;
        h && (t[o] = A0.leftRightDelim(h.delim, r, a, h.options, n.mode, []));
      }
    var f;
    if (n.right === ".")
      f = pr(e, ["mclose"]);
    else {
      var p = n.rightColor ? e.withColor(n.rightColor) : e;
      f = A0.leftRightDelim(n.right, r, a, p, n.mode, ["mclose"]);
    }
    return t.push(f), M.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (n, e) => {
    Tl(n);
    var t = Ct(n.body, e);
    if (n.left !== ".") {
      var r = new H.MathNode("mo", [Lt(n.left, n.mode)]);
      r.setAttribute("fence", "true"), t.unshift(r);
    }
    if (n.right !== ".") {
      var a = new H.MathNode("mo", [Lt(n.right, n.mode)]);
      a.setAttribute("fence", "true"), n.rightColor && a.setAttribute("mathcolor", n.rightColor), t.push(a);
    }
    return Bi(t);
  }
});
G({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = ga(e[0], n);
    if (!n.parser.leftrightDepth)
      throw new J("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: n.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    if (n.delim === ".")
      t = pr(e, []);
    else {
      t = A0.sizedDelim(n.delim, 1, e, n.mode, []);
      var r = {
        delim: n.delim,
        options: e
      };
      t.isMiddle = r;
    }
    return t;
  },
  mathmlBuilder: (n, e) => {
    var t = n.delim === "\\vert" || n.delim === "|" ? Lt("|", "text") : Lt(n.delim, n.mode), r = new H.MathNode("mo", [t]);
    return r.setAttribute("fence", "true"), r.setAttribute("lspace", "0.05em"), r.setAttribute("rspace", "0.05em"), r;
  }
});
var Li = (n, e) => {
  var t = M.wrapFragment(Se(n.body, e), e), r = n.label.slice(1), a = e.sizeMultiplier, i, l = 0, s = Fe.isCharacterBox(n.body);
  if (r === "sout")
    i = M.makeSpan(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / a, l = -0.5 * e.fontMetrics().xHeight;
  else if (r === "phase") {
    var o = Ue({
      number: 0.6,
      unit: "pt"
    }, e), d = Ue({
      number: 0.35,
      unit: "ex"
    }, e), h = e.havingBaseSizing();
    a = a / h.sizeMultiplier;
    var f = t.height + t.depth + o + d;
    t.style.paddingLeft = V(f / 2 + o);
    var p = Math.floor(1e3 * f * a), _ = nc(p), y = new $0([new mn("phase", _)], {
      width: "400em",
      height: V(p / 1e3),
      viewBox: "0 0 400000 " + p,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = M.makeSvgSpan(["hide-tail"], [y], e), i.style.height = V(f), l = t.depth + o + d;
  } else {
    /cancel/.test(r) ? s || t.classes.push("cancel-pad") : r === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var S = 0, E = 0, A = 0;
    /box/.test(r) ? (A = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), S = e.fontMetrics().fboxsep + (r === "colorbox" ? 0 : A), E = S) : r === "angl" ? (A = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), S = 4 * A, E = Math.max(0, 0.25 - t.depth)) : (S = s ? 0.2 : 0, E = S), i = x0.encloseSpan(t, r, S, E, e), /fbox|boxed|fcolorbox/.test(r) ? (i.style.borderStyle = "solid", i.style.borderWidth = V(A)) : r === "angl" && A !== 0.049 && (i.style.borderTopWidth = V(A), i.style.borderRightWidth = V(A)), l = t.depth + E, n.backgroundColor && (i.style.backgroundColor = n.backgroundColor, n.borderColor && (i.style.borderColor = n.borderColor));
  }
  var b;
  if (n.backgroundColor)
    b = M.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var v = /cancel|phase/.test(r) ? ["svg-align"] : [];
    b = M.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: v
        }
      ]
    }, e);
  }
  return /cancel/.test(r) && (b.height = t.height, b.depth = t.depth), /cancel/.test(r) && !s ? M.makeSpan(["mord", "cancel-lap"], [b], e) : M.makeSpan(["mord"], [b], e);
}, Oi = (n, e) => {
  var t = 0, r = new H.MathNode(n.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [Be(n.body, e)]);
  switch (n.label) {
    case "\\cancel":
      r.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      r.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      r.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      r.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      r.setAttribute("notation", "box");
      break;
    case "\\angl":
      r.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * t + "pt"), r.setAttribute("height", "+" + 2 * t + "pt"), r.setAttribute("lspace", t + "pt"), r.setAttribute("voffset", t + "pt"), n.label === "\\fcolorbox") {
        var a = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        r.setAttribute("style", "border: " + a + "em solid " + String(n.borderColor));
      }
      break;
    case "\\xcancel":
      r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return n.backgroundColor && r.setAttribute("mathbackground", n.backgroundColor), r;
};
G({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = me(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: Li,
  mathmlBuilder: Oi
});
G({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = me(e[0], "color-token").color, l = me(e[1], "color-token").color, s = e[2];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: l,
      borderColor: i,
      body: s
    };
  },
  htmlBuilder: Li,
  mathmlBuilder: Oi
});
G({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
G({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: r,
      body: a
    };
  },
  htmlBuilder: Li,
  mathmlBuilder: Oi
});
G({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var Lo = {};
function f0(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, s = {
    type: e,
    numArgs: r.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: a
  }, o = 0; o < t.length; ++o)
    Lo[t[o]] = s;
  i && (ta[e] = i), l && (na[e] = l);
}
var l4 = {};
function g(n, e) {
  l4[n] = e;
}
function Ml(n) {
  var e = [];
  n.consumeSpaces();
  var t = n.fetch().text;
  for (t === "\\relax" && (n.consume(), n.consumeSpaces(), t = n.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    n.consume(), e.push(t === "\\hdashline"), n.consumeSpaces(), t = n.fetch().text;
  return e;
}
var va = (n) => {
  var e = n.parser.settings;
  if (!e.displayMode)
    throw new J("{" + n.envName + "} can be used only in display mode.");
};
function Pi(n) {
  if (n.indexOf("ed") === -1)
    return n.indexOf("*") === -1;
}
function V0(n, e, t) {
  var {
    hskipBeforeAndAfter: r,
    addJot: a,
    cols: i,
    arraystretch: l,
    colSeparationType: s,
    autoTag: o,
    singleRow: d,
    emptySingleRow: h,
    maxNumCols: f,
    leqno: p
  } = e;
  if (n.gullet.beginGroup(), d || n.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var _ = n.gullet.expandMacroAsText("\\arraystretch");
    if (_ == null)
      l = 1;
    else if (l = parseFloat(_), !l || l < 0)
      throw new J("Invalid \\arraystretch: " + _);
  }
  n.gullet.beginGroup();
  var y = [], S = [y], E = [], A = [], b = o != null ? [] : void 0;
  function v() {
    o && n.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function w() {
    b && (n.gullet.macros.get("\\df@tag") ? (b.push(n.subparse([new Ci("\\df@tag")])), n.gullet.macros.set("\\df@tag", void 0, !0)) : b.push(!!o && n.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (v(), A.push(Ml(n)); ; ) {
    var C = n.parseExpression(!1, d ? "\\end" : "\\\\");
    n.gullet.endGroup(), n.gullet.beginGroup(), C = {
      type: "ordgroup",
      mode: n.mode,
      body: C
    }, t && (C = {
      type: "styling",
      mode: n.mode,
      style: t,
      body: [C]
    }), y.push(C);
    var T = n.fetch().text;
    if (T === "&") {
      if (f && y.length === f) {
        if (d || s)
          throw new J("Too many tab characters: &", n.nextToken);
        n.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      n.consume();
    } else if (T === "\\end") {
      w(), y.length === 1 && C.type === "styling" && C.body[0].body.length === 0 && (S.length > 1 || !h) && S.pop(), A.length < S.length + 1 && A.push([]);
      break;
    } else if (T === "\\\\") {
      n.consume();
      var B = void 0;
      n.gullet.future().text !== " " && (B = n.parseSizeGroup(!0)), E.push(B ? B.value : null), w(), A.push(Ml(n)), y = [], S.push(y), v();
    } else
      throw new J("Expected & or \\\\ or \\cr or \\end", n.nextToken);
  }
  return n.gullet.endGroup(), n.gullet.endGroup(), {
    type: "array",
    mode: n.mode,
    addJot: a,
    arraystretch: l,
    body: S,
    cols: i,
    rowGaps: E,
    hskipBeforeAndAfter: r,
    hLinesBeforeRow: A,
    colSeparationType: s,
    tags: b,
    leqno: p
  };
}
function $i(n) {
  return n.slice(0, 1) === "d" ? "display" : "text";
}
var p0 = function(e, t) {
  var r, a, i = e.body.length, l = e.hLinesBeforeRow, s = 0, o = new Array(i), d = [], h = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), f = 1 / t.fontMetrics().ptPerEm, p = 5 * f;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var _ = t.havingStyle(re.SCRIPT).sizeMultiplier;
    p = 0.2778 * (_ / t.sizeMultiplier);
  }
  var y = e.colSeparationType === "CD" ? Ue({
    number: 3,
    unit: "ex"
  }, t) : 12 * f, S = 3 * f, E = e.arraystretch * y, A = 0.7 * E, b = 0.3 * E, v = 0;
  function w(ze) {
    for (var Xe = 0; Xe < ze.length; ++Xe)
      Xe > 0 && (v += 0.25), d.push({
        pos: v,
        isDashed: ze[Xe]
      });
  }
  for (w(l[0]), r = 0; r < e.body.length; ++r) {
    var C = e.body[r], T = A, B = b;
    s < C.length && (s = C.length);
    var $ = new Array(C.length);
    for (a = 0; a < C.length; ++a) {
      var z = Se(C[a], t);
      B < z.depth && (B = z.depth), T < z.height && (T = z.height), $[a] = z;
    }
    var N = e.rowGaps[r], j = 0;
    N && (j = Ue(N, t), j > 0 && (j += b, B < j && (B = j), j = 0)), e.addJot && (B += S), $.height = T, $.depth = B, v += T, $.pos = v, v += B + j, o[r] = $, w(l[r + 1]);
  }
  var W = v / 2 + t.fontMetrics().axisHeight, ye = e.cols || [], Z = [], pe, ke, Re = [];
  if (e.tags && e.tags.some((ze) => ze))
    for (r = 0; r < i; ++r) {
      var se = o[r], Ae = se.pos - W, xe = e.tags[r], ie = void 0;
      xe === !0 ? ie = M.makeSpan(["eqn-num"], [], t) : xe === !1 ? ie = M.makeSpan([], [], t) : ie = M.makeSpan([], lt(xe, t, !0), t), ie.depth = se.depth, ie.height = se.height, Re.push({
        type: "elem",
        elem: ie,
        shift: Ae
      });
    }
  for (
    a = 0, ke = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    a < s || ke < ye.length;
    ++a, ++ke
  ) {
    for (var ce = ye[ke] || {}, de = !0; ce.type === "separator"; ) {
      if (de || (pe = M.makeSpan(["arraycolsep"], []), pe.style.width = V(t.fontMetrics().doubleRuleSep), Z.push(pe)), ce.separator === "|" || ce.separator === ":") {
        var ge = ce.separator === "|" ? "solid" : "dashed", P = M.makeSpan(["vertical-separator"], [], t);
        P.style.height = V(v), P.style.borderRightWidth = V(h), P.style.borderRightStyle = ge, P.style.margin = "0 " + V(-h / 2);
        var Ie = v - W;
        Ie && (P.style.verticalAlign = V(-Ie)), Z.push(P);
      } else
        throw new J("Invalid separator type: " + ce.separator);
      ke++, ce = ye[ke] || {}, de = !1;
    }
    if (!(a >= s)) {
      var Ee = void 0;
      (a > 0 || e.hskipBeforeAndAfter) && (Ee = Fe.deflt(ce.pregap, p), Ee !== 0 && (pe = M.makeSpan(["arraycolsep"], []), pe.style.width = V(Ee), Z.push(pe)));
      var L = [];
      for (r = 0; r < i; ++r) {
        var he = o[r], we = he[a];
        if (we) {
          var R = he.pos - W;
          we.depth = he.depth, we.height = he.height, L.push({
            type: "elem",
            elem: we,
            shift: R
          });
        }
      }
      L = M.makeVList({
        positionType: "individualShift",
        children: L
      }, t), L = M.makeSpan(["col-align-" + (ce.align || "c")], [L]), Z.push(L), (a < s - 1 || e.hskipBeforeAndAfter) && (Ee = Fe.deflt(ce.postgap, p), Ee !== 0 && (pe = M.makeSpan(["arraycolsep"], []), pe.style.width = V(Ee), Z.push(pe)));
    }
  }
  if (o = M.makeSpan(["mtable"], Z), d.length > 0) {
    for (var te = M.makeLineSpan("hline", t, h), ae = M.makeLineSpan("hdashline", t, h), ue = [{
      type: "elem",
      elem: o,
      shift: 0
    }]; d.length > 0; ) {
      var _e = d.pop(), Le = _e.pos - W;
      _e.isDashed ? ue.push({
        type: "elem",
        elem: ae,
        shift: Le
      }) : ue.push({
        type: "elem",
        elem: te,
        shift: Le
      });
    }
    o = M.makeVList({
      positionType: "individualShift",
      children: ue
    }, t);
  }
  if (Re.length === 0)
    return M.makeSpan(["mord"], [o], t);
  var je = M.makeVList({
    positionType: "individualShift",
    children: Re
  }, t);
  return je = M.makeSpan(["tag"], [je], t), M.makeFragment([o, je]);
}, s4 = {
  c: "center ",
  l: "left ",
  r: "right "
}, _0 = function(e, t) {
  for (var r = [], a = new H.MathNode("mtd", [], ["mtr-glue"]), i = new H.MathNode("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var s = e.body[l], o = [], d = 0; d < s.length; d++)
      o.push(new H.MathNode("mtd", [Be(s[d], t)]));
    e.tags && e.tags[l] && (o.unshift(a), o.push(a), e.leqno ? o.unshift(i) : o.push(i)), r.push(new H.MathNode("mtr", o));
  }
  var h = new H.MathNode("mtable", r), f = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  h.setAttribute("rowspacing", V(f));
  var p = "", _ = "";
  if (e.cols && e.cols.length > 0) {
    var y = e.cols, S = "", E = !1, A = 0, b = y.length;
    y[0].type === "separator" && (p += "top ", A = 1), y[y.length - 1].type === "separator" && (p += "bottom ", b -= 1);
    for (var v = A; v < b; v++)
      y[v].type === "align" ? (_ += s4[y[v].align], E && (S += "none "), E = !0) : y[v].type === "separator" && E && (S += y[v].separator === "|" ? "solid " : "dashed ", E = !1);
    h.setAttribute("columnalign", _.trim()), /[sd]/.test(S) && h.setAttribute("columnlines", S.trim());
  }
  if (e.colSeparationType === "align") {
    for (var w = e.cols || [], C = "", T = 1; T < w.length; T++)
      C += T % 2 ? "0em " : "1em ";
    h.setAttribute("columnspacing", C.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? h.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? h.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? h.setAttribute("columnspacing", "0.5em") : h.setAttribute("columnspacing", "1em");
  var B = "", $ = e.hLinesBeforeRow;
  p += $[0].length > 0 ? "left " : "", p += $[$.length - 1].length > 0 ? "right " : "";
  for (var z = 1; z < $.length - 1; z++)
    B += $[z].length === 0 ? "none " : $[z][0] ? "dashed " : "solid ";
  return /[sd]/.test(B) && h.setAttribute("rowlines", B.trim()), p !== "" && (h = new H.MathNode("menclose", [h]), h.setAttribute("notation", p.trim())), e.arraystretch && e.arraystretch < 1 && (h = new H.MathNode("mstyle", [h]), h.setAttribute("scriptlevel", "1")), h;
}, Oo = function(e, t) {
  e.envName.indexOf("ed") === -1 && va(e);
  var r = [], a = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", l = V0(e.parser, {
    cols: r,
    addJot: !0,
    autoTag: i ? void 0 : Pi(e.envName),
    emptySingleRow: !0,
    colSeparationType: a,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), s, o = 0, d = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var h = "", f = 0; f < t[0].body.length; f++) {
      var p = me(t[0].body[f], "textord");
      h += p.text;
    }
    s = Number(h), o = s * 2;
  }
  var _ = !o;
  l.body.forEach(function(A) {
    for (var b = 1; b < A.length; b += 2) {
      var v = me(A[b], "styling"), w = me(v.body[0], "ordgroup");
      w.body.unshift(d);
    }
    if (_)
      o < A.length && (o = A.length);
    else {
      var C = A.length / 2;
      if (s < C)
        throw new J("Too many math in a row: " + ("expected " + s + ", but got " + C), A[0]);
    }
  });
  for (var y = 0; y < o; ++y) {
    var S = "r", E = 0;
    y % 2 === 1 ? S = "l" : y > 0 && _ && (E = 1), r[y] = {
      type: "align",
      align: S,
      pregap: E,
      postgap: 0
    };
  }
  return l.colSeparationType = _ ? "align" : "alignat", l;
};
f0({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = pa(e[0]), r = t ? [e[0]] : me(e[0], "ordgroup").body, a = r.map(function(l) {
      var s = Ni(l), o = s.text;
      if ("lcr".indexOf(o) !== -1)
        return {
          type: "align",
          align: o
        };
      if (o === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (o === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new J("Unknown column alignment: " + o, l);
    }), i = {
      cols: a,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: a.length
    };
    return V0(n.parser, i, $i(n.envName));
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[n.envName.replace("*", "")], t = "c", r = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (n.envName.charAt(n.envName.length - 1) === "*") {
      var a = n.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), t = a.fetch().text, "lcr".indexOf(t) === -1)
          throw new J("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), r.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = V0(n.parser, r, $i(n.envName)), l = Math.max(0, ...i.body.map((s) => s.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: n.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 0.5
    }, t = V0(n.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = pa(e[0]), r = t ? [e[0]] : me(e[0], "ordgroup").body, a = r.map(function(l) {
      var s = Ni(l), o = s.text;
      if ("lc".indexOf(o) !== -1)
        return {
          type: "align",
          align: o
        };
      throw new J("Unknown column alignment: " + o, l);
    });
    if (a.length > 1)
      throw new J("{subarray} can contain only one column");
    var i = {
      cols: a,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = V0(n.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new J("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = V0(n.parser, e, $i(n.envName));
    return {
      type: "leftright",
      mode: n.mode,
      body: [t],
      left: n.envName.indexOf("r") > -1 ? "." : "\\{",
      right: n.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: Oo,
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    ["gather", "gather*"].includes(n.envName) && va(n);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: Pi(n.envName),
      emptySingleRow: !0,
      leqno: n.parser.settings.leqno
    };
    return V0(n.parser, e, "display");
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: Oo,
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    va(n);
    var e = {
      autoTag: Pi(n.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: n.parser.settings.leqno
    };
    return V0(n.parser, e, "display");
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
f0({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(n) {
    return va(n), jc(n.parser);
  },
  htmlBuilder: p0,
  mathmlBuilder: _0
});
g("\\nonumber", "\\gdef\\@eqnsw{0}");
g("\\notag", "\\nonumber");
G({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(n, e) {
    throw new J(n.funcName + " valid only within array environment");
  }
});
var zl = Lo;
G({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    if (a.type !== "ordgroup")
      throw new J("Invalid environment name", a);
    for (var i = "", l = 0; l < a.body.length; ++l)
      i += me(a.body[l], "textord").text;
    if (r === "\\begin") {
      if (!zl.hasOwnProperty(i))
        throw new J("No such environment: " + i, a);
      var s = zl[i], {
        args: o,
        optArgs: d
      } = t.parseArguments("\\begin{" + i + "}", s), h = {
        mode: t.mode,
        envName: i,
        parser: t
      }, f = s.handler(h, o, d);
      t.expect("\\end", !1);
      var p = t.nextToken, _ = me(t.parseFunction(), "environment");
      if (_.name !== i)
        throw new J("Mismatch: \\begin{" + i + "} matched by \\end{" + _.name + "}", p);
      return f;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: a
    };
  }
});
var Po = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return Se(n.body, r);
}, $o = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return Be(n.body, r);
}, Bl = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
G({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    "\\mathsfit",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = ra(e[0]), i = r;
    return i in Bl && (i = Bl[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: a
    };
  },
  htmlBuilder: Po,
  mathmlBuilder: $o
});
G({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0], a = Fe.isCharacterBox(r);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: _a(r),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: r
      }],
      isCharacterBox: a
    };
  }
});
G({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      breakOnTokenText: a
    } = n, {
      mode: i
    } = t, l = t.parseExpression(!0, a), s = "math" + r.slice(1);
    return {
      type: "font",
      mode: i,
      font: s,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: Po,
  mathmlBuilder: $o
});
var Ho = (n, e) => {
  var t = e;
  return n === "display" ? t = t.id >= re.SCRIPT.id ? t.text() : re.DISPLAY : n === "text" && t.size === re.DISPLAY.size ? t = re.TEXT : n === "script" ? t = re.SCRIPT : n === "scriptscript" && (t = re.SCRIPTSCRIPT), t;
}, Hi = (n, e) => {
  var t = Ho(n.size, e.style), r = t.fracNum(), a = t.fracDen(), i;
  i = e.havingStyle(r);
  var l = Se(n.numer, i, e);
  if (n.continued) {
    var s = 8.5 / e.fontMetrics().ptPerEm, o = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < s ? s : l.height, l.depth = l.depth < o ? o : l.depth;
  }
  i = e.havingStyle(a);
  var d = Se(n.denom, i, e), h, f, p;
  n.hasBarLine ? (n.barSize ? (f = Ue(n.barSize, e), h = M.makeLineSpan("frac-line", e, f)) : h = M.makeLineSpan("frac-line", e), f = h.height, p = h.height) : (h = null, f = 0, p = e.fontMetrics().defaultRuleThickness);
  var _, y, S;
  t.size === re.DISPLAY.size || n.size === "display" ? (_ = e.fontMetrics().num1, f > 0 ? y = 3 * p : y = 7 * p, S = e.fontMetrics().denom1) : (f > 0 ? (_ = e.fontMetrics().num2, y = p) : (_ = e.fontMetrics().num3, y = 3 * p), S = e.fontMetrics().denom2);
  var E;
  if (h) {
    var b = e.fontMetrics().axisHeight;
    _ - l.depth - (b + 0.5 * f) < y && (_ += y - (_ - l.depth - (b + 0.5 * f))), b - 0.5 * f - (d.height - S) < y && (S += y - (b - 0.5 * f - (d.height - S)));
    var v = -(b - 0.5 * f);
    E = M.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: d,
        shift: S
      }, {
        type: "elem",
        elem: h,
        shift: v
      }, {
        type: "elem",
        elem: l,
        shift: -_
      }]
    }, e);
  } else {
    var A = _ - l.depth - (d.height - S);
    A < y && (_ += 0.5 * (y - A), S += 0.5 * (y - A)), E = M.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: d,
        shift: S
      }, {
        type: "elem",
        elem: l,
        shift: -_
      }]
    }, e);
  }
  i = e.havingStyle(t), E.height *= i.sizeMultiplier / e.sizeMultiplier, E.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var w;
  t.size === re.DISPLAY.size ? w = e.fontMetrics().delim1 : t.size === re.SCRIPTSCRIPT.size ? w = e.havingStyle(re.SCRIPT).fontMetrics().delim2 : w = e.fontMetrics().delim2;
  var C, T;
  return n.leftDelim == null ? C = pr(e, ["mopen"]) : C = A0.customSizedDelim(n.leftDelim, w, !0, e.havingStyle(t), n.mode, ["mopen"]), n.continued ? T = M.makeSpan([]) : n.rightDelim == null ? T = pr(e, ["mclose"]) : T = A0.customSizedDelim(n.rightDelim, w, !0, e.havingStyle(t), n.mode, ["mclose"]), M.makeSpan(["mord"].concat(i.sizingClasses(e)), [C, M.makeSpan(["mfrac"], [E]), T], e);
}, Ui = (n, e) => {
  var t = new H.MathNode("mfrac", [Be(n.numer, e), Be(n.denom, e)]);
  if (!n.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (n.barSize) {
    var r = Ue(n.barSize, e);
    t.setAttribute("linethickness", V(r));
  }
  var a = Ho(n.size, e.style);
  if (a.size !== e.style.size) {
    t = new H.MathNode("mstyle", [t]);
    var i = a.size === re.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", i), t.setAttribute("scriptlevel", "0");
  }
  if (n.leftDelim != null || n.rightDelim != null) {
    var l = [];
    if (n.leftDelim != null) {
      var s = new H.MathNode("mo", [new H.TextNode(n.leftDelim.replace("\\", ""))]);
      s.setAttribute("fence", "true"), l.push(s);
    }
    if (l.push(t), n.rightDelim != null) {
      var o = new H.MathNode("mo", [new H.TextNode(n.rightDelim.replace("\\", ""))]);
      o.setAttribute("fence", "true"), l.push(o);
    }
    return Bi(l);
  }
  return t;
};
G({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1], l, s = null, o = null, d = "auto";
    switch (r) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, s = "(", o = ")";
        break;
      case "\\\\bracefrac":
        l = !1, s = "\\{", o = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, s = "[", o = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (r) {
      case "\\dfrac":
      case "\\dbinom":
        d = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        d = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: a,
      denom: i,
      hasBarLine: l,
      leftDelim: s,
      rightDelim: o,
      size: d,
      barSize: null
    };
  },
  htmlBuilder: Hi,
  mathmlBuilder: Ui
});
G({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: a,
      denom: i,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
G({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t,
      token: r
    } = n, a;
    switch (t) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: a,
      token: r
    };
  }
});
var ql = ["display", "text", "script", "scriptscript"], Nl = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
G({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[4], a = e[5], i = ra(e[0]), l = i.type === "atom" && i.family === "open" ? Nl(i.text) : null, s = ra(e[1]), o = s.type === "atom" && s.family === "close" ? Nl(s.text) : null, d = me(e[2], "size"), h, f = null;
    d.isBlank ? h = !0 : (f = d.value, h = f.number > 0);
    var p = "auto", _ = e[3];
    if (_.type === "ordgroup") {
      if (_.body.length > 0) {
        var y = me(_.body[0], "textord");
        p = ql[Number(y.text)];
      }
    } else
      _ = me(_, "textord"), p = ql[Number(_.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: r,
      denom: a,
      continued: !1,
      hasBarLine: h,
      barSize: f,
      leftDelim: l,
      rightDelim: o,
      size: p
    };
  },
  htmlBuilder: Hi,
  mathmlBuilder: Ui
});
G({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: me(e[0], "size").value,
      token: a
    };
  }
});
G({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = $1(me(e[1], "infix").size), l = e[2], s = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: l,
      continued: !1,
      hasBarLine: s,
      barSize: i,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: Hi,
  mathmlBuilder: Ui
});
var Uo = (n, e) => {
  var t = e.style, r, a;
  n.type === "supsub" ? (r = n.sup ? Se(n.sup, e.havingStyle(t.sup()), e) : Se(n.sub, e.havingStyle(t.sub()), e), a = me(n.base, "horizBrace")) : a = me(n, "horizBrace");
  var i = Se(a.base, e.havingBaseStyle(re.DISPLAY)), l = x0.svgSpan(a, e), s;
  if (a.isOver ? (s = M.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }, e), s.children[0].children[0].children[1].classes.push("svg-align")) : (s = M.makeVList({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }, e), s.children[0].children[0].children[0].classes.push("svg-align")), r) {
    var o = M.makeSpan(["mord", a.isOver ? "mover" : "munder"], [s], e);
    a.isOver ? s = M.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: o
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: r
      }]
    }, e) : s = M.makeVList({
      positionType: "bottom",
      positionData: o.depth + 0.2 + r.height + r.depth,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: o
      }]
    }, e);
  }
  return M.makeSpan(["mord", a.isOver ? "mover" : "munder"], [s], e);
}, o4 = (n, e) => {
  var t = x0.mathMLnode(n.label);
  return new H.MathNode(n.isOver ? "mover" : "munder", [Be(n.base, e), t]);
};
G({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: r,
      isOver: /^\\over/.test(r),
      base: e[0]
    };
  },
  htmlBuilder: Uo,
  mathmlBuilder: o4
});
G({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[1], a = me(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: t.mode,
      href: a,
      body: Ze(r)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (n, e) => {
    var t = lt(n.body, e, !1);
    return M.makeAnchor(n.href, [], t, e);
  },
  mathmlBuilder: (n, e) => {
    var t = H0(n.body, e);
    return t instanceof Bt || (t = new Bt("mrow", [t])), t.setAttribute("href", n.href), t;
  }
});
G({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = me(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: r
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var a = [], i = 0; i < r.length; i++) {
      var l = r[i];
      l === "~" && (l = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var s = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: t.mode,
      href: r,
      body: Ze(s)
    };
  }
});
G({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "hbox",
      mode: t.mode,
      body: Ze(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = lt(n.body, e, !1);
    return M.makeFragment(t);
  },
  mathmlBuilder(n, e) {
    return new H.MathNode("mrow", Ct(n.body, e));
  }
});
G({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n, i = me(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var s, o = {};
    switch (r) {
      case "\\htmlClass":
        o.class = i, s = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        o.id = i, s = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        o.style = i, s = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var d = i.split(","), h = 0; h < d.length; h++) {
          var f = d[h].split("=");
          if (f.length !== 2)
            throw new J("Error parsing key-value for \\htmlData");
          o["data-" + f[0].trim()] = f[1].trim();
        }
        s = {
          command: "\\htmlData",
          attributes: o
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(s) ? {
      type: "html",
      mode: t.mode,
      attributes: o,
      body: Ze(l)
    } : t.formatUnsupportedCmd(r);
  },
  htmlBuilder: (n, e) => {
    var t = lt(n.body, e, !1), r = ["enclosing"];
    n.attributes.class && r.push(...n.attributes.class.trim().split(/\s+/));
    var a = M.makeSpan(r, t, e);
    for (var i in n.attributes)
      i !== "class" && n.attributes.hasOwnProperty(i) && a.setAttribute(i, n.attributes[i]);
    return a;
  },
  mathmlBuilder: (n, e) => H0(n.body, e)
});
G({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: Ze(e[0]),
      mathml: Ze(e[1])
    };
  },
  htmlBuilder: (n, e) => {
    var t = lt(n.html, e, !1);
    return M.makeFragment(t);
  },
  mathmlBuilder: (n, e) => H0(n.mathml, e)
});
var Oa = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new J("Invalid size: '" + e + "' in \\includegraphics");
  var r = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!oc(r))
    throw new J("Invalid unit: '" + r.unit + "' in \\includegraphics.");
  return r;
};
G({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, s = "";
    if (t[0])
      for (var o = me(t[0], "raw").string, d = o.split(","), h = 0; h < d.length; h++) {
        var f = d[h].split("=");
        if (f.length === 2) {
          var p = f[1].trim();
          switch (f[0].trim()) {
            case "alt":
              s = p;
              break;
            case "width":
              a = Oa(p);
              break;
            case "height":
              i = Oa(p);
              break;
            case "totalheight":
              l = Oa(p);
              break;
            default:
              throw new J("Invalid key: '" + f[0] + "' in \\includegraphics.");
          }
        }
      }
    var _ = me(e[0], "url").url;
    return s === "" && (s = _, s = s.replace(/^.*[\\/]/, ""), s = s.substring(0, s.lastIndexOf("."))), r.settings.isTrusted({
      command: "\\includegraphics",
      url: _
    }) ? {
      type: "includegraphics",
      mode: r.mode,
      alt: s,
      width: a,
      height: i,
      totalheight: l,
      src: _
    } : r.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (n, e) => {
    var t = Ue(n.height, e), r = 0;
    n.totalheight.number > 0 && (r = Ue(n.totalheight, e) - t);
    var a = 0;
    n.width.number > 0 && (a = Ue(n.width, e));
    var i = {
      height: V(t + r)
    };
    a > 0 && (i.width = V(a)), r > 0 && (i.verticalAlign = V(-r));
    var l = new cc(n.src, n.alt, i);
    return l.height = t, l.depth = r, l;
  },
  mathmlBuilder: (n, e) => {
    var t = new H.MathNode("mglyph", []);
    t.setAttribute("alt", n.alt);
    var r = Ue(n.height, e), a = 0;
    if (n.totalheight.number > 0 && (a = Ue(n.totalheight, e) - r, t.setAttribute("valign", V(-a))), t.setAttribute("height", V(r + a)), n.width.number > 0) {
      var i = Ue(n.width, e);
      t.setAttribute("width", V(i));
    }
    return t.setAttribute("src", n.src), t;
  }
});
G({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = me(e[0], "size");
    if (t.settings.strict) {
      var i = r[1] === "m", l = a.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " supports only mu units, " + ("not " + a.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: a.value
    };
  },
  htmlBuilder(n, e) {
    return M.makeGlue(n.dimension, e);
  },
  mathmlBuilder(n, e) {
    var t = Ue(n.dimension, e);
    return new H.SpaceNode(t);
  }
});
G({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: r.slice(5),
      body: a
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    n.alignment === "clap" ? (t = M.makeSpan([], [Se(n.body, e)]), t = M.makeSpan(["inner"], [t], e)) : t = M.makeSpan(["inner"], [Se(n.body, e)]);
    var r = M.makeSpan(["fix"], []), a = M.makeSpan([n.alignment], [t, r], e), i = M.makeSpan(["strut"]);
    return i.style.height = V(a.height + a.depth), a.depth && (i.style.verticalAlign = V(-a.depth)), a.children.unshift(i), a = M.makeSpan(["thinbox"], [a], e), M.makeSpan(["mord", "vbox"], [a], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new H.MathNode("mpadded", [Be(n.body, e)]);
    if (n.alignment !== "rlap") {
      var r = n.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", r + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
G({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    var {
      funcName: t,
      parser: r
    } = n, a = r.mode;
    r.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = r.parseExpression(!1, i);
    return r.expect(i), r.switchMode(a), {
      type: "styling",
      mode: r.mode,
      style: "text",
      body: l
    };
  }
});
G({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    throw new J("Mismatched " + n.funcName);
  }
});
var Rl = (n, e) => {
  switch (e.style.size) {
    case re.DISPLAY.size:
      return n.display;
    case re.TEXT.size:
      return n.text;
    case re.SCRIPT.size:
      return n.script;
    case re.SCRIPTSCRIPT.size:
      return n.scriptscript;
    default:
      return n.text;
  }
};
G({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: Ze(e[0]),
      text: Ze(e[1]),
      script: Ze(e[2]),
      scriptscript: Ze(e[3])
    };
  },
  htmlBuilder: (n, e) => {
    var t = Rl(n, e), r = lt(t, e, !1);
    return M.makeFragment(r);
  },
  mathmlBuilder: (n, e) => {
    var t = Rl(n, e);
    return H0(t, e);
  }
});
var Vo = (n, e, t, r, a, i, l) => {
  n = M.makeSpan([], [n]);
  var s = t && Fe.isCharacterBox(t), o, d;
  if (e) {
    var h = Se(e, r.havingStyle(a.sup()), r);
    d = {
      elem: h,
      kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - h.depth)
    };
  }
  if (t) {
    var f = Se(t, r.havingStyle(a.sub()), r);
    o = {
      elem: f,
      kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - f.height)
    };
  }
  var p;
  if (d && o) {
    var _ = r.fontMetrics().bigOpSpacing5 + o.elem.height + o.elem.depth + o.kern + n.depth + l;
    p = M.makeVList({
      positionType: "bottom",
      positionData: _,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: o.elem,
        marginLeft: V(-i)
      }, {
        type: "kern",
        size: o.kern
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: d.kern
      }, {
        type: "elem",
        elem: d.elem,
        marginLeft: V(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else if (o) {
    var y = n.height - l;
    p = M.makeVList({
      positionType: "top",
      positionData: y,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: o.elem,
        marginLeft: V(-i)
      }, {
        type: "kern",
        size: o.kern
      }, {
        type: "elem",
        elem: n
      }]
    }, r);
  } else if (d) {
    var S = n.depth + l;
    p = M.makeVList({
      positionType: "bottom",
      positionData: S,
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: d.kern
      }, {
        type: "elem",
        elem: d.elem,
        marginLeft: V(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else
    return n;
  var E = [p];
  if (o && i !== 0 && !s) {
    var A = M.makeSpan(["mspace"], [], r);
    A.style.marginRight = V(i), E.unshift(A);
  }
  return M.makeSpan(["mop", "op-limits"], E, r);
}, Go = ["\\smallint"], Un = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = me(n.base, "op"), a = !0) : i = me(n, "op");
  var l = e.style, s = !1;
  l.size === re.DISPLAY.size && i.symbol && !Go.includes(i.name) && (s = !0);
  var o;
  if (i.symbol) {
    var d = s ? "Size2-Regular" : "Size1-Regular", h = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (h = i.name.slice(1), i.name = h === "oiint" ? "\\iint" : "\\iiint"), o = M.makeSymbol(i.name, d, "math", e, ["mop", "op-symbol", s ? "large-op" : "small-op"]), h.length > 0) {
      var f = o.italic, p = M.staticSvg(h + "Size" + (s ? "2" : "1"), e);
      o = M.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: o,
          shift: 0
        }, {
          type: "elem",
          elem: p,
          shift: s ? 0.08 : 0
        }]
      }, e), i.name = "\\" + h, o.classes.unshift("mop"), o.italic = f;
    }
  } else if (i.body) {
    var _ = lt(i.body, e, !0);
    _.length === 1 && _[0] instanceof m0 ? (o = _[0], o.classes[0] = "mop") : o = M.makeSpan(["mop"], _, e);
  } else {
    for (var y = [], S = 1; S < i.name.length; S++)
      y.push(M.mathsym(i.name[S], i.mode, e));
    o = M.makeSpan(["mop"], y, e);
  }
  var E = 0, A = 0;
  return (o instanceof m0 || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (E = (o.height - o.depth) / 2 - e.fontMetrics().axisHeight, A = o.italic), a ? Vo(o, t, r, e, l, A, E) : (E && (o.style.position = "relative", o.style.top = V(E)), o);
}, br = (n, e) => {
  var t;
  if (n.symbol)
    t = new Bt("mo", [Lt(n.name, n.mode)]), Go.includes(n.name) && t.setAttribute("largeop", "false");
  else if (n.body)
    t = new Bt("mo", Ct(n.body, e));
  else {
    t = new Bt("mi", [new i0(n.name.slice(1))]);
    var r = new Bt("mo", [Lt("⁡", "text")]);
    n.parentIsSupSub ? t = new Bt("mrow", [t, r]) : t = ko([t, r]);
  }
  return t;
}, u4 = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
G({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = r;
    return a.length === 1 && (a = u4[a]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: Un,
  mathmlBuilder: br
});
G({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: Ze(r)
    };
  },
  htmlBuilder: Un,
  mathmlBuilder: br
});
var c4 = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
G({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: Un,
  mathmlBuilder: br
});
G({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: Un,
  mathmlBuilder: br
});
G({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = t;
    return r.length === 1 && (r = c4[r]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: r
    };
  },
  htmlBuilder: Un,
  mathmlBuilder: br
});
var jo = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = me(n.base, "operatorname"), a = !0) : i = me(n, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var s = i.body.map((f) => {
      var p = f.text;
      return typeof p == "string" ? {
        type: "textord",
        mode: f.mode,
        text: p
      } : f;
    }), o = lt(s, e.withFont("mathrm"), !0), d = 0; d < o.length; d++) {
      var h = o[d];
      h instanceof m0 && (h.text = h.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = M.makeSpan(["mop"], o, e);
  } else
    l = M.makeSpan(["mop"], [], e);
  return a ? Vo(l, t, r, e, e.style, 0, 0) : l;
}, d4 = (n, e) => {
  for (var t = Ct(n.body, e.withFont("mathrm")), r = !0, a = 0; a < t.length; a++) {
    var i = t[a];
    if (!(i instanceof H.SpaceNode)) if (i instanceof H.MathNode)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof H.TextNode ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
          break;
        }
        default:
          r = !1;
      }
    else
      r = !1;
  }
  if (r) {
    var s = t.map((h) => h.toText()).join("");
    t = [new H.TextNode(s)];
  }
  var o = new H.MathNode("mi", t);
  o.setAttribute("mathvariant", "normal");
  var d = new H.MathNode("mo", [Lt("⁡", "text")]);
  return n.parentIsSupSub ? new H.MathNode("mrow", [o, d]) : H.newDocumentFragment([o, d]);
};
G({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: Ze(a),
      alwaysHandleSupSub: r === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: jo,
  mathmlBuilder: d4
});
g("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
_n({
  type: "ordgroup",
  htmlBuilder(n, e) {
    return n.semisimple ? M.makeFragment(lt(n.body, e, !1)) : M.makeSpan(["mord"], lt(n.body, e, !0), e);
  },
  mathmlBuilder(n, e) {
    return H0(n.body, e, !0);
  }
});
G({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder(n, e) {
    var t = Se(n.body, e.havingCrampedStyle()), r = M.makeLineSpan("overline-line", e), a = e.fontMetrics().defaultRuleThickness, i = M.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: a
      }]
    }, e);
    return M.makeSpan(["mord", "overline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mo", [new H.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new H.MathNode("mover", [Be(n.body, e), t]);
    return r.setAttribute("accent", "true"), r;
  }
});
G({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: Ze(r)
    };
  },
  htmlBuilder: (n, e) => {
    var t = lt(n.body, e.withPhantom(), !1);
    return M.makeFragment(t);
  },
  mathmlBuilder: (n, e) => {
    var t = Ct(n.body, e);
    return new H.MathNode("mphantom", t);
  }
});
G({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = M.makeSpan([], [Se(n.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0, t.children[r].depth = 0;
    return t = M.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), M.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (n, e) => {
    var t = Ct(Ze(n.body), e), r = new H.MathNode("mphantom", t), a = new H.MathNode("mpadded", [r]);
    return a.setAttribute("height", "0px"), a.setAttribute("depth", "0px"), a;
  }
});
G({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = M.makeSpan(["inner"], [Se(n.body, e.withPhantom())]), r = M.makeSpan(["fix"], []);
    return M.makeSpan(["mord", "rlap"], [t, r], e);
  },
  mathmlBuilder: (n, e) => {
    var t = Ct(Ze(n.body), e), r = new H.MathNode("mphantom", t), a = new H.MathNode("mpadded", [r]);
    return a.setAttribute("width", "0px"), a;
  }
});
G({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = me(e[0], "size").value, a = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: r,
      body: a
    };
  },
  htmlBuilder(n, e) {
    var t = Se(n.body, e), r = Ue(n.dy, e);
    return M.makeVList({
      positionType: "shift",
      positionData: -r,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mpadded", [Be(n.body, e)]), r = n.dy.number + n.dy.unit;
    return t.setAttribute("voffset", r), t;
  }
});
G({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInArgument: !0
  },
  handler(n) {
    var {
      parser: e
    } = n;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
G({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    argTypes: ["size", "size", "size"]
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = me(e[0], "size"), l = me(e[1], "size");
    return {
      type: "rule",
      mode: r.mode,
      shift: a && me(a, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(n, e) {
    var t = M.makeSpan(["mord", "rule"], [], e), r = Ue(n.width, e), a = Ue(n.height, e), i = n.shift ? Ue(n.shift, e) : 0;
    return t.style.borderRightWidth = V(r), t.style.borderTopWidth = V(a), t.style.bottom = V(i), t.width = r, t.height = a + i, t.depth = -i, t.maxFontSize = a * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(n, e) {
    var t = Ue(n.width, e), r = Ue(n.height, e), a = n.shift ? Ue(n.shift, e) : 0, i = e.color && e.getColor() || "black", l = new H.MathNode("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", V(t)), l.setAttribute("height", V(r));
    var s = new H.MathNode("mpadded", [l]);
    return a >= 0 ? s.setAttribute("height", V(a)) : (s.setAttribute("height", V(a)), s.setAttribute("depth", V(-a))), s.setAttribute("voffset", V(a)), s;
  }
});
function Wo(n, e, t) {
  for (var r = lt(n, e, !1), a = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < r.length; i++) {
    var l = r[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(r[i].classes, e.sizingClasses(t)) : r[i].classes[l + 1] === "reset-size" + e.size && (r[i].classes[l + 1] = "reset-size" + t.size), r[i].height *= a, r[i].depth *= a;
  }
  return M.makeFragment(r);
}
var Il = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], h4 = (n, e) => {
  var t = e.havingSize(n.size);
  return Wo(n.body, t, e);
};
G({
  type: "sizing",
  names: Il,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: a.mode,
      // Figure out what size to use based on the list of functions above
      size: Il.indexOf(r) + 1,
      body: i
    };
  },
  htmlBuilder: h4,
  mathmlBuilder: (n, e) => {
    var t = e.havingSize(n.size), r = Ct(n.body, t), a = new H.MathNode("mstyle", r);
    return a.setAttribute("mathsize", V(t.sizeMultiplier)), a;
  }
});
G({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = !1, i = !1, l = t[0] && me(t[0], "ordgroup");
    if (l)
      for (var s = "", o = 0; o < l.body.length; ++o) {
        var d = l.body[o];
        if (s = d.text, s === "t")
          a = !0;
        else if (s === "b")
          i = !0;
        else {
          a = !1, i = !1;
          break;
        }
      }
    else
      a = !0, i = !0;
    var h = e[0];
    return {
      type: "smash",
      mode: r.mode,
      body: h,
      smashHeight: a,
      smashDepth: i
    };
  },
  htmlBuilder: (n, e) => {
    var t = M.makeSpan([], [Se(n.body, e)]);
    if (!n.smashHeight && !n.smashDepth)
      return t;
    if (n.smashHeight && (t.height = 0, t.children))
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0;
    if (n.smashDepth && (t.depth = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].depth = 0;
    var i = M.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return M.makeSpan(["mord"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new H.MathNode("mpadded", [Be(n.body, e)]);
    return n.smashHeight && t.setAttribute("height", "0px"), n.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
G({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: r.mode,
      body: i,
      index: a
    };
  },
  htmlBuilder(n, e) {
    var t = Se(n.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = M.wrapFragment(t, e);
    var r = e.fontMetrics(), a = r.defaultRuleThickness, i = a;
    e.style.id < re.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = a + i / 4, s = t.height + t.depth + l + a, {
      span: o,
      ruleWidth: d,
      advanceWidth: h
    } = A0.sqrtImage(s, e), f = o.height - d;
    f > t.height + t.depth + l && (l = (l + f - t.height - t.depth) / 2);
    var p = o.height - t.height - l - d;
    t.style.paddingLeft = V(h);
    var _ = M.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + p)
      }, {
        type: "elem",
        elem: o
      }, {
        type: "kern",
        size: d
      }]
    }, e);
    if (n.index) {
      var y = e.havingStyle(re.SCRIPTSCRIPT), S = Se(n.index, y, e), E = 0.6 * (_.height - _.depth), A = M.makeVList({
        positionType: "shift",
        positionData: -E,
        children: [{
          type: "elem",
          elem: S
        }]
      }, e), b = M.makeSpan(["root"], [A]);
      return M.makeSpan(["mord", "sqrt"], [b, _], e);
    } else
      return M.makeSpan(["mord", "sqrt"], [_], e);
  },
  mathmlBuilder(n, e) {
    var {
      body: t,
      index: r
    } = n;
    return r ? new H.MathNode("mroot", [Be(t, e), Be(r, e)]) : new H.MathNode("msqrt", [Be(t, e)]);
  }
});
var Ll = {
  display: re.DISPLAY,
  text: re.TEXT,
  script: re.SCRIPT,
  scriptscript: re.SCRIPTSCRIPT
};
G({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!0, t), l = r.slice(1, r.length - 5);
    return {
      type: "styling",
      mode: a.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(n, e) {
    var t = Ll[n.style], r = e.havingStyle(t).withFont("");
    return Wo(n.body, r, e);
  },
  mathmlBuilder(n, e) {
    var t = Ll[n.style], r = e.havingStyle(t), a = Ct(n.body, r), i = new H.MathNode("mstyle", a), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, s = l[n.style];
    return i.setAttribute("scriptlevel", s[0]), i.setAttribute("displaystyle", s[1]), i;
  }
});
var m4 = function(e, t) {
  var r = e.base;
  if (r)
    if (r.type === "op") {
      var a = r.limits && (t.style.size === re.DISPLAY.size || r.alwaysHandleSupSub);
      return a ? Un : null;
    } else if (r.type === "operatorname") {
      var i = r.alwaysHandleSupSub && (t.style.size === re.DISPLAY.size || r.limits);
      return i ? jo : null;
    } else {
      if (r.type === "accent")
        return Fe.isCharacterBox(r.base) ? Ri : null;
      if (r.type === "horizBrace") {
        var l = !e.sub;
        return l === r.isOver ? Uo : null;
      } else
        return null;
    }
  else return null;
};
_n({
  type: "supsub",
  htmlBuilder(n, e) {
    var t = m4(n, e);
    if (t)
      return t(n, e);
    var {
      base: r,
      sup: a,
      sub: i
    } = n, l = Se(r, e), s, o, d = e.fontMetrics(), h = 0, f = 0, p = r && Fe.isCharacterBox(r);
    if (a) {
      var _ = e.havingStyle(e.style.sup());
      s = Se(a, _, e), p || (h = l.height - _.fontMetrics().supDrop * _.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var y = e.havingStyle(e.style.sub());
      o = Se(i, y, e), p || (f = l.depth + y.fontMetrics().subDrop * y.sizeMultiplier / e.sizeMultiplier);
    }
    var S;
    e.style === re.DISPLAY ? S = d.sup1 : e.style.cramped ? S = d.sup3 : S = d.sup2;
    var E = e.sizeMultiplier, A = V(0.5 / d.ptPerEm / E), b = null;
    if (o) {
      var v = n.base && n.base.type === "op" && n.base.name && (n.base.name === "\\oiint" || n.base.name === "\\oiiint");
      (l instanceof m0 || v) && (b = V(-l.italic));
    }
    var w;
    if (s && o) {
      h = Math.max(h, S, s.depth + 0.25 * d.xHeight), f = Math.max(f, d.sub2);
      var C = d.defaultRuleThickness, T = 4 * C;
      if (h - s.depth - (o.height - f) < T) {
        f = T - (h - s.depth) + o.height;
        var B = 0.8 * d.xHeight - (h - s.depth);
        B > 0 && (h += B, f -= B);
      }
      var $ = [{
        type: "elem",
        elem: o,
        shift: f,
        marginRight: A,
        marginLeft: b
      }, {
        type: "elem",
        elem: s,
        shift: -h,
        marginRight: A
      }];
      w = M.makeVList({
        positionType: "individualShift",
        children: $
      }, e);
    } else if (o) {
      f = Math.max(f, d.sub1, o.height - 0.8 * d.xHeight);
      var z = [{
        type: "elem",
        elem: o,
        marginLeft: b,
        marginRight: A
      }];
      w = M.makeVList({
        positionType: "shift",
        positionData: f,
        children: z
      }, e);
    } else if (s)
      h = Math.max(h, S, s.depth + 0.25 * d.xHeight), w = M.makeVList({
        positionType: "shift",
        positionData: -h,
        children: [{
          type: "elem",
          elem: s,
          marginRight: A
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var N = oi(l, "right") || "mord";
    return M.makeSpan([N], [l, M.makeSpan(["msupsub"], [w])], e);
  },
  mathmlBuilder(n, e) {
    var t = !1, r, a;
    n.base && n.base.type === "horizBrace" && (a = !!n.sup, a === n.base.isOver && (t = !0, r = n.base.isOver)), n.base && (n.base.type === "op" || n.base.type === "operatorname") && (n.base.parentIsSupSub = !0);
    var i = [Be(n.base, e)];
    n.sub && i.push(Be(n.sub, e)), n.sup && i.push(Be(n.sup, e));
    var l;
    if (t)
      l = r ? "mover" : "munder";
    else if (n.sub)
      if (n.sup) {
        var d = n.base;
        d && d.type === "op" && d.limits && e.style === re.DISPLAY || d && d.type === "operatorname" && d.alwaysHandleSupSub && (e.style === re.DISPLAY || d.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var o = n.base;
        o && o.type === "op" && o.limits && (e.style === re.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || e.style === re.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var s = n.base;
      s && s.type === "op" && s.limits && (e.style === re.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || e.style === re.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new H.MathNode(l, i);
  }
});
_n({
  type: "atom",
  htmlBuilder(n, e) {
    return M.mathsym(n.text, n.mode, e, ["m" + n.family]);
  },
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mo", [Lt(n.text, n.mode)]);
    if (n.family === "bin") {
      var r = qi(n, e);
      r === "bold-italic" && t.setAttribute("mathvariant", r);
    } else n.family === "punct" ? t.setAttribute("separator", "true") : (n.family === "open" || n.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var Yo = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
_n({
  type: "mathord",
  htmlBuilder(n, e) {
    return M.makeOrd(n, e, "mathord");
  },
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mi", [Lt(n.text, n.mode, e)]), r = qi(n, e) || "italic";
    return r !== Yo[t.type] && t.setAttribute("mathvariant", r), t;
  }
});
_n({
  type: "textord",
  htmlBuilder(n, e) {
    return M.makeOrd(n, e, "textord");
  },
  mathmlBuilder(n, e) {
    var t = Lt(n.text, n.mode, e), r = qi(n, e) || "normal", a;
    return n.mode === "text" ? a = new H.MathNode("mtext", [t]) : /[0-9]/.test(n.text) ? a = new H.MathNode("mn", [t]) : n.text === "\\prime" ? a = new H.MathNode("mo", [t]) : a = new H.MathNode("mi", [t]), r !== Yo[a.type] && a.setAttribute("mathvariant", r), a;
  }
});
var Pa = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, $a = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
_n({
  type: "spacing",
  htmlBuilder(n, e) {
    if ($a.hasOwnProperty(n.text)) {
      var t = $a[n.text].className || "";
      if (n.mode === "text") {
        var r = M.makeOrd(n, e, "textord");
        return r.classes.push(t), r;
      } else
        return M.makeSpan(["mspace", t], [M.mathsym(n.text, n.mode, e)], e);
    } else {
      if (Pa.hasOwnProperty(n.text))
        return M.makeSpan(["mspace", Pa[n.text]], [], e);
      throw new J('Unknown type of space "' + n.text + '"');
    }
  },
  mathmlBuilder(n, e) {
    var t;
    if ($a.hasOwnProperty(n.text))
      t = new H.MathNode("mtext", [new H.TextNode(" ")]);
    else {
      if (Pa.hasOwnProperty(n.text))
        return new H.MathNode("mspace");
      throw new J('Unknown type of space "' + n.text + '"');
    }
    return t;
  }
});
var Ol = () => {
  var n = new H.MathNode("mtd", []);
  return n.setAttribute("width", "50%"), n;
};
_n({
  type: "tag",
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mtable", [new H.MathNode("mtr", [Ol(), new H.MathNode("mtd", [H0(n.body, e)]), Ol(), new H.MathNode("mtd", [H0(n.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var Pl = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, $l = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, f4 = {
  "\\textit": "textit",
  "\\textup": "textup"
}, Hl = (n, e) => {
  var t = n.font;
  if (t) {
    if (Pl[t])
      return e.withTextFontFamily(Pl[t]);
    if ($l[t])
      return e.withTextFontWeight($l[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(f4[t]);
};
G({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: Ze(a),
      font: r
    };
  },
  htmlBuilder(n, e) {
    var t = Hl(n, e), r = lt(n.body, t, !0);
    return M.makeSpan(["mord", "text"], r, t);
  },
  mathmlBuilder(n, e) {
    var t = Hl(n, e);
    return H0(n.body, t);
  }
});
G({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = Se(n.body, e), r = M.makeLineSpan("underline-line", e), a = e.fontMetrics().defaultRuleThickness, i = M.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return M.makeSpan(["mord", "underline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new H.MathNode("mo", [new H.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new H.MathNode("munder", [Be(n.body, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
G({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = Se(n.body, e), r = e.fontMetrics().axisHeight, a = 0.5 * (t.height - r - (t.depth + r));
    return M.makeVList({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    return new H.MathNode("mpadded", [Be(n.body, e)], ["vcenter"]);
  }
});
G({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    throw new J("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(n, e) {
    for (var t = Ul(n), r = [], a = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), r.push(M.makeSymbol(l, "Typewriter-Regular", n.mode, a, ["mord", "texttt"]));
    }
    return M.makeSpan(["mord", "text"].concat(a.sizingClasses(e)), M.tryCombineChars(r), a);
  },
  mathmlBuilder(n, e) {
    var t = new H.TextNode(Ul(n)), r = new H.MathNode("mtext", [t]);
    return r.setAttribute("mathvariant", "monospace"), r;
  }
});
var Ul = (n) => n.body.replace(/ /g, n.star ? "␣" : " "), p4 = yo;
g("\\noexpand", function(n) {
  var e = n.popToken();
  return n.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
g("\\expandafter", function(n) {
  var e = n.popToken();
  return n.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
g("\\@firstoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
g("\\@secondoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
g("\\@ifnextchar", function(n) {
  var e = n.consumeArgs(3);
  n.consumeSpaces();
  var t = n.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
g("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
g("\\TextOrMath", function(n) {
  var e = n.consumeArgs(2);
  return n.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var Vl = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
g("\\char", function(n) {
  var e = n.popToken(), t, r = "";
  if (e.text === "'")
    t = 8, e = n.popToken();
  else if (e.text === '"')
    t = 16, e = n.popToken();
  else if (e.text === "`")
    if (e = n.popToken(), e.text[0] === "\\")
      r = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new J("\\char` missing argument");
      r = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (r = Vl[e.text], r == null || r >= t)
      throw new J("Invalid base-" + t + " digit " + e.text);
    for (var a; (a = Vl[n.future().text]) != null && a < t; )
      r *= t, r += a, n.popToken();
  }
  return "\\@char{" + r + "}";
});
var Vi = (n, e, t, r) => {
  var a = n.consumeArg().tokens;
  if (a.length !== 1)
    throw new J("\\newcommand's first argument must be a macro name");
  var i = a[0].text, l = n.isDefined(i);
  if (l && !e)
    throw new J("\\newcommand{" + i + "} attempting to redefine " + (i + "; use \\renewcommand"));
  if (!l && !t)
    throw new J("\\renewcommand{" + i + "} when command " + i + " does not yet exist; use \\newcommand");
  var s = 0;
  if (a = n.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
    for (var o = "", d = n.expandNextToken(); d.text !== "]" && d.text !== "EOF"; )
      o += d.text, d = n.expandNextToken();
    if (!o.match(/^\s*[0-9]+\s*$/))
      throw new J("Invalid number of arguments: " + o);
    s = parseInt(o), a = n.consumeArg().tokens;
  }
  return l && r || n.macros.set(i, {
    tokens: a,
    numArgs: s
  }), "";
};
g("\\newcommand", (n) => Vi(n, !1, !0, !1));
g("\\renewcommand", (n) => Vi(n, !0, !1, !1));
g("\\providecommand", (n) => Vi(n, !0, !0, !0));
g("\\message", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
g("\\errmessage", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
g("\\show", (n) => {
  var e = n.popToken(), t = e.text;
  return console.log(e, n.macros.get(t), p4[t], Ke.math[t], Ke.text[t]), "";
});
g("\\bgroup", "{");
g("\\egroup", "}");
g("~", "\\nobreakspace");
g("\\lq", "`");
g("\\rq", "'");
g("\\aa", "\\r a");
g("\\AA", "\\r A");
g("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
g("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
g("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
g("ℬ", "\\mathscr{B}");
g("ℰ", "\\mathscr{E}");
g("ℱ", "\\mathscr{F}");
g("ℋ", "\\mathscr{H}");
g("ℐ", "\\mathscr{I}");
g("ℒ", "\\mathscr{L}");
g("ℳ", "\\mathscr{M}");
g("ℛ", "\\mathscr{R}");
g("ℭ", "\\mathfrak{C}");
g("ℌ", "\\mathfrak{H}");
g("ℨ", "\\mathfrak{Z}");
g("\\Bbbk", "\\Bbb{k}");
g("·", "\\cdotp");
g("\\llap", "\\mathllap{\\textrm{#1}}");
g("\\rlap", "\\mathrlap{\\textrm{#1}}");
g("\\clap", "\\mathclap{\\textrm{#1}}");
g("\\mathstrut", "\\vphantom{(}");
g("\\underbar", "\\underline{\\text{#1}}");
g("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
g("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
g("\\ne", "\\neq");
g("≠", "\\neq");
g("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
g("∉", "\\notin");
g("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
g("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
g("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
g("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
g("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
g("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
g("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
g("⟂", "\\perp");
g("‼", "\\mathclose{!\\mkern-0.8mu!}");
g("∌", "\\notni");
g("⌜", "\\ulcorner");
g("⌝", "\\urcorner");
g("⌞", "\\llcorner");
g("⌟", "\\lrcorner");
g("©", "\\copyright");
g("®", "\\textregistered");
g("️", "\\textregistered");
g("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
g("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
g("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
g("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
g("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
g("⋮", "\\vdots");
g("\\varGamma", "\\mathit{\\Gamma}");
g("\\varDelta", "\\mathit{\\Delta}");
g("\\varTheta", "\\mathit{\\Theta}");
g("\\varLambda", "\\mathit{\\Lambda}");
g("\\varXi", "\\mathit{\\Xi}");
g("\\varPi", "\\mathit{\\Pi}");
g("\\varSigma", "\\mathit{\\Sigma}");
g("\\varUpsilon", "\\mathit{\\Upsilon}");
g("\\varPhi", "\\mathit{\\Phi}");
g("\\varPsi", "\\mathit{\\Psi}");
g("\\varOmega", "\\mathit{\\Omega}");
g("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
g("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
g("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
g("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
g("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
g("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
g("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
g("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var Gl = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
g("\\dots", function(n) {
  var e = "\\dotso", t = n.expandAfterFuture().text;
  return t in Gl ? e = Gl[t] : (t.slice(0, 4) === "\\not" || t in Ke.math && ["bin", "rel"].includes(Ke.math[t].group)) && (e = "\\dotsb"), e;
});
var Gi = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
g("\\dotso", function(n) {
  var e = n.future().text;
  return e in Gi ? "\\ldots\\," : "\\ldots";
});
g("\\dotsc", function(n) {
  var e = n.future().text;
  return e in Gi && e !== "," ? "\\ldots\\," : "\\ldots";
});
g("\\cdots", function(n) {
  var e = n.future().text;
  return e in Gi ? "\\@cdots\\," : "\\@cdots";
});
g("\\dotsb", "\\cdots");
g("\\dotsm", "\\cdots");
g("\\dotsi", "\\!\\cdots");
g("\\dotsx", "\\ldots\\,");
g("\\DOTSI", "\\relax");
g("\\DOTSB", "\\relax");
g("\\DOTSX", "\\relax");
g("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
g("\\,", "\\tmspace+{3mu}{.1667em}");
g("\\thinspace", "\\,");
g("\\>", "\\mskip{4mu}");
g("\\:", "\\tmspace+{4mu}{.2222em}");
g("\\medspace", "\\:");
g("\\;", "\\tmspace+{5mu}{.2777em}");
g("\\thickspace", "\\;");
g("\\!", "\\tmspace-{3mu}{.1667em}");
g("\\negthinspace", "\\!");
g("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
g("\\negthickspace", "\\tmspace-{5mu}{.277em}");
g("\\enspace", "\\kern.5em ");
g("\\enskip", "\\hskip.5em\\relax");
g("\\quad", "\\hskip1em\\relax");
g("\\qquad", "\\hskip2em\\relax");
g("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
g("\\tag@paren", "\\tag@literal{({#1})}");
g("\\tag@literal", (n) => {
  if (n.macros.get("\\df@tag"))
    throw new J("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
g("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
g("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
g("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
g("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
g("\\newline", "\\\\\\relax");
g("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var Xo = V(D0["Main-Regular"][84][1] - 0.7 * D0["Main-Regular"][65][1]);
g("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + Xo + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
g("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + Xo + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
g("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
g("\\@hspace", "\\hskip #1\\relax");
g("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
g("\\ordinarycolon", ":");
g("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
g("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
g("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
g("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
g("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
g("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
g("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
g("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
g("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
g("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
g("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
g("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
g("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
g("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
g("∷", "\\dblcolon");
g("∹", "\\eqcolon");
g("≔", "\\coloneqq");
g("≕", "\\eqqcolon");
g("⩴", "\\Coloneqq");
g("\\ratio", "\\vcentcolon");
g("\\coloncolon", "\\dblcolon");
g("\\colonequals", "\\coloneqq");
g("\\coloncolonequals", "\\Coloneqq");
g("\\equalscolon", "\\eqqcolon");
g("\\equalscoloncolon", "\\Eqqcolon");
g("\\colonminus", "\\coloneq");
g("\\coloncolonminus", "\\Coloneq");
g("\\minuscolon", "\\eqcolon");
g("\\minuscoloncolon", "\\Eqcolon");
g("\\coloncolonapprox", "\\Colonapprox");
g("\\coloncolonsim", "\\Colonsim");
g("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
g("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
g("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
g("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
g("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
g("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
g("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
g("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
g("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
g("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
g("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
g("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
g("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
g("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
g("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
g("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
g("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
g("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
g("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
g("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
g("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
g("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
g("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
g("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
g("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
g("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
g("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
g("\\imath", "\\html@mathml{\\@imath}{ı}");
g("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
g("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
g("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
g("⟦", "\\llbracket");
g("⟧", "\\rrbracket");
g("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
g("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
g("⦃", "\\lBrace");
g("⦄", "\\rBrace");
g("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
g("⦵", "\\minuso");
g("\\darr", "\\downarrow");
g("\\dArr", "\\Downarrow");
g("\\Darr", "\\Downarrow");
g("\\lang", "\\langle");
g("\\rang", "\\rangle");
g("\\uarr", "\\uparrow");
g("\\uArr", "\\Uparrow");
g("\\Uarr", "\\Uparrow");
g("\\N", "\\mathbb{N}");
g("\\R", "\\mathbb{R}");
g("\\Z", "\\mathbb{Z}");
g("\\alef", "\\aleph");
g("\\alefsym", "\\aleph");
g("\\Alpha", "\\mathrm{A}");
g("\\Beta", "\\mathrm{B}");
g("\\bull", "\\bullet");
g("\\Chi", "\\mathrm{X}");
g("\\clubs", "\\clubsuit");
g("\\cnums", "\\mathbb{C}");
g("\\Complex", "\\mathbb{C}");
g("\\Dagger", "\\ddagger");
g("\\diamonds", "\\diamondsuit");
g("\\empty", "\\emptyset");
g("\\Epsilon", "\\mathrm{E}");
g("\\Eta", "\\mathrm{H}");
g("\\exist", "\\exists");
g("\\harr", "\\leftrightarrow");
g("\\hArr", "\\Leftrightarrow");
g("\\Harr", "\\Leftrightarrow");
g("\\hearts", "\\heartsuit");
g("\\image", "\\Im");
g("\\infin", "\\infty");
g("\\Iota", "\\mathrm{I}");
g("\\isin", "\\in");
g("\\Kappa", "\\mathrm{K}");
g("\\larr", "\\leftarrow");
g("\\lArr", "\\Leftarrow");
g("\\Larr", "\\Leftarrow");
g("\\lrarr", "\\leftrightarrow");
g("\\lrArr", "\\Leftrightarrow");
g("\\Lrarr", "\\Leftrightarrow");
g("\\Mu", "\\mathrm{M}");
g("\\natnums", "\\mathbb{N}");
g("\\Nu", "\\mathrm{N}");
g("\\Omicron", "\\mathrm{O}");
g("\\plusmn", "\\pm");
g("\\rarr", "\\rightarrow");
g("\\rArr", "\\Rightarrow");
g("\\Rarr", "\\Rightarrow");
g("\\real", "\\Re");
g("\\reals", "\\mathbb{R}");
g("\\Reals", "\\mathbb{R}");
g("\\Rho", "\\mathrm{P}");
g("\\sdot", "\\cdot");
g("\\sect", "\\S");
g("\\spades", "\\spadesuit");
g("\\sub", "\\subset");
g("\\sube", "\\subseteq");
g("\\supe", "\\supseteq");
g("\\Tau", "\\mathrm{T}");
g("\\thetasym", "\\vartheta");
g("\\weierp", "\\wp");
g("\\Zeta", "\\mathrm{Z}");
g("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
g("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
g("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
g("\\bra", "\\mathinner{\\langle{#1}|}");
g("\\ket", "\\mathinner{|{#1}\\rangle}");
g("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
g("\\Bra", "\\left\\langle#1\\right|");
g("\\Ket", "\\left|#1\\right\\rangle");
var Zo = (n) => (e) => {
  var t = e.consumeArg().tokens, r = e.consumeArg().tokens, a = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), s = e.macros.get("\\|");
  e.macros.beginGroup();
  var o = (f) => (p) => {
    n && (p.macros.set("|", l), a.length && p.macros.set("\\|", s));
    var _ = f;
    if (!f && a.length) {
      var y = p.future();
      y.text === "|" && (p.popToken(), _ = !0);
    }
    return {
      tokens: _ ? a : r,
      numArgs: 0
    };
  };
  e.macros.set("|", o(!1)), a.length && e.macros.set("\\|", o(!0));
  var d = e.consumeArg().tokens, h = e.expandTokens([
    ...i,
    ...d,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: h.reverse(),
    numArgs: 0
  };
};
g("\\bra@ket", Zo(!1));
g("\\bra@set", Zo(!0));
g("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
g("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
g("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
g("\\angln", "{\\angl n}");
g("\\blue", "\\textcolor{##6495ed}{#1}");
g("\\orange", "\\textcolor{##ffa500}{#1}");
g("\\pink", "\\textcolor{##ff00af}{#1}");
g("\\red", "\\textcolor{##df0030}{#1}");
g("\\green", "\\textcolor{##28ae7b}{#1}");
g("\\gray", "\\textcolor{gray}{#1}");
g("\\purple", "\\textcolor{##9d38bd}{#1}");
g("\\blueA", "\\textcolor{##ccfaff}{#1}");
g("\\blueB", "\\textcolor{##80f6ff}{#1}");
g("\\blueC", "\\textcolor{##63d9ea}{#1}");
g("\\blueD", "\\textcolor{##11accd}{#1}");
g("\\blueE", "\\textcolor{##0c7f99}{#1}");
g("\\tealA", "\\textcolor{##94fff5}{#1}");
g("\\tealB", "\\textcolor{##26edd5}{#1}");
g("\\tealC", "\\textcolor{##01d1c1}{#1}");
g("\\tealD", "\\textcolor{##01a995}{#1}");
g("\\tealE", "\\textcolor{##208170}{#1}");
g("\\greenA", "\\textcolor{##b6ffb0}{#1}");
g("\\greenB", "\\textcolor{##8af281}{#1}");
g("\\greenC", "\\textcolor{##74cf70}{#1}");
g("\\greenD", "\\textcolor{##1fab54}{#1}");
g("\\greenE", "\\textcolor{##0d923f}{#1}");
g("\\goldA", "\\textcolor{##ffd0a9}{#1}");
g("\\goldB", "\\textcolor{##ffbb71}{#1}");
g("\\goldC", "\\textcolor{##ff9c39}{#1}");
g("\\goldD", "\\textcolor{##e07d10}{#1}");
g("\\goldE", "\\textcolor{##a75a05}{#1}");
g("\\redA", "\\textcolor{##fca9a9}{#1}");
g("\\redB", "\\textcolor{##ff8482}{#1}");
g("\\redC", "\\textcolor{##f9685d}{#1}");
g("\\redD", "\\textcolor{##e84d39}{#1}");
g("\\redE", "\\textcolor{##bc2612}{#1}");
g("\\maroonA", "\\textcolor{##ffbde0}{#1}");
g("\\maroonB", "\\textcolor{##ff92c6}{#1}");
g("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
g("\\maroonD", "\\textcolor{##ca337c}{#1}");
g("\\maroonE", "\\textcolor{##9e034e}{#1}");
g("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
g("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
g("\\purpleC", "\\textcolor{##aa87ff}{#1}");
g("\\purpleD", "\\textcolor{##7854ab}{#1}");
g("\\purpleE", "\\textcolor{##543b78}{#1}");
g("\\mintA", "\\textcolor{##f5f9e8}{#1}");
g("\\mintB", "\\textcolor{##edf2df}{#1}");
g("\\mintC", "\\textcolor{##e0e5cc}{#1}");
g("\\grayA", "\\textcolor{##f6f7f7}{#1}");
g("\\grayB", "\\textcolor{##f0f1f2}{#1}");
g("\\grayC", "\\textcolor{##e3e5e6}{#1}");
g("\\grayD", "\\textcolor{##d6d8da}{#1}");
g("\\grayE", "\\textcolor{##babec2}{#1}");
g("\\grayF", "\\textcolor{##888d93}{#1}");
g("\\grayG", "\\textcolor{##626569}{#1}");
g("\\grayH", "\\textcolor{##3b3e40}{#1}");
g("\\grayI", "\\textcolor{##21242c}{#1}");
g("\\kaBlue", "\\textcolor{##314453}{#1}");
g("\\kaGreen", "\\textcolor{##71B307}{#1}");
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
function ji() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let gn = ji();
function Ko(n) {
  gn = n;
}
const Qo = /[&<>"']/, _4 = new RegExp(Qo.source, "g"), Jo = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, g4 = new RegExp(Jo.source, "g"), v4 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, jl = (n) => v4[n];
function xt(n, e) {
  if (e) {
    if (Qo.test(n))
      return n.replace(_4, jl);
  } else if (Jo.test(n))
    return n.replace(g4, jl);
  return n;
}
const b4 = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function y4(n) {
  return n.replace(b4, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const w4 = /(^|[^\[])\^/g;
function Me(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const r = {
    replace: (a, i) => {
      let l = typeof i == "string" ? i : i.source;
      return l = l.replace(w4, "$1"), t = t.replace(a, l), r;
    },
    getRegex: () => new RegExp(t, e)
  };
  return r;
}
function Wl(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const ur = { exec: () => null };
function Yl(n, e) {
  const t = n.replace(/\|/g, (i, l, s) => {
    let o = !1, d = l;
    for (; --d >= 0 && s[d] === "\\"; )
      o = !o;
    return o ? "|" : " |";
  }), r = t.split(/ \|/);
  let a = 0;
  if (r[0].trim() || r.shift(), r.length > 0 && !r[r.length - 1].trim() && r.pop(), e)
    if (r.length > e)
      r.splice(e);
    else
      for (; r.length < e; )
        r.push("");
  for (; a < r.length; a++)
    r[a] = r[a].trim().replace(/\\\|/g, "|");
  return r;
}
function Nr(n, e, t) {
  const r = n.length;
  if (r === 0)
    return "";
  let a = 0;
  for (; a < r && n.charAt(r - a - 1) === e; )
    a++;
  return n.slice(0, r - a);
}
function k4(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let r = 0; r < n.length; r++)
    if (n[r] === "\\")
      r++;
    else if (n[r] === e[0])
      t++;
    else if (n[r] === e[1] && (t--, t < 0))
      return r;
  return -1;
}
function Xl(n, e, t, r) {
  const a = e.href, i = e.title ? xt(e.title) : null, l = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    r.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: a,
      title: i,
      text: l,
      tokens: r.inlineTokens(l)
    };
    return r.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: i,
    text: xt(l)
  };
}
function D4(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const r = t[1];
  return e.split(`
`).map((a) => {
    const i = a.match(/^\s+/);
    if (i === null)
      return a;
    const [l] = i;
    return l.length >= r.length ? a.slice(r.length) : a;
  }).join(`
`);
}
class aa {
  // set by the lexer
  constructor(e) {
    Ne(this, "options");
    Ne(this, "rules");
    // set by the lexer
    Ne(this, "lexer");
    this.options = e || gn;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : Nr(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], a = D4(r, t[3] || "");
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (/#$/.test(r)) {
        const a = Nr(r, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (r = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      r = Nr(r.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(r);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: r
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const a = r.length > 1, i = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = a ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = a ? r : "[*+-]");
      const l = new RegExp(`^( {0,3}${r})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", o = "", d = !1;
      for (; e; ) {
        let h = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let f = t[2].split(`
`, 1)[0].replace(/^\t+/, (A) => " ".repeat(3 * A.length)), p = e.split(`
`, 1)[0], _ = 0;
        this.options.pedantic ? (_ = 2, o = f.trimStart()) : (_ = t[2].search(/[^ ]/), _ = _ > 4 ? 1 : _, o = f.slice(_), _ += t[1].length);
        let y = !1;
        if (!f && /^ *$/.test(p) && (s += p + `
`, e = e.substring(p.length + 1), h = !0), !h) {
          const A = new RegExp(`^ {0,${Math.min(3, _ - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), b = new RegExp(`^ {0,${Math.min(3, _ - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), v = new RegExp(`^ {0,${Math.min(3, _ - 1)}}(?:\`\`\`|~~~)`), w = new RegExp(`^ {0,${Math.min(3, _ - 1)}}#`);
          for (; e; ) {
            const C = e.split(`
`, 1)[0];
            if (p = C, this.options.pedantic && (p = p.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), v.test(p) || w.test(p) || A.test(p) || b.test(e))
              break;
            if (p.search(/[^ ]/) >= _ || !p.trim())
              o += `
` + p.slice(_);
            else {
              if (y || f.search(/[^ ]/) >= 4 || v.test(f) || w.test(f) || b.test(f))
                break;
              o += `
` + p;
            }
            !y && !p.trim() && (y = !0), s += C + `
`, e = e.substring(C.length + 1), f = p.slice(_);
          }
        }
        i.loose || (d ? i.loose = !0 : /\n *\n *$/.test(s) && (d = !0));
        let S = null, E;
        this.options.gfm && (S = /^\[[ xX]\] /.exec(o), S && (E = S[0] !== "[ ] ", o = o.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: s,
          task: !!S,
          checked: E,
          loose: !1,
          text: o,
          tokens: []
        }), i.raw += s;
      }
      i.items[i.items.length - 1].raw = s.trimEnd(), i.items[i.items.length - 1].text = o.trimEnd(), i.raw = i.raw.trimEnd();
      for (let h = 0; h < i.items.length; h++)
        if (this.lexer.state.top = !1, i.items[h].tokens = this.lexer.blockTokens(i.items[h].text, []), !i.loose) {
          const f = i.items[h].tokens.filter((_) => _.type === "space"), p = f.length > 0 && f.some((_) => /\n.*\n/.test(_.raw));
          i.loose = p;
        }
      if (i.loose)
        for (let h = 0; h < i.items.length; h++)
          i.items[h].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: a,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const r = Yl(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === a.length) {
      for (const s of a)
        /^ *-+: *$/.test(s) ? l.align.push("right") : /^ *:-+: *$/.test(s) ? l.align.push("center") : /^ *:-+ *$/.test(s) ? l.align.push("left") : l.align.push(null);
      for (const s of r)
        l.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of i)
        l.rows.push(Yl(s, l.header.length).map((o) => ({
          text: o,
          tokens: this.lexer.inline(o)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: xt(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && /^</.test(r)) {
        if (!/>$/.test(r))
          return;
        const l = Nr(r.slice(0, -1), "\\");
        if ((r.length - l.length) % 2 === 0)
          return;
      } else {
        const l = k4(t[2], "()");
        if (l > -1) {
          const o = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, o).trim(), t[3] = "";
        }
      }
      let a = t[2], i = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], i = l[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(r) ? a = a.slice(1) : a = a.slice(1, -1)), Xl(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const a = (r[2] || r[1]).replace(/\s+/g, " "), i = t[a.toLowerCase()];
      if (!i) {
        const l = r[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return Xl(r, i, r[0], this.lexer);
    }
  }
  emStrong(e, t, r = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && r.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const l = [...a[0]].length - 1;
      let s, o, d = l, h = 0;
      const f = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (f.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = f.exec(t)) != null; ) {
        if (s = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !s)
          continue;
        if (o = [...s].length, a[3] || a[4]) {
          d += o;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + o) % 3)) {
          h += o;
          continue;
        }
        if (d -= o, d > 0)
          continue;
        o = Math.min(o, o + d + h);
        const p = [...a[0]][0].length, _ = e.slice(0, l + a.index + p + o);
        if (Math.min(l, o) % 2) {
          const S = _.slice(1, -1);
          return {
            type: "em",
            raw: _,
            text: S,
            tokens: this.lexer.inlineTokens(S)
          };
        }
        const y = _.slice(2, -2);
        return {
          type: "strong",
          raw: _,
          text: y,
          tokens: this.lexer.inlineTokens(y)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(r), i = /^ /.test(r) && / $/.test(r);
      return a && i && (r = r.substring(1, r.length - 1)), r = xt(r, !0), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, a;
      return t[2] === "@" ? (r = xt(t[1]), a = "mailto:" + r) : (r = xt(t[1]), a = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: a,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, i;
      if (t[2] === "@")
        a = xt(t[0]), i = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (l !== t[0]);
        a = xt(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: i,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let r;
      return this.lexer.state.inRawBlock ? r = t[0] : r = xt(t[0]), {
        type: "text",
        raw: t[0],
        text: r
      };
    }
  }
}
const S4 = /^(?: *(?:\n|$))+/, A4 = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, x4 = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, yr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, F4 = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, eu = /(?:[*+-]|\d{1,9}[.)])/, tu = Me(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, eu).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Wi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, E4 = /^[^\n]+/, Yi = /(?!\s*\])(?:\\.|[^\[\]\\])+/, C4 = Me(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Yi).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), T4 = Me(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, eu).getRegex(), ba = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Xi = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, M4 = Me("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Xi).replace("tag", ba).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), nu = Me(Wi).replace("hr", yr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ba).getRegex(), z4 = Me(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", nu).getRegex(), Zi = {
  blockquote: z4,
  code: A4,
  def: C4,
  fences: x4,
  heading: F4,
  hr: yr,
  html: M4,
  lheading: tu,
  list: T4,
  newline: S4,
  paragraph: nu,
  table: ur,
  text: E4
}, Zl = Me("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", yr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ba).getRegex(), B4 = {
  ...Zi,
  table: Zl,
  paragraph: Me(Wi).replace("hr", yr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Zl).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ba).getRegex()
}, q4 = {
  ...Zi,
  html: Me(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Xi).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: ur,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Me(Wi).replace("hr", yr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", tu).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, ru = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, N4 = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, au = /^( {2,}|\\)\n(?!\s*$)/, R4 = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, wr = "\\p{P}\\p{S}", I4 = Me(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, wr).getRegex(), L4 = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, O4 = Me(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, wr).getRegex(), P4 = Me("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, wr).getRegex(), $4 = Me("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, wr).getRegex(), H4 = Me(/\\([punct])/, "gu").replace(/punct/g, wr).getRegex(), U4 = Me(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), V4 = Me(Xi).replace("(?:-->|$)", "-->").getRegex(), G4 = Me("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", V4).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ia = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, j4 = Me(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", ia).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), iu = Me(/^!?\[(label)\]\[(ref)\]/).replace("label", ia).replace("ref", Yi).getRegex(), lu = Me(/^!?\[(ref)\](?:\[\])?/).replace("ref", Yi).getRegex(), W4 = Me("reflink|nolink(?!\\()", "g").replace("reflink", iu).replace("nolink", lu).getRegex(), Ki = {
  _backpedal: ur,
  // only used for GFM url
  anyPunctuation: H4,
  autolink: U4,
  blockSkip: L4,
  br: au,
  code: N4,
  del: ur,
  emStrongLDelim: O4,
  emStrongRDelimAst: P4,
  emStrongRDelimUnd: $4,
  escape: ru,
  link: j4,
  nolink: lu,
  punctuation: I4,
  reflink: iu,
  reflinkSearch: W4,
  tag: G4,
  text: R4,
  url: ur
}, Y4 = {
  ...Ki,
  link: Me(/^!?\[(label)\]\((.*?)\)/).replace("label", ia).getRegex(),
  reflink: Me(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ia).getRegex()
}, di = {
  ...Ki,
  escape: Me(ru).replace("])", "~|])").getRegex(),
  url: Me(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, X4 = {
  ...di,
  br: Me(au).replace("{2,}", "*").getRegex(),
  text: Me(di.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Rr = {
  normal: Zi,
  gfm: B4,
  pedantic: q4
}, Kn = {
  normal: Ki,
  gfm: di,
  breaks: X4,
  pedantic: Y4
};
class l0 {
  constructor(e) {
    Ne(this, "tokens");
    Ne(this, "options");
    Ne(this, "state");
    Ne(this, "tokenizer");
    Ne(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || gn, this.options.tokenizer = this.options.tokenizer || new aa(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Rr.normal,
      inline: Kn.normal
    };
    this.options.pedantic ? (t.block = Rr.pedantic, t.inline = Kn.pedantic) : this.options.gfm && (t.block = Rr.gfm, this.options.breaks ? t.inline = Kn.breaks : t.inline = Kn.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Rr,
      inline: Kn
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new l0(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new l0(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const r = this.inlineQueue[t];
      this.inlineTokens(r.src, r.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, o, d) => o + "    ".repeat(d.length));
    let r, a, i, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (r = s.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.space(e)) {
          e = e.substring(r.raw.length), r.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(r);
          continue;
        }
        if (r = this.tokenizer.code(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.fences(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.heading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.hr(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.blockquote(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.list(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.html(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.def(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = {
            href: r.href,
            title: r.title
          });
          continue;
        }
        if (r = this.tokenizer.table(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.lheading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const o = e.slice(1);
          let d;
          this.options.extensions.startBlock.forEach((h) => {
            d = h.call({ lexer: this }, o), typeof d == "number" && d >= 0 && (s = Math.min(s, d));
          }), s < 1 / 0 && s >= 0 && (i = e.substring(0, s + 1));
        }
        if (this.state.top && (r = this.tokenizer.paragraph(i))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r), l = i.length !== e.length, e = e.substring(r.raw.length);
          continue;
        }
        if (r = this.tokenizer.text(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let r, a, i, l = e, s, o, d;
    if (this.tokens.links) {
      const h = Object.keys(this.tokens.links);
      if (h.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          h.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, s.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (o || (d = ""), o = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((h) => (r = h.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.escape(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.tag(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.link(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.emStrong(e, l, d)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.codespan(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.br(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.del(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.autolink(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (!this.state.inLink && (r = this.tokenizer.url(e))) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let h = 1 / 0;
          const f = e.slice(1);
          let p;
          this.options.extensions.startInline.forEach((_) => {
            p = _.call({ lexer: this }, f), typeof p == "number" && p >= 0 && (h = Math.min(h, p));
          }), h < 1 / 0 && h >= 0 && (i = e.substring(0, h + 1));
        }
        if (r = this.tokenizer.inlineText(i)) {
          e = e.substring(r.raw.length), r.raw.slice(-1) !== "_" && (d = r.raw.slice(-1)), o = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (e) {
          const h = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(h);
            break;
          } else
            throw new Error(h);
        }
      }
    return t;
  }
}
class la {
  constructor(e) {
    Ne(this, "options");
    this.options = e || gn;
  }
  code(e, t, r) {
    var i;
    const a = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + xt(a) + '">' + (r ? e : xt(e, !0)) + `</code></pre>
` : "<pre><code>" + (r ? e : xt(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, r) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, r) {
    const a = t ? "ol" : "ul", i = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + a + i + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, r) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const r = t.header ? "th" : "td";
    return (t.align ? `<${r} align="${t.align}">` : `<${r}>`) + e + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, r) {
    const a = Wl(e);
    if (a === null)
      return r;
    e = a;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + r + "</a>", i;
  }
  image(e, t, r) {
    const a = Wl(e);
    if (a === null)
      return r;
    e = a;
    let i = `<img src="${e}" alt="${r}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class Qi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, r) {
    return "" + r;
  }
  image(e, t, r) {
    return "" + r;
  }
  br() {
    return "";
  }
}
class s0 {
  constructor(e) {
    Ne(this, "options");
    Ne(this, "renderer");
    Ne(this, "textRenderer");
    this.options = e || gn, this.options.renderer = this.options.renderer || new la(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Qi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new s0(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new s0(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = i, s = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          r += s || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          r += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = i;
          r += this.renderer.heading(this.parseInline(l.tokens), l.depth, y4(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = i;
          r += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = i;
          let s = "", o = "";
          for (let h = 0; h < l.header.length; h++)
            o += this.renderer.tablecell(this.parseInline(l.header[h].tokens), { header: !0, align: l.align[h] });
          s += this.renderer.tablerow(o);
          let d = "";
          for (let h = 0; h < l.rows.length; h++) {
            const f = l.rows[h];
            o = "";
            for (let p = 0; p < f.length; p++)
              o += this.renderer.tablecell(this.parseInline(f[p].tokens), { header: !1, align: l.align[p] });
            d += this.renderer.tablerow(o);
          }
          r += this.renderer.table(s, d);
          continue;
        }
        case "blockquote": {
          const l = i, s = this.parse(l.tokens);
          r += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const l = i, s = l.ordered, o = l.start, d = l.loose;
          let h = "";
          for (let f = 0; f < l.items.length; f++) {
            const p = l.items[f], _ = p.checked, y = p.task;
            let S = "";
            if (p.task) {
              const E = this.renderer.checkbox(!!_);
              d ? p.tokens.length > 0 && p.tokens[0].type === "paragraph" ? (p.tokens[0].text = E + " " + p.tokens[0].text, p.tokens[0].tokens && p.tokens[0].tokens.length > 0 && p.tokens[0].tokens[0].type === "text" && (p.tokens[0].tokens[0].text = E + " " + p.tokens[0].tokens[0].text)) : p.tokens.unshift({
                type: "text",
                text: E + " "
              }) : S += E + " ";
            }
            S += this.parse(p.tokens, d), h += this.renderer.listitem(S, y, !!_);
          }
          r += this.renderer.list(h, s, o);
          continue;
        }
        case "html": {
          const l = i;
          r += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = i;
          r += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = i, s = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], s += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          r += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          r += l || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        case "html": {
          const l = i;
          r += t.html(l.text);
          break;
        }
        case "link": {
          const l = i;
          r += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = i;
          r += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = i;
          r += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = i;
          r += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = i;
          r += t.codespan(l.text);
          break;
        }
        case "br": {
          r += t.br();
          break;
        }
        case "del": {
          const l = i;
          r += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
}
class cr {
  constructor(e) {
    Ne(this, "options");
    this.options = e || gn;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
Ne(cr, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var pn, hi, su;
class Z4 {
  constructor(...e) {
    Fa(this, pn);
    Ne(this, "defaults", ji());
    Ne(this, "options", this.setOptions);
    Ne(this, "parse", Er(this, pn, hi).call(this, l0.lex, s0.parse));
    Ne(this, "parseInline", Er(this, pn, hi).call(this, l0.lexInline, s0.parseInline));
    Ne(this, "Parser", s0);
    Ne(this, "Renderer", la);
    Ne(this, "TextRenderer", Qi);
    Ne(this, "Lexer", l0);
    Ne(this, "Tokenizer", aa);
    Ne(this, "Hooks", cr);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, i;
    let r = [];
    for (const l of e)
      switch (r = r.concat(t.call(this, l)), l.type) {
        case "table": {
          const s = l;
          for (const o of s.header)
            r = r.concat(this.walkTokens(o.tokens, t));
          for (const o of s.rows)
            for (const d of o)
              r = r.concat(this.walkTokens(d.tokens, t));
          break;
        }
        case "list": {
          const s = l;
          r = r.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = l;
          (i = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && i[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((o) => {
            const d = s[o].flat(1 / 0);
            r = r.concat(this.walkTokens(d, t));
          }) : s.tokens && (r = r.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const a = { ...r };
      if (a.async = this.defaults.async || a.async || !1, r.extensions && (r.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const l = t.renderers[i.name];
          l ? t.renderers[i.name] = function(...s) {
            let o = i.renderer.apply(this, s);
            return o === !1 && (o = l.apply(this, s)), o;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[i.level];
          l ? l.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), a.extensions = t), r.renderer) {
        const i = this.defaults.renderer || new la(this.defaults);
        for (const l in r.renderer) {
          if (!(l in i))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const s = l, o = r.renderer[s], d = i[s];
          i[s] = (...h) => {
            let f = o.apply(i, h);
            return f === !1 && (f = d.apply(i, h)), f || "";
          };
        }
        a.renderer = i;
      }
      if (r.tokenizer) {
        const i = this.defaults.tokenizer || new aa(this.defaults);
        for (const l in r.tokenizer) {
          if (!(l in i))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const s = l, o = r.tokenizer[s], d = i[s];
          i[s] = (...h) => {
            let f = o.apply(i, h);
            return f === !1 && (f = d.apply(i, h)), f;
          };
        }
        a.tokenizer = i;
      }
      if (r.hooks) {
        const i = this.defaults.hooks || new cr();
        for (const l in r.hooks) {
          if (!(l in i))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const s = l, o = r.hooks[s], d = i[s];
          cr.passThroughHooks.has(l) ? i[s] = (h) => {
            if (this.defaults.async)
              return Promise.resolve(o.call(i, h)).then((p) => d.call(i, p));
            const f = o.call(i, h);
            return d.call(i, f);
          } : i[s] = (...h) => {
            let f = o.apply(i, h);
            return f === !1 && (f = d.apply(i, h)), f;
          };
        }
        a.hooks = i;
      }
      if (r.walkTokens) {
        const i = this.defaults.walkTokens, l = r.walkTokens;
        a.walkTokens = function(s) {
          let o = [];
          return o.push(l.call(this, s)), i && (o = o.concat(i.call(this, s))), o;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return l0.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return s0.parse(e, t ?? this.defaults);
  }
}
pn = new WeakSet(), hi = function(e, t) {
  return (r, a) => {
    const i = { ...a }, l = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const s = Er(this, pn, su).call(this, !!l.silent, !!l.async);
    if (typeof r > "u" || r === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof r != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(r) : r).then((o) => e(o, l)).then((o) => l.hooks ? l.hooks.processAllTokens(o) : o).then((o) => l.walkTokens ? Promise.all(this.walkTokens(o, l.walkTokens)).then(() => o) : o).then((o) => t(o, l)).then((o) => l.hooks ? l.hooks.postprocess(o) : o).catch(s);
    try {
      l.hooks && (r = l.hooks.preprocess(r));
      let o = e(r, l);
      l.hooks && (o = l.hooks.processAllTokens(o)), l.walkTokens && this.walkTokens(o, l.walkTokens);
      let d = t(o, l);
      return l.hooks && (d = l.hooks.postprocess(d)), d;
    } catch (o) {
      return s(o);
    }
  };
}, su = function(e, t) {
  return (r) => {
    if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + xt(r.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(r);
    throw r;
  };
};
const fn = new Z4();
function Te(n, e) {
  return fn.parse(n, e);
}
Te.options = Te.setOptions = function(n) {
  return fn.setOptions(n), Te.defaults = fn.defaults, Ko(Te.defaults), Te;
};
Te.getDefaults = ji;
Te.defaults = gn;
Te.use = function(...n) {
  return fn.use(...n), Te.defaults = fn.defaults, Ko(Te.defaults), Te;
};
Te.walkTokens = function(n, e) {
  return fn.walkTokens(n, e);
};
Te.parseInline = fn.parseInline;
Te.Parser = s0;
Te.parser = s0.parse;
Te.Renderer = la;
Te.TextRenderer = Qi;
Te.Lexer = l0;
Te.lexer = l0.lex;
Te.Tokenizer = aa;
Te.Hooks = cr;
Te.parse = Te;
Te.options;
Te.setOptions;
Te.use;
Te.walkTokens;
Te.parseInline;
s0.parse;
l0.lex;
const K4 = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Q4 = Object.hasOwnProperty;
class ou {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const r = this;
    let a = J4(e, t === !0);
    const i = a;
    for (; Q4.call(r.occurrences, a); )
      r.occurrences[i]++, a = i + "-" + r.occurrences[i];
    return r.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function J4(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(K4, "").replace(/ /g, "-"));
}
new ou();
var Kl = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, ed = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(r) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, l = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: r.Prism && r.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: r.Prism && r.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function b(v) {
          return v instanceof o ? new o(v.type, b(v.content), v.alias) : Array.isArray(v) ? v.map(b) : v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(b) {
          return Object.prototype.toString.call(b).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(b) {
          return b.__id || Object.defineProperty(b, "__id", { value: ++i }), b.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function b(v, w) {
          w = w || {};
          var C, T;
          switch (s.util.type(v)) {
            case "Object":
              if (T = s.util.objId(v), w[T])
                return w[T];
              C = /** @type {Record<string, any>} */
              {}, w[T] = C;
              for (var B in v)
                v.hasOwnProperty(B) && (C[B] = b(v[B], w));
              return (
                /** @type {any} */
                C
              );
            case "Array":
              return T = s.util.objId(v), w[T] ? w[T] : (C = [], w[T] = C, /** @type {Array} */
              /** @type {any} */
              v.forEach(function($, z) {
                C[z] = b($, w);
              }), /** @type {any} */
              C);
            default:
              return v;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(b) {
          for (; b; ) {
            var v = a.exec(b.className);
            if (v)
              return v[1].toLowerCase();
            b = b.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(b, v) {
          b.className = b.className.replace(RegExp(a, "gi"), ""), b.classList.add("language-" + v);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (C) {
            var b = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(C.stack) || [])[1];
            if (b) {
              var v = document.getElementsByTagName("script");
              for (var w in v)
                if (v[w].src == b)
                  return v[w];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(b, v, w) {
          for (var C = "no-" + v; b; ) {
            var T = b.classList;
            if (T.contains(v))
              return !0;
            if (T.contains(C))
              return !1;
            b = b.parentElement;
          }
          return !!w;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(b, v) {
          var w = s.util.clone(s.languages[b]);
          for (var C in v)
            w[C] = v[C];
          return w;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(b, v, w, C) {
          C = C || /** @type {any} */
          s.languages;
          var T = C[b], B = {};
          for (var $ in T)
            if (T.hasOwnProperty($)) {
              if ($ == v)
                for (var z in w)
                  w.hasOwnProperty(z) && (B[z] = w[z]);
              w.hasOwnProperty($) || (B[$] = T[$]);
            }
          var N = C[b];
          return C[b] = B, s.languages.DFS(s.languages, function(j, W) {
            W === N && j != b && (this[j] = B);
          }), B;
        },
        // Traverse a language definition with Depth First Search
        DFS: function b(v, w, C, T) {
          T = T || {};
          var B = s.util.objId;
          for (var $ in v)
            if (v.hasOwnProperty($)) {
              w.call(v, $, v[$], C || $);
              var z = v[$], N = s.util.type(z);
              N === "Object" && !T[B(z)] ? (T[B(z)] = !0, b(z, w, null, T)) : N === "Array" && !T[B(z)] && (T[B(z)] = !0, b(z, w, $, T));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(b, v) {
        s.highlightAllUnder(document, b, v);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(b, v, w) {
        var C = {
          callback: w,
          container: b,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", C), C.elements = Array.prototype.slice.apply(C.container.querySelectorAll(C.selector)), s.hooks.run("before-all-elements-highlight", C);
        for (var T = 0, B; B = C.elements[T++]; )
          s.highlightElement(B, v === !0, C.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(b, v, w) {
        var C = s.util.getLanguage(b), T = s.languages[C];
        s.util.setLanguage(b, C);
        var B = b.parentElement;
        B && B.nodeName.toLowerCase() === "pre" && s.util.setLanguage(B, C);
        var $ = b.textContent, z = {
          element: b,
          language: C,
          grammar: T,
          code: $
        };
        function N(W) {
          z.highlightedCode = W, s.hooks.run("before-insert", z), z.element.innerHTML = z.highlightedCode, s.hooks.run("after-highlight", z), s.hooks.run("complete", z), w && w.call(z.element);
        }
        if (s.hooks.run("before-sanity-check", z), B = z.element.parentElement, B && B.nodeName.toLowerCase() === "pre" && !B.hasAttribute("tabindex") && B.setAttribute("tabindex", "0"), !z.code) {
          s.hooks.run("complete", z), w && w.call(z.element);
          return;
        }
        if (s.hooks.run("before-highlight", z), !z.grammar) {
          N(s.util.encode(z.code));
          return;
        }
        if (v && r.Worker) {
          var j = new Worker(s.filename);
          j.onmessage = function(W) {
            N(W.data);
          }, j.postMessage(JSON.stringify({
            language: z.language,
            code: z.code,
            immediateClose: !0
          }));
        } else
          N(s.highlight(z.code, z.grammar, z.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(b, v, w) {
        var C = {
          code: b,
          grammar: v,
          language: w
        };
        if (s.hooks.run("before-tokenize", C), !C.grammar)
          throw new Error('The language "' + C.language + '" has no grammar.');
        return C.tokens = s.tokenize(C.code, C.grammar), s.hooks.run("after-tokenize", C), o.stringify(s.util.encode(C.tokens), C.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(b, v) {
        var w = v.rest;
        if (w) {
          for (var C in w)
            v[C] = w[C];
          delete v.rest;
        }
        var T = new f();
        return p(T, T.head, b), h(b, T, v, T.head, 0), y(T);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(b, v) {
          var w = s.hooks.all;
          w[b] = w[b] || [], w[b].push(v);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(b, v) {
          var w = s.hooks.all[b];
          if (!(!w || !w.length))
            for (var C = 0, T; T = w[C++]; )
              T(v);
        }
      },
      Token: o
    };
    r.Prism = s;
    function o(b, v, w, C) {
      this.type = b, this.content = v, this.alias = w, this.length = (C || "").length | 0;
    }
    o.stringify = function b(v, w) {
      if (typeof v == "string")
        return v;
      if (Array.isArray(v)) {
        var C = "";
        return v.forEach(function(N) {
          C += b(N, w);
        }), C;
      }
      var T = {
        type: v.type,
        content: b(v.content, w),
        tag: "span",
        classes: ["token", v.type],
        attributes: {},
        language: w
      }, B = v.alias;
      B && (Array.isArray(B) ? Array.prototype.push.apply(T.classes, B) : T.classes.push(B)), s.hooks.run("wrap", T);
      var $ = "";
      for (var z in T.attributes)
        $ += " " + z + '="' + (T.attributes[z] || "").replace(/"/g, "&quot;") + '"';
      return "<" + T.tag + ' class="' + T.classes.join(" ") + '"' + $ + ">" + T.content + "</" + T.tag + ">";
    };
    function d(b, v, w, C) {
      b.lastIndex = v;
      var T = b.exec(w);
      if (T && C && T[1]) {
        var B = T[1].length;
        T.index += B, T[0] = T[0].slice(B);
      }
      return T;
    }
    function h(b, v, w, C, T, B) {
      for (var $ in w)
        if (!(!w.hasOwnProperty($) || !w[$])) {
          var z = w[$];
          z = Array.isArray(z) ? z : [z];
          for (var N = 0; N < z.length; ++N) {
            if (B && B.cause == $ + "," + N)
              return;
            var j = z[N], W = j.inside, ye = !!j.lookbehind, Z = !!j.greedy, pe = j.alias;
            if (Z && !j.pattern.global) {
              var ke = j.pattern.toString().match(/[imsuy]*$/)[0];
              j.pattern = RegExp(j.pattern.source, ke + "g");
            }
            for (var Re = j.pattern || j, se = C.next, Ae = T; se !== v.tail && !(B && Ae >= B.reach); Ae += se.value.length, se = se.next) {
              var xe = se.value;
              if (v.length > b.length)
                return;
              if (!(xe instanceof o)) {
                var ie = 1, ce;
                if (Z) {
                  if (ce = d(Re, Ae, b, ye), !ce || ce.index >= b.length)
                    break;
                  var Ie = ce.index, de = ce.index + ce[0].length, ge = Ae;
                  for (ge += se.value.length; Ie >= ge; )
                    se = se.next, ge += se.value.length;
                  if (ge -= se.value.length, Ae = ge, se.value instanceof o)
                    continue;
                  for (var P = se; P !== v.tail && (ge < de || typeof P.value == "string"); P = P.next)
                    ie++, ge += P.value.length;
                  ie--, xe = b.slice(Ae, ge), ce.index -= Ae;
                } else if (ce = d(Re, 0, xe, ye), !ce)
                  continue;
                var Ie = ce.index, Ee = ce[0], L = xe.slice(0, Ie), he = xe.slice(Ie + Ee.length), we = Ae + xe.length;
                B && we > B.reach && (B.reach = we);
                var R = se.prev;
                L && (R = p(v, R, L), Ae += L.length), _(v, R, ie);
                var te = new o($, W ? s.tokenize(Ee, W) : Ee, pe, Ee);
                if (se = p(v, R, te), he && p(v, se, he), ie > 1) {
                  var ae = {
                    cause: $ + "," + N,
                    reach: we
                  };
                  h(b, v, w, se.prev, Ae, ae), B && ae.reach > B.reach && (B.reach = ae.reach);
                }
              }
            }
          }
        }
    }
    function f() {
      var b = { value: null, prev: null, next: null }, v = { value: null, prev: b, next: null };
      b.next = v, this.head = b, this.tail = v, this.length = 0;
    }
    function p(b, v, w) {
      var C = v.next, T = { value: w, prev: v, next: C };
      return v.next = T, C.prev = T, b.length++, T;
    }
    function _(b, v, w) {
      for (var C = v.next, T = 0; T < w && C !== b.tail; T++)
        C = C.next;
      v.next = C, C.prev = v, b.length -= T;
    }
    function y(b) {
      for (var v = [], w = b.head.next; w !== b.tail; )
        v.push(w.value), w = w.next;
      return v;
    }
    if (!r.document)
      return r.addEventListener && (s.disableWorkerMessageHandler || r.addEventListener("message", function(b) {
        var v = JSON.parse(b.data), w = v.language, C = v.code, T = v.immediateClose;
        r.postMessage(s.highlight(C, s.languages[w], w)), T && r.close();
      }, !1)), s;
    var S = s.util.currentScript();
    S && (s.filename = S.src, S.hasAttribute("data-manual") && (s.manual = !0));
    function E() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var A = document.readyState;
      A === "loading" || A === "interactive" && S && S.defer ? document.addEventListener("DOMContentLoaded", E) : window.requestAnimationFrame ? window.requestAnimationFrame(E) : window.setTimeout(E, 16);
    }
    return s;
  }(e);
  n.exports && (n.exports = t), typeof Kl < "u" && (Kl.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(r) {
    r.type === "entity" && (r.attributes.title = r.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, i) {
      var l = {};
      l["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      s["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var o = {};
      o[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", o);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(r, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + r + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(r) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    r.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, r.languages.css.atrule.inside.rest = r.languages.css;
    var i = r.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var r = "Loading…", a = function(S, E) {
      return "✖ Error " + S + " while fetching file: " + E;
    }, i = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", o = "loading", d = "loaded", h = "failed", f = "pre[data-src]:not([" + s + '="' + d + '"]):not([' + s + '="' + o + '"])';
    function p(S, E, A) {
      var b = new XMLHttpRequest();
      b.open("GET", S, !0), b.onreadystatechange = function() {
        b.readyState == 4 && (b.status < 400 && b.responseText ? E(b.responseText) : b.status >= 400 ? A(a(b.status, b.statusText)) : A(i));
      }, b.send(null);
    }
    function _(S) {
      var E = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(S || "");
      if (E) {
        var A = Number(E[1]), b = E[2], v = E[3];
        return b ? v ? [A, Number(v)] : [A, void 0] : [A, A];
      }
    }
    t.hooks.add("before-highlightall", function(S) {
      S.selector += ", " + f;
    }), t.hooks.add("before-sanity-check", function(S) {
      var E = (
        /** @type {HTMLPreElement} */
        S.element
      );
      if (E.matches(f)) {
        S.code = "", E.setAttribute(s, o);
        var A = E.appendChild(document.createElement("CODE"));
        A.textContent = r;
        var b = E.getAttribute("data-src"), v = S.language;
        if (v === "none") {
          var w = (/\.(\w+)$/.exec(b) || [, "none"])[1];
          v = l[w] || w;
        }
        t.util.setLanguage(A, v), t.util.setLanguage(E, v);
        var C = t.plugins.autoloader;
        C && C.loadLanguages(v), p(
          b,
          function(T) {
            E.setAttribute(s, d);
            var B = _(E.getAttribute("data-range"));
            if (B) {
              var $ = T.split(/\r\n?|\n/g), z = B[0], N = B[1] == null ? $.length : B[1];
              z < 0 && (z += $.length), z = Math.max(0, Math.min(z - 1, $.length)), N < 0 && (N += $.length), N = Math.max(0, Math.min(N, $.length)), T = $.slice(z, N).join(`
`), E.hasAttribute("data-start") || E.setAttribute("data-start", String(z + 1));
            }
            A.textContent = T, t.highlightElement(A);
          },
          function(T) {
            E.setAttribute(s, h), A.textContent = T;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(E) {
        for (var A = (E || document).querySelectorAll(f), b = 0, v; v = A[b++]; )
          t.highlightElement(v);
      }
    };
    var y = !1;
    t.fileHighlight = function() {
      y || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), y = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ed);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, r = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: r.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: r.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = r.variable[1].inside, l = 0; l < a.length; l++)
    i[a[l]] = n.languages.bash[a[l]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
new ou();
const td = (n) => {
  const e = {};
  for (let t = 0, r = n.length; t < r; t++) {
    const a = n[t];
    for (const i in a)
      e[i] ? e[i] = e[i].concat(a[i]) : e[i] = a[i];
  }
  return e;
}, nd = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], rd = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], ad = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
td([
  Object.fromEntries(nd.map((n) => [n, ["*"]])),
  Object.fromEntries(rd.map((n) => [n, ["svg:*"]])),
  Object.fromEntries(ad.map((n) => [n, ["math:*"]]))
]);
const {
  HtmlTagHydration: Jm,
  SvelteComponent: e2,
  attr: t2,
  binding_callbacks: n2,
  children: r2,
  claim_element: a2,
  claim_html_tag: i2,
  detach: l2,
  element: s2,
  init: o2,
  insert_hydration: u2,
  noop: c2,
  safe_not_equal: d2,
  toggle_class: h2
} = window.__gradio__svelte__internal, { afterUpdate: m2 } = window.__gradio__svelte__internal, {
  SvelteComponent: f2,
  attr: p2,
  children: _2,
  claim_component: g2,
  claim_element: v2,
  create_component: b2,
  destroy_component: y2,
  detach: w2,
  element: k2,
  init: D2,
  insert_hydration: S2,
  mount_component: A2,
  safe_not_equal: x2,
  transition_in: F2,
  transition_out: E2
} = window.__gradio__svelte__internal, {
  SvelteComponent: C2,
  attr: T2,
  check_outros: M2,
  children: z2,
  claim_component: B2,
  claim_element: q2,
  claim_space: N2,
  create_component: R2,
  create_slot: I2,
  destroy_component: L2,
  detach: O2,
  element: P2,
  empty: $2,
  get_all_dirty_from_scope: H2,
  get_slot_changes: U2,
  group_outros: V2,
  init: G2,
  insert_hydration: j2,
  mount_component: W2,
  safe_not_equal: Y2,
  space: X2,
  toggle_class: Z2,
  transition_in: K2,
  transition_out: Q2,
  update_slot_base: J2
} = window.__gradio__svelte__internal, {
  SvelteComponent: ef,
  append_hydration: tf,
  attr: nf,
  children: rf,
  claim_component: af,
  claim_element: lf,
  claim_space: sf,
  claim_text: of,
  create_component: uf,
  destroy_component: cf,
  detach: df,
  element: hf,
  init: mf,
  insert_hydration: ff,
  mount_component: pf,
  safe_not_equal: _f,
  set_data: gf,
  space: vf,
  text: bf,
  toggle_class: yf,
  transition_in: wf,
  transition_out: kf
} = window.__gradio__svelte__internal, {
  SvelteComponent: id,
  append_hydration: mi,
  attr: b0,
  bubble: ld,
  check_outros: sd,
  children: fi,
  claim_component: od,
  claim_element: pi,
  claim_space: ud,
  claim_text: cd,
  construct_svelte_component: Ql,
  create_component: Jl,
  destroy_component: es,
  detach: dr,
  element: _i,
  group_outros: dd,
  init: hd,
  insert_hydration: uu,
  listen: md,
  mount_component: ts,
  safe_not_equal: fd,
  set_data: pd,
  set_style: Ir,
  space: _d,
  text: gd,
  toggle_class: gt,
  transition_in: ns,
  transition_out: rs
} = window.__gradio__svelte__internal;
function as(n) {
  let e, t;
  return {
    c() {
      e = _i("span"), t = gd(
        /*label*/
        n[1]
      ), this.h();
    },
    l(r) {
      e = pi(r, "SPAN", { class: !0 });
      var a = fi(e);
      t = cd(
        a,
        /*label*/
        n[1]
      ), a.forEach(dr), this.h();
    },
    h() {
      b0(e, "class", "svelte-vk34kx");
    },
    m(r, a) {
      uu(r, e, a), mi(e, t);
    },
    p(r, a) {
      a & /*label*/
      2 && pd(
        t,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && dr(e);
    }
  };
}
function vd(n) {
  let e, t, r, a, i, l, s, o = (
    /*show_label*/
    n[2] && as(n)
  );
  var d = (
    /*Icon*/
    n[0]
  );
  function h(f, p) {
    return {};
  }
  return d && (a = Ql(d, h())), {
    c() {
      e = _i("button"), o && o.c(), t = _d(), r = _i("div"), a && Jl(a.$$.fragment), this.h();
    },
    l(f) {
      e = pi(f, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var p = fi(e);
      o && o.l(p), t = ud(p), r = pi(p, "DIV", { class: !0 });
      var _ = fi(r);
      a && od(a.$$.fragment, _), _.forEach(dr), p.forEach(dr), this.h();
    },
    h() {
      b0(r, "class", "svelte-vk34kx"), gt(
        r,
        "small",
        /*size*/
        n[4] === "small"
      ), gt(
        r,
        "large",
        /*size*/
        n[4] === "large"
      ), gt(
        r,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], b0(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), b0(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), b0(
        e,
        "title",
        /*label*/
        n[1]
      ), b0(e, "class", "svelte-vk34kx"), gt(
        e,
        "pending",
        /*pending*/
        n[3]
      ), gt(
        e,
        "padded",
        /*padded*/
        n[5]
      ), gt(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), gt(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), Ir(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), Ir(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(f, p) {
      uu(f, e, p), o && o.m(e, null), mi(e, t), mi(e, r), a && ts(a, r, null), i = !0, l || (s = md(
        e,
        "click",
        /*click_handler*/
        n[13]
      ), l = !0);
    },
    p(f, [p]) {
      if (/*show_label*/
      f[2] ? o ? o.p(f, p) : (o = as(f), o.c(), o.m(e, t)) : o && (o.d(1), o = null), p & /*Icon*/
      1 && d !== (d = /*Icon*/
      f[0])) {
        if (a) {
          dd();
          const _ = a;
          rs(_.$$.fragment, 1, 0, () => {
            es(_, 1);
          }), sd();
        }
        d ? (a = Ql(d, h()), Jl(a.$$.fragment), ns(a.$$.fragment, 1), ts(a, r, null)) : a = null;
      }
      (!i || p & /*size*/
      16) && gt(
        r,
        "small",
        /*size*/
        f[4] === "small"
      ), (!i || p & /*size*/
      16) && gt(
        r,
        "large",
        /*size*/
        f[4] === "large"
      ), (!i || p & /*size*/
      16) && gt(
        r,
        "medium",
        /*size*/
        f[4] === "medium"
      ), (!i || p & /*disabled*/
      128) && (e.disabled = /*disabled*/
      f[7]), (!i || p & /*label*/
      2) && b0(
        e,
        "aria-label",
        /*label*/
        f[1]
      ), (!i || p & /*hasPopup*/
      256) && b0(
        e,
        "aria-haspopup",
        /*hasPopup*/
        f[8]
      ), (!i || p & /*label*/
      2) && b0(
        e,
        "title",
        /*label*/
        f[1]
      ), (!i || p & /*pending*/
      8) && gt(
        e,
        "pending",
        /*pending*/
        f[3]
      ), (!i || p & /*padded*/
      32) && gt(
        e,
        "padded",
        /*padded*/
        f[5]
      ), (!i || p & /*highlight*/
      64) && gt(
        e,
        "highlight",
        /*highlight*/
        f[6]
      ), (!i || p & /*transparent*/
      512) && gt(
        e,
        "transparent",
        /*transparent*/
        f[9]
      ), p & /*disabled, _color*/
      2176 && Ir(e, "color", !/*disabled*/
      f[7] && /*_color*/
      f[11] ? (
        /*_color*/
        f[11]
      ) : "var(--block-label-text-color)"), p & /*disabled, background*/
      1152 && Ir(e, "--bg-color", /*disabled*/
      f[7] ? "auto" : (
        /*background*/
        f[10]
      ));
    },
    i(f) {
      i || (a && ns(a.$$.fragment, f), i = !0);
    },
    o(f) {
      a && rs(a.$$.fragment, f), i = !1;
    },
    d(f) {
      f && dr(e), o && o.d(), a && es(a), l = !1, s();
    }
  };
}
function bd(n, e, t) {
  let r, { Icon: a } = e, { label: i = "" } = e, { show_label: l = !1 } = e, { pending: s = !1 } = e, { size: o = "small" } = e, { padded: d = !0 } = e, { highlight: h = !1 } = e, { disabled: f = !1 } = e, { hasPopup: p = !1 } = e, { color: _ = "var(--block-label-text-color)" } = e, { transparent: y = !1 } = e, { background: S = "var(--block-background-fill)" } = e;
  function E(A) {
    ld.call(this, n, A);
  }
  return n.$$set = (A) => {
    "Icon" in A && t(0, a = A.Icon), "label" in A && t(1, i = A.label), "show_label" in A && t(2, l = A.show_label), "pending" in A && t(3, s = A.pending), "size" in A && t(4, o = A.size), "padded" in A && t(5, d = A.padded), "highlight" in A && t(6, h = A.highlight), "disabled" in A && t(7, f = A.disabled), "hasPopup" in A && t(8, p = A.hasPopup), "color" in A && t(12, _ = A.color), "transparent" in A && t(9, y = A.transparent), "background" in A && t(10, S = A.background);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, r = h ? "var(--color-accent)" : _);
  }, [
    a,
    i,
    l,
    s,
    o,
    d,
    h,
    f,
    p,
    y,
    S,
    r,
    _,
    E
  ];
}
class yd extends id {
  constructor(e) {
    super(), hd(this, e, bd, vd, fd, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Df,
  append_hydration: Sf,
  attr: Af,
  binding_callbacks: xf,
  children: Ff,
  claim_element: Ef,
  create_slot: Cf,
  detach: Tf,
  element: Mf,
  get_all_dirty_from_scope: zf,
  get_slot_changes: Bf,
  init: qf,
  insert_hydration: Nf,
  safe_not_equal: Rf,
  toggle_class: If,
  transition_in: Lf,
  transition_out: Of,
  update_slot_base: Pf
} = window.__gradio__svelte__internal, {
  SvelteComponent: $f,
  append_hydration: Hf,
  attr: Uf,
  children: Vf,
  claim_svg_element: Gf,
  detach: jf,
  init: Wf,
  insert_hydration: Yf,
  noop: Xf,
  safe_not_equal: Zf,
  svg_element: Kf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qf,
  append_hydration: Jf,
  attr: e5,
  children: t5,
  claim_svg_element: n5,
  detach: r5,
  init: a5,
  insert_hydration: i5,
  noop: l5,
  safe_not_equal: s5,
  svg_element: o5
} = window.__gradio__svelte__internal, {
  SvelteComponent: u5,
  append_hydration: c5,
  attr: d5,
  children: h5,
  claim_svg_element: m5,
  detach: f5,
  init: p5,
  insert_hydration: _5,
  noop: g5,
  safe_not_equal: v5,
  svg_element: b5
} = window.__gradio__svelte__internal, {
  SvelteComponent: y5,
  append_hydration: w5,
  attr: k5,
  children: D5,
  claim_svg_element: S5,
  detach: A5,
  init: x5,
  insert_hydration: F5,
  noop: E5,
  safe_not_equal: C5,
  svg_element: T5
} = window.__gradio__svelte__internal, {
  SvelteComponent: M5,
  append_hydration: z5,
  attr: B5,
  children: q5,
  claim_svg_element: N5,
  detach: R5,
  init: I5,
  insert_hydration: L5,
  noop: O5,
  safe_not_equal: P5,
  svg_element: $5
} = window.__gradio__svelte__internal, {
  SvelteComponent: H5,
  append_hydration: U5,
  attr: V5,
  children: G5,
  claim_svg_element: j5,
  detach: W5,
  init: Y5,
  insert_hydration: X5,
  noop: Z5,
  safe_not_equal: K5,
  svg_element: Q5
} = window.__gradio__svelte__internal, {
  SvelteComponent: J5,
  append_hydration: e3,
  attr: t3,
  children: n3,
  claim_svg_element: r3,
  detach: a3,
  init: i3,
  insert_hydration: l3,
  noop: s3,
  safe_not_equal: o3,
  svg_element: u3
} = window.__gradio__svelte__internal, {
  SvelteComponent: c3,
  append_hydration: d3,
  attr: h3,
  children: m3,
  claim_svg_element: f3,
  detach: p3,
  init: _3,
  insert_hydration: g3,
  noop: v3,
  safe_not_equal: b3,
  svg_element: y3
} = window.__gradio__svelte__internal, {
  SvelteComponent: w3,
  append_hydration: k3,
  attr: D3,
  children: S3,
  claim_svg_element: A3,
  detach: x3,
  init: F3,
  insert_hydration: E3,
  noop: C3,
  safe_not_equal: T3,
  svg_element: M3
} = window.__gradio__svelte__internal, {
  SvelteComponent: z3,
  append_hydration: B3,
  attr: q3,
  children: N3,
  claim_svg_element: R3,
  detach: I3,
  init: L3,
  insert_hydration: O3,
  noop: P3,
  safe_not_equal: $3,
  svg_element: H3
} = window.__gradio__svelte__internal, {
  SvelteComponent: wd,
  append_hydration: Ha,
  attr: Ut,
  children: Lr,
  claim_svg_element: Or,
  detach: Qn,
  init: kd,
  insert_hydration: Dd,
  noop: Ua,
  safe_not_equal: Sd,
  set_style: e0,
  svg_element: Pr
} = window.__gradio__svelte__internal;
function Ad(n) {
  let e, t, r, a;
  return {
    c() {
      e = Pr("svg"), t = Pr("g"), r = Pr("path"), a = Pr("path"), this.h();
    },
    l(i) {
      e = Or(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = Lr(e);
      t = Or(l, "g", { transform: !0 });
      var s = Lr(t);
      r = Or(s, "path", { d: !0, style: !0 }), Lr(r).forEach(Qn), s.forEach(Qn), a = Or(l, "path", { d: !0, style: !0 }), Lr(a).forEach(Qn), l.forEach(Qn), this.h();
    },
    h() {
      Ut(r, "d", "M18,6L6.087,17.913"), e0(r, "fill", "none"), e0(r, "fill-rule", "nonzero"), e0(r, "stroke-width", "2px"), Ut(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Ut(a, "d", "M4.364,4.364L19.636,19.636"), e0(a, "fill", "none"), e0(a, "fill-rule", "nonzero"), e0(a, "stroke-width", "2px"), Ut(e, "width", "100%"), Ut(e, "height", "100%"), Ut(e, "viewBox", "0 0 24 24"), Ut(e, "version", "1.1"), Ut(e, "xmlns", "http://www.w3.org/2000/svg"), Ut(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ut(e, "xml:space", "preserve"), Ut(e, "stroke", "currentColor"), e0(e, "fill-rule", "evenodd"), e0(e, "clip-rule", "evenodd"), e0(e, "stroke-linecap", "round"), e0(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      Dd(i, e, l), Ha(e, t), Ha(t, r), Ha(e, a);
    },
    p: Ua,
    i: Ua,
    o: Ua,
    d(i) {
      i && Qn(e);
    }
  };
}
class xd extends wd {
  constructor(e) {
    super(), kd(this, e, null, Ad, Sd, {});
  }
}
const {
  SvelteComponent: U3,
  append_hydration: V3,
  attr: G3,
  children: j3,
  claim_svg_element: W3,
  detach: Y3,
  init: X3,
  insert_hydration: Z3,
  noop: K3,
  safe_not_equal: Q3,
  svg_element: J3
} = window.__gradio__svelte__internal, {
  SvelteComponent: e6,
  append_hydration: t6,
  attr: n6,
  children: r6,
  claim_svg_element: a6,
  detach: i6,
  init: l6,
  insert_hydration: s6,
  noop: o6,
  safe_not_equal: u6,
  svg_element: c6
} = window.__gradio__svelte__internal, {
  SvelteComponent: d6,
  append_hydration: h6,
  attr: m6,
  children: f6,
  claim_svg_element: p6,
  detach: _6,
  init: g6,
  insert_hydration: v6,
  noop: b6,
  safe_not_equal: y6,
  svg_element: w6
} = window.__gradio__svelte__internal, {
  SvelteComponent: k6,
  append_hydration: D6,
  attr: S6,
  children: A6,
  claim_svg_element: x6,
  detach: F6,
  init: E6,
  insert_hydration: C6,
  noop: T6,
  safe_not_equal: M6,
  svg_element: z6
} = window.__gradio__svelte__internal, {
  SvelteComponent: B6,
  append_hydration: q6,
  attr: N6,
  children: R6,
  claim_svg_element: I6,
  detach: L6,
  init: O6,
  insert_hydration: P6,
  noop: $6,
  safe_not_equal: H6,
  svg_element: U6
} = window.__gradio__svelte__internal, {
  SvelteComponent: V6,
  append_hydration: G6,
  attr: j6,
  children: W6,
  claim_svg_element: Y6,
  detach: X6,
  init: Z6,
  insert_hydration: K6,
  noop: Q6,
  safe_not_equal: J6,
  svg_element: e7
} = window.__gradio__svelte__internal, {
  SvelteComponent: t7,
  append_hydration: n7,
  attr: r7,
  children: a7,
  claim_svg_element: i7,
  detach: l7,
  init: s7,
  insert_hydration: o7,
  noop: u7,
  safe_not_equal: c7,
  svg_element: d7
} = window.__gradio__svelte__internal, {
  SvelteComponent: h7,
  append_hydration: m7,
  attr: f7,
  children: p7,
  claim_svg_element: _7,
  detach: g7,
  init: v7,
  insert_hydration: b7,
  noop: y7,
  safe_not_equal: w7,
  svg_element: k7
} = window.__gradio__svelte__internal, {
  SvelteComponent: D7,
  append_hydration: S7,
  attr: A7,
  children: x7,
  claim_svg_element: F7,
  detach: E7,
  init: C7,
  insert_hydration: T7,
  noop: M7,
  safe_not_equal: z7,
  svg_element: B7
} = window.__gradio__svelte__internal, {
  SvelteComponent: q7,
  append_hydration: N7,
  attr: R7,
  children: I7,
  claim_svg_element: L7,
  detach: O7,
  init: P7,
  insert_hydration: $7,
  noop: H7,
  safe_not_equal: U7,
  svg_element: V7
} = window.__gradio__svelte__internal, {
  SvelteComponent: G7,
  append_hydration: j7,
  attr: W7,
  children: Y7,
  claim_svg_element: X7,
  detach: Z7,
  init: K7,
  insert_hydration: Q7,
  noop: J7,
  safe_not_equal: e8,
  svg_element: t8
} = window.__gradio__svelte__internal, {
  SvelteComponent: n8,
  append_hydration: r8,
  attr: a8,
  children: i8,
  claim_svg_element: l8,
  detach: s8,
  init: o8,
  insert_hydration: u8,
  noop: c8,
  safe_not_equal: d8,
  svg_element: h8
} = window.__gradio__svelte__internal, {
  SvelteComponent: m8,
  append_hydration: f8,
  attr: p8,
  children: _8,
  claim_svg_element: g8,
  detach: v8,
  init: b8,
  insert_hydration: y8,
  noop: w8,
  safe_not_equal: k8,
  svg_element: D8
} = window.__gradio__svelte__internal, {
  SvelteComponent: S8,
  append_hydration: A8,
  attr: x8,
  children: F8,
  claim_svg_element: E8,
  detach: C8,
  init: T8,
  insert_hydration: M8,
  noop: z8,
  safe_not_equal: B8,
  svg_element: q8
} = window.__gradio__svelte__internal, {
  SvelteComponent: N8,
  append_hydration: R8,
  attr: I8,
  children: L8,
  claim_svg_element: O8,
  detach: P8,
  init: $8,
  insert_hydration: H8,
  noop: U8,
  safe_not_equal: V8,
  svg_element: G8
} = window.__gradio__svelte__internal, {
  SvelteComponent: j8,
  append_hydration: W8,
  attr: Y8,
  children: X8,
  claim_svg_element: Z8,
  detach: K8,
  init: Q8,
  insert_hydration: J8,
  noop: ep,
  safe_not_equal: tp,
  svg_element: np
} = window.__gradio__svelte__internal, {
  SvelteComponent: rp,
  append_hydration: ap,
  attr: ip,
  children: lp,
  claim_svg_element: sp,
  detach: op,
  init: up,
  insert_hydration: cp,
  noop: dp,
  safe_not_equal: hp,
  svg_element: mp
} = window.__gradio__svelte__internal, {
  SvelteComponent: fp,
  append_hydration: pp,
  attr: _p,
  children: gp,
  claim_svg_element: vp,
  detach: bp,
  init: yp,
  insert_hydration: wp,
  noop: kp,
  safe_not_equal: Dp,
  svg_element: Sp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ap,
  append_hydration: xp,
  attr: Fp,
  children: Ep,
  claim_svg_element: Cp,
  detach: Tp,
  init: Mp,
  insert_hydration: zp,
  noop: Bp,
  safe_not_equal: qp,
  svg_element: Np
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rp,
  append_hydration: Ip,
  attr: Lp,
  children: Op,
  claim_svg_element: Pp,
  detach: $p,
  init: Hp,
  insert_hydration: Up,
  noop: Vp,
  safe_not_equal: Gp,
  svg_element: jp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wp,
  append_hydration: Yp,
  attr: Xp,
  children: Zp,
  claim_svg_element: Kp,
  detach: Qp,
  init: Jp,
  insert_hydration: e_,
  noop: t_,
  safe_not_equal: n_,
  svg_element: r_
} = window.__gradio__svelte__internal, {
  SvelteComponent: a_,
  append_hydration: i_,
  attr: l_,
  children: s_,
  claim_svg_element: o_,
  detach: u_,
  init: c_,
  insert_hydration: d_,
  noop: h_,
  safe_not_equal: m_,
  svg_element: f_
} = window.__gradio__svelte__internal, {
  SvelteComponent: p_,
  append_hydration: __,
  attr: g_,
  children: v_,
  claim_svg_element: b_,
  detach: y_,
  init: w_,
  insert_hydration: k_,
  noop: D_,
  safe_not_equal: S_,
  svg_element: A_
} = window.__gradio__svelte__internal, {
  SvelteComponent: x_,
  append_hydration: F_,
  attr: E_,
  children: C_,
  claim_svg_element: T_,
  detach: M_,
  init: z_,
  insert_hydration: B_,
  noop: q_,
  safe_not_equal: N_,
  svg_element: R_
} = window.__gradio__svelte__internal, {
  SvelteComponent: I_,
  append_hydration: L_,
  attr: O_,
  children: P_,
  claim_svg_element: $_,
  detach: H_,
  init: U_,
  insert_hydration: V_,
  noop: G_,
  safe_not_equal: j_,
  svg_element: W_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y_,
  append_hydration: X_,
  attr: Z_,
  children: K_,
  claim_svg_element: Q_,
  detach: J_,
  init: eg,
  insert_hydration: tg,
  noop: ng,
  safe_not_equal: rg,
  svg_element: ag
} = window.__gradio__svelte__internal, {
  SvelteComponent: ig,
  append_hydration: lg,
  attr: sg,
  children: og,
  claim_svg_element: ug,
  detach: cg,
  init: dg,
  insert_hydration: hg,
  noop: mg,
  safe_not_equal: fg,
  svg_element: pg
} = window.__gradio__svelte__internal, {
  SvelteComponent: _g,
  append_hydration: gg,
  attr: vg,
  children: bg,
  claim_svg_element: yg,
  detach: wg,
  init: kg,
  insert_hydration: Dg,
  noop: Sg,
  safe_not_equal: Ag,
  svg_element: xg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fg,
  append_hydration: Eg,
  attr: Cg,
  children: Tg,
  claim_svg_element: Mg,
  detach: zg,
  init: Bg,
  insert_hydration: qg,
  noop: Ng,
  safe_not_equal: Rg,
  svg_element: Ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lg,
  append_hydration: Og,
  attr: Pg,
  children: $g,
  claim_svg_element: Hg,
  detach: Ug,
  init: Vg,
  insert_hydration: Gg,
  noop: jg,
  safe_not_equal: Wg,
  set_style: Yg,
  svg_element: Xg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zg,
  append_hydration: Kg,
  attr: Qg,
  children: Jg,
  claim_svg_element: e9,
  detach: t9,
  init: n9,
  insert_hydration: r9,
  noop: a9,
  safe_not_equal: i9,
  svg_element: l9
} = window.__gradio__svelte__internal, {
  SvelteComponent: s9,
  append_hydration: o9,
  attr: u9,
  children: c9,
  claim_svg_element: d9,
  detach: h9,
  init: m9,
  insert_hydration: f9,
  noop: p9,
  safe_not_equal: _9,
  svg_element: g9
} = window.__gradio__svelte__internal, {
  SvelteComponent: v9,
  append_hydration: b9,
  attr: y9,
  children: w9,
  claim_svg_element: k9,
  detach: D9,
  init: S9,
  insert_hydration: A9,
  noop: x9,
  safe_not_equal: F9,
  svg_element: E9
} = window.__gradio__svelte__internal, {
  SvelteComponent: C9,
  append_hydration: T9,
  attr: M9,
  children: z9,
  claim_svg_element: B9,
  detach: q9,
  init: N9,
  insert_hydration: R9,
  noop: I9,
  safe_not_equal: L9,
  svg_element: O9
} = window.__gradio__svelte__internal, {
  SvelteComponent: P9,
  append_hydration: $9,
  attr: H9,
  children: U9,
  claim_svg_element: V9,
  detach: G9,
  init: j9,
  insert_hydration: W9,
  noop: Y9,
  safe_not_equal: X9,
  svg_element: Z9
} = window.__gradio__svelte__internal, {
  SvelteComponent: K9,
  append_hydration: Q9,
  attr: J9,
  children: ev,
  claim_svg_element: tv,
  detach: nv,
  init: rv,
  insert_hydration: av,
  noop: iv,
  safe_not_equal: lv,
  svg_element: sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: ov,
  append_hydration: uv,
  attr: cv,
  children: dv,
  claim_svg_element: hv,
  detach: mv,
  init: fv,
  insert_hydration: pv,
  noop: _v,
  safe_not_equal: gv,
  svg_element: vv
} = window.__gradio__svelte__internal, {
  SvelteComponent: bv,
  append_hydration: yv,
  attr: wv,
  children: kv,
  claim_svg_element: Dv,
  detach: Sv,
  init: Av,
  insert_hydration: xv,
  noop: Fv,
  safe_not_equal: Ev,
  svg_element: Cv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tv,
  append_hydration: Mv,
  attr: zv,
  children: Bv,
  claim_svg_element: qv,
  claim_text: Nv,
  detach: Rv,
  init: Iv,
  insert_hydration: Lv,
  noop: Ov,
  safe_not_equal: Pv,
  svg_element: $v,
  text: Hv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uv,
  append_hydration: Vv,
  attr: Gv,
  children: jv,
  claim_svg_element: Wv,
  detach: Yv,
  init: Xv,
  insert_hydration: Zv,
  noop: Kv,
  safe_not_equal: Qv,
  svg_element: Jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eb,
  append_hydration: tb,
  attr: nb,
  children: rb,
  claim_svg_element: ab,
  detach: ib,
  init: lb,
  insert_hydration: sb,
  noop: ob,
  safe_not_equal: ub,
  svg_element: cb
} = window.__gradio__svelte__internal, {
  SvelteComponent: db,
  append_hydration: hb,
  attr: mb,
  children: fb,
  claim_svg_element: pb,
  detach: _b,
  init: gb,
  insert_hydration: vb,
  noop: bb,
  safe_not_equal: yb,
  svg_element: wb
} = window.__gradio__svelte__internal, {
  SvelteComponent: kb,
  append_hydration: Db,
  attr: Sb,
  children: Ab,
  claim_svg_element: xb,
  detach: Fb,
  init: Eb,
  insert_hydration: Cb,
  noop: Tb,
  safe_not_equal: Mb,
  svg_element: zb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bb,
  append_hydration: qb,
  attr: Nb,
  children: Rb,
  claim_svg_element: Ib,
  detach: Lb,
  init: Ob,
  insert_hydration: Pb,
  noop: $b,
  safe_not_equal: Hb,
  svg_element: Ub
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vb,
  append_hydration: Gb,
  attr: jb,
  children: Wb,
  claim_svg_element: Yb,
  claim_text: Xb,
  detach: Zb,
  init: Kb,
  insert_hydration: Qb,
  noop: Jb,
  safe_not_equal: ey,
  svg_element: ty,
  text: ny
} = window.__gradio__svelte__internal, {
  SvelteComponent: ry,
  append_hydration: ay,
  attr: iy,
  children: ly,
  claim_svg_element: sy,
  claim_text: oy,
  detach: uy,
  init: cy,
  insert_hydration: dy,
  noop: hy,
  safe_not_equal: my,
  svg_element: fy,
  text: py
} = window.__gradio__svelte__internal, {
  SvelteComponent: _y,
  append_hydration: gy,
  attr: vy,
  children: by,
  claim_svg_element: yy,
  claim_text: wy,
  detach: ky,
  init: Dy,
  insert_hydration: Sy,
  noop: Ay,
  safe_not_equal: xy,
  svg_element: Fy,
  text: Ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cy,
  append_hydration: Ty,
  attr: My,
  children: zy,
  claim_svg_element: By,
  detach: qy,
  init: Ny,
  insert_hydration: Ry,
  noop: Iy,
  safe_not_equal: Ly,
  svg_element: Oy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Py,
  append_hydration: $y,
  attr: Hy,
  children: Uy,
  claim_svg_element: Vy,
  detach: Gy,
  init: jy,
  insert_hydration: Wy,
  noop: Yy,
  safe_not_equal: Xy,
  svg_element: Zy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ky,
  append_hydration: Qy,
  attr: Jy,
  children: ew,
  claim_svg_element: tw,
  detach: nw,
  init: rw,
  insert_hydration: aw,
  noop: iw,
  safe_not_equal: lw,
  svg_element: sw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ow,
  append_hydration: uw,
  attr: cw,
  children: dw,
  claim_svg_element: hw,
  detach: mw,
  init: fw,
  insert_hydration: pw,
  noop: _w,
  safe_not_equal: gw,
  svg_element: vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: bw,
  append_hydration: yw,
  attr: ww,
  children: kw,
  claim_svg_element: Dw,
  detach: Sw,
  init: Aw,
  insert_hydration: xw,
  noop: Fw,
  safe_not_equal: Ew,
  svg_element: Cw
} = window.__gradio__svelte__internal, Fd = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], is = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Fd.reduce(
  (n, { color: e, primary: t, secondary: r }) => ({
    ...n,
    [e]: {
      primary: is[e][t],
      secondary: is[e][r]
    }
  }),
  {}
);
const {
  SvelteComponent: Tw,
  claim_component: Mw,
  create_component: zw,
  destroy_component: Bw,
  init: qw,
  mount_component: Nw,
  safe_not_equal: Rw,
  transition_in: Iw,
  transition_out: Lw
} = window.__gradio__svelte__internal, { createEventDispatcher: Ow } = window.__gradio__svelte__internal, {
  SvelteComponent: Pw,
  append_hydration: $w,
  attr: Hw,
  check_outros: Uw,
  children: Vw,
  claim_component: Gw,
  claim_element: jw,
  claim_space: Ww,
  claim_text: Yw,
  create_component: Xw,
  destroy_component: Zw,
  detach: Kw,
  element: Qw,
  empty: Jw,
  group_outros: ek,
  init: tk,
  insert_hydration: nk,
  mount_component: rk,
  safe_not_equal: ak,
  set_data: ik,
  space: lk,
  text: sk,
  toggle_class: ok,
  transition_in: uk,
  transition_out: ck
} = window.__gradio__svelte__internal, {
  SvelteComponent: dk,
  attr: hk,
  children: mk,
  claim_element: fk,
  create_slot: pk,
  detach: _k,
  element: gk,
  get_all_dirty_from_scope: vk,
  get_slot_changes: bk,
  init: yk,
  insert_hydration: wk,
  safe_not_equal: kk,
  toggle_class: Dk,
  transition_in: Sk,
  transition_out: Ak,
  update_slot_base: xk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fk,
  append_hydration: Ek,
  attr: Ck,
  check_outros: Tk,
  children: Mk,
  claim_component: zk,
  claim_element: Bk,
  claim_space: qk,
  create_component: Nk,
  destroy_component: Rk,
  detach: Ik,
  element: Lk,
  empty: Ok,
  group_outros: Pk,
  init: $k,
  insert_hydration: Hk,
  listen: Uk,
  mount_component: Vk,
  safe_not_equal: Gk,
  space: jk,
  toggle_class: Wk,
  transition_in: Yk,
  transition_out: Xk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zk,
  attr: Kk,
  children: Qk,
  claim_element: Jk,
  create_slot: eD,
  detach: tD,
  element: nD,
  get_all_dirty_from_scope: rD,
  get_slot_changes: aD,
  init: iD,
  insert_hydration: lD,
  null_to_empty: sD,
  safe_not_equal: oD,
  transition_in: uD,
  transition_out: cD,
  update_slot_base: dD
} = window.__gradio__svelte__internal, { setContext: hD, getContext: mD } = window.__gradio__svelte__internal, {
  SvelteComponent: fD,
  assign: pD,
  check_outros: _D,
  children: gD,
  claim_element: vD,
  compute_rest_props: bD,
  create_slot: yD,
  detach: wD,
  element: kD,
  empty: DD,
  exclude_internal_props: SD,
  get_all_dirty_from_scope: AD,
  get_slot_changes: xD,
  get_spread_update: FD,
  group_outros: ED,
  init: CD,
  insert_hydration: TD,
  listen: MD,
  prevent_default: zD,
  safe_not_equal: BD,
  set_attributes: qD,
  set_style: ND,
  toggle_class: RD,
  transition_in: ID,
  transition_out: LD,
  update_slot_base: OD
} = window.__gradio__svelte__internal, { createEventDispatcher: PD } = window.__gradio__svelte__internal, {
  SvelteComponent: $D,
  check_outros: HD,
  claim_component: UD,
  claim_space: VD,
  create_component: GD,
  create_slot: jD,
  destroy_component: WD,
  detach: YD,
  get_all_dirty_from_scope: XD,
  get_slot_changes: ZD,
  group_outros: KD,
  init: QD,
  insert_hydration: JD,
  mount_component: eS,
  safe_not_equal: tS,
  space: nS,
  transition_in: rS,
  transition_out: aS,
  update_slot_base: iS
} = window.__gradio__svelte__internal, { createEventDispatcher: lS } = window.__gradio__svelte__internal, { tick: Ed } = window.__gradio__svelte__internal;
async function gi(n, e, t, r) {
  if (await Ed(), r || e === t) return;
  const a = window.getComputedStyle(n), i = parseFloat(a.paddingTop), l = parseFloat(a.paddingBottom), s = parseFloat(a.lineHeight);
  let o = t === void 0 ? !1 : i + l + s * t, d = i + l + e * s;
  n.style.height = "1px";
  let h;
  o && n.scrollHeight > o ? h = o : n.scrollHeight < d ? h = d : h = n.scrollHeight, n.style.height = `${h}px`;
}
function Cd(n, e) {
  if (e.lines === e.max_lines) return;
  n.style.overflowY = "scroll";
  function t(r) {
    gi(r.target, e.lines, e.max_lines, !1);
  }
  if (n.addEventListener("input", t), !!e.text.trim())
    return gi(n, e.lines, e.max_lines, !1), {
      destroy: () => n.removeEventListener("input", t)
    };
}
function Td(n, e) {
  return n.addEventListener(
    "icegatheringstatechange",
    () => {
      console.debug(n.iceGatheringState);
    },
    !1
  ), n.addEventListener(
    "iceconnectionstatechange",
    () => {
      console.debug(n.iceConnectionState);
    },
    !1
  ), n.addEventListener(
    "signalingstatechange",
    () => {
      console.debug(n.signalingState);
    },
    !1
  ), n.addEventListener("track", (t) => {
    console.debug("track event listener"), e && e.srcObject !== t.streams[0] && (console.debug("streams", t.streams), e.srcObject = t.streams[0], console.debug("node.srcOject", e.srcObject), t.track.kind === "audio" && (e.volume = 1, e.muted = !1, e.autoplay = !0, console.debug(e), console.debug("autoplay track"), e.play().catch((r) => console.debug("Autoplay failed:", r))));
  }), n;
}
async function Md(n, e, t, r, a, i = "video", l = () => {
}, s = {}) {
  e = Td(e, t);
  const o = e.createDataChannel("text");
  return o.onopen = () => {
    console.debug("Data channel is open"), o.send("handshake");
  }, o.onmessage = (d) => {
    console.debug("Received message:", d.data), (d.data === "change" || d.data === "tick" || d.data === "stopword") && (console.debug(`${d.data} event received`), console.debug(`${d}`), l(d.data));
  }, n ? n.getTracks().forEach(async (d) => {
    console.debug("Track stream callback", d);
    const h = e.addTrack(d, n), p = { ...h.getParameters(), ...s };
    await h.setParameters(p), console.debug("sender params", h.getParameters());
  }) : (console.debug("Creating transceiver!"), e.addTransceiver(i, { direction: "recvonly" })), await Bd(e, r, a), e;
}
function zd(n, e) {
  return new Promise((t, r) => {
    n(e).then((a) => {
      console.debug("data", a), (a == null ? void 0 : a.status) === "failed" && (console.debug("rejecting"), r("error")), t(a);
    });
  });
}
async function Bd(n, e, t) {
  return n.createOffer().then((r) => n.setLocalDescription(r)).then(() => new Promise((r) => {
    if (console.debug("ice gathering state", n.iceGatheringState), n.iceGatheringState === "complete")
      r();
    else {
      const a = () => {
        n.iceGatheringState === "complete" && (console.debug("ice complete"), n.removeEventListener("icegatheringstatechange", a), r());
      };
      n.addEventListener("icegatheringstatechange", a);
    }
  })).then(() => {
    var r = n.localDescription;
    return zd(e, {
      sdp: r.sdp,
      type: r.type,
      webrtc_id: t
    });
  }).then((r) => r).then((r) => n.setRemoteDescription(r));
}
function Va(n) {
  console.debug("Stopping peer connection"), n.getTransceivers && n.getTransceivers().forEach((e) => {
    e.stop && e.stop();
  }), n.getSenders() && n.getSenders().forEach((e) => {
    console.debug("sender", e), e.track && e.track.stop && e.track.stop();
  }), setTimeout(() => {
    n.close();
  }, 500);
}
function qd() {
  return navigator.mediaDevices.enumerateDevices();
}
function Nd(n, e = "videoinput") {
  return n.filter(
    (r) => r.kind === e
  );
}
async function Rd(n) {
  const e = await navigator.mediaDevices.enumerateDevices();
  console.log("Devices:", e);
  const r = e.filter((a) => a.kind === "audiooutput").find(
    (a) => /headset|casque|earphone|headphones|AirPods/i.test(a.label)
  );
  if (r && typeof n.setSinkId == "function")
    try {
      await n.setSinkId(r.deviceId), console.log("Sortie audio définie sur le casque");
    } catch (a) {
      console.warn("Erreur setSinkId:", a);
    }
  else
    console.log("Casque non détecté ou setSinkId non supporté");
}
const {
  SvelteComponent: Id,
  append_hydration: Ga,
  attr: n0,
  children: Ln,
  claim_element: sn,
  claim_space: Ld,
  destroy_each: cu,
  detach: It,
  element: on,
  empty: ls,
  ensure_array_like: sa,
  init: Od,
  insert_hydration: Vn,
  noop: vi,
  safe_not_equal: Pd,
  set_style: o0,
  space: $d,
  src_url_equal: ss
} = window.__gradio__svelte__internal, { onDestroy: Hd } = window.__gradio__svelte__internal;
function os(n, e, t) {
  const r = n.slice();
  return r[17] = e[t], r;
}
function us(n, e, t) {
  const r = n.slice();
  return r[17] = e[t], r[19] = t, r;
}
function Ud(n) {
  let e, t = sa(Array(
    /*numBars*/
    n[0]
  )), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = cs(os(n, t, a));
  return {
    c() {
      e = on("div");
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      this.h();
    },
    l(a) {
      e = sn(a, "DIV", { class: !0 });
      var i = Ln(e);
      for (let l = 0; l < r.length; l += 1)
        r[l].l(i);
      i.forEach(It), this.h();
    },
    h() {
      n0(e, "class", "gradio-audio-boxContainer svelte-1cqbdpi"), o0(
        e,
        "width",
        /*containerWidth*/
        n[6]
      );
    },
    m(a, i) {
      Vn(a, e, i);
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(e, null);
    },
    p(a, i) {
      if (i & /*numBars*/
      1) {
        t = sa(Array(
          /*numBars*/
          a[0]
        ));
        let l;
        for (l = 0; l < t.length; l += 1) {
          const s = os(a, t, l);
          r[l] ? r[l].p(s, i) : (r[l] = cs(), r[l].c(), r[l].m(e, null));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
      i & /*containerWidth*/
      64 && o0(
        e,
        "width",
        /*containerWidth*/
        a[6]
      );
    },
    d(a) {
      a && It(e), cu(r, a);
    }
  };
}
function Vd(n) {
  let e, t, r, a, i, l = (
    /*pulseIntensity*/
    n[5] > 0 && ds(n)
  );
  return {
    c() {
      e = on("div"), l && l.c(), t = $d(), r = on("div"), a = on("img"), this.h();
    },
    l(s) {
      e = sn(s, "DIV", { class: !0 });
      var o = Ln(e);
      l && l.l(o), t = Ld(o), r = sn(o, "DIV", { class: !0 });
      var d = Ln(r);
      a = sn(d, "IMG", { src: !0, alt: !0, class: !0 }), d.forEach(It), o.forEach(It), this.h();
    },
    h() {
      ss(a.src, i = /*icon*/
      n[1]) || n0(a, "src", i), n0(a, "alt", "Audio visualization icon"), n0(a, "class", "icon-image svelte-1cqbdpi"), n0(r, "class", "gradio-audio-icon svelte-1cqbdpi"), o0(r, "transform", `scale(${/*pulseScale*/
      n[4]})`), o0(
        r,
        "background",
        /*icon_button_color*/
        n[2]
      ), n0(e, "class", "gradio-audio-icon-container svelte-1cqbdpi");
    },
    m(s, o) {
      Vn(s, e, o), l && l.m(e, null), Ga(e, t), Ga(e, r), Ga(r, a);
    },
    p(s, o) {
      /*pulseIntensity*/
      s[5] > 0 ? l ? l.p(s, o) : (l = ds(s), l.c(), l.m(e, t)) : l && (l.d(1), l = null), o & /*icon*/
      2 && !ss(a.src, i = /*icon*/
      s[1]) && n0(a, "src", i), o & /*pulseScale*/
      16 && o0(r, "transform", `scale(${/*pulseScale*/
      s[4]})`), o & /*icon_button_color*/
      4 && o0(
        r,
        "background",
        /*icon_button_color*/
        s[2]
      );
    },
    d(s) {
      s && It(e), l && l.d();
    }
  };
}
function cs(n) {
  let e;
  return {
    c() {
      e = on("div"), this.h();
    },
    l(t) {
      e = sn(t, "DIV", { class: !0, style: !0 }), Ln(e).forEach(It), this.h();
    },
    h() {
      n0(e, "class", "gradio-audio-box svelte-1cqbdpi"), o0(e, "transform", "scaleY(0.1)");
    },
    m(t, r) {
      Vn(t, e, r);
    },
    p: vi,
    d(t) {
      t && It(e);
    }
  };
}
function ds(n) {
  let e, t = sa(Array(3)), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = hs(us(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = ls();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = ls();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      Vn(a, e, i);
    },
    p(a, i) {
      if (i & /*pulse_color*/
      8) {
        t = sa(Array(3));
        let l;
        for (l = 0; l < t.length; l += 1) {
          const s = us(a, t, l);
          r[l] ? r[l].p(s, i) : (r[l] = hs(s), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && It(e), cu(r, a);
    }
  };
}
function hs(n) {
  let e;
  return {
    c() {
      e = on("div"), this.h();
    },
    l(t) {
      e = sn(t, "DIV", { class: !0 }), Ln(e).forEach(It), this.h();
    },
    h() {
      n0(e, "class", "pulse-ring svelte-1cqbdpi"), o0(
        e,
        "background",
        /*pulse_color*/
        n[3]
      ), o0(e, "animation-delay", `${/*i*/
      n[19] * 0.4}s`);
    },
    m(t, r) {
      Vn(t, e, r);
    },
    p(t, r) {
      r & /*pulse_color*/
      8 && o0(
        e,
        "background",
        /*pulse_color*/
        t[3]
      );
    },
    d(t) {
      t && It(e);
    }
  };
}
function Gd(n) {
  let e;
  function t(i, l) {
    return (
      /*icon*/
      i[1] ? Vd : Ud
    );
  }
  let r = t(n), a = r(n);
  return {
    c() {
      e = on("div"), a.c(), this.h();
    },
    l(i) {
      e = sn(i, "DIV", { class: !0 });
      var l = Ln(e);
      a.l(l), l.forEach(It), this.h();
    },
    h() {
      n0(e, "class", "gradio-audio-waveContainer svelte-1cqbdpi");
    },
    m(i, l) {
      Vn(i, e, l), a.m(e, null);
    },
    p(i, [l]) {
      r === (r = t(i)) && a ? a.p(i, l) : (a.d(1), a = r(i), a && (a.c(), a.m(e, null)));
    },
    i: vi,
    o: vi,
    d(i) {
      i && It(e), a.d();
    }
  };
}
function jd(n, e, t) {
  let r;
  var a = this && this.__awaiter || function(w, C, T, B) {
    function $(z) {
      return z instanceof T ? z : new T(function(N) {
        N(z);
      });
    }
    return new (T || (T = Promise))(function(z, N) {
      function j(Z) {
        try {
          ye(B.next(Z));
        } catch (pe) {
          N(pe);
        }
      }
      function W(Z) {
        try {
          ye(B.throw(Z));
        } catch (pe) {
          N(pe);
        }
      }
      function ye(Z) {
        Z.done ? z(Z.value) : $(Z.value).then(j, W);
      }
      ye((B = B.apply(w, C || [])).next());
    });
  };
  let { numBars: i = 16 } = e, { stream_state: l = "closed" } = e, { audio_source_callback: s } = e, { icon: o = void 0 } = e, { icon_button_color: d = "var(--body-text-color)" } = e, { pulse_color: h = "var(--body-text-color)" } = e, f, p, _, y, S = 1, E = 0;
  Hd(() => {
    y && cancelAnimationFrame(y), f && f.close();
  });
  function A() {
    return a(this, void 0, void 0, function* () {
      const w = new (window.AudioContext || window.webkitAudioContext)(), C = yield navigator.mediaDevices.getUserMedia({ audio: !0 }), T = yield s(), B = w.createMediaStreamSource(C), $ = w.createMediaStreamSource(T), z = w.createMediaStreamDestination();
      return B.connect(z), $.connect(z), z.stream;
    });
  }
  function b() {
    return a(this, void 0, void 0, function* () {
      f = new (window.AudioContext || window.webkitAudioContext)(), p = f.createAnalyser();
      const w = yield A();
      f.createMediaStreamSource(w).connect(p), p.fftSize = 64, p.smoothingTimeConstant = 0.8, _ = new Uint8Array(p.frequencyBinCount), v();
    });
  }
  function v() {
    if (p.getByteFrequencyData(_), o) {
      const C = Array.from(_).reduce((T, B) => T + B, 0) / _.length / 255;
      t(4, S = 1 + C * 0.15), t(5, E = C);
    } else {
      const w = document.querySelectorAll(".gradio-audio-waveContainer .gradio-audio-box");
      for (let C = 0; C < w.length; C++) {
        const T = _[C] / 255;
        w[C].style.transform = `scaleY(${Math.max(0.1, T)})`;
      }
    }
    y = requestAnimationFrame(v);
  }
  return n.$$set = (w) => {
    "numBars" in w && t(0, i = w.numBars), "stream_state" in w && t(7, l = w.stream_state), "audio_source_callback" in w && t(8, s = w.audio_source_callback), "icon" in w && t(1, o = w.icon), "icon_button_color" in w && t(2, d = w.icon_button_color), "pulse_color" in w && t(3, h = w.pulse_color);
  }, n.$$.update = () => {
    n.$$.dirty & /*icon, numBars*/
    3 && t(6, r = o ? "128px" : `calc((var(--boxSize) + var(--gutter)) * ${i})`), n.$$.dirty & /*stream_state*/
    128 && l === "open" && b();
  }, [
    i,
    o,
    d,
    h,
    S,
    E,
    r,
    l,
    s
  ];
}
class Wd extends Id {
  constructor(e) {
    super(), Od(this, e, jd, Gd, Pd, {
      numBars: 0,
      stream_state: 7,
      audio_source_callback: 8,
      icon: 1,
      icon_button_color: 2,
      pulse_color: 3
    });
  }
}
const {
  SvelteComponent: Yd,
  append_hydration: R0,
  attr: fe,
  binding_callbacks: ms,
  check_outros: du,
  children: Xt,
  claim_component: Xd,
  claim_element: On,
  claim_space: hu,
  claim_svg_element: Cn,
  create_component: Zd,
  destroy_component: Kd,
  detach: it,
  element: Pn,
  get_svelte_dataset: Qd,
  group_outros: mu,
  init: Jd,
  insert_hydration: $n,
  listen: oa,
  mount_component: eh,
  noop: hr,
  run_all: th,
  safe_not_equal: nh,
  space: fu,
  svg_element: Tn,
  toggle_class: ua,
  transition_in: _r,
  transition_out: gr
} = window.__gradio__svelte__internal, { createEventDispatcher: rh, onMount: ah } = window.__gradio__svelte__internal;
function ih(n) {
  let e, t, r, a, i, l, s, o, d;
  const h = [oh, sh], f = [];
  function p(_, y) {
    return (
      /*stream_state*/
      _[8] === "open" ? 0 : 1
    );
  }
  return e = p(n), t = f[e] = h[e](n), {
    c() {
      t.c(), r = fu(), a = Pn("button"), i = Tn("svg"), l = Tn("rect"), this.h();
    },
    l(_) {
      t.l(_), r = hu(_), a = On(_, "BUTTON", { class: !0, title: !0 });
      var y = Xt(a);
      i = Cn(y, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var S = Xt(i);
      l = Cn(S, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), Xt(l).forEach(it), S.forEach(it), y.forEach(it), this.h();
    },
    h() {
      fe(l, "x", "8"), fe(l, "y", "8"), fe(l, "width", "8"), fe(l, "height", "8"), fe(l, "rx", "1"), fe(l, "ry", "1"), fe(i, "xmlns", "http://www.w3.org/2000/svg"), fe(i, "width", "100%"), fe(i, "height", "100%"), fe(i, "viewBox", "0 0 24 24"), fe(i, "stroke-linecap", "round"), fe(i, "stroke-linejoin", "round"), fe(i, "class", "svelte-gqmcuu"), fe(a, "class", "stop-audio-button svelte-gqmcuu"), fe(
        a,
        "title",
        /*stop_audio_btn_title*/
        n[6]
      ), a.disabled = /*disabled*/
      n[7];
    },
    m(_, y) {
      f[e].m(_, y), $n(_, r, y), $n(_, a, y), R0(a, i), R0(i, l), s = !0, o || (d = oa(
        a,
        "click",
        /*handle_end_streaming_click*/
        n[14]
      ), o = !0);
    },
    p(_, y) {
      let S = e;
      e = p(_), e === S ? f[e].p(_, y) : (mu(), gr(f[S], 1, 1, () => {
        f[S] = null;
      }), du(), t = f[e], t ? t.p(_, y) : (t = f[e] = h[e](_), t.c()), _r(t, 1), t.m(r.parentNode, r)), (!s || y[0] & /*stop_audio_btn_title*/
      64) && fe(
        a,
        "title",
        /*stop_audio_btn_title*/
        _[6]
      ), (!s || y[0] & /*disabled*/
      128) && (a.disabled = /*disabled*/
      _[7]);
    },
    i(_) {
      s || (_r(t), s = !0);
    },
    o(_) {
      gr(t), s = !1;
    },
    d(_) {
      _ && (it(r), it(a)), f[e].d(_), o = !1, d();
    }
  };
}
function lh(n) {
  let e, t, r, a, i, l, s;
  return {
    c() {
      e = Pn("button"), t = Tn("svg"), r = Tn("path"), a = Tn("path"), i = Tn("line"), this.h();
    },
    l(o) {
      e = On(o, "BUTTON", { class: !0, title: !0 });
      var d = Xt(e);
      t = Cn(d, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      });
      var h = Xt(t);
      r = Cn(h, "path", { d: !0 }), Xt(r).forEach(it), a = Cn(h, "path", { d: !0 }), Xt(a).forEach(it), i = Cn(h, "line", { x1: !0, x2: !0, y1: !0, y2: !0 }), Xt(i).forEach(it), h.forEach(it), d.forEach(it), this.h();
    },
    h() {
      fe(r, "d", "M12 4a2.4 2.4 0 0 0-2.4 2.4v5.6a2.4 2.4 0 0 0 4.8 0V6.4a2.4 2.4 0 0 0-2.4-2.4Z"), fe(a, "d", "M17.6 10.4v1.6a5.6 5.6 0 0 1-11.2 0v-1.6"), fe(i, "x1", "12"), fe(i, "x2", "12"), fe(i, "y1", "17.6"), fe(i, "y2", "20"), fe(t, "xmlns", "http://www.w3.org/2000/svg"), fe(t, "width", "100%"), fe(t, "height", "100%"), fe(t, "viewBox", "0 0 24 24"), fe(t, "fill", "none"), fe(t, "stroke", "currentColor"), fe(t, "stroke-width", "1.5"), fe(t, "stroke-linecap", "round"), fe(t, "stroke-linejoin", "round"), fe(e, "class", "audio-button svelte-gqmcuu"), fe(
        e,
        "title",
        /*audio_btn_title*/
        n[5]
      ), e.disabled = /*disabled*/
      n[7], ua(
        e,
        "padded-button",
        /*audio_btn*/
        n[4] !== !0
      );
    },
    m(o, d) {
      $n(o, e, d), R0(e, t), R0(t, r), R0(t, a), R0(t, i), l || (s = oa(
        e,
        "click",
        /*handle_audio_click*/
        n[13]
      ), l = !0);
    },
    p(o, d) {
      d[0] & /*audio_btn_title*/
      32 && fe(
        e,
        "title",
        /*audio_btn_title*/
        o[5]
      ), d[0] & /*disabled*/
      128 && (e.disabled = /*disabled*/
      o[7]), d[0] & /*audio_btn*/
      16 && ua(
        e,
        "padded-button",
        /*audio_btn*/
        o[4] !== !0
      );
    },
    i: hr,
    o: hr,
    d(o) {
      o && it(e), l = !1, s();
    }
  };
}
function sh(n) {
  let e, t = '<span class="svelte-gqmcuu">·</span><span class="svelte-gqmcuu">·</span><span class="svelte-gqmcuu">·</span>';
  return {
    c() {
      e = Pn("div"), e.innerHTML = t, this.h();
    },
    l(r) {
      e = On(r, "DIV", { class: !0, "data-svelte-h": !0 }), Qd(e) !== "svelte-y8y9ab" && (e.innerHTML = t), this.h();
    },
    h() {
      fe(e, "class", "audio-blinker svelte-gqmcuu");
    },
    m(r, a) {
      $n(r, e, a);
    },
    p: hr,
    i: hr,
    o: hr,
    d(r) {
      r && it(e);
    }
  };
}
function oh(n) {
  let e, t, r;
  return t = new Wd({
    props: {
      audio_source_callback: (
        /*audio_source_callback*/
        n[11]
      ),
      stream_state: (
        /*stream_state*/
        n[8]
      ),
      icon: (
        /*icon*/
        n[1]
      ),
      icon_button_color: (
        /*icon_button_color*/
        n[2]
      ),
      pulse_color: (
        /*pulse_color*/
        n[3]
      )
    }
  }), {
    c() {
      e = Pn("div"), Zd(t.$$.fragment), this.h();
    },
    l(a) {
      e = On(a, "DIV", { class: !0 });
      var i = Xt(e);
      Xd(t.$$.fragment, i), i.forEach(it), this.h();
    },
    h() {
      fe(e, "class", "audiowave svelte-gqmcuu");
    },
    m(a, i) {
      $n(a, e, i), eh(t, e, null), r = !0;
    },
    p(a, i) {
      const l = {};
      i[0] & /*stream_state*/
      256 && (l.stream_state = /*stream_state*/
      a[8]), i[0] & /*icon*/
      2 && (l.icon = /*icon*/
      a[1]), i[0] & /*icon_button_color*/
      4 && (l.icon_button_color = /*icon_button_color*/
      a[2]), i[0] & /*pulse_color*/
      8 && (l.pulse_color = /*pulse_color*/
      a[3]), t.$set(l);
    },
    i(a) {
      r || (_r(t.$$.fragment, a), r = !0);
    },
    o(a) {
      gr(t.$$.fragment, a), r = !1;
    },
    d(a) {
      a && it(e), Kd(t);
    }
  };
}
function uh(n) {
  let e, t, r, a, i, l, s, o, d;
  const h = [lh, ih], f = [];
  function p(_, y) {
    return (
      /*audio_btn*/
      _[4] ? 0 : (
        /*stream_state*/
        _[8] === "open" || /*stream_state*/
        _[8] === "waiting" ? 1 : -1
      )
    );
  }
  return ~(a = p(n)) && (i = f[a] = h[a](n)), {
    c() {
      e = Pn("div"), t = Pn("audio"), r = fu(), i && i.c(), this.h();
    },
    l(_) {
      e = On(_, "DIV", { class: !0 });
      var y = Xt(e);
      t = On(y, "AUDIO", { class: !0 }), Xt(t).forEach(it), r = hu(y), i && i.l(y), y.forEach(it), this.h();
    },
    h() {
      fe(t, "class", "standard-player svelte-gqmcuu"), ua(
        t,
        "hidden",
        /*value*/
        n[0] === "__webrtc_value__"
      ), fe(e, "class", l = "audio-container" + /*audio_btn*/
      (n[4] ? "" : " large") + " svelte-gqmcuu");
    },
    m(_, y) {
      $n(_, e, y), R0(e, t), n[27](t), R0(e, r), ~a && f[a].m(e, null), n[30](e), s = !0, o || (d = [
        oa(
          t,
          "ended",
          /*ended_handler*/
          n[28]
        ),
        oa(
          t,
          "play",
          /*play_handler*/
          n[29]
        )
      ], o = !0);
    },
    p(_, y) {
      (!s || y[0] & /*value*/
      1) && ua(
        t,
        "hidden",
        /*value*/
        _[0] === "__webrtc_value__"
      );
      let S = a;
      a = p(_), a === S ? ~a && f[a].p(_, y) : (i && (mu(), gr(f[S], 1, 1, () => {
        f[S] = null;
      }), du()), ~a ? (i = f[a], i ? i.p(_, y) : (i = f[a] = h[a](_), i.c()), _r(i, 1), i.m(e, null)) : i = null), (!s || y[0] & /*audio_btn*/
      16 && l !== (l = "audio-container" + /*audio_btn*/
      (_[4] ? "" : " large") + " svelte-gqmcuu")) && fe(e, "class", l);
    },
    i(_) {
      s || (_r(i), s = !0);
    },
    o(_) {
      gr(i), s = !1;
    },
    d(_) {
      _ && it(e), n[27](null), ~a && f[a].d(), n[30](null), o = !1, th(d);
    }
  };
}
function ch(n, e, t) {
  var r = this && this.__awaiter || function(L, he, we, R) {
    function te(ae) {
      return ae instanceof we ? ae : new we(function(ue) {
        ue(ae);
      });
    }
    return new (we || (we = Promise))(function(ae, ue) {
      function _e(ze) {
        try {
          je(R.next(ze));
        } catch (Xe) {
          ue(Xe);
        }
      }
      function Le(ze) {
        try {
          je(R.throw(ze));
        } catch (Xe) {
          ue(Xe);
        }
      }
      function je(ze) {
        ze.done ? ae(ze.value) : te(ze.value).then(_e, Le);
      }
      je((R = R.apply(L, he || [])).next());
    });
  };
  let { mode: a } = e, { value: i = null } = e, { rtc_configuration: l = null } = e, { i18n: s } = e, { time_limit: o = null } = e, { track_constraints: d = {} } = e, { rtp_params: h = {} } = e, { on_change_cb: f } = e, { icon: p = void 0 } = e, { icon_button_color: _ = "var(--body-text-color)" } = e, { pulse_color: y = "var(--body-text-color)" } = e, { audio_btn: S = !1 } = e, { audio_btn_title: E = "" } = e, { handle_audio_click_visibility: A = function() {
  } } = e, { stop_audio_btn_title: b = "" } = e, { handle_end_streaming_click_visibility: v = function() {
  } } = e, { disabled: w = !1 } = e, C = !1, T;
  ah(() => {
    i === "__webrtc_value__" && t(26, T = new Audio("https://huggingface.co/datasets/freddyaboulton/bucket/resolve/main/pop-sounds.mp3"));
  });
  let B = (L) => {
    L === "stopword" ? (console.log("stopword recognized"), t(25, C = !0), setTimeout(
      () => {
        t(25, C = !1);
      },
      3e3
    )) : f(L);
  }, { server: $ } = e, z = "closed", N, j, W, ye = null, Z, pe, ke = null;
  const Re = () => (console.log("stream in callback", Z), a === "send" ? Z : N.srcObject), se = rh();
  function Ae() {
    return r(this, void 0, void 0, function* () {
      try {
        const he = ke ? Object.assign(
          {
            deviceId: { exact: ke.deviceId }
          },
          d
        ) : d;
        Z = yield navigator.mediaDevices.getUserMedia({ audio: he });
      } catch (he) {
        if (!navigator.mediaDevices) {
          se("error", s("audio.no_device_support"));
          return;
        }
        if (he instanceof DOMException && he.name == "NotAllowedError") {
          se("error", s("audio.allow_recording_access"));
          return;
        }
        throw he;
      }
      pe = Nd(yield qd(), "audioinput");
      const L = Z.getTracks().map((he) => {
        var we;
        return (we = he.getSettings()) === null || we === void 0 ? void 0 : we.deviceId;
      })[0];
      ke = L && pe.find((he) => he.deviceId === L) || pe[0];
    });
  }
  function xe() {
    return r(this, void 0, void 0, function* () {
      Z && (Z.getTracks().forEach((L) => L.stop()), Z = null);
    });
  }
  function ie() {
    return r(this, void 0, void 0, function* () {
      if (z === "open" || z === "waiting") {
        t(8, z = "waiting"), Va(W), yield xe(), t(8, z = "closed");
        return;
      }
      t(8, z = "waiting"), ye = Math.random().toString(36).substring(2), t(0, i = ye), console.log(i), W = new RTCPeerConnection(l), W.addEventListener("connectionstatechange", (L) => r(this, void 0, void 0, function* () {
        switch (console.log("connection state change:", W.connectionState), W.connectionState) {
          case "connected":
            console.info("connected"), t(8, z = "open");
            break;
          case "disconnected":
          case "failed":
          case "closed":
            console.info("closed"), t(8, z = "closed"), Va(W), se("stop_recording");
            break;
        }
      })), W.addEventListener("iceconnectionstatechange", (L) => r(this, void 0, void 0, function* () {
        console.info("ICE connection state change:", W.iceConnectionState), (W.iceConnectionState === "failed" || W.iceConnectionState === "disconnected" || W.iceConnectionState === "closed") && (yield Va(W));
      })), Z = null;
      try {
        yield Ae();
      } catch (L) {
        if (!navigator.mediaDevices) {
          se("error", s("audio.no_device_support"));
          return;
        }
        if (L instanceof DOMException && L.name == "NotAllowedError") {
          se("error", s("audio.allow_recording_access"));
          return;
        }
        throw L;
      }
      Z != null && (Rd(N), Md(Z, W, a === "send" ? null : N, $.offer, ye, "audio", B, h).then((L) => {
        W = L;
      }).catch((L) => {
        console.error("interactive audio error: ", L);
      }));
    });
  }
  function ce() {
    A(), ie();
  }
  function de() {
    v(), z === "open" || z === "waiting" ? ie() : t(8, z = "closed");
  }
  function ge(L) {
    ms[L ? "unshift" : "push"](() => {
      N = L, t(9, N);
    });
  }
  const P = () => se("stop"), Ie = () => se("play");
  function Ee(L) {
    ms[L ? "unshift" : "push"](() => {
      j = L, t(10, j);
    });
  }
  return n.$$set = (L) => {
    "mode" in L && t(15, a = L.mode), "value" in L && t(0, i = L.value), "rtc_configuration" in L && t(16, l = L.rtc_configuration), "i18n" in L && t(17, s = L.i18n), "time_limit" in L && t(18, o = L.time_limit), "track_constraints" in L && t(19, d = L.track_constraints), "rtp_params" in L && t(20, h = L.rtp_params), "on_change_cb" in L && t(21, f = L.on_change_cb), "icon" in L && t(1, p = L.icon), "icon_button_color" in L && t(2, _ = L.icon_button_color), "pulse_color" in L && t(3, y = L.pulse_color), "audio_btn" in L && t(4, S = L.audio_btn), "audio_btn_title" in L && t(5, E = L.audio_btn_title), "handle_audio_click_visibility" in L && t(22, A = L.handle_audio_click_visibility), "stop_audio_btn_title" in L && t(6, b = L.stop_audio_btn_title), "handle_end_streaming_click_visibility" in L && t(23, v = L.handle_end_streaming_click_visibility), "disabled" in L && t(7, w = L.disabled), "server" in L && t(24, $ = L.server);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*stopword_recognized, notification_sound*/
    100663296 && C && T.play();
  }, [
    i,
    p,
    _,
    y,
    S,
    E,
    b,
    w,
    z,
    N,
    j,
    Re,
    se,
    ce,
    de,
    a,
    l,
    s,
    o,
    d,
    h,
    f,
    A,
    v,
    $,
    C,
    T,
    ge,
    P,
    Ie,
    Ee
  ];
}
class dh extends Yd {
  constructor(e) {
    super(), Jd(
      this,
      e,
      ch,
      uh,
      nh,
      {
        mode: 15,
        value: 0,
        rtc_configuration: 16,
        i18n: 17,
        time_limit: 18,
        track_constraints: 19,
        rtp_params: 20,
        on_change_cb: 21,
        icon: 1,
        icon_button_color: 2,
        pulse_color: 3,
        audio_btn: 4,
        audio_btn_title: 5,
        handle_audio_click_visibility: 22,
        stop_audio_btn_title: 6,
        handle_end_streaming_click_visibility: 23,
        disabled: 7,
        server: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: hh,
  action_destroyer: mh,
  add_flush_callback: Wr,
  append_hydration: Ft,
  attr: K,
  bind: Yr,
  binding_callbacks: un,
  bubble: $r,
  check_outros: bi,
  children: wt,
  claim_component: pu,
  claim_element: rn,
  claim_space: lr,
  claim_svg_element: cn,
  claim_text: fh,
  create_component: _u,
  destroy_component: gu,
  detach: Ye,
  element: an,
  empty: fs,
  group_outros: yi,
  init: ph,
  insert_hydration: U0,
  is_function: _h,
  listen: vt,
  mount_component: vu,
  noop: N0,
  prevent_default: gh,
  run_all: vh,
  safe_not_equal: bh,
  set_data: yh,
  set_input_value: ps,
  space: sr,
  svg_element: dn,
  text: wh,
  toggle_class: r0,
  transition_in: a0,
  transition_out: I0
} = window.__gradio__svelte__internal, { beforeUpdate: kh, afterUpdate: Dh, createEventDispatcher: Sh, tick: _s } = window.__gradio__svelte__internal;
function gs(n) {
  let e, t, r, a, i, l, s, o, d, h;
  function f(b) {
    n[66](b);
  }
  function p(b) {
    n[67](b);
  }
  function _(b) {
    n[68](b);
  }
  let y = {
    file_count: (
      /*file_count*/
      n[19]
    ),
    filetype: (
      /*file_types*/
      n[15]
    ),
    root: (
      /*root*/
      n[14]
    ),
    max_file_size: (
      /*max_file_size*/
      n[16]
    ),
    show_progress: !1,
    disable_click: !0,
    hidden: !0,
    upload: (
      /*upload*/
      n[17]
    ),
    stream_handler: (
      /*stream_handler*/
      n[18]
    )
  };
  /*dragging*/
  n[2] !== void 0 && (y.dragging = /*dragging*/
  n[2]), /*uploading*/
  n[32] !== void 0 && (y.uploading = /*uploading*/
  n[32]), /*hidden_upload*/
  n[35] !== void 0 && (y.hidden_upload = /*hidden_upload*/
  n[35]), e = new _1({ props: y }), n[65](e), un.push(() => Yr(e, "dragging", f)), un.push(() => Yr(e, "uploading", p)), un.push(() => Yr(e, "hidden_upload", _)), e.$on(
    "load",
    /*handle_upload*/
    n[45]
  ), e.$on(
    "error",
    /*error_handler*/
    n[69]
  );
  function S(b, v) {
    return (
      /*upload_btn*/
      b[8] === !0 ? xh : Ah
    );
  }
  let E = S(n), A = E(n);
  return {
    c() {
      _u(e.$$.fragment), i = sr(), l = an("button"), A.c(), this.h();
    },
    l(b) {
      pu(e.$$.fragment, b), i = lr(b), l = rn(b, "BUTTON", {
        "data-testid": !0,
        class: !0,
        title: !0,
        style: !0
      });
      var v = wt(l);
      A.l(v), v.forEach(Ye), this.h();
    },
    h() {
      K(l, "data-testid", "upload-button"), K(l, "class", "upload-button svelte-1mynk12"), K(
        l,
        "title",
        /*upload_btn_title*/
        n[37]
      ), l.disabled = /*disabled*/
      n[1], K(l, "style", s = `${/*stop_audio_btn*/
      n[21] ? "display: none;" : ""}`);
    },
    m(b, v) {
      vu(e, b, v), U0(b, i, v), U0(b, l, v), A.m(l, null), o = !0, d || (h = vt(
        l,
        "click",
        /*handle_upload_click*/
        n[46]
      ), d = !0);
    },
    p(b, v) {
      const w = {};
      v[0] & /*file_count*/
      524288 && (w.file_count = /*file_count*/
      b[19]), v[0] & /*file_types*/
      32768 && (w.filetype = /*file_types*/
      b[15]), v[0] & /*root*/
      16384 && (w.root = /*root*/
      b[14]), v[0] & /*max_file_size*/
      65536 && (w.max_file_size = /*max_file_size*/
      b[16]), v[0] & /*upload*/
      131072 && (w.upload = /*upload*/
      b[17]), v[0] & /*stream_handler*/
      262144 && (w.stream_handler = /*stream_handler*/
      b[18]), !t && v[0] & /*dragging*/
      4 && (t = !0, w.dragging = /*dragging*/
      b[2], Wr(() => t = !1)), !r && v[1] & /*uploading*/
      2 && (r = !0, w.uploading = /*uploading*/
      b[32], Wr(() => r = !1)), !a && v[1] & /*hidden_upload*/
      16 && (a = !0, w.hidden_upload = /*hidden_upload*/
      b[35], Wr(() => a = !1)), e.$set(w), E === (E = S(b)) && A ? A.p(b, v) : (A.d(1), A = E(b), A && (A.c(), A.m(l, null))), (!o || v[1] & /*upload_btn_title*/
      64) && K(
        l,
        "title",
        /*upload_btn_title*/
        b[37]
      ), (!o || v[0] & /*disabled*/
      2) && (l.disabled = /*disabled*/
      b[1]), (!o || v[0] & /*stop_audio_btn*/
      2097152 && s !== (s = `${/*stop_audio_btn*/
      b[21] ? "display: none;" : ""}`)) && K(l, "style", s);
    },
    i(b) {
      o || (a0(e.$$.fragment, b), o = !0);
    },
    o(b) {
      I0(e.$$.fragment, b), o = !1;
    },
    d(b) {
      b && (Ye(i), Ye(l)), n[65](null), gu(e, b), A.d(), d = !1, h();
    }
  };
}
function Ah(n) {
  let e;
  return {
    c() {
      e = wh(
        /*upload_btn*/
        n[8]
      );
    },
    l(t) {
      e = fh(
        t,
        /*upload_btn*/
        n[8]
      );
    },
    m(t, r) {
      U0(t, e, r);
    },
    p(t, r) {
      r[0] & /*upload_btn*/
      256 && yh(
        e,
        /*upload_btn*/
        t[8]
      );
    },
    d(t) {
      t && Ye(e);
    }
  };
}
function xh(n) {
  let e, t, r;
  return {
    c() {
      e = dn("svg"), t = dn("path"), r = dn("path"), this.h();
    },
    l(a) {
      e = cn(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      });
      var i = wt(e);
      t = cn(i, "path", { d: !0, "stroke-width": !0 }), wt(t).forEach(Ye), r = cn(i, "path", { d: !0, "stroke-width": !0 }), wt(r).forEach(Ye), i.forEach(Ye), this.h();
    },
    h() {
      K(t, "d", "M12 5L12 19"), K(t, "stroke-width", "1.3"), K(r, "d", "M5 12L19 12"), K(r, "stroke-width", "1.3"), K(e, "xmlns", "http://www.w3.org/2000/svg"), K(e, "width", "100%"), K(e, "height", "100%"), K(e, "viewBox", "0 0 24 24"), K(e, "stroke-linecap", "round"), K(e, "stroke-linejoin", "round");
    },
    m(a, i) {
      U0(a, e, i), Ft(e, t), Ft(e, r);
    },
    p: N0,
    d(a) {
      a && Ye(e);
    }
  };
}
function vs(n) {
  let e, t, r, a;
  const i = [Eh, Fh], l = [];
  function s(o, d) {
    return (
      /*mode*/
      (o[26] === "send-receive" || /*mode*/
      o[26] == "send") && /*modality*/
      o[25] === "video" ? 0 : (
        /*mode*/
        (o[26] === "send-receive" || /*mode*/
        o[26] === "send") && /*modality*/
        o[25] === "audio" ? 1 : -1
      )
    );
  }
  return ~(e = s(n)) && (t = l[e] = i[e](n)), {
    c() {
      t && t.c(), r = fs();
    },
    l(o) {
      t && t.l(o), r = fs();
    },
    m(o, d) {
      ~e && l[e].m(o, d), U0(o, r, d), a = !0;
    },
    p(o, d) {
      let h = e;
      e = s(o), e === h ? ~e && l[e].p(o, d) : (t && (yi(), I0(l[h], 1, 1, () => {
        l[h] = null;
      }), bi()), ~e ? (t = l[e], t ? t.p(o, d) : (t = l[e] = i[e](o), t.c()), a0(t, 1), t.m(r.parentNode, r)) : t = null);
    },
    i(o) {
      a || (a0(t), a = !0);
    },
    o(o) {
      I0(t), a = !1;
    },
    d(o) {
      o && Ye(r), ~e && l[e].d(o);
    }
  };
}
function Fh(n) {
  let e, t, r;
  function a(l) {
    n[72](l);
  }
  let i = {
    mode: (
      /*mode*/
      n[26]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[23]
    ),
    i18n: (
      /*gradio*/
      n[22].i18n
    ),
    time_limit: (
      /*time_limit*/
      n[24]
    ),
    track_constraints: (
      /*track_constraints*/
      n[28]
    ),
    rtp_params: (
      /*rtp_params*/
      n[27]
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[29]
    ),
    server: (
      /*server*/
      n[30]
    ),
    audio_btn: (
      /*audio_btn*/
      n[20]
    ),
    audio_btn_title: (
      /*audio_btn_title*/
      n[40]
    ),
    handle_audio_click_visibility: (
      /*handle_audio_click_visibility*/
      n[53]
    ),
    stop_audio_btn: (
      /*stop_audio_btn*/
      n[21]
    ),
    stop_audio_btn_title: (
      /*stop_audio_btn_title*/
      n[41]
    ),
    handle_end_streaming_click_visibility: (
      /*handle_end_streaming_click_visibility*/
      n[54]
    ),
    disabled: (
      /*disabled*/
      n[1]
    )
  };
  return (
    /*value*/
    n[0].audio !== void 0 && (i.value = /*value*/
    n[0].audio), e = new dh({ props: i }), un.push(() => Yr(e, "value", a)), e.$on(
      "tick",
      /*tick_handler*/
      n[73]
    ), e.$on(
      "error",
      /*error_handler_1*/
      n[74]
    ), e.$on(
      "stop_recording",
      /*stop_recording_handler*/
      n[75]
    ), {
      c() {
        _u(e.$$.fragment);
      },
      l(l) {
        pu(e.$$.fragment, l);
      },
      m(l, s) {
        vu(e, l, s), r = !0;
      },
      p(l, s) {
        const o = {};
        s[0] & /*mode*/
        67108864 && (o.mode = /*mode*/
        l[26]), s[0] & /*rtc_configuration*/
        8388608 && (o.rtc_configuration = /*rtc_configuration*/
        l[23]), s[0] & /*gradio*/
        4194304 && (o.i18n = /*gradio*/
        l[22].i18n), s[0] & /*time_limit*/
        16777216 && (o.time_limit = /*time_limit*/
        l[24]), s[0] & /*track_constraints*/
        268435456 && (o.track_constraints = /*track_constraints*/
        l[28]), s[0] & /*rtp_params*/
        134217728 && (o.rtp_params = /*rtp_params*/
        l[27]), s[0] & /*on_change_cb*/
        536870912 && (o.on_change_cb = /*on_change_cb*/
        l[29]), s[0] & /*server*/
        1073741824 && (o.server = /*server*/
        l[30]), s[0] & /*audio_btn*/
        1048576 && (o.audio_btn = /*audio_btn*/
        l[20]), s[1] & /*audio_btn_title*/
        512 && (o.audio_btn_title = /*audio_btn_title*/
        l[40]), s[0] & /*stop_audio_btn*/
        2097152 && (o.stop_audio_btn = /*stop_audio_btn*/
        l[21]), s[1] & /*stop_audio_btn_title*/
        1024 && (o.stop_audio_btn_title = /*stop_audio_btn_title*/
        l[41]), s[0] & /*disabled*/
        2 && (o.disabled = /*disabled*/
        l[1]), !t && s[0] & /*value*/
        1 && (t = !0, o.value = /*value*/
        l[0].audio, Wr(() => t = !1)), e.$set(o);
      },
      i(l) {
        r || (a0(e.$$.fragment, l), r = !0);
      },
      o(l) {
        I0(e.$$.fragment, l), r = !1;
      },
      d(l) {
        gu(e, l);
      }
    }
  );
}
function Eh(n) {
  return {
    c: N0,
    l: N0,
    m: N0,
    p: N0,
    i: N0,
    o: N0,
    d: N0
  };
}
function bs(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = an("button"), t = dn("svg"), r = dn("path"), this.h();
    },
    l(l) {
      e = rn(l, "BUTTON", { class: !0, title: !0 });
      var s = wt(e);
      t = cn(s, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var o = wt(t);
      r = cn(o, "path", {
        d: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), wt(r).forEach(Ye), o.forEach(Ye), s.forEach(Ye), this.h();
    },
    h() {
      K(r, "d", "M12 5V18M12 5L7 10M12 5L17 10"), K(r, "stroke-width", "1.6"), K(r, "stroke-linecap", "round"), K(r, "stroke-linejoin", "round"), K(t, "xmlns", "http://www.w3.org/2000/svg"), K(t, "width", "100%"), K(t, "height", "100%"), K(t, "viewBox", "0 0 24 24"), K(e, "class", "submit-button svelte-1mynk12"), K(
        e,
        "title",
        /*submit_btn_title*/
        n[38]
      ), e.disabled = /*disabled*/
      n[1], r0(
        e,
        "padded-button",
        /*submit_btn*/
        n[9] !== !0
      );
    },
    m(l, s) {
      U0(l, e, s), Ft(e, t), Ft(t, r), a || (i = vt(
        e,
        "click",
        /*handle_submit*/
        n[48]
      ), a = !0);
    },
    p(l, s) {
      s[1] & /*submit_btn_title*/
      128 && K(
        e,
        "title",
        /*submit_btn_title*/
        l[38]
      ), s[0] & /*disabled*/
      2 && (e.disabled = /*disabled*/
      l[1]), s[0] & /*submit_btn*/
      512 && r0(
        e,
        "padded-button",
        /*submit_btn*/
        l[9] !== !0
      );
    },
    d(l) {
      l && Ye(e), a = !1, i();
    }
  };
}
function ys(n) {
  let e, t, r, a, i;
  return {
    c() {
      e = an("button"), t = dn("svg"), r = dn("rect"), this.h();
    },
    l(l) {
      e = rn(l, "BUTTON", { class: !0, title: !0 });
      var s = wt(e);
      t = cn(s, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var o = wt(t);
      r = cn(o, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), wt(r).forEach(Ye), o.forEach(Ye), s.forEach(Ye), this.h();
    },
    h() {
      K(r, "x", "8"), K(r, "y", "8"), K(r, "width", "8"), K(r, "height", "8"), K(r, "rx", "1"), K(r, "ry", "1"), K(t, "xmlns", "http://www.w3.org/2000/svg"), K(t, "width", "100%"), K(t, "height", "100%"), K(t, "viewBox", "0 0 24 24"), K(t, "stroke-linecap", "round"), K(t, "stroke-linejoin", "round"), K(t, "class", "svelte-1mynk12"), K(e, "class", "stop-button svelte-1mynk12"), K(
        e,
        "title",
        /*stop_btn_title*/
        n[39]
      ), r0(
        e,
        "padded-button",
        /*stop_btn*/
        n[10] !== !0
      );
    },
    m(l, s) {
      U0(l, e, s), Ft(e, t), Ft(t, r), a || (i = vt(
        e,
        "click",
        /*handle_stop*/
        n[47]
      ), a = !0);
    },
    p(l, s) {
      s[1] & /*stop_btn_title*/
      256 && K(
        e,
        "title",
        /*stop_btn_title*/
        l[39]
      ), s[0] & /*stop_btn*/
      1024 && r0(
        e,
        "padded-button",
        /*stop_btn*/
        l[10] !== !0
      );
    },
    d(l) {
      l && Ye(e), a = !1, i();
    }
  };
}
function Ch(n) {
  let e, t, r, a, i, l, s, o, d, h, f, p, _, y, S = (
    /*upload_btn*/
    n[8] && gs(n)
  ), E = (
    /*use_audio_video_recording*/
    n[33] && vs(n)
  ), A = (
    /*submit_btn*/
    n[9] && bs(n)
  ), b = (
    /*stop_btn*/
    n[10] && ys(n)
  );
  return {
    c() {
      e = an("div"), t = an("label"), r = an("div"), S && S.c(), a = sr(), i = an("textarea"), d = sr(), E && E.c(), h = sr(), A && A.c(), f = sr(), b && b.c(), this.h();
    },
    l(v) {
      e = rn(v, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var w = wt(e);
      t = rn(w, "LABEL", {});
      var C = wt(t);
      r = rn(C, "DIV", { class: !0 });
      var T = wt(r);
      S && S.l(T), a = lr(T), i = rn(T, "TEXTAREA", {
        "data-testid": !0,
        class: !0,
        dir: !0,
        placeholder: !0,
        rows: !0,
        style: !0
      }), wt(i).forEach(Ye), d = lr(T), E && E.l(T), h = lr(T), A && A.l(T), f = lr(T), b && b.l(T), T.forEach(Ye), C.forEach(Ye), w.forEach(Ye), this.h();
    },
    h() {
      K(i, "data-testid", "textbox"), K(i, "class", "scroll-hide svelte-1mynk12"), K(i, "dir", l = /*rtl*/
      n[11] ? "rtl" : "ltr"), K(
        i,
        "placeholder",
        /*placeholder*/
        n[4]
      ), i.disabled = /*disabled*/
      n[1], K(
        i,
        "rows",
        /*lines*/
        n[3]
      ), i.autofocus = /*autofocus*/
      n[12], K(i, "style", s = `${/*stop_audio_btn*/
      n[21] ? "display: none; " : ""}${/*text_align*/
      n[13] ? "text-align: " + /*text_align*/
      n[13] + "; " : ""}flex-grow: 1;`), r0(i, "no-label", !/*show_label*/
      n[5]), K(r, "class", "input-container svelte-1mynk12"), r0(
        t,
        "container",
        /*container*/
        n[6]
      ), K(e, "class", "full-container svelte-1mynk12"), K(e, "role", "group"), K(e, "aria-label", "Multimedia input field"), r0(
        e,
        "dragging",
        /*dragging*/
        n[2]
      );
    },
    m(v, w) {
      U0(v, e, w), Ft(e, t), Ft(t, r), S && S.m(r, null), Ft(r, a), Ft(r, i), ps(
        i,
        /*value*/
        n[0].text
      ), n[71](i), Ft(r, d), E && E.m(r, null), Ft(r, h), A && A.m(r, null), Ft(r, f), b && b.m(r, null), n[76](e), p = !0, /*autofocus*/
      n[12] && i.focus(), _ || (y = [
        mh(o = Cd.call(null, i, {
          text: (
            /*value*/
            n[0].text
          ),
          lines: (
            /*lines*/
            n[3]
          ),
          max_lines: (
            /*max_lines*/
            n[7]
          )
        })),
        vt(
          i,
          "input",
          /*textarea_input_handler*/
          n[70]
        ),
        vt(
          i,
          "keypress",
          /*handle_keypress*/
          n[43]
        ),
        vt(
          i,
          "blur",
          /*blur_handler*/
          n[63]
        ),
        vt(
          i,
          "select",
          /*handle_select*/
          n[42]
        ),
        vt(
          i,
          "focus",
          /*focus_handler*/
          n[64]
        ),
        vt(
          i,
          "scroll",
          /*handle_scroll*/
          n[44]
        ),
        vt(
          i,
          "paste",
          /*handle_paste*/
          n[49]
        ),
        vt(
          e,
          "dragenter",
          /*handle_dragenter*/
          n[50]
        ),
        vt(
          e,
          "dragleave",
          /*handle_dragleave*/
          n[51]
        ),
        vt(e, "dragover", gh(
          /*dragover_handler*/
          n[62]
        )),
        vt(
          e,
          "drop",
          /*handle_drop*/
          n[52]
        )
      ], _ = !0);
    },
    p(v, w) {
      /*upload_btn*/
      v[8] ? S ? (S.p(v, w), w[0] & /*upload_btn*/
      256 && a0(S, 1)) : (S = gs(v), S.c(), a0(S, 1), S.m(r, a)) : S && (yi(), I0(S, 1, 1, () => {
        S = null;
      }), bi()), (!p || w[0] & /*rtl*/
      2048 && l !== (l = /*rtl*/
      v[11] ? "rtl" : "ltr")) && K(i, "dir", l), (!p || w[0] & /*placeholder*/
      16) && K(
        i,
        "placeholder",
        /*placeholder*/
        v[4]
      ), (!p || w[0] & /*disabled*/
      2) && (i.disabled = /*disabled*/
      v[1]), (!p || w[0] & /*lines*/
      8) && K(
        i,
        "rows",
        /*lines*/
        v[3]
      ), (!p || w[0] & /*autofocus*/
      4096) && (i.autofocus = /*autofocus*/
      v[12]), (!p || w[0] & /*stop_audio_btn, text_align*/
      2105344 && s !== (s = `${/*stop_audio_btn*/
      v[21] ? "display: none; " : ""}${/*text_align*/
      v[13] ? "text-align: " + /*text_align*/
      v[13] + "; " : ""}flex-grow: 1;`)) && K(i, "style", s), o && _h(o.update) && w[0] & /*value, lines, max_lines*/
      137 && o.update.call(null, {
        text: (
          /*value*/
          v[0].text
        ),
        lines: (
          /*lines*/
          v[3]
        ),
        max_lines: (
          /*max_lines*/
          v[7]
        )
      }), w[0] & /*value*/
      1 && ps(
        i,
        /*value*/
        v[0].text
      ), (!p || w[0] & /*show_label*/
      32) && r0(i, "no-label", !/*show_label*/
      v[5]), /*use_audio_video_recording*/
      v[33] ? E ? (E.p(v, w), w[1] & /*use_audio_video_recording*/
      4 && a0(E, 1)) : (E = vs(v), E.c(), a0(E, 1), E.m(r, h)) : E && (yi(), I0(E, 1, 1, () => {
        E = null;
      }), bi()), /*submit_btn*/
      v[9] ? A ? A.p(v, w) : (A = bs(v), A.c(), A.m(r, f)) : A && (A.d(1), A = null), /*stop_btn*/
      v[10] ? b ? b.p(v, w) : (b = ys(v), b.c(), b.m(r, null)) : b && (b.d(1), b = null), (!p || w[0] & /*container*/
      64) && r0(
        t,
        "container",
        /*container*/
        v[6]
      ), (!p || w[0] & /*dragging*/
      4) && r0(
        e,
        "dragging",
        /*dragging*/
        v[2]
      );
    },
    i(v) {
      p || (a0(S), a0(E), p = !0);
    },
    o(v) {
      I0(S), I0(E), p = !1;
    },
    d(v) {
      v && Ye(e), S && S.d(), n[71](null), E && E.d(), A && A.d(), b && b.d(), n[76](null), _ = !1, vh(y);
    }
  };
}
function Th(n, e, t) {
  var r = this && this.__awaiter || function(q, qe, tt, Ce) {
    function kt(z0) {
      return z0 instanceof tt ? z0 : new tt(function(W0) {
        W0(z0);
      });
    }
    return new (tt || (tt = Promise))(function(z0, W0) {
      function Zn(Jt) {
        try {
          Dt(Ce.next(Jt));
        } catch (kn) {
          W0(kn);
        }
      }
      function Fr(Jt) {
        try {
          Dt(Ce.throw(Jt));
        } catch (kn) {
          W0(kn);
        }
      }
      function Dt(Jt) {
        Jt.done ? z0(Jt.value) : kt(Jt.value).then(Zn, Fr);
      }
      Dt((Ce = Ce.apply(q, qe || [])).next());
    });
  };
  let { value: a = {
    text: "",
    files: [],
    audio: "__webrtc_value__"
  } } = e, { value_is_output: i = !1 } = e, { lines: l = 1 } = e, { placeholder: s = "Type here..." } = e, { disabled: o = !1 } = e, { interactive: d } = e, { loading_message: h } = e, { show_label: f = !0 } = e, { container: p = !0 } = e, { max_lines: _ } = e, { upload_btn: y = null } = e, { submit_btn: S = null } = e, { stop_btn: E = null } = e, { rtl: A = !1 } = e, { autofocus: b = !1 } = e, { text_align: v = void 0 } = e, { autoscroll: w = !0 } = e, { root: C } = e, { file_types: T = null } = e, { max_file_size: B = null } = e, { upload: $ } = e, { stream_handler: z } = e, { file_count: N = "multiple" } = e, { audio_btn: j = !1 } = e, { stop_audio_btn: W = !1 } = e, { gradio: ye } = e, { rtc_configuration: Z } = e, { time_limit: pe = null } = e, { modality: ke = "audio" } = e, { mode: Re = "send-receive" } = e, { rtp_params: se = {} } = e, { track_constraints: Ae = {} } = e, { on_change_cb: xe } = e, { server: ie } = e, ce, de, ge, P, Ie = 0, Ee = !1, { dragging: L = !1 } = e, he = !1, we = a.text, R, te = !1, ae = !1, ue, _e, Le, je, ze, Xe;
  navigator.language.startsWith("fr") ? (_e = "Ajouter un fichier", Le = "Poser une question", je = "Arrêter", ze = "Activer Neo audio", Xe = "Arreter Neo audio") : (_e = "Add a file", Le = "Ask a question", je = "Stop", ze = "Launch Neo audio", Xe = "Stop Neo audio");
  const Oe = Sh();
  kh(() => {
    P = ge && ge.offsetHeight + ge.scrollTop > ge.scrollHeight - 100;
  });
  const pt = () => {
    P && w && !Ee && ge.scrollTo(0, ge.scrollHeight);
  };
  function Qt() {
    return r(this, void 0, void 0, function* () {
      Oe("change", a), i || Oe("input");
    });
  }
  Dh(() => {
    b && ge !== null && ge.focus(), P && w && pt(), t(55, i = !1);
  });
  function Gn(q) {
    const qe = q.target, tt = qe.value, Ce = [qe.selectionStart, qe.selectionEnd];
    Oe("select", { value: tt.substring(...Ce), index: Ce });
  }
  function O(q) {
    return r(this, void 0, void 0, function* () {
      yield _s(), (q.key === "Enter" && q.shiftKey && l > 1 || q.key === "Enter" && !q.shiftKey && l === 1 && _ >= 1) && (q.preventDefault(), Oe("submit"));
    });
  }
  function G0(q) {
    const qe = q.target, tt = qe.scrollTop;
    tt < Ie && (Ee = !0), Ie = tt;
    const Ce = qe.scrollHeight - qe.clientHeight;
    tt >= Ce && (Ee = !1);
  }
  function E0(q) {
    return r(this, arguments, void 0, function* ({ detail: qe }) {
      if (Qt(), Array.isArray(qe)) {
        for (let tt of qe)
          a.files.push(tt);
        t(0, a), t(32, he), t(61, te), t(57, h), t(60, R);
      } else
        a.files.push(qe), t(0, a), t(32, he), t(61, te), t(57, h), t(60, R);
      yield _s(), Oe("change", a), Oe("upload", qe);
    });
  }
  function C0() {
    de && (t(35, de.value = "", de), de.click());
  }
  function kr() {
    Oe("stop");
  }
  function Dr() {
    Oe("submit");
  }
  function Sr(q) {
    if (!q.clipboardData) return;
    const qe = q.clipboardData.items;
    for (let tt in qe) {
      const Ce = qe[tt];
      if (Ce.type.includes("text/plain"))
        break;
      if (Ce.kind === "file" && Ce.type.includes("image")) {
        const kt = Ce.getAsFile();
        kt && ce.load_files([kt]);
      }
    }
  }
  function jn(q) {
    q.preventDefault(), t(2, L = !0);
  }
  function Ar(q) {
    q.preventDefault();
    const qe = ue.getBoundingClientRect(), { clientX: tt, clientY: Ce } = q;
    (tt <= qe.left || tt >= qe.right || Ce <= qe.top || Ce >= qe.bottom) && t(2, L = !1);
  }
  function vn(q) {
    q.preventDefault(), t(2, L = !1), q.dataTransfer && q.dataTransfer.files && ce.load_files(Array.from(q.dataTransfer.files));
  }
  function bn() {
    Oe("start_recording");
  }
  function Ht() {
    Oe("stop_recording");
  }
  function T0(q) {
    $r.call(this, n, q);
  }
  function Wn(q) {
    $r.call(this, n, q);
  }
  function Yn(q) {
    $r.call(this, n, q);
  }
  function ya(q) {
    un[q ? "unshift" : "push"](() => {
      ce = q, t(34, ce);
    });
  }
  function yn(q) {
    L = q, t(2, L);
  }
  function wn(q) {
    he = q, t(32, he);
  }
  function wa(q) {
    de = q, t(35, de);
  }
  function j0(q) {
    $r.call(this, n, q);
  }
  function ka() {
    a.text = this.value, t(0, a), t(32, he), t(61, te), t(57, h), t(60, R);
  }
  function Da(q) {
    un[q ? "unshift" : "push"](() => {
      ge = q, t(31, ge);
    });
  }
  function Qe(q) {
    n.$$.not_equal(a.audio, q) && (a.audio = q, t(0, a), t(32, he), t(61, te), t(57, h), t(60, R));
  }
  const M0 = () => ye.dispatch("tick"), Sa = ({ detail: q }) => ye.dispatch("error", q), xr = () => ye.dispatch("stop_recording");
  function Xn(q) {
    un[q ? "unshift" : "push"](() => {
      ue = q, t(36, ue);
    });
  }
  return n.$$set = (q) => {
    "value" in q && t(0, a = q.value), "value_is_output" in q && t(55, i = q.value_is_output), "lines" in q && t(3, l = q.lines), "placeholder" in q && t(4, s = q.placeholder), "disabled" in q && t(1, o = q.disabled), "interactive" in q && t(56, d = q.interactive), "loading_message" in q && t(57, h = q.loading_message), "show_label" in q && t(5, f = q.show_label), "container" in q && t(6, p = q.container), "max_lines" in q && t(7, _ = q.max_lines), "upload_btn" in q && t(8, y = q.upload_btn), "submit_btn" in q && t(9, S = q.submit_btn), "stop_btn" in q && t(10, E = q.stop_btn), "rtl" in q && t(11, A = q.rtl), "autofocus" in q && t(12, b = q.autofocus), "text_align" in q && t(13, v = q.text_align), "autoscroll" in q && t(58, w = q.autoscroll), "root" in q && t(14, C = q.root), "file_types" in q && t(15, T = q.file_types), "max_file_size" in q && t(16, B = q.max_file_size), "upload" in q && t(17, $ = q.upload), "stream_handler" in q && t(18, z = q.stream_handler), "file_count" in q && t(19, N = q.file_count), "audio_btn" in q && t(20, j = q.audio_btn), "stop_audio_btn" in q && t(21, W = q.stop_audio_btn), "gradio" in q && t(22, ye = q.gradio), "rtc_configuration" in q && t(23, Z = q.rtc_configuration), "time_limit" in q && t(24, pe = q.time_limit), "modality" in q && t(25, ke = q.modality), "mode" in q && t(26, Re = q.mode), "rtp_params" in q && t(27, se = q.rtp_params), "track_constraints" in q && t(28, Ae = q.track_constraints), "on_change_cb" in q && t(29, xe = q.on_change_cb), "server" in q && t(30, ie = q.server), "dragging" in q && t(2, L = q.dragging);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*dragging*/
    4 && Oe("drag", L), n.$$.dirty[0] & /*audio_btn*/
    1048576 | n.$$.dirty[1] & /*use_audio_video_recording*/
    4 && j && !ae && t(33, ae = j), n.$$.dirty[0] & /*value*/
    1 && a === null && t(0, a = { text: "", files: [], audio: null }), n.$$.dirty[0] & /*value*/
    1 | n.$$.dirty[1] & /*uploading, retrieve_saved_message, loading_message, saved_message*/
    1677721602 && (he && !te ? (t(60, R = a.text), t(61, te = !0), t(0, a.text = h, a), console.log("value.text uploading", a.text)) : !he && te && (t(0, a.text = R, a), t(61, te = !1), console.log("value.text end of uploading", a.text))), n.$$.dirty[0] & /*value*/
    1 | n.$$.dirty[1] & /*oldValue, uploading, retrieve_saved_message*/
    1342177282 && we !== a.text && !he && !te && (t(59, we = a.text), Oe("change", a)), n.$$.dirty[1] & /*uploading*/
    2 && he && console.log("uploading"), n.$$.dirty[1] & /*interactive, uploading*/
    33554434 && t(1, o = !d || he), n.$$.dirty[0] & /*disabled*/
    2 && o && console.log("disabled"), n.$$.dirty[0] & /*value, lines, max_lines*/
    137 | n.$$.dirty[1] & /*el, uploading*/
    3 && ge && l !== _ && gi(ge, l, _, he);
  }, [
    a,
    o,
    L,
    l,
    s,
    f,
    p,
    _,
    y,
    S,
    E,
    A,
    b,
    v,
    C,
    T,
    B,
    $,
    z,
    N,
    j,
    W,
    ye,
    Z,
    pe,
    ke,
    Re,
    se,
    Ae,
    xe,
    ie,
    ge,
    he,
    ae,
    ce,
    de,
    ue,
    _e,
    Le,
    je,
    ze,
    Xe,
    Gn,
    O,
    G0,
    E0,
    C0,
    kr,
    Dr,
    Sr,
    jn,
    Ar,
    vn,
    bn,
    Ht,
    i,
    d,
    h,
    w,
    we,
    R,
    te,
    T0,
    Wn,
    Yn,
    ya,
    yn,
    wn,
    wa,
    j0,
    ka,
    Da,
    Qe,
    M0,
    Sa,
    xr,
    Xn
  ];
}
class Mh extends hh {
  constructor(e) {
    super(), ph(
      this,
      e,
      Th,
      Ch,
      bh,
      {
        value: 0,
        value_is_output: 55,
        lines: 3,
        placeholder: 4,
        disabled: 1,
        interactive: 56,
        loading_message: 57,
        show_label: 5,
        container: 6,
        max_lines: 7,
        upload_btn: 8,
        submit_btn: 9,
        stop_btn: 10,
        rtl: 11,
        autofocus: 12,
        text_align: 13,
        autoscroll: 58,
        root: 14,
        file_types: 15,
        max_file_size: 16,
        upload: 17,
        stream_handler: 18,
        file_count: 19,
        audio_btn: 20,
        stop_audio_btn: 21,
        gradio: 22,
        rtc_configuration: 23,
        time_limit: 24,
        modality: 25,
        mode: 26,
        rtp_params: 27,
        track_constraints: 28,
        on_change_cb: 29,
        server: 30,
        dragging: 2
      },
      null,
      [-1, -1, -1]
    );
  }
}
function Mn(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let r = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + r;
}
function Xr() {
}
function zh(n, e) {
  return n != n ? e == e : n !== e || n && typeof n == "object" || typeof n == "function";
}
const bu = typeof window < "u";
let ws = bu ? () => window.performance.now() : () => Date.now(), yu = bu ? (n) => requestAnimationFrame(n) : Xr;
const qn = /* @__PURE__ */ new Set();
function wu(n) {
  qn.forEach((e) => {
    e.c(n) || (qn.delete(e), e.f());
  }), qn.size !== 0 && yu(wu);
}
function Bh(n) {
  let e;
  return qn.size === 0 && yu(wu), {
    promise: new Promise((t) => {
      qn.add(e = { c: n, f: t });
    }),
    abort() {
      qn.delete(e);
    }
  };
}
const xn = [];
function qh(n, e = Xr) {
  let t;
  const r = /* @__PURE__ */ new Set();
  function a(s) {
    if (zh(n, s) && (n = s, t)) {
      const o = !xn.length;
      for (const d of r)
        d[1](), xn.push(d, n);
      if (o) {
        for (let d = 0; d < xn.length; d += 2)
          xn[d][0](xn[d + 1]);
        xn.length = 0;
      }
    }
  }
  function i(s) {
    a(s(n));
  }
  function l(s, o = Xr) {
    const d = [s, o];
    return r.add(d), r.size === 1 && (t = e(a, i) || Xr), s(n), () => {
      r.delete(d), r.size === 0 && t && (t(), t = null);
    };
  }
  return { set: a, update: i, subscribe: l };
}
function ks(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function wi(n, e, t, r) {
  if (typeof t == "number" || ks(t)) {
    const a = r - t, i = (t - e) / (n.dt || 1 / 60), l = n.opts.stiffness * a, s = n.opts.damping * i, o = (l - s) * n.inv_mass, d = (i + o) * n.dt;
    return Math.abs(d) < n.opts.precision && Math.abs(a) < n.opts.precision ? r : (n.settled = !1, ks(t) ? new Date(t.getTime() + d) : t + d);
  } else {
    if (Array.isArray(t))
      return t.map(
        (a, i) => wi(n, e[i], t[i], r[i])
      );
    if (typeof t == "object") {
      const a = {};
      for (const i in t)
        a[i] = wi(n, e[i], t[i], r[i]);
      return a;
    } else
      throw new Error(`Cannot spring ${typeof t} values`);
  }
}
function Ds(n, e = {}) {
  const t = qh(n), { stiffness: r = 0.15, damping: a = 0.8, precision: i = 0.01 } = e;
  let l, s, o, d = n, h = n, f = 1, p = 0, _ = !1;
  function y(E, A = {}) {
    h = E;
    const b = o = {};
    return n == null || A.hard || S.stiffness >= 1 && S.damping >= 1 ? (_ = !0, l = ws(), d = E, t.set(n = h), Promise.resolve()) : (A.soft && (p = 1 / ((A.soft === !0 ? 0.5 : +A.soft) * 60), f = 0), s || (l = ws(), _ = !1, s = Bh((v) => {
      if (_)
        return _ = !1, s = null, !1;
      f = Math.min(f + p, 1);
      const w = {
        inv_mass: f,
        opts: S,
        settled: !0,
        dt: (v - l) * 60 / 1e3
      }, C = wi(w, d, n, h);
      return l = v, d = n, t.set(n = C), w.settled && (s = null), !w.settled;
    })), new Promise((v) => {
      s.promise.then(() => {
        b === o && v();
      });
    }));
  }
  const S = {
    set: y,
    update: (E, A) => y(E(h, n), A),
    subscribe: t.subscribe,
    stiffness: r,
    damping: a,
    precision: i
  };
  return S;
}
const {
  SvelteComponent: Nh,
  append_hydration: Vt,
  attr: De,
  children: Mt,
  claim_element: Rh,
  claim_svg_element: Gt,
  component_subscribe: Ss,
  detach: St,
  element: Ih,
  init: Lh,
  insert_hydration: Oh,
  noop: As,
  safe_not_equal: Ph,
  set_style: Hr,
  svg_element: jt,
  toggle_class: xs
} = window.__gradio__svelte__internal, { onMount: $h } = window.__gradio__svelte__internal;
function Hh(n) {
  let e, t, r, a, i, l, s, o, d, h, f, p;
  return {
    c() {
      e = Ih("div"), t = jt("svg"), r = jt("g"), a = jt("path"), i = jt("path"), l = jt("path"), s = jt("path"), o = jt("g"), d = jt("path"), h = jt("path"), f = jt("path"), p = jt("path"), this.h();
    },
    l(_) {
      e = Rh(_, "DIV", { class: !0 });
      var y = Mt(e);
      t = Gt(y, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var S = Mt(t);
      r = Gt(S, "g", { style: !0 });
      var E = Mt(r);
      a = Gt(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Mt(a).forEach(St), i = Gt(E, "path", { d: !0, fill: !0, class: !0 }), Mt(i).forEach(St), l = Gt(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Mt(l).forEach(St), s = Gt(E, "path", { d: !0, fill: !0, class: !0 }), Mt(s).forEach(St), E.forEach(St), o = Gt(S, "g", { style: !0 });
      var A = Mt(o);
      d = Gt(A, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Mt(d).forEach(St), h = Gt(A, "path", { d: !0, fill: !0, class: !0 }), Mt(h).forEach(St), f = Gt(A, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Mt(f).forEach(St), p = Gt(A, "path", { d: !0, fill: !0, class: !0 }), Mt(p).forEach(St), A.forEach(St), S.forEach(St), y.forEach(St), this.h();
    },
    h() {
      De(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), De(a, "fill", "#FF7C00"), De(a, "fill-opacity", "0.4"), De(a, "class", "svelte-43sxxs"), De(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), De(i, "fill", "#FF7C00"), De(i, "class", "svelte-43sxxs"), De(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), De(l, "fill", "#FF7C00"), De(l, "fill-opacity", "0.4"), De(l, "class", "svelte-43sxxs"), De(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), De(s, "fill", "#FF7C00"), De(s, "class", "svelte-43sxxs"), Hr(r, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), De(d, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), De(d, "fill", "#FF7C00"), De(d, "fill-opacity", "0.4"), De(d, "class", "svelte-43sxxs"), De(h, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), De(h, "fill", "#FF7C00"), De(h, "class", "svelte-43sxxs"), De(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), De(f, "fill", "#FF7C00"), De(f, "fill-opacity", "0.4"), De(f, "class", "svelte-43sxxs"), De(p, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), De(p, "fill", "#FF7C00"), De(p, "class", "svelte-43sxxs"), Hr(o, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), De(t, "viewBox", "-1200 -1200 3000 3000"), De(t, "fill", "none"), De(t, "xmlns", "http://www.w3.org/2000/svg"), De(t, "class", "svelte-43sxxs"), De(e, "class", "svelte-43sxxs"), xs(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(_, y) {
      Oh(_, e, y), Vt(e, t), Vt(t, r), Vt(r, a), Vt(r, i), Vt(r, l), Vt(r, s), Vt(t, o), Vt(o, d), Vt(o, h), Vt(o, f), Vt(o, p);
    },
    p(_, [y]) {
      y & /*$top*/
      2 && Hr(r, "transform", "translate(" + /*$top*/
      _[1][0] + "px, " + /*$top*/
      _[1][1] + "px)"), y & /*$bottom*/
      4 && Hr(o, "transform", "translate(" + /*$bottom*/
      _[2][0] + "px, " + /*$bottom*/
      _[2][1] + "px)"), y & /*margin*/
      1 && xs(
        e,
        "margin",
        /*margin*/
        _[0]
      );
    },
    i: As,
    o: As,
    d(_) {
      _ && St(e);
    }
  };
}
function Uh(n, e, t) {
  let r, a;
  var i = this && this.__awaiter || function(_, y, S, E) {
    function A(b) {
      return b instanceof S ? b : new S(function(v) {
        v(b);
      });
    }
    return new (S || (S = Promise))(function(b, v) {
      function w(B) {
        try {
          T(E.next(B));
        } catch ($) {
          v($);
        }
      }
      function C(B) {
        try {
          T(E.throw(B));
        } catch ($) {
          v($);
        }
      }
      function T(B) {
        B.done ? b(B.value) : A(B.value).then(w, C);
      }
      T((E = E.apply(_, y || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const s = Ds([0, 0]);
  Ss(n, s, (_) => t(1, r = _));
  const o = Ds([0, 0]);
  Ss(n, o, (_) => t(2, a = _));
  let d;
  function h() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 140]), o.set([-125, -140])]), yield Promise.all([s.set([-125, 140]), o.set([125, -140])]), yield Promise.all([s.set([-125, 0]), o.set([125, -0])]), yield Promise.all([s.set([125, 0]), o.set([-125, 0])]);
    });
  }
  function f() {
    return i(this, void 0, void 0, function* () {
      yield h(), d || f();
    });
  }
  function p() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 0]), o.set([-125, 0])]), f();
    });
  }
  return $h(() => (p(), () => d = !0)), n.$$set = (_) => {
    "margin" in _ && t(0, l = _.margin);
  }, [l, r, a, s, o];
}
class Vh extends Nh {
  constructor(e) {
    super(), Lh(this, e, Uh, Hh, Ph, { margin: 0 });
  }
}
const {
  SvelteComponent: Gh,
  append_hydration: ln,
  attr: Kt,
  binding_callbacks: Fs,
  check_outros: ki,
  children: u0,
  claim_component: ku,
  claim_element: c0,
  claim_space: Nt,
  claim_text: Ve,
  create_component: Du,
  create_slot: Su,
  destroy_component: Au,
  destroy_each: xu,
  detach: ee,
  element: d0,
  empty: Ot,
  ensure_array_like: ca,
  get_all_dirty_from_scope: Fu,
  get_slot_changes: Eu,
  group_outros: Di,
  init: jh,
  insert_hydration: oe,
  mount_component: Cu,
  noop: Si,
  safe_not_equal: Wh,
  set_data: Pt,
  set_style: L0,
  space: Rt,
  text: Ge,
  toggle_class: zt,
  transition_in: Zt,
  transition_out: h0,
  update_slot_base: Tu
} = window.__gradio__svelte__internal, { tick: Yh } = window.__gradio__svelte__internal, { onDestroy: Xh } = window.__gradio__svelte__internal, { createEventDispatcher: Zh } = window.__gradio__svelte__internal, Kh = (n) => ({}), Es = (n) => ({}), Qh = (n) => ({}), Cs = (n) => ({});
function Ts(n, e, t) {
  const r = n.slice();
  return r[41] = e[t], r[43] = t, r;
}
function Ms(n, e, t) {
  const r = n.slice();
  return r[41] = e[t], r;
}
function Jh(n) {
  let e, t, r, a, i = (
    /*i18n*/
    n[1]("common.error") + ""
  ), l, s, o;
  t = new yd({
    props: {
      Icon: xd,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const d = (
    /*#slots*/
    n[30].error
  ), h = Su(
    d,
    n,
    /*$$scope*/
    n[29],
    Es
  );
  return {
    c() {
      e = d0("div"), Du(t.$$.fragment), r = Rt(), a = d0("span"), l = Ge(i), s = Rt(), h && h.c(), this.h();
    },
    l(f) {
      e = c0(f, "DIV", { class: !0 });
      var p = u0(e);
      ku(t.$$.fragment, p), p.forEach(ee), r = Nt(f), a = c0(f, "SPAN", { class: !0 });
      var _ = u0(a);
      l = Ve(_, i), _.forEach(ee), s = Nt(f), h && h.l(f), this.h();
    },
    h() {
      Kt(e, "class", "clear-status svelte-17v219f"), Kt(a, "class", "error svelte-17v219f");
    },
    m(f, p) {
      oe(f, e, p), Cu(t, e, null), oe(f, r, p), oe(f, a, p), ln(a, l), oe(f, s, p), h && h.m(f, p), o = !0;
    },
    p(f, p) {
      const _ = {};
      p[0] & /*i18n*/
      2 && (_.label = /*i18n*/
      f[1]("common.clear")), t.$set(_), (!o || p[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      f[1]("common.error") + "") && Pt(l, i), h && h.p && (!o || p[0] & /*$$scope*/
      536870912) && Tu(
        h,
        d,
        f,
        /*$$scope*/
        f[29],
        o ? Eu(
          d,
          /*$$scope*/
          f[29],
          p,
          Kh
        ) : Fu(
          /*$$scope*/
          f[29]
        ),
        Es
      );
    },
    i(f) {
      o || (Zt(t.$$.fragment, f), Zt(h, f), o = !0);
    },
    o(f) {
      h0(t.$$.fragment, f), h0(h, f), o = !1;
    },
    d(f) {
      f && (ee(e), ee(r), ee(a), ee(s)), Au(t), h && h.d(f);
    }
  };
}
function em(n) {
  let e, t, r, a, i, l, s, o, d, h = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && zs(n)
  );
  function f(v, w) {
    if (
      /*progress*/
      v[7]
    ) return rm;
    if (
      /*queue_position*/
      v[2] !== null && /*queue_size*/
      v[3] !== void 0 && /*queue_position*/
      v[2] >= 0
    ) return nm;
    if (
      /*queue_position*/
      v[2] === 0
    ) return tm;
  }
  let p = f(n), _ = p && p(n), y = (
    /*timer*/
    n[5] && Ns(n)
  );
  const S = [sm, lm], E = [];
  function A(v, w) {
    return (
      /*last_progress_level*/
      v[15] != null ? 0 : (
        /*show_progress*/
        v[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = A(n)) && (l = E[i] = S[i](n));
  let b = !/*timer*/
  n[5] && Hs(n);
  return {
    c() {
      h && h.c(), e = Rt(), t = d0("div"), _ && _.c(), r = Rt(), y && y.c(), a = Rt(), l && l.c(), s = Rt(), b && b.c(), o = Ot(), this.h();
    },
    l(v) {
      h && h.l(v), e = Nt(v), t = c0(v, "DIV", { class: !0 });
      var w = u0(t);
      _ && _.l(w), r = Nt(w), y && y.l(w), w.forEach(ee), a = Nt(v), l && l.l(v), s = Nt(v), b && b.l(v), o = Ot(), this.h();
    },
    h() {
      Kt(t, "class", "progress-text svelte-17v219f"), zt(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), zt(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(v, w) {
      h && h.m(v, w), oe(v, e, w), oe(v, t, w), _ && _.m(t, null), ln(t, r), y && y.m(t, null), oe(v, a, w), ~i && E[i].m(v, w), oe(v, s, w), b && b.m(v, w), oe(v, o, w), d = !0;
    },
    p(v, w) {
      /*variant*/
      v[8] === "default" && /*show_eta_bar*/
      v[18] && /*show_progress*/
      v[6] === "full" ? h ? h.p(v, w) : (h = zs(v), h.c(), h.m(e.parentNode, e)) : h && (h.d(1), h = null), p === (p = f(v)) && _ ? _.p(v, w) : (_ && _.d(1), _ = p && p(v), _ && (_.c(), _.m(t, r))), /*timer*/
      v[5] ? y ? y.p(v, w) : (y = Ns(v), y.c(), y.m(t, null)) : y && (y.d(1), y = null), (!d || w[0] & /*variant*/
      256) && zt(
        t,
        "meta-text-center",
        /*variant*/
        v[8] === "center"
      ), (!d || w[0] & /*variant*/
      256) && zt(
        t,
        "meta-text",
        /*variant*/
        v[8] === "default"
      );
      let C = i;
      i = A(v), i === C ? ~i && E[i].p(v, w) : (l && (Di(), h0(E[C], 1, 1, () => {
        E[C] = null;
      }), ki()), ~i ? (l = E[i], l ? l.p(v, w) : (l = E[i] = S[i](v), l.c()), Zt(l, 1), l.m(s.parentNode, s)) : l = null), /*timer*/
      v[5] ? b && (Di(), h0(b, 1, 1, () => {
        b = null;
      }), ki()) : b ? (b.p(v, w), w[0] & /*timer*/
      32 && Zt(b, 1)) : (b = Hs(v), b.c(), Zt(b, 1), b.m(o.parentNode, o));
    },
    i(v) {
      d || (Zt(l), Zt(b), d = !0);
    },
    o(v) {
      h0(l), h0(b), d = !1;
    },
    d(v) {
      v && (ee(e), ee(t), ee(a), ee(s), ee(o)), h && h.d(v), _ && _.d(), y && y.d(), ~i && E[i].d(v), b && b.d(v);
    }
  };
}
function zs(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = d0("div"), this.h();
    },
    l(r) {
      e = c0(r, "DIV", { class: !0 }), u0(e).forEach(ee), this.h();
    },
    h() {
      Kt(e, "class", "eta-bar svelte-17v219f"), L0(e, "transform", t);
    },
    m(r, a) {
      oe(r, e, a);
    },
    p(r, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && L0(e, "transform", t);
    },
    d(r) {
      r && ee(e);
    }
  };
}
function tm(n) {
  let e;
  return {
    c() {
      e = Ge("processing |");
    },
    l(t) {
      e = Ve(t, "processing |");
    },
    m(t, r) {
      oe(t, e, r);
    },
    p: Si,
    d(t) {
      t && ee(e);
    }
  };
}
function nm(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), r, a, i, l;
  return {
    c() {
      e = Ge("queue: "), r = Ge(t), a = Ge("/"), i = Ge(
        /*queue_size*/
        n[3]
      ), l = Ge(" |");
    },
    l(s) {
      e = Ve(s, "queue: "), r = Ve(s, t), a = Ve(s, "/"), i = Ve(
        s,
        /*queue_size*/
        n[3]
      ), l = Ve(s, " |");
    },
    m(s, o) {
      oe(s, e, o), oe(s, r, o), oe(s, a, o), oe(s, i, o), oe(s, l, o);
    },
    p(s, o) {
      o[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      s[2] + 1 + "") && Pt(r, t), o[0] & /*queue_size*/
      8 && Pt(
        i,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (ee(e), ee(r), ee(a), ee(i), ee(l));
    }
  };
}
function rm(n) {
  let e, t = ca(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = qs(Ms(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = Ot();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = Ot();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      oe(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress*/
      128) {
        t = ca(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const s = Ms(a, t, l);
          r[l] ? r[l].p(s, i) : (r[l] = qs(s), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && ee(e), xu(r, a);
    }
  };
}
function Bs(n) {
  let e, t = (
    /*p*/
    n[41].unit + ""
  ), r, a, i = " ", l;
  function s(h, f) {
    return (
      /*p*/
      h[41].length != null ? im : am
    );
  }
  let o = s(n), d = o(n);
  return {
    c() {
      d.c(), e = Rt(), r = Ge(t), a = Ge(" | "), l = Ge(i);
    },
    l(h) {
      d.l(h), e = Nt(h), r = Ve(h, t), a = Ve(h, " | "), l = Ve(h, i);
    },
    m(h, f) {
      d.m(h, f), oe(h, e, f), oe(h, r, f), oe(h, a, f), oe(h, l, f);
    },
    p(h, f) {
      o === (o = s(h)) && d ? d.p(h, f) : (d.d(1), d = o(h), d && (d.c(), d.m(e.parentNode, e))), f[0] & /*progress*/
      128 && t !== (t = /*p*/
      h[41].unit + "") && Pt(r, t);
    },
    d(h) {
      h && (ee(e), ee(r), ee(a), ee(l)), d.d(h);
    }
  };
}
function am(n) {
  let e = Mn(
    /*p*/
    n[41].index || 0
  ) + "", t;
  return {
    c() {
      t = Ge(e);
    },
    l(r) {
      t = Ve(r, e);
    },
    m(r, a) {
      oe(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = Mn(
        /*p*/
        r[41].index || 0
      ) + "") && Pt(t, e);
    },
    d(r) {
      r && ee(t);
    }
  };
}
function im(n) {
  let e = Mn(
    /*p*/
    n[41].index || 0
  ) + "", t, r, a = Mn(
    /*p*/
    n[41].length
  ) + "", i;
  return {
    c() {
      t = Ge(e), r = Ge("/"), i = Ge(a);
    },
    l(l) {
      t = Ve(l, e), r = Ve(l, "/"), i = Ve(l, a);
    },
    m(l, s) {
      oe(l, t, s), oe(l, r, s), oe(l, i, s);
    },
    p(l, s) {
      s[0] & /*progress*/
      128 && e !== (e = Mn(
        /*p*/
        l[41].index || 0
      ) + "") && Pt(t, e), s[0] & /*progress*/
      128 && a !== (a = Mn(
        /*p*/
        l[41].length
      ) + "") && Pt(i, a);
    },
    d(l) {
      l && (ee(t), ee(r), ee(i));
    }
  };
}
function qs(n) {
  let e, t = (
    /*p*/
    n[41].index != null && Bs(n)
  );
  return {
    c() {
      t && t.c(), e = Ot();
    },
    l(r) {
      t && t.l(r), e = Ot();
    },
    m(r, a) {
      t && t.m(r, a), oe(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[41].index != null ? t ? t.p(r, a) : (t = Bs(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && ee(e), t && t.d(r);
    }
  };
}
function Ns(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), r, a;
  return {
    c() {
      e = Ge(
        /*formatted_timer*/
        n[20]
      ), r = Ge(t), a = Ge("s");
    },
    l(i) {
      e = Ve(
        i,
        /*formatted_timer*/
        n[20]
      ), r = Ve(i, t), a = Ve(i, "s");
    },
    m(i, l) {
      oe(i, e, l), oe(i, r, l), oe(i, a, l);
    },
    p(i, l) {
      l[0] & /*formatted_timer*/
      1048576 && Pt(
        e,
        /*formatted_timer*/
        i[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && Pt(r, t);
    },
    d(i) {
      i && (ee(e), ee(r), ee(a));
    }
  };
}
function lm(n) {
  let e, t;
  return e = new Vh({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      Du(e.$$.fragment);
    },
    l(r) {
      ku(e.$$.fragment, r);
    },
    m(r, a) {
      Cu(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*variant*/
      256 && (i.margin = /*variant*/
      r[8] === "default"), e.$set(i);
    },
    i(r) {
      t || (Zt(e.$$.fragment, r), t = !0);
    },
    o(r) {
      h0(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Au(e, r);
    }
  };
}
function sm(n) {
  let e, t, r, a, i, l = `${/*last_progress_level*/
  n[15] * 100}%`, s = (
    /*progress*/
    n[7] != null && Rs(n)
  );
  return {
    c() {
      e = d0("div"), t = d0("div"), s && s.c(), r = Rt(), a = d0("div"), i = d0("div"), this.h();
    },
    l(o) {
      e = c0(o, "DIV", { class: !0 });
      var d = u0(e);
      t = c0(d, "DIV", { class: !0 });
      var h = u0(t);
      s && s.l(h), h.forEach(ee), r = Nt(d), a = c0(d, "DIV", { class: !0 });
      var f = u0(a);
      i = c0(f, "DIV", { class: !0 }), u0(i).forEach(ee), f.forEach(ee), d.forEach(ee), this.h();
    },
    h() {
      Kt(t, "class", "progress-level-inner svelte-17v219f"), Kt(i, "class", "progress-bar svelte-17v219f"), L0(i, "width", l), Kt(a, "class", "progress-bar-wrap svelte-17v219f"), Kt(e, "class", "progress-level svelte-17v219f");
    },
    m(o, d) {
      oe(o, e, d), ln(e, t), s && s.m(t, null), ln(e, r), ln(e, a), ln(a, i), n[31](i);
    },
    p(o, d) {
      /*progress*/
      o[7] != null ? s ? s.p(o, d) : (s = Rs(o), s.c(), s.m(t, null)) : s && (s.d(1), s = null), d[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      o[15] * 100}%`) && L0(i, "width", l);
    },
    i: Si,
    o: Si,
    d(o) {
      o && ee(e), s && s.d(), n[31](null);
    }
  };
}
function Rs(n) {
  let e, t = ca(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = $s(Ts(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = Ot();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = Ot();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      oe(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = ca(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const s = Ts(a, t, l);
          r[l] ? r[l].p(s, i) : (r[l] = $s(s), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && ee(e), xu(r, a);
    }
  };
}
function Is(n) {
  let e, t, r, a, i = (
    /*i*/
    n[43] !== 0 && om()
  ), l = (
    /*p*/
    n[41].desc != null && Ls(n)
  ), s = (
    /*p*/
    n[41].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[43]
    ] != null && Os()
  ), o = (
    /*progress_level*/
    n[14] != null && Ps(n)
  );
  return {
    c() {
      i && i.c(), e = Rt(), l && l.c(), t = Rt(), s && s.c(), r = Rt(), o && o.c(), a = Ot();
    },
    l(d) {
      i && i.l(d), e = Nt(d), l && l.l(d), t = Nt(d), s && s.l(d), r = Nt(d), o && o.l(d), a = Ot();
    },
    m(d, h) {
      i && i.m(d, h), oe(d, e, h), l && l.m(d, h), oe(d, t, h), s && s.m(d, h), oe(d, r, h), o && o.m(d, h), oe(d, a, h);
    },
    p(d, h) {
      /*p*/
      d[41].desc != null ? l ? l.p(d, h) : (l = Ls(d), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      d[41].desc != null && /*progress_level*/
      d[14] && /*progress_level*/
      d[14][
        /*i*/
        d[43]
      ] != null ? s || (s = Os(), s.c(), s.m(r.parentNode, r)) : s && (s.d(1), s = null), /*progress_level*/
      d[14] != null ? o ? o.p(d, h) : (o = Ps(d), o.c(), o.m(a.parentNode, a)) : o && (o.d(1), o = null);
    },
    d(d) {
      d && (ee(e), ee(t), ee(r), ee(a)), i && i.d(d), l && l.d(d), s && s.d(d), o && o.d(d);
    }
  };
}
function om(n) {
  let e;
  return {
    c() {
      e = Ge(" /");
    },
    l(t) {
      e = Ve(t, " /");
    },
    m(t, r) {
      oe(t, e, r);
    },
    d(t) {
      t && ee(e);
    }
  };
}
function Ls(n) {
  let e = (
    /*p*/
    n[41].desc + ""
  ), t;
  return {
    c() {
      t = Ge(e);
    },
    l(r) {
      t = Ve(r, e);
    },
    m(r, a) {
      oe(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      r[41].desc + "") && Pt(t, e);
    },
    d(r) {
      r && ee(t);
    }
  };
}
function Os(n) {
  let e;
  return {
    c() {
      e = Ge("-");
    },
    l(t) {
      e = Ve(t, "-");
    },
    m(t, r) {
      oe(t, e, r);
    },
    d(t) {
      t && ee(e);
    }
  };
}
function Ps(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[43]
  ] || 0)).toFixed(1) + "", t, r;
  return {
    c() {
      t = Ge(e), r = Ge("%");
    },
    l(a) {
      t = Ve(a, e), r = Ve(a, "%");
    },
    m(a, i) {
      oe(a, t, i), oe(a, r, i);
    },
    p(a, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[43]
      ] || 0)).toFixed(1) + "") && Pt(t, e);
    },
    d(a) {
      a && (ee(t), ee(r));
    }
  };
}
function $s(n) {
  let e, t = (
    /*p*/
    (n[41].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[43]
    ] != null) && Is(n)
  );
  return {
    c() {
      t && t.c(), e = Ot();
    },
    l(r) {
      t && t.l(r), e = Ot();
    },
    m(r, a) {
      t && t.m(r, a), oe(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[41].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[43]
      ] != null ? t ? t.p(r, a) : (t = Is(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && ee(e), t && t.d(r);
    }
  };
}
function Hs(n) {
  let e, t, r, a;
  const i = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), l = Su(
    i,
    n,
    /*$$scope*/
    n[29],
    Cs
  );
  return {
    c() {
      e = d0("p"), t = Ge(
        /*loading_text*/
        n[9]
      ), r = Rt(), l && l.c(), this.h();
    },
    l(s) {
      e = c0(s, "P", { class: !0 });
      var o = u0(e);
      t = Ve(
        o,
        /*loading_text*/
        n[9]
      ), o.forEach(ee), r = Nt(s), l && l.l(s), this.h();
    },
    h() {
      Kt(e, "class", "loading svelte-17v219f");
    },
    m(s, o) {
      oe(s, e, o), ln(e, t), oe(s, r, o), l && l.m(s, o), a = !0;
    },
    p(s, o) {
      (!a || o[0] & /*loading_text*/
      512) && Pt(
        t,
        /*loading_text*/
        s[9]
      ), l && l.p && (!a || o[0] & /*$$scope*/
      536870912) && Tu(
        l,
        i,
        s,
        /*$$scope*/
        s[29],
        a ? Eu(
          i,
          /*$$scope*/
          s[29],
          o,
          Qh
        ) : Fu(
          /*$$scope*/
          s[29]
        ),
        Cs
      );
    },
    i(s) {
      a || (Zt(l, s), a = !0);
    },
    o(s) {
      h0(l, s), a = !1;
    },
    d(s) {
      s && (ee(e), ee(r)), l && l.d(s);
    }
  };
}
function um(n) {
  let e, t, r, a, i;
  const l = [em, Jh], s = [];
  function o(d, h) {
    return (
      /*status*/
      d[4] === "pending" ? 0 : (
        /*status*/
        d[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = o(n)) && (r = s[t] = l[t](n)), {
    c() {
      e = d0("div"), r && r.c(), this.h();
    },
    l(d) {
      e = c0(d, "DIV", { class: !0 });
      var h = u0(e);
      r && r.l(h), h.forEach(ee), this.h();
    },
    h() {
      Kt(e, "class", a = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), zt(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), zt(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), zt(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), zt(
        e,
        "border",
        /*border*/
        n[12]
      ), L0(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), L0(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(d, h) {
      oe(d, e, h), ~t && s[t].m(e, null), n[33](e), i = !0;
    },
    p(d, h) {
      let f = t;
      t = o(d), t === f ? ~t && s[t].p(d, h) : (r && (Di(), h0(s[f], 1, 1, () => {
        s[f] = null;
      }), ki()), ~t ? (r = s[t], r ? r.p(d, h) : (r = s[t] = l[t](d), r.c()), Zt(r, 1), r.m(e, null)) : r = null), (!i || h[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      d[8] + " " + /*show_progress*/
      d[6] + " svelte-17v219f")) && Kt(e, "class", a), (!i || h[0] & /*variant, show_progress, status, show_progress*/
      336) && zt(e, "hide", !/*status*/
      d[4] || /*status*/
      d[4] === "complete" || /*show_progress*/
      d[6] === "hidden" || /*status*/
      d[4] == "streaming"), (!i || h[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && zt(
        e,
        "translucent",
        /*variant*/
        d[8] === "center" && /*status*/
        (d[4] === "pending" || /*status*/
        d[4] === "error") || /*translucent*/
        d[11] || /*show_progress*/
        d[6] === "minimal"
      ), (!i || h[0] & /*variant, show_progress, status, show_progress*/
      336) && zt(
        e,
        "generating",
        /*status*/
        d[4] === "generating" && /*show_progress*/
        d[6] === "full"
      ), (!i || h[0] & /*variant, show_progress, border*/
      4416) && zt(
        e,
        "border",
        /*border*/
        d[12]
      ), h[0] & /*absolute*/
      1024 && L0(
        e,
        "position",
        /*absolute*/
        d[10] ? "absolute" : "static"
      ), h[0] & /*absolute*/
      1024 && L0(
        e,
        "padding",
        /*absolute*/
        d[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(d) {
      i || (Zt(r), i = !0);
    },
    o(d) {
      h0(r), i = !1;
    },
    d(d) {
      d && ee(e), ~t && s[t].d(), n[33](null);
    }
  };
}
var cm = function(n, e, t, r) {
  function a(i) {
    return i instanceof t ? i : new t(function(l) {
      l(i);
    });
  }
  return new (t || (t = Promise))(function(i, l) {
    function s(h) {
      try {
        d(r.next(h));
      } catch (f) {
        l(f);
      }
    }
    function o(h) {
      try {
        d(r.throw(h));
      } catch (f) {
        l(f);
      }
    }
    function d(h) {
      h.done ? i(h.value) : a(h.value).then(s, o);
    }
    d((r = r.apply(n, e || [])).next());
  });
};
let Ur = [], ja = !1;
const dm = typeof window < "u", Mu = dm ? window.requestAnimationFrame : (n) => {
};
function hm(n) {
  return cm(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Ur.push(e), !ja) ja = !0;
      else return;
      yield Yh(), Mu(() => {
        let r = [0, 0];
        for (let a = 0; a < Ur.length; a++) {
          const l = Ur[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= r[0]) && (r[0] = l.top + window.scrollY, r[1] = a);
        }
        window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), ja = !1, Ur = [];
      });
    }
  });
}
function mm(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e;
  this && this.__awaiter;
  const l = Zh();
  let { i18n: s } = e, { eta: o = null } = e, { queue_position: d } = e, { queue_size: h } = e, { status: f } = e, { scroll_to_output: p = !1 } = e, { timer: _ = !0 } = e, { show_progress: y = "full" } = e, { message: S = null } = e, { progress: E = null } = e, { variant: A = "default" } = e, { loading_text: b = "Loading..." } = e, { absolute: v = !0 } = e, { translucent: w = !1 } = e, { border: C = !1 } = e, { autoscroll: T } = e, B, $ = !1, z = 0, N = 0, j = null, W = null, ye = 0, Z = null, pe, ke = null, Re = !0;
  const se = () => {
    t(0, o = t(27, j = t(19, ie = null))), t(25, z = performance.now()), t(26, N = 0), $ = !0, Ae();
  };
  function Ae() {
    Mu(() => {
      t(26, N = (performance.now() - z) / 1e3), $ && Ae();
    });
  }
  function xe() {
    t(26, N = 0), t(0, o = t(27, j = t(19, ie = null))), $ && ($ = !1);
  }
  Xh(() => {
    $ && xe();
  });
  let ie = null;
  function ce(P) {
    Fs[P ? "unshift" : "push"](() => {
      ke = P, t(16, ke), t(7, E), t(14, Z), t(15, pe);
    });
  }
  const de = () => {
    l("clear_status");
  };
  function ge(P) {
    Fs[P ? "unshift" : "push"](() => {
      B = P, t(13, B);
    });
  }
  return n.$$set = (P) => {
    "i18n" in P && t(1, s = P.i18n), "eta" in P && t(0, o = P.eta), "queue_position" in P && t(2, d = P.queue_position), "queue_size" in P && t(3, h = P.queue_size), "status" in P && t(4, f = P.status), "scroll_to_output" in P && t(22, p = P.scroll_to_output), "timer" in P && t(5, _ = P.timer), "show_progress" in P && t(6, y = P.show_progress), "message" in P && t(23, S = P.message), "progress" in P && t(7, E = P.progress), "variant" in P && t(8, A = P.variant), "loading_text" in P && t(9, b = P.loading_text), "absolute" in P && t(10, v = P.absolute), "translucent" in P && t(11, w = P.translucent), "border" in P && t(12, C = P.border), "autoscroll" in P && t(24, T = P.autoscroll), "$$scope" in P && t(29, i = P.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (o === null && t(0, o = j), o != null && j !== o && (t(28, W = (performance.now() - z) / 1e3 + o), t(19, ie = W.toFixed(1)), t(27, j = o))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ye = W === null || W <= 0 || !N ? null : Math.min(N / W, 1)), n.$$.dirty[0] & /*progress*/
    128 && E != null && t(18, Re = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (E != null ? t(14, Z = E.map((P) => {
      if (P.index != null && P.length != null)
        return P.index / P.length;
      if (P.progress != null)
        return P.progress;
    })) : t(14, Z = null), Z ? (t(15, pe = Z[Z.length - 1]), ke && (pe === 0 ? t(16, ke.style.transition = "0", ke) : t(16, ke.style.transition = "150ms", ke))) : t(15, pe = void 0)), n.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? se() : xe()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && B && p && (f === "pending" || f === "complete") && hm(B, T), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, r = N.toFixed(1));
  }, [
    o,
    s,
    d,
    h,
    f,
    _,
    y,
    E,
    A,
    b,
    v,
    w,
    C,
    B,
    Z,
    pe,
    ke,
    ye,
    Re,
    ie,
    r,
    l,
    p,
    S,
    T,
    z,
    N,
    j,
    W,
    i,
    a,
    ce,
    de,
    ge
  ];
}
class fm extends Gh {
  constructor(e) {
    super(), jh(
      this,
      e,
      mm,
      um,
      Wh,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.3.0 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.3.0/LICENSE */
const {
  entries: zu,
  setPrototypeOf: Us,
  isFrozen: pm,
  getPrototypeOf: _m,
  getOwnPropertyDescriptor: gm
} = Object;
let {
  freeze: ht,
  seal: $t,
  create: Ai
} = Object, {
  apply: xi,
  construct: Fi
} = typeof Reflect < "u" && Reflect;
ht || (ht = function(e) {
  return e;
});
$t || ($t = function(e) {
  return e;
});
xi || (xi = function(e, t) {
  for (var r = arguments.length, a = new Array(r > 2 ? r - 2 : 0), i = 2; i < r; i++)
    a[i - 2] = arguments[i];
  return e.apply(t, a);
});
Fi || (Fi = function(e) {
  for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
    r[a - 1] = arguments[a];
  return new e(...r);
});
const Vr = mt(Array.prototype.forEach), vm = mt(Array.prototype.lastIndexOf), Vs = mt(Array.prototype.pop), Jn = mt(Array.prototype.push), bm = mt(Array.prototype.splice), Zr = mt(String.prototype.toLowerCase), Wa = mt(String.prototype.toString), Ya = mt(String.prototype.match), er = mt(String.prototype.replace), ym = mt(String.prototype.indexOf), wm = mt(String.prototype.trim), Wt = mt(Object.prototype.hasOwnProperty), ct = mt(RegExp.prototype.test), tr = km(TypeError);
function mt(n) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      r[a - 1] = arguments[a];
    return xi(n, e, r);
  };
}
function km(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    return Fi(n, t);
  };
}
function ve(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Zr;
  Us && Us(n, null);
  let r = e.length;
  for (; r--; ) {
    let a = e[r];
    if (typeof a == "string") {
      const i = t(a);
      i !== a && (pm(e) || (e[r] = i), a = i);
    }
    n[a] = !0;
  }
  return n;
}
function Dm(n) {
  for (let e = 0; e < n.length; e++)
    Wt(n, e) || (n[e] = null);
  return n;
}
function y0(n) {
  const e = Ai(null);
  for (const [t, r] of zu(n))
    Wt(n, t) && (Array.isArray(r) ? e[t] = Dm(r) : r && typeof r == "object" && r.constructor === Object ? e[t] = y0(r) : e[t] = r);
  return e;
}
function nr(n, e) {
  for (; n !== null; ) {
    const r = gm(n, e);
    if (r) {
      if (r.get)
        return mt(r.get);
      if (typeof r.value == "function")
        return mt(r.value);
    }
    n = _m(n);
  }
  function t() {
    return null;
  }
  return t;
}
const Gs = ht(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Xa = ht(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Za = ht(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Sm = ht(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Ka = ht(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Am = ht(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), js = ht(["#text"]), Ws = ht(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Qa = ht(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "mask-type", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Ys = ht(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Gr = ht(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), xm = $t(/\{\{[\w\W]*|[\w\W]*\}\}/gm), Fm = $t(/<%[\w\W]*|[\w\W]*%>/gm), Em = $t(/\$\{[\w\W]*/gm), Cm = $t(/^data-[\-\w.\u00B7-\uFFFF]+$/), Tm = $t(/^aria-[\-\w]+$/), Bu = $t(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Mm = $t(/^(?:\w+script|data):/i), zm = $t(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), qu = $t(/^html$/i), Bm = $t(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Xs = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Tm,
  ATTR_WHITESPACE: zm,
  CUSTOM_ELEMENT: Bm,
  DATA_ATTR: Cm,
  DOCTYPE_NAME: qu,
  ERB_EXPR: Fm,
  IS_ALLOWED_URI: Bu,
  IS_SCRIPT_OR_DATA: Mm,
  MUSTACHE_EXPR: xm,
  TMPLIT_EXPR: Em
});
const rr = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, qm = function() {
  return typeof window > "u" ? null : window;
}, Nm = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let r = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (r = t.getAttribute(a));
  const i = "dompurify" + (r ? "#" + r : "");
  try {
    return e.createPolicy(i, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + i + " could not be created."), null;
  }
}, Zs = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Nu() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : qm();
  const e = (Q) => Nu(Q);
  if (e.version = "3.3.0", e.removed = [], !n || !n.document || n.document.nodeType !== rr.document || !n.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const r = t, a = r.currentScript, {
    DocumentFragment: i,
    HTMLTemplateElement: l,
    Node: s,
    Element: o,
    NodeFilter: d,
    NamedNodeMap: h = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: f,
    DOMParser: p,
    trustedTypes: _
  } = n, y = o.prototype, S = nr(y, "cloneNode"), E = nr(y, "remove"), A = nr(y, "nextSibling"), b = nr(y, "childNodes"), v = nr(y, "parentNode");
  if (typeof l == "function") {
    const Q = t.createElement("template");
    Q.content && Q.content.ownerDocument && (t = Q.content.ownerDocument);
  }
  let w, C = "";
  const {
    implementation: T,
    createNodeIterator: B,
    createDocumentFragment: $,
    getElementsByTagName: z
  } = t, {
    importNode: N
  } = r;
  let j = Zs();
  e.isSupported = typeof zu == "function" && typeof v == "function" && T && T.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: W,
    ERB_EXPR: ye,
    TMPLIT_EXPR: Z,
    DATA_ATTR: pe,
    ARIA_ATTR: ke,
    IS_SCRIPT_OR_DATA: Re,
    ATTR_WHITESPACE: se,
    CUSTOM_ELEMENT: Ae
  } = Xs;
  let {
    IS_ALLOWED_URI: xe
  } = Xs, ie = null;
  const ce = ve({}, [...Gs, ...Xa, ...Za, ...Ka, ...js]);
  let de = null;
  const ge = ve({}, [...Ws, ...Qa, ...Ys, ...Gr]);
  let P = Object.seal(Ai(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ie = null, Ee = null;
  const L = Object.seal(Ai(null, {
    tagCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    }
  }));
  let he = !0, we = !0, R = !1, te = !0, ae = !1, ue = !0, _e = !1, Le = !1, je = !1, ze = !1, Xe = !1, Oe = !1, pt = !0, Qt = !1;
  const Gn = "user-content-";
  let O = !0, G0 = !1, E0 = {}, C0 = null;
  const kr = ve({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Dr = null;
  const Sr = ve({}, ["audio", "video", "img", "source", "image", "track"]);
  let jn = null;
  const Ar = ve({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), vn = "http://www.w3.org/1998/Math/MathML", bn = "http://www.w3.org/2000/svg", Ht = "http://www.w3.org/1999/xhtml";
  let T0 = Ht, Wn = !1, Yn = null;
  const ya = ve({}, [vn, bn, Ht], Wa);
  let yn = ve({}, ["mi", "mo", "mn", "ms", "mtext"]), wn = ve({}, ["annotation-xml"]);
  const wa = ve({}, ["title", "style", "font", "a", "script"]);
  let j0 = null;
  const ka = ["application/xhtml+xml", "text/html"], Da = "text/html";
  let Qe = null, M0 = null;
  const Sa = t.createElement("form"), xr = function(x) {
    return x instanceof RegExp || x instanceof Function;
  }, Xn = function() {
    let x = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(M0 && M0 === x)) {
      if ((!x || typeof x != "object") && (x = {}), x = y0(x), j0 = // eslint-disable-next-line unicorn/prefer-includes
      ka.indexOf(x.PARSER_MEDIA_TYPE) === -1 ? Da : x.PARSER_MEDIA_TYPE, Qe = j0 === "application/xhtml+xml" ? Wa : Zr, ie = Wt(x, "ALLOWED_TAGS") ? ve({}, x.ALLOWED_TAGS, Qe) : ce, de = Wt(x, "ALLOWED_ATTR") ? ve({}, x.ALLOWED_ATTR, Qe) : ge, Yn = Wt(x, "ALLOWED_NAMESPACES") ? ve({}, x.ALLOWED_NAMESPACES, Wa) : ya, jn = Wt(x, "ADD_URI_SAFE_ATTR") ? ve(y0(Ar), x.ADD_URI_SAFE_ATTR, Qe) : Ar, Dr = Wt(x, "ADD_DATA_URI_TAGS") ? ve(y0(Sr), x.ADD_DATA_URI_TAGS, Qe) : Sr, C0 = Wt(x, "FORBID_CONTENTS") ? ve({}, x.FORBID_CONTENTS, Qe) : kr, Ie = Wt(x, "FORBID_TAGS") ? ve({}, x.FORBID_TAGS, Qe) : y0({}), Ee = Wt(x, "FORBID_ATTR") ? ve({}, x.FORBID_ATTR, Qe) : y0({}), E0 = Wt(x, "USE_PROFILES") ? x.USE_PROFILES : !1, he = x.ALLOW_ARIA_ATTR !== !1, we = x.ALLOW_DATA_ATTR !== !1, R = x.ALLOW_UNKNOWN_PROTOCOLS || !1, te = x.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ae = x.SAFE_FOR_TEMPLATES || !1, ue = x.SAFE_FOR_XML !== !1, _e = x.WHOLE_DOCUMENT || !1, ze = x.RETURN_DOM || !1, Xe = x.RETURN_DOM_FRAGMENT || !1, Oe = x.RETURN_TRUSTED_TYPE || !1, je = x.FORCE_BODY || !1, pt = x.SANITIZE_DOM !== !1, Qt = x.SANITIZE_NAMED_PROPS || !1, O = x.KEEP_CONTENT !== !1, G0 = x.IN_PLACE || !1, xe = x.ALLOWED_URI_REGEXP || Bu, T0 = x.NAMESPACE || Ht, yn = x.MATHML_TEXT_INTEGRATION_POINTS || yn, wn = x.HTML_INTEGRATION_POINTS || wn, P = x.CUSTOM_ELEMENT_HANDLING || {}, x.CUSTOM_ELEMENT_HANDLING && xr(x.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (P.tagNameCheck = x.CUSTOM_ELEMENT_HANDLING.tagNameCheck), x.CUSTOM_ELEMENT_HANDLING && xr(x.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (P.attributeNameCheck = x.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), x.CUSTOM_ELEMENT_HANDLING && typeof x.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (P.allowCustomizedBuiltInElements = x.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ae && (we = !1), Xe && (ze = !0), E0 && (ie = ve({}, js), de = [], E0.html === !0 && (ve(ie, Gs), ve(de, Ws)), E0.svg === !0 && (ve(ie, Xa), ve(de, Qa), ve(de, Gr)), E0.svgFilters === !0 && (ve(ie, Za), ve(de, Qa), ve(de, Gr)), E0.mathMl === !0 && (ve(ie, Ka), ve(de, Ys), ve(de, Gr))), x.ADD_TAGS && (typeof x.ADD_TAGS == "function" ? L.tagCheck = x.ADD_TAGS : (ie === ce && (ie = y0(ie)), ve(ie, x.ADD_TAGS, Qe))), x.ADD_ATTR && (typeof x.ADD_ATTR == "function" ? L.attributeCheck = x.ADD_ATTR : (de === ge && (de = y0(de)), ve(de, x.ADD_ATTR, Qe))), x.ADD_URI_SAFE_ATTR && ve(jn, x.ADD_URI_SAFE_ATTR, Qe), x.FORBID_CONTENTS && (C0 === kr && (C0 = y0(C0)), ve(C0, x.FORBID_CONTENTS, Qe)), O && (ie["#text"] = !0), _e && ve(ie, ["html", "head", "body"]), ie.table && (ve(ie, ["tbody"]), delete Ie.tbody), x.TRUSTED_TYPES_POLICY) {
        if (typeof x.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw tr('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof x.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw tr('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        w = x.TRUSTED_TYPES_POLICY, C = w.createHTML("");
      } else
        w === void 0 && (w = Nm(_, a)), w !== null && typeof C == "string" && (C = w.createHTML(""));
      ht && ht(x), M0 = x;
    }
  }, q = ve({}, [...Xa, ...Za, ...Sm]), qe = ve({}, [...Ka, ...Am]), tt = function(x) {
    let U = v(x);
    (!U || !U.tagName) && (U = {
      namespaceURI: T0,
      tagName: "template"
    });
    const X = Zr(x.tagName), Pe = Zr(U.tagName);
    return Yn[x.namespaceURI] ? x.namespaceURI === bn ? U.namespaceURI === Ht ? X === "svg" : U.namespaceURI === vn ? X === "svg" && (Pe === "annotation-xml" || yn[Pe]) : !!q[X] : x.namespaceURI === vn ? U.namespaceURI === Ht ? X === "math" : U.namespaceURI === bn ? X === "math" && wn[Pe] : !!qe[X] : x.namespaceURI === Ht ? U.namespaceURI === bn && !wn[Pe] || U.namespaceURI === vn && !yn[Pe] ? !1 : !qe[X] && (wa[X] || !q[X]) : !!(j0 === "application/xhtml+xml" && Yn[x.namespaceURI]) : !1;
  }, Ce = function(x) {
    Jn(e.removed, {
      element: x
    });
    try {
      v(x).removeChild(x);
    } catch {
      E(x);
    }
  }, kt = function(x, U) {
    try {
      Jn(e.removed, {
        attribute: U.getAttributeNode(x),
        from: U
      });
    } catch {
      Jn(e.removed, {
        attribute: null,
        from: U
      });
    }
    if (U.removeAttribute(x), x === "is")
      if (ze || Xe)
        try {
          Ce(U);
        } catch {
        }
      else
        try {
          U.setAttribute(x, "");
        } catch {
        }
  }, z0 = function(x) {
    let U = null, X = null;
    if (je)
      x = "<remove></remove>" + x;
    else {
      const Je = Ya(x, /^[\r\n\t ]+/);
      X = Je && Je[0];
    }
    j0 === "application/xhtml+xml" && T0 === Ht && (x = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + x + "</body></html>");
    const Pe = w ? w.createHTML(x) : x;
    if (T0 === Ht)
      try {
        U = new p().parseFromString(Pe, j0);
      } catch {
      }
    if (!U || !U.documentElement) {
      U = T.createDocument(T0, "template", null);
      try {
        U.documentElement.innerHTML = Wn ? C : Pe;
      } catch {
      }
    }
    const st = U.body || U.documentElement;
    return x && X && st.insertBefore(t.createTextNode(X), st.childNodes[0] || null), T0 === Ht ? z.call(U, _e ? "html" : "body")[0] : _e ? U.documentElement : st;
  }, W0 = function(x) {
    return B.call(
      x.ownerDocument || x,
      x,
      // eslint-disable-next-line no-bitwise
      d.SHOW_ELEMENT | d.SHOW_COMMENT | d.SHOW_TEXT | d.SHOW_PROCESSING_INSTRUCTION | d.SHOW_CDATA_SECTION,
      null
    );
  }, Zn = function(x) {
    return x instanceof f && (typeof x.nodeName != "string" || typeof x.textContent != "string" || typeof x.removeChild != "function" || !(x.attributes instanceof h) || typeof x.removeAttribute != "function" || typeof x.setAttribute != "function" || typeof x.namespaceURI != "string" || typeof x.insertBefore != "function" || typeof x.hasChildNodes != "function");
  }, Fr = function(x) {
    return typeof s == "function" && x instanceof s;
  };
  function Dt(Q, x, U) {
    Vr(Q, (X) => {
      X.call(e, x, U, M0);
    });
  }
  const Jt = function(x) {
    let U = null;
    if (Dt(j.beforeSanitizeElements, x, null), Zn(x))
      return Ce(x), !0;
    const X = Qe(x.nodeName);
    if (Dt(j.uponSanitizeElement, x, {
      tagName: X,
      allowedTags: ie
    }), ue && x.hasChildNodes() && !Fr(x.firstElementChild) && ct(/<[/\w!]/g, x.innerHTML) && ct(/<[/\w!]/g, x.textContent) || x.nodeType === rr.progressingInstruction || ue && x.nodeType === rr.comment && ct(/<[/\w]/g, x.data))
      return Ce(x), !0;
    if (!(L.tagCheck instanceof Function && L.tagCheck(X)) && (!ie[X] || Ie[X])) {
      if (!Ie[X] && rl(X) && (P.tagNameCheck instanceof RegExp && ct(P.tagNameCheck, X) || P.tagNameCheck instanceof Function && P.tagNameCheck(X)))
        return !1;
      if (O && !C0[X]) {
        const Pe = v(x) || x.parentNode, st = b(x) || x.childNodes;
        if (st && Pe) {
          const Je = st.length;
          for (let _t = Je - 1; _t >= 0; --_t) {
            const g0 = S(st[_t], !0);
            g0.__removalCount = (x.__removalCount || 0) + 1, Pe.insertBefore(g0, A(x));
          }
        }
      }
      return Ce(x), !0;
    }
    return x instanceof o && !tt(x) || (X === "noscript" || X === "noembed" || X === "noframes") && ct(/<\/no(script|embed|frames)/i, x.innerHTML) ? (Ce(x), !0) : (ae && x.nodeType === rr.text && (U = x.textContent, Vr([W, ye, Z], (Pe) => {
      U = er(U, Pe, " ");
    }), x.textContent !== U && (Jn(e.removed, {
      element: x.cloneNode()
    }), x.textContent = U)), Dt(j.afterSanitizeElements, x, null), !1);
  }, kn = function(x, U, X) {
    if (pt && (U === "id" || U === "name") && (X in t || X in Sa))
      return !1;
    if (!(we && !Ee[U] && ct(pe, U))) {
      if (!(he && ct(ke, U))) {
        if (!(L.attributeCheck instanceof Function && L.attributeCheck(U, x))) {
          if (!de[U] || Ee[U]) {
            if (
              // First condition does a very basic check if a) it's basically a valid custom element tagname AND
              // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
              !(rl(x) && (P.tagNameCheck instanceof RegExp && ct(P.tagNameCheck, x) || P.tagNameCheck instanceof Function && P.tagNameCheck(x)) && (P.attributeNameCheck instanceof RegExp && ct(P.attributeNameCheck, U) || P.attributeNameCheck instanceof Function && P.attributeNameCheck(U, x)) || // Alternative, second condition checks if it's an `is`-attribute, AND
              // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              U === "is" && P.allowCustomizedBuiltInElements && (P.tagNameCheck instanceof RegExp && ct(P.tagNameCheck, X) || P.tagNameCheck instanceof Function && P.tagNameCheck(X)))
            ) return !1;
          } else if (!jn[U]) {
            if (!ct(xe, er(X, se, ""))) {
              if (!((U === "src" || U === "xlink:href" || U === "href") && x !== "script" && ym(X, "data:") === 0 && Dr[x])) {
                if (!(R && !ct(Re, er(X, se, "")))) {
                  if (X)
                    return !1;
                }
              }
            }
          }
        }
      }
    }
    return !0;
  }, rl = function(x) {
    return x !== "annotation-xml" && Ya(x, Ae);
  }, al = function(x) {
    Dt(j.beforeSanitizeAttributes, x, null);
    const {
      attributes: U
    } = x;
    if (!U || Zn(x))
      return;
    const X = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: de,
      forceKeepAttr: void 0
    };
    let Pe = U.length;
    for (; Pe--; ) {
      const st = U[Pe], {
        name: Je,
        namespaceURI: _t,
        value: g0
      } = st, Dn = Qe(Je), Aa = g0;
      let rt = Je === "value" ? Aa : wm(Aa);
      if (X.attrName = Dn, X.attrValue = rt, X.keepAttr = !0, X.forceKeepAttr = void 0, Dt(j.uponSanitizeAttribute, x, X), rt = X.attrValue, Qt && (Dn === "id" || Dn === "name") && (kt(Je, x), rt = Gn + rt), ue && ct(/((--!?|])>)|<\/(style|title|textarea)/i, rt)) {
        kt(Je, x);
        continue;
      }
      if (Dn === "attributename" && Ya(rt, "href")) {
        kt(Je, x);
        continue;
      }
      if (X.forceKeepAttr)
        continue;
      if (!X.keepAttr) {
        kt(Je, x);
        continue;
      }
      if (!te && ct(/\/>/i, rt)) {
        kt(Je, x);
        continue;
      }
      ae && Vr([W, ye, Z], (ll) => {
        rt = er(rt, ll, " ");
      });
      const il = Qe(x.nodeName);
      if (!kn(il, Dn, rt)) {
        kt(Je, x);
        continue;
      }
      if (w && typeof _ == "object" && typeof _.getAttributeType == "function" && !_t)
        switch (_.getAttributeType(il, Dn)) {
          case "TrustedHTML": {
            rt = w.createHTML(rt);
            break;
          }
          case "TrustedScriptURL": {
            rt = w.createScriptURL(rt);
            break;
          }
        }
      if (rt !== Aa)
        try {
          _t ? x.setAttributeNS(_t, Je, rt) : x.setAttribute(Je, rt), Zn(x) ? Ce(x) : Vs(e.removed);
        } catch {
          kt(Je, x);
        }
    }
    Dt(j.afterSanitizeAttributes, x, null);
  }, Ru = function Q(x) {
    let U = null;
    const X = W0(x);
    for (Dt(j.beforeSanitizeShadowDOM, x, null); U = X.nextNode(); )
      Dt(j.uponSanitizeShadowNode, U, null), Jt(U), al(U), U.content instanceof i && Q(U.content);
    Dt(j.afterSanitizeShadowDOM, x, null);
  };
  return e.sanitize = function(Q) {
    let x = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, U = null, X = null, Pe = null, st = null;
    if (Wn = !Q, Wn && (Q = "<!-->"), typeof Q != "string" && !Fr(Q))
      if (typeof Q.toString == "function") {
        if (Q = Q.toString(), typeof Q != "string")
          throw tr("dirty is not a string, aborting");
      } else
        throw tr("toString is not a function");
    if (!e.isSupported)
      return Q;
    if (Le || Xn(x), e.removed = [], typeof Q == "string" && (G0 = !1), G0) {
      if (Q.nodeName) {
        const g0 = Qe(Q.nodeName);
        if (!ie[g0] || Ie[g0])
          throw tr("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (Q instanceof s)
      U = z0("<!---->"), X = U.ownerDocument.importNode(Q, !0), X.nodeType === rr.element && X.nodeName === "BODY" || X.nodeName === "HTML" ? U = X : U.appendChild(X);
    else {
      if (!ze && !ae && !_e && // eslint-disable-next-line unicorn/prefer-includes
      Q.indexOf("<") === -1)
        return w && Oe ? w.createHTML(Q) : Q;
      if (U = z0(Q), !U)
        return ze ? null : Oe ? C : "";
    }
    U && je && Ce(U.firstChild);
    const Je = W0(G0 ? Q : U);
    for (; Pe = Je.nextNode(); )
      Jt(Pe), al(Pe), Pe.content instanceof i && Ru(Pe.content);
    if (G0)
      return Q;
    if (ze) {
      if (Xe)
        for (st = $.call(U.ownerDocument); U.firstChild; )
          st.appendChild(U.firstChild);
      else
        st = U;
      return (de.shadowroot || de.shadowrootmode) && (st = N.call(r, st, !0)), st;
    }
    let _t = _e ? U.outerHTML : U.innerHTML;
    return _e && ie["!doctype"] && U.ownerDocument && U.ownerDocument.doctype && U.ownerDocument.doctype.name && ct(qu, U.ownerDocument.doctype.name) && (_t = "<!DOCTYPE " + U.ownerDocument.doctype.name + `>
` + _t), ae && Vr([W, ye, Z], (g0) => {
      _t = er(_t, g0, " ");
    }), w && Oe ? w.createHTML(_t) : _t;
  }, e.setConfig = function() {
    let Q = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Xn(Q), Le = !0;
  }, e.clearConfig = function() {
    M0 = null, Le = !1;
  }, e.isValidAttribute = function(Q, x, U) {
    M0 || Xn({});
    const X = Qe(Q), Pe = Qe(x);
    return kn(X, Pe, U);
  }, e.addHook = function(Q, x) {
    typeof x == "function" && Jn(j[Q], x);
  }, e.removeHook = function(Q, x) {
    if (x !== void 0) {
      const U = vm(j[Q], x);
      return U === -1 ? void 0 : bm(j[Q], U, 1)[0];
    }
    return Vs(j[Q]);
  }, e.removeHooks = function(Q) {
    j[Q] = [];
  }, e.removeAllHooks = function() {
    j = Zs();
  }, e;
}
Nu();
const {
  HtmlTagHydration: sS,
  SvelteComponent: oS,
  add_render_callback: uS,
  append_hydration: cS,
  attr: dS,
  bubble: hS,
  check_outros: mS,
  children: fS,
  claim_component: pS,
  claim_element: _S,
  claim_html_tag: gS,
  claim_space: vS,
  claim_text: bS,
  create_component: yS,
  create_in_transition: wS,
  create_out_transition: kS,
  destroy_component: DS,
  detach: SS,
  element: AS,
  get_svelte_dataset: xS,
  group_outros: FS,
  init: ES,
  insert_hydration: CS,
  listen: TS,
  mount_component: MS,
  run_all: zS,
  safe_not_equal: BS,
  set_data: qS,
  space: NS,
  stop_propagation: RS,
  text: IS,
  toggle_class: LS,
  transition_in: OS,
  transition_out: PS
} = window.__gradio__svelte__internal, { createEventDispatcher: $S, onMount: HS } = window.__gradio__svelte__internal, {
  SvelteComponent: US,
  append_hydration: VS,
  attr: GS,
  bubble: jS,
  check_outros: WS,
  children: YS,
  claim_component: XS,
  claim_element: ZS,
  claim_space: KS,
  create_animation: QS,
  create_component: JS,
  destroy_component: eA,
  detach: tA,
  element: nA,
  ensure_array_like: rA,
  fix_and_outro_and_destroy_block: aA,
  fix_position: iA,
  group_outros: lA,
  init: sA,
  insert_hydration: oA,
  mount_component: uA,
  noop: cA,
  safe_not_equal: dA,
  set_style: hA,
  space: mA,
  transition_in: fA,
  transition_out: pA,
  update_keyed_each: _A
} = window.__gradio__svelte__internal, {
  SvelteComponent: gA,
  attr: vA,
  children: bA,
  claim_element: yA,
  detach: wA,
  element: kA,
  empty: DA,
  init: SA,
  insert_hydration: AA,
  noop: xA,
  safe_not_equal: FA,
  set_style: EA
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rm,
  add_flush_callback: Ja,
  assign: Im,
  bind: ei,
  binding_callbacks: ti,
  check_outros: Lm,
  claim_component: Ji,
  claim_space: Om,
  create_component: el,
  destroy_component: tl,
  detach: Pm,
  flush: be,
  get_spread_object: $m,
  get_spread_update: Hm,
  group_outros: Um,
  init: Vm,
  insert_hydration: Gm,
  mount_component: nl,
  safe_not_equal: jm,
  space: Wm,
  transition_in: zn,
  transition_out: mr
} = window.__gradio__svelte__internal;
function Ks(n) {
  let e, t;
  const r = [
    { autoscroll: (
      /*gradio*/
      n[2].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      n[2].i18n
    ) },
    /*loading_status*/
    n[20]
  ];
  let a = {};
  for (let i = 0; i < r.length; i += 1)
    a = Im(a, r[i]);
  return e = new fm({ props: a }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    n[39]
  ), {
    c() {
      el(e.$$.fragment);
    },
    l(i) {
      Ji(e.$$.fragment, i);
    },
    m(i, l) {
      nl(e, i, l), t = !0;
    },
    p(i, l) {
      const s = l[0] & /*gradio, loading_status*/
      1048580 ? Hm(r, [
        l[0] & /*gradio*/
        4 && { autoscroll: (
          /*gradio*/
          i[2].autoscroll
        ) },
        l[0] & /*gradio*/
        4 && { i18n: (
          /*gradio*/
          i[2].i18n
        ) },
        l[0] & /*loading_status*/
        1048576 && $m(
          /*loading_status*/
          i[20]
        )
      ]) : {};
      e.$set(s);
    },
    i(i) {
      t || (zn(e.$$.fragment, i), t = !0);
    },
    o(i) {
      mr(e.$$.fragment, i), t = !1;
    },
    d(i) {
      tl(e, i);
    }
  };
}
function Ym(n) {
  let e, t, r, a, i, l, s = (
    /*loading_status*/
    n[20] && Ks(n)
  );
  function o(p) {
    n[42](p);
  }
  function d(p) {
    n[43](p);
  }
  function h(p) {
    n[44](p);
  }
  let f = {
    file_types: (
      /*file_types*/
      n[6]
    ),
    root: (
      /*root*/
      n[26]
    ),
    label: (
      /*label*/
      n[9]
    ),
    info: (
      /*info*/
      n[10]
    ),
    show_label: (
      /*show_label*/
      n[11]
    ),
    lines: (
      /*lines*/
      n[7]
    ),
    rtl: (
      /*rtl*/
      n[21]
    ),
    text_align: (
      /*text_align*/
      n[22]
    ),
    max_lines: /*max_lines*/ n[12] ? (
      /*max_lines*/
      n[12]
    ) : (
      /*lines*/
      n[7] + 1
    ),
    placeholder: (
      /*placeholder*/
      n[8]
    ),
    upload_btn: (
      /*upload_btn*/
      n[16]
    ),
    submit_btn: (
      /*submit_btn*/
      n[17]
    ),
    stop_btn: (
      /*stop_btn*/
      n[18]
    ),
    autofocus: (
      /*autofocus*/
      n[23]
    ),
    container: (
      /*container*/
      n[13]
    ),
    autoscroll: (
      /*autoscroll*/
      n[24]
    ),
    file_count: (
      /*file_count*/
      n[27]
    ),
    interactive: (
      /*interactive*/
      n[25]
    ),
    loading_message: (
      /*loading_message*/
      n[19]
    ),
    audio_btn: (
      /*audio_btn*/
      n[28]
    ),
    stop_audio_btn: (
      /*stop_audio_btn*/
      n[29]
    ),
    max_file_size: (
      /*gradio*/
      n[2].max_file_size
    ),
    on_change_cb: (
      /*on_change_cb*/
      n[38]
    ),
    server: (
      /*server*/
      n[36]
    ),
    rtc_configuration: (
      /*rtc_configuration*/
      n[30]
    ),
    time_limit: (
      /*time_limit*/
      n[31]
    ),
    track_constraints: (
      /*track_constraints*/
      n[35]
    ),
    mode: (
      /*mode*/
      n[33]
    ),
    rtp_params: (
      /*rtp_params*/
      n[34]
    ),
    modality: (
      /*modality*/
      n[32]
    ),
    gradio: (
      /*gradio*/
      n[2]
    ),
    upload: (
      /*func*/
      n[40]
    ),
    stream_handler: (
      /*func_1*/
      n[41]
    )
  };
  return (
    /*value*/
    n[0] !== void 0 && (f.value = /*value*/
    n[0]), /*value_is_output*/
    n[1] !== void 0 && (f.value_is_output = /*value_is_output*/
    n[1]), /*dragging*/
    n[37] !== void 0 && (f.dragging = /*dragging*/
    n[37]), t = new Mh({ props: f }), ti.push(() => ei(t, "value", o)), ti.push(() => ei(t, "value_is_output", d)), ti.push(() => ei(t, "dragging", h)), t.$on(
      "tick",
      /*tick_handler*/
      n[45]
    ), t.$on(
      "change",
      /*change_handler*/
      n[46]
    ), t.$on(
      "input",
      /*input_handler*/
      n[47]
    ), t.$on(
      "submit",
      /*submit_handler*/
      n[48]
    ), t.$on(
      "stop",
      /*stop_handler*/
      n[49]
    ), t.$on(
      "blur",
      /*blur_handler*/
      n[50]
    ), t.$on(
      "select",
      /*select_handler*/
      n[51]
    ), t.$on(
      "focus",
      /*focus_handler*/
      n[52]
    ), t.$on(
      "upload",
      /*upload_handler*/
      n[53]
    ), t.$on(
      "error",
      /*error_handler*/
      n[54]
    ), t.$on(
      "start_recording",
      /*start_recording_handler*/
      n[55]
    ), t.$on(
      "stop_recording",
      /*stop_recording_handler*/
      n[56]
    ), {
      c() {
        s && s.c(), e = Wm(), el(t.$$.fragment);
      },
      l(p) {
        s && s.l(p), e = Om(p), Ji(t.$$.fragment, p);
      },
      m(p, _) {
        s && s.m(p, _), Gm(p, e, _), nl(t, p, _), l = !0;
      },
      p(p, _) {
        /*loading_status*/
        p[20] ? s ? (s.p(p, _), _[0] & /*loading_status*/
        1048576 && zn(s, 1)) : (s = Ks(p), s.c(), zn(s, 1), s.m(e.parentNode, e)) : s && (Um(), mr(s, 1, 1, () => {
          s = null;
        }), Lm());
        const y = {};
        _[0] & /*file_types*/
        64 && (y.file_types = /*file_types*/
        p[6]), _[0] & /*root*/
        67108864 && (y.root = /*root*/
        p[26]), _[0] & /*label*/
        512 && (y.label = /*label*/
        p[9]), _[0] & /*info*/
        1024 && (y.info = /*info*/
        p[10]), _[0] & /*show_label*/
        2048 && (y.show_label = /*show_label*/
        p[11]), _[0] & /*lines*/
        128 && (y.lines = /*lines*/
        p[7]), _[0] & /*rtl*/
        2097152 && (y.rtl = /*rtl*/
        p[21]), _[0] & /*text_align*/
        4194304 && (y.text_align = /*text_align*/
        p[22]), _[0] & /*max_lines, lines*/
        4224 && (y.max_lines = /*max_lines*/
        p[12] ? (
          /*max_lines*/
          p[12]
        ) : (
          /*lines*/
          p[7] + 1
        )), _[0] & /*placeholder*/
        256 && (y.placeholder = /*placeholder*/
        p[8]), _[0] & /*upload_btn*/
        65536 && (y.upload_btn = /*upload_btn*/
        p[16]), _[0] & /*submit_btn*/
        131072 && (y.submit_btn = /*submit_btn*/
        p[17]), _[0] & /*stop_btn*/
        262144 && (y.stop_btn = /*stop_btn*/
        p[18]), _[0] & /*autofocus*/
        8388608 && (y.autofocus = /*autofocus*/
        p[23]), _[0] & /*container*/
        8192 && (y.container = /*container*/
        p[13]), _[0] & /*autoscroll*/
        16777216 && (y.autoscroll = /*autoscroll*/
        p[24]), _[0] & /*file_count*/
        134217728 && (y.file_count = /*file_count*/
        p[27]), _[0] & /*interactive*/
        33554432 && (y.interactive = /*interactive*/
        p[25]), _[0] & /*loading_message*/
        524288 && (y.loading_message = /*loading_message*/
        p[19]), _[0] & /*audio_btn*/
        268435456 && (y.audio_btn = /*audio_btn*/
        p[28]), _[0] & /*stop_audio_btn*/
        536870912 && (y.stop_audio_btn = /*stop_audio_btn*/
        p[29]), _[0] & /*gradio*/
        4 && (y.max_file_size = /*gradio*/
        p[2].max_file_size), _[1] & /*server*/
        32 && (y.server = /*server*/
        p[36]), _[0] & /*rtc_configuration*/
        1073741824 && (y.rtc_configuration = /*rtc_configuration*/
        p[30]), _[1] & /*time_limit*/
        1 && (y.time_limit = /*time_limit*/
        p[31]), _[1] & /*track_constraints*/
        16 && (y.track_constraints = /*track_constraints*/
        p[35]), _[1] & /*mode*/
        4 && (y.mode = /*mode*/
        p[33]), _[1] & /*rtp_params*/
        8 && (y.rtp_params = /*rtp_params*/
        p[34]), _[1] & /*modality*/
        2 && (y.modality = /*modality*/
        p[32]), _[0] & /*gradio*/
        4 && (y.gradio = /*gradio*/
        p[2]), _[0] & /*gradio*/
        4 && (y.upload = /*func*/
        p[40]), _[0] & /*gradio*/
        4 && (y.stream_handler = /*func_1*/
        p[41]), !r && _[0] & /*value*/
        1 && (r = !0, y.value = /*value*/
        p[0], Ja(() => r = !1)), !a && _[0] & /*value_is_output*/
        2 && (a = !0, y.value_is_output = /*value_is_output*/
        p[1], Ja(() => a = !1)), !i && _[1] & /*dragging*/
        64 && (i = !0, y.dragging = /*dragging*/
        p[37], Ja(() => i = !1)), t.$set(y);
      },
      i(p) {
        l || (zn(s), zn(t.$$.fragment, p), l = !0);
      },
      o(p) {
        mr(s), mr(t.$$.fragment, p), l = !1;
      },
      d(p) {
        p && Pm(e), s && s.d(p), tl(t, p);
      }
    }
  );
}
function Xm(n) {
  let e, t;
  return e = new B1({
    props: {
      visible: (
        /*visible*/
        n[5]
      ),
      elem_id: (
        /*elem_id*/
        n[3]
      ),
      elem_classes: [.../*elem_classes*/
      n[4], "multimodal-textbox"],
      scale: (
        /*scale*/
        n[14]
      ),
      min_width: (
        /*min_width*/
        n[15]
      ),
      allow_overflow: !1,
      padding: (
        /*container*/
        n[13]
      ),
      border_mode: (
        /*dragging*/
        n[37] ? "focus" : "base"
      ),
      $$slots: { default: [Ym] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      el(e.$$.fragment);
    },
    l(r) {
      Ji(e.$$.fragment, r);
    },
    m(r, a) {
      nl(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*visible*/
      32 && (i.visible = /*visible*/
      r[5]), a[0] & /*elem_id*/
      8 && (i.elem_id = /*elem_id*/
      r[3]), a[0] & /*elem_classes*/
      16 && (i.elem_classes = [.../*elem_classes*/
      r[4], "multimodal-textbox"]), a[0] & /*scale*/
      16384 && (i.scale = /*scale*/
      r[14]), a[0] & /*min_width*/
      32768 && (i.min_width = /*min_width*/
      r[15]), a[0] & /*container*/
      8192 && (i.padding = /*container*/
      r[13]), a[1] & /*dragging*/
      64 && (i.border_mode = /*dragging*/
      r[37] ? "focus" : "base"), a[0] & /*file_types, root, label, info, show_label, lines, rtl, text_align, max_lines, placeholder, upload_btn, submit_btn, stop_btn, autofocus, container, autoscroll, file_count, interactive, loading_message, audio_btn, stop_audio_btn, gradio, rtc_configuration, value, value_is_output, loading_status*/
      2147434439 | a[1] & /*$$scope, server, time_limit, track_constraints, mode, rtp_params, modality, dragging*/
      67108991 && (i.$$scope = { dirty: a, ctx: r }), e.$set(i);
    },
    i(r) {
      t || (zn(e.$$.fragment, r), t = !0);
    },
    o(r) {
      mr(e.$$.fragment, r), t = !1;
    },
    d(r) {
      tl(e, r);
    }
  };
}
function Zm(n, e, t) {
  let { gradio: r } = e, { elem_id: a = "" } = e, { elem_classes: i = [] } = e, { visible: l = !0 } = e, { value: s = {
    text: "",
    files: [],
    audio: "__webrtc_value__"
  } } = e, { file_types: o = null } = e, { lines: d } = e, { placeholder: h = "" } = e, { label: f = "MultimodalTextbox" } = e, { info: p = void 0 } = e, { show_label: _ } = e, { max_lines: y } = e, { container: S = !0 } = e, { scale: E = null } = e, { min_width: A = void 0 } = e, { upload_btn: b = null } = e, { submit_btn: v = null } = e, { stop_btn: w = null } = e, { loading_message: C = "... Loading files ..." } = e, { loading_status: T = void 0 } = e, { value_is_output: B = !1 } = e, { rtl: $ = !1 } = e, { text_align: z = void 0 } = e, { autofocus: N = !1 } = e, { autoscroll: j = !0 } = e, { interactive: W } = e, { root: ye } = e, { file_count: Z } = e, { audio_btn: pe } = e, { stop_audio_btn: ke } = e, { rtc_configuration: Re } = e, { time_limit: se = null } = e, { modality: Ae = "audio" } = e, { mode: xe = "send-receive" } = e, { rtp_params: ie = {} } = e, { track_constraints: ce = {} } = e, { server: de } = e;
  const ge = (O) => {
    r.dispatch(O === "change" ? "state_change" : "tick");
  };
  let P;
  const Ie = () => r.dispatch("clear_status", T), Ee = (...O) => r.client.upload(...O), L = (...O) => r.client.stream(...O);
  function he(O) {
    s = O, t(0, s);
  }
  function we(O) {
    B = O, t(1, B);
  }
  function R(O) {
    P = O, t(37, P);
  }
  const te = () => r.dispatch("tick"), ae = () => r.dispatch("change", s), ue = () => r.dispatch("input"), _e = () => r.dispatch("submit"), Le = () => r.dispatch("stop"), je = () => r.dispatch("blur"), ze = (O) => r.dispatch("select", O.detail), Xe = () => r.dispatch("focus"), Oe = ({ detail: O }) => r.dispatch("upload", O), pt = ({ detail: O }) => {
    r.dispatch("error", O);
  }, Qt = () => r.dispatch("start_recording"), Gn = () => r.dispatch("stop_recording");
  return n.$$set = (O) => {
    "gradio" in O && t(2, r = O.gradio), "elem_id" in O && t(3, a = O.elem_id), "elem_classes" in O && t(4, i = O.elem_classes), "visible" in O && t(5, l = O.visible), "value" in O && t(0, s = O.value), "file_types" in O && t(6, o = O.file_types), "lines" in O && t(7, d = O.lines), "placeholder" in O && t(8, h = O.placeholder), "label" in O && t(9, f = O.label), "info" in O && t(10, p = O.info), "show_label" in O && t(11, _ = O.show_label), "max_lines" in O && t(12, y = O.max_lines), "container" in O && t(13, S = O.container), "scale" in O && t(14, E = O.scale), "min_width" in O && t(15, A = O.min_width), "upload_btn" in O && t(16, b = O.upload_btn), "submit_btn" in O && t(17, v = O.submit_btn), "stop_btn" in O && t(18, w = O.stop_btn), "loading_message" in O && t(19, C = O.loading_message), "loading_status" in O && t(20, T = O.loading_status), "value_is_output" in O && t(1, B = O.value_is_output), "rtl" in O && t(21, $ = O.rtl), "text_align" in O && t(22, z = O.text_align), "autofocus" in O && t(23, N = O.autofocus), "autoscroll" in O && t(24, j = O.autoscroll), "interactive" in O && t(25, W = O.interactive), "root" in O && t(26, ye = O.root), "file_count" in O && t(27, Z = O.file_count), "audio_btn" in O && t(28, pe = O.audio_btn), "stop_audio_btn" in O && t(29, ke = O.stop_audio_btn), "rtc_configuration" in O && t(30, Re = O.rtc_configuration), "time_limit" in O && t(31, se = O.time_limit), "modality" in O && t(32, Ae = O.modality), "mode" in O && t(33, xe = O.mode), "rtp_params" in O && t(34, ie = O.rtp_params), "track_constraints" in O && t(35, ce = O.track_constraints), "server" in O && t(36, de = O.server);
  }, [
    s,
    B,
    r,
    a,
    i,
    l,
    o,
    d,
    h,
    f,
    p,
    _,
    y,
    S,
    E,
    A,
    b,
    v,
    w,
    C,
    T,
    $,
    z,
    N,
    j,
    W,
    ye,
    Z,
    pe,
    ke,
    Re,
    se,
    Ae,
    xe,
    ie,
    ce,
    de,
    P,
    ge,
    Ie,
    Ee,
    L,
    he,
    we,
    R,
    te,
    ae,
    ue,
    _e,
    Le,
    je,
    ze,
    Xe,
    Oe,
    pt,
    Qt,
    Gn
  ];
}
class CA extends Rm {
  constructor(e) {
    super(), Vm(
      this,
      e,
      Zm,
      Xm,
      jm,
      {
        gradio: 2,
        elem_id: 3,
        elem_classes: 4,
        visible: 5,
        value: 0,
        file_types: 6,
        lines: 7,
        placeholder: 8,
        label: 9,
        info: 10,
        show_label: 11,
        max_lines: 12,
        container: 13,
        scale: 14,
        min_width: 15,
        upload_btn: 16,
        submit_btn: 17,
        stop_btn: 18,
        loading_message: 19,
        loading_status: 20,
        value_is_output: 1,
        rtl: 21,
        text_align: 22,
        autofocus: 23,
        autoscroll: 24,
        interactive: 25,
        root: 26,
        file_count: 27,
        audio_btn: 28,
        stop_audio_btn: 29,
        rtc_configuration: 30,
        time_limit: 31,
        modality: 32,
        mode: 33,
        rtp_params: 34,
        track_constraints: 35,
        server: 36
      },
      null,
      [-1, -1]
    );
  }
  get gradio() {
    return this.$$.ctx[2];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), be();
  }
  get elem_id() {
    return this.$$.ctx[3];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), be();
  }
  get elem_classes() {
    return this.$$.ctx[4];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), be();
  }
  get visible() {
    return this.$$.ctx[5];
  }
  set visible(e) {
    this.$$set({ visible: e }), be();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), be();
  }
  get file_types() {
    return this.$$.ctx[6];
  }
  set file_types(e) {
    this.$$set({ file_types: e }), be();
  }
  get lines() {
    return this.$$.ctx[7];
  }
  set lines(e) {
    this.$$set({ lines: e }), be();
  }
  get placeholder() {
    return this.$$.ctx[8];
  }
  set placeholder(e) {
    this.$$set({ placeholder: e }), be();
  }
  get label() {
    return this.$$.ctx[9];
  }
  set label(e) {
    this.$$set({ label: e }), be();
  }
  get info() {
    return this.$$.ctx[10];
  }
  set info(e) {
    this.$$set({ info: e }), be();
  }
  get show_label() {
    return this.$$.ctx[11];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), be();
  }
  get max_lines() {
    return this.$$.ctx[12];
  }
  set max_lines(e) {
    this.$$set({ max_lines: e }), be();
  }
  get container() {
    return this.$$.ctx[13];
  }
  set container(e) {
    this.$$set({ container: e }), be();
  }
  get scale() {
    return this.$$.ctx[14];
  }
  set scale(e) {
    this.$$set({ scale: e }), be();
  }
  get min_width() {
    return this.$$.ctx[15];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), be();
  }
  get upload_btn() {
    return this.$$.ctx[16];
  }
  set upload_btn(e) {
    this.$$set({ upload_btn: e }), be();
  }
  get submit_btn() {
    return this.$$.ctx[17];
  }
  set submit_btn(e) {
    this.$$set({ submit_btn: e }), be();
  }
  get stop_btn() {
    return this.$$.ctx[18];
  }
  set stop_btn(e) {
    this.$$set({ stop_btn: e }), be();
  }
  get loading_message() {
    return this.$$.ctx[19];
  }
  set loading_message(e) {
    this.$$set({ loading_message: e }), be();
  }
  get loading_status() {
    return this.$$.ctx[20];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), be();
  }
  get value_is_output() {
    return this.$$.ctx[1];
  }
  set value_is_output(e) {
    this.$$set({ value_is_output: e }), be();
  }
  get rtl() {
    return this.$$.ctx[21];
  }
  set rtl(e) {
    this.$$set({ rtl: e }), be();
  }
  get text_align() {
    return this.$$.ctx[22];
  }
  set text_align(e) {
    this.$$set({ text_align: e }), be();
  }
  get autofocus() {
    return this.$$.ctx[23];
  }
  set autofocus(e) {
    this.$$set({ autofocus: e }), be();
  }
  get autoscroll() {
    return this.$$.ctx[24];
  }
  set autoscroll(e) {
    this.$$set({ autoscroll: e }), be();
  }
  get interactive() {
    return this.$$.ctx[25];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), be();
  }
  get root() {
    return this.$$.ctx[26];
  }
  set root(e) {
    this.$$set({ root: e }), be();
  }
  get file_count() {
    return this.$$.ctx[27];
  }
  set file_count(e) {
    this.$$set({ file_count: e }), be();
  }
  get audio_btn() {
    return this.$$.ctx[28];
  }
  set audio_btn(e) {
    this.$$set({ audio_btn: e }), be();
  }
  get stop_audio_btn() {
    return this.$$.ctx[29];
  }
  set stop_audio_btn(e) {
    this.$$set({ stop_audio_btn: e }), be();
  }
  get rtc_configuration() {
    return this.$$.ctx[30];
  }
  set rtc_configuration(e) {
    this.$$set({ rtc_configuration: e }), be();
  }
  get time_limit() {
    return this.$$.ctx[31];
  }
  set time_limit(e) {
    this.$$set({ time_limit: e }), be();
  }
  get modality() {
    return this.$$.ctx[32];
  }
  set modality(e) {
    this.$$set({ modality: e }), be();
  }
  get mode() {
    return this.$$.ctx[33];
  }
  set mode(e) {
    this.$$set({ mode: e }), be();
  }
  get rtp_params() {
    return this.$$.ctx[34];
  }
  set rtp_params(e) {
    this.$$set({ rtp_params: e }), be();
  }
  get track_constraints() {
    return this.$$.ctx[35];
  }
  set track_constraints(e) {
    this.$$set({ track_constraints: e }), be();
  }
  get server() {
    return this.$$.ctx[36];
  }
  set server(e) {
    this.$$set({ server: e }), be();
  }
}
export {
  CA as default
};
