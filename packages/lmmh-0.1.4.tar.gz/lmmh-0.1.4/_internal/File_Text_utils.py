import os
import unicodedata
import re
import fitz
import docx
import pandas as pd

from flask import Flask, request
import datetime


from .Convert_utils import New_Convert_To_LMMH_Data,Old_Convert_To_LMMH_Data,Convert_To_Text_Data

import fitz  # PyMuPDF
import pytesseract
from PIL import Image
import io
import time


ALLOWED_EXTENSIONS_Doc = {'pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'}
ALLOWED_EXTENSIONS_img = {'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'tiff', 'svg'}

ALLOWED_EXTENSIONS = ALLOWED_EXTENSIONS_Doc | ALLOWED_EXTENSIONS_img

def Clean_Text_LMMH(text):
    text = unicodedata.normalize('NFKD', text)
    replacements = {
        '&': 'and',
        '–': '-',
        '—': '-',
        '“': '"',
        '”': '"',
        '’': "'",
        '‘': "'",
        '؟': '?',
    }
    for k, v in replacements.items():
        text = text.replace(k, v)
    text = re.sub(r'[^\w\s.,?!\'"-]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def Detect_Language_LMMH(text):
    from langdetect import detect
    try:
        lang = detect(text)
        return lang
    except:
        return 'en'


def Extract_Text_LMMH(Docs_LMMH_USER,filename,file):


    
    save_path = os.path.join(Docs_LMMH_USER, filename)          
    
    ext = save_path.rsplit('.', 1)[-1].lower()         
  
    
    
    if ext == 'pdf':
        if os.path.exists(Docs_LMMH_USER + '/' + filename.rsplit('.', 1)[0] +  '/' + filename.rsplit('.', 1)[0] + ".txt"):

            return open(Docs_LMMH_USER + '/' + filename.rsplit('.', 1)[0] +  '/' + filename.rsplit('.', 1)[0] + ".txt", 'r', encoding='utf-8').read()
    else:
        cache_path = os.path.join(os.path.basename(save_path))
        if os.path.exists(cache_path):
            return open(cache_path, 'r', encoding='utf-8').read()
        

    
    if ext == 'pdf':

        # Save PDF
        os.makedirs(Docs_LMMH_USER + '/' + filename.rsplit('.', 1)[0], exist_ok=True)
        pdf_path = os.path.join(Docs_LMMH_USER + '/' + filename.rsplit('.', 1)[0], filename)
        file.save(pdf_path)

        # Images + OCR
        images_folder = os.path.join(Docs_LMMH_USER + '/' + filename.rsplit('.', 1)[0], "Images")
        os.makedirs(images_folder, exist_ok=True)
        total_text = ""
        total_text_withimage_text = ""
        image_urls = []

        doc = fitz.open(pdf_path)
        for page_number, page in enumerate(doc, start=1):
            total_text += page.get_text() + "\n"
            total_text_withimage_text += page.get_text() + "\n" 
            for img_index, img in enumerate(page.get_images(full=True), start=1):
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                image = Image.open(io.BytesIO(image_bytes))
                image_name = f"page{page_number}_img{img_index}.{image_ext}"
                image_path = os.path.join(images_folder, image_name)
                image.save(image_path)

                ocr_text = pytesseract.image_to_string(image)
                total_text += f"\n[Image {image_name}]\n\n"
                total_text_withimage_text += f"\n{ocr_text}\n\n"
                with open(os.path.join(images_folder, f"page{page_number}_img{img_index}.txt"), "w", encoding="utf-8") as f:
                    f.write(ocr_text)
        

        # Save full text
        txt_filename = filename.rsplit('.', 1)[0] + ".txt"
        with open(os.path.join(Docs_LMMH_USER + '/' + filename.rsplit('.', 1)[0], txt_filename), "w", encoding="utf-8") as f:
            f.write(total_text)
        text = total_text_withimage_text



        
        
        
        
        
        
        
    elif ext == 'docx':
        # Save the file
        file.save(save_path)
        text = "\n".join([p.text for p in docx.Document(save_path).paragraphs])
    elif ext in ['xls', 'xlsx']:
        # Save the file
        file.save(save_path)
        df = pd.read_excel(save_path)
        text = df.to_string(index=False)
    else:
        # Save the file
        file.save(save_path)
        text = open(save_path, 'r', encoding='utf-8').read()
    #with open(cache_path, 'w', encoding='utf-8') as f:
       # f.write(text)
    return text


def Allowed_File(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
    
    


def Save_Data_in_History_LMMH(file_content,Question,Answer,Tools,HISTORY_FOLDER):

    # Get current timestamp
    now = datetime.datetime.now()
    timestamp = now.strftime("%H:%M:%S")
    filename_time = now.strftime("%Y%m%d")  
    
    # Define filename (you can change this to use IP or something else)
    filename = f"{HISTORY_FOLDER}/{filename_time}.HLMMH"
    
    DataInfo = f"""---------------------- New Question & Answer ----------------------\n
    Time|D|D|{timestamp}\n
    Tool|D|D|{Tools}::::::{file_content}\n
    Question|D|D|{Question}\n
    Answer|D|D|{Answer}\n"""
    
    print(DataInfo)
    
    
    # Check if the file exists
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            file_data = file.read()  # Read the contents of the file
            # Save to file
            with open(filename, "a", encoding="utf-8") as file:
                file.write((DataInfo))
    else:
        # Save to file
        with open(filename, "w", encoding="utf-8") as file:
            file.write((DataInfo))

        
        
        

