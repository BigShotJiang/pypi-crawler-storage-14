# -*- coding: utf-8 -*-
"""
Created on Sun Nov  5 16:01:02 2023

@author: atakan
"""

_T_SURROUNDING = 288.15 # K