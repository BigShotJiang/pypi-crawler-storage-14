"""contains some log utils (used to notify processing advancement)"""
