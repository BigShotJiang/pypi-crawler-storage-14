from .decorator import tool

__all__ = ["tool"]
