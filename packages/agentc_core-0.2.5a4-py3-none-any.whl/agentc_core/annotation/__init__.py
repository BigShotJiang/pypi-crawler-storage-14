from .annotation import AnnotationPredicate

__all__ = ["AnnotationPredicate"]
