

---

 Wayne Graphics

A lightweight Python graphics library built to speedrun AP CSP assignments and simplify event-driven programming.

Created by Wayne, a high school TA and PyPI developer from Martin County, Florida.

---

 Installation

`bash
pip install wayne-graphics
`

---

 Quick Start

`python
from graphics.core import *
from graphics.shapes import *
from graphics.events import *
from graphics.groups import *

Create a window
app = WayneGraphics(width=600, height=400, title="Wayne Demo")

Draw shapes
drawRect(app.canvas, 50, 50, 100, 60, color="blue")
drawCircle(app.canvas, 300, 200, 40, color="red")
drawText(app.canvas, 150, 300, "Hello Wayne!", font=("Courier", 16), color="green")

Handle mouse click
def handle_click(x, y):
    print(f"Mouse clicked at ({x}, {y})")

onMousePress(app.canvas, handle_click)

Handle key press
def handle_key(char):
    print(f"Key pressed: {char}")

onKeyPress(app.root, handle_key)

Run the app
app.run()
`

---

 Modules

core.py
 WayneGraphics: Main window class with built-in canvas and event loop
 onMousePress(func): Binds left-click handler
 onKeyPress(func): Binds keypress handler
 run(): Starts the GUI loop

shapes.py
 drawRect(canvas, x, y, width, height, color)
drawCircle(canvas, x, y, radius, color)
 drawText(canvas, x, y, text, font, color)

events.py
 Mouse Events:
   onMousePress, onMouseRelease, onMouseDrag, onMouseMove
   onMouseEnter, onMouseLeave, onRightClick, onMiddleClick, onScroll
 Keyboard Events:
   onKeyPress, onKeyRelease
 Animation:
   onStep(root, func, delay)
 Custom Binding:
   bind(canvasorroot, event, func)


groups.py
group = app.createGroup(canvas, shape)
group.move(x,y)


---

 Why Wayne Graphics?

 Minimal boilerplate — perfect for beginners and AP CSP students
 Fast setup — one-line install, instant canvas
 Event-driven — intuitive mouse and keyboard handling
 Modular design — clean separation of core, shapes, and events
 Classroom-tested — used in real AP CSP assignments

---

 Educational Use

Wayne Graphics was built to help students focus on logic and creativity, not boilerplate. It’s ideal for:
 AP Computer Science Principles
 Python graphics projects
 Teaching event-driven programming
 Rapid prototyping

---

 Contributing

Pull requests are welcome! If you’d like to add new shapes, events, or features, feel free to fork and submit.

---

 License

MIT License — free to use, modify, and distribute.

---

 Credits

Built by Wayne, a 17-year-old TA and PyPI developer from Martin County High School.  
Inspired by the need to speedrun AP CSP assignments with style.

---


