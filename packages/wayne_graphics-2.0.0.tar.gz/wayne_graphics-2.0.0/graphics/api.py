# api.py

import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from graphics.shapes import drawRect, drawCircle, drawText

class Route:
    def __init__(self, app=None) -> None:
        self.routes = {}
        self.app = app
        self.canvas = getattr(app, "canvas", None)

    def add(self, path: str, method: str, handler):
        key = (path.lower(), method.upper())
        self.routes[key] = handler

    def remove(self, path: str, method: str):
        key = (path.lower(), method.upper())
        if key in self.routes:
            del self.routes[key]

    def dispatch(self, path: str, method: str, request: dict):
        key = (path.lower(), method.upper())
        handler = self.routes.get(key)
        if not handler:
            return {"status": "error", "message": f"No route for {method} {path}"}
        try:
            return handler(request)
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ---------- Shape Routes ----------
    def register_shape_routes(self):
        # Circle
        def create_circle(req):
            x = req.get("x", 100)
            y = req.get("y", 100)
            r = req.get("radius", 50)
            color = req.get("color", "blue")
            if not self.canvas:
                return {"status": "error", "message": "No canvas available"}
            shape = drawCircle(self.canvas, x, y, r, color=color)
            return {"status": "ok", "message": f"Circle at ({x},{y}) r={r}", "id": shape}

        self.add("/circle", "POST", create_circle)

        # Rectangle
        def create_rect(req):
            x = req.get("x", 50)
            y = req.get("y", 50)
            w = req.get("width", 100)
            h = req.get("height", 50)
            color = req.get("color", "red")
            if not self.canvas:
                return {"status": "error", "message": "No canvas available"}
            shape = drawRect(self.canvas, x, y, w, h, color=color)
            return {"status": "ok", "message": f"Rect at ({x},{y}) {w}x{h}", "id": shape}

        self.add("/rect", "POST", create_rect)

        # Text
        def create_text(req):
            x = req.get("x", 200)
            y = req.get("y", 200)
            text = req.get("text", "Hello")
            color = req.get("color", "black")
            if not self.canvas:
                return {"status": "error", "message": "No canvas available"}
            shape = drawText(self.canvas, x, y, text, color=color)
            return {"status": "ok", "message": f"Text '{text}' at ({x},{y})", "id": shape}

        self.add("/text", "POST", create_text)


# ---------- HTTP Server ----------
class APIServer(BaseHTTPRequestHandler):
    router: Route = None  # shared router instance

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8")
        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            self._send_json({"status": "error", "message": "Invalid JSON"}, 400)
            return

        result = self.router.dispatch(self.path, "POST", data)
        self._send_json(result)


def run_server(router: Route, host="127.0.0.1", port=5000):
    APIServer.router = router
    server = HTTPServer((host, port), APIServer)
    print(f"Wayne-API running on http://{host}:{port}")
    server.serve_forever()
