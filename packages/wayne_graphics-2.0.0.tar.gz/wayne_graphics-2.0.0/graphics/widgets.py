from graphics.core import *
from graphics.events import *
from graphics.shapes import *
from graphics.groups import *

class Widgets:
    def __init__(self):
        # Internal collection of all active widgets
        self._registry = Group()

    def add(self, widget):
        """Register a new widget into the system."""
        self._registry.add(widget)

    def remove(self, widget):
        """Unregister a widget from the system."""
        self._registry.remove(widget)

    def draw(self, canvas):
        """Render all widgets onto the given canvas."""
        for widget in self._registry:
            widget.draw(canvas)

    def dispatch(self, event):
        """Send events to all widgets that can handle them."""
        for widget in self._registry:
            if hasattr(widget, "on_event"):
                widget.on_event(event)

        