import sys
# ---------- Response ----------
class Response:
    def ok(self, message, data=None):
        return {
            "status": "ok",
            "message": message,
            "data": data or {}
        }

    def error(self, message, details=None):
        return {
            "status": "error",
            "message": message,
            "details": details or {}
        }


class AI:
    def __init__(self):
        self.resp = Response()
        self.chat_history = []
        print("Wayne-AI ready. Paste code or type questions, and I'll explain clearly.")

    def ai_query(self, raw_text: str):
        # Save every chat
        self.chat_history.append(raw_text)
        # Explain code directly
        self._explain_code(raw_text)

    def _explain_code(self, code_snippet: str):
        """
        Explain code line by line.
        """
        lines = code_snippet.strip().split("\n")
        for i, line in enumerate(lines, start=1):
            explanation = self._analyze_line(line)
            print(f"Line {i}: {line.strip()} -> {explanation}")

    def _analyze_line(self, line: str) -> str:
        """
        Simple heuristic explanations.
        """
        line = line.strip()
        if line.startswith("class "):
            return "Defines a class — a reusable blueprint for objects."
        if line.startswith("def "):
            return "Defines a function — reusable code that can be called."
        if "import " in line:
            return "Imports external modules or functions."
        if "=" in line and "==" not in line:
            return "Assigns a value to a variable."
        if "for " in line or "while " in line:
            return "Creates a loop to repeat actions."
        if "if " in line:
            return "Conditional statement — runs code only if the condition is true."
        return "General statement or expression."

    def save_chats(self, filename="chat_log.txt"):
        with open(filename, "a") as f:
            for entry in self.chat_history:
                f.write(entry + "\n")
        self.chat_history.clear()


def main():
    ai = AI()

    # If a file path is passed as an argument, explain that file
    if len(sys.argv) > 1:
        filepath = sys.argv[1]
        try:
            with open(filepath, "r") as f:
                code = f.read()
            ai.ai_query(code)
            ai.save_chats()
        except FileNotFoundError:
            print(f"Error: File '{filepath}' not found.")
        return

    # Otherwise, start interactive CLI loop
    while True:
        try:
            raw = input("wayne-ai> ")
            if raw.lower() in ("exit", "quit"):
                ai.save_chats()
                break
            ai.ai_query(raw)
        except KeyboardInterrupt:
            ai.save_chats()
            break
