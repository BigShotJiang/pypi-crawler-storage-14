from .logger import init, log_install, log_data, set_debug, get_installation_id

__version__ = "1.1.3"
__all__ = ["init", "log_install", "log_data", "set_debug", "get_installation_id"]
