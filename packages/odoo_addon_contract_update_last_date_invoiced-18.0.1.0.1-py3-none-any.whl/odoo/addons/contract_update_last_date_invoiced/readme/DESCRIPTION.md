This module allows users to update the last date invoiced (e.g.:
deletion of invoices).
