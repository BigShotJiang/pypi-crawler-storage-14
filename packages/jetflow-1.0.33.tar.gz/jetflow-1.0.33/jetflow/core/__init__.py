"""Core module - backwards compatibility stub

This module exists for backwards compatibility.
Import from jetflow directly instead.
"""

# Don't re-export anything to avoid circular imports
# Code should import from jetflow directly now
__all__ = []
