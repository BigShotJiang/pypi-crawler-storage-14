if __name__ == "__main__":
    from rtds_vitis.app import app

    app()
