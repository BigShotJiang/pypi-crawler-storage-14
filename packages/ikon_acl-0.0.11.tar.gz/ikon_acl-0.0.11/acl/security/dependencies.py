# acl/security/dependencies.py
from fastapi import Header
from sqlalchemy.orm import Session
from typing import Callable

_db_provider: Callable[[], Session] | None = None


def register_db_provider(provider: Callable[[], Session]):
    """
    Consuming application must call this once to register a DB provider
    """
    global _db_provider
    _db_provider = provider


def get_db():
    if not _db_provider:
        raise RuntimeError(
            "No DB provider registered. Call register_db_provider() in your application."
        )

    db = _db_provider()
    try:
        yield db
    finally:
        db.close()


async def get_current_user_id(x_user_id: str = Header(...)) -> str:
    return x_user_id


async def get_current_account_id(x_account_id: str = Header(...)) -> str:
    return x_account_id
