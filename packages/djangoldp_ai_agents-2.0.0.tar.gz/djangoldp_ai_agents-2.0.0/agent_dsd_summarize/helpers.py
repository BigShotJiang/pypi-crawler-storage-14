import logging
import os

from mistralai import Mistral

logger = logging.getLogger(__name__)


def get_mistral_summary(input_text: str) -> str | None:
    """
    Gets a summary from Mistral AI.
    Returns the summary text or None if an error occurs.
    """
    try:
        api_key = os.environ.get("MISTRAL_API_KEY")
        if not api_key:
            logger.error("MISTRAL_API_KEY environment variable not set.")
            return None

        client = Mistral(api_key=api_key)
        system_prompt = (
            "Vous êtes un expert en résumé de textes. Votre rôle est de synthétiser les "
            "principales préoccupations à partir de la liste de consultations fournie. Chaque "
            "consultation comprend un titre, une description, une catégorie et l'organisme "
            "organisateur. Fournissez un résumé très court en une phrase en français qui "
            "met en évidence les principaux problèmes soulevés. "
            "Le texte doit être rédigé sans markdown."
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": input_text},
        ]
        response = client.chat.complete(
            model="mistral-small-latest",
            messages=messages,
            temperature=0.1,
        )
        summary = response.choices[0].message.content
        logger.info("Successfully got summary from Mistral AI.")
        return summary
    except Exception as e:
        logger.error(f"Mistral AI API error: {e}")
        return None


def format_consultation_for_prompt(consultation: dict) -> str:
    """Formats a consultation object into a human-readable string for the AI (:-))."""
    lines = [
        f"Title: {consultation.get('name', 'N/A')}",
        f"Description: {consultation.get('description', 'N/A')}",
        f"Category: {consultation.get('category', 'N/A')}",
    ]
    organe = consultation.get("organe")
    if organe and isinstance(organe, dict):
        lines.append(f"Organizing Body: {organe.get('name', 'N/A')}")
    return "\n".join(lines)


def json_to_prompt(objects: list[dict]) -> str:
    """
    Converts a list of consultation objects into a formatted string prompt.
    """
    return "\n\n---\n\n".join(format_consultation_for_prompt(obj) for obj in objects)
