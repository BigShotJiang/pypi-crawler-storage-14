import json

from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from pydantic import ValidationError

from agent_dsd_summarize.helpers import get_mistral_summary, json_to_prompt
from djangoldp_ai_agents.helpers import ObjectList


@method_decorator(csrf_exempt, name="dispatch")
class DSDSummarizeView(View):
    def post(self, request, *args, **kwargs):
        try:
            payload = json.loads(request.body)
            object_list = ObjectList(items=payload.get("items", []))
        except (json.JSONDecodeError, ValidationError) as e:
            return JsonResponse({"error": str(e)}, status=400)

        input_text = json_to_prompt(object_list.items)
        summary = get_mistral_summary(input_text)

        if summary:
            return JsonResponse({"summary": summary})
        else:
            return JsonResponse(
                {"error": "Failed to get summary from Mistral AI."}, status=500
            )
