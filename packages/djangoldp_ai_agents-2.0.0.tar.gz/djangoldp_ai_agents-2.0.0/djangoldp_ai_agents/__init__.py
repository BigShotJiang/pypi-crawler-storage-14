__version__ = "2.0.0"
name = "djangoldp_ai_agents"
