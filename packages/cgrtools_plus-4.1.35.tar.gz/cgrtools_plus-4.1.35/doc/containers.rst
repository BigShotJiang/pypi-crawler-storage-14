CGRtools\.containers package
============================

Data classes.

.. automodule:: CGRtools.containers
    :members:
    :undoc-members:
    :inherited-members:
