CGRtools\.utils package
=======================

Utils for data transformation.

.. automodule:: CGRtools.utils
    :members:
    :undoc-members:
    :inherited-members:
