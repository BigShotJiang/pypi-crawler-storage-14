CGRtools\.files package
=======================

Available file parsers and writers:

.. automodule:: CGRtools.files
    :members:
    :undoc-members:
