# Example notebook: https://colab.research.google.com/drive/1XpDkCMb1myskcQOILK6XaaF1g0a_8666?usp=sharing
import os
import sys
from enum import Enum
from typing import Optional, Dict, Any, List

from aiq_platform_api.common_utils import (
    AttackIQRestClient,
    AttackIQLogger,
    AssessmentUtils,
    AssessmentExecutionStrategy,
)
from aiq_platform_api.env import ATTACKIQ_PLATFORM_API_TOKEN, ATTACKIQ_PLATFORM_URL

logger = AttackIQLogger.get_logger(__name__)


def list_assessments(client: AttackIQRestClient, limit: Optional[int] = 10) -> int:
    """List assessments with basic information."""
    logger.info(f"Listing up to {limit} assessments")
    count = 0

    for assessment in AssessmentUtils.get_assessments(client, limit=limit):
        count += 1
        logger.info(f"Assessment {count}:")
        logger.info(f"  ID: {assessment.get('id', 'N/A')}")
        logger.info(f"  Name: {assessment.get('name', 'N/A')}")
        logger.info(f"  Status: {assessment.get('status', 'N/A')}")
        logger.info("---")

    logger.info(f"Total assessments listed: {count}")
    return count


def get_assessment_by_id(client: AttackIQRestClient, assessment_id: str) -> Optional[Dict[str, Any]]:
    """Get detailed information about an assessment by ID."""
    logger.info(f"Getting assessment with ID: {assessment_id}")
    assessment = AssessmentUtils.get_assessment_by_id(client, assessment_id)

    if assessment:
        logger.info(f"Assessment Name: {assessment.get('name')}")
        logger.info(f"Is Attack Graph: {assessment.get('is_attack_graph')}")  # Add more fields as needed

    return assessment


def list_assessment_runs(client: AttackIQRestClient, assessment_id: str, limit: Optional[int] = 10):
    """List recent runs for an assessment."""
    logger.info(f"Listing up to {limit} runs for assessment {assessment_id}")
    count = 0

    for run in AssessmentUtils.list_assessment_runs(client, assessment_id, limit=limit):
        count += 1
        logger.info(f"Run {count}:")
        logger.info(f"  ID: {run.get('id', 'N/A')}")
        logger.info(f"  Created: {run.get('created_at', 'N/A')}")
        logger.info(f"  Scenario Jobs In Progress: {run.get('scenario_jobs_in_progress', 'N/A')}")
        logger.info(f"  Integration Jobs In Progress: {run.get('integration_jobs_in_progress', 'N/A')}")
        logger.info("---")

    return count


def run_and_monitor_assessment(
    client: AttackIQRestClient,
    assessment_id: str,
    assessment_version: int,
    timeout: int = 600,
    check_interval: int = 5,
) -> Optional[str]:
    """Run an assessment and wait for it to complete."""
    logger.info(f"Running assessment {assessment_id} and monitoring completion")

    try:
        # Start the assessment
        run_id = AssessmentUtils.run_assessment(client, assessment_id, assessment_version)
        logger.info(f"Assessment started with run ID: {run_id}")

        # Wait for completion
        without_detection = True
        completed = AssessmentUtils.wait_for_run_completion(
            client, assessment_id, run_id, timeout, check_interval, without_detection
        )

        if completed:
            logger.info(f"Assessment run {run_id} completed successfully")
            return run_id
        else:
            logger.warning(f"Assessment run {run_id} did not complete within {timeout} seconds")
            return None

    except Exception as e:
        logger.error(f"Error running assessment: {str(e)}")
        return None


def get_run_results(
    client: AttackIQRestClient, run_id: str, assessment_version: int, limit: Optional[int] = 10
) -> List[Dict[str, Any]]:
    """Get results for a completed run and return them as a list."""
    logger.info(f"Getting results for run {run_id}")

    results_generator = AssessmentUtils.get_results_by_run_id(client, run_id, assessment_version, limit=limit)
    collected_results = []
    for i, result in enumerate(results_generator):
        logger.info(f"Result {i + 1}:")
        logger.info(f"  ID: {result.get('id', 'N/A')}")
        logger.info(f"  Outcome: {result.get('outcome', 'N/A')}")
        logger.info(f"  Start: {result.get('started_at', result.get('start_time', 'N/A'))}")
        logger.info(f"  End: {result.get('ended_at', result.get('end_time', 'N/A'))}")
        logger.info("---")
        collected_results.append(result)
    return collected_results


def get_detailed_result(
    client: AttackIQRestClient, result_id: str, assessment_version: int
) -> Optional[Dict[str, Any]]:
    """Get detailed information about a specific result, including intermediate results."""
    logger.info(f"Getting detailed information for result {result_id}")
    result = AssessmentUtils.get_result_details(client, result_id, assessment_version)

    if not result:
        logger.error(f"Could not retrieve detailed result for result ID: {result_id}")
        return None

    logger.info("--- Detailed Result ---")
    logger.info(f"  Result ID: {result.get('id', 'N/A')}")
    logger.info(f"  Overall Outcome: {result.get('outcome', 'N/A')}")
    logger.info(f"  Detection Outcome: {result.get('detection_outcome', 'N/A')}")
    logger.info(f"  Run Started At: {result.get('run_started_at', 'N/A')}")

    # Log intermediate results
    intermediate_results = result.get("intermediate_results")
    if intermediate_results and isinstance(intermediate_results, list):
        logger.info("--- Intermediate Results (Nodes/Steps) ---")
        for i, step in enumerate(intermediate_results):
            logger.info(f"  Step {i + 1}:")
            logger.info(f"    Node ID: {step.get('node_id', 'N/A')}")
            logger.info(f"    Scenario Name: {step.get('scenario_name', 'N/A')}")
            logger.info(f"    Outcome: {step.get('outcome', 'N/A')}")

    return result


def list_assets_in_assessment(client: AttackIQRestClient, assessment_id: str, limit: Optional[int] = 10):
    """List assets associated with an assessment."""
    logger.info(f"Listing assets for assessment {assessment_id}")
    count = 0

    for asset in AssessmentUtils.get_assets_in_assessment(client, assessment_id, limit=limit):
        count += 1
        logger.info(f"Asset {count}:")
        logger.info(f"  ID: {asset.get('id', 'N/A')}")
        logger.info(f"  Name: {asset.get('name', 'N/A')}")
        logger.info(f"  Type: {asset.get('type', 'N/A')}")
        logger.info(f"  IP Address: {asset.get('ipv4_address', 'N/A')}")
        logger.info("---")

    return count


def assessment_workflow_demo(client: AttackIQRestClient, assessment_id: str, run_assessment: bool):
    """Demonstrate a complete assessment workflow."""
    logger.info(f"Starting assessment workflow demo for assessment {assessment_id}")

    # Step 1: Get assessment metadata
    assessment = get_assessment_by_id(client, assessment_id)
    if not assessment:
        logger.error("Could not get assessment metadata. Aborting workflow.")
        return

    # Step 2: List recent runs
    list_assessment_runs(client, assessment_id)

    # Step 3: Run the assessment and wait for completion
    run_id = None
    assessment_version = assessment["version"]
    if run_assessment:
        run_id = run_and_monitor_assessment(client, assessment_id, assessment_version, timeout=300, check_interval=5)

    # If we didn't run an assessment or it didn't complete, get the most recent run
    if not run_id:
        run = AssessmentUtils.get_most_recent_run_status(client, assessment_id)
        if not run:
            logger.error("No runs found for assessment. Aborting workflow.")
            return
        run_id = run.get("id")

    # Step 4: Get results for the run
    assessment_version = assessment["version"]
    results = get_run_results(client, run_id, assessment_version)
    if not results:
        logger.error("No results found for run. Aborting workflow.")
        return

    # Step 5: Get detailed results including intermediate results
    for result in results:
        get_detailed_result(client, result["id"], assessment_version)


def test_list_assessments(client: AttackIQRestClient):
    """Test listing assessments."""
    list_assessments(client, limit=5)


def test_get_recent_run(client: AttackIQRestClient, assessment_id: str):
    """Test getting the most recent run."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    run = AssessmentUtils.get_most_recent_run_status(client, assessment_id)
    if run:
        logger.info(f"Recent run: {run.get('id')}")
        logger.info(f"  Created: {run.get('created', 'N/A')}")
        logger.info(f"  Progress: {run.get('done_count', 0)}/{run.get('total_count', 0)} completed")
        logger.info(f"  Completed: {run.get('completed', False)}")
    else:
        logger.info("No runs found")


def test_run_assessment(client: AttackIQRestClient, assessment_id: str):
    """Test running an assessment."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    assessment = AssessmentUtils.get_assessment_by_id(client, assessment_id)
    if not assessment:
        logger.error(f"Assessment {assessment_id} not found")
        return

    assessment_version = assessment["version"]
    run_id = run_and_monitor_assessment(client, assessment_id, assessment_version)
    if run_id:
        results = list(AssessmentUtils.get_results_by_run_id(client, run_id, assessment_version, limit=3))
        logger.info(f"Completed with {len(results)} results")


def test_get_results(client: AttackIQRestClient, assessment_id: str):
    """Test getting results for the most recent run."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    assessment = AssessmentUtils.get_assessment_by_id(client, assessment_id)
    if not assessment:
        logger.error(f"Assessment {assessment_id} not found")
        return

    assessment_version = assessment["version"]
    run = AssessmentUtils.get_most_recent_run_status(client, assessment_id)
    if run:
        run_id = run.get("id")
        results = get_run_results(client, run_id, assessment_version)
        logger.info(f"Retrieved {len(results)} results")


def test_get_recent_run_results(client: AttackIQRestClient, assessment_id: str):
    """Test getting detailed results for the most recent run."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    assessment = AssessmentUtils.get_assessment_by_id(client, assessment_id)
    if not assessment:
        logger.error(f"Assessment {assessment_id} not found")
        return

    assessment_version = assessment["version"]
    run = AssessmentUtils.get_most_recent_run_status(client, assessment_id)
    if run:
        run_id = run.get("id")
        logger.info(f"Getting results for recent run: {run_id}")
        logger.info(f"  Run completed: {run.get('completed', False)}")
        logger.info(f"  Progress: {run.get('done_count', 0)}/{run.get('total_count', 0)}")

        results = get_run_results(client, run_id, assessment_version, limit=10)
        if results:
            logger.info(f"Successfully retrieved {len(results)} results")
            for result in results[:3]:  # Show first 3 results
                get_detailed_result(client, result["id"], assessment_version)
        else:
            logger.warning("No results found for the most recent run")
    else:
        logger.info("No recent runs found")


def test_execution_with_detection(client: AttackIQRestClient, assessment_id: str):
    """Test setting execution strategy to run with detection validation."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    result = AssessmentUtils.set_execution_strategy(client, assessment_id, with_detection=True)
    logger.info(f"Set execution WITH detection: {'Success' if result else 'Failed'}")


def test_execution_without_detection(client: AttackIQRestClient, assessment_id: str):
    """Test setting execution strategy to run without detection validation."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    result = AssessmentUtils.set_execution_strategy(client, assessment_id, with_detection=False)
    logger.info(f"Set execution WITHOUT detection: {'Success' if result else 'Failed'}")


def test_get_execution_strategy(client: AttackIQRestClient, assessment_id: str):
    """Get and display execution strategy for an assessment."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    strategy = AssessmentUtils.get_execution_strategy(client, assessment_id)
    assessment = AssessmentUtils.get_assessment_by_id(client, assessment_id)

    logger.info(f"Assessment: {assessment.get('name')}")
    logger.info(f"Execution Strategy: {strategy.name} (value={strategy.value})")

    if strategy == AssessmentExecutionStrategy.WITH_DETECTION:
        logger.info("Detection validation is ENABLED")
    else:
        logger.info("Detection validation is DISABLED")

    return strategy


def test_workflow_demo(client: AttackIQRestClient, assessment_id: str):
    """Test the full workflow demo."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    assessment_workflow_demo(client, assessment_id, run_assessment=True)


def test_all(client: AttackIQRestClient, assessment_id: str):
    """Run all tests."""
    list_assessments(client, limit=3)
    if assessment_id:
        get_assessment_by_id(client, assessment_id)
        run = AssessmentUtils.get_most_recent_run_status(client, assessment_id)
        if run:
            logger.info(f"Most recent run: {run.get('id')}")
            logger.info(f"  Progress: {run.get('done_count', 0)}/{run.get('total_count', 0)} completed")
        list_assessment_runs(client, assessment_id, limit=3)
        assessment_workflow_demo(client, assessment_id, run_assessment=False)


def test_search_assessments_pagination(client: AttackIQRestClient):
    """Validate search_assessments pagination (offset, limit, count)."""
    logger.info("=" * 60)
    logger.info("TEST: search_assessments pagination")
    logger.info("=" * 60)

    # Test 1: Basic search with count
    result = AssessmentUtils.search_assessments(client, limit=3, offset=0)
    total_count = result.get("count", 0)
    results = result.get("results", [])
    logger.info(f"Total count: {total_count}, Page 1 results: {len(results)}")

    if total_count == 0:
        logger.warning("No assessments found - cannot validate pagination")
        return

    # Test 2: Validate offset works (different results)
    if total_count > 3:
        page1_ids = {a["id"] for a in results}
        result2 = AssessmentUtils.search_assessments(client, limit=3, offset=3)
        page2_results = result2.get("results", [])
        page2_ids = {a["id"] for a in page2_results}

        overlap = page1_ids & page2_ids
        if overlap:
            logger.error(f"FAIL: Pages overlap! IDs in both: {overlap}")
        else:
            logger.info("PASS: Page 1 and Page 2 have different results")
    else:
        logger.info(f"SKIP: Only {total_count} assessments, cannot test offset")

    # Test 3: Version filter
    result_v1 = AssessmentUtils.search_assessments(client, version=1, limit=3)
    result_v2 = AssessmentUtils.search_assessments(client, version=2, limit=3)
    logger.info(f"v1 assessments: {result_v1.get('count', 0)}")
    logger.info(f"v2 assessments: {result_v2.get('count', 0)}")

    # Test 4: Search query
    result_search = AssessmentUtils.search_assessments(client, query="test", limit=3)
    logger.info(f"Search 'test': {result_search.get('count', 0)} matches")

    logger.info("PASS: search_assessments pagination validated")


def test_search_assessment_runs_pagination(client: AttackIQRestClient, assessment_id: str):
    """Validate search_assessment_runs pagination (offset, limit, count)."""
    if not assessment_id:
        logger.error("ASSESSMENT_ID required for this test")
        return

    logger.info("=" * 60)
    logger.info("TEST: search_assessment_runs pagination")
    logger.info("=" * 60)

    # Test 1: Basic search with count
    result = AssessmentUtils.search_assessment_runs(client, assessment_id, limit=3, offset=0)
    total_count = result.get("count", 0)
    results = result.get("results", [])
    logger.info(f"Total runs: {total_count}, Page 1 results: {len(results)}")

    if total_count == 0:
        logger.warning("No runs found - cannot validate pagination")
        return

    # Test 2: Validate offset works (different results)
    if total_count > 3:
        page1_ids = {r["id"] for r in results}
        result2 = AssessmentUtils.search_assessment_runs(client, assessment_id, limit=3, offset=3)
        page2_results = result2.get("results", [])
        page2_ids = {r["id"] for r in page2_results}

        overlap = page1_ids & page2_ids
        if overlap:
            logger.error(f"FAIL: Pages overlap! IDs in both: {overlap}")
        else:
            logger.info("PASS: Page 1 and Page 2 have different results")
    else:
        logger.info(f"SKIP: Only {total_count} runs, cannot test offset")

    logger.info("PASS: search_assessment_runs pagination validated")


def test_assessment_filters(client: AttackIQRestClient) -> Dict[str, Any]:
    """Validate all assessment filter parameters work correctly.

    Run: poetry run python aiq_platform_api/assessment_use_cases.py
    Then set choice = TestChoice.TEST_FILTERS
    """
    logger.info("=" * 60)
    logger.info("TEST: Assessment Filter Validation")
    logger.info("=" * 60)

    results = {"passed": 0, "failed": 0, "tests": []}

    # Baseline
    baseline = AssessmentUtils.search_assessments(client, limit=1)
    total = baseline.get("count", 0)
    logger.info(f"BASELINE: Total assessments = {total}\n")

    # Get sample data for UUID filters
    sample = baseline.get("results", [{}])[0] if baseline.get("results") else {}
    sample_user_id = sample.get("users", [None])[0]
    sample_template_id = sample.get("project_template_id")

    def check(name: str, condition: bool, detail: str):
        status = "✅ PASS" if condition else "❌ FAIL"
        results["passed" if condition else "failed"] += 1
        results["tests"].append({"name": name, "passed": condition, "detail": detail})
        logger.info(f"{name}: {status} - {detail}")

    # 1. version filter
    v1 = AssessmentUtils.search_assessments(client, version=1, limit=1).get("count", 0)
    v2 = AssessmentUtils.search_assessments(client, version=2, limit=1).get("count", 0)
    check("version", v1 + v2 == total, f"v1={v1} + v2={v2} = {v1+v2} (expected {total})")

    # 2. created_after filter
    r = AssessmentUtils.search_assessments(client, created_after="2025-01-01T00:00:00Z", limit=1).get("count", 0)
    check("created_after", r < total, f"filtered to {r} (from {total})")

    # 3. modified_after filter
    r = AssessmentUtils.search_assessments(client, modified_after="2025-11-01T00:00:00Z", limit=1).get("count", 0)
    check("modified_after", r < total, f"filtered to {r} (from {total})")

    # 4. execution_strategy filter
    e0 = AssessmentUtils.search_assessments(client, execution_strategy=0, limit=1).get("count", 0)
    e1 = AssessmentUtils.search_assessments(client, execution_strategy=1, limit=1).get("count", 0)
    check("execution_strategy", e0 + e1 == total, f"0={e0} + 1={e1} = {e0+e1} (expected {total})")

    # 5. user_id filter
    if sample_user_id:
        r = AssessmentUtils.search_assessments(client, user_id=sample_user_id, limit=1).get("count", 0)
        check("user_id", 0 < r <= total, f"filtered to {r} for user {sample_user_id[:8]}...")

    # 6. is_attack_graph filter
    ag_true = AssessmentUtils.search_assessments(client, is_attack_graph=True, limit=1).get("count", 0)
    ag_false = AssessmentUtils.search_assessments(client, is_attack_graph=False, limit=1).get("count", 0)
    check(
        "is_attack_graph",
        ag_true + ag_false == total,
        f"true={ag_true} + false={ag_false} = {ag_true+ag_false} (expected {total})",
    )

    # 7. project_template_id filter
    if sample_template_id:
        r = AssessmentUtils.search_assessments(client, project_template_id=sample_template_id, limit=1).get("count", 0)
        check("project_template_id", 0 < r <= total, f"filtered to {r} for template {sample_template_id[:8]}...")

    # 8. Combined filters
    r = AssessmentUtils.search_assessments(client, version=1, is_attack_graph=False, limit=1).get("count", 0)
    check("combined_filters", r <= min(v1, ag_false), f"v1 AND !attack_graph = {r} (<= {min(v1, ag_false)})")

    # 9. Search + filter
    r = AssessmentUtils.search_assessments(client, query="security", version=2, limit=1).get("count", 0)
    check("search_with_filter", r <= v2, f"query='security' AND v2 = {r} (<= {v2})")

    logger.info(f"\n{'='*50}")
    logger.info(f"RESULTS: {results['passed']} passed, {results['failed']} failed")
    logger.info(f"{'='*50}")
    return results


def test_assessment_runs(client: AttackIQRestClient) -> Dict[str, Any]:
    """Validate assessment runs functions work correctly.

    Run: ATTACKIQ_PLATFORM_URL=... ATTACKIQ_PLATFORM_API_TOKEN=... python -c "
    from aiq_platform_api.assessment_use_cases import test_assessment_runs
    from aiq_platform_api import AttackIQRestClient, ATTACKIQ_PLATFORM_URL, ATTACKIQ_PLATFORM_API_TOKEN
    client = AttackIQRestClient(ATTACKIQ_PLATFORM_URL, ATTACKIQ_PLATFORM_API_TOKEN)
    test_assessment_runs(client)
    "
    """
    results = {"passed": 0, "failed": 0, "tests": []}

    def check(name: str, condition: bool, detail: str):
        status = "✅ PASS" if condition else "❌ FAIL"
        results["passed" if condition else "failed"] += 1
        results["tests"].append({"name": name, "passed": condition, "detail": detail})
        logger.info(f"{name}: {status} - {detail}")

    # Get an assessment with runs
    assessments = AssessmentUtils.search_assessments(client, limit=5)
    assessment_id = None
    for a in assessments.get("results", []):
        runs = AssessmentUtils.search_assessment_runs(client, a["id"], limit=1)
        if runs.get("count", 0) > 0:
            assessment_id = a["id"]
            break

    if not assessment_id:
        logger.error("❌ No assessment with runs found")
        return results

    logger.info(f"Using assessment: {assessment_id[:8]}...\n")

    # 1. search_assessment_runs returns proper format
    runs = AssessmentUtils.search_assessment_runs(client, assessment_id, limit=3)
    has_count = "count" in runs
    has_results = "results" in runs
    check(
        "search_runs_format",
        has_count and has_results,
        f"count={runs.get('count', 0)}, results={len(runs.get('results', []))}",
    )

    # 2. search_assessment_runs has run data
    run_count = runs.get("count", 0)
    check("search_runs_data", run_count > 0, f"found {run_count} runs")

    if runs.get("results"):
        run = runs["results"][0]
        run_id = run.get("id")

        # 3. Run has expected fields
        check("list_run_has_id", "id" in run, f"id={'present' if 'id' in run else 'missing'}")
        check(
            "list_run_has_project_id",
            "project_id" in run,
            f"project_id={'present' if 'project_id' in run else 'missing'}",
        )

        # 4. get_run returns data
        run_details = AssessmentUtils.get_run(client, assessment_id, run_id)
        check("get_run_returns", run_details is not None, f"returned {'dict' if run_details else 'None'}")

        if run_details:
            # 5. Run details has expected fields
            check(
                "get_run_has_run_id",
                "run_id" in run_details,
                f"run_id={'present' if 'run_id' in run_details else 'missing'}",
            )
            check(
                "get_run_has_status",
                "status" in run_details,
                f"status={'present' if 'status' in run_details else 'missing'}",
            )

            # 6. Status is valid
            status = run_details.get("status", "")
            valid_statuses = ["Completed", "Running", "Pending", "Cancelled", "Failed"]
            check("run_status_valid", status in valid_statuses, f"status='{status}'")

    logger.info(f"\n{'='*50}")
    logger.info(f"RESULTS: {results['passed']} passed, {results['failed']} failed")
    logger.info(f"{'='*50}")
    return results


# ============================================================================
# Assessment Configuration Test (with SRP private helpers)
# ============================================================================


def _print_header(text: str) -> None:
    """Print a section header."""
    print(f"\n{'=' * 70}")
    print(f"  {text}")
    print(f"{'=' * 70}")


def _print_subheader(text: str) -> None:
    """Print a subsection header."""
    print(f"\n  {text}")
    print(f"  {'-' * 66}")


def _find_assessment_with_analysis(client: AttackIQRestClient) -> Optional[str]:
    """Find first assessment that has _analysis data."""
    for is_ag in [False, True]:
        assessments = AssessmentUtils.search_assessments(client, is_attack_graph=is_ag, limit=5)
        for a in assessments.get("results", []):
            result = AssessmentUtils.get_assessment_by_id(client, a["id"], include_tests=True)
            if result and "_analysis" in result:
                return a["id"]
    return None


def _print_assessment_summary(data: Dict[str, Any], analysis: Dict[str, Any]) -> None:
    """Print assessment name, ID, type, and version."""
    _print_header("ASSESSMENT CONFIGURATION")
    print(f"  Name: {data.get('name', 'N/A')[:55]}")
    print(f"  ID: {data.get('id')}")
    print(f"  Type: {analysis.get('assessment_type', 'Unknown')}")
    print(f"  Version: v{data.get('version', 1)}")

    _print_header("ANALYSIS (_analysis from get_assessment_by_id)")
    for key, value in analysis.items():
        print(f"  {key}: {value}")


def _print_attack_graph_details(data: Dict[str, Any]) -> None:
    """Print attack graph stages and nodes."""
    ag = data.get("attack_graph", {})
    graph = ag.get("graph", {})
    stages = graph.get("graph_meta", {}).get("stages", {})
    nodes = graph.get("graph", {})

    _print_subheader(f"Stages ({len(stages)})")
    for stage_id, stage_data in list(stages.items())[:4]:
        if isinstance(stage_data, dict):
            title = stage_data.get("title", f"Stage {stage_id}")
            node_ids = stage_data.get("node_ids", [])
            print(f"    [{stage_id}] {title[:45]}: {len(node_ids)} node(s)")

    _print_subheader(f"Nodes ({len(nodes)} scenarios)")
    for node_id, node in list(nodes.items())[:3]:
        name = node.get("scenario_name", "N/A")
        multi = " [MULTI-ASSET]" if node.get("is_multi_asset") else ""
        print(f"    [{node_id}] {name[:50]}...{multi}")
    if len(nodes) > 3:
        print(f"    ... +{len(nodes) - 3} more")


def _print_boundaries(boundaries: List[Dict]) -> None:
    """Print boundary attacker→target pairs."""
    if not boundaries:
        return
    _print_subheader(f"Boundaries ({len(boundaries)} attacker→target pairs)")
    for i, b in enumerate(boundaries[:2]):
        print(f"    [{i+1}] {b.get('attacker_asset_id', '')[:12]}... → {b.get('target_asset_id', '')[:12]}...")


def _print_test_scenarios(scenarios: List[Dict]) -> None:
    """Print sample scenarios for a test."""
    for s in scenarios[:2]:
        scenario = s.get("scenario", {})
        model_json = s.get("model_json", {})
        multi = " [MULTI-ASSET]" if scenario.get("is_multi_asset") else ""
        keys = list(model_json.keys())[:3] if model_json else []
        print(f"        - {scenario.get('name', 'N/A')[:35]}...{multi}")
        if keys:
            print(f"          model_json: {{{', '.join(keys)}...}}")
    if len(scenarios) > 2:
        print(f"        ... +{len(scenarios) - 2} more scenarios")


def _print_test_assets(assets: List[Dict]) -> None:
    """Print sample assets for a test."""
    if not assets:
        return
    for a in assets[:2]:
        asset = a.get("asset", {})
        print(f"        * {asset.get('hostname', 'N/A')} ({asset.get('ipv4_address', 'N/A')})")
    if len(assets) > 2:
        print(f"        ... +{len(assets) - 2} more assets")


def _print_atomic_tests(tests: List[Dict]) -> None:
    """Print tests with scenarios and assets."""
    _print_subheader(f"Tests ({len(tests)})")
    for i, test in enumerate(tests[:2]):
        scenarios = test.get("scenarios", [])
        assets = test.get("assets", [])
        print(f"  [{i+1}] {test.get('name', 'N/A')[:45]}")
        print(f"      scenarios: {len(scenarios)}, assets: {len(assets)}")
        _print_test_scenarios(scenarios)
        _print_test_assets(assets)
    if len(tests) > 2:
        print(f"  ... +{len(tests) - 2} more tests")


def _print_sample_model_json(tests: List[Dict]) -> None:
    """Print first model_json as sample."""
    import json

    for test in tests:
        for s in test.get("scenarios", []):
            model_json = s.get("model_json", {})
            if model_json:
                _print_header("SAMPLE model_json → scenario_args")
                print(f"  {s.get('scenario', {}).get('name', 'N/A')[:55]}...")
                print(json.dumps(model_json, indent=2))
                return


def test_assessment_configuration(client: AttackIQRestClient, assessment_id: Optional[str] = None) -> None:
    """Display assessment configuration using _analysis from get_assessment_by_id().

    Run:
        python -c "from aiq_platform_api.assessment_use_cases import test_assessment_configuration; ..."
    """
    if not assessment_id:
        assessment_id = _find_assessment_with_analysis(client)

    if not assessment_id:
        print("No suitable assessment found")
        return

    data = AssessmentUtils.get_assessment_by_id(client, assessment_id, include_tests=True)
    if not data:
        print(f"Assessment {assessment_id} not found")
        return

    analysis = data.get("_analysis", {})

    _print_assessment_summary(data, analysis)

    if analysis.get("is_attack_graph"):
        _print_attack_graph_details(data)
    else:
        _print_boundaries(data.get("boundaries", []))
        _print_atomic_tests(data.get("tests", []))
        _print_sample_model_json(data.get("tests", []))


def run_test(choice: "TestChoice", client: AttackIQRestClient, assessment_id: str):
    """Run the selected test."""
    test_functions = {
        TestChoice.LIST_ASSESSMENTS: lambda: test_list_assessments(client),
        TestChoice.GET_RECENT_RUN: lambda: test_get_recent_run(client, assessment_id),
        TestChoice.RUN_ASSESSMENT: lambda: test_run_assessment(client, assessment_id),
        TestChoice.WORKFLOW_DEMO: lambda: test_workflow_demo(client, assessment_id),
        TestChoice.GET_RESULTS: lambda: test_get_results(client, assessment_id),
        TestChoice.GET_RECENT_RUN_RESULTS: lambda: test_get_recent_run_results(client, assessment_id),
        TestChoice.EXECUTION_WITH_DETECTION: lambda: test_execution_with_detection(client, assessment_id),
        TestChoice.EXECUTION_WITHOUT_DETECTION: lambda: test_execution_without_detection(client, assessment_id),
        TestChoice.GET_EXECUTION_STRATEGY: lambda: test_get_execution_strategy(client, assessment_id),
        TestChoice.SEARCH_ASSESSMENTS_PAGINATION: lambda: test_search_assessments_pagination(client),
        TestChoice.SEARCH_RUNS_PAGINATION: lambda: test_search_assessment_runs_pagination(client, assessment_id),
        TestChoice.TEST_FILTERS: lambda: test_assessment_filters(client),
        TestChoice.TEST_RUNS: lambda: test_assessment_runs(client),
        TestChoice.TEST_CONFIGURATION: lambda: test_assessment_configuration(client, assessment_id),
        TestChoice.ALL: lambda: test_all(client, assessment_id),
    }

    test_func = test_functions.get(choice)
    if test_func:
        test_func()
    else:
        logger.error(f"Unknown test choice: {choice}")


if __name__ == "__main__":
    if not ATTACKIQ_PLATFORM_URL or not ATTACKIQ_PLATFORM_API_TOKEN:
        logger.error("Missing ATTACKIQ_PLATFORM_URL or ATTACKIQ_PLATFORM_API_TOKEN")
        sys.exit(1)

    class TestChoice(Enum):
        LIST_ASSESSMENTS = "list_assessments"
        GET_RECENT_RUN = "get_recent_run"
        RUN_ASSESSMENT = "run_assessment"
        WORKFLOW_DEMO = "workflow_demo"
        GET_RESULTS = "get_results"
        GET_RECENT_RUN_RESULTS = "get_recent_run_results"
        EXECUTION_WITH_DETECTION = "execution_with_detection"
        EXECUTION_WITHOUT_DETECTION = "execution_without_detection"
        GET_EXECUTION_STRATEGY = "get_execution_strategy"
        SEARCH_ASSESSMENTS_PAGINATION = "search_assessments_pagination"
        SEARCH_RUNS_PAGINATION = "search_runs_pagination"
        TEST_FILTERS = "test_filters"
        TEST_RUNS = "test_runs"
        TEST_CONFIGURATION = "test_configuration"
        ALL = "all"

    client = AttackIQRestClient(ATTACKIQ_PLATFORM_URL, ATTACKIQ_PLATFORM_API_TOKEN)
    assessment_id = os.environ.get("ASSESSMENT_ID") or os.environ.get("ATTACKIQ_ATOMIC_ASSESSMENT_ID")

    # Change this to test different functionalities
    # choice = TestChoice.GET_RECENT_RUN
    # choice = TestChoice.LIST_ASSESSMENTS
    # choice = TestChoice.RUN_ASSESSMENT
    # choice = TestChoice.WORKFLOW_DEMO
    # choice = TestChoice.GET_RESULTS
    # choice = TestChoice.GET_RECENT_RUN_RESULTS
    # choice = TestChoice.EXECUTION_WITH_DETECTION
    # choice = TestChoice.EXECUTION_WITHOUT_DETECTION
    # choice = TestChoice.GET_EXECUTION_STRATEGY
    choice = TestChoice.SEARCH_ASSESSMENTS_PAGINATION
    # choice = TestChoice.ALL

    run_test(choice, client, assessment_id)
