"""
Unit tests for klug-builds CLI commands (with mocked requests).
"""
import os
import sys
import json
import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

pytestmark = pytest.mark.unit

# Add parent directory to path to import main
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import using direct file import
import importlib.util
main_path = os.path.join(parent_dir, "main.py")
spec = importlib.util.spec_from_file_location("main", main_path)
main_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(main_module)

# Import the CLI components
cli = main_module.cli


@pytest.fixture
def runner():
    """Create a CLI runner for testing."""
    return CliRunner()


@pytest.fixture(autouse=True)
def mock_env():
    """Set up environment variables for testing."""
    with patch.dict(os.environ, {
        'KLUG_AUTOCLOUD_API_KEY': 'test-api-key',
        'KLUG_BUILDS_API_ENDPOINT': 'https://test-api.example.com/prod'
    }, clear=False):
        yield


@pytest.fixture
def mock_requests():
    """Mock requests library."""
    with patch('requests.get') as mock_get, \
         patch('requests.post') as mock_post, \
         patch('requests.put') as mock_put, \
         patch('requests.delete') as mock_delete:
        mock_req = MagicMock()
        mock_req.get = mock_get
        mock_req.post = mock_post
        mock_req.put = mock_put
        mock_req.delete = mock_delete
        yield mock_req


class TestBuildCommand:
    """Test build command."""
    
    def test_build_success(self, runner, mock_requests, tmp_path):
        """Test successful build."""
        # Create test directories
        api_dir = tmp_path / 'api'
        layers_dir = tmp_path / 'layers'
        api_dir.mkdir()
        layers_dir.mkdir()
        
        # Create test files
        (api_dir / 'test.py').write_text('print("test")')
        (layers_dir / 'test.py').write_text('print("layer")')
        
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'build_id': 'test-build-id',
            'status': 'pending',
            'system_id': 'main',
            'env_name': 'dev'
        }
        mock_response.raise_for_status = MagicMock()
        mock_requests.post.return_value = mock_response
        
        # Mock status polling
        status_response = MagicMock()
        status_response.json.return_value = {
            'build_id': 'test-build-id',
            'status': 'completed',
            'api_endpoint': 'https://api.example.com/live'
        }
        status_response.raise_for_status = MagicMock()
        mock_requests.get.return_value = status_response
        
        result = runner.invoke(cli, [
            'build',
            str(api_dir),
            str(layers_dir),
            '--system', 'main',
            '--env', 'dev'
        ])
        
        assert result.exit_code == 0
        assert 'Build initiated' in result.output
        assert 'completed successfully' in result.output
        mock_requests.post.assert_called_once()
    
    def test_build_missing_directories(self, runner):
        """Test build with missing directories."""
        result = runner.invoke(cli, [
            'build',
            '/nonexistent/api',
            '/nonexistent/layers',
            '--system', 'main',
            '--env', 'dev'
        ])
        
        assert result.exit_code != 0
        assert 'Error' in result.output


class TestListCommand:
    """Test list command."""
    
    def test_list_builds(self, runner, mock_requests):
        """Test listing builds."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'builds': [
                {
                    'build_id': 'build-1',
                    'system_id': 'main',
                    'env_name': 'dev',
                    'status': 'completed',
                    'created_at': '2024-01-01T00:00:00'
                },
                {
                    'build_id': 'build-2',
                    'system_id': 'main',
                    'env_name': 'prod',
                    'status': 'failed',
                    'created_at': '2024-01-02T00:00:00'
                }
            ],
            'count': 2
        }
        mock_response.raise_for_status = MagicMock()
        mock_requests.get.return_value = mock_response
        
        result = runner.invoke(cli, ['list'])
        
        assert result.exit_code == 0
        assert 'build-1' in result.output
        assert 'build-2' in result.output
        mock_requests.get.assert_called_once()
    
    def test_list_builds_filtered(self, runner, mock_requests):
        """Test listing builds with filters."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'builds': [],
            'count': 0
        }
        mock_response.raise_for_status = MagicMock()
        mock_requests.get.return_value = mock_response
        
        result = runner.invoke(cli, ['list', '--system', 'main', '--env', 'dev'])
        
        assert result.exit_code == 0
        call_args = mock_requests.get.call_args
        assert call_args[1]['params']['system_id'] == 'main'
        assert call_args[1]['params']['env_name'] == 'dev'


class TestStatusCommand:
    """Test status command."""
    
    def test_get_build_status(self, runner, mock_requests):
        """Test getting build status."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'build_id': 'test-build-id',
            'status': 'completed',
            'system_id': 'main',
            'env_name': 'dev',
            'created_at': '2024-01-01T00:00:00',
            'api_endpoint': 'https://api.example.com/live'
        }
        mock_response.raise_for_status = MagicMock()
        mock_requests.get.return_value = mock_response
        
        result = runner.invoke(cli, ['status', 'test-build-id'])
        
        assert result.exit_code == 0
        assert 'test-build-id' in result.output
        assert 'completed' in result.output
        assert 'https://api.example.com/live' in result.output
        mock_requests.get.assert_called_once()


class TestErrorHandling:
    """Test error handling scenarios."""
    
    def test_missing_api_key(self, runner):
        """Test error when API key is missing."""
        with patch.dict(os.environ, {}, clear=True):
            result = runner.invoke(cli, ['list'])
            assert result.exit_code != 0
            assert 'KLUG_AUTOCLOUD_API_KEY' in result.output
    
    def test_http_error(self, runner, mock_requests):
        """Test handling of HTTP errors."""
        from requests.exceptions import HTTPError
        mock_response = MagicMock()
        mock_response.json.return_value = {'error': 'Unauthorized'}
        http_error = HTTPError('401 Unauthorized')
        http_error.response = mock_response
        mock_response.raise_for_status.side_effect = http_error
        mock_requests.get.return_value = mock_response
        
        result = runner.invoke(cli, ['list'])
        
        assert result.exit_code != 0
        assert 'Error' in result.output

