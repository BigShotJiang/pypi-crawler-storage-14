"""
Main CLI entry point for klug-builds.
"""
import os
import sys
import click
import requests
import json
import zipfile
import hashlib
from pathlib import Path
from typing import Optional, Dict, Any
from uuid import uuid4

# Default API endpoint (can be overridden with env var)
DEFAULT_API_ENDPOINT = os.environ.get('KLUG_BUILDS_API_ENDPOINT', 
                                      'https://kjudjxy5oc.execute-api.eu-west-3.amazonaws.com/prod')

def make_request(method: str, path: str, data: Optional[Dict] = None, params: Optional[Dict] = None) -> Dict[str, Any]:
    """Make a request to the API."""
    url = f"{DEFAULT_API_ENDPOINT}{path}"
    headers = {
        'Content-Type': 'application/json'
    }
    
    try:
        if method == 'GET':
            response = requests.get(url, headers=headers, params=params)
        elif method == 'POST':
            response = requests.post(url, headers=headers, json=data)
        elif method == 'PUT':
            response = requests.put(url, headers=headers, json=data)
        elif method == 'DELETE':
            response = requests.delete(url, headers=headers)
        else:
            raise ValueError(f"Unsupported method: {method}")
        
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        error_msg = "Unknown error"
        try:
            error_data = e.response.json()
            error_msg = error_data.get('error', str(e))
        except:
            error_msg = str(e)
        click.echo(click.style(f'Error: {error_msg}', fg='red'), err=True)
        sys.exit(1)
    except requests.exceptions.RequestException as e:
        click.echo(click.style(f'Request error: {str(e)}', fg='red'), err=True)
        sys.exit(1)


def create_zip_from_directory(directory: Path, output_path: Path) -> str:
    """Create ZIP file from directory and return SHA256 hash."""
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for root, dirs, files in os.walk(directory):
            for file in files:
                file_path = Path(root) / file
                arcname = file_path.relative_to(directory)
                zip_file.write(file_path, arcname)
    
    # Calculate SHA256
    with open(output_path, 'rb') as f:
        sha256_hash = hashlib.sha256(f.read()).hexdigest()
    
    return sha256_hash


@click.group()
@click.version_option(version='1.0.0')
def cli():
    """KLUG Builds - Build and deploy Lambda functions via CLI."""
    pass


@cli.command()
@click.argument('api_path', type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.argument('layers_path', type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.option('--system', 'system_id', required=True, help='System ID')
@click.option('--env', 'env_name', required=True, help='Environment name')
@click.option('--account-id', help='Account ID (defaults to API key account)')
@click.option('--target-role-arn', help='ARN of IAM role to assume in target account for cross-account deployments')
@click.option('--target-region', help='AWS region for target account (defaults to source region)')
def build(api_path: str, layers_path: str, system_id: str, env_name: str, 
          account_id: Optional[str], target_role_arn: Optional[str], target_region: Optional[str]):
    """Build and deploy Lambda functions.
    
    Example:
        klug-builds api/ layers/ --system main --env dev
    """
    api_dir = Path(api_path)
    layers_dir = Path(layers_path)
    
    if not api_dir.exists() or not api_dir.is_dir():
        click.echo(click.style(f'Error: API directory not found: {api_path}', fg='red'), err=True)
        sys.exit(1)
    
    if not layers_dir.exists() or not layers_dir.is_dir():
        click.echo(click.style(f'Error: Layers directory not found: {layers_path}', fg='red'), err=True)
        sys.exit(1)
    
    click.echo(click.style(f'📦 Building for system={system_id}, env={env_name}', fg='cyan'))
    
    # Create temporary ZIP files
    api_zip_id = str(uuid4())
    layers_zip_id = str(uuid4())
    api_zip_path = Path(f'/tmp/{api_zip_id}.zip')
    layers_zip_path = Path(f'/tmp/{layers_zip_id}.zip')
    
    try:
        # Create ZIPs
        click.echo(click.style('📦 Creating API code ZIP...', fg='blue'))
        api_hash = create_zip_from_directory(api_dir, api_zip_path)
        click.echo(click.style(f'✅ API ZIP created (SHA256: {api_hash[:16]}...)', fg='green'))
        
        click.echo(click.style('📦 Creating layers ZIP...', fg='blue'))
        layers_hash = create_zip_from_directory(layers_dir, layers_zip_path)
        click.echo(click.style(f'✅ Layers ZIP created (SHA256: {layers_hash[:16]}...)', fg='green'))
        
        # Upload to S3 via API
        click.echo(click.style('☁️  Uploading to S3...', fg='blue'))
        
        # Read ZIP files
        with open(api_zip_path, 'rb') as f:
            api_zip_data = f.read()
        
        with open(layers_zip_path, 'rb') as f:
            layers_zip_data = f.read()
        
        # Create build request (matching API format exactly)
        build_data = {
            'system_id': system_id,
            'env_name': env_name,
            'api_code_zip': api_zip_data.hex(),  # Send as hex string
            'layers_code_zip': layers_zip_data.hex(),
            'api_code_key': f'lambda-code/{api_zip_id}.zip',  # Match S3 key format
            'layers_code_key': f'layer-code/{layers_zip_id}.zip'  # Match S3 key format
        }
        
        if account_id:
            build_data['account_id'] = account_id
        
        # Add cross-account role if provided (CLI option takes precedence over env var)
        if not target_role_arn:
            target_role_arn = os.environ.get('KLUG_BUILDS_TARGET_ROLE_ARN')
        if not target_region:
            target_region = os.environ.get('KLUG_BUILDS_TARGET_REGION')
        
        if target_role_arn:
            build_data['target_role_arn'] = target_role_arn
            click.echo(click.style(f'🔐 Using cross-account role: {target_role_arn}', fg='cyan'))
        if target_region:
            build_data['target_region'] = target_region
        
        result = make_request('POST', '/builds', data=build_data)
        
        build_id = result.get('build_id')
        status = result.get('status')
        
        click.echo(click.style(f'✅ Build initiated: {build_id}', fg='green'))
        click.echo(click.style(f'📊 Status: {status}', fg='cyan'))
        
        # Poll for build status
        if status == 'pending':
            click.echo(click.style('⏳ Waiting for build to complete...', fg='yellow'))
            max_wait = 300  # 5 minutes
            wait_time = 0
            poll_interval = 5
            
            while wait_time < max_wait:
                import time
                time.sleep(poll_interval)
                wait_time += poll_interval
                
                status_result = make_request('GET', f'/builds/{build_id}')
                current_status = status_result.get('status')
                
                if current_status != status:
                    status = current_status
                    click.echo(click.style(f'📊 Status: {status}', fg='cyan'))
                
                if status in ['completed', 'failed']:
                    break
            
            # Get final status
            final_result = make_request('GET', f'/builds/{build_id}')
            
            if final_result.get('status') == 'completed':
                click.echo(click.style('✅ Build completed successfully!', fg='green'))
                if 'api_endpoint' in final_result:
                    click.echo(click.style(f'🌐 API Endpoint: {final_result["api_endpoint"]}', fg='green'))
            elif final_result.get('status') == 'failed':
                click.echo(click.style('❌ Build failed', fg='red'))
                if 'error' in final_result:
                    click.echo(click.style(f'Error: {final_result["error"]}', fg='red'), err=True)
                sys.exit(1)
            else:
                click.echo(click.style(f'⚠️  Build still in progress (status: {final_result.get("status")})', fg='yellow'))
        
    finally:
        # Clean up temporary files
        if api_zip_path.exists():
            api_zip_path.unlink()
        if layers_zip_path.exists():
            layers_zip_path.unlink()


@cli.command()
@click.option('--system', 'system_id', help='Filter by system ID')
@click.option('--env', 'env_name', help='Filter by environment name')
@click.option('--account-id', help='Filter by account ID')
def list(system_id: Optional[str], env_name: Optional[str], account_id: Optional[str]):
    """List all builds."""
    params = {}
    if system_id:
        params['system_id'] = system_id
    if env_name:
        params['env_name'] = env_name
    if account_id:
        params['account_id'] = account_id
    
    result = make_request('GET', '/builds', params=params)
    builds = result.get('builds', [])
    
    if not builds:
        click.echo('No builds found.')
        return
    
    # Display builds in a table format
    click.echo(f"{'Build ID':<40} {'System':<20} {'Env':<15} {'Status':<15} {'Created':<25}")
    click.echo('-' * 115)
    
    for build in builds:
        build_id = build.get('build_id', 'N/A')[:38]
        sys_id = build.get('system_id', 'N/A')
        env = build.get('env_name', 'N/A')
        status = build.get('status', 'N/A')
        created = build.get('created_at', 'N/A')
        
        status_color = 'green' if status == 'completed' else 'red' if status == 'failed' else 'yellow'
        click.echo(f"{build_id:<40} {sys_id:<20} {env:<15} {click.style(status, fg=status_color):<15} {created:<25}")


@cli.command()
@click.argument('build_id')
def status(build_id: str):
    """Get build status."""
    result = make_request('GET', f'/builds/{build_id}')
    
    click.echo(click.style(f'Build ID: {build_id}', fg='cyan'))
    click.echo(f"Status: {result.get('status', 'N/A')}")
    click.echo(f"System: {result.get('system_id', 'N/A')}")
    click.echo(f"Environment: {result.get('env_name', 'N/A')}")
    click.echo(f"Created: {result.get('created_at', 'N/A')}")
    
    if 'api_code_key' in result:
        click.echo(f"API Code Key: {result['api_code_key']}")
    if 'layers_code_key' in result:
        click.echo(f"Layers Code Key: {result['layers_code_key']}")
    if 'api_endpoint' in result:
        click.echo(click.style(f"API Endpoint: {result['api_endpoint']}", fg='green'))
    if 'error' in result:
        click.echo(click.style(f"Error: {result['error']}", fg='red'))


@cli.command()
@click.option('--role-name', default='klug-builds-role', help='Name of the IAM role to create in target account (default: klug-builds-role)')
@click.option('--target-account-id', required=True, help='Target AWS account ID (where resources will be deployed)')
@click.option('--profile', help='AWS profile to use for target account (alternative to prompting for credentials)')
@click.option('--region', default='eu-west-3', help='AWS region for target account (default: eu-west-3)')
def setup_role(role_name: str, target_account_id: str, profile: Optional[str], region: str):
    """Create IAM role in target AWS account for cross-account deployments.
    
    This command creates a role in the target account with all permissions needed
    for the build service to deploy Lambda functions, layers, and API Gateway.
    
    The role allows the klug-autocloud account (372315927986) to assume it for
    cross-account deployments.
    
    You can either use --profile to specify an AWS profile for the target account,
    or you will be prompted for AWS credentials for the target account.
    
    The role name defaults to 'klug-builds-role' if not specified.
    
    Example with profile:
        klug-builds setup-role \\
            --target-account-id 987654321098 \\
            --profile target-account-profile
    
    Example with custom role name:
        klug-builds setup-role \\
            --role-name my-custom-role \\
            --target-account-id 987654321098
    
    Example with credentials (will prompt for target account):
        klug-builds setup-role \\
            --target-account-id 987654321098
    """
    import boto3
    from botocore.exceptions import ClientError
    
    # Klug Autocloud account ID
    KLUG_ACCOUNT_ID = '372315927986'
    KLUG_ACCOUNT_NAME = 'klug-autocloud'
    
    click.echo(click.style(f'🔐 Setting up IAM role for {KLUG_ACCOUNT_NAME} account ({KLUG_ACCOUNT_ID})...', fg='cyan'))
    
    # Get AWS credentials for target account - either from profile or prompt
    if profile:
        aws_access_key_id = None
        aws_secret_access_key = None
        click.echo(click.style(f'Using AWS profile for target account: {profile}', fg='cyan'))
    else:
        # Prompt for AWS credentials
        aws_access_key_id = click.prompt('AWS Access Key ID for target account', type=str)
        aws_secret_access_key = click.prompt('AWS Secret Access Key for target account', 
                                             hide_input=True, type=str)
    
    # Load policy documents
    policy_path = Path(__file__).parent.parent / 'target_account_role_policy.json'
    trust_policy_path = Path(__file__).parent.parent / 'target_account_trust_policy.json'
    
    with open(policy_path, 'r') as f:
        role_policy = json.load(f)
    
    with open(trust_policy_path, 'r') as f:
        trust_policy = json.load(f)
    
    # Trust policy already has the klug account ID hardcoded, no need to modify
    
    # Create boto3 client for target account
    if profile:
        target_session = boto3.Session(
            profile_name=profile,
            region_name=region
        )
    else:
        target_session = boto3.Session(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            region_name=region
        )
    iam_client = target_session.client('iam')
    
    try:
        click.echo(click.style(f'🔐 Creating IAM role in target account {target_account_id}...', fg='cyan'))
        
        # Create the role
        try:
            response = iam_client.create_role(
                RoleName=role_name,
                AssumeRolePolicyDocument=json.dumps(trust_policy),
                Description=f'Role for Klug Builds cross-account deployments. Allows {KLUG_ACCOUNT_NAME} account ({KLUG_ACCOUNT_ID}) to assume this role for deploying Lambda functions, layers, and API Gateway.',
                MaxSessionDuration=3600  # 1 hour
            )
            role_arn = response['Role']['Arn']
            click.echo(click.style(f'✅ Created IAM role: {role_arn}', fg='green'))
        except ClientError as e:
            if e.response['Error']['Code'] == 'EntityAlreadyExists':
                click.echo(click.style(f'⚠️  Role {role_name} already exists, updating trust policy...', fg='yellow'))
                # Update trust policy
                iam_client.update_assume_role_policy(
                    RoleName=role_name,
                    PolicyDocument=json.dumps(trust_policy)
                )
                # Get existing role ARN
                response = iam_client.get_role(RoleName=role_name)
                role_arn = response['Role']['Arn']
                click.echo(click.style(f'✅ Updated trust policy for role: {role_arn}', fg='green'))
            else:
                raise
        
        # Attach inline policy
        policy_name = f'{role_name}-policy'
        try:
            iam_client.put_role_policy(
                RoleName=role_name,
                PolicyName=policy_name,
                PolicyDocument=json.dumps(role_policy)
            )
            click.echo(click.style(f'✅ Attached policy {policy_name} to role', fg='green'))
        except ClientError as e:
            if 'already exists' in str(e).lower():
                # Update existing policy
                iam_client.put_role_policy(
                    RoleName=role_name,
                    PolicyName=policy_name,
                    PolicyDocument=json.dumps(role_policy)
                )
                click.echo(click.style(f'✅ Updated policy {policy_name}', fg='green'))
            else:
                raise
        
        click.echo()
        click.echo(click.style('✅ Role setup completed successfully!', fg='green'))
        click.echo()
        click.echo(click.style('📋 Role Details:', fg='cyan'))
        click.echo(f'   Role Name: {role_name}')
        click.echo(f'   Role ARN: {role_arn}')
        click.echo(f'   Trusted Account: {KLUG_ACCOUNT_NAME} ({KLUG_ACCOUNT_ID})')
        click.echo()
        click.echo(click.style('📝 Permissions:', fg='cyan'))
        click.echo('   ✓ Lambda: Create, update, delete functions and layers')
        click.echo('   ✓ API Gateway: Create, update, deploy APIs')
        click.echo('   ✓ S3: Read/write for code storage')
        click.echo('   ✓ IAM: Pass role for Lambda execution')
        click.echo('   ✓ CloudWatch Logs: Create log groups and streams')
        click.echo()
        click.echo(click.style('💡 Next steps:', fg='cyan'))
        click.echo(f'   1. Use this role ARN when creating builds:')
        click.echo(f'      klug-builds build api/ layers/ \\')
        click.echo(f'        --system <system> --env <env> \\')
        click.echo(f'        --account-id {target_account_id} \\')
        click.echo(f'        --target-role-arn {role_arn}')
        click.echo('   2. The build service will automatically assume this role')
        click.echo('   3. Resources will be deployed to the target account')
        
    except ClientError as e:
        click.echo(click.style(f'❌ Error: {e.response["Error"]["Message"]}', fg='red'), err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(click.style(f'❌ Unexpected error: {str(e)}', fg='red'), err=True)
        sys.exit(1)


if __name__ == '__main__':
    cli()

