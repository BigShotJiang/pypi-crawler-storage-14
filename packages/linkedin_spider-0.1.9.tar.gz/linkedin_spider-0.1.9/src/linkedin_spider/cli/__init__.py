"""LinkedIn Scraper CLI application."""

__version__ = "1.0.0"
