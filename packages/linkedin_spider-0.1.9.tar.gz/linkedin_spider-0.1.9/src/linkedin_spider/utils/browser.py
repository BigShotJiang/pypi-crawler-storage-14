# This file is intentionally empty as BrowserUtils class was removed (unused)
