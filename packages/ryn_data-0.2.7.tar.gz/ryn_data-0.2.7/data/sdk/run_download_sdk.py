# a simple script to download the latest SDK package
import logging
from pathlib import Path
from data.sdk.download_sdk import s3_download
from transformers import AutoTokenizer
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def main():
    absolute_path = Path(__file__).parent / "downloaded_datasettt"
    dataset_name = "mshojaei77-merged_persian_alpaca"
    

    user_name = "datauserv3"

    # download

    ds = s3_download(
        dataset_name=dataset_name,
        absolute_path=absolute_path,
        token="username_datauser-v1",
        clearml_api_host="http://144.172.105.98:30003",
        user_management_url="http://144.172.105.98:30009",
        s3_endpoint_url="http://144.172.105.98:7000",
        dataset_type="text_generation"
    )

    # ds = create_image_classification_dataset(absolute_path,dataset_name)

    print(ds)


    print(ds.keys())

    for i in range(10):
        for split in ds.keys():
            data = ds[split][i]

            print(data)

    model_id = "Qwen/Qwen2.5-0.5B-Instruct" 
    
    print(f"Loading tokenizer for {model_id}...")
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_id)
    except Exception as e:
        print(f"Error loading tokenizer: {e}")
        return

    # ---------------------------------------------------------
    # 2. Define function to apply ChatML template
    # ---------------------------------------------------------
    def apply_chatml(example):
        """
        Takes the 'messages' list and converts it to a string 
        formatted with <|im_start|>, <|im_end|>, etc.
        """
        # We use tokenize=False to get the string back for inspection/debugging
        # or if you plan to tokenize later in a data collator.
        formatted_text = tokenizer.apply_chat_template(
            example["messages"], 
            tokenize=False, 
            add_generation_prompt=False
        )
        return {"text": formatted_text}

    ds = ds.map(apply_chatml)

    print(ds["train"][0]["text"])

    # for i in range(15010,15015):
    #     for split in ds.keys():
    #         image = ds[split][i]["image"]
    #         label = ds[split][i]["label"]
    #         label_name = ds[split][i]["label_name"]

    #         print(np.array(image).shape,label,label_name)


    
    # presigned_urls method

    # url = s3_download(
    # clearml_access_key,
    # clearml_secret_key,
    # s3_access_key,
    # s3_secret_key,
    # s3_endpoint_url,
    # dataset_name,
    # absolute_path,
    # user_name,
    # method="presigned_urls")

    # print("Downloaded SDK package is available at:", url)

    # zip_streaming method

    # zip_data = s3_download_sdk(
    #     clearml_access_key,
    #     clearml_secret_key,
    #     s3_access_key,
    #     s3_secret_key,
    #     s3_endpoint_url,
    #     dataset_name,
    #     absolute_path,
    #     user_name,
    #     method="streaming_zip")

    # print(type(zip_data))
    # if zip_data:
    #     path = Path(__file__).parent / "dataset.zip"
    #     with open(path, "wb") as f:
    #         f.write(zip_data)
    #     print("Successfully saved dataset.zip")


if __name__ == "__main__":
    main()


# import os
# import logging
# from pathlib import Path
# import numpy as np
# from transformers import AutoTokenizer # Import transformers

# # Assuming these are your local modules
# from download_sdk import s3_download
# from torch_datasets import create_image_classification_dataset

# logger = logging.getLogger(__name__)
# logging.basicConfig(level=logging.INFO)

# def main():
#     absolute_path = Path(__file__).parent / "downloaded_datasettt"
#     dataset_name = "datapizza-ai-lab-dnd5e-srd-qa"
    
#     # ... (Your existing download logic) ...
#     ds = s3_download(
#         dataset_name=dataset_name,
#         absolute_path=absolute_path,
#         token="username_datauser-v1",
#         clearml_api_host="http://144.172.105.98:30003",
#         user_management_url="http://144.172.105.98:30009",
#         s3_endpoint_url="http://144.172.105.98:7000",
#         dataset_type="text_generation",
#         version="1.0.0"
#     )

#     print("Original Dataset Structure:", ds)

#     # ---------------------------------------------------------
#     # 1. Load Qwen 0.5B Tokenizer
#     # ---------------------------------------------------------
#     # Qwen2.5 is the latest, but Qwen1.5 works similarly. 
#     # Using 'Instruct' ensures the chat template is properly configured.
#     model_id = "Qwen/Qwen2.5-0.5B-Instruct" 
    
#     print(f"Loading tokenizer for {model_id}...")
#     try:
#         tokenizer = AutoTokenizer.from_pretrained(model_id)
#     except Exception as e:
#         print(f"Error loading tokenizer: {e}")
#         return

#     # ---------------------------------------------------------
#     # 2. Define function to apply ChatML template
#     # ---------------------------------------------------------
#     def apply_chatml(example):
#         """
#         Takes the 'messages' list and converts it to a string 
#         formatted with <|im_start|>, <|im_end|>, etc.
#         """
#         # We use tokenize=False to get the string back for inspection/debugging
#         # or if you plan to tokenize later in a data collator.
#         formatted_text = tokenizer.apply_chat_template(
#             example["messages"], 
#             tokenize=False, 
#             add_generation_prompt=False
#         )
#         return {"text": formatted_text}

#     # ---------------------------------------------------------
#     # 3. Apply to the dataset
#     # ---------------------------------------------------------
#     # check if 'messages' column exists
#     column_names = ds[list(ds.keys())[0]].column_names
#     if "messages" in column_names:
#         print("Applying ChatML template to 'messages' column...")
        
#         # This creates a new column called 'text' with the formatted string
#         ds = ds.map(apply_chatml)

#         # ---------------------------------------------------------
#         # 4. Inspect Results
#         # ---------------------------------------------------------
#         print("\n--- Sample Formatted Output ---")
#         # Get the first available split (e.g., 'train')
#         first_split = list(ds.keys())[0]
#         sample = ds[first_split][0]
        
#         print("Raw Messages:", sample['messages'])
#         print("\nFormatted ChatML Text:")
#         print(sample['text'])
#         print("-------------------------------\n")
#     else:
#         print(f"Column 'messages' not found. Available columns: {column_names}")

#     # Optional: Continue with your loop logic using the new format
#     # for i in range(2):
#     #     for split in ds.keys():
#     #         print(f"Split: {split}, Index: {i}")
#     #         print(ds[split][i]['text'])

# if __name__ == "__main__":
#     main()