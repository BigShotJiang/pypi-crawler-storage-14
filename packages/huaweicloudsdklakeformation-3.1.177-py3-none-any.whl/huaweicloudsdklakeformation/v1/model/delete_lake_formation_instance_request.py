# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteLakeFormationInstanceRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'to_recycle_bin': 'bool',
        'instance_id': 'str'
    }

    attribute_map = {
        'to_recycle_bin': 'to_recycle_bin',
        'instance_id': 'instance_id'
    }

    def __init__(self, to_recycle_bin=None, instance_id=None):
        r"""DeleteLakeFormationInstanceRequest

        The model defined in huaweicloud sdk

        :param to_recycle_bin: 是否放入回收站
        :type to_recycle_bin: bool
        :param instance_id: LakeFormation实例ID
        :type instance_id: str
        """
        
        

        self._to_recycle_bin = None
        self._instance_id = None
        self.discriminator = None

        self.to_recycle_bin = to_recycle_bin
        self.instance_id = instance_id

    @property
    def to_recycle_bin(self):
        r"""Gets the to_recycle_bin of this DeleteLakeFormationInstanceRequest.

        是否放入回收站

        :return: The to_recycle_bin of this DeleteLakeFormationInstanceRequest.
        :rtype: bool
        """
        return self._to_recycle_bin

    @to_recycle_bin.setter
    def to_recycle_bin(self, to_recycle_bin):
        r"""Sets the to_recycle_bin of this DeleteLakeFormationInstanceRequest.

        是否放入回收站

        :param to_recycle_bin: The to_recycle_bin of this DeleteLakeFormationInstanceRequest.
        :type to_recycle_bin: bool
        """
        self._to_recycle_bin = to_recycle_bin

    @property
    def instance_id(self):
        r"""Gets the instance_id of this DeleteLakeFormationInstanceRequest.

        LakeFormation实例ID

        :return: The instance_id of this DeleteLakeFormationInstanceRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this DeleteLakeFormationInstanceRequest.

        LakeFormation实例ID

        :param instance_id: The instance_id of this DeleteLakeFormationInstanceRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteLakeFormationInstanceRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
