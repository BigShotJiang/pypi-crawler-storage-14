import logging

LOG = logging.getLogger("prime_hunters_patcher")
