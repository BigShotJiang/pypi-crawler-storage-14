VERSION = "0.3.9"

# this will be templated during the build
GIT_COMMIT = "238ae256a3a1ab93e682d603c4b53652fa0059f1"
