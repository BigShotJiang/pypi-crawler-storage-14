"""
A minimalistic approach to building AI agents.
Implements ReAct and CodeAct agents, supported by Planner and Observer.
"""
import asyncio
import inspect
import json
import os
import random
import re
import uuid
import warnings
from abc import ABC, abstractmethod
from datetime import datetime
from json import JSONDecodeError
from typing import (
    AsyncIterator,
    Literal,
    Optional,
    Callable,
    Any,
    Type,
    Union,
    ClassVar,
)

import json_repair
import litellm
import pydantic as pyd
import rich
from dotenv import load_dotenv

from . import kutils as ku
from . import tools as dtools
from .code_runner import CodeRunner, CODE_ENV_NAMES
from .models import (
    AgentPlan,
    AgentResponse,
    ChatMessage,
    CodeActChatMessage,
    PlanStep,
    ObserverResponse,
    ReActChatMessage,
    Task,
    AGENT_RESPONSE_TYPES
)


load_dotenv()

warnings.simplefilter('once', UserWarning)
warnings.filterwarnings('ignore', message='.*Pydantic serializer warnings.*')

litellm.success_callback = ['langfuse']
litellm.failure_callback = ['langfuse']

logger = ku.get_logger()


REACT_SYSTEM_PROMPT = ku.read_prompt('system/react.txt')
CODE_ACT_SYSTEM_PROMPT = ku.read_prompt('system/codeact.txt')
AGENT_PLAN_PROMPT = ku.read_prompt('agent_plan.txt')
UPDATE_PLAN_PROMPT = ku.read_prompt('update_plan.txt')
OBSERVATION_PROMPT = ku.read_prompt('observation.txt')
SALVAGE_RESPONSE_PROMPT = ku.read_prompt('salvage_response.txt')
RELEVANT_TOOLS_PROMPT = ku.read_prompt('relevant_tools.txt')

# Regex for message parsing from LLM response text (case-insensitive, multiline)
THOUGHT_MATCH = re.compile(
    r'Thought:\s*(.+?)(?=\n(?:Action|Answer|Code):|$)',
    re.DOTALL | re.IGNORECASE
)
ACTION_MATCH = re.compile(r'Action:\s*(\w+)', re.IGNORECASE)
ARGS_MATCH = re.compile(r'Args:\s*(\{.+?\})', re.DOTALL | re.IGNORECASE)
ANSWER_MATCH = re.compile(r'Answer:\s*(.+?)(?=\nSuccessful:|$)', re.DOTALL | re.IGNORECASE)
SUCCESS_MATCH = re.compile(r'Successful:\s*(true|false)', re.IGNORECASE)
CODE_MATCH = re.compile(r'Code:\s*```(?:python)?\s*(.+?)\s*```', re.DOTALL | re.IGNORECASE)

CODE_ACT_PSEUDO_TOOL_NAME = 'code_execution'


class Planner:
    """Given a task, generate and maintain a step-by-step plan to solve it."""
    def __init__(self, model_name: str, litellm_params: Optional[dict] = None):
        self.model_name = model_name
        self.litellm_params = litellm_params or {}
        self.plan: Optional[AgentPlan] = None

    async def create_plan(self, task: Task, agent_type: str) -> AgentPlan:
        """Create a plan to solve the given task and store it."""
        messages = ku.make_user_message(
            text_content=AGENT_PLAN_PROMPT.format(
                agent_type=agent_type,
                task=task.description,
                task_files='\n'.join(task.files) if task.files else '[None]',
            ),
            files=task.files,
        )
        plan_response = await ku.call_llm(
            model_name=self.model_name,
            litellm_params=self.litellm_params,
            messages=messages,
            response_format=AgentPlan,
            trace_id=task.id
        )
        self.plan = AgentPlan.model_validate_json(plan_response)
        return self.plan

    async def update_plan(self, thought: str, observation: str, task_id: str):
        """Update the plan based on the last thought and observation."""
        if not self.plan:
            return

        prompt = UPDATE_PLAN_PROMPT.format(
            plan=self.plan.model_dump_json(indent=2),
            thought=thought,
            observation=observation
        )
        plan_response = await ku.call_llm(
            model_name=self.model_name,
            litellm_params=self.litellm_params,
            messages=ku.make_user_message(prompt),
            response_format=AgentPlan,
            trace_id=task_id
        )
        self.plan = AgentPlan.model_validate_json(plan_response)

    def get_steps_done(self) -> list[PlanStep]:
        """Returns the completed steps from the current plan."""
        if not self.plan:
            return []
        return [step for step in self.plan.steps if step.is_done]

    def get_steps_pending(self) -> list[PlanStep]:
        """Returns the pending steps from the current plan."""
        if not self.plan:
            return []
        return [step for step in self.plan.steps if not step.is_done]

    def get_formatted_plan(self, scope: Literal['all', 'done', 'pending'] = 'all') -> str:
        """Convert the agent's plan into a markdown checklist."""
        if not self.plan or not self.plan.steps:
            return ''

        if scope == 'all':
            steps_to_format = self.plan.steps
        elif scope == 'done':
            steps_to_format = self.get_steps_done()
        else:  # pending
            steps_to_format = self.get_steps_pending()

        todo_list = []
        for step in steps_to_format:
            status = 'x' if step.is_done else ' '
            todo_list.append(f'- [{status}] {step.description}')
        return '\n'.join(todo_list)


class Observer:
    """Monitors an agent's behavior to detect issues like loops or stalled plans."""
    def __init__(
            self,
            model_name: str,
            tool_names: set[str],
            litellm_params: Optional[dict] = None,
            threshold: int = 3
    ):
        self.threshold = threshold
        self.model_name = model_name
        self.tool_names = tool_names
        self.litellm_params = litellm_params or {}
        self.last_correction_iteration: int = 0

    async def observe(
            self,
            iteration: int,
            task: Task,
            history: str,
            plan_before: Optional[str | AgentPlan],
            plan_after: Optional[str | AgentPlan],
    ) -> Optional[str]:
        """Observe the agent's state and return a corrective message if a problem is detected."""
        if self.threshold is None or iteration <= 1:
            return None
        if iteration - self.last_correction_iteration < self.threshold:
            return None

        try:
            tool_names = '\n'.join(sorted(list(self.tool_names)))
            prompt = OBSERVATION_PROMPT.format(
                task=task.description,
                plan_before=plan_before,
                plan_after=plan_after,
                history=history,
                tools=tool_names,
            )
            observation_response = await ku.call_llm(
                model_name=self.model_name,
                litellm_params=self.litellm_params,
                messages=[{'role': 'user', 'content': prompt}],
                response_format=ObserverResponse,
            )
            observation = ObserverResponse.model_validate_json(observation_response)

            if not observation.is_progressing or observation.is_in_loop:
                self.last_correction_iteration = iteration
                msg = (
                        observation.correction_message or observation.reasoning
                        or 'Adjust your approach based on the plan and history.'
                )
                correction = (
                    f'!!!CRITICAL FOR COURSE CORRECTION: {msg}\n'
                )

                if self.tool_names:
                    correction += (
                        f'Here are the exact TOOL names once again for reference:\n{tool_names}'
                    )
                return correction

        except Exception as e:
            logger.exception('LLM Observer failed: %s', str(e))
            return None

        return None

    def reset(self):
        """Reset the observer state."""
        self.last_correction_iteration = 0


class Agent(ABC):
    """An abstract agent. Base class for all types of agents."""

    response_format_class: ClassVar[Type[pyd.BaseModel]] = ChatMessage

    def __init__(
            self,
            name: str,
            model_name: str,
            description: Optional[str] = None,
            tools: Optional[list[Callable]] = None,
            litellm_params: Optional[dict] = None,
            max_iterations: int = 20,
            filter_tools_for_task: bool = False,
    ):
        self.id = uuid.uuid4()
        self.name: str = name
        self.description = description
        self.model_name: str = model_name

        self.tools = tools or []
        self.filter_tools_for_task = filter_tools_for_task
        self.litellm_params: dict = litellm_params or {}
        self.max_iterations = max_iterations

        self.tool_names = {t.name for t in tools} if tools else set()
        self.tool_name_to_func = {t.name: t for t in tools} if tools else {}

        self.task: Optional[Task] = None
        self.messages: list[ChatMessage] = []
        self.msg_idx_of_new_task: int = 0
        self.final_answer_found = False
        self.planner: Optional[Planner] = None
        self.observer = Observer(
            model_name=model_name,
            litellm_params=litellm_params,
            tool_names=self.tool_names
        )

        self.is_visual_model: bool = llm_vision_support([model_name])[0] or False

    def __str__(self):
        return (
            f'Agent: {self.name} ({self.id}); LLM: {self.model_name}; Tools: {self.tools}'
        )

    @property
    def current_plan(self) -> Optional[str]:
        """Returns the current plan for the task."""
        if not self.planner or not self.planner.plan:
            return None
        return self.planner.get_formatted_plan()

    async def get_relevant_tools(
            self,
            task_description: str,
            task_files: Optional[list[str]] = None,
    ) -> list[Any]:
        """Calls an LLM to determine which tools are relevant for the given task."""
        tool_descriptions = self.get_tools_description()
        prompt = RELEVANT_TOOLS_PROMPT.format(
            task_description=task_description,
            task_files=task_files,
            tool_descriptions=tool_descriptions,
        )

        try:
            tools_response = await ku.call_llm(
                model_name=self.model_name,
                litellm_params=self.litellm_params,
                messages=ku.make_user_message(prompt),
                trace_id=self.task.id if self.task else None
            )
            relevant_tool_names = tools_response.split(',') if tools_response.strip() else []
            relevant_tool_names = {t.strip() for t in relevant_tool_names if t.strip()}
            logger.debug('Relevant tool names: %s', relevant_tool_names)
            relevant_tools = [
                t for t in self.tools if t.name in relevant_tool_names
            ]
            return relevant_tools
        except Exception as e:
            logger.error('Error determining relevant tools: %s', str(e))
            return list(self.tools)

    def _run_init(
            self,
            description: str,
            files: Optional[list[str]] = None,
            task_id: Optional[str] = None
    ):
        """Initialize the running of a task by an agent."""
        self.task = Task(description=description, files=files)
        if task_id:
            self.task.id = task_id
        self.final_answer_found = False
        if self.planner:
            self.planner.plan = None
        self.observer.reset()

    @abstractmethod
    def parse_text_response(self, text: str) -> ChatMessage:
        """Parse a text response from the LLM into a ChatMessage."""

    async def salvage_response(self) -> str:
        """
        When an agent fails to find an answer, salvage what information could be gathered.
        """
        prompt = SALVAGE_RESPONSE_PROMPT.format(
            task=self.task.description,
            task_files='\n'.join(self.task.files) if self.task.files else '[None]',
            history=self.get_history(start_idx=self.msg_idx_of_new_task)
        )
        salvaged_response = await ku.call_llm(
            model_name=self.model_name,
            litellm_params=self.litellm_params,
            messages=ku.make_user_message(prompt),
            trace_id=self.task.id
        )
        return salvaged_response

    def trace(self) -> str:
        """Provide a trace of the agent's activities for the current task."""
        trace_log = []
        for msg in self.messages[self.msg_idx_of_new_task:]:
            if isinstance(msg, ReActChatMessage):
                trace_log.append(f"Thought: {msg.thought}")
                if msg.action:
                    trace_log.append(f"Action: {msg.action}({msg.args})")
            elif isinstance(msg, CodeActChatMessage):
                trace_log.append(f"Thought: {msg.thought}")
                if msg.code:
                    trace_log.append(f"Code:\n{msg.code}")
            elif msg.role == 'tool':
                trace_log.append(f"Observation: {msg.content}")
        return "\n".join(trace_log)

    @abstractmethod
    async def run(
            self,
            task: str,
            files: Optional[list[str]] = None,
            task_id: Optional[str] = None
    ) -> AsyncIterator[AgentResponse]:
        """Execute a task using the agent."""

    def response(
            self,
            rtype: AGENT_RESPONSE_TYPES,
            value: Any,
            channel: Optional[str] = None,
            metadata: Optional[dict[str, Any]] = None
    ) -> AgentResponse:
        """Prepare a response to be sent by the agent."""
        return {'type': rtype, 'channel': channel, 'value': value, 'metadata': metadata}

    @abstractmethod
    def formatted_history_for_llm(self) ->list[dict]:
        """Generate a formatted list of chat history messages to send to an LLM."""

    async def _chat(self, response_format: Optional[Type[pyd.BaseModel]] = None) -> Optional[str]:
        """
        Interact with the LLM using the agent's message history.
        Enhanced with retry logic for structured output failures.
        """
        formatted_messages = self.formatted_history_for_llm()

        max_retries = 3
        for attempt in range(max_retries):
            try:
                chat_response: str = await ku.call_llm(
                    model_name=self.model_name,
                    litellm_params=self.litellm_params,
                    messages=formatted_messages,
                    response_format=response_format,
                    trace_id=self.task.id if self.task else None
                )
                return chat_response or ''

            except Exception as e:
                logger.warning(f'LLM call failed (attempt {attempt + 1}/{max_retries}): {e}')

                if attempt < max_retries - 1:
                    # Add feedback to help LLM correct itself
                    await asyncio.sleep(random.uniform(0.5, 1.5))
                    feedback = (
                        f"Error: Previous response had issues: {str(e)}. "
                        f"Please ensure your response follows the exact JSON schema provided. "
                        f"[Timestamp={datetime.now()}]"
                    )
                    formatted_messages.append({'role': 'user', 'content': feedback})
                else:
                    raise

    def add_to_history(self, message: ChatMessage):
        """Add a chat message to the agent's message history."""
        assert isinstance(message, ChatMessage), (
            f'add_to_history() expects a `ChatMessage`; got `{type(message)}`'
        )
        self.messages.append(message)

    def get_tools_description(self, tools: Optional[list[Any]] = None) -> str:
        """
        Generate a description of all the tools available to the agent. Required args are marked.

        Args:
            tools: Optional list of tools to describe. If None, describes all available tools.

        Returns:
            A formatted string describing each tool, its parameters, and example usage.
        """
        description = ''
        filtered_tool_names = {t.name for t in (tools or self.tools)}

        for t in self.tools:
            if t.name in filtered_tool_names:
                description += f'\n### Tool: {t.name}\n'
                description += f'**Description:** {t.description}\n'

                # Extract and highlight required parameters
                if hasattr(t, 'args_schema') and t.args_schema:
                    schema = t.args_schema.model_json_schema()
                    properties = schema.get('properties', {})
                    required = schema.get('required', [])

                    if properties:
                        description += '\n**Parameters:**\n'
                        for param_name, param_info in properties.items():
                            param_type = param_info.get('type', 'any')
                            is_required = param_name in required
                            req_marker = '**REQUIRED**' if is_required else 'Optional'
                            description += f'  - `{param_name}` ({param_type}): {req_marker}\n'

                description += '\n---\n\n'

        return description

    @property
    def purpose(self) -> str:
        """Describe the name, purpose of, and tools available to an agent."""
        description = f'Name: {self.name}\nDescription: {self.description or "N/A"}'
        description += f'\nTools available to this agent (`{self.name}`):'
        description += f'\n{self.get_tools_description()}'

        return description

    def get_history(self, start_idx: int = 0) -> str:
        """Get a formatted string representation of all the messages."""
        return '\n'.join([f'[{msg.role}]: {msg.content}' for msg in self.messages[start_idx:]])

    def clear_history(self):
        """Clear the agent's message history."""
        self.messages = []


class ReActAgent(Agent):
    """Reasoning and Acting agent with thought-action-observation loop."""
    response_format_class: ClassVar[Type[pyd.BaseModel]] = ReActChatMessage

    def __init__(
            self,
            name: str,
            model_name: str,
            tools: list,
            description: Optional[str] = None,
            litellm_params: Optional[dict] = None,
            max_iterations: int = 20,
            filter_tools_for_task: bool = False,
    ):
        super().__init__(
            name=name,
            model_name=model_name,
            tools=tools,
            litellm_params=litellm_params,
            description=description,
            max_iterations=max_iterations,
            filter_tools_for_task=filter_tools_for_task,
        )

        self.planner = Planner(model_name, litellm_params)
        if tools:
            logger.info('Created agent: %s; tools: %s', name, [t.name for t in tools])

    async def _update_plan(self):
        """Update the plan based on the last thought and observation."""
        # Find last thought/observation pair explicitly
        last_thought = None
        last_observation = None

        for msg in reversed(self.messages):
            if not last_observation and msg.role == 'tool':
                last_observation = msg.content
            elif not last_thought and isinstance(msg, (ReActChatMessage, CodeActChatMessage)):
                last_thought = msg.thought
            if last_thought and last_observation:
                break

        if len(self.messages) > 1:
            if isinstance(self.messages[-2], (ReActChatMessage, CodeActChatMessage)):
                last_thought = self.messages[-2].thought
            if self.messages[-1].role == 'tool':
                last_observation = self.messages[-1].content
        await self.planner.update_plan(
            thought=last_thought,
            observation=last_observation,
            task_id=self.task.id,
        )

    async def run(
            self,
            task: str,
            files: Optional[list[str]] = None,
            task_id: Optional[str] = None,
            summarize_progress_on_failure: bool = True,
    ) -> AsyncIterator[AgentResponse]:
        """Solve a task using ReAct's TAO loop."""
        self._run_init(task, files, task_id)
        self.clear_history()

        if self.__class__.__name__ == 'ReActAgent':
            self.add_to_history(
                ChatMessage(
                    role='system',
                    content=REACT_SYSTEM_PROMPT.format(tools=self.get_tools_description())
                )
            )
        elif self.__class__.__name__ == 'CodeActAgent':
            self.add_to_history(
                ChatMessage(
                    role='system',
                    content=CODE_ACT_SYSTEM_PROMPT.format(
                        tools=self.get_tools_description(),
                        authorized_imports='\n'.join([f'- {imp}' for imp in self.allowed_imports])
                    )
                )
            )

        yield self.response(
            rtype='log',
            value=f'Solving task: `{self.task.description}`',
            channel='run'
        )

        await self.planner.create_plan(self.task, self.__class__.__name__)
        yield self.response(
            rtype='log', value=f'Plan:\n{self.planner.get_formatted_plan()}', channel='run'
        )

        self.add_to_history(
            ChatMessage(
                role='user',
                content=f'New Task:\n{self.task.description}',
                files=self.task.files
            )
        )
        self.add_to_history(
            ChatMessage(role='user', content=f'Plan:\n{self.planner.get_formatted_plan()}')
        )

        for idx in range(self.max_iterations):
            yield self.response(rtype='log', channel='run', value=f'* Executing step {idx + 1}')

            async for update in self._think():
                yield update
            async for update in self._act():
                yield update

            if self.final_answer_found:
                break

            plan_before_update = None
            if self.planner.plan:
                plan_before_update = self.current_plan
                await self._update_plan()
                self.add_to_history(
                    ChatMessage(
                        role='user',
                        content=f'Plan progress:\n{self.planner.get_formatted_plan()}'
                    )
                )

            correction_msg = await self.observer.observe(
                task=self.task,
                history='\n'.join([str(msg) for msg in self.messages]),
                plan_before=plan_before_update,
                plan_after=self.current_plan,
                iteration=idx + 1
            )
            if correction_msg:
                self.add_to_history(
                    ChatMessage(role='user', content=f'Observation: {correction_msg}')
                )
                yield self.response(rtype='log', value=correction_msg, channel='observer')

        if not self.final_answer_found:
            failure_msg = f'Sorry, I failed to get a complete answer even after {idx + 1} steps!'

            if summarize_progress_on_failure:
                progress_summary = await self.salvage_response()
                failure_msg += (
                    f'\n\nHere\'s a summary of my progress for this task:\n{progress_summary}'
                )

            yield self.response(
                rtype='final',
                value=failure_msg,
                channel='run',
                metadata={'final_answer_found': False}
            )

            self.add_to_history(ChatMessage(role='assistant', content=failure_msg))
        else:
            if self.planner.plan:
                await self._update_plan()

    async def _think(self) -> AsyncIterator[AgentResponse]:
        """Think about the next step using the new structured response format."""
        thought = await self._record_thought(ReActChatMessage)
        yield self.response(rtype='step', value=thought, channel='_think')

    async def _record_thought(
            self,
            response_format_class: Type[pyd.BaseModel]
    ) -> Optional[Union[ReActChatMessage, CodeActChatMessage]]:
        """
        Record the agent's thought with improved error handling and fallback parsing.
        Now returns ChatMessage directly instead of separate Response class.
        """
        for attempt in range(3):
            try:
                thought_response: str = await self._chat(response_format=response_format_class)

                try:
                    thought_response_cleaned = ku.clean_json_string(thought_response)

                    try:
                        parsed_json = json.loads(thought_response_cleaned)
                    except JSONDecodeError as e:
                        logger.warning(f'Initial JSON parse failed: {e}. Attempting repair...')
                        thought_response_cleaned = json_repair.repair_json(
                            thought_response_cleaned)
                        parsed_json = json.loads(thought_response_cleaned)

                    if 'args' in parsed_json and isinstance(parsed_json['args'], str):
                        parsed_json['args'] = ku.clean_json_string(parsed_json['args'])

                    # Handle mutual exclusivity violations
                    if response_format_class == ReActChatMessage:
                        has_action = parsed_json.get('action') and parsed_json[
                            'action'] != 'FINISH'
                        has_final_answer = parsed_json.get('final_answer')

                        if has_action and has_final_answer:
                            logger.warning(
                                f"LLM provided both action ('{parsed_json['action']}') and"
                                f" final_answer. Keeping action, removing final_answer."
                            )
                            parsed_json['final_answer'] = None
                            parsed_json['task_successful'] = False

                    elif response_format_class == CodeActChatMessage:
                        has_code = parsed_json.get('code')
                        has_final_answer = parsed_json.get('final_answer')

                        if has_code and has_final_answer:
                            logger.warning(
                                "LLM provided both code and final_answer. "
                                "Keeping code, removing final_answer."
                            )
                            parsed_json['final_answer'] = None
                            parsed_json['task_successful'] = False

                    thought_response_cleaned = json.dumps(parsed_json)

                    # Validate and create message directly
                    msg = response_format_class.model_validate_json(thought_response_cleaned)
                    msg.role = 'assistant'  # Set role

                    logger.debug('Successfully parsed structured JSON response')

                except (JSONDecodeError, pyd.ValidationError) as parse_error:
                    logger.warning(
                        f'Structured parsing failed: {type(parse_error).__name__}: {parse_error}. '
                        f'Falling back to text parsing...'
                    )

                    try:
                        msg = self.parse_text_response(thought_response)
                        msg.role = 'assistant'
                        logger.info('Successfully parsed response using text fallback')

                    except Exception as text_error:
                        logger.error(f'Text parsing also failed: {text_error}')
                        raise ValueError(
                            f'Both structured and text parsing failed. '
                            f'Structured error: {parse_error}. '
                            f'Text parsing error: {text_error}'
                        ) from text_error

                self.add_to_history(msg)
                return msg

            except ValueError as ex:
                logger.error(f'Parsing error in _record_thought (attempt {attempt + 1}/3): {ex}')

                if attempt < 2:
                    await asyncio.sleep(random.uniform(0.5, 1.0))
                    feedback_message = (
                        f'!Parsing Error: {str(ex)}. '
                        'Please ensure your response follows the required format. '
                        f'[Timestamp={datetime.now()}]'
                    )
                    self.add_to_history(ChatMessage(role='user', content=feedback_message))
                else:
                    logger.error('Failed to parse response after 3 attempts')
                    return None

            except Exception as ex:
                logger.exception(
                    f'Unexpected error in _record_thought (attempt {attempt + 1}/3): {ex}')

                if attempt < 2:
                    await asyncio.sleep(random.uniform(0.5, 1.0))
                    feedback_message = (
                        f'!Error: {type(ex).__name__}: {str(ex)}. '
                        f'[Timestamp={datetime.now()}]'
                    )
                    self.add_to_history(ChatMessage(role='user', content=feedback_message))
                else:
                    logger.error('Failed after 3 attempts due to unexpected errors')
                    return None

        return None

    async def _act(self) -> AsyncIterator[AgentResponse]:
        """
        Take action based on the agent's previous thought.
        Now handles explicit FINISH action with proper error handling.
        """
        prev_msg: ReActChatMessage = self.messages[-1]  # type: ignore

        # Check for malformed response
        if not hasattr(prev_msg, 'thought') or not prev_msg.thought:
            self.add_to_history(
                ChatMessage(
                    role='user',
                    content=(
                        '* Error: Response must have a valid `thought` field. '
                        'Please respond strictly following the schema.'
                    )
                )
            )
            return

        # Check if this is a final answer
        if hasattr(prev_msg, 'final_answer') and prev_msg.final_answer:
            self.final_answer_found = True
            self.task.is_finished = True
            self.task.is_error = not prev_msg.task_successful

            yield self.response(
                rtype='final',
                value=prev_msg.final_answer,
                channel='_act',
                metadata={'final_answer_found': prev_msg.task_successful}
            )
        else:
            # Tool execution
            tool_name = prev_msg.action
            tool_args = prev_msg.args
            tool_args_dict = {}

            # Validate tool call has required fields
            if not tool_name or not tool_args:
                error_msg = 'Error: Both action and args must be provided for tool calls.'
                # CRITICAL: Use role='tool' instead of role='user' to maintain conversation format
                self.add_to_history(ChatMessage(role='tool', content=error_msg))
                yield self.response(
                    rtype='step',
                    value=error_msg,
                    channel='_act',
                    metadata={'is_error': True}
                )
                return

            try:
                # CRITICAL: Parse the JSON string into a dictionary
                # The args field is a JSON string, not a dict
                tool_args = tool_args.strip().strip('`').strip()
                if tool_args.startswith('json'):
                    tool_args = tool_args[4:].strip()

                try:
                    tool_args_dict = json.loads(tool_args)
                except JSONDecodeError:
                    logger.warning('JSON decode failed, attempting repair...')
                    tool_args_dict = json_repair.loads(tool_args)

                # Validate it's actually a dictionary
                if not isinstance(tool_args_dict, dict):
                    error_msg = f'Tool args must be a dict, got {type(tool_args_dict).__name__}'
                    self.add_to_history(ChatMessage(role='tool', content=error_msg))
                    yield self.response(
                        rtype='step',
                        value=error_msg,
                        channel='_act',
                        metadata={'is_error': True}
                    )
                    return

                # Execute tool
                if tool_name in self.tool_names:
                    logger.debug('🛠 Running tool: %s with args: %s', tool_name, tool_args_dict)
                    result = self.tool_name_to_func[tool_name](**tool_args_dict)
                    # Always use role='tool' for tool results
                    self.add_to_history(ChatMessage(role='tool', content=str(result)))
                    yield self.response(
                        rtype='step',
                        value=result,
                        channel='_act',
                        metadata={'tool': tool_name, 'args': tool_args_dict}
                    )
                else:
                    result = (
                        f'Error: Tool "{tool_name}" not found! '
                        f'Available tools: {", ".join(sorted(self.tool_names))}. '
                        'Please use an exact tool name from the list.'
                    )
                    # Use role='tool' for tool errors too
                    self.add_to_history(ChatMessage(role='tool', content=result))
                    yield self.response(
                        rtype='step',
                        value=result,
                        channel='_act',
                        metadata={'is_error': True}
                    )

            except Exception as ex:
                error_msg = (
                    f'*** Error: Tool execution failed: {type(ex).__name__}: {str(ex)}\n'
                    f'Tool: {tool_name}\n'
                    f'Args provided: {tool_args_dict}\n'
                    f'Please check the tool signature and try again with correct arguments.'
                )
                logger.error(error_msg)
                # Use role='tool' to maintain proper conversation structure
                self.add_to_history(ChatMessage(role='tool', content=error_msg))
                yield self.response(
                    rtype='step',
                    value=error_msg,
                    channel='_act',
                    metadata={'is_error': True}
                )

    def parse_text_response(self, text: str) -> ReActChatMessage:
        """
        Parse text-based response when structured output fails.
        Uses regex to extract components from free-form text.

        This is a FALLBACK for when JSON parsing completely fails.
        It only handles text format like:
            Thought: ...
            Action: ...
            Args: {...}
        OR
            Thought: ...
            Answer: ...
            Successful: true/false

        Args:
            text: The raw text response from the LLM

        Returns:
            Parsed structured response

        Raises:
            ValueError: If unable to parse required fields
        """
        logger.info('Falling back to text-based regex parsing')

        # Extract thought - REQUIRED
        thought_match = THOUGHT_MATCH.search(text)
        if not thought_match:
            raise ValueError(
                f"Could not extract 'Thought:' field from response. "
                f"Response must start with reasoning. Text: {text[:200]}..."
            )
        thought = thought_match.group(1).strip()

        # Parse ReAct response
        action_match = ACTION_MATCH.search(text)
        action = action_match.group(1).strip() if action_match else None
        args = None

        # Try to extract and validate args
        args_match = ARGS_MATCH.search(text)
        if args_match:
            args_str = args_match.group(1).strip()
            args = ku.clean_json_string(args_str)
            # Validate it's actually valid JSON
            try:
                json.loads(args)
            except (JSONDecodeError, Exception) as e:
                logger.warning(f'Args extraction failed, invalid JSON: {e}')
                args = None

        # Extract final answer and success status
        answer_match = ANSWER_MATCH.search(text)
        success_match = SUCCESS_MATCH.search(text)
        final_answer = answer_match.group(1).strip() if answer_match else None
        task_successful = success_match.group(1).lower() == 'true' if success_match else False

        # Validation: Must have either (action + args) OR final_answer
        if final_answer:
            # This is a final answer
            return ReActChatMessage(
                role='assistant',
                thought=thought,
                action='FINISH',
                args=None,
                final_answer=final_answer,
                task_successful=task_successful
            )

        if action:
            # This is a tool call
            if action == 'FINISH':
                raise ValueError(
                    f"Action is 'FINISH' but no Answer field found. "
                    f"Text: {text[:200]}..."
                )
            if not args:
                raise ValueError(
                    f"Action '{action}' specified but no valid Args found. "
                    f"Text: {text[:200]}..."
                )
            return ReActChatMessage(
                role='assistant',
                thought=thought,
                action=action,
                args=args,
                final_answer=None,
                task_successful=False
            )
        else:
            raise ValueError(
                f"Could not extract valid Action or Answer from response. "
                f"Text: {text[:300]}..."
            )

    def formatted_history_for_llm(self) ->list[dict]:
        """Format message history for LLM with proper tool call structure."""
        formatted_messages = []
        last_tool_call_id = None
        pending_tool_call = False  # Track if we're expecting a tool response

        for msg in self.messages:
            d = msg.model_dump()
            role = d.get('role')

            # Handle assistant tool call
            if role == 'assistant' and (
                    hasattr(msg, 'action') and getattr(msg, 'action', None)
            ) and not getattr(msg, 'final_answer', None):
                tool_call_id = f'call_{uuid.uuid4().hex[:8]}'
                last_tool_call_id = tool_call_id
                pending_tool_call = True
                formatted_messages.append({
                    'role': 'assistant',
                    'content': None,
                    'tool_calls': [
                        {
                            'id': tool_call_id,
                            'type': 'function',
                            'function': {
                                'name': getattr(msg, 'action'),
                                'arguments': getattr(msg, 'args', '{}')
                            }
                        }
                    ]
                })

            elif role == 'tool':
                tool_msg = {'role': 'tool', 'content': str(d.get('content', ''))}
                if last_tool_call_id:
                    tool_msg['tool_call_id'] = last_tool_call_id
                    last_tool_call_id = None
                    pending_tool_call = False
                formatted_messages.append(tool_msg)

            elif role == 'assistant':
                if hasattr(msg, 'final_answer') and getattr(msg, 'final_answer', None):
                    formatted_messages.append(
                        {'role': 'assistant', 'content': getattr(msg, 'final_answer')}
                    )
                else:
                    formatted_messages.append(
                        {'role': 'assistant', 'content': d.get('content', '')}
                    )

            elif role == 'user':
                usr_msgs = ku.make_user_message(
                    text_content=d.get('content', ''),
                    files=d.get('files', None)
                )
                formatted_messages.extend(usr_msgs)

            else:
                # system
                formatted_messages.append({'role': role, 'content': d.get('content', '')})

        # Safety check: if we have a pending tool call without response, add a placeholder
        if pending_tool_call and last_tool_call_id:
            logger.warning(
                'Found tool_call without corresponding tool response, adding placeholder')
            formatted_messages.append({
                'role': 'tool',
                'tool_call_id': last_tool_call_id,
                'content': 'Error: Tool execution was interrupted'
            })

        formatted_messages = ku.combine_user_messages(formatted_messages)
        return formatted_messages


class CodeActAgent(ReActAgent):
    """CodeAct agent using Thought-Code-Observation loop."""
    response_format_class: ClassVar[Type[pyd.BaseModel]] = CodeActChatMessage

    def __init__(
            self,
            name: str,
            model_name: str,
            run_env: CODE_ENV_NAMES,
            tools: Optional[list[Callable]] = None,
            description: Optional[str] = None,
            litellm_params: Optional[dict] = None,
            max_iterations: int = 20,
            allowed_imports: Optional[list[str]] = None,
            pip_packages: Optional[str] = None,
            timeout: int = 30,
            env_vars_to_set: Optional[dict[str, str]] = None,
            filter_tools_for_task: bool = False,
    ):
        super().__init__(
            name=name,
            model_name=model_name,
            tools=tools,
            litellm_params=litellm_params,
            max_iterations=max_iterations,
            description=description,
            filter_tools_for_task=filter_tools_for_task,
        )
        self.tools_source_code: str = 'from typing import *\n\n'

        if tools:
            for t in self.tools:
                self.tools_source_code += inspect.getsource(t).replace('@tool\n', '', 1) + '\n'

        self.pip_packages = pip_packages

        if not allowed_imports:
            allowed_imports = []

        self.allowed_imports = allowed_imports + ['datetime', 'typing', 'mimetypes']
        self.code_runner = CodeRunner(
            env=run_env,
            allowed_imports=self.allowed_imports,
            pip_packages=self.pip_packages,
            timeout=timeout,
            env_vars_to_set=env_vars_to_set,
        )

    def formatted_history_for_llm(self) ->list[dict]:
        """Generate formatted message history for LLM."""
        formatted_messages = []
        last_tool_call_id = None

        for msg in self.messages:
            d = msg.model_dump()
            role = d.get('role')

            if role == 'assistant' and (
                    hasattr(msg, 'code') and getattr(msg, 'code', None)
            ) and not getattr(msg, 'final_answer', None):
                tool_call_id = f'call_{uuid.uuid4().hex[:8]}'
                last_tool_call_id = tool_call_id
                formatted_messages.append({
                    'role': 'assistant',
                    'content': None,
                    'tool_calls': [
                        {
                            'id': tool_call_id,
                            'type': 'function',
                            'function': {
                                'name': CODE_ACT_PSEUDO_TOOL_NAME,
                                'arguments': json.dumps({
                                    "code": getattr(msg, 'code')
                                })
                            }
                        }
                    ]
                })

            elif role == 'tool':
                tool_msg = {'role': 'tool', 'content': str(d.get('content', ''))}
                if last_tool_call_id:
                    tool_msg['tool_call_id'] = last_tool_call_id
                    last_tool_call_id = None
                formatted_messages.append(tool_msg)

            elif role == 'assistant':
                if hasattr(msg, 'final_answer') and getattr(msg, 'final_answer', None):
                    formatted_messages.append(
                        {'role': 'assistant', 'content': getattr(msg, 'final_answer')}
                    )
                else:
                    formatted_messages.append(
                        {'role': 'assistant', 'content': d.get('content', '')}
                    )

            elif role == 'user':
                usr_msgs = ku.make_user_message(
                    text_content=d.get('content', ''),
                    files=d.get('files', None)
                )
                formatted_messages.extend(usr_msgs)

            else:
                formatted_messages.append({'role': role, 'content': d.get('content', '')})

        formatted_messages = ku.combine_user_messages(formatted_messages)
        return formatted_messages

    def parse_text_response(self, text: str) -> CodeActChatMessage:
        """
        Uses regex to extract components from free-form text and parse into messages.

        Returns:
            Parsed structured response

        Raises:
            ValueError: If unable to parse required fields
        """
        react_msg: ReActChatMessage = super().parse_text_response(text)
        thought = react_msg.thought
        final_answer = react_msg.final_answer
        task_successful = react_msg.task_successful

        # Parse CodeAct response
        code_match = CODE_MATCH.search(text)
        code = code_match.group(1).strip() if code_match else None

        # Also try to find code without markdown blocks
        if not code:
            code_alt_match = re.search(
                r'Code:\s*(.+?)(?=\n(?:Thought|Answer):|$)',
                text,
                re.DOTALL | re.IGNORECASE
            )
            if code_alt_match:
                code = code_alt_match.group(1).strip()
                code = code.strip('`').strip()
            else:
                code = None

        # Validation: Must have either code OR final_answer
        if final_answer:
            return CodeActChatMessage(
                role='assistant',
                thought=thought,
                code=None,
                final_answer=final_answer,
                task_successful=task_successful
            )

        if code:
            return CodeActChatMessage(
                role='assistant',
                thought=thought,
                code=code,
                final_answer=None,
                task_successful=False
            )

        raise ValueError(
            f"Could not extract valid Code or Answer from response. Text: {text[:300]}..."
        )

    async def _think(self) -> AsyncIterator[AgentResponse]:
        """Think step for CodeAct agent."""
        msg = await self._record_thought(CodeActChatMessage)
        yield self.response(rtype='step', value=msg, channel='_think')

    async def _act(self) -> AsyncIterator[AgentResponse]:
        """Execute code based on CodeActAgent's previous thought."""
        prev_msg: CodeActChatMessage = self.messages[-1]  # type: ignore

        if not hasattr(prev_msg, 'thought') or not prev_msg.thought:
            self.add_to_history(
                ChatMessage(
                    role='user',
                    content=(
                        '* Error: Response must have a valid `thought` field. '
                        'Please respond strictly following the schema.'
                    )
                )
            )
            return

        if hasattr(prev_msg, 'final_answer') and prev_msg.final_answer:
            self.final_answer_found = True
            self.task.is_finished = True
            self.task.is_error = not prev_msg.task_successful

            yield self.response(
                rtype='final',
                value=prev_msg.final_answer,
                channel='_act',
                metadata={'final_answer_found': prev_msg.task_successful}
            )
        else:
            try:
                code = prev_msg.code.strip()
                code = code.replace('```py', '')
                code = code.replace('```python', '')
                code = code.replace('```', '').strip()
                code = f'{self.tools_source_code}\n\n{code}'

                stdout, stderr, exit_status = self.code_runner.run(code, self.task.id)
                observation = f'{stdout}\n{stderr}'.strip()
                msg = ChatMessage(role='tool', content=observation)
                self.add_to_history(msg)
                yield self.response(
                    rtype='step',
                    value=observation,
                    channel='_act',
                    metadata={'is_error': exit_status != 0}
                )

            except Exception as ex:
                error_msg = f'*** Error running code: {type(ex).__name__}: {str(ex)}'
                logger.error(error_msg)
                # Respond as the pseudo "tool"
                tool_msg = ChatMessage(role='tool', content=error_msg)
                self.add_to_history(tool_msg)
                yield self.response(
                    rtype='step',
                    value=error_msg,
                    channel='_act',
                    metadata={'is_error': True}
                )


def llm_vision_support(model_names: list[str]) -> list[bool]:
    """Check whether images can be used with given LLMs."""
    status = [litellm.supports_vision(model=model) for model in model_names]
    for model, value in zip(model_names, status):
        print(f'- Vision supported by {model}: {value}')

    return status


def print_response(response: AgentResponse, only_final: bool = True):
    """Print agent's response in terminal with colors."""
    if response['type'] == 'final':
        msg = (
            response['value']
            if isinstance(response['value'], str) else response['value']
        )
        rich.print(f'[green][bold]Agent[/bold]: {msg}[/green]\n')

    if not only_final:
        if response['type'] == 'log':
            rich.print(f'[white]{response}[/white]')
        else:
            rich.print(f'{response}')


async def main():
    """Demonstrate the use of ReActAgent and CodeActAgent."""
    litellm_params = {'temperature': 0, 'timeout': 30}
    model_name = 'gemini/gemini-2.0-flash-lite'
    # model_name = 'openai/gpt-4.1-mini'

    agent = ReActAgent(
        name='Simple agent',
        model_name=model_name,
        tools=[
            dtools.calculator, dtools.search_web, dtools.read_webpage, dtools.extract_as_markdown
        ],
        max_iterations=5,
        litellm_params=litellm_params,
        filter_tools_for_task=False
    )
    # agent = CodeActAgent(
    #     name='Simple agent',
    #     model_name=model_name,
    #     tools=[
    #         dtools.calculator, dtools.search_web, dtools.read_webpage, dtools.extract_as_markdown
    #     ],
    #     max_iterations=7,
    #     litellm_params=litellm_params,
    #     run_env='host',
    #     allowed_imports=[
    #         'math', 'datetime', 'time', 're', 'typing', 'mimetypes', 'random', 'ddgs',
    #         'bs4', 'urllib.parse', 'requests', 'markitdown', 'pathlib'
    #     ],
    #     pip_packages='ddgs~=9.5.2;beautifulsoup4~=4.14.2;',
    #     filter_tools_for_task=False
    # )

    the_tasks = [
        ('What is ten plus 15, raised to 2, expressed in words?', None),
        ('What is the date today? Express it in words like <Month> <Day>, <Year>.', None),
        (
            'Which image has a purple background?',
            [
                'https://www.slideteam.net/media/catalog/product/cache/1280x720/p/r/process_of_natural_language_processing_training_ppt_slide01.jpg',
                'https://cdn.prod.website-files.com/61a05ff14c09ecacc06eec05/66e8522cbe3d357b8434826a_ai-agents.jpg',
            ]
        ),
        (
            'What is four plus seven? Also, what are the festivals in Paris?'
            ' How they differ from Kolkata?',
            None
        ),
        (
            'Summarize the notes',
            ['https://web.stanford.edu/class/cs102/lectureslides/ClassificationSlides.pdf',]
        ),
    ]

    print(f'{agent.__class__.__name__} demo\n')

    for task, img_urls in the_tasks:
        rich.print(f'[yellow][bold]User[/bold]: {task}[/yellow]')
        async for response in agent.run(task, files=img_urls):
            print_response(response, only_final=True)

        if agent.current_plan:
            print(f'Plan:\n{agent.current_plan}')

        await asyncio.sleep(random.uniform(0.15, 0.55))
        print('\n\n')


if __name__ == '__main__':
    os.environ['PYTHONUTF8'] = '1'
    asyncio.run(main())
