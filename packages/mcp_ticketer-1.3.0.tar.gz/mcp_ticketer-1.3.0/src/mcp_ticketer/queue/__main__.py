"""Run the queue worker as a module."""

from .run_worker import main

if __name__ == "__main__":
    main()
