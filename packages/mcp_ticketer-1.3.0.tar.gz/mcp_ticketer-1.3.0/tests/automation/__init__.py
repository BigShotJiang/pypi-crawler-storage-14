"""Tests for automation features."""
