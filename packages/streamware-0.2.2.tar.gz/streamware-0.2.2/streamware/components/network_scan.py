"""
Network Scan Component - Discover devices on network with AI queries

Supported operations:
    - scan: Scan network for devices
    - find: Find specific device types using LLM
    - identify: Identify device by IP/MAC
    - monitor: Monitor network for new devices

URI Examples:
    network://scan?subnet=192.168.1.0/24
    network://find?query=cameras&subnet=192.168.1.0/24
    network://find?query=raspberry pi
    network://identify?ip=192.168.1.100

CLI:
    sq network scan --subnet 192.168.1.0/24
    sq network find "all cameras"
    sq network find "raspberry pi devices"
    sq network find "printers"

Related:
    - examples/network/network_discovery.py
    - streamware/components/stream.py (for camera integration)
"""

import subprocess
import socket
import logging
import re
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from ..core import Component, StreamwareURI, register
from ..exceptions import ComponentError

logger = logging.getLogger(__name__)


# Known device signatures (MAC prefixes and characteristics)
DEVICE_SIGNATURES = {
    "raspberry_pi": {
        "mac_prefixes": ["B8:27:EB", "DC:A6:32", "E4:5F:01", "28:CD:C1"],
        "hostnames": ["raspberry", "raspberrypi", "rpi"],
        "ports": [22],
        "port_signature": {22},  # SSH only = likely Pi
        "description": "Raspberry Pi"
    },
    "camera": {
        "mac_prefixes": ["00:80:F0", "00:0F:7C", "00:40:8C", "AC:CC:8E", "00:18:AE", "28:87:BA"],
        "hostnames": ["cam", "camera", "ipcam", "hikvision", "dahua", "axis", "reolink"],
        "ports": [80, 443, 554, 8080, 8554],
        "port_signature": {554},  # RTSP = camera
        "description": "IP Camera"
    },
    "printer": {
        "mac_prefixes": ["00:00:48", "00:1B:A9", "00:17:08", "00:1E:0B", "3C:2A:F4"],
        "hostnames": ["printer", "hp", "epson", "canon", "brother", "xerox"],
        "ports": [9100, 515, 631],
        "port_signature": {9100, 631},  # Printing ports
        "description": "Network Printer"
    },
    "router": {
        "mac_prefixes": ["00:1A:2B", "00:1D:7E", "00:22:6B", "00:24:01", "14:CC:20", "68:1D:EF"],
        "hostnames": ["router", "gateway", "_gateway", "ap", "wifi", "access", "fritz"],
        "ports": [80, 443, 22, 23, 53],
        "port_signature": {53},  # DNS = router
        "description": "Router / Access Point"
    },
    "nas": {
        "mac_prefixes": ["00:11:32", "00:90:A9"],
        "hostnames": ["nas", "synology", "qnap", "storage", "fileserver", "diskstation"],
        "ports": [5000, 5001, 445, 139, 22],
        "port_signature": {5000, 445},  # Synology + SMB
        "description": "NAS Storage"
    },
    "smart_tv": {
        "mac_prefixes": ["00:12:FB", "5C:49:7D", "78:BD:BC", "EC:71:DB"],
        "hostnames": ["tv", "samsung", "lg", "sony", "roku", "firetv", "chromecast", "androidtv"],
        "ports": [8008, 8443, 9080, 8009],
        "port_signature": {8008, 8009},  # Chromecast ports
        "description": "Smart TV / Media"
    },
    "iot_device": {
        "mac_prefixes": ["18:FE:34", "60:01:94", "A0:20:A6", "AC:CF:23", "E8:A0:ED"],
        "hostnames": ["esp", "tasmota", "sonoff", "shelly", "tuya", "smart", "plug"],
        "ports": [80, 8080],
        "port_signature": set(),
        "description": "IoT Device"
    },
    "gpu_server": {
        "mac_prefixes": [],
        "hostnames": ["nvidia", "gpu", "cuda", "ml", "ai", "deep", "tensor"],
        "ports": [22, 8888, 6006, 5000],
        "port_signature": {8888, 6006},  # Jupyter + TensorBoard
        "description": "GPU/ML Server"
    },
    "server": {
        "mac_prefixes": [],
        "hostnames": ["server", "srv", "host", "node", "linux", "ubuntu", "debian", "centos"],
        "ports": [22, 80, 443, 3306, 5432, 6379, 27017],
        "port_signature": {3306, 5432, 6379},  # Databases
        "description": "Server"
    },
    "workstation": {
        "mac_prefixes": [],
        "hostnames": ["pc", "desktop", "workstation", "win", "mac", "imac"],
        "ports": [22, 3389, 5900],
        "port_signature": {3389, 5900},  # RDP, VNC
        "description": "Workstation/PC"
    },
    "mobile": {
        "mac_prefixes": [],
        "hostnames": ["iphone", "android", "phone", "mobile", "galaxy", "pixel", "ipad"],
        "ports": [],
        "port_signature": set(),
        "description": "Mobile Device"
    },
}


@register("network")
@register("netscan")
@register("discover")
class NetworkScanComponent(Component):
    """
    Network scanning and device discovery component.
    
    Operations:
        - scan: Full network scan
        - find: Find devices by type using LLM
        - identify: Identify single device
        - monitor: Watch for new devices
    
    URI Examples:
        network://scan?subnet=192.168.1.0/24
        network://find?query=cameras
        network://find?query=raspberry pi&subnet=192.168.1.0/24
        network://identify?ip=192.168.1.100
    """
    
    input_mime = "*/*"
    output_mime = "application/json"
    
    def __init__(self, uri: StreamwareURI):
        super().__init__(uri)
        self.operation = uri.operation or "scan"
        
        self.subnet = uri.get_param("subnet") or self._detect_subnet()
        self.query = uri.get_param("query")  # For LLM queries
        self.ip = uri.get_param("ip")
        self.mac = uri.get_param("mac")
        self.timeout = int(uri.get_param("timeout", "10"))
        self.deep_scan = uri.get_param("deep", "false").lower() == "true"
        
    def process(self, data: Any) -> Dict:
        """Process network scan operation"""
        operations = {
            "scan": self._scan_network,
            "find": self._find_devices,
            "identify": self._identify_device,
            "monitor": self._monitor_network,
            "ports": self._scan_ports,
        }
        
        if self.operation not in operations:
            raise ComponentError(f"Unknown operation: {self.operation}")
        
        return operations[self.operation](data)
    
    def _detect_subnet(self) -> str:
        """Auto-detect local subnet"""
        try:
            # Get default gateway
            result = subprocess.run(
                ["ip", "route", "show", "default"],
                capture_output=True, text=True, timeout=5
            )
            
            if result.returncode == 0:
                match = re.search(r'via (\d+\.\d+\.\d+\.)', result.stdout)
                if match:
                    return f"{match.group(1)}0/24"
            
            # Fallback: get local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            
            parts = local_ip.rsplit('.', 1)
            return f"{parts[0]}.0/24"
            
        except Exception:
            return "192.168.1.0/24"
    
    def _scan_network(self, data: Any) -> Dict:
        """Scan network for all devices"""
        devices = []
        
        # Try multiple scan methods
        devices = self._scan_with_nmap() or self._scan_with_arp() or self._scan_with_ping()
        
        # Enrich device info - first pass
        for device in devices:
            device["type"] = self._identify_device_type(device)
            device["description"] = DEVICE_SIGNATURES.get(device["type"], {}).get("description", "Unknown Device")
        
        # Second pass: scan ports for unknown devices to identify them
        for device in devices:
            if device["type"] == "unknown":
                ports = self._scan_common_ports(device["ip"])
                device["open_ports"] = ports
                device["services"] = self._identify_services(ports)
                
                # Re-identify based on ports
                new_type = self._identify_by_ports(ports)
                if new_type != "unknown":
                    device["type"] = new_type
                    device["description"] = DEVICE_SIGNATURES.get(new_type, {}).get("description", "Unknown Device")
        
        # Group by type
        by_type = {}
        for device in devices:
            t = device["type"]
            if t not in by_type:
                by_type[t] = []
            by_type[t].append(device)
        
        return {
            "success": True,
            "subnet": self.subnet,
            "total_devices": len(devices),
            "devices": devices,
            "by_type": by_type,
            "scan_method": "nmap" if self._has_nmap() else "arp"
        }
    
    def _identify_by_ports(self, ports: List[int]) -> str:
        """Identify device type based on open ports"""
        if not ports:
            return "unknown"
        
        port_set = set(ports)
        
        # Check port signatures
        if 554 in port_set:
            return "camera"
        if 9100 in port_set or 631 in port_set:
            return "printer"
        if 53 in port_set:
            return "router"
        if 5000 in port_set and 445 in port_set:
            return "nas"
        if 445 in port_set or 139 in port_set:
            return "nas"
        if 8008 in port_set or 8009 in port_set:
            return "smart_tv"
        if 8888 in port_set or 6006 in port_set:
            return "gpu_server"
        if 3306 in port_set or 5432 in port_set or 6379 in port_set or 27017 in port_set:
            return "server"
        if 3389 in port_set or 5900 in port_set:
            return "workstation"
        if 22 in port_set and len(port_set) == 1:
            return "raspberry_pi"
        if 22 in port_set and (80 in port_set or 443 in port_set):
            return "server"
        if 80 in port_set and len(port_set) <= 2:
            return "iot_device"
        
        return "unknown"
    
    def _scan_with_nmap(self) -> Optional[List[Dict]]:
        """Scan using nmap (most accurate)"""
        if not self._has_nmap():
            return None
        
        try:
            cmd = ["nmap", "-sn", self.subnet, "-oG", "-"]
            if self.deep_scan:
                cmd = ["nmap", "-sV", "-O", self.subnet, "-oG", "-"]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            
            if result.returncode != 0:
                return None
            
            devices = []
            for line in result.stdout.split('\n'):
                if 'Host:' in line and 'Status: Up' in line:
                    match = re.search(r'Host: (\d+\.\d+\.\d+\.\d+) \(([^)]*)\)', line)
                    if match:
                        ip = match.group(1)
                        hostname = match.group(2) or ""
                        
                        mac = self._get_mac_for_ip(ip)
                        
                        devices.append({
                            "ip": ip,
                            "hostname": hostname,
                            "mac": mac,
                            "vendor": self._get_vendor(mac),
                            "status": "up"
                        })
            
            return devices if devices else None
            
        except Exception as e:
            logger.debug(f"nmap scan failed: {e}")
            return None
    
    def _scan_with_arp(self) -> Optional[List[Dict]]:
        """Scan using arp-scan"""
        try:
            result = subprocess.run(
                ["arp-scan", "--localnet", "-q"],
                capture_output=True, text=True, timeout=60
            )
            
            if result.returncode != 0:
                # Try with sudo
                result = subprocess.run(
                    ["sudo", "arp-scan", "--localnet", "-q"],
                    capture_output=True, text=True, timeout=60
                )
            
            devices = []
            for line in result.stdout.split('\n'):
                parts = line.split('\t')
                if len(parts) >= 2:
                    ip = parts[0].strip()
                    mac = parts[1].strip() if len(parts) > 1 else ""
                    vendor = parts[2].strip() if len(parts) > 2 else ""
                    
                    if re.match(r'\d+\.\d+\.\d+\.\d+', ip):
                        hostname = self._resolve_hostname(ip)
                        devices.append({
                            "ip": ip,
                            "hostname": hostname,
                            "mac": mac.upper(),
                            "vendor": vendor or self._get_vendor(mac),
                            "status": "up"
                        })
            
            return devices if devices else None
            
        except Exception as e:
            logger.debug(f"arp-scan failed: {e}")
            return None
    
    def _scan_with_ping(self) -> List[Dict]:
        """Fallback: ping sweep"""
        devices = []
        base = self.subnet.rsplit('.', 1)[0]
        
        # Quick ping sweep
        for i in range(1, 255):
            ip = f"{base}.{i}"
            try:
                result = subprocess.run(
                    ["ping", "-c", "1", "-W", "1", ip],
                    capture_output=True, timeout=2
                )
                
                if result.returncode == 0:
                    mac = self._get_mac_for_ip(ip)
                    hostname = self._resolve_hostname(ip)
                    
                    devices.append({
                        "ip": ip,
                        "hostname": hostname,
                        "mac": mac,
                        "vendor": self._get_vendor(mac),
                        "status": "up"
                    })
            except Exception:
                continue
        
        return devices
    
    def _find_devices(self, data: Any) -> Dict:
        """Find devices by type using LLM to interpret query"""
        if not self.query:
            raise ComponentError("Query required for find operation")
        
        # First, scan the network
        scan_result = self._scan_network(data)
        devices = scan_result.get("devices", [])
        
        # Use LLM to interpret query and filter devices
        filtered = self._llm_filter_devices(devices, self.query)
        
        return {
            "success": True,
            "query": self.query,
            "subnet": self.subnet,
            "matched_devices": len(filtered),
            "total_scanned": len(devices),
            "devices": filtered
        }
    
    def _llm_filter_devices(self, devices: List[Dict], query: str) -> List[Dict]:
        """Use LLM to filter devices based on natural language query"""
        
        # First try rule-based matching
        query_lower = query.lower()
        
        # Map common queries to device types
        type_mappings = {
            "raspberry": "raspberry_pi",
            "rpi": "raspberry_pi",
            "pi": "raspberry_pi",
            "camera": "camera",
            "cam": "camera",
            "ipcam": "camera",
            "security": "camera",
            "printer": "printer",
            "drukark": "printer",  # Polish
            "router": "router",
            "access point": "router",
            "ap": "router",
            "nas": "nas",
            "storage": "nas",
            "tv": "smart_tv",
            "telewiz": "smart_tv",  # Polish
            "media": "smart_tv",
            "iot": "iot_device",
            "smart": "iot_device",
            "esp": "iot_device",
            "server": "server",
            "serwer": "server",  # Polish
        }
        
        # Check for direct type match
        matched_type = None
        for keyword, device_type in type_mappings.items():
            if keyword in query_lower:
                matched_type = device_type
                break
        
        if matched_type:
            return [d for d in devices if d.get("type") == matched_type]
        
        # Use LLM for complex queries
        try:
            import requests
            
            devices_json = json.dumps([{
                "ip": d["ip"],
                "hostname": d.get("hostname", ""),
                "mac": d.get("mac", ""),
                "vendor": d.get("vendor", ""),
                "type": d.get("type", "unknown"),
                "description": d.get("description", "")
            } for d in devices], indent=2)
            
            prompt = f"""Given this list of network devices:

{devices_json}

User query: "{query}"

Return ONLY a JSON array of IP addresses that match the query.
Example: ["192.168.1.10", "192.168.1.20"]

If no devices match, return: []
"""
            
            response = requests.post(
                "http://localhost:11434/api/generate",
                json={"model": "qwen2.5:14b", "prompt": prompt, "stream": False},
                timeout=30
            )
            
            if response.ok:
                result_text = response.json().get("response", "[]")
                # Extract JSON array from response
                match = re.search(r'\[.*?\]', result_text, re.DOTALL)
                if match:
                    matched_ips = json.loads(match.group())
                    return [d for d in devices if d["ip"] in matched_ips]
                    
        except Exception as e:
            logger.debug(f"LLM filter failed: {e}")
        
        # Fallback: simple text matching
        return [d for d in devices if 
                query_lower in d.get("hostname", "").lower() or
                query_lower in d.get("vendor", "").lower() or
                query_lower in d.get("description", "").lower()]
    
    def _identify_device(self, data: Any) -> Dict:
        """Identify a single device"""
        if not self.ip and not self.mac:
            raise ComponentError("IP or MAC address required")
        
        device = {
            "ip": self.ip,
            "mac": self.mac or self._get_mac_for_ip(self.ip),
            "hostname": self._resolve_hostname(self.ip) if self.ip else "",
            "vendor": "",
            "open_ports": [],
            "services": []
        }
        
        device["vendor"] = self._get_vendor(device["mac"])
        device["type"] = self._identify_device_type(device)
        device["description"] = DEVICE_SIGNATURES.get(device["type"], {}).get("description", "Unknown")
        
        # Scan common ports
        if self.ip:
            device["open_ports"] = self._scan_common_ports(self.ip)
            device["services"] = self._identify_services(device["open_ports"])
        
        return {
            "success": True,
            "device": device
        }
    
    def _monitor_network(self, data: Any) -> Dict:
        """Monitor network for changes (returns current state for comparison)"""
        scan_result = self._scan_network(data)
        
        return {
            "success": True,
            "subnet": self.subnet,
            "snapshot_time": __import__("time").strftime("%Y-%m-%d %H:%M:%S"),
            "devices": scan_result.get("devices", []),
            "device_count": scan_result.get("total_devices", 0)
        }
    
    def _scan_ports(self, data: Any) -> Dict:
        """Scan ports on specific IP"""
        if not self.ip:
            raise ComponentError("IP address required for port scan")
        
        open_ports = self._scan_common_ports(self.ip)
        services = self._identify_services(open_ports)
        
        return {
            "success": True,
            "ip": self.ip,
            "open_ports": open_ports,
            "services": services
        }
    
    def _identify_device_type(self, device: Dict) -> str:
        """Identify device type based on MAC, hostname, ports"""
        mac = device.get("mac", "").upper()
        hostname = device.get("hostname", "").lower()
        ports = device.get("open_ports", [])
        
        for device_type, signatures in DEVICE_SIGNATURES.items():
            # Check MAC prefix
            for prefix in signatures.get("mac_prefixes", []):
                if mac.startswith(prefix.upper()):
                    return device_type
            
            # Check hostname
            for name_pattern in signatures.get("hostnames", []):
                if name_pattern in hostname:
                    return device_type
            
            # Check ports (if we have port info)
            if ports:
                sig_ports = signatures.get("ports", [])
                if any(p in ports for p in sig_ports):
                    return device_type
        
        return "unknown"
    
    def _get_mac_for_ip(self, ip: str) -> str:
        """Get MAC address for IP from ARP table"""
        try:
            result = subprocess.run(
                ["arp", "-n", ip],
                capture_output=True, text=True, timeout=5
            )
            
            match = re.search(r'([0-9A-Fa-f:]{17})', result.stdout)
            if match:
                return match.group(1).upper()
        except Exception:
            pass
        return ""
    
    def _resolve_hostname(self, ip: str) -> str:
        """Resolve hostname for IP"""
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            return hostname
        except Exception:
            return ""
    
    def _get_vendor(self, mac: str) -> str:
        """Get vendor from MAC address (first 3 octets)"""
        if not mac:
            return ""
        
        # Common vendors (simplified)
        vendors = {
            "B8:27:EB": "Raspberry Pi Foundation",
            "DC:A6:32": "Raspberry Pi Foundation",
            "E4:5F:01": "Raspberry Pi Foundation",
            "00:80:F0": "Axis Communications",
            "00:0F:7C": "ACTi Corporation (Cameras)",
            "AC:CC:8E": "Hikvision",
            "00:18:AE": "TVT (Cameras)",
            "00:00:48": "HP (Printers)",
            "00:1B:A9": "Brother Industries",
            "3C:2A:F4": "Brother Industries",
            "00:11:32": "Synology",
            "00:90:A9": "QNAP",
            "18:FE:34": "Espressif (ESP8266/ESP32)",
            "60:01:94": "Espressif",
            "A0:20:A6": "Espressif",
        }
        
        prefix = mac[:8].upper()
        return vendors.get(prefix, "")
    
    def _scan_common_ports(self, ip: str) -> List[int]:
        """Quick scan of common ports"""
        common_ports = [22, 23, 80, 443, 445, 554, 631, 3306, 5000, 5432, 8080, 8443, 9100]
        open_ports = []
        
        for port in common_ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                result = sock.connect_ex((ip, port))
                sock.close()
                
                if result == 0:
                    open_ports.append(port)
            except Exception:
                continue
        
        return open_ports
    
    def _identify_services(self, ports: List[int]) -> List[Dict]:
        """Identify services from open ports"""
        services_map = {
            22: {"name": "SSH", "description": "Secure Shell"},
            23: {"name": "Telnet", "description": "Telnet"},
            80: {"name": "HTTP", "description": "Web Server"},
            443: {"name": "HTTPS", "description": "Secure Web Server"},
            445: {"name": "SMB", "description": "File Sharing"},
            554: {"name": "RTSP", "description": "Streaming (Camera)"},
            631: {"name": "IPP", "description": "Printing"},
            3306: {"name": "MySQL", "description": "MySQL Database"},
            5000: {"name": "Synology", "description": "NAS Web UI"},
            5432: {"name": "PostgreSQL", "description": "PostgreSQL Database"},
            8080: {"name": "HTTP-Alt", "description": "Alternative Web Server"},
            8443: {"name": "HTTPS-Alt", "description": "Alternative HTTPS"},
            9100: {"name": "JetDirect", "description": "Printer"},
        }
        
        return [
            {"port": p, **services_map.get(p, {"name": "Unknown", "description": "Unknown service"})}
            for p in ports
        ]
    
    def _has_nmap(self) -> bool:
        """Check if nmap is installed"""
        try:
            subprocess.run(["nmap", "--version"], capture_output=True, timeout=5)
            return True
        except Exception:
            return False


# Quick helper functions
def scan_network(subnet: str = None) -> Dict:
    """Quick network scan"""
    from ..core import flow
    uri = f"network://scan"
    if subnet:
        uri += f"?subnet={subnet}"
    return flow(uri).run()


def find_devices(query: str, subnet: str = None) -> Dict:
    """Find devices by query"""
    from ..core import flow
    uri = f"network://find?query={query}"
    if subnet:
        uri += f"&subnet={subnet}"
    return flow(uri).run()


def find_cameras(subnet: str = None) -> Dict:
    """Find all cameras on network"""
    return find_devices("cameras", subnet)


def find_raspberry_pi(subnet: str = None) -> Dict:
    """Find all Raspberry Pi devices"""
    return find_devices("raspberry pi", subnet)


def find_printers(subnet: str = None) -> Dict:
    """Find all printers"""
    return find_devices("printers", subnet)
