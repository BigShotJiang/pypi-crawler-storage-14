from .color import Painter, paint
