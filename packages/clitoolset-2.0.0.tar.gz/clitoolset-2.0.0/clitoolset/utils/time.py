from os import system
from time import sleep

def clear(delay):
    if delay < 0:
        raise ValueError("[!] No puedes parar el tiempo en negativo broder")
    sleep(delay)
    system("clear")
