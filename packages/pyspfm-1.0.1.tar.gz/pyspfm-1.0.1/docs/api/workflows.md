# Workflows

```{eval-rst}
.. currentmodule:: pySPFM.workflows

.. autosummary::
   :toctree: ../generated/
   :template: module.rst

   pySPFM
   auc_to_estimates
```
