:mod:`{{module}}`.{{objname}}
{{ underline }}==============

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :members:
   :inherited-members:
   :show-inheritance:
   {% block methods %}
   {% endblock %}

.. include:: {{fullname}}.examples

.. raw:: html

    <div class="clearer"></div>
