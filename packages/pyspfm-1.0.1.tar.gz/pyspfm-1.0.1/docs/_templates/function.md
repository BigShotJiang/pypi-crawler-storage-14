{mod}`{{module}}`.{\{objname}}
{{ underline }}====================

```{eval-rst}
.. currentmodule:: {{ module }}
```

```{eval-rst}
.. autofunction:: {{ objname }}
```

% .. include:: {{module}}.{{objname}}.examples

```{raw} html
<div class="clearer"></div>
```
