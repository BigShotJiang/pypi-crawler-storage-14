# GraphQL Operations

::: questra_automation.operations.QueryOperations
    options:
      show_source: false
      heading_level: 2

::: questra_automation.operations.MutationOperations
    options:
      show_source: false
      heading_level: 2
