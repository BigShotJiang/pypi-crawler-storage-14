"""Shell command support with jc fallback."""
