"""Plugin system (logic): discovery, registry, executor, service."""
