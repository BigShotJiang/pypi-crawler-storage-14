"""Top-level command registrations (one module per command)."""
