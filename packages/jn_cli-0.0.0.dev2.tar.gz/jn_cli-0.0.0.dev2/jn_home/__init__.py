"""Default JN_HOME package containing bundled plugins.

This package provides the lowest-priority, built-in plugins that ship with
jn. Discovery loads from user/custom locations first, then falls back to
these bundled plugins.
"""

