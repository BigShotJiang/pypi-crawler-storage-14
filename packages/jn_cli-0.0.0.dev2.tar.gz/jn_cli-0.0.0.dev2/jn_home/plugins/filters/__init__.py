"""Bundled filter plugins."""

