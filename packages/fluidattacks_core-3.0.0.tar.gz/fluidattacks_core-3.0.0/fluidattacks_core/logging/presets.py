from fluidattacks_core.logging.handlers import DebuggingHandler, ProductionSyncHandler

# Main formats
DATE_FORMAT = "%Y-%m-%dT%H:%M:%S%z"
"""
Default date format for logs.
"""


PRODUCT_LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "production_handler": {"()": ProductionSyncHandler},
        "debugging_handler": {"()": DebuggingHandler},
    },
    "root": {
        "handlers": ["production_handler", "debugging_handler"],
        "level": "INFO",
    },
}
"""
Default logging configuration dict for all the products.

Required environment variables:
- `PRODUCT_ID`
- `CI_COMMIT_REF_NAME`
- `CI_COMMIT_SHA`
"""
