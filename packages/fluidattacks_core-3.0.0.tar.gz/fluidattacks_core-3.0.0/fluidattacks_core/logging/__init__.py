import logging
import logging.config
import sys
from types import TracebackType

from fluidattacks_core.logging.presets import DATE_FORMAT, PRODUCT_LOGGING
from fluidattacks_core.logging.types import JobMetadata
from fluidattacks_core.logging.utils import get_job_metadata, set_telemetry_metadata


def init_uncaught_exception_logging() -> None:
    logger = logging.getLogger("unhandled")

    def handle_uncaught_exception(
        exception_type: type[BaseException],
        msg: BaseException,
        traceback: TracebackType | None,
    ) -> None:
        if issubclass(exception_type, KeyboardInterrupt):
            sys.__excepthook__(exception_type, msg, traceback)
            return

        logger.critical(
            "Uncaught exception",
            exc_info=(exception_type, msg, traceback),
        )

    sys.excepthook = handle_uncaught_exception


def init_logging() -> None:
    logging.config.dictConfig(PRODUCT_LOGGING)
    init_uncaught_exception_logging()


__all__ = [
    "DATE_FORMAT",
    "PRODUCT_LOGGING",
    "JobMetadata",
    "get_job_metadata",
    "init_logging",
    "init_uncaught_exception_logging",
    "set_telemetry_metadata",
]
