"""Simple math operations: add, subtract, multiply, divide"""

def add(a, b):
    """Return the sum of a and b."""
    return a + b

def subtract(a, b):
    """Return a minus b."""
    return a - b

def multiply(a, b):
    """Return product of a and b."""
    return a * b

def divide(a, b):
    """Return a divided by b. Raises ZeroDivisionError if b == 0."""
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b
