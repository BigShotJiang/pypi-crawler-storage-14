"""myfirstpro package - simple math operations"""
from .operations import add, subtract, multiply, divide

__all__ = ['add', 'subtract', 'multiply', 'divide']
__version__ = "0.1.0"
