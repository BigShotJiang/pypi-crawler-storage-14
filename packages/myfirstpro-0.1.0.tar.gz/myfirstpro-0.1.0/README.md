# myfirstpro

`myfirstpro` is a minimal Python package that provides four basic math functions:

- `add(a, b)`
- `subtract(a, b)`
- `multiply(a, b)`
- `divide(a, b)` (raises `ZeroDivisionError` on division by zero)

Install: (not published on PyPI — use local install)
```bash
pip install ./myfirstpro
```

Example:
```python
from myfirstpro import add, divide
print(add(2,3))        # 5
print(divide(10,2))    # 5.0
```
