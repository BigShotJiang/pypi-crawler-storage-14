\# Calculadora Python



Um pacote simples de calculadora escrito em Python.  

Ele oferece operações básicas como soma, subtração, multiplicação e divisão.



---



\## 📦 Instalação



Se o pacote estiver somente na sua máquina (modo desenvolvimento):



```bash

pip install -e .

