def test():
    assert True
