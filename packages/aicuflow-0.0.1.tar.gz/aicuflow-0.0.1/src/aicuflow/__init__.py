def aicu():
    return "flow"
