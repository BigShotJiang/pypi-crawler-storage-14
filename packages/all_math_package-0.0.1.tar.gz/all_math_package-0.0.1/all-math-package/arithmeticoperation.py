# arithmeticoperation.py

def arithmeticoperation(num1, num2, choice):
    # -----------------------------
    # STEP 1: Validate and convert numeric inputs
    # -----------------------------
    def convert_to_number(value):
        # Reject alphabetic characters in numeric input
        if isinstance(value, str):
            if any(c.isalpha() for c in value):
                raise ValueError(f"Invalid numeric input: '{value}'. Alphabetic characters are not allowed.")
            try:
                # Convert string to float or int
                if "." in value:
                    return float(value)
                else:
                    return int(value)
            except ValueError:
                raise ValueError(f"Invalid numeric input: '{value}'. Cannot convert to a number.")
        return value

    num1 = convert_to_number(num1)
    num2 = convert_to_number(num2)

    # -----------------------------
    # STEP 2: Normalize choice input
    # -----------------------------
    if not isinstance(choice, str):
        raise ValueError("Choice must be a string.")

    choice = choice.lower().strip()

    # Map multiple inputs to unified operation names
    operation_map = {
        "+": "add",
        "-": "sub",
        "*": "mul",
        "/": "div",
        "%": "mod",

        "add": "add",
        "addition": "add",

        "sub": "sub",
        "subtract": "sub",
        "subtraction": "sub",

        "prod": "mul",
        "multiply": "mul",
        "multiplication": "mul",

        "div": "div",
        "divide": "div",
        "division": "div",

        "mod": "mod",
        "modulo": "mod",
    }

    if choice not in operation_map:
        raise ValueError(f"Invalid operation choice: '{choice}'")

    operation = operation_map[choice]

    # -----------------------------
    # STEP 3: Perform arithmetic using match-case
    # -----------------------------
    match operation:
        case "add":
            return num1 + num2

        case "sub":
            return num1 - num2

        case "mul":
            return num1 * num2

        case "div":
            if num2 == 0:
                raise ZeroDivisionError("Division by zero is not allowed.")
            return num1 / num2

        case "mod":
            if num2 == 0:
                raise ZeroDivisionError("Modulo by zero is not allowed.")
            return num1 % num2

        case _:
            raise ValueError("Unexpected operation encountered.")
