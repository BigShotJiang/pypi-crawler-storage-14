from setuptools import setup, find_packages

classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Education",
    "Intended Audience :: Developers",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Operating System :: OS Independent",
]

setup(
    name="all-math-package",
    version='0.0.1',
    description="All-Math-Package Python Package Is For All Types Of Mathematical Solutions.",
    url="",
    author="ATISH KUMAR SAHU",
    author_email="kumarsahuatishoff280301@gmail.com",
    license='MIT',
    license_files=("LICENSE",),
    classifiers=classifiers,
    keywords='all-math-package, arithmetic operations, addition, subtraction, multiplication, division, modulo',
    packages=find_packages(),
    install_requires=[],
)