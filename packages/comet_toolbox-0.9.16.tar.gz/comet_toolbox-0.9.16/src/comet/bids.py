#import nibabel as nib
#from bids import BIDSLayout
#from nilearn import datasets, maskers
#from nilearn.interfaces.fmriprep import load_confounds

"""
SECTION: BIDS data handling
 - Currently only implemented as a draft in the gui functions.
   will be outsourced to this file in the future
"""
def load_fmriprep_outputs(bids_folder):
    pass
