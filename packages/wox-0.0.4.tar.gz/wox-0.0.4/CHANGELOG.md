## [unreleased]

### 🚀 Features

- Git setup
