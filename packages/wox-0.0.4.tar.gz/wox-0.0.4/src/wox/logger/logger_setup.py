import logging
import sys

from wox.logger.handlers.stream_handler import initialize_console_handler

from wox.logger.handlers.log_file_handler import initialize_log_file_handler


SUBINFO = 25
logging.addLevelName(SUBINFO, 'SUBINFO')

def subinfo_log(self, message, *args, **kwargs):
    if self.isEnabledFor(SUBINFO):
        self._log(SUBINFO, message, args, **kwargs)

logging.Logger.subinfo = subinfo_log

console_handler = initialize_console_handler()
log_file_handler = initialize_log_file_handler()

wox_logger = logging.getLogger('wox')
wox_logger.setLevel(logging.INFO)
wox_logger.addHandler(console_handler)
if log_file_handler:
    wox_logger.addHandler(log_file_handler)
else:
    wox_logger.addHandler(logging.NullHandler())

if 'pytest' in sys.modules:
    wox_logger.propagate = True
else:
    wox_logger.propagate = False
