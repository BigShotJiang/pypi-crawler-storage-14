cadnaPromise
=============

.. image:: https://img.shields.io/badge/License-GPLv3-yellowgreen.svg
   :target: LICENSE
   :alt: License

.. image:: https://gitlab.lip6.fr/hilaire/promise2/badges/master/pipeline.svg
   :target: pipeline
   :alt: Pipeline

--------------------------------------------------------------------------------------------

``cadnaPromise`` is a software for precision tuning via static analysis and dynamic profiling.  
It is based on the `CADNA library <https://cadna.lip6.fr/>`_, which implements Discrete Stochastic Arithmetic (DSA) to estimate round-off error propagation in numerical codes.

``cadnaPromise`` provides precision auto-tuning through command-line interfaces.
