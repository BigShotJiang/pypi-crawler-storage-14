from packaging.specifiers import SpecifierSet
from packaging.requirements import Requirement


class EndOfLife:
    family = "endoflife"


class EOL001(EndOfLife):
    """Recent Python Verion"""

    url = "https://endoflife.date/python"

    @staticmethod
    def check(pyproject):
        match pyproject:
            case {"project": {"requires-python": version}}:
                req = SpecifierSet(version)
                if req.contains("3.9"):
                    return f"Specified version {req} too low"
                return True
            case _:
                return "Missing requires-python"


class EOL002(EndOfLife):
    """Recent Django Version"""

    url = "https://endoflife.date/django"

    @staticmethod
    def check(pyproject):
        match pyproject:
            case {"project": {"dependencies": dependencies}}:
                for dep in dependencies:
                    req = Requirement(dep)
                    if req.name.lower() == "django":
                        if req.specifier.contains("3.2"):
                            return f"Specified version {req} too low"
                        return True
            case _:
                return None


def repo_review_checks() -> dict[str, EndOfLife]:
    return {p.__name__: p() for p in EndOfLife.__subclasses__()}
