# Checks for old requirements based on endoflife.date

See also

- <https://repo-review.readthedocs.io/en/latest/index.html>
- <https://endoflife.date/python>
- <https://endoflife.date/django>
