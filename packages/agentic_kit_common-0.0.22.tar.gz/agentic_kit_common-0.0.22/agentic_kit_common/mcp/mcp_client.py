import logging
from typing import Dict, Any, List, Optional, TYPE_CHECKING

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_core.tools import BaseTool

# if TYPE_CHECKING:
#     from src.core.config import ConfigManager

logger = logging.getLogger(__name__)
logger.setLevel(logging.ERROR)


class MCPToolsNotAvailableError(Exception):
    """MCP工具不可用异常"""
    pass


class MCPClient:
    """
    MCP (Model Context Protocol) 客户端
    
    支持的配置方式（优先级从高到低）：
    1. 初始化时传入的 config 参数
    2. 配置管理器 (config_manager)
    3. 默认配置文件（项目根目录/conf.yaml）
    
    Examples:
        # 方式1: 直接传入配置（外部 SDK 推荐）
        client = MCPClient(config={
            "default_servers": {
                "web_search": {
                    "url": "http://your-server.com/mcp",
                    "transport": "streamable_http",
                    "enabled_tools": ["web_search", "crawl_page"]  # 可选，不传则使用所有工具
                }
            }
        })
        
        # 方式2: 使用配置管理器
        from src.core.config import ConfigManager
        config_mgr = ConfigManager(config={
            "MCP_SETTINGS": {
                "default_servers": {...}
            }
        })
        client = MCPClient(config_manager=config_mgr)
        
        # 方式3: 使用默认配置文件（conf.yaml）
        client = MCPClient()
    """
    
    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        config_manager: Optional['ConfigManager'] = None
    ):
        """
        初始化MCP客户端
        
        Args:
            config: 直接传入的配置字典（可选）
                格式示例：
                {
                    "default_servers": {
                        "server_name": {
                            "url": "http://...",
                            "transport": "sse" | "streamable_http",
                            "enabled_tools": ["tool1", "tool2"]  # 可选，不传则使用所有工具
                        }
                    }
                }
            config_manager: 配置管理器实例（可选）
        """
        assert not (config is None and config_manager is None), "config 与 config_manager 不能同时为 None"

        self._config = config
        self._config_manager = config_manager
        self._client: Optional[MultiServerMCPClient] = None
        self._initialized = False
        self._enabled_tools_map: Dict[str, List[str]] = {}  # 服务器名 -> 启用的工具列表
        self._server_tools_cache: Dict[str, List[BaseTool]] = {}  # 服务器名 -> 工具列表缓存
    
    def _get_mcp_config(self) -> Dict[str, Any]:
        """
        获取 MCP 配置
        
        Returns:
            Dict[str, Any]: MCP 配置
        """
        if self._config:
            return self._config
        
        if self._config_manager:
            return self._config_manager.get_mcp_config()
    
    async def initialize(self):
        """初始化MCP客户端"""
        if self._initialized:
            return
        
        try:
            mcp_config = self._get_mcp_config()
            default_servers = mcp_config.get('default_servers', {})
            
            if not default_servers:
                logger.warning("配置文件中没有MCP服务器")
                return
            
            logger.info(f"开始初始化 {len(default_servers)} 个MCP服务器...")
            
            server_configs = {}
            for server_name, server_config in default_servers.items():
                url = server_config.get('url')
                transport = server_config.get('transport', 'sse')
                enabled_tools = server_config.get('enabled_tools')
                
                if not url:
                    logger.warning(f"服务器 {server_name} 缺少URL配置")
                    continue
                
                server_configs[server_name] = {
                    'url': url,
                    'transport': transport
                }
                
                if enabled_tools:
                    self._enabled_tools_map[server_name] = enabled_tools
                    logger.info(f"服务器 {server_name} 启用工具: {enabled_tools}")
                else:
                    logger.info(f"服务器 {server_name} 将使用所有可用工具")
            
            if not server_configs:
                logger.warning("没有有效的MCP服务器配置")
                return
            
            self._client = MultiServerMCPClient(server_configs)
            
            self._initialized = True
            
            tools = await self.get_all_tools()
            logger.info(f"成功初始化MCP客户端，加载了 {len(tools)} 个工具")
            
        except Exception as e:
            logger.error(f"MCP客户端初始化失败: {str(e)}", exc_info=True)
            raise MCPToolsNotAvailableError(f"初始化失败: {str(e)}") from e
    
    async def get_all_tools(self) -> List[BaseTool]:
        """
        获取所有MCP工具
        
        如果配置了 enabled_tools，只返回启用的工具；
        否则返回所有可用工具。
        
        Returns:
            List[BaseTool]: 所有可用工具的列表（LangChain工具）
        """
        if not self._initialized:
            await self.initialize()
        
        if not self._client:
            logger.warning("MCP客户端未初始化")
            return []
        
        try:
            all_tools = await self._client.get_tools()
            
            if not self._enabled_tools_map:
                logger.debug(f"获取到 {len(all_tools)} 个MCP工具（使用所有工具）")
                return all_tools
            
            enabled_tools = []
            all_enabled_tool_names = set()
            
            for server_name, tool_names in self._enabled_tools_map.items():
                all_enabled_tool_names.update(tool_names)
            
            for tool in all_tools:
                if tool.name in all_enabled_tool_names:
                    enabled_tools.append(tool)
            
            logger.info(f"获取到 {len(all_tools)} 个MCP工具，启用了 {len(enabled_tools)} 个工具")
            if len(enabled_tools) < len(all_enabled_tool_names):
                missing_tools = all_enabled_tool_names - {t.name for t in enabled_tools}
                logger.warning(f"配置中的某些工具未找到: {missing_tools}")
            
            return enabled_tools
            
        except Exception as e:
            logger.error(f"获取MCP工具失败: {str(e)}", exc_info=True)
            return []

    async def get_tool_by_name(self, tool_name: str) -> Optional[BaseTool]:
        """
        根据名称获取特定工具
        
        Args:
            tool_name: 工具名称
            
        Returns:
            工具实例，如果未找到返回None
        """
        tools = await self.get_all_tools()
        for tool in tools:
            if tool.name == tool_name:
                return tool
        return None
    
    async def get_tools_by_server(self, server_names: str | List[str]) -> List[BaseTool]:
        """
        根据服务器名称获取工具（支持单个或多个服务器）
        
        Args:
            server_names: 服务器名称或服务器名称列表
            
        Returns:
            List[BaseTool]: 工具列表（如果是多个服务器，会合并去重）
            
        Examples:
            # 获取单个服务器的工具
            tools = await mcp_client.get_tools_by_server("web_search_server")
            
            # 获取多个服务器的工具
            tools = await mcp_client.get_tools_by_server(["web_search_server", "file-processor"])
            
            # 也支持传入逗号分隔的字符串
            tools = await mcp_client.get_tools_by_server("web_search_server,file-processor")
        """
        if not self._initialized:
            await self.initialize()
        
        if not self._client:
            logger.warning("MCP客户端未初始化")
            return []
        
        # 统一处理输入格式
        if isinstance(server_names, str):
            # 支持逗号分隔的字符串
            if ',' in server_names:
                server_list = [s.strip() for s in server_names.split(',') if s.strip()]
            else:
                server_list = [server_names]
        else:
            server_list = server_names
        
        if not server_list:
            logger.warning("未提供有效的服务器名称")
            return []
        
        # 收集所有工具（去重）
        all_server_tools = []
        seen_tool_names = set()
        
        for server_name in server_list:
            # 检查缓存
            if server_name in self._server_tools_cache:
                logger.debug(f"使用缓存的服务器工具: {server_name}")
                server_tools = self._server_tools_cache[server_name]
            else:
                # 获取该服务器的工具
                server_tools = await self._get_single_server_tools(server_name)
                # 缓存结果
                self._server_tools_cache[server_name] = server_tools
            
            # 添加到结果中（去重）
            for tool in server_tools:
                if tool.name not in seen_tool_names:
                    all_server_tools.append(tool)
                    seen_tool_names.add(tool.name)
        
        if len(server_list) == 1:
            logger.info(f"服务器 {server_list[0]} 有 {len(all_server_tools)} 个工具")
        else:
            logger.info(f"从 {len(server_list)} 个服务器获取了 {len(all_server_tools)} 个工具（已去重）")
        
        return all_server_tools
    
    async def _get_single_server_tools(self, server_name: str) -> List[BaseTool]:
        """
        获取单个服务器的工具（内部方法）
        
        Args:
            server_name: 服务器名称
            
        Returns:
            List[BaseTool]: 该服务器的工具列表
        """
        try:
            all_tools = await self._client.get_tools()
            server_tools = []
            
            for tool in all_tools:
                # 方式1: 检查 tool.server 属性
                if hasattr(tool, 'server') and tool.server == server_name:
                    server_tools.append(tool)
                # 方式2: 检查 tool.metadata
                elif hasattr(tool, 'metadata') and tool.metadata is not None and tool.metadata.get('server') == server_name:
                    server_tools.append(tool)
                # 方式3: 检查 enabled_tools_map 配置
                elif server_name in self._enabled_tools_map:
                    if tool.name in self._enabled_tools_map[server_name]:
                        server_tools.append(tool)
            
            # 如果前面的方式都没找到，但配置了 enabled_tools，尝试按工具名匹配
            if not server_tools and server_name in self._enabled_tools_map:
                enabled_tool_names = self._enabled_tools_map[server_name]
                server_tools = [
                    tool for tool in all_tools 
                    if tool.name in enabled_tool_names
                ]
            
            logger.debug(f"服务器 {server_name} 有 {len(server_tools)} 个工具")
            return server_tools
            
        except Exception as e:
            logger.error(f"获取服务器 {server_name} 的工具失败: {str(e)}", exc_info=True)
            return []
    
    async def list_servers(self) -> List[str]:
        """
        列出所有配置的服务器名称
        
        Returns:
            List[str]: 服务器名称列表
            
        Examples:
            servers = await mcp_client.list_servers()
            print(f"已配置的服务器: {servers}")
        """
        mcp_config = self._get_mcp_config()
        default_servers = mcp_config.get('default_servers', {})
        return list(default_servers.keys())
    
    def close(self):
        """
        清理 MCP 客户端
        """
        if self._client and self._initialized:
            self._initialized = False
            self._client = None
            self._server_tools_cache.clear()
            logger.info("MCP客户端已清理")

# mcp_client = MCPClient()
