import inspect
import logging
import os
from typing import Any, Dict, Literal, get_args, Optional

import httpx
from langchain_core.language_models import BaseChatModel
from langchain_openai import ChatOpenAI

logger = logging.getLogger(__name__)

LLMType = Literal["basic", "vision"]


class LLMManager:
    """
    LLM 管理器 - 支持从配置文件或外部传入配置
    
    配置优先级（从高到低）：
    1. 环境变量（BASIC_MODEL__api_key 等）
    2. 运行时传入的 llm_config 参数
    3. 初始化时传入的 config 参数
    4. 项目根目录下的 conf.yaml 文件
    """
    
    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        config_manager: Optional['ConfigManager'] = None,
        use_cache: bool = True
    ):
        """
        初始化 LLM 管理器
        
        Args:
            config: 外部传入的配置字典（可选），格式示例：
                # 方式1: 多模型配置
                {
                    "BASIC_MODEL": {
                        "default": "qwen",
                        "models": {
                            "qwen": {
                                "base_url": "http://example.com/v1",
                                "model": "qwen-model",
                                "api_key": "YOUR_API_KEY",
                                "temperature": 0.1
                            },
                            "gpt4": {
                                "base_url": "https://api.openai.com/v1",
                                "model": "gpt-4",
                                "api_key": "YOUR_API_KEY"
                            }
                        }
                    }
                }
                
                # 方式2: 单模型配置
                {
                    "BASIC_MODEL": {
                        "base_url": "http://example.com/v1",
                        "model": "qwen-model",
                        "api_key": "YOUR_API_KEY",
                        "temperature": 0.1
                    }
                }
            
            use_cache: 是否使用缓存（默认True）
            config_manager: 配置管理器实例（可选），用于从配置文件或其他来源加载配置
        
        Examples:
            # SDK 外部调用示例1: 传入完整配置（推荐）
            manager = LLMManager(config={
                "BASIC_MODEL": {
                    "base_url": "http://your-server.com/v1",
                    "model": "qwen",
                    "api_key": "sk-xxx"
                }
            })
            llm = manager.get_llm()
            
            # SDK 外部调用示例2: 使用配置管理器
            from src.core.config import ConfigManager
            config_mgr = ConfigManager(config_path="/custom/path/conf.yaml")
            manager = LLMManager(config_manager=config_mgr)
            llm = manager.get_llm()
            
            # SDK 外部调用示例3: 使用默认配置文件（conf.yaml）
            manager = LLMManager()
            llm = manager.get_llm()
            
            # SDK 外部调用示例4: 运行时直接传入配置
            manager = LLMManager()
            llm = manager.get_llm(llm_config={
                "base_url": "http://example.com/v1",
                "model": "qwen",
                "api_key": "sk-xxx"
            })
        """
        assert not (config is None and config_manager is None), "config 与 config_manager 不能同时为 None"

        self._external_config = config or {}
        self._config_manager = config_manager
        self._use_cache = use_cache
        self._llm_cache: dict[tuple, BaseChatModel] = {}
        
    def _get_llm_type_config_keys(self) -> dict[str, str]:
        """获取 LLM 类型到配置键的映射"""
        return {
            "basic": "BASIC_MODEL",
            "vision": "VISION_MODEL",
        }
    
    def _get_env_llm_conf(self, llm_type: str) -> Dict[str, Any]:
        """
        从环境变量获取 LLM 配置
        
        环境变量格式: {LLM_TYPE}_MODEL__{KEY}
        例如: BASIC_MODEL__api_key, BASIC_MODEL__base_url
        """
        prefix = f"{llm_type.upper()}_MODEL__"
        conf = {}
        for key, value in os.environ.items():
            if key.startswith(prefix):
                conf_key = key[len(prefix):].lower()
                conf[conf_key] = value
        return conf
    
    def _create_llm(self, llm_type: LLMType, llm_conf: Dict[str, Any]) -> BaseChatModel:
        """根据配置创建 LLM 实例"""
        if not llm_conf:
            raise ValueError(f"No configuration found for LLM type: {llm_type}")
        
        llm_conf = llm_conf.copy()
        
        # 设置默认值
        llm_conf.setdefault("max_retries", 3)
        llm_conf.setdefault("parallel_tool_calls", False)
        
        # 处理 SSL 验证
        verify_ssl = llm_conf.pop("verify_ssl", True)
        if not verify_ssl:
            llm_conf["http_client"] = httpx.Client(verify=False)
            llm_conf["http_async_client"] = httpx.AsyncClient(verify=False)
        
        # 过滤只保留 ChatOpenAI 支持的参数
        constructor_params = inspect.signature(ChatOpenAI).parameters
        filtered_conf = {k: v for k, v in llm_conf.items() if k in constructor_params}
        
        logger.info(f"创建LLM实例: type={llm_type}, model={filtered_conf.get('model')}, "
                   f"base_url={filtered_conf.get('base_url')}")
        
        return ChatOpenAI(**filtered_conf)
    
    def _get_config_section(self, llm_type: LLMType) -> Dict[str, Any]:
        """
        获取配置段（优先使用外部配置，其次使用配置文件）
        
        配置读取逻辑（优先级从高到低）：
        1. 初始化时传入的 config 参数
        2. 配置管理器 (config_manager)
        3. 默认配置文件（项目根目录/conf.yaml）
           - 配置文件路径：项目根目录/conf.yaml
           - 通过 src.core.config.get_llm_config() 读取
           - 会自动缓存，避免重复读取
        """
        llm_type_config_keys = self._get_llm_type_config_keys()
        config_key = llm_type_config_keys.get(llm_type)
        
        if not config_key:
            raise ValueError(f"Unknown LLM type: {llm_type}")
        
        # 优先使用外部传入的配置
        if config_key in self._external_config:
            return self._external_config[config_key]
        
        # 使用配置管理器
        if self._config_manager:
            return self._config_manager.get_llm_config(config_key)

        raise ValueError(f"Failed to load configuration for LLM type '{llm_type}'")

    def _create_llm_from_config(self, llm_type: LLMType, model_name: str = None) -> BaseChatModel:
        """从配置创建 LLM 实例"""
        llm_conf_section = self._get_config_section(llm_type)
        
        final_llm_conf = {}
        is_multi_model_conf = "models" in llm_conf_section and isinstance(
            llm_conf_section.get("models"), dict
        )
        
        if is_multi_model_conf:
            # 多模型配置
            models = llm_conf_section["models"]
            target_model_name = model_name or llm_conf_section.get("default")
            
            if target_model_name and target_model_name in models:
                final_llm_conf = models[target_model_name]
            elif not model_name:
                raise ValueError(
                    f"No default model specified for '{llm_type}' and no model name was provided."
                )
            else:
                available_models = list(models.keys()) if models else []
                raise ValueError(
                    f"Model '{model_name}' not found in configuration for LLM type '{llm_type}'. "
                    f"Available models: {available_models}"
                )
        else:
            # 单模型配置
            if model_name:
                logger.warning(
                    f"model_name '{model_name}' provided for LLM type '{llm_type}', "
                    f"but no multi-model configuration was found. Using single model configuration."
                )
            final_llm_conf = llm_conf_section
        
        # 合并环境变量配置（环境变量优先级最高）
        env_conf = self._get_env_llm_conf(llm_type)
        merged_conf = {**final_llm_conf, **env_conf}
        
        return self._create_llm(llm_type, merged_conf)
    
    def get_llm(
        self,
        llm_type: LLMType = "basic",
        model_name: str = None,
        llm_config: Dict[str, Any] = None,
        force_new_instance: bool = False,
    ) -> BaseChatModel:
        """
        获取 LLM 实例
        
        Args:
            llm_type: LLM 类型 ('basic' 或 'vision')，默认 'basic'
            model_name: 模型名称（用于多模型配置）
            llm_config: 直接传入的配置字典（会覆盖配置文件和外部配置）
                格式示例：
                {
                    "base_url": "http://example.com/v1",
                    "model": "qwen-model",
                    "api_key": "YOUR_API_KEY",
                    "temperature": 0.1,
                    "max_tokens": 2000
                }
            force_new_instance: 是否强制创建新实例（忽略缓存）
            
        Returns:
            BaseChatModel 实例
            
        Examples:
            # 方式1: 使用默认配置
            llm = manager.get_llm()
            
            # 方式2: 指定模型名称
            llm = manager.get_llm(model_name="qwen")
            
            # 方式3: 运行时传入配置
            llm = manager.get_llm(llm_config={
                "base_url": "http://example.com/v1",
                "model": "qwen",
                "api_key": "sk-xxx"
            })
            
            # 方式4: 获取 vision 模型
            llm = manager.get_llm(llm_type="vision")
            
            # 方式5: 强制创建新实例（不使用缓存）
            llm = manager.get_llm(force_new_instance=True)
        """
        # 如果直接传入配置，直接创建（不使用缓存）
        if llm_config:
            env_conf = self._get_env_llm_conf(llm_type)
            merged_conf = {**llm_config, **env_conf}
            return self._create_llm(llm_type, merged_conf)
        
        # 检查缓存
        cache_key = (llm_type, model_name)
        if self._use_cache and not force_new_instance and cache_key in self._llm_cache:
            logger.debug(f"使用缓存的LLM实例: type={llm_type}, model={model_name}")
            return self._llm_cache[cache_key]
        
        # 创建新实例
        llm = self._create_llm_from_config(llm_type, model_name=model_name)
        
        # 存入缓存
        if self._use_cache and not force_new_instance:
            self._llm_cache[cache_key] = llm
        
        return llm
    
    def get_basic_llm(
        self,
        model_name: str = None,
        llm_config: Dict[str, Any] = None,
        force_new_instance: bool = False,
    ) -> BaseChatModel:
        """
        快捷方法：获取 basic 类型的 LLM
        
        这是最常用的方法，等同于 get_llm(llm_type="basic", ...)
        """
        return self.get_llm("basic", model_name, llm_config, force_new_instance)
    
    def get_vision_llm(
        self,
        model_name: str = None,
        llm_config: Dict[str, Any] = None,
        force_new_instance: bool = False,
    ) -> BaseChatModel:
        """
        快捷方法：获取 vision 类型的 LLM
        
        等同于 get_llm(llm_type="vision", ...)
        """
        return self.get_llm("vision", model_name, llm_config, force_new_instance)
    
    def get_configured_models(self) -> dict[str, dict]:
        """
        获取所有已配置的模型信息
        
        Returns:
            字典，按 LLM 类型分组，包含 models 列表和 default 模型
            格式：
            {
                "basic": {
                    "models": ["qwen", "gpt4"],
                    "default": "qwen"
                },
                "vision": {
                    "models": ["qwen-vl"],
                    "default": "qwen-vl"
                }
            }
        
        Examples:
            models = manager.get_configured_models()
            print(f"可用的 basic 模型: {models['basic']['models']}")
            print(f"默认 basic 模型: {models['basic']['default']}")
        """
        try:
            configured_models: dict[str, dict] = {}
            
            for llm_type in get_args(LLMType):
                try:
                    llm_conf_section = self._get_config_section(llm_type)
                    
                    if "models" in llm_conf_section and isinstance(
                        llm_conf_section.get("models"), dict
                    ):
                        # 多模型配置
                        model_names = list(llm_conf_section["models"].keys())
                        default = llm_conf_section.get("default")
                        configured_models[llm_type] = {
                            "models": model_names,
                            "default": default
                        }
                    else:
                        # 单模型配置
                        env_conf = self._get_env_llm_conf(llm_type)
                        merged_conf = {**llm_conf_section, **env_conf}
                        model_name = merged_conf.get("model")
                        if model_name:
                            configured_models[llm_type] = {
                                "models": [model_name],
                                "default": model_name
                            }
                except Exception:
                    # 如果某个类型配置不存在，跳过
                    continue
            
            return configured_models
        
        except Exception as e:
            logger.error(f"Failed to load LLM configuration: {e}")
            return {}
    
    def clear_cache(self):
        """清除 LLM 实例缓存"""
        self._llm_cache.clear()
        logger.info("LLM缓存已清除")
    
    def __repr__(self) -> str:
        """返回 LLMManager 的字符串表示"""
        has_external_config = bool(self._external_config)
        cache_size = len(self._llm_cache)
        return (
            f"LLMManager(has_external_config={has_external_config}, "
            f"use_cache={self._use_cache}, cached_instances={cache_size})"
        )
