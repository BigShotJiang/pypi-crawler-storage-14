# 📝 Environment Configuration Example

Create a `.env` file in your project root with these settings:

```bash
# ============================================================================
# APEX SAAS FRAMEWORK - ENVIRONMENT CONFIGURATION
# ============================================================================

# ============================================================================
# 🗄️ DATABASE CONFIGURATION (REQUIRED)
# ============================================================================
DATABASE_URL=postgresql+asyncpg://postgres:mypassword@localhost:5432/mydb

# ============================================================================
# 🔐 SECURITY & JWT (REQUIRED)
# ============================================================================
# Generate with: python -c "import secrets; print(secrets.token_urlsafe(32))"
SECRET_KEY=your-super-secret-key-min-32-characters-change-in-production

# ============================================================================
# 🌐 APPLICATION SETTINGS (OPTIONAL)
# ============================================================================
APP_NAME=My SaaS App
ENVIRONMENT=development
DEBUG=true

# ============================================================================
# 🔗 CORS SETTINGS (OPTIONAL)
# ============================================================================
CORS_ORIGINS=http://localhost:3000,http://localhost:8000

# ============================================================================
# 📧 EMAIL CONFIGURATION (OPTIONAL)
# ============================================================================
EMAIL_PROVIDER=sendgrid
SEND_GRID_API=SG.your-sendgrid-api-key-here
FROM_EMAIL=noreply@yourdomain.com
FROM_NAME=My SaaS App
FRONTEND_RESET_URL=http://localhost:3000/reset-password

# ============================================================================
# 💳 PAYPAL CONFIGURATION (OPTIONAL)
# ============================================================================
PAYPAL_CLIENT_ID=your-paypal-client-id
PAYPAL_CLIENT_SECRET=your-paypal-client-secret
PAYPAL_MODE=sandbox
```

## 🚀 Quick Setup

### 1. Create `.env` file:
```bash
touch .env
nano .env  # or use your favorite editor
```

### 2. Minimal Configuration (Required):
```bash
DATABASE_URL=postgresql+asyncpg://postgres:mypassword@localhost:5432/mydb
SECRET_KEY=your-super-secret-key-change-this-in-production
```

### 3. Generate Strong Secret Key:
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

## 🐳 Quick PostgreSQL Setup with Docker

```bash
# Start PostgreSQL container
docker run --name apex-db \
  -e POSTGRES_PASSWORD=mypassword \
  -e POSTGRES_DB=mydb \
  -p 5432:5432 \
  -d postgres:15

# Your DATABASE_URL is:
# postgresql+asyncpg://postgres:mypassword@localhost:5432/mydb
```

## ✅ Test Your Configuration

Create `test_config.py`:

```python
from apex.core.config import get_settings

settings = get_settings()
print(f"✅ App Name: {settings.APP_NAME}")
print(f"✅ Database: {settings.DATABASE_URL}")
print(f"✅ Environment: {settings.ENVIRONMENT}")
print("✅ Configuration loaded successfully!")
```

Run:
```bash
python test_config.py
```

## 📋 Complete Example for Testing

Save as `.env`:

```bash
# Database
DATABASE_URL=postgresql+asyncpg://postgres:mypassword@localhost:5432/mydb

# Security
SECRET_KEY=test-secret-key-for-local-dev-only-change-in-production

# App
APP_NAME=Test SaaS App
DEBUG=true

# CORS
CORS_ORIGINS=http://localhost:3000,http://localhost:8000
```

## 🔐 Production Configuration

For production, use strong values:

```bash
# Database (use production credentials)
DATABASE_URL=postgresql+asyncpg://prod_user:strong_password@prod-db.example.com:5432/prod_db

# Security (generate strong key!)
SECRET_KEY=wJhQG8g6...your-actual-secure-key...LmN9pK
ENVIRONMENT=production
DEBUG=false

# Email (real credentials)
EMAIL_PROVIDER=sendgrid
SEND_GRID_API=SG.real-api-key-here
FROM_EMAIL=noreply@yourcompany.com
FRONTEND_RESET_URL=https://yourapp.com/reset-password

# PayPal (production credentials)
PAYPAL_CLIENT_ID=your-live-client-id
PAYPAL_CLIENT_SECRET=your-live-client-secret
PAYPAL_MODE=live

# CORS (your actual domain)
CORS_ORIGINS=https://yourapp.com,https://www.yourapp.com
```

## ⚠️ Security Best Practices

1. **NEVER commit `.env` to git** - Add to `.gitignore`
2. **Generate strong SECRET_KEY** - Use `secrets.token_urlsafe(32)`
3. **Use different keys per environment** - Dev, staging, production
4. **Rotate secrets regularly** - Change keys periodically
5. **Use secret management** - AWS Secrets Manager, Azure Key Vault, etc.
6. **Set proper file permissions** - `chmod 600 .env`

## 🆘 Troubleshooting

### Error: "SECRET_KEY must be at least 32 characters"
```bash
# Generate a proper key:
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

### Error: "Database connection failed"
```bash
# Check if PostgreSQL is running:
docker ps | grep postgres

# Test connection:
psql postgresql://postgres:mypassword@localhost:5432/mydb
```

### Error: "No module named 'dotenv'"
```bash
pip install python-dotenv
```

## 📚 More Information

- **Quick Start:** See `QUICK_START.md`
- **User Guide:** See `USER_GUIDE.md`
- **Simple Usage:** See `SIMPLE_USAGE.md`
- **PyPI:** https://pypi.org/project/apex-saas-framework/

