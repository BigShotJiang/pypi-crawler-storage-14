"""
Users router - CRUD operations for users.

This is a base implementation. Users should extend this to work with their
specific User model and add custom business logic.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from apex.api.v1.schemas.user import UserCreate, UserResponse, UserUpdate
from apex.core.authentication.dependencies import get_current_active_user
from apex.core.permissions.dependencies import require_permission
from apex.infrastructure.database.session import get_db

router = APIRouter(tags=["Users"])


@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: dict = Depends(require_permission("users", "create")),
):
    """
    Create a new user.

    This is a base implementation. Users should override this to:
    1. Provide their User model
    2. Implement actual creation logic

    Args:
        user_data: User creation data
        db: Database session
        current_user: Current authenticated user with permissions

    Returns:
        Created user data

    Raises:
        HTTPException: If creation fails
    """
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="User creation endpoint needs to be implemented with your User model",
    )


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: dict = Depends(require_permission("users", "read")),
):
    """
    Get user by ID.

    Args:
        user_id: User UUID
        db: Database session
        current_user: Current authenticated user with permissions

    Returns:
        User data

    Raises:
        HTTPException: If user not found
    """
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Get user endpoint needs to be implemented with your User model",
    )


@router.get("/", response_model=list[UserResponse])
async def list_users(
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: dict = Depends(require_permission("users", "read")),
    skip: int = 0,
    limit: int = 100,
):
    """
    List all users with pagination.

    Args:
        skip: Number of records to skip
        limit: Maximum number of records to return
        db: Database session
        current_user: Current authenticated user with permissions

    Returns:
        List of users
    """
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="List users endpoint needs to be implemented with your User model",
    )


@router.patch("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    user_data: UserUpdate,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: dict = Depends(require_permission("users", "update")),
):
    """
    Update user.

    Args:
        user_id: User UUID
        user_data: User update data
        db: Database session
        current_user: Current authenticated user with permissions

    Returns:
        Updated user data

    Raises:
        HTTPException: If user not found or update fails
    """
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Update user endpoint needs to be implemented with your User model",
    )


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: dict = Depends(require_permission("users", "delete")),
):
    """
    Delete user.

    Args:
        user_id: User UUID
        db: Database session
        current_user: Current authenticated user with permissions

    Raises:
        HTTPException: If user not found or deletion fails
    """
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Delete user endpoint needs to be implemented with your User model",
    )

