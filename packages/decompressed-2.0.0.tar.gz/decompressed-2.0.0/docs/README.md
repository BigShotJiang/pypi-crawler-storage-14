# Decompressed Website

This is the React-based website for the Decompressed library, hosted on GitHub Pages.

## Development

```bash
cd docs
npm install
npm run dev
```

## Build for Production

```bash
npm run build
```

## Deployment

GitHub Pages automatically deploys the `build` directory when pushed to the `main` branch.
