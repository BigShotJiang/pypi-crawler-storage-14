# Euroncalcu

A Simple calculator package for python.

## Installation

'''bash
pip install euroncalcu