"""boilerplate necessary to build conda packages."""

from setuptools import setup

setup()
