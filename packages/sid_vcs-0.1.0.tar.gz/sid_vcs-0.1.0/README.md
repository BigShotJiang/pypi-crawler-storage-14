# SID-VCS
A minimal Git-like version control system made with python

After unzipping, you can install it locally:

pip install .


Then run:

sid init
sid add file.txt
sid commit "msg"
sid log
