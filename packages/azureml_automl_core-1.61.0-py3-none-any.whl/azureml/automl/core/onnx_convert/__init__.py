# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Init for the onnx_convert module."""

# OnnxConvert Constants module.
from .onnx_convert_constants import OnnxConvertConstants, SplitOnnxModelName
