# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Contains functionality for customizing automated ML in Azure Machine Learning."""
from .featurizationconfig import FeaturizationConfig
