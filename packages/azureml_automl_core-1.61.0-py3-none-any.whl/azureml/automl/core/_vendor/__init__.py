# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""
This is a legacy stub package that used to exist for the previously vendored
azureml.automl.core.shared packaged.
"""
