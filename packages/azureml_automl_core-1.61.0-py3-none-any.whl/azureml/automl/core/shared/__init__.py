# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""
Contains shared classes used by multiple packages under azureml.automl.core
for Azure Machine Learning.
"""
