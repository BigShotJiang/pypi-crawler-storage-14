NAME='router_uwsgi'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_uwsgi']
