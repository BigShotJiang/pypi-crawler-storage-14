"""Integration tests for Rapids."""
