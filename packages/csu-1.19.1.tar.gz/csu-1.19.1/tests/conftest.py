import logging
import sys
from datetime import datetime
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from vcr.stubs import httpx_stubs
from vcr.stubs.httpx_stubs import _from_serialized_response

from csu import exceptions


@pytest.fixture(scope="session")
def vcr_config():
    return {
        "decode_compressed_response": True,
        "match_on": ("method", "scheme", "host", "path", "query"),  # no port because it's random
    }


@pytest.fixture
def fake_accident_id(monkeypatch):
    calls = []

    def fake_urandom(_):
        frame = sys._getframe().f_back.f_back
        filename = Path(frame.f_code.co_filename).name
        calls.append(f"{filename}:{frame.f_lineno}")
        return bytes([len(calls)])

    monkeypatch.setattr(exceptions, "naivenow", lambda: datetime(2024, 12, 12))  # noqa: DTZ001
    monkeypatch.setattr(exceptions, "urandom", fake_urandom)

    def patched_from_serialized_response(*args, **kwargs):
        resp = _from_serialized_response(*args, **kwargs)
        resp.elapsed = timedelta(microseconds=123)
        return resp

    monkeypatch.setattr(httpx_stubs, "_from_serialized_response", patched_from_serialized_response)

    return SimpleNamespace(
        calls=calls,
    )


@pytest.fixture
def caplogs(caplog):
    def get_logs():
        logs = "\n".join(f"{record.levelname:7} | {record.message}" for record in caplog.records)
        print(logs)
        return logs

    with caplog.at_level(logging.INFO, logger="service"):
        yield SimpleNamespace(
            get=get_logs,
        )
