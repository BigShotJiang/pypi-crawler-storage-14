This module allows you to set a default bank account purchase orders. 
That bank account will be propagated to its vendor bills.
