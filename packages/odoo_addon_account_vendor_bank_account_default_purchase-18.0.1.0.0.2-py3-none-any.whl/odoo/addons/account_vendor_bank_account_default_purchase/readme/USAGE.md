To use this module, you need to:

1. Create a purchase order. On the other info tab you can see its bank account, which will be equal to the configured in the partner's "Default Bank Account" field.
2. Confirm the purchase and create its vendor bill. Its recipient bank account will be equal to the purchase's bank account.
