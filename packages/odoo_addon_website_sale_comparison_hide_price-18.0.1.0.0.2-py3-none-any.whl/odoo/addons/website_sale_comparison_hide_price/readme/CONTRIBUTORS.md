- [Tecnativa](https://www.tecnativa.com/):

  - David Vidal

- [InitOS](https://www.initos.com):

  > - Dhara Solanki \<<dhara.solanki@initos.com>\>

- [Kencove](https://kencove.com/):

  - Mohamed Alkobrosli
