This module extends the base of website_sale_hide_price to hide prices
in the comparison views as well.
