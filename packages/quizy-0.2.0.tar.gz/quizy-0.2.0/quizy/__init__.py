"""
Quizy - A professional Python quiz framework
"""

from .core import (
    Quiz,
    Question,
    QuestionType,
    MultipleChoiceQuestion,
    MultipleSelectQuestion,
    ShortTextQuestion,
    TrueFalseQuestion,
    MatchingQuestion,
    QuizResult,
    QuestionResult,
    ResultStatus,
)
from .cli import QuizCLI, TimerManager
from .quiz_101 import quiz_101
from .quiz_102 import quiz_102

__version__ = "0.2.0"
__all__ = [
    "Quiz",
    "Question",
    "QuestionType",
    "MultipleChoiceQuestion",
    "MultipleSelectQuestion",
    "ShortTextQuestion",
    "TrueFalseQuestion",
    "MatchingQuestion",
    "QuizResult",
    "QuestionResult",
    "ResultStatus",
    "QuizCLI",
    "TimerManager",
    "quiz_101",
    "quiz_102",
]
