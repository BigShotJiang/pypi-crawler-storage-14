To configure the default repair order planned duration:

    Go to "Repairs > Configuration > Settings".
    Put the value using the "hh:mm" in the "Default Planned Order Duration" field.
