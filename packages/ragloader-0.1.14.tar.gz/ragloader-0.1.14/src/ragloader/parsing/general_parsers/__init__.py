from .docling_parser import DoclingParser

__all__ = ["DoclingParser"]
