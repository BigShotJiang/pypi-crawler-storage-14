from io import BytesIO
import base64

from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.utils.model_downloader import download_models
from docling_core.types.doc import ImageRefMode, DoclingDocument
from docling_core.types.io import DocumentStream
from PIL import Image as PILImage
from pydantic import BaseModel, Field

from ragloader.indexing import File
from ragloader.parsing import ParsedFile, BaseFileParser
from ragloader.conf import get_logger


class ParsedImage(BaseModel):
    """Structured output model for image parsing."""

    visual_description: str = Field(description="Detailed visual description of what is depicted in the image")
    text_content: str = Field(default="", description="Any text visible in the image (OCR extraction)")
    key_elements: list[str] = Field(
        default_factory=list, description="List of key elements, objects, or features in the image"
    )


class DoclingParser(BaseFileParser):
    """
    General-purpose file parser using Docling's DocumentConverter.
    Supports: PDF, DOCX, XLSX, PPTX, HTML, MD, CSV, and various image formats.

    Extracts text content and handles embedded images with OCR.
    Optionally enhances image understanding using OpenAI vision model.
    """

    IMAGE_PLACEHOLDER = "<!-- image -->"

    def __init__(self, config=None):
        """
        Initialize DoclingParser with Docling's DocumentConverter.
        Downloads required models on first initialization.

        Args:
            config: Optional configuration object (for future extensibility)
        """
        self.config = config
        self.logger = get_logger(config) if config else None

        # Download Docling models (idempotent - only downloads if missing)
        download_models()

        # Initialize DocumentConverter with PDF pipeline options
        self.doc_converter = self._init_converter()

        # Initialize OpenAI image parser for enhanced image understanding
        self.image_parser_available = False
        self.openai_client = None
        self._init_image_parser()

    def _init_converter(self) -> DocumentConverter:
        """Initialize Docling DocumentConverter with pipeline options."""
        pipeline_options = PdfPipelineOptions()
        pipeline_options.generate_page_images = True
        pipeline_options.generate_picture_images = True

        doc_converter = DocumentConverter(
            format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)}
        )
        return doc_converter

    def _init_image_parser(self):
        """
        Initialize OpenAI image parser for enhanced image descriptions.
        Falls back gracefully if OpenAI is not available.
        """
        try:
            import os
            from dotenv import load_dotenv
            from openai import OpenAI

            load_dotenv()

            if not os.getenv("OPENAI_API_KEY"):
                raise ValueError("OPENAI_API_KEY not set in environment")

            self.openai_client = OpenAI()
            self.image_parser_available = True

            if self.logger:
                self.logger.info("OpenAI image parser initialized successfully")

        except Exception as e:
            if self.logger:
                self.logger.warning(f"OpenAI image parser not available: {str(e)}. Using OCR only for images.")
            self.image_parser_available = False

    def parse(self, file: File) -> ParsedFile:
        """
        Parse a file using Docling's DocumentConverter.

        Args:
            file: File object with file_path to parse

        Returns:
            ParsedFile with extracted text content
        """
        if self.logger:
            self.logger.info(f"Parsing file with DoclingParser: {file.file_name}")

        try:
            # Read file content and create DocumentStream
            with open(file.file_path, "rb") as f:
                file_content = f.read()

            doc_stream = DocumentStream(stream=BytesIO(file_content), name=file.file_name)

            # Convert document using Docling
            conv_result = self.doc_converter.convert(doc_stream)
            doc = conv_result.document

            # Export to markdown with image references
            markdown = doc.export_to_markdown(image_mode=ImageRefMode.REFERENCED)

            # Process embedded images if available
            if doc.pictures and self.image_parser_available:
                markdown = self._process_images(doc, markdown, file.file_name)

            # Create ParsedFile with extracted content
            parsed_file = ParsedFile(file.file_path, markdown)

            if self.logger:
                self.logger.info(
                    f"Successfully parsed {file.file_name} "
                    f"(pages: {len(doc.pages)}, images: {len(doc.pictures) if doc.pictures else 0})"
                )

            return parsed_file

        except Exception as e:
            error_msg = f"Failed to parse {file.file_name}: {str(e)}"
            if self.logger:
                self.logger.error(error_msg)
            raise RuntimeError(error_msg) from e

    def _process_images(self, doc: DoclingDocument, markdown: str, filename: str) -> str:
        """
        Process embedded images by extracting them and using LLM for structured description.

        Args:
            doc: Docling document object
            markdown: Extracted markdown text with IMAGE_PLACEHOLDER markers
            filename: Original filename for image naming

        Returns:
            Markdown text with image placeholders replaced by enhanced descriptions
        """
        if not doc.pictures:
            return markdown

        for i, picture in enumerate(doc.pictures):
            try:
                # Extract image from document
                image = picture.get_image(doc)

                # Generate enhanced image description using LLM with structured output
                image_markdown = self._parse_image_with_llm(
                    image=image, image_filename=f"{filename}_image_{i + 1}"
                )

                # Replace first occurrence of placeholder with image description
                markdown = markdown.replace(self.IMAGE_PLACEHOLDER, image_markdown, 1)

            except Exception as e:
                if self.logger:
                    self.logger.warning(f"Failed to process image {i + 1}: {str(e)}")
                # Replace placeholder with simple marker if processing fails
                markdown = markdown.replace(self.IMAGE_PLACEHOLDER, f"[Image {i + 1} - processing failed]", 1)

        return markdown

    def _image_to_base64(self, image: PILImage.Image) -> str:
        """
        Converts a PIL Image to a base64-encoded JPEG string.
        Handles RGBA and other modes that don't support JPEG.

        Args:
            image: PIL Image object

        Returns:
            Base64-encoded JPEG string
        """
        buffer = BytesIO()

        # Handle different image modes
        if image.mode in ("RGBA", "LA", "P"):
            rgb_image = PILImage.new("RGB", image.size, (255, 255, 255))
            if image.mode == "P":
                image = image.convert("RGBA")
            rgb_image.paste(image, mask=image.split()[-1] if image.mode in ("RGBA", "LA") else None)
            rgb_image.save(buffer, format="JPEG", quality=95)
        else:
            image.save(buffer, format="JPEG", quality=95)

        buffer.seek(0)
        return base64.b64encode(buffer.read()).decode("utf-8")

    def _parse_image_with_llm(self, image: PILImage.Image, image_filename: str) -> str:
        """
        Parse image using OpenAI vision model with structured output.

        Args:
            image: PIL Image object
            image_filename: Filename for the image

        Returns:
            Markdown formatted image description with structured content
        """
        if not self.image_parser_available or not self.openai_client:
            return f"[Image: {image_filename}]"

        try:
            # Convert PIL Image to base64
            base64_image = self._image_to_base64(image)

            # Use OpenAI vision model with structured output
            prompt = "Comprehensively describe the content of the image in a structured format."

            response = self.openai_client.beta.chat.completions.parse(
                model="gpt-4.1-nano",
                temperature=0.1,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"},
                            },
                        ],
                    },
                ],
                response_format=ParsedImage,
            )

            parsed_image: ParsedImage = response.choices[0].message.parsed

            if self.logger:
                self.logger.info(f"Successfully parsed image: {image_filename}")

            # Format structured output as markdown
            markdown_parts = [f"<image={image_filename}>", ""]

            # Visual description
            if parsed_image.visual_description:
                markdown_parts.append("**Visual Description:**")
                markdown_parts.append(parsed_image.visual_description)
                markdown_parts.append("")

            # Text content (OCR)
            if parsed_image.text_content:
                markdown_parts.append("**Text Content (OCR):**")
                markdown_parts.append(parsed_image.text_content)
                markdown_parts.append("")

            # Key elements
            if parsed_image.key_elements:
                markdown_parts.append("**Key Elements:**")
                for element in parsed_image.key_elements:
                    markdown_parts.append(f"- {element}")
                markdown_parts.append("")

            markdown_parts.append("</image>")
            markdown_parts.append("")

            return "\n".join(markdown_parts)

        except Exception as e:
            if self.logger:
                self.logger.warning(f"LLM image parsing failed for {image_filename}: {str(e)}")
            return f"[Image: {image_filename}]"
