from ._core._schema import FeatureSchema

__all__ = [
    "FeatureSchema"
]
