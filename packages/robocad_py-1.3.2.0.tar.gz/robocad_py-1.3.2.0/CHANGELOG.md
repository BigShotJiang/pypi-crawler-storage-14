# Change Log

## 0.0.0.1
- First Release

## 0.0.0.2
- Real camera exception checker added

## 0.0.0.5
- Hope this works

## 0.0.0.6
- Servo motors should work now

## 0.0.0.7
- Thread joins added

## 0.0.0.8
- Thread joins fixed :)

## 0.0.0.9
- Thread joins fixed 2 :)

## 0.0.1.1
- Library fully changed according to the new requirements

## 1.0.3.0
- Fully rewritten