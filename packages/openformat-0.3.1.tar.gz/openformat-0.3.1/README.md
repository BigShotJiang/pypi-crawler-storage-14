# Openformat: making data usable [![CI](https://github.com/tillahoffmann/openformat/actions/workflows/main.yml/badge.svg)](https://github.com/tillahoffmann/openformat/actions/workflows/main.yml)

Scientific equipment often produces output in binary formats that make it difficult to analyse the data without proprietary software. Openformat allows researchers to load binary data and analyse it in python.

## Supported formats

* Perkin Elmer spectra
* Multi-isotope imaging mass spectrometry (MIMS)
