import ssl


ssl_ctx1, ssl_ctx2 = ssl.SSLContext(), ssl.SSLContext()
