import hashlib


hashlib.md5()  # suppress: py004
