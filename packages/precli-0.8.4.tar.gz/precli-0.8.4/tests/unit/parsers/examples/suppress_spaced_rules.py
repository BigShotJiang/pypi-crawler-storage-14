import hashlib


hashlib.md5()  # suppress: PY003 PY004
