import hashlib


hashlib.md5()  # suppress: PY001, PY002, PY003, PY004, PY005
