import hashlib


hashlib.md5()  # suppress: PY004
