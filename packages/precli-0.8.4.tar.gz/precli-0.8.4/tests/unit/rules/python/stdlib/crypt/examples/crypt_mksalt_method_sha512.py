# level: NONE
import crypt


crypt.mksalt(crypt.METHOD_SHA512)
