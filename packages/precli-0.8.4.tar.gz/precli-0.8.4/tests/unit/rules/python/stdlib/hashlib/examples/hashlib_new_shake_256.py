# level: NONE
import hashlib


hashlib.new("shake_256")
