# level: NONE
import hashlib


hashlib.shake_128()
