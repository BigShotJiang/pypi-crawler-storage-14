# level: WARNING
# start_line: 9
# end_line: 9
# start_column: 0
# end_column: 12
import crypt


crypt.mksalt(crypt.METHOD_CRYPT)
