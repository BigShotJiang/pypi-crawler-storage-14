# level: NONE
import crypt


crypt.mksalt()
