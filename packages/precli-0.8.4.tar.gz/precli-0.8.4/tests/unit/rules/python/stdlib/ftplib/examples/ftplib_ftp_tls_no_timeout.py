# level: WARNING
# start_line: 9
# end_line: 9
# start_column: 27
# end_column: 46
import ftplib


ftp_server = ftplib.FTP_TLS("ftp.example.com")
