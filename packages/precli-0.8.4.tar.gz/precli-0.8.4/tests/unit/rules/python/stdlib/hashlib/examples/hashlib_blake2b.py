# level: NONE
import hashlib


hashlib.blake2b()
