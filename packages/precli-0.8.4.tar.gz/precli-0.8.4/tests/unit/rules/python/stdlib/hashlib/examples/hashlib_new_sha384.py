# level: NONE
import hashlib


hashlib.new("sha384")
