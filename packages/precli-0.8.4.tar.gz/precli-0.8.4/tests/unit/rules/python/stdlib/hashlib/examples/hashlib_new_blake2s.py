# level: NONE
import hashlib


hashlib.new("blake2s")
