# level: NONE
import crypt


crypt.crypt("asdfasdfasdfasdf")
