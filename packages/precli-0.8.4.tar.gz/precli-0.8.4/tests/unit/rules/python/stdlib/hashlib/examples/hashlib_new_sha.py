# level: ERROR
# start_line: 9
# end_line: 9
# start_column: 12
# end_column: 17
import hashlib


hashlib.new("sha")
