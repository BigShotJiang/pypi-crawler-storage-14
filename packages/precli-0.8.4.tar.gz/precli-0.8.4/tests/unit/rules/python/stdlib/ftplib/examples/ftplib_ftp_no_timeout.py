# level: WARNING
# start_line: 9
# end_line: 9
# start_column: 23
# end_column: 42
import ftplib


ftp_server = ftplib.FTP("ftp.example.com")
