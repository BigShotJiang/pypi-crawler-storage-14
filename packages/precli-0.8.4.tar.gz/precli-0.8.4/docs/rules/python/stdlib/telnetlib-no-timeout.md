---
id: PY044
title: telnetlib — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY044
---

::: precli.rules.python.stdlib.telnetlib_no_timeout
