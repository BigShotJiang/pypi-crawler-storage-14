---
id: PY033
title: re — denial of service
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY033
---

::: precli.rules.python.stdlib.re_denial_of_service
