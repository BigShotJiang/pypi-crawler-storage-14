---
id: PY024
title: nntplib — unverified context
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY024
---

::: precli.rules.python.stdlib.nntplib_unverified_context
