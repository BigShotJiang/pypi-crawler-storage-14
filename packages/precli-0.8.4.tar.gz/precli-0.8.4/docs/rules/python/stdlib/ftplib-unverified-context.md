---
id: PY022
title: ftplib — unverified context
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY022
---

::: precli.rules.python.stdlib.ftplib_unverified_context
