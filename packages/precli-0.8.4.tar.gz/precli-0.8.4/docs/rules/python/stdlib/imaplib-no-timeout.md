---
id: PY041
title: imaplib — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY041
---

::: precli.rules.python.stdlib.imaplib_no_timeout
