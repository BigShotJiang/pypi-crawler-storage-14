---
id: PY040
title: smtplib — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY040
---

::: precli.rules.python.stdlib.smtplib_no_timeout
