---
id: PY039
title: socket — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY039
---

::: precli.rules.python.stdlib.socket_no_timeout
