---
id: PY028
title: secrets — weak token
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY028
---

::: precli.rules.python.stdlib.secrets_weak_token
