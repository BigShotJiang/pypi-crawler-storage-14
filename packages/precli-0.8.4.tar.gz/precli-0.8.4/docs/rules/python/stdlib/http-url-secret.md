---
id: PY007
title: http — url secret
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY007
---

::: precli.rules.python.stdlib.http_url_secret
