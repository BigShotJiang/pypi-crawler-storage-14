---
id: PY008
title: imaplib — cleartext
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY008
---

::: precli.rules.python.stdlib.imaplib_cleartext
