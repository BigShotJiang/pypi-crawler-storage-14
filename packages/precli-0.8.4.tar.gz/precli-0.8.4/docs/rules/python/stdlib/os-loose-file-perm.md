---
id: PY036
title: os — incorrect permission
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY036
---

::: precli.rules.python.stdlib.os_loose_file_perm
