---
id: PY004
title: hashlib — weak hash
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY004
---

::: precli.rules.python.stdlib.hashlib_weak_hash
