---
id: PY025
title: poplib — unverified context
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY025
---

::: precli.rules.python.stdlib.poplib_unverified_context
