---
id: PY042
title: nntplib — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY042
---

::: precli.rules.python.stdlib.nntplib_no_timeout
