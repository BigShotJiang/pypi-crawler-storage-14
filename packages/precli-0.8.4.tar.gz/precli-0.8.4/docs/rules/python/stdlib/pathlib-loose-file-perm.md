---
id: PY037
title: pathlib — incorrect permission
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY037
---

::: precli.rules.python.stdlib.pathlib_loose_file_perm
