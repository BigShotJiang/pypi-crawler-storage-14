---
id: PY029
title: socket — unrestricted bind
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY029
---

::: precli.rules.python.stdlib.socket_unrestricted_bind
