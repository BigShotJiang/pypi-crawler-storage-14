---
id: PY012
title: nntplib — cleartext
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY012
---

::: precli.rules.python.stdlib.nntplib_cleartext
