---
id: PY020
title: telnetlib — cleartext
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY020
---

::: precli.rules.python.stdlib.telnetlib_cleartext
