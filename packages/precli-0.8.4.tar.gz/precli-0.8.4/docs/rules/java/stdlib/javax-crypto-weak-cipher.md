---
id: JAV001
title: javax.crypto — weak cipher
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/JAV001
---

::: precli.rules.java.stdlib.javax_crypto_weak_cipher
