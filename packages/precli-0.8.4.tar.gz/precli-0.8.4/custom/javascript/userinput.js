let userInput = prompt("Enter code:");
eval(userInput);
