import scala.concurrent.ExecutionContext

val ec = ExecutionContext.global
