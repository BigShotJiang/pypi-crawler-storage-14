# La Convertoche

> Le tableau de conversion de l'école primaire... dans ton terminal !

**La Convertoche** est un outil CLI qui reproduit le fameux tableau de conversion métrique que nous avons tous utilisé à l'école. Fini les calculs de tête pour savoir combien font 2,5 km en mètres - visualisez instantanément le placement des chiffres !

```
                           Longueurs
┌────────┬────────┬────────┬────────┬────────┬────────┬────────┐
│   km   │   hm   │  dam   │   m    │   dm   │   cm   │   mm   │
├────────┼────────┼────────┼────────┼────────┼────────┼────────┤
│        │   1    │   2,   │   5    │        │        │        │
└────────┴────────┴────────┴────────┴────────┴────────┴────────┘
```

## Fonctionnalités

- **Tableau visuel** : Placement automatique des chiffres comme à l'école
- **3 familles d'unités** : Longueurs, Poids, Capacités
- **Couleurs distinctives** : Bleu pour les longueurs, Vert pour les poids, Jaune pour les capacités
- **Input flexible** : Accepte les points (`.`) ET les virgules (`,`) pour les décimales
- **Conversions rapides** : Affiche automatiquement les équivalents métriques et impériaux
- **Mode interactif** : Boucle interactive avec historique et commandes
- **Mode Quiz** : Testez vos connaissances en conversion d'unités
- **Lecture stdin** : Intégration avec d'autres commandes via pipe
- **Export presse-papier** : Copiez le résultat directement
- **Tableau responsive** : S'adapte à la largeur de votre terminal
- **Avertissements de débordement** : Signale si la valeur dépasse le tableau

## Installation

### Via pip (recommandé)

```bash
git clone https://github.com/LuKrlier/La-Convertoche.git
cd La-Convertoche
pip install .
```

Après installation, la commande `convertoche` est disponible globalement.

### Installation développeur

```bash
git clone https://github.com/LuKrlier/La-Convertoche.git
cd La-Convertoche
pip install -e ".[dev]"
```

## Utilisation

### Mode ligne de commande

```bash
# Conversion simple
convertoche 12.5 m

# Avec virgule française
convertoche 1,5 kg

# Conversion vers une unité cible
convertoche 2.5 km --to m

# Capacités
convertoche 250 mL
```

### Mode interactif

Lancez simplement sans arguments :

```bash
convertoche
```

Le mode interactif propose une boucle avec commandes :
- `quit` ou `q` : Quitter
- `history` ou `h` : Afficher l'historique des conversions
- `list` ou `l` : Lister les unités disponibles
- `help` ou `?` : Afficher l'aide

### Mode Quiz

Testez vos connaissances :

```bash
# Quiz de 5 questions (par défaut)
convertoche --quiz

# Quiz personnalisé (10 questions)
convertoche --quiz 10
```

### Autres options

```bash
# Afficher les unités disponibles
convertoche --list

# Afficher la version
convertoche --version

# Copier le résultat dans le presse-papier
convertoche 12.5 m --copy

# Lire la valeur depuis stdin
echo 12.5 | convertoche --read m

# Combiner les options
echo 2.5 | convertoche --read km --to m --copy
```

## Unités supportées

| Famille    | Unités                           | Couleur |
|------------|----------------------------------|---------|
| Longueurs  | km, hm, dam, m, dm, cm, mm       | Bleu    |
| Poids      | kg, hg, dag, g, dg, cg, mg       | Vert    |
| Capacités  | kL, hL, daL, L, dL, cL, mL       | Jaune   |

## Exemples

### Exemple 1 : Longueur

```bash
$ convertoche 12.5 dam
```

Affiche :
- Le tableau avec `1` sous `hm`, `2` sous `dam`, `5` sous `m`
- Conversion : 125 m
- Conversions impériales : ~410.1 feet, ~4921.3 inches

### Exemple 2 : Poids avec conversion ciblée

```bash
$ convertoche 3,75 kg --to g
```

Affiche :
- Le tableau de conversion
- Résultat : 3 750 g

### Exemple 3 : Capacité

```bash
$ convertoche 500 mL
```

Affiche :
- Le tableau avec `5` sous `dL`, `0` sous `cL`, `0` sous `mL`
- Conversion : 0,5 L
- Conversions impériales : ~0,132 gallon (US)

## Comment fonctionne le tableau ?

Le principe est simple et reproduit exactement la méthode scolaire :

1. **Le chiffre des unités** (celui juste avant la virgule) est placé dans la colonne de l'unité source
2. **Les chiffres à gauche** remontent vers les unités plus grandes
3. **Les chiffres après la virgule** descendent vers les unités plus petites

Exemple avec `12,5 m` :
- Le `2` (unités) va sous `m`
- Le `1` (dizaines) va sous `dam`
- Le `5` (dixièmes) va sous `dm`

Pour lire la valeur dans une autre unité, il suffit de placer mentalement la virgule après la colonne souhaitée !

## Gestion des erreurs

- **Valeurs négatives** : Rejetées (les unités physiques sont positives)
- **Unités inconnues** : Message d'erreur clair avec suggestion d'utiliser `--list`
- **Conversion entre familles** : Impossible de convertir des mètres en grammes
- **Débordement** : Avertissement si la valeur dépasse les limites du tableau

## Structure du projet

```
La-Convertoche/
├── main.py              # Script principal
├── pyproject.toml       # Configuration du package
├── requirements.txt     # Dépendances
├── LICENSE              # Licence MIT
├── README.md            # Documentation
└── tests/               # Tests unitaires
    ├── conftest.py
    ├── test_parsing.py
    ├── test_unit_detection.py
    ├── test_conversion.py
    ├── test_digit_placement.py
    ├── test_formatting.py
    ├── test_overflow.py
    ├── test_cli.py
    ├── test_history.py
    ├── test_clipboard.py
    └── test_quiz.py
```

## Tests

```bash
# Exécuter tous les tests
pytest

# Avec couverture
pytest --cov=main

# Tests verbeux
pytest -v
```

## Dépendances

- [Rich](https://github.com/Textualize/rich) : Pour le rendu coloré dans le terminal
- [pyperclip](https://github.com/asweigart/pyperclip) (optionnel) : Pour l'export presse-papier

## Licence

MIT - Voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

*Fait avec nostalgie des cours de maths de CM2.*
