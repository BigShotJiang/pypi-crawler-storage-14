"""
Tests pour les fonctions de détection et gestion des unités.
"""

import pytest

from main import find_unit_family, get_unit_index, normalize_unit, UNIT_FAMILIES


class TestFindUnitFamily:
    """Tests de détection de famille d'unités."""

    def test_unite_longueur(self):
        """2.1 - Détecte une unité de longueur."""
        result = find_unit_family("m")
        assert result is not None
        assert result[0] == "longueur"

    def test_unite_poids(self):
        """2.2 - Détecte une unité de poids."""
        result = find_unit_family("kg")
        assert result is not None
        assert result[0] == "poids"

    def test_unite_capacite(self):
        """2.3 - Détecte une unité de capacité."""
        result = find_unit_family("L")
        assert result is not None
        assert result[0] == "capacite"

    def test_casse_insensible_minuscule(self):
        """2.4 - Casse insensible (minuscule)."""
        result = find_unit_family("km")
        assert result is not None
        assert result[0] == "longueur"

    def test_casse_insensible_majuscule(self):
        """2.5 - Casse insensible (majuscule)."""
        result = find_unit_family("KM")
        assert result is not None
        assert result[0] == "longueur"

    def test_litre_majuscule(self):
        """2.6 - Litre en majuscule."""
        result = find_unit_family("L")
        assert result is not None
        assert result[0] == "capacite"

    def test_litre_minuscule(self):
        """2.7 - Litre en minuscule."""
        result = find_unit_family("l")
        assert result is not None
        assert result[0] == "capacite"

    def test_unite_inconnue(self):
        """2.8 - Retourne None pour unité inconnue."""
        assert find_unit_family("xyz") is None

    def test_chaine_vide(self):
        """2.9 - Retourne None pour chaîne vide."""
        assert find_unit_family("") is None


class TestGetUnitIndex:
    """Tests d'index d'unité dans sa famille."""

    def test_premiere_unite_km(self):
        """3.1 - Index de km (première unité)."""
        family_config = UNIT_FAMILIES["longueur"]
        assert get_unit_index("km", family_config) == 0

    def test_unite_base_m(self):
        """3.2 - Index de m (unité de base)."""
        family_config = UNIT_FAMILIES["longueur"]
        assert get_unit_index("m", family_config) == 3

    def test_derniere_unite_mm(self):
        """3.3 - Index de mm (dernière unité)."""
        family_config = UNIT_FAMILIES["longueur"]
        assert get_unit_index("mm", family_config) == 6

    def test_casse_mixte(self):
        """3.4 - Casse mixte acceptée."""
        family_config = UNIT_FAMILIES["longueur"]
        assert get_unit_index("Km", family_config) == 0


class TestNormalizeUnit:
    """Tests de normalisation des unités."""

    def test_minuscule_vers_correct(self):
        """10.1 - Normalise minuscule."""
        family_config = UNIT_FAMILIES["longueur"]
        assert normalize_unit("km", family_config) == "km"

    def test_majuscule_vers_correct(self):
        """10.2 - Normalise majuscule vers minuscule."""
        family_config = UNIT_FAMILIES["longueur"]
        assert normalize_unit("KM", family_config) == "km"

    def test_litre_minuscule(self):
        """10.3 - Normalise litre minuscule vers majuscule."""
        family_config = UNIT_FAMILIES["capacite"]
        assert normalize_unit("l", family_config) == "L"

    def test_litre_majuscule(self):
        """10.4 - Litre majuscule reste majuscule."""
        family_config = UNIT_FAMILIES["capacite"]
        assert normalize_unit("L", family_config) == "L"

    def test_dal_mixte(self):
        """10.5 - Normalise daL mixte."""
        family_config = UNIT_FAMILIES["capacite"]
        assert normalize_unit("dal", family_config) == "daL"
