"""
Tests pour les fonctions de conversion.
"""

import pytest
from decimal import Decimal

from main import convert_to_base, convert_between_units, UNIT_FAMILIES


class TestConvertToBase:
    """Tests de conversion vers l'unité de base."""

    def test_km_vers_m(self):
        """4.1 - Convertit km vers m."""
        family_config = UNIT_FAMILIES["longueur"]
        result = convert_to_base(Decimal("1"), "km", family_config)
        assert result == Decimal("1000")

    def test_mm_vers_m(self):
        """4.2 - Convertit mm vers m."""
        family_config = UNIT_FAMILIES["longueur"]
        result = convert_to_base(Decimal("1000"), "mm", family_config)
        assert result == Decimal("1")

    def test_m_vers_m_identite(self):
        """4.3 - m vers m (identité)."""
        family_config = UNIT_FAMILIES["longueur"]
        result = convert_to_base(Decimal("5"), "m", family_config)
        assert result == Decimal("5")

    def test_kg_vers_g(self):
        """4.4 - Convertit kg vers g."""
        family_config = UNIT_FAMILIES["poids"]
        result = convert_to_base(Decimal("2.5"), "kg", family_config)
        assert result == Decimal("2500")

    def test_mg_vers_g(self):
        """4.5 - Convertit mg vers g."""
        family_config = UNIT_FAMILIES["poids"]
        result = convert_to_base(Decimal("500"), "mg", family_config)
        assert result == Decimal("0.5")

    def test_l_vers_l_identite(self):
        """4.6 - L vers L (identité)."""
        family_config = UNIT_FAMILIES["capacite"]
        result = convert_to_base(Decimal("1"), "L", family_config)
        assert result == Decimal("1")

    def test_ml_vers_l(self):
        """4.7 - Convertit mL vers L."""
        family_config = UNIT_FAMILIES["capacite"]
        result = convert_to_base(Decimal("250"), "mL", family_config)
        assert result == Decimal("0.25")

    def test_hl_vers_l(self):
        """4.8 - Convertit hL vers L."""
        family_config = UNIT_FAMILIES["capacite"]
        result = convert_to_base(Decimal("1"), "hL", family_config)
        assert result == Decimal("100")


class TestConvertBetweenUnits:
    """Tests de conversion entre unités de la même famille."""

    def test_km_vers_m(self):
        """5.1 - Convertit km vers m."""
        family_config = UNIT_FAMILIES["longueur"]
        result = convert_between_units(Decimal("2.5"), "km", "m", family_config)
        assert result == Decimal("2500")

    def test_m_vers_km(self):
        """5.2 - Convertit m vers km."""
        family_config = UNIT_FAMILIES["longueur"]
        result = convert_between_units(Decimal("2500"), "m", "km", family_config)
        assert result == Decimal("2.5")

    def test_cm_vers_mm(self):
        """5.3 - Convertit cm vers mm."""
        family_config = UNIT_FAMILIES["longueur"]
        result = convert_between_units(Decimal("10"), "cm", "mm", family_config)
        assert result == Decimal("100")

    def test_g_vers_kg(self):
        """5.4 - Convertit g vers kg."""
        family_config = UNIT_FAMILIES["poids"]
        result = convert_between_units(Decimal("1500"), "g", "kg", family_config)
        assert result == Decimal("1.5")

    def test_ml_vers_l(self):
        """5.5 - Convertit mL vers L."""
        family_config = UNIT_FAMILIES["capacite"]
        result = convert_between_units(Decimal("500"), "mL", "L", family_config)
        assert result == Decimal("0.5")

    def test_meme_unite(self):
        """5.6 - Même unité (identité)."""
        family_config = UNIT_FAMILIES["longueur"]
        result = convert_between_units(Decimal("5"), "m", "m", family_config)
        assert result == Decimal("5")
