"""
Tests pour l'historique des conversions.
"""

import pytest
from decimal import Decimal

from main import add_to_history, conversion_history


class TestHistorique:
    """Tests de l'historique des conversions."""

    def setup_method(self):
        """Vide l'historique avant chaque test."""
        conversion_history.clear()

    def test_ajout_historique_simple(self):
        """Ajoute une entrée simple à l'historique."""
        add_to_history(Decimal("12.5"), "m")
        assert len(conversion_history) == 1
        assert conversion_history[0]["value"] == Decimal("12.5")
        assert conversion_history[0]["unit"] == "m"
        assert conversion_history[0]["target_unit"] is None

    def test_ajout_historique_avec_target(self):
        """Ajoute une entrée avec unité cible."""
        add_to_history(Decimal("2.5"), "km", "m")
        assert len(conversion_history) == 1
        assert conversion_history[0]["value"] == Decimal("2.5")
        assert conversion_history[0]["unit"] == "km"
        assert conversion_history[0]["target_unit"] == "m"

    def test_historique_multiple(self):
        """Plusieurs entrées dans l'historique."""
        add_to_history(Decimal("10"), "m")
        add_to_history(Decimal("5"), "kg")
        add_to_history(Decimal("2"), "L")
        assert len(conversion_history) == 3

    def test_historique_ordre_chronologique(self):
        """L'historique conserve l'ordre d'ajout."""
        add_to_history(Decimal("1"), "m")
        add_to_history(Decimal("2"), "kg")
        add_to_history(Decimal("3"), "L")
        assert conversion_history[0]["value"] == Decimal("1")
        assert conversion_history[1]["value"] == Decimal("2")
        assert conversion_history[2]["value"] == Decimal("3")

    def test_historique_vide_initialement(self):
        """L'historique est vide après clear."""
        assert len(conversion_history) == 0

    def test_historique_contient_toutes_familles(self):
        """L'historique peut contenir des conversions de toutes les familles."""
        add_to_history(Decimal("10"), "m")      # longueur
        add_to_history(Decimal("5"), "kg")      # poids
        add_to_history(Decimal("2"), "L")       # capacité

        assert conversion_history[0]["unit"] == "m"
        assert conversion_history[1]["unit"] == "kg"
        assert conversion_history[2]["unit"] == "L"
