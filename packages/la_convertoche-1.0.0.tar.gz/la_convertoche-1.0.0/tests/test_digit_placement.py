"""
Tests pour la fonction build_digit_placement.
"""

import pytest
from decimal import Decimal

from main import build_digit_placement, UNIT_FAMILIES


class TestBuildDigitPlacement:
    """Tests de placement des chiffres dans le tableau."""

    def test_entier_simple(self):
        """6.1 - Placement d'un entier simple."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("12"), "m", family_config
        )
        assert placement == ["", "", "1", "2", "", "", ""]
        assert not overflow_left
        assert not overflow_right

    def test_avec_decimale(self):
        """6.2 - Placement avec décimale."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("12.5"), "m", family_config
        )
        assert placement == ["", "", "1", "2", "5", "", ""]
        assert not overflow_left
        assert not overflow_right

    def test_unite_km(self):
        """6.3 - Placement avec unité km."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("2.5"), "km", family_config
        )
        assert placement == ["2", "5", "", "", "", "", ""]
        assert not overflow_left
        assert not overflow_right

    def test_unite_mm(self):
        """6.4 - Placement avec unité mm."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("125"), "mm", family_config
        )
        assert placement == ["", "", "", "", "1", "2", "5"]
        assert not overflow_left
        assert not overflow_right

    def test_debordement_gauche(self):
        """6.5 - Détecte débordement à gauche."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("12345678"), "m", family_config
        )
        # Seuls les 4 derniers chiffres sont visibles (5678 -> positions 0-3)
        assert placement == ["5", "6", "7", "8", "", "", ""]
        assert overflow_left
        assert not overflow_right

    def test_debordement_droite(self):
        """6.6 - Détecte débordement à droite."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("1.2345678"), "km", family_config
        )
        # Décimales tronquées après position 6
        assert placement == ["1", "2", "3", "4", "5", "6", "7"]
        assert not overflow_left
        assert overflow_right

    def test_zero(self):
        """6.7 - Placement de zéro."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("0"), "m", family_config
        )
        assert placement == ["", "", "", "0", "", "", ""]
        assert not overflow_left
        assert not overflow_right

    def test_petit_decimal(self):
        """6.8 - Placement d'un petit décimal."""
        family_config = UNIT_FAMILIES["longueur"]
        placement, overflow_left, overflow_right = build_digit_placement(
            Decimal("0.5"), "m", family_config
        )
        assert placement == ["", "", "", "0", "5", "", ""]
        assert not overflow_left
        assert not overflow_right
