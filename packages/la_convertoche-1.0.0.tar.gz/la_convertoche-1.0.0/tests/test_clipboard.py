"""
Tests pour le presse-papier (stockage du dernier résultat).
"""

import pytest
from decimal import Decimal

import main
from main import set_last_result, UNIT_FAMILIES


class TestSetLastResult:
    """Tests du stockage du dernier résultat pour presse-papier."""

    def test_resultat_simple_longueur(self):
        """Stocke un résultat simple en longueur."""
        family_config = UNIT_FAMILIES["longueur"]
        set_last_result(Decimal("12.5"), "m", None, family_config)
        assert main.last_result == "12,5 m"

    def test_resultat_avec_conversion(self):
        """Stocke un résultat avec conversion."""
        family_config = UNIT_FAMILIES["longueur"]
        set_last_result(Decimal("2.5"), "km", "m", family_config)
        assert main.last_result == "2 500 m"

    def test_resultat_poids(self):
        """Stocke un résultat de poids."""
        family_config = UNIT_FAMILIES["poids"]
        set_last_result(Decimal("1.5"), "kg", "g", family_config)
        assert main.last_result == "1 500 g"

    def test_resultat_capacite(self):
        """Stocke un résultat de capacité."""
        family_config = UNIT_FAMILIES["capacite"]
        set_last_result(Decimal("0.5"), "L", None, family_config)
        assert main.last_result == "0,5 L"

    def test_resultat_entier(self):
        """Stocke un résultat entier."""
        family_config = UNIT_FAMILIES["longueur"]
        set_last_result(Decimal("100"), "m", None, family_config)
        assert main.last_result == "100 m"

    def test_resultat_conversion_inverse(self):
        """Stocke une conversion vers unité plus grande."""
        family_config = UNIT_FAMILIES["longueur"]
        set_last_result(Decimal("1000"), "m", "km", family_config)
        assert main.last_result == "1 km"

    def test_resultat_petit_decimal(self):
        """Stocke un petit décimal."""
        family_config = UNIT_FAMILIES["capacite"]
        set_last_result(Decimal("0.25"), "L", None, family_config)
        assert main.last_result == "0,25 L"
