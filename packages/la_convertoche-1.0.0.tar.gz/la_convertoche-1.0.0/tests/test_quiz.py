"""
Tests pour le mode quiz.
"""

import pytest
from decimal import Decimal

from main import generate_quiz_question, convert_between_units, UNIT_FAMILIES


class TestGenerateQuizQuestion:
    """Tests de la génération de questions quiz."""

    def test_question_retourne_tuple(self):
        """Génère un tuple de 4 éléments."""
        result = generate_quiz_question()
        assert isinstance(result, tuple)
        assert len(result) == 4

    def test_question_valeur_decimal(self):
        """La valeur générée est un Decimal positif."""
        value, _, _, _ = generate_quiz_question()
        assert isinstance(value, Decimal)
        assert value > 0

    def test_question_unites_differentes(self):
        """Les unités source et cible sont différentes."""
        _, source_unit, target_unit, _ = generate_quiz_question()
        assert source_unit != target_unit

    def test_question_unites_meme_famille(self):
        """Les unités appartiennent à la même famille."""
        for _ in range(10):
            _, source_unit, target_unit, _ = generate_quiz_question()

            source_family = None
            target_family = None
            for family_name, family_config in UNIT_FAMILIES.items():
                units_lower = [u.lower() for u in family_config["units"]]
                if source_unit.lower() in units_lower:
                    source_family = family_name
                if target_unit.lower() in units_lower:
                    target_family = family_name

            assert source_family is not None
            assert target_family is not None
            assert source_family == target_family

    def test_question_reponse_decimal(self):
        """La réponse est un Decimal."""
        _, _, _, answer = generate_quiz_question()
        assert isinstance(answer, Decimal)

    def test_question_unites_valides(self):
        """Les unités générées sont des unités connues."""
        all_units = []
        for family_config in UNIT_FAMILIES.values():
            all_units.extend([u.lower() for u in family_config["units"]])

        for _ in range(10):
            _, source_unit, target_unit, _ = generate_quiz_question()
            assert source_unit.lower() in all_units
            assert target_unit.lower() in all_units

    def test_question_reponse_correcte(self):
        """La réponse générée est mathématiquement correcte."""
        for _ in range(10):
            value, source_unit, target_unit, answer = generate_quiz_question()

            for family_config in UNIT_FAMILIES.values():
                units_lower = [u.lower() for u in family_config["units"]]
                if source_unit.lower() in units_lower:
                    expected = convert_between_units(value, source_unit, target_unit, family_config)
                    assert answer == expected
                    break

    def test_question_valeurs_raisonnables(self):
        """Les valeurs générées sont raisonnables (entre 0.1 et 100)."""
        for _ in range(20):
            value, _, _, _ = generate_quiz_question()
            assert Decimal("0.1") <= value <= Decimal("100")

    def test_question_variete_familles(self):
        """Les questions couvrent différentes familles sur plusieurs générations."""
        familles_vues = set()

        for _ in range(50):
            _, source_unit, _, _ = generate_quiz_question()

            for family_name, family_config in UNIT_FAMILIES.items():
                units_lower = [u.lower() for u in family_config["units"]]
                if source_unit.lower() in units_lower:
                    familles_vues.add(family_name)
                    break

        # Sur 50 générations, on devrait voir au moins 2 familles différentes
        assert len(familles_vues) >= 2
