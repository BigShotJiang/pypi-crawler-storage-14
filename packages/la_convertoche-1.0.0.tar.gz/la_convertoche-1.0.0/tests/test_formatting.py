"""
Tests pour le formatage et l'affichage.
- Formatage des nombres en notation française
- Tableau responsive
"""

import pytest
from decimal import Decimal
from unittest.mock import patch

from main import format_number_fr, get_responsive_column_width, console


class TestFormatNumberFr:
    """Tests de formatage des nombres en notation française."""

    def test_entier_simple(self):
        """7.1 - Formate un entier simple."""
        assert format_number_fr(42) == "42"

    def test_decimal(self):
        """7.2 - Formate un décimal avec virgule."""
        assert format_number_fr(12.5) == "12,5"

    def test_milliers(self):
        """7.3 - Formate avec séparateur de milliers."""
        assert format_number_fr(1500) == "1 500"

    def test_millions(self):
        """7.4 - Formate des millions."""
        assert format_number_fr(1234567) == "1 234 567"

    def test_sans_separateur_milliers(self):
        """7.5 - Sans séparateur de milliers."""
        assert format_number_fr(1500, use_thousands_sep=False) == "1500"

    def test_petit_decimal(self):
        """7.6 - Formate un petit décimal."""
        assert format_number_fr(0.5) == "0,5"

    def test_nombre_inferieur_1000(self):
        """7.7 - Nombre < 1000 sans séparateur."""
        assert format_number_fr(999) == "999"

    def test_decimal_type(self):
        """Test avec type Decimal."""
        # Le formatage utilise des chiffres significatifs, donc arrondi possible
        result = format_number_fr(Decimal("1234.56"), decimals=6)
        assert result == "1 234,56"

    def test_grand_decimal(self):
        """Test grand nombre avec décimales."""
        # Le formatage g arrondit à 6 chiffres significatifs par défaut
        result = format_number_fr(12345.67, decimals=7)
        assert result == "12 345,67"


class TestResponsiveTable:
    """Tests du tableau responsive."""

    def test_largeur_calculee_valide(self):
        """La largeur calculée est entre 3 et 6."""
        width = get_responsive_column_width()
        assert 3 <= width <= 6

    def test_terminal_etroit(self):
        """Terminal étroit (40 colonnes) → largeur minimale."""
        # Test la logique du calcul directement
        terminal_width = 40
        available_width = terminal_width - 28
        col_width = max(3, min(6, available_width // 7))
        assert col_width == 3

    def test_terminal_large(self):
        """Terminal large (120 colonnes) → largeur maximale."""
        terminal_width = 120
        available_width = terminal_width - 28
        col_width = max(3, min(6, available_width // 7))
        assert col_width == 6

    def test_terminal_moyen(self):
        """Terminal moyen (80 colonnes) → largeur intermédiaire."""
        terminal_width = 80
        available_width = terminal_width - 28
        col_width = max(3, min(6, available_width // 7))
        assert 3 <= col_width <= 6
