"""
Tests pour la fonction parse_value.
"""

import pytest
from decimal import Decimal

from main import parse_value


class TestParseValue:
    """Tests de parsing des valeurs numériques."""

    def test_entier_simple(self):
        """1.1 - Parse un entier simple."""
        assert parse_value("42") == Decimal("42")

    def test_decimal_avec_point(self):
        """1.2 - Parse un décimal avec point."""
        assert parse_value("12.5") == Decimal("12.5")

    def test_decimal_avec_virgule(self):
        """1.3 - Parse un décimal avec virgule française."""
        assert parse_value("12,5") == Decimal("12.5")

    def test_espaces_autour(self):
        """1.4 - Parse avec espaces autour."""
        assert parse_value("  12.5  ") == Decimal("12.5")

    def test_zero(self):
        """1.5 - Parse zéro."""
        assert parse_value("0") == Decimal("0")

    def test_tres_petit_nombre(self):
        """1.6 - Parse un très petit nombre."""
        assert parse_value("0.0001") == Decimal("0.0001")

    def test_tres_grand_nombre(self):
        """1.7 - Parse un très grand nombre."""
        assert parse_value("999999999") == Decimal("999999999")

    def test_valeur_negative_rejet(self):
        """1.8 - Rejette une valeur négative par défaut."""
        with pytest.raises(ValueError, match="négatives"):
            parse_value("-5")

    def test_valeur_negative_autorisee(self):
        """1.9 - Accepte une valeur négative si autorisée."""
        assert parse_value("-5", allow_negative=True) == Decimal("-5")

    def test_texte_invalide(self):
        """1.10 - Rejette du texte invalide."""
        with pytest.raises(ValueError, match="pas un nombre valide"):
            parse_value("abc")

    def test_chaine_vide(self):
        """1.11 - Rejette une chaîne vide."""
        with pytest.raises(ValueError):
            parse_value("")

    def test_double_virgule(self):
        """1.12 - Rejette une double virgule."""
        with pytest.raises(ValueError):
            parse_value("12,,5")
