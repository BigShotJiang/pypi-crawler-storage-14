"""
Tests pour la détection de débordement et les warnings.
"""

import pytest
import subprocess
import sys
from pathlib import Path
from decimal import Decimal

from main import build_digit_placement, find_decimal_position, UNIT_FAMILIES

MAIN_PY = Path(__file__).parent.parent / "main.py"


def run_cli(*args):
    """Exécute main.py avec les arguments donnés."""
    result = subprocess.run(
        [sys.executable, str(MAIN_PY)] + list(args),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    return result


class TestOverflowDetection:
    """Tests de détection de débordement."""

    def test_pas_de_debordement(self):
        """9.1 - Pas de débordement pour valeur normale."""
        family_config = UNIT_FAMILIES["longueur"]
        _, overflow_left, overflow_right = build_digit_placement(
            Decimal("12.5"), "m", family_config
        )
        assert not overflow_left
        assert not overflow_right

    def test_debordement_gauche(self):
        """9.2 - Détecte débordement à gauche."""
        family_config = UNIT_FAMILIES["longueur"]
        _, overflow_left, overflow_right = build_digit_placement(
            Decimal("12345678"), "m", family_config
        )
        assert overflow_left
        assert not overflow_right

    def test_debordement_droite(self):
        """9.3 - Détecte débordement à droite."""
        family_config = UNIT_FAMILIES["longueur"]
        _, overflow_left, overflow_right = build_digit_placement(
            Decimal("1.23456789"), "km", family_config
        )
        assert not overflow_left
        assert overflow_right

    def test_double_debordement(self):
        """9.4 - Détecte double débordement."""
        family_config = UNIT_FAMILIES["longueur"]
        _, overflow_left, overflow_right = build_digit_placement(
            Decimal("12345678.123456789"), "m", family_config
        )
        assert overflow_left
        assert overflow_right


class TestOverflowWarningsCLI:
    """Tests des warnings de débordement via CLI."""

    def test_warning_debordement_gauche(self):
        """Warning affiché pour débordement gauche."""
        result = run_cli("12345678", "m")
        assert "Attention" in result.stdout
        assert "entière" in result.stdout

    def test_warning_debordement_droite(self):
        """Warning affiché pour débordement droite."""
        result = run_cli("1.23456789", "km")
        assert "Attention" in result.stdout
        assert "décimale" in result.stdout

    def test_pas_de_warning_valeur_normale(self):
        """Pas de warning pour valeur normale."""
        result = run_cli("12.5", "m")
        assert "Attention" not in result.stdout


class TestFindDecimalPosition:
    """Tests de la position de la virgule."""

    def test_entier_pas_de_virgule(self):
        """Entier → pas de position de virgule."""
        assert find_decimal_position(3, Decimal("12")) == -1

    def test_decimal_position_correcte(self):
        """Décimal → position à l'unité."""
        assert find_decimal_position(3, Decimal("12.5")) == 3

    def test_decimal_position_km(self):
        """Décimal en km → position 0."""
        assert find_decimal_position(0, Decimal("2.5")) == 0
