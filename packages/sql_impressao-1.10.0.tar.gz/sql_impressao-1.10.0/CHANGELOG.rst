=========
Changelog
=========

1.10.0 (2025-11-27)
-------------------

* Drop Python 3.9 support.

* Provide Python 3.14 wheels for all platforms.

1.9.0 (2025-09-09)
------------------

* Support Python 3.14.

1.8.0 (2025-07-31)
------------------

* Update to sql-fingerprint 1.9.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.7.0 (2025-07-05)
------------------

* Update to sql-fingerprint 1.8.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.6.0 (2025-06-26)
------------------

* Update to sql-fingerprint 1.7.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.5.0 (2025-06-26)
------------------

* Update to sql-fingerprint 1.6.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.4.0 (2025-04-28)
------------------

* Update to sql-fingerprint 1.5.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.3.0 (2025-04-15)
------------------

* Update to sql-fingerprint 1.4.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.2.0 (2025-04-04)
------------------

* Update to sql-fingerprint 1.3.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.1.0 (2025-04-03)
------------------

* Update to sql-fingerprint 1.2.0 (`changelog <https://github.com/adamchainz/sql-fingerprint/blob/main/CHANGELOG.rst>`__).

1.0.0 (2025-04-03)
------------------

* First release on PyPI.
