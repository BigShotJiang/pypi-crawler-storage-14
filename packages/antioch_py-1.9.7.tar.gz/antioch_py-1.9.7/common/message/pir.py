from pydantic import Field

from common.message.base import Message


class PirStatus(Message):
    """
    PIR sensor status containing detection state and signal information.
    """

    _type = "antioch/pir_status"
    is_detected: bool = Field(description="Whether motion is currently detected")
    signal_strength: float = Field(description="Current analog signal value after filtering")
    threshold: float = Field(description="Current detection threshold")
    element_power: list[float] = Field(default_factory=list, description="Power received on each sensing element")
