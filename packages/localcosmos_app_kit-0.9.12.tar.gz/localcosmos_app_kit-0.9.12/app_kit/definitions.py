TEXT_LENGTH_RESTRICTIONS = {
    'GenericContent' : {
        'name' : 40
    }
}
