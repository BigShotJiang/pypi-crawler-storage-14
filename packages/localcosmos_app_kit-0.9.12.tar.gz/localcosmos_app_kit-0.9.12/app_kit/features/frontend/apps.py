from django.apps import AppConfig


class FrontendConfig(AppConfig):
    name = 'app_kit.features.frontend'
