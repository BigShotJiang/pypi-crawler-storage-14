from django.apps import AppConfig


class BackbonetaxonomyConfig(AppConfig):
    name = 'app_kit.features.backbonetaxonomy'
