<p align="center">
  <img src="docs/assets/logo-gh.png" alt="JaxLatt Logo" width="600"/>
</p>

[![image](https://img.shields.io/pypi/v/jaxlatt.svg)](https://pypi.python.org/pypi/jaxlatt)
[![image](https://img.shields.io/badge/arXiv-260X.0XXXX%20-red.svg)](https://arxiv.org/abs/260X.0XXXX)
[![image](http://img.shields.io/badge/license-MIT-blue.svg?style=flat)](https://github.com/rcalderonb6/JaxLatt/blob/main/LICENSE) 

`JaxLatt` is a high-performance lattice field theory simulation library built on JAX, designed for researchers in cosmology and high-energy physics. It provides efficient implementations of scalar and gauge field dynamics on discrete lattices, leveraging JAX's automatic differentiation and GPU acceleration capabilities.

## Example: Scalar Field Evolution in 2D

Let's consider the simple example of a 2D scalar field evolving under a double-well potential:

$\mathcal{L} = \frac{1}{2} \partial_\mu \varphi \partial^\mu \varphi - V(\varphi)$ , where $V(\varphi)= -\frac12\mu ^2 \varphi ^2 + \frac{\lambda}{4} \varphi ^4$

<p align="center">
  <!-- <img src="examples/animations/field_2d_evolution.gif" alt="2D Field Evolution" width="600"/> -->
  <img src="examples/animations/dark_phase_transition_field_higgs2d.gif" alt="2D Field Evolution" width="600"/>
</p>

This animation shows the evolution of a 2D scalar field undergoing a phase transition, visualized as a heatmap. The simulation captures domain formation and topological defects, demonstrating JaxLatt's capabilities in handling complex field dynamics efficiently.