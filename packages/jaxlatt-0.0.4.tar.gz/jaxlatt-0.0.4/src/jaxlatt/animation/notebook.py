def to_nb(anim_object):
    from IPython.display import HTML

    # Display in notebook (requires JavaScript)
    return HTML(anim_object.to_jshtml())
