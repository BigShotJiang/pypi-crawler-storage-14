"""
Animation utilities for visualizing lattice field evolution.

This package provides tools to create animations of scalar field dynamics
across different dimensionalities (1D, 2D, 3D), phase space visualizations,
and comparison plots.

Functions are organized by category:
- 1d: 1D field animations and phase space
- 2d: 2D field animations and phase portraits
- 3d: 3D slice and isosurface animations
- comparison: Side-by-side and dimensional comparisons
"""

from .dim1 import field as field_1d
from .dim1 import phase_space as phase_space_1d
from .dim2 import field as field_2d
from .dim3 import slices as slices_3d
from .dim3 import field as field_3d
from .notebook import to_nb


from .comparison import (
    create_comparison_animation,
    animate_multi_snapshot_grid,
)

__all__ = [
    # 1D animations
    "field_1d",
    "phase_space_1d",
    # 2D animations
    "field_2d",
    # 3D animations
    "slices_3d",
    "field_3d",
    # Comparisons
    "create_comparison_animation",
    "animate_multi_snapshot_grid",
    # notebook
    "to_nb",
]
