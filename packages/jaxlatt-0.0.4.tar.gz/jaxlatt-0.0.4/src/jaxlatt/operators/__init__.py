"""
Operators module for lattice field theory.

Provides organized operators for:
- Stencil operators (stencil.py) - Finite-difference derivatives (any dimension)
- Pure scalar fields (scalar.py)
- Pure gauge fields (gauge.py)
- Coupled scalar-gauge fields (coupled.py)
- Spectral methods (spectral.py) - FFT-based derivatives
- Autodiff methods (autodiff.py) - JAX automatic differentiation
"""

# Stencil operators (finite-difference, any dimension)
from .stencil import (
    laplacian as stencil_laplacian,
    gradient_squared as stencil_gradient_squared,
    gradient as stencil_gradient,
    divergence as stencil_divergence,
    forward_gradient,
    backward_gradient,
)

# Spectral operators (FFT-based)
from .spectral import (
    laplacian,
    laplacian_1d,
    laplacian_2d,
    laplacian_3d,
    gradient_1d,
    gradient_2d,
    gradient_3d,
    gradient_energy,
    gradient_energy_1d,
    gradient_energy_2d,
    gradient_energy_3d,
)

# Scalar operators
from .scalar import (
    scalar_laplacian,
    gradient_squared,
    scalar_potential_energy,
    scalar_potential_force,
    scalar_kinetic_energy_density,
)

# Gauge operators
from .gauge import (
    plaquette,
    all_plaquettes,
    magnetic_field,
    staple,
    all_staples,
    gauge_force,
    magnetic_energy_density,
    electric_energy_density,
    divergence_3d,
    gauss_constraint,
    gauss_violation_norm,
    gauge_energy,
    evolve_links_half_step,
    evolve_links_full_step,
)

# Coupled operators
from .coupled import (
    covariant_derivative,
    covariant_gradient_squared,
    covariant_laplacian,
    scalar_force,
    scalar_charge_density,
    scalar_current_density,
    gauss_constraint_with_source,
    gauss_violation_norm_with_source,
    coupled_energy,
    scalar_potential,  # backward compatibility alias for scalar_potential_energy
)

# Force operators (unified autodiff-based forces)
from .forces import (
    make_scalar_force,
    make_coupled_scalar_force,
    make_coupled_scalar_force_expanding,
    make_rescaled_scalar_force,
    make_gauge_force,
    make_gauge_force_expanding,
    make_forces_from_hamiltonian,
    validate_force_against_manual,
)

# Autodiff operators (JAX automatic differentiation)
from .autodiff import (
    make_gradient_operator,
    make_hessian_operator,
    potential_force_autodiff,
    check_gradient_correctness,
    energy_gradient_wrt_field,
    stability_hessian,
    validate_force_implementation,
    # Energy functionals (Hamiltonians for force computation)
    scalar_kinetic_energy_functional,
    scalar_gradient_energy_functional,
    scalar_potential_energy_functional,
    scalar_hamiltonian,
    gauge_electric_energy_functional,
    gauge_magnetic_energy_functional,
    gauge_hamiltonian,
    coupled_hamiltonian,
    make_scalar_force_from_hamiltonian,
    verify_force_is_gradient,
    wilson_action,
    compute_all_energy_components,
)

__all__ = [
    # Spectral (FFT-based)
    "laplacian",
    "laplacian_1d",
    "laplacian_2d",
    "laplacian_3d",
    "gradient_1d",
    "gradient_2d",
    "gradient_3d",
    "gradient_energy",
    "gradient_energy_1d",
    "gradient_energy_2d",
    "gradient_energy_3d",
    # Scalar
    "scalar_laplacian",
    "gradient_squared",
    "scalar_potential_energy",
    "scalar_potential_force",
    "scalar_kinetic_energy_density",
    # Gauge
    "plaquette",
    "all_plaquettes",
    "magnetic_field",
    "staple",
    "all_staples",
    "gauge_force",
    "magnetic_energy_density",
    "electric_energy_density",
    "divergence_3d",
    "gauss_constraint",
    "gauss_violation_norm",
    "gauge_energy",
    "evolve_links_half_step",
    "evolve_links_full_step",
    # Coupled
    "covariant_derivative",
    "covariant_gradient_squared",
    "covariant_laplacian",
    "scalar_force",
    "scalar_charge_density",
    "scalar_current_density",
    "gauss_constraint_with_source",
    "gauss_violation_norm_with_source",
    "coupled_energy",
    # Backward compatibility
    "scalar_potential",
    # Autodiff
    "make_gradient_operator",
    "make_hessian_operator",
    "potential_force_autodiff",
    "check_gradient_correctness",
    "energy_gradient_wrt_field",
    "stability_hessian",
    "validate_force_implementation",
    # Energy functionals
    "scalar_kinetic_energy_functional",
    "scalar_gradient_energy_functional",
    "scalar_potential_energy_functional",
    "scalar_hamiltonian",
    "gauge_electric_energy_functional",
    "gauge_magnetic_energy_functional",
    "gauge_hamiltonian",
    "coupled_hamiltonian",
    "make_scalar_force_from_hamiltonian",
    "verify_force_is_gradient",
    "wilson_action",
    "compute_all_energy_components",
    # Force operators
    "make_scalar_force",
    "make_coupled_scalar_force",
    "make_coupled_scalar_force_expanding",
    "make_rescaled_scalar_force",
    "make_gauge_force",
    "make_gauge_force_expanding",
    "make_forces_from_hamiltonian",
    "validate_force_against_manual",
    # Stencil operators
    "stencil_laplacian",
    "stencil_gradient_squared",
    "stencil_gradient",
    "stencil_divergence",
    "forward_gradient",
    "backward_gradient",
]
