"""
Static plotting utilities for field analysis.

This package provides tools to create static publication-quality figures
for analyzing lattice field dynamics, including phase portraits, energy plots,
and field distributions.
"""

from .phase import portrait as phase_portrait
from .dimensional import dimensional_comparison
from .field import snapshot2d
from .style import apply_dark_style, apply_dark_style_colorbar

__all__ = [
    "phase_portrait",
    "dimensional_comparison",
    "snapshot2d",
    "apply_dark_style",
    "apply_dark_style_colorbar",
]
