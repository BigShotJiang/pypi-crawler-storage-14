"""
Observable quantities for lattice field theory simulations.

This module provides functions to compute physical observables from
field configurations, including:

**Power Spectra & Correlations:**
- Power spectrum calculations (1D/2D/3D)
- Binning and radial averaging

**Energy Diagnostics:**
- Kinetic, gradient, potential energies
- Energy conservation tracking
- Energy component breakdown

**Gauge Theory Observables:**
- Gauss law enforcement and projection
- Gauge transformations and invariance
- Charge/current continuity

**Stability Analysis:**
- Tachyonic mode detection
- Hessian analysis and phase transitions
- Fluctuation spectra

**Energy Functionals:**
- Hamiltonian construction
- Force validation
- Wilson action
"""

from jaxlatt.observables.spectra import (
    power_spectrum_1d,
    power_spectrum_2d,
    power_spectrum_3d,
    power_spectrum,
    bin_power_spectrum,
    power_spectrum_with_binning,
)

from jaxlatt.observables.energy import (
    kinetic_energy_averaged as kinetic_energy,
    gradient_energy_averaged as gradient_energy,
    potential_energy_averaged as potential_energy,
    total_energy_averaged as total_energy,
    energy_components_averaged as energy_components,
    # Volume-integrated versions
    kinetic_energy as kinetic_energy_integrated,
    potential_energy as potential_energy_integrated,
    compute_energy_components,
    compute_energy,
    energy_density,
    EnergyTracker,
    # Physical energy densities for expanding universe (FLRW)
    compute_physical_energy_density,
    compute_physical_energy_components,
    compute_comoving_energy_density,
    compute_physical_scalar_gradient_energy,
    compute_physical_scalar_kinetic_energy,
    compute_physical_potential_energy,
    compute_physical_gauge_electric_energy,
    compute_physical_gauge_magnetic_energy,
)

from jaxlatt.core.constraints import (
    # Gauss constraint computation - canonical implementation
    gauss_constraint_with_source,
    # Projection methods
    project_gauss_constraint,
    project_gauss_coupled_lattice,
    # Baumgarte-Shapiro stabilization
    stabilized_constraint_evolution,
    # Gauge transformations
    gauge_transform_scalar,
    gauge_transform_links,
    gauge_transform_coupled_lattice,
    # Diagnostics
    check_gauge_invariance,
    compute_constraint_violation_norm,
    check_constraint_preservation,
    charge_current_continuity,
)

from jaxlatt.observables.stability import (
    compute_mass_matrix,
    detect_tachyonic_modes,
    compute_fluctuation_spectrum_1d,
    estimate_effective_mass_from_spectrum,
    compute_linear_response,
    compute_curvature_at_origin,
    compute_vev_estimate,
    check_symmetry_breaking,
    estimate_bounce_action,
    generate_stability_report,
)

__all__ = [
    # Power spectra
    "power_spectrum_1d",
    "power_spectrum_2d",
    "power_spectrum_3d",
    "power_spectrum",
    "bin_power_spectrum",
    "power_spectrum_with_binning",
    # Energy diagnostics (volume-averaged)
    "kinetic_energy",
    "gradient_energy",
    "potential_energy",
    "total_energy",
    "energy_components",
    "EnergyTracker",
    # Energy (volume-integrated)
    "kinetic_energy_integrated",
    "potential_energy_integrated",
    "compute_energy_components",
    "compute_energy",
    "energy_density",
    # Physical energy densities for expanding universe (FLRW)
    "compute_physical_energy_density",
    "compute_physical_energy_components",
    "compute_comoving_energy_density",
    "compute_physical_scalar_gradient_energy",
    "compute_physical_scalar_kinetic_energy",
    "compute_physical_potential_energy",
    "compute_physical_gauge_electric_energy",
    "compute_physical_gauge_magnetic_energy",
    # Constraints - computation
    "gauss_constraint_with_source",
    # Constraints - projection
    "project_gauss_constraint",
    "project_gauss_coupled_lattice",
    # Constraints - stabilization
    "stabilized_constraint_evolution",
    # Gauge transformations
    "gauge_transform_scalar",
    "gauge_transform_links",
    "gauge_transform_coupled_lattice",
    # Diagnostics
    "check_gauge_invariance",
    "compute_constraint_violation_norm",
    "check_constraint_preservation",
    "charge_current_continuity",
    # Stability
    "compute_mass_matrix",
    "detect_tachyonic_modes",
    "compute_fluctuation_spectrum_1d",
    "estimate_effective_mass_from_spectrum",
    "compute_linear_response",
    "compute_curvature_at_origin",
    "compute_vev_estimate",
    "check_symmetry_breaking",
    "estimate_bounce_action",
    "generate_stability_report",
]
