"""
Evolution module for lattice field theory.

Provides symplectic leapfrog integrators for:
- Pure gauge fields (flat + expanding space)
- Coupled scalar-gauge fields (flat + expanding space)
- Simple scalar fields (flat space only)

Also provides RK4 (4th-order Runge-Kutta) integrators as a high-accuracy alternative.

All leapfrog integrators preserve energy, symplectic structure, and constraints.
RK4 offers higher accuracy but does not preserve symplectic structure.
"""

from .leapfrog import (
    # Gauge evolution (flat space)
    gauge_leapfrog_step,
    gauge_evolve,
    # Coupled evolution (flat space)
    coupled_leapfrog_step,
    coupled_evolve,
    # Expanding universe evolution
    scalar_force_expanding,
    coupled_leapfrog_step_expanding,
    coupled_evolve_expanding,
    make_radiation_rho,
    compute_energy_densities_expanding,
    # Rescaled evolution (experimental)
    scalar_force_rescaled,
    coupled_leapfrog_step_rescaled,
)

from .rk4 import (
    # RK4 integrators (high-accuracy alternative)
    coupled_rk4_step,
    gauge_rk4_step,
)

from .scalar import (
    # Simple scalar field evolution (for basic Lattice class)
    evolve,
    evolve_step,
)

__all__ = [
    # Gauge (flat)
    "gauge_leapfrog_step",
    "gauge_evolve",
    # Coupled (flat)
    "coupled_leapfrog_step",
    "coupled_evolve",
    # Expanding
    "scalar_force_expanding",
    "coupled_leapfrog_step_expanding",
    "coupled_evolve_expanding",
    "make_radiation_rho",
    "compute_energy_densities_expanding",
    # Rescaled (experimental)
    "scalar_force_rescaled",
    "coupled_leapfrog_step_rescaled",
    # RK4 (high-accuracy)
    "coupled_rk4_step",
    "gauge_rk4_step",
    # Simple scalar (flat space only)
    "evolve",
    "evolve_step",
]
