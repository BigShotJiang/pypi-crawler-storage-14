This module adds basic a management system for Vertical Lift Modules.
It's thought as a simpler alternative attemp to stock_vertical_lift and
all the dependencies that come with it.
