from .noise import add_gaussian_noise, add_salt_and_pepper_noise, mse
from .morpho import bweuler
from .figures import add_legend, plotHistograms