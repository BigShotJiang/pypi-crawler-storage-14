import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import sys
import os
import copy

# Ensure ellice is in path
try:
    import ellice
except ImportError:
    # Assuming script is in ellice/demos/
    current_dir = os.path.dirname(os.path.abspath(__file__))
    repo_root = os.path.abspath(os.path.join(current_dir, ".."))
    sys.path.insert(0, repo_root)
    import ellice

from ellice.generators.continuous import ContinuousGenerator

# Global Config for visual appeal
plt.style.use('seaborn-v0_8-whitegrid')
COLOR_MAP_CONT = plt.cm.RdBu
COLOR_MAP_SCATTER = plt.cm.RdBu_r

# Custom colors
# Custom colors
COLOR_ORIGINAL = '#000080'  # Dark/Navy Blue
COLOR_RASHOMON = "#008080"#'#008080'  # Deep Teal
COLOR_CLASS_0 = '#4A7AC2'   # More vivid blue
COLOR_CLASS_1 = '#C24A4A'   # More vivid red

# 1. Generate Synthetic Data - Two Moons Dataset
def generate_data(n_samples=1000, noise=0.1, random_state=42):
    """
    Generate a two moons dataset - a classic non-linearly separable dataset
    where two classes form interlocking crescent shapes.
    
    Parameters:
    -----------
    n_samples : int, default=1000
        Total number of samples (half per class)
    noise : float, default=0.1
        Standard deviation of Gaussian noise added to the data
    random_state : int, default=42
        Random seed for reproducibility
    
    Returns:
    --------
    X : array-like of shape (n_samples, 2)
        The generated samples
    y : array-like of shape (n_samples,)
        The integer labels (0 or 1) for class membership
    """
    np.random.seed(random_state)
    
    n_samples_per_class = n_samples // 2
    
    # Generate first moon (upper crescent, curving upward like a smile)
    # This creates a half-circle curving upward
    angles1 = np.linspace(0, np.pi, n_samples_per_class)
    # Add radius variation to increase variance (spread) of the moon
    radius_variation1 = np.random.normal(1.0, 0.5, n_samples_per_class)  # Mean 1.0, std 0.3
    X1 = np.zeros((n_samples_per_class, 2))
    # First moon: variable radius, centered at (0, 0), curving upward
    X1[:, 0] = np.cos(angles1) * radius_variation1
    X1[:, 1] = np.sin(angles1) * radius_variation1
    # Add noise
    X1 += np.random.normal(0, noise, X1.shape)
    
    # Generate second moon (lower crescent, curving downward like a frown)
    # This creates a half-circle curving downward, positioned to interlock
    angles2 = np.linspace(0, np.pi, n_samples_per_class)
    # Add radius variation to increase variance (spread) of the moon
    radius_variation2 = np.random.normal(1.0, 0.3, n_samples_per_class)  # Mean 1.0, std 0.3
    X2 = np.zeros((n_samples_per_class, 2))
    # Second moon: variable radius, shifted to (1, 0.5), curving downward
    # Apply radius variation to the cos/sin parts, then apply the shift
    X2[:, 0] = 1.0 - np.cos(angles2) * radius_variation2
    X2[:, 1] = 0.5 - np.sin(angles2) * radius_variation2
    # Add noise
    X2 += np.random.normal(0, noise, X2.shape)
    
    # Combine
    X = np.vstack([X1, X2])
    y = np.hstack([np.zeros(n_samples_per_class), np.ones(n_samples_per_class)])
    
    # Standardize
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    return X, y

# 2. Define Simple NN
class SimpleNN(nn.Sequential):
    def __init__(self):
        super().__init__(
            nn.Linear(2, 48),
            nn.ReLU(),
            nn.Linear(48, 48),
            nn.ReLU(),
            nn.Linear(48, 1)
        )

def train_model(model, X, y, epochs=300):
    X_t = torch.FloatTensor(X)
    y_t = torch.FloatTensor(y).unsqueeze(1)
    
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.AdamW(model.parameters(), lr=0.01, weight_decay=0.001)
    
    model.train()
    for _ in range(epochs):
        optimizer.zero_grad()
        out = model(X_t)
        loss = criterion(out, y_t)
        loss.backward()
        optimizer.step()
    
    model.eval()
    return model

# 3. Helper to sample models from Ellipsoid
def sample_models_from_ellipsoid(generator, n_samples=32, indices=None):
    """
    Sample models that are worst-case for specific points.
    Instead of random sampling on the boundary, we sample points from the dataset
    and find the model on the boundary that minimizes/maximizes prediction for that point.
    This visualizes the 'worst-case' envelope.
    """
    sampled_models = []
    
    theta_star = generator.theta_star
    Q_inv_sqrt = generator.Q_inv_sqrt
    
    # We need data points to construct worst-case directions
    # Let's use points from the training set that are near the boundary or just random
    # Or better, points from each class to show both sides of the envelope
    
    # Access data from generator
    X_train = generator.data.get_dev_data().values.astype(np.float32)
    y_train = generator.data.get_target_data().values.astype(np.float32)
    
    # Sample n_samples points from each class
    # n_samples passed is total, so we split
    n_per_class = n_samples // 2
    
    indices_0 = np.where(y_train == 0)[0]
    indices_1 = np.where(y_train == 1)[0]
    
    # If we have enough points
    if len(indices_0) >= n_per_class:
        selected_0 = np.random.choice(indices_0, n_per_class, replace=False)
    else:
        selected_0 = indices_0
        
    if len(indices_1) >= n_per_class:
        selected_1 = np.random.choice(indices_1, n_per_class, replace=False)
    else:
        selected_1 = indices_1
    
    selected_indices = np.concatenate([selected_0, selected_1])
    if indices is not None:
        print('Using indices')
        selected_indices = np.concatenate([indices, selected_indices])
    
    # For each point, compute the worst-case direction u
    # The worst case direction for input x is u = Q^{-1/2} h / ||Q^{-1/2} h||
    # Depending on class we want to push prob up or down
    # But boundary is symmetric for theta -> theta +/- delta
    # So we just compute boundary points corresponding to these directions
    
    for idx in selected_indices:
        x_pt = X_train[idx]
        y_pt = y_train[idx]
        
        # Construct h_aug for this point
        x_tensor = torch.tensor(x_pt, device=generator.device, dtype=generator.dtype).unsqueeze(0)
        
        with torch.no_grad():
            h_flat = generator._get_penult_features(x_tensor)
            bias = torch.ones(h_flat.size(0), 1, device=generator.device, dtype=generator.dtype)
            h_aug = torch.cat([h_flat, bias], dim=1).squeeze(0) # [dim]
            
            # Calculate direction u in transformed space
            # u propto Q^{-1/2} h_aug
            u_unnorm = torch.matmul(generator.Q_inv_sqrt, h_aug)
            norm_u = torch.norm(u_unnorm)
            
            if norm_u < 1e-9:
                continue
                
            u = u_unnorm / norm_u
            
            # We want to sample BOTH directions (+u and -u) to show the full envelope width for this point
            # But function signature implies one model per iteration?
            # Let's just add both models for each point, so we might exceed n_samples slightly but that's fine
            
            directions = [u, -u]
            
            for direction_u in directions:
                # Scale by radius r=1 to be exactly on the boundary
                delta_theta = torch.matmul(generator.Q_inv_sqrt, direction_u)
                theta_new = theta_star + delta_theta
                
                # Reconstruct model
                new_model = copy.deepcopy(generator.model_wrapper.model)
                
                # Assuming simple structure where last layer is the one optimized/analyzed
                last_layer = new_model[-1]
                w_len = last_layer.weight.numel()
                
                w_new = theta_new[:w_len].reshape(last_layer.weight.shape)
                b_new = theta_new[w_len:]
                
                last_layer.weight.data.copy_(w_new)
                last_layer.bias.data.copy_(b_new)
                
                sampled_models.append(new_model)
        
    return sampled_models

def plot_background(model, X, y, ax, plot_scatter=True, alpha_contour=0.75):
    # Focus on the center by shrinking the bounds by 10%
    # Original range
    x_min_orig, x_max_orig = X[:, 0].min() - 0.5, X[:, 0].max() + 0.5
    y_min_orig, y_max_orig = X[:, 1].min() - 0.5, X[:, 1].max() + 0.5
    
    # Shrink by 10% towards center
    x_center = (x_min_orig + x_max_orig) / 2
    y_center = (y_min_orig + y_max_orig) / 2
    
    # Shrink factor 0.9 means 90% of the width/height around center
    shrink = 0.9
    x_span = (x_max_orig - x_min_orig) * shrink / 2
    y_span = (y_max_orig - y_min_orig) * shrink / 2
    
    x_min, x_max = x_center - x_span, x_center + x_span
    y_min, y_max = y_center - y_span, y_center + y_span
    
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.02),
                         np.arange(y_min, y_max, 0.02))
    
    grid_tensor = torch.FloatTensor(np.c_[xx.ravel(), yy.ravel()])
    
    with torch.no_grad():
        Z = torch.sigmoid(model(grid_tensor)).reshape(xx.shape).numpy()
        
    # Create custom colormap for softer background
    from matplotlib.colors import LinearSegmentedColormap
    colors = [COLOR_CLASS_0, 'white', COLOR_CLASS_1]
    cmap_soft = LinearSegmentedColormap.from_list('soft_rdbu', colors, N=100)
    
    ax.contourf(xx, yy, Z, alpha=0.7, cmap=cmap_soft, levels=100) # More vivid (higher alpha)
    ax.contour(xx, yy, Z, levels=[0.5], colors=COLOR_ORIGINAL, linewidths=2.5)
    
    if plot_scatter:
        # Filter points outside bounds for cleaner scatter
        mask = (X[:, 0] >= x_min) & (X[:, 0] <= x_max) & (X[:, 1] >= y_min) & (X[:, 1] <= y_max)
        ax.scatter(X[mask, 0], X[mask, 1], c=y[mask], cmap=COLOR_MAP_SCATTER, edgecolors='white', linewidths=1.5, alpha=0.7, s=45)
        
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    ax.set_xticks([])
    ax.set_yticks([])

def main():
    # Setup
    X, y = generate_data(n_samples=32_000, noise=0.2)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = SimpleNN()
    model = train_model(model, X_train, y_train, epochs=50)
    
    # ElliCE Setup
    df_full = pd.DataFrame(X_train, columns=['f1', 'f2'])
    df_full['target'] = y_train
    data = ellice.Data(df_full, target_column='target')
    
    # Define Epsilon for Robustness
    ROBUST_EPS = 0.02  # Large enough to show difference
    REG_COEF = 0.001

    
    # Create figure
    fig, axs = plt.subplots(1, 4, figsize=(24, 6))
    
    # Increase global font sizes
    plt.rcParams.update({'font.size': 14})
    
    # 1. Original Model
    plot_background(model, X_train, y_train, axs[0])
    axs[0].set_title("Original\nModel", fontsize=22, fontweight='bold')
    
    # Select a query point (class 0, close to boundary)
    # We want a point that is predicted as 0 (blue) but is somewhat close to 1 (red)
    model.eval()
    
    # Use randommly samples 1024 from dataset for plotting candidate selection
    # (But we should ideally select from full X_test, but for consistent density maybe random)
    # The prompt says "but when plotting use randommly samples 1024 from dataset"
    # I assume this refers to the scatter plot in plot_background OR the candidate selection?
    # Since plot_background uses X_train, maybe we should subsample X_train there.
    # But let's first fix query selection.
    
    # Let's subsample X_train for cleaner plots
    if len(X_train) > 1024:
        indices = np.random.choice(len(X_train), 1024, replace=False)
        X_plot = X_train[indices]
        y_plot = y_train[indices]
    else:
        X_plot = X_train
        y_plot = y_train
        
    # Re-plot first panel with subsampled data
    axs[0].clear()
    plot_background(model, X_plot, y_plot, axs[0])
    axs[0].set_title("Original\nModel", fontsize=22, fontweight='bold')

    with torch.no_grad():
        preds = torch.sigmoid(model(torch.FloatTensor(X_test))).numpy().flatten()
        
    # Filter for class 0 with prob between 0.1 and 0.4 (not too deep, not too boundary)
    candidates = np.where((preds < 0.5) & (preds > 0.25))[0]
    if len(candidates) < 3:
        # If not enough candidates, use any class 0 points
        candidates = np.where(preds < 0.5)[0]
    if len(candidates) < 3:
        # Fallback: use first 3 test points
        candidates = np.arange(min(3, len(X_test)))
    
    # Select 3 DIFFERENT query points
    selected_indices = np.random.choice(candidates, size=min(10, len(candidates)), replace=False)
    query_points = [X_test[idx] for idx in selected_indices]
    target_class = 1
    
    print(f"Selected {len(query_points)} different query points:")
    for i, qp in enumerate(query_points):
        print(f"  Query {i}: {qp}")
    
    # 2. Usual Counterfactual (Standard Gradient Descent)
    # We simulate this by using ContinuousGenerator with very small epsilon
    exp_std = ellice.Explainer(model, data, backend='pytorch')
    
    # Generate 1 standard CF for each query point
    std_cfs = []
    print("\nGenerating Standard CFs...")
    for i, query_pt in enumerate(query_points):
        cf_std_df = exp_std.generate_counterfactuals(
            query_pt, 
            method='continuous', 
            target_class=target_class,
            robustness_epsilon=1e-6,
            progress_bar=False,
            optimization_params={'max_iterations': 1000, 'learning_rate': 0.05}
        )
        if not cf_std_df.empty:
            val = cf_std_df[data.feature_names].values[0]
            std_cfs.append((query_pt, val))
            print(f"  Standard CF {i}: Query={query_pt}, CF={val}")
        else:
            print(f"  Failed to generate CF {i}")
    
    # Use X_plot for subsequent plots too
    plot_background(model, X_plot, y_plot, axs[1], plot_scatter=True) # Show scatter for context
    
    # Plot 3 Query points and their CFs
    for i, (query_pt, cf_std) in enumerate(std_cfs):
        # Plot Query
        axs[1].scatter(query_pt[0], query_pt[1], c='gold', s=200, marker='*', edgecolors='black', 
                      label='Query' if i == 0 else None, zorder=10)
        # Plot CF
        axs[1].scatter(cf_std[0], cf_std[1], c='lime', s=200, marker='X', edgecolors='black', 
                      label='CF' if i == 0 else None, zorder=10)
        # Add annotation arrow from Query to CF
        axs[1].annotate("", xy=(cf_std[0], cf_std[1]), xytext=(query_pt[0], query_pt[1]),
                        arrowprops=dict(arrowstyle="->", color="black", lw=2.0, mutation_scale=15, alpha=0.8))
                    
    axs[1].set_title("Standard Counterfactuals\n(Non-Robust)", fontsize=22, fontweight='bold')
    
    # 3. Sampled Models from Ellipsoid
    # We need a generator with actual epsilon
    gen_robust = ContinuousGenerator(exp_std.model, data, eps=ROBUST_EPS, reg_coef=0.01)
    
    # Sample diverse models
    # 1. Sample many models (128)
    # 2. Select 32 most different ones
    all_sampled_models = sample_models_from_ellipsoid(gen_robust, n_samples=2048 * 8, indices=selected_indices)
    
    # Calculate pairwise differences in weights to find diverse set
    # Or simply cluster them? Or greedy selection?
    # Greedy Max-Min distance selection
    
    # Extract weight vectors
    weight_vectors = []
    for m in all_sampled_models:
        last_layer = m[-1]
        w = last_layer.weight.data.flatten()
        b = last_layer.bias.data.flatten()
        theta = torch.cat([w, b]).cpu().numpy()
        weight_vectors.append(theta)
    weight_vectors = np.array(weight_vectors)
    
    # Greedy selection
    #selected_indices = [0] # Start with first
    selected_indices = [i for i in range(1024)]
    n_select = 512
    
    while len(selected_indices) < n_select:
        # Find candidate that maximizes min distance to already selected
        max_min_dist = -1
        best_candidate = -1
        
        for i in range(len(weight_vectors)):
            if i in selected_indices:
                continue
                
            # Dist to selected
            dists = np.linalg.norm(weight_vectors[i] - weight_vectors[selected_indices], axis=1)
            min_dist = np.mean(dists)
            
            if min_dist > max_min_dist:
                max_min_dist = min_dist
                best_candidate = i
        
        selected_indices.append(best_candidate)

    #selected_indices = [i for i in range(64)]#
    sampled_models = [all_sampled_models[i] for i in selected_indices]
    
    # Plot background of original model faintly
    plot_background(model, X_plot, y_plot, axs[2], plot_scatter=True)
    
    # Plot boundaries of sampled models
    x_min, x_max = axs[0].get_xlim()
    y_min, y_max = axs[0].get_ylim()
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1), np.arange(y_min, y_max, 0.1))
    grid_tensor = torch.FloatTensor(np.c_[xx.ravel(), yy.ravel()])
    
    for m in sampled_models:
        with torch.no_grad():
            Z = torch.sigmoid(m(grid_tensor)).reshape(xx.shape).numpy()
        axs[2].contour(xx, yy, Z, levels=[0.5], colors=COLOR_RASHOMON, linestyles='dashed', linewidths=0.75, alpha=0.2) #
        
    # Re-plot original boundary
    with torch.no_grad():
        Z_orig = torch.sigmoid(model(grid_tensor)).reshape(xx.shape).numpy()
    axs[2].contour(xx, yy, Z_orig, levels=[0.5], colors=COLOR_ORIGINAL, linewidths=3.0)
    
    axs[2].set_title("Rashomon Set (Sampled Models)\nfrom explicit ellipsoid", fontsize=22, fontweight='bold')
    
    # 4. Robust Counterfactual
    # Generate robust CF
    # We need to use the generator directly or re-wrap, but reusing exp_std is easier if we just pass epsilon
    
    # Generate 1 robust CF for each query point
    rob_cfs = []
    print("\nGenerating Robust CFs...")
    for i, query_pt in enumerate(query_points):
        cf_rob_df = exp_std.generate_counterfactuals(
            query_pt, 
            method='continuous', 
            target_class=target_class,
            robustness_epsilon=ROBUST_EPS, 
            regularization_coefficient=REG_COEF,
            progress_bar=False,
            optimization_params={'max_iterations': 1000, 'learning_rate': 0.01}
        )
        
        if not cf_rob_df.empty:
            val = cf_rob_df[data.feature_names].values[0]
            rob_cfs.append((query_pt, val))
            print(f"  Robust CF {i}: Query={query_pt}, CF={val}")
        else:
            print(f"  Failed to generate robust CF {i}, using placeholder")
            rob_cfs.append((query_pt, query_pt)) # Fallback
        
    # For the 4th plot, we want to visualize "Robustness". 
    # Showing the robust CF against the sampled boundaries is a good way.
    
    # Plot background of original model faintly
    plot_background(model, X_plot, y_plot, axs[3], plot_scatter=True)
    
    # Plot sampled boundaries faintly
    for m in sampled_models:
        with torch.no_grad():
            Z = torch.sigmoid(m(grid_tensor)).reshape(xx.shape).numpy()
        axs[3].contour(xx, yy, Z, levels=[0.5], colors=COLOR_RASHOMON, linestyles='dashed', linewidths=0.75, alpha=0.2) #
        
    # Plot original boundary
    axs[3].contour(xx, yy, Z_orig, levels=[0.5], colors=COLOR_ORIGINAL, linewidths=2.5)
    
    # Plot 3 Query points and their Robust CFs
    for i, (query_pt, cf_rob) in enumerate(rob_cfs):
        # Plot Query
        axs[3].scatter(query_pt[0], query_pt[1], c='gold', s=200, marker='*', edgecolors='black', 
                      label='Query' if i == 0 else None, zorder=10)
        # Plot Robust CF
        axs[3].scatter(cf_rob[0], cf_rob[1], c='magenta', s=200, marker='P', edgecolors='black', 
                      label='Robust CF' if i == 0 else None, zorder=10)
        # Add annotation arrow from Query to Robust CF
        axs[3].annotate("", xy=(cf_rob[0], cf_rob[1]), xytext=(query_pt[0], query_pt[1]),
                        arrowprops=dict(arrowstyle="->", color="black", lw=2.0, mutation_scale=15, alpha=0.8))
                 
    # Optionally: Highlight that Robust CF is valid for ALL sampled boundaries (it should be on the correct side of all gray lines)
    
    axs[3].set_title("Robust Counterfactuals\nfrom explicit ellipsoid", fontsize=22, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('ellice_banner.png', dpi=300)
    print("Saved ellice_banner.png")
    # plt.show()

if __name__ == "__main__":
    main()