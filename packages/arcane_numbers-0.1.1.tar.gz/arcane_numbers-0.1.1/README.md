# Arcane numbers

This package help us format numbers

## Test
`poetry run pytest tests`
