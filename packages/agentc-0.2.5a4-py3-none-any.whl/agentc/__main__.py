def main():
    import agentc_cli

    # Note: all the CLI code currently resides in agentc_cli.
    agentc_cli.main()


if __name__ == "__main__":
    main()
