# Python Utilities Library

Version 2.1.2, 2018 - 2025, Dmitrii Gusev  
*Last update: 28.11.2025*

## Project Description

Useful utilities functions for various needs for the python 3.10+. Containing 'general purpose' functions.

## Versions history

### 2.1.2

Major release with complete set of useful 'general purpose' functions. Documentation 'is coming'...

**Warning! Versions 2.1.0, 2.1.1 are intended only for the python version = 3.10 and may be installed only for it!**

### Versions before 2.x.x

**It is strongly recommended: don't use versions prior to the 2.x.x!**

Main properties of the previous library versions:

- set of the 'minor' and 'experimental' releases
- various set of functions without consistency
- many 'experimental' functions without proper testing
- a lot of unnecessary code
- experiments with building/dependencies management tools - no tool, pipenv poetry
- unstable list of dependencies with obsolete versions
