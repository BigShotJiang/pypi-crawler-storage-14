import asyncio
import os
from typing import ClassVar, Literal

from anthropic.types.beta import BetaToolBash20250124Param
import httpx

from .base import BaseAnthropicTool, CLIResult, ToolError, ToolResult
def _http_error_detail(e: Exception) -> str:
    if isinstance(e, httpx.HTTPStatusError) and e.response is not None:
        try:
            body = e.response.text
        except Exception:
            body = "<no body>"
        req = e.request
        return f"{e.response.status_code} {e.response.reason_phrase} {req.method} {req.url} body={body}"
    if isinstance(e, httpx.TimeoutException):
        req = getattr(e, "request", None)
        return f"timeout {getattr(req, 'method', '')} {getattr(req, 'url', '')}"
    return repr(e)



class _BashSession:
    """A session of a bash shell."""

    _started: bool
    _process: asyncio.subprocess.Process

    command: str = "/bin/bash"
    _output_delay: float = 0.2  # seconds
    _timeout: float = 120.0  # seconds
    _sentinel: str = "<<exit>>"

    def __init__(self):
        self._started = False
        self._timed_out = False

    async def start(self):
        if self._started:
            return

        self._process = await asyncio.create_subprocess_shell(
            self.command,
            preexec_fn=os.setsid,
            shell=True,
            bufsize=0,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        self._started = True

    def stop(self):
        """Terminate the bash shell."""
        if not self._started:
            raise ToolError("Session has not started.")
        if self._process.returncode is not None:
            return
        self._process.terminate()

    async def run(self, command: str):
        """Execute a command in the bash shell."""
        if not self._started:
            raise ToolError("Session has not started.")
        if self._process.returncode is not None:
            return ToolResult(
                system="tool must be restarted",
                error=f"bash has exited with returncode {self._process.returncode}",
            )
        if self._timed_out:
            raise ToolError(
                f"timed out: bash has not returned in {self._timeout} seconds and must be restarted",
            )

        # we know these are not None because we created the process with PIPEs
        assert self._process.stdin
        assert self._process.stdout
        assert self._process.stderr

        # send command to the process
        self._process.stdin.write(
            command.encode() + f"; echo '{self._sentinel}'\n".encode()
        )
        await self._process.stdin.drain()

        # read output from the process, until the sentinel is found
        try:
            async with asyncio.timeout(self._timeout):
                while True:
                    await asyncio.sleep(self._output_delay)
                    # if we read directly from stdout/stderr, it will wait forever for
                    # EOF. use the StreamReader buffer directly instead.
                    output = self._process.stdout._buffer.decode()  # pyright: ignore[reportAttributeAccessIssue]
                    if self._sentinel in output:
                        # strip the sentinel and break
                        output = output[: output.index(self._sentinel)]
                        break
        except asyncio.TimeoutError:
            self._timed_out = True
            raise ToolError(
                f"timed out: bash has not returned in {self._timeout} seconds and must be restarted",
            ) from None

        if output.endswith("\n"):
            output = output[:-1]

        error = self._process.stderr._buffer.decode()  # pyright: ignore[reportAttributeAccessIssue]
        if error.endswith("\n"):
            error = error[:-1]

        # clear the buffers so that the next output can be read correctly
        self._process.stdout._buffer.clear()  # pyright: ignore[reportAttributeAccessIssue]
        self._process.stderr._buffer.clear()  # pyright: ignore[reportAttributeAccessIssue]

        return CLIResult(output=output, error=error)


class BashTool(BaseAnthropicTool):
    """
    A tool that allows the agent to run bash commands.
    The tool parameters are defined by Anthropic and are not editable.
    """

    _session: _BashSession | None
    name: ClassVar[Literal["bash"]] = "bash"
    api_type: ClassVar[Literal["bash_20250124"]] = "bash_20250124"

    def __init__(self, port: int = 8002):
        self._session = None
        self.api_base_url = f"http://localhost:{port}"
        self.client = httpx.AsyncClient()
        super().__init__()

    async def __call__(
        self, command: str | None = None, restart: bool = False, **kwargs
    ):
        try:
            response = await self.client.post(
                f"{self.api_base_url}/bash",
                json={"command": command, "restart": restart}
            )
            response.raise_for_status()
            data = response.json()
            
            if data.get("system"):
                return ToolResult(system=data["system"])
            
            return CLIResult(output=data.get("output"), error=data.get("error"))

        except httpx.HTTPError as e:
            return ToolResult(error=f"API request failed: {_http_error_detail(e)}")

    def to_params(self) -> BetaToolBash20250124Param:
        return {
            "type": self.api_type,
            "name": self.name,
        }
