import os
import smtplib
import time
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List

import pandas as pd


def add_extension(email: str) -> str:
    return email + ".rpost.biz"


def shipment_email(subject: str, recipients: List[str], html_content, files, SMTP_SERVER, SMTP_PORT, SMTP_USER, SMTP_PASSWORD):
    recipients = [str(recipient).strip() for recipient in recipients]
    cc_recipients = []
    bcc_recipients = []

    # build message
    msg = MIMEMultipart()
    msg["From"] = SMTP_USER
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject

    msg["Cc"] = ", ".join(cc_recipients)
    msg["Bcc"] = ", ".join(bcc_recipients)

    # Agregar el HTML como cuerpo del correo
    msg.attach(MIMEText(html_content, "html"))

    # Adjuntar archivos PDF
    if files:
        for file_path in files:
            if os.path.exists(file_path):
                try:
                    with open(file_path, "rb") as attachment:
                        part = MIMEBase("application", "octet-stream")
                        part.set_payload(attachment.read())

                    encoders.encode_base64(part)

                    # Obtener el nombre del archivo
                    filename = os.path.basename(file_path)
                    part.add_header(
                        "Content-Disposition",
                        f"attachment; filename= {filename}",
                    )

                    msg.attach(part)
                    print(f"✅ Archivo adjuntado: {filename}")
                except Exception as e:
                    print(f"❌ Error al adjuntar {file_path}: {str(e)}")
            else:
                print(f"⚠️  Archivo no encontrado: {file_path}")

    # shipment email
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()  # Seguridad TLS
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.sendmail(SMTP_USER, recipients + cc_recipients + bcc_recipients, msg.as_string())
        server.quit()
        print("Correo enviado con éxito ✅")
        return True
    except Exception as e:
        print(f"❌ Error al enviar correo: {str(e)}")
        return False


if __name__ == "__main__":
    # remitente
    SMTP_USER = "info@viviendapotencial.com"
    SMTP_PASSWORD = "jsnixmuoutykfeos"

    # sujects
    subject_inquilino = "Notificación cesión de contrato Vivienda Potencial"
    subject_coarrendatario = "Notificación cesión de contrato Vivienda Potencial"
    subject_propietario = "Aviso importante sobre la cesión de tu contrato"

    # definición de emails
    inquilinos = pd.read_excel("vivienda_potencial/recipients/emails_inquilino.xlsx")
    inquilinos = inquilinos.to_dict("records")

    coarrendatarios = pd.read_excel("vivienda_potencial/recipients/emails_coarrendatario.xlsx")
    coarrendatarios = coarrendatarios.to_dict("records")

    emails_propietario = ["analista1@lagencia.com.co", "analista2@lagencia.com.co", "azuluaga@lagencia.com.co"]
    emails_propietario = pd.read_excel("vivienda_potencial/recipients/email_propietarios.xlsx")["CORREO ELECTRONICO"]
    emails_propietario.dropna(inplace=True)
    emails_propietario.drop_duplicates(inplace=True)
    emails_propietario = emails_propietario.to_list()

    # Cargar la plantilla HTML
    with open("vivienda_potencial/templates_html/inquilino.html", "r", encoding="utf-8") as file:
        html_template_inquilino = file.read()

    with open("vivienda_potencial/templates_html/coarrendatario.html", "r", encoding="utf-8") as file:
        html_template_coarrendatario = file.read()

    with open("vivienda_potencial/templates_html/propietario.html", "r", encoding="utf-8") as file:
        html_template_propietario = file.read()

    # servidor
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 587

    # Archivos a adjuntar
    archivos_adjuntos = ["vivienda_potencial/pdfs/Notif paso a paso.pdf"]


    # + envio propietarios
    status_shipmet_propietarios= {"email": [], "status": []}
    for email in emails_propietario:
        result_shipment= shipment_email(subject= subject_propietario,recipients=[email], html_content=html_template_propietario, files=[], SMTP_SERVER=SMTP_SERVER, SMTP_PORT=SMTP_PORT, SMTP_USER=SMTP_USER, SMTP_PASSWORD=SMTP_PASSWORD)
        status_shipmet_propietarios["email"].append(email)
        status_shipmet_propietarios["status"].append(result_shipment)
        time.sleep(1)
    print(status_shipmet_propietarios)
    pd.DataFrame(status_shipmet_propietarios).to_excel("vivienda_potencial/status_shipmet_propietarios.xlsx", index=False)

    # # + envio inquilino
    # status_shipmet_inquilino = {"email": [], "status": []}
    # # Guarda el template original ANTES del loop
    # for inquilino_ in inquilinos:
    #     inquilino = inquilino_.copy()
    #     inquilino["Email_Inq"] = add_extension(email=inquilino["Email_Inq"])

    #     # Crea una NUEVA copia del template original en cada iteración
    #     html_template_personalizado = (
    #         html_template_inquilino.replace("{{Nombre_Inquilino__}}", inquilino.get("Nombre_Inquilino", "")).replace("{{contrato__}}", str(inquilino.get("Contrato", ""))).replace("{{Dir_Inmueble__}}", inquilino.get("Dir_Inmueble", "")).replace("{{Municipio_Inmueble__}}", inquilino.get("Municipio_Inmueble", ""))
    #     )

    #     result_shipment = shipment_email(
    #         subject=subject_inquilino,
    #         recipients=[inquilino["Email_Inq"]],
    #         html_content=html_template_personalizado,  # Usa el personalizado
    #         files=archivos_adjuntos,
    #         SMTP_SERVER=SMTP_SERVER,
    #         SMTP_PORT=SMTP_PORT,
    #         SMTP_USER=SMTP_USER,
    #         SMTP_PASSWORD=SMTP_PASSWORD,
    #     )

    #     status_shipmet_inquilino["email"].append(inquilino["Email_Inq"])
    #     status_shipmet_inquilino["status"].append(result_shipment)
    #     time.sleep(1)

    # print(status_shipmet_inquilino)
    # pd.DataFrame(status_shipmet_inquilino).to_excel("vivienda_potencial/status_shipmet_inquilino.xlsx", index=False)

    # # ++ envio coarrendatario
    # status_shipmet_coarrendatario = {"email": [], "status": []}
    # # Guarda el template original ANTES del loop
    # for coarrendatario_ in coarrendatarios:
    #     coarrendatario = coarrendatario_.copy()
    #     coarrendatario["Email_Coarrendatario"] = add_extension(email=coarrendatario["Email_Coarrendatario"])

    #     # Crea una NUEVA copia del template original en cada iteración
    #     html_template_personalizado = (
    #         html_template_coarrendatario.replace("{{Nombre_coarrendatario__}}", coarrendatario.get("Nombre_coarrendatario", "")).replace("{{Nombre_Inquilino__}}", coarrendatario.get("Nombre_Inquilino", "")).replace("{{contrato__}}", str(coarrendatario.get("Contrato", ""))).replace("{{Dir_Inmueble__}}", coarrendatario.get("Dir_Inmueble", "")).replace("{{Municipio_Inmueble__}}", coarrendatario.get("Municipio_Inmueble", ""))
    #     )

    #     result_shipment = shipment_email(
    #         subject=subject_coarrendatario,
    #         recipients=[coarrendatario["Email_Coarrendatario"]],
    #         html_content=html_template_personalizado,  # Usa el personalizado
    #         files=archivos_adjuntos,
    #         SMTP_SERVER=SMTP_SERVER,
    #         SMTP_PORT=SMTP_PORT,
    #         SMTP_USER=SMTP_USER,
    #         SMTP_PASSWORD=SMTP_PASSWORD,
    #     )

    #     status_shipmet_coarrendatario["email"].append(coarrendatario["Email_Coarrendatario"])
    #     status_shipmet_coarrendatario["status"].append(result_shipment)
    #     time.sleep(1)

    # print(status_shipmet_coarrendatario)
    # pd.DataFrame(status_shipmet_coarrendatario).to_excel("vivienda_potencial/status_shipmet_coarrendatario.xlsx", index=False)
