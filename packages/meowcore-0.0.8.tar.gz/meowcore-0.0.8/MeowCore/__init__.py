__version__ = "0.0.8"

from MeowCore.main import MeowCore

__all__ = [
    "MeowCore"
]
