from .server import main

main()
