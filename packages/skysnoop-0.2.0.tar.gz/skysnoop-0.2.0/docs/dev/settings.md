# Settings

This project uses the [Pydantic Base Settings](https://docs.pydantic.dev/usage/settings/) system. The `skysnoop.conf.settings:Settings` class can be expanded to include new settings. An active instance of the settings class can be found at `skysnoop.conf:settings`.
