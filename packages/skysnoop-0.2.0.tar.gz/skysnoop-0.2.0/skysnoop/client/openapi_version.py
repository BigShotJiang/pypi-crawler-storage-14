"""OpenAPI specification version tracking.

This file is auto-generated and should not be edited manually.
Updated via: make openapi-update
"""

# Version from OpenAPI spec
OPENAPI_VERSION = "0.0.2"

# SHA256 hash of the OpenAPI spec file
SPEC_HASH = "aacc9934a550712574ba5cf484d2c04614b19e54baeea37f036544b9a392446a"

# Last update timestamp
SPEC_UPDATED = "2025-11-18"
