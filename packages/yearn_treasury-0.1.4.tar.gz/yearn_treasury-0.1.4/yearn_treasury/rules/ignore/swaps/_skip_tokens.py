from typing import Final

from ...constants import YFI


SKIP_TOKENS: Final = (
    YFI,
    "0x9d409a0A012CFbA9B15F6D4B36Ac57A46966Ab9a",  # yvboost
)
