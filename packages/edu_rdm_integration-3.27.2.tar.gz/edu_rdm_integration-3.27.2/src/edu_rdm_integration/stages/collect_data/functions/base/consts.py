NOT_SPECIFIED_QUEUE_TO_MODEL_ERROR = 'Для переданной модели {} не указана очередь для сохранения!'

CACHED_OBJECTS_TYPE_MISMATCH_ERROR = 'Тип сравниваемого объекта не соответствует типу объекта в кеше'
