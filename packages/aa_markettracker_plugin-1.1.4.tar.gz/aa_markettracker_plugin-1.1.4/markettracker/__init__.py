"""Initialize the app"""

__version__ = "1.1.4"
__title__ = "Markettracker"
