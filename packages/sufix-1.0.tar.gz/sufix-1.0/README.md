# 🚀 Sufi AI

**Unlimited Free LLM Chat - No API Key Needed!**

Simple Python library for AI chat. Install karo aur shuru ho jao! 💡

## ✨ Features

- ✅ **No API Key Required** - Seedha use karo
- ✅ **Unlimited Chat** - Koi limit nahi
- ✅ **Super Simple** - 2 lines me ready
- ✅ **Multiple Models** - Choose karo apni choice ka
- ✅ **Free Forever** - Hamesha free!

## 📦 Installation

```bash
pip install sufi-ai
```

## 🎯 Usage

```python
import sufi_ai

# Bas itna! 🔥
response = sufi_ai.chat("What is artificial intelligence?")
print(response)

# Different model use karo
response = sufi_ai.chat("Explain Python", model=sufi_ai.Models.PRO)
print(response)
```

## 🤖 Available Models

```python
sufi_ai.Models.FAST  # sufi-o1-fast (default)
sufi_ai.Models.PRO   # sufi-o1-pro
sufi_ai.Models.MINI  # sufi-mini
```

## 💬 Examples

### Simple Chat
```python
import sufi_ai

response = sufi_ai.chat("Hello!")
print(response)
```

### Code Generation
```python
response = sufi_ai.chat("Write a Python function to add two numbers")
print(response)
```

### Creative Writing
```python
response = sufi_ai.chat("Write a short poem about AI")
print(response)
```

## 🛠️ Requirements

- Python 3.7+
- requests library (auto-installed)

## 📄 License

MIT License - Use freely!

## 🤝 Contributing

Issues aur PRs welcome hai! GitHub pe contribute karo.

## 📞 Support

Problems? GitHub issues pe bolo ya email karo.

---

**Made with ❤️ by [Sufiyan]**

*Unlimited AI chat for everyone!* 🌍