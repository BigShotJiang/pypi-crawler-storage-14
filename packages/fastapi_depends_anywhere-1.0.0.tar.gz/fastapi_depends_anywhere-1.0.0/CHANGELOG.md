# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-11-28)


## v0.0.0 (2025-11-28)

- Initial Release
