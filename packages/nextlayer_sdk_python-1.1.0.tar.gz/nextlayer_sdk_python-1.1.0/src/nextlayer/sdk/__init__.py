# do not edit this version line, it will be updated in CI-Pipeline!
__version__ = "v1.1.0"
