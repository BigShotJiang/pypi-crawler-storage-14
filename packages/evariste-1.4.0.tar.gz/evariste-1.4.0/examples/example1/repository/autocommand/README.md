Test of the `action.autocommand` plugin.
