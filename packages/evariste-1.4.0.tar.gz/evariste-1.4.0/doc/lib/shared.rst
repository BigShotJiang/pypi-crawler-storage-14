:mod:`evariste.shared`
======================

.. automodule:: evariste.shared
