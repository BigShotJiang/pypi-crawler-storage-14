:mod:`evariste.plugins.action`
==============================

.. automodule:: evariste.plugins.action

