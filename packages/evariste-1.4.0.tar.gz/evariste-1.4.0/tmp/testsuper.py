class A:
    attribut = "aaaa"

    @classmethod
    def testiter(cls):
        # print(dir(super()))
        # if hasattr(super(), "testiter"):
        print(cls, issubclass(cls, A))
        if cls != A:
            print(cls)
            yield from super().testiter()
        yield cls.attribut


class B(A):
    attribut = "bbbb"


class C(A):
    attribut = "cccc"


a = A()
b = B()
c = C()

for i in a, b, c:
    print(i, list(i.testiter()))
