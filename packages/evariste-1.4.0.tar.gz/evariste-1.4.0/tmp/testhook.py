import functools


def hook(name):
    def wrapper(func):
        @functools.wraps(func)
        def wrapped(self, bar):
            return func(self, bar)

        setattr(wrapped, "hooked", name)
        return wrapped

    return wrapper


print("DÉFINITION DE A")


class A:
    @hook("foo")
    def foo(self):
        print(f"foo")

    @hook("bar")
    @hook("foo")
    def foobar(self):
        print(f"foobar")

    def baz(self):
        print("baz")


class B(A):
    def foo(self):
        pass


for classe in (A, B):
    for attr in dir(classe):
        method = getattr(classe, attr)
        if hasattr(method, "hooked"):
            print("HOOK", classe, method, getattr(method, "hooked"))

print("IMPLÉMENTATION DE A")
a = A()
