import itertools

for lettre in list(
    itertools.chain.from_iterable(mot for mot in "tagada tsoin tsoin".split())
):
    print(lettre)
