import asyncio
import datetime
from pathlib import Path

import aiohttp

from earthcare_downloader import utils

from .params import File, SearchParams
from .products import ESAProd, JAXAProd, MetData, OrbitData


async def get_files(params: SearchParams) -> list[File]:
    base_url = "https://ec-pdgs-discovery.eo.esa.int/socat"
    common_params = _get_query_params(params)

    product_groups = {
        "esa-lv1": [
            p for p in params.product if p in ESAProd._value2member_map_ and "1" in p
        ],
        "esa-lv2": [
            p for p in params.product if p in ESAProd._value2member_map_ and "2" in p
        ],
        "jaxa-lv2": [p for p in params.product if p in JAXAProd._value2member_map_],
        "orbit-scenarios": [p for p in params.product if p == OrbitData.MPL_ORBSCT],
        "orbit-predictions": [p for p in params.product if p == OrbitData.AUX_ORBPRE],
        "met-data": [p for p in params.product if p == MetData.AUX_MET_1D],
    }
    urls = {
        "esa-lv1": f"{base_url}/EarthCAREL1Validated/search",
        "esa-lv2": f"{base_url}/EarthCAREL2Validated/search",
        "jaxa-lv2": f"{base_url}/JAXAL2Validated/search",
        "orbit-scenarios": f"{base_url}/EarthCAREOrbitData/search",
        "orbit-predictions": f"{base_url}/EarthCAREOrbitData/search",
        "met-data": f"{base_url}/EarthCAREAuxiliaryXMETL1D/search",
    }

    async with aiohttp.ClientSession() as session:
        tasks = []
        for type, prods in product_groups.items():
            if not prods:
                continue
            query_params = common_params.copy()
            if type != "met-data":
                query_params["query.productType"] = prods
            if type in ("orbit-scenarios", "orbit-predictions"):
                query_params.update(
                    {"query.orbitNumber.min": "", "query.orbitNumber.max": ""}
                )
                _set_footprint(query_params)
            if type == "orbit-scenarios":
                query_params.update(
                    {
                        "query.beginAcquisition.start": "",
                        "query.beginAcquisition.stop": "",
                        "query.endAcquisition.start": "",
                        "query.endAcquisition.stop": "",
                    }
                )
            if type == "met-data":
                _set_footprint(query_params)
            tasks.append(_fetch_files(session, urls[type], query_params))
        results = await asyncio.gather(*tasks, return_exceptions=False)

    files = [
        _create_file(url, product)
        for result in results
        for url in result
        for product in params.product
        if product in url
    ]
    if params.all is False:
        files = _parse_newest_file_versions(files)

    return files


def _create_file(url: str, product: str) -> File:
    filename = Path(url).name
    parts = filename.split("_")
    try:
        processing_time = datetime.datetime.strptime(parts[-2], "%Y%m%dT%H%M%SZ")
    except ValueError:
        processing_time = None
    return File(
        url=url,
        product=product,
        filename=filename,
        server=url.split("/data/")[0],
        baseline=parts[1][-2:],
        frame_start_time=datetime.datetime.strptime(parts[-3], "%Y%m%dT%H%M%SZ"),
        processing_time=processing_time,
        identifier="_".join(parts[2:-2]),
    )


def _parse_newest_file_versions(files: list[File]) -> list[File]:
    files_filtered: dict[str, File] = {}
    for f in files:
        key = f.identifier
        current = files_filtered.get(key)
        if current is None:
            files_filtered[key] = f
        else:
            if f.baseline > current.baseline or (
                f.baseline == current.baseline
                and f.processing_time is not None
                and current.processing_time is not None
                and f.processing_time > current.processing_time
            ):
                files_filtered[key] = f
    return list(files_filtered.values())


async def _fetch_files(
    session: aiohttp.ClientSession, url: str, query_params: dict
) -> list[str]:
    async with session.post(url, data=query_params) as response:
        response.raise_for_status()
        text = await response.text()
        return text.splitlines()


def _get_query_params(params: SearchParams) -> dict:
    query_params = {
        "service": "SimpleOnlineCatalogue",
        "version": "1.2",
        "request": "search",
        "format": "text/plain",
        "query.beginAcquisition.start": params.start,
        "query.beginAcquisition.stop": params.stop,
        "query.endAcquisition.start": params.start,
        "query.endAcquisition.stop": params.stop,
        "query.orbitNumber.min": params.orbit_min,
        "query.orbitNumber.max": params.orbit_max,
    }
    if (
        params.lat is not None
        and params.lon is not None
        and params.distance is not None
    ):
        lat_buf = utils.distance_to_lat_deg(params.distance)
        lon_buf = utils.distance_to_lon_deg(params.lat, params.distance)
        _set_footprint(
            query_params,
            max(params.lat - lat_buf, -90),
            min(params.lat + lat_buf, 90),
            max(params.lon - lon_buf, -180),
            min(params.lon + lon_buf, 180),
        )
    elif params.lat_range is not None and params.lon_range is not None:
        _set_footprint(
            query_params,
            params.lat_range[0],
            params.lat_range[1],
            params.lon_range[0],
            params.lon_range[1],
        )
    return query_params


def _set_footprint(
    q: dict,
    minlat: float | str = "",
    maxlat: float | str = "",
    minlon: float | str = "",
    maxlon: float | str = "",
) -> None:
    q.update(
        {
            "query.footprint.minlat": minlat,
            "query.footprint.maxlat": maxlat,
            "query.footprint.minlon": minlon,
            "query.footprint.maxlon": maxlon,
        }
    )
