from earthcare_downloader.api import download, search
from earthcare_downloader.version import __version__

__all__ = ["__version__", "download", "search"]
