"""Routes package for SelfMemory server."""
