FIELD_TYPE_MAP = {"varchar": str, "string": str}
