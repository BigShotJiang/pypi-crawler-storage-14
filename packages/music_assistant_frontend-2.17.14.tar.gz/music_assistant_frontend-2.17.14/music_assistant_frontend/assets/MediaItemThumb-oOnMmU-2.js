import{_ as a,ce as s}from"./index-CFcIX8RO.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
