const s=["home","search","artists","albums","tracks","playlists","audiobooks","podcasts","radios","browse","settings"],o="syncgroup_";export{s as D,o as S};
