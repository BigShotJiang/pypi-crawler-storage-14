# Changelog
Todas as alterações relevantes deste projeto serão documentadas neste arquivo.

O formato segue as recomendações de [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/).

## [1.0.1] - 2025-01-27
### Fixado
- Dependência adicional necessária para o SAGE Edu.
- Correção no `pyproject.toml` para gerar wheel corretamente.
- Ajustes na estrutura do pacote para publicação no PyPI.

## [1.0.0] - 2025-01-26
### Adicionado
- Primeira publicação do módulo `akademy_company`.
- Estrutura inicial do SAGE Edu.
