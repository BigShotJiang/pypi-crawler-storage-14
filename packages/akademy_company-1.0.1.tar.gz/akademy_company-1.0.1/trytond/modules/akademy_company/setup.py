entry_points="""
    [trytond.modules]
    akademy_company = trytond.modules.akademy_company
    """

