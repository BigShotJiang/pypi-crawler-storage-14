"""
Legacy module for presets.

This module contains legacy model classes.
"""

# Note: These are legacy model files with various names,
# will import them as modules rather than individual classes
# since most seem to be function-based rather than class-based

__all__ = []
