from .generic import JaxMLPRegressor, JaxMLPClassifier

__all__ = [
    'JaxMLPRegressor',
    'JaxMLPClassifier'
]
