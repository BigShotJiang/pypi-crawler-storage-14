"""
Visualization tools for NIRS data analysis.
"""

__all__ = []
