"""Splitter controllers.

Controllers for data splitting operators.
"""

from .split import *

__all__ = []
