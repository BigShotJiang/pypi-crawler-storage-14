Please briefly describe your problem and what output you expect.

Please include a [minimal reprex](https://github.com/jennybc/reprex#what-is-a-reprex). The goal of a reprex is to make it as easy as possible for me to recreate your problem so that I can fix it.

Delete these instructions once you have read them.

---

Brief description of the problem

``` r
# insert reprex here
```
