import compileTS from "./src/js/scripts/compileTs";

compileTS("./dist/js/schema", `./src/js/types.ts`);
