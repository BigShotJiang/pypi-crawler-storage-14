=====
Usage
=====

To use the Read Structure plug-in in a project::

    import read_structure_step
