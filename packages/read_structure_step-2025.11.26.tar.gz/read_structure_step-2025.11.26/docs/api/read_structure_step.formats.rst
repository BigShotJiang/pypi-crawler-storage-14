read\_structure\_step.formats package
=====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   read_structure_step.formats.cif
   read_structure_step.formats.mol2
   read_structure_step.formats.mop
   read_structure_step.formats.openbabel_io
   read_structure_step.formats.sdf
   read_structure_step.formats.smi
   read_structure_step.formats.xyz

Submodules
----------

read\_structure\_step.formats.registries module
-----------------------------------------------

.. automodule:: read_structure_step.formats.registries
   :members:
   :undoc-members:
   :show-inheritance:

read\_structure\_step.formats.which module
------------------------------------------

.. automodule:: read_structure_step.formats.which
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: read_structure_step.formats
   :members:
   :undoc-members:
   :show-inheritance:
