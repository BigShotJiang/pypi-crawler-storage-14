read\_structure\_step.formats.mol2 package
==========================================

Submodules
----------

read\_structure\_step.formats.mol2.mol2 module
----------------------------------------------

.. automodule:: read_structure_step.formats.mol2.mol2
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: read_structure_step.formats.mol2
   :members:
   :undoc-members:
   :show-inheritance:
