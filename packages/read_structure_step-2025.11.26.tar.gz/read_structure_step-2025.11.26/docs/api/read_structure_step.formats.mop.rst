read\_structure\_step.formats.mop package
=========================================

Submodules
----------

read\_structure\_step.formats.mop.find\_mopac module
----------------------------------------------------

.. automodule:: read_structure_step.formats.mop.find_mopac
   :members:
   :undoc-members:
   :show-inheritance:

read\_structure\_step.formats.mop.obabel module
-----------------------------------------------

.. automodule:: read_structure_step.formats.mop.obabel
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: read_structure_step.formats.mop
   :members:
   :undoc-members:
   :show-inheritance:
