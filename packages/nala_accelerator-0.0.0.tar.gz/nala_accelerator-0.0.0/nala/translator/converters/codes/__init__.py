magnetic_orders = {"Dipole": 0, "Quadrupole": 1, "Sextupole": 2, "Octupole": 3, "SBend": 0, "RBend": 0}
