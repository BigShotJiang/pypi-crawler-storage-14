from .baseModels import IgnoreExtra


class LightingElement(IgnoreExtra):
    """Lighting info model."""
