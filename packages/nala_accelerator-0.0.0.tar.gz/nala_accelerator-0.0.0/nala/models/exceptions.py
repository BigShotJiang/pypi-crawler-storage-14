class LatticeError(Exception):
    pass
