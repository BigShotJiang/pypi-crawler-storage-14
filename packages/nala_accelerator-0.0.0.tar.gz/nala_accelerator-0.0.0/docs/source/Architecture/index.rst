Architecture
============

This section describes the architecture of accelerator components and lattices.

.. toctree::
   :maxdepth: 2

   Element
   Lattice

