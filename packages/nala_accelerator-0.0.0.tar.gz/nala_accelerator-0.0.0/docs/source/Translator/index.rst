Translator
==========

Handles the translation layer between for importing and exporting to different formats.

.. toctree::
   :maxdepth: 1

   Fields

