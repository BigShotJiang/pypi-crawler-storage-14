# 2401477

A lightweight Python package for basic unit conversions.

## Installation

```
pip install 2401477
```

## Usage

```python
import 2401477 as conv

print(conv.km_to_miles(5))
print(conv.c_to_f(30))
```
