def km_to_miles(km: float) -> float:
    return km * 0.621371

def miles_to_km(miles: float) -> float:
    return miles / 0.621371
