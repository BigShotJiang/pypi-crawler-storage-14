from package_2401477 import km_to_miles

def test_km_to_miles():
    assert round(km_to_miles(1), 2) == 0.62
