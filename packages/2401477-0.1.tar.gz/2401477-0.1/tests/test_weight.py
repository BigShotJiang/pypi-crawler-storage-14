from package_2401477 import kg_to_lb

def test_kg_to_lb():
    assert round(kg_to_lb(1), 2) == 2.20
