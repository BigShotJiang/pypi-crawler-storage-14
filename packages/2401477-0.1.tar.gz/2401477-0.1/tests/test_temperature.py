from package_2401477  import c_to_f

def test_c_to_f():
    assert c_to_f(0) == 32
