from setuptools import setup
setup(
  name ='2401477',
  version='0.1',
  authors='Dinesh Bist',
  install_requires=[],

)

