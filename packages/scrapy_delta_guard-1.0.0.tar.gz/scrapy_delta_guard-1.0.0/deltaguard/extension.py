import logging
import csv
import io
import tempfile
import os
from collections import defaultdict
from importlib import import_module
from scrapy import signals
from scrapy.exceptions import NotConfigured

logger = logging.getLogger(__name__)

class DeltaGuard:
    """
    A Scrapy extension to monitor data drift by comparing scraped items to
    database records, with configurable thresholds and alerting.
    """
    def __init__(self, crawler):
        self.stats = crawler.stats
        self.settings = crawler.settings
        self.crawler = crawler

        # Core settings
        self.batch_size = self.settings.getint("DELTA_GUARD_BATCH_SIZE", 50)
        self.default_threshold = self.settings.get("DELTA_GUARD_DEFAULT_THRESHOLD", 5)
        self.stop_on_high_delta = self.settings.getbool("DELTA_GUARD_STOP_SPIDER_ON_HIGH_DELTA", True)

        # Alerting settings
        self.jira_func_path = self.settings.get("DELTA_GUARD_JIRA_FUNC")
        self.slack_webhook = self.settings.get("DELTA_GUARD_SLACK_WEBHOOK")
        self.logs_on_slack = self.settings.getbool("DELTA_GUARD_LOGS_ON_SLACK", False)
        self.slack_bot_token = self.settings.get("DELTA_GUARD_SLACK_BOT_TOKEN")
        self.slack_channel_id = self.settings.get("DELTA_GUARD_SLACK_CHANNEL_ID")

        # Configurable None handling
        self.db_none_is_delta = self.settings.getbool('DELTA_GUARD_DB_NONE_IS_DELTA', False)
        self.spider_none_is_delta = self.settings.getbool('DELTA_GUARD_SPIDER_NONE_IS_DELTA', False)

        # Parse the field configurations
        self.raw_fields_config = self.settings.getlist("DELTA_GUARD_FIELDS_CONFIG")
        self.fields_config = [fc for fc in (self._parse_field_config(fc) for fc in self.raw_fields_config) if fc is not None]

        # Internal state
        self.delta_batch = []
        self.delta_logs = []
        self.item_count = 0
        self.alert_triggered = False
        self._load_alert_functions()

        logger.debug(f"DeltaGuard initialized with batch_size={self.batch_size}, default_threshold={self.default_threshold}")

    def _parse_field_config(self, field_conf):
        name = field_conf.get('name')
        if not name:
            logger.warning(f"DeltaGuard: Skipping invalid field config (missing 'name'): {field_conf}")
            return None

        threshold = field_conf.get('threshold', self.default_threshold)
        threshold_val = self.default_threshold

        try:
            if isinstance(threshold, str) and '%' in threshold:
                threshold_val = float(threshold.strip().replace('%', ''))
            else:
                threshold_val = float(threshold)
        except (ValueError, TypeError):
            logger.warning(f"DeltaGuard: Invalid threshold format '{threshold}' for field '{name}'. Using default.")
            threshold_val = self.default_threshold
            if isinstance(threshold_val, str):
                threshold_val = float(threshold_val.strip().replace('%', ''))

        if threshold_val > 1:
            threshold_val /= 100.0

        logger.debug(f"Field config: name={name}, threshold={threshold_val}")
        return {
            'name': name,
            'db_var': field_conf.get('db_var', name),
            'spider_var': field_conf.get('spider_var', name),
            'threshold': threshold_val,
        }

    @classmethod
    def from_crawler(cls, crawler):
        if not crawler.settings.getbool("DELTA_GUARD_ENABLED"):
            raise NotConfigured("DeltaGuard is not enabled.")
        ext = cls(crawler)
        setattr(crawler.spider, 'delta_guard_high_delta_detected', False)
        crawler.signals.connect(ext.item_scraped, signal=signals.item_scraped)
        crawler.signals.connect(ext.spider_closed, signal=signals.spider_closed)
        logger.info("DeltaGuard extension enabled and configured ✅.")
        return ext

    def item_scraped(self, item, response, spider):
        db_item = item.get('db_item')
        if not db_item:
            logger.debug("DeltaGuard: No db_item attached; skipping deltas.")
            return

        self.item_count += 1
        item_deltas = self._compare_fields(item, db_item)
        if item_deltas:
            self.delta_batch.append(item_deltas)
        logger.debug(f"DeltaGuard: Item {self.item_count} processed, deltas: {len(item_deltas)}")

        if self.item_count >= self.batch_size:
            self._process_batch(spider)

    def _compare_fields(self, item, db_item):
        deltas = []
        db_item_id = self._get_db_item_id(db_item)
        for field_conf in self.fields_config:
            db_var, spider_var = field_conf["db_var"], field_conf["spider_var"]
            field_name = field_conf["name"]
            old_value = self._get_db_item_value(db_item, db_var)
            new_value = item.get(spider_var)

            if old_value is None and new_value is None:
                continue
            if old_value is None and new_value is not None and not self.db_none_is_delta:
                continue
            if new_value is None and old_value is not None and not self.spider_none_is_delta:
                continue

            if str(old_value) != str(new_value):
                deltas.append({"field": field_name})
                self.stats.inc_value(f'deltaguard/delta_detected/{field_name}')
                logger.info(f"DeltaGuard: Delta for item {self.item_count} field '{field_name}': '{old_value}' -> '{new_value}'")
                self.delta_logs.append({
                    'item_count': self.item_count,
                    'db_item_id': db_item_id,
                    'field': field_name,
                    'old_value': old_value,
                    'new_value': new_value
                })
        return deltas

    def _process_batch(self, spider):
        logger.debug(f"DeltaGuard: Processing batch of {self.batch_size}")
        if not self.delta_batch:
            self._reset_batch()
            return

        fields_summary = defaultdict(int)
        for item_deltas in self.delta_batch:
            for delta in item_deltas:
                fields_summary[delta['field']] += 1

        details = ', '.join([f"{field} ({count})" for field, count in fields_summary.items()])
        logger.info(f"DeltaGuard: Batch delta summary: {details}")

        exceeded_fields = []
        for field_conf in self.fields_config:
            field_name = field_conf['name']
            threshold = field_conf['threshold']
            threshold_count = int(self.batch_size * threshold)
            if threshold_count == 0 and threshold > 0:
                threshold_count = 1
            delta_count = fields_summary.get(field_name, 0)
            if delta_count >= threshold_count:
                delta_percentage = delta_count / self.batch_size
                exceeded_fields.append({
                    'field': field_name,
                    'count': delta_count,
                    'percentage': delta_percentage,
                    'threshold': threshold
                })

        if exceeded_fields and not self.alert_triggered:
            self.alert_triggered = True
            for field_info in exceeded_fields:
                logger.warning(
                    f"DeltaGuard: HIGH DELTA on field '{field_info['field']}'. "
                    f"Found {field_info['count']} deltas ({field_info['percentage']:.0%}), "
                    f"threshold {field_info['threshold']:.0%}."
                )
            self._trigger_alerts(spider, exceeded_fields)
            if self.stop_on_high_delta:
                setattr(spider, 'delta_guard_high_delta_detected', True)
                exceeded_field_names = ', '.join([f['field'] for f in exceeded_fields])
                logger.warning(f"DeltaGuard: Set high delta flag on spider; stopping. Fields: {exceeded_field_names}")
                self.stats.set_value('finish_reason', f'deltaguard_shutdown_multiple_fields')
                self.crawler.engine.close_spider(spider, reason=f'deltaguard_shutdown_multiple_fields')

        self._reset_batch()

    def _reset_batch(self):
        logger.debug("DeltaGuard: Resetting batch state and clearing logs")
        self.item_count = 0
        self.delta_batch.clear()
        self.delta_logs.clear()

    def spider_closed(self, spider, reason):
        logger.debug(f"DeltaGuard: Spider closed, reason: {reason}. Processing final batch if items remain.")
        if self.item_count > 0:
            self._process_batch(spider)

    def _load_alert_functions(self):
        self.jira_func = None
        if self.jira_func_path:
            try:
                module_path, func_name = self.jira_func_path.rsplit('.', 1)
                module = import_module(module_path)
                self.jira_func = getattr(module, func_name)
                logger.debug(f"DeltaGuard: Jira function loaded: {self.jira_func_path}")
            except (ImportError, AttributeError) as e:
                logger.error(f"DeltaGuard: Could not load Jira function from '{self.jira_func_path}': {e}")

    def _trigger_alerts(self, spider, exceeded_fields):
        # Compose alert summary message
        field_summaries = [
            f"• *{f['field']}*: {f['count']} deltas ({f['percentage']:.0%}) - threshold {f['threshold']:.0%}"
            for f in exceeded_fields
        ]
        base_message = (
            f":alert: *DeltaGuard Alert* for Spider: `{spider.name}`\n\n"
            f"*Fields exceeding delta thresholds:*\n" + "\n".join(field_summaries)
        )

        jira_ticket_info = None
        csv_file_path = None
        try:
            if self.logs_on_slack and self.delta_logs:
                fields = [f['field'] for f in exceeded_fields]
                filtered_logs = [log for log in self.delta_logs if log['field'] in fields]
                if filtered_logs:
                    csv_content = self._generate_csv(filtered_logs)
                    self._send_csv_to_slack(spider.name, csv_content)

                    # Write CSV to temp file for Jira attachment
                    with tempfile.NamedTemporaryFile(mode='w+', suffix='.csv', delete=False) as tmp_file:
                        tmp_file.write(csv_content)
                        csv_file_path = tmp_file.name

            if self.jira_func:
                exceeded_field_names = ', '.join([f['field'] for f in exceeded_fields])
                summary = f"High Delta Rate on fields: {exceeded_field_names} in Spider: {spider.name}"

                # Pass attachment path only if file created
                attachments = [csv_file_path] if csv_file_path else None
                jira_ticket_info = self.jira_func(spider, summary, base_message, attachment_paths=attachments)
                logger.info(f"DeltaGuard: Jira ticket created: {jira_ticket_info}")
                self.stats.inc_value('deltaguard/alerts_sent/jira')
        except Exception as e:
            logger.error(f"DeltaGuard: Failed to execute Jira function: {e}")
        finally:
            if csv_file_path:
                try:
                    os.unlink(csv_file_path)
                except Exception as e:
                    logger.warning(f"DeltaGuard: Failed to delete temp CSV file: {e}")

        # Append Jira ticket info to Slack message if exists
        slack_message = base_message
        if jira_ticket_info:
            slack_message += f"\n\nJira Ticket: {jira_ticket_info}"

        if self.slack_webhook:
            try:
                import requests
                requests.post(self.slack_webhook, json={"text": slack_message}, headers={"Content-Type": "application/json"})
                logger.debug("DeltaGuard: Slack alert sent")
                self.stats.inc_value('deltaguard/alerts_sent/slack')
            except Exception as e:
                logger.error(f"DeltaGuard: Failed to send Slack notification: {e}")

    def _generate_csv(self, delta_logs):
        output = io.StringIO()
        sorted_logs = sorted(delta_logs, key=lambda x: x['field'])
        fieldnames = ['db_item_id', 'field', 'old_value', 'new_value']
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        for log in sorted_logs:
            writer.writerow({
                'db_item_id': log['db_item_id'],
                'field': log['field'],
                'old_value': log['old_value'],
                'new_value': log['new_value']
            })
        logger.debug("DeltaGuard: CSV log generated")
        return output.getvalue()

    def _send_csv_to_slack(self, spider_name, csv_content):
        try:
            import requests
            if not self.slack_bot_token or not self.slack_channel_id:
                logger.warning("DeltaGuard: Missing bot token or channel ID. Cannot upload CSV.")
                return
            
            headers = {'Authorization': f'Bearer {self.slack_bot_token}'}
            filename = f'deltaguard_{spider_name}_deltas.csv'

            upload_url_resp = requests.post(
                'https://slack.com/api/files.getUploadURLExternal',
                headers={**headers, 'Content-Type': 'application/x-www-form-urlencoded'},
                data={'filename': filename, 'length': len(csv_content.encode('utf-8'))}
            )
            upload_data = upload_url_resp.json()
            if not upload_data.get('ok'):
                error = upload_data.get('error', 'Unknown error')
                logger.error(f"DeltaGuard: Failed to get upload URL: {error}")
                return
            
            upload_url = upload_data['upload_url']
            file_id = upload_data['file_id']

            upload_resp = requests.post(
                upload_url,
                data=csv_content.encode('utf-8'),
                headers={'Content-Type': 'text/csv'}
            )
            if upload_resp.status_code != 200:
                logger.error(f"DeltaGuard: Failed to upload CSV: {upload_resp.text}")
                return
            
            complete_resp = requests.post(
                'https://slack.com/api/files.completeUploadExternal',
                headers={
                    'Authorization': f'Bearer {self.slack_bot_token}',
                    'Content-Type': 'application/json'
                },
                json={
                    'files': [{'id': file_id, 'title': filename}],
                    'channel_id': self.slack_channel_id,
                    'initial_comment': f'📊 DeltaGuard detailed delta logs for spider: `{spider_name}`'
                }
            )
            complete_data = complete_resp.json()
            if complete_data.get('ok'):
                logger.info("DeltaGuard: Delta logs CSV file uploaded to Slack successfully.")
            else:
                error = complete_data.get('error', 'Unknown error')
                logger.error(f"DeltaGuard: Failed to complete upload: {error}")

        except Exception as e:
            logger.error(f"DeltaGuard: Failed to send CSV to Slack: {e}")

    def _get_db_item_value(self, db_item, key):
        if isinstance(db_item, dict):
            return db_item.get(key, None)
        return getattr(db_item, key, None)

    def _get_db_item_id(self, db_item):
        return self._get_db_item_value(db_item, 'id') or 'N/A'
