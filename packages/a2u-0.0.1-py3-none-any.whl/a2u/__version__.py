#
# BSD 3-Clause License

"""A2U."""

__version__ = "0.0.1"
