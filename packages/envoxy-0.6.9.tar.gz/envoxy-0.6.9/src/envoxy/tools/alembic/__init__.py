"""Framework-shipped alembic integration helpers and packaged assets.

This package contains the `alembic.ini` and the `alembic/` script folder used
by services that prefer to reuse the framework alembic configuration.
"""

__all__ = []
