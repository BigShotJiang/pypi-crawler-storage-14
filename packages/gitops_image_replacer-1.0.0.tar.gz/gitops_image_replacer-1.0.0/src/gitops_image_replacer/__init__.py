"""
gitops-image-replacer

Automated container image updates for GitOps repositories via GitHub API.
"""

__version__ = "1.0.0"
__author__ = "Simon Lauger"
__email__ = "simon@lauger.de"
