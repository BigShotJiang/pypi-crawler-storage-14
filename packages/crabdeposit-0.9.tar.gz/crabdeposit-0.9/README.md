# crabdeposit
A Python library for creating CRAB-compatible data deposits and interacting with CRAB programatically.
