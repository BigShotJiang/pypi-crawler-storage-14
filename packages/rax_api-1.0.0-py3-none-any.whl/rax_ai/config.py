"""Configuration and utilities for Rax AI SDK."""

import os
from typing import Optional


class Config:
    """Configuration class for Rax AI SDK."""
    
    DEFAULT_BASE_URL = "https://ai.raxcore.dev/api"
    DEFAULT_TIMEOUT = 30
    
    @classmethod
    def from_env(cls, api_key: Optional[str] = None) -> dict:
        """Create configuration from environment variables.
        
        Args:
            api_key: API key override
            
        Returns:
            Dictionary with configuration
            
        Environment Variables:
            RAX_AI_API_KEY: API key
            RAX_AI_BASE_URL: Base URL
            RAX_AI_TIMEOUT: Timeout in seconds
        """
        return {
            'api_key': api_key or os.getenv('RAX_AI_API_KEY'),
            'base_url': os.getenv('RAX_AI_BASE_URL', cls.DEFAULT_BASE_URL),
            'timeout': int(os.getenv('RAX_AI_TIMEOUT', cls.DEFAULT_TIMEOUT))
        }


def create_client_from_env(**kwargs):
    """Create RaxAI client from environment variables.
    
    Args:
        **kwargs: Override configuration
        
    Returns:
        RaxAI client instance
        
    Example:
        >>> client = create_client_from_env()
        >>> # or with overrides
        >>> client = create_client_from_env(timeout=60)
    """
    from .client import RaxAI
    
    config = Config.from_env()
    config.update(kwargs)
    
    if not config['api_key']:
        raise ValueError("API key not found. Set RAX_AI_API_KEY environment variable or pass api_key parameter.")
    
    return RaxAI(**config)


def create_async_client_from_env(**kwargs):
    """Create AsyncRaxAI client from environment variables.
    
    Args:
        **kwargs: Override configuration
        
    Returns:
        AsyncRaxAI client instance
    """
    try:
        from .async_client import AsyncRaxAI
    except ImportError:
        raise ImportError("aiohttp is required for async client. Install with: pip install aiohttp")
    
    config = Config.from_env()
    config.update(kwargs)
    
    if not config['api_key']:
        raise ValueError("API key not found. Set RAX_AI_API_KEY environment variable or pass api_key parameter.")
    
    return AsyncRaxAI(**config)
