"""Async Rax AI Python client."""

import asyncio
import json
from typing import Dict, List, Optional, AsyncIterator, Any
try:
    import aiohttp
except ImportError:
    aiohttp = None

from .types import ChatResponse, Model, UsageStats
from .client import RaxAIError


class AsyncRaxAI:
    """Async Rax AI Python client."""
    
    def __init__(
        self, 
        api_key: str, 
        base_url: str = "https://ai.raxcore.dev/api",
        timeout: int = 30
    ):
        """Initialize async Rax AI client.
        
        Args:
            api_key: Your Rax AI API key
            base_url: API base URL
            timeout: Request timeout in seconds
            
        Raises:
            ImportError: If aiohttp is not installed
        """
        if aiohttp is None:
            raise ImportError("aiohttp is required for async client. Install with: pip install aiohttp")
        
        if not api_key:
            raise ValueError("API key is required")
        
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session = None
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self._ensure_session()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
    
    async def _ensure_session(self):
        """Ensure aiohttp session exists."""
        if self._session is None or self._session.closed:
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json',
                'User-Agent': 'rax-ai-python-async/1.0.0',
                'X-Platform': 'rax-ai-python-async'
            }
            self._session = aiohttp.ClientSession(
                headers=headers,
                timeout=self.timeout
            )
    
    async def chat(
        self,
        model: str,
        messages: List[Dict[str, str]],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        user: Optional[str] = None,
        **kwargs
    ) -> ChatResponse:
        """Create a chat completion asynchronously.
        
        Args:
            model: Model to use
            messages: List of chat messages
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            user: User identifier
            **kwargs: Additional parameters
            
        Returns:
            ChatResponse with the completion
        """
        if not model:
            raise ValueError("Model is required")
        if not messages:
            raise ValueError("Messages are required")
        
        payload = {
            'model': model,
            'messages': messages
        }
        
        if max_tokens is not None:
            payload['max_tokens'] = max_tokens
        if temperature is not None:
            payload['temperature'] = temperature
        if top_p is not None:
            payload['top_p'] = top_p
        if user is not None:
            payload['user'] = user
        
        payload.update(kwargs)
        
        return await self._request('POST', '/v1/chat/completions', json=payload)
    
    async def get_models(self) -> Dict[str, List[Model]]:
        """Get available models asynchronously."""
        return await self._request('GET', '/v1/models')
    
    async def get_usage(
        self, 
        start_date: Optional[str] = None, 
        end_date: Optional[str] = None
    ) -> UsageStats:
        """Get usage statistics asynchronously."""
        params = {}
        if start_date:
            params['start_date'] = start_date
        if end_date:
            params['end_date'] = end_date
            
        return await self._request('GET', '/v1/usage', params=params)
    
    async def validate_key(self) -> bool:
        """Validate the API key asynchronously."""
        try:
            await self.get_models()
            return True
        except RaxAIError:
            return False
    
    async def close(self):
        """Close the aiohttp session."""
        if self._session and not self._session.closed:
            await self._session.close()
    
    async def _request(self, method: str, endpoint: str, **kwargs) -> Any:
        """Make async HTTP request with retry logic."""
        await self._ensure_session()
        url = f"{self.base_url}{endpoint}"
        last_error = None
        
        for attempt in range(3):
            try:
                async with self._session.request(method, url, **kwargs) as response:
                    try:
                        data = await response.json()
                    except json.JSONDecodeError:
                        text = await response.text()
                        data = {
                            "error": {
                                "message": f"Invalid JSON response: {text[:100]}",
                                "type": "parse_error"
                            }
                        }
                    
                    if not response.ok:
                        error_info = data.get('error', {})
                        message = error_info.get('message', f'HTTP {response.status}')
                        error_type = error_info.get('type', 'api_error')
                        
                        error = RaxAIError(message, response.status, error_type)
                        
                        # Don't retry client errors
                        if 400 <= response.status < 500:
                            raise error
                        
                        # Retry server errors
                        if attempt < 2:
                            await asyncio.sleep(2 ** attempt)
                            last_error = error
                            continue
                        
                        raise error
                    
                    return data
                    
            except aiohttp.ClientError as e:
                error = RaxAIError(f"Client error: {str(e)}", 0, "client_error")
                if attempt < 2:
                    await asyncio.sleep(2 ** attempt)
                    last_error = error
                    continue
                raise error
        
        raise last_error or RaxAIError("Max retries exceeded", 0, "network_error")
