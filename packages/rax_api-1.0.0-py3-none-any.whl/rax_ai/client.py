"""Rax AI Python client."""

import json
import time
from typing import Dict, List, Optional, Iterator, Any, Union
import requests

from .types import (
    ChatRequest, ChatResponse, Model, UsageStats, APIError
)


class RaxAIError(Exception):
    """Exception raised for Rax AI API errors."""
    
    def __init__(self, message: str, status_code: int = 0, error_type: str = "unknown"):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_type = error_type
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary."""
        return {
            "message": self.message,
            "status_code": self.status_code,
            "error_type": self.error_type
        }


class RaxAI:
    """Rax AI Python client."""
    
    def __init__(
        self, 
        api_key: str, 
        base_url: str = "https://ai.raxcore.dev/api",
        timeout: int = 30
    ):
        """Initialize Rax AI client.
        
        Args:
            api_key: Your Rax AI API key
            base_url: API base URL (default: https://ai.raxcore.dev/api)
            timeout: Request timeout in seconds (default: 30)
        """
        if not api_key:
            raise ValueError("API key is required")
        
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'User-Agent': 'rax-ai-python/1.0.0',
            'X-Platform': 'rax-ai-python'
        })
    
    def chat(
        self,
        model: str,
        messages: List[Dict[str, str]],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        user: Optional[str] = None,
        **kwargs
    ) -> ChatResponse:
        """Create a chat completion.
        
        Args:
            model: Model to use (e.g., 'rax-4.0')
            messages: List of chat messages
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0-2.0)
            top_p: Nucleus sampling parameter
            user: User identifier
            **kwargs: Additional parameters
            
        Returns:
            ChatResponse with the completion
            
        Raises:
            RaxAIError: If the API request fails
            ValueError: If required parameters are missing
        """
        if not model:
            raise ValueError("Model is required")
        if not messages:
            raise ValueError("Messages are required")
        
        # Validate messages structure
        for i, msg in enumerate(messages):
            if not isinstance(msg, dict):
                raise ValueError(f"Message {i} must be a dictionary")
            if 'role' not in msg or 'content' not in msg:
                raise ValueError(f"Message {i} must have 'role' and 'content' keys")
            if msg['role'] not in ['system', 'user', 'assistant']:
                raise ValueError(f"Message {i} role must be 'system', 'user', or 'assistant'")
        
        # Validate parameters
        if temperature is not None and not (0.0 <= temperature <= 2.0):
            raise ValueError("Temperature must be between 0.0 and 2.0")
        if top_p is not None and not (0.0 <= top_p <= 1.0):
            raise ValueError("Top_p must be between 0.0 and 1.0")
        if max_tokens is not None and max_tokens <= 0:
            raise ValueError("Max_tokens must be positive")
        
        payload = {
            'model': model,
            'messages': messages
        }
        
        if max_tokens is not None:
            payload['max_tokens'] = max_tokens
        if temperature is not None:
            payload['temperature'] = temperature
        if top_p is not None:
            payload['top_p'] = top_p
        if user is not None:
            payload['user'] = user
        
        # Add any additional kwargs
        payload.update(kwargs)
        
        return self._request('POST', '/v1/chat/completions', json=payload)
    
    def chat_stream(
        self,
        model: str,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> Iterator[str]:
        """Create a streaming chat completion.
        
        Args:
            model: Model to use
            messages: List of chat messages
            **kwargs: Additional parameters
            
        Yields:
            str: Streaming content chunks
            
        Note:
            Streaming implementation coming soon.
        """
        # TODO: Implement actual streaming
        yield "Streaming implementation coming soon..."
    
    def get_models(self) -> Dict[str, List[Model]]:
        """Get available models.
        
        Returns:
            Dictionary with 'data' key containing list of models
            
        Raises:
            RaxAIError: If the API request fails
        """
        return self._request('GET', '/v1/models')
    
    def get_usage(
        self, 
        start_date: Optional[str] = None, 
        end_date: Optional[str] = None
    ) -> UsageStats:
        """Get usage statistics.
        
        Args:
            start_date: Start date (YYYY-MM-DD format)
            end_date: End date (YYYY-MM-DD format)
            
        Returns:
            UsageStats with consumption data
            
        Raises:
            RaxAIError: If the API request fails
        """
        params = {}
        if start_date:
            params['start_date'] = start_date
        if end_date:
            params['end_date'] = end_date
            
        return self._request('GET', '/v1/usage', params=params)
    
    def validate_key(self) -> bool:
        """Validate the API key.
        
        Returns:
            bool: True if key is valid, False otherwise
        """
        try:
            self.get_models()
            return True
        except RaxAIError:
            return False
    
    def get_config(self) -> Dict[str, Any]:
        """Get current client configuration.
        
        Returns:
            Dictionary with client configuration
        """
        return {
            'base_url': self.base_url,
            'timeout': self.timeout,
            'api_key_set': bool(self.api_key)
        }
    
    def close(self) -> None:
        """Close the HTTP session."""
        if self._session:
            self._session.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Any:
        """Make HTTP request with retry logic.
        
        Args:
            method: HTTP method
            endpoint: API endpoint
            **kwargs: Additional request arguments
            
        Returns:
            Parsed JSON response
            
        Raises:
            RaxAIError: If request fails after retries
        """
        url = f"{self.base_url}{endpoint}"
        last_error = None
        
        for attempt in range(3):  # 3 retry attempts
            try:
                response = self._session.request(
                    method=method,
                    url=url,
                    timeout=self.timeout,
                    **kwargs
                )
                
                # Parse response
                try:
                    data = response.json()
                except json.JSONDecodeError:
                    data = {
                        "error": {
                            "message": f"Invalid JSON response: {response.text[:100]}",
                            "type": "parse_error"
                        }
                    }
                
                # Handle errors
                if not response.ok:
                    error_info = data.get('error', {})
                    message = error_info.get('message', f'HTTP {response.status_code}')
                    error_type = error_info.get('type', 'api_error')
                    
                    error = RaxAIError(message, response.status_code, error_type)
                    
                    # Don't retry client errors (4xx)
                    if 400 <= response.status_code < 500:
                        raise error
                    
                    # Retry server errors (5xx) and rate limits
                    if attempt < 2:  # Not the last attempt
                        wait_time = (2 ** attempt) + (attempt * 0.1)  # Jittered backoff
                        time.sleep(wait_time)
                        last_error = error
                        continue
                    
                    raise error
                
                return data
                
            except requests.exceptions.Timeout as e:
                error = RaxAIError(f"Request timeout after {self.timeout}s", 0, "timeout_error")
                if attempt < 2:
                    time.sleep(2 ** attempt)
                    last_error = error
                    continue
                raise error
                
            except requests.exceptions.ConnectionError as e:
                error = RaxAIError(f"Connection error: {str(e)}", 0, "connection_error")
                if attempt < 2:
                    time.sleep(2 ** attempt)
                    last_error = error
                    continue
                raise error
                
            except requests.exceptions.RequestException as e:
                error = RaxAIError(f"Request error: {str(e)}", 0, "network_error")
                if attempt < 2:
                    time.sleep(2 ** attempt)
                    last_error = error
                    continue
                raise error
        
        # This should never be reached, but just in case
        raise last_error or RaxAIError("Max retries exceeded", 0, "network_error")
