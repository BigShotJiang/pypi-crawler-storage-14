# sonolus.script.metadata

::: sonolus.script.metadata
