# random
Supported functions in the Python standard library `random` module.

::: doc_stubs.random
