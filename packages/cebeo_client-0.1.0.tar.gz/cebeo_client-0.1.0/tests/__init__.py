"""Tests for cebeo-client."""
