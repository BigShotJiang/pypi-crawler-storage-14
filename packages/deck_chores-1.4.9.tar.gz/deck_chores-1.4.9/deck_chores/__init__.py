from importlib import metadata

__version__ = metadata.version("deck-chores")

__all__ = ("__version__",)
