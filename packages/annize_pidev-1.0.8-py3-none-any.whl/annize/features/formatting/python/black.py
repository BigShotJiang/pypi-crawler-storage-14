# SPDX-FileCopyrightText: © 2025 Josef Hahn
# SPDX-License-Identifier: AGPL-3.0-only
"""
Python code formatting supported by Black.
"""
import subprocess

import annize.features.base
import annize.fs


class FormatCode:

    def __init__(self, *, source_dir: annize.fs.TInputPath, line_length: int = 120):
        self.__source_dir = source_dir
        self.__line_length = line_length

    def __call__(self, *args, **kwargs):
        subprocess.check_call(
            (
                "black",
                "--line-length",
                str(self.__line_length),
                annize.features.base.project_directory()(self.__source_dir),
            )
        )
