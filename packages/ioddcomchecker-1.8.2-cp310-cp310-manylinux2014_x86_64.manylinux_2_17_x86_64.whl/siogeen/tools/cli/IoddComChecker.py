# coding=utf-8
'''
Copyright (C) 2023-2025 Siogeen

Created on 4.1.2023

@author: Reimund Renner
'''

import argparse

def get_parser():
    """Get CLI parser"""
    ret = argparse.ArgumentParser(
        description='Check for IO-Link masters and devices',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''Examples:
  python -m siogeen.tools.cli.IoddComChecker
  python -m siogeen.tools.cli.IoddComChecker -a 10.0.0.17 -a 10.0.0.19 --auto -s ETH''')
    ret.add_argument("-a", "--address", action='append',
                        help="specify one or more master addresses (default all)")
    ret.add_argument("--auto", action='store_true',
                        help="activate master ports if all are disabled")
    ret.add_argument("-s", "--select",
                        help="select specific master types: ETH (ethernet) or USB")
    ret.add_argument("--verbose", default=2, help="verbosity 0..3")
    ret.add_argument("--version", action='store_true',
        help="print version")

    return ret

if __name__ == '__main__':
    parser = get_parser()
    args = parser.parse_args()
    #args = parser.parse_args(['--auto'])
    #args = parser.parse_args(['-a', '/dev/ttyUSB0'])
    #args = parser.parse_args(['-a', '192.168.178.77'])
    #args = parser.parse_args(['-a', '192.168.178.77', '-a', '192.168.178.73'])
    #args = parser.parse_args(['-a', '192.168.178.77', '--auto'])

    from siogeen.tools import IoddComChecker

    if args.version:
        print(f"IoddComChecker {IoddComChecker.__version__}")
    else:
        IoddComChecker.check(args.address, args.auto, verbose=args.verbose)
