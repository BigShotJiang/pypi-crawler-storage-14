import{_ as a,cu as s}from"./index-Czc5w9YN.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
