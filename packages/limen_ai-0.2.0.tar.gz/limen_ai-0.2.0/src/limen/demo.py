"""Legacy demo helpers used by the CLI entrypoints."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Tuple

from .core import Atom, Constant, KnowledgeBase, Predicate, TruthAssignment, FormulaNode, Operator, WeightedFormula
from .truth_functions import ConstantTruthFunction
from .semantics import evaluate_formula
from .deduction import generate_atoms
from .inference import ImportanceSampler
from .sampling import make_score_guided_proposal, rule_activation_trace
from .explanations import summarize_rule_contributions, format_explanations
from .printing import format_kb
from .storage import load_knowledge_base, save_knowledge_base


def build_demo_kb() -> Tuple[KnowledgeBase, Dict[str, Atom]]:
    kb = KnowledgeBase()
    failed = Predicate(name="failedLogin", arity=1, description="Failed login count")
    suspicious = Predicate(name="suspiciousHost", arity=1)
    alert = Predicate(name="raiseAlert", arity=1)
    failed_on = Predicate(name="failedLoginOn", arity=2, description="User failed on host")
    lateral = Predicate(name="lateralMove", arity=2, description="Potential lateral move")
    escalates = Predicate(name="escalates", arity=2, description="Escalation relation to learn")
    user = Constant("alice")
    analyst = Constant("bob")
    hosts = [Constant(name) for name in ("server01", "srv3", "srv4", "srv6")]
    primary_host = hosts[0]

    for predicate in (failed, suspicious, alert, failed_on, lateral, escalates):
        kb.add_predicate(predicate)
    for constant in (user, analyst, *hosts):
        kb.add_constant(constant)

    failed_atom = Atom(predicate=failed, arguments=(user,))
    suspicious_atom = Atom(predicate=suspicious, arguments=(primary_host,))
    alert_atom = Atom(predicate=alert, arguments=(user,))

    antecedent = FormulaNode(
        operator=Operator.AND,
        children=(
            FormulaNode.atom_node(failed_atom),
            FormulaNode.atom_node(suspicious_atom),
        ),
    )
    rule = FormulaNode(
        operator=Operator.IMPLIES,
        children=(antecedent, FormulaNode.atom_node(alert_atom)),
    )
    kb.add_formula(WeightedFormula(formula=rule, weight=2.0, name="cyber_rule"))

    kb.register_truth_function("failedLogin", ConstantTruthFunction(0.9))
    kb.register_truth_function("suspiciousHost", ConstantTruthFunction(0.8))
    kb.register_truth_function("raiseAlert", ConstantTruthFunction(0.3))
    atoms = {
        "failed": failed_atom,
        "suspicious": suspicious_atom,
        "alert": alert_atom,
    }
    return kb, atoms


def build_induction_assignment(kb: KnowledgeBase) -> TruthAssignment:
    assignment = TruthAssignment()

    def set_truth(pred: str, args: Tuple[str, str], value: float) -> None:
        predicate = kb.get_predicate(pred)
        consts = tuple(kb.get_constant(name) for name in args)
        assignment.set(Atom(predicate, consts), value)

    set_truth("failedLoginOn", ("alice", "srv3"), 0.95)
    set_truth("failedLoginOn", ("bob", "srv4"), 0.35)
    set_truth("lateralMove", ("srv3", "srv6"), 0.9)
    set_truth("lateralMove", ("srv4", "srv6"), 0.2)
    return assignment


def run_inference_demo(kb: KnowledgeBase, atoms: Dict[str, Atom], base_assignment: TruthAssignment) -> None:
    proposal = make_score_guided_proposal(kb, temperature=0.05)
    sampler = ImportanceSampler(kb, proposal)
    expectation, traces = sampler.estimate(lambda a: a.get(atoms["alert"]), num_samples=64)
    print(f"Estimated alert degree via importance sampling: {expectation:.3f}")

    example_trace = traces[0]
    print("Sampled assignment (first trace):")
    for atom, value in example_trace.assignment.values.items():
        print(f"  {atom}: {value:.3f}")

    print("Rule activations for first trace:")
    for rule, activation in example_trace.activations.items():
        print(f"  {rule}: {activation:.3f}")

    print("Base assignment rule activations:")
    for rule, activation in rule_activation_trace(kb, base_assignment).items():
        print(f"  {rule}: {activation:.3f}")

    explanations = summarize_rule_contributions(kb, base_assignment)
    print("\nTop rule contributions:")
    print(format_explanations(explanations))


def run_induction_demo(kb: KnowledgeBase) -> None:
    print("\nRunning inductive rule discovery (escalates)...")
    assignment = build_induction_assignment(kb)
    labels = {
        "escalates": {
            "pos": [("alice", "srv6")],
            "neg": [("bob", "srv6")],
        }
    }
    kb.update_labels(
        labels,
        assignment=assignment,
        auto_induce=True,
        induction_config={
            "train_steps": 60,
            "learning_rate": 0.1,
            "min_strength": 0.5,
            "positive_threshold": 0.6,
            "min_positive_margin": 0.15,
            "max_clauses_per_head": 2,
        },
    )
    if kb.induced_clauses:
        print("Induced clauses:")
        for clause in kb.induced_clauses:
            print(f"  {clause}")
    else:
        print("  No clauses induced.")


def run_classic_demo() -> None:
    kb, atoms = build_demo_kb()
    assignment = kb.build_assignment_from_truth_functions()

    print("Knowledge Base Structure:")
    print(format_kb(kb))

    value = evaluate_formula(kb.formulas[0].formula, assignment)
    print(f"Rule satisfaction degree: {value:.3f}")

    deduction_threshold = 0.65
    derived_assignment, generated = generate_atoms(kb, assignment, threshold=deduction_threshold)
    if generated:
        print(f"\nGenerated atoms from rules (threshold={deduction_threshold}):")
        for fact in generated:
            print(
                f"  {fact.atom} raised from {fact.previous_value:.3f} to {fact.value:.3f} via {fact.rule_name}"
            )
    else:
        print(f"\nNo new atoms generated at threshold={deduction_threshold}.")

    run_inference_demo(kb, atoms, derived_assignment)

    db_path = Path("./demo_kb.sqlite")
    save_knowledge_base(kb, db_path)
    restored = load_knowledge_base(db_path)
    print(f"Restored KB with {len(restored.predicates)} predicates and {len(restored.formulas)} formulas")

    run_induction_demo(kb)


__all__ = [
    "build_demo_kb",
    "build_induction_assignment",
    "run_inference_demo",
    "run_induction_demo",
    "run_classic_demo",
]

