With Cluster on Demand you can spin up a cluster running Base Command Manager.

This package is a supporting package, for the full COD client packages check:
- cm-cluster-on-demand-aws
- cm-cluster-on-demand-azure
- cm-cluster-on-demand-oci
