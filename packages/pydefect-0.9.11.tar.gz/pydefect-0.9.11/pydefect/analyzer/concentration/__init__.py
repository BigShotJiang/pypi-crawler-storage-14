# -*- coding: utf-8 -*-
#  Copyright (c) 2023 Kumagai group.
