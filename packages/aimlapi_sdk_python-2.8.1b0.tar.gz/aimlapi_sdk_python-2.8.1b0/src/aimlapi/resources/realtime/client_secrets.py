from __future__ import annotations

from openai.resources.realtime.client_secrets import *  # noqa: F401, F403
