from __future__ import annotations

from .cli_adapter import CLIAdapter

class ClaudeCodeAgent(CLIAdapter):
    """Claude Code adapter using CLIAdapter mechanics."""
    pass
