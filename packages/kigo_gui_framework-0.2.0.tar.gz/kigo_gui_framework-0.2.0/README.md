This is the README of the kigo-gui-framework v0.2.0.
It follows the MIT Licence. 
Do you like PyQt6, but you dont wanna write all the code? Well, kigo-gui-framework is your bet! Its open source, and you can code in the extremely simple syntax to get a pyqt6 window! Check out the GitHub repo at https:\\github.com\TheYoungDev430\kigo-gui-framework2. 