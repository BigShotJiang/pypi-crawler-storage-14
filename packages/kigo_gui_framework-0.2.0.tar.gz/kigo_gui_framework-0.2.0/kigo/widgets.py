from PyQt6.QtWidgets import QLabel, QPushButton, QLineEdit, QComboBox, QWidget, QVBoxLayout
from PyQt6.QtCore import Qt, pyqtSignal

# The base class for all widgets
class WidgetBase:
    def render(self, parent: QWidget):
        """Creates and returns the native PyQt6 widget."""
        raise NotImplementedError("Subclasses must implement the render method.")

class Label(WidgetBase):
    def __init__(self, text):
        self.text = text

    def render(self, parent):
        # QLabel is the PyQt equivalent of tk.Label
        lbl = QLabel(self.text, parent)
        # We don't need .pack() anymore; positioning is handled by the layout manager
        return lbl

class Button(WidgetBase):
    def __init__(self, text, on_click=None):
        self.text = text
        self.on_click = on_click

    def render(self, parent):
        # QPushButton is the PyQt equivalent of tk.Button
        btn = QPushButton(self.text, parent)
        
        if self.on_click:
            # Connect the button's clicked signal to the user's on_click function
            btn.clicked.connect(self.on_click)
            
        return btn

class TextBox(WidgetBase):
    def __init__(self, width=20):
        # Width is handled by the layout, but kept for interface consistency
        self.width = width 
        self._pyqt_entry = None # Store the QLineEdit instance

    def render(self, parent):
        # QLineEdit is the PyQt equivalent of tk.Entry
        self._pyqt_entry = QLineEdit(parent)
        # Note: Setting width directly is discouraged in PyQt, relying on layouts
        return self._pyqt_entry

    def get_text(self):
        if self._pyqt_entry is not None:
            return self._pyqt_entry.text()
        return ""

class Dropdown(WidgetBase):
    def __init__(self, options):
        self.options = options
        self._pyqt_combo = None # Store the QComboBox instance

    def render(self, parent):
        # QComboBox is the PyQt equivalent of tk.OptionMenu
        self._pyqt_combo = QComboBox(parent)
        self._pyqt_combo.addItems(self.options)
        
        return self._pyqt_combo

    def get_selected(self):
        if self._pyqt_combo is not None:
            return self._pyqt_combo.currentText()
        return None