from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout
from PyQt6.QtCore import QSize
import sys

class App:
    def __init__(self, title="Kigo App", size=(500, 400)):
        # QApplication must be created first (or passed in)
        self.app = QApplication.instance() 
        if self.app is None:
            self.app = QApplication(sys.argv)
            
        # The main window is a QWidget
        self.root = QWidget()
        self.root.setWindowTitle(title)
        self.root.resize(QSize(size[0], size[1]))
        
        # Create a layout manager for the main window
        self.layout = QVBoxLayout()
        self.root.setLayout(self.layout)

    def add(self, widget):
        # We assume the widget's render method returns the PyQt widget
        # The widget must be added to the layout manager, not the root directly
        pyqt_widget = widget.render(self.root)
        self.layout.addWidget(pyqt_widget)

    def run(self):
        self.root.show()
        # Start the event loop
        sys.exit(self.app.exec())