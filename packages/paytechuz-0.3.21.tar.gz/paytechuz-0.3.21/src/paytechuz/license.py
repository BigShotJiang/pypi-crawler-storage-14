import os
from typing import Optional

import requests

from paytechuz.core.exceptions import UnknownPartnerError


API_KEY_ENV_NAME = "PAYTECH_LICENSE_API_KEY"


def _get_license_api_key(explicit_key: Optional[str]) -> str:
    license_api_key = explicit_key or os.environ.get(API_KEY_ENV_NAME)
    if not license_api_key:
        raise UnknownPartnerError(
            f"Missing license_api_key for paytechuz. Please set the '{API_KEY_ENV_NAME}' environment variable "
            "or pass it explicitly. To obtain a valid license_api_key, please contact @muhammadali_me on Telegram."
        )
    return license_api_key


def _validate_license_api_key(license_api_key: Optional[str] = None) -> None:
    key = _get_license_api_key(license_api_key)

    try:
        license_url = "https://paytechuz.demo-projects.uz/api/v1/license/validate"
        response = requests.post(
            license_url,
            json={"api_key": key},
            timeout=5,
        )
    except requests.RequestException as exc:
        raise UnknownPartnerError(
            "Unable to validate license_api_key. Please contact @muhammadali_me on Telegram."
        ) from exc

    if response.status_code != 200:
        raise UnknownPartnerError(
            "Invalid license_api_key for paytechuz. Please contact @muhammadali_me on Telegram."
        )
