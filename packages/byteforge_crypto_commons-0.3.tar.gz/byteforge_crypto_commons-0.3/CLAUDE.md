# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

ByteForge Crypto Commons is a Python library providing standardized data models for cryptocurrency projects. It defines core data structures used across cryptocurrency applications for representing token information, market quotes, and token states.

## Commands

### Build and Publish
```bash
# Build and publish to PyPI (requires PyPI credentials)
./build_publish.sh
```

### Development Setup
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install package in development mode
pip install -e .
```

## Architecture

### Core Structure
The library is organized around data models in the `crypto_commons.types` module:

1. **TokenInfo** - Basic cryptocurrency token information (id, name, symbol, rank)
2. **Quote** - Market data for a token in a specific currency (price, volume, market cap)
3. **TokenState** - Complete token state combining TokenInfo with multiple currency quotes

### Key Design Patterns
- **Dataclasses**: All models use Python dataclasses with type hints for type safety
- **Optional fields**: Many fields are Optional to handle incomplete API data gracefully
- **Nested structures**: TokenState contains TokenInfo and a map of Quote objects
- **Immutable-by-default**: While not frozen, dataclasses encourage immutable usage

### Type System
The codebase makes heavy use of Python's type system:
- All fields have explicit type annotations
- Uses `Optional[T]` for nullable fields
- Datetime objects for timestamps
- Clear distinction between required and optional fields

## Important Notes

1. **Python Version**: Requires Python 3.8+ (uses modern type hints and dataclasses)
2. **No Test Suite**: Currently no tests exist - when adding features, consider adding tests
3. **License Discrepancy**: README mentions MIT but LICENSE file is Apache 2.0 - verify before changes
4. **PyPI Package**: Published as `byteforge-crypto-commons` - version in pyproject.toml
5. **Dependencies**: Minimal - only `python-dateutil` for datetime handling

## Common Tasks

### Adding a New Data Model
1. Create new file in `crypto_commons/types/`
2. Follow existing pattern: dataclass with type hints and comprehensive docstring
3. Include both class and field-level documentation
4. Consider which fields should be Optional vs required

### Modifying Existing Models
1. Check impact on dependent projects (this is a foundational library)
2. Consider backwards compatibility
3. Update docstrings to reflect changes
4. Version bump may be needed for breaking changes

### Publishing Updates
1. Update version in `pyproject.toml`
2. Ensure all changes are committed
3. Run `./build_publish.sh` (requires PyPI credentials)