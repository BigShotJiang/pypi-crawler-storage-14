"""
PayPal payment tracking model.
"""
from sqlalchemy import Numeric, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from apex.app.database.base import BaseModel


class BasePayment(BaseModel):
    """Abstract payment record."""

    __abstract__ = True

    paypal_order_id: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    paypal_capture_id: Mapped[str | None] = mapped_column(String(100), unique=True)
    amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), nullable=False, default="USD")
    payment_metadata: Mapped[dict | None] = mapped_column(JSONB, default=dict)


__all__ = ["BasePayment"]

