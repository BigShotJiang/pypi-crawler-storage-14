import cf_basic_signal.steps as steps


def test_inline_source_handles_plain_and_inline_json():
    plain = steps.inline_source("hello")
    assert plain["data"] == "hello"

    inline = steps.inline_source('inline://{"a": 1}')
    assert inline["data"] == {"a": 1}


def test_fifo_window_buffer_keeps_last_values():
    res = steps.fifo_window_buffer([1, 2, 3, 4], windowSize=2)
    assert res["window"] == [3, 4]
