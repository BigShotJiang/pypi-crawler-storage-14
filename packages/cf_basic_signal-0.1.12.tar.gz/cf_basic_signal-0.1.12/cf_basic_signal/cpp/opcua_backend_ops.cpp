#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <cmath>
#include <string>
#include <vector>

#include <open62541/client_config_default.h>
#include <open62541/client_highlevel.h>

#include "pipeline_backend_compat.hpp"

namespace py = pybind11;

// C API type exposed by pipeline_backend via PyCapsule.
using register_op_c_api_t = void (*)(const char *, pipeline::OpFn);

static std::string str_or_default(const py::dict &payload, const char *key, const std::string &fallback) {
    if (payload.contains(key)) {
        return py::cast<std::string>(payload[key]);
    }
    return fallback;
}

static double read_double(UA_Client *client, const std::string &node_id_str) {
    UA_String node_id_string = UA_STRING_ALLOC(node_id_str.c_str());
    UA_NodeId node_id = UA_NODEID_NULL;
    if (UA_NodeId_parse(&node_id, node_id_string) != UA_STATUSCODE_GOOD) {
        UA_String_clear(&node_id_string);
        return std::nan("");
    }
    UA_String_clear(&node_id_string);

    UA_Variant value;
    UA_Variant_init(&value);
    const auto status = UA_Client_readValueAttribute(client, node_id, &value);
    UA_NodeId_clear(&node_id);

    if (status != UA_STATUSCODE_GOOD) {
        UA_NodeId_clear(&node_id);
        return std::nan("");
    }

    if (UA_Variant_hasScalarType(&value, &UA_TYPES[UA_TYPES_DOUBLE])) {
        UA_NodeId_clear(&node_id);
        return *static_cast<UA_Double *>(value.data);
    }
    if (UA_Variant_hasScalarType(&value, &UA_TYPES[UA_TYPES_FLOAT])) {
        UA_NodeId_clear(&node_id);
        return static_cast<double>(*static_cast<UA_Float *>(value.data));
    }
    UA_NodeId_clear(&node_id);
    return std::nan("");
}

static std::vector<double> values_list(py::dict payload) {
    if (payload.contains("values")) {
        try {
            return py::cast<std::vector<double>>(payload["values"]);
        } catch (const py::cast_error &) {
        }
    }
    if (payload.contains("sampleChunk")) {
        try {
            return py::cast<std::vector<double>>(payload["sampleChunk"]);
        } catch (const py::cast_error &) {
        }
    }
    return {};
}

static void opcua_ph_source_op(pipeline::Data &data) {
    py::dict payload = data.payload;

    // Align defaults with Python implementation (VirtualPhServer) and force IPv4 to avoid ::1 issues.
    const std::string endpoint = str_or_default(payload, "endpoint", "opc.tcp://127.0.0.1:4840/VirtualPhServer");
    const std::string ph_node = str_or_default(payload, "phNode", "ns=2;s=VirtualPhMeter01.pH");
    const std::string temp_node = str_or_default(payload, "temperatureNode", "ns=2;s=VirtualPhMeter01.temperature");

    UA_Client *client = UA_Client_new();
    UA_ClientConfig_setDefault(UA_Client_getConfig(client));

    const auto connect_status = UA_Client_connect(client, endpoint.c_str());
    if (connect_status != UA_STATUSCODE_GOOD) {
        UA_Client_delete(client);
        throw std::runtime_error("opcua_ph_source_op: connect failed for endpoint " + endpoint);
    }

    const double ph_val = read_double(client, ph_node);
    const double temp_val = read_double(client, temp_node);
    UA_Client_disconnect(client);
    UA_Client_delete(client);

    py::dict sample;
    sample["pH"] = ph_val;
    sample["temperature"] = temp_val;
    sample["timestamp"] = py::none();
    payload["opcua_sample"] = sample;

    auto vals = values_list(payload);
    vals.push_back(ph_val);
    payload["values"] = vals;
}

// ---------------------------------------------------------------------------
// Registration with pipeline_backend via PyCapsule
// ---------------------------------------------------------------------------

static void register_with_backend() {
    py::object backend = py::module_::import("pipeline_backend");
    py::object capsule = backend.attr("_register_op_capsule");

    auto reg_fn = reinterpret_cast<register_op_c_api_t>(
        PyCapsule_GetPointer(capsule.ptr(), "pipeline_backend.register_op_v1"));
    if (!reg_fn) {
        throw std::runtime_error("Failed to obtain register_op_c_api from pipeline_backend capsule");
    }

    reg_fn("opcua_ph_source", &opcua_ph_source_op);
}

PYBIND11_MODULE(_opcua_backend_ops, m) {
    m.doc() = "C++ OPC UA pipeline_backend ops for cf_basic_signal (requires open62541)";
    register_with_backend();
}
