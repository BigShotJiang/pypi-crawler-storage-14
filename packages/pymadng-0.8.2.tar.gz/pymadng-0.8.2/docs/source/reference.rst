API Reference
=============

PyMAD-NG Module contents
------------------------

.. automodule:: pymadng
   :members:
   :undoc-members:
   :show-inheritance:

Useful functions for MAD References
-----------------------------------

.. autofunction:: pymadng.madp_classes.MadObject.convert_to_dataframe
   :no-index:

.. autofunction:: pymadng.madp_classes.MadObject.to_df
   :no-index: