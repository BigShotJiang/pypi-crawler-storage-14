from setuptools import setup, find_packages

setup(
    name="fasapi-auth-toolkit",
    version="1.0.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "fastapi>=0.104.0",
        "asyncpg>=0.29.0",
        "httpx>=0.25.0",
        "PyJWT>=2.8.0",
        "cachetools>=5.3.0",
        "aiofiles>=23.0.0",
        "pydantic>=2.0.0",
    ],
    python_requires=">=3.9",
)