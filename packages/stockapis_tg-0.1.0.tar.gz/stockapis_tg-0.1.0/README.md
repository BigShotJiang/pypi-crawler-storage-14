# stockapis-tg

Telegram channel monitoring for trading signals - StockAPIs.

## Install

```bash
pip install stockapis-tg
```

## Usage

```python
from stockapis_tg import TelegramSpy

spy = TelegramSpy(
    api_id=12345,
    api_hash="your_api_hash",
    session_string="YOUR_SESSION_STRING",
    channels=["crypto_signals"],
)

@spy.on_signal
async def handle_signal(signal):
    print(f"Signal: {signal.action} {signal.symbol}")

await spy.start()
```

## CLI

```bash
# Generate session string
telegram-spy auth --api-id 12345 --api-hash abc123

# Test session
telegram-spy test --session "1BQA..."

# List channels
telegram-spy channels --session "1BQA..."

# Run spy
telegram-spy run
```

## License

MIT
