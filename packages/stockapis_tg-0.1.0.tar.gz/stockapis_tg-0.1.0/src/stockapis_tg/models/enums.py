"""Enums for stockapis-tg."""

from enum import Enum


class SignalAction(str, Enum):
    """Trading signal actions."""

    BUY = "BUY"
    SELL = "SELL"
    SKIP = "SKIP"
    PUMP = "PUMP"
    LISTING = "LISTING"
    BINANCE_LISTING = "BINANCE_LISTING"
    UNKNOWN = "UNKNOWN"


class MarketType(str, Enum):
    """Exchange market type."""

    SPOT = "spot"
    FUTURES = "futures"
    PERPETUAL = "perpetual"
    SWAP = "swap"
