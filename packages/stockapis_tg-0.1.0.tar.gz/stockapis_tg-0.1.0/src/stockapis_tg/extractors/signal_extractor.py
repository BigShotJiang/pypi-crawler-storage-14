"""
Signal extractor - extracts trading signals from message text.
"""

from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, Field

from stockapis_tg.utils import get_logger

from stockapis_tg.models import MarketType, SignalAction
from .patterns import PATTERNS, Exchange

logger = get_logger(__name__)


class PriceRange(BaseModel):
    """Price range (min-max)."""

    min_price: Decimal = Field(..., gt=0)
    max_price: Decimal = Field(..., gt=0)

    @property
    def avg_price(self) -> Decimal:
        """Average price."""
        return (self.min_price + self.max_price) / 2


class TargetLevel(BaseModel):
    """Individual target price level."""

    price: Decimal = Field(..., gt=0)
    level: int = Field(..., ge=1)


class ExtractedSignal(BaseModel):
    """Trading signal extracted from Telegram message."""

    # Identification
    signal_id: str = Field(default_factory=lambda: str(uuid4()))
    action: SignalAction
    symbol: str = Field(..., min_length=3)

    # Prices
    entry_price: Optional[Decimal] = None
    entry_range: Optional[PriceRange] = None
    targets: list[TargetLevel] = Field(default_factory=list)
    stop_loss: Optional[Decimal] = None

    # Market info
    exchange: Optional[str] = None
    market_type: MarketType = MarketType.SPOT
    leverage: Optional[int] = Field(default=None, ge=1, le=125)

    # Quality metrics
    confidence: Decimal = Field(default=Decimal("0"), ge=0, le=1)
    completeness: Decimal = Field(default=Decimal("0"), ge=0, le=1)

    # Source metadata
    channel_name: str = ""
    channel_username: str = ""
    message_id: int = 0
    message_text: str = ""
    message_date: Optional[datetime] = None

    # Timestamps
    extracted_at: datetime = Field(default_factory=datetime.utcnow)

    @property
    def base_currency(self) -> str:
        """Extract base from BTC/USDT -> BTC."""
        if "/" in self.symbol:
            return self.symbol.split("/")[0]
        return self.symbol

    @property
    def quote_currency(self) -> str:
        """Extract quote from BTC/USDT -> USDT."""
        if "/" in self.symbol:
            return self.symbol.split("/")[1]
        return "USDT"

    @property
    def effective_entry(self) -> Optional[Decimal]:
        """Get entry price or average of range."""
        if self.entry_price:
            return self.entry_price
        if self.entry_range:
            return self.entry_range.avg_price
        return None

    def to_redis_dict(self) -> dict[str, Any]:
        """Convert to dict for Redis publishing."""
        return {
            "signal_id": self.signal_id,
            "symbol": self.symbol,
            "signal_type": self.action.value,
            "source": "telegram",
            "confidence": float(self.confidence),
            "price": float(self.effective_entry) if self.effective_entry else None,
            "stop_loss": float(self.stop_loss) if self.stop_loss else None,
            "take_profit": float(self.targets[0].price) if self.targets else None,
            "timestamp": (
                self.message_date.isoformat() if self.message_date else None
            ),
            "metadata": {
                "channel": self.channel_name,
                "channel_username": self.channel_username,
                "message_id": self.message_id,
                "exchange": self.exchange,
                "market_type": self.market_type.value,
                "leverage": self.leverage,
                "completeness": float(self.completeness),
                "targets": [
                    {"level": t.level, "price": float(t.price)} for t in self.targets
                ],
            },
        }


class ExtractionResult(BaseModel):
    """Result of signal extraction process."""

    success: bool
    signal: Optional[ExtractedSignal] = None
    confidence: Decimal = Decimal("0")
    matched_patterns: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    processing_time_ms: Decimal = Decimal("0")


class SignalExtractor:
    """
    Extract trading signals from message text using regex patterns.

    Supports:
    - Multi-pattern matching (action, symbol, prices, exchange, leverage)
    - Confidence scoring based on matched patterns
    - Completeness scoring based on signal data
    - Bilingual support (English + Russian)
    """

    def __init__(self) -> None:
        """Initialize extractor with compiled patterns."""
        self.patterns = PATTERNS

    def extract(
        self,
        text: str,
        channel_name: str = "",
        channel_username: str = "",
        message_id: int = 0,
        message_date: Optional[datetime] = None,
    ) -> ExtractionResult:
        """
        Extract trading signal from message text.

        Args:
            text: Message text.
            channel_name: Source channel name.
            channel_username: Source channel username.
            message_id: Telegram message ID.
            message_date: Message timestamp.

        Returns:
            ExtractionResult with signal or errors.
        """
        start_time = datetime.utcnow()
        matched_patterns: list[str] = []
        warnings: list[str] = []

        try:
            # Step 1: Extract action
            action, action_patterns = self._extract_action(text)
            matched_patterns.extend(action_patterns)

            if action == SignalAction.UNKNOWN:
                return ExtractionResult(
                    success=False,
                    confidence=Decimal("0"),
                    errors=["No valid signal action detected"],
                    processing_time_ms=self._elapsed_ms(start_time),
                )

            # Step 2: Extract symbol
            symbol = self._extract_symbol(text)
            if not symbol:
                return ExtractionResult(
                    success=False,
                    confidence=Decimal("0"),
                    errors=["No trading symbol detected"],
                    matched_patterns=matched_patterns,
                    processing_time_ms=self._elapsed_ms(start_time),
                )

            # Step 3: Extract prices
            price_data = self._extract_prices(text)

            # Step 4: Extract exchange
            exchange = self._extract_exchange(text)

            # Step 5: Extract market type and leverage
            market_type, leverage = self._extract_market_info(text)

            # Step 6: Build signal
            signal = ExtractedSignal(
                action=action,
                symbol=symbol,
                entry_price=price_data.get("entry_price"),
                entry_range=price_data.get("entry_range"),
                targets=price_data.get("targets", []),
                stop_loss=price_data.get("stop_loss"),
                exchange=exchange,
                market_type=market_type,
                leverage=leverage,
                channel_name=channel_name,
                channel_username=channel_username,
                message_id=message_id,
                message_text=text,
                message_date=message_date or datetime.utcnow(),
            )

            # Step 7: Calculate quality metrics
            confidence = self._calculate_confidence(signal, matched_patterns)
            completeness = self._calculate_completeness(signal)

            # Update signal with calculated scores
            signal.confidence = confidence
            signal.completeness = completeness

            # Warnings
            if not signal.stop_loss:
                warnings.append("No stop loss detected")
            if not signal.targets:
                warnings.append("No target prices detected")

            return ExtractionResult(
                success=True,
                signal=signal,
                confidence=confidence,
                matched_patterns=matched_patterns,
                warnings=warnings,
                processing_time_ms=self._elapsed_ms(start_time),
            )

        except Exception as e:
            logger.error(f"Extraction failed: {e}", exc_info=True)
            return ExtractionResult(
                success=False,
                confidence=Decimal("0"),
                matched_patterns=matched_patterns,
                errors=[f"Extraction failed: {str(e)}"],
                warnings=warnings,
                processing_time_ms=self._elapsed_ms(start_time),
            )

    def _extract_action(self, text: str) -> tuple[SignalAction, list[str]]:
        """Extract signal action from text."""
        matched_patterns: list[str] = []

        # Check Binance listing first (most specific)
        binance_listing = self.patterns.exchanges[Exchange.BINANCE].search(
            text
        ) and any(p.search(text) for p in self.patterns.listing)
        if binance_listing:
            matched_patterns.append("binance_listing")
            return SignalAction.BINANCE_LISTING, matched_patterns

        # Check listing
        for pattern in self.patterns.listing:
            if pattern.search(text):
                matched_patterns.append(f"listing:{pattern.pattern}")
                return SignalAction.LISTING, matched_patterns

        # Check pump (need 2+ indicators)
        pump_count = sum(1 for p in self.patterns.pump if p.search(text))
        if pump_count >= 2:
            for p in self.patterns.pump:
                if p.search(text):
                    matched_patterns.append(f"pump:{p.pattern}")
            return SignalAction.PUMP, matched_patterns

        # Check SELL before BUY (more specific)
        for pattern in self.patterns.sell:
            if pattern.search(text):
                matched_patterns.append(f"sell:{pattern.pattern}")
                return SignalAction.SELL, matched_patterns

        # Check BUY
        for pattern in self.patterns.buy:
            if pattern.search(text):
                matched_patterns.append(f"buy:{pattern.pattern}")
                return SignalAction.BUY, matched_patterns

        return SignalAction.UNKNOWN, matched_patterns

    def _extract_symbol(self, text: str) -> Optional[str]:
        """Extract trading symbol from text."""
        # Try standard format (BTC/USDT)
        match = self.patterns.symbol.search(text)
        if match:
            base, quote = match.groups()
            return f"{base.upper()}/{quote.upper()}"

        # Try $ format ($BTC)
        match = self.patterns.symbol_dollar.search(text)
        if match:
            base = match.group(1).upper()
            return f"{base}/USDT"

        # Try # format (#BTC)
        match = self.patterns.symbol_hashtag.search(text)
        if match:
            base = match.group(1).upper()
            return f"{base}/USDT"

        return None

    def _extract_prices(self, text: str) -> dict[str, Any]:
        """Extract price information from text."""
        result: dict[str, Any] = {
            "entry_price": None,
            "entry_range": None,
            "targets": [],
            "stop_loss": None,
        }

        # Extract entry price
        entry_match = self.patterns.entry.search(text)
        if entry_match:
            result["entry_price"] = self._parse_decimal(entry_match.group(1))

        # Check for entry range
        range_match = self.patterns.price_range.search(text)
        if range_match:
            min_price = self._parse_decimal(range_match.group(1))
            max_price = self._parse_decimal(range_match.group(2))
            if min_price and max_price and min_price < max_price:
                try:
                    result["entry_range"] = PriceRange(
                        min_price=min_price,
                        max_price=max_price,
                    )
                except ValueError:
                    pass

        # Extract targets
        targets = self.patterns.target.finditer(text)
        target_list: list[TargetLevel] = []
        for idx, match in enumerate(targets, start=1):
            level_str = match.group(1)
            price_str = match.group(2)

            level = int(level_str) if level_str and level_str.isdigit() else idx
            price = self._parse_decimal(price_str)

            if price:
                target_list.append(TargetLevel(price=price, level=level))

        result["targets"] = target_list

        # Extract stop loss
        sl_match = self.patterns.stop_loss.search(text)
        if sl_match:
            result["stop_loss"] = self._parse_decimal(sl_match.group(1))

        return result

    def _extract_exchange(self, text: str) -> Optional[str]:
        """Extract exchange from text."""
        for exchange, pattern in self.patterns.exchanges.items():
            if pattern.search(text):
                return exchange
        return None

    def _extract_market_info(self, text: str) -> tuple[MarketType, Optional[int]]:
        """Extract market type and leverage."""
        market_type = MarketType.SPOT
        leverage = None

        # Check for futures
        if self.patterns.futures.search(text):
            market_type = MarketType.FUTURES

        # Check for leverage (implies futures)
        leverage_match = self.patterns.leverage.search(text)
        if leverage_match:
            leverage = int(leverage_match.group(1))
            if leverage > 1:
                market_type = MarketType.FUTURES

        return market_type, leverage

    def _calculate_confidence(
        self,
        signal: ExtractedSignal,
        matched_patterns: list[str],
    ) -> Decimal:
        """Calculate extraction confidence score (0.0-1.0)."""
        score = Decimal("0")

        # Pattern matching score (max 0.3)
        pattern_score = min(len(matched_patterns) * Decimal("0.1"), Decimal("0.3"))
        score += pattern_score

        # Price completeness (max 0.3)
        if signal.entry_price or signal.entry_range:
            score += Decimal("0.1")
        if signal.targets:
            score += Decimal("0.1")
        if signal.stop_loss:
            score += Decimal("0.1")

        # Exchange specified (0.2)
        if signal.exchange and signal.exchange != Exchange.UNKNOWN:
            score += Decimal("0.2")

        # Symbol clarity (0.2)
        if "/" in signal.symbol and signal.symbol.count("/") == 1:
            score += Decimal("0.2")

        return min(score, Decimal("1"))

    def _calculate_completeness(self, signal: ExtractedSignal) -> Decimal:
        """Calculate signal completeness score (0.0-1.0)."""
        score = Decimal("0")

        # Entry price/range (0.3)
        if signal.entry_price or signal.entry_range:
            score += Decimal("0.3")

        # Targets (0.3)
        if signal.targets:
            score += Decimal("0.3")

        # Stop loss (0.2)
        if signal.stop_loss:
            score += Decimal("0.2")

        # Exchange (0.1)
        if signal.exchange and signal.exchange != Exchange.UNKNOWN:
            score += Decimal("0.1")

        # Leverage for futures (0.1)
        if signal.market_type in (MarketType.FUTURES, MarketType.PERPETUAL):
            if signal.leverage:
                score += Decimal("0.1")
        else:
            score += Decimal("0.1")  # Not required for spot

        return min(score, Decimal("1"))

    def _parse_decimal(self, value: str) -> Optional[Decimal]:
        """Parse decimal from string, handling commas."""
        try:
            normalized = value.replace(",", ".")
            return Decimal(normalized)
        except (ValueError, TypeError, InvalidOperation):
            return None

    def _elapsed_ms(self, start_time: datetime) -> Decimal:
        """Calculate elapsed time in milliseconds."""
        delta = datetime.utcnow() - start_time
        return Decimal(str(delta.total_seconds() * 1000))
