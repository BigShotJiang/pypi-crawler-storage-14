"""
Telegram CLI commands with rich output.

Commands:
    auth      - Generate session string
    test      - Test session validity
    channels  - List subscribed channels
    send      - Send test signal to channel
"""

import asyncio
from typing import Optional

import typer
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

# Create Typer app for telegram commands
telegram_app = typer.Typer(
    name="telegram",
    help="[bold blue]Telegram[/bold blue] spy commands - auth, test, channels",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

console = Console()




# ═══════════════════════════════════════════════════════════════
# AUTH COMMAND
# ═══════════════════════════════════════════════════════════════


@telegram_app.command("auth")
def auth(
    api_id: int = typer.Option(
        ...,
        "--api-id",
        "-i",
        help="Telegram API ID from [link=https://my.telegram.org]my.telegram.org[/link]",
        prompt="Telegram API ID",
        rich_help_panel="Credentials",
    ),
    api_hash: str = typer.Option(
        ...,
        "--api-hash",
        "-h",
        help="Telegram API hash (32 hex characters)",
        prompt="Telegram API hash",
        rich_help_panel="Credentials",
    ),
    phone: Optional[str] = typer.Option(
        None,
        "--phone",
        "-p",
        help="Phone number with country code (e.g., +1234567890)",
        rich_help_panel="Credentials",
    ),
) -> None:
    """
    [bold green]Generate[/bold green] Telegram session string for containerized deployment.

    This is an interactive process that requires phone verification.
    Run once locally, save the session string, use in containers.

    [bold]Example:[/bold]
        botclient telegram auth --api-id 12345 --api-hash abc123...

    [bold]Get credentials:[/bold]
        1. Go to https://my.telegram.org
        2. Log in with your phone number
        3. Go to "API development tools"
        4. Create a new application
        5. Copy api_id and api_hash
    """
    from telethon import TelegramClient
    from telethon.errors import SessionPasswordNeededError
    from telethon.sessions import StringSession

    # Get phone if not provided
    if not phone:
        phone = Prompt.ask(
            "[bold]Phone number[/bold] (with country code, e.g., +1234567890)"
        )

    # Validate phone format
    if not phone.startswith("+"):
        phone = "+" + phone

    rprint()
    rprint(
        Panel(
            "[bold]Telegram Session String Generator[/bold]\n\n"
            "This will authorize your Telegram account and generate a session string.\n"
            "The session string can be used for non-interactive authentication.",
            title="BotClient",
            border_style="blue",
        )
    )

    async def generate_session() -> tuple[str, str]:
        client = TelegramClient(StringSession(), api_id, api_hash)

        try:
            await client.connect()

            if not await client.is_user_authorized():
                # Send code
                with console.status("[bold blue]Sending verification code..."):
                    await client.send_code_request(phone)

                rprint(f"\n[green]✓[/green] Code sent to [bold]{phone}[/bold]")

                # Get code from user
                code = Prompt.ask("[bold]Verification code[/bold]")

                try:
                    await client.sign_in(phone, code)
                except SessionPasswordNeededError:
                    rprint(
                        "\n[yellow]⚠[/yellow] Two-factor authentication is enabled"
                    )
                    password = Prompt.ask(
                        "[bold]2FA Password[/bold]", password=True
                    )
                    await client.sign_in(password=password)

            # Get user info
            me = await client.get_me()
            username = me.username or me.phone

            # Get session string
            session_string = client.session.save()

            return session_string, username

        finally:
            await client.disconnect()

    try:
        with console.status("[bold blue]Connecting to Telegram..."):
            session_string, username = asyncio.run(generate_session())

        rprint()
        rprint(f"[green]✓[/green] Authorized as [bold]{username}[/bold]")
        rprint()

        # Show session string in a panel
        rprint(
            Panel(
                f"[bold green]{session_string}[/bold green]",
                title="Session String (keep this secret!)",
                border_style="green",
                subtitle="Copy and save this value",
            )
        )

        rprint()
        rprint("[bold]Usage in code:[/bold]")
        rprint()
        rprint(
            Panel(
                f'''[cyan]from stockapis_tg import TelegramSpy

spy = TelegramSpy(
    api_id={api_id},
    api_hash="{api_hash}",
    session_string="{session_string[:20]}...",  # Use full string!
    channels=["crypto_signals"],
)

await spy.start()[/cyan]''',
                title="Python",
                border_style="cyan",
            )
        )

        rprint()
        rprint("[bold]Or set as environment variable:[/bold]")
        rprint()
        rprint(f'[dim]export TELEGRAM_SESSION="{session_string}"[/dim]')
        rprint()

    except Exception as e:
        rprint(f"\n[red]✗ Error:[/red] {e}")
        raise typer.Exit(1)


# ═══════════════════════════════════════════════════════════════
# TEST COMMAND
# ═══════════════════════════════════════════════════════════════


@telegram_app.command("test")
def test(
    api_id: int = typer.Option(
        ...,
        "--api-id",
        "-i",
        help="Telegram API ID",
        prompt="Telegram API ID",
    ),
    api_hash: str = typer.Option(
        ...,
        "--api-hash",
        "-h",
        help="Telegram API hash",
        prompt="Telegram API hash",
    ),
    session_string: str = typer.Option(
        ...,
        "--session",
        "-s",
        help="Session string to test",
        prompt="Session string",
    ),
) -> None:
    """
    [bold yellow]Test[/bold yellow] Telegram session string validity.

    [bold]Example:[/bold]
        botclient telegram test --api-id 12345 --api-hash abc... --session 1BQA...
    """
    from telethon import TelegramClient
    from telethon.sessions import StringSession

    async def test_session() -> dict:
        client = TelegramClient(StringSession(session_string), api_id, api_hash)

        try:
            await client.connect()

            if not await client.is_user_authorized():
                return {"valid": False, "error": "Session is expired or invalid"}

            me = await client.get_me()

            return {
                "valid": True,
                "user_id": me.id,
                "username": me.username,
                "phone": me.phone,
                "first_name": me.first_name,
                "last_name": me.last_name,
            }

        finally:
            await client.disconnect()

    try:
        with console.status("[bold blue]Testing session..."):
            result = asyncio.run(test_session())

        if result["valid"]:
            rprint()
            rprint("[green]✓[/green] Session is [bold green]valid[/bold green]!")
            rprint()

            # Show user info table
            table = Table(title="Account Info", border_style="green")
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="white")

            table.add_row("User ID", str(result["user_id"]))
            table.add_row("Username", result["username"] or "-")
            table.add_row("Phone", result["phone"] or "-")
            name = f"{result['first_name'] or ''} {result['last_name'] or ''}".strip()
            table.add_row("Name", name or "-")

            console.print(table)
        else:
            rprint()
            rprint("[red]✗[/red] Session is [bold red]invalid[/bold red]!")
            rprint(f"[dim]{result.get('error', 'Unknown error')}[/dim]")
            raise typer.Exit(1)

    except Exception as e:
        rprint(f"\n[red]✗ Error:[/red] {e}")
        raise typer.Exit(1)


# ═══════════════════════════════════════════════════════════════
# CHANNELS COMMAND
# ═══════════════════════════════════════════════════════════════


@telegram_app.command("channels")
def channels(
    api_id: int = typer.Option(..., "--api-id", "-i", help="Telegram API ID"),
    api_hash: str = typer.Option(..., "--api-hash", "-h", help="Telegram API hash"),
    session_string: str = typer.Option(..., "--session", "-s", help="Session string"),
    limit: int = typer.Option(50, "--limit", "-l", help="Max channels to show"),
) -> None:
    """
    [bold cyan]List[/bold cyan] Telegram channels/groups you're subscribed to.

    Use channel usernames (without @) in TelegramSpy configuration.

    [bold]Example:[/bold]
        botclient telegram channels --api-id 12345 --api-hash abc... --session 1BQA...
    """
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    from telethon.tl.types import Channel

    async def get_channels() -> list:
        client = TelegramClient(StringSession(session_string), api_id, api_hash)

        try:
            await client.connect()

            if not await client.is_user_authorized():
                return []

            dialogs = await client.get_dialogs(limit=limit)
            result = []

            for dialog in dialogs:
                if isinstance(dialog.entity, Channel):
                    result.append({
                        "username": dialog.entity.username or "-",
                        "title": dialog.entity.title,
                        "id": dialog.entity.id,
                        "participants": dialog.entity.participants_count or 0,
                    })

            return result

        finally:
            await client.disconnect()

    try:
        with console.status("[bold blue]Fetching channels..."):
            channel_list = asyncio.run(get_channels())

        if not channel_list:
            rprint("[yellow]No channels found or session invalid[/yellow]")
            raise typer.Exit(1)

        rprint()
        table = Table(
            title=f"Your Channels ({len(channel_list)})",
            border_style="blue",
        )
        table.add_column("#", style="dim", width=4)
        table.add_column("Username", style="cyan", min_width=20)
        table.add_column("Title", style="white", max_width=40)
        table.add_column("Members", style="green", justify="right")

        for i, ch in enumerate(channel_list, 1):
            username = f"@{ch['username']}" if ch["username"] != "-" else "[dim]-[/dim]"
            members = f"{ch['participants']:,}" if ch["participants"] else "-"
            table.add_row(str(i), username, ch["title"][:40], members)

        console.print(table)
        rprint()
        rprint(
            "[dim]Tip: Use channel usernames (without @) in TelegramSpy channels list[/dim]"
        )

    except Exception as e:
        rprint(f"\n[red]✗ Error:[/red] {e}")
        raise typer.Exit(1)


# ═══════════════════════════════════════════════════════════════
# SEND COMMAND
# ═══════════════════════════════════════════════════════════════


@telegram_app.command("run")
def run() -> None:
    """
    [bold green]Run[/bold green] Telegram Spy - monitors channels and publishes signals to Redis.

    Reads configuration from environment variables:
        TELEGRAM__API_ID, TELEGRAM__API_HASH, TELEGRAM__SESSION, TELEGRAM__CHANNELS
        REDIS__HOST, REDIS__PORT, REDIS__CHANNEL

    [bold]Example:[/bold]
        telegram-spy run
    """
    from ..spy import main as spy_main

    try:
        rprint(Panel.fit("[bold cyan]Telegram Spy[/bold cyan]", subtitle="Ctrl+C to stop"))
        asyncio.run(spy_main())
    except KeyboardInterrupt:
        rprint("\n[yellow]Stopped[/yellow]")
    except Exception as e:
        rprint(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@telegram_app.command("send")
def send(
    message: Optional[str] = typer.Option(None, "-m", "--message", help="Custom message"),
    all_signals: bool = typer.Option(False, "-a", "--all", help="Send all test signals"),
) -> None:
    """
    [bold magenta]Send[/bold magenta] test signal via Bot API.

    Requires BOT_TOKEN environment variable.

    [bold]Examples:[/bold]
        telegram-spy send           # Send default BUY signal
        telegram-spy send --all     # Send all test signals
        telegram-spy send -m "test" # Send custom message
    """
    from ..test_bot import TEST_SIGNALS, send_all_signals, send_test_signal

    try:
        if all_signals:
            rprint(f"[cyan]Sending {len(TEST_SIGNALS)} signals...[/cyan]")
            sent = send_all_signals()
            rprint(f"[green]✓ Sent {sent} signals[/green]")
        else:
            rprint("[cyan]Sending...[/cyan]")
            if send_test_signal(message):
                rprint("[green]✓ Sent![/green]")
            else:
                rprint("[red]Failed[/red]")
                raise typer.Exit(1)

    except ValueError as e:
        rprint(f"[red]{e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        rprint(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
