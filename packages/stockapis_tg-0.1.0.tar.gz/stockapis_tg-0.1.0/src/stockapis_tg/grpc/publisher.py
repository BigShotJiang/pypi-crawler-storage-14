"""
gRPC Signal Publisher - sends signals to Django via gRPC.

Based on telegram/grpc/publisher.py but for botclient.
Uses SignalService on port 50051 (same as BotStreamingService).
"""

import asyncio
import uuid
from datetime import datetime, timezone
from typing import Optional

import grpc
from google.protobuf.timestamp_pb2 import Timestamp

from stockapis_tg.utils import get_logger

from .generated import signal_service_pb2 as pb2
from .generated import signal_service_pb2_grpc as pb2_grpc

logger = get_logger(__name__)


# Map signal types to proto enum
SIGNAL_TYPE_MAP = {
    "buy": pb2.BUY,
    "sell": pb2.SELL,
    "pump": pb2.PUMP,
    "listing": pb2.LISTING,
    "binance_listing": pb2.BINANCE_LISTING,
    "info": pb2.INFO,
    "alert": pb2.ALERT,
    "unknown": pb2.SIGNAL_TYPE_UNSPECIFIED,
}


class SignalPublisher:
    """
    Publishes trading signals to Django via gRPC.

    Uses SignalService on port 50051 (unified gRPC server).

    Usage:
        publisher = SignalPublisher(
            host="localhost",
            port=50051,
            bot_id="uuid",
        )
        await publisher.connect()
        await publisher.publish_signal(signal_data)
        await publisher.disconnect()

    Or as context manager:
        async with SignalPublisher(...) as publisher:
            await publisher.publish_signal(signal_data)
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 50051,
        bot_id: Optional[str] = None,
        source: str = "botclient",
    ) -> None:
        """Initialize signal publisher."""
        self._host = host
        self._port = port
        self._bot_id = bot_id
        self._source = source
        self._channel: Optional[grpc.aio.Channel] = None
        self._stub: Optional[pb2_grpc.SignalServiceStub] = None

        logger.info(f"SignalPublisher initialized: {host}:{port}")

    @property
    def address(self) -> str:
        """Get server address."""
        return f"{self._host}:{self._port}"

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._stub is not None

    async def connect(self, timeout: float = 5.0) -> bool:
        """Connect to gRPC server."""
        try:
            self._channel = grpc.aio.insecure_channel(self.address)
            self._stub = pb2_grpc.SignalServiceStub(self._channel)

            await asyncio.wait_for(
                self._channel.channel_ready(),
                timeout=timeout,
            )

            logger.info(f"Connected to SignalService: {self.address}")
            return True

        except asyncio.TimeoutError:
            logger.warning(f"Connection timeout after {timeout}s: {self.address}")
            await self.disconnect()
            return False

        except Exception as e:
            logger.error(f"Failed to connect: {e}")
            await self.disconnect()
            return False

    async def disconnect(self) -> None:
        """Disconnect from server."""
        if self._channel:
            await self._channel.close()
            self._channel = None
            self._stub = None
            logger.info("SignalPublisher disconnected")

    async def publish_signal(
        self,
        signal_type: str,
        symbol: str,
        price: Optional[str] = None,
        stop_loss: Optional[str] = None,
        take_profit: Optional[str] = None,
        targets: Optional[list[tuple[int, str]]] = None,
        entry_min: Optional[str] = None,
        entry_max: Optional[str] = None,
        leverage: Optional[int] = None,
        exchange: Optional[str] = None,
        market_type: Optional[str] = None,
        confidence: float = 0.0,
        signal_id: Optional[str] = None,
        message_text: str = "",
    ) -> tuple[bool, str]:
        """
        Publish trading signal to Django.

        Args:
            signal_type: BUY, SELL, INFO, etc.
            symbol: Trading pair (e.g., "BTC/USDT")
            price: Entry price
            stop_loss: Stop loss price
            take_profit: First target price
            targets: List of (level, price) tuples
            entry_min: Entry range min
            entry_max: Entry range max
            leverage: Leverage for futures
            exchange: Exchange name
            market_type: spot, futures, perpetual
            confidence: Signal confidence 0-1
            signal_id: Custom signal ID (auto-generated if not provided)
            message_text: Optional message/reasoning

        Returns:
            Tuple of (success, signal_id or error message)
        """
        if not self._stub:
            return False, "Not connected"

        try:
            proto_signal = self._create_proto_signal(
                signal_type=signal_type,
                symbol=symbol,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                targets=targets,
                entry_min=entry_min,
                entry_max=entry_max,
                leverage=leverage,
                exchange=exchange,
                market_type=market_type,
                confidence=confidence,
                signal_id=signal_id,
                message_text=message_text,
            )

            request = pb2.SubmitSignalRequest(signal=proto_signal)
            if self._bot_id:
                request.bot_id = self._bot_id

            response = await self._stub.SubmitSignal(request, timeout=10.0)

            if response.success:
                logger.info(f"Signal published: {symbol} {signal_type} (id={response.signal_id})")
                return True, response.signal_id
            else:
                logger.warning(f"Signal rejected: {response.message} (error={response.error})")
                return False, response.error or response.message

        except grpc.RpcError as e:
            logger.error(f"gRPC error: {e.code()} - {e.details()}")
            return False, str(e.details())

        except Exception as e:
            logger.error(f"Error publishing signal: {e}")
            return False, str(e)

    def _create_proto_signal(
        self,
        signal_type: str,
        symbol: str,
        price: Optional[str] = None,
        stop_loss: Optional[str] = None,
        take_profit: Optional[str] = None,
        targets: Optional[list[tuple[int, str]]] = None,
        entry_min: Optional[str] = None,
        entry_max: Optional[str] = None,
        leverage: Optional[int] = None,
        exchange: Optional[str] = None,
        market_type: Optional[str] = None,
        confidence: float = 0.0,
        signal_id: Optional[str] = None,
        message_text: str = "",
    ) -> pb2.TradingSignal:
        """Create protobuf signal message."""
        proto_type = SIGNAL_TYPE_MAP.get(
            signal_type.lower(),
            pb2.SIGNAL_TYPE_UNSPECIFIED,
        )

        proto = pb2.TradingSignal(
            signal_id=signal_id or str(uuid.uuid4()),
            signal_type=proto_type,
            source=self._source,
            symbol=symbol,
            channel_name=self._source,
            channel_username="",
            message_id=0,
            message_text=message_text[:1000] if message_text else "",
        )

        if price:
            proto.price = price
        if stop_loss:
            proto.stop_loss = stop_loss
        if take_profit:
            proto.take_profit = take_profit
        if entry_min:
            proto.entry_min = entry_min
        if entry_max:
            proto.entry_max = entry_max
        if leverage:
            proto.leverage = leverage
        if exchange:
            proto.exchange = exchange
        if market_type:
            proto.market_type = market_type

        proto.confidence = str(confidence)
        proto.completeness = "1.0"

        if targets:
            for level, target_price in targets:
                proto.targets.append(pb2.TargetPrice(
                    level=level,
                    price=target_price,
                ))

        ts = Timestamp()
        ts.FromDatetime(datetime.now(timezone.utc))
        proto.extracted_at.CopyFrom(ts)

        return proto

    async def publish_batch(
        self,
        signals: list[dict],
    ) -> tuple[int, int]:
        """
        Publish multiple signals in batch.

        Args:
            signals: List of signal dicts with same args as publish_signal

        Returns:
            Tuple of (accepted_count, rejected_count)
        """
        if not self._stub:
            return 0, len(signals)

        try:
            proto_signals = []
            for sig in signals:
                proto_signals.append(self._create_proto_signal(**sig))

            request = pb2.SubmitSignalBatchRequest(signals=proto_signals)
            if self._bot_id:
                request.bot_id = self._bot_id

            response = await self._stub.SubmitSignalBatch(request, timeout=30.0)

            logger.info(f"Batch published: {response.accepted}/{response.total} accepted")
            return response.accepted, response.rejected

        except grpc.RpcError as e:
            logger.error(f"gRPC error in batch: {e.code()} - {e.details()}")
            return 0, len(signals)

    async def __aenter__(self) -> "SignalPublisher":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
