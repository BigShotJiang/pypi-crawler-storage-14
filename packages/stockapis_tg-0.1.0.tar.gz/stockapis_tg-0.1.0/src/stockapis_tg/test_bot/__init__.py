"""
Test bot utilities for E2E testing.

Uses simple Telegram Bot API - just needs BOT_TOKEN.
"""

from .send import TEST_SIGNALS, send_all_signals, send_test_signal

__all__ = [
    "send_test_signal",
    "send_all_signals",
    "TEST_SIGNALS",
]
