"""DuckDB storage backend for ragcrawl."""

from ragcrawl.storage.duckdb.backend import DuckDBBackend

__all__ = ["DuckDBBackend"]
