"""Minimal smoke test to ensure pytest collects at least one test within the package."""


def test_smoke():
    """Basic sanity check so CI always executes at least one test."""
    assert True
