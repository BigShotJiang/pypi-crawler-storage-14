# flake8: noqa

# import apis into api package
from magpiepay.api.payments_api import PaymentsApi
from magpiepay.api.payouts_api import PayoutsApi
from magpiepay.api.qrph_requests_api import QRPhRequestsApi
from magpiepay.api.references_api import ReferencesApi

