"""Excel MCP Server - Convert Excel files to Markdown tables."""

__version__ = "0.1.0"
