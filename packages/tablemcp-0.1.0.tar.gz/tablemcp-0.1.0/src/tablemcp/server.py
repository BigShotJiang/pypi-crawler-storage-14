"""MCP Server for Excel to Markdown conversion."""

from mcp.server.fastmcp import FastMCP

from .converter import convert_excel_file, convert_sheet, list_excel_sheets

mcp = FastMCP("tablemcp")


@mcp.tool()
def read_excel_as_markdown(file_path: str) -> str:
    """
    Convert an Excel file to Markdown tables.

    Reads all sheets from the Excel file and returns them as formatted
    Markdown tables, with each sheet labeled by name.

    Args:
        file_path: Absolute path to the Excel file (.xlsx or .xls)

    Returns:
        Markdown formatted tables for all sheets in the file
    """
    results = convert_excel_file(file_path)

    output_parts = []
    for sheet_name, markdown in results.items():
        output_parts.append(f"## Sheet: {sheet_name}\n\n{markdown}")

    return "\n\n".join(output_parts)


@mcp.tool()
def read_excel_sheet_as_markdown(
    file_path: str,
    sheet_name: str,
    header_row: int | None = None,
    columns: str | None = None,
) -> str:
    """
    Convert a specific sheet from an Excel file to a Markdown table.

    Args:
        file_path: Absolute path to the Excel file (.xlsx or .xls)
        sheet_name: Name of the sheet to convert
        header_row: Optional header row number (1-based). If not provided, auto-detects.
        columns: Optional column range like 'A:D' or '1-4'. If not provided, auto-detects.

    Returns:
        Markdown formatted table for the specified sheet
    """
    return convert_sheet(file_path, sheet_name, header_row, columns)


@mcp.tool()
def list_sheets(file_path: str) -> list[str]:
    """
    List all sheet names in an Excel file.

    Args:
        file_path: Absolute path to the Excel file (.xlsx or .xls)

    Returns:
        List of sheet names in the file
    """
    return list_excel_sheets(file_path)


def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
