"""Excel to Markdown conversion logic."""

from pathlib import Path

import pandas as pd


def detect_table_start(df: pd.DataFrame) -> int | None:
    """
    Detect the starting row of the table by finding the first row
    that is completely filled within the non-null columns.

    Args:
        df: DataFrame to analyze

    Returns:
        Row index where table starts, or None if not found
    """
    non_null_columns = df.columns[df.notnull().any(axis=0)]
    if len(non_null_columns) == 0:
        return None

    left_col_index = df.columns.get_loc(non_null_columns[0])
    right_col_index = df.columns.get_loc(non_null_columns[-1])

    for idx, row in df.iterrows():
        row_slice = row.iloc[left_col_index : right_col_index + 1]
        if (
            row_slice.notnull().all()
            and not row_slice.astype(str).str.strip().eq("").any()
        ):
            return idx

    return None


def get_table_region(df: pd.DataFrame) -> tuple[int, list]:
    """
    Detect table region including header row and relevant columns.

    Args:
        df: DataFrame to analyze

    Returns:
        Tuple of (header_row_index, list_of_column_indices)
    """
    start_row = detect_table_start(df)
    if start_row is not None:
        threshold = 0.49
        valid_cols = [
            col for col in df.columns if df[col].notnull().mean() > threshold
        ]
        return start_row, valid_cols
    return 0, list(df.columns)


def dataframe_to_markdown(df: pd.DataFrame) -> str:
    """
    Convert a pandas DataFrame to a Markdown table.

    Args:
        df: DataFrame to convert

    Returns:
        Markdown-formatted table string
    """
    if df.empty:
        return ""

    markdown = "| " + " | ".join(str(col) for col in df.columns) + " |\n"
    markdown += "| " + " | ".join(["---"] * len(df.columns)) + " |\n"

    for _, row in df.iterrows():
        row_values = [str(cell) if pd.notnull(cell) else "" for cell in row]
        # Escape pipe characters in cell values
        row_values = [v.replace("|", "\\|") for v in row_values]
        markdown += "| " + " | ".join(row_values) + " |\n"

    return markdown


def column_letter_to_index(letter: str) -> int:
    """
    Convert Excel column letter to zero-based index.

    Args:
        letter: Column letter (e.g., 'A', 'AA')

    Returns:
        Zero-based column index
    """
    result = 0
    for char in letter.upper():
        result = result * 26 + (ord(char) - ord("A") + 1)
    return result - 1


def parse_columns(cols_input: str, df: pd.DataFrame) -> list:
    """
    Parse column specification string.

    Args:
        cols_input: Column spec like 'A:D' or '1-4'
        df: DataFrame to get columns from

    Returns:
        List of column names
    """
    cols_input = cols_input.replace(" ", "").upper()
    if ":" in cols_input:
        start, end = cols_input.split(":")
    elif "-" in cols_input:
        start, end = cols_input.split("-")
    else:
        start, end = cols_input, cols_input

    if start.isalpha() and end.isalpha():
        start_idx = column_letter_to_index(start)
        end_idx = column_letter_to_index(end)
    elif start.isdigit() and end.isdigit():
        start_idx = int(start) - 1
        end_idx = int(end) - 1
    else:
        raise ValueError("Mixed or invalid column specification.")

    if start_idx > end_idx:
        raise ValueError("Start column comes after end column.")

    return df.columns[start_idx : end_idx + 1].tolist()


def convert_excel_file(file_path: str | Path) -> dict[str, str]:
    """
    Convert all sheets in an Excel file to Markdown.

    Args:
        file_path: Path to Excel file

    Returns:
        Dictionary mapping sheet names to markdown content
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    if not file_path.suffix.lower() in (".xlsx", ".xls"):
        raise ValueError(f"Unsupported file type: {file_path.suffix}")

    results = {}
    excel = pd.ExcelFile(file_path, engine="openpyxl")

    for sheet_name in excel.sheet_names:
        results[sheet_name] = convert_sheet(file_path, sheet_name)

    return results


def convert_sheet(
    file_path: str | Path,
    sheet_name: str | int = 0,
    header_row: int | None = None,
    columns: str | None = None,
) -> str:
    """
    Convert a specific sheet to Markdown.

    Args:
        file_path: Path to Excel file
        sheet_name: Sheet name or index
        header_row: Optional manual header row (1-based)
        columns: Optional column range like 'A:D' or '1-4'

    Returns:
        Markdown table string
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    df_full = pd.read_excel(
        file_path, sheet_name=sheet_name, header=None, engine="openpyxl"
    )

    if header_row is not None and columns is not None:
        # Manual specification
        usecols = parse_columns(columns, df_full)
        detected_header = header_row - 1  # Convert to 0-based
    else:
        # Auto-detect
        detected_header, usecols = get_table_region(df_full)

    df = pd.read_excel(
        file_path,
        sheet_name=sheet_name,
        header=detected_header,
        usecols=usecols if usecols else None,
        engine="openpyxl",
    )

    df.dropna(how="all", inplace=True)
    df.reset_index(drop=True, inplace=True)

    return dataframe_to_markdown(df)


def list_excel_sheets(file_path: str | Path) -> list[str]:
    """
    List all sheet names in an Excel file.

    Args:
        file_path: Path to Excel file

    Returns:
        List of sheet names
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    excel = pd.ExcelFile(file_path, engine="openpyxl")
    return excel.sheet_names
