"""Tests for Excel to Markdown converter."""

import tempfile
from pathlib import Path

import pandas as pd
import pytest

from tablemcp.converter import (
    column_letter_to_index,
    convert_excel_file,
    convert_sheet,
    dataframe_to_markdown,
    detect_table_start,
    list_excel_sheets,
    parse_columns,
)


class TestDataframeToMarkdown:
    def test_simple_dataframe(self):
        df = pd.DataFrame({"Name": ["Alice", "Bob"], "Age": [30, 25]})
        result = dataframe_to_markdown(df)

        assert "| Name | Age |" in result
        assert "| --- | --- |" in result
        assert "| Alice | 30 |" in result
        assert "| Bob | 25 |" in result

    def test_empty_dataframe(self):
        df = pd.DataFrame()
        result = dataframe_to_markdown(df)
        assert result == ""

    def test_dataframe_with_null_values(self):
        df = pd.DataFrame({"A": ["a", None, "c"], "B": ["x", "y", None]})
        result = dataframe_to_markdown(df)

        assert "| a | x |" in result
        assert "|  | y |" in result
        assert "| c |  |" in result

    def test_escapes_pipe_characters(self):
        df = pd.DataFrame({"Col": ["value|with|pipes"]})
        result = dataframe_to_markdown(df)
        assert "\\|" in result


class TestColumnLetterToIndex:
    def test_single_letters(self):
        assert column_letter_to_index("A") == 0
        assert column_letter_to_index("B") == 1
        assert column_letter_to_index("Z") == 25

    def test_double_letters(self):
        assert column_letter_to_index("AA") == 26
        assert column_letter_to_index("AB") == 27
        assert column_letter_to_index("AZ") == 51

    def test_lowercase(self):
        assert column_letter_to_index("a") == 0
        assert column_letter_to_index("aa") == 26


class TestParseColumns:
    def test_letter_range_colon(self):
        df = pd.DataFrame(columns=["A", "B", "C", "D", "E"])
        result = parse_columns("A:C", df)
        assert result == ["A", "B", "C"]

    def test_letter_range_dash(self):
        df = pd.DataFrame(columns=["A", "B", "C", "D", "E"])
        result = parse_columns("B-D", df)
        assert result == ["B", "C", "D"]

    def test_numeric_range(self):
        df = pd.DataFrame(columns=["Col1", "Col2", "Col3", "Col4"])
        result = parse_columns("1-3", df)
        assert result == ["Col1", "Col2", "Col3"]

    def test_single_column(self):
        df = pd.DataFrame(columns=["A", "B", "C"])
        result = parse_columns("B", df)
        assert result == ["B"]

    def test_invalid_range_order(self):
        df = pd.DataFrame(columns=["A", "B", "C"])
        with pytest.raises(ValueError, match="Start column comes after"):
            parse_columns("C:A", df)


class TestDetectTableStart:
    def test_table_at_start(self):
        df = pd.DataFrame({0: ["Header1", "Data1"], 1: ["Header2", "Data2"]})
        result = detect_table_start(df)
        assert result == 0

    def test_table_with_empty_rows_above(self):
        df = pd.DataFrame(
            {
                0: [None, None, "Header1", "Data1"],
                1: [None, None, "Header2", "Data2"],
            }
        )
        result = detect_table_start(df)
        assert result == 2

    def test_empty_dataframe(self):
        df = pd.DataFrame({0: [None, None], 1: [None, None]})
        result = detect_table_start(df)
        assert result is None


class TestExcelIntegration:
    @pytest.fixture
    def sample_excel_file(self):
        """Create a temporary Excel file for testing."""
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
            file_path = Path(f.name)

        df1 = pd.DataFrame({"Name": ["Alice", "Bob"], "Score": [95, 87]})
        df2 = pd.DataFrame(
            {"Product": ["Widget", "Gadget"], "Price": [10.99, 24.99]}
        )

        with pd.ExcelWriter(file_path, engine="openpyxl") as writer:
            df1.to_excel(writer, sheet_name="Students", index=False)
            df2.to_excel(writer, sheet_name="Products", index=False)

        yield file_path

        file_path.unlink()

    def test_list_sheets(self, sample_excel_file):
        sheets = list_excel_sheets(sample_excel_file)
        assert sheets == ["Students", "Products"]

    def test_convert_single_sheet(self, sample_excel_file):
        result = convert_sheet(sample_excel_file, "Students")
        assert "| Name | Score |" in result
        assert "| Alice | 95 |" in result

    def test_convert_all_sheets(self, sample_excel_file):
        results = convert_excel_file(sample_excel_file)
        assert "Students" in results
        assert "Products" in results
        assert "Alice" in results["Students"]
        assert "Widget" in results["Products"]

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            convert_sheet("/nonexistent/file.xlsx", "Sheet1")

    def test_invalid_file_type(self, tmp_path):
        fake_file = tmp_path / "test.txt"
        fake_file.write_text("not an excel file")
        with pytest.raises(ValueError, match="Unsupported file type"):
            convert_excel_file(fake_file)
