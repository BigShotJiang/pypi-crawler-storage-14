# tablemcp

An MCP (Model Context Protocol) server that converts Excel files to Markdown tables.

## Installation

```bash
# Using uvx (recommended)
uvx tablemcp

# Or install via pip
pip install tablemcp
```

## Usage with Claude Code

Add to your Claude Code MCP settings (`~/.claude/settings.json`):

```json
{
  "mcpServers": {
    "excel": {
      "command": "uvx",
      "args": ["tablemcp"]
    }
  }
}
```

## Available Tools

### `read_excel_as_markdown`

Convert an entire Excel file (all sheets) to Markdown tables.

**Parameters:**
- `file_path` (string): Absolute path to the Excel file (.xlsx or .xls)

**Returns:** Markdown formatted tables for all sheets

### `read_excel_sheet_as_markdown`

Convert a specific sheet from an Excel file to a Markdown table.

**Parameters:**
- `file_path` (string): Absolute path to the Excel file
- `sheet_name` (string): Name of the sheet to convert
- `header_row` (int, optional): Header row number (1-based). Auto-detects if not provided.
- `columns` (string, optional): Column range like 'A:D' or '1-4'. Auto-detects if not provided.

**Returns:** Markdown formatted table

### `list_sheets`

List all sheet names in an Excel file.

**Parameters:**
- `file_path` (string): Absolute path to the Excel file

**Returns:** List of sheet names

## Features

- Automatic table detection (finds header rows and relevant columns)
- Multi-sheet support
- Manual column/row specification for complex layouts
- Handles null values gracefully
- Escapes pipe characters in cell values

## Development

```bash
# Clone and install dependencies
git clone https://github.com/jvsteiner/tablemcp
cd tablemcp
uv sync

# Run tests
uv run pytest

# Run the server locally
uv run tablemcp
```

## License

MIT
