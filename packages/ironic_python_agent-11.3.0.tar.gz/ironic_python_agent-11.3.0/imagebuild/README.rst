ironic-python-agent images
==========================

The content has been moved to `ironic-python-agent-builder
<https://docs.openstack.org/ironic-python-agent-builder>`_.
