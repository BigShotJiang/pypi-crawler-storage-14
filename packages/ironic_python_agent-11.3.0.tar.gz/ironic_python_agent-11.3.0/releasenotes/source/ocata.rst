==========================================
Ocata Series (2.0.0 - 2.0.x) Release Notes
==========================================

.. release-notes::
   :branch: origin/stable/ocata
