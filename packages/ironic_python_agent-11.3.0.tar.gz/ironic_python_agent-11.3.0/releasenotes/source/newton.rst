===========================================
Newton Series (1.3.0 - 1.5.x) Release Notes
===========================================

.. release-notes::
   :branch: origin/stable/newton
