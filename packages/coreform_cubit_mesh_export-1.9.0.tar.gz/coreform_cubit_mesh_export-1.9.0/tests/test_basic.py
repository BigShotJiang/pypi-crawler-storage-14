"""Basic tests for cubit_mesh_export module.

Note: These tests require Cubit to be installed and available.
They are primarily placeholder tests to establish the testing structure.
"""

import unittest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cubit_mesh_export


class TestModuleImport(unittest.TestCase):
	"""Test that the module can be imported successfully."""

	def test_module_exists(self):
		"""Test that cubit_mesh_export module exists."""
		self.assertIsNotNone(cubit_mesh_export)

	def test_functions_exist(self):
		"""Test that all main export functions exist (snake_case)."""
		self.assertTrue(hasattr(cubit_mesh_export, 'export_exodus'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_gmsh_v2'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_gmsh_v4'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_nastran'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_netgen'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_meg'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_vtk'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_vtu'))

	def test_legacy_functions_exist(self):
		"""Test that legacy PascalCase function names still exist."""
		self.assertTrue(hasattr(cubit_mesh_export, 'export_Gmsh_ver2'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_Gmsh_ver4'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_Nastran'))
		self.assertTrue(hasattr(cubit_mesh_export, 'export_NetgenMesh'))

	def test_functions_callable(self):
		"""Test that export functions are callable."""
		self.assertTrue(callable(cubit_mesh_export.export_exodus))
		self.assertTrue(callable(cubit_mesh_export.export_gmsh_v2))
		self.assertTrue(callable(cubit_mesh_export.export_gmsh_v4))
		self.assertTrue(callable(cubit_mesh_export.export_nastran))
		self.assertTrue(callable(cubit_mesh_export.export_netgen))
		self.assertTrue(callable(cubit_mesh_export.export_meg))
		self.assertTrue(callable(cubit_mesh_export.export_vtk))
		self.assertTrue(callable(cubit_mesh_export.export_vtu))

	def test_aliases_point_to_same_function(self):
		"""Test that snake_case aliases point to the same functions."""
		self.assertIs(cubit_mesh_export.export_gmsh_v2, cubit_mesh_export.export_Gmsh_ver2)
		self.assertIs(cubit_mesh_export.export_gmsh_v4, cubit_mesh_export.export_Gmsh_ver4)
		self.assertIs(cubit_mesh_export.export_nastran, cubit_mesh_export.export_Nastran)
		self.assertIs(cubit_mesh_export.export_netgen, cubit_mesh_export.export_NetgenMesh)


class TestFunctionSignatures(unittest.TestCase):
	"""Test function signatures and default parameters."""

	def test_export_gmsh_v2_signature(self):
		"""Test export_gmsh_v2 has correct parameters."""
		import inspect
		sig = inspect.signature(cubit_mesh_export.export_gmsh_v2)
		params = list(sig.parameters.keys())
		self.assertIn('cubit', params)
		self.assertIn('FileName', params)

	def test_export_nastran_defaults(self):
		"""Test export_nastran has correct default parameters."""
		import inspect
		sig = inspect.signature(cubit_mesh_export.export_nastran)
		self.assertEqual(sig.parameters['DIM'].default, "3D")
		self.assertEqual(sig.parameters['PYRAM'].default, True)

	def test_export_meg_defaults(self):
		"""Test export_meg has correct default parameters."""
		import inspect
		sig = inspect.signature(cubit_mesh_export.export_meg)
		self.assertEqual(sig.parameters['DIM'].default, 'T')
		self.assertEqual(sig.parameters['MGR2'].default, None)

	def test_export_vtk_signature(self):
		"""Test export_vtk has correct parameters."""
		import inspect
		sig = inspect.signature(cubit_mesh_export.export_vtk)
		params = list(sig.parameters.keys())
		self.assertIn('cubit', params)
		self.assertIn('FileName', params)
		# Note: ORDER parameter was removed in v1.5.1 (auto-detection)

	def test_export_vtu_defaults(self):
		"""Test export_vtu has correct default parameters."""
		import inspect
		sig = inspect.signature(cubit_mesh_export.export_vtu)
		self.assertEqual(sig.parameters['binary'].default, False)

	def test_export_netgen_defaults(self):
		"""Test export_netgen has correct default parameters."""
		import inspect
		sig = inspect.signature(cubit_mesh_export.export_netgen)
		self.assertEqual(sig.parameters['geometry_file'].default, None)

	def test_export_exodus_defaults(self):
		"""Test export_exodus has correct default parameters."""
		import inspect
		sig = inspect.signature(cubit_mesh_export.export_exodus)
		self.assertEqual(sig.parameters['overwrite'].default, True)
		self.assertEqual(sig.parameters['large_model'].default, False)


if __name__ == '__main__':
	unittest.main()
