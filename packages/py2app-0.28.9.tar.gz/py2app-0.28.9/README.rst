py2app is a Python setuptools command which will allow
you to make standalone Mac OS X application bundles
and plugins from Python scripts.

py2app is similar in purpose and design to py2exe for
Windows.

NOTE: py2app must be used on macOS to build applications,
it cannot create Mac applications on other platforms.

Project links
-------------

* `Documentation <https://py2app.readthedocs.io/en/latest/>`_

* `Issue Tracker <https://github.com/ronaldoussoren/py2app/issues>`_

* `Repository <https://github.com/ronaldoussoren/py2app/>`_
