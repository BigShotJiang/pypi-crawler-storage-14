""" py2app tests """
