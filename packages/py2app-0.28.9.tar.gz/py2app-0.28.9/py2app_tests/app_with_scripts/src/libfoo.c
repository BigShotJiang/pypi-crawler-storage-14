#include "libfoo.h"


int square(int value)
{
	return value * value;
}
