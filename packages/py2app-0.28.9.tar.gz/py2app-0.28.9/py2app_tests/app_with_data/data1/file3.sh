#!/bin/sh

echo "Hello world"
exit 0
