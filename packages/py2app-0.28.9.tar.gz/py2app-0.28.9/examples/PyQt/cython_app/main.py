import testLoad
from logging import basicConfig

def main():
    testLoad.main()

if __name__ == '__main__':
    main()
