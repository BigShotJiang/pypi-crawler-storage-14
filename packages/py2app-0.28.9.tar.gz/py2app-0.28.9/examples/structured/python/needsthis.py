from __future__ import print_function
print("needsthis found")
print("data file: ", open('data/datafile.txt', 'r').read())
