#!/bin/bash

wget https://homepage.iihe.ac.be/~mitjadesmet/origin_showers/SIM145024.hdf5

wget https://homepage.iihe.ac.be/~mitjadesmet/origin_showers/SIM145060.hdf5