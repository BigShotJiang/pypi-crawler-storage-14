Package documentation
=====================

.. toctree::
   :maxdepth: 1

   ../apidoc/smiet.numpy.io
   ../apidoc/smiet.numpy.synthesis
   ../apidoc/smiet.numpy.utilities
   ../apidoc/smiet.units
