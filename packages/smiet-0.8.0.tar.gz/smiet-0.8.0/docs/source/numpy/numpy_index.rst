NumPy module
============

The NumPy version of the template synthesis package is considered the standard version.
By default, when importing from the `template-synthesis` package, the NumPy version is resolved.
More information about the module structure can be found in the :doc:`module_structure` documentation.

.. toctree::
    :maxdepth: 2

    module_structure
    package_documentation