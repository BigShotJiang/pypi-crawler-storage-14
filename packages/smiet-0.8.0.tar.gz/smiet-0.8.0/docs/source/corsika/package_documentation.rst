Package documentation
=====================

.. toctree::
   :maxdepth: 1

   ../apidoc/smiet.corsika
