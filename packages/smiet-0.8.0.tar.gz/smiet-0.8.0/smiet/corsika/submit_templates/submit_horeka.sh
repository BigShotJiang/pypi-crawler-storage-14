#!/bin/bash
#SBATCH --partition=cpuonly
#SBATCH --job-name=xmax{0:.0f}_zen{1:.0f}_{7:06d}
#SBATCH --output={2}/logs/log-%j.out
#SBATCH --error={2}/logs/log-%j.err
#SBATCH --nodes={3}
#SBATCH --ntasks-per-node={4}
#SBATCH --cpus-per-task=1  # Keep this to 1 to distribute tasks correctly
#SBATCH --time=18:00:00
#SBATCH --mem-per-cpu=3200mb

# loading necessary modules
module load compiler/intel/2023.1.0
module load mpi/openmpi/5.0
module load numlib/mkl/2022.0.2

# echo slurm variables
echo "SLURM_NTASKS: $SLURM_NTASKS"
echo "SLURM_CPUS_ON_NODE: $SLURM_CPUS_ON_NODE"
echo "SLURM_CPUS_PER_TASK: $SLURM_CPUS_PER_TASK"

# run corsika
time mpirun --bind-to core --map-by core -report-bindings {5}/{6} {2}/SIM{7:06d}/SIM{7:06d}.inp > {2}/SIM{7:06d}/SIM{7:06d}.log

# Remove unnecessary files
rm {2}/SIM{7:06d}/*.cut
rm {2}/SIM{7:06d}/*.lst
rm {2}/SIM{7:06d}/corsika_timetable*

ls {2}

# generate origin shower
python {8}/coreas_to_hdf5_origin.py {2}/SIM{7:06d}/SIM{7:06d}.reas --outputDirectory={8}/hdf5_sims

# zip the raw traces
zip -r {2}/SIM{7:06d}/SIM{7:06d}_coreas.zip {2}/SIM{7:06d}/SIM{7:06d}_coreas

# also remove the contents
rm -r {2}/SIM{7:06d}/SIM{7:06d}_coreas