export class SMAAPass {
    constructor(width: number, height: number);
    renderToScreen: boolean;
}

