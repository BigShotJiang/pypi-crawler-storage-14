import { BufferGeometry, Vector3 } from "../lib/three-core";

export class ConvexGeometry extends BufferGeometry {
    constructor(points: Vector3[]);
}