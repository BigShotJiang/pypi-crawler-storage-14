"""Tests for ACE integrations with external agentic frameworks."""
