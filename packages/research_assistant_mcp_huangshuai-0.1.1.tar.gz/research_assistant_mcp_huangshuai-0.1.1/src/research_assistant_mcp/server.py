"""
科研资料云端整理助手 MCP Server.

该示例通过 FastMCP 暴露三个工具，分别负责论文检索、阅读计划生成以及笔记整理。
"""
from __future__ import annotations

import textwrap
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta

import httpx
from mcp.server.fastmcp import FastMCP

ARXIV_API_ENDPOINT = "https://export.arxiv.org/api/query"
USER_AGENT = "learnMCP-research-assistant/0.1"
DEFAULT_MAX_RESULTS = 5
SUMMARY_MAX_LENGTH = 120

mcp = FastMCP("ResearchAssistantServer")


async def fetch_arxiv_entries(topic: str, max_results: int) -> list[dict[str, str]]:
    """调用 arXiv API 并解析返回的 Atom Feed。"""
    params = {
        "search_query": f"all:{topic}",
        "start": 0,
        "max_results": max(min(max_results, 10), 1),
        "sortBy": "submittedDate",
        "sortOrder": "descending",
    }
    headers = {"User-Agent": USER_AGENT}
    async with httpx.AsyncClient(timeout=30.0, headers=headers, follow_redirects=True) as client:
        response = await client.get(ARXIV_API_ENDPOINT, params=params)
        response.raise_for_status()
    return parse_arxiv_feed(response.text)


def parse_arxiv_feed(feed_xml: str) -> list[dict[str, str]]:
    """将 arXiv Atom Feed 解析为便于展示的结构。"""
    ns = {"atom": "http://www.w3.org/2005/Atom"}
    root = ET.fromstring(feed_xml)
    entries: list[dict[str, str]] = []
    for entry in root.findall("atom:entry", ns):
        title = entry.findtext("atom:title", default="未知标题", namespaces=ns).strip()
        summary = entry.findtext("atom:summary", default="", namespaces=ns).strip()
        authors = [
            author.findtext("atom:name", default="", namespaces=ns).strip()
            for author in entry.findall("atom:author", ns)
        ]
        link = entry.find("atom:link[@rel='alternate']", ns)
        pdf_link = entry.find("atom:link[@title='pdf']", ns)
        primary_link = (link or pdf_link)
        entries.append(
            {
                "title": title,
                "summary": clean_summary(summary),
                "authors": ", ".join(filter(None, authors)) or "未知作者",
                "link": primary_link.get("href") if primary_link is not None else "N/A",
                "published": entry.findtext("atom:published", default="", namespaces=ns),
            }
        )
    return entries


def clean_summary(summary: str) -> str:
    """压缩摘要，避免在 MCP 客户端中展示过长文本。"""
    collapsed = " ".join(summary.split())
    if len(collapsed) <= SUMMARY_MAX_LENGTH:
        return collapsed
    return f"{collapsed[:SUMMARY_MAX_LENGTH]}..."


def format_papers(entries: list[dict[str, str]]) -> str:
    """将论文条目格式化为 Markdown 列表。"""
    if not entries:
        return "未找到相关论文，可尝试更换关键词。"
    parts = []
    for idx, item in enumerate(entries, start=1):
        published = item["published"][:10] if item["published"] else "未知日期"
        parts.append(
            textwrap.dedent(
                f"""\
                {idx}. **{item['title']}**  
                   - 作者：{item['authors']}  
                   - 日期：{published}  
                   - 摘要：{item['summary']}  
                   - 链接：{item['link']}
                """
            ).strip()
        )
    return "\n\n".join(parts)


def build_time_blocks(available_hours: int, target_papers: int) -> list[tuple[str, int]]:
    """根据可用时间，为不同任务环节分配工时。"""
    available_hours = max(1, min(available_hours, 40))
    target_papers = max(1, min(target_papers, 10))
    per_paper = available_hours / target_papers
    return [
        ("快速浏览与筛选", round(per_paper * 0.3, 1)),
        ("精读与批注", round(per_paper * 0.5, 1)),
        ("总结与回顾", round(per_paper * 0.2, 1)),
    ]


def format_reading_plan(topic: str, available_hours: int, target_papers: int) -> str:
    """输出分阶段的阅读计划。"""
    blocks = build_time_blocks(available_hours, target_papers)
    today = datetime.utcnow()
    plan_lines = [
        f"### 主题：{topic}",
        f"- 时间预算：{available_hours} 小时",
        f"- 目标论文数：{target_papers} 篇",
        f"- 建议起止：{today.date()} ~ {(today + timedelta(days=target_papers)).date()}",
        "",
        "#### 分阶段安排",
    ]
    for stage, hours in blocks:
        plan_lines.append(f"- {stage}：约 {hours} 小时/篇")
    plan_lines.append("")
    plan_lines.append("#### 执行建议")
    plan_lines.extend(
        [
            "1. 用 `search_papers` 工具锁定候选论文，并输出 Markdown 表格存档；",
            "2. 将 `organize_notes` 输出同步到云笔记或 Git 仓库，建立可追溯的知识库；",
            "3. 每完成一篇精读，即刻补充关键方法/引用信息，确保上下游同步。",
        ]
    )
    return "\n".join(plan_lines)


def structure_notes(raw_notes: str) -> str:
    """将原始笔记切分为概念/方法/引用三大区域。"""
    concepts, methods, references = [], [], []
    for line in raw_notes.splitlines():
        normalized = line.strip()
        if not normalized:
            continue
        lowered = normalized.lower()
        if lowered.startswith(("method:", "experiment:", "approach:")):
            methods.append(normalized.split(":", 1)[1].strip())
        elif lowered.startswith(("ref:", "cite:", "doi:")):
            references.append(normalized.split(":", 1)[1].strip())
        else:
            concepts.append(normalized.lstrip("-* "))
    concept_block = format_note_block(concepts)
    method_block = format_note_block(methods)
    reference_block = format_note_block(references)
    return textwrap.dedent(
        f"""\
        ### 核心概念
        - {concept_block}

        ### 技术方法 / 实验设计
        - {method_block}

        ### 引文 / 参考资料
        - {reference_block}
        """
    ).strip()


def format_note_block(items: list[str]) -> str:
    """生成多行 Markdown 列表内容。"""
    return "\n- ".join(items) if items else "（待补充）"


@mcp.tool()
async def search_papers(topic: str, max_results: int = DEFAULT_MAX_RESULTS) -> str:
    """
    检索指定主题的 arXiv 论文。

    :param topic: 主题关键词，例如 "multi-modal llm"
    :param max_results: 返回的论文数量（1~10）
    """
    try:
        entries = await fetch_arxiv_entries(topic, max_results)
    except httpx.HTTPError as exc:
        return f"检索失败：{exc}"
    except ET.ParseError as exc:
        return f"解析 arXiv 数据时出错：{exc}"
    return format_papers(entries)


@mcp.tool()
def build_reading_plan(topic: str, available_hours: int = 6, target_papers: int = 3) -> str:
    """
    生成可执行的科研阅读计划。

    :param topic: 学习主题
    :param available_hours: 可支配总时长（小时）
    :param target_papers: 计划精读的论文数
    """
    return format_reading_plan(topic, available_hours, target_papers)


@mcp.tool()
def organize_notes(raw_notes: str) -> str:
    """
    将零散笔记整理成结构化 Markdown。

    :param raw_notes: 包含多行内容的原始记录，可包含 "method:"、"ref:" 等前缀
    """
    if not raw_notes.strip():
        return "未检测到笔记内容，请输入至少一行文本。"
    return structure_notes(raw_notes)


def main() -> None:
    """以 stdio 方式运行 MCP Server。"""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()

