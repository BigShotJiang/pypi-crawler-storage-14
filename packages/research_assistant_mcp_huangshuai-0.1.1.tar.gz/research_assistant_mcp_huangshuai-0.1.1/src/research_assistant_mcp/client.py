from __future__ import annotations

"""
科研资料云端整理助手 MCP Client（接入硅基流动大模型）

本客户端示例演示如何：
1. 通过 mcp Python SDK 以 STDIO 方式拉起本项目的 MCP Server；
2. 使用硅基流动兼容的 OpenAI 接口加载 DeepSeek 模型；
3. 通过 Function Calling 机制，让大模型自动决定何时调用
   `search_papers`、`build_reading_plan`、`organize_notes` 三个工具；
4. 在终端中以自然语言与“科研资料云端整理助手”对话。

运行前请在项目根目录的 `.env` 中配置：
BASE_URL=https://api.siliconflow.cn/v1
MODEL=deepseek-ai/DeepSeek-V3
API_KEY=你的_API_Key
"""

import asyncio
import os
import sys
from contextlib import AsyncExitStack
from typing import Any, Dict, List

from dotenv import load_dotenv
from mcp import ClientSession, StdioServerParameters, stdio_client
from openai import OpenAI


# 从 .env 加载硅基流动的 LLM 配置
load_dotenv()

BASE_URL = os.getenv("BASE_URL")
MODEL = os.getenv("MODEL")
API_KEY = os.getenv("API_KEY")


def _ensure_llm_config() -> None:
    missing: List[str] = []
    if not BASE_URL:
        missing.append("BASE_URL")
    if not MODEL:
        missing.append("MODEL")
    if not API_KEY:
        missing.append("API_KEY")
    if missing:
        joined = ", ".join(missing)
        raise RuntimeError(
            f"缺少必要的 LLM 配置：{joined}。请在项目根目录的 .env 中设置这些环境变量。"
        )


class ResearchAssistantClient:
    """科研资料云端整理助手的命令行 MCP 客户端。"""

    def __init__(self, server_script: str) -> None:
        _ensure_llm_config()
        self.server_script = os.path.abspath(server_script)
        self.exit_stack = AsyncExitStack()
        self.session: ClientSession | None = None
        self.llm = OpenAI(api_key=API_KEY, base_url=BASE_URL)

    async def connect(self) -> None:
        """启动并连接 MCP Server。"""
        server_params = StdioServerParameters(
            command="python",
            args=[self.server_script],
            env=os.environ.copy(),
            cwd=os.path.dirname(self.server_script),
        )

        # stdio_client 和 ClientSession 都是异步上下文管理器，这里统一交给 AsyncExitStack 管理
        read, write = await self.exit_stack.enter_async_context(stdio_client(server_params))
        self.session = await self.exit_stack.enter_async_context(ClientSession(read, write))
        await self.session.initialize()

        tools = await self.session.list_tools()
        print("已连接到 ResearchAssistantServer，当前可用工具：")
        for tool in tools.tools:
            print(f"- {tool.name}: {tool.description or ''}")
        print("-" * 60)

    async def close(self) -> None:
        """关闭会话。"""
        # 统一由 AsyncExitStack 负责资源清理
        await self.exit_stack.aclose()
        self.session = None

    async def call_tool(self, name: str, arguments: Dict[str, Any]) -> None:
        """调用指定的 MCP 工具并打印结果（供手动测试使用）。"""
        result_text = await self._invoke_tool(name, arguments)
        print("\n=== 工具返回 ===")
        print(result_text)
        print("================\n")

    async def _invoke_tool(self, name: str, arguments: Dict[str, Any]) -> str:
        """调用指定的 MCP 工具并打印结果。"""
        if self.session is None:
            raise RuntimeError("会话尚未初始化，请先调用 connect()。")

        result = await self.session.call_tool(name, arguments)

        # MCP Tool 调用结果可能包含多个 content 项，这里简单拼接为文本返回
        texts: list[str] = []
        for item in result.content:
            if item.type == "text":
                texts.append(item.text)
        return "\n\n".join(texts)

    async def chat_with_llm(self) -> None:
        """与大模型进行多轮对话，由模型自动决定是否调用 MCP 工具。"""
        assert self.session is not None

        tools = [
            {
                "type": "function",
                "function": {
                    "name": "search_papers",
                    "description": "在 arXiv 上检索指定主题的最新论文。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "topic": {"type": "string", "description": "论文主题关键词"},
                            "max_results": {
                                "type": "integer",
                                "description": "返回的论文数量（1-10）",
                                "minimum": 1,
                                "maximum": 10,
                            },
                        },
                        "required": ["topic"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "build_reading_plan",
                    "description": "根据主题与时间预算生成阶段化的论文阅读计划。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "topic": {"type": "string", "description": "学习主题"},
                            "available_hours": {
                                "type": "integer",
                                "description": "可支配总时长（小时）",
                            },
                            "target_papers": {
                                "type": "integer",
                                "description": "计划精读的论文数",
                            },
                        },
                        "required": ["topic"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "organize_notes",
                    "description": "将零散科研笔记整理为结构化 Markdown。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "raw_notes": {
                                "type": "string",
                                "description": "包含多行内容的原始笔记文本",
                            }
                        },
                        "required": ["raw_notes"],
                    },
                },
            },
        ]

        # 固定问候 + 工具说明
        print(
            "助手：你好，我是“科研资料云端整理助手”。\n"
            "我可以帮你：\n"
            "  - 使用 `search_papers` 检索 arXiv 论文；\n"
            "  - 使用 `build_reading_plan` 制定阅读计划；\n"
            "  - 使用 `organize_notes` 把零散笔记整理成结构化 Markdown。\n"
            "你可以直接用自然语言告诉我需求，例如：\n"
            "  “帮我查一下多模态 LLM 的最新 3 篇论文并给一个一周阅读计划”。\n"
            "输入 q 或 quit 可以随时退出。\n"
        )

        # 会话上下文，添加 system 角色，指导大模型行为
        conversation: list[dict[str, Any]] = [
            {
                "role": "system",
                "content": (
                    "你是一个科研资料云端整理助手，擅长："
                    "1）检索 arXiv 论文；2）制定阶段化阅读计划；3）整理科研笔记为结构化 Markdown。"
                    "优先使用提供的 MCP 工具完成用户需求，然后用简明的中文给出总结性回答。"
                ),
            }
        ]

        while True:
            user_input = input("\n你：").strip()
            if user_input.lower() in {"q", "quit", "exit"}:
                print("会话结束。")
                break

            conversation.append({"role": "user", "content": user_input})

            # 最多进行两轮工具调用（防止死循环）
            for _ in range(2):
                response = self.llm.chat.completions.create(
                    model=MODEL,
                    messages=conversation,
                    tools=tools,
                    tool_choice="auto",
                )
                choice = response.choices[0]

                if choice.finish_reason == "tool_calls" and choice.message.tool_calls:
                    # 记录模型发起的工具调用
                    conversation.append(
                        {
                            "role": "assistant",
                            "tool_calls": [
                                tc.to_dict() for tc in choice.message.tool_calls
                            ],
                        }
                    )

                    # 逐个执行工具，并把结果反馈给模型
                    for tool_call in choice.message.tool_calls:
                        name = tool_call.function.name
                        args = tool_call.function.arguments or "{}"
                        try:
                            parsed_args = __import__("json").loads(args)
                        except Exception:
                            parsed_args = {}

                        tool_result = await self._invoke_tool(name, parsed_args)
                        conversation.append(
                            {
                                "role": "tool",
                                "tool_call_id": tool_call.id,
                                "name": name,
                                "content": tool_result,
                            }
                        )
                    # 继续下一轮，让模型基于工具结果生成最终回答
                    continue

                # 不再需要调用工具，直接返回回答
                assistant_msg = choice.message.content or ""
                print(f"\n助手：{assistant_msg}")
                conversation.append({"role": "assistant", "content": assistant_msg})
                break

async def main() -> None:
    """命令行入口：连接本地 server 并启动交互循环。"""
    if len(sys.argv) > 1:
        server_script = sys.argv[1]
    else:
        # 默认使用本项目自带的 server.py
        server_script = os.path.join(os.path.dirname(__file__), "server.py")

    client = ResearchAssistantClient(server_script)
    try:
        await client.connect()
        await client.chat_with_llm()
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())


