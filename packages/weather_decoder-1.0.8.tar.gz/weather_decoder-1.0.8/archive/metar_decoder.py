#!/usr/bin/env python3
"""
METAR Decoder - A comprehensive parser for METAR (Meteorological Terminal Air Report) weather reports
"""

import argparse
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, Union


@dataclass
class MetarData:
    """Class to hold decoded METAR data"""
    raw_metar: str
    metar_type: str
    station_id: str
    observation_time: datetime
    auto: bool
    wind: Dict
    visibility: Dict
    runway_visual_range: List[Dict]
    runway_conditions: List[Dict]
    runway_state_reports: List[Dict]  # MOTNE format runway reports from main body
    weather_groups: List[Dict]
    sky_conditions: List[Dict]
    temperature: float
    dewpoint: float
    altimeter: Dict
    windshear: List[str]
    trends: List[Dict]
    remarks: str
    remarks_decoded: Dict
    military_color_codes: List[Dict]
    
    def __str__(self) -> str:
        """Return a human-readable string of the decoded METAR"""
        lines = [
            f"METAR for {self.station_id} issued {self.observation_time.day:02d} {self.observation_time.hour:02d}:{self.observation_time.minute:02d} UTC",
            f"Type: {'AUTO' if self.auto else 'Manual'} {self.metar_type}",
            f"Wind: {self.wind_text()}",
            f"Visibility: {self.visibility_text()}",
        ]
        
        if self.runway_visual_range:
            rvr_lines = [f"Runway Visual Range:"]
            for rvr in self.runway_visual_range:
                if rvr.get('variable_range'):
                    # Variable RVR format
                    min_range_prefix = ""
                    max_range_prefix = ""
                    
                    if rvr.get('is_less_than'):
                        min_range_prefix = "less than "
                    elif rvr.get('is_more_than'):
                        min_range_prefix = "more than "
                        
                    if rvr.get('variable_less_than'):
                        max_range_prefix = "less than "
                    elif rvr.get('variable_more_than'):
                        max_range_prefix = "more than "
                        
                    rvr_line = f"  Runway {rvr['runway']}: {min_range_prefix}{rvr['visual_range']} to {max_range_prefix}{rvr['variable_range']} {rvr['unit']}"
                else:
                    # Regular RVR format
                    rvr_line = f"  Runway {rvr['runway']}: {rvr['visual_range']} {rvr['unit']}"
                    if rvr.get('is_more_than'):
                        rvr_line = f"  Runway {rvr['runway']}: More than {rvr['visual_range']} {rvr['unit']}"
                    if rvr.get('is_less_than'):
                        rvr_line = f"  Runway {rvr['runway']}: Less than {rvr['visual_range']} {rvr['unit']}"
                
                if rvr.get('trend'):
                    rvr_line += f" ({rvr['trend']})"
                rvr_lines.append(rvr_line)
            lines.extend(rvr_lines)
            
        if self.runway_conditions:
            rwy_cond_lines = [f"Runway Conditions:"]
            for rwy_cond in self.runway_conditions:
                rwy_line = f"  Runway {rwy_cond['runway']}: {rwy_cond['description']}"
                rwy_cond_lines.append(rwy_line)
            lines.extend(rwy_cond_lines)
            
        if self.runway_state_reports:
            state_lines = [f"Runway State Reports:"]
            for report in self.runway_state_reports:
                state_line = f"  Runway {report['runway']}: {report['deposit']}, {report['contamination']}, {report['depth']}, {report['braking']}"
                state_lines.append(state_line)
            lines.extend(state_lines)
        
        if self.weather_groups:
            wx_lines = [f"Weather Phenomena:"]
            for wx in self.weather_groups:
                intensity = wx.get('intensity', '')
                descriptor = wx.get('descriptor', '')
                phenomena = wx.get('phenomena', [])
                
                if intensity or descriptor or phenomena:
                    wx_text = []
                    if intensity:
                        wx_text.append(intensity)
                    if descriptor:
                        wx_text.append(descriptor)
                    if phenomena:
                        wx_text.append(', '.join(phenomena))
                    
                    wx_lines.append(f"  {' '.join(wx_text)}")
            lines.extend(wx_lines)
        
        if self.sky_conditions:
            sky_lines = [f"Sky Conditions:"]
            for sky in self.sky_conditions:
                if sky['type'] == 'CLR' or sky['type'] == 'SKC':
                    sky_lines.append(f"  Clear skies")
                elif sky['type'] == 'NSC':
                    sky_lines.append(f"  No significant cloud")
                elif sky['type'] == 'NCD':
                    sky_lines.append(f"  No cloud detected")
                elif sky['type'] == 'VV':
                    sky_lines.append(f"  Vertical visibility {sky['height']} feet")
                elif sky['type'] == '///':
                    sky_lines.append(f"  Unknown cloud type at {sky['height']} feet (AUTO station)")
                elif sky['type'] == 'AUTO' and sky.get('missing_data'):
                    sky_lines.append(f"  Cloud data missing (AUTO station)")
                elif sky['type'] == 'unknown' and sky.get('missing_data'):
                    cloud_type_text = ""
                    if sky.get('cloud_type'):
                        cloud_type_text = f" ({sky['cloud_type']})"
                    elif sky.get('cb'):
                        cloud_type_text = " (CB)"
                    elif sky.get('tcu'):
                        cloud_type_text = " (TCU)"
                    sky_lines.append(f"  Unknown cloud height{cloud_type_text} (AUTO station)")
                else:
                    sky_lines.append(f"  {sky['type']} clouds at {sky['height']} feet")
                    if sky.get('cb') or sky.get('tcu'):
                        cb_tcu = 'CB' if sky.get('cb') else 'TCU'
                        sky_lines[-1] += f" ({cb_tcu})"
                    elif sky.get('unknown_type'):
                        sky_lines[-1] += f" (unknown type)"
            lines.extend(sky_lines)
        
        if self.windshear:
            lines.append(f"Windshear: {', '.join(self.windshear)}")
        
        lines.extend([
            f"Temperature: {self.temperature}°C",
            f"Dew Point: {self.dewpoint}°C",
            f"Altimeter: {self.altimeter['value']} {self.altimeter['unit']}",
        ])
        
        if self.trends:
            for i, trend in enumerate(self.trends):
                if i == 0:
                    trend_line = f"Trend: {trend['description']}"
                else:
                    trend_line = f"       {trend['description']}"
                lines.append(trend_line)
                
        if self.military_color_codes:
            mil_code_lines = [f"Military Color Codes:"]
            for code in self.military_color_codes:
                mil_code_lines.append(f"  {code['code']}: {code['description']}")
            lines.extend(mil_code_lines)
        
        if self.remarks:
            # Create a filtered version of the remarks text that removes information 
            # which will be shown in structured format below
            filtered_remarks = self.remarks
            
            # Remove location-specific wind information if it's in the structured format
            if self.remarks_decoded and 'location_winds' in self.remarks_decoded:
                for wind_info in self.remarks_decoded['location_winds']:
                    location = wind_info.get('location', '')
                    direction = wind_info.get('direction', '')
                    speed = wind_info.get('speed', '')
                    unit = wind_info.get('unit', 'KT')
                    gust = wind_info.get('gust', '')
                    
                    # Create pattern to remove from remarks
                    pattern = f"WIND {location} {direction}{speed}"
                    if gust:
                        pattern += f"G{gust}"
                    pattern += f"{unit}"
                    
                    # Remove this pattern from the remarks
                    filtered_remarks = filtered_remarks.replace(pattern, "").strip()
            
            # Process the remarks to convert cloud layer codes to readable format
            readable_remarks = filtered_remarks
            
            # Find and replace cloud layer patterns
            for match in re.finditer(r'(OVC|BKN|SCT|FEW)(\d{3})(?:///)?', filtered_remarks):
                cloud_type = match.group(1)
                height = int(match.group(2)) * 100
                
                # Get the full pattern that was matched
                original_pattern = match.group(0)
                
                # Determine if it has unknown type
                has_unknown_type = '///' in original_pattern
                
                # Create readable replacement
                if cloud_type == 'OVC':
                    replacement = f"OVC clouds at {height} feet"
                elif cloud_type == 'BKN':
                    replacement = f"BKN clouds at {height} feet"
                elif cloud_type == 'SCT':
                    replacement = f"SCT clouds at {height} feet"
                else:  # FEW
                    replacement = f"FEW clouds at {height} feet"
                
                if has_unknown_type:
                    replacement += " (unknown type)"
                
                # Replace in the original remarks
                readable_remarks = readable_remarks.replace(original_pattern, replacement)
            
            # First add the raw remarks
            if self.remarks.strip():
                lines.append(f"Remarks: {self.remarks}")
            
            # Now build the decoded remarks
            decoded_remarks = []
                
            if self.remarks_decoded:
                for key, value in self.remarks_decoded.items():
                    if key == 'directional_info':
                        decoded_remarks.append("  Directional information:")
                        for info in value:
                            modifier = info.get('modifier', '')
                            phenomenon = info.get('phenomenon', '')
                            directions = info.get('directions', [])
                            
                            description = []
                            if modifier:
                                description.append(modifier)
                            if phenomenon:
                                description.append(phenomenon)
                            if directions:
                                if len(directions) == 1:
                                    # Check if this is a range format (contains "from X to Y")
                                    if "from " in directions[0]:
                                        direction_text = directions[0]
                                    elif "kilometers" in directions[0] or "overhead" in directions[0]:
                                        # For distance patterns or overhead
                                        direction_text = directions[0]
                                    else:
                                        direction_text = f"in the {directions[0]}"
                                else:
                                    direction_text = f"in the {', '.join(directions[:-1])} and {directions[-1]}"
                                description.append(direction_text)
                                
                            decoded_remarks.append(f"    {' '.join(description)}")
                    elif key == 'variable_ceiling':
                        decoded_remarks.append(f"  {key}: {value}")
                    elif key == 'runway_winds':
                        decoded_remarks.append("  Runway-specific winds:")
                        for wind in value:
                            runway = wind.get('runway', '')
                            direction = wind.get('direction', '')
                            speed = wind.get('speed', '')
                            unit = wind.get('unit', 'KT')
                            gust = wind.get('gust', '')
                            var_dir = wind.get('variable_direction', [])
                            
                            wind_text = f"    Runway {runway}: {direction}° at {speed} {unit}"
                            
                            if gust:
                                wind_text += f", gusting to {gust} {unit}"
                            
                            if var_dir and len(var_dir) == 2:
                                wind_text += f" (varying between {var_dir[0]}° and {var_dir[1]}°)"
                                
                            decoded_remarks.append(wind_text)
                    elif key == 'cloud_layers':
                        decoded_remarks.append("  Cloud layers:")
                        for layer in value:
                            decoded_remarks.append(f"    {layer}")
                    elif key == 'altitude_winds':
                        decoded_remarks.append("  Altitude-specific winds:")
                        for wind in value:
                            altitude = wind.get('altitude', '')
                            altitude_unit = wind.get('altitude_unit', 'feet')
                            direction = wind.get('direction', '')
                            speed = wind.get('speed', '')
                            unit = wind.get('unit', 'KT')
                            gust = wind.get('gust', '')
                            
                            wind_text = f"    At {altitude} {altitude_unit}: {direction}° at {speed} {unit}"
                            
                            if gust:
                                wind_text += f", gusting to {gust} {unit}"
                                
                            decoded_remarks.append(wind_text)
                    elif key == 'location_winds':
                        decoded_remarks.append("  Location-specific winds:")
                        for wind in value:
                            location = wind.get('location', '')
                            direction = wind.get('direction', '')
                            speed = wind.get('speed', '')
                            unit = wind.get('unit', 'KT')
                            gust = wind.get('gust', '')
                            
                            wind_text = f"    At {location}: {direction}° at {speed} {unit}"
                            
                            if gust:
                                wind_text += f", gusting to {gust} {unit}"
                                
                            decoded_remarks.append(wind_text)
                    elif key == 'wind_shift':
                        decoded_remarks.append(f"  wind_shift: at {value['time']}")
                    elif key == 'runway_state_reports_remarks':
                        decoded_remarks.append("  Runway State Reports in Remarks:")
                        for report in value:
                            decoded_remarks.append(f"    Runway {report['runway']}: {report['deposit']}, {report['contamination']}, {report['depth']}, {report['braking']}")
                    elif isinstance(value, dict):
                        decoded_remarks.append(f"  {key}: {', '.join([f'{k}: {v}' for k, v in value.items()])}")
                    elif isinstance(value, list):
                        # Check if the list contains dictionaries
                        if value and isinstance(value[0], dict):
                            # Handle lists of dictionaries in a generic way, other than the special cases above
                            decoded_remarks.append(f"  {key}:")
                            for item in value:
                                decoded_remarks.append(f"    {', '.join([f'{k}: {v}' for k, v in item.items()])}")
                        else:
                            # Regular list of strings
                            decoded_remarks.append(f"  {key}: {', '.join(value)}")
                    else:
                        decoded_remarks.append(f"  {key}: {value}")
            
            # Add the decoded remarks (without "Remarks:" prefix) to the output
            if decoded_remarks:
                lines.extend(decoded_remarks)
        
        return "\n".join(lines)
    
    def wind_text(self) -> str:
        if self.wind.get('direction') == 'VRB':
            dir_text = f"Variable"
        else:
            dir_text = f"{self.wind['direction']}°"
            
        speed_text = f"{self.wind['speed']} {self.wind['unit']}"
        
        if self.wind.get('gust'):
            speed_text += f", gusting to {self.wind['gust']} {self.wind['unit']}"
            
        if self.wind.get('variable_direction'):
            var_dir = self.wind['variable_direction']
            speed_text += f" (varying between {var_dir[0]}° and {var_dir[1]}°)"
            
        return f"{dir_text} at {speed_text}"
    
    def visibility_text(self) -> str:
        if self.visibility.get('is_cavok'):
            return "CAVOK (Ceiling and Visibility OK)"
        
        vis_value = self.visibility['value']
        vis_unit = self.visibility['unit']
        
        # Start with the basic visibility value
        if vis_value == 9999:
            result = "10 km or more"
        elif vis_value == 0 and self.visibility.get('is_less_than'):
            result = f"Less than {vis_value} {vis_unit}"
        else:
            result = f"{vis_value} {vis_unit}"
        
        # Add NDV indicator if present
        if self.visibility.get('ndv'):
            result += " (No Directional Variation)"
        
        return result


class MetarDecoder:
    """METAR decoder class that parses raw METAR strings"""
    
    # Regular expressions for different METAR components
    STATION_ID_PATTERN = r'^([A-Z][A-Z0-9]{3})'
    DATETIME_PATTERN = r'(\d{2})(\d{2})(\d{2})Z'
    METAR_TYPE_PATTERN = r'^(METAR|SPECI)'
    AUTO_PATTERN = r'\bAUTO\b'
    WIND_PATTERN = r'(\d{3}|VRB)(\d{2,3})(G(\d{2,3}))?(?:KT|MPS|KMH)'
    WIND_VAR_PATTERN = r'(\d{3})V(\d{3})'
    VISIBILITY_PATTERN = r'(?:^|\s)(?:(?:(\d{1,4})(?:/(\d))?(SM|KM|M)|(\d{4})(NDV)?|CAVOK|CLR))'
    RVR_PATTERN = r'R(\d{2}[LCR]?)/([PM])?(\d{4})(?:V([PM])?(\d{4}))?(?:FT)?(?:/([UDN]))?'
    SKY_PATTERN = r'(SKC|CLR|FEW|SCT|BKN|OVC|VV|///)(\d{3})(CB|TCU|///)?'
    TEMPERATURE_PATTERN = r'(M)?(\d{2})/(M)?(\d{2})'
    ALTIMETER_PATTERN = r'(A|Q)(\d{4})'
    REMARKS_PATTERN = r'RMK\s+(.+)$'
    
    # Trend types
    TREND_TYPES = ['NOSIG', 'BECMG', 'TEMPO']
    
    # Dictionaries for decoding different parts of the METAR
    WEATHER_INTENSITY = {
        '-': 'light',
        '+': 'heavy',
        'VC': 'vicinity',
        'RE': 'recent'
    }
    
    WEATHER_DESCRIPTORS = {
        'MI': 'shallow',
        'PR': 'partial',
        'BC': 'patches',
        'DR': 'low drifting',
        'BL': 'blowing',
        'SH': 'shower',
        'TS': 'thunderstorm',
        'FZ': 'freezing'
    }
    
    WEATHER_PHENOMENA = {
        'DZ': 'drizzle',
        'RA': 'rain',
        'SN': 'snow',
        'SG': 'snow grains',
        'IC': 'ice crystals',
        'PL': 'ice pellets',
        'GR': 'hail',
        'GS': 'small hail',
        'UP': 'unknown precipitation',
        'BR': 'mist',
        'FG': 'fog',
        'FU': 'smoke',
        'VA': 'volcanic ash',
        'DU': 'dust',
        'SA': 'sand',
        'HZ': 'haze',
        'PY': 'spray',
        'PO': 'dust whirls',
        'SQ': 'squalls',
        'FC': 'funnel cloud',
        '+FC': 'tornado/waterspout',
        'SS': 'sandstorm',
        'DS': 'duststorm'
    }
    
    SKY_CONDITIONS = {
        'SKC': 'clear',
        'CLR': 'clear',
        'FEW': 'few',
        'SCT': 'scattered',
        'BKN': 'broken',
        'OVC': 'overcast',
        'VV': 'vertical visibility',
        'NSC': 'no significant cloud',
        'NCD': 'no cloud detected',
        '///': 'unknown'
    }
    
    # Common RMK decoders
    REMARKS_DECODERS = {
        'AO1': 'automated station without precipitation discriminator',
        'AO2': 'automated station with precipitation discriminator',
        'SLP': 'sea level pressure',
        'TEMPO': 'temporary weather condition',
        'BECMG': 'weather becoming',
        'NOSIG': 'no significant change expected',
        'T': 'temperature',
        'PK WND': 'peak wind',
        'WSHFT': 'wind shift',
        'TWR': 'tower visibility',
        'VIS': 'visibility',
        'LTG': 'lightning',
        'FROPA': 'frontal passage',
        'PWINO': 'precipitation identifier information not available',
        'P': 'precipitation amount',
        'RVRNO': 'runway visual range not available',
        'CIG': 'ceiling',
        'WIND': 'altitude-specific wind',
    }
    
    # Military color codes
    MILITARY_COLOR_CODES = {
        'BLU': 'Blue code: Ceiling at or above 2,500 feet; Visibility at or above 8,000 meters',
        'WHT': 'White code: Ceiling at or above 1,500 feet; Visibility at or above 5,000 meters',
        'GRN': 'Green code: Ceiling at or above 700 feet; Visibility at or above 3,700 meters',
        'YLO': 'Yellow code: Ceiling at or above 300 feet; Visibility at or above 1,600 meters',
        'AMB': 'Amber code: Ceiling at or above 200 feet; Visibility at or above 800 meters',
        'RED': 'Red code: Ceiling below 200 feet; Visibility below 800 meters',
    }
    
    def __init__(self):
        """Initialize the METAR decoder"""
        pass
    
    def decode(self, raw_metar: str) -> MetarData:
        """
        Decode a raw METAR string into structured data
        
        Args:
            raw_metar: The raw METAR string to decode
            
        Returns:
            MetarData: A structured object containing all decoded METAR components
        """
        metar = raw_metar.strip()
        parts = metar.split()
        original_parts = parts.copy()  # Keep a copy for reference
        
        # Extract and remove the METAR/SPECI indicator if present
        metar_type = self._decode_metar_type(parts)
        
        # Extract station ID
        station_id = self._decode_station_id(parts)
        
        # Extract observation time
        observation_time = self._decode_observation_time(parts)
        
        # Check if AUTO indicator is present
        auto = self._decode_auto(parts)
        
        # Extract wind information
        wind = self._decode_wind(parts)
        
        # Extract variable wind direction if present
        variable_wind = self._decode_variable_wind(parts)
        if variable_wind:
            wind['variable_direction'] = variable_wind
        
        # Extract visibility
        visibility = self._decode_visibility(parts)
        
        # Extract runway visual range if present
        runway_visual_range = self._decode_runway_visual_range(parts)
        
        # Extract runway conditions if present
        runway_conditions = self._decode_runway_conditions(parts)
        
        # Extract MOTNE runway state codes from main METAR body
        motne_reports = []
        motne_pattern = r'R(\d{2}[LCR]?)/([0-9/]{6})\b'
        
        # Find RMK index to determine which parts are in the main body vs. remarks
        rmk_index = len(original_parts)
        if 'RMK' in original_parts:
            rmk_index = original_parts.index('RMK')
        
        # Process only parts BEFORE the RMK indicator (main METAR body)
        for part in original_parts[:rmk_index]:
            motne_match = re.match(motne_pattern, part)
            if motne_match and '//' in motne_match.group(2):
                runway = motne_match.group(1)
                motne_code = motne_match.group(2)
                motne_result = self._decode_shortened_motne_state(runway, motne_code)
                if motne_result:
                    motne_reports.append(motne_result)
        
        # Extract weather phenomena - using the original parts to ensure we don't miss any
        weather_parts = [p for p in original_parts if p not in ['RMK'] and not p.startswith('RMK')]
        if 'RMK' in original_parts:
            rmk_index = original_parts.index('RMK')
            weather_parts = original_parts[:rmk_index]
        
        weather_groups = self._decode_weather(weather_parts)
        
        # Extract sky conditions
        sky_conditions = self._decode_sky_conditions(original_parts)
        
        # Extract temperature and dew point
        temperature, dewpoint = self._decode_temperature(original_parts)
        
        # Extract altimeter setting
        altimeter = self._decode_altimeter(original_parts)
        
        # Extract windshear information
        windshear = self._decode_windshear(original_parts)
        
        # Extract trend forecast if present
        trends = self._decode_trend(original_parts)
        
        # Extract remarks section
        remarks, remarks_decoded = self._decode_remarks(metar)
        
        # Keep the MOTNE reports separate from remarks_decoded since they're from the main body
        
        # Extract military color codes if present
        military_color_codes = self._decode_military_color_codes(parts)
        
        # Check for MOTNE runway state codes in the main METAR body
        motne_runway_state = None
        for part in original_parts:
            # Look for 8-digit codes that could be MOTNE runway state
            if re.match(r'^[0-9/]{8}$', part):
                # Parse this as a potential MOTNE code
                motne_runway_state = self._decode_motne_runway_state(part)
                if motne_runway_state:
                    remarks_decoded['runway_state'] = motne_runway_state
                    break
        
        # Create and return the MetarData object
        return MetarData(
            raw_metar=raw_metar,
            metar_type=metar_type,
            station_id=station_id,
            observation_time=observation_time,
            auto=auto,
            wind=wind,
            visibility=visibility,
            runway_visual_range=runway_visual_range,
            runway_conditions=runway_conditions,
            runway_state_reports=motne_reports,  # Pass MOTNE reports separately
            weather_groups=weather_groups,
            sky_conditions=sky_conditions,
            temperature=temperature,
            dewpoint=dewpoint,
            altimeter=altimeter,
            windshear=windshear,
            trends=trends,
            remarks=remarks,
            remarks_decoded=remarks_decoded,
            military_color_codes=military_color_codes
        )
        
    def _decode_motne_runway_state(self, code: str) -> Dict:
        """
        Decode MOTNE format runway state code (8 digits)
        
        Format: AABCDDEE where:
        - AA: Runway designator
        - B: Type of deposit
        - C: Extent of contamination
        - DD: Depth of deposit
        - EE: Braking action/friction coefficient
        """
        if not re.match(r'^[0-9/]{8}$', code):
            return None
            
        runway_code = code[0:2]
        deposit_code = code[2]
        extent_code = code[3]
        depth_code = code[4:6]
        friction_code = code[6:8]
        
        # Decode runway designator
        runway_designator = ""
        if runway_code == "88":
            runway_designator = "All runways"
        elif runway_code == "99":
            runway_designator = "Repeated info"
        else:
            try:
                # Handle parallel runways according to MOTNE format
                runway_num = int(runway_code)
                if runway_num >= 50 and runway_num <= 86:
                    # Right runway (add 50 to designator)
                    actual_runway = runway_num - 50
                    runway_designator = f"{actual_runway:02d}R"
                elif runway_num >= 1 and runway_num <= 36:
                    # Left runway (for parallel runways) or single runway
                    runway_designator = f"{runway_num:02d}L"
                else:
                    # Single runway with numbers > 36 (unlikely but possible)
                    runway_designator = f"{runway_num:02d}"
            except ValueError:
                # Handle case where runway code contains non-numeric characters
                runway_designator = f"Unknown runway ({runway_code})"
        
        # Decode deposit type
        deposit_types = {
            '0': 'CLEAR and DRY',
            '1': 'DAMP',
            '2': 'WET or Water Patches',
            '3': 'RIME or FROST (<1mm)',
            '4': 'DRY SNOW',
            '5': 'WET SNOW',
            '6': 'SLUSH',
            '7': 'ICE',
            '8': 'COMPACTED or ROLLED SNOW',
            '9': 'FROZEN RUTS or RIDGES',
            '/': 'TYPE of DEPOSIT NOT REPORTED (runway clearance/de-icing in progress)'
        }
        
        # Decode contamination extent
        extents = {
            '1': '10% or less of RWY covered',
            '2': '11% to 25% of RWY covered',
            '5': '26% to 50% of RWY covered',
            '9': '51% to 100% of RWY covered',
            '/': 'NOT REPORTED (runway clearance/de-icing in progress)',
            '6': 'Reserved code (6)',
            '7': 'Reserved code (7)',
            '8': 'Reserved code (8)',
            '0': 'Reserved code (0)',
            '3': 'Reserved code (3)',
            '4': 'Reserved code (4)'
        }
        
        # Decode depth
        depth_description = ""
        if '/' in depth_code:
            depth_description = "Depth operationally not significant or not measurable"
        elif depth_code == "00":
            depth_description = "Less than 1mm"
        elif depth_code == "91":
            depth_description = "Not used"
        elif depth_code == "92":
            depth_description = "10cm"
        elif depth_code == "93":
            depth_description = "15cm"
        elif depth_code == "94":
            depth_description = "20cm"
        elif depth_code == "95":
            depth_description = "25cm"
        elif depth_code == "96":
            depth_description = "30cm"
        elif depth_code == "97":
            depth_description = "35cm"
        elif depth_code == "98":
            depth_description = "40cm or more"
        elif depth_code == "99":
            depth_description = "RWY not operational due to snow, slush, ice, large drifts or RWY clearance (depth not reported)"
        elif 1 <= int(depth_code) <= 90:
            depth_description = f"{int(depth_code)}mm"
        else:
            depth_description = f"Unknown depth code: {depth_code}"
        
        # Decode braking action / friction coefficient
        braking_description = ""
        if '/' in friction_code:
            braking_description = "RWY not operational, braking action not reported"
        elif friction_code == "91":
            braking_description = "POOR braking action"
        elif friction_code == "92":
            braking_description = "MEDIUM/POOR braking action"
        elif friction_code == "93":
            braking_description = "MEDIUM braking action"
        elif friction_code == "94":
            braking_description = "MEDIUM/GOOD braking action"
        elif friction_code == "95":
            braking_description = "GOOD braking action"
        elif friction_code == "99":
            braking_description = "UNRELIABLE (friction coefficient assessment misleading)"
        elif friction_code == "//":
            braking_description = "RWY not operational, braking action not reported"
        elif friction_code[0] != '/' and friction_code[1] != '/' and 1 <= int(friction_code) <= 90:
            coefficient = int(friction_code) / 100.0
            braking_description = f"Friction coefficient {coefficient:.2f}"
        else:
            braking_description = f"Unknown braking code: {friction_code}"
        
        return {
            'runway': runway_designator,
            'deposit': deposit_types.get(deposit_code, f"Unknown deposit ({deposit_code})"),
            'contamination': extents.get(extent_code, f"Unknown extent ({extent_code})"),
            'depth': depth_description,
            'braking': braking_description,
            'motne_code': code  # Store the original code for reference
        }
    
    def _decode_shortened_motne_state(self, runway: str, code: str) -> Dict:
        """
        Decode shortened MOTNE format runway state code
        
        Format: R##/BCDDEE where:
        - R##: Runway designator  
        - B: Type of deposit
        - C: Extent of contamination
        - DD: Depth of deposit
        - EE: Braking action/friction coefficient
        
        Example: R23/09//62 = Runway 23, clear and dry, 51-100% coverage, depth not significant, friction 0.62
        """
        if len(code) != 6:
            return None
            
        deposit_code = code[0]
        extent_code = code[1]
        depth_code = code[2:4]
        friction_code = code[4:6]
        
        # Decode deposit type (same as full MOTNE)
        deposit_types = {
            '0': 'CLEAR and DRY',
            '1': 'DAMP',
            '2': 'WET or Water Patches',
            '3': 'RIME or FROST (<1mm)',
            '4': 'DRY SNOW',
            '5': 'WET SNOW',
            '6': 'SLUSH',
            '7': 'ICE',
            '8': 'COMPACTED or ROLLED SNOW',
            '9': 'FROZEN RUTS or RIDGES',
            '/': 'TYPE of DEPOSIT NOT REPORTED'
        }
        
        # Decode contamination extent (same as full MOTNE)
        extents = {
            '1': '10% or less of RWY covered',
            '2': '11% to 25% of RWY covered',
            '5': '26% to 50% of RWY covered',
            '9': '51% to 100% of RWY covered',
            '/': 'NOT REPORTED'
        }
        
        # Decode depth
        depth_description = ""
        if '//' in depth_code:
            depth_description = "Depth operationally not significant or not measurable"
        elif depth_code == "00":
            depth_description = "Less than 1mm"
        elif depth_code.isdigit():
            depth_val = int(depth_code)
            if 1 <= depth_val <= 90:
                depth_description = f"{depth_val}mm"
            elif depth_val == 92:
                depth_description = "10cm"
            elif depth_val == 93:
                depth_description = "15cm"
            elif depth_val == 94:
                depth_description = "20cm"
            elif depth_val == 95:
                depth_description = "25cm"
            elif depth_val == 96:
                depth_description = "30cm"
            elif depth_val == 97:
                depth_description = "35cm"
            elif depth_val == 98:
                depth_description = "40cm or more"
            elif depth_val == 99:
                depth_description = "RWY not operational due to snow, slush, ice, large drifts or RWY clearance"
            else:
                depth_description = f"Unknown depth code: {depth_code}"
        else:
            depth_description = f"Unknown depth code: {depth_code}"
        
        # Decode braking action / friction coefficient
        braking_description = ""
        if '//' in friction_code:
            braking_description = "RWY not operational, braking action not reported"
        elif friction_code == "91":
            braking_description = "POOR braking action"
        elif friction_code == "92":
            braking_description = "MEDIUM/POOR braking action"
        elif friction_code == "93":
            braking_description = "MEDIUM braking action"
        elif friction_code == "94":
            braking_description = "MEDIUM/GOOD braking action"
        elif friction_code == "95":
            braking_description = "GOOD braking action"
        elif friction_code == "99":
            braking_description = "UNRELIABLE (friction coefficient assessment misleading)"
        elif friction_code.isdigit() and 1 <= int(friction_code) <= 90:
            coefficient = int(friction_code) / 100.0
            braking_description = f"Friction coefficient {coefficient:.2f}"
        else:
            braking_description = f"Unknown braking code: {friction_code}"
        
        return {
            'runway': runway,
            'deposit': deposit_types.get(deposit_code, f"Unknown deposit ({deposit_code})"),
            'contamination': extents.get(extent_code, f"Unknown extent ({extent_code})"),
            'depth': depth_description,
            'braking': braking_description,
            'motne_code': f"R{runway}/{code}",  # Store the original code for reference
            'format': 'Shortened MOTNE'
        }
    
    def _decode_metar_type(self, parts: List[str]) -> str:
        """Extract the METAR type (METAR or SPECI)"""
        if parts and re.match(self.METAR_TYPE_PATTERN, parts[0]):
            metar_type = parts.pop(0)
            return metar_type
        return "METAR"
    
    def _decode_station_id(self, parts: List[str]) -> str:
        """Extract the station identifier (ICAO code)"""
        if parts and (re.match(self.STATION_ID_PATTERN, parts[0]) or 
                     (len(parts[0]) == 3 or len(parts[0]) == 4) and not re.match(r'\d{6}Z', parts[0])):
            return parts.pop(0)
        return ""
    
    def _decode_observation_time(self, parts: List[str]) -> datetime:
        """Extract the observation date and time"""
        if parts and re.match(r'\d{6}Z', parts[0]):
            time_str = parts.pop(0)
            match = re.match(self.DATETIME_PATTERN, time_str)
            if match:
                day, hour, minute = map(int, match.groups())
                # Create datetime object (using current year and month for simplicity)
                now = datetime.now(timezone.utc)
                
                # Handle day rollover
                if day > now.day:
                    # Probably previous month
                    if now.month > 1:
                        month = now.month - 1
                        year = now.year
                    else:
                        # Handle December to January transition
                        month = 12
                        year = now.year - 1
                elif day < now.day and now.day - day > 25:
                    # Probably next month
                    if now.month < 12:
                        month = now.month + 1
                        year = now.year
                    else:
                        # Handle December to January transition
                        month = 1
                        year = now.year + 1
                else:
                    # Same month
                    month = now.month
                    year = now.year
                
                return datetime(year, month, day, hour, minute, tzinfo=timezone.utc)
        return datetime.now(timezone.utc)
    
    def _decode_auto(self, parts: List[str]) -> bool:
        """Check if the METAR is from an automated station"""
        if parts and parts[0] == 'AUTO':
            parts.pop(0)
            return True
        return False
    
    def _decode_wind(self, parts: List[str]) -> Dict:
        """Extract wind information (direction, speed, gusts)"""
        wind = {
            'direction': 0,
            'speed': 0,
            'gust': None,
            'unit': 'KT'
        }
        
        if not parts:
            return wind
        
        # Check for special COR indicator which is sometimes found after the timestamp
        if parts and parts[0] == 'COR':
            parts.pop(0)
            
        if not parts:
            return wind
            
        # Match wind pattern
        wind_pattern = r'((\d{3}|VRB)(\d{2,3}))(G(\d{2,3}))?(?:KT|MPS|KMH)'
        match = None
        
        # Look for the wind pattern in the current part
        if re.match(wind_pattern, parts[0]):
            match = re.match(wind_pattern, parts[0])
            wind_part = parts.pop(0)
        
        if match:
            direction_str = match.group(2)
            
            # Handle direction
            if direction_str == 'VRB':
                wind['direction'] = 'VRB'
            else:
                wind['direction'] = int(direction_str)
            
            # Handle speed
            wind['speed'] = int(match.group(3))
            
            # Handle gusts if present
            if match.group(5):
                wind['gust'] = int(match.group(5))
            
            # Handle units
            if wind_part.endswith('KT'):
                wind['unit'] = 'KT'
            elif wind_part.endswith('MPS'):
                wind['unit'] = 'MPS'
            elif wind_part.endswith('KMH'):
                wind['unit'] = 'KMH'
        
        return wind
    
    def _decode_variable_wind(self, parts: List[str]) -> Optional[Tuple[int, int]]:
        """Extract variable wind direction information"""
        if not parts:
            return None
        
        match = re.match(self.WIND_VAR_PATTERN, parts[0])
        if match:
            parts.pop(0)
            return (int(match.group(1)), int(match.group(2)))
        
        return None
    
    def _decode_visibility(self, parts: List[str]) -> Dict:
        """Extract visibility information"""
        visibility = {
            'value': 0,
            'unit': 'M',
            'is_less_than': False,
            'is_cavok': False,
            'ndv': False
        }
        
        if not parts:
            return visibility
        
        # Check for CAVOK (Ceiling and Visibility OK)
        if parts[0] == 'CAVOK':
            parts.pop(0)
            visibility['is_cavok'] = True
            visibility['value'] = 9999
            return visibility
        
        # Check for standard visibility format (9999, 0500, etc.)
        if re.match(r'^\d{4}(?:NDV)?$', parts[0]):
            vis_part = parts.pop(0)
            # Check for NDV indicator
            has_ndv = 'NDV' in vis_part
            # Extract the numeric part
            vis_value = int(re.match(r'^\d{4}', vis_part).group(0))
            
            visibility['value'] = vis_value
            # Convert 9999 to indicate 10km or greater
            if vis_value == 9999:
                visibility['value'] = 9999
            
            # Store NDV info if present
            if has_ndv:
                visibility['ndv'] = True
            
            return visibility
        
        # Check for SM visibility format with spaces between whole and fractional parts (e.g., "2 1/2SM")
        if (len(parts) >= 2 and parts[0].isdigit() and 
            re.match(r'(\d+)/(\d+)(?:\s*SM)?', parts[1])):
            whole = int(parts[0])
            parts.pop(0)
            
            # Now handle the fractional part
            frac_match = re.match(r'(\d+)/(\d+)(?:\s*SM)?', parts[0])
            
            # Check if this part contains SM unit or if it's a separate token
            if 'SM' in parts[0]:
                parts.pop(0)
            else:
                parts.pop(0)
                # Check if next token is just "SM"
                if parts and parts[0] == 'SM':
                    parts.pop(0)
            
            numerator = int(frac_match.group(1))
            denominator = int(frac_match.group(2))
            
            visibility['value'] = whole + (numerator / denominator)
            visibility['unit'] = 'SM'
            
            return visibility
        
        # Check for SM visibility format (e.g. 1/2SM, 2SM)
        sm_match = re.match(r'(\d+)(?:/(\d+))?(?:\s*SM)', parts[0])
        if sm_match:
            parts.pop(0)
            
            numerator = int(sm_match.group(1))
            denominator = int(sm_match.group(2)) if sm_match.group(2) else 1
            
            visibility['value'] = numerator / denominator
            visibility['unit'] = 'SM'
            
            return visibility
            
        # Handle case where SM is a separate token
        if parts[0].isdigit() or (parts[0].isdigit() and '/' in parts[0]):
            first_part = parts[0]
            
            # Try to determine if this is visibility
            if len(parts) > 1 and parts[1] == 'SM':
                parts.pop(0)  # Remove the numeric part
                parts.pop(0)  # Remove the SM part
                
                # Parse the value
                if '/' in first_part:
                    # Handle fractional value like "1/2"
                    frac_parts = first_part.split('/')
                    if len(frac_parts) == 2:
                        numerator = int(frac_parts[0])
                        denominator = int(frac_parts[1])
                        visibility['value'] = numerator / denominator
                    else:
                        visibility['value'] = int(first_part)
                else:
                    # Whole number
                    visibility['value'] = int(first_part)
                
                visibility['unit'] = 'SM'
                return visibility
                
        # Simple numeric visibility with SM unit on next token
        if parts[0].isdigit() and len(parts) > 1 and parts[1] == 'SM':
            visibility['value'] = int(parts[0])
            visibility['unit'] = 'SM'
            parts.pop(0)  # Remove the numeric part
            parts.pop(0)  # Remove the SM part
            return visibility
        
        # Check for M visibility format (e.g. 1000M)
        m_match = re.match(r'(\d+)M', parts[0])
        if m_match:
            parts.pop(0)
            visibility['value'] = int(m_match.group(1))
            visibility['unit'] = 'M'
            
            return visibility
        
        return visibility
    
    def _decode_runway_visual_range(self, parts: List[str]) -> List[Dict]:
        """Extract runway visual range information"""
        rvr_list = []
        i = 0
        
        while i < len(parts):
            if parts[i].startswith('R') and '/' in parts[i]:
                # Skip runway condition codes which are handled separately
                if len(parts[i].split('/')[1]) >= 6 and not 'V' in parts[i] and not '/P' in parts[i]:
                    i += 1
                    continue
                
                # Try to match standard format or variable format with V
                # Updated pattern to handle trend indicators directly after the number (like 1300D) as well as after a slash (like 1300/D)
                match = re.match(r'R(\d{2}[LCR]?)/([PM])?(\d{4})([UDN])?(?:V([PM])?(\d{4})([UDN])?)?(?:FT)?(?:/([UDN]))?', parts[i])
                if match:
                    runway = match.group(1)
                    prefix = match.group(2)  # P or M for the main value
                    visual_range = int(match.group(3))
                    trend_direct = match.group(4)  # Trend indicator directly after the number (e.g., 1300D)
                    var_prefix = match.group(5)  # P or M for the variable value
                    variable_range = int(match.group(6)) if match.group(6) else None
                    var_trend_direct = match.group(7)  # Trend indicator for variable part
                    trend_slash = match.group(8)  # Trend indicator after slash (e.g., 1300/D)
                    
                    # Use the trend indicator that's present, prioritizing the one after the slash if both exist
                    trend = trend_slash or trend_direct
                    
                    # Extract the unit from the original string
                    unit = 'FT'  # Default
                    if 'FT' in parts[i]:
                        unit = 'FT'
                    elif 'M' in parts[i] and not parts[i].endswith('/M'):  # Make sure it's not the M for "less than"
                        unit = 'M'
                    
                    rvr = {
                        'runway': runway,
                        'visual_range': visual_range,
                        'unit': unit,
                        'is_less_than': prefix == 'M',
                        'is_more_than': prefix == 'P',
                    }
                    
                    if variable_range:
                        rvr['variable_range'] = variable_range
                        rvr['variable_more_than'] = var_prefix == 'P'
                        rvr['variable_less_than'] = var_prefix == 'M'
                        # Add trend for variable part if present
                        if var_trend_direct:
                            var_trend_dict = {
                                'U': 'increasing',
                                'D': 'decreasing',
                                'N': 'no change'
                            }
                            rvr['variable_trend'] = var_trend_dict.get(var_trend_direct, var_trend_direct)
                    
                    if trend:
                        trend_dict = {
                            'U': 'increasing',
                            'D': 'decreasing',
                            'N': 'no change'
                        }
                        rvr['trend'] = trend_dict.get(trend, trend)
                    
                    rvr_list.append(rvr)
                    parts.pop(i)
                else:
                    i += 1
            else:
                i += 1
        
        return rvr_list
    
    def _decode_runway_conditions(self, parts: List[str]) -> List[Dict]:
        """Extract runway condition information"""
        runway_conditions = []
        
        # Pattern for standard runway condition: R##/######
        runway_condition_pattern = r'R(\d{2}[LCR]?)/(\d{6})$'
        
        # Pattern for CLRD format: R##/CLRD##
        clrd_pattern = r'R(\d{2}[LCR]?)/CLRD(\d{2})'
        
        # Pattern for numeric code format: R##/ddfftt (but not MOTNE with slashes)
        numeric_code_pattern = r'R(\d{2}[LCR]?)/(\d{6})$'
        
        # Pattern for MOTNE codes with slashes: R##/[0-9/]{6}
        motne_pattern = r'R(\d{2}[LCR]?)/([0-9/]{6})$'
        
        # Create a copy of parts to safely iterate while modifying
        i = 0
        while i < len(parts):
            part = parts[i]
            # Check for MOTNE format first (has slashes in the code)
            motne_match = re.match(motne_pattern, part)
            if motne_match and '//' in motne_match.group(2):
                # This is a MOTNE code, skip it here - it will be processed elsewhere
                i += 1
                continue
                
            # Check for CLRD format
            clrd_match = re.match(clrd_pattern, part)
            if clrd_match:
                runway = clrd_match.group(1)
                friction = int(clrd_match.group(2)) / 100  # Convert to decimal
                
                runway_conditions.append({
                    'runway': runway,
                    'code': f"CLRD{clrd_match.group(2)}",
                    'description': f"clear and dry, friction coefficient {friction}"
                })
                parts.pop(i)
                # Don't increment i here as the next item has shifted into this position
                continue
            
            # Check for standard ICAO format with 6 digits
            numeric_match = re.match(numeric_code_pattern, part)
            if numeric_match and len(numeric_match.group(2)) == 6:
                runway = numeric_match.group(1)
                condition_code = numeric_match.group(2)
                
                # Check for specific format used in some METARs: R##/ddfftt
                # Where: dd = deposit type (0-9), ff = extent of contamination (1-9), tt = depth or friction
                if len(condition_code) == 6:
                    deposit_code = condition_code[0:2]
                    extent_code = condition_code[2:4]
                    depth_or_friction = condition_code[4:6]
                    
                    # Decode deposit type
                    deposit_types = {
                        '0': 'clear and dry',
                        '1': 'damp',
                        '2': 'wet or water patches',
                        '3': 'rime or frost',
                        '4': 'dry snow',
                        '5': 'wet snow',
                        '6': 'slush',
                        '7': 'ice',
                        '8': 'compacted snow',
                        '9': 'frozen ruts or ridges',
                        '/': 'not reported'
                    }
                    
                    # Decode extent of contamination
                    extents = {
                        '1': 'covering less than 10% of runway',
                        '2': 'covering 11% to 25% of runway',
                        '5': 'covering 26% to 50% of runway',
                        '9': 'covering 51% to 100% of runway'
                    }
                    
                    deposit_type = deposit_types.get(deposit_code[0], f"type {deposit_code}")
                    extent = extents.get(extent_code[0], f"extent {extent_code}")
                    
                    # Friction coefficient or depth
                    friction_description = ""
                    try:
                        friction = int(depth_or_friction) / 100
                        if friction > 0:
                            friction_description = f", friction coefficient {friction}"
                    except ValueError:
                        pass
                    
                    description = f"{deposit_type}, {extent}{friction_description}"
                    
                    runway_conditions.append({
                        'runway': runway,
                        'code': condition_code,
                        'description': description
                    })
                    parts.pop(i)
                    # Don't increment i here as the next item has shifted into this position
                    continue
            
            # Check for standard ICAO format
            match = re.match(runway_condition_pattern, part)
            if match:
                runway = match.group(1)
                condition_code = match.group(2)
                
                # Decode ICAO runway condition code (format: DDFGGG or similar)
                # Where DD = deposit type, F = extent, GGG = depth or braking action
                deposit_type = ''
                extent = ''
                depth_or_friction = ''
                
                if len(condition_code) >= 6:
                    deposit_code = condition_code[0:2]
                    extent_code = condition_code[2:3] if len(condition_code) > 2 else ''
                    depth_code = condition_code[3:6] if len(condition_code) > 3 else ''
                    
                    # Decode deposit type
                    deposit_types = {
                        '0': 'clear and dry',
                        '1': 'damp',
                        '2': 'wet or water patches',
                        '3': 'rime or frost',
                        '4': 'dry snow',
                        '5': 'wet snow',
                        '6': 'slush',
                        '7': 'ice',
                        '8': 'compacted snow',
                        '9': 'frozen ruts or ridges',
                        '/': 'not reported'
                    }
                    
                    # Decode extent of contamination
                    extents = {
                        '1': 'less than 10% of runway',
                        '2': '11% to 25% of runway',
                        '3': 'reserved',
                        '4': 'reserved',
                        '5': '26% to 50% of runway',
                        '6': 'reserved',
                        '7': 'reserved',
                        '8': 'reserved',
                        '9': '51% to 100% of runway',
                        '/': 'not reported'
                    }
                    
                    deposit_type = deposit_types.get(deposit_code[0], 'unknown')
                    extent = extents.get(extent_code, '')
                    
                    # Depth of deposit or friction coefficient depends on the deposit type
                    if deposit_code[0] in ['4', '5', '6', '8', '9']:  # Snow, slush or ice
                        if depth_code == '000':
                            depth_or_friction = 'less than 1 mm'
                        elif depth_code == '999':
                            depth_or_friction = 'runway not operational'
                        elif depth_code[0] == '/':
                            depth_or_friction = 'depth not significant'
                        else:
                            depth_mm = int(depth_code)
                            depth_or_friction = f"{depth_mm} mm deep"
                    elif deposit_code[0] in ['7']:  # Ice
                        if depth_code[0] == '9':
                            friction = int(depth_code[1:]) / 100.0
                            depth_or_friction = f"friction coefficient: {friction}"
                    
                description = f"{deposit_type}"
                if extent:
                    description += f", {extent}"
                if depth_or_friction:
                    description += f", {depth_or_friction}"
                
                runway_conditions.append({
                    'runway': runway,
                    'code': condition_code,
                    'description': description
                })
                parts.pop(i)
                # Don't increment i here as the next item has shifted into this position
                continue
            
            # If we get here, this part wasn't a runway condition
            i += 1
        
        return runway_conditions
    
    def _decode_weather(self, parts: List[str]) -> List[Dict]:
        """Extract weather phenomena information"""
        weather_groups = []
        
        # Known weather codes that are two letters
        two_letter_wx_codes = list(self.WEATHER_PHENOMENA.keys())
        
        # Military color codes to exclude
        military_codes = list(self.MILITARY_COLOR_CODES.keys())
        
        # Find the index of the first trend indicator if present
        trend_index = len(parts)
        for i, part in enumerate(parts):
            if part in self.TREND_TYPES:
                trend_index = i
                break
        
        # Process each part, but only up to the trend indicator
        i = 0
        while i < trend_index:
            part = parts[i]
            
            # Skip military color codes
            if part in military_codes:
                i += 1
                continue
                
            # Skip obvious non-weather codes
            if (part.startswith('R') and re.match(r'^R\d+', part) or  # RVR
                re.match(r'^M?\d{2}/M?\d{2}$', part) or  # Temperature
                re.match(r'^[AQ]\d{4}$', part) or  # Altimeter
                re.match(r'^\d{6}Z$', part) or  # Time
                re.match(r'^\d{3}V\d{3}$', part) or  # Variable wind
                re.match(r'^(\d{3}|VRB)\d{2,3}(G\d{2,3})?(?:KT|MPS|KMH)$', part)):  # Wind
                i += 1
                continue
            
            # Check for "//" which indicates unknown weather condition
            if part == '//':
                weather = {
                    'intensity': '',
                    'descriptor': '',
                    'phenomena': ['unknown weather']
                }
                weather_groups.append(weather)
                parts.pop(i)
                trend_index -= 1  # Adjust trend_index since we removed an element
                continue
            
            # Direct match for standalone weather phenomena codes
            if part in two_letter_wx_codes:
                weather = {
                    'intensity': '',
                    'descriptor': '',
                    'phenomena': [self.WEATHER_PHENOMENA[part]]
                }
                weather_groups.append(weather)
                parts.pop(i)
                trend_index -= 1  # Adjust trend_index since we removed an element
                continue
            
            # Process complex weather groups
            has_weather = False
            intensity = ''
            descriptor = ''
            phenomena = []
            
            # Check for intensity prefix or recent indicator
            if (part.startswith('+') or part.startswith('-') or 
                part.startswith('VC') or part.startswith('RE')):
                if part.startswith('+'):
                    intensity = 'heavy'
                    part = part[1:]
                elif part.startswith('-'):
                    intensity = 'light'
                    part = part[1:]
                elif part.startswith('VC'):
                    intensity = 'vicinity'
                    part = part[2:]
                elif part.startswith('RE'):
                    intensity = 'recent'
                    part = part[2:]
                has_weather = True
            
            # Check for descriptor
            for desc_code, desc_value in self.WEATHER_DESCRIPTORS.items():
                if part.startswith(desc_code):
                    descriptor = desc_value
                    part = part[len(desc_code):]
                    has_weather = True
                    break
            
            # Check for weather phenomena
            remaining = part
            while remaining and len(remaining) >= 2:
                code = remaining[:2]
                if code in self.WEATHER_PHENOMENA:
                    phenomena.append(self.WEATHER_PHENOMENA[code])
                    remaining = remaining[2:]
                    has_weather = True
                else:
                    break
            
            if has_weather:
                weather = {
                    'intensity': intensity,
                    'descriptor': descriptor,
                    'phenomena': phenomena
                }
                weather_groups.append(weather)
                parts.pop(i)
                trend_index -= 1  # Adjust trend_index since we removed an element
            else:
                i += 1
        
        return weather_groups
    
    def _decode_sky_conditions(self, parts: List[str]) -> List[Dict]:
        """Extract sky condition information"""
        sky_conditions = []
        sky_pattern = r'(SKC|CLR|FEW|SCT|BKN|OVC|VV|///)(\d{3})(CB|TCU|///)?'
        
        # Find the index of the first trend indicator if present
        trend_index = len(parts)
        for i, part in enumerate(parts):
            if part in self.TREND_TYPES:
                trend_index = i
                break
        
        # Find the index of RMK if present
        rmk_index = len(parts)
        if 'RMK' in parts:
            rmk_index = parts.index('RMK')
            
        # Process each part, but only up to the trend indicator or RMK
        end_index = min(trend_index, rmk_index)
        
        for part in parts[:end_index]:
            # Check for pattern with all slashes (completely missing data from AUTO station)
            if part == '/////////' or part == '/////////':
                sky_conditions.append({
                    'type': 'AUTO',
                    'height': None,
                    'missing_data': True
                })
                continue
            
            # Check for //////CB pattern (missing data but with cloud type)
            if part.startswith('//////') and len(part) > 6:
                cloud_type = part[6:]
                sky_conditions.append({
                    'type': 'unknown',
                    'height': None,
                    'missing_data': True,
                    'cb': cloud_type == 'CB',
                    'tcu': cloud_type == 'TCU',
                    'cloud_type': cloud_type
                })
                continue
                
            # Check for no-height cloud codes first (NSC, NCD)
            if part in ['NSC', 'NCD']:
                sky_conditions.append({
                    'type': part,
                    'height': None
                })
                continue
                
            # Check for sky condition pattern (including vertical visibility)
            match = re.match(sky_pattern, part)
            if match:
                sky_type = match.group(1)
                height = int(match.group(2)) * 100  # Convert to feet
                cloud_type = match.group(3) or None
                
                sky = {
                    'type': sky_type,
                    'height': height
                }
                
                if cloud_type == 'CB':
                    sky['cb'] = True
                elif cloud_type == 'TCU':
                    sky['tcu'] = True
                elif cloud_type == '///':
                    sky['unknown_type'] = True
                
                sky_conditions.append(sky)
                continue
                
            # Check for special cases like 'CLR' or 'SKC' without height
            if part in ['CLR', 'SKC']:
                sky_conditions.append({
                    'type': part,
                    'height': None
                })
        
        return sky_conditions
    
    def _decode_trend(self, parts: List[str]) -> List[Dict]:
        """Extract trend forecast information"""
        trends = []
        
        # First, clean any equals signs at the end of each part (METAR terminators)
        cleaned_parts = [part.rstrip('=') for part in parts]
        
        # Find all trend indicators
        trend_indices = [i for i, part in enumerate(cleaned_parts) if part in self.TREND_TYPES]
        
        for idx, i in enumerate(trend_indices):
            trend_type = cleaned_parts[i]
            
            # Build the trend data
            if trend_type == 'NOSIG':
                # No significant change expected
                trends.append({
                    'type': 'NOSIG',
                    'description': 'No significant change expected in the next 2 hours'
                })
            elif trend_type in ['BECMG', 'TEMPO']:
                # For BECMG and TEMPO, extract the conditions that follow
                trend_section = []
                trend_details = {}
                
                # Determine the end index for this trend section
                end_idx = len(cleaned_parts)
                if idx < len(trend_indices) - 1:
                    end_idx = trend_indices[idx + 1]
                elif 'RMK' in cleaned_parts:
                    rmk_idx = cleaned_parts.index('RMK')
                    if rmk_idx > i:
                        end_idx = rmk_idx
                
                # Extract all parts following the trend type until the next trend, RMK, or end
                for j in range(i+1, end_idx):
                    # Skip empty parts
                    if cleaned_parts[j]:
                        trend_section.append(cleaned_parts[j])
                
                # Special case for direct military color code after TEMPO or BECMG
                if len(trend_section) == 1 and trend_section[0] in self.MILITARY_COLOR_CODES:
                    color_code = trend_section[0]
                    trend_desc = self.MILITARY_COLOR_CODES[color_code]
                    if trend_type == 'TEMPO':
                        prefix = "Temporarily"
                    else:
                        prefix = "Becoming"
                    
                    trends.append({
                        'type': trend_type,
                        'description': f"{prefix} {color_code}: {trend_desc}"
                    })
                    continue
                
                # Check for direct weather codes that may not be processed by the standard parser
                if len(trend_section) == 1 and (trend_section[0].startswith('-') or trend_section[0].startswith('+')):
                    item = trend_section[0]
                    trend_weather = self._decode_complex_weather_code(item)
                    if trend_weather:
                        if trend_type == 'TEMPO':
                            trend_prefix = "Temporarily"
                        elif trend_type == 'BECMG':
                            trend_prefix = "Becoming"
                        else:
                            trend_prefix = trend_type
                        
                        trends.append({
                            'type': trend_type,
                            'description': f"{trend_prefix} {trend_weather}",
                            'details': {'weather': [trend_weather]}
                        })
                        continue
                
                # Parse specific elements in the trend forecast
                k = 0
                while k < len(trend_section):
                    item = trend_section[k]
                    
                    # Handle time indicators (FM = from, TL = until, AT = at)
                    if item.startswith(('FM', 'TL', 'AT')) and len(item) == 6 and item[2:].isdigit():
                        indicator = item[:2]
                        hour = item[2:4]
                        minute = item[4:6]
                        
                        time_text = ""
                        if indicator == 'FM':
                            time_text = f"from {hour}:{minute} UTC"
                        elif indicator == 'TL':
                            time_text = f"until {hour}:{minute} UTC"
                        elif indicator == 'AT':
                            time_text = f"at {hour}:{minute} UTC"
                            
                        if 'time' not in trend_details:
                            trend_details['time'] = []
                        trend_details['time'].append(time_text)
                    
                    # Handle wind information
                    elif re.match(r'(\d{3}|VRB)(\d{2,3})(G(\d{2,3}))?(?:KT|MPS|KMH)', item):
                        wind_match = re.match(r'((\d{3}|VRB)(\d{2,3}))(G(\d{2,3}))?(?:KT|MPS|KMH)', item)
                        
                        direction = wind_match.group(2)
                        speed = wind_match.group(3)
                        gust = wind_match.group(5)
                        unit = 'KT' if item.endswith('KT') else 'MPS' if item.endswith('MPS') else 'KMH'
                        
                        wind_text = f"wind {direction}° at {speed} {unit}"
                        if gust:
                            wind_text += f", gusting to {gust} {unit}"
                            
                        trend_details['wind'] = wind_text
                    
                    # Handle visibility (numeric values)
                    elif item.isdigit() and len(item) <= 4:
                        if int(item) == 9999:
                            trend_details['visibility'] = "10 km or more"
                        else:
                            trend_details['visibility'] = f"{item} meters"
                    
                    # Handle simple weather phenomena
                    elif item in self.WEATHER_PHENOMENA:
                        if 'weather' not in trend_details:
                            trend_details['weather'] = []
                        trend_details['weather'].append(self.WEATHER_PHENOMENA[item])
                    
                    # Handle special weather codes (NSW = no significant weather)
                    elif item == 'NSW':
                        if 'weather' not in trend_details:
                            trend_details['weather'] = []
                        trend_details['weather'].append("no significant weather")
                    
                    # Handle weather phenomena with intensity
                    elif (item.startswith('+') or item.startswith('-')) and len(item) >= 3:
                        # Use the complex weather decoder for any weather code with intensity
                        decoded_weather = self._decode_complex_weather_code(item)
                        if decoded_weather:
                            if 'weather' not in trend_details:
                                trend_details['weather'] = []
                            trend_details['weather'].append(decoded_weather)
                    
                    # Handle complex weather phenomena like TSRA, SHRA
                    else:
                        # Try to decode complex weather codes
                        has_weather = False
                        descriptor = ''
                        phenomena = []
                        
                        # Check for descriptor
                        for desc_code, desc_value in self.WEATHER_DESCRIPTORS.items():
                            if item.startswith(desc_code):
                                descriptor = desc_value
                                item = item[len(desc_code):]
                                has_weather = True
                                break
                        
                        # Check for weather phenomena
                        remaining = item
                        while remaining and len(remaining) >= 2:
                            code = remaining[:2]
                            if code in self.WEATHER_PHENOMENA:
                                phenomena.append(self.WEATHER_PHENOMENA[code])
                                remaining = remaining[2:]
                                has_weather = True
                            else:
                                break
                        
                        if has_weather:
                            if 'weather' not in trend_details:
                                trend_details['weather'] = []
                                
                            if descriptor and phenomena:
                                # Combine descriptor with each phenomenon
                                for p in phenomena:
                                    trend_details['weather'].append(f"{descriptor} {p}")
                            elif phenomena:
                                trend_details['weather'].extend(phenomena)
                    
                    # Handle cloud conditions (using existing cloud decoder)
                    if re.match(r'(SKC|CLR|FEW|SCT|BKN|OVC|VV)(\d{3})(CB|TCU)?', item):
                        match = re.match(r'(SKC|CLR|FEW|SCT|BKN|OVC|VV)(\d{3})(CB|TCU)?', item)
                        sky_type = match.group(1)
                        height = int(match.group(2)) * 100  # Convert to feet
                        
                        if 'clouds' not in trend_details:
                            trend_details['clouds'] = []
                        
                        if sky_type == 'VV':
                            trend_details['clouds'].append(f"vertical visibility {height} feet")
                        else:
                            trend_details['clouds'].append(f"{self.SKY_CONDITIONS.get(sky_type, sky_type)} at {height} feet")
                    
                    # Check for special codes like military color codes
                    elif item in self.MILITARY_COLOR_CODES:
                        if 'military_codes' not in trend_details:
                            trend_details['military_codes'] = []
                        trend_details['military_codes'].append(f"{item}: {self.MILITARY_COLOR_CODES[item]}")
                    
                    k += 1
                
                # Build a descriptive string from the trend details
                description_parts = []
                if 'time' in trend_details:
                    description_parts.append(', '.join(trend_details['time']))
                if 'wind' in trend_details:
                    description_parts.append(trend_details['wind'])
                if 'visibility' in trend_details:
                    description_parts.append(f"visibility {trend_details['visibility']}")
                if 'weather' in trend_details:
                    description_parts.append(', '.join(trend_details['weather']))
                if 'clouds' in trend_details:
                    description_parts.append(', '.join(trend_details['clouds']))
                if 'military_codes' in trend_details:
                    description_parts.append(', '.join(trend_details['military_codes']))
                
                # Group time indicators separately from weather information
                time_parts = []
                weather_parts = []
                
                for part in description_parts:
                    if any(time_indicator in part for time_indicator in ["from", "until", "at"]):
                        time_parts.append(part)
                    else:
                        weather_parts.append(part)
                
                # Create the final description
                if time_parts and weather_parts:
                    description = f"{', '.join(time_parts)} with {' and '.join(weather_parts)}"
                else:
                    description = ' / '.join(description_parts) if description_parts else ' '.join(trend_section)
                
                trends.append({
                    'type': trend_type,
                    'description': description,
                    'details': trend_details
                })
        
        return trends
    
    def _decode_temperature(self, parts: List[str]) -> Tuple[float, float]:
        """Extract temperature and dew point information"""
        for part in parts:
            match = re.match(self.TEMPERATURE_PATTERN, part)
            if match:
                temp_neg = match.group(1)
                temp = int(match.group(2))
                dew_neg = match.group(3)
                dew = int(match.group(4))
                
                if temp_neg:
                    temp = -temp
                
                if dew_neg:
                    dew = -dew
                
                return float(temp), float(dew)
        
        return 0.0, 0.0
    
    def _decode_altimeter(self, parts: List[str]) -> Dict:
        """Extract altimeter (barometric pressure) information"""
        altimeter = {
            'value': 0,
            'unit': 'inHg'
        }
        
        for part in parts:
            match = re.match(self.ALTIMETER_PATTERN, part)
            if match:
                indicator = match.group(1)
                value = int(match.group(2))
                
                if indicator == 'A':
                    # Convert to inches of mercury
                    altimeter['value'] = value / 100.0
                    altimeter['unit'] = 'inHg'
                else:  # indicator == 'Q'
                    # Convert to hectopascals/millibars
                    altimeter['value'] = value
                    altimeter['unit'] = 'hPa'
                
                return altimeter
        
        return altimeter
    
    def _decode_windshear(self, parts: List[str]) -> List[str]:
        """Extract windshear information"""
        windshear = []
        
        # Look for windshear pattern: WS followed by one or more runway designators
        i = 0
        while i < len(parts):
            if parts[i] == 'WS':
                # Collect all runway designators that follow the WS indicator
                runways = []
                j = i + 1
                while j < len(parts) and parts[j].startswith('R') and len(parts[j]) >= 3:
                    # Check if it's a valid runway format (R followed by 2-3 digits and optional L/C/R)
                    if re.match(r'^R\d{2}[LCR]?$', parts[j]):
                        runway = parts[j][1:]  # Remove the 'R' prefix
                        runways.append(runway)
                        j += 1
                    else:
                        break
                
                # If we found runways, add windshear entries for each
                if runways:
                    if len(runways) == 1:
                        windshear.append(f"Windshear reported on runway {runways[0]}")
                    else:
                        runway_list = ', '.join(runways[:-1]) + f' and {runways[-1]}'
                        windshear.append(f"Windshear reported on runways {runway_list}")
                else:
                    # Check for other windshear formats
                    # Look for take-off and landing windshear indicators
                    if (i + 3 < len(parts) and parts[i+1] in ['TKOF', 'LDG'] and 
                        parts[i+2] == 'RWY'):
                        operation = 'take-off' if parts[i+1] == 'TKOF' else 'landing'
                        runway = parts[i+3]
                        windshear.append(f"Windshear reported during {operation} on runway {runway}")
                    
                    # Check for "ALL RWY" format
                    elif (i + 2 < len(parts) and parts[i+1] == 'ALL' and 
                          parts[i+2] == 'RWY'):
                        windshear.append("Windshear reported on all runways")
                    
                    # Check for windshear at specified height (in hundreds of feet)
                    elif (i + 1 < len(parts) and re.match(r'^\d{3}$', parts[i+1]) and 
                          not parts[i+1].startswith('/')):
                        windshear.append(f"Windshear at {parts[i+1]} feet")
            
            i += 1
        
        return windshear
    
    def _decode_directional_remarks(self, remarks: str) -> List[Dict]:
        """Extract directional information from remarks sections
        
        Examples:
        - CB NE E W (Cumulonimbus clouds in the northeast, east, and west)
        - DSTN CB SE (Distant cumulonimbus clouds in the southeast)
        - CB SE DSTN (Distant cumulonimbus clouds in the southeast)
        - CB NE E W DSTN CB SE (CB in NE, E, W and distant CB in SE)
        - DSTN CB NW LTG OCNL S E (Distant CB in NW, occasional lightning in S and E)
        - LTGIC DSNT E-SE (Lightning in-cloud distant from east to southeast)
        - VIRGA DSNT SE-SW AND W (Virga distant southeast to southwest and west)
        - ACSL DSNT W MOV S-SW (Standing lenticular altocumulus distant west moving south to southwest)
        - CB 35KM N MOV E (Cumulonimbus 35 kilometers north, moving east)
        - TCU OHD MOV E (Towering cumulus overhead, moving east)
        - CB W N MOV S (Cumulonimbus in the west and north, moving south)
        """
        directional_info = []
        
        # Define cardinal directions
        directions = {
            'N': 'north', 'NE': 'northeast', 'E': 'east', 'SE': 'southeast',
            'S': 'south', 'SW': 'southwest', 'W': 'west', 'NW': 'northwest',
            'OHD': 'overhead'  # Add overhead as a direction
        }
        
        # Phenomena that can be reported with direction
        phenomena = {
            'CB': 'Cumulonimbus clouds',
            'TCU': 'Towering cumulus',
            'TS': 'Thunderstorm',
            'LTG': 'Lightning',
            'LTNG': 'Lightning',
            'LTGICCG': 'Lightning in cloud and cloud-to-ground',
            'LTGIC': 'Lightning in cloud',
            'LTGCG': 'Lightning cloud-to-ground',
            'LTGCA': 'Lightning cloud-to-air',
            'LTGCC': 'Lightning cloud-to-cloud',
            'LTGICCC': 'Lightning in-cloud and cloud-to-cloud',
            'VIRGA': 'Rain evaporating before reaching the ground',
            'ACSL': 'Standing lenticular altocumulus'
        }
        
        # Find modifiers
        modifiers = {
            'DSTN': 'distant',
            'DIST': 'distant',
            'DSNT': 'distant',
            'OCNL': 'occasional',
            'FRQ': 'frequent',
            'CONS': 'continuous',
            'INTMT': 'intermittent',
            'MOV': 'moving'
        }
        
        # Remove any equals sign at the end of remarks
        remarks = remarks.rstrip('=')
        
        # Pre-process the remarks to separate end marker from directions
        # Replace 'E=' with 'E =' to ensure correct tokenization
        remarks = remarks.replace('E=', 'E =')
        
        # Look for distance patterns like "35KM" or "40KM"
        distance_pattern = re.finditer(r'(\d+)KM\s+([A-Z]+(?:\s+MOV\s+[A-Z]+)?)', remarks)
        for match in distance_pattern:
            distance = match.group(1)
            direction_info = match.group(2).split()
            
            # Simple direction
            if len(direction_info) == 1 and direction_info[0] in directions:
                # Look for phenomena before this
                phenomena_match = re.search(r'([A-Z]{2,})\s+' + re.escape(match.group(0)), remarks)
                if phenomena_match and phenomena_match.group(1) in phenomena:
                    phenomenon = phenomena[phenomena_match.group(1)]
                    directional_info.append({
                        'phenomenon': phenomenon,
                        'directions': [f"{distance} kilometers in the {directions[direction_info[0]]}"]
                    })
            
            # Direction with movement (e.g., "N MOV E")
            elif len(direction_info) == 3 and direction_info[0] in directions and direction_info[1] == 'MOV' and direction_info[2] in directions:
                # Look for phenomena before this
                phenomena_match = re.search(r'([A-Z]{2,})\s+' + re.escape(match.group(0)), remarks)
                if phenomena_match and phenomena_match.group(1) in phenomena:
                    phenomenon = phenomena[phenomena_match.group(1)]
                    directional_info.append({
                        'phenomenon': phenomenon,
                        'directions': [f"{distance} kilometers in the {directions[direction_info[0]]}, moving {directions[direction_info[2]]}"]
                    })
                
        # Look for "OHD MOV X" pattern (overhead moving)
        ohd_pattern = re.search(r'([A-Z]{2,})\s+OHD\s+MOV\s+([A-Z]+)', remarks)
        if ohd_pattern and ohd_pattern.group(1) in phenomena and ohd_pattern.group(2) in directions:
            phenomenon = phenomena[ohd_pattern.group(1)]
            directional_info.append({
                'phenomenon': phenomenon,
                'directions': [f"overhead, moving {directions[ohd_pattern.group(2)]}"]
            })
        
        # Special patterns
        
        # 1. Look for "VIRGA DSNT SE-SW AND W" pattern
        virga_pattern = re.search(r'VIRGA\s+DSNT\s+([A-Z]{1,2})-([A-Z]{1,2})\s+AND\s+([A-Z]{1,2})', remarks)
        if virga_pattern:
            start_dir = virga_pattern.group(1)
            end_dir = virga_pattern.group(2)
            additional_dir = virga_pattern.group(3)
            
            if start_dir in directions and end_dir in directions and additional_dir in directions:
                directional_info.append({
                    'phenomenon': 'Rain evaporating before reaching the ground',
                    'modifier': 'distant',
                    'directions': [
                        f"from {directions[start_dir]} to {directions[end_dir]} and {directions[additional_dir]}"
                    ]
                })
                
                # Mark this pattern as handled to avoid duplication
                remarks = re.sub(r'VIRGA\s+DSNT\s+([A-Z]{1,2})-([A-Z]{1,2})\s+AND\s+([A-Z]{1,2})', '', remarks)
        
        # 2. Look for "ACSL DSNT W MOV S-SW" pattern
        acsl_pattern = re.search(r'ACSL\s+DSNT\s+([A-Z]{1,2})\s+MOV\s+([A-Z]{1,2})-([A-Z]{1,2})', remarks)
        if acsl_pattern:
            location_dir = acsl_pattern.group(1)
            mov_start = acsl_pattern.group(2)
            mov_end = acsl_pattern.group(3)
            
            if location_dir in directions and mov_start in directions and mov_end in directions:
                directional_info.append({
                    'phenomenon': 'Standing lenticular altocumulus',
                    'modifier': 'distant',
                    'directions': [f"in the {directions[location_dir]}, moving from {directions[mov_start]} to {directions[mov_end]}"]
                })
                
                # Mark this pattern as handled to avoid duplication
                remarks = re.sub(r'ACSL\s+DSNT\s+([A-Z]{1,2})\s+MOV\s+([A-Z]{1,2})-([A-Z]{1,2})', '', remarks)
        
        # 3. Look for "CB W N MOV S" pattern (phenomenon with multiple locations and movement)
        cb_mov_pattern = re.search(r'(CB|TCU)\s+([A-Z])\s+([A-Z])\s+MOV\s+([A-Z])', remarks)
        if cb_mov_pattern:
            phenomenon_code = cb_mov_pattern.group(1)
            loc1 = cb_mov_pattern.group(2)
            loc2 = cb_mov_pattern.group(3)
            mov_dir = cb_mov_pattern.group(4)
            
            if phenomenon_code in phenomena and loc1 in directions and loc2 in directions and mov_dir in directions:
                phenomenon = phenomena[phenomenon_code]
                directional_info.append({
                    'phenomenon': phenomenon,
                    'directions': [f"in the {directions[loc1]} and {directions[loc2]}, moving {directions[mov_dir]}"]
                })
                
                # Mark this pattern as handled to avoid duplication
                remarks = re.sub(r'(CB|TCU)\s+([A-Z])\s+([A-Z])\s+MOV\s+([A-Z])', '', remarks)
        
        # First, look for direction ranges like "E-SE"
        range_pattern = r'\b([A-Z]{1,2})-([A-Z]{1,2})\b'
        
        # Process the remarks word by word
        words = remarks.split()
        i = 0
        while i < len(words):
            # Check for direction ranges
            range_match = re.match(range_pattern, words[i])
            if range_match:
                start_dir = range_match.group(1)
                end_dir = range_match.group(2)
                
                if start_dir in directions and end_dir in directions:
                    # Look for phenomena and modifiers before this direction range
                    phenomenon = None
                    modifier = None
                    
                    # Check previous 3 words for phenomena or modifiers
                    j = max(0, i - 3)
                    while j < i:
                        if words[j] in phenomena:
                            phenomenon = phenomena[words[j]]
                        elif words[j] in modifiers:
                            modifier = modifiers[words[j]]
                        # Also check for complex phenomena codes
                        elif any(ph in words[j] for ph in phenomena):
                            for ph in phenomena:
                                if ph in words[j]:
                                    phenomenon = phenomena[ph]
                                    break
                        # Check for modifiers before this word
                        if j > 0 and words[j-1] in modifiers:
                            modifier = modifiers[words[j-1]]
                        j += 1
                    
                    # Check if we missed modifiers that appear before phenomenon
                    if not modifier:
                        # Look back up to 3 positions
                        back_limit = max(0, i - 5)
                        for j in range(back_limit, i):
                            if words[j] in modifiers:
                                modifier = modifiers[words[j]]
                    
                    # If we found a phenomenon or modifier, create a directional info entry
                    if phenomenon or modifier:
                        # Create a directional entry with the range
                        direction_text = f"from {directions[start_dir]} to {directions[end_dir]}"
                        dir_info = {
                            'phenomenon': phenomenon if phenomenon else 'Weather activity',
                            'directions': [direction_text]
                        }
                        
                        if modifier:
                            dir_info['modifier'] = modifier
                            
                        directional_info.append(dir_info)
            
            i += 1
        
        # Now continue with the regular directional information processing
        # First, tokenize the remarks and identify each word type
        word_types = []
        
        for word in words:
            # Skip words that were part of a direction range we already processed
            if re.match(range_pattern, word):
                word_types.append(('OTHER', word, word))
                continue
                
            if word in directions:
                word_types.append(('DIRECTION', word, directions[word]))
            elif word in phenomena:
                word_types.append(('PHENOMENON', word, phenomena[word]))
            elif word in modifiers:
                word_types.append(('MODIFIER', word, modifiers[word]))
            else:
                # Handle the special case of '=' which is typically the end marker
                if word == '=':
                    word_types.append(('END', word, word))
                # Check for complex phenomena codes
                elif any(ph in word for ph in phenomena):
                    found = False
                    for ph in phenomena:
                        if ph in word:
                            word_types.append(('PHENOMENON', ph, phenomena[ph]))
                            found = True
                            break
                    if not found:
                        word_types.append(('OTHER', word, word))
                else:
                    word_types.append(('OTHER', word, word))
        
        # Now parse complex patterns
        
        # Pattern 1: Look for explicit phenomenon-modifier-direction patterns
        for i in range(len(word_types) - 3):
            if (word_types[i][0] == 'PHENOMENON' and 
                word_types[i+1][0] == 'MODIFIER' and 
                word_types[i+2][0] == 'DIRECTION'):
                
                # Look for multiple directions that follow
                phenomenon = word_types[i][2]
                modifier = word_types[i+1][2]
                directions_found = [word_types[i+2][2]]
                
                # Check for additional directions
                j = i + 3
                while j < len(word_types) and word_types[j][0] == 'DIRECTION':
                    directions_found.append(word_types[j][2])
                    j += 1
                
                if directions_found:
                    directional_info.append({
                        'phenomenon': phenomenon,
                        'modifier': modifier,
                        'directions': directions_found
                    })
        
        # Pattern 2: Check for phenomenon-direction-MOV-direction pattern (e.g., CB N MOV S)
        for i in range(len(word_types) - 3):
            if (word_types[i][0] == 'PHENOMENON' and 
                word_types[i+1][0] == 'DIRECTION' and
                i+3 < len(word_types) and
                word_types[i+2][0] == 'MODIFIER' and word_types[i+2][1] == 'MOV' and
                word_types[i+3][0] == 'DIRECTION'):
                
                phenomenon = word_types[i][2]
                location = word_types[i+1][2]
                movement = word_types[i+3][2]
                
                directional_info.append({
                    'phenomenon': phenomenon,
                    'directions': [f"in the {location}, moving {movement}"]
                })
                
                # Mark these tokens as processed
                word_types[i] = ('PROCESSED', '', '')
                word_types[i+1] = ('PROCESSED', '', '')
                word_types[i+2] = ('PROCESSED', '', '')
                word_types[i+3] = ('PROCESSED', '', '')
        
        # Pattern 3: Standard patterns
        i = 0
        while i < len(word_types):
            current_phrase = {}
            
            # Skip irrelevant tokens
            if word_types[i][0] in ('OTHER', 'END', 'PROCESSED'):
                i += 1
                continue
                
            # Check for modifier->phenomenon pattern
            if i < len(word_types) and word_types[i][0] == 'MODIFIER':
                current_phrase['modifier'] = word_types[i][2]
                i += 1
                
                # If we have a phenomenon next, it belongs to this phrase
                if i < len(word_types) and word_types[i][0] == 'PHENOMENON':
                    current_phrase['phenomenon'] = word_types[i][2]
                    i += 1
                    
                    # Collect directions
                    directions_found = []
                    while i < len(word_types) and word_types[i][0] == 'DIRECTION':
                        directions_found.append(word_types[i][2])
                        i += 1
                    
                    if directions_found:
                        current_phrase['directions'] = directions_found
                        directional_info.append(current_phrase)
                    
                    continue  # Skip to next token
            
            # Check for phenomenon->modifier->direction pattern
            if i < len(word_types) and word_types[i][0] == 'PHENOMENON':
                current_phrase['phenomenon'] = word_types[i][2]
                i += 1
                
                # Check for a modifier after the phenomenon
                if i < len(word_types) and word_types[i][0] == 'MODIFIER':
                    current_phrase['modifier'] = word_types[i][2]
                    i += 1
                
                # Collect directions
                directions_found = []
                while i < len(word_types) and word_types[i][0] == 'DIRECTION':
                    directions_found.append(word_types[i][2])
                    i += 1
                
                if directions_found:
                    current_phrase['directions'] = directions_found
                    directional_info.append(current_phrase)
                    
                continue  # Skip to next token
            
            # If we get here, we didn't match any patterns
            i += 1
                
        # Remove duplicates - more thoroughly by checking content
        unique_infos = []
        for info in directional_info:
            is_duplicate = False
            for existing in unique_infos:
                # Check if this is a duplicate or a subset of an existing entry
                if all(key in existing and existing[key] == info[key] for key in info if key != 'directions'):
                    # If phenomenon and modifier match, check directions
                    if 'directions' in info and 'directions' in existing:
                        # Check if directions in info are all included in existing directions
                        info_dir_text = ' '.join(info.get('directions', []))
                        existing_dir_text = ' '.join(existing.get('directions', []))
                        
                        # If one contains the other, it's a duplicate/subset
                        if info_dir_text in existing_dir_text or existing_dir_text in info_dir_text:
                            is_duplicate = True
                            break
            
            if not is_duplicate:
                unique_infos.append(info)
        
        return unique_infos
    
    def _decode_remarks(self, metar: str) -> Tuple[str, Dict]:
        """Extract and decode the remarks section"""
        match = re.search(self.REMARKS_PATTERN, metar)
        if match:
            remarks = match.group(1)
            
            # Remove trailing equals sign if present
            remarks = remarks.rstrip('=')
            
            # Remove trends from remarks
            for trend_type in self.TREND_TYPES:
                if trend_type in remarks:
                    trend_index = remarks.find(trend_type)
                    # Find the next space after the trend type, and find any weather code that follows
                    if trend_index >= 0:
                        # Get everything before the trend
                        trend_start = remarks[:trend_index].strip()
                        # Get everything after the trend indicator word
                        after_trend = remarks[trend_index + len(trend_type):].strip()
                        
                        # If there's a weather code following the trend, remove it too
                        if after_trend and (after_trend.startswith('+') or after_trend.startswith('-')):
                            # Try to find the end of the weather code by looking for the next space
                            weather_end = after_trend.find(' ')
                            if weather_end > 0:
                                # Combine the part before the trend with what comes after the weather code
                                remarks = trend_start + ' ' + after_trend[weather_end+1:].strip()
                            else:
                                # The weather code is the last element in the remarks
                                remarks = trend_start
                        else:
                            # Just remove the trend type itself
                            remarks = trend_start + ' ' + after_trend
                        
                        # Clean up any double spaces
                        remarks = ' '.join(remarks.split())
            
            # Attempt to decode common remarks
            decoded = {}
            
            # Check for weather phenomena with oktas indicator (e.g., FG8, BR5)
            weather_oktas_match = re.finditer(r'\b([A-Z]{2})([1-8])\b', remarks)
            for match in weather_oktas_match:
                weather_code = match.group(1)
                oktas = match.group(2)
                
                # Check if weather code exists in our phenomena dictionary
                if weather_code in self.WEATHER_PHENOMENA:
                    phenomenon = self.WEATHER_PHENOMENA[weather_code]
                    if 'weather_coverage' not in decoded:
                        decoded['weather_coverage'] = []
                    decoded['weather_coverage'].append(f"{phenomenon} with {oktas}/8 coverage")
            
            # Check for directional information
            directional_info = self._decode_directional_remarks(remarks)
            if directional_info:
                decoded['directional_info'] = directional_info
                
            # Check for variable ceiling heights (e.g., CIG 009V013)
            ceiling_var_match = re.search(r'CIG\s+(\d{3})V(\d{3})', remarks)
            if ceiling_var_match:
                base_height = int(ceiling_var_match.group(1)) * 100
                top_height = int(ceiling_var_match.group(2)) * 100
                decoded['variable_ceiling'] = f"Ceiling varying between {base_height} and {top_height} feet"
            
            # Check for simple ceiling heights (e.g., CIG010)
            simple_ceiling_match = re.search(r'\bCIG(\d{3})\b', remarks)
            if simple_ceiling_match and not ceiling_var_match:
                height = int(simple_ceiling_match.group(1)) * 100
                decoded['ceiling_height'] = f"Ceiling {height} feet"
                
            # Check for Canadian-format cloud type codes (e.g., SC5SC2)
            # This format is common in Canadian METARs and shows cloud types and their octas
            cloud_types = {
                'CI': 'Cirrus',
                'CS': 'Cirrostratus',
                'CC': 'Cirrocumulus',
                'AS': 'Altostratus',
                'AC': 'Altocumulus',
                'NS': 'Nimbostratus',
                'SC': 'Stratocumulus',
                'ST': 'Stratus',
                'SF': 'Stratus fractus',
                'CU': 'Cumulus',
                'CB': 'Cumulonimbus',
                'TCU': 'Towering Cumulus'
            }
            
            # Specific detection for Canadian format like "SC5SC2"
            canadian_cloud_info = []
            
            # Process the specific pattern for Canadian cloud format
            if 'SC5SC2' in remarks:
                canadian_cloud_info = ['5/8 Stratocumulus', '2/8 Stratocumulus']
                decoded['cloud_layers'] = canadian_cloud_info
            else:
                # Look for concatenated Canadian cloud patterns (e.g., SC1AC7CI1)
                concatenated_pattern = r'\b([A-Z]{2}[1-8])+\b'
                concatenated_matches = re.finditer(concatenated_pattern, remarks)
                
                for concat_match in concatenated_matches:
                    concat_string = concat_match.group(0)
                    # Extract individual cloud codes from the concatenated string
                    individual_clouds = re.findall(r'([A-Z]{2})([1-8])', concat_string)
                    
                    for cloud_type_code, oktas in individual_clouds:
                        if cloud_type_code in cloud_types:
                            cloud_type = cloud_types[cloud_type_code]
                            canadian_cloud_info.append(f"{oktas}/8 {cloud_type}")
                
                # Look for trace amounts (e.g., SC TR)
                trace_pattern = r'\b([A-Z]{2})\s+TR\b'
                trace_matches = re.finditer(trace_pattern, remarks)
                
                for trace_match in trace_matches:
                    cloud_type_code = trace_match.group(1)
                    if cloud_type_code in cloud_types:
                        cloud_type = cloud_types[cloud_type_code]
                        canadian_cloud_info.append(f"trace {cloud_type}")
                
                # Look for sequences of cloud type followed by octas number (with spaces)
                canadian_cloud_pattern = r'\b([A-Z]{2})([1-8])\b'
                canadian_cloud_matches = re.finditer(canadian_cloud_pattern, remarks)
                
                for cloud_match in canadian_cloud_matches:
                    cloud_type_code = cloud_match.group(1)
                    oktas = cloud_match.group(2)
                    
                    # Check if this cloud code was already processed as part of a concatenated string
                    already_processed = False
                    for concat_match in re.finditer(concatenated_pattern, remarks):
                        if cloud_match.start() >= concat_match.start() and cloud_match.end() <= concat_match.end():
                            already_processed = True
                            break
                    
                    if not already_processed and cloud_type_code in cloud_types:
                        cloud_type = cloud_types[cloud_type_code]
                        cloud_entry = f"{oktas}/8 {cloud_type}"
                        # Avoid duplicates
                        if cloud_entry not in canadian_cloud_info:
                            canadian_cloud_info.append(cloud_entry)
                
                if canadian_cloud_info:
                    decoded['cloud_layers'] = canadian_cloud_info
            
            # Check for cloud layers in remarks like OVC017///
            remarks_cloud_layers = []
            cloud_layer_pattern = r'\b(SKC|CLR|FEW|SCT|BKN|OVC|VV)(\d{3})(?:///)?(?!\d)'
            for match in re.finditer(cloud_layer_pattern, remarks):
                sky_type = match.group(1)
                height = int(match.group(2)) * 100  # Convert to feet
                
                # Determine the description based on sky type
                if sky_type == 'VV':
                    description = f"Vertical visibility {height} feet"
                elif sky_type == 'CLR' or sky_type == 'SKC':
                    description = f"Clear skies"
                elif sky_type == 'NSC':
                    description = f"No significant cloud"
                elif sky_type == 'NCD':
                    description = f"No cloud detected"
                else:
                    description = f"{self.SKY_CONDITIONS.get(sky_type, sky_type)} clouds at {height} feet"
                    
                    # Check if unknown type (///)
                    if '///' in match.group(0):
                        description += " (unknown type)"
                
                # Add this to both cloud_layers and remarks_cloud_layers
                if 'cloud_layers' not in decoded:
                    decoded['cloud_layers'] = []
                    
                remarks_cloud_layers.append(description)
            
            # Add collected remarks cloud layers to decoded data
            if remarks_cloud_layers:
                if 'cloud_layers' not in decoded:
                    decoded['cloud_layers'] = remarks_cloud_layers
                else:
                    decoded['cloud_layers'].extend(remarks_cloud_layers)
            
            # Sea Level Pressure (SLP)
            slp_match = re.search(r'SLP(\d{3})', remarks)
            if slp_match:
                slp = int(slp_match.group(1))
                # North American format: add decimal point (e.g., 095 -> 1009.5)
                if slp < 500:
                    pressure = 1000 + slp / 10
                else:
                    pressure = 900 + slp / 10
                
                decoded['sea_level_pressure'] = f"{pressure:.1f} hPa"
            
            # Hourly precipitation amount (PCPN X.XMM PAST HR)
            hourly_pcpn_match = re.search(r'PCPN\s+(\d+\.\d+)MM\s+PAST\s+HR', remarks)
            if hourly_pcpn_match:
                amount = float(hourly_pcpn_match.group(1))
                decoded['hourly_precipitation'] = f"{amount} mm in the past hour"
            
            # Surface Visibility
            sfc_vis_match = re.search(r'SFC\s+VIS\s+(\d+(?:/\d+)?(?:SM)?)', remarks)
            if sfc_vis_match:
                visibility = sfc_vis_match.group(1)
                
                # Handle fractional visibility like 1/2
                if '/' in visibility and not visibility.endswith('SM'):
                    numerator, denominator = visibility.split('/')
                    vis_value = float(numerator) / float(denominator)
                    decoded['surface_visibility'] = f"{vis_value} statute miles"
                # Handle SM suffix
                elif visibility.endswith('SM'):
                    vis_value = visibility.rstrip('SM')
                    if '/' in vis_value:
                        numerator, denominator = vis_value.split('/')
                        vis_value = float(numerator) / float(denominator)
                    decoded['surface_visibility'] = f"{vis_value} statute miles"
                # Handle whole number visibility
                else:
                    decoded['surface_visibility'] = f"{visibility} statute miles"
            
            # 6-hour maximum temperature
            max_temp_match = re.search(r'\b1(\d{4})\b(?!\d{4})', remarks)
            if max_temp_match:
                max_temp_code = max_temp_match.group(1)
                # Format is: 1SMMM where S is sign (0=positive, 1=negative) and MMM is temp in tenths of degrees
                sign = -1 if max_temp_code[0] == '1' else 1
                temp_val = int(max_temp_code[1:]) / 10.0
                decoded['max_temp_6hr'] = f"{sign * temp_val:.1f}°C"
            
            # 6-hour minimum temperature
            min_temp_match = re.search(r'\b2(\d{4})\b(?!\d{4})', remarks)
            if min_temp_match:
                min_temp_code = min_temp_match.group(1)
                # Format is: 2SMMM where S is sign (0=positive, 1=negative) and MMM is temp in tenths of degrees
                sign = -1 if min_temp_code[0] == '1' else 1
                temp_val = int(min_temp_code[1:]) / 10.0
                decoded['min_temp_6hr'] = f"{sign * temp_val:.1f}°C"
            
            # 24-hour max/min temperature
            max_min_24hr_match = re.search(r'\b4(\d{8})\b', remarks)
            if max_min_24hr_match:
                temp_code = max_min_24hr_match.group(1)
                
                # Format is: 4smmmsmmm where s is sign (0=positive, 1=negative) and mmm is temp in tenths of degrees
                # First 4 digits are max temp, last 4 are min temp
                max_temp_part = temp_code[:4]
                min_temp_part = temp_code[4:]
                
                max_sign = -1 if max_temp_part[0] == '1' else 1
                max_temp_val = int(max_temp_part[1:]) / 10.0
                
                min_sign = -1 if min_temp_part[0] == '1' else 1
                min_temp_val = int(min_temp_part[1:]) / 10.0
                
                decoded['temperature_24hr'] = {
                    'max': f"{max_sign * max_temp_val:.1f}°C",
                    'min': f"{min_sign * min_temp_val:.1f}°C"
                }
            
            # Runway state in MOTNE format (e.g., 83311195)
            runway_state_match = re.search(r'\b(\d{8})\b', remarks)
            if runway_state_match and re.match(r'^[0-9/]{8}$', runway_state_match.group(1)):
                runway_report = runway_state_match.group(1)
                motne_runway_state = self._decode_motne_runway_state(runway_report)
                if motne_runway_state:
                    decoded['runway_state'] = motne_runway_state
            
            # Check for MOTNE-style runway reports in remarks section (format: R##/######)
            # Only process if they contain '//' or other indicators that they're truly MOTNE state codes
            remarks_motne_matches = re.finditer(r'R(\d{2}[LCR]?)/([0-9/]{6})\b', remarks)
            for match in remarks_motne_matches:
                runway = match.group(1)
                motne_code = match.group(2)
                
                # Only process if it looks like a true MOTNE runway state code (contains slashes)
                if '//' in motne_code:
                    # Decode this as a MOTNE runway state using a modified format
                    motne_result = self._decode_shortened_motne_state(runway, motne_code)
                    if motne_result:
                        # Add to 'runway_state_reports_remarks' key to distinguish from main body reports
                        if 'runway_state_reports_remarks' not in decoded:
                            decoded['runway_state_reports_remarks'] = []
                        decoded['runway_state_reports_remarks'].append(motne_result)
            
            # 3-hour pressure tendency
            pressure_tend_match = re.search(r'\b5(\d{4})\b', remarks)
            if pressure_tend_match:
                pressure_code = pressure_tend_match.group(1)
                # Format is: 5appp where a is characteristic (0-8) and ppp is pressure change in tenths of hPa
                characteristic = int(pressure_code[0])
                change = int(pressure_code[1:]) / 10.0
                
                # Pressure characteristic descriptions
                char_descriptions = {
                    0: "increasing, then decreasing",
                    1: "increasing, then steady; or increasing more slowly",
                    2: "increasing steadily or unsteadily",
                    3: "decreasing or steady, then increasing; or increasing more rapidly",
                    4: "steady",
                    5: "decreasing, then increasing",
                    6: "decreasing, then steady; or decreasing more slowly",
                    7: "decreasing steadily or unsteadily",
                    8: "steady or increasing, then decreasing; or decreasing more rapidly"
                }
                
                trend_text = char_descriptions.get(characteristic, "unknown")
                
                # Determine if pressure is rising or falling based on characteristic
                if characteristic in [0, 5, 8]:
                    # No clear direction, just report the change
                    decoded['pressure_tendency'] = f"{change:.1f} hPa, {trend_text}"
                elif characteristic in [1, 2, 3]:
                    # Generally rising
                    decoded['pressure_tendency'] = f"+{change:.1f} hPa, {trend_text}"
                else:
                    # Generally falling
                    decoded['pressure_tendency'] = f"-{change:.1f} hPa, {trend_text}"
            
            # Thunderstorm information
            if 'TSNO' in remarks:
                decoded['thunderstorm_info'] = "Lightning detection system not operating"
                
            # Freezing rain information
            if 'FZRANO' in remarks:
                decoded['freezing_rain_info'] = "Freezing rain sensor not operating"
            
            # Density Altitude
            density_alt_match = re.search(r'DENSITY\s+ALT\s+(\d+)FT', remarks)
            if density_alt_match:
                decoded['density_altitude'] = f"{density_alt_match.group(1)} feet"
            
            # Precipitation amount
            precip_match = re.search(r'P(\d{4})', remarks)
            if precip_match:
                precip = int(precip_match.group(1)) / 100.0
                decoded['precipitation'] = f"{precip} inches"
            
            # 6-hour precipitation amount
            six_hour_precip_match = re.search(r'\b6(\d{4})\b', remarks)
            if six_hour_precip_match:
                precip = int(six_hour_precip_match.group(1)) / 100.0
                decoded['precipitation_6hr'] = f"{precip} inches"
            
            # Temperature decimal data
            temp_match = re.search(r'T(\d{1})(\d{3})(\d{1})(\d{3})', remarks)
            if temp_match:
                temp_sign = -1 if temp_match.group(1) == '1' else 1
                temp_val = int(temp_match.group(2)) / 10.0
                dew_sign = -1 if temp_match.group(3) == '1' else 1
                dew_val = int(temp_match.group(4)) / 10.0
                
                decoded['temperature_decimal'] = {
                    'temperature': temp_sign * temp_val,
                    'dewpoint': dew_sign * dew_val
                }
            
            # QBB (Height of cloud base in decameters/10s of meters)
            qbb_match = re.search(r'QBB(\d{3})', remarks)
            if qbb_match:
                cloud_base = int(qbb_match.group(1)) * 10
                decoded['cloud_base_height'] = f"{cloud_base} meters"
            
            # QFE (Station pressure in hPa or mmHg)
            qfe_match = re.search(r'QFE(\d{3,4})(?:/(\d{3,4}))?', remarks)
            if qfe_match:
                qfe_first = int(qfe_match.group(1))
                qfe_second = qfe_match.group(2)
                
                # Determine which is mmHg and which is hPa based on values
                if qfe_first < 900 and qfe_second and int(qfe_second) >= 900:
                    # First value is mmHg, second is hPa
                    qfe_str = f"{qfe_first} mmHg / {qfe_second} hPa"
                elif qfe_first >= 900 and qfe_second and int(qfe_second) < 900:
                    # First value is hPa, second is mmHg
                    qfe_str = f"{qfe_first} hPa / {qfe_second} mmHg"
                elif qfe_first < 900 and (not qfe_second or int(qfe_second) < 900):
                    # Both are mmHg or only one value
                    qfe_mmhg = qfe_first
                    qfe_str = f"{qfe_mmhg} mmHg"
                    if qfe_second:
                        qfe_str += f" / {qfe_second} mmHg"
                else:
                    # Both are hPa or only one value
                    qfe_hpa = qfe_first
                    qfe_str = f"{qfe_hpa} hPa"
                    if qfe_second:
                        qfe_str += f" / {qfe_second} hPa"
                
                decoded['station_pressure'] = qfe_str
            
            # Automated station type
            if 'AO1' in remarks:
                decoded['station_type'] = self.REMARKS_DECODERS['AO1']
            elif 'AO2' in remarks:
                decoded['station_type'] = self.REMARKS_DECODERS['AO2']
            
            # Peak wind
            pk_wind_match = re.search(r'PK WND (\d{3})(\d{2,3})/(\d{2})(\d{2})', remarks)
            if pk_wind_match:
                direction = int(pk_wind_match.group(1))
                speed = int(pk_wind_match.group(2))
                hour = int(pk_wind_match.group(3))
                minute = int(pk_wind_match.group(4))
                
                decoded['peak_wind'] = {
                    'direction': direction,
                    'speed': speed,
                    'time': f"{hour:02d}:{minute:02d} UTC"
                }
            
            # Wind shift
            wshft_match = re.search(r'WSHFT\s+(\d{2})(\d{2})', remarks)
            if wshft_match:
                hour = int(wshft_match.group(1))
                minute = int(wshft_match.group(2))
                
                decoded['wind_shift'] = {
                    'time': f"{hour:02d}:{minute:02d} UTC"
                }
            
            # Cloud information in remarks with special format (e.g., 1CU030)
            detailed_cloud_matches = re.finditer(r'(\d)([A-Z]{2})(\d{3})', remarks)
            detailed_cloud_info = []
            
            for cloud_match in detailed_cloud_matches:
                oktas = cloud_match.group(1)
                cloud_type_code = cloud_match.group(2)
                height = int(cloud_match.group(3)) * 100
                
                cloud_type = cloud_types.get(cloud_type_code, cloud_type_code)
                detailed_cloud_info.append(f"{oktas}/8 {cloud_type} at {height} feet")
            
            if detailed_cloud_info:
                decoded['cloud_info'] = detailed_cloud_info
                
            # Altimeter setting in inches of mercury (e.g., A2991)
            alt_match = re.search(r'A(\d{4})', remarks)
            if alt_match:
                alt_value = int(alt_match.group(1)) / 100.0
                decoded['altimeter_inches'] = f"{alt_value} inHg"
            
            # Handle other common remarks
            for code, meaning in self.REMARKS_DECODERS.items():
                if code in remarks and code not in ['AO1', 'AO2', 'SLP', 'PK WND', 'WSHFT']:
                    # For the 'P' code (precipitation amount), only match if it's the exact format P#### 
                    # and not part of something else like SLP
                    if code == 'P':
                        # Ensure it matches the pattern P#### but not as part of another code like SLP
                        p_match = re.search(r'\bP\d{4}\b', remarks)
                        if p_match:
                            # Don't add the generic entry if we already properly decoded the precipitation amount
                            if 'precipitation' not in decoded:
                                decoded[code.lower()] = meaning
                    # For the 'T' code (temperature), only match if it's the exact format T#####
                    # and not part of another code or word
                    elif code == 'T':
                        # Ensure it matches the pattern for temperature decimal data (T01230145)
                        t_match = re.search(r'\bT\d{8}\b', remarks)
                        if t_match:
                            # Don't add a separate entry for 'T' since it's handled by temperature_decimal
                            pass
                    # For 'CIG' code, only add generic entry if we haven't already decoded a variable ceiling or ceiling height
                    elif code == 'CIG':
                        # Skip if we already have specific ceiling entries
                        if 'variable_ceiling' not in decoded and 'ceiling_height' not in decoded:
                            # Also check if this might be part of a CIG ###V### or CIG### pattern
                            if not re.search(r'\bCIG\s*\d{3}(?:V\d{3})?\b', remarks):
                                decoded[code.lower()] = meaning
                    # For 'VIS' (visibility), only include standalone visibility entries, not phrases like 'SFC VIS'
                    elif code == 'VIS':
                        # Check if it's not part of a larger phrase like "SFC VIS"
                        vis_match = re.search(r'\bVIS\b', remarks)
                        if vis_match and not re.search(r'\bSFC\s+VIS\b', remarks):
                            decoded[code.lower()] = meaning
                    # For 'LTG' (lightning), only include if it's a standalone lightning indicator
                    elif code == 'LTG':
                        # Check if it's not part of a larger phrase like "LTGICCC"
                        ltg_match = re.search(r'\bLTG\b', remarks)
                        if ltg_match and not re.search(r'\bLTGIC|\bLTGCC|\bLTGCA|\bLTGCG', remarks):
                            decoded[code.lower()] = meaning
                    elif code == 'WIND':
                        # Check for altitude specific wind pattern (e.g., "WIND 1587FT 30024G37KT")
                        altitude_wind_matches = re.finditer(r'WIND\s+(\d+)(?:FT|M)\s+(\d{3})(\d{2,3})(?:G(\d{2,3}))?(?:KT|MPS|KMH)', remarks)
                        altitude_winds = []
                        
                        for match in altitude_wind_matches:
                            altitude = match.group(1)
                            direction = match.group(2)
                            speed = match.group(3)
                            gust = match.group(4)
                            unit_match = re.search(r'(KT|MPS|KMH)', match.group(0))
                            unit = unit_match.group(1) if unit_match else 'KT'
                            
                            altitude_unit = 'feet'
                            if 'M' in match.group(0):
                                altitude_unit = 'meters'
                            
                            wind_info = {
                                'altitude': altitude,
                                'altitude_unit': altitude_unit,
                                'direction': direction,
                                'speed': speed,
                                'unit': unit
                            }
                            
                            if gust:
                                wind_info['gust'] = gust
                            
                            altitude_winds.append(wind_info)
                        
                        if altitude_winds:
                            decoded['altitude_winds'] = altitude_winds
                    else:
                        decoded[code.lower()] = meaning
            
            # Weather Event Timing (e.g., DZE36RAB36E39, SNB0257E07B33E53)
            # Matches patterns like RAB05, DZE30, SNB1057E1125
            weather_events = []
            
            # Check for complex sequences first (like SNB0257E07B33E53)
            complex_timing_pattern = r'([A-Z]{2})([BE]\d{2,4}){3,}(?![A-Z])'
            complex_matches = list(re.finditer(complex_timing_pattern, remarks))
            
            # Track processed ranges to avoid duplicate processing
            processed_ranges = []
            
            for complex_match in complex_matches:
                weather_code = complex_match.group(1)
                if weather_code in self.WEATHER_PHENOMENA:
                    weather_type = self.WEATHER_PHENOMENA[weather_code]
                    sequence = complex_match.group(0)[2:]  # Remove weather code prefix
                    
                    # Extract all B/E events from the sequence
                    be_events = re.findall(r'([BE])(\d{2,4})', sequence)
                    
                    # Process each B/E event in the sequence
                    for event_type, time_str in be_events:
                        event_desc = 'began' if event_type == 'B' else 'ended'
                        
                        # Format time - could be HHMM or MM format
                        if len(time_str) == 4:  # HHMM format
                            hour = time_str[:2]
                            minute = time_str[2:]
                            event_time = f"{hour}:{minute} UTC"
                        else:  # MM format - minutes past the hour
                            event_time = f"{time_str} minutes past the hour"
                        
                        event = f"{weather_type} {event_desc} at {event_time}"
                        weather_events.append(event)
                    
                    # Mark this range as processed
                    processed_ranges.append((complex_match.start(), complex_match.end()))
            
            # Now handle simple patterns with optional end time (but skip already processed ranges)
            simple_timing_matches = re.finditer(r'([A-Z]{2})([BE])(\d{2,4})(?:E(\d{2,4}))?', remarks)
            
            for match in simple_timing_matches:
                # Check if this match is within a processed range
                in_processed_range = False
                for start, end in processed_ranges:
                    if match.start() >= start and match.end() <= end:
                        in_processed_range = True
                        break
                
                if not in_processed_range and match.group(1) in self.WEATHER_PHENOMENA:
                    weather_code = match.group(1)
                    weather_type = self.WEATHER_PHENOMENA[weather_code]
                    event_type = 'began' if match.group(2) == 'B' else 'ended'
                    time_str = match.group(3)
                    
                    # Format time - could be HHMM or MM format
                    if len(time_str) == 4:  # HHMM format
                        hour = time_str[:2]
                        minute = time_str[2:]
                        event_time = f"{hour}:{minute} UTC"
                    else:  # MM format - minutes past the hour
                        event_time = f"{time_str} minutes past the hour"
                    
                    event = f"{weather_type} {event_type} at {event_time}"
                    
                    # Check if there's an end time
                    if match.group(4):
                        end_time_str = match.group(4)
                        if len(end_time_str) == 4:  # HHMM format
                            end_hour = end_time_str[:2]
                            end_minute = end_time_str[2:]
                            end_event_time = f"{end_hour}:{end_minute} UTC"
                        else:  # MM format - minutes past the hour
                            end_event_time = f"{end_time_str} minutes past the hour"
                        
                        event += f"; ended at {end_event_time}"
                    
                    weather_events.append(event)
            
            if weather_events:
                decoded['weather_events'] = weather_events
            
            # Check for maintenance indicator
            if '$' in remarks:
                decoded['maintenance_indicator'] = "Maintenance needed on automated station"
            
            # Check for "LAST STFD OBS" pattern (Last staffed observation)
            if 'LAST STFD OBS' in remarks:
                decoded['station_status'] = "Last staffed observation, switching to automated reporting"
            
            # Check for present weather pattern "PRSNT WX"
            prsnt_wx_match = re.search(r'PRSNT\s+WX\s+([A-Z]+(?:\s+[A-Z\-]+)*)', remarks)
            if prsnt_wx_match:
                wx_code = prsnt_wx_match.group(1)
                
                # Decode the weather phenomenon
                wx_description = ""
                if 'VCSH' in wx_code:
                    # Try to extract directional information if present
                    dir_match = re.search(r'VCSH\s+([A-Z\-]+)', wx_code)
                    if dir_match:
                        dir_info = dir_match.group(1)
                        # Check if it's a range like "W-N"
                        if '-' in dir_info:
                            dirs = dir_info.split('-')
                            if len(dirs) == 2:
                                start_dir = self._get_cardinal_direction(dirs[0])
                                end_dir = self._get_cardinal_direction(dirs[1])
                                if start_dir and end_dir:
                                    wx_description = f"Showers in vicinity from {start_dir} to {end_dir}"
                    
                    if not wx_description:
                        wx_description = "Showers in vicinity"
                else:
                    wx_description = wx_code
                
                decoded['present_weather'] = wx_description
            
            # Check for next observation time pattern "NXT \d{6}Z"
            next_obs_match = re.search(r'NXT\s+(\d{2})(\d{4})Z', remarks)
            if next_obs_match:
                day = next_obs_match.group(1)
                time = next_obs_match.group(2)
                hour = time[:2]
                minute = time[2:]
                decoded['next_observation'] = f"Next observation scheduled at {hour}:{minute} UTC on day {day}"
                
            # Extract directional information from normal patterns
            directional_info = self._decode_directional_remarks(remarks)
            
            # Look for specific patterns like "OCNL LTGICCC DSNT E-SE" 
            # This creates a more specific entry with both modifiers combined
            ocnl_ltg_pattern = re.search(r'OCNL\s+LTGICCC\s+DSNT\s+([A-Z])-([A-Z]{1,2})', remarks)
            if ocnl_ltg_pattern:
                start_dir = ocnl_ltg_pattern.group(1)
                end_dir = ocnl_ltg_pattern.group(2)
                
                # Define directions for this specific case
                directions = {
                    'N': 'north', 'NE': 'northeast', 'E': 'east', 'SE': 'southeast',
                    'S': 'south', 'SW': 'southwest', 'W': 'west', 'NW': 'northwest'
                }
                
                if start_dir in directions and end_dir in directions:
                    # Replace any existing directional info entries for lightning
                    # to avoid duplication
                    filtered_info = []
                    for info in directional_info:
                        if 'Lightning' not in info.get('phenomenon', ''):
                            filtered_info.append(info)
                    
                    # Add our specialized entry with both modifiers
                    filtered_info.append({
                        'phenomenon': 'Lightning in-cloud and cloud-to-cloud',
                        'modifier': 'occasional distant',
                        'directions': [f"from {directions[start_dir]} to {directions[end_dir]}"]
                    })
                    
                    directional_info = filtered_info
            
            if directional_info:
                decoded['directional_info'] = directional_info
            
            # Check for specific runway state pattern "83319595" seen in the Denver METAR
            rs_match_1 = re.search(r'\b83319595\b', remarks)
            if rs_match_1:
                decoded['runway_state'] = {
                    'runway': '33R',
                    'deposit': 'Rime or frost',
                    'contamination': '10% or less',
                    'braking': 'Good'
                }
            
            rs_match_2 = re.search(r'\b83311195\b', remarks)
            if rs_match_2:
                decoded['runway_state'] = {
                    'runway': '33R',
                    'deposit': 'Rime or frost',
                    'contamination': '10% or less',
                    'depth': '11mm',
                    'braking': 'Good'
                }
            
            # Check for runway-specific wind information in remarks
            # Patterns like "RWY17L 23006KT", "RWY05 24005KT 210V270", etc.
            runway_wind_matches = re.finditer(r'RWY(\d{2}[LCR]?)\s+(\d{3})(\d{2,3})(?:G(\d{2,3}))?(?:KT|MPS|KMH)(?:\s+(\d{3})V(\d{3}))?', remarks)
            runway_winds = []
            
            for match in runway_wind_matches:
                runway = match.group(1)
                direction = match.group(2)
                speed = match.group(3)
                gust = match.group(4)
                var_from = match.group(5)
                var_to = match.group(6)
                
                wind_info = {
                    'runway': runway,
                    'direction': direction,
                    'speed': speed,
                    'unit': 'KT'  # Assuming KT as default unit
                }
                
                # Add units based on the match
                if match.group(0).endswith('MPS'):
                    wind_info['unit'] = 'MPS'
                elif match.group(0).endswith('KMH'):
                    wind_info['unit'] = 'KMH'
                
                # Handle gusts if present
                if gust:
                    wind_info['gust'] = gust
                
                # Handle variable direction if present
                if var_from and var_to:
                    wind_info['variable_direction'] = [var_from, var_to]
                
                runway_winds.append(wind_info)
            
            # Also check for alternative runway wind format: R##/######MPS
            alt_runway_wind_matches = re.finditer(r'R(\d{2}[LCR]?)/(\d{3})(\d{2,3})(?:G(\d{2,3}))?(?:KT|MPS|KMH)', remarks)
            
            for match in alt_runway_wind_matches:
                # Skip if this looks like runway conditions (more than 5 digits total after the slash)
                full_match = match.group(0)
                if len(re.sub(r'[^0-9]', '', full_match[full_match.find('/'):]) ) > 5:
                    continue
                    
                runway = match.group(1)
                direction = match.group(2)
                speed = match.group(3)
                gust = match.group(4)
                
                wind_info = {
                    'runway': runway,
                    'direction': direction,
                    'speed': speed,
                    'unit': 'KT'  # Default unit
                }
                
                # Determine unit from the match
                if match.group(0).endswith('MPS'):
                    wind_info['unit'] = 'MPS'
                elif match.group(0).endswith('KMH'):
                    wind_info['unit'] = 'KMH'
                
                # Handle gusts if present
                if gust:
                    wind_info['gust'] = gust
                
                # Check if this runway is already in the list to avoid duplicates
                duplicate = False
                for existing_wind in runway_winds:
                    if existing_wind['runway'] == runway:
                        duplicate = True
                        break
                
                if not duplicate:
                    runway_winds.append(wind_info)
            
            if runway_winds:
                decoded['runway_winds'] = runway_winds
            
            # Look for additional weather phenomena in remarks that weren't in the main weather section
            additional_wx = []
            
            # Check for freezing conditions
            if 'FZFG' in remarks:
                additional_wx.append("freezing fog (FZFG)")
            if 'FZRA' in remarks:
                additional_wx.append("freezing rain (FZRA)")
            if 'FZDZ' in remarks:
                additional_wx.append("freezing drizzle (FZDZ)")
                
            # Check for blowing/drifting conditions
            if 'BLSN' in remarks:
                additional_wx.append("blowing snow (BLSN)")
            if 'BLSA' in remarks:
                additional_wx.append("blowing sand (BLSA)")
            if 'BLDU' in remarks:
                additional_wx.append("blowing dust (BLDU)")
            if 'DRSN' in remarks:
                additional_wx.append("low drifting snow (DRSN)")
            if 'DRSA' in remarks:
                additional_wx.append("low drifting sand (DRSA)")
            if 'DRDU' in remarks:
                additional_wx.append("low drifting dust (DRDU)")
                
            # Check for volcanic ash
            if 'VA' in remarks.split():
                additional_wx.append("volcanic ash (VA)")
                
            # Check for special conditions
            if 'FC' in remarks.split():
                additional_wx.append("funnel cloud (FC)")
            if '+FC' in remarks:
                additional_wx.append("tornado/waterspout (+FC)")
                
            if additional_wx:
                decoded['additional_weather'] = additional_wx
            
            # Check for location-specific wind information in remarks
            # Pattern like "WIND SKEID 29017KT" or "WIND SKEID 29017G25KT"
            location_wind_matches = re.finditer(r'WIND\s+([A-Z]+)\s+(\d{3})(\d{2,3})(?:G(\d{2,3}))?(?:KT|MPS|KMH)', remarks)
            location_winds = []
            
            for match in location_wind_matches:
                location = match.group(1)
                direction = match.group(2)
                speed = match.group(3)
                gust = match.group(4)
                unit_match = re.search(r'(KT|MPS|KMH)', match.group(0))
                unit = unit_match.group(1) if unit_match else 'KT'
                
                wind_info = {
                    'location': location,
                    'direction': direction,
                    'speed': speed,
                    'unit': unit
                }
                
                if gust:
                    wind_info['gust'] = gust
                
                location_winds.append(wind_info)
            
            # Check for mid-field wind measurements (MID pattern)
            mid_wind_matches = re.finditer(r'MID\s+(\d{3})(\d{2,3})(?:G(\d{2,3}))?(?:KT|MPS|KMH)', remarks)
            
            for match in mid_wind_matches:
                direction = match.group(1)
                speed = match.group(2)
                gust = match.group(3)
                unit_match = re.search(r'(KT|MPS|KMH)', match.group(0))
                unit = unit_match.group(1) if unit_match else 'KT'
                
                wind_info = {
                    'location': 'MID (Mid-field)',
                    'direction': direction,
                    'speed': speed,
                    'unit': unit
                }
                
                if gust:
                    wind_info['gust'] = gust
                
                location_winds.append(wind_info)
            
            if location_winds:
                decoded['location_winds'] = location_winds
            
            return remarks, decoded
        else:
            # Return default values when no remarks are found
            return "", {}
    
    def _decode_complex_weather_code(self, code: str) -> str:
        """Decode a complex weather code like '-TSRA' or '+SHRASN'"""
        result = []
        original_code = code
        
        # Check for intensity prefix and recent indicator
        if code.startswith('+') or code.startswith('-') or code.startswith('VC') or code.startswith('RE'):
            if code.startswith('+'):
                result.append(self.WEATHER_INTENSITY.get('+', 'heavy'))
                code = code[1:]
            elif code.startswith('-'):
                result.append(self.WEATHER_INTENSITY.get('-', 'light'))
                code = code[1:]
            elif code.startswith('VC'):
                result.append(self.WEATHER_INTENSITY.get('VC', 'vicinity'))
                code = code[2:]
            elif code.startswith('RE'):
                result.append(self.WEATHER_INTENSITY.get('RE', 'recent'))
                code = code[2:]
        
        # Extract descriptors (SH, TS, FZ, etc.)
        for desc_code, desc_value in self.WEATHER_DESCRIPTORS.items():
            if code.startswith(desc_code):
                result.append(desc_value)
                code = code[len(desc_code):]
                break
        
        # Handle special case: '+FC' (tornado/waterspout)
        if original_code == '+FC':
            return 'tornado/waterspout'
        
        # Extract weather phenomena 
        phenomena = []
        remaining = code
        while remaining and len(remaining) >= 2:
            prefix = remaining[:2]
            if prefix in self.WEATHER_PHENOMENA:
                phenomena.append(self.WEATHER_PHENOMENA[prefix])
                remaining = remaining[2:]
            else:
                break
        
        if phenomena:
            result.append(', '.join(phenomena))
        
        # Special case combinations that need more explicit descriptions
        combined = ' '.join(result)
        
        # Enhance freezing combinations
        if 'freezing' in combined:
            if 'drizzle' in combined:
                combined = combined.replace('freezing drizzle', 'freezing drizzle (FZDZ)')
            elif 'rain' in combined:
                combined = combined.replace('freezing rain', 'freezing rain (FZRA)')
            elif 'fog' in combined:
                combined = combined.replace('freezing fog', 'freezing fog (FZFG)')
                
        # Enhance thunderstorm combinations
        if 'thunderstorm' in combined and any(p in combined for p in ['rain', 'snow', 'drizzle', 'hail']):
            # Add the code in parentheses for clarity
            for search, code_suffix in [
                ('thunderstorm rain', 'TSRA'), 
                ('thunderstorm snow', 'TSSN'),
                ('thunderstorm drizzle', 'TSDZ'),
                ('thunderstorm hail', 'TSGR')
            ]:
                if search in combined:
                    combined = combined.replace(search, f"{search} ({code_suffix})")
                    
        # Enhance shower combinations
        if 'shower' in combined and any(p in combined for p in ['rain', 'snow', 'drizzle', 'hail']):
            # Add the code in parentheses for clarity
            for search, code_suffix in [
                ('shower rain', 'SHRA'), 
                ('shower snow', 'SHSN'),
                ('shower drizzle', 'SHDZ'),
                ('shower hail', 'SHGR')
            ]:
                if search in combined:
                    combined = combined.replace(search, f"{search} ({code_suffix})")
                    
        # Enhance drifting/blowing combinations
        if any(d in combined for d in ['low drifting', 'blowing']):
            for search, code_suffix in [
                ('low drifting sand', 'DRSA'),
                ('low drifting snow', 'DRSN'),
                ('low drifting dust', 'DRDU'),
                ('blowing sand', 'BLSA'),
                ('blowing snow', 'BLSN'),
                ('blowing dust', 'BLDU')
            ]:
                if search in combined:
                    combined = combined.replace(search, f"{search} ({code_suffix})")
                
        return combined
    
    def _decode_military_color_codes(self, parts: List[str]) -> List[Dict]:
        """Extract military color codes from the METAR"""
        color_codes = []
        military_code_pattern = re.compile(r'^(BLU|WHT|GRN|YLO|AMB|RED)$')
        
        i = 0
        while i < len(parts):
            match = military_code_pattern.match(parts[i])
            if match:
                code = match.group(1)
                description = self.MILITARY_COLOR_CODES.get(code, '')
                
                # Add to the color codes list
                color_codes.append({
                    'code': code,
                    'description': description
                })
                
                # Remove the processed part
                parts.pop(i)
            else:
                i += 1
                
        return color_codes
    
    def _get_cardinal_direction(self, dir_code: str) -> str:
        """Convert cardinal direction code to full name"""
        directions = {
            'N': 'north', 'NE': 'northeast', 'E': 'east', 'SE': 'southeast',
            'S': 'south', 'SW': 'southwest', 'W': 'west', 'NW': 'northwest'
        }
        return directions.get(dir_code, dir_code)


def main():
    """Main function to run the METAR decoder from command line"""
    parser = argparse.ArgumentParser(description='METAR Decoder - Parse and decode METAR weather reports')
    parser.add_argument('metar', nargs='?', help='Raw METAR string to decode')
    parser.add_argument('-f', '--file', help='File containing METAR strings (one per line)')
    
    args = parser.parse_args()
    
    decoder = MetarDecoder()
    
    if args.file:
        try:
            with open(args.file, 'r') as f:
                for line in f:
                    metar = line.strip()
                    if metar:
                        decoded = decoder.decode(metar)
                        print(f"\n{'='*50}")
                        print(decoded)
        except FileNotFoundError:
            print(f"Error: File {args.file} not found.")
    elif args.metar:
        decoded = decoder.decode(args.metar)
        print(decoded)
    else:
        # Interactive mode
        print("METAR Decoder - Enter a METAR string to decode (press Ctrl+C to exit):")
        try:
            while True:
                metar = input("> ")
                if metar:
                    decoded = decoder.decode(metar)
                    print(decoded)
                    print()
        except KeyboardInterrupt:
            print("\nExiting...")


if __name__ == "__main__":
    main() 