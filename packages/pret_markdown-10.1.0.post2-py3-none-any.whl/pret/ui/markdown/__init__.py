"""
Backward compatibility shim for the previous `pret.ui.markdown` import path.
"""
from pret_markdown import *  # noqa: F401,F403
