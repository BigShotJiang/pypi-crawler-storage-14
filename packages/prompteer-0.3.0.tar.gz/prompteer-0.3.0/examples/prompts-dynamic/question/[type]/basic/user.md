---
description: Basic user query
name: User name
---
Hello {name}, this is a basic question. How can I help you today?