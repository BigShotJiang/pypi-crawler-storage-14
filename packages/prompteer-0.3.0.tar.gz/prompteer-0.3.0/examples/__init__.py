"""Examples package for prompteer."""
