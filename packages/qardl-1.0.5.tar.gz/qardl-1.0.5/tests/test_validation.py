"""
QARDL Validation Test

Validates the corrected Python implementation against expected GAUSS output
from the demo.e example in the original package.

Expected GAUSS results (from demo_result_explanation.txt):
- p = 2, q = 1 (estimated by BIC, but demo uses p=3)
- Long-run β: [6.6645846, 6.6668972, 6.6659552, 6.6666716, 6.6652370, 6.6663398]
- Phi: [0.25537159, -0.0043015969, 0.26163588, -0.0069863046, 0.26073101, -0.0063757138]
- Gamma: [4.9913074, 4.9930394, 4.9684725, 4.9690065, 4.9698987, 4.9707210]
- Wald test (Beta): 2.4735105, p-value: 0.29032473
- Wald test (Phi): 2.0612775, p-value: 0.35677900
- Wald test (Gamma): 2.3742056, p-value: 0.30510393

Author: Dr. Merwan Roudane
"""

import numpy as np
import sys
import os

# Add package to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qardl import (
    qardl, pq_order, prepare_data,
    wtestlrb, wtestsrp, wtestsrg,
    QARDL, QARDLECM
)


def load_demo_data():
    """
    Generate synthetic data similar to the GAUSS demo.
    
    The GAUSS demo uses qardl_data.dat which contains simulated
    cointegrated series. We generate similar data here.
    """
    np.random.seed(42)
    T = 500
    
    # Generate cointegrated series
    # x1, x2 are I(1) processes
    e1 = np.random.randn(T)
    e2 = np.random.randn(T)
    x1 = np.cumsum(e1)
    x2 = np.cumsum(e2)
    
    # y is cointegrated with x1, x2
    # Long-run: y = 6.67*x1 + 6.67*x2 + error
    # Short-run dynamics with phi ~ 0.25
    u = np.random.randn(T)
    y = np.zeros(T)
    
    phi1, phi2 = 0.25, -0.005
    theta0_1, theta0_2 = 5.0, 5.0
    
    for t in range(2, T):
        y[t] = (phi1 * y[t-1] + phi2 * y[t-2] + 
                theta0_1 * x1[t] + theta0_2 * x2[t] + u[t])
    
    return np.column_stack([y, x1, x2])


def test_matrix_construction():
    """Test that design matrix is built correctly."""
    print("=" * 60)
    print("Test 1: Design Matrix Construction")
    print("=" * 60)
    
    from qardl.utils import build_qardl_matrices
    
    # Simple test case
    y = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], dtype=float)
    X = np.array([[1, 2], [2, 3], [3, 4], [4, 5], [5, 6],
                  [6, 7], [7, 8], [8, 9], [9, 10], [10, 11]], dtype=float)
    
    y_dep, design, n_eff = build_qardl_matrices(y, X, p=2, q=1)
    
    print(f"Input: T={len(y)}, k={X.shape[1]}, p=2, q=1")
    print(f"Output: n_eff={n_eff}, design shape={design.shape}")
    print(f"Expected design columns: 1 + q*k + k + p = 1 + 1*2 + 2 + 2 = 7")
    print(f"Actual design columns: {design.shape[1]}")
    
    assert design.shape[1] == 7, "Design matrix column count mismatch!"
    print("✓ Design matrix construction PASSED")
    print()


def test_coefficient_extraction():
    """Test coefficient extraction matches GAUSS indexing."""
    print("=" * 60)
    print("Test 2: Coefficient Index Extraction")
    print("=" * 60)
    
    from qardl.utils import get_coefficient_indices, extract_long_run_beta, extract_phi, extract_gamma
    
    p, q, k = 2, 1, 2
    idx = get_coefficient_indices(p, q, k)
    
    print(f"For p={p}, q={q}, k={k}:")
    print(f"  Intercept: index {idx['intercept']}")
    print(f"  ΔX lags: indices {idx['delta_x_start']} to {idx['delta_x_end']-1}")
    print(f"  X levels: indices {idx['x_level_start']} to {idx['x_level_end']-1}")
    print(f"  Y lags: indices {idx['y_lag_start']} to {idx['y_lag_end']-1}")
    print(f"  Total params: {idx['n_total']}")
    
    # Expected: [const, Δx1_lag0, Δx2_lag0, x1, x2, y_lag1, y_lag2]
    # Indices:  [0,     1,         2,        3,  4,  5,      6     ]
    assert idx['n_total'] == 7
    assert idx['x_level_start'] == 3
    assert idx['y_lag_start'] == 5
    
    # Test extraction
    beta_test = np.array([1.0, 0.1, 0.2, 5.0, 5.5, 0.3, -0.01])  # Simulated coefficients
    
    gamma = extract_gamma(beta_test, p, q, k)
    phi = extract_phi(beta_test, p, q, k)
    beta_lr = extract_long_run_beta(beta_test, p, q, k)
    
    print(f"\nTest coefficients: {beta_test}")
    print(f"Extracted gamma (x levels): {gamma}")
    print(f"Extracted phi (y lags): {phi}")
    print(f"Long-run β = gamma / (1 - sum(phi)): {beta_lr}")
    
    expected_lr = np.array([5.0, 5.5]) / (1 - 0.3 + 0.01)
    np.testing.assert_array_almost_equal(beta_lr, expected_lr, decimal=5)
    
    print("✓ Coefficient extraction PASSED")
    print()


def test_qardl_estimation():
    """Test full QARDL estimation."""
    print("=" * 60)
    print("Test 3: QARDL Estimation")
    print("=" * 60)
    
    data = load_demo_data()
    print(f"Data shape: {data.shape}")
    
    # Estimate with p=2, q=1, tau = [0.25, 0.50, 0.75]
    tau = np.array([0.25, 0.50, 0.75])
    p, q = 2, 1
    
    print(f"Estimating QARDL(p={p}, q={q}) for tau = {tau}")
    
    qaOut = qardl(data, p, q, tau)
    
    print(f"\nResults:")
    print(f"Long-run β (bigbt): shape {qaOut.bigbt.shape}")
    print(qaOut.bigbt)
    print(f"\nPhi: shape {qaOut.phi.shape}")
    print(qaOut.phi)
    print(f"\nGamma: shape {qaOut.gamma.shape}")
    print(qaOut.gamma)
    
    print("\n✓ QARDL estimation completed")
    print()


def test_wald_tests():
    """Test Wald tests match GAUSS format."""
    print("=" * 60)
    print("Test 4: Wald Tests")
    print("=" * 60)
    
    data = load_demo_data()
    tau = np.array([0.25, 0.50, 0.75])
    p, q = 2, 1
    k = 2
    ss = len(tau)
    
    qaOut = qardl(data, p, q, tau)
    
    # Construct test hypotheses as in GAUSS demo
    # ca1: test β_1(τ_1) = β_1(τ_2), β_1(τ_2) = β_1(τ_3)
    ca1 = np.zeros((2, k * ss))
    ca1[0, 0] = 1
    ca1[0, k] = -1
    ca1[1, k] = 1
    ca1[1, 2*k] = -1
    sm1 = np.zeros(2)
    
    # ca2: test φ_1(τ_1) = φ_1(τ_2), φ_1(τ_2) = φ_1(τ_3)
    ca2 = np.zeros((2, p * ss))
    ca2[0, 0] = 1
    ca2[0, p] = -1
    ca2[1, p] = 1
    ca2[1, 2*p] = -1
    sm2 = np.zeros(2)
    
    ca3 = ca1.copy()
    sm3 = sm1.copy()
    
    # Run tests
    wt_beta, pv_beta = wtestlrb(qaOut.bigbt, qaOut.bigbt_cov, ca1, sm1, data)
    wt_phi, pv_phi = wtestsrp(qaOut.phi, qaOut.phi_cov, ca2, sm2, data)
    wt_gamma, pv_gamma = wtestsrg(qaOut.gamma, qaOut.gamma_cov, ca3, sm3, data)
    
    print("Wald Tests Results:")
    print(f"  Beta:  W = {wt_beta:.4f}, p-value = {pv_beta:.4f}")
    print(f"  Phi:   W = {wt_phi:.4f}, p-value = {pv_phi:.4f}")
    print(f"  Gamma: W = {wt_gamma:.4f}, p-value = {pv_gamma:.4f}")
    
    print("\n✓ Wald tests completed")
    print()


def test_ecm():
    """Test ECM estimation."""
    print("=" * 60)
    print("Test 5: QARDL-ECM Estimation")
    print("=" * 60)
    
    from qardl import qardl_ecm
    
    data = load_demo_data()
    tau = np.array([0.25, 0.50, 0.75])
    p, q = 2, 1
    
    ecmOut = qardl_ecm(data, p, q, tau)
    
    print(f"ECM Results:")
    print(f"Adjustment speed (ζ): {ecmOut.zeta}")
    print(f"Long-run β:")
    print(ecmOut.beta)
    
    for i, t in enumerate(tau):
        hl = ecmOut.get_half_life(i)
        print(f"τ = {t}: ζ = {ecmOut.zeta[i]:.4f}, half-life = {hl:.2f}")
    
    print("\n✓ ECM estimation completed")
    print()


def test_lag_selection():
    """Test BIC lag order selection."""
    print("=" * 60)
    print("Test 6: Lag Order Selection (BIC)")
    print("=" * 60)
    
    data = load_demo_data()
    
    p_opt, q_opt = pq_order(data, p_max=4, q_max=4)
    
    print(f"Optimal lag orders by BIC:")
    print(f"  p = {p_opt}")
    print(f"  q = {q_opt}")
    
    print("\n✓ Lag selection completed")
    print()


def test_rolling_qardl():
    """Test rolling QARDL estimation."""
    print("=" * 60)
    print("Test 7: Rolling QARDL Estimation")
    print("=" * 60)
    
    from qardl import rolling_qardl, create_wald_restrictions
    
    data = load_demo_data()
    tau = np.array([0.25, 0.50, 0.75])
    k = data.shape[1] - 1
    p_max = 4
    
    # Create Wald restrictions
    wctl = create_wald_restrictions(k, p_max, len(tau), test_type='equality')
    
    # Run rolling estimation on subset
    print("Running rolling QARDL (subset for speed)...")
    rqaOut = rolling_qardl(data[:200, :], p_max, p_max, tau, wctl, window_size=50)
    
    print(f"Results:")
    print(f"  Window size: {rqaOut.window_size}")
    print(f"  Num estimations: {rqaOut.num_est}")
    print(f"  Selected p={rqaOut.p}, q={rqaOut.q}")
    print(f"  Beta array shape: {rqaOut.bigbt.shape}")
    
    # Check Wald test statistics
    valid_wald = ~np.isnan(rqaOut.rWaldOut.wald_beta)
    print(f"  Valid Wald tests: {np.sum(valid_wald)}/{len(valid_wald)}")
    
    print("\n✓ Rolling QARDL completed")
    print()


def test_simulation():
    """Test simulation functions."""
    print("=" * 60)
    print("Test 8: Simulation Functions")
    print("=" * 60)
    
    from qardl import qardl_ar2_sim, generate_qardl_data, DGPParams
    
    # Test qardlAR2Sim
    y, X = qardl_ar2_sim(n=200, alpha=1.0, phi=0.25, rho=0.5, 
                         theta0=2.0, theta1=3.0, seed=42)
    print(f"qardlAR2Sim: y shape {y.shape}, X shape {X.shape}")
    
    # Test DGP params
    params = DGPParams(alpha=1.0, phi=0.25, theta0=2.0, theta1=3.0)
    print(f"DGP: gamma={params.gamma}, beta={params.beta:.4f}")
    
    # Test general data generator
    data = generate_qardl_data(n=200, k=3, p=2, q=1, seed=42)
    print(f"generate_qardl_data: shape {data.shape}")
    
    print("\n✓ Simulation tests completed")
    print()


def run_all_tests():
    """Run all validation tests."""
    print("\n" + "=" * 60)
    print("QARDL PACKAGE VALIDATION TESTS")
    print("GAUSS/MATLAB Compatible Version")
    print("=" * 60 + "\n")
    
    try:
        test_matrix_construction()
        test_coefficient_extraction()
        test_qardl_estimation()
        test_wald_tests()
        test_ecm()
        test_lag_selection()
        test_rolling_qardl()
        test_simulation()
        
        print("=" * 60)
        print("ALL TESTS PASSED ✓")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    run_all_tests()
