"""
Rolling QARDL Estimation - GAUSS Compatible

Exact implementation of rollingQardl from GAUSS qardl.src (lines 479-573)

Features:
- Rolling window estimation
- Automatic p,q selection via BIC on full sample
- Window size = 10% of sample (GAUSS default)
- Wald tests at each window
- Standard errors extraction

Output structure matches GAUSS rollingQardlOut:
- bigbt: 3D array (k x num_est x num_tau)
- bigbt_se: 3D array of standard errors
- phi, phi_se: 3D arrays for AR parameters
- gamma, gamma_se: 3D arrays for impact parameters
- rWaldOut: Wald test results for each window

Author: Dr. Merwan Roudane
"""

import numpy as np
from typing import Optional, Dict, Tuple
from dataclasses import dataclass
import warnings

from .core import qardl, QARDLOut
from .utils import pq_order
from .testing import wtestlrb, wtestsrp, wtestsrg


@dataclass
class WaldTestRestrictions:
    """
    Structure for Wald test restrictions - matches GAUSS waldTestRestrictions.
    
    Attributes
    ----------
    bigR_beta : np.ndarray
        Restriction matrix for beta (n_restrictions x k*num_tau)
    smlr_beta : np.ndarray
        Restriction values for beta
    bigR_phi : np.ndarray
        Restriction matrix for phi (n_restrictions x p_max*num_tau)
    smlr_phi : np.ndarray
        Restriction values for phi
    bigR_gamma : np.ndarray
        Restriction matrix for gamma (n_restrictions x k*num_tau)
    smlr_gamma : np.ndarray
        Restriction values for gamma
    """
    bigR_beta: np.ndarray
    smlr_beta: np.ndarray
    bigR_phi: np.ndarray
    smlr_phi: np.ndarray
    bigR_gamma: np.ndarray
    smlr_gamma: np.ndarray


@dataclass
class RollingWaldTests:
    """
    Rolling Wald test results - matches GAUSS rollingWaldTests.
    
    Attributes
    ----------
    wald_beta : np.ndarray
        Wald statistics for beta at each window (num_est x 1)
    pv_beta : np.ndarray
        P-values for beta Wald tests
    wald_phi : np.ndarray
        Wald statistics for phi
    pv_phi : np.ndarray
        P-values for phi Wald tests
    wald_gamma : np.ndarray
        Wald statistics for gamma
    pv_gamma : np.ndarray
        P-values for gamma Wald tests
    """
    wald_beta: np.ndarray
    pv_beta: np.ndarray
    wald_phi: np.ndarray
    pv_phi: np.ndarray
    wald_gamma: np.ndarray
    pv_gamma: np.ndarray


class RollingQARDLOut:
    """
    Rolling QARDL Output Structure - matches GAUSS rollingQardlOut.
    
    All estimate arrays are 3D: (n_vars x num_est x num_tau)
    
    Attributes
    ----------
    bigbt : np.ndarray
        Beta estimates array (k x num_est x num_tau)
    bigbt_se : np.ndarray
        Beta standard errors
    phi : np.ndarray
        Phi estimates array (p x num_est x num_tau)
    phi_se : np.ndarray
        Phi standard errors
    gamma : np.ndarray
        Gamma estimates array (k x num_est x num_tau)
    gamma_se : np.ndarray
        Gamma standard errors
    rWaldOut : RollingWaldTests
        Wald test results
    p : int
        Selected AR order
    q : int
        Selected DL order
    k : int
        Number of X variables
    tau : np.ndarray
        Quantile levels
    window_size : int
        Rolling window size
    num_est : int
        Number of estimations
    """
    
    def __init__(self):
        self.bigbt = None
        self.bigbt_se = None
        self.phi = None
        self.phi_se = None
        self.gamma = None
        self.gamma_se = None
        self.rWaldOut = None
        self.p = None
        self.q = None
        self.k = None
        self.tau = None
        self.window_size = None
        self.num_est = None
    
    def get_beta(self, var_idx: int, tau_idx: int) -> np.ndarray:
        """
        Get beta estimates for specific variable and quantile.
        
        Parameters
        ----------
        var_idx : int
            Variable index (0 to k-1)
        tau_idx : int
            Quantile index (0 to num_tau-1)
            
        Returns
        -------
        np.ndarray
            Beta estimates across all windows (num_est x 1)
        """
        return self.bigbt[var_idx, :, tau_idx]
    
    def get_phi(self, lag_idx: int, tau_idx: int) -> np.ndarray:
        """Get phi estimates for specific lag and quantile."""
        return self.phi[lag_idx, :, tau_idx]
    
    def get_gamma(self, var_idx: int, tau_idx: int) -> np.ndarray:
        """Get gamma estimates for specific variable and quantile."""
        return self.gamma[var_idx, :, tau_idx]
    
    def summary(self) -> str:
        """Generate summary of rolling estimation."""
        lines = []
        lines.append("=" * 60)
        lines.append("Rolling QARDL Estimation Results")
        lines.append("=" * 60)
        lines.append(f"Window size: {self.window_size}")
        lines.append(f"Number of estimations: {self.num_est}")
        lines.append(f"AR order (p): {self.p}")
        lines.append(f"DL order (q): {self.q}")
        lines.append(f"Number of X variables (k): {self.k}")
        lines.append(f"Quantiles: {self.tau}")
        lines.append("")
        
        # Summary statistics for beta
        lines.append("-" * 60)
        lines.append("Beta Summary Statistics")
        lines.append("-" * 60)
        for i in range(self.k):
            for j, tau in enumerate(self.tau):
                beta_vals = self.get_beta(i, j)
                lines.append(f"β_{i+1}(τ={tau:.2f}): mean={np.mean(beta_vals):.4f}, "
                           f"std={np.std(beta_vals):.4f}")
        
        lines.append("")
        lines.append("-" * 60)
        lines.append("Wald Test Summary")
        lines.append("-" * 60)
        lines.append(f"Beta Wald: mean={np.mean(self.rWaldOut.wald_beta):.4f}, "
                    f"% sig (5%)={100*np.mean(self.rWaldOut.pv_beta < 0.05):.1f}%")
        lines.append(f"Phi Wald:  mean={np.mean(self.rWaldOut.wald_phi):.4f}, "
                    f"% sig (5%)={100*np.mean(self.rWaldOut.pv_phi < 0.05):.1f}%")
        lines.append(f"Gamma Wald: mean={np.mean(self.rWaldOut.wald_gamma):.4f}, "
                    f"% sig (5%)={100*np.mean(self.rWaldOut.pv_gamma < 0.05):.1f}%")
        
        lines.append("=" * 60)
        return "\n".join(lines)


def _get_beta_array(bigbt: np.ndarray, num_tau: int, k: int) -> np.ndarray:
    """
    Reshape beta vector to array - GAUSS _getBetaArray.
    
    GAUSS (lines 629-641):
    beta_mat = reshape(_beta, num_tau, k);
    beta_array[i, ., .] = beta_mat[., i]';
    
    Parameters
    ----------
    bigbt : np.ndarray
        Stacked beta vector (k*num_tau x 1)
    num_tau : int
        Number of quantiles
    k : int
        Number of X variables
        
    Returns
    -------
    np.ndarray
        Beta array (k x 1 x num_tau)
    """
    # Reshape: bigbt is stacked by quantile first
    beta_mat = bigbt.reshape(num_tau, k)  # (num_tau x k)
    
    # Create array (k x 1 x num_tau)
    beta_array = np.zeros((k, 1, num_tau))
    for i in range(k):
        beta_array[i, 0, :] = beta_mat[:, i]
    
    return beta_array


def _get_gamma_array(gamma: np.ndarray, num_tau: int, k: int) -> np.ndarray:
    """Reshape gamma vector to array - same as _getBetaArray."""
    gamma_mat = gamma.reshape(num_tau, k)
    gamma_array = np.zeros((k, 1, num_tau))
    for i in range(k):
        gamma_array[i, 0, :] = gamma_mat[:, i]
    return gamma_array


def _get_phi_array(phi: np.ndarray, num_tau: int, p: int) -> np.ndarray:
    """Reshape phi vector to array - GAUSS _getPhiArray."""
    phi_mat = phi.reshape(num_tau, p)
    phi_array = np.zeros((p, 1, num_tau))
    for i in range(p):
        phi_array[i, 0, :] = phi_mat[:, i]
    return phi_array


def _get_beta_se(bigbt_cov: np.ndarray, num_tau: int, k: int) -> np.ndarray:
    """
    Extract beta standard errors - GAUSS _getBetaSE.
    
    GAUSS (lines 575-591):
    beta_se = sqrt(diag(_beta_cov));
    beta_se = reshape(beta_se, num_tau, k);
    """
    beta_se = np.sqrt(np.maximum(np.diag(bigbt_cov), 0))
    beta_se_mat = beta_se.reshape(num_tau, k)
    
    beta_se_array = np.zeros((k, 1, num_tau))
    for i in range(k):
        beta_se_array[i, 0, :] = beta_se_mat[:, i]
    
    return beta_se_array


def _get_gamma_se(gamma_cov: np.ndarray, num_tau: int, k: int) -> np.ndarray:
    """Extract gamma standard errors."""
    gamma_se = np.sqrt(np.maximum(np.diag(gamma_cov), 0))
    gamma_se_mat = gamma_se.reshape(num_tau, k)
    
    gamma_se_array = np.zeros((k, 1, num_tau))
    for i in range(k):
        gamma_se_array[i, 0, :] = gamma_se_mat[:, i]
    
    return gamma_se_array


def _get_phi_se(phi_cov: np.ndarray, num_tau: int, p: int) -> np.ndarray:
    """Extract phi standard errors."""
    phi_se = np.sqrt(np.maximum(np.diag(phi_cov), 0))
    phi_se_mat = phi_se.reshape(num_tau, p)
    
    phi_se_array = np.zeros((p, 1, num_tau))
    for i in range(p):
        phi_se_array[i, 0, :] = phi_se_mat[:, i]
    
    return phi_se_array


def rolling_qardl(
    data: np.ndarray,
    p_max: int,
    q_max: int,
    tau: np.ndarray,
    wctl: WaldTestRestrictions,
    window_size: Optional[int] = None,
    p_fixed: Optional[int] = None,
    q_fixed: Optional[int] = None
) -> RollingQARDLOut:
    """
    Rolling QARDL Estimation - EXACT GAUSS rollingQardl.
    
    Performs rolling window QARDL estimation with Wald tests at each window.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix (T x (1+k)) with y in first column
    p_max : int
        Maximum AR order for BIC selection
    q_max : int
        Maximum DL order for BIC selection
    tau : np.ndarray
        Quantile levels
    wctl : WaldTestRestrictions
        Wald test restriction matrices
    window_size : int, optional
        Rolling window size. Default is 10% of sample (GAUSS default).
    p_fixed : int, optional
        Fixed p order. If None, selected by BIC.
    q_fixed : int, optional
        Fixed q order. If None, selected by BIC.
        
    Returns
    -------
    RollingQARDLOut
        Rolling estimation results
        
    Notes
    -----
    GAUSS implementation (lines 479-573):
    - Selects p,q using BIC on full sample
    - Window size = trunc(0.1*rows(data))
    - Rolling: starts at observation 1, ends at window_size, then increments
    """
    tau = np.sort(np.asarray(tau).flatten())
    num_tau = len(tau)
    
    T = len(data)
    k = data.shape[1] - 1
    
    # Select p, q using BIC on full sample (GAUSS line 486)
    if p_fixed is not None and q_fixed is not None:
        pst, qst = p_fixed, q_fixed
    else:
        pst, qst = pq_order(data, p_max, q_max)
    
    # Window size: 10% of sample by default (GAUSS line 489)
    if window_size is None:
        window_size = int(0.1 * T)
    
    # Number of estimations
    num_est = T - window_size
    
    if num_est <= 0:
        raise ValueError(f"Window size {window_size} too large for sample size {T}")
    
    # Initialize storage arrays (GAUSS lines 502-508)
    # Arrays are (n_vars x num_est x num_tau)
    beta_array = np.zeros((k, num_est, num_tau))
    gamma_array = np.zeros((k, num_est, num_tau))
    phi_array = np.zeros((pst, num_est, num_tau))
    
    beta_se = np.zeros((k, num_est, num_tau))
    gamma_se = np.zeros((k, num_est, num_tau))
    phi_se = np.zeros((pst, num_est, num_tau))
    
    # Wald test storage (GAUSS lines 511-516)
    wald_beta = np.zeros(num_est)
    wald_phi = np.zeros(num_est)
    wald_gamma = np.zeros(num_est)
    pv_beta = np.zeros(num_est)
    pv_phi = np.zeros(num_est)
    pv_gamma = np.zeros(num_est)
    
    # Rolling estimation (GAUSS lines 518-553)
    st = 0  # Starting index (0-indexed)
    fin_obs = window_size
    
    while fin_obs <= T and st < num_est:
        # Get data subset (GAUSS line 521)
        data_subset = data[st:fin_obs, :]
        
        # Parameter estimation (GAUSS lines 524-525)
        try:
            qaOut = qardl(data_subset, pst, qst, tau)
            
            # Wald tests (GAUSS lines 527-539)
            try:
                wt_b, pv_b = wtestlrb(qaOut.bigbt, qaOut.bigbt_cov, 
                                       wctl.bigR_beta, wctl.smlr_beta, data_subset)
            except:
                wt_b, pv_b = np.nan, np.nan
            
            # Adjust phi restriction matrix if pst < p_max
            bigR_phi_test = wctl.bigR_phi
            if pst < p_max:
                # GAUSS lines 532-535: delete columns for unused lags
                cols_to_keep = pst * num_tau
                if bigR_phi_test.shape[1] > cols_to_keep:
                    bigR_phi_test = bigR_phi_test[:, :cols_to_keep]
            
            try:
                wt_p, pv_p = wtestsrp(qaOut.phi, qaOut.phi_cov,
                                       bigR_phi_test, wctl.smlr_phi, data_subset)
            except:
                wt_p, pv_p = np.nan, np.nan
            
            try:
                wt_g, pv_g = wtestsrg(qaOut.gamma, qaOut.gamma_cov,
                                       wctl.bigR_gamma, wctl.smlr_gamma, data_subset)
            except:
                wt_g, pv_g = np.nan, np.nan
            
            wald_beta[st] = wt_b
            pv_beta[st] = pv_b
            wald_phi[st] = wt_p
            pv_phi[st] = pv_p
            wald_gamma[st] = wt_g
            pv_gamma[st] = pv_g
            
            # Extract estimates (GAUSS lines 542-544)
            b_arr = _get_beta_array(qaOut.bigbt, num_tau, k)
            g_arr = _get_gamma_array(qaOut.gamma, num_tau, k)
            p_arr = _get_phi_array(qaOut.phi, num_tau, pst)
            
            beta_array[:, st, :] = b_arr[:, 0, :]
            gamma_array[:, st, :] = g_arr[:, 0, :]
            phi_array[:, st, :] = p_arr[:, 0, :]
            
            # Standard errors (GAUSS lines 547-549)
            b_se = _get_beta_se(qaOut.bigbt_cov, num_tau, k)
            g_se = _get_gamma_se(qaOut.gamma_cov, num_tau, k)
            p_se = _get_phi_se(qaOut.phi_cov, num_tau, pst)
            
            beta_se[:, st, :] = b_se[:, 0, :]
            gamma_se[:, st, :] = g_se[:, 0, :]
            phi_se[:, st, :] = p_se[:, 0, :]
            
        except Exception as e:
            warnings.warn(f"Estimation failed at window {st}: {e}")
            # Fill with NaN
            beta_array[:, st, :] = np.nan
            gamma_array[:, st, :] = np.nan
            phi_array[:, st, :] = np.nan
            beta_se[:, st, :] = np.nan
            gamma_se[:, st, :] = np.nan
            phi_se[:, st, :] = np.nan
            wald_beta[st] = np.nan
            pv_beta[st] = np.nan
            wald_phi[st] = np.nan
            pv_phi[st] = np.nan
            wald_gamma[st] = np.nan
            pv_gamma[st] = np.nan
        
        st += 1
        fin_obs += 1
    
    # Build output structure (GAUSS lines 556-571)
    rqaOut = RollingQARDLOut()
    rqaOut.bigbt = beta_array
    rqaOut.bigbt_se = beta_se
    rqaOut.phi = phi_array
    rqaOut.phi_se = phi_se
    rqaOut.gamma = gamma_array
    rqaOut.gamma_se = gamma_se
    
    rqaOut.rWaldOut = RollingWaldTests(
        wald_beta=wald_beta,
        pv_beta=pv_beta,
        wald_phi=wald_phi,
        pv_phi=pv_phi,
        wald_gamma=wald_gamma,
        pv_gamma=pv_gamma
    )
    
    rqaOut.p = pst
    rqaOut.q = qst
    rqaOut.k = k
    rqaOut.tau = tau
    rqaOut.window_size = window_size
    rqaOut.num_est = num_est
    
    return rqaOut


def create_wald_restrictions(
    k: int,
    p_max: int,
    num_tau: int,
    test_type: str = "equality"
) -> WaldTestRestrictions:
    """
    Create default Wald test restriction matrices.
    
    Parameters
    ----------
    k : int
        Number of X variables
    p_max : int
        Maximum AR order
    num_tau : int
        Number of quantiles
    test_type : str
        Type of test:
        - "equality": Test adjacent quantile equality
        - "zero": Test if parameters are zero
        
    Returns
    -------
    WaldTestRestrictions
        Restriction matrices
    """
    if test_type == "equality" and num_tau >= 2:
        # Test β₁(τᵢ) = β₁(τᵢ₊₁) for adjacent quantiles
        n_restrictions = num_tau - 1
        
        bigR_beta = np.zeros((n_restrictions, k * num_tau))
        for i in range(n_restrictions):
            bigR_beta[i, i * k] = 1
            bigR_beta[i, (i + 1) * k] = -1
        smlr_beta = np.zeros(n_restrictions)
        
        bigR_phi = np.zeros((n_restrictions, p_max * num_tau))
        for i in range(n_restrictions):
            bigR_phi[i, i * p_max] = 1
            bigR_phi[i, (i + 1) * p_max] = -1
        smlr_phi = np.zeros(n_restrictions)
        
        bigR_gamma = np.zeros((n_restrictions, k * num_tau))
        for i in range(n_restrictions):
            bigR_gamma[i, i * k] = 1
            bigR_gamma[i, (i + 1) * k] = -1
        smlr_gamma = np.zeros(n_restrictions)
        
    else:  # test_type == "zero"
        # Test if first parameter is zero
        bigR_beta = np.zeros((1, k * num_tau))
        bigR_beta[0, 0] = 1
        smlr_beta = np.zeros(1)
        
        bigR_phi = np.zeros((1, p_max * num_tau))
        bigR_phi[0, 0] = 1
        smlr_phi = np.zeros(1)
        
        bigR_gamma = np.zeros((1, k * num_tau))
        bigR_gamma[0, 0] = 1
        smlr_gamma = np.zeros(1)
    
    return WaldTestRestrictions(
        bigR_beta=bigR_beta,
        smlr_beta=smlr_beta,
        bigR_phi=bigR_phi,
        smlr_phi=smlr_phi,
        bigR_gamma=bigR_gamma,
        smlr_gamma=smlr_gamma
    )


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'WaldTestRestrictions',
    'RollingWaldTests',
    'RollingQARDLOut',
    'rolling_qardl',
    'create_wald_restrictions',
]
