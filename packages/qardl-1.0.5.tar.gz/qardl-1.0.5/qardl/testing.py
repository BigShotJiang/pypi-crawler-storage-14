"""
QARDL Hypothesis Testing - GAUSS/MATLAB Compatible

Exact implementation of Wald tests from:
- wtestlrb.src (long-run beta)
- wtestsrp.src (short-run phi)  
- wtestsrg.src (short-run gamma)

Key formulas:
- Long-run: W = (n-1)² * (R*β - r)' * inv(R*Σ*R') * (R*β - r)
- Short-run: W = (n-1) * (R*θ - r)' * inv(R*Σ*R') * (R*θ - r)

Author: Dr. Merwan Roudane
"""

import numpy as np
from scipy import stats
from typing import Tuple, Optional
import warnings


class WaldTestResult:
    """Wald test result container."""
    
    def __init__(self, statistic: float, pvalue: float, df: int, hypothesis: str = ""):
        self.statistic = statistic
        self.pvalue = pvalue
        self.df = df
        self.hypothesis = hypothesis
    
    def __repr__(self):
        return f"WaldTestResult(W={self.statistic:.4f}, p={self.pvalue:.4f}, df={self.df})"
    
    def summary(self) -> str:
        lines = [
            "=" * 60,
            "Wald Test Results",
            "=" * 60,
            f"Null hypothesis: {self.hypothesis}",
            f"Test statistic:  {self.statistic:.6f}",
            f"Degrees of freedom: {self.df}",
            f"P-value:         {self.pvalue:.6f}",
        ]
        if self.pvalue < 0.01:
            lines.append("Conclusion: Reject H0 at 1% level ***")
        elif self.pvalue < 0.05:
            lines.append("Conclusion: Reject H0 at 5% level **")
        elif self.pvalue < 0.10:
            lines.append("Conclusion: Reject H0 at 10% level *")
        else:
            lines.append("Conclusion: Fail to reject H0")
        lines.append("=" * 60)
        return "\n".join(lines)


def wtestlrb(
    beta: np.ndarray,
    cov: np.ndarray,
    bigR: np.ndarray,
    smr: np.ndarray,
    data: np.ndarray
) -> Tuple[float, float]:
    """
    Wald test for long-run parameter (beta) - EXACT GAUSS wtestlrb.src.
    
    GAUSS formula:
    wt = ((nn-1)^2)*(bigR*_beta-smr)'*inv(bigR*cov*bigR')*(bigR*_beta-smr);
    pv = cdfchic(wt, rnk);
    
    Parameters
    ----------
    beta : np.ndarray
        Long-run parameter estimates (bigbt from qardl)
    cov : np.ndarray
        Covariance matrix of beta (bigbt_cov from qardl)
    bigR : np.ndarray
        Restriction matrix R in H0: R*β = r
    smr : np.ndarray
        Restriction values r in H0: R*β = r
    data : np.ndarray
        Original data matrix (used for sample size)
        
    Returns
    -------
    Tuple[float, float]
        (wald_statistic, p_value)
    """
    beta = np.asarray(beta).flatten()
    smr = np.asarray(smr).flatten()
    bigR = np.asarray(bigR)
    cov = np.asarray(cov)
    
    if bigR.ndim == 1:
        bigR = bigR.reshape(1, -1)
    
    nn = len(data)
    
    # R*beta - r
    diff = bigR @ beta - smr
    
    # inv(R*cov*R')
    RcovR = bigR @ cov @ bigR.T
    try:
        RcovR_inv = np.linalg.inv(RcovR)
    except np.linalg.LinAlgError:
        RcovR_inv = np.linalg.pinv(RcovR)
    
    # Wald statistic with (n-1)² scaling
    wt = ((nn - 1) ** 2) * (diff.T @ RcovR_inv @ diff)
    
    # Degrees of freedom = number of restrictions
    rnk = bigR.shape[0]
    
    # P-value from chi-squared
    pv = 1 - stats.chi2.cdf(wt, rnk)
    
    return float(wt), float(pv)


def wtestsrp(
    phi: np.ndarray,
    cov: np.ndarray,
    bigR: np.ndarray,
    smr: np.ndarray,
    data: np.ndarray
) -> Tuple[float, float]:
    """
    Wald test for short-run parameter phi - EXACT GAUSS wtestsrp.src.
    
    GAUSS formula:
    wt = (nn-1)*(bigR*phi-smr)'*inv(bigR*cov*bigR')*(bigR*phi-smr);
    pv = cdfchic(wt, rnk);
    
    Parameters
    ----------
    phi : np.ndarray
        Short-run phi estimates (from qardl)
    cov : np.ndarray
        Covariance matrix of phi (phi_cov from qardl)
    bigR : np.ndarray
        Restriction matrix R
    smr : np.ndarray
        Restriction values r
    data : np.ndarray
        Original data matrix
        
    Returns
    -------
    Tuple[float, float]
        (wald_statistic, p_value)
    """
    phi = np.asarray(phi).flatten()
    smr = np.asarray(smr).flatten()
    bigR = np.asarray(bigR)
    cov = np.asarray(cov)
    
    if bigR.ndim == 1:
        bigR = bigR.reshape(1, -1)
    
    nn = len(data)
    
    # R*phi - r
    diff = bigR @ phi - smr
    
    # inv(R*cov*R')
    RcovR = bigR @ cov @ bigR.T
    try:
        RcovR_inv = np.linalg.inv(RcovR)
    except np.linalg.LinAlgError:
        RcovR_inv = np.linalg.pinv(RcovR)
    
    # Wald statistic with (n-1) scaling (NOT squared for short-run)
    wt = (nn - 1) * (diff.T @ RcovR_inv @ diff)
    
    # Degrees of freedom
    rnk = bigR.shape[0]
    
    # P-value
    pv = 1 - stats.chi2.cdf(wt, rnk)
    
    return float(wt), float(pv)


def wtestsrg(
    gamma: np.ndarray,
    cov: np.ndarray,
    bigR: np.ndarray,
    smr: np.ndarray,
    data: np.ndarray
) -> Tuple[float, float]:
    """
    Wald test for short-run parameter gamma - EXACT GAUSS wtestsrg.src.
    
    GAUSS formula:
    wt = (nn-1)*(bigR*_gamma-smr)'*inv(bigR*cov*bigR')*(bigR*_gamma-smr);
    pv = cdfchic(wt, rnk);
    
    Parameters
    ----------
    gamma : np.ndarray
        Short-run gamma estimates (from qardl)
    cov : np.ndarray
        Covariance matrix of gamma (gamma_cov from qardl)
    bigR : np.ndarray
        Restriction matrix R
    smr : np.ndarray
        Restriction values r
    data : np.ndarray
        Original data matrix
        
    Returns
    -------
    Tuple[float, float]
        (wald_statistic, p_value)
    """
    gamma = np.asarray(gamma).flatten()
    smr = np.asarray(smr).flatten()
    bigR = np.asarray(bigR)
    cov = np.asarray(cov)
    
    if bigR.ndim == 1:
        bigR = bigR.reshape(1, -1)
    
    nn = len(data)
    
    # R*gamma - r
    diff = bigR @ gamma - smr
    
    # inv(R*cov*R')
    RcovR = bigR @ cov @ bigR.T
    try:
        RcovR_inv = np.linalg.inv(RcovR)
    except np.linalg.LinAlgError:
        RcovR_inv = np.linalg.pinv(RcovR)
    
    # Wald statistic with (n-1) scaling
    wt = (nn - 1) * (diff.T @ RcovR_inv @ diff)
    
    # Degrees of freedom
    rnk = bigR.shape[0]
    
    # P-value
    pv = 1 - stats.chi2.cdf(wt, rnk)
    
    return float(wt), float(pv)


# =============================================================================
# HIGH-LEVEL TESTING FUNCTIONS
# =============================================================================

def test_long_run_equality(qaOut, data: np.ndarray, quantile_pairs: list = None) -> WaldTestResult:
    """
    Test equality of long-run parameters across quantiles.
    
    Default tests adjacent quantile pairs:
    H0: β(τ_1) = β(τ_2), β(τ_2) = β(τ_3), ...
    
    Parameters
    ----------
    qaOut : QARDLOut
        QARDL estimation results
    data : np.ndarray
        Original data
    quantile_pairs : list, optional
        List of (i, j) index pairs to test. If None, tests adjacent pairs.
        
    Returns
    -------
    WaldTestResult
    """
    k = qaOut.k
    ss = len(qaOut.tau)
    
    if quantile_pairs is None:
        # Test adjacent pairs
        n_pairs = ss - 1
        quantile_pairs = [(i, i + 1) for i in range(n_pairs)]
    
    n_restrictions = len(quantile_pairs) * k
    
    # Build restriction matrix
    bigR = np.zeros((n_restrictions, k * ss))
    
    for idx, (i, j) in enumerate(quantile_pairs):
        for kk in range(k):
            row = idx * k + kk
            bigR[row, i * k + kk] = 1
            bigR[row, j * k + kk] = -1
    
    smr = np.zeros(n_restrictions)
    
    wt, pv = wtestlrb(qaOut.bigbt, qaOut.bigbt_cov, bigR, smr, data)
    
    return WaldTestResult(
        statistic=wt,
        pvalue=pv,
        df=n_restrictions,
        hypothesis=f"H0: β equal across quantiles {[qaOut.tau[i] for i, _ in quantile_pairs]}"
    )


def test_phi_equality(qaOut, data: np.ndarray) -> WaldTestResult:
    """
    Test equality of phi parameters across quantiles.
    
    H0: φ(τ_1) = φ(τ_2) = ... = φ(τ_s)
    """
    p = qaOut.p
    ss = len(qaOut.tau)
    
    if ss < 2:
        raise ValueError("Need at least 2 quantiles for equality test")
    
    n_restrictions = (ss - 1) * p
    bigR = np.zeros((n_restrictions, p * ss))
    
    for i in range(ss - 1):
        for j in range(p):
            row = i * p + j
            bigR[row, i * p + j] = 1
            bigR[row, (i + 1) * p + j] = -1
    
    smr = np.zeros(n_restrictions)
    
    wt, pv = wtestsrp(qaOut.phi, qaOut.phi_cov, bigR, smr, data)
    
    return WaldTestResult(
        statistic=wt,
        pvalue=pv,
        df=n_restrictions,
        hypothesis="H0: φ equal across quantiles"
    )


def test_gamma_equality(qaOut, data: np.ndarray) -> WaldTestResult:
    """
    Test equality of gamma parameters across quantiles.
    
    H0: γ(τ_1) = γ(τ_2) = ... = γ(τ_s)
    """
    k = qaOut.k
    ss = len(qaOut.tau)
    
    if ss < 2:
        raise ValueError("Need at least 2 quantiles for equality test")
    
    n_restrictions = (ss - 1) * k
    bigR = np.zeros((n_restrictions, k * ss))
    
    for i in range(ss - 1):
        for j in range(k):
            row = i * k + j
            bigR[row, i * k + j] = 1
            bigR[row, (i + 1) * k + j] = -1
    
    smr = np.zeros(n_restrictions)
    
    wt, pv = wtestsrg(qaOut.gamma, qaOut.gamma_cov, bigR, smr, data)
    
    return WaldTestResult(
        statistic=wt,
        pvalue=pv,
        df=n_restrictions,
        hypothesis="H0: γ equal across quantiles"
    )


def test_cointegration(qaOut, data: np.ndarray, param_index: int = 0) -> WaldTestResult:
    """
    Test if specific long-run coefficient equals zero.
    
    H0: β_i = 0 (no cointegration effect for variable i)
    
    Parameters
    ----------
    qaOut : QARDLOut
        QARDL estimation results
    data : np.ndarray
        Original data
    param_index : int
        Index of the long-run parameter to test (0-indexed)
        
    Returns
    -------
    WaldTestResult
    """
    k = qaOut.k
    ss = len(qaOut.tau)
    
    # Test β_i = 0 for all quantiles
    n_restrictions = ss
    bigR = np.zeros((n_restrictions, k * ss))
    
    for i in range(ss):
        bigR[i, i * k + param_index] = 1
    
    smr = np.zeros(n_restrictions)
    
    wt, pv = wtestlrb(qaOut.bigbt, qaOut.bigbt_cov, bigR, smr, data)
    
    return WaldTestResult(
        statistic=wt,
        pvalue=pv,
        df=n_restrictions,
        hypothesis=f"H0: β_{param_index + 1} = 0 for all quantiles"
    )


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'WaldTestResult',
    'wtestlrb',
    'wtestsrp',
    'wtestsrg',
    'test_long_run_equality',
    'test_phi_equality',
    'test_gamma_equality',
    'test_cointegration',
]
