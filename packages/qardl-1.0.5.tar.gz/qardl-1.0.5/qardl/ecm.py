"""
QARDL-ECM Error Correction Model - MATLAB Compatible

Based on qardlecm.m MATLAB implementation from Cho, Kim & Shin (2015).

The ECM representation:
    Δy_t = α + ζ*(y_{t-1} - β'x_{t-1}) + Σ γ_i*Δy_{t-i} + δ'Δx_t + Σ λ_j'Δx_{t-j} + u_t

where:
    - ζ: adjustment speed (error correction coefficient, should be negative)
    - β: long-run coefficients
    - γ_i: short-run coefficients on lagged Δy
    - δ: contemporaneous effect of Δx
    - λ_j: short-run coefficients on lagged Δx

Author: Dr. Merwan Roudane
"""

import numpy as np
from scipy import stats
from typing import List, Optional, Union, Dict
import warnings

from .utils import (
    quantile_regression,
    bandwidth_bofinger,
    estimate_density,
)


class QARDLECMOut:
    """
    QARDL-ECM Output Structure.
    
    Attributes
    ----------
    tau : np.ndarray
        Quantile levels
    alpha : np.ndarray
        Intercepts (s x 1)
    zeta : np.ndarray
        Adjustment speeds (s x 1)
    beta : np.ndarray
        Long-run coefficients (k x s)
    gamma : np.ndarray
        Short-run y-lag coefficients ((p-1) x s)
    delta : np.ndarray
        Contemporaneous Δx coefficients (k x s)
    lambda_x : np.ndarray
        Lagged Δx coefficients (q x k x s)
    residuals : dict
        Residuals for each quantile
    vcov : dict
        Variance-covariance matrices for each quantile
    n_obs : int
        Effective sample size
    p : int
        AR lag order
    q : int
        DL lag order
    k : int
        Number of X variables
    """
    
    def __init__(self):
        self.tau = None
        self.alpha = None
        self.zeta = None
        self.beta = None
        self.gamma = None
        self.delta = None
        self.lambda_x = None
        self.residuals = {}
        self.vcov = {}
        self.n_obs = None
        self.p = None
        self.q = None
        self.k = None
    
    def get_half_life(self, tau_idx: int = 0) -> float:
        """
        Compute half-life of adjustment.
        
        Half-life = -ln(2) / ζ
        
        Returns inf if ζ >= 0 (non-convergent)
        """
        zeta = self.zeta[tau_idx] if isinstance(self.zeta, np.ndarray) else self.zeta
        if zeta >= 0:
            return np.inf
        return -np.log(2) / zeta
    
    def summary(self) -> str:
        """Generate summary output."""
        lines = []
        lines.append("=" * 70)
        lines.append("QARDL-ECM Estimation Results")
        lines.append("=" * 70)
        lines.append(f"Sample size: {self.n_obs}")
        lines.append(f"AR order (p): {self.p}, DL order (q): {self.q}")
        lines.append(f"Number of X variables: {self.k}")
        lines.append(f"Quantiles: {self.tau}")
        lines.append("")
        
        for i, tau in enumerate(self.tau):
            lines.append("-" * 70)
            lines.append(f"Quantile τ = {tau:.2f}")
            lines.append("-" * 70)
            
            zeta_i = self.zeta[i]
            lines.append(f"Adjustment speed (ζ): {zeta_i:.6f}")
            
            hl = self.get_half_life(i)
            if np.isinf(hl):
                lines.append("Half-life: Non-convergent (ζ ≥ 0)")
            else:
                lines.append(f"Half-life: {hl:.2f} periods")
            
            lines.append("")
            lines.append("Long-run coefficients (β):")
            for j in range(self.k):
                lines.append(f"  β_{j+1}: {self.beta[j, i]:.6f}")
            
            lines.append("")
        
        lines.append("=" * 70)
        return "\n".join(lines)


def qardl_ecm(
    data: np.ndarray,
    p: int,
    q: int,
    tau: np.ndarray
) -> QARDLECMOut:
    """
    QARDL-ECM Estimation - MATLAB qardlecm.m compatible.
    
    Two-step estimation procedure:
    1. Estimate long-run relationship: y_t = α_lr + β'x_t + ε_t
    2. Estimate ECM: Δy_t = α + ζ*ECT_{t-1} + short-run dynamics + u_t
    
    Parameters
    ----------
    data : np.ndarray
        (T x (1+k)) matrix with y in first column
    p : int
        AR lag order
    q : int
        DL lag order
    tau : np.ndarray
        Quantile levels
        
    Returns
    -------
    QARDLECMOut
        ECM estimation results
    """
    tau = np.sort(np.asarray(tau).flatten())
    ss = len(tau)
    
    nn = len(data)
    k0 = data.shape[1] - 1
    
    yy = data[:, 0]
    xx = data[:, 1:]
    
    max_lag = max(p, q)
    
    # =========================================================================
    # STEP 1: First differences
    # =========================================================================
    dy = np.diff(yy)  # Δy_t
    dx = np.diff(xx, axis=0)  # Δx_t
    
    # =========================================================================
    # STEP 2: Build ECM design matrix
    # =========================================================================
    
    # Effective sample: need max_lag observations for lags
    n_eff = nn - max_lag - 1
    
    # Dependent variable: Δy_t for t = max_lag+1 to T
    dy_dep = dy[max_lag:]
    
    # Error correction term: y_{t-1} - estimated long-run relationship
    # First estimate long-run β by regressing y on x (static regression)
    
    # Components for ECM design matrix:
    # 1. Constant
    # 2. ECT = y_{t-1} - β'x_{t-1} (computed after long-run estimation)
    # 3. Lagged Δy_{t-1}, ..., Δy_{t-p+1}
    # 4. Current Δx_t
    # 5. Lagged Δx_{t-1}, ..., Δx_{t-q}
    
    # Build lagged Δy
    if p > 1:
        dy_lags = np.zeros((n_eff, p - 1))
        for i in range(p - 1):
            dy_lags[:, i] = dy[max_lag - i - 1:nn - i - 2]
    else:
        dy_lags = np.empty((n_eff, 0))
    
    # Current Δx
    dx_current = dx[max_lag:, :]
    
    # Lagged Δx
    if q > 0:
        dx_lags = np.zeros((n_eff, q * k0))
        for i in range(q):
            dx_lags[:, i * k0:(i + 1) * k0] = dx[max_lag - i - 1:nn - i - 2, :]
    else:
        dx_lags = np.empty((n_eff, 0))
    
    # =========================================================================
    # STEP 3: Estimate for each quantile
    # =========================================================================
    
    # Storage
    alpha_all = np.zeros(ss)
    zeta_all = np.zeros(ss)
    beta_all = np.zeros((k0, ss))
    gamma_all = np.zeros((max(p - 1, 0), ss))
    delta_all = np.zeros((k0, ss))
    lambda_all = np.zeros((q, k0, ss)) if q > 0 else None
    residuals_all = {}
    vcov_all = {}
    
    for jj in range(ss):
        t = tau[jj]
        
        # -----------------------------------------------------------------
        # Step 3a: Estimate long-run relationship
        # y_t = α_lr + β'x_t + ε_t
        # -----------------------------------------------------------------
        y_lr = yy[max_lag:]
        x_lr = xx[max_lag:, :]
        
        lr_beta = quantile_regression(y_lr, x_lr, t, intercept=True)
        alpha_lr = lr_beta[0]
        beta_lr = lr_beta[1:]
        
        beta_all[:, jj] = beta_lr
        
        # -----------------------------------------------------------------
        # Step 3b: Compute ECT
        # ECT_{t-1} = y_{t-1} - β'x_{t-1}
        # -----------------------------------------------------------------
        y_lag1 = yy[max_lag:-1]  # y_{t-1}
        x_lag1 = xx[max_lag:-1, :]  # x_{t-1}
        
        ect = y_lag1 - x_lag1 @ beta_lr
        
        # -----------------------------------------------------------------
        # Step 3c: Build ECM design matrix and estimate
        # Δy_t = α + ζ*ECT_{t-1} + γ'Δy_lags + δ'Δx_t + λ'Δx_lags + u_t
        # -----------------------------------------------------------------
        design_parts = [ect.reshape(-1, 1)]  # ECT (no constant in design, added by QR)
        
        if p > 1:
            design_parts.append(dy_lags)
        
        design_parts.append(dx_current)
        
        if q > 0:
            design_parts.append(dx_lags)
        
        design = np.column_stack(design_parts)
        
        # Quantile regression
        ecm_beta = quantile_regression(dy_dep, design, t, intercept=True)
        
        # Extract coefficients
        idx = 0
        alpha_all[jj] = ecm_beta[idx]
        idx += 1
        
        zeta_all[jj] = ecm_beta[idx]
        idx += 1
        
        if p > 1:
            gamma_all[:, jj] = ecm_beta[idx:idx + p - 1]
            idx += p - 1
        
        delta_all[:, jj] = ecm_beta[idx:idx + k0]
        idx += k0
        
        if q > 0:
            for i in range(q):
                lambda_all[i, :, jj] = ecm_beta[idx:idx + k0]
                idx += k0
        
        # Residuals
        design_full = np.column_stack([np.ones(n_eff), design])
        residuals_all[jj] = dy_dep - design_full @ ecm_beta
        
        # Variance-covariance
        h = bandwidth_bofinger(t, nn)
        f_hat = estimate_density(residuals_all[jj], t, bandwidth=h, n=nn)
        
        J = f_hat * (design_full.T @ design_full) / n_eff
        Omega = t * (1 - t) * (design_full.T @ design_full) / n_eff
        
        try:
            J_inv = np.linalg.inv(J)
        except:
            J_inv = np.linalg.pinv(J)
        
        vcov_all[jj] = J_inv @ Omega @ J_inv / n_eff
    
    # =========================================================================
    # STEP 4: Build output structure
    # =========================================================================
    
    ecmOut = QARDLECMOut()
    ecmOut.tau = tau
    ecmOut.alpha = alpha_all
    ecmOut.zeta = zeta_all
    ecmOut.beta = beta_all
    ecmOut.gamma = gamma_all
    ecmOut.delta = delta_all
    ecmOut.lambda_x = lambda_all
    ecmOut.residuals = residuals_all
    ecmOut.vcov = vcov_all
    ecmOut.n_obs = n_eff
    ecmOut.p = p
    ecmOut.q = q
    ecmOut.k = k0
    
    return ecmOut


# =============================================================================
# CLASS INTERFACE
# =============================================================================

class QARDLECM:
    """
    QARDL-ECM Model class interface.
    
    Parameters
    ----------
    y : np.ndarray
        Dependent variable
    X : np.ndarray
        Independent variable(s)
    p : int
        AR lag order
    q : int
        DL lag order
    tau : Union[float, List[float], np.ndarray]
        Quantile(s)
    """
    
    def __init__(
        self,
        y: np.ndarray,
        X: np.ndarray,
        p: int,
        q: int,
        tau: Union[float, List[float], np.ndarray] = 0.5
    ):
        self.y = np.asarray(y).flatten()
        self.X = np.asarray(X)
        if self.X.ndim == 1:
            self.X = self.X.reshape(-1, 1)
        
        self.p = p
        self.q = q
        
        if isinstance(tau, (int, float)):
            self.tau = np.array([tau])
        else:
            self.tau = np.sort(np.asarray(tau))
        
        self.data = np.column_stack([self.y, self.X])
        self.results_ = None
    
    def fit(self) -> QARDLECMOut:
        """Fit QARDL-ECM model."""
        self.results_ = qardl_ecm(self.data, self.p, self.q, self.tau)
        return self.results_
    
    def summary(self) -> str:
        """Get results summary."""
        if self.results_ is None:
            return "Model not fitted. Call fit() first."
        return self.results_.summary()


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def convert_qardl_to_ecm(qaOut) -> dict:
    """
    Convert QARDL output to ECM representation.
    
    The relationship between QARDL and ECM parameters:
    - ζ = Σφ - 1 (adjustment speed)
    - β = long-run coefficients (same as bigbt but reshaped)
    
    Parameters
    ----------
    qaOut : QARDLOut
        Output from qardl() estimation
        
    Returns
    -------
    dict
        ECM coefficients for each quantile
    """
    p = qaOut.p
    k = qaOut.k
    ss = len(qaOut.tau)
    
    ecm_params = {}
    
    for i, tau in enumerate(qaOut.tau):
        phi = qaOut.get_phi_for_tau(i)
        beta = qaOut.get_beta_for_tau(i)
        gamma = qaOut.get_gamma_for_tau(i)
        
        zeta = np.sum(phi) - 1
        half_life = -np.log(2) / zeta if zeta < 0 else np.inf
        
        ecm_params[tau] = {
            'zeta': zeta,
            'beta': beta,
            'gamma': gamma,
            'phi': phi,
            'half_life': half_life
        }
    
    return ecm_params


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'QARDLECMOut',
    'qardl_ecm',
    'QARDLECM',
    'convert_qardl_to_ecm',
]
