"""
QARDL - Quantile Autoregressive Distributed Lag Models

Exact implementation of Cho, Kim & Shin (2015) methodology.
Compatible with original GAUSS/MATLAB code.

Reference:
    Cho, J.S., Kim, T.-H., & Shin, Y. (2015). Quantile cointegration in the
    autoregressive distributed-lag modeling framework. Journal of Econometrics,
    188(1), 281-300.

Modules:
    - core: Main QARDL estimation (qardl.src compatible)
    - ecm: Error Correction Model (qardlecm.m compatible)
    - testing: Wald tests (wtestlrb.src, wtestsrp.src, wtestsrg.src)
    - rolling: Rolling window estimation (rollingQardl)
    - simulation: Monte Carlo simulation (qardlAR2Sim)
    - plotting: Visualization (plotQARDL equivalent)
    - utils: Utilities and helpers

Author: Dr. Merwan Roudane
Email: merwanroudane920@gmail.com
Version: 1.0.3 (GAUSS/MATLAB Compatible)
"""

from .core import (
    QARDL,
    QARDLOut,
    qardl,
)

from .ecm import (
    QARDLECM,
    QARDLECMOut,
    qardl_ecm,
    convert_qardl_to_ecm,
)

from .testing import (
    WaldTestResult,
    wtestlrb,
    wtestsrp,
    wtestsrg,
    test_long_run_equality,
    test_phi_equality,
    test_gamma_equality,
    test_cointegration,
)

from .rolling import (
    WaldTestRestrictions,
    RollingWaldTests,
    RollingQARDLOut,
    rolling_qardl,
    create_wald_restrictions,
)

from .simulation import (
    DGPParams,
    qardl_ar2_sim,
    generate_qardl_data,
    simulate_wald_tests,
    print_simulation_results,
)

from .plotting import (
    plot_qardl,
    plot_beta,
    plot_gamma,
    plot_phi,
    plot_rolling,
    plot_ecm,
)

from .utils import (
    quantile_regression,
    bandwidth_bofinger,
    bandwidth_hall_sheather,
    estimate_density,
    build_qardl_matrices,
    ic_mean,
    pq_order,
    compute_M_matrix,
    get_coefficient_indices,
    extract_long_run_beta,
    extract_phi,
    extract_gamma,
    generate_param_names,
    prepare_data,
)

__version__ = "1.0.5"
__author__ = "Dr. Merwan Roudane"
__email__ = "merwanroudane920@gmail.com"

__all__ = [
    # Core
    'QARDL',
    'QARDLOut',
    'qardl',
    # ECM
    'QARDLECM',
    'QARDLECMOut',
    'qardl_ecm',
    'convert_qardl_to_ecm',
    # Testing
    'WaldTestResult',
    'wtestlrb',
    'wtestsrp',
    'wtestsrg',
    'test_long_run_equality',
    'test_phi_equality',
    'test_gamma_equality',
    'test_cointegration',
    # Rolling
    'WaldTestRestrictions',
    'RollingWaldTests',
    'RollingQARDLOut',
    'rolling_qardl',
    'create_wald_restrictions',
    # Simulation
    'DGPParams',
    'qardl_ar2_sim',
    'generate_qardl_data',
    'simulate_wald_tests',
    'print_simulation_results',
    # Plotting
    'plot_qardl',
    'plot_beta',
    'plot_gamma',
    'plot_phi',
    'plot_rolling',
    'plot_ecm',
    # Utils
    'quantile_regression',
    'bandwidth_bofinger',
    'bandwidth_hall_sheather',
    'estimate_density',
    'build_qardl_matrices',
    'ic_mean',
    'pq_order',
    'compute_M_matrix',
    'get_coefficient_indices',
    'extract_long_run_beta',
    'extract_phi',
    'extract_gamma',
    'generate_param_names',
    'prepare_data',
]
