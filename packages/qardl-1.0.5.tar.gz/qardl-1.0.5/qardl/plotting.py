"""
QARDL Plotting - Python Visualization

Matplotlib-based plotting functions equivalent to GAUSS plotQARDL.

Functions:
- plot_qardl(): Main plotting function for QARDL results
- plot_beta(): Plot long-run parameters across quantiles
- plot_gamma(): Plot short-run impact parameters
- plot_phi(): Plot AR parameters
- plot_rolling(): Plot rolling estimation results

Author: Dr. Merwan Roudane
"""

import numpy as np
from typing import Optional, List, Tuple, Union
import warnings

try:
    import matplotlib.pyplot as plt
    from matplotlib.figure import Figure
    from matplotlib.axes import Axes
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    warnings.warn("matplotlib not installed. Plotting functions will not work.")


def _check_matplotlib():
    """Check if matplotlib is available."""
    if not HAS_MATPLOTLIB:
        raise ImportError("matplotlib is required for plotting. Install with: pip install matplotlib")


def plot_qardl(qaOut, tau: Optional[np.ndarray] = None, figsize: Tuple[int, int] = (12, 10),
               title: str = "QARDL Estimation Results") -> 'Figure':
    """
    Plot QARDL results - equivalent to GAUSS plotQARDL.
    
    Creates a multi-panel figure with:
    - Top row: Beta (long-run) parameters
    - Middle row: Gamma (short-run impact) parameters
    - Bottom row: Phi (AR) parameters
    
    Parameters
    ----------
    qaOut : QARDLOut
        QARDL estimation output
    tau : np.ndarray, optional
        Quantile levels. If None, uses qaOut.tau.
    figsize : tuple, default=(12, 10)
        Figure size
    title : str, default="QARDL Estimation Results"
        Main title
        
    Returns
    -------
    matplotlib.figure.Figure
        Figure object
    """
    _check_matplotlib()
    
    if tau is None:
        tau = qaOut.tau
    
    ntau = len(tau)
    k = qaOut.k
    p = qaOut.p
    
    # Reshape parameters
    beta = qaOut.bigbt.reshape(ntau, k)
    gamma = qaOut.gamma.reshape(ntau, k)
    phi = qaOut.phi.reshape(ntau, p)
    
    # Determine layout
    n_cols = max(k, p)
    
    fig, axes = plt.subplots(3, n_cols, figsize=figsize, squeeze=False)
    fig.suptitle(title, fontsize=14, fontweight='bold')
    
    # Plot beta (long-run)
    for i in range(k):
        ax = axes[0, i]
        ax.plot(tau, beta[:, i], 'b-o', linewidth=2, markersize=6)
        ax.set_title(f'$\\beta_{{{i+1}}}$', fontsize=12)
        ax.set_xlabel('$\\tau$')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    # Hide unused beta axes
    for i in range(k, n_cols):
        axes[0, i].set_visible(False)
    
    # Plot gamma (short-run impact)
    for i in range(k):
        ax = axes[1, i]
        ax.plot(tau, gamma[:, i], 'g-o', linewidth=2, markersize=6)
        ax.set_title(f'$\\gamma_{{{i+1}}}$', fontsize=12)
        ax.set_xlabel('$\\tau$')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    # Hide unused gamma axes
    for i in range(k, n_cols):
        axes[1, i].set_visible(False)
    
    # Plot phi (AR)
    for i in range(p):
        ax = axes[2, i]
        ax.plot(tau, phi[:, i], 'r-o', linewidth=2, markersize=6)
        ax.set_title(f'$\\phi_{{t-{i+1}}}$', fontsize=12)
        ax.set_xlabel('$\\tau$')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    # Hide unused phi axes
    for i in range(p, n_cols):
        axes[2, i].set_visible(False)
    
    plt.tight_layout()
    return fig


def plot_beta(qaOut, tau: Optional[np.ndarray] = None, 
              with_ci: bool = True, alpha: float = 0.05,
              figsize: Optional[Tuple[int, int]] = None) -> 'Figure':
    """
    Plot long-run beta parameters with confidence intervals.
    
    Parameters
    ----------
    qaOut : QARDLOut
        QARDL estimation output
    tau : np.ndarray, optional
        Quantile levels
    with_ci : bool, default=True
        Include confidence intervals
    alpha : float, default=0.05
        Significance level for CI
    figsize : tuple, optional
        Figure size
        
    Returns
    -------
    matplotlib.figure.Figure
    """
    _check_matplotlib()
    
    from scipy import stats
    
    if tau is None:
        tau = qaOut.tau
    
    ntau = len(tau)
    k = qaOut.k
    
    if figsize is None:
        figsize = (4 * k, 4)
    
    beta = qaOut.bigbt.reshape(ntau, k)
    
    # Get standard errors from covariance
    beta_se = np.sqrt(np.maximum(np.diag(qaOut.bigbt_cov), 0)).reshape(ntau, k)
    
    z_crit = stats.norm.ppf(1 - alpha / 2)
    
    fig, axes = plt.subplots(1, k, figsize=figsize, squeeze=False)
    
    for i in range(k):
        ax = axes[0, i]
        
        ax.plot(tau, beta[:, i], 'b-o', linewidth=2, markersize=6, label=f'$\\beta_{{{i+1}}}$')
        
        if with_ci:
            lower = beta[:, i] - z_crit * beta_se[:, i]
            upper = beta[:, i] + z_crit * beta_se[:, i]
            ax.fill_between(tau, lower, upper, alpha=0.2, color='blue')
        
        ax.set_title(f'Long-run $\\beta_{{{i+1}}}$', fontsize=12)
        ax.set_xlabel('Quantile ($\\tau$)')
        ax.set_ylabel('Coefficient')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    plt.tight_layout()
    return fig


def plot_gamma(qaOut, tau: Optional[np.ndarray] = None,
               with_ci: bool = True, alpha: float = 0.05,
               figsize: Optional[Tuple[int, int]] = None) -> 'Figure':
    """
    Plot short-run gamma parameters with confidence intervals.
    
    Parameters
    ----------
    qaOut : QARDLOut
        QARDL estimation output
    tau : np.ndarray, optional
        Quantile levels
    with_ci : bool, default=True
        Include confidence intervals
    alpha : float, default=0.05
        Significance level for CI
    figsize : tuple, optional
        Figure size
        
    Returns
    -------
    matplotlib.figure.Figure
    """
    _check_matplotlib()
    
    from scipy import stats
    
    if tau is None:
        tau = qaOut.tau
    
    ntau = len(tau)
    k = qaOut.k
    
    if figsize is None:
        figsize = (4 * k, 4)
    
    gamma = qaOut.gamma.reshape(ntau, k)
    gamma_se = np.sqrt(np.maximum(np.diag(qaOut.gamma_cov), 0)).reshape(ntau, k)
    
    z_crit = stats.norm.ppf(1 - alpha / 2)
    
    fig, axes = plt.subplots(1, k, figsize=figsize, squeeze=False)
    
    for i in range(k):
        ax = axes[0, i]
        
        ax.plot(tau, gamma[:, i], 'g-o', linewidth=2, markersize=6)
        
        if with_ci:
            lower = gamma[:, i] - z_crit * gamma_se[:, i]
            upper = gamma[:, i] + z_crit * gamma_se[:, i]
            ax.fill_between(tau, lower, upper, alpha=0.2, color='green')
        
        ax.set_title(f'Short-run $\\gamma_{{{i+1}}}$', fontsize=12)
        ax.set_xlabel('Quantile ($\\tau$)')
        ax.set_ylabel('Coefficient')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    plt.tight_layout()
    return fig


def plot_phi(qaOut, tau: Optional[np.ndarray] = None,
             with_ci: bool = True, alpha: float = 0.05,
             figsize: Optional[Tuple[int, int]] = None) -> 'Figure':
    """
    Plot AR phi parameters with confidence intervals.
    
    Parameters
    ----------
    qaOut : QARDLOut
        QARDL estimation output
    tau : np.ndarray, optional
        Quantile levels
    with_ci : bool, default=True
        Include confidence intervals
    alpha : float, default=0.05
        Significance level for CI
    figsize : tuple, optional
        Figure size
        
    Returns
    -------
    matplotlib.figure.Figure
    """
    _check_matplotlib()
    
    from scipy import stats
    
    if tau is None:
        tau = qaOut.tau
    
    ntau = len(tau)
    p = qaOut.p
    
    if figsize is None:
        figsize = (4 * p, 4)
    
    phi = qaOut.phi.reshape(ntau, p)
    phi_se = np.sqrt(np.maximum(np.diag(qaOut.phi_cov), 0)).reshape(ntau, p)
    
    z_crit = stats.norm.ppf(1 - alpha / 2)
    
    fig, axes = plt.subplots(1, p, figsize=figsize, squeeze=False)
    
    for i in range(p):
        ax = axes[0, i]
        
        ax.plot(tau, phi[:, i], 'r-o', linewidth=2, markersize=6)
        
        if with_ci:
            lower = phi[:, i] - z_crit * phi_se[:, i]
            upper = phi[:, i] + z_crit * phi_se[:, i]
            ax.fill_between(tau, lower, upper, alpha=0.2, color='red')
        
        ax.set_title(f'AR $\\phi_{{t-{i+1}}}$', fontsize=12)
        ax.set_xlabel('Quantile ($\\tau$)')
        ax.set_ylabel('Coefficient')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    plt.tight_layout()
    return fig


def plot_rolling(rqaOut, var_idx: int = 0, tau_idx: int = 0,
                 param_type: str = 'beta',
                 with_se: bool = True,
                 figsize: Tuple[int, int] = (10, 6)) -> 'Figure':
    """
    Plot rolling QARDL estimation results.
    
    Parameters
    ----------
    rqaOut : RollingQARDLOut
        Rolling QARDL output
    var_idx : int, default=0
        Variable index (for beta and gamma)
    tau_idx : int, default=0
        Quantile index
    param_type : str, default='beta'
        Parameter type: 'beta', 'gamma', 'phi', or 'wald'
    with_se : bool, default=True
        Include standard error bands
    figsize : tuple
        Figure size
        
    Returns
    -------
    matplotlib.figure.Figure
    """
    _check_matplotlib()
    
    fig, ax = plt.subplots(figsize=figsize)
    
    obs = np.arange(1, rqaOut.num_est + 1)
    tau = rqaOut.tau[tau_idx]
    
    if param_type == 'beta':
        values = rqaOut.bigbt[var_idx, :, tau_idx]
        se = rqaOut.bigbt_se[var_idx, :, tau_idx] if with_se else None
        title = f'Rolling $\\beta_{{{var_idx + 1}}}(\\tau = {tau:.2f})$'
        color = 'blue'
        
    elif param_type == 'gamma':
        values = rqaOut.gamma[var_idx, :, tau_idx]
        se = rqaOut.gamma_se[var_idx, :, tau_idx] if with_se else None
        title = f'Rolling $\\gamma_{{{var_idx + 1}}}(\\tau = {tau:.2f})$'
        color = 'green'
        
    elif param_type == 'phi':
        values = rqaOut.phi[var_idx, :, tau_idx]
        se = rqaOut.phi_se[var_idx, :, tau_idx] if with_se else None
        title = f'Rolling $\\phi_{{t-{var_idx + 1}}}(\\tau = {tau:.2f})$'
        color = 'red'
        
    elif param_type == 'wald':
        fig, axes = plt.subplots(3, 1, figsize=(figsize[0], figsize[1] * 1.5))
        
        axes[0].plot(obs, rqaOut.rWaldOut.wald_beta, 'b-', linewidth=1)
        axes[0].set_title('Wald Statistic: $\\beta$')
        axes[0].set_ylabel('Wald')
        axes[0].grid(True, alpha=0.3)
        
        axes[1].plot(obs, rqaOut.rWaldOut.wald_phi, 'r-', linewidth=1)
        axes[1].set_title('Wald Statistic: $\\phi$')
        axes[1].set_ylabel('Wald')
        axes[1].grid(True, alpha=0.3)
        
        axes[2].plot(obs, rqaOut.rWaldOut.wald_gamma, 'g-', linewidth=1)
        axes[2].set_title('Wald Statistic: $\\gamma$')
        axes[2].set_xlabel('Window')
        axes[2].set_ylabel('Wald')
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig
    else:
        raise ValueError(f"Unknown param_type: {param_type}")
    
    ax.plot(obs, values, color=color, linewidth=1.5, label=param_type.capitalize())
    
    if se is not None and with_se:
        from scipy import stats
        z = stats.norm.ppf(0.975)
        lower = values - z * se
        upper = values + z * se
        ax.fill_between(obs, lower, upper, alpha=0.2, color=color)
    
    ax.set_title(title, fontsize=12)
    ax.set_xlabel('Window')
    ax.set_ylabel('Coefficient')
    ax.grid(True, alpha=0.3)
    ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    plt.tight_layout()
    return fig


def plot_ecm(ecmOut, figsize: Tuple[int, int] = (12, 8)) -> 'Figure':
    """
    Plot ECM estimation results.
    
    Parameters
    ----------
    ecmOut : QARDLECMOut
        ECM estimation output
    figsize : tuple
        Figure size
        
    Returns
    -------
    matplotlib.figure.Figure
    """
    _check_matplotlib()
    
    tau = ecmOut.tau
    k = ecmOut.k
    
    fig, axes = plt.subplots(2, max(k, 2), figsize=figsize, squeeze=False)
    
    # Plot adjustment speed
    ax = axes[0, 0]
    ax.bar(tau, ecmOut.zeta, width=0.05, color='purple', alpha=0.7)
    ax.set_title('Adjustment Speed ($\\zeta$)', fontsize=12)
    ax.set_xlabel('Quantile ($\\tau$)')
    ax.set_ylabel('$\\zeta$')
    ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    ax.axhline(y=-1, color='r', linestyle=':', alpha=0.5, label='Full adjustment')
    ax.grid(True, alpha=0.3)
    
    # Plot half-life
    ax = axes[0, 1]
    half_lives = [-np.log(2) / z if z < 0 else np.inf for z in ecmOut.zeta]
    half_lives = [min(hl, 10) for hl in half_lives]  # Cap for visualization
    ax.bar(tau, half_lives, width=0.05, color='orange', alpha=0.7)
    ax.set_title('Half-life of Adjustment', fontsize=12)
    ax.set_xlabel('Quantile ($\\tau$)')
    ax.set_ylabel('Periods')
    ax.grid(True, alpha=0.3)
    
    # Hide unused top axes
    for i in range(2, max(k, 2)):
        axes[0, i].set_visible(False)
    
    # Plot long-run beta
    for i in range(k):
        ax = axes[1, i]
        ax.plot(tau, ecmOut.beta[i, :], 'b-o', linewidth=2, markersize=6)
        ax.set_title(f'Long-run $\\beta_{{{i+1}}}$', fontsize=12)
        ax.set_xlabel('Quantile ($\\tau$)')
        ax.set_ylabel('Coefficient')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    
    # Hide unused bottom axes
    for i in range(k, max(k, 2)):
        axes[1, i].set_visible(False)
    
    plt.tight_layout()
    return fig


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'plot_qardl',
    'plot_beta',
    'plot_gamma',
    'plot_phi',
    'plot_rolling',
    'plot_ecm',
]
