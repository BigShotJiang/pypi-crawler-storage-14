"""
QARDL Simulation - GAUSS Compatible

Data generation for Monte Carlo experiments and testing.

Based on GAUSS functions:
- qardlAR2Sim (qardl.src lines 332-354)
- DGP from wald_tests_sim.e (lines 74-87)

Author: Dr. Merwan Roudane
"""

import numpy as np
from typing import Tuple, Optional
from dataclasses import dataclass


@dataclass
class DGPParams:
    """
    Data Generating Process parameters.
    
    For QARDL(1, 1) model:
        y_t = α + φ*y_{t-1} + θ₀*x_t + θ₁*x_{t-1} + u_t
    
    Long-run: β = (θ₀ + θ₁) / (1 - φ)
    Short-run: γ = θ₀
    
    Attributes
    ----------
    alpha : float
        Intercept
    phi : float
        AR(1) coefficient (should be |φ| < 1 for stationarity)
    theta0 : float
        Contemporaneous X coefficient
    theta1 : float
        Lagged X coefficient
    rho : float
        Serial correlation in X innovations (0 for i.i.d.)
    sigma_u : float
        Standard deviation of y equation errors
    sigma_e : float
        Standard deviation of X innovations
    """
    alpha: float = 1.0
    phi: float = 0.25
    theta0: float = 2.0
    theta1: float = 3.0
    rho: float = 0.5
    sigma_u: float = 1.0
    sigma_e: float = 1.0
    
    @property
    def gamma(self) -> float:
        """Short-run parameter γ = θ₀ + θ₁"""
        return self.theta0 + self.theta1
    
    @property
    def beta(self) -> float:
        """Long-run parameter β = γ / (1 - φ)"""
        return self.gamma / (1 - self.phi)


def qardl_ar2_sim(
    n: int,
    alpha: float,
    phi: float,
    rho: float,
    theta0: float,
    theta1: float,
    seed: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate QARDL AR(1) data - EXACT GAUSS qardlAR2Sim.
    
    GAUSS (qardl.src lines 332-354):
    Generates cointegrated data with:
    - Two I(1) X variables (random walks)
    - Y follows QARDL(1,1) with both X variables
    
    Model:
        y_t = α + φ*y_{t-1} + θ₀*(x_{t,1} + x_{t,2}) + θ₁*(x_{t-1,1} + x_{t-1,2}) + u_t
    
    Parameters
    ----------
    n : int
        Sample size
    alpha : float
        Intercept
    phi : float
        AR(1) coefficient
    rho : float
        Serial correlation in first X (not used in original, kept for API)
    theta0 : float
        Contemporaneous coefficient
    theta1 : float
        Lagged coefficient
    seed : int, optional
        Random seed
        
    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (y, X) where y is (n x 1) and X is (n x 2)
        
    Notes
    -----
    Long-run coefficient: β = (θ₀ + θ₁) / (1 - φ)
    """
    if seed is not None:
        np.random.seed(seed)
    
    # Compute theoretical parameters
    gam = theta0 + theta1
    bes = gam / (1 - phi)
    
    # Generate innovations (GAUSS lines 339-343)
    eee1 = np.random.randn(n + 1)
    eee2 = np.random.randn(n)
    eee = eee1[:n]
    
    # X variables: I(1) random walks
    x1 = np.cumsum(eee)
    x2 = np.cumsum(eee2)
    xxx = np.column_stack([x1, x2])
    
    # Y equation errors
    uuu = np.random.randn(n)
    
    # Generate Y (GAUSS lines 344-351)
    yyy = np.zeros(n)
    for jjj in range(1, n):
        yyy[jjj] = (alpha + 
                   phi * yyy[jjj - 1] + 
                   theta0 * xxx[jjj, 0] + theta1 * xxx[jjj - 1, 0] +
                   theta0 * xxx[jjj, 1] + theta1 * xxx[jjj - 1, 1] + 
                   uuu[jjj])
    
    return yyy, xxx


def generate_qardl_data(
    n: int,
    k: int = 2,
    p: int = 1,
    q: int = 1,
    params: Optional[DGPParams] = None,
    seed: Optional[int] = None
) -> np.ndarray:
    """
    Generate QARDL data for arbitrary (p, q, k).
    
    More flexible version of qardlAR2Sim that supports:
    - Arbitrary number of X variables (k)
    - Arbitrary AR order (p)
    - Arbitrary DL order (q)
    
    Parameters
    ----------
    n : int
        Sample size
    k : int, default=2
        Number of X variables
    p : int, default=1
        AR order
    q : int, default=1
        Distributed lag order
    params : DGPParams, optional
        DGP parameters. If None, uses defaults.
    seed : int, optional
        Random seed
        
    Returns
    -------
    np.ndarray
        Data matrix (n x (1+k)) with y in first column
    """
    if seed is not None:
        np.random.seed(seed)
    
    if params is None:
        params = DGPParams()
    
    # Generate I(1) X variables
    X = np.zeros((n, k))
    for j in range(k):
        e = np.random.randn(n)
        if params.rho > 0 and j == 0:
            # Add serial correlation to first X
            e_corr = np.zeros(n)
            e_corr[0] = e[0]
            for t in range(1, n):
                e_corr[t] = params.rho * e_corr[t-1] + np.sqrt(1 - params.rho**2) * e[t]
            X[:, j] = np.cumsum(e_corr)
        else:
            X[:, j] = np.cumsum(e)
    
    # Generate phi coefficients
    phi = np.zeros(p)
    phi[0] = params.phi
    if p > 1:
        # Higher order AR coefficients decay
        for i in range(1, p):
            phi[i] = params.phi ** (i + 1) * (-1) ** i * 0.1
    
    # Generate theta coefficients (for each X variable)
    theta = np.zeros((q + 1, k))
    for j in range(k):
        theta[0, j] = params.theta0 / k  # Divide by k to keep total effect similar
        for lag in range(1, q + 1):
            theta[lag, j] = params.theta1 / (k * lag)  # Decay with lag
    
    # Generate Y
    max_lag = max(p, q)
    u = params.sigma_u * np.random.randn(n)
    
    y = np.zeros(n)
    for t in range(max_lag, n):
        # AR component
        ar_term = params.alpha
        for i in range(p):
            ar_term += phi[i] * y[t - 1 - i]
        
        # X component
        x_term = 0
        for j in range(k):
            for lag in range(q + 1):
                x_term += theta[lag, j] * X[t - lag, j]
        
        y[t] = ar_term + x_term + u[t]
    
    return np.column_stack([y, X])


def simulate_wald_tests(
    n: int,
    n_iter: int,
    p: int,
    q: int,
    tau: np.ndarray,
    params: Optional[DGPParams] = None,
    seed: Optional[int] = None,
    verbose: bool = True
) -> dict:
    """
    Monte Carlo simulation of Wald tests - based on wald_tests_sim.e.
    
    Simulates Wald test statistics under the null hypothesis
    to check size properties.
    
    Parameters
    ----------
    n : int
        Sample size
    n_iter : int
        Number of Monte Carlo iterations
    p : int
        AR order
    q : int
        DL order
    tau : np.ndarray
        Quantile levels
    params : DGPParams, optional
        DGP parameters
    seed : int, optional
        Random seed
    verbose : bool, default=True
        Print progress
        
    Returns
    -------
    dict
        Simulation results containing:
        - wald_beta, wald_phi, wald_gamma: Test statistics
        - pv_beta, pv_phi, pv_gamma: P-values
        - rejection_rates: Empirical rejection rates at various levels
    """
    from .core import qardl
    from .testing import wtestlrb, wtestsrp, wtestsrg
    
    if seed is not None:
        np.random.seed(seed)
    
    if params is None:
        params = DGPParams()
    
    tau = np.sort(np.asarray(tau).flatten())
    num_tau = len(tau)
    k = 2  # Number of X variables
    
    # Storage
    wald_beta = np.zeros(n_iter)
    wald_phi = np.zeros(n_iter)
    wald_gamma = np.zeros(n_iter)
    pv_beta = np.zeros(n_iter)
    pv_phi = np.zeros(n_iter)
    pv_gamma = np.zeros(n_iter)
    
    # Restriction matrices for equality tests
    # Beta: test β₁(τ₁) = β₁(τ₂), etc.
    n_restr = min(2, num_tau - 1) if num_tau > 1 else 1
    
    ca1 = np.zeros((n_restr, k * num_tau))
    if num_tau >= 2:
        ca1[0, 0] = 1
        ca1[0, k] = -1
    if num_tau >= 3 and n_restr >= 2:
        ca1[1, 2 * k] = 1
        ca1[1, 3 * k] = -1
    sm1 = np.zeros(n_restr)
    
    ca2 = np.zeros((1, num_tau * p))
    if num_tau >= 2:
        ca2[0, 0] = 1
        ca2[0, p] = -1
    sm2 = np.zeros(1)
    
    ca3 = np.zeros((1, k * num_tau))
    if num_tau >= 2:
        ca3[0, 0] = 1
        ca3[0, k] = -1
    sm3 = np.zeros(1)
    
    for i in range(n_iter):
        if verbose and (i + 1) % 100 == 0:
            print(f"Iteration {i + 1}/{n_iter}")
        
        # Generate data (DGP from wald_tests_sim.e)
        yyy, xxx = qardl_ar2_sim(
            n, params.alpha, params.phi, params.rho,
            params.theta0, params.theta1
        )
        data = np.column_stack([yyy, xxx])
        
        try:
            # Estimate QARDL
            qaOut = qardl(data, p, q, tau)
            
            # Wald tests
            wt_b, pv_b = wtestlrb(qaOut.bigbt, qaOut.bigbt_cov, ca1, sm1, data)
            wt_p, pv_p = wtestsrp(qaOut.phi, qaOut.phi_cov, ca2, sm2, data)
            wt_g, pv_g = wtestsrg(qaOut.gamma, qaOut.gamma_cov, ca3, sm3, data)
            
            wald_beta[i] = wt_b
            wald_phi[i] = wt_p
            wald_gamma[i] = wt_g
            pv_beta[i] = pv_b
            pv_phi[i] = pv_p
            pv_gamma[i] = pv_g
            
        except Exception as e:
            if verbose:
                print(f"Iteration {i} failed: {e}")
            wald_beta[i] = np.nan
            wald_phi[i] = np.nan
            wald_gamma[i] = np.nan
            pv_beta[i] = np.nan
            pv_phi[i] = np.nan
            pv_gamma[i] = np.nan
    
    # Compute rejection rates
    valid_mask = ~np.isnan(pv_beta)
    n_valid = np.sum(valid_mask)
    
    rejection_rates = {
        'beta': {
            '0.01': np.mean(pv_beta[valid_mask] < 0.01),
            '0.05': np.mean(pv_beta[valid_mask] < 0.05),
            '0.10': np.mean(pv_beta[valid_mask] < 0.10),
        },
        'phi': {
            '0.01': np.mean(pv_phi[valid_mask] < 0.01),
            '0.05': np.mean(pv_phi[valid_mask] < 0.05),
            '0.10': np.mean(pv_phi[valid_mask] < 0.10),
        },
        'gamma': {
            '0.01': np.mean(pv_gamma[valid_mask] < 0.01),
            '0.05': np.mean(pv_gamma[valid_mask] < 0.05),
            '0.10': np.mean(pv_gamma[valid_mask] < 0.10),
        }
    }
    
    return {
        'wald_beta': wald_beta,
        'wald_phi': wald_phi,
        'wald_gamma': wald_gamma,
        'pv_beta': pv_beta,
        'pv_phi': pv_phi,
        'pv_gamma': pv_gamma,
        'rejection_rates': rejection_rates,
        'n_valid': n_valid,
        'n_iter': n_iter,
        'params': params
    }


def print_simulation_results(results: dict):
    """Print formatted simulation results."""
    print("=" * 60)
    print("Monte Carlo Simulation Results")
    print("=" * 60)
    print(f"Valid iterations: {results['n_valid']}/{results['n_iter']}")
    print("")
    print("Empirical Rejection Rates (Nominal Size)")
    print("-" * 60)
    print(f"{'Test':<15} {'1%':<10} {'5%':<10} {'10%':<10}")
    print("-" * 60)
    
    for test in ['beta', 'phi', 'gamma']:
        rates = results['rejection_rates'][test]
        print(f"{test:<15} {rates['0.01']:.3f}     {rates['0.05']:.3f}     {rates['0.10']:.3f}")
    
    print("=" * 60)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'DGPParams',
    'qardl_ar2_sim',
    'generate_qardl_data',
    'simulate_wald_tests',
    'print_simulation_results',
]
