"""
QARDL Utility Functions - GAUSS/MATLAB Compatible

Exact implementation matching Cho, Kim & Shin (2015) GAUSS code.

Author: Dr. Merwan Roudane
"""

import numpy as np
from scipy import stats
from scipy.optimize import linprog
from typing import Tuple, Optional, List
import warnings


def quantile_regression(y, X, tau, intercept=True, max_iter=10000):
    """Quantile regression via LP."""
    if not 0 < tau < 1:
        raise ValueError("tau must be between 0 and 1")
    y = np.asarray(y).flatten()
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    n = len(y)
    if intercept:
        X = np.column_stack([np.ones(n), X])
    k = X.shape[1]
    try:
        c = np.concatenate([np.zeros(k), np.zeros(k), tau * np.ones(n), (1 - tau) * np.ones(n)])
        A_eq = np.column_stack([X, -X, np.eye(n), -np.eye(n)])
        result = linprog(c, A_eq=A_eq, b_eq=y, bounds=[(0, None)] * (2*k + 2*n), method='highs')
        if result.success:
            beta = result.x[:k] - result.x[k:2*k]
        else:
            beta = np.linalg.lstsq(X, y, rcond=None)[0]
    except:
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
    return beta


def bandwidth_bofinger(tau, n):
    """Bofinger bandwidth - EXACT GAUSS formula."""
    z_tau = stats.norm.ppf(tau)
    phi_z = stats.norm.pdf(z_tau)
    return ((4.5 * phi_z ** 4) / (n * (2 * z_tau ** 2 + 1) ** 2)) ** 0.2


def bandwidth_hall_sheather(tau, n, alpha=0.05):
    """Hall-Sheather bandwidth - EXACT GAUSS formula."""
    z_alpha = stats.norm.ppf(1 - alpha / 2)
    z_tau = stats.norm.ppf(tau)
    phi_z = stats.norm.pdf(z_tau)
    return z_alpha ** (2/3) * ((1.5 * phi_z ** 2) / (n * (2 * z_tau ** 2 + 1))) ** (1/3)


def estimate_density(residuals, tau, bandwidth=None, n=None):
    """Density estimation - GAUSS uses negative residuals."""
    residuals = np.asarray(residuals).flatten()
    if n is None:
        n = len(residuals)
    if bandwidth is None:
        bandwidth = bandwidth_bofinger(tau, n)
    kernel_values = stats.norm.pdf(-residuals / bandwidth)
    return max(np.mean(kernel_values) / bandwidth, 1e-10)


def build_qardl_matrices(y, X, p, q, include_intercept=True):
    """
    Build QARDL design matrices - EXACT GAUSS qardl.src.
    Design = [1 | eei | xxi | yyi]
    """
    y = np.asarray(y).flatten()
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    nn = len(y)
    k0 = X.shape[1]
    
    # First differences: ee = [0; diff(X)]
    ee = np.zeros((nn, k0))
    ee[1:, :] = X[1:, :] - X[:-1, :]
    
    # eei: lagged differences (GAUSS lines 80-95)
    eei = np.zeros((nn - q, q * k0))
    for jj in range(k0):
        for ii in range(q):
            col_idx = ii + jj * q
            start_row = q - ii
            end_row = nn - ii
            eei[:, col_idx] = ee[start_row:end_row, jj]
    
    # xxi: current X levels
    xxi = X[q:nn, :]
    
    # yyi: lagged Y
    yyi = np.zeros((nn - p, p))
    for ii in range(p):
        yyi[:, ii] = y[p - 1 - ii:nn - 1 - ii]
    
    # Combine based on max(p, q)
    if p > q:
        diff = len(eei) - len(yyi)
        eei_trim = eei[diff:, :]
        xxi_trim = xxi[diff:, :]
        design_core = np.column_stack([eei_trim, xxi_trim, yyi])
        n_eff = len(yyi)
    else:
        diff = len(yyi) - len(xxi)
        yyi_trim = yyi[diff:, :]
        design_core = np.column_stack([eei, xxi, yyi_trim])
        n_eff = len(xxi)
    
    if include_intercept:
        design = np.column_stack([np.ones(n_eff), design_core])
    else:
        design = design_core
    
    y_dep = y[nn - n_eff:nn]
    return y_dep, design, n_eff


def ic_mean(data, p, q):
    """BIC for lag selection - EXACT GAUSS icmean.src."""
    y_dep, design, n = build_qardl_matrices(data[:, 0], data[:, 1:], p, q)
    try:
        bt = np.linalg.lstsq(design, y_dep, rcond=None)[0]
    except:
        return np.inf
    rh = (y_dep - design @ bt) ** 2
    return n * np.log(np.mean(rh)) + design.shape[1] * np.log(n)


def pq_order(data, p_max, q_max):
    """Select optimal (p, q) using BIC - EXACT GAUSS."""
    icb = np.full(p_max * q_max, np.inf)
    for jj1 in range(1, p_max + 1):
        for jj2 in range(1, q_max + 1):
            idx = p_max * (jj1 - 1) + jj2 - 1
            try:
                icb[idx] = ic_mean(data, jj1, jj2)
            except:
                pass
    lst = np.argmin(icb) + 1
    pst = int(np.ceil(lst / q_max))
    qst = lst - (pst - 1) * q_max
    return pst, qst


def compute_M_matrix(X, ee, q, k):
    """M matrix for long-run covariance - EXACT GAUSS."""
    nn = len(X)
    barw = np.zeros((nn - 1, q * k))
    for jj in range(q):
        barw[jj:nn-1, k*jj:k*(jj+1)] = ee[1:nn-jj, :]
    tw = np.column_stack([np.ones(nn - 1), barw])
    xx_sub = X[q:nn, :]
    tw_sub = tw[q-1:nn-1, :]
    xx_xx = xx_sub.T @ xx_sub
    xx_tw = xx_sub.T @ tw_sub
    tw_tw = tw_sub.T @ tw_sub
    try:
        tw_tw_inv = np.linalg.inv(tw_tw)
    except:
        tw_tw_inv = np.linalg.pinv(tw_tw)
    return (xx_xx - xx_tw @ tw_tw_inv @ tw_sub.T @ xx_sub) / ((nn - q) ** 2)


def get_coefficient_indices(p, q, k):
    """Get coefficient index ranges for GAUSS ordering."""
    return {
        'intercept': 0,
        'delta_x_start': 1, 'delta_x_end': 1 + q * k,
        'x_level_start': 1 + q * k, 'x_level_end': 1 + (q + 1) * k,
        'y_lag_start': 1 + (q + 1) * k, 'y_lag_end': 1 + (q + 1) * k + p,
        'n_total': 1 + (q + 1) * k + p
    }


def extract_long_run_beta(beta, p, q, k):
    """Long-run β = θ₀ / (1 - Σφ) - EXACT GAUSS."""
    idx = get_coefficient_indices(p, q, k)
    theta_0 = beta[idx['x_level_start']:idx['x_level_end']]
    phi = beta[idx['y_lag_start']:idx['y_lag_end']]
    sum_phi = np.sum(phi)
    if np.abs(1 - sum_phi) < 1e-10:
        warnings.warn("Near unit root")
        return theta_0 / 1e-10
    return theta_0 / (1 - sum_phi)


def extract_phi(beta, p, q, k):
    """Extract phi coefficients."""
    idx = get_coefficient_indices(p, q, k)
    return beta[idx['y_lag_start']:idx['y_lag_end']]


def extract_gamma(beta, p, q, k):
    """Extract gamma coefficients (= coefficients on x levels)."""
    idx = get_coefficient_indices(p, q, k)
    return beta[idx['x_level_start']:idx['x_level_end']]


def generate_param_names(p, q, k):
    """Parameter names in GAUSS order."""
    names = ['const']
    for j in range(k):
        for lag in range(q):
            names.append(f'Dx{j+1}_lag{lag}')
    for j in range(k):
        names.append(f'x{j+1}')
    for lag in range(1, p + 1):
        names.append(f'y_lag{lag}')
    return names


def prepare_data(y, X, standardize=False):
    """Prepare data in GAUSS format [y | X]."""
    y = np.asarray(y).flatten()
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    data = np.column_stack([y, X])
    data = data[~np.any(np.isnan(data), axis=1)]
    if standardize:
        data = (data - np.mean(data, axis=0)) / np.std(data, axis=0)
    return data
