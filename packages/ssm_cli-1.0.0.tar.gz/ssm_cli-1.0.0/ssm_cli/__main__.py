import sys
from ssm_cli.cli import cli


"""
This is the entry point for the CLI when called as a module. (python -m ssm_cli)
"""
if __name__ == "__main__":
    sys.exit(cli())