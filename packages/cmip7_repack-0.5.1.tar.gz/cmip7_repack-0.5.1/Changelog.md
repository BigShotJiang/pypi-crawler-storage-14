Version 0.5
-----------

**2025-11-12**

* New script: `check_cmip7_packing`
* Upated exit return codes from `cmip7repack`
