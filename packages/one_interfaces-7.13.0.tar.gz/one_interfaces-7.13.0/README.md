One_Interfaces
==============
Python bindings for One protobuf packages.

Supported File Formats
======================
Universal wheel file and source tar ball

Requirements
============
protobuf runtime

Usage
=====
pip install one_interfaces-<version>-py2.py3-none-any.whl
or once package has been published to pypi
pip install one_interfaces==<version>
Testing
=======

