from zettelkasten_mcp.server.mcp_server import ZettelkastenMcpServer

server = ZettelkastenMcpServer()
mcp = server.mcp