import requests

class UnisonRepo:
    BASE_URL = "https://aevi.lat"

    def download_file(self, dataset_id, output_filename):
        """
        Descarga un archivo desde la API de AEVI usando el ID del dataset.
        """
        url = f"{self.BASE_URL}/api/datasets/{dataset_id}/download"

        response = requests.get(url)

        if response.status_code != 200:
            raise Exception(f"Error descargando archivo: {response.text}")

        with open(output_filename, "wb") as f:
            f.write(response.content)

        return output_filename
