from .downloader import UnisonRepo

def download_file(dataset_id, output_filename):
    """
    Función simple para descargar datasets sin necesidad de instanciar la clase.
    """
    return UnisonRepo().download_file(dataset_id, output_filename)
