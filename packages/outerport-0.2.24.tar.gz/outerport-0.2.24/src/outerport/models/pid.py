from __future__ import annotations

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


class PidDetection(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    x0: int
    y0: int
    x1: int
    y1: int
    width: int
    height: int
    class_name: Optional[str] = None


class PidDetectionPage(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    page_number: int
    image_width: Optional[int] = None
    image_height: Optional[int] = None
    detections: List[PidDetection] = Field(default_factory=list)


class PidDetectionJob(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    component_id: str
    job_status_id: str
    status: str
    error_message: Optional[str] = None

    @property
    def pid_result_id(self) -> str:
        # Backwards compatibility with previous PID endpoints
        return self.component_id

    def is_done(self) -> bool:
        return self.status == "done"

    def is_error(self) -> bool:
        return self.status == "error"


class PidDetectionResult(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    component_id: str
    job_status_id: str
    status: str
    component_type: str
    label: str
    description: Optional[str] = None
    content: Optional[str] = None
    grounding: Optional[dict] = Field(default=None, alias="grounding")

    @property
    def pid_result_id(self) -> str:
        return self.component_id

    def _grounding_pages(self) -> List[dict]:
        grounding = self.grounding or {}
        return (
            grounding.get("pid_detection", {}).get("pages")  # type: ignore[return-value]
            or []
        )

    def detection_pages(self) -> List[PidDetectionPage]:
        pages: List[PidDetectionPage] = []
        for page in self._grounding_pages():
            page_detections: List[PidDetection] = []
            for det in page.get("detections", []) or []:
                try:
                    page_detections.append(PidDetection(**det))
                except Exception:
                    continue

            page_number = page.get("page_number")
            try:
                page_number = int(page_number) if page_number is not None else None
            except Exception:
                page_number = None

            pages.append(
                PidDetectionPage(
                    page_number=page_number or (len(pages) + 1),
                    image_width=page.get("image_width"),
                    image_height=page.get("image_height"),
                    detections=page_detections,
                )
            )

        return pages

    def detections(self) -> List[PidDetection]:
        """
        Convenience helper that flattens all detections from grounding pages.
        """
        results: List[PidDetection] = []

        for page in self.detection_pages():
            results.extend(page.detections)

        return results

    def detection_count(self) -> int:
        return len(self.detections())
