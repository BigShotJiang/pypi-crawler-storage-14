from __future__ import annotations

from typing import IO, Optional, Any, Dict

import aiohttp
import requests
import json

from outerport.models.pid import (
    PidDetectionJob,
    PidDetectionResult,
)
from outerport.resources.base_resource import BaseResource, AsyncBaseResource


def _resolve_file_name(file: IO[bytes], file_name: Optional[str]) -> str:
    """
    Helper to determine the filename for uploads.
    """
    if file_name:
        return file_name
    inferred = getattr(file, "name", None)
    if inferred:
        return inferred
    raise ValueError("File has no name")


class PidResource(BaseResource):
    """Resource wrapper for PID detection via the components endpoint."""

    def _submit_detection(
        self,
        file: IO[bytes],
        file_name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> PidDetectionJob:
        url = f"{self.client.base_url}/api/v0/components"
        params = {"component_type": "pid"}
        headers = self.client._form_headers()
        resolved_name = _resolve_file_name(file, file_name)

        data = {}
        if config:
            data["config"] = json.dumps(config)

        files = {"image": (resolved_name, file, "application/octet-stream")}
        resp = requests.post(
            url, headers=headers, params=params, data=data, files=files
        )
        resp.raise_for_status()
        data = resp.json()
        return PidDetectionJob(
            component_id=data["component_id"],
            job_status_id=data["job_status_id"],
            status=data["status"],
            error_message=data.get("error_message"),
        )

    def _get_component(self, component_id: str) -> dict:
        url = f"{self.client.base_url}/api/v0/components/{component_id}"
        headers = self.client._json_headers()
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        return resp.json()

    def _build_result(
        self, job_status_id: str, component: dict, status: str = "done"
    ) -> PidDetectionResult:
        return PidDetectionResult(
            component_id=component["id"],
            job_status_id=job_status_id,
            status=status,
            component_type=component.get("type", "pid"),
            label=component.get("label", "PID Component"),
            description=component.get("description"),
            content=component.get("content"),
            grounding=component.get("grounding"),
        )

    def detect_components(
        self,
        file: IO[bytes],
        file_name: Optional[str] = None,
        timeout: int = 100,
        poll_interval: float = 1.0,
        config: Optional[Dict[str, Any]] = None,
    ) -> PidDetectionResult:
        """
        Upload a PID diagram (image or PDF), wait for detection to complete, and return the resulting component.
        """
        job = self._submit_detection(file, file_name=file_name, config=config)
        self.client.job_statuses.wait_for_completion(
            job.job_status_id, timeout=timeout, poll_interval=poll_interval
        )
        component = self._get_component(job.component_id)
        return self._build_result(job.job_status_id, component)

    def get_result(self, component_id: str) -> PidDetectionResult:
        """
        Fetch detection results for a previously queued PID job by component ID.
        """
        component = self._get_component(component_id)
        # Job status is not included in this response; callers should track it separately.
        return self._build_result(
            job_status_id=component.get("job_status_id", ""),
            component=component,
            status=component.get("status", "unknown"),
        )


class AsyncPidResource(AsyncBaseResource):
    """Async resource wrapper for PID detection via the components endpoint."""

    async def _submit_detection(
        self,
        file: IO[bytes],
        file_name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> PidDetectionJob:
        url = f"{self.client.base_url}/api/v0/components"
        params = {"component_type": "pid"}
        headers = self.client._form_headers()
        resolved_name = _resolve_file_name(file, file_name)

        # ensure we start from beginning
        try:
            file.seek(0)
        except Exception:
            pass

        payload = aiohttp.FormData()
        payload.add_field(
            "image",
            file.read(),
            filename=resolved_name,
            content_type="application/octet-stream",
        )
        if config:
            payload.add_field("config", json.dumps(config))

        async with aiohttp.ClientSession() as session:
            async with session.post(
                url, headers=headers, params=params, data=payload
            ) as resp:
                resp.raise_for_status()
                data = await resp.json()
                return PidDetectionJob(
                    component_id=data["component_id"],
                    job_status_id=data["job_status_id"],
                    status=data["status"],
                    error_message=data.get("error_message"),
                )

    async def _get_component(self, component_id: str) -> dict:
        url = f"{self.client.base_url}/api/v0/components/{component_id}"
        headers = self.client._json_headers()

        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as resp:
                resp.raise_for_status()
                return await resp.json()

    def _build_result(
        self, job_status_id: str, component: dict, status: str = "done"
    ) -> PidDetectionResult:
        return PidDetectionResult(
            component_id=component["id"],
            job_status_id=job_status_id,
            status=status,
            component_type=component.get("type", "pid"),
            label=component.get("label", "PID Component"),
            description=component.get("description"),
            content=component.get("content"),
            grounding=component.get("grounding"),
        )

    async def detect_components(
        self,
        file: IO[bytes],
        file_name: Optional[str] = None,
        timeout: int = 100,
        poll_interval: float = 1.0,
        config: Optional[Dict[str, Any]] = None,
    ) -> PidDetectionResult:
        job = await self._submit_detection(file, file_name=file_name, config=config)
        await self.client.job_statuses.wait_for_completion(
            job.job_status_id, timeout=timeout, poll_interval=poll_interval
        )
        component = await self._get_component(job.component_id)
        return self._build_result(job.job_status_id, component)

    async def get_result(self, component_id: str) -> PidDetectionResult:
        component = await self._get_component(component_id)
        return self._build_result(
            job_status_id=component.get("job_status_id", ""),
            component=component,
            status=component.get("status", "unknown"),
        )
