# Requests to Nucleic Acid Knowledge-Base

![PyPI version](https://img.shields.io/pypi/v/python-nakb.svg)
[![Documentation Status](https://readthedocs.org/projects/python-nakb/badge/?version=latest)](https://python-nakb.readthedocs.io/en/latest/?version=latest)
[![Coverage Status](https://gitlab.com/MorfeoRenai/python-nakb/badges/main/coverage.svg)](https://gitlab.com/MorfeoRenai/python-nakb/-/commits/main)

Python package that makes custom requests to the NAKB site. The client offers both a **high-level interface** and a
**raw low-level interface**.

* PyPI package: https://pypi.org/project/python-nakb/
* Free software: MIT License
* Documentation: https://python-nakb.readthedocs.io.

## Features

* High-level Pythonic query interface;
* Raw low-level Solr access;
* Automatic filter construction;
* Clean pandas DataFrame output.

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
