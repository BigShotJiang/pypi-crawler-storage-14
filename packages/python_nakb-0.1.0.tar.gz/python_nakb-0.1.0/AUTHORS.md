# Credits

## Development Lead

- Alessandro Pandolfi <alessandro.pandolfi@protonmail.com>

# Contributors

None yet. Why not be the first?
