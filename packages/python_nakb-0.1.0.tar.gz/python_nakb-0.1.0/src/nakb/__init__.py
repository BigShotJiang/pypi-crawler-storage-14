"""Top-level package for : python-nakb"""

from nakb.core import NAKBClient

__author__ = """Alessandro Pandolfi"""
__email__ = "alessandro.pandolfi@protonmail.com"
__version__ = "0.1.0"

__all__ = ["NAKBClient"]
