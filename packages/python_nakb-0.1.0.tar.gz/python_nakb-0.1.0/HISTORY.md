# History

## 0.1.0 (2025-11-27)

* First release on PyPI.
