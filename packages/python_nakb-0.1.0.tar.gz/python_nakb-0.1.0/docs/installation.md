# Installation

## Stable release

To install `python-nakb`, run this command in your terminal:

```sh
uv add python-nakb
```

Or if you prefer to use `pip`:

```sh
pip install python-nakb
```

## From source

The source files for `python-nakb` can be downloaded from the [GitLab repo](https://gitlab.com/MorfeoRenai/python-nakb).

You can either clone the public repository:

```sh
git clone git://gitlab.com/MorfeoRenai/python-nakb
```

Or download the [tarball](https://gitlab.com/MorfeoRenai/python-nakb/tarball/main):

```sh
curl -OJL https://gitlab.com/MorfeoRenai/python-nakb/tarball/main
```

Once you have a copy of the source, you can install it with:

```sh
cd python-nakb
make install
```
