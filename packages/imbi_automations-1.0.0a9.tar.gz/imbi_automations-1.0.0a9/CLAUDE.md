@AGENTS.md

- Remember to check for updates in AGENTS.md when making changes. This file is for AI Assistants like Claude Code so I expect that you maintain it as well.
