import pandas as pd
import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt
from ta.volatility import AverageTrueRange
from ta.trend import EMAIndicator, SuperTrend
from ta.momentum import RSIIndicator
from ta.volume import VolumeWeightedAveragePrice

# Configuración global para Matplotlib (estética de gráficos)
plt.style.use('seaborn-v0_8-darkgrid')

# --- 1. CLASE BASE DE ESTRATEGIA ---

class BaseStrategy:
    """
    Clase base para todas las estrategias de trading.
    Define la estructura mínima y el método apply_strategy.
    """
    def __init__(self, name="Base Strategy"):
        self.name = name

    def generate_signals(self, df):
        """
        Método a sobrescribir por cada estrategia.
        Debe tomar un DataFrame de precios y retornar las señales de trading.
        1: Compra (Long), -1: Venta (Short), 0: Mantener.
        """
        raise NotImplementedError("El método generate_signals debe ser implementado por la subclase.")

    def __str__(self):
        return self.name

# --- 2. IMPLEMENTACIÓN DE ESTRATEGIAS ESPECÍFICAS ---

class EMA_Cross(BaseStrategy):
    """Estrategia de Cruce de Medias Móviles Exponenciales (EMA)."""
    def __init__(self, short=9, long=21):
        super().__init__(f"EMA Cross ({short}/{long})")
        self.short = short
        self.long = long

    def generate_signals(self, df):
        # 1. Calcular EMAs
        df['EMA_Short'] = EMAIndicator(close=df['Close'], window=self.short, fillna=False).ema_indicator()
        df['EMA_Long'] = EMAIndicator(close=df['Close'], window=self.long, fillna=False).ema_indicator()

        # 2. Generar Señales:
        # Compra (1) cuando la EMA corta cruza por encima de la EMA larga.
        # Venta (-1) cuando la EMA corta cruza por debajo de la EMA larga.
        df['Signal'] = np.where(
            (df['EMA_Short'].shift(1) < df['EMA_Long'].shift(1)) & (df['EMA_Short'] > df['EMA_Long']),
            1, # Compra
            0
        )
        df['Signal'] = np.where(
            (df['EMA_Short'].shift(1) > df['EMA_Long'].shift(1)) & (df['EMA_Short'] < df['EMA_Long']),
            -1, # Venta
            df['Signal']
        )
        # Asegurarse de que el primer valor sea 0 antes de la señal
        df['Position'] = df['Signal'].replace(to_replace=0, method='ffill').fillna(0)
        return df

class RSI_MeanReversion(BaseStrategy):
    """Estrategia de Reversión a la Media basada en RSI."""
    def __init__(self, window=14, entry_low=30, exit_high=70):
        super().__init__(f"RSI Mean Reversion (Low {entry_low}/High {exit_high})")
        self.window = window
        self.entry_low = entry_low
        self.exit_high = exit_high

    def generate_signals(self, df):
        # 1. Calcular RSI
        df['RSI'] = RSIIndicator(close=df['Close'], window=self.window, fillna=False).rsi()

        # 2. Generar Señales:
        # Compra (1) cuando RSI < entry_low (sobreventa)
        # Cierre de posición (0) cuando RSI > exit_high o si se alcanza un nivel de Take Profit (simplificado)
        df['Signal'] = 0
        df.loc[df['RSI'] < self.entry_low, 'Signal'] = 1 # Señal de Compra
        df.loc[df['RSI'] > self.exit_high, 'Signal'] = -1 # Señal de Venta/Cierre

        # Lógica de posición: tomar la señal actual para la posición.
        df['Position'] = df['Signal'].replace(to_replace=0, method='ffill').fillna(0)
        return df

class Breakout_ATR(BaseStrategy):
    """Estrategia de Ruptura (Breakout) basada en ATR."""
    def __init__(self, atr_window=14, multiplier=1.5):
        super().__init__(f"ATR Breakout (Mult {multiplier})")
        self.atr_window = atr_window
        self.multiplier = multiplier

    def generate_signals(self, df):
        # 1. Calcular ATR
        df['ATR'] = AverageTrueRange(high=df['High'], low=df['Low'], close=df['Close'], window=self.atr_window, fillna=False).average_true_range()
        df['Upper_Band'] = df['Close'].shift(1) + (self.multiplier * df['ATR'].shift(1))
        df['Lower_Band'] = df['Close'].shift(1) - (self.multiplier * df['ATR'].shift(1))

        # 2. Generar Señales:
        # Compra (1) si el precio rompe la banda superior (Breakout)
        df['Signal'] = np.where(df['Close'] > df['Upper_Band'], 1, 0)
        # Venta (-1) si el precio rompe la banda inferior
        df['Signal'] = np.where(df['Close'] < df['Lower_Band'], -1, df['Signal'])

        df['Position'] = df['Signal'].replace(to_replace=0, method='ffill').fillna(0)
        return df

class VWAP_Reversal(BaseStrategy):
    """Estrategia de Reversión al VWAP (Precio Promedio Ponderado por Volumen)."""
    def __init__(self):
        super().__init__("VWAP Reversal")

    def generate_signals(self, df):
        # 1. Calcular VWAP (solo funciona si se tienen datos intradía, lo calculamos sobre la sesión disponible)
        df['VWAP'] = VolumeWeightedAveragePrice(
            high=df['High'], low=df['Low'], close=df['Close'], volume=df['Volume'], window=1, fillna=False
        ).vwap

        # 2. Generar Señales (Reversión a la media):
        # Compra (1) cuando el precio está por debajo del VWAP y empieza a subir (simplificado)
        df['Signal'] = np.where(
            (df['Close'] < df['VWAP']) & (df['Close'] > df['Open']), 1, 0
        )
        # Venta (-1) cuando el precio está por encima del VWAP y empieza a caer (simplificado)
        df['Signal'] = np.where(
            (df['Close'] > df['VWAP']) & (df['Close'] < df['Open']), -1, df['Signal']
        )

        df['Position'] = df['Signal'].replace(to_replace=0, method='ffill').fillna(0)
        return df

class SuperTrendStrategy(BaseStrategy):
    """Estrategia de SuperTrend."""
    def __init__(self, period=10, multiplier=3):
        super().__init__(f"SuperTrend ({period}x{multiplier})")
        self.period = period
        self.multiplier = multiplier

    def generate_signals(self, df):
        # 1. Calcular SuperTrend
        st = SuperTrend(
            high=df['High'], low=df['Low'], close=df['Close'], window=self.period, multiplier=self.multiplier, fillna=False
        )
        df['SuperTrend'] = st.supertrend()
        df['SuperTrend_Direction'] = st.supertrend_indicator() # 1: Uptrend, -1: Downtrend

        # 2. Generar Señales:
        # Compra (1) cuando la dirección cambia de -1 (Bajista) a 1 (Alcista)
        df['Signal'] = np.where(
            (df['SuperTrend_Direction'].shift(1) == -1) & (df['SuperTrend_Direction'] == 1),
            1, # Compra
            0
        )
        # Venta (-1) cuando la dirección cambia de 1 (Alcista) a -1 (Bajista)
        df['Signal'] = np.where(
            (df['SuperTrend_Direction'].shift(1) == 1) & (df['SuperTrend_Direction'] == -1),
            -1, # Venta
            df['Signal']
        )

        df['Position'] = df['SuperTrend_Direction']
        return df

class BasicMarketMaker(BaseStrategy):
    """
    Modelo Básico de Market Maker (MM) - Simula el spread
    Asume que el MM intenta comprar bajo y vender alto, o capitalizar
    en movimientos de rango. Utiliza una media móvil como precio de referencia.
    """
    def __init__(self, spread_factor=0.001, window=50):
        super().__init__(f"Basic Market Maker (Spread {spread_factor*100:.2f}%)")
        self.spread_factor = spread_factor
        self.window = window

    def generate_signals(self, df):
        # Usamos una EMA como precio justo (Fair Value)
        df['Fair_Value'] = EMAIndicator(close=df['Close'], window=self.window, fillna=False).ema_indicator()
        # Niveles de Bid (Compra) y Ask (Venta)
        df['Bid_Level'] = df['Fair_Value'] * (1 - self.spread_factor)
        df['Ask_Level'] = df['Fair_Value'] * (1 + self.spread_factor)

        # Si el precio toca el Bid (Compramos barato), señal de Compra
        df['Signal'] = np.where(df['Low'] <= df['Bid_Level'], 1, 0)
        # Si el precio toca el Ask (Vendemos caro), señal de Venta/Cierre
        df['Signal'] = np.where(df['High'] >= df['Ask_Level'], -1, df['Signal'])

        # Para un backtest simple, la 'Position' simplemente refleja la última señal,
        # pero en un MM real, las órdenes se ejecutan en los niveles Bid/Ask.
        # Aquí simplificamos el backtest para mostrar dónde ocurrirían las transacciones.
        df['Position'] = df['Signal'].replace(to_replace=0, method='ffill').fillna(0)
        return df

class GridTrading(BaseStrategy):
    """
    Estrategia de Grid Trading (Basada en la estructura de precios).
    Compra en niveles inferiores y vende en niveles superiores.
    """
    def __init__(self, num_grids=5, range_percent=0.05):
        super().__init__(f"Grid Trading ({num_grids} Grids)")
        self.num_grids = num_grids
        self.range_percent = range_percent

    def generate_signals(self, df):
        # Usamos la última media móvil como centro (simplificación)
        center_price = df['Close'].iloc[-100:].mean()
        grid_step = center_price * self.range_percent / self.num_grids

        # Definir las cuadrículas
        grid_levels = [center_price + (i - self.num_grids // 2) * grid_step for i in range(self.num_grids + 1)]

        df['Signal'] = 0
        df['Position'] = 0

        # Lógica simplificada:
        # 1. Si el precio toca un nivel de grid y está por debajo del centro, Compra (1).
        # 2. Si el precio toca un nivel de grid y está por encima del centro, Venta/Cierre (-1).
        
        # Esta es una simulación de señal. El grid trading real requiere gestionar
        # múltiples órdenes pendientes simultáneamente.
        for i in range(1, self.num_grids // 2 + 1):
            # Compras por debajo del centro
            buy_level = grid_levels[self.num_grids // 2 - i]
            df.loc[df['Low'] <= buy_level, 'Signal'] = 1
            # Ventas/Cierre por encima del centro
            sell_level = grid_levels[self.num_grids // 2 + i]
            df.loc[df['High'] >= sell_level, 'Signal'] = -1

        df['Position'] = df['Signal'].replace(to_replace=0, method='ffill').fillna(0)
        return df

class TurtleTrendFollowing(BaseStrategy):
    """Estrategia de Seguimiento de Tendencia tipo Tortuga (Donchian Channel Breakout)."""
    def __init__(self, entry_window=20, exit_window=10):
        super().__init__(f"Turtle Trend Following (Entry {entry_window}/Exit {exit_window})")
        self.entry_window = entry_window
        self.exit_window = exit_window

    def generate_signals(self, df):
        # 1. Calcular Canales Donchian
        df['High_Entry'] = df['High'].rolling(window=self.entry_window).max().shift(1)
        df['Low_Entry'] = df['Low'].rolling(window=self.entry_window).min().shift(1)
        df['High_Exit'] = df['High'].rolling(window=self.exit_window).max().shift(1)
        df['Low_Exit'] = df['Low'].rolling(window=self.exit_window).min().shift(1)

        df['Signal'] = 0
        df['Position'] = 0

        # 2. Señal de Entrada Larga: Precio cruza el máximo de N días
        df['Signal'] = np.where(df['Close'] > df['High_Entry'], 1, 0)
        # 3. Señal de Salida Larga: Precio cruza el mínimo de M días (o cambio de tendencia)
        # Esto simplifica la lógica de las Tortugas, que es más compleja (uso de N)
        df.loc[(df['Position'].shift(1) == 1) & (df['Close'] < df['Low_Exit']), 'Signal'] = -1

        # 4. Señal de Entrada Corta (Inversa): Precio cruza el mínimo de N días
        df.loc[df['Close'] < df['Low_Entry'], 'Signal'] = -1
        # 5. Señal de Salida Corta: Precio cruza el máximo de M días (o cambio de tendencia)
        df.loc[(df['Position'].shift(1) == -1) & (df['Close'] > df['High_Exit']), 'Signal'] = 1

        # Llenar la posición actual
        df['Position'] = df['Signal'].replace(to_replace=0, method='ffill').fillna(0)
        return df


# --- 3. CLASE DE BACKTESTING ---

class Backtest:
    """
    Clase para ejecutar el backtest de una estrategia, calcular métricas y graficar.
    """
    def __init__(self, strategy: BaseStrategy, ticker: str, timeframe: str = '1d', start='2020-01-01', end=None, initial_capital=10000, risk_free_rate=0.02):
        self.strategy = strategy
        self.ticker = ticker
        self.timeframe = timeframe
        self.start = start
        self.end = end
        self.initial_capital = initial_capital
        # Nuevo parámetro para la tasa libre de riesgo (2% anual por defecto)
        self.risk_free_rate = risk_free_rate 
        self.data = None
        self.results = None
        print(f"Backtest inicializado para {strategy} en {ticker} ({timeframe})")


    def _load_data(self):
        """Carga datos históricos usando yfinance."""
        print(f"Cargando datos para {self.ticker}...")
        try:
            # yfinance usa 'interval' en lugar de 'timeframe'
            df = yf.download(self.ticker, start=self.start, end=self.end, interval=self.timeframe, progress=False)
            if df.empty:
                raise ValueError("No se pudieron cargar datos. Verifica el ticker y el timeframe.")
            df.columns = [col.capitalize() for col in df.columns] # Asegura que las columnas sean Mayúscula Inicial (Close, Open, etc.)
            self.data = df
            print(f"Datos cargados. {len(df)} barras desde {df.index.min().date()} hasta {df.index.max().date()}.")
        except Exception as e:
            print(f"ERROR al cargar datos: {e}")
            self.data = None

    def _calculate_metrics(self):
        """Calcula el rendimiento de la estrategia, incluyendo el Ratio de Sharpe."""
        df = self.data.copy()

        # 1. Rendimiento del activo (Buy and Hold)
        df['Returns'] = df['Close'].pct_change()
        df['Cumulative_BH'] = (1 + df['Returns']).cumprod().fillna(1)
        df['Cumulative_BH'] = df['Cumulative_BH'] * self.initial_capital # Capital de Buy & Hold

        # 2. Rendimiento de la estrategia
        # 'Position' es 1 (Long), -1 (Short) o 0 (Flat)
        df['Strategy_Returns'] = df['Returns'] * df['Position'].shift(1)
        df['Cumulative_Strategy'] = (1 + df['Strategy_Returns']).cumprod().fillna(1)
        df['Cumulative_Strategy'] = df['Cumulative_Strategy'] * self.initial_capital # Capital de Estrategia

        # Métricas de rendimiento
        total_return_strategy = (df['Cumulative_Strategy'].iloc[-1] / self.initial_capital - 1) * 100
        total_return_bh = (df['Cumulative_BH'].iloc[-1] / self.initial_capital - 1) * 100
        
        # Retorno anualizado (simplificado)
        days = (df.index[-1] - df.index[0]).days
        years = days / 365.25 if days > 0 else 1
        
        annualized_return_strategy = ((1 + total_return_strategy / 100) ** (1/years) - 1) * 100
        annualized_return_bh = ((1 + total_return_bh / 100) ** (1/years) - 1) * 100
        
        # Max Drawdown
        df['Peak_Strategy'] = df['Cumulative_Strategy'].cummax()
        max_drawdown_strategy = ((df['Cumulative_Strategy'] - df['Peak_Strategy']) / df['Peak_Strategy']).min() * 100

        # --- CÁLCULO DEL RATIO DE SHARPE ---
        strategy_returns = df['Strategy_Returns'].dropna()

        # Factor de anualización (252 días hábiles en mercados de valores)
        N = 252 
        
        # Tasa libre de riesgo diaria
        # Convertimos la tasa anual (ej: 0.02) a diaria.
        rf_daily = (1 + self.risk_free_rate) ** (1/N) - 1 if self.risk_free_rate != 0 else 0
        
        # Rendimiento promedio diario y volatilidad diaria
        avg_daily_return = strategy_returns.mean()
        std_daily_return = strategy_returns.std()
        
        # Rendimiento promedio diario en exceso (vs riesgo libre)
        excess_daily_return = avg_daily_return - rf_daily
        
        # Sharpe Ratio (anualizado)
        if std_daily_return != 0:
            # Fórmula de Sharpe: (Retorno Anualizado - Rf) / Volatilidad Anualizada
            sharpe_ratio = (excess_daily_return * N) / (std_daily_return * np.sqrt(N))
        else:
            sharpe_ratio = np.inf
        # -----------------------------------

        print("\n--- Resultados del Backtest ---")
        print(f"Estrategia: {self.strategy}")
        print(f"Capital Inicial: ${self.initial_capital:,.2f}")
        print(f"Periodo: {df.index[0].date()} a {df.index[-1].date()}")
        print("-" * 30)
        print(f"Retorno Total (Estrategia): {total_return_strategy:.2f}%")
        print(f"Retorno Anualizado (Estrategia): {annualized_return_strategy:.2f}%")
        print(f"Max Drawdown (Estrategia): {max_drawdown_strategy:.2f}%")
        print(f"Ratio de Sharpe (anualizado): {sharpe_ratio:.2f} (Rf={self.risk_free_rate*100:.2f}%)") # Nuevo print
        print("-" * 30)
        print(f"Retorno Total (Buy & Hold): {total_return_bh:.2f}%")
        print(f"Retorno Anualizado (Buy & Hold): {annualized_return_bh:.2f}%")
        print("-" * 30)

        self.results = df

    def run(self):
        """Ejecuta el proceso de backtesting: carga datos, aplica estrategia y calcula métricas."""
        self._load_data()

        if self.data is None:
            return

        print("Aplicando estrategia y generando señales...")
        # Aplica la estrategia para obtener las columnas 'Signal' y 'Position'
        self.data = self.strategy.generate_signals(self.data)
        
        # Limpia filas iniciales con NaNs introducidos por indicadores
        self.data.dropna(subset=['Position'], inplace=True)
        self.data.fillna(0, inplace=True) # Rellena otros NaNs (ej: primeras filas de ATR, EMA, etc.)

        # Recalcula métricas
        self._calculate_metrics()


    def plot(self):
        """Genera un gráfico comparando el rendimiento de la estrategia vs Buy & Hold."""
        if self.results is None or self.results.empty:
            print("No hay resultados para graficar. Ejecuta .run() primero.")
            return

        fig, ax = plt.subplots(figsize=(14, 7))
        
        # Gráfico de Rendimiento Acumulado
        ax.plot(self.results.index, self.results['Cumulative_Strategy'], label=f"Estrategia: {self.strategy}", color='darkblue', linewidth=2)
        ax.plot(self.results.index, self.results['Cumulative_BH'], label=f"{self.ticker} Buy & Hold", color='grey', linestyle='--', linewidth=1)
        
        # Marcar puntos de Compra (Señal == 1)
        buy_signals = self.results[self.results['Signal'] == 1]
        ax.plot(buy_signals.index, buy_signals['Close'], '^', markersize=8, color='green', label='Compra', alpha=0.7)
        
        # Marcar puntos de Venta/Cierre (Señal == -1)
        sell_signals = self.results[self.results['Signal'] == -1]
        ax.plot(sell_signals.index, sell_signals['Close'], 'v', markersize=8, color='red', label='Venta/Cierre', alpha=0.7)

        # Formato del gráfico
        ax.set_title(f"Backtest de Rendimiento: {self.strategy} vs. Buy & Hold en {self.ticker}", fontsize=16)
        ax.set_xlabel("Fecha", fontsize=12)
        ax.set_ylabel("Capital (€/USD)", fontsize=12)
        ax.legend(loc='upper left', fontsize=10)
        
        # Agregar un segundo eje para el precio de cierre (más útil que el capital en sí para ver señales)
        # Esto requiere un pequeño ajuste si el capital es muy diferente al precio
        ax2 = ax.twinx()
        ax2.plot(self.results.index, self.results['Close'], label='Precio de Cierre', color='purple', alpha=0.3)
        ax2.set_ylabel("Precio de Cierre (USD)", color='purple', alpha=0.7)

        plt.tight_layout()
        plt.show()

# --- USO DE EJEMPLO DE LA LIBRERÍA (La parte 'Plug & Play') ---
if __name__ == '__main__':
    # Este bloque solo se ejecuta si corres src_trading.py directamente
    print("Ejecutando demostración de la librería (simulando example_usage.py)...")

    # 1. EMA Crossover
    print("\n--- Demostración 1: EMA Crossover ---")
    strategy_ema = EMA_Cross(short=9, long=21)
    # Usaremos un periodo de tiempo más corto para los ejemplos rápidos (1 año)
    # Ahora podemos pasar una tasa libre de riesgo, por ejemplo 4%
    bt_ema = Backtest(strategy_ema, ticker='BTC-USD', timeframe='1h', start='2024-01-01', end='2025-01-01', risk_free_rate=0.04)
    bt_ema.run()
    # bt_ema.plot() # Descomenta para ver el gráfico

    # 2. RSI Mean Reversion
    print("\n--- Demostración 2: RSI Mean Reversion ---")
    strategy_rsi = RSI_MeanReversion(entry_low=30, exit_high=75)
    bt_rsi = Backtest(strategy_rsi, ticker='AAPL', timeframe='1d', start='2023-01-01')
    bt_rsi.run()
    # bt_rsi.plot() # Descomenta para ver el gráfico
    
    # 3. SuperTrend
    print("\n--- Demostración 3: SuperTrend ---")
    strategy_st = SuperTrendStrategy(period=10, multiplier=3.0)
    bt_st = Backtest(strategy_st, ticker='ETH-USD', timeframe='4h', start='2024-01-01')
    bt_st.run()
    # bt_st.plot() # Descomenta para ver el gráfico
    
    print("\nDemostración finalizada. Edita example_usage.py para probar las demás estrategias.")