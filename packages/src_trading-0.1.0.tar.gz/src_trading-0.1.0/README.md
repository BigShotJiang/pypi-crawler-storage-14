🐍 Trading Backtester Lib

Una librería simple y modular en Python diseñada para facilitar el backtesting rápido de diversas estrategias de trading con datos de mercados reales.

✨ Características

Estructura Modular: Fácil de extender con nuevas estrategias personalizadas (clase BaseStrategy).

Datos Reales: Utiliza yfinance para obtener datos de acciones, criptomonedas e índices.

Métricas de Rendimiento: Calcula Retorno Total, Drawdown Máximo, y el Ratio de Sharpe (ajustado al riesgo).

Estrategias Incluidas: Cruce de Medias Móviles, Reversión a la Media con RSI, SuperTrend, y más.

🚀 Instalación

Asegúrate de tener Python 3.8 o superior.

# 1. Instalar las dependencias de la librería
!pip install pandas numpy yfinance matplotlib python-ta

# 2. Descargar el archivo src_trading.py y el ejemplo de uso



🛠️ Uso Básico

Una vez instaladas las dependencias y con el archivo src_trading.py en tu directorio, puedes importar y ejecutar un backtest fácilmente:

from src_trading import EMA_Cross, Backtest

# 1. Definir la estrategia
mi_estrategia = EMA_Cross(short=10, long=30)

# 2. Inicializar el backtest
# Ticker: AAPL, Intervalo: 1 día, Tasa Libre de Riesgo: 3% anual
backtest_runner = Backtest(
    strategy=mi_estrategia, 
    ticker='AAPL', 
    timeframe='1d', 
    start='2021-01-01',
    risk_free_rate=0.03 # Usado para el Ratio de Sharpe
)

# 3. Ejecutar y obtener resultados
backtest_runner.run()

# 4. (Opcional) Graficar el rendimiento vs. Buy & Hold
# backtest_runner.plot() 

