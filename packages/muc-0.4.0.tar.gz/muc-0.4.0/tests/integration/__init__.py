# Copyright (c) 2025. All rights reserved.
"""Integration tests for MUC Soundboard CLI."""
