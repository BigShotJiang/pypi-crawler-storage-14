# Copyright (c) 2025. All rights reserved.
"""Test fixtures for MUC Soundboard."""
