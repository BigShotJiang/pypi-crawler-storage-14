from pathlib import Path
from typing import Iterable, Iterator, Optional, Sequence

import chardet


def safe_read_text(file_path: Path, max_bytes: Optional[int] = None) -> str:
    """
    Read text from file with encoding detection and optional size cap.
    """
    try:
        with open(file_path, "rb") as f:
            raw_data = f.read(max_bytes)

        detected = chardet.detect(raw_data or b"")
        encoding = detected.get("encoding") or "utf-8"
        try:
            return (raw_data or b"").decode(encoding)
        except Exception:
            return (raw_data or b"").decode("utf-8", errors="replace")
    except Exception as e:
        return f"[Error reading file: {e}]"


def list_files(
    root: Path,
    extensions: Optional[Sequence[str]] = None,
    include_hidden: bool = False,
    ignore_patterns: Optional[Sequence[str]] = None,
) -> Iterator[Path]:
    """
    Yield files under root filtered by extension and simple ignore rules.
    """
    normalized_exts = None
    if extensions:
        normalized_exts = {ext.lower() if ext.startswith(".") else f".{ext.lower()}" for ext in extensions}

    for path in root.iterdir():
        if path.name.startswith(".") and not include_hidden:
            continue
        if path.is_file():
            if normalized_exts and path.suffix.lower() not in normalized_exts:
                continue
            if _matches_patterns(path, ignore_patterns):
                continue
            yield path


def _matches_patterns(path: Path, patterns: Optional[Sequence[str]]) -> bool:
    if not patterns:
        return False
    lowered = path.name.lower()
    for pattern in patterns:
        p = pattern.lower()
        if p and p in lowered:
            return True
    return False
