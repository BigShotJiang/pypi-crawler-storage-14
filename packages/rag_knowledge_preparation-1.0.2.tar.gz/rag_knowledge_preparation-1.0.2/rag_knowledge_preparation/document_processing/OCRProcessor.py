from __future__ import annotations

import asyncio
import base64
import io
import logging
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from langchain_core.messages import HumanMessage
from pdf2image import convert_from_bytes
from PIL import Image

from .DocumentProcessingConfig import ProcessingConfig
from ..utils.CustomExceptions import ConfigurationError, ConversionError
from ..utils.GeminiClient import GeminiClientConfig, create_chat_model
from ..utils.RetryBackoff import async_run_with_retry

logger = logging.getLogger(__name__)


class GeminiOCRProcessor:
    """Gemini-based OCR pipeline that mirrors the Colab workflow for PDF OCR."""

    def __init__(self, config: ProcessingConfig, api_key: Optional[str] = None) -> None:
        self.config = config
        self._client_config = GeminiClientConfig(
            model_name=self.config.model_name,
            api_key=api_key,
            temperature=self.config.temperature,
            max_output_tokens=self.config.max_output_tokens,
        )

        try:
            self.api_key = self._client_config.resolve_api_key()
            self.llm = create_chat_model(self._client_config)
        except Exception as exc:  # noqa: BLE001
            raise ConfigurationError(str(exc)) from exc

    def convert_pdf_to_markdown(self, document_path: Path) -> str:
        """Synchronously convert a PDF to Markdown."""
        coro = self.convert_pdf_to_markdown_async(document_path)
        return self._run_coroutine(coro)

    async def convert_pdf_to_markdown_async(self, document_path: Path) -> str:
        """Asynchronously convert a PDF to Markdown following the Gemini OCR recipe."""
        try:
            pdf_bytes = document_path.read_bytes()
        except Exception as e:
            raise ConversionError(f"Unable to read document bytes: {e}") from e

        try:
            logger.info("Rasterizing PDF %s at %sdpi", document_path, self.config.dpi)
            images = convert_from_bytes(pdf_bytes, dpi=self.config.dpi, fmt="PNG")
        except Exception as e:
            raise ConversionError(f"Failed to rasterize PDF: {e}") from e

        return await self._convert_images_async(images, title=document_path.stem)

    def convert_images_to_markdown(self, images: List[Image.Image], title: str) -> str:
        """Synchronously convert a list of images to Markdown."""
        coro = self._convert_images_async(images, title=title)
        return self._run_coroutine(coro)

    async def _convert_images_async(self, images: List[Image.Image], title: str) -> str:
        total_pages = len(images)
        selected_pages = parse_page_selection(self.config.page_selection, total_pages)
        if not selected_pages:
            raise ConversionError("No pages selected after applying page selection.")
        logger.info("Total pages: %s | selected: %s", total_pages, selected_pages)

        try:
            page_results = await self._process_all(images, selected_pages)
        except Exception as e:
            raise ConversionError(f"Failed during OCR processing: {e}") from e

        page_results.sort(key=lambda x: x[0])
        logger.info("Completed OCR for %s pages", len(page_results))
        return merge_markdown(page_results, title=title)

    async def _process_all(
        self, images: List[Image.Image], selected_pages: List[int]
    ) -> List[Tuple[int, str]]:
        semaphore = asyncio.Semaphore(self.config.parallel_concurrency)
        tasks = [
            asyncio.create_task(self._process_page(images, idx, semaphore))
            for idx in selected_pages
        ]
        results: List[Tuple[int, str]] = []
        for fut in asyncio.as_completed(tasks):
            results.append(await fut)
        return results

    async def _process_page(
        self, images: List[Image.Image], page_index: int, semaphore: asyncio.Semaphore
    ) -> Tuple[int, str]:
        data_url = _pil_to_b64_png(images[page_index - 1])
        message = HumanMessage(
            content=[
                {"type": "text", "text": self.config.prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]
        )

        async def _invoke() -> str:
            response = await self.llm.ainvoke([message])
            text = (response.content or "").strip()
            if not text:
                raise RuntimeError("Empty response from Gemini.")
            return text

        async with semaphore:
            text = await async_run_with_retry(
                _invoke,
                max_retries=self.config.max_retries,
                min_wait=1.0,
                max_wait=10.0,
            )
            return page_index, text

    @staticmethod
    def _run_coroutine(coro: Any) -> Any:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(coro)

        result: Dict[str, Any] = {}
        error: Dict[str, BaseException] = {}

        def runner() -> None:
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            try:
                result["value"] = new_loop.run_until_complete(coro)
            except BaseException as exc:  # noqa: BLE001
                error["value"] = exc
            finally:
                new_loop.close()

        thread = threading.Thread(target=runner, daemon=True)
        thread.start()
        thread.join()

        if error:
            raise error["value"]  # type: ignore[misc]
        if "value" not in result:
            raise ConversionError("Failed to execute OCR coroutine.")
        return result["value"]


def parse_page_selection(spec: Optional[str], total_pages: int) -> List[int]:
    """Parse a page selection string into 1-based page indices."""
    if not spec:
        return list(range(1, total_pages + 1))

    wanted = set()
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            start, end = chunk.split("-", 1)
            start, end = int(start), int(end)
            wanted.update(range(start, end + 1))
        else:
            wanted.add(int(chunk))
    return [i for i in sorted(wanted) if 1 <= i <= total_pages]


def merge_markdown(page_texts: List[Tuple[int, str]], title: str) -> str:
    """Merge page-by-page markdown with explicit page headers."""
    lines: List[str] = []
    for idx, txt in page_texts:
        lines.append(f"## Page {idx}\n")
        lines.append(txt.strip())
        lines.append("\n")
    return "\n".join(lines)


def _pil_to_b64_png(img: Image.Image) -> str:
    """Convert a PIL image to a base64-encoded PNG data URL."""
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{b64}"
