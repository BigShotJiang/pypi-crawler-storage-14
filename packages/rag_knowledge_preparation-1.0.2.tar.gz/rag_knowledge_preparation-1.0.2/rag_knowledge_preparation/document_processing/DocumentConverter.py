from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Union, List

from .DocumentProcessingConfig import ProcessingConfig, get_config
from .ConversionService import (
    DocumentConversionService,
    _DocumentConversionService,
    DocumentInputs,
    normalize_document_inputs,
    find_supported_documents,
)
from .OCRProcessor import GeminiOCRProcessor
from ..utils.CustomExceptions import (
    ConfigurationError,
    DocumentNotFoundError,
)

logger = logging.getLogger(__name__)


def convert_document_to_markdown(
    document_path: Union[str, Path],
    processing_preset: str = "standard",
    api_key: Optional[str] = None,
    **preset_overrides: Any,
) -> str:
    """
    Convert a document to Markdown.

    - PDFs and images are processed with Gemini OCR.
    - Text/Markdown files are read directly.
    - DOCX files are parsed and rendered to Markdown.

    Args:
        document_path: Path to the document.
        processing_preset: Name of the processing configuration preset.
        api_key: Optional Google API key. Defaults to GOOGLE_API_KEY env var.
        **preset_overrides: Optional overrides for the selected preset.

    Returns:
        Markdown content extracted from the document.
    """
    try:
        processing_config = _get_customized_config(processing_preset, preset_overrides)
    except ValueError as e:
        raise ConfigurationError(f"Invalid configuration: {e}") from e
    service = DocumentConversionService(
        processing_config, api_key, processing_preset, ocr_factory=GeminiOCRProcessor
    )
    path_obj = Path(document_path)
    if not path_obj.exists():
        raise DocumentNotFoundError(f"Document not found: {path_obj}")
    return service.convert(path_obj)


def _get_customized_config(preset_name: str, overrides: Dict[str, Any]) -> ProcessingConfig:
    """Get configuration with custom overrides applied."""
    try:
        base_config = get_config(preset_name)
    except ValueError as e:
        raise ValueError(f"Invalid preset name: {e}") from e

    if not overrides:
        return base_config

    for option_name in overrides.keys():
        if not hasattr(base_config, option_name):
            raise ValueError(f"Unknown configuration option: {option_name}")

    config_dict = {field: getattr(base_config, field) for field in base_config.__dataclass_fields__}  # type: ignore[attr-defined]
    config_dict.update(overrides)
    return ProcessingConfig(**config_dict)


_DocumentConversionService = _DocumentConversionService  # backward compatible for patches

def convert_scanned_document_to_markdown(
    document_path: Union[str, Path], api_key: Optional[str] = None
) -> str:
    """
    Convert a scanned document to Markdown using OCR processing.
    This shortcut uses the ocr_heavy preset.
    """
    return convert_document_to_markdown(
        document_path=document_path,
        processing_preset="ocr_heavy",
        api_key=api_key,
    )


def convert_document_with_table_processing(
    document_path: Union[str, Path], api_key: Optional[str] = None
) -> str:
    """
    Convert a document with table-aware prompting.
    Uses the table_focused preset tuned for tabular content.
    """
    return convert_document_to_markdown(
        document_path=document_path,
        processing_preset="table_focused",
        api_key=api_key,
    )


def convert_document_with_maximum_quality(
    document_path: Union[str, Path], api_key: Optional[str] = None
) -> str:
    """
    Convert a document with maximum quality processing (high DPI, more retries).
    Uses the high_quality preset.
    """
    return convert_document_to_markdown(
        document_path=document_path,
        processing_preset="high_quality",
        api_key=api_key,
    )


def convert_documents_batch(
    document_paths: DocumentInputs,
    processing_preset: str = "standard",
    api_key: Optional[str] = None,
    **preset_overrides: Any,
) -> Dict[str, str]:
    """
    Convert multiple documents to Markdown format in batch.

    Args:
        document_paths: List of document paths, or a directory path to process all supported files.
        processing_preset: Processing configuration preset.
        api_key: Optional Google API key. Defaults to GOOGLE_API_KEY env var.
        **preset_overrides: Additional configuration options to override preset.

    Returns:
        Dictionary mapping file paths to their Markdown content.
    """
    try:
        processing_config = _get_customized_config(processing_preset, preset_overrides)
    except ValueError as e:
        raise ConfigurationError(f"Invalid configuration: {e}") from e

    service = _DocumentConversionService(
        processing_config, api_key, processing_preset, ocr_factory=GeminiOCRProcessor
    )
    normalized = normalize_document_inputs(document_paths)
    results: Dict[str, str] = {}
    for doc_path in normalized:
        if not doc_path.exists():
            raise DocumentNotFoundError(f"Document not found: {doc_path}")
        markdown_content = service.convert(doc_path)
        results[str(doc_path)] = markdown_content

    return results


def convert_folder_to_markdown(
    folder_path: Union[str, Path],
    processing_preset: str = "standard",
    api_key: Optional[str] = None,
    **preset_overrides: Any,
) -> Dict[str, str]:
    """
    Convert all supported documents in a folder to Markdown format.

    Args:
        folder_path: Path to the folder containing documents.
        processing_preset: Processing configuration preset.
        api_key: Optional Google API key. Defaults to GOOGLE_API_KEY env var.
        **preset_overrides: Additional configuration options to override preset.

    Returns:
        Dictionary mapping file paths to their Markdown content.
    """
    folder_path = Path(folder_path)
    if not folder_path.exists():
        raise DocumentNotFoundError(f"Folder not found: {folder_path}")

    if not folder_path.is_dir():
        raise DocumentNotFoundError(f"Path is not a directory: {folder_path}")

    return convert_documents_batch(
        document_paths=folder_path,
        processing_preset=processing_preset,
        api_key=api_key,
        **preset_overrides,
    )


# Backward compatible alias for tests/legacy imports.
def _find_supported_documents(folder_path: Path) -> List[Path]:
    return find_supported_documents(folder_path)
