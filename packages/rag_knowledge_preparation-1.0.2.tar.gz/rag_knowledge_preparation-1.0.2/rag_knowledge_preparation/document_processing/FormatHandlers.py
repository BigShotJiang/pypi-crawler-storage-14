from enum import Enum
from pathlib import Path
from typing import Any, List, Optional

import docx
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table
from docx.text.paragraph import Paragraph
from PIL import Image, ImageSequence

from ..utils.CustomExceptions import ConfigurationError, ConversionError, UnsupportedFormatError
from ..utils.FileIO import safe_read_text

OCR_EXTENSIONS = {".pdf"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".webp"}
TEXT_EXTENSIONS = {".txt", ".md", ".markdown", ".csv"}
DOCX_EXTENSIONS = {".docx"}
SUPPORTED_EXTENSIONS = OCR_EXTENSIONS | IMAGE_EXTENSIONS | TEXT_EXTENSIONS | DOCX_EXTENSIONS


class DocumentKind(str, Enum):
    PDF = "pdf"
    IMAGE = "image"
    TEXT = "text"
    DOCX = "docx"


def detect_kind(document_path: Path) -> DocumentKind:
    """Return the logical document kind for a path or raise for unsupported."""
    suffix = document_path.suffix.lower()
    if suffix in OCR_EXTENSIONS:
        return DocumentKind.PDF
    if suffix in IMAGE_EXTENSIONS:
        return DocumentKind.IMAGE
    if suffix in TEXT_EXTENSIONS:
        return DocumentKind.TEXT
    if suffix in DOCX_EXTENSIONS:
        return DocumentKind.DOCX
    raise UnsupportedFormatError(
        f"Unsupported format '{suffix}'. "
        f"Supported: PDF, images ({', '.join(sorted(IMAGE_EXTENSIONS))}), "
        f"text ({', '.join(sorted(TEXT_EXTENSIONS))}), DOCX."
    )


def load_images(document_path: Path) -> List[Image.Image]:
    """Load an image (or multi-frame image) into a list of PIL images."""
    try:
        with Image.open(document_path) as img:
            frames = [frame.copy() for frame in ImageSequence.Iterator(img)]
    except Exception as exc:
        raise ConversionError(f"Failed to read image file: {exc}") from exc

    if not frames:
        raise ConversionError("No image frames found in file.")
    return frames


def read_text_document(document_path: Path) -> str:
    """Read plain text/markdown content from disk."""
    try:
        return safe_read_text(document_path)
    except Exception as exc:
        raise ConversionError(f"Failed to read text document: {exc}") from exc


def convert_docx_to_markdown(document_path: Path) -> str:
    """Convert a DOCX document to Markdown using a lightweight parser."""
    try:
        document = docx.Document(document_path)
    except Exception as exc:
        raise ConversionError(f"Failed to read DOCX file: {exc}") from exc

    lines: List[str] = []
    for block in _iter_docx_blocks(document, CT_P, CT_Tbl, Paragraph, Table):
        if isinstance(block, Paragraph):
            text = block.text.strip()
            if not text:
                continue
            heading_level = _get_heading_level(block.style.name if block.style else "")
            if heading_level:
                lines.append(f"{'#' * heading_level} {text}")
            else:
                lines.append(text)
        elif isinstance(block, Table):
            lines.extend(_table_to_markdown(block))
            lines.append("")  # blank line after a table

    return "\n".join(lines).strip()


def _iter_docx_blocks(document: Any, CT_P: Any, CT_Tbl: Any, Paragraph: Any, Table: Any) -> Any:
    """Yield paragraphs and tables from a DOCX in document order."""
    parent_elm = document.element.body
    for child in parent_elm.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, document)
        elif isinstance(child, CT_Tbl):
            yield Table(child, document)


def _get_heading_level(style_name: str) -> Optional[int]:
    """Return heading level (1-6) from a DOCX style name like 'Heading 2'."""
    if not style_name:
        return None
    parts = style_name.lower().split()
    if parts and parts[0] == "heading":
        for part in parts[1:]:
            if part.isdigit():
                level = int(part)
                if 1 <= level <= 6:
                    return level
    return None


def _table_to_markdown(table: Any) -> List[str]:
    """Render a python-docx Table to markdown rows."""
    rows: List[List[str]] = []
    for row in table.rows:
        cells = [cell.text.replace("\n", " ").strip() for cell in row.cells]
        rows.append(cells)

    if not rows:
        return []

    col_count = max(len(r) for r in rows)
    header = (rows[0] + [""] * col_count)[:col_count]
    separator = ["---"] * col_count

    lines = [
        "| " + " | ".join(header) + " |",
        "| " + " | ".join(separator) + " |",
    ]

    for row in rows[1:]:
        padded = (row + [""] * col_count)[:col_count]
        lines.append("| " + " | ".join(padded) + " |")
    return lines
