from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Sequence, Type, Union

from .DocumentProcessingConfig import ProcessingConfig
from .FormatHandlers import (
    SUPPORTED_EXTENSIONS,
    DocumentKind,
    convert_docx_to_markdown,
    detect_kind,
    load_images,
    read_text_document,
)
from .OCRProcessor import GeminiOCRProcessor
from ..utils.CustomExceptions import (
    ConfigurationError,
    ConversionError,
    DocumentNotFoundError,
    UnsupportedFormatError,
)
from ..utils.FileIO import list_files

PathInput = Union[str, Path]
DocumentInputs = Union[Sequence[PathInput], PathInput]


class DocumentConversionService:
    """Routes documents to the correct handler and keeps OCR state."""

    def __init__(
        self,
        config: ProcessingConfig,
        api_key: Optional[str],
        preset_name: str,
        ocr_factory: Type[GeminiOCRProcessor] = GeminiOCRProcessor,
    ) -> None:
        self.config = config
        self.api_key = api_key
        self.preset_name = preset_name
        self._ocr_factory = ocr_factory
        self._ocr_processor: Optional[GeminiOCRProcessor] = None

    def convert(self, document_path: Path) -> str:
        kind = detect_kind(document_path)
        try:
            handlers = {
                DocumentKind.PDF: self._convert_pdf,
                DocumentKind.IMAGE: self._convert_image,
                DocumentKind.TEXT: self._convert_text,
                DocumentKind.DOCX: self._convert_docx,
            }
            handler = handlers.get(kind)
            if handler:
                return handler(document_path)
        except (UnsupportedFormatError, ConfigurationError, DocumentNotFoundError):
            raise
        except Exception as exc:
            raise ConversionError(f"Failed to convert document: {exc}") from exc

        raise UnsupportedFormatError(f"Unsupported format: {document_path.suffix}")

    def _ocr(self) -> GeminiOCRProcessor:
        if self._ocr_processor is None:
            self._ocr_processor = self._ocr_factory(self.config, api_key=self.api_key)
        return self._ocr_processor

    def _convert_pdf(self, document_path: Path) -> str:
        processor = self._ocr()
        return processor.convert_pdf_to_markdown(document_path)

    def _convert_image(self, document_path: Path) -> str:
        processor = self._ocr()
        images = load_images(document_path)
        return processor.convert_images_to_markdown(images, title=document_path.stem)

    def _convert_text(self, document_path: Path) -> str:
        return read_text_document(document_path)

    def _convert_docx(self, document_path: Path) -> str:
        return convert_docx_to_markdown(document_path)


def normalize_document_inputs(document_paths: DocumentInputs) -> List[Path]:
    """Normalize incoming paths or folder reference into a flat list of Paths."""
    if isinstance(document_paths, (str, Path)):
        path_obj = Path(document_paths)
        if path_obj.is_dir():
            return find_supported_documents(path_obj)
        return [path_obj]

    normalized: List[Path] = []
    for raw in document_paths:
        normalized.append(Path(raw))
    return normalized


def find_supported_documents(folder_path: Path) -> List[Path]:
    """Find all supported document files in a folder."""
    supported_files = list_files(folder_path, extensions=sorted(SUPPORTED_EXTENSIONS))
    return sorted(supported_files)


# Backward-compatible alias used in tests/patching
_DocumentConversionService = DocumentConversionService
