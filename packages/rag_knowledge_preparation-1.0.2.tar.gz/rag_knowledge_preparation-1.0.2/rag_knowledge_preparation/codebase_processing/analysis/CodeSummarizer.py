from pathlib import Path
from typing import Optional, Dict, Any

from langchain_core.messages import AIMessage

from ..utils.CodebaseConstants import MAX_SUMMARY_WORDS, MAX_CONTENT_LENGTH
from ...utils.GeminiClient import (
    ChatGoogleGenerativeAI,
    GEMINI_CHAT_AVAILABLE,
    GeminiClientConfig,
    create_chat_model_with_cls,
)
from ...utils.RetryBackoff import run_with_retry
from ...utils.LRUCache import LRUCache


class CodeSummarizer:
    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: str = "gemini-2.5-flash",
        temperature: float = 0.2,
        max_output_tokens: int = 1024,
        max_retries: int = 3,
    ):
        self.api_key = api_key
        self.model = None
        self.max_retries = max_retries
        self._config = GeminiClientConfig(
            model_name=model_name,
            api_key=api_key,
            temperature=temperature,
            max_output_tokens=max_output_tokens,
        )

        if GEMINI_CHAT_AVAILABLE or ChatGoogleGenerativeAI is not None:
            try:
                self.model = create_chat_model_with_cls(self._config, ChatGoogleGenerativeAI)
            except Exception:
                self.model = None

    def generate_summary(
        self,
        content: str,
        file_path: Path,
        language: str,
        project_metadata: Optional[Dict[str, Any]] = None,
        relative_path: Optional[str] = None
    ) -> str:
        if not self.model:
            return self._fallback_summary(content, language)

        try:
            code_snippet = self._extract_key_code(content)

            project_name = (project_metadata or {}).get("name") or "Unknown project"
            alias_section = ""
            aliases = (project_metadata or {}).get("aliases") or []
            if aliases:
                alias_section = f"Known project aliases: {', '.join(aliases)}\n"
            file_reference = relative_path or file_path.name

            prompt = f"""You are an expert engineer documenting code for retrieval QA systems.
Project name: {project_name}
{alias_section}File reference: {file_reference}
Programming language: {language}
Filename: {file_path.name}
Code snippet:
{code_snippet}

Write a concise summary (max {MAX_SUMMARY_WORDS} words) that:
- explains the main responsibilities of this code
- highlights notable implementation or integration details
- uses plain text (no markdown) and DO NOT repeat the project name or file path"""

            def _invoke():
                return self.model.invoke(prompt)

            response = run_with_retry(
                _invoke,
                max_retries=self.max_retries,
                min_wait=1.0,
                max_wait=6.0,
            )
            return self._clean_summary(self._extract_text(response), MAX_SUMMARY_WORDS)
        except Exception:
            return self._fallback_summary(content, language)

    def generate_readme_overview(self, content: str, file_path: Path, max_words: int = 220) -> Optional[str]:
        if not self.model:
            return None

        try:
            trimmed_content = content[:MAX_CONTENT_LENGTH * 2]
            prompt = f"""You are an expert technical writer. Summarize the following project README for stakeholders.

README name: {file_path.name}
README content (truncated):
{trimmed_content}

Write a concise narrative (no bullet lists) of up to {max_words} words that covers:
- the project's purpose and primary capabilities
- the architecture or component layout and key technologies used
- important setup, usage, or operational considerations

Keep the tone factual and highlight the most important details."""

            def _invoke():
                return self.model.invoke(prompt)

            response = run_with_retry(
                _invoke,
                max_retries=self.max_retries,
                min_wait=1.0,
                max_wait=6.0,
            )
            return self._clean_summary(self._extract_text(response), max_words)
        except Exception:
            return None

    def _extract_key_code(self, content: str) -> str:
        """Extract most important parts of code for analysis"""
        lines = content.split('\n')
        key_lines = []

        key_lines.extend(lines[:10])

        for line in lines:
            stripped = line.strip()
            if stripped.startswith(('class ', 'def ', 'function ', 'export ', 'const ', 'interface ')):
                key_lines.append(line)

        result = '\n'.join(key_lines)
        return result[:800]

    def _clean_summary(self, summary: str, max_words: int = MAX_SUMMARY_WORDS) -> str:
        summary = summary.strip().replace('**', '').replace('*', '').replace('```', '').replace('`', '')
        words = summary.split()
        if max_words and len(words) > max_words:
            summary = ' '.join(words[:max_words]) + '...'
        return summary or "Code file with implementation details"

    def _extract_text(self, response: Any) -> str:
        if isinstance(response, AIMessage):
            return (response.content or "").strip()
        if hasattr(response, "text"):
            return (response.text or "").strip()
        return str(response).strip()

    def _fallback_summary(self, content: str, language: str) -> str:
        lines = [line.strip() for line in content.split('\n') if line.strip()]

        if len(lines) < 5:
            return f"Small {language} file with {len(lines)} lines"
        if 'def ' in content or 'function ' in content:
            return f"{language} file containing functions and logic"
        if 'class ' in content:
            return f"{language} file with class definitions"
        if 'import ' in content or 'require ' in content:
            return f"{language} file with imports and dependencies"
        return f"{language} code file with {len(lines)} lines of implementation"


_global_summarizer = None
_global_summarizer_config = None
_summary_cache = LRUCache(capacity=100)
_readme_summary_cache = LRUCache(capacity=100)


def generate_code_summary(
    content: str,
    file_path: Path,
    language: str,
    api_key: Optional[str] = None,
    model_name: str = "gemini-2.5-flash",
    project_metadata: Optional[Dict[str, Any]] = None,
    relative_path: Optional[str] = None
) -> str:
    global _global_summarizer, _global_summarizer_config

    import hashlib
    content_hash = hashlib.md5(content[:1000].encode()).hexdigest()
    project_name = (project_metadata or {}).get("name", "")
    cache_key = f"{project_name}_{relative_path or ''}_{file_path.name}_{language}_{content_hash[:8]}"

    cached = _summary_cache.get(cache_key)
    if cached is not None:
        return cached

    current_config = (api_key, model_name)

    if _global_summarizer is None or _global_summarizer_config != current_config:
        _global_summarizer = CodeSummarizer(api_key, model_name)
        _global_summarizer_config = current_config

    summary = _global_summarizer.generate_summary(
        content,
        file_path,
        language,
        project_metadata,
        relative_path
    )

    _summary_cache.set(cache_key, summary)

    return summary


def generate_readme_summary(content: str, file_path: Path, api_key: Optional[str] = None, model_name: str = "gemini-2.5-flash", max_words: int = 220) -> Optional[str]:
    global _global_summarizer, _global_summarizer_config, _readme_summary_cache

    import hashlib
    content_hash = hashlib.md5(content[:2000].encode()).hexdigest()
    cache_key = f"readme_{file_path.name}_{content_hash[:8]}_{max_words}"

    cached = _readme_summary_cache.get(cache_key)
    if cached is not None:
        return cached

    current_config = (api_key, model_name)

    if _global_summarizer is None or _global_summarizer_config != current_config:
        _global_summarizer = CodeSummarizer(api_key, model_name)
        _global_summarizer_config = current_config

    summary = _global_summarizer.generate_readme_overview(content, file_path, max_words)

    if summary:
        _readme_summary_cache.set(cache_key, summary)

    return summary
