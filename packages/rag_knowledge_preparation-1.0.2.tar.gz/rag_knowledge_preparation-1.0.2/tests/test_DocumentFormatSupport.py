import pytest
from pathlib import Path
from unittest.mock import Mock, patch

from docx import Document
from PIL import Image

from rag_knowledge_preparation import convert_document_to_markdown
from rag_knowledge_preparation.utils.CustomExceptions import UnsupportedFormatError


class TestDifferentFormats:
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_pdf_format(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Test PDF"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="basic")
            assert result == "# Test PDF"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink(missing_ok=True)
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_image_format(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_images_to_markdown.return_value = "# Image Page"
        mock_processor.return_value = mock_instance

        test_file = Path("tests/test_data/test_document.png")
        Image.new("RGB", (10, 10), color="red").save(test_file)

        try:
            result = convert_document_to_markdown(test_file, processing_preset="basic")
            assert result == "# Image Page"
            mock_processor.assert_called_once()
            mock_instance.convert_images_to_markdown.assert_called_once()
        finally:
            test_file.unlink(missing_ok=True)

    def test_text_format(self):
        test_file = Path("tests/test_data/test_document.txt")
        content = "Hello text document"
        test_file.write_text(content, encoding="utf-8")
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="basic")
            assert content in result
        finally:
            test_file.unlink(missing_ok=True)

    def test_docx_format(self):
        test_file = Path("tests/test_data/test_document.docx")
        doc = Document()
        doc.add_heading("Docx Title", level=1)
        doc.add_paragraph("Docx paragraph content.")
        doc.save(test_file)

        try:
            result = convert_document_to_markdown(test_file, processing_preset="basic")
            assert "# Docx Title" in result
            assert "Docx paragraph content." in result
        finally:
            test_file.unlink(missing_ok=True)
    
    def test_unsupported_format(self):
        test_file = Path("tests/test_data/test_document.unsupported")
        test_file.touch()
        
        try:
            with pytest.raises(UnsupportedFormatError):
                convert_document_to_markdown(test_file, processing_preset="basic")
        finally:
            test_file.unlink(missing_ok=True)


if __name__ == "__main__":
    pytest.main([__file__])
