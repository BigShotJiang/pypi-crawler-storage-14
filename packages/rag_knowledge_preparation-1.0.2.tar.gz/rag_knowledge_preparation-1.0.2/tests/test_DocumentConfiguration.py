import pytest

from rag_knowledge_preparation.document_processing.DocumentProcessingConfig import (
    ProcessingConfig,
    get_config,
    list_available_configs,
    CONFIGS
)


class TestProcessingConfig:
    def test_default_config(self):
        config = ProcessingConfig()
        
        assert config.model_name == "gemini-2.5-pro"
        assert config.prompt
        assert config.temperature == 0.2
        assert config.max_output_tokens == 4096
        assert config.dpi == 300
        assert config.page_selection is None
        assert config.parallel_concurrency == 5
        assert config.max_retries == 4
    
    def test_custom_config(self):
        config = ProcessingConfig(
            model_name="custom-model",
            prompt="Test prompt",
            temperature=0.5,
            max_output_tokens=1024,
            dpi=200,
            page_selection="1-2",
            parallel_concurrency=2,
            max_retries=2,
        )
        
        assert config.model_name == "custom-model"
        assert config.prompt == "Test prompt"
        assert config.temperature == 0.5
        assert config.max_output_tokens == 1024
        assert config.dpi == 200
        assert config.page_selection == "1-2"
        assert config.parallel_concurrency == 2
        assert config.max_retries == 2
    
    def test_invalid_values(self):
        with pytest.raises(ValueError):
            ProcessingConfig(dpi=0)
        with pytest.raises(ValueError):
            ProcessingConfig(parallel_concurrency=0)
        with pytest.raises(ValueError):
            ProcessingConfig(max_retries=0)
        with pytest.raises(ValueError):
            ProcessingConfig(temperature=-0.1)
        with pytest.raises(ValueError):
            ProcessingConfig(max_output_tokens=0)


class TestConfigManagement:
    
    def test_get_config_valid_preset(self):
        config = get_config("basic")
        assert isinstance(config, ProcessingConfig)
        assert config.dpi == CONFIGS["basic"].dpi
        
        config = get_config("high_quality")
        assert isinstance(config, ProcessingConfig)
        assert config.dpi == CONFIGS["high_quality"].dpi
    
    def test_get_config_invalid_preset(self):
        with pytest.raises(ValueError):
            get_config("invalid_preset")
    
    def test_get_config_default(self):
        config = get_config()  # Should default to "standard"
        assert isinstance(config, ProcessingConfig)
        assert config.dpi == CONFIGS["standard"].dpi
    
    def test_list_available_configs(self):
        configs = list_available_configs()
        
        assert isinstance(configs, dict)
        assert len(configs) == len(CONFIGS)
        
        for config_name in CONFIGS.keys():
            assert config_name in configs
            assert isinstance(configs[config_name], str)
            assert len(configs[config_name]) > 0


class TestPredefinedConfigs:
    
    def test_basic_config(self):
        config = CONFIGS["basic"]
        
        assert config.dpi == 200
        assert config.parallel_concurrency == 3
        assert config.max_output_tokens == 2048
    
    def test_standard_config(self):
        config = CONFIGS["standard"]
        
        assert config.dpi == 300
        assert config.temperature == 0.2
    
    def test_ocr_heavy_config(self):
        config = CONFIGS["ocr_heavy"]
        
        assert config.dpi >= 350
        assert config.max_retries >= 5
    
    def test_table_focused_config(self):
        config = CONFIGS["table_focused"]
        
        assert "table" in config.prompt.lower()
    
    def test_high_quality_config(self):
        config = CONFIGS["high_quality"]
        
        assert config.dpi >= 400
        assert config.max_output_tokens >= 6144


if __name__ == "__main__":
    pytest.main([__file__])
