import pytest
from pathlib import Path
from unittest.mock import Mock, patch

from rag_knowledge_preparation import (
    convert_document_to_markdown,
    convert_scanned_document_to_markdown,
    convert_document_with_table_processing,
    convert_document_with_maximum_quality
)
from rag_knowledge_preparation.utils.CustomExceptions import (
    DocumentNotFoundError,
    ConfigurationError,
    UnsupportedFormatError
)


class TestDocumentConverter:
    def test_convert_document_to_markdown_file_not_found(self):
        with pytest.raises(DocumentNotFoundError):
            convert_document_to_markdown("non_existent_file.pdf")
    
    def test_convert_document_to_markdown_invalid_preset(self):
        test_file = Path("test_file.pdf")
        test_file.touch()
        
        try:
            with pytest.raises(ConfigurationError):
                convert_document_to_markdown(
                    test_file, 
                    processing_preset="invalid_preset"
                )
        finally:
            test_file.unlink()
    
    def test_convert_document_to_markdown_invalid_format(self):
        test_file = Path("test_file.xyz")
        test_file.touch()
        
        try:
            with pytest.raises(UnsupportedFormatError):
                convert_document_to_markdown(test_file)
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_document_to_markdown_success(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Test Markdown"
        mock_processor.return_value = mock_instance
        
        test_file = Path("test_file.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, api_key="test-key")
            assert result == "# Test Markdown"
            mock_processor.assert_called_once()
            mock_instance.convert_pdf_to_markdown.assert_called_once_with(test_file)
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_scanned_document_to_markdown(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Scanned Document"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_scanned_document_to_markdown(test_file, api_key="key")
            assert result == "# Scanned Document"
            mock_processor.assert_called_once()
            mock_instance.convert_pdf_to_markdown.assert_called_once_with(test_file)
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_document_with_table_processing(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Table Processing"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_with_table_processing(test_file, api_key="key")
            assert result == "# Table Processing"
            mock_processor.assert_called_once()
            mock_instance.convert_pdf_to_markdown.assert_called_once_with(test_file)
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_document_with_maximum_quality(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Maximum Quality"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_with_maximum_quality(test_file, api_key="key")
            assert result == "# Maximum Quality"
            mock_processor.assert_called_once()
            mock_instance.convert_pdf_to_markdown.assert_called_once_with(test_file)
        finally:
            test_file.unlink()


if __name__ == "__main__":
    pytest.main([__file__])
