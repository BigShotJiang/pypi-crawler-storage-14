# src/pyinitgen/__init__.py

