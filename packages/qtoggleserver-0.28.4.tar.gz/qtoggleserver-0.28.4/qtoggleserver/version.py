VERSION = "0.28.4"
VENDOR = "qtoggle/qtoggleserver"
