<div align="center">
<img alt="" src="https://forge.steffo.eu/steffo/steamleaderboards/raw/branch/main/.media/icon-512.png" height="128" style="border-radius: 100%;">
<hgroup>
<h1>Steam Leaderboards</h1>
<p>Retrieve and parse Steam leaderboards</p>
</hgroup>
</div>

## Links

### Tools

<a href="https://www.python.org/">
    <img alt="Written in Python" title="Written in Python" src="https://img.shields.io/badge/language-python-3775a9" height="30px">
</a>

### Packaging

<a href="https://pypi.org/project/steamleaderboards">
    <img alt="Available on PyPI" title="Available on PyPI" src="https://img.shields.io/pypi/v/steamleaderboards?label=pypi&color=ffd242" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/-/packages/pypi/steamleaderboards">
    <img alt="Available on Forgejo Packages" title="Available on Forgejo Packages" src="https://img.shields.io/badge/forgejo%20packages-latest-ff6600" height="30px">
</a>

### Documentation

<a href="https://forge.steffo.eu/steffo/steamleaderboards/wiki">
    <img alt="Documentation available" title="Documentation available" src="https://img.shields.io/website?url=https%3A%2F%2Fforge.steffo.eu%2Fsteffo%2Fsteamleaderboards%2Fwiki&up_color=175d36&up_message=available&down_message=error&label=documentation" height="30px">
</a>
&hairsp;
<a href="https://opensource.org/license/MIT">
    <img alt="Licensed under MIT license" title="Licensed under MIT license" src="https://img.shields.io/badge/license-MIT-3da638" height="30px">
</a>

### Development

<a href="https://forge.steffo.eu/steffo/steamleaderboards">
    <img alt="Code repository" title="Code repository" src="https://img.shields.io/gitea/last-commit/steffo/steamleaderboards?gitea_url=https%3A%2F%2Fforge.steffo.eu&color=374351" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/steamleaderboards/releases">
    <img alt="Releases" title="Releases" src="https://img.shields.io/gitea/v/release/steffo/steamleaderboards?gitea_url=https%3A%2F%2Fforge.steffo.eu&label=last+release&color=374351" height="30px">
</a>
