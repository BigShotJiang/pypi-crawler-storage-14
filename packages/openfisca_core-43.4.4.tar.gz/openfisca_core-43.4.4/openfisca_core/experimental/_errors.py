class MemoryConfigWarning(UserWarning):
    """Custom warning for MemoryConfig."""


__all__ = ["MemoryConfigWarning"]
