class TempfileWarning(UserWarning):
    """Custom warning when using a tempfile on disk."""
