# -*- coding: utf-8 -*-
"""
测试 INSERT 和 UPDATE 操作的单元测试
"""

import unittest
import os
import sys
from pathlib import Path

# 添加 src 到路径
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from sqlalchemy_fastmcp.exec_query import exec_query
from sqlalchemy_fastmcp.set_database_source import set_database_source


class TestInsertUpdateOperations(unittest.TestCase):
    """测试 INSERT 和 UPDATE 操作"""

    @classmethod
    def setUpClass(cls):
        """设置测试数据库"""
        # 设置 SQLite 数据库路径
        db_path = str(Path(__file__).parent / "db.sqlite")
        set_database_source(
            db_type="sqlite",
            db_path=db_path
        )

    def test_insert_user(self):
        """测试插入用户数据"""
        # 先查询当前用户数
        result_before = exec_query("SELECT COUNT(*) as count FROM users")
        self.assertFalse(result_before.get("error", False), "查询失败")
        count_before = result_before["data"][0]["count"]

        # 插入新用户
        insert_result = exec_query("INSERT INTO users (name, email) VALUES ('王五', 'wangwu@example.com')")

        # 验证插入成功
        self.assertFalse(insert_result.get("error", False), f"插入失败: {insert_result.get('message')}")
        self.assertEqual(insert_result["execution_info"]["operation_type"], "插入")
        self.assertEqual(insert_result["execution_info"]["affected_rows"], 1)

        # 验证数据已插入
        result_after = exec_query("SELECT * FROM users WHERE name = '王五'")
        self.assertFalse(result_after.get("error", False), "查询失败")
        self.assertEqual(len(result_after["data"]), 1)
        self.assertEqual(result_after["data"][0]["email"], "wangwu@example.com")

        # 验证总数增加
        count_result = exec_query("SELECT COUNT(*) as count FROM users")
        count_after = count_result["data"][0]["count"]
        self.assertEqual(count_after, count_before + 1)

    def test_insert_post(self):
        """测试插入帖子数据"""
        # 先查询当前帖子数
        result_before = exec_query("SELECT COUNT(*) as count FROM posts")
        self.assertFalse(result_before.get("error", False), "查询失败")
        count_before = result_before["data"][0]["count"]

        # 插入新帖子
        insert_result = exec_query("INSERT INTO posts (title, content, user_id) VALUES ('第四篇帖子', '这是新插入的帖子内容', 1)")

        # 验证插入成功
        self.assertFalse(insert_result.get("error", False), f"插入失败: {insert_result.get('message')}")
        self.assertEqual(insert_result["execution_info"]["operation_type"], "插入")
        self.assertEqual(insert_result["execution_info"]["affected_rows"], 1)

        # 验证数据已插入
        result_after = exec_query("SELECT * FROM posts WHERE title = '第四篇帖子'")
        self.assertFalse(result_after.get("error", False), "查询失败")
        self.assertEqual(len(result_after["data"]), 1)
        self.assertEqual(result_after["data"][0]["content"], "这是新插入的帖子内容")
        self.assertEqual(result_after["data"][0]["user_id"], 1)

        # 验证总数增加
        count_result = exec_query("SELECT COUNT(*) as count FROM posts")
        count_after = count_result["data"][0]["count"]
        self.assertEqual(count_after, count_before + 1)

    def test_update_user(self):
        """测试更新用户数据"""
        # 先查询原始数据
        result_before = exec_query("SELECT * FROM users WHERE id = 1")
        self.assertFalse(result_before.get("error", False), "查询失败")
        original_email = result_before["data"][0]["email"]

        # 更新用户邮箱
        update_result = exec_query("UPDATE users SET email = 'zhangsan_new@example.com' WHERE id = 1")

        # 验证更新成功
        self.assertFalse(update_result.get("error", False), f"更新失败: {update_result.get('message')}")
        self.assertEqual(update_result["execution_info"]["operation_type"], "更新")
        self.assertEqual(update_result["execution_info"]["affected_rows"], 1)

        # 验证数据已更新
        result_after = exec_query("SELECT * FROM users WHERE id = 1")
        self.assertFalse(result_after.get("error", False), "查询失败")
        self.assertEqual(result_after["data"][0]["email"], "zhangsan_new@example.com")
        self.assertNotEqual(result_after["data"][0]["email"], original_email)

    def test_update_post(self):
        """测试更新帖子数据"""
        # 更新帖子标题
        update_result = exec_query("UPDATE posts SET title = '更新后的帖子标题' WHERE id = 1")

        # 验证更新成功
        self.assertFalse(update_result.get("error", False), f"更新失败: {update_result.get('message')}")
        self.assertEqual(update_result["execution_info"]["operation_type"], "更新")
        self.assertEqual(update_result["execution_info"]["affected_rows"], 1)

        # 验证数据已更新
        result_after = exec_query("SELECT * FROM posts WHERE id = 1")
        self.assertFalse(result_after.get("error", False), "查询失败")
        self.assertEqual(result_after["data"][0]["title"], "更新后的帖子标题")

    def test_update_multiple_rows(self):
        """测试更新多行数据"""
        # 更新所有张三的帖子
        update_result = exec_query("UPDATE posts SET content = '批量更新的内容' WHERE user_id = 1")

        # 验证更新成功
        self.assertFalse(update_result.get("error", False), f"更新失败: {update_result.get('message')}")
        self.assertEqual(update_result["execution_info"]["operation_type"], "更新")
        self.assertGreater(update_result["execution_info"]["affected_rows"], 1)

        # 验证数据已更新
        result_after = exec_query("SELECT * FROM posts WHERE user_id = 1")
        self.assertFalse(result_after.get("error", False), "查询失败")
        for row in result_after["data"]:
            self.assertEqual(row["content"], "批量更新的内容")

    def test_insert_with_invalid_foreign_key(self):
        """测试插入外键不存在的记录"""
        # 先删除已存在的测试数据（如果存在）
        exec_query("DELETE FROM posts WHERE title = '无效帖子'")

        # SQLite 默认不检查外键约束，所以我们改为测试插入后查询不到数据
        # 尝试插入 user_id 不存在的帖子
        insert_result = exec_query("INSERT INTO posts (title, content, user_id) VALUES ('无效帖子', '用户不存在', 999)")

        # 插入应该成功（SQLite 不检查外键）
        self.assertFalse(insert_result.get("error", False), f"插入失败: {insert_result.get('message')}")

        # 但查询时应该找不到对应的用户
        join_result = exec_query("SELECT p.*, u.name FROM posts p LEFT JOIN users u ON p.user_id = u.id WHERE p.title = '无效帖子'")
        self.assertFalse(join_result.get("error", False), "查询失败")
        self.assertEqual(len(join_result["data"]), 1)
        # 用户名为空，因为 user_id=999 的用户不存在
        self.assertIsNone(join_result["data"][0].get("name"))

    def test_update_nonexistent_record(self):
        """测试更新不存在的记录"""
        update_result = exec_query("UPDATE users SET email = 'test@example.com' WHERE id = 999")

        # 应该成功但影响行数为0
        self.assertFalse(update_result.get("error", False), f"更新失败: {update_result.get('message')}")
        self.assertEqual(update_result["execution_info"]["operation_type"], "更新")
        self.assertEqual(update_result["execution_info"]["affected_rows"], 0)


if __name__ == '__main__':
    unittest.main()
