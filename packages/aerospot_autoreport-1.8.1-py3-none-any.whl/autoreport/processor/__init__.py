"""
数据处理模块
===========

负责数据的下载、提取、处理和分析，包括：
- 数据下载
- 文件解压 (ZipExtractor 已迁移至 core，Phase 2.4)
- 数据处理和清洗
- 地图生成
- 配置生成

导入位置更新 (Phase 2.4)：
- ZipExtractor: from autoreport.core.extractor import ZipExtractor
"""

# 延迟导入以避免循环依赖
# from .config import create_updated_config
# from .downloader import *
# from .maps import SatelliteMapGenerator
# from .data import DataProcessor
#
# ZipExtractor 已迁移至 core/extractor.py，Phase 2.4 优化

__all__ = [
    "create_updated_config",
    "SatelliteMapGenerator",
    "DataProcessor",
]
