#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
指标地图处理引擎

负责处理单个指标的地图生成流程编排。
这是从 AeroSpotReportGenerator._process_indicator() 和 _determine_map_types() 提取的逻辑。
"""

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


class IndicatorMapEngine:
    """指标地图处理引擎

    职责：
    1. 确定单指标应生成的地图类型
    2. 确定定量/定性模式
    3. 编排指标处理流程

    原来的职责分散在：
    - _process_indicator() (167 行)
    - _determine_map_types() (63 行)
    """

    def __init__(self) -> None:
        """初始化指标处理引擎"""
        self.logger = logger

    def determine_map_types(
        self, indicator: str, prep_data: Dict[str, Any], renderer: Any
    ) -> List[str]:
        """决定指标支持的地图类型

        根据指标名称、是否为NDVI、是否支持分级等条件，
        决定该指标应生成哪些类型的地图。

        Args:
            indicator: 指标名称（如'TP', 'NDVI'）
            prep_data: 地图准备数据字典
            renderer: 地图渲染器实例

        Returns:
            list[str]: 地图类型列表，如['distribution', 'interpolation', ...]
        """
        has_measured_data = prep_data.get("has_measured_data", False)
        visualization_mode = prep_data.get("visualization_mode", "quantitative")

        # 检查指标是否支持国标分级
        grade_config = renderer.grade_manager.get_grade_config(indicator)
        supports_grading = grade_config is not None

        # 检查是否为NDVI指标
        is_ndvi = indicator.upper() == "NDVI"

        # 判断是否为定量模式：有实测数据或配置为定量模式
        is_quantitative_mode = has_measured_data or visualization_mode == "quantitative"

        self.logger.info(
            f"{indicator} - 是否支持国标分级: {supports_grading}, "
            f"是否NDVI: {is_ndvi}, 是否定量模式: {is_quantitative_mode}"
        )

        # 根据指标类型决定生成哪些类型的图
        if is_ndvi:
            # NDVI指标生成藻华检测专用图
            map_types = [
                "distribution",
                "interpolation",
                "ndvi_binary",
                "ndvi_bloom_level",
            ]
            self.logger.info(f"{indicator} 为NDVI指标，将生成藻华检测专用图")
        elif supports_grading and is_quantitative_mode:
            map_types = [
                "distribution",
                "interpolation",
                "level",
            ]
            self.logger.info(
                f"{indicator} 支持国标分级且为定量模式，将生成完整的图表集（包括等级图）"
            )
        else:
            map_types = ["distribution", "interpolation"]
            if not supports_grading:
                self.logger.info(f"{indicator} 不支持国标分级，跳过等级图生成")
            if not is_quantitative_mode:
                self.logger.info(f"{indicator} 为定性模式，跳过等级图生成")

        return map_types

    def is_quantitative_mode(self, prep_data: Dict[str, Any]) -> bool:
        """检查是否为定量模式

        Args:
            prep_data: 地图准备数据字典

        Returns:
            bool: 是否为定量模式
        """
        has_measured_data: bool = prep_data.get("has_measured_data", False)
        visualization_mode: str = prep_data.get("visualization_mode", "quantitative")
        return bool(has_measured_data) or visualization_mode == "quantitative"
