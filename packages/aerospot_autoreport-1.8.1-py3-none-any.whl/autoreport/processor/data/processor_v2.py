"""
数据处理器模块

提供数据处理和分析的核心功能

兼容旧版本 API 并支持新的分离架构
"""

import logging
from typing import Any, Dict, Optional

import pandas as pd


from .analyzer import calculate_statistics, generate_data_summary
from .standardizer import standardize_column_names, standardize_indicator_names
from .utils import get_indicator_unit
from .data_matching_analyzer import DataMatchingAnalyzer

logger = logging.getLogger(__name__)


class DataProcessor:
    """
    数据处理器类
    用于处理和分析航测数据

    ✨ 改进：使用新的分离架构，同时保持向后兼容
    """

    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        config_service: Optional[Any] = None,
    ):
        """
        初始化数据处理器

        Args:
            config: 配置字典，包含数据处理的相关配置（已弃用，保留向后兼容）
            config_service: ConfigurationService 实例（可选）
        """
        self.config = config or {}
        self.config_service = config_service
        self._matcher_analyzer = DataMatchingAnalyzer()

    def _get_indicator_unit(self, indicator: str) -> str:
        """
        根据指标名称获取单位

        Args:
            indicator: 指标名称

        Returns:
            指标单位字符串
        """
        # 优先使用 ConfigurationService 获取单位
        if self.config_service is not None:
            units_config = self.config_service.get_indicator_units_config()
            return units_config.get_unit(indicator)

        # 否则使用传统方式
        return get_indicator_unit(indicator, self.config)

    def process_data(self, merged_data: pd.DataFrame) -> Optional[Dict[str, Any]]:
        """
        处理合并后的数据，计算统计信息

        Args:
            merged_data: 合并后的数据DataFrame

        Returns:
            处理后的统计信息字典
        """
        try:
            logger.info("开始处理数据")

            # 初始化结果字典
            result = dict()

            # 标准化列名
            merged_data, column_mapping = standardize_column_names(merged_data)

            # 确保必要的列存在
            required_columns = ["index", "Latitude", "Longitude"]
            for col in required_columns:
                if col not in merged_data.columns:
                    logger.warning(f"缺少必要的列: {col}")

            # 提取指标列
            indicator_columns = [
                col for col in merged_data.columns if col not in required_columns
            ]
            logger.info(
                f"找到 {len(indicator_columns)} 个指标: {', '.join(indicator_columns)}"
            )

            # 标准化指标名称
            merged_data, indicator_columns = standardize_indicator_names(
                merged_data, indicator_columns
            )

            # 存储处理后的数据
            result["processed_data"] = merged_data

            # 计算统计信息
            result["statistics"] = calculate_statistics(
                merged_data, indicator_columns, self._get_indicator_unit
            )

            # 生成数据摘要
            result["data_summary"] = generate_data_summary(
                merged_data, indicator_columns
            )

            logger.info("数据处理完成")
            return result
        except Exception as e:
            logger.error(f"处理数据时出错: {str(e)}")
            return None

    def match_and_analyze_data(
        self,
        merged_data: pd.DataFrame,
        measure_data: pd.DataFrame,
        ref_data: pd.DataFrame,
        historical_ref,
        historical_merged,
        historical_measure,
        output_file: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        匹配和分析航测数据与人工采样数据

        ✨ 改进：现在使用 DataMatchingAnalyzer 分离职责

        Args:
            merged_data: 合并后的航测数据DataFrame
            measure_data: 人工采样数据DataFrame
            ref_data: 参考数据DataFrame
            output_file: 可选的输出文件路径

        Returns:
            匹配和分析结果字典
        """
        logger.info("开始匹配和分析数据")

        # 使用专职分析器处理
        return self._matcher_analyzer.analyze(
            merged_data=merged_data,
            measure_data=measure_data,
            ref_data=ref_data,
            historical_ref=historical_ref,
            historical_merged=historical_merged,
            historical_measure=historical_measure,
            output_file=output_file,
        )
