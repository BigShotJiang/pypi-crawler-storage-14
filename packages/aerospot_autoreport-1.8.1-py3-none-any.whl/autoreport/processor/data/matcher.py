"""
数据匹配模块
提供航测数据与人工采样数据的匹配和分析功能
"""

import logging
from typing import List, Any, Tuple, Optional

import numpy as np
import pandas as pd

from ...utils.coordinates import haversine

logger = logging.getLogger(__name__)


def find_common_indicators(
    merged_data: pd.DataFrame, measure_data: pd.DataFrame
) -> List[str]:
    """
    查找共同的指标列

    Args:
        merged_data: 合并后的航测数据DataFrame
        measure_data: 人工采样数据DataFrame

    Returns:
        List[str]: 共同的指标列名列表
    """
    common_indicators = list(set(merged_data.columns) & set(measure_data.columns))
    # common_indicators = [col for col in common_indicators if col not in ['index', 'Latitude', 'longitude']]

    if not common_indicators:
        logger.warning("没有找到共同的指标列")
    else:
        logger.info(f"找到共同指标: {', '.join(common_indicators)}")

    return common_indicators


def match_nearest_points(
    measure_data: pd.DataFrame, merged_data: pd.DataFrame
) -> List[int]:
    """
    为每个人工采样点找到最近的航测点

    Args:
        measure_data: 人工采样数据DataFrame
        merged_data: 合并后的航测数据DataFrame

    Returns:
        List[int]: 匹配的航测点索引列表
    """
    matched_idx: List[int] = []

    logger.info(
        f"开始匹配人工采样点与航测点，总共{len(measure_data)}个人工采样点，{len(merged_data)}个航测点。"
    )

    # 对每个人工采样点，找到最近的航测点
    for idx, measure_row in measure_data.iterrows():
        measure_lat = measure_row["Latitude"]
        measure_lon = measure_row["Longitude"]

        # 计算到所有航测点的距离
        distances = []
        for _, merged_row in merged_data.iterrows():
            dist = haversine(
                measure_lat,
                measure_lon,
                merged_row["Latitude"],
                merged_row["Longitude"],
            )
            distances.append(dist)

        # 找到最近的点
        min_dist_idx = int(np.argmin(distances))
        matched_idx.append(min_dist_idx)
        logger.info(
            f"人工采样点 {idx} (lat: {measure_lat}, lon: {measure_lon}) 匹配到最近航测点索引 {min_dist_idx}，距离为 {distances[min_dist_idx]:.4f} 米。"
        )

    logger.info("所有人工采样点已完成匹配。")
    return matched_idx


def handle_invalid_values(
    pred_data: pd.DataFrame, matched_merged_df: pd.DataFrame
) -> pd.DataFrame:
    """
    处理无效值，用原始航测数据替换

    Args:
        pred_data: 预测数据DataFrame
        matched_merged_df: 匹配的原始航测数据DataFrame

    Returns:
        pd.DataFrame: 处理后的预测数据DataFrame
    """
    # 检查pred_data中缺失的列
    missing_cols = set(matched_merged_df.columns) - set(pred_data.columns)
    if missing_cols:
        logger.warning(f"发现{len(missing_cols)}个缺失列: {', '.join(missing_cols)}")
        # 从matched_merged_df中复制缺失的列
        for col in missing_cols:
            pred_data[col] = matched_merged_df[col]
        logger.info("已从原始航测数据补充缺失列")

    # 检查pred_data中的无效值
    invalid_mask = pred_data.isna() | (pred_data <= 0)
    invalid_count = invalid_mask.sum().sum()

    if invalid_count > 0:
        logger.warning(f"发现{invalid_count}个无效值(NA或非正数)")

        # 记录每个指标中无效值的数量
        for col in pred_data.columns:
            col_invalid = invalid_mask[col].sum()
            if col_invalid > 0:
                logger.warning(f"指标 {col} 中存在 {col_invalid} 个无效值")

                # 记录具体的行索引
                invalid_rows = pred_data.index[invalid_mask[col]].tolist()
                logger.warning(f"无效值出现在行: {invalid_rows}")

        # 用matched_merged_df的值替换无效值
        pred_data = pred_data.where(~invalid_mask, matched_merged_df)
        logger.info("已用原始航测数据替换所有无效值")
    else:
        logger.info("未发现无效值")

    # 按照matched_merged_df的列顺序重新排列pred_data的列
    # pred_data = pred_data[matched_merged_df.columns]

    return pred_data


class DataMatcher:
    """数据匹配处理器

    职责：
    - 匹配 UAV 反演数据与实地测量数据
    - 进行水质模型的优化和建模
    - 管理建模结果数据

    原始职责来自：
    - AeroSpotReportGenerator._match_analyze_data() 的第 571-579 行

    示例：
        >>> matcher = DataMatcher(data_processor)
        >>> results = matcher.match_and_analyze(
        ...     merged_data, measure_data, ref_data,
        ...     hist_ref, hist_merged, hist_measure
        ... )
    """

    def __init__(self, data_processor: Any) -> None:
        """初始化数据匹配器

        Args:
            data_processor: 数据处理器实例，提供 match_and_analyze_data 方法
        """
        self.data_processor = data_processor
        self.logger = logger
        self.last_results = None

    def match_and_analyze(
        self,
        merged_data: pd.DataFrame,
        measure_data: pd.DataFrame,
        ref_data: pd.DataFrame,
        historical_ref: Optional[pd.DataFrame] = None,
        historical_merged: Optional[pd.DataFrame] = None,
        historical_measure: Optional[pd.DataFrame] = None,
    ) -> Any:
        """执行数据匹配和建模分析

        将当前数据与历史数据组合，进行模型优化和预测。

        Args:
            merged_data: 当前 UAV 反演数据
            measure_data: 当前实地测量数据
            ref_data: 当前参考光谱数据
            historical_ref: 历史参考光谱数据（可选）
            historical_merged: 历史 UAV 反演数据（可选）
            historical_measure: 历史实地测量数据（可选）

        Returns:
            Tuple[Any, Any, Any, Any, Any]: 包含以下内容：
                - comparison_data: 对比数据
                - pred_data: 预测数据
                - model_func: 模型函数
                - all_pred_data: 所有预测数据
                - his_instance: 历史数据实例

        Raises:
            Exception: 匹配或建模过程中的任何错误
        """
        try:
            self.logger.info("开始数据匹配和建模")

            # 调用数据处理器的匹配方法
            results = self.data_processor.match_and_analyze_data(
                merged_data,
                measure_data,
                ref_data,
                historical_ref,
                historical_merged,
                historical_measure,
            )

            # 保存结果以供后续使用
            self.last_results = results

            self.logger.info("数据匹配和建模完成")
            return results

        except Exception as e:
            self.logger.exception(f"数据匹配失败: {e}")
            raise

    def get_last_results(self) -> Optional[Tuple]:
        """获取最后一次匹配的结果

        Returns:
            Optional[Tuple]: 最后一次匹配的结果，若无则返回 None
        """
        return self.last_results

    def validate_data(
        self,
        merged_data: pd.DataFrame,
        measure_data: pd.DataFrame,
        ref_data: pd.DataFrame,
    ) -> bool:
        """验证输入数据的有效性

        Args:
            merged_data: UAV 反演数据
            measure_data: 实地测量数据
            ref_data: 参考光谱数据

        Returns:
            bool: 数据是否有效
        """
        try:
            # 检查数据框不为空
            if merged_data is None or merged_data.empty:
                self.logger.error("merged_data 为空或 None")
                return False

            if measure_data is None or measure_data.empty:
                self.logger.error("measure_data 为空或 None")
                return False

            if ref_data is None or ref_data.empty:
                self.logger.error("ref_data 为空或 None")
                return False

            self.logger.debug("输入数据有效")
            return True

        except Exception as e:
            self.logger.exception(f"数据验证异常: {e}")
            return False
