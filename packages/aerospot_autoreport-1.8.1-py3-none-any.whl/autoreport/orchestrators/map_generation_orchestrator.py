#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""地图生成流程编排器

编排和协调地图生成的各个阶段，包括地图数据准备、地图类型判断、指标地图生成和结果保存。

Phase 3 改进：
- 集成HeatmapGenerator用于heatmap_only模式
- 自动检测执行模式，选择最优的地图生成策略
- 对heatmap_only模式使用独立的、高效的HeatmapGenerator实现
"""

import logging
import os
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.boundary_manager import BoundaryManager
from ..core.configuration_service import ConfigurationService
from ..models.report_data import ReportData
from ..processor.maps import (
    InterpolationEngine,
    RendererFactory,
    GeoUtilities,
    SatelliteImageLoader,
    HeatmapGenerator,
)
from ..processor.maps.engines import IndicatorMapEngine
from ..processor.maps.visualization.rendering_config import global_rendering_config
from ..utils.path import PathManager
from .orchestrator import Orchestrator

logger = logging.getLogger(__name__)


class MapGenerationOrchestrator(Orchestrator):
    """地图生成流程编排器

    职责：
    - 准备地图生成所需的数据
    - 为每个指标判断应生成的地图类型
    - 执行指标地图的渲染和生成
    - 管理地图输出文件

    原始职责来自 AeroSpotReportGenerator 的以下方法：
    - _prepare_map_generation_data()
    - _initialize_renderer()
    - _compute_colorbar_range()
    - _perform_interpolation()
    - generate_indicator_maps()

    示例：
        >>> orchestrator = MapGenerationOrchestrator(
        ...     config_service=config_service,
        ...     path_manager=path_manager,
        ... )
        >>> if orchestrator.generate(report_data):
        ...     print("地图生成成功")
        ... else:
        ...     print("地图生成失败")
    """

    def __init__(
        self,
        config_service: ConfigurationService,
        path_manager: PathManager,
        boundary_manager: Optional[BoundaryManager] = None,
        map_generation_config=None,
        rendering_config=None,
    ) -> None:
        """初始化地图生成编排器

        Args:
            config_service: 配置服务实例
            path_manager: 路径管理器实例
            boundary_manager: 边界管理器（可选）
            map_generation_config: 地图生成配置对象
            rendering_config: 渲染配置对象
        """
        super().__init__()
        self.config_service = config_service
        self.path_manager = path_manager
        self.boundary_manager = boundary_manager
        self.logger = logger
        self.map_generation_config = map_generation_config
        self.rendering_config = rendering_config

        # 延迟初始化的组件
        self.interpolation_engine: Optional[InterpolationEngine] = None
        self.geo_utilities: Optional[GeoUtilities] = None
        self.satellite_loader: Optional[SatelliteImageLoader] = None

    def execute(self, data: ReportData) -> ReportData:
        """执行编排流程（Orchestrator 接口实现）

        Args:
            data: ReportData模型实例

        Returns:
            ReportData: 处理后的模型实例
        """
        return self.generate(data)

    def validate_input(self, data: ReportData) -> bool:
        """验证输入数据的有效性（Orchestrator 接口实现）

        Args:
            data: 需要验证的报告数据模型

        Returns:
            bool: 验证通过返回 True；失败返回 False
        """
        if data is None:
            self.logger.error("输入数据为 None")
            return False

        if data.config is None:
            self.logger.error("配置信息缺失")
            return False

        return True

    def generate(self, report_data: ReportData) -> ReportData:
        """执行地图生成流程

        执行顺序：
        1. 初始化所有必要的组件
        2. 准备地图生成所需数据
        3. 为每个指标生成地图
        4. 保存地图路径到报告数据

        Phase 3 改进：
        - 自动检测heatmap_only模式，使用HeatmapGenerator
        - full_report模式使用原有的多类型地图生成逻辑

        Args:
            report_data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例，包含maps字段
        """
        try:
            self.logger.info("=" * 60)
            self.logger.info("启动地图生成流程")
            self.logger.info("=" * 60)

            # 检测执行模式：是否为heatmap_only模式
            is_heatmap_only_mode = (
                self.map_generation_config
                and hasattr(self.map_generation_config, 'allowed_types')
                and self.map_generation_config.allowed_types == ["clean_interpolation_svg"]
            )

            if is_heatmap_only_mode:
                self.logger.info("检测到heatmap_only模式，使用独立的HeatmapGenerator")
                return self._generate_heatmap_only(report_data)
            else:
                self.logger.info("使用全功能的地图生成（full_report模式）")
                return self._generate_full_report(report_data)

        except Exception as e:
            self.logger.exception(f"地图生成异常: {e}")
            report_data.update_processing_state("failed", f"地图生成失败: {str(e)}")
            return report_data

    def _generate_heatmap_only(self, report_data: ReportData) -> ReportData:
        """为heatmap_only模式生成热力图

        在heatmap_only模式下，使用独立的HeatmapGenerator实现专门的热力图生成。
        相比full_report模式，heatmap_only提供了以下优化：
        - 专注于clean_interpolation_svg和colorbar的生成
        - 使用更高效的插值算法
        - 优化的SVG和colorbar输出格式

        Args:
            report_data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例
        """
        try:
            self.logger.info("启动heatmap_only模式的热力图生成（使用独立HeatmapGenerator）")

            # 导入并实例化HeatmapGenerator
            from ..processor.maps.heatmap_generator import HeatmapGenerator

            heatmap_gen = HeatmapGenerator(
                config_service=self.config_service,
                path_manager=self.path_manager,
                boundary_manager=self.boundary_manager,
                rendering_config=self.rendering_config,
            )

            # 使用HeatmapGenerator生成热力图
            result = heatmap_gen.generate_heatmap(report_data)

            self.logger.info("✓ heatmap_only模式热力图生成完成")
            return result

        except Exception as e:
            self.logger.error(f"heatmap_only模式热力图生成失败: {str(e)}")
            report_data.update_processing_state(
                "failed", f"热力图生成失败: {str(e)}"
            )
            return report_data

    def _generate_full_report(self, report_data: ReportData) -> ReportData:
        """为full_report模式生成多类型地图

        原始的全功能地图生成逻辑，支持多种地图类型。

        Args:
            report_data: ReportData模型实例

        Returns:
            ReportData: 更新后的模型实例，包含maps字段
        """
        try:
            # 初始化延迟加载的组件
            if self.interpolation_engine is None:
                self.interpolation_engine = InterpolationEngine(
                    config_service=self.config_service
                )
            if self.geo_utilities is None:
                self.geo_utilities = GeoUtilities()
            if self.satellite_loader is None:
                self.satellite_loader = SatelliteImageLoader()

            # 从ReportData中提取必要的数据
            data_to_process, indicator_columns = self._extract_data_to_process(report_data)
            if data_to_process is None or not indicator_columns:
                self.logger.info("无有效的数据用于地图生成，跳过地图生成")
                return report_data

            # 解析地理边界
            geo_info = report_data.config.get("geo_info", {})
            satellite_img = report_data.image_resources.satellite

            try:
                geo_bounds = self.geo_utilities.parse_bounds(geo_info)
                satellite_geo_bounds = geo_bounds
                self.logger.info(f"卫星图地理边界: {satellite_geo_bounds}")
            except Exception as e:
                self.logger.error(f"解析地理边界失败: {str(e)}")
                satellite_geo_bounds = None

            # 计算数据地理边界
            try:
                data_geo_bounds = (
                    float(data_to_process["Longitude"].min()),
                    float(data_to_process["Latitude"].min()),
                    float(data_to_process["Longitude"].max()),
                    float(data_to_process["Latitude"].max()),
                )
                self.logger.info(f"数据地理边界: {data_geo_bounds}")
            except Exception as e:
                self.logger.error(f"计算数据地理边界失败: {str(e)}")
                return report_data

            # 如果卫星图边界为 None，使用数据边界作为回退
            if satellite_geo_bounds is None:
                satellite_geo_bounds = data_geo_bounds

            # 检查数据点是否都在卫星图范围外
            try:
                all_points_outside = (
                    data_geo_bounds[0] > satellite_geo_bounds[2]
                    or data_geo_bounds[2] < satellite_geo_bounds[0]
                    or data_geo_bounds[1] > satellite_geo_bounds[3]
                    or data_geo_bounds[3] < satellite_geo_bounds[1]
                )
                if all_points_outside:
                    self.logger.warning("所有数据点都在卫星图像范围外")
            except Exception as e:
                self.logger.error(f"检查点范围失败: {str(e)}")
                all_points_outside = False

            # 加载卫星图像
            satellite_info = None
            if satellite_img:
                try:
                    satellite_info = self.satellite_loader.load(satellite_img)
                    self.logger.info(f"卫星图像加载成功: {satellite_info}")
                except Exception as e:
                    self.logger.error(f"加载卫星图像失败: {str(e)}")
                    # 不再根据执行模式决定是否返回，由调用者决定
                    self.logger.warning("继续处理（无卫星图像）")
            else:
                self.logger.warning("未提供卫星图像，某些功能可能不可用")

            # 初始化渲染器
            factory = RendererFactory(
                satellite_info=satellite_info,
                geo_bounds=satellite_geo_bounds,
                config_service=self.config_service,
            )
            renderer = factory.get_renderer()

            # 创建指标引擎用于逻辑判断
            indicator_engine = IndicatorMapEngine()

            # 生成所有指标的地图
            maps_paths: Dict[str, Dict[str, str]] = {}
            has_measured_data = report_data.measure_data is not None and not report_data.measure_data.get("data", pd.DataFrame()).empty

            # 获取地图类型过滤（如果有）
            map_types_filter = None
            if self.map_generation_config and hasattr(self.map_generation_config, 'allowed_types'):
                map_types_filter = self.map_generation_config.allowed_types
            else:
                map_types_filter = getattr(report_data, 'map_types_filter', None)

            for indicator in indicator_columns:
                self.logger.info(f"处理指标: {indicator}")

                try:
                    # 计算 colorbar 范围
                    vmin, vmax = self._compute_colorbar_range(
                        data_to_process, indicator
                    )

                    # 检查是否为 NDVI 指标和是否支持分级
                    is_ndvi = indicator.upper() == "NDVI"
                    grade_config = renderer.grade_manager.get_grade_config(indicator)
                    supports_grading = grade_config is not None

                    # 构建临时prep_data用于向后兼容
                    prep_data = {
                        "has_measured_data": has_measured_data,
                        "visualization_mode": self.config_service.get_visualization_mode() if self.config_service else "quantitative",
                    }

                    # 决定该指标的地图类型
                    map_types = indicator_engine.determine_map_types(
                        indicator, prep_data, renderer
                    )

                    # 应用地图类型过滤（如果有）
                    if map_types_filter:
                        map_types = [mt for mt in map_types if mt in map_types_filter]
                        self.logger.info(f"{indicator} 应用地图类型过滤: {map_types}")

                    # 初始化该指标的地图路径字典
                    maps_paths[indicator] = {}

                    # 创建该指标的渲染会话
                    session = renderer.prepare_rendering_session(
                        indicator=indicator,
                        data=data_to_process,
                        satellite_geo_bounds=satellite_geo_bounds,
                        data_geo_bounds=data_geo_bounds,
                        all_points_outside=all_points_outside,
                        colorbar_mode=(
                            "quantitative"
                            if prep_data["visualization_mode"] == "quantitative"
                            else "qualitative"
                        ),
                        has_colorbar=True,
                    )

                    # 生成散点分布图
                    if "distribution" in map_types:
                        try:
                            save_path = os.path.join(
                                self.path_manager.get_path("maps"),
                                f"{indicator}_distribution.png",
                            )
                            result = renderer.render_distribution(
                                data=data_to_process,
                                indicator=indicator,
                                save_path=save_path,
                                session=session,
                            )
                            if result:
                                maps_paths[indicator]["distribution"] = result
                                self.logger.info(f"✓ {indicator} 散点分布图生成成功")
                        except Exception as e:
                            self.logger.error(
                                f"生成 {indicator} 散点分布图失败: {str(e)}"
                            )

                    # 如果需要插值，执行一次插值并保存结果
                    if self._needs_interpolation(map_types):
                        self.logger.info(f"开始对 {indicator} 执行插值...")
                        Z, grid_lon, grid_lat, mask, boundary = (
                            self._perform_interpolation(
                                data_to_process=data_to_process,
                                indicator=indicator,
                                satellite_geo_bounds=satellite_geo_bounds,
                            )
                        )

                        if Z is not None:
                            self.logger.info(
                                f"{indicator} 插值完成，网格大小: {Z.shape}"
                            )

                            # 生成基于插值结果的地图
                            self._generate_interpolation_based_maps(
                                renderer=renderer,
                                indicator=indicator,
                                map_types=map_types,
                                Z=Z,
                                grid_lon=grid_lon,
                                grid_lat=grid_lat,
                                session=session,
                                data=data_to_process,
                                data_geo_bounds=data_geo_bounds,
                                prep_data=prep_data,
                                is_ndvi=is_ndvi,
                                supports_grading=supports_grading,
                                maps_paths=maps_paths,
                            )
                        else:
                            self.logger.warning(f"{indicator} 插值失败，跳过后续处理")

                    self.logger.info(f"✓ {indicator} 处理完成")

                except Exception as e:
                    self.logger.error(f"处理 {indicator} 时出错: {str(e)}")

            # 保存地图路径到报告数据模型
            report_data.maps = maps_paths
            self.logger.info(
                f"地图生成完成，共生成 {len(indicator_columns)} 个指标的地图"
            )

            return report_data

        except Exception as e:
            self.logger.exception(f"full_report模式地图生成异常: {e}")
            report_data.update_processing_state("failed", f"地图生成失败: {str(e)}")
            return report_data

    def _extract_data_to_process(
        self, report_data: ReportData
    ) -> tuple[Optional[pd.DataFrame], list[str]]:
        """从ReportData中提取用于地图生成的数据

        确定使用哪个数据源（降级逻辑：优先 pred_data，其次 uav_data）。

        Args:
            report_data: ReportData模型实例

        Returns:
            tuple: (data_to_process, indicator_columns)，如果无有效数据返回 (None, [])
        """
        try:
            # 获取所有可用数据源
            pred_data = report_data.config.get("all_pred_data")
            uav_data = report_data.uav_data.get("data") if report_data.uav_data else None

            # 确定使用哪个数据源
            if pred_data is not None and not pred_data.empty:
                data_to_process = pred_data
                self.logger.info(f"使用预测数据，包含 {len(pred_data)} 条记录")
            elif uav_data is not None and not uav_data.empty:
                data_to_process = uav_data
                self.logger.info(f"使用 UAV 反演数据，包含 {len(uav_data)} 条记录")
            else:
                self.logger.warning("无有效的数据源，跳过地图生成")
                return None, []

            # 提取指标列表（排除坐标列）
            indicator_columns = [
                col
                for col in data_to_process.columns
                if col not in ["Longitude", "Latitude", "index"]
            ]

            if not indicator_columns:
                self.logger.warning("未找到有效的指标列，跳过地图生成")
                return None, []

            return data_to_process, indicator_columns

        except Exception as e:
            self.logger.error(f"提取地图数据失败: {str(e)}")
            return None, []

    def _compute_colorbar_range(
        self, data: pd.DataFrame, indicator: str
    ) -> Tuple[float, float]:
        """计算指标的 colorbar 范围

        基于原始数据点的 min/max，确保所有图都使用一致的 colorbar 范围。
        这是 interpolation 图和 clean_transparent 图共用的 colorbar 范围。

        Args:
            data: 包含指标数据的 DataFrame
            indicator: 指标名称

        Returns:
            Tuple[float, float]: (vmin, vmax) colorbar 范围
        """
        original_values = data[indicator].values
        original_values_clean = original_values[np.isfinite(original_values)]

        if len(original_values_clean) == 0:
            self.logger.warning(f"{indicator} 没有有效的数据值，使用默认范围")
            return 0.0, 1.0

        vmin = float(np.min(original_values_clean))
        vmax = float(np.max(original_values_clean))
        self.logger.info(f"{indicator} colorbar 范围: [{vmin:.3f}, {vmax:.3f}]")
        return vmin, vmax

    def _perform_interpolation(
        self,
        data_to_process: pd.DataFrame,
        indicator: str,
        satellite_geo_bounds: Tuple[float, float, float, float],
    ) -> Tuple[
        Optional[np.ndarray],
        Optional[np.ndarray],
        Optional[np.ndarray],
        Optional[np.ndarray],
        Optional[np.ndarray],
    ]:
        """执行 Kriging 插值并返回插值结果

        根据 boundary_manager 的状态选择合适的边界检测方法，调用插值引擎生成插值网格数据。

        Args:
            data_to_process: 待插值的数据 DataFrame
            indicator: 指标名称
            satellite_geo_bounds: 卫星图地理边界 [min_lon, min_lat, max_lon, max_lat]

        Returns:
            Tuple: (Z, grid_lon, grid_lat, mask, boundary)
                - Z: 插值结果网格
                - grid_lon: 经度网格
                - grid_lat: 纬度网格
                - mask: 边界掩膜
                - boundary: 边界信息
        """
        # 根据 boundary_manager 的状态选择边界检测方法
        boundary_method = (
            "kml"
            if self.boundary_manager and self.boundary_manager.is_enabled
            else "alpha_shape"
        )
        self.logger.info(f"使用 {boundary_method} 边界检测方法进行插值")

        # 执行插值
        Z, grid_lon, grid_lat, mask, boundary = (
            self.interpolation_engine.enhanced_interpolate(
                all_data=data_to_process,
                indicator_col=indicator,
                fixed_bounds=satellite_geo_bounds,
                boundary_manager=self.boundary_manager,
                boundary_method=boundary_method,
            )
        )

        self.logger.info(
            f"{indicator} 插值完成，网格大小: Z{Z.shape if Z is not None else 'None'}"
        )

        return Z, grid_lon, grid_lat, mask, boundary

    def _needs_interpolation(self, map_types: list) -> bool:
        """判断是否需要执行插值

        Args:
            map_types: 地图类型列表

        Returns:
            bool: 是否需要插值
        """
        interpolation_types = [
            "interpolation",
            "clean_interpolation_svg",
            "level",
            "ndvi_binary",
            "ndvi_bloom_level",
        ]
        return any(t in map_types for t in interpolation_types)
        
    def _calculate_geo_bounds_from_z(
        self,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        original_geo_bounds: Tuple[float, float, float, float],
        indicator: str,
    ) -> Tuple[float, float, float, float]:
        """基于插值后的Z数据范围计算地理边界

        Z已经包含了所有约束（mask、虚拟点等），其实际数据范围就是最终应显示的范围。
        此方法从Z的有效数据（排除NaN）提取实际的经纬度范围。

        Args:
            Z: 插值结果网格（可含NaN值，代表无效区域）
            grid_lon: 经度网格（与Z同形状）
            grid_lat: 纬度网格（与Z同形状）
            original_geo_bounds: 原始数据的地理边界（用于回退）
            indicator: 指标名称（用于日志）

        Returns:
            Tuple: (lon_min, lat_min, lon_max, lat_max) - Z数据的实际地理范围
        """
        try:
            # 找出Z中有效数据（非NaN）的位置
            valid_mask = ~np.isnan(Z)

            if np.any(valid_mask):
                # 获取有效数据对应的经纬度坐标
                valid_indices = np.where(valid_mask)
                valid_lons = grid_lon[valid_indices]
                valid_lats = grid_lat[valid_indices]

                # 计算Z的实际地理范围
                z_geo_bounds = (
                    float(np.min(valid_lons)),  # lon_min
                    float(np.min(valid_lats)),  # lat_min
                    float(np.max(valid_lons)),  # lon_max
                    float(np.max(valid_lats))   # lat_max
                )
                
                self.logger.info(
                    f"{indicator} 基于Z数据范围的地理边界: {z_geo_bounds}"
                )

                return z_geo_bounds
            else:
                # 如果Z全是NaN（罕见），回退到原始geo_bounds
                self.logger.warning(
                    f"{indicator} Z数据全为NaN，使用原始地理边界作为回退"
                )
                return original_geo_bounds
        except Exception as e:
            self.logger.error(
                f"{indicator} 计算Z地理边界失败: {str(e)}，使用原始边界"
            )
            return original_geo_bounds

    def _generate_interpolation_based_maps(
        self,
        renderer: Any,
        indicator: str,
        map_types: list,
        Z: np.ndarray,
        grid_lon: np.ndarray,
        grid_lat: np.ndarray,
        session: Any,
        data: pd.DataFrame,
        data_geo_bounds: Tuple[float, float, float, float],
        prep_data: Dict[str, Any],
        is_ndvi: bool,
        supports_grading: bool,
        maps_paths: Dict[str, Dict[str, str]],
    ) -> None:
        """生成基于插值结果的地图

        生成 4 种基于插值结果的地图类型：
        1. 热力图
        2. 清洁 SVG 热力图
        3. 等级图
        4. NDVI 藻华检测图

        Args:
            renderer: 地图渲染器实例
            indicator: 指标名称
            map_types: 地图类型列表
            Z: 插值结果网格
            grid_lon: 经度网格
            grid_lat: 纬度网格
            session: 渲染会话
            data: 处理数据
            data_geo_bounds: 数据地理边界
            is_ndvi: 是否为 NDVI 指标
            supports_grading: 是否支持分级
            maps_paths: 地图路径字典（直接修改）
        """
        # 🔧 核心改进：基于 Z 数据计算实际地理边界
        # 获取原始边界（用于回退）
        original_geo_bounds = session.geo_bounds or data_geo_bounds


        # 计算基于 Z 的地理边界
        z_geo_bounds = self._calculate_geo_bounds_from_z(
            Z=Z,
            grid_lon=grid_lon,
            grid_lat=grid_lat,
            original_geo_bounds=original_geo_bounds,
            indicator=indicator
        )

        # 创建新的会话副本，使用基于 Z 的地理边界
        # 这样可以保持原始会话不变，同时为当前指标使用正确的边界
        from copy import deepcopy
        z_session = deepcopy(session)
        z_session.geo_bounds = z_geo_bounds

        
        # 1. 热力图
        if "interpolation" in map_types:
            try:
                save_path = os.path.join(
                    self.path_manager.get_path("maps"),
                    f"{indicator}_interpolation.png",
                )
                result = renderer.render_interpolation(
                    data=data,
                    indicator=indicator,
                    Z=Z,
                    grid_lon=grid_lon,
                    grid_lat=grid_lat,
                    save_path=save_path,
                    session=z_session,
                )
                if result:
                    maps_paths[indicator]["interpolation"] = result
                    self.logger.info(f"✓ {indicator} 插值热力图生成成功")
            except Exception as e:
                self.logger.error(f"生成 {indicator} 插值热力图失败: {str(e)}")

        # 2. 等级图
        if (
            "level" in map_types
            and supports_grading
            and IndicatorMapEngine().is_quantitative_mode(prep_data)
        ):
            try:
                save_path = os.path.join(
                    self.path_manager.get_path("maps"),
                    f"{indicator}_level.png",
                )
                result = renderer.render_level(
                    Z=Z,
                    grid_lon=grid_lon,
                    grid_lat=grid_lat,
                    indicator=indicator,
                    save_path=save_path,
                    session=z_session,
                )
                if result:
                    maps_paths[indicator]["level"] = result
                    self.logger.info(f"✓ {indicator} 等级图生成成功")
            except Exception as e:
                self.logger.error(f"生成 {indicator} 等级图失败: {str(e)}")

        # 4. NDVI 藻华检测图
        if is_ndvi and ("ndvi_binary" in map_types or "ndvi_bloom_level" in map_types):
            try:
                # 二值化藻华检测图
                if "ndvi_binary" in map_types:
                    save_path = os.path.join(
                        self.path_manager.get_path("maps"),
                        f"{indicator}_ndvi_binary.png",
                    )
                    result = renderer.render_ndvi_binary(
                        indicator=indicator,
                        save_path=save_path,
                        Z=Z,
                        session=z_session,
                        grid_lon=grid_lon,
                        grid_lat=grid_lat,
                    )
                    if result:
                        maps_paths[indicator]["ndvi_binary"] = result

                # 藻华程度分级图
                if "ndvi_bloom_level" in map_types:
                    save_path = os.path.join(
                        self.path_manager.get_path("maps"),
                        f"{indicator}_ndvi_bloom_level.png",
                    )
                    result = renderer.render_ndvi_bloom_level(
                        indicator=indicator,
                        save_path=save_path,
                        Z=Z,
                        session=z_session,
                        grid_lon=grid_lon,
                        grid_lat=grid_lat,
                    )
                    if result:
                        maps_paths[indicator]["ndvi_bloom_level"] = result

                self.logger.info(f"✓ {indicator} NDVI 地图生成成功")
            except Exception as e:
                self.logger.error(f"生成 {indicator} NDVI 地图失败: {str(e)}")
