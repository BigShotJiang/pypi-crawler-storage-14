#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
报告数据模型定义 - 核心数据结构

该模块定义了整个报告生成系统的核心数据结构 ReportData，
替代原有的动态字典 Dict[str, Any]，提供类型安全和验证能力。

字段生命周期说明：
- **基础配置**：初始化时填充
- **第1阶段：资源**：资源下载后填充（image_resources）
- **第2阶段：数据处理**：数据处理后填充（uav_data, measure_data）
- **第3阶段：地图生成**：地图生成后填充（maps）
- **第4阶段：报告生成**：报告生成后填充（report_path, config_path）
- **处理状态**：全程更新（processing_state, error_message, timestamp）
"""

import logging
from typing import Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, field_validator, ConfigDict

logger = logging.getLogger(__name__)


class ImageResources(BaseModel):
    """图片资源模型

    存储报告生成过程中所需的各种图片资源的路径。
    这些资源在第1阶段（资源下载）时被填充。
    """

    model_config = ConfigDict(
        extra="forbid",
        arbitrary_types_allowed=True,
    )

    logo: Optional[str] = Field(
        default=None, description="公司logo路径或URL"
    )
    satellite: Optional[str] = Field(
        default=None, description="卫星遥感影像路径或URL"
    )
    wayline: Optional[str] = Field(
        default=None, description="无人机航线图路径或URL"
    )


class ReportData(BaseModel):
    """核心报告数据模型

    这个模型替代原有的动态字典 Dict[str, Any]，为报告生成系统
    提供类型安全、验证和IDE智能提示的支持。

    使用示例：
        >>> from autoreport.models.report_data import ReportData
        >>> report_data = ReportData(
        ...     config=config_dict,
        ...     output_dir="./output"
        ... )
        >>> report_data.processing_state = "processing"
    """

    # ========================================================================
    # 第0阶段：基础配置（初始化时填充）
    # ========================================================================

    config: Dict[str, Any] = Field(
        ..., description="应用配置字典，包含company_info等信息"
    )

    output_dir: str = Field(
        ..., description="报告输出目录的根路径"
    )

    # ========================================================================
    # 第1阶段：资源（资源下载后填充）
    # ========================================================================

    image_resources: ImageResources = Field(
        default_factory=ImageResources,
        description="图片资源（logo、卫星影像、航线图等）"
    )

    # ========================================================================
    # 第2阶段：数据处理（数据处理完成后填充）
    # ========================================================================

    uav_data: Optional[Dict[str, Any]] = Field(
        default=None,
        description="无人机反演数据（包含各种指标的数据）"
    )

    measure_data: Optional[Dict[str, Any]] = Field(
        default=None,
        description="实地测量数据（用于对比和验证）"
    )

    # ========================================================================
    # 第3阶段：地图生成（地图生成完成后填充）
    # ========================================================================

    maps: Optional[Dict[str, Dict[str, str]]] = Field(
        default=None,
        description="生成的地图集合，key为指标名称，value为该指标各类型地图的路径字典"
    )

    # ========================================================================
    # 第4阶段：报告生成（报告生成完成后填充）
    # ========================================================================

    report_path: Optional[str] = Field(
        default=None,
        description="最终生成的Word报告路径"
    )

    config_path: Optional[str] = Field(
        default=None,
        description="处理后的配置文件保存路径"
    )

    # ========================================================================
    # 处理状态（全程更新）
    # ========================================================================

    processing_state: str = Field(
        default="pending",
        description="处理状态：pending(待处理)/processing(处理中)/success(成功)/failed(失败)"
    )

    error_message: Optional[str] = Field(
        default=None,
        description="错误信息（仅在failed状态时有值）"
    )

    timestamp: datetime = Field(
        default_factory=datetime.now,
        description="创建时间戳"
    )

    # ========================================================================
    # 几何边界（可选，集成KML修复）
    # ========================================================================

    boundary_geom: Optional[Any] = Field(
        default=None,
        description="地理边界几何体（shapely Polygon/MultiPolygon）"
    )

    model_config = ConfigDict(
        # 禁止动态添加字段，确保类型安全
        extra="forbid",
        # 实时验证赋值，每次修改字段时验证
        validate_assignment=True,
        # 允许任意类型（如shapely几何体）
        arbitrary_types_allowed=True,
    )

    @field_validator("processing_state")
    @classmethod
    def validate_processing_state(cls, v: str) -> str:
        """验证处理状态是否为有效值"""
        valid_states = {"pending", "processing", "success", "failed"}
        if v not in valid_states:
            raise ValueError(
                f"processing_state必须是以下之一: {valid_states}，"
                f"收到: {v}"
            )
        return v

    @field_validator("boundary_geom")
    @classmethod
    def validate_boundary_geom(cls, v: Any) -> Any:
        """验证和修复几何体（集成KML修复逻辑）"""
        if v is not None:
            try:
                from autoreport.utils.kml import _fix_geometry_with_retry
                v = _fix_geometry_with_retry(v, max_attempts=3)
                if v is None:
                    logger.warning("几何体无法修复，将被设置为None")
            except Exception as e:
                logger.error(f"几何体验证失败: {str(e)}")
                # 不抛异常，只记录日志，允许继续
        return v

    def update_processing_state(self, state: str, error: Optional[str] = None) -> None:
        """更新处理状态

        Args:
            state: 新的处理状态
            error: 错误信息（仅当state为'failed'时有用）

        Examples:
            >>> report_data.update_processing_state("processing")
            >>> report_data.update_processing_state("failed", "数据处理失败")
        """
        self.processing_state = state
        self.timestamp = datetime.now()
        if state == "failed" and error:
            self.error_message = error
        elif state != "failed":
            self.error_message = None

    def is_complete(self) -> bool:
        """检查报告生成是否完成

        Returns:
            True 如果report_path和config_path都已设置，表示报告已生成
        """
        return self.report_path is not None and self.config_path is not None

    def get_summary(self) -> Dict[str, Any]:
        """获取报告数据的摘要信息

        Returns:
            包含关键信息的字典，用于日志记录和调试
        """
        return {
            "processing_state": self.processing_state,
            "timestamp": self.timestamp.isoformat(),
            "output_dir": self.output_dir,
            "has_uav_data": self.uav_data is not None,
            "has_measure_data": self.measure_data is not None,
            "has_maps": self.maps is not None and len(self.maps) > 0,
            "report_completed": self.is_complete(),
            "error_message": self.error_message,
        }
