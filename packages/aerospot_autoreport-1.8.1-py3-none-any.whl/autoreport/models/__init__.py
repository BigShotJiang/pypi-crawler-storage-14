#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Models package for AeroSpot AutoReport"""

from .map_data import (
    IndicatorContext,
    InterpolationResult,
    MapPrepData,
    RenderingResult,
    SatelliteInfo,
)

__all__ = [
    "MapPrepData",
    "IndicatorContext",
    "InterpolationResult",
    "RenderingResult",
    "SatelliteInfo",
]
