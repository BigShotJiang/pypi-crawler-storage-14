from .abc_continuum_object import ABCContinuumObject, ABCContinuumObjectNoId


class DataCenter(ABCContinuumObject): ...
