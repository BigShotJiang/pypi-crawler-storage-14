#!/usr/bin/env python3
"""Main entry point for dustr module"""

from dustr import main

if __name__ == "__main__":
    main()
