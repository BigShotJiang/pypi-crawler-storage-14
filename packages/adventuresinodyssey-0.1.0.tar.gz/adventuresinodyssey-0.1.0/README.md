# Adventures in Odyssey API Client

An unofficial Python API client for the Adventures in Odyssey Club and public endpoints. This library allows you to interact with AIO content, including retrieving metadata for albums and episodes.

**Note:** This is an Alpha release. APIs may change.

## Installation

Install the package via pip:

```bash
pip install adventuresinodyssey
```

### Important: Browser Requirement

This library uses Playwright for authentication. After installing the package, you must install the required browser binaries (Chromium):

```bash
playwright install chromium
```
