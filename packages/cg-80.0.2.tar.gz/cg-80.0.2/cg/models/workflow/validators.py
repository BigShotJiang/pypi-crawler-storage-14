def get_first_word(value: str) -> str:
    return value.split(" ")[0]
