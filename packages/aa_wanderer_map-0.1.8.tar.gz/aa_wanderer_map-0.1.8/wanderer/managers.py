"""Models managers"""

from django.db import models


class WandererManagedMapManager(models.Manager):
    """Manager for WandererManagedMaps"""
