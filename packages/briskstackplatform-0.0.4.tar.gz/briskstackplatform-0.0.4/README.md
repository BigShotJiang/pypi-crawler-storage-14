# BriskStack Platform SDK (Python)

Official Python SDK for the BriskStack Platform. Access all BriskStack services through a single unified SDK.

[![PyPI version](https://badge.fury.io/py/briskstack-platform-sdk.svg)](https://pypi.org/project/briskstack-platform-sdk/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/briskstack-platform-sdk.svg)](https://pypi.org/project/briskstack-platform-sdk/)

## Installation

```bash
pip install briskstack-platform-sdk
```

Or with poetry:
```bash
poetry add briskstack-platform-sdk
```

Or with pipenv:
```bash
pipenv install briskstack-platform-sdk
```

## Quick Start

```python
from briskstack_platform_sdk import (
    Configuration,
    ApiClient,
    HelloWorldMessagesApi,
    AiGatewayChatApi
)

# Configure once for all services
config = Configuration(
    host='https://api.briskstack.com',
    access_token='your-jwt-token'
)

client = ApiClient(config)

# Use different services
hello_world_api = HelloWorldMessagesApi(client)
message = hello_world_api.hello_world_v1_messages_post(
    hello_world_create_message_request={'content': 'Hello!'}
)

ai_gateway_api = AiGatewayChatApi(client)
completion = ai_gateway_api.ai_gateway_v1_chat_completions_post(
    ai_gateway_chat_completion_request={
        'model': 'gpt-4',
        'messages': [{'role': 'user', 'content': 'Hello AI'}]
    }
)
```

## Features

- 🚀 **Unified SDK** - Access all BriskStack services through a single package
- 🔐 **Multiple Auth Methods** - Support for JWT tokens and API keys
- 🌐 **Environment URLs** - Predefined configs for dev, staging, and production
- 📝 **Type Hints** - Full type annotations for better IDE support
- 🔄 **Auto-generated** - Always up-to-date with the latest API changes
- 🐍 **Python 3.8+** - Modern Python support

## Authentication

### Bearer Token (JWT)

For user authentication via Supabase:

```python
from briskstack_platform_sdk import Configuration, ApiClient

config = Configuration(
    host='https://api.briskstack.com',
    access_token='your-jwt-token'
)

client = ApiClient(config)
```

### API Key

For BYOK (Bring Your Own Key) scenarios:

```python
from briskstack_platform_sdk import Configuration, ApiClient

config = Configuration(
    host='https://api.briskstack.com',
    api_key={'X-API-Key': 'your-api-key'}
)

client = ApiClient(config)
```

## Environment URLs

The SDK supports multiple environments:

```python
# Development
config = Configuration(
    host='https://api-dev.briskstack.com',
    access_token='your-token'
)

# Staging
config = Configuration(
    host='https://api-staging.briskstack.com',
    access_token='your-token'
)

# Production
config = Configuration(
    host='https://api.briskstack.com',
    access_token='your-token'
)
```

## Available Services

This SDK includes all BriskStack platform services:

- **Hello World** - Example service
- **AI Gateway** - AI model integrations
- *(More services added automatically)*

See the [API documentation](https://docs.briskstack.com) for complete service details.

## Usage Examples

### Hello World Service

```python
from briskstack_platform_sdk import Configuration, ApiClient, HelloWorldMessagesApi

config = Configuration(
    host='https://api.briskstack.com',
    access_token='your-jwt-token'
)

client = ApiClient(config)
api = HelloWorldMessagesApi(client)

# Create a message
message = api.hello_world_v1_messages_post(
    hello_world_create_message_request={
        'content': 'Hello, World!'
    }
)

print(message.id, message.content)
```

### AI Gateway Service

```python
from briskstack_platform_sdk import Configuration, ApiClient, AiGatewayChatApi

config = Configuration(
    host='https://api.briskstack.com',
    api_key={'X-API-Key': 'your-api-key'}  # Use API key for BYOK
)

client = ApiClient(config)
api = AiGatewayChatApi(client)

# Create a chat completion
completion = api.ai_gateway_v1_chat_completions_post(
    ai_gateway_chat_completion_request={
        'model': 'gpt-4',
        'messages': [
            {'role': 'system', 'content': 'You are a helpful assistant.'},
            {'role': 'user', 'content': 'Tell me a joke about programming.'}
        ]
    }
)

print(completion.choices[0].message.content)
```

## Error Handling

```python
from briskstack_platform_sdk.exceptions import ApiException

try:
    message = api.hello_world_v1_messages_post(
        hello_world_create_message_request={'content': 'Hello!'}
    )
except ApiException as e:
    print(f"Error: {e.status} {e.reason}")
    print(f"Response body: {e.body}")
```

## Async Support

The SDK supports asynchronous operations:

```python
import asyncio
from briskstack_platform_sdk import Configuration, ApiClient, HelloWorldMessagesApi

async def main():
    config = Configuration(
        host='https://api.briskstack.com',
        access_token='your-jwt-token'
    )

    async with ApiClient(config) as client:
        api = HelloWorldMessagesApi(client)
        message = await api.hello_world_v1_messages_post(
            hello_world_create_message_request={'content': 'Hello!'}
        )
        print(message.content)

asyncio.run(main())
```

## Type Hints

This SDK provides full type annotations:

```python
from typing import Dict, Any
from briskstack_platform_sdk import (
    Configuration,
    ApiClient,
    HelloWorldMessagesApi,
    HelloWorldMessage,
    HelloWorldCreateMessageRequest
)

config: Configuration = Configuration(
    host='https://api.briskstack.com',
    access_token='your-jwt-token'
)

request: Dict[str, Any] = {
    'content': 'Hello!',
    'metadata': {'key': 'value'}
}

message: HelloWorldMessage = api.hello_world_v1_messages_post(
    hello_world_create_message_request=request
)
```

## Framework Integration

### FastAPI

```python
from fastapi import FastAPI, Header
from briskstack_platform_sdk import Configuration, ApiClient, HelloWorldMessagesApi

app = FastAPI()

@app.post("/api/hello")
async def create_message(
    content: str,
    authorization: str = Header(...)
):
    config = Configuration(
        host="https://api.briskstack.com",
        access_token=authorization.replace("Bearer ", "")
    )

    async with ApiClient(config) as client:
        api = HelloWorldMessagesApi(client)
        message = await api.hello_world_v1_messages_post(
            hello_world_create_message_request={'content': content}
        )
        return message.to_dict()
```

### Flask

```python
from flask import Flask, request, jsonify
from briskstack_platform_sdk import Configuration, ApiClient, HelloWorldMessagesApi

app = Flask(__name__)

@app.route('/api/hello', methods=['POST'])
def create_message():
    config = Configuration(
        host="https://api.briskstack.com",
        access_token=request.headers.get('Authorization', '').replace('Bearer ', '')
    )

    with ApiClient(config) as client:
        api = HelloWorldMessagesApi(client)
        message = api.hello_world_v1_messages_post(
            hello_world_create_message_request=request.json
        )
        return jsonify(message.to_dict())
```

### Django

```python
from django.http import JsonResponse
from briskstack_platform_sdk import Configuration, ApiClient, HelloWorldMessagesApi
import json

def create_message(request):
    if request.method == 'POST':
        config = Configuration(
            host="https://api.briskstack.com",
            access_token=request.META.get('HTTP_AUTHORIZATION', '').replace('Bearer ', '')
        )

        with ApiClient(config) as client:
            api = HelloWorldMessagesApi(client)
            data = json.loads(request.body)
            message = api.hello_world_v1_messages_post(
                hello_world_create_message_request=data
            )
            return JsonResponse(message.to_dict())
```

## Environment Variables

Best practice is to use environment variables for configuration:

```python
import os
from briskstack_platform_sdk import Configuration, ApiClient

config = Configuration(
    host=os.getenv('BRISKSTACK_API_URL', 'https://api.briskstack.com'),
    access_token=os.getenv('BRISKSTACK_ACCESS_TOKEN')
)

client = ApiClient(config)
```

## Requirements

- Python 3.8+
- urllib3 >= 1.25.3
- python-dateutil

## Contributing

This SDK is automatically generated from OpenAPI specifications. To contribute:

1. Make changes to the platform services in [briskstack-platform](https://github.com/briskstack/briskstack-platform)
2. The SDK will be automatically regenerated and published

## Documentation

- [API Documentation](https://docs.briskstack.com)
- [Platform Repository](https://github.com/briskstack/briskstack-platform)
- [SDK Generation Guide](https://github.com/briskstack/briskstack-platform/tree/main/sdks)

## License

MIT

## Support

- GitHub Issues: [briskstack/platform-sdk-python/issues](https://github.com/briskstack/platform-sdk-python/issues)
- Email: support@briskstack.com
- Documentation: [docs.briskstack.com](https://docs.briskstack.com)
