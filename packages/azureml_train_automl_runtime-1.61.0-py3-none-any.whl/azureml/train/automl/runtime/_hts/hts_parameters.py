# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from .._solution_accelorators.data_models.hts_parameters import (
    HTSInferenceParameters,
    HTSTrainParameters
)
