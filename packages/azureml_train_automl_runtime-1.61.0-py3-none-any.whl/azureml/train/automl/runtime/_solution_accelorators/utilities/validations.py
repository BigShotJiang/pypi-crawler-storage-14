# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azureml.train.automl._hts.hts_client_utilities import validate_hierarchy_settings
