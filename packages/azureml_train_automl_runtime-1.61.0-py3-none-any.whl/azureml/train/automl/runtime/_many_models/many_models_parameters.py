# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from .._solution_accelorators.data_models.many_models_parameters import (
    ManyModelsInferenceParameters,
    ManyModelsTrainParameters
)
