# beancount-tx-cleanup

Apply a specific set of rules to transaction's payee, populate other transaction's fields.
