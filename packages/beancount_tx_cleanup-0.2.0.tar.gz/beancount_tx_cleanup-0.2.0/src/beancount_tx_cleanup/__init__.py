"""Beancount transaction cleanup utilities."""
