from enum import Enum


class Exchange(Enum):
    BINANCE = "binance"
    HYPERLIQUID = "hyperliquid"
