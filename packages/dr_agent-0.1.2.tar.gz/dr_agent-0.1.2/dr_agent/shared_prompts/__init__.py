from .unified_tool_calling import ALL_PROMPTS as UNIFIED_TOOL_CALLING_PROMPTS
from .unified_tool_calling import (
    STRUCTURED_PROMPTS as UNIFIED_TOOL_CALLING_STRUCTURED_PROMPTS,
)
