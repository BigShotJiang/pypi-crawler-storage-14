# Python Light API

Provides partial Python wrappers for calling NEM and Symbol API functions.

Only a subset of APIs are currently supported.

PRs are accepted for extending the set of APIs.
