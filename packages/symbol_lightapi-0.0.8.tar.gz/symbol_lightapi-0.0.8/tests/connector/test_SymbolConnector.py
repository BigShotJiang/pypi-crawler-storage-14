import json
from binascii import hexlify, unhexlify

import pytest
from aiohttp import web
from symbolchain.CryptoTypes import Hash256, PublicKey
from symbolchain.symbol.Network import Address

from symbollightapi.connector.SymbolConnector import SymbolConnector
from symbollightapi.model.Constants import TimeoutSettings, TransactionStatus
from symbollightapi.model.Endpoint import Endpoint
from symbollightapi.model.Exceptions import InsufficientBalanceException, NodeException
from symbollightapi.model.NodeInfo import NodeInfo

from ..test.LightApiTestUtils import HASHES, SYMBOL_ADDRESSES

# region test data


NODE_INFO_1 = {
	'friendlyName': 'The Wolf Farm owned by Tresto(@TrendStream)',
	'host': 'wolf.importance.jp',
	'networkGenerationHashSeed': '57F7DA205008026C776CB6AED843393F04CD458E0AA2D9F1D5F31A402072B2D6',
	'networkIdentifier': 104,
	'nodePublicKey': 'A4714451910AF026AF7A3960FF87EDCA0BA4E80CABCB350FA2B69439E1CB0B97',
	'port': 7900,
	'publicKey': 'D8F4FE47F1F5B1046748067E52725AEBAA1ED9F3CE45D02054011A39671DD9AA',
	'roles': 3,
	'version': 16777988
}

NODE_INFO_2 = {
	'friendlyName': 'Allnodes619',
	'host': 'xym619.allnodes.me',
	'networkGenerationHashSeed': '57F7DA205008026C776CB6AED843393F04CD458E0AA2D9F1D5F31A402072B2D6',
	'networkIdentifier': 104,
	'nodePublicKey': 'A19C14033EB508EF6AD48A3E5D1E7DEDF0B1DCBAD1978CD61797017749A1B999',
	'port': 7900,
	'publicKey': 'FB744B408D392E0F99701432E0BC8A0D38BEFDEA8019826CCE91458C6E734ADB',
	'roles': 3,
	'version': 16777989
}

NODE_INFO_3 = {
	'friendlyName': 'tiger',
	'host': 'tiger.catapult.ninja',
	'networkGenerationHashSeed': '57F7DA205008026C776CB6AED843393F04CD458E0AA2D9F1D5F31A402072B2D6',
	'networkIdentifier': 104,
	'port': 7900,
	'publicKey': 'C807BE28855D0C87A8A2C032E51790CCB9158C15CBACB8B222E27DFFFEB3697D',
	'roles': 5,
	'version': 16777989
}

MULTISIG_INFO_1 = {
	'multisig': {
		'version': 1,
		'accountAddress': '987BC1722F417C93BA80C4212AA0E4621FB5B18550CC4103',
		'minApproval': 2,
		'minRemoval': 3,
		'cosignatoryAddresses': [
			'98AAB8782D4452F0DE6C82A778BB6937C509B9A1AFDF2320',
			'98661D23312F31066CA5298FD453301C930553528FFE0FF1',
			'98BEC4842DEE913E737CC267D984F5FCC955C981291B3936'
		],
		'multisigAddresses': [
			'98D35CCF663D61C64E6B083C08B1544C3D9538EB01369248',
			'98996F3C23DDE4258E9D3E0F0BE4BAED48370CA6EDD7DD2C'
		]
	}
}


def generate_transaction_statuses(status_start_height, status_groups, transaction_hashes):
	return [
		{
			'group': status_groups[i % len(status_groups)],
			'code': f'Failure{i}' if 'failed' == status_groups[i % len(status_groups)] else 'Success',
			'hash': str(transaction_hash),
			'height': str(status_start_height + i)
		}
		for i, transaction_hash in enumerate(transaction_hashes)
	]

# endregion


# region server fixture

@pytest.fixture
async def server(aiohttp_client):
	class MockSymbolServer:
		def __init__(self):
			self.urls = []
			self.status_start_height = 111001
			self.status_groups = ('confirmed', 'unconfirmed')

			self.request_json_payloads = []
			self.simulate_error = False

		async def network_properties(self, request):
			return await self._process(request, {
				'chain': {'currencyMosaicId': '0x72C0\'212E\'67A0\'8BCE'}
			})

		async def chain_info(self, request):
			return await self._process(request, {
				'height': '1234',
				'scoreHigh': '888999',
				'scoreLow': '222111',
				'latestFinalizedBlock': {
					'finalizationEpoch': 222,
					'finalizationPoint': 10,
					'height': '1198',
					'hash': 'C49C566E4CF60856BC127C9E4748C89E3D38566DE0DAFE1A491012CC27A1C043'
				}
			})

		async def node_time(self, request):
			return await self._process(request, {
				'communicationTimestamps': {
					'sendTimestamp': '68414660756',
					'receiveTimestamp': '68414660780'
				}
			})

		async def blocks(self, request):
			height = request.match_info['height']
			return await self._process(request, {
				'meta': {'hash': HASHES[0]},
				'block': {
					'height': str(height),
					'timestamp': '85426407',
				}
			})

		async def node_info(self, request):
			return await self._process(request, NODE_INFO_1)

		async def node_peers(self, request):
			return await self._process(request, [NODE_INFO_2, NODE_INFO_3])

		async def accounts_by_id(self, request):
			account_id = request.match_info['account_id']
			if 'error' == account_id:
				return await self._process(request, {'code': 'ResourceNotFound', 'message': 'accountId does not exist'}, 404)

			json_supplemental_public_keys = {}
			if account_id in ('linked', 'all'):
				json_supplemental_public_keys['linked'] = {'publicKey': 'BCC8F27E4CF085FB4668EE787E76308DED7C4B811C8B8188CE4452A916F8378F'}

			if account_id in ('vrf', 'all'):
				json_supplemental_public_keys['vrf'] = {'publicKey': '5BD25262153603172A79677DC2703984D1249F43186BB970D2B70C88C78C0724'}

			if account_id in ('voting', 'all'):
				json_supplemental_public_keys['voting'] = {
					'publicKeys': [
						{
							'publicKey': '833D02CBB3502F11D80AA77CF3C9CC7056DBBD0C52EFD3CB8387004CBF41A273',
							'startEpoch': 1133,
							'endEpoch': 1492
						},
						{
							'publicKey': 'B339999D60A38E43605C26CC868C4631FF6ACB6FB275A320CA9793A98FA00441',
							'startEpoch': 1493,
							'endEpoch': 1852
						}
					]
				}

			return await self._process(request, {
				'account': {
					'supplementalPublicKeys': json_supplemental_public_keys,

					'mosaics': [
						{'id': '00BBCCFF00112244', 'amount': '11223344'},
						{'id': 'DEADDEADDEADDEAD', 'amount': '9988776655'},
						{'id': 'FFBBCCFF00112244', 'amount': '123'}
					]
				}
			})

		async def account_multisig(self, request):
			address = Address(request.match_info['address'])
			if Address(unhexlify(MULTISIG_INFO_1['multisig']['accountAddress'])) == address:
				return await self._process(request, MULTISIG_INFO_1)

			return await self._process(request, {'code': 'ResourceNotFound', 'message': 'no resource exists with id'}, 404)

		async def transaction_status(self, request):
			transaction_hash = Hash256(request.match_info['transaction_hash'])

			if Hash256(HASHES[0]) == transaction_hash:
				return await self._process(request, {'hash': str(transaction_hash), 'code': 'Success', 'group': 'confirmed'})

			if Hash256(HASHES[1]) == transaction_hash:
				return await self._process(request, {'hash': str(transaction_hash), 'code': 'Success', 'group': 'unconfirmed'})

			if Hash256(HASHES[2]) == transaction_hash:
				return await self._process(request, {
					'hash': str(transaction_hash),
					'code': 'Failure_Core_Future_Deadline',
					'group': 'failed'
				})

			if Hash256(HASHES[4]) == transaction_hash:
				return await self._process(request, {
					'hash': str(transaction_hash),
					'code': 'Failure_Core_Insufficient_Balance',
					'group': 'failed'
				})

			return await self._process(request, {'code': 'ResourceNotFound', 'message': 'no resource exists with id'}, 404)

		async def transaction_statuses(self, request):
			request_json = json.loads(await request.text())
			return await self._process(request, generate_transaction_statuses(
				self.status_start_height,
				self.status_groups,
				request_json['hashes']))

		async def transaction_confirmed(self, request):
			return await self._process(request, {'meta': {'height': 1234}, 'transaction': {'message': 'foo'}})

		async def transactions_confirmed(self, request):
			messages = ['sigma', 'beta', 'gamma']
			return await self._process(request, {
				'data': [
					{
						'meta': {'hash': HASHES[i]},
						'transaction': {'message': hexlify(message.encode('utf8')).decode('utf8')}
					} for i, message in enumerate(messages)
				] + [{
					'meta': {'aggregateHash': HASHES[3]},
					'transaction': {'message': hexlify(messages[0].encode('utf8')).decode('utf8')}
				}]
			})

		async def announce_transaction(self, request):
			request_json = await request.json()
			self.request_json_payloads.append(request_json)

			if self.simulate_error:
				return await self._process(request, {'code': 'InvalidContent', 'message': 'Invalid JSON'}, 500)

			return await self._process(request, {'message': 'packet 9 was pushed to the network via /transactions'})

		async def _process(self, request, response_body, status_code=200):
			self.urls.append(str(request.url))
			return web.Response(body=json.dumps(response_body), headers={'Content-Type': 'application/json'}, status=status_code)

	# create a mock server
	mock_server = MockSymbolServer()

	# create an app using the server
	app = web.Application()
	app.router.add_get('/network/properties', mock_server.network_properties)
	app.router.add_get('/chain/info', mock_server.chain_info)
	app.router.add_get('/node/time', mock_server.node_time)
	app.router.add_get(r'/blocks/{height}', mock_server.blocks)
	app.router.add_get('/node/info', mock_server.node_info)
	app.router.add_get('/node/peers', mock_server.node_peers)
	app.router.add_get(r'/accounts/{account_id}', mock_server.accounts_by_id)
	app.router.add_get(r'/account/{address}/multisig', mock_server.account_multisig)
	app.router.add_get(f'/transactions/confirmed/{HASHES[0]}', mock_server.transaction_confirmed)
	app.router.add_get('/transactions/confirmed', mock_server.transactions_confirmed)
	app.router.add_get(r'/transactionStatus/{transaction_hash}', mock_server.transaction_status)
	app.router.add_post('/transactionStatus', mock_server.transaction_statuses)
	app.router.add_put('/transactions', mock_server.announce_transaction)
	app.router.add_put('/transactions/partial', mock_server.announce_transaction)
	server = await aiohttp_client(app)  # pylint: disable=redefined-outer-name

	server.mock = mock_server
	return server

# endregion

# pylint: disable=invalid-name


# region extract_transaction_id, extract_block_timestamp

def test_can_extract_transaction_id():
	# Act:
	transaction_id = SymbolConnector.extract_transaction_id({
		'id': '1234',
		'meta': {'id': '5577'}
	})

	# Assert:
	assert '1234' == transaction_id


def test_can_extract_block_timestamp():
	# Act:
	timestamp = SymbolConnector.extract_block_timestamp({
		'timestamp': '1234',
		'meta': {'timestamp': '5577'},
		'block': {'timestamp': '8901'},
	})

	# Assert:
	assert 8901 == timestamp

# endregion


# region GET (currency_mosaic_id)

async def test_can_query_currency_mosaic_id(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	currency_mosaic_id = await connector.currency_mosaic_id()

	# Assert:
	assert [f'{server.make_url("")}/network/properties'] == server.mock.urls
	assert 0x72C0212E67A08BCE == currency_mosaic_id


async def test_can_cache_currency_mosaic_id(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	currency_mosaic_id = None
	for _ in range(4):
		currency_mosaic_id = await connector.currency_mosaic_id()

	# Assert: only one network call
	assert [f'{server.make_url("")}/network/properties'] == server.mock.urls
	assert 0x72C0212E67A08BCE == currency_mosaic_id

# endregion


# region GET (chain_height, chain_statistics, finalized_chain_height, finalization_statistics, network_time)

async def test_can_query_chain_height(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	height = await connector.chain_height()

	# Assert:
	assert [f'{server.make_url("")}/chain/info'] == server.mock.urls
	assert 1234 == height


async def test_can_query_chain_statistics(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	chain_statistics = await connector.chain_statistics()

	# Assert:
	assert [f'{server.make_url("")}/chain/info'] == server.mock.urls
	assert 1234 == chain_statistics.height
	assert 888999 == chain_statistics.score_high
	assert 222111 == chain_statistics.score_low


async def test_can_query_finalized_chain_height(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	height = await connector.finalized_chain_height()

	# Assert:
	assert [f'{server.make_url("")}/chain/info'] == server.mock.urls
	assert 1198 == height


async def test_can_query_finalization_statistics(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	finalization_statistics = await connector.finalization_statistics()

	# Assert:
	assert [f'{server.make_url("")}/chain/info'] == server.mock.urls
	assert 222 == finalization_statistics.epoch
	assert 10 == finalization_statistics.point
	assert 1198 == finalization_statistics.height
	assert Hash256('C49C566E4CF60856BC127C9E4748C89E3D38566DE0DAFE1A491012CC27A1C043') == finalization_statistics.hash


async def test_can_query_network_time(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	timestamp = await connector.network_time()

	# Assert:
	assert [f'{server.make_url("")}/node/time'] == server.mock.urls
	assert 68414660756 == timestamp.timestamp

# endregion


# region GET (block_headers)

async def test_can_get_block_headers(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	headers = await connector.block_headers(1001)

	# Assert:
	assert [f'{server.make_url("")}/blocks/1001'] == server.mock.urls
	assert {
		'meta': {'hash': HASHES[0]},
		'block': {
			'height': '1001',
			'timestamp': '85426407',
		}
	} == headers

# endregion


# region GET (node_info)

async def test_can_query_node_info(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	node_info = await connector.node_info()

	# Assert:
	assert [f'{server.make_url("")}/node/info'] == server.mock.urls
	assert NodeInfo(
		104,
		Hash256('57F7DA205008026C776CB6AED843393F04CD458E0AA2D9F1D5F31A402072B2D6'),
		PublicKey('D8F4FE47F1F5B1046748067E52725AEBAA1ED9F3CE45D02054011A39671DD9AA'),
		PublicKey('A4714451910AF026AF7A3960FF87EDCA0BA4E80CABCB350FA2B69439E1CB0B97'),
		Endpoint('http', 'wolf.importance.jp', 3000),
		'The Wolf Farm owned by Tresto(@TrendStream)',
		'1.0.3.4',
		3) == node_info

# endregion


# region GET (peers)

async def test_can_query_peers(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	peers = await connector.peers()

	# Assert:
	assert [f'{server.make_url("")}/node/peers'] == server.mock.urls
	assert 2 == len(peers)
	assert NodeInfo(
		104,
		Hash256('57F7DA205008026C776CB6AED843393F04CD458E0AA2D9F1D5F31A402072B2D6'),
		PublicKey('FB744B408D392E0F99701432E0BC8A0D38BEFDEA8019826CCE91458C6E734ADB'),
		PublicKey('A19C14033EB508EF6AD48A3E5D1E7DEDF0B1DCBAD1978CD61797017749A1B999'),
		Endpoint('http', 'xym619.allnodes.me', 3000),
		'Allnodes619',
		'1.0.3.5',
		3) == peers[0]
	assert NodeInfo(
		104,
		Hash256('57F7DA205008026C776CB6AED843393F04CD458E0AA2D9F1D5F31A402072B2D6'),  # pylint: disable=duplicate-code
		PublicKey('C807BE28855D0C87A8A2C032E51790CCB9158C15CBACB8B222E27DFFFEB3697D'),
		None,
		Endpoint('http', 'tiger.catapult.ninja', 7900),
		'tiger',
		'1.0.3.5',
		5) == peers[1]

# endregion


# region GET (balance)

async def _assert_can_query_balance(server, mosaic_id, expected_balance, call_count=1):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	balance = await connector.balance(Address(SYMBOL_ADDRESSES[0]), mosaic_id)

	# Assert:
	assert [f'{server.make_url("")}/accounts/{SYMBOL_ADDRESSES[0]}'] * call_count == server.mock.urls
	assert expected_balance == balance


async def test_can_query_balance_for_owned_mosaic(server):  # pylint: disable=redefined-outer-name
	await _assert_can_query_balance(server, '00BBCCFF00112244', 11223344)
	await _assert_can_query_balance(server, 'DEADDEADDEADDEAD', 9988776655, 2)
	await _assert_can_query_balance(server, 'FFBBCCFF00112244', 123, 3)


async def test_can_query_balance_for_not_owned_mosaic(server):  # pylint: disable=redefined-outer-name
	await _assert_can_query_balance(server, 'AABBCCFF00112244', 0)

# endregion


# region GET (account_links)

def _assert_no_links(links):
	assert None is links.linked_public_key
	assert None is links.vrf_public_key
	assert 0 == len(links.voting_public_keys)


def _assert_voting_public_keys(links):
	assert 2 == len(links.voting_public_keys)
	assert PublicKey('833D02CBB3502F11D80AA77CF3C9CC7056DBBD0C52EFD3CB8387004CBF41A273') == links.voting_public_keys[0].public_key
	assert 1133 == links.voting_public_keys[0].start_epoch
	assert 1492 == links.voting_public_keys[0].end_epoch
	assert PublicKey('B339999D60A38E43605C26CC868C4631FF6ACB6FB275A320CA9793A98FA00441') == links.voting_public_keys[1].public_key
	assert 1493 == links.voting_public_keys[1].start_epoch
	assert 1852 == links.voting_public_keys[1].end_epoch


async def test_can_query_account_links_for_unknown_account(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	links = await connector.account_links('error')

	# Assert:
	assert [f'{server.make_url("")}/accounts/error'] == server.mock.urls
	_assert_no_links(links)


async def test_can_query_account_links_for_account_with_no_links(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	links = await connector.account_links('none')

	# Assert:
	assert [f'{server.make_url("")}/accounts/none'] == server.mock.urls
	_assert_no_links(links)


async def test_can_query_account_links_for_account_with_only_linked_public_key(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	links = await connector.account_links('linked')

	# Assert:
	assert [f'{server.make_url("")}/accounts/linked'] == server.mock.urls
	assert PublicKey('BCC8F27E4CF085FB4668EE787E76308DED7C4B811C8B8188CE4452A916F8378F') == links.linked_public_key
	assert None is links.vrf_public_key
	assert 0 == len(links.voting_public_keys)


async def test_can_query_account_links_for_account_with_only_vrf_public_key(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	links = await connector.account_links('vrf')

	# Assert:
	assert [f'{server.make_url("")}/accounts/vrf'] == server.mock.urls
	assert None is links.linked_public_key
	assert PublicKey('5BD25262153603172A79677DC2703984D1249F43186BB970D2B70C88C78C0724') == links.vrf_public_key
	assert 0 == len(links.voting_public_keys)


async def test_can_query_account_links_for_account_with_only_voting_public_keys(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	links = await connector.account_links('voting')

	# Assert:
	assert [f'{server.make_url("")}/accounts/voting'] == server.mock.urls
	assert None is links.linked_public_key
	assert None is links.vrf_public_key
	_assert_voting_public_keys(links)


async def test_can_query_account_links_for_account_with_all_links(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	links = await connector.account_links('all')

	# Assert:
	assert [f'{server.make_url("")}/accounts/all'] == server.mock.urls
	assert PublicKey('BCC8F27E4CF085FB4668EE787E76308DED7C4B811C8B8188CE4452A916F8378F') == links.linked_public_key
	assert PublicKey('5BD25262153603172A79677DC2703984D1249F43186BB970D2B70C88C78C0724') == links.vrf_public_key
	_assert_voting_public_keys(links)

# endregion


# region GET (account_multisig)

async def test_can_query_account_multisig_information_for_unknown_account(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	multisig_info = await connector.account_multisig(Address('TCVLQ6BNIRJPBXTMQKTXRO3JG7CQTONBV7PSGIA'))

	# Assert:
	assert [f'{server.make_url("")}/account/TCVLQ6BNIRJPBXTMQKTXRO3JG7CQTONBV7PSGIA/multisig'] == server.mock.urls
	assert 0 == multisig_info.min_approval
	assert 0 == multisig_info.min_removal
	assert [] == multisig_info.cosignatory_addresses
	assert [] == multisig_info.multisig_addresses


async def test_can_query_account_multisig_information_for_known_account(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	multisig_info = await connector.account_multisig(Address(unhexlify(MULTISIG_INFO_1['multisig']['accountAddress'])))

	# Assert:
	assert [f'{server.make_url("")}/account/TB54C4RPIF6JHOUAYQQSVIHEMIP3LMMFKDGECAY/multisig'] == server.mock.urls
	assert 2 == multisig_info.min_approval
	assert 3 == multisig_info.min_removal
	assert [
		Address('TCVLQ6BNIRJPBXTMQKTXRO3JG7CQTONBV7PSGIA'),
		Address('TBTB2IZRF4YQM3FFFGH5IUZQDSJQKU2SR77A74I'),
		Address('TC7MJBBN52IT4434YJT5TBHV7TEVLSMBFENTSNQ')
	] == multisig_info.cosignatory_addresses
	assert [
		Address('TDJVZT3GHVQ4MTTLBA6ARMKUJQ6ZKOHLAE3JESA'),
		Address('TCMW6PBD3XSCLDU5HYHQXZF25VEDODFG5XL52LA')
	] == multisig_info.multisig_addresses

# endregion


# region POST (transaction_statuses, filter_confirmed_transactions, filter_failed_transactions)

async def test_can_query_transaction_statuses(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	transaction_statuses = await connector.transaction_statuses([HASHES[0], HASHES[2], HASHES[1]])

	# Assert:
	assert [f'{server.make_url("")}/transactionStatus'] == server.mock.urls
	assert 3 == len(transaction_statuses)

	assert 'confirmed' == transaction_statuses[0]['group']
	assert 'Success' == transaction_statuses[0]['code']
	assert str(HASHES[0]) == transaction_statuses[0]['hash']
	assert '111001' == transaction_statuses[0]['height']

	assert 'unconfirmed' == transaction_statuses[1]['group']
	assert 'Success' == transaction_statuses[1]['code']
	assert str(HASHES[2]) == transaction_statuses[1]['hash']
	assert '111002' == transaction_statuses[1]['height']

	assert 'confirmed' == transaction_statuses[2]['group']
	assert 'Success' == transaction_statuses[2]['code']
	assert str(HASHES[1]) == transaction_statuses[2]['hash']
	assert '111003' == transaction_statuses[2]['height']


async def test_can_filter_confirmed_transactions(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))
	transaction_hashes = [Hash256(HASHES[i]) for i in (0, 2, 1)]

	# Act:
	transaction_hash_height_pairs = await connector.filter_confirmed_transactions(transaction_hashes)

	# Assert:
	assert [f'{server.make_url("")}/transactionStatus'] == server.mock.urls
	assert 2 == len(transaction_hash_height_pairs)

	assert (Hash256(HASHES[0]), 111001) == transaction_hash_height_pairs[0]
	assert (Hash256(HASHES[1]), 111003) == transaction_hash_height_pairs[1]


async def test_can_filter_failed_transactions(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	server.mock.status_groups = ('failed', 'confirmed')

	connector = SymbolConnector(server.make_url(''))
	transaction_hashes = [Hash256(HASHES[i]) for i in (0, 2, 1)]

	# Act:
	transaction_hash_error_pairs = await connector.filter_failed_transactions(transaction_hashes)

	# Assert:
	assert [f'{server.make_url("")}/transactionStatus'] == server.mock.urls
	assert 2 == len(transaction_hash_error_pairs)

	assert (Hash256(HASHES[0]), 'Failure0') == transaction_hash_error_pairs[0]
	assert (Hash256(HASHES[1]), 'Failure2') == transaction_hash_error_pairs[1]

# endregion


# region GET (transaction_confirmed)

async def test_transaction_confirmed(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	transaction = await connector.transaction_confirmed(Hash256(HASHES[0]))

	# Assert:
	assert [f'{server.make_url("")}/transactions/confirmed/{HASHES[0]}'] == server.mock.urls
	assert {'meta': {'height': 1234}, 'transaction': {'message': 'foo'}} == transaction

# endregion


# region GET (incoming_transactions)

def assert_message(message, transaction):
	assert hexlify(message.encode('utf8')).decode('utf8') == transaction['transaction']['message']


async def test_incoming_transactions(server):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	transactions = await connector.incoming_transactions(Address(SYMBOL_ADDRESSES[0]))

	# Assert:
	assert [
		f'{server.make_url("")}/transactions/confirmed?recipientAddress={Address(SYMBOL_ADDRESSES[0])}&embedded=true&pageSize=100&order=desc'
	] == server.mock.urls
	assert 4 == len(transactions)

	assert_message('sigma', transactions[0])
	assert_message('beta', transactions[1])
	assert_message('gamma', transactions[2])
	assert_message('sigma', transactions[3])

# endregion


# region PUT (announce_transaction, announce_partial_transaction)

async def _assert_can_announce_transaction(server, transaction_payload, connector_function_name, url_path):
	# pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	await getattr(connector, connector_function_name)(transaction_payload)

	# Assert:
	assert [f'{server.make_url("")}/{url_path}'] == server.mock.urls
	assert [{'payload': '68656C6C6F20776F726C6421'}] == server.mock.request_json_payloads


async def _assert_can_announce_transaction_object(server, connector_function_name, url_path):  # pylint: disable=redefined-outer-name
	# Arrange:
	class MockTransaction:
		def __init__(self, buffer):
			self.buffer = buffer

		def serialize(self):
			return self.buffer

	# Act + Assert:
	await _assert_can_announce_transaction(server, MockTransaction(b'hello world!'), connector_function_name, url_path)


async def _assert_can_announce_transaction_buffer(server, connector_function_name, url_path):  # pylint: disable=redefined-outer-name
	await _assert_can_announce_transaction(server, b'hello world!', connector_function_name, url_path)


async def _assert_cannot_announce_transaction_with_error(server, connector_function_name):  # pylint: disable=redefined-outer-name
	# Arrange:
	server.mock.simulate_error = True

	connector = SymbolConnector(server.make_url(''))

	# Act + Assert:
	with pytest.raises(NodeException, match='Invalid JSON'):
		await getattr(connector, connector_function_name)(b'hello world!')


async def test_can_announce_transaction_object(server):  # pylint: disable=redefined-outer-name
	await _assert_can_announce_transaction_object(server, 'announce_transaction', 'transactions')


async def test_can_announce_transaction_object_partial(server):  # pylint: disable=redefined-outer-name
	await _assert_can_announce_transaction_object(server, 'announce_partial_transaction', 'transactions/partial')


async def test_can_announce_transaction_buffer(server):  # pylint: disable=redefined-outer-name
	await _assert_can_announce_transaction_buffer(server, 'announce_transaction', 'transactions')


async def test_can_announce_transaction_buffer_partial(server):  # pylint: disable=redefined-outer-name
	await _assert_can_announce_transaction_buffer(server, 'announce_partial_transaction', 'transactions/partial')


async def test_cannot_announce_transaction_with_error(server):  # pylint: disable=redefined-outer-name
	await _assert_cannot_announce_transaction_with_error(server, 'announce_transaction')


async def test_cannot_announce_transaction_with_error_partial(server):  # pylint: disable=redefined-outer-name
	await _assert_cannot_announce_transaction_with_error(server, 'announce_partial_transaction')

# endregion


# region try_wait_for_announced_transaction

async def _assert_can_try_wait_for_announced_transaction_success(server, transaction_hash, status):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	result = await connector.try_wait_for_announced_transaction(transaction_hash, status, TimeoutSettings(5, 0.001))

	# Assert:
	assert [f'{server.make_url("")}/transactionStatus/{transaction_hash}'] == server.mock.urls
	assert result


async def _assert_can_try_wait_for_announced_transaction_failure(server, transaction_hash, status):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act + Assert:
	with pytest.raises(NodeException, match='transaction was rejected with error Failure_Core_Future_Deadline'):
		await connector.try_wait_for_announced_transaction(transaction_hash, status, TimeoutSettings(5, 0.001))

	assert [f'{server.make_url("")}/transactionStatus/{transaction_hash}'] == server.mock.urls


async def _assert_can_try_wait_for_announced_transaction_failure_insufficient_balance(server, transaction_hash, status):
	# pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act + Assert:
	with pytest.raises(InsufficientBalanceException, match='transaction was rejected with error Failure_Core_Insufficient_Balance'):
		await connector.try_wait_for_announced_transaction(transaction_hash, status, TimeoutSettings(5, 0.001))

	assert [f'{server.make_url("")}/transactionStatus/{transaction_hash}'] == server.mock.urls


async def _assert_can_try_wait_for_announced_transaction_timeout(server, transaction_hash, status):  # pylint: disable=redefined-outer-name
	# Arrange:
	connector = SymbolConnector(server.make_url(''))

	# Act:
	result = await connector.try_wait_for_announced_transaction(transaction_hash, status, TimeoutSettings(5, 0.001))

	# Assert:
	assert [f'{server.make_url("")}/transactionStatus/{transaction_hash}'] * 5 == server.mock.urls
	assert not result


async def test_can_try_wait_for_announced_transaction_unconfirmed_success_confirmed(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_success(server, Hash256(HASHES[0]), TransactionStatus.UNCONFIRMED)


async def test_can_try_wait_for_announced_transaction_unconfirmed_success_unconfirmed(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_success(server, Hash256(HASHES[1]), TransactionStatus.UNCONFIRMED)


async def test_can_try_wait_for_announced_transaction_unconfirmed_timeout(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_timeout(server, Hash256(HASHES[3]), TransactionStatus.UNCONFIRMED)


async def test_can_try_wait_for_announced_transaction_unconfirmed_failure(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_failure(server, Hash256(HASHES[2]), TransactionStatus.UNCONFIRMED)


async def test_can_try_wait_for_announced_transaction_unconfirmed_failure_insufficient_balance(server):
	# pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_failure_insufficient_balance(
		server,
		Hash256(HASHES[4]),
		TransactionStatus.UNCONFIRMED)


async def test_can_try_wait_for_announced_transaction_confirmed_success(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_success(server, Hash256(HASHES[0]), TransactionStatus.CONFIRMED)


async def test_can_try_wait_for_announced_transaction_confirmed_timeout_unconfirmed(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_timeout(server, Hash256(HASHES[1]), TransactionStatus.CONFIRMED)


async def test_can_try_wait_for_announced_transaction_confirmed_timeout_unknown(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_timeout(server, Hash256(HASHES[3]), TransactionStatus.CONFIRMED)


async def test_can_try_wait_for_announced_transaction_confirmed_failure(server):  # pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_failure(server, Hash256(HASHES[2]), TransactionStatus.CONFIRMED)


async def test_can_try_wait_for_announced_transaction_confirmed_failure_insufficient_balance(server):
	# pylint: disable=redefined-outer-name
	await _assert_can_try_wait_for_announced_transaction_failure_insufficient_balance(
		server,
		Hash256(HASHES[4]),
		TransactionStatus.CONFIRMED)

# endregion
