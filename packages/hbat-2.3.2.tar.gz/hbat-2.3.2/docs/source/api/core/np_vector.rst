Vecctor Support
===============

.. automodule:: hbat.core.np_vector
   :members:
   :undoc-members:
   :show-inheritance: