#!/usr/bin/env python3
"""
OPENRGD — ChronoGraph Builder
-----------------------------

Genera/aggiorna il manifest del ChronoGraf:

- Calcola SHA-256 di:
    spec/00_core/chronograf/layers/time_kernel.jsonc
    spec/00_core/chronograf/layers/time_channels.jsonc
    spec/00_core/chronograf/layers/time_topology.jsonc

- Aggiorna in spec/00_core/chronograf/manifest/chronograf_manifest.jsonc:
    meta_group.generated_at_iso8601_str
    sources_group.*.relative_path_str
    sources_group.*.expected_sha256_hex_str
    bounds_group.total_defined_channels_int
    bounds_group.total_defined_loops_int

Uso (da root repo):
    python spec/00_core/chronograf/tools/build_chronograf.py
"""

import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone
import sys


# ---------------------------------------------------------------------
# Helper: trova la root del repo cercando la cartella "spec"
# ---------------------------------------------------------------------
def find_repo_root(start: Path) -> Path:
    cur = start
    while cur != cur.parent:
        if (cur / "spec").exists():
            return cur
        cur = cur.parent
    raise RuntimeError("Could not find repo root (directory containing 'spec').")


# ---------------------------------------------------------------------
# Helper: loader JSONC (toglie i // comment)
# ---------------------------------------------------------------------
def load_jsonc(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    cleaned_lines = []
    for line in text.splitlines():
        if "//" in line:
            idx = line.index("//")
            line = line[:idx]
        cleaned_lines.append(line)
    cleaned = "\n".join(cleaned_lines).strip()
    if not cleaned:
        raise ValueError(f"{path} is empty after stripping comments")
    return json.loads(cleaned)


# ---------------------------------------------------------------------
# Helper: SHA-256
# ---------------------------------------------------------------------
def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------
# Build logic
# ---------------------------------------------------------------------
def build_chronograf(repo_root: Path) -> None:
    base_dir     = repo_root / "spec" / "00_core" / "chronograf"
    layers_dir   = base_dir / "layers"
    manifest_dir = base_dir / "manifest"

    kernel_path   = layers_dir / "time_kernel.jsonc"
    channels_path = layers_dir / "time_channels.jsonc"
    topology_path = layers_dir / "time_topology.jsonc"
    manifest_path = manifest_dir / "chronograf_manifest.jsonc"

    if not manifest_path.exists():
        raise FileNotFoundError(f"Chronograf manifest not found: {manifest_path}")

    print("=== OPENRGD ChronoGraph Builder ===")
    print(f"Repo root:       {repo_root}")
    print(f"Chronograf base: {base_dir}")
    print(f"Layers dir:      {layers_dir}")
    print(f"Manifest file:   {manifest_path}")
    print("-----------------------------------")

    # Carica manifest esistente (template)
    manifest = load_jsonc(manifest_path)

    # 1) Aggiorna meta_group.generated_at_iso8601_str
    meta = manifest.setdefault("meta_group", {})
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    meta["generated_at_iso8601_str"] = now
    print(f"[META] generated_at_iso8601_str = {now}")

    # 2) Calcola hash dei tre file e aggiorna sources_group
    sources = manifest.setdefault("sources_group", {})

    files = {
        "time_kernel_file":   kernel_path,
        "time_channels_file": channels_path,
        "time_topology_file": topology_path,
    }

    for key, path in files.items():
        print(f"\n[SOURCE] {key}")
        if not path.exists():
            raise FileNotFoundError(f"Missing source file: {path}")

        sha = sha256_file(path)
        print(f"  Path:   {path}")
        print(f"  SHA256: {sha}")

        entry = sources.setdefault(key, {})
        # Path relativo rispetto alla root chronograf (layers/...)
        entry["relative_path_str"] = f"layers/{path.name}"
        entry["expected_sha256_hex_str"] = sha

    # 3) Bounds: total_defined_channels_int e total_defined_loops_int
    bounds = manifest.setdefault("bounds_group", {})

    # 3a) Channels count
    if channels_path.exists():
        channels_doc = load_jsonc(channels_path)
        channels_list = channels_doc.get("channels_list", [])
        channels_count = len(channels_list)
        bounds["total_defined_channels_int"] = channels_count
        print(f"\n[BOUNDS] total_defined_channels_int = {channels_count}")
    else:
        print("\n[BOUNDS] WARNING: channels file not found, cannot set total_defined_channels_int")

    # 3b) Loops count (se presente)
    if topology_path.exists():
        topology_doc = load_jsonc(topology_path)
        loops_list = topology_doc.get("loops_list", [])
        if isinstance(loops_list, list) and loops_list:
            loops_count = len(loops_list)
            bounds["total_defined_loops_int"] = loops_count
            print(f"[BOUNDS] total_defined_loops_int = {loops_count}")
        else:
            print("[BOUNDS] WARNING: 'loops_list' not found or empty in time_topology.jsonc")
    else:
        print("[BOUNDS] WARNING: topology file not found, cannot set total_defined_loops_int")

    # 4) Scrive il nuovo manifest (JSON “pulito” con header di commento)
    header = (
        "/**\n"
        " * OPENRGD — CHRONOGRAPH MANIFEST\n"
        " * This file is AUTO-GENERATED by spec/00_core/chronograf/tools/build_chronograf.py\n"
        " * Do not edit by hand: changes will be overwritten.\n"
        " */\n\n"
    )

    manifest_json = json.dumps(manifest, indent=2, sort_keys=False)
    manifest_path.write_text(header + manifest_json + "\n", encoding="utf-8")

    print("\n[OK] Chronograf manifest successfully rebuilt.")
    print(f"     Path: {manifest_path}")


def main():
    here = Path(__file__).resolve()
    try:
        repo_root = find_repo_root(here)
    except RuntimeError as e:
        print(f"[ERROR] {e}")
        sys.exit(1)

    try:
        build_chronograf(repo_root)
    except Exception as e:
        print(f"[ERROR] Build failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
