#!/usr/bin/env python3
"""
OPENRGD — ChronoGraph Validator
--------------------------------

Usage (from repo root):
    python spec/00_core/chronograf/tools/validate_chronograf.py

Purpose:
    - Recompute SHA-256 for:
        spec/00_core/chronograf/layers/time_kernel.jsonc
        spec/00_core/chronograf/layers/time_channels.jsonc
        spec/00_core/chronograf/layers/time_topology.jsonc
    - Compare them against:
        spec/00_core/chronograf/manifest/chronograf_manifest.jsonc
    - Verify:
        bounds_group.total_defined_channels_int == len(channels_list)
        bounds_group.total_defined_loops_int    == len(loops_list)
    - Print a human-readable OK/FAIL report
    - Exit code:
        0 -> everything consistent
        1 -> any inconsistency
"""

import sys
import json
import hashlib
from pathlib import Path
from datetime import datetime


# ---------------------------------------------------------------------
# JSONC loader (strip // comments)
# ---------------------------------------------------------------------
def load_jsonc(path: Path):
    """
    Load a JSONC-like file by stripping // comments and then parsing as JSON.
    Assumes no pathological '//' inside strings.
    """
    text = path.read_text(encoding="utf-8")

    cleaned_lines = []
    for line in text.splitlines():
        if "//" in line:
            idx = line.index("//")
            line = line[:idx]
        cleaned_lines.append(line)

    cleaned = "\n".join(cleaned_lines).strip()
    if not cleaned:
        raise ValueError(f"{path} appears empty after stripping comments.")

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse JSONC in {path}: {e}") from e


# ---------------------------------------------------------------------
# SHA-256 helper
# ---------------------------------------------------------------------
def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------
# Repo root finder (look for 'spec' folder)
# ---------------------------------------------------------------------
def find_repo_root(start: Path) -> Path:
    cur = start
    while cur != cur.parent:
        if (cur / "spec").exists():
            return cur
        cur = cur.parent
    raise RuntimeError("Could not find repo root (directory containing 'spec').")


# ---------------------------------------------------------------------
# Core validation logic
# ---------------------------------------------------------------------
def validate_chronograf(repo_root: Path) -> bool:
    base_dir = repo_root / "spec" / "00_core" / "chronograf"
    layers_dir = base_dir / "layers"
    manifest_dir = base_dir / "manifest"

    kernel_path   = layers_dir / "time_kernel.jsonc"
    channels_path = layers_dir / "time_channels.jsonc"
    topology_path = layers_dir / "time_topology.jsonc"
    manifest_path = manifest_dir / "chronograf_manifest.jsonc"

    if not manifest_path.exists():
        print(f"[FAIL] Manifest not found: {manifest_path}")
        return False

    manifest = load_jsonc(manifest_path)

    print("=== OPENRGD ChronoGraph Validation ===")
    print(f"Repo root:          {repo_root}")
    print(f"Chronograf base:    {base_dir}")
    print(f"Layers directory:   {layers_dir}")
    print(f"Manifest directory: {manifest_dir}")
    print(f"Manifest file:      {manifest_path}")
    print("--------------------------------------")

    ok = True

    # ----- 1. Check sources_group hashes -----
    sources = manifest.get("sources_group", {})

    def check_source(name: str, path: Path):
        nonlocal ok
        print(f"\n[CHECK] {name}")
        if not path.exists():
            print(f"  [FAIL] File not found: {path}")
            ok = False
            return

        manifest_entry_key = name + "_file"
        meta_entry = sources.get(manifest_entry_key, {})
        expected = meta_entry.get("expected_sha256_hex_str")

        actual = sha256_file(path)

        print(f"  Path:     {path}")
        print(f"  Actual:   {actual}")
        print(f"  Expected: {expected}")

        if expected is None:
            print("  [FAIL] No expected SHA set in manifest.")
            ok = False
        elif expected == "__TO_BE_FILLED_BY_BUILD_TOOL__":
            print("  [FAIL] Expected SHA is still placeholder (__TO_BE_FILLED_BY_BUILD_TOOL__).")
            ok = False
        elif expected != actual:
            print("  [FAIL] SHA mismatch.")
            ok = False
        else:
            print("  [OK] SHA matches.")

    check_source("time_kernel", kernel_path)
    check_source("time_channels", channels_path)
    check_source("time_topology", topology_path)

    # ----- 2. Bounds: channel & loop counts -----
    print("\n--------------------------------------")
    print("[CHECK] Bounds: channel & loop counts")

    bounds = manifest.get("bounds_group", {})
    expected_channels = bounds.get("total_defined_channels_int")
    expected_loops = bounds.get("total_defined_loops_int")

    # Load channels & topology
    if channels_path.exists():
        channels_doc = load_jsonc(channels_path)
        actual_channels = len(channels_doc.get("channels_list", []))
    else:
        actual_channels = None

    if topology_path.exists():
        topology_doc = load_jsonc(topology_path)
        actual_loops = len(topology_doc.get("loops_list", []))
    else:
        actual_loops = None

    print(f"  Expected channels: {expected_channels}")
    print(f"  Actual   channels: {actual_channels}")
    if expected_channels is None or actual_channels is None:
        print("  [FAIL] Cannot validate channel count.")
        ok = False
    elif expected_channels != actual_channels:
        print("  [FAIL] Channel count mismatch.")
        ok = False
    else:
        print("  [OK] Channel count matches.")

    print(f"\n  Expected loops: {expected_loops}")
    print(f"  Actual   loops: {actual_loops}")
    if expected_loops is None or actual_loops is None:
        print("  [FAIL] Cannot validate loop count.")
        ok = False
    elif expected_loops != actual_loops:
        print("  [FAIL] Loop count mismatch.")
        ok = False
    else:
        print("  [OK] Loop count matches.")

    # ----- 3. Sanity check on generated_at_iso8601_str -----
    print("\n--------------------------------------")
    print("[CHECK] Manifest metadata")

    meta = manifest.get("meta_group", {})
    gen_at = meta.get("generated_at_iso8601_str")

    print(f"  generated_at_iso8601_str: {gen_at}")
    if gen_at is None:
        print("  [WARN] generated_at_iso8601_str is missing.")
    elif gen_at == "__TO_BE_SET_AT_BUILD_TIME__":
        print("  [FAIL] Manifest timestamp still placeholder. Did you run the build tool?")
        ok = False
    else:
        try:
            cleaned = gen_at.replace("Z", "+00:00")
            datetime.fromisoformat(cleaned)
            print("  [OK] Timestamp looks like a valid ISO8601 datetime.")
        except Exception:
            print("  [WARN] Timestamp is not valid ISO8601 (or parsing failed).")

    # ----- 4. Final verdict -----
    print("\n======================================")
    if ok:
        print("[OK] ChronoGraph manifest is consistent with source files.")
        print("     Temporal integrity checks PASSED.")
    else:
        print("[FAIL] ChronoGraph manifest is NOT consistent with source files.")
        print("       Temporal integrity checks FAILED.")
    print("======================================")

    return ok


def main():
    here = Path(__file__).resolve()
    try:
        repo_root = find_repo_root(here)
    except RuntimeError as e:
        print(f"[ERROR] {e}")
        sys.exit(1)

    ok = validate_chronograf(repo_root)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
