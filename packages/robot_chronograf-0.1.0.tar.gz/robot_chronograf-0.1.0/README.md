Robot Chronograf (RGC)

Robot Chronograf is a Temporal Operating System (TOS) for embodied artificial agents. It moves time management from an implicit dependency (system clock) to an explicit architectural layer, allowing robots to synchronize physical motor loops, cognitive planning, and social interactions coherently.

Note: This is the Python reference implementation of the RGC engine.

🚀 Features

Multi-Layer Ontology: Native support for Chronos (Physical), Kairos (Cognitive), Aion (Social), and Metachronos (Exotic) time layers.

RGC-16 Encoding: Fast 16-bit channel addressing for temporal signals (0x1001, 0x3F00, etc.).

OpenRGD Integration: Parses OpenRGD definition files to auto-configure temporal topology.

Time Dilation: APIs to programmatically slow down or speed up subjective cognitive time relative to physical ticks.

📦 Installation

pip install robot-chronograf


⚡ Quick Start

import chronograf as rgc
from chronograf.layers import Chronos, Kairos

# 1. Initialize the Kernel
kernel = rgc.Kernel(tick_rate_hz=1000)

# 2. Define Channels
motor_sync = kernel.create_channel(Chronos, "MOTOR_CORE", precision=0)
brain_plan = kernel.create_channel(Kairos,  "PLANNER_V1", precision=1)

# 3. The Loop
@kernel.loop
def run_cycle(context):
    # Physical time allows no latency
    if context.layer == Chronos:
        actuate_motors()
    
    # Cognitive time can dilate
    elif context.layer == Kairos:
        if context.is_emergency():
            # Dilate time: spend more CPU cycles per physical tick
            kernel.dilate(factor=0.5) 
            replan_trajectory()

kernel.start()


📜 License

This software is released under the Polyform Noncommercial License 1.0.0.

Free for Use: Research, education, personal projects, and non-commercial testing.

Commercial Use: Requires a separate OEM agreement. Contact info@robotchronograf.org.

Concept & Architecture by Pasquale Ranieri.