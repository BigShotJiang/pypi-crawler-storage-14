import re
import string
from typing import str

from exceptions import InvalidTextError


def remove_whitespace(text: str) -> str:
    """
    Убирает лишние пробелы: и в начале, и в конце, и повторяющиеся внутри.
    
    Args:
        text: Исходный текст для обработки
        
    Returns:
        Текст без лишних пробелов
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Убираем пробелы в начале и конце, затем заменяем множественные пробелы на один
    return re.sub(r's+', ' ', text.strip())


def remove_punctuation(text: str, keep: str = "") -> str:
    """
    Убирает знаки пунктуации.
    
    Args:
        text: Исходный текст для обработки
        keep: Строка символов, которые нужно оставить
        
    Returns:
        Текст без знаков пунктуации (кроме указанных в keep)
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Создаем таблицу символов для удаления
    # Исключаем символы, которые нужно оставить
    punctuation_to_remove = string.punctuation
    for char in keep:
        punctuation_to_remove = punctuation_to_remove.replace(char, '')
    
    # Создаем таблицу переводов: знаки пунктуации заменяются на пробелы
    translator = str.maketrans(punctuation_to_remove, ' ' * len(punctuation_to_remove))
    
    # Применяем трансляцию и убираем лишние пробелы
    result = text.translate(translator)
    return re.sub(r's+', ' ', result).strip()


def normalize_spaces(text: str) -> str:
    """
    Превращает все виды пробелов/табов/переносов в обычный пробел.
    
    Args:
        text: Исходный текст для обработки
        
    Returns:
        Текст с нормализованными пробелами
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Заменяем все whitespace-символы на обычные пробелы
    return re.sub(r's+', ' ', text)


# Примеры использования
if __name__ == "__main__":
    # Тестирование remove_whitespace
    print("remove_whitespace:")
    print(f"'{remove_whitespace('   Hello    world   ')}'")  # 'Hello world'
    print(f"'{remove_whitespace('   Multiple     spaces   here   ')}'")  # 'Multiple spaces here'
    
    # Тестирование remove_punctuation
    print("\nremove_punctuation:")
    print(f"'{remove_punctuation('Hi!!!', '!')}'")  # 'Hi!'
    print(f"'{remove_punctuation('Hello, world!')}'")  # 'Hello world'
    print(f"'{remove_punctuation('Test: keep dots...', '.')}'")  # 'Test keep dots...'
    
    # Тестирование normalize_spaces
    print("\nnormalize_spaces:")
    print(f"'{normalize_spaces('Hello\tworld\nhi')}'")  # 'Hello world hi'
    print(f"'{normalize_spaces('Multiple\t\t\tspaces')}'")  # 'Multiple spaces'
