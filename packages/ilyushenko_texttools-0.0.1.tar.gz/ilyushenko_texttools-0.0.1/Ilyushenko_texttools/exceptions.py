class TextToolsError(Exception):
    """Базовое исключение библиотеки TextTools."""
    pass


class InvalidTextError(TextToolsError):
    """Исключение, выбрасываемое когда в функцию передано не строковое значение."""
    
    def __init__(self, value, message=None):
        self.value = value
        if message is None:
            message = f"Ожидалась строка, получен {type(value).__name__}: {value!r}"
        super().__init__(message)