import re
from collections import Counter
from typing import List, Tuple

from exceptions import InvalidTextError
from cleaning import remove_punctuation, normalize_spaces


def word_count(text: str) -> int:
    """
    Подсчитывает количество слов в тексте.
    
    Args:
        text: Текст для анализа
        
    Returns:
        Количество слов в тексте
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Очистка текста: нормализуем пробелы и удаляем пунктуацию
    cleaned_text = remove_punctuation(normalize_spaces(text.strip()))
    
    # Если текст пустой после очистки
    if not cleaned_text:
        return 0
    
    # Разбиваем на слова по пробелам и считаем количество
    words = cleaned_text.split()
    return len(words)


def char_count(text: str, ignore_spaces: bool = False) -> int:
    """
    Подсчитывает количество символов в тексте.
    
    Args:
        text: Текст для анализа
        ignore_spaces: Если True, пробелы не учитываются
        
    Returns:
        Количество символов в тексте
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Очистка текста: нормализуем пробелы
    cleaned_text = normalize_spaces(text.strip())
    
    if ignore_spaces:
        # Удаляем все пробелы и считаем оставшиеся символы
        cleaned_text = cleaned_text.replace(' ', '')
    
    return len(cleaned_text)


def top_words(text: str, n: int = 3) -> List[Tuple[str, int]]:
    """
    Находит N самых частых слов в тексте.
    
    Args:
        text: Текст для анализа
        n: Количество топовых слов для возврата (по умолчанию 3)
        
    Returns:
        Список кортежей в формате [(слово, количество), ...], 
        отсортированный по убыванию частоты
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
        ValueError: Если n <= 0
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    if n <= 0:
        raise ValueError("n должно быть положительным числом")
    
    # Очистка текста: удаляем пунктуацию и нормализуем пробелы
    cleaned_text = remove_punctuation(normalize_spaces(text.strip()))
    
    # Если текст пустой после очистки
    if not cleaned_text:
        return []
    
    # Разбиваем на слова и приводим к нижнему регистру
    words = cleaned_text.lower().split()
    
    # Подсчитываем частоту слов
    word_freq = Counter(words)
    
    # Возвращаем N самых частых слов
    return word_freq.most_common(n)


# Альтернативная версия top_words без использования Counter
def top_words_v2(text: str, n: int = 3) -> List[Tuple[str, int]]:
    """
    Альтернативная реализация top_words без использования collections.Counter.
    
    Args:
        text: Текст для анализа
        n: Количество топовых слов для возврата
        
    Returns:
        Список кортежей в формате [(слово, количество), ...]
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    if n <= 0:
        raise ValueError("n должно быть положительным числом")
    
    # Очистка текста
    cleaned_text = remove_punctuation(normalize_spaces(text.strip()))
    
    if not cleaned_text:
        return []
    
    # Разбиваем на слова и приводим к нижнему регистру
    words = cleaned_text.lower().split()
    
    # Подсчитываем частоту вручную
    word_freq = {}
    for word in words:
        word_freq[word] = word_freq.get(word, 0) + 1
    
    # Сортируем слова по частоте (по убыванию) и берем первые n
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    
    return sorted_words[:n]


# Дополнительные функции анализа

def sentence_count(text: str) -> int:
    """
    Подсчитывает количество предложений в тексте.
    
    Args:
        text: Текст для анализа
        
    Returns:
            Количество предложений в тексте
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    if not text.strip():
        return 0
    
    # Разделяем текст на предложения по .!?
    # Используем регулярное выражение для более точного разделения
    sentences = re.split(r'[.!?]+', text.strip())
    
    # Фильтруем пустые строки
    sentences = [s.strip() for s in sentences if s.strip()]
    
    return len(sentences)


def avg_word_length(text: str) -> float:
    """
    Вычисляет среднюю длину слова в тексте.
    
    Args:
        text: Текст для анализа
        
    Returns:
        Средняя длина слова. 0 если слов нет.
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Очистка текста
    cleaned_text = remove_punctuation(normalize_spaces(text.strip()))
    
    if not cleaned_text:
        return 0.0
    
    words = cleaned_text.split()
    
    if not words:
        return 0.0
    
    total_chars = sum(len(word) for word in words)
    return total_chars / len(words)


# Примеры использования
if __name__ == "__main__":
    test_text = "Hello world! This is a test. Hello again, world. Test completed."
    
    print("Тестовый текст:")
    print(f"'{test_text}'")
    print()
    
    # Тестирование word_count
    print("word_count:")
    print(f"Слов в тексте: {word_count(test_text)}")  # 11
    print(f"Пустой текст: {word_count('')}")  # 0
    print(f"Текст с лишними пробелами: {word_count('   multiple   spaces   ')}")  # 2
    
    # Тестирование char_count
    print("\nchar_count:")
    print(f"Все символы: {char_count(test_text)}")  # 58
    print(f"Без пробелов: {char_count(test_text, ignore_spaces=True)}")  # 48
    print(f"Пустой текст: {char_count('')}")  # 0
    
    # Тестирование top_words
    print("\ntop_words:")
    print(f"Топ 3 слова: {top_words(test_text, 3)}")  # [('hello', 2), ('world', 2), ('test', 2)]
    print(f"Топ 5 слов: {top_words(test_text, 5)}")  # [('hello', 2), ('world', 2), ('test', 2), ('this', 1), ('is', 1)]
    print(f"Пустой текст: {top_words('', 3)}")  # []
    
    # Тестирование дополнительных функций
    print("\nДополнительные функции:")
    print(f"Количество предложений: {sentence_count(test_text)}")  # 4
    print(f"Средняя длина слова: {avg_word_length(test_text):.2f}")  # ~4.27
    
    # Тестирование с русским текстом
    russian_text = "Привет мир. Это тестовый текст. Привет ещё раз."
    print(f"\nРусский текст: '{russian_text}'")
    print(f"Слов: {word_count(russian_text)}")  # 8
    print(f"Топ слова: {top_words(russian_text, 2)}")  # [('привет', 2), ('мир', 1)]
