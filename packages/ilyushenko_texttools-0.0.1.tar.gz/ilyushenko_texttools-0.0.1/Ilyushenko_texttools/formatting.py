import re
from typing import str

from exceptions import InvalidTextError
from cleaning import remove_punctuation, normalize_spaces


def to_snake_case(text: str) -> str:
    """
    Переводит строку в snake_case.
    
    Args:
        text: Исходный текст для преобразования
        
    Returns:
        Текст в формате snake_case
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Очистка текста: убираем пунктуацию и нормализуем пробелы
    cleaned_text = remove_punctuation(normalize_spaces(text.strip()))
    
    # Разбиение: разделяем на слова по пробелам
    words = cleaned_text.split()
    
    # Преобразование: приводим к нижнему регистру
    words = [word.lower() for word in words]
    
    # Склейка: объединяем слова через подчеркивания
    return '_'.join(words)


def to_kebab_case(text: str) -> str:
    """
    Переводит строку в kebab-case.
    
    Args:
        text: Исходный текст для преобразования
        
    Returns:
        Текст в формате kebab-case
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    # Очистка текста: убираем пунктуацию и нормализуем пробелы
    cleaned_text = remove_punctuation(normalize_spaces(text.strip()))
    
    # Разбиение: разделяем на слова по пробелам
    words = cleaned_text.split()
    
    # Преобразование: приводим к нижнему регистру
    words = [word.lower() for word in words]
    
    # Склейка: объединяем слова через дефисы
    return '-'.join(words)


def capitalize_sentences(text: str) -> str:
    """
    Делает первую букву каждого предложения заглавной.
    
    Args:
        text: Исходный текст для преобразования
        
    Returns:
        Текст с заглавными первыми буквами предложений
        
    Raises:
        InvalidTextError: Если передан не строковый аргумент
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    if not text.strip():
        return text
    
    # Очистка текста: нормализуем пробелы
    cleaned_text = normalize_spaces(text.strip())
    
    # Разбиение: разделяем на предложения по точкам, восклицательным и вопросительным знакам
    # Используем lookahead чтобы сохранить разделители
    sentences = re.split(r'([.!?]+s*)', cleaned_text)
    
    # Преобразование: делаем первую букву каждого предложения заглавной
    result_sentences = []
    capitalize_next = True
    
    for part in sentences:
        if not part.strip():
            result_sentences.append(part)
            continue
            
        if part.endswith(('.', '!', '?')):
            # Это разделитель предложения
            result_sentences.append(part)
            capitalize_next = True
        else:
            # Это текст предложения
            if capitalize_next and part:
                # Делаем первую букву заглавной
                capitalized = part[0].upper() + part[1:] if part else part
                result_sentences.append(capitalized)
                capitalize_next = False
            else:
                result_sentences.append(part)
    
    # Склейка: объединяем все части обратно
    return ''.join(result_sentences)


# Альтернативная версия capitalize_sentences с другим подходом
def capitalize_sentences_v2(text: str) -> str:
    """
    Альтернативная реализация capitalize_sentences с использованием регулярных выражений.
    
    Args:
        text: Исходный текст для преобразования
        
    Returns:
        Текст с заглавными первыми буквами предложений
    """
    if not isinstance(text, str):
        raise InvalidTextError(text)
    
    if not text.strip():
        return text
    
    # Очистка текста
    cleaned_text = normalize_spaces(text.strip())
    
    # Используем регулярное выражение для поиска начала предложений
    # Паттерн: начало строки или точка/восклицательный/вопросительный знак + пробел
    # За которым следует буква
    def capitalize_match(match):
        return match.group(0).upper()
    
    # Первая буква текста
    result = cleaned_text[0].upper() + cleaned_text[1:] if cleaned_text else cleaned_text
    
    # Первые буквы после .!?
    result = re.sub(
        r'([.!?]s+)([a-zа-я])', 
        lambda m: m.group(1) + m.group(2).upper(), 
        result
    )
    
    return result


# Примеры использования
if __name__ == "__main__":
    # Тестирование to_snake_case
    print("to_snake_case:")
    print(f"'{to_snake_case('Hello World')}'")  # 'hello_world'
    print(f"'{to_snake_case('Multiple   Words   Here')}'")  # 'multiple_words_here'
    print(f"'{to_snake_case('Test with, punctuation!')}'")  # 'test_with_punctuation'
    
    # Тестирование to_kebab_case
    print("\nto_kebab_case:")
    print(f"'{to_kebab_case('Hello World')}'")  # 'hello-world'
    print(f"'{to_kebab_case('Convert This Text')}'")  # 'convert-this-text'
    print(f"'{to_kebab_case('Remove! all? punctuation.')}'")  # 'remove_all_punctuation'
    
    # Тестирование capitalize_sentences
    print("\ncapitalize_sentences:")
    test_text = "hello. this is a test! does it work? yes, it does."
    print(f"Исходный: '{test_text}'")
    print(f"Результат: '{capitalize_sentences(test_text)}'")
    # 'Hello. This is a test! Does it work? Yes, it does.'
    
    # Тестирование с различными разделителями
    test_text2 = "first sentence. second sentence! third sentence?"
    print(f"Результат 2: '{capitalize_sentences(test_text2)}'")
    # 'First sentence. Second sentence! Third sentence?'
