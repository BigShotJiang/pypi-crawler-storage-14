"""Import Tests."""

import matplotlib as mpl
import numpy as np
import scipy
import torch

import gmtorch


def test_gmtorch_import() -> None:
    """Test that the `gmtorch` package can be imported."""
    assert isinstance(gmtorch.__name__, str)


def test_torch_import() -> None:
    """Test that the `torch` package can be imported."""
    assert isinstance(torch.__name__, str)


def test_numpy_import() -> None:
    """Test that the `numpy` package can be imported."""
    assert isinstance(np.__name__, str)
    assert np.__name__ == "numpy"


def test_scipy_import() -> None:
    """Test that the `scipy` package can be imported."""
    assert isinstance(scipy.__name__, str)
    assert scipy.__name__ == "scipy"


def test_matplotlib_import() -> None:
    """Test that the `matplotlib` package can be imported."""
    assert isinstance(mpl.__name__, str)
    assert mpl.__name__ == "matplotlib"
