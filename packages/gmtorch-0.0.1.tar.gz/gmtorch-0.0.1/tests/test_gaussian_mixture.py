"""Tests for Gaussian Mixture Model."""

import gmtorch


def test_gaussian_mixture_default_constructor_valid() -> None:
    """Test that the GaussianMixture default constructor works."""
    gm = gmtorch.GaussianMixture()
    assert gm is not None


def test_gaussian_mixture_init_type() -> None:
    """Test that the GaussianMixture instance is of correct type."""
    gm = gmtorch.GaussianMixture()
    assert isinstance(gm, gmtorch.GaussianMixture)
