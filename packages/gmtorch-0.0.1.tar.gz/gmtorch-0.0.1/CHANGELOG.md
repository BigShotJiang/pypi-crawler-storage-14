## v0.0.1 (2025-11-17)

### Feat

- provide better instructions for uv setup and remove cuda dependencies from pyproject.toml
- add initial implementation for ci/cd pipeline

### Fix

- **docker**: install the correct torch version in Dockerfile
