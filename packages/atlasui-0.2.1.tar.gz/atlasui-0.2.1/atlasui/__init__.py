"""
AtlasUI - MongoDB Atlas User Interface

A comprehensive UI for MongoDB Atlas administration including web interface and CLI.
"""

from atlasui.config import settings

__version__ = settings.app_version
