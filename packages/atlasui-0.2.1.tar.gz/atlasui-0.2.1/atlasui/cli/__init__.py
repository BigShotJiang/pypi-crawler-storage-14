"""
CLI tool for MongoDB Atlas management.
"""

from atlasui.cli.main import app

__all__ = ["app"]
