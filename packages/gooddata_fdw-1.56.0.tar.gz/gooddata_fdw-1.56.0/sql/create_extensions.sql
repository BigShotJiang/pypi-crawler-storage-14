-- (C) 2021 GoodData Corporation
CREATE EXTENSION multicorn;
CREATE EXTENSION foreign_table_exposer;
