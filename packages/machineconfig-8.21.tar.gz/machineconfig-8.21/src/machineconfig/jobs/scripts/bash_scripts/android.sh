cp crouton /tmp/
sudo sh /tmp/crouton -r bookworm -t core -n debian
