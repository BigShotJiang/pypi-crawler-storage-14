# Contributors

This file lists the contributors to the Remoulade project.

By adding your name to the list below you disavow any rights or claims
to any changes submitted to the Remoulade project and assign copyright
of those changes to CLEARTYPE SRL.

| Username                                                         | Name                   |
|:-----------------------------------------------------------------|:-----------------------|
| [@bendemaree](https://github.com/bendemaree)                     | Ben Demaree            |
| [@whalesalad](https://github.com/whalesalad)                     | Michael Whalen         |
| [@rakanalh](https://github.com/rakanalh)                         | Rakan Alhneiti         |
| [@jssuzanne](https://github.com/jssuzanne)                       | Jean-Sébastien Suzanne |
| [@chen2aaron](https://github.com/chen2aaron)                     | xixijun                |
| [@aequitas](https://github.com/aequitas)                         | Johan Bloemberg        |
| [@najamansari](https://github.com/najamansari)                   | Najam Ahmed Ansari     |
| [@rpkilby](https://github.com/rpkilby)                           | Ryan P Kilby           |
| [@2miksyn](https://github.com/2miksyn)                           | Mikhail Smirnov        |
| [@gdvalle](https://github.com/gdvalle)                           | Greg Dallavalle        |
| [@viiicky](https://github.com/viiicky)                           | Vikas Prasad           |
| [@xdmiodz](https://github.com/xdmiodz)                           | Dmitry Odzerikho       |
| [@ryansm1](https://github.com/ryansm1)                           | Ryan Smith             |
| [@aericson](https://github.com/aericson)                         | André Ericson          |
| [@xdanielsb](https://github.com/xdanielsb)                       | Daniel Santos          |
| [@simondosda](https://github.com/simondosda)                     | Simon Dosda            |
| [@ben-natan](https://github.com/ben-natan)                       | Adrien Bennatan        |
| [@Corentin-Br](https://github.com/Corentin-Br)                   | Corentin Bravo         |
| [@antoinerabany](https://github.com/antoinerabany)               | Antoine Rabany         |
| [@thomasLeMeur](https://github.com/thomasLeMeur)                 | Thomas Le Meur         |
| [@fregogui](https://github.com/fregogui)                         | Guillaume Fregosi      |
| [@pgitips](https://github.com/pgitips)                           | Pierre Giraud          |
| [@williampollet](https://github.com/williampollet)               | William Pollet         |
| [@mehdithez](https://github.com/mehdithez)                       | Zeroual Mehdi          |
| [@julien-duponchelle](https://github.com/julien-duponchelle)    |  Julien Duponchelle           |
| [@alisterd51](https://github.com/alisterd51)       | Antoine Clarman        |
