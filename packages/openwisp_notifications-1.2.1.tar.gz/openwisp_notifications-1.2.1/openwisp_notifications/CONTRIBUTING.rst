Please refer to the `OpenWISP Contributing Guidelines
<http://openwisp.io/docs/developer/contributing.html>`_.
