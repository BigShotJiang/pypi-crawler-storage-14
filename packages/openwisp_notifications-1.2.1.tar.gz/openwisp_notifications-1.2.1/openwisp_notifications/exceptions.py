class NotificationRenderException(Exception):
    """
    Raised when notification's message or email cannot be rendered.
    """

    pass
