from openwisp_notifications.management.commands import (
    BasePopulateNotificationPreferencesCommand,
)


class Command(BasePopulateNotificationPreferencesCommand):
    pass
