from openwisp_notifications.management.commands import BaseCreateNotificationCommand


class Command(BaseCreateNotificationCommand):
    pass
