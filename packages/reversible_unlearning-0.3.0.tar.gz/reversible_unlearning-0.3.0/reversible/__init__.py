﻿# reversible_unlearning/__init__.py (with underscores for Python imports)
from .core import (
    Reversible,
    ForgetVerification,
    BalancedUnlearner,           # NEW V3
    SelectiveGradientUnlearner,  # NEW V3
    MembershipInferenceTest,     # NEW V3
    verify_unlearning_quality,   # NEW V3
    reversible_pipeline          # Helper
)
