import argparse
import sys
import os
import json
from datetime import datetime
from pathlib import Path

from jarvis_ai.core.ai_engine import ai_engine
from jarvis_ai.system.file_manager import FileManager
from jarvis_ai.system.screen_analyzer import ScreenAnalyzer

class JarvisCLI:
    def __init__(self):
        # Создаем экземпляры компонентов
        self.file_manager = FileManager()
        self.screen_analyzer = ScreenAnalyzer()
        self.ai_engine = ai_engine
        
        # Статистика использования
        self.command_count = 0
        
    def _print_banner(self):
        """Вывод баннера Jarvis AI"""
        print("╔══════════════════════════════════════════════════════════════╗")
        print("║                    🤖 JARVIS AI v0.2.0                       ║")
        print("║      Персональный AI ассистент с Hugging Face                ║")
        print("╚══════════════════════════════════════════════════════════════╝")
        print()
    
    def _handle_start(self, args):
        """Запуск интерактивного режима"""
        self._print_banner()
        
        # Проверка доступности Hugging Face
        hf_status = self.ai_engine.test_connection()
        if hf_status["status"] == "error":
            print("❌ Hugging Face не настроен")
            print(f"📝 {hf_status['message']}")
            print("\n🔧 Используйте: python setup_huggingface.py")
            return
        
        print(f"✅ Hugging Face доступен (Пользователь: {hf_status.get('user', 'Unknown')})")
        print("🚀 Jarvis AI готов к работе!")
        print("\n" + "═" * 60)
        print("💡 Доступные команды:")
        print("  analyze 'проблема'      - Анализ проблемы")
        print("  screenshots            - История скриншотов")
        print("  cleanup-screenshots    - Очистка старых скриншотов")
        print("  file <команда>         - Работа с файлами")
        print("  knowledge search 'запрос' - Поиск в базе знаний")
        print("  knowledge stats        - Статистика знаний")
        print("  stats                  - Общая статистика")
        print("  version                - Версия системы")
        print("  help                   - Справка по командам")
        print("  exit                   - Выход")
        print("═" * 60)
        
        # Интерактивный цикл
        while True:
            try:
                user_input = input("\njarvis> ").strip()
                self.command_count += 1
                
                if not user_input:
                    continue
                    
                if user_input.lower() in ['exit', 'quit', 'выход']:
                    print(f"👋 До свидания! Выполнено команд: {self.command_count}")
                    break
                    
                elif user_input.lower() in ['help', 'помощь', '?']:
                    print("Доступные команды:")
                    print("  start                    - Перезапуск интерактивного режима")
                    print("  analyze 'проблема'       - Анализ проблемы со скриншотом")
                    print("  screenshots [limit]      - История скриншотов (по умолчанию 10)")
                    print("  cleanup-screenshots      - Очистка скриншотов старше 30 дней")
                    print("  file list [путь]         - Список файлов")
                    print("  file cd <путь>           - Сменить директорию")
                    print("  file pwd                 - Текущая директория")
                    print("  file mkdir <имя>         - Создать папку")
                    print("  file touch <имя>         - Создать файл")
                    print("  file cp <откуда> <куда>  - Копировать файл")
                    print("  file mv <откуда> <куда>  - Переместить файл")
                    print("  file rm <путь>           - Удалить файл")
                    print("  file find <имя>          - Поиск файлов")
                    print("  file info <путь>         - Информация о файле")
                    print("  file disk                - Информация о дисках")
                    print("  file cat <путь>          - Показать содержимое файла")
                    print("  file screenshot          - Сделать скриншот")
                    print("  knowledge search 'запрос' - Поиск в базе знаний")
                    print("  knowledge stats          - Статистика базы знаний")
                    print("  stats                    - Статистика системы")
                    print("  version                  - Версия Jarvis AI")
                    print("  help                     - Эта справка")
                    print("  exit                     - Выход")
                    
                elif user_input.lower() == 'start':
                    print("🔄 Перезапуск интерактивного режима...")
                    continue
                    
                elif user_input.startswith('analyze '):
                    problem = user_input[8:].strip()
                    if problem:
                        self._handle_analyze_interactive(problem)
                    else:
                        print("❌ Укажите проблему: analyze 'ваша проблема'")
                        
                elif user_input.startswith('screenshots'):
                    parts = user_input.split()
                    limit = int(parts[1]) if len(parts) > 1 else 10
                    self._handle_screenshots_interactive(limit)
                    
                elif user_input == 'cleanup-screenshots':
                    self._handle_cleanup_screenshots_interactive()
                    
                elif user_input.startswith('file '):
                    file_cmd = user_input[5:].strip()
                    self._handle_file_interactive(file_cmd)
                    
                elif user_input.startswith('knowledge '):
                    knowledge_cmd = user_input[10:].strip()
                    self._handle_knowledge_interactive(knowledge_cmd)
                    
                elif user_input == 'stats':
                    self._handle_stats_interactive()
                    
                elif user_input == 'version':
                    self._handle_version_interactive()
                    
                else:
                    # Если это не команда, обрабатываем как запрос к ИИ
                    print(f"🤖 Обработка запроса: {user_input}")
                    response = self.ai_engine.process_query(user_input)
                    print(f"📝 {response}")
                    
            except KeyboardInterrupt:
                print(f"\n👋 До свидания! Выполнено команд: {self.command_count}")
                break
            except Exception as e:
                print(f"❌ Ошибка: {e}")
    
    def _handle_analyze(self, args):
        """Анализ проблемы через CLI"""
        print(f"🔍 Анализ проблемы: {args.problem}")
        
        # Создаем скриншот
        print("📸 Создание скриншота...")
        screenshot_result = self.screen_analyzer.analyze_ui_problem(args.problem)
        print(f"✅ {screenshot_result}")
        
        # Получаем ответ от ИИ
        print("🤖 Анализ проблемы через Hugging Face...")
        response = self.ai_engine.process_query(args.problem)
        print(f"💡 Решение: {response}")
    
    def _handle_analyze_interactive(self, problem):
        """Анализ проблемы в интерактивном режиме"""
        print(f"🔍 Анализ проблемы: {problem}")
        print("📸 Создание скриншота...")
        screenshot_result = self.screen_analyzer.analyze_ui_problem(problem)
        print(f"✅ {screenshot_result}")
        print("🤖 Анализ проблемы через Hugging Face...")
        response = self.ai_engine.process_query(problem)
        print(f"💡 Решение: {response}")
    
    def _handle_screenshots(self, args):
        """Показать историю скриншотов"""
        screenshots = self.screen_analyzer.get_recent_screenshots(args.limit)
        
        if not screenshots:
            print("📸 История скриншотов пуста")
            return
        
        print(f"📸 Последние {len(screenshots)} скриншотов:")
        for i, screenshot in enumerate(screenshots, 1):
            created = screenshot["created"].strftime("%Y-%m-%d %H:%M:%S")
            size_kb = screenshot["size"] / 1024
            name = screenshot['name'][:50] + "..." if len(screenshot['name']) > 50 else screenshot['name']
            print(f"  {i:2d}. {name}")
            print(f"      📅 {created} | 📏 {size_kb:.1f} KB | 📍 {screenshot['path']}")
    
    def _handle_screenshots_interactive(self, limit=10):
        """История скриншотов в интерактивном режиме"""
        screenshots = self.screen_analyzer.get_recent_screenshots(limit)
        
        if not screenshots:
            print("📸 История скриншотов пуста")
            return
        
        print(f"📸 Последние {len(screenshots)} скриншотов:")
        for i, screenshot in enumerate(screenshots, 1):
            created = screenshot["created"].strftime("%Y-%m-%d %H:%M:%S")
            size_kb = screenshot["size"] / 1024
            print(f"  {i:2d}. {screenshot['name']} ({size_kb:.1f} KB, {created})")
    
    def _handle_cleanup_screenshots(self, args):
        """Очистка старых скриншотов"""
        print("🧹 Очистка старых скриншотов...")
        result = self.screen_analyzer.cleanup_old_screenshots(args.days)
        
        if 'error' in result:
            print(f"❌ {result['error']}")
        else:
            freed_mb = result['freed_space'] / (1024 * 1024)
            print(f"✅ {result['message']}")
            print(f"💾 Освобождено места: {freed_mb:.2f} MB")
    
    def _handle_cleanup_screenshots_interactive(self):
        """Очистка скриншотов в интерактивном режиме"""
        print("🧹 Очистка скриншотов старше 30 дней...")
        result = self.screen_analyzer.cleanup_old_screenshots(30)
        
        if 'error' in result:
            print(f"❌ {result['error']}")
        else:
            freed_mb = result['freed_space'] / (1024 * 1024)
            print(f"✅ {result['message']}")
            print(f"💾 Освобождено места: {freed_mb:.2f} MB")
    
    def _handle_file(self, args):
        """Обработка файловых команд"""
        if args.subcommand == 'list':
            files = self.file_manager.list_files(args.path)
            for file in files:
                print(file)
                
        elif args.subcommand == 'cd':
            result = self.file_manager.change_directory(args.path)
            print(result)
            
        elif args.subcommand == 'pwd':
            print(self.file_manager.current_directory)
            
        elif args.subcommand == 'mkdir':
            result = self.file_manager.create_directory(args.name)
            print(result)
            
        elif args.subcommand == 'touch':
            result = self.file_manager.create_file(args.name)
            print(result)
            
        elif args.subcommand == 'cp':
            result = self.file_manager.copy_file(args.source, args.destination)
            print(result)
            
        elif args.subcommand == 'mv':
            result = self.file_manager.move_file(args.source, args.destination)
            print(result)
            
        elif args.subcommand == 'rm':
            result = self.file_manager.delete_file(args.path)
            print(result)
            
        elif args.subcommand == 'find':
            results = self.file_manager.find_files(args.name, args.path)
            for result in results:
                print(result)
                
        elif args.subcommand == 'info':
            result = self.file_manager.get_file_info(args.path)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
        elif args.subcommand == 'disk':
            result = self.file_manager.get_disk_info()
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
        elif args.subcommand == 'cat':
            result = self.file_manager.read_file(args.path)
            print(result)
            
        elif args.subcommand == 'screenshot':
            result = self.screen_analyzer.capture_problem_screenshot("manual_screenshot")
            if result["success"]:
                print(f"✅ Скриншот сохранен: {result['screenshot_path']}")
            else:
                print(f"❌ Ошибка: {result['error']}")
    
    def _handle_file_interactive(self, command):
        """Обработка файловых команд в интерактивном режиме"""
        parts = command.split()
        if not parts:
            print("❌ Укажите файловую команду")
            return
        
        subcommand = parts[0]
        
        try:
            if subcommand == 'list':
                path = parts[1] if len(parts) > 1 else '.'
                files = self.file_manager.list_files(path)
                for file in files:
                    print(file)
                    
            elif subcommand == 'cd':
                if len(parts) > 1:
                    result = self.file_manager.change_directory(parts[1])
                    print(result)
                else:
                    print("❌ Укажите путь")
                    
            elif subcommand == 'pwd':
                print(self.file_manager.current_directory)
                
            elif subcommand == 'mkdir':
                if len(parts) > 1:
                    result = self.file_manager.create_directory(parts[1])
                    print(result)
                else:
                    print("❌ Укажите имя папки")
                    
            elif subcommand == 'touch':
                if len(parts) > 1:
                    result = self.file_manager.create_file(parts[1])
                    print(result)
                else:
                    print("❌ Укажите имя файла")
                    
            elif subcommand == 'cp':
                if len(parts) > 2:
                    result = self.file_manager.copy_file(parts[1], parts[2])
                    print(result)
                else:
                    print("❌ Укажите исходный и целевой пути")
                    
            elif subcommand == 'mv':
                if len(parts) > 2:
                    result = self.file_manager.move_file(parts[1], parts[2])
                    print(result)
                else:
                    print("❌ Укажите исходный и целевой пути")
                    
            elif subcommand == 'rm':
                if len(parts) > 1:
                    result = self.file_manager.delete_file(parts[1])
                    print(result)
                else:
                    print("❌ Укажите путь к файлу")
                    
            elif subcommand == 'find':
                if len(parts) > 1:
                    path = parts[2] if len(parts) > 2 else '.'
                    results = self.file_manager.find_files(parts[1], path)
                    for result in results:
                        print(result)
                else:
                    print("❌ Укажите имя файла для поиска")
                    
            elif subcommand == 'info':
                if len(parts) > 1:
                    result = self.file_manager.get_file_info(parts[1])
                    print(json.dumps(result, indent=2, ensure_ascii=False))
                else:
                    print("❌ Укажите путь к файлу")
                    
            elif subcommand == 'disk':
                result = self.file_manager.get_disk_info()
                print(json.dumps(result, indent=2, ensure_ascii=False))
                
            elif subcommand == 'cat':
                if len(parts) > 1:
                    result = self.file_manager.read_file(parts[1])
                    print(result)
                else:
                    print("❌ Укажите путь к файлу")
                    
            elif subcommand == 'screenshot':
                result = self.screen_analyzer.capture_problem_screenshot("manual_screenshot")
                if result["success"]:
                    print(f"✅ Скриншот сохранен: {result['screenshot_path']}")
                else:
                    print(f"❌ Ошибка: {result['error']}")
                    
            else:
                print(f"❌ Неизвестная файловая команда: {subcommand}")
                print("💡 Доступные: list, cd, pwd, mkdir, touch, cp, mv, rm, find, info, disk, cat, screenshot")
                
        except Exception as e:
            print(f"❌ Ошибка выполнения команды: {e}")
    
    def _handle_knowledge(self, args):
        """Обработка команд базы знаний"""
        if args.subcommand == 'search':
            if hasattr(self.ai_engine, 'knowledge_base') and self.ai_engine.knowledge_base:
                result = self.ai_engine.knowledge_base.find_similar(args.query)
                if result:
                    print(f"✅ Найдено в базе знаний: {result}")
                else:
                    print("❌ Не найдено в базе знаний")
            else:
                print("❌ База знаний не инициализирована")
                
        elif args.subcommand == 'stats':
            if hasattr(self.ai_engine, 'knowledge_base') and self.ai_engine.knowledge_base:
                stats = self.ai_engine.knowledge_base.get_statistics()
                print("📊 Статистика базы знаний:")
                print(f"  📚 Всего вопросов: {stats.get('total_questions', 0)}")
                print(f"  📈 Всего использований: {stats.get('total_usage', 0)}")
                print(f"  🔥 Активных (7 дней): {stats.get('recent_usage_7d', 0)}")
                print(f"  💰 Сэкономлено токенов: ~{stats.get('tokens_saved_estimate', 0)}")
                
                if 'top_questions' in stats:
                    print("\n  🏆 Популярные вопросы:")
                    for i, (question, count) in enumerate(stats['top_questions'][:3], 1):
                        print(f"    {i}. {question[:50]}... ({count} раз)")
            else:
                print("❌ База знаний не инициализирована")
    
    def _handle_knowledge_interactive(self, command):
        """Обработка команд базы знаний в интерактивном режиме"""
        parts = command.split()
        if not parts:
            print("❌ Укажите команду базы знаний: search или stats")
            return
        
        subcommand = parts[0]
        
        try:
            if subcommand == 'search':
                if len(parts) > 1:
                    query = ' '.join(parts[1:])
                    if hasattr(self.ai_engine, 'knowledge_base') and self.ai_engine.knowledge_base:
                        result = self.ai_engine.knowledge_base.find_similar(query)
                        if result:
                            print(f"✅ Найдено в базе знаний: {result}")
                        else:
                            print("❌ Не найдено в базе знаний")
                    else:
                        print("❌ База знаний не инициализирована")
                else:
                    print("❌ Укажите запрос для поиска")
                    
            elif subcommand == 'stats':
                if hasattr(self.ai_engine, 'knowledge_base') and self.ai_engine.knowledge_base:
                    stats = self.ai_engine.knowledge_base.get_statistics()
                    print("📊 Статистика базы знаний:")
                    print(f"  📚 Всего вопросов: {stats.get('total_questions', 0)}")
                    print(f"  📈 Всего использований: {stats.get('total_usage', 0)}")
                    print(f"  🔥 Активных (7 дней): {stats.get('recent_usage_7d', 0)}")
                else:
                    print("❌ База знаний не инициализирована")
                    
            else:
                print(f"❌ Неизвестная команда базы знаний: {subcommand}")
                print("💡 Доступные: search, stats")
                
        except Exception as e:
            print(f"❌ Ошибка выполнения команды: {e}")
    
    def _handle_stats(self, args):
        """Показать общую статистику системы"""
        print("📊 Общая статистика Jarvis AI:")
        print("═" * 40)
        
        # Статистика Hugging Face
        hf_status = self.ai_engine.test_connection()
        print(f"🤖 Hugging Face: {hf_status['status'].upper()}")
        print(f"   📝 {hf_status['message']}")
        if 'user' in hf_status:
            print(f"   👤 Пользователь: {hf_status['user']}")
        
        # Статистика базы знаний
        if hasattr(self.ai_engine, 'knowledge_base') and self.ai_engine.knowledge_base:
            try:
                stats = self.ai_engine.knowledge_base.get_statistics()
                print(f"🧠 База знаний: {stats.get('total_questions', 0)} вопросов")
                print(f"   📈 Использовано: {stats.get('total_usage', 0)} раз")
            except:
                print("🧠 База знаний: недоступна")
        
        # Статистика скриншотов
        screenshots = self.screen_analyzer.get_recent_screenshots(1000)
        print(f"📸 Скриншотов всего: {len(screenshots)}")
        
        # Статистика приватности
        if hasattr(self.ai_engine, 'privacy_engine') and self.ai_engine.privacy_engine:
            try:
                report = self.ai_engine.privacy_engine.get_privacy_report()
                print(f"🛡️ Правил приватности: {report.get('total_rules', 0)}")
            except:
                print("🛡️ Приватность: недоступна")
        
        print("═" * 40)
    
    def _handle_stats_interactive(self):
        """Статистика в интерактивном режиме"""
        self._handle_stats(None)
    
    def _handle_version(self, args):
        """Показать версию системы"""
        self._print_banner()
        print("📦 Версия: 0.2.0")
        print("🤖 ИИ: Hugging Face API")
        print("🔗 Бесплатный лимит: 100,000 токенов в месяц")
        print("🇷🇺 Работает в России: ✅ Да")
        print("🛡️ Приватность: Очистка личных данных перед отправкой")
        print("🧠 Самообучение: Сохранение ответов в локальную базу")
    
    def _handle_version_interactive(self):
        """Версия в интерактивном режиме"""
        self._handle_version(None)
    
    def _handle_test(self, args):
        """Запуск тестов системы"""
        print("🧪 Запуск тестов Jarvis AI...")
        print("═" * 40)
        
        # Тест подключения
        print("1. 🔗 Тест подключения Hugging Face...")
        hf_status = self.ai_engine.test_connection()
        if hf_status["status"] == "success":
            print(f"   ✅ Успешно: {hf_status['message']}")
        else:
            print(f"   ❌ Ошибка: {hf_status['message']}")
        
        # Тест скриншота
        print("\n2. 📸 Тест создания скриншота...")
        result = self.screen_analyzer.capture_problem_screenshot("тестовая_проблема")
        if result["success"]:
            print(f"   ✅ Успешно: {result['message']}")
        else:
            print(f"   ❌ Ошибка: {result['error']}")
        
        # Тест файлового менеджера
        print("\n3. 📁 Тест файлового менеджера...")
        try:
            current_dir = self.file_manager.current_directory
            print(f"   ✅ Текущая директория: {current_dir}")
        except Exception as e:
            print(f"   ❌ Ошибка: {e}")
        
        # Тест ИИ
        print("\n4. 🤖 Тест обработки запроса ИИ...")
        response = self.ai_engine.process_query("Привет, это тест")
        if "❌" not in response:
            print(f"   ✅ Успешно: {response[:50]}...")
        else:
            print(f"   ❌ Ошибка: {response}")
        
        print("\n═" * 40)
        print("🧪 Тесты завершены!")
    
    def _handle_help(self, args):
        """Показать справку по командам"""
        self._print_banner()
        print("📖 Справка по командам Jarvis AI:")
        print("═" * 60)
        
        print("\n🚀 Основные команды:")
        print("  jarvis start                    - Запуск интерактивного режима")
        print("  jarvis analyze \"проблема\"       - Анализ проблемы со скриншотом")
        print("  jarvis stats                    - Статистика системы")
        print("  jarvis version                  - Версия системы")
        print("  jarvis help                     - Эта справка")
        
        print("\n📸 Команды скриншотов:")
        print("  jarvis screenshots [лимит]      - История скриншотов")
        print("  jarvis cleanup-screenshots      - Очистка старых скриншотов")
        
        print("\n📁 Файловые команды:")
        print("  jarvis file list [путь]         - Список файлов")
        print("  jarvis file cd <путь>           - Сменить директорию")
        print("  jarvis file pwd                 - Текущая директория")
        print("  jarvis file mkdir <имя>         - Создать папку")
        print("  jarvis file touch <имя>         - Создать файл")
        print("  jarvis file cp <откуда> <куда>  - Копировать файл")
        print("  jarvis file mv <откуда> <куда>  - Переместить файл")
        print("  jarvis file rm <путь>           - Удалить файл")
        print("  jarvis file find <имя> [путь]   - Поиск файлов")
        print("  jarvis file info <путь>         - Информация о файле")
        print("  jarvis file disk                - Информация о дисках")
        print("  jarvis file cat <путь>          - Показать содержимое файла")
        print("  jarvis file screenshot          - Сделать скриншот")
        
        print("\n🧠 Команды базы знаний:")
        print("  jarvis knowledge search \"запрос\" - Поиск в базе знаний")
        print("  jarvis knowledge stats          - Статистика базы знаний")
        
        print("\n🔧 Сервисные команды:")
        print("  jarvis test                     - Запуск тестов системы")
        
        print("\n═" * 60)
        print("💡 В интерактивном режиме (jarvis start) доступны те же команды")

def main():
    cli = JarvisCLI()
    
    parser = argparse.ArgumentParser(
        description="Jarvis AI - персональный AI помощник с Hugging Face",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  jarvis start                    - Запуск интерактивного режима
  jarvis analyze "не работает кнопка" - Анализ проблемы
  jarvis screenshots              - История скриншотов
  jarvis file list                - Список файлов
  jarvis knowledge search "ошибка" - Поиск в базе знаний
  jarvis stats                    - Статистика системы
  jarvis version                  - Версия Jarvis AI
  jarvis help                     - Справка по командам

Для подробной справки по конкретной команде используйте:
  jarvis <команда> --help
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Доступные команды')
    
    # Команда start
    start_parser = subparsers.add_parser('start', help='Запуск интерактивного режима')
    
    # Команда analyze
    analyze_parser = subparsers.add_parser('analyze', help='Анализ проблемы со скриншотом')
    analyze_parser.add_argument('problem', help='Описание проблемы')
    
    # Команда screenshots
    screenshots_parser = subparsers.add_parser('screenshots', help='История скриншотов')
    screenshots_parser.add_argument('--limit', type=int, default=10, help='Лимит скриншотов')
    
    # Команда cleanup-screenshots
    cleanup_parser = subparsers.add_parser('cleanup-screenshots', help='Очистка старых скриншотов')
    cleanup_parser.add_argument('--days', type=int, default=30, help='Удалять скриншоты старше N дней')
    
    # Команда file
    file_parser = subparsers.add_parser('file', help='Управление файлами')
    file_subparsers = file_parser.add_subparsers(dest='subcommand', help='Файловые команды')
    
    # Подкоманды file
    file_list_parser = file_subparsers.add_parser('list', help='Список файлов')
    file_list_parser.add_argument('path', nargs='?', default='.', help='Путь')
    
    file_cd_parser = file_subparsers.add_parser('cd', help='Сменить директорию')
    file_cd_parser.add_argument('path', help='Путь')
    
    file_pwd_parser = file_subparsers.add_parser('pwd', help='Текущая директория')
    
    file_mkdir_parser = file_subparsers.add_parser('mkdir', help='Создать папку')
    file_mkdir_parser.add_argument('name', help='Имя папки')
    
    file_touch_parser = file_subparsers.add_parser('touch', help='Создать файл')
    file_touch_parser.add_argument('name', help='Имя файла')
    
    file_cp_parser = file_subparsers.add_parser('cp', help='Копировать файл')
    file_cp_parser.add_argument('source', help='Источник')
    file_cp_parser.add_argument('destination', help='Назначение')
    
    file_mv_parser = file_subparsers.add_parser('mv', help='Переместить файл')
    file_mv_parser.add_argument('source', help='Источник')
    file_mv_parser.add_argument('destination', help='Назначение')
    
    file_rm_parser = file_subparsers.add_parser('rm', help='Удалить файл')
    file_rm_parser.add_argument('path', help='Путь к файлу')
    
    file_find_parser = file_subparsers.add_parser('find', help='Поиск файлов')
    file_find_parser.add_argument('name', help='Имя файла для поиска')
    file_find_parser.add_argument('path', nargs='?', default='.', help='Путь для поиска')
    
    file_info_parser = file_subparsers.add_parser('info', help='Информация о файле')
    file_info_parser.add_argument('path', help='Путь к файлу')
    
    file_disk_parser = file_subparsers.add_parser('disk', help='Информация о дисках')
    
    file_cat_parser = file_subparsers.add_parser('cat', help='Показать содержимое файла')
    file_cat_parser.add_argument('path', help='Путь к файлу')
    
    file_screenshot_parser = file_subparsers.add_parser('screenshot', help='Сделать скриншот')
    
    # Команда knowledge
    knowledge_parser = subparsers.add_parser('knowledge', help='Работа с базой знаний')
    knowledge_subparsers = knowledge_parser.add_subparsers(dest='subcommand', help='Команды базы знаний')
    
    knowledge_search_parser = knowledge_subparsers.add_parser('search', help='Поиск в базе знаний')
    knowledge_search_parser.add_argument('query', help='Запрос для поиска')
    
    knowledge_stats_parser = knowledge_subparsers.add_parser('stats', help='Статистика базы знаний')
    
    # Команда stats
    stats_parser = subparsers.add_parser('stats', help='Статистика системы')
    
    # Команда version
    version_parser = subparsers.add_parser('version', help='Версия Jarvis AI')
    
    # Команда help
    help_parser = subparsers.add_parser('help', help='Справка по командам')
    
    # Команда test
    test_parser = subparsers.add_parser('test', help='Запуск тестов системы')
    
    # Парсим аргументы
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Обработка команд
    try:
        if args.command == 'start':
            cli._handle_start(args)
        elif args.command == 'analyze':
            cli._handle_analyze(args)
        elif args.command == 'screenshots':
            cli._handle_screenshots(args)
        elif args.command == 'cleanup-screenshots':
            cli._handle_cleanup_screenshots(args)
        elif args.command == 'file':
            cli._handle_file(args)
        elif args.command == 'knowledge':
            cli._handle_knowledge(args)
        elif args.command == 'stats':
            cli._handle_stats(args)
        elif args.command == 'version':
            cli._handle_version(args)
        elif args.command == 'help':
            cli._handle_help(args)
        elif args.command == 'test':
            cli._handle_test(args)
        else:
            parser.print_help()
    except KeyboardInterrupt:
        print("\n👋 Прервано пользователем")
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()