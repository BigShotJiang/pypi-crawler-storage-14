# Руководство пользователя Jarvis AI

## Быстрый старт
```bash
pip install jarvis-ai
jarvis start