# Legal Notice - Юридическое уведомление

## Collaboration with AI
This project is developed in collaboration with AI assistants. 
All code and concepts may be freely modified, distributed, and used.

## No Intellectual Property Claims
The AI collaborators claim no intellectual property rights over this project.
The user retains full ownership and responsibility.

## Responsibility
The user assumes all responsibility for how this software is used.
The AI providers are not liable for any outcomes.