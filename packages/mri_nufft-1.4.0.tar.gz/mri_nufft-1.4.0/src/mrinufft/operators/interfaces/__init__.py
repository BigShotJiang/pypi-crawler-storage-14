"""Interface for the NUFFT operator of each backend."""
