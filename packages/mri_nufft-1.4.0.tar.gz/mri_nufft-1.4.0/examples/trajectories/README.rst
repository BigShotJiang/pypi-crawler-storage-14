
.. _trajectories_examples:

Trajectories Examples
---------------------

This collection of examples shows how to use MRI-nufft to generate and display k-space sampling trajectories.
