
Explanations
============


.. toctree::

   nufft
   mrinufft_convention
   trajectory_gradspec
