from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import Field

from .enums import CommandType, OrderType, Side, StrategyType
from .models import CustomBaseModel


class CommandBase(CustomBaseModel):
    id: UUID = Field(default_factory=uuid4)
    version: Literal["v1"] = "v1"
    type: CommandType
    details: dict[str, Any] | None = None


class NewOrderCommandBase(CommandBase):
    type: Literal[CommandType.NEW_ORDER] = CommandType.NEW_ORDER
    strategy_type: StrategyType
    instrument_id: UUID


class SingleOrderMeta(CustomBaseModel):
    order_id: UUID
    user_id: UUID
    order_type: OrderType
    side: Side
    quantity: int
    limit_price: float | None = Field(None, ge=0.0)
    stop_price: float | None = Field(None, ge=0.0)

    def model_post_init(self, context):
        if self.limit_price is None and self.stop_price is None:
            raise ValueError("Either limit or stop price must be specified")
        return self


class NewSingleOrderCommand(NewOrderCommandBase, SingleOrderMeta):
    pass


class NewOCOOrderCommand(NewOrderCommandBase):
    legs: list[SingleOrderMeta] = Field(max_length=2)


class NewOTOOrderCommand(NewOrderCommandBase):
    parent: dict
    child: dict


class NewOTOCOOrderCommand(NewOrderCommandBase):
    parent: dict
    oco_legs: list[SingleOrderMeta] = Field(min_length=2, max_length=2)


class CancelOrderCommand(CommandBase):
    order_id: UUID
    instrument_id: UUID


class ModifyOrderCommand(CommandBase):
    order_id: str
    symbol: str
    limit_price: float | None = None
    stop_price: float | None = None


class CreateInstrumentCommand(CommandBase):
    instrument_id: UUID
