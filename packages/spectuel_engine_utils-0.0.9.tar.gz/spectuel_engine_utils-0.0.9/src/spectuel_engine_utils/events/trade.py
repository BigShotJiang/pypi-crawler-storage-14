from typing import Literal
from uuid import UUID

from spectuel_engine_utils.enums import LiquidityRole
from spectuel_engine_utils.events.base import EngineEventBase
from .enums import TradeEventType


class NewTradeEvent(EngineEventBase):
    type: Literal[TradeEventType.NEW_TRADE] = TradeEventType.NEW_TRADE
    version: Literal["v1"] = "v1"
    order_id: UUID
    instrument_id: UUID
    role: LiquidityRole
    quantity: int
    price: float
