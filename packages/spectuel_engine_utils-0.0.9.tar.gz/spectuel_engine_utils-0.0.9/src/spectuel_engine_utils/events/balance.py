from typing import Literal

from .base import EngineEventBase
from .enums import BalanceEventType


class BalanceEventBase(EngineEventBase):
    type: BalanceEventType
    user_id: str


class CashBalanceIncreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.CASH_BALANCE_INCREASED] = (
        BalanceEventType.CASH_BALANCE_INCREASED
    )
    amount: float


class CashBalanceDecreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.CASH_BALANCE_DECREASED] = (
        BalanceEventType.CASH_BALANCE_DECREASED
    )
    amount: float


class CashEscrowIncreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.CASH_ESCROW_INCREASED] = (
        BalanceEventType.CASH_ESCROW_INCREASED
    )
    amount: float


class CashEscrowDecreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.CASH_ESCROW_DECREASED] = (
        BalanceEventType.CASH_ESCROW_DECREASED
    )
    amount: float


class AssetBalanceIncreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.ASSET_BALANCE_INCREASED] = (
        BalanceEventType.ASSET_BALANCE_INCREASED
    )
    instrument_id: str
    amount: float


class AssetBalanceDecreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.ASSET_BALANCE_DECREASED] = (
        BalanceEventType.ASSET_BALANCE_DECREASED
    )
    instrument_id: str
    amount: float


class AssetEscrowIncreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.ASSET_ESCROW_INCREASED] = (
        BalanceEventType.ASSET_ESCROW_INCREASED
    )
    instrument_id: str
    amount: float


class AssetEscrowDecreasedEvent(BalanceEventBase):
    type: Literal[BalanceEventType.ASSET_ESCROW_DECREASED] = (
        BalanceEventType.ASSET_ESCROW_DECREASED
    )
    instrument_id: str
    amount: float


class AskSettledEvent(BalanceEventBase):
    type: Literal[BalanceEventType.ASK_SETTLED] = BalanceEventType.ASK_SETTLED
    instrument_id: str
    quantity: float
    price: float


class BidSettledEvent(BalanceEventBase):
    type: Literal[BalanceEventType.BID_SETTLED] = BalanceEventType.BID_SETTLED
    instrument_id: str
    quantity: float
    price: float
