# TNFR Locking — Canonical Module Hub (Single Source of Truth)

English-only hub for concurrency/locking utilities.

## Scope
- File locks, process/thread safety helpers

## Policy
- Keep minimal; defer theory and design to central docs (`AGENTS.md`).
