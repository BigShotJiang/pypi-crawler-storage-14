# TNFR Selector — Canonical Module Hub (Single Source of Truth)

English-only hub for selection utilities (nodes, edges, subgraphs).

## Scope
- Deterministic, seedable selection helpers; filters and predicates
