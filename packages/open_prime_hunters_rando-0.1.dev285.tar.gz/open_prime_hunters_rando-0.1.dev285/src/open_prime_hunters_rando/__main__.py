from open_prime_hunters_rando import cli

cli.main()
