from .parser import parse_data  # 同じフォルダ内の parser.py から import
__all__ = ['parse_data']       # * で import したときに公開される関数
