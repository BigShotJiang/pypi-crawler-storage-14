"""
questions_mcp_server 包入口模块

支持使用 `python -m questions_mcp_server` 启动 Questions MCP Server。
内部直接委托给 src.main.main，避免重复实现启动逻辑。
"""

from src.main import main as _main


def main():
    """程序入口函数，委托给 src.main.main"""
    _main()


if __name__ == "__main__":
    main()

