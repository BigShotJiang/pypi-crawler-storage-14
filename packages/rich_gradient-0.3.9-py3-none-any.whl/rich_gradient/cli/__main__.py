"""Executable entry point for python -m rich_gradient.cli."""

from . import cli

cli.main()
