"""qstar package."""

__version__ = "0.1.2"

from .positional_embeddings import RoPE