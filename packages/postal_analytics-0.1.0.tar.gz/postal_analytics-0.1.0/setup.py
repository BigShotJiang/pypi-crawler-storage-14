"""
Setup configuration for postal-analytics PyPI package
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="postal-analytics",
    version="0.1.0",
    author="Mahadeva Chandra",
    author_email="x24272507@student.ncirl.ie",
    description="Sales report generation library for postal service applications",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mswamych2/CPP_PostalService/tree/main/postal-service/postal_analytics",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "boto3>=1.29.0",
        "reportlab>=4.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
        ],
    },
    keywords="postal, analytics, sales, reports, dynamodb",
    project_urls={
        "Bug Reports": "https://github.com/mswamych2/CPP_PostalService/tree/main/postal-service/postal_analytics/issues",
        "Source": "https://github.com/mswamych2/CPP_PostalService/tree/main/postal-service/postal_analytics",
    },
)