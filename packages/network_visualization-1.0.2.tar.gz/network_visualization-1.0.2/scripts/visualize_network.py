"""
Interactive Network Visualization Tool

This script creates an interactive visualization of the Chile energy network,
showing power plants, substations, transmission nodes, and their connections.

Usage:
    python visualize_network.py --model-path PATH_TO_MODEL [--output OUTPUT_FILE]
"""

import os
import sys
import argparse
import plotly.graph_objs as go
import plotly.offline as pyo

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.load_data import load_all_locations, load_all_connections
from utils.graph_builder import build_network_graph, analyze_connectivity
from utils.report_generator import generate_report, save_report


# Visual styling configuration
COLORS = {
    'power': 'rgb(255, 107, 107)',           # Red - Power plants
    'substation': 'rgb(78, 205, 196)',       # Cyan - Substations
    'substation_with_demand': 'rgb(255, 183, 77)',  # Orange - Demand substations
    'nodo': 'rgb(149, 225, 211)'             # Light cyan - Transmission nodes
}

SIZES = {
    'power': 8,
    'substation': 5,
    'substation_with_demand': 10,
    'nodo': 6
}

LEGEND_NAMES = {
    'power': 'Power Plants',
    'substation': 'Substations',
    'substation_with_demand': 'Substations with Demand',
    'nodo': 'Transmission Nodes'
}


def create_visualization(locations, connections, output_file='network_graph.html'):
    """
    Create interactive Plotly visualization of the network.
    
    Args:
        locations: Dictionary of locations
        connections: List of connections
        output_file: Output HTML filename
    """
    print("\nCreating visualization...")
    
    data = []
    
    # Draw power_links (plant to substation)
    power_link_lats = []
    power_link_lons = []
    for conn in connections:
        if conn['type'] == 'power_link':
            if conn['from'] in locations and conn['to'] in locations:
                from_loc = locations[conn['from']]
                to_loc = locations[conn['to']]
                power_link_lats.extend([from_loc['lat'], to_loc['lat'], None])
                power_link_lons.extend([from_loc['lon'], to_loc['lon'], None])
    
    if power_link_lats:
        data.append(go.Scattergeo(
            lon=power_link_lons,
            lat=power_link_lats,
            mode='lines',
            line=dict(width=1.5, color='rgba(255, 107, 107, 0.3)'),
            name='Power Links',
            hoverinfo='skip',
            showlegend=True
        ))
    
    # Draw transmission_links (substation to substation)
    transmission_link_lats = []
    transmission_link_lons = []
    for conn in connections:
        if conn['type'] == 'transmission_link':
            if conn['from'] in locations and conn['to'] in locations:
                from_loc = locations[conn['from']]
                to_loc = locations[conn['to']]
                transmission_link_lats.extend([from_loc['lat'], to_loc['lat'], None])
                transmission_link_lons.extend([from_loc['lon'], to_loc['lon'], None])
    
    if transmission_link_lats:
        data.append(go.Scattergeo(
            lon=transmission_link_lons,
            lat=transmission_link_lats,
            mode='lines',
            line=dict(width=0.8, color='rgba(69, 183, 209, 0.2)'),
            name='Transmission Links',
            hoverinfo='skip',
            showlegend=True
        ))
    
    # Draw locations by type
    for loc_type in ['nodo', 'substation', 'power', 'substation_with_demand']:
        locs_of_type = {
            name: loc_data 
            for name, loc_data in locations.items() 
            if loc_data['type'] == loc_type
        }
        
        if not locs_of_type:
            continue
        
        lats = [loc['lat'] for loc in locs_of_type.values()]
        lons = [loc['lon'] for loc in locs_of_type.values()]
        names = list(locs_of_type.keys())
        
        # Create hover text
        hover_texts = []
        for name, loc in locs_of_type.items():
            text = f"<b>{name}</b><br>"
            text += f"Type: {loc['type']}<br>"
            text += f"Coordinates: ({loc['lat']:.4f}, {loc['lon']:.4f})<br>"
            if loc['techs']:
                tech_list = ', '.join(loc['techs'][:5])
                if len(loc['techs']) > 5:
                    tech_list += f" (+{len(loc['techs'])-5} more)"
                text += f"Technologies: {tech_list}"
            hover_texts.append(text)
        
        data.append(go.Scattergeo(
            lon=lons,
            lat=lats,
            mode='markers',
            marker=dict(
                size=SIZES[loc_type],
                color=COLORS[loc_type],
                line=dict(width=0.5, color='white'),
                opacity=0.8
            ),
            text=hover_texts,
            hoverinfo='text',
            name=LEGEND_NAMES[loc_type],
            showlegend=True
        ))
    
    # Layout configuration
    layout = go.Layout(
        title={
            'text': 'Chile Energy Network - Interactive Visualization',
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 24}
        },
        autosize=True,
        hovermode='closest',
        geo=dict(
            scope='south america',
            center=dict(lat=-33.4, lon=-70.6),
            projection_scale=4.5,
            showcountries=True,
            countrycolor="rgb(200, 200, 200)",
            showcoastlines=True,
            coastlinecolor="rgb(150, 150, 150)",
            showland=True,
            landcolor="rgb(250, 250, 250)",
            showocean=True,
            oceancolor="rgb(230, 245, 255)",
            showlakes=True,
            lakecolor="rgb(230, 245, 255)"
        ),
        height=900,
        legend=dict(
            x=0.02,
            y=0.98,
            bgcolor='rgba(255, 255, 255, 0.9)',
            bordercolor='black',
            borderwidth=1
        )
    )
    
    fig = go.Figure(data=data, layout=layout)
    
    # Save to file
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'graphs')
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, output_file)
    
    pyo.plot(fig, filename=output_path, auto_open=False)
    print(f"✓ Visualization saved: {output_path}")
    
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Visualize Chile energy network')
    parser.add_argument('--model-path', type=str, required=True,
                       help='Path to Calliope model directory')
    parser.add_argument('--output', type=str, default='network_graph.html',
                       help='Output HTML filename')
    parser.add_argument('--report-format', type=str, default='text',
                       choices=['text', 'markdown', 'html'],
                       help='Report output format')
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("CHILE ENERGY NETWORK VISUALIZATION")
    print("=" * 80)
    
    # Load data
    print("\n1. Loading network data...")
    locations = load_all_locations(args.model_path)
    connections = load_all_connections(args.model_path)
    
    print(f"   ✓ Loaded {len(locations)} locations")
    print(f"   ✓ Loaded {len(connections)} connections")
    
    # Build graph and analyze
    print("\n2. Analyzing network connectivity...")
    graph = build_network_graph(locations, connections)
    analysis = analyze_connectivity(graph, locations)
    
    print(f"   ✓ Network has {analysis['num_components']} component(s)")
    print(f"   ✓ Main component: {analysis['main_component_size']} nodes")
    
    if analysis['num_isolated'] > 0:
        print(f"   ⚠ Warning: {analysis['num_isolated']} isolated nodes")
    
    if len(analysis['demand_isolated']) > 0:
        print(f"   ⚠ Warning: {len(analysis['demand_isolated'])} isolated demand substations")
    
    # Create visualization
    print("\n3. Generating visualization...")
    viz_path = create_visualization(locations, connections, args.output)
    
    # Generate report
    print("\n4. Generating analysis report...")
    report = generate_report(locations, connections, analysis, args.report_format)
    
    ext_map = {'text': 'txt', 'markdown': 'md', 'html': 'html'}
    report_filename = f"network_analysis_report.{ext_map[args.report_format]}"
    report_path = save_report(report, report_filename)
    
    print(f"   ✓ Report saved: {report_path}")
    
    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"Total Locations: {len(locations)}")
    print(f"Total Connections: {len(connections)}")
    print(f"Network Components: {analysis['num_components']}")
    print(f"Isolated Demand Substations: {len(analysis['demand_isolated'])}")
    print("\nFiles generated:")
    print(f"  - Visualization: {viz_path}")
    print(f"  - Report: {report_path}")
    print("=" * 80)


if __name__ == '__main__':
    main()
