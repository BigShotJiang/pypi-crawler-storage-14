"""
Analyze Isolated Nodes

This script identifies and reports on isolated nodes and small disconnected
components in the network, with special focus on demand substations.

Usage:
    python analyze_isolated.py --model-path PATH_TO_MODEL
"""

import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.load_data import load_all_locations, load_all_connections
from utils.graph_builder import (build_network_graph, analyze_connectivity,
                                 get_component_info, identify_problematic_components)
from utils.geo_utils import suggest_connections_for_isolated


def main():
    parser = argparse.ArgumentParser(description='Analyze isolated nodes in network')
    parser.add_argument('--model-path', type=str, required=True,
                       help='Path to Calliope model directory')
    parser.add_argument('--min-component-size', type=int, default=2,
                       help='Minimum component size to report')
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("ISOLATED NODES ANALYSIS")
    print("=" * 80)
    
    # Load data
    print("\n1. Loading data...")
    locations = load_all_locations(args.model_path)
    connections = load_all_connections(args.model_path)
    print(f"   ✓ {len(locations)} locations, {len(connections)} connections")
    
    # Analyze
    print("\n2. Analyzing connectivity...")
    graph = build_network_graph(locations, connections)
    analysis = analyze_connectivity(graph, locations)
    
    # Detailed component analysis
    print("\n3. Component Details:")
    print("-" * 80)
    
    for i, component in enumerate(analysis['components'][:10], 1):
        info = get_component_info(component, locations)
        print(f"\n   Component {i}: {info['size']} nodes")
        print(f"     - Power Plants: {len(info['power_plants'])}")
        print(f"     - Demand Substations: {len(info['substations_with_demand'])}")
        print(f"     - Other Substations: {len(info['substations_no_demand'])}")
        print(f"     - Transmission Nodes: {len(info['nodos'])}")
        
        if i == 1:
            print("     [Main component]")
        elif len(info['substations_with_demand']) > 0:
            print(f"     ⚠️ HAS ISOLATED DEMAND:")
            for sub in info['substations_with_demand']:
                print(f"        - {sub}")
    
    # Problematic components
    print("\n4. Problematic Components:")
    print("-" * 80)
    
    problematic = identify_problematic_components(graph, locations, args.min_component_size)
    
    if not problematic:
        print("   ✓ No problematic components found")
    else:
        for prob in problematic:
            print(f"\n   Type: {prob['type']}")
            print(f"   Size: {prob['info']['size']} nodes")
            if prob['type'] == 'demand_without_generation':
                print("   ⚠️ CRITICAL: Demand without local generation")
                print(f"   Demand substations: {', '.join(prob['info']['substations_with_demand'])}")
    
    # Connection suggestions
    if len(analysis['demand_isolated']) > 0:
        print("\n5. Connection Suggestions:")
        print("-" * 80)
        
        suggestions = suggest_connections_for_isolated(
            list(analysis['demand_isolated']),
            locations,
            analysis['main_component'],
            max_suggestions=3
        )
        
        for isolated_node, nearest in suggestions.items():
            print(f"\n   {isolated_node}:")
            for target, distance in nearest:
                print(f"     → {target} ({distance:.1f} km)")
    
    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"Total Components: {analysis['num_components']}")
    print(f"Isolated Nodes: {analysis['num_isolated']}")
    print(f"Isolated Demand Substations: {len(analysis['demand_isolated'])}")
    
    if len(analysis['demand_isolated']) > 0:
        print("\n⚠️ ACTION REQUIRED:")
        print("Add transmission links to connect isolated demand substations")
        for node in sorted(analysis['demand_isolated']):
            print(f"  - {node}")
    
    print("=" * 80)


if __name__ == '__main__':
    main()
