"""
Data loading utilities for Calliope model configurations.
Universal parser that handles ANY naming structure and data format.
"""

import yaml
import os
from typing import Dict, List, Tuple


def _has_coordinate_data(data: Dict) -> bool:
    """Check if dictionary contains coordinate-like data."""
    if not isinstance(data, dict):
        return False
    coord_keys = ['lat', 'lon', 'latitude', 'longitude', 'x', 'y', 'coords', 'coordinates']
    return any(key in data for key in coord_keys)


def _extract_coordinates(coords: Dict) -> Tuple[float, float]:
    """
    Extract coordinates from any structure.
    Handles: lat/lon, latitude/longitude, x/y, or numeric pairs.
    """
    if not isinstance(coords, dict):
        return 0.0, 0.0
    
    # Try common coordinate key patterns
    lat = (coords.get('lat') or coords.get('latitude') or 
           coords.get('y') or coords.get('coord_lat') or 0)
    lon = (coords.get('lon') or coords.get('long') or coords.get('longitude') or 
           coords.get('x') or coords.get('coord_lon') or 0)
    
    # If coords has nested 'coordinates' key
    if 'coordinates' in coords:
        return _extract_coordinates(coords['coordinates'])
    
    return float(lat), float(lon)


def _classify_location_type(techs: List[str]) -> str:
    """
    Classify location type based on technologies.
    Flexible detection of generation and demand patterns.
    """
    if not techs:
        return 'nodo'  # Transmission node
    
    techs_lower = [str(t).lower() for t in techs]
    
    # Check for demand
    has_demand = any('demand' in tech for tech in techs_lower)
    
    # Check for generation (broad patterns)
    generation_patterns = ['ccgt', 'csp', 'battery', 'chp', 'boiler', 'pv', 'solar', 
                          'wind', 'hydro', 'nuclear', 'coal', 'gas', 'generation', 
                          'generator', 'plant', 'storage']
    has_generation = any(pattern in tech for tech in techs_lower for pattern in generation_patterns)
    
    # Check for transmission/supply
    transmission_patterns = ['transmission', 'supply', 'grid', 'ac_', 'dc_']
    has_transmission = any(pattern in tech for tech in techs_lower for pattern in transmission_patterns)
    
    # Classify
    if has_generation:
        return 'power'
    elif has_demand:
        return 'substation_with_demand'
    elif has_transmission:
        return 'substation'
    else:
        return 'substation'  # Default for nodes with techs


def load_all_locations(model_path: str) -> Dict:
    """
    Load all locations from Calliope model configuration files.
    Handles ANY naming structure and extracts data regardless of format.
    
    Supports:
    - Single-file (locations.yaml) and multi-file structures
    - Any naming pattern (with suffixes, prefixes, separators)
    - Split coordinates (e.g., "name.coordinates", "name:coords", etc.)
    - Shared techs (e.g., "loc1, loc2", "loc1|loc2", etc.)
    - Multiple coordinate systems (lat/lon, x/y, or any other keys)
    
    Args:
        model_path: Path to the Calliope model directory
        
    Returns:
        Dictionary with location names as keys and location data as values
    """
    locations = {}
    
    # Try single-file structure first (standard Calliope)
    single_file = os.path.join(model_path, 'model_config', 'locations.yaml')
    if os.path.exists(single_file):
        with open(single_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
            if data and 'locations' in data:
                # PHASE 1: Collect all coordinate definitions and shared techs
                coordinates_map = {}  # Maps base names to coordinates
                shared_techs_map = {}  # Maps location names to their shared techs
                standard_entries = {}  # Standard format entries
                
                for key, value in data['locations'].items():
                    if not value or not isinstance(value, dict):
                        continue
                    
                    # Detect if this is a coordinate-only entry (any suffix pattern)
                    # Look for patterns: "name.XXX", "name:XXX", "name_XXX" where XXX suggests coordinates
                    is_coord_entry = False
                    base_name = key
                    
                    for separator in ['.', ':', '_']:
                        if separator in key:
                            parts = key.split(separator)
                            suffix = parts[-1].lower()
                            # Check if suffix suggests coordinates
                            if any(coord_word in suffix for coord_word in ['coord', 'position', 'location', 'pos', 'latlon']):
                                is_coord_entry = True
                                base_name = separator.join(parts[:-1])
                                break
                    
                    # If no techs and has coordinate-like data, assume it's a coordinate entry
                    if not is_coord_entry and 'techs' not in value and _has_coordinate_data(value):
                        is_coord_entry = True
                    
                    if is_coord_entry:
                        # This is a coordinate definition
                        coordinates_map[base_name] = value
                    
                    # Detect shared tech assignments (comma-separated or other delimiters)
                    elif any(delimiter in key for delimiter in [',', '|', ';']):
                        # Extract location names from the key
                        for delimiter in [',', '|', ';']:
                            if delimiter in key:
                                location_names = [name.strip() for name in key.split(delimiter)]
                                techs = list(value.get('techs', {}).keys())
                                for name in location_names:
                                    if name not in shared_techs_map:
                                        shared_techs_map[name] = []
                                    shared_techs_map[name].extend(techs)
                                break
                    
                    # Standard entry
                    else:
                        standard_entries[key] = value
                
                # PHASE 2: Build complete location objects
                all_location_names = set(standard_entries.keys()) | set(coordinates_map.keys()) | set(shared_techs_map.keys())
                
                for loc_name in all_location_names:
                    # Gather all data for this location
                    loc_data = standard_entries.get(loc_name, {})
                    coords = loc_data.get('coordinates') or coordinates_map.get(loc_name, {})
                    techs = list(loc_data.get('techs', {}).keys())
                    
                    # Add shared techs
                    if loc_name in shared_techs_map:
                        techs.extend(shared_techs_map[loc_name])
                    techs = list(set(techs))  # Remove duplicates
                    
                    # Extract coordinates from any structure
                    if coords:
                        lat, lon = _extract_coordinates(coords)
                        
                        # Classify location type
                        loc_type = _classify_location_type(techs)
                        has_demand = any('demand' in str(tech).lower() for tech in techs)
                        
                        locations[loc_name] = {
                            'type': loc_type,
                            'lat': lat,
                            'lon': lon,
                            'techs': techs,
                            'has_demand': has_demand
                        }
        
        return locations
    
    # Fall back to multi-file structure (custom models)
    config_path = os.path.join(model_path, 'model_config', 'locations')
    
    # Load power plants
    power_file = os.path.join(config_path, 'locations_power.yaml')
    if os.path.exists(power_file):
        with open(power_file, 'r', encoding='utf-8') as f:
            power_data = yaml.safe_load(f)
            for loc_name, loc_data in power_data.get('locations', {}).items():
                if loc_data and 'coordinates' in loc_data:
                    coords = loc_data['coordinates']
                    techs = list(loc_data.get('techs', {}).keys())
                    locations[loc_name] = {
                        'type': 'power',
                        'lat': coords['lat'],
                        'lon': coords['lon'],
                        'techs': techs
                    }
    
    # Load substations
    substation_file = os.path.join(config_path, 'locations_substation.yaml')
    if os.path.exists(substation_file):
        with open(substation_file, 'r', encoding='utf-8') as f:
            substation_data = yaml.safe_load(f)
            for loc_name, loc_data in substation_data.get('locations', {}).items():
                if loc_data and 'coordinates' in loc_data:
                    coords = loc_data['coordinates']
                    techs = list(loc_data.get('techs', {}).keys())
                    has_demand = 'total_demand' in techs
                    locations[loc_name] = {
                        'type': 'substation_with_demand' if has_demand else 'substation',
                        'lat': coords['lat'],
                        'lon': coords['lon'],
                        'techs': techs,
                        'has_demand': has_demand
                    }
    
    # Load transmission nodes
    nodos_file = os.path.join(config_path, 'locations_nodos.yaml')
    if os.path.exists(nodos_file):
        with open(nodos_file, 'r', encoding='utf-8') as f:
            nodos_data = yaml.safe_load(f)
            for loc_name, loc_data in nodos_data.get('locations', {}).items():
                if loc_data and 'coordinates' in loc_data:
                    coords = loc_data['coordinates']
                    locations[loc_name] = {
                        'type': 'nodo',
                        'lat': coords['lat'],
                        'lon': coords['lon'],
                        'techs': []
                    }
    
    return locations


def load_all_connections(model_path: str) -> List[Dict]:
    """
    Load all connections (power_links and transmission_links) from model.
    Supports both single-file (locations.yaml) and multi-file structures.
    
    Args:
        model_path: Path to the Calliope model directory
        
    Returns:
        List of connection dictionaries
    """
    connections = []
    
    # Try single-file structure first (standard Calliope)
    single_file = os.path.join(model_path, 'model_config', 'locations.yaml')
    if os.path.exists(single_file):
        with open(single_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
            if data and 'links' in data:
                for link_name, link_data in data['links'].items():
                    if not link_data or not isinstance(link_data, dict):
                        continue
                    
                    if 'techs' in link_data:
                        parts = [p.strip() for p in link_name.split(',')]
                        if len(parts) == 2:
                            techs = list(link_data['techs'].keys())
                            
                            # Determine link type from tech names
                            link_type = 'transmission_link'
                            if any('power' in tech.lower() for tech in techs):
                                link_type = 'power_link'
                            
                            connections.append({
                                'from': parts[0],
                                'to': parts[1],
                                'type': link_type,
                                'techs': techs,
                                'name': link_name
                            })
        
        return connections
    
    # Fall back to multi-file structure (custom models)
    links_path = os.path.join(model_path, 'model_config', 'links')
    
    # Load power_links
    power_links_file = os.path.join(links_path, 'power_links.yaml')
    if os.path.exists(power_links_file):
        with open(power_links_file, 'r', encoding='utf-8') as f:
            power_links = yaml.safe_load(f)
            for link_name, link_data in power_links.get('links', {}).items():
                if link_data and 'techs' in link_data:
                    parts = link_name.split(',')
                    if len(parts) == 2:
                        techs = list(link_data.get('techs', {}).keys())
                        connections.append({
                            'from': parts[0],
                            'to': parts[1],
                            'type': 'power_link',
                            'techs': techs,
                            'name': link_name
                        })
    
    # Load transmission_links
    transmission_links_file = os.path.join(links_path, 'transmission_links.yaml')
    if os.path.exists(transmission_links_file):
        with open(transmission_links_file, 'r', encoding='utf-8') as f:
            transmission_links = yaml.safe_load(f)
            for link_name, link_data in transmission_links.get('links', {}).items():
                if link_data and 'techs' in link_data:
                    parts = link_name.split(',')
                    if len(parts) == 2:
                        techs = list(link_data['techs'].keys())
                        connections.append({
                            'from': parts[0],
                            'to': parts[1],
                            'type': 'transmission_link',
                            'techs': techs,
                            'name': link_name
                        })
    
    return connections


def get_location_counts(locations: Dict) -> Dict[str, int]:
    """
    Count locations by type.
    
    Args:
        locations: Dictionary of locations
        
    Returns:
        Dictionary with counts by type
    """
    counts = {
        'power': 0,
        'substation_with_demand': 0,
        'substation': 0,
        'nodo': 0
    }
    
    for loc_data in locations.values():
        loc_type = loc_data['type']
        if loc_type in counts:
            counts[loc_type] += 1
    
    return counts


def get_connection_counts(connections: List[Dict]) -> Dict[str, int]:
    """
    Count connections by type.
    
    Args:
        connections: List of connections
        
    Returns:
        Dictionary with counts by type
    """
    counts = {
        'power_link': 0,
        'transmission_link': 0
    }
    
    for conn in connections:
        conn_type = conn['type']
        if conn_type in counts:
            counts[conn_type] += 1
    
    return counts
