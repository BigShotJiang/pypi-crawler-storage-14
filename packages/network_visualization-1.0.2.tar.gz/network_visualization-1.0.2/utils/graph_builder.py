"""
Network graph building and connectivity analysis utilities.
"""

import networkx as nx
from typing import Dict, List, Tuple, Set


def build_network_graph(locations: Dict, connections: List[Dict]) -> nx.Graph:
    """
    Build a NetworkX graph from locations and connections.
    
    Args:
        locations: Dictionary of locations
        connections: List of connections
        
    Returns:
        NetworkX Graph object
    """
    G = nx.Graph()
    
    # Add all locations as nodes
    for loc_name in locations.keys():
        G.add_node(loc_name)
    
    # Add connections as edges
    for conn in connections:
        if conn['from'] in locations and conn['to'] in locations:
            G.add_edge(conn['from'], conn['to'], **conn)
    
    return G


def analyze_connectivity(graph: nx.Graph, locations: Dict) -> Dict:
    """
    Analyze connectivity of the network graph.
    
    Args:
        graph: NetworkX graph
        locations: Dictionary of locations
        
    Returns:
        Dictionary with connectivity analysis results
    """
    # Find connected components
    connected_components = list(nx.connected_components(graph))
    connected_components_sorted = sorted(connected_components, key=len, reverse=True)
    
    # Find isolated nodes
    isolated_nodes = list(nx.isolates(graph))
    
    # Analyze main component
    main_component = connected_components_sorted[0] if connected_components_sorted else set()
    main_component_size = len(main_component)
    
    # Find substations with demand
    substations_with_demand = {
        name for name, data in locations.items()
        if data.get('type') == 'substation_with_demand'
    }
    
    # Check which demand substations are in main component
    demand_in_main = main_component & substations_with_demand
    demand_isolated = substations_with_demand - main_component
    
    return {
        'total_nodes': graph.number_of_nodes(),
        'total_edges': graph.number_of_edges(),
        'num_components': len(connected_components),
        'components': connected_components_sorted,
        'main_component': main_component,
        'main_component_size': main_component_size,
        'isolated_nodes': isolated_nodes,
        'num_isolated': len(isolated_nodes),
        'substations_with_demand': substations_with_demand,
        'demand_in_main': demand_in_main,
        'demand_isolated': demand_isolated,
        'is_fully_connected': len(connected_components) == 1
    }


def find_isolated_demand_substations(graph: nx.Graph, locations: Dict) -> List[str]:
    """
    Find substations with demand that are isolated or in small components.
    
    Args:
        graph: NetworkX graph
        locations: Dictionary of locations
        
    Returns:
        List of isolated demand substation names
    """
    analysis = analyze_connectivity(graph, locations)
    return list(analysis['demand_isolated'])


def get_component_info(component: Set[str], locations: Dict) -> Dict:
    """
    Get detailed information about a component.
    
    Args:
        component: Set of node names in component
        locations: Dictionary of locations
        
    Returns:
        Dictionary with component information
    """
    info = {
        'size': len(component),
        'power_plants': [],
        'substations_with_demand': [],
        'substations_no_demand': [],
        'nodos': []
    }
    
    for node in component:
        if node in locations:
            loc_type = locations[node]['type']
            if loc_type == 'power':
                info['power_plants'].append(node)
            elif loc_type == 'substation_with_demand':
                info['substations_with_demand'].append(node)
            elif loc_type == 'substation':
                info['substations_no_demand'].append(node)
            elif loc_type == 'nodo':
                info['nodos'].append(node)
    
    info['has_generation'] = len(info['power_plants']) > 0
    info['has_demand'] = len(info['substations_with_demand']) > 0
    
    return info


def identify_problematic_components(graph: nx.Graph, locations: Dict, 
                                   min_size: int = 2) -> List[Dict]:
    """
    Identify components that have demand but no generation, or vice versa.
    
    Args:
        graph: NetworkX graph
        locations: Dictionary of locations
        min_size: Minimum component size to consider
        
    Returns:
        List of problematic components with details
    """
    analysis = analyze_connectivity(graph, locations)
    problematic = []
    
    for component in analysis['components']:
        if len(component) >= min_size:
            info = get_component_info(component, locations)
            
            # Check if component has demand but no generation
            if info['has_demand'] and not info['has_generation']:
                problematic.append({
                    'type': 'demand_without_generation',
                    'component': component,
                    'info': info
                })
            
            # Check if component has generation but no demand (less critical)
            elif info['has_generation'] and not info['has_demand']:
                problematic.append({
                    'type': 'generation_without_demand',
                    'component': component,
                    'info': info
                })
    
    return problematic
