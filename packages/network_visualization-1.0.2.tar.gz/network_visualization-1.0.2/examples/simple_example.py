"""
Simple example: Visualize your Calliope model

USAGE:
1. Install: pip install network-visualization
2. Edit MODEL_PATH below to point to your Calliope model
3. Run: python simple_example.py
"""

import network_visualization as nv

# ============================================================================
# EDIT THIS: Point to your Calliope model directory
# (The folder containing 'model_config' with locations.yaml)
# ============================================================================
MODEL_PATH = "C:/path/to/your/calliope/model"

# ============================================================================
# That's it! The code below will:
# - Load your model
# - Create an interactive visualization
# - Analyze connectivity
# - Save results
# ============================================================================

print("=" * 80)
print("NETWORK VISUALIZATION")
print("=" * 80)

# 1. Create interactive visualization
print("\n1. Creating visualization...")
output_file = nv.plot_network(
    model_path=MODEL_PATH,
    output_file="network_visualization.html",
    auto_open=True,  # Opens in browser automatically
    title="Energy Network"
)
print(f"   ✓ Saved to: {output_file}")

# 2. Analyze network
print("\n2. Analyzing network...")
analysis = nv.analyze_network(MODEL_PATH)

print(f"   ✓ Total locations: {analysis['total_nodes']}")
print(f"   ✓ Total connections: {analysis['total_edges']}")
print(f"   ✓ Network components: {analysis['num_components']}")
print(f"   ✓ Isolated nodes: {len(analysis['isolated_nodes'])}")

if analysis['isolated_nodes']:
    print(f"\n   ⚠ Warning: {len(analysis['isolated_nodes'])} isolated nodes found:")
    for node in analysis['isolated_nodes']:
        print(f"     - {node}")

# 3. Check for isolated demand
print("\n3. Checking demand substations...")
isolated = nv.find_isolated_nodes(MODEL_PATH)
if isolated['isolated_with_demand']:
    print(f"   ⚠ {len(isolated['isolated_with_demand'])} demand nodes are isolated:")
    for node in isolated['isolated_with_demand']:
        print(f"     - {node}")
else:
    print("   ✓ All demand nodes are connected")

print("\n" + "=" * 80)
print("DONE! Open 'network_visualization.html' to view your network")
print("=" * 80)
