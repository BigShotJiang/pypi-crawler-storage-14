# Changelog

All notable changes to this project will be documented in this file.

## [1.0.2] - 2025-11-25

### Improved
- **Clear Installation Instructions**: Step-by-step guide for new users
- **Copy-Paste Examples**: Ready-to-use code snippets
- **Troubleshooting Section**: Common issues and solutions
- **Simple Example Script**: simple_example.py for quick start
- **Better API Documentation**: Clear usage patterns with examples

### Added
- Real-world usage examples with path formatting
- Module structure requirements documentation
- Import error solutions

## [1.0.1] - 2025-11-25

### Added
- **Universal Data Extraction**: Handles ANY Calliope naming structure and format
- Flexible coordinate system support (lat/lon, x/y, custom)
- Smart pattern detection for split coordinates and shared technologies
- Automatic type classification for generation, demand, and transmission nodes

### Fixed
- Complete data extraction from complex Calliope models
- Parameter order in report generation
- Division by zero protection in calculations
- Type checking robustness

### Changed
- Refactored load_data.py with intelligent parsing algorithm
- Consolidated documentation into single README
- Cleaned up unnecessary test files

## [1.0.0] - 2025-10-21

### Added
- Initial release
- Interactive network visualization
- Connectivity analysis
- Basic Calliope support
- Simple Python API
