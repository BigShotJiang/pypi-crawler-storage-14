class EmptyCredentialsError(Exception):
    """ Raised when empty credentials are provided"""
    pass
