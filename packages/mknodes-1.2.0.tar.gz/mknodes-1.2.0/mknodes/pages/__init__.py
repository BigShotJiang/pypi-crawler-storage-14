"""Module containing MkPages and its subclasses."""
