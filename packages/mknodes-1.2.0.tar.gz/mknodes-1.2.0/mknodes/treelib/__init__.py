"""Tree style helpers."""

from __future__ import annotations
