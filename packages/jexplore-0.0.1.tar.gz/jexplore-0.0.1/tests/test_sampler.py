"""
Testing a full jaxsampler run
"""

import os
from glob import glob
from shutil import rmtree

import h5py
import jax
import jax.numpy as jnp
import numpy as np

import jexplore.tools.distributions as d
from jexplore.backends import DefaultBackend
from jexplore.sampler import JaxSampler, Steps
from jexplore.sampling import EpochMH, SamplingMH
from jexplore.steps import Stretch, TSwap

TEST_DIR = os.path.join(os.path.dirname(__file__), "test_sampler.d")


class TestJaxSampler:
    """Testing the JaxSampler class"""

    sampling: SamplingMH = SamplingMH(
        dim=2,
        nwalker=4,
        temps=jnp.arange(1, 10, 3),
        loglik=d.Normal(dim=2).leval,
        logprior=d.Uniform(dim=2, minval=-10, maxval=10).leval,
    )

    steps: Steps = Steps([{TSwap().builder: 1.0}, {Stretch().builder: 1.0}])

    backend: DefaultBackend = DefaultBackend(
        burn=1000, outdir=TEST_DIR, epochs_per_file=2
    )

    key: jax.Array = jax.random.key(42)

    fepoch: EpochMH

    def setup_class(self):
        """Executing sampler run"""

        if os.path.exists(TEST_DIR):
            rmtree(TEST_DIR)

        iepoch = EpochMH({"p": d.Normal(dim=2).sample(self.key, shape=(12,))[1]})

        sampler = JaxSampler(self.sampling, self.steps, self.backend)

        self.fepoch = sampler.run(iepoch, niters=2000, nepoch=2, seed=42)

    def test_run(self):
        """Check run results"""

        outfile = os.path.join(TEST_DIR, "epochs_1.h5")

        files = glob(os.path.join(TEST_DIR, "*.h5"))

        assert files == [outfile]

        epoch = h5py.File(outfile)

        assert list(epoch.keys()) == ["epoch_0", "epoch_1"]

        # pylint: disable=no-member
        assert epoch["epoch_0/samples/p"][()].shape == (12, 2, 1000)
        assert epoch["epoch_0/samples/ll"][()].shape == (12, 1, 1000)
        assert epoch["epoch_0/samples/lp"][()].shape == (12, 1, 1000)

        assert epoch["epoch_1/samples/p"][()].shape == (12, 2, 2000)
        assert epoch["epoch_1/samples/ll"][()].shape == (12, 1, 2000)
        assert epoch["epoch_1/samples/lp"][()].shape == (12, 1, 2000)

        assert np.all(epoch["epoch_1/samples/p"][()] == self.fepoch.samples.p)
        assert np.all(epoch["epoch_1/samples/ll"][()] == self.fepoch.samples.ll)
        assert np.all(epoch["epoch_1/samples/lp"][()] == self.fepoch.samples.lp)

        for _ind, _fact in enumerate([1, 4, 7]):
            samples = (
                epoch["epoch_0/samples/p"][_ind::3, :, :]
                .swapaxes(0, 1)
                .swapaxes(1, 2)
                .reshape(2, -1)
            )
            assert np.allclose(
                np.cov(samples), _fact * np.identity(2), atol=0.2 * _fact
            )

    def teardown_class(self):
        """
        Cleanup after execution
        """
        rmtree(TEST_DIR)
