# jexplore

## Installation

```
pip install .
```
