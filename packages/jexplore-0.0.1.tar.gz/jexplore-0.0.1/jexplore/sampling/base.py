"""
This module provides the definitions of the base
:py:attr:`jexplore.sampling.state.Sampling` class.
"""

from dataclasses import dataclass
from typing import Generic, TypeVar

from .space import Box, Space

Tspace = TypeVar("Tspace", bound=Space)
"""Placeholder for the target space class"""


@dataclass
class Sampling(Generic[Tspace]):
    """Markov sampling defining parameters.

    In this base class version the parameter are the dimension of the
    target space and the number of chains. Child classes may specialize
    to specific type of markov sampling (e.g.
    :py:attr:`jexplore.sampling.mh.SamplingMH`)

    :param dim: dimension of the target space.
    :param nchains: number of chains.

    the state will then be defined by a (nchain, dim) point"""

    dim: int
    """Dimension of the target space"""

    nchain: int
    """Number of chains"""

    space: Tspace | Box
    """Target space."""

    def __init__(
        self, nchain: int, dim: int | None = None, space: Tspace | None = None
    ):
        self.nchain = nchain

        if space is not None:
            self.space = space
            self.dim = self.space.dim

        elif dim is not None:
            self.dim = dim
            self.space = Box(dim=dim)

        else:
            raise ValueError(
                "You need at least to define the dimension of the chains space."
            )
