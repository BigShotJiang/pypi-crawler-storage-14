"""
This module define the class for a MH step based on Differential evolution
proposal.
"""

from typing import cast

import jax
import jax.numpy as jnp

from jexplore.sampling import EpochMH, State, StateMH
from jexplore.steps.colored import ColoredSC


class DEStep(ColoredSC):
    r"""Class implementing a Differential evolution step

    :param gamma: :math:`\gamma` scale parameter
    :param ngroups: number of groups. Default 2.
    :param permute: if true walkers are permuted at each iteration.
    """

    gamma: float
    r"""DE proposal :math:`\gamma` parameter"""

    sigma: jax.Array
    r"""gamma distribution :math:`\sigma = \frac{\gamma}{2\sqrt{D}}`"""

    def __init__(self, gamma: float = 2.38, ngroups: int = 3, permute: bool = False):
        if ngroups < 3:
            raise ValueError("DE requires at least 3 colors grouping.")

        super().__init__(ngroups, permute)
        self.gamma = gamma

    def build(self, epoch: EpochMH) -> None:
        r"""Step initialisation method. It extends
        :py:attr:`jexplore.steps.colored.Colored.build` by simply adding  the
        computation of the :math:`\sigma` of the :math:`\gamma` distribution.

        :param epoch: current epoch.
        """

        super().build(epoch)
        self.sigma = self.gamma / jnp.sqrt(epoch.sampling.dim) / 2

    def sample_gamma(self, key: jax.Array, size: int) -> jax.Array:
        r"""Sample :math:`\gamma` from normal distribution

        :param key: PRNG key
        :param size: output size

        :return: samples
        """
        return self.sigma * jax.random.normal(key, shape=(size,))

    # pylint: disable=unused-argument
    def proposal(
        self, key: jax.Array, state: StateMH, group: jax.Array, cgroup: jax.Array
    ) -> tuple[jax.Array, StateMH, jax.Array]:
        """Propose a new state according to the DE proposal algorithm.

        :param key: PRNG key
        :param state: current state

        :return: new state and the boolean mask of the chains modified by the step.
        """

        ntemps = self.sampling.temps.shape[0]

        key = jax.random.split(key, 3)

        shuffled = jax.random.permutation(
            key[0], cgroup.reshape(-1, ntemps), axis=0, independent=True
        )

        nwalk = group.shape[0] // ntemps

        # We assume ngroups >= 3, so shuffled has at least size 2 * nwalk
        _a = state.p[shuffled[:nwalk, :].flatten(), :]
        _b = state.p[shuffled[nwalk : 2 * nwalk, :].flatten(), :]
        _x = state.p[group, :] + self.sample_gamma(key[1], size=_a.shape[0])[
            :, None
        ] * (_b - _a)

        _prop = state.slice(group).update_mask(cast(StateMH, State(_x)), pars=["p"])

        return key[2], _prop, jnp.zeros(_x.shape[0])
