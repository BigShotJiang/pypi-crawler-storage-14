"""
This module define the class for a MH step based on stretch proposal.
"""

from typing import cast

import jax
import jax.numpy as jnp

from jexplore.sampling import State, StateMH
from jexplore.steps.colored import ColoredSC


class Stretch(ColoredSC):
    """Class implementing a MH steps based on stretch proposal

    :param a: stretch proposal `a` parameter
    :param ngroups: number of groups. Default 2.
    :param permute: if true walkers are permuted at each iteration.
    """

    a: float
    """stretch proposal `a` parameter"""

    def __init__(self, a: float = 2.0, ngroups: int = 2, permute: bool = False):
        super().__init__(ngroups, permute)
        self.sa = jnp.sqrt(a)

    def sample_z(self, key: jax.Array, size: int) -> jax.Array:
        """Sample the z distribution

        :param key: PRNG key
        :param size: output size

        :return: samples
        """
        u = jax.random.uniform(key, shape=(size,))
        z = (u * (self.sa - 1.0 / self.sa) + 1.0 / self.sa) ** 2
        return z

    # pylint: disable=unused-argument
    def proposal(
        self, key: jax.Array, state: StateMH, group: jax.Array, cgroup: jax.Array
    ) -> tuple[jax.Array, StateMH, jax.Array]:
        """Propose a new state according to the stretch proposal algorithm.

        :param key: PRNG key
        :param state: current state

        :return: new state and the boolean mask of the chains modified by the step.
        """

        ntemps = self.sampling.temps.shape[0]

        key = jax.random.split(key, 3)

        partners = jax.random.permutation(
            key[0], cgroup.reshape(-1, ntemps), axis=0, independent=True
        )[: group.shape[0] // ntemps, :].flatten()

        # Here is the actual stretch prosal
        _y = state.p[partners, :]
        _x = state.p[group, :]
        z = self.sample_z(key[1], size=_y.shape[0])
        _y = _y + z[:, None] * (_x - _y)

        _prop = state.slice(group).update_mask(cast(StateMH, State(_y)), pars=["p"])

        return key[2], _prop, (self.sampling.dim - 1) * jnp.log(z)
