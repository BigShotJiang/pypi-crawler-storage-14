"""
This modules defines the classes for Metropolis-Hastings
steps.
"""

import jax
import jax.numpy as jnp

from jexplore.sampling import EpochMH, SamplingMH, StateMH
from jexplore.steps.step import Step


class MHStep(Step[EpochMH, StateMH, SamplingMH]):
    """Base class for a single chain MH step. It specializes
    `build` method to define a suitable array of :math:`\beta_i = 1/T_i`.
    It also defines a generic MH acceptance step (the `mh` method).

    :param epoch: the current epoch.
    :param sampling: sampling parameters.
    """

    beta: jax.Array
    """Array of temperatures inverses for all chains. Shape is (nchains, 1)"""

    def build(self, epoch: EpochMH) -> None:
        """Step epoch initialisation method. Extend :py:attr:`jexplore.steps.step.Step.build`
        by populating the `betas` attribute.

        :param epoch: current epoch.
        """

        super().build(epoch)
        self.beta = 1.0 / jnp.tile(epoch.sampling.temps, epoch.sampling.nwalker)
        self.beta = self.beta.reshape(-1, 1)

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def mh(
        self,
        key: jax.Array,
        state: StateMH,
        prop: StateMH,
        betas: jax.Array,
        qxy: jax.Array,
    ) -> tuple[StateMH, jax.Array]:
        """Metropoling-Hastings acceptance step

        :param key: PRNG key
        :param state: current state
        :param prop: proposed state
        :param betas: (nchains, 1) betas array
        :param qxy: transition probabilities (nchains, 1)

        :return: new state with accepted changes and boolean mask of the changed chains.
        """
        _new: StateMH = (
            state.update_mask(prop, pars=["p"])
            .compute("ll", self.sampling.loglik, ["p"])
            .compute("lp", self.sampling.logprior, ["p"])
        )

        acc: jax.Array
        _, acc = self.get_accepted(
            key, betas * (_new.ll - state.ll) + _new.lp - state.lp + qxy.reshape(-1, 1)
        )

        acc = acc.reshape(state.ll.shape[0])
        return state.update_mask(_new, acc), acc

    def step(self, key: jax.Array, state: StateMH) -> tuple[StateMH, jax.Array]:
        """Step sampling method. This is just a prototype.

        :param key: PRNG key
        :param state: current state

        :return: new state and the boolean mask of the chains modified by the step.
        """
        raise NotImplementedError(
            "MHStep is an abstract class. Need to implement this method."
        )


class AllChains(MHStep):
    """Full parallel all chains MH step.

    :param epoch: the current epoch.
    :param sampling: sampling parameters.
    """

    def proposal(
        self, key: jax.Array, state: StateMH
    ) -> tuple[jax.Array, StateMH, jax.Array]:
        """All chain proposal. This is a prototype.

        :param key: PRNG key
        :param state: current state

        :return: the new PRNG key, the proposed state, the transition log probability.
        """
        raise NotImplementedError(
            "AllChains step is absract. You need to implement this method."
        )

    def step(self, key: jax.Array, state: StateMH) -> tuple[StateMH, jax.Array]:
        """Metropolis Hasting step sampling method. It proposes a new state
        calling the `proposal` method and then performs a MH acceptance calling
        :py:attr:`jexplore.steps.mh.MHState.mh` method.

        :param key: PRNG key
        :param state: current state

        :return: new state and the boolean mask of the chains modified by the step.
        """
        prop: StateMH
        qxy: jax.Array

        key, prop, qxy = self.proposal(key, state)
        return self.mh(key, state, prop, self.beta, qxy)
