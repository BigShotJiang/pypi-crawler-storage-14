"""
Ths module defines the default version of a Jexplore
backend for storing data in memory and on disk.
"""

import logging
import os
from types import EllipsisType
from typing import Generic, TypeVar, cast

import h5py  # type: ignore
import numpy as np

from jexplore.sampling import Epoch

Tepoch = TypeVar("Tepoch", bound=Epoch)
"""placeholder for epoch class"""

DEFAULTBKND_CONFIG = {
    "outdir": "./",
    "outfile_fmt": "epochs_%d.h5",
    "epochs_per_file": 1,
    "inmem_epochs": 0,
    "save_stats": True,
}
"""Default backend config parameters"""

logger = logging.getLogger(__name__)
"""logger instance"""

# TODO: recreate from a dumped backend (dump the registry if needed)


class DefaultBackend(Generic[Tepoch]):
    r"""Default backend dumping samples on disk per epoch.

    :param burn: number of samples to burn (these will not be registered by the
                 backend)
    :param \**config: backend configuration options.
    """

    burn: int
    """burned samples"""

    _config: dict
    _registry: list[dict]
    _epochs: list[dict | None]

    def __init__(self, burn: int = 0, **config: dict):
        self._config = DEFAULTBKND_CONFIG | config
        self.burn = burn
        self._registry = []
        self._epochs = []

    def ingest(self, epoch: Tepoch) -> None:
        """loads and store one epoch in the backend.
        :param epoch: the epoch to be loaded."""

        _nsamples, _burn, _epoch = epoch.to_backend(
            burn=self._get_nsamples()[1], stats=self._config["save_stats"]
        )
        _ind = len(self._registry)
        self._epochs.append(_epoch if _nsamples > 0 else None)
        self._registry.append(
            {
                "index": _ind,
                "name": f"epoch_{_ind}",
                "location": 0 if _nsamples > 0 else -1,
                "nsamples": _nsamples,
                "burn": _burn,
            }
        )
        self.update()

    def _get_nsamples(self) -> tuple[int, int]:
        """return number of samples that still have to be burn"""
        _burn = self.burn
        _nsamples = 0
        for _epoch in self._registry:
            _burn -= _epoch["burn"]
            _nsamples += _epoch["nsamples"]

        return _nsamples, _burn

    def set_burn(self, burn: int) -> None:
        """Sets the number of samples to be burned and removes stored
        samples if necessary.

        :param burn: number of burned samples
        """
        if self.burn > burn:
            raise ValueError(
                "Burned samples are burned. You can only augment burn value."
            )
        self.burn = burn
        self.update()

    def update(self) -> None:
        """This implements the storing logic of this backend. It parses
        the registry of the ingested epochs and implements storing policies
        according to the configuration paremeters."""
        (
            _inmem,
            _file,
        ) = self._check_registry()

        _burn = self.burn
        for _ind, _entry in enumerate(self._registry):
            logging.debug(
                "Processing epoch %s: %s. Left to burn: %s.", _ind, _entry, _burn
            )
            if _entry["location"] == -1:
                _burn -= _entry["burn"]
                logger.debug(
                    "Epoch %s already burned: %s. Left to burn: %s.",
                    _ind,
                    _entry,
                    _burn,
                )
                continue

            _burn -= _entry["burn"]

            if _burn > 0:
                if _burn >= _entry["nsamples"]:
                    _burn -= _entry["nsamples"]
                    self._burn_epoch(_ind)
                    logger.debug(
                        "Epoch %s burned: %s. Left to burn: %s.", _ind, _entry, _burn
                    )
                    continue

                _entry["nsamples"] -= _burn
                self._cut_to_size(_ind, _entry["nsamples"])
                _entry["burn"] += _burn
                _burn = 0
                logger.debug(
                    "Epoch %s cut to size: %s. Left to burn: %s.", _ind, _entry, _burn
                )

        # At this point we may have 1 (and only 1) inmem epoch
        # to put on disk. The last one.
        logger.debug("Pre-dump status: %s", self._registry)

        if (self._registry[-1]["location"] != 0) or (
            _inmem <= self._config["inmem_epochs"]
        ):
            logger.debug("No need to dump on file.")
            return

        _iepoch = len(self._registry) - _inmem
        logger.debug("Dumping on file %s epoch %s", _file, _iepoch)
        self._dump_to_file(_file, _iepoch)

    def _check_registry(self) -> tuple[int, int]:
        _find = 1
        _inmem = 0
        _fcount = 0
        for _entry in self._registry:
            if _entry["location"] == -1:
                continue

            if _entry["location"] == 0:
                _inmem += 1
                continue

            if _find != _entry["location"]:
                _find = _entry["location"]
                _fcount = 1
                continue

            _fcount += 1

        if _fcount == self._config["epochs_per_file"]:
            _find += 1

        return _inmem, _find

    def _get_fname(self, fnum: int) -> str:
        return os.path.join(self._config["outdir"], self._config["outfile_fmt"] % fnum)

    def _burn_epoch(self, ind: int) -> None:

        _epoch = self._registry[ind]

        if _epoch["location"] == 0:
            self._epochs[ind] = None

        else:
            _fname = self._get_fname(_epoch["location"])

            with h5py.File(_fname, "a") as _fhand:
                del _fhand[_epoch["name"]]

                _left = len(_fhand.keys())
            if _left == 0:
                os.remove(_fname)

        _epoch["location"] = -1
        _epoch["burn"] += _epoch["nsamples"]
        _epoch["nsamples"] = 0

    def _cut_to_size(self, ind: int, nsamples: int) -> None:
        if self._registry[ind]["location"] == 0:
            self._cut_to_size_inmem(ind, nsamples)

        else:
            self._cut_to_size_h5(ind, nsamples)

    def _cut_to_size_inmem(self, ind: int, nsamples: int) -> None:
        def _cutter(_par, _pkey):
            if isinstance(_par[_pkey], dict):
                for _key in _par[_pkey]:
                    _cutter(_par[_pkey], _key)
                return

            _par[_pkey] = _par[_pkey][:, :, -nsamples:]
            return

        _cutter(self._epochs[ind], "samples")

    def _cut_to_size_h5(self, ind: int, nsamples: int) -> None:
        epoch = self._registry[ind]

        fname = self._get_fname(epoch["location"])

        fhand = h5py.File(fname, "a")

        def _cutter(_path):
            if isinstance(fhand[_path], h5py.Dataset):
                _dat = cast(h5py.Dataset, fhand[_path])[...][:, :, -nsamples:]
                del fhand[_path]
                fhand.create_dataset(_path, data=_dat, dtype=_dat.dtype)
                return

            for _key in cast(h5py.Group, fhand[_path]).keys():
                _cutter(_path + "/" + _key)

        _cutter(epoch["name"] + "/samples")
        fhand.close()

    def _dump_to_file(self, find: int, iepoch: int) -> None:

        epoch = self._registry[iepoch]

        fname = self._get_fname(find)

        os.makedirs(self._config["outdir"], exist_ok=True)

        fhand = h5py.File(fname, "a")

        def _writer(_obj, _path):
            if isinstance(_obj, dict):
                for _key, _val in _obj.items():
                    _writer(_val, _path + "/" + _key)
                return

            fhand.create_dataset(_path, data=_obj, dtype=_obj.dtype)

        _writer(self._epochs[iepoch], epoch["name"])
        fhand.close()

        self._epochs[iepoch] = None
        epoch["location"] = find

    @staticmethod
    def _add_samples(
        samples: dict[str, np.ndarray] | None, add: dict[str, np.ndarray]
    ) -> dict[str, np.ndarray]:
        if samples is None:
            return add

        for _key in samples:
            samples[_key] = np.concatenate([samples[_key], add[_key]], axis=2)

        return samples

    def _get_samples_inmem(
        self, slc: slice, pars: list[str], eind: int, mask: np.ndarray | EllipsisType
    ) -> dict[str, np.ndarray]:
        """Get the samples inmem"""

        return {
            _par: cast(dict, self._epochs[eind])["samples"][_par][mask, :, slc]
            for _par in pars
        }

    def _get_samples_file(
        self, slc: slice, pars: list[str], eind: int, mask: np.ndarray | EllipsisType
    ) -> dict[str, np.ndarray]:
        """Get the samples from"""

        _fname = self._get_fname(self._registry[eind]["location"])
        _ename = f"epoch_{eind}"
        with h5py.File(_fname) as _file:
            _samples = {
                _par: _file[f"{_ename}/samples/{_par}"][mask, :, slc] for _par in pars
            }

        return _samples

    def get_samples(
        self,
        burn: int = 0,
        thin: int = 1,
        pars: list[str] | None = None,
        mask: np.ndarray | EllipsisType = Ellipsis,
    ) -> dict[str, np.ndarray] | None:
        """Get the samples from the backend.

        :param burn: number of initial samples to discart. This is added
                     on top of the backend instance `burn` parameter.
        :param thin: thinning factor.
        :param pars: list of names of the sample parameters to be returned.
                     Default: only "p".
        :param mask: mask (boolean mask or list of index) for the chains to be
                     retrieved.

        :return: a dictionnary which keys are the parameters names and values
                 the returned chains. None if no samples could be retrieved.
        """

        pars = ["p"] if pars is None else pars
        _samples = None

        for _eind, _entry in enumerate(self._registry):
            if _entry["location"] == -1:
                continue

            if _entry["nsamples"] <= burn:
                burn -= _entry["nsamples"]
                continue

            if _entry["location"] == 0:

                _samples = self._add_samples(
                    _samples,
                    self._get_samples_inmem(slice(burn, None, thin), pars, _eind, mask),
                )

            else:
                _samples = self._add_samples(
                    _samples,
                    self._get_samples_file(slice(burn, None, thin), pars, _eind, mask),
                )

            burn = 0

        return _samples
