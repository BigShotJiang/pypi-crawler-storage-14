"""
Distributions
=============

Classes for sampling and evaluating some relevant distributions.
"""

from typing import Protocol

import jax
import jax.numpy as jnp


class Distr(Protocol):
    """
    Abstract parent distribution class.

    :param int dim: space dimension
    """

    dim: int

    def __init__(self, dim: int):
        self.dim = dim

    def sample(self, key: jax.Array, shape: tuple) -> tuple[jax.Array, jax.Array]:
        """
        Samples the distribution.

        :param ArrayLike key: PRNG key used as the random key.
        :param tuple shape: shape of the sample.

        :return: the actualized PRNG key and the samples with shape shape + (py:attr:`dim`,)
        :rtype: tuple
        """
        # pylint: disable=unnecessary-ellipsis
        ...

    def eval(self, x: jax.Array) -> jax.Array:
        """
        Evaluates the distribution on a set of points

        :param array x: points array, with shape (..., py:attr:`dim`)

        :return: the values of the distribution on the given points
        :rtype: Array
        """
        return jnp.exp(self.leval(x))

    def leval(self, x: jax.Array) -> jax.Array:
        """
        Evaluates the distribution on a set of points

        :param array x: points array, with shape (..., py:attr:`dim`)

        :return: the values of the distribution on the given points
        :rtype: Array
        """
        # pylint: disable=unnecessary-ellipsis
        ...


class Uniform(Distr):
    """
    Constant distribution in a box:

    :param int dim: space dimension
    :param RealArray minval: minimum (inclusive) value broadcast-compatible with
                             shape for the range (default 0).
    :param RealArray maxval: maximum (exclusive) value broadcast-compatible with
                             shape for the range (default 1).
    """

    minval: jax.Array
    maxval: jax.Array
    lvol: jax.Array

    def __init__(
        self, dim: int, minval: jax.Array | float = 0.0, maxval: jax.Array | float = 1.0
    ):
        super().__init__(dim)
        self.minval = jnp.array(minval) * jnp.ones(dim)
        self.maxval = jnp.array(maxval) * jnp.ones(dim)
        self.lvol = jnp.sum(jnp.log(self.maxval - self.minval))

    def sample(self, key: jax.Array, shape: tuple) -> tuple[jax.Array, jax.Array]:
        key, k_x = jax.random.split(key)
        return key, jax.random.uniform(
            k_x, shape=shape + (self.dim,), minval=self.minval, maxval=self.maxval
        )

    def leval(self, x: jax.Array) -> jax.Array:
        return -self.lvol


class Normal(Distr):
    """
    Normal distribution with identity covariance.

    :param int dim: space dimension
    """

    norm: float

    def __init__(self, dim: int):
        super().__init__(dim)
        self.lnorm = (self.dim / 2) * jnp.log(2 * jnp.pi)

    def sample(self, key: jax.Array, shape: tuple) -> tuple[jax.Array, jax.Array]:
        key, k_x = jax.random.split(key)
        return key, jax.random.normal(k_x, shape=shape + (self.dim,))

    def leval(self, x: jax.Array) -> jax.Array:
        return -self.lnorm - 0.5 * jnp.sum(x**2, axis=-1)


class StudentT(Distr):
    r"""
    Multivarate student-t with identity covariance.

    :param int dim: space dimension
    :param float nu: student-t :math:`\nu` parameter
    """

    nu: float = 5.0

    def __init__(self, dim: int, nu: float = 5.0):
        super().__init__(dim)
        self.normal = Normal(dim)
        self.nu = nu

    def sample(self, key: jax.Array, shape: tuple) -> tuple[jax.Array, jax.Array]:
        key, _z = self.normal.sample(key, shape)
        key, _gkey = jax.random.split(key)
        _g = jax.random.gamma(_gkey, a=self.nu / 2.0, shape=shape + (1,))
        _g *= 2.0 / self.nu
        return key, _z / jnp.sqrt(_g)

    def eval(self, x: jax.Array) -> jax.Array:
        return x
