# This file is required for Django to recognize 'tests' as an app with models.
# Models are defined inline in test files.
