"""Defines the version of the txt2tex package."""

__version__ = "1.0.2"
