from omibio.io.read_fasta import read
from omibio.io.write_fasta import write_fasta

__all__ = [
    "read",
    "write_fasta"
]
