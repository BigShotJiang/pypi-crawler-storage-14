.. _settings_api:

Settings
========

.. currentmodule:: festim

.. autoclass:: Settings
    :members:
    :show-inheritance: