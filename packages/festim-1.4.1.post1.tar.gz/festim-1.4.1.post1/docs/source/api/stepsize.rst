Stepsize
========

.. currentmodule:: festim

.. autoclass:: Stepsize
    :members:
    :show-inheritance: