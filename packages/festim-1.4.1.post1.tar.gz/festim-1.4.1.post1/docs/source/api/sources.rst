.. _sources_api:

Sources
=======

.. currentmodule:: festim

.. autoclass:: Source
    :members:
    :show-inheritance:

.. autoclass:: ImplantationFlux
    :members:
    :show-inheritance:

.. autoclass:: RadioactiveDecay
    :members:
    :show-inheritance:
