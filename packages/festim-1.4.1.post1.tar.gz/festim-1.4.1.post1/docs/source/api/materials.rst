.. _materials_api:

Materials
=========

.. currentmodule:: festim

.. autoclass:: Material
    :members:
    :show-inheritance:

.. autoclass:: Materials
    :members:
    :show-inheritance: