===================
Running in parallel
===================

FESTIM can be run in parallel on N cores using the command: 

.. code::
    
    mpirun -np N python3 your_FESTIM_script.py