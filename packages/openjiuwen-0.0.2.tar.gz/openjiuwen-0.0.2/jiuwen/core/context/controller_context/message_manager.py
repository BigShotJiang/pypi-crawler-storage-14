class MessageMgr:
    pass
