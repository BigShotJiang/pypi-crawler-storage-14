﻿from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as fh:
    long_description = fh.read()

setup(
    name='reversible-unlearning',
    version='0.1.2.1',  # NEW: Patch version
    author='AUREON Labs',
    author_email='research@aureon.ai',
    description='Universal reversible unlearning with loss maximization',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/aureon-labs/reversible',
    packages=['reversible'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
    install_requires=['torch>=1.9.0', 'numpy>=1.19.0'],
)
