# Coreform Cubit Mesh Export

A Python library for exporting mesh files from Coreform Cubit to various formats.

## Installation

### Install from PyPI (Recommended)
```bash
pip install --upgrade coreform-cubit-mesh-export
```

### Install into Cubit's Python Environment
To use within Cubit's journal scripts (`play "script.py"`) for Gmsh/VTK/Nastran export:

**Windows:**
```bash
"C:\Program Files\Coreform Cubit 2025.3\bin\python3\python.exe" -m pip install coreform-cubit-mesh-export
```

**Linux/Mac:**
```bash
/path/to/cubit/bin/python3/python -m pip install coreform-cubit-mesh-export
```

### Install for Netgen/NGSolve Integration
For `export_Netgen()` with high-order curving, install into your own Python environment (not Cubit's bundled Python):

```bash
# Install with ngsolve dependency
pip install coreform-cubit-mesh-export[netgen]

# Or install separately
pip install coreform-cubit-mesh-export ngsolve
```

Then add Cubit's bin path to your script:
```python
import sys
sys.path.append("C:/Program Files/Coreform Cubit 2025.3/bin")
import cubit
```

### Install Development Version from GitHub
```bash
pip install git+https://github.com/ksugahar/Coreform_Cubit_Mesh_Export.git
```

## Supported File Formats

- **Netgen** ⭐ NEW
  - Direct mesh conversion (no intermediate files)
  - High-order curving via `mesh.Curve()` (order 2, 3, 4, 5, ...)
  - All element types: Tet, Hex, Wedge, Pyramid
- **Gmsh Format**
  - Version 4.1 (with $Entities section, 2D/3D auto-detect)
  - Version 2.2 (full support, 2nd-order elements)
- **Nastran Format**
  - 2D meshes
  - 3D meshes
- **MEG Format** (for ELF)
  - 2D meshes
  - 3D meshes
- **VTK Format**
  - Legacy VTK (.vtk) - auto-detect element order
  - VTK XML (.vtu) - modern format with binary support

## Usage

### Netgen (High-Order Curving)

```python
import cubit
import cubit_mesh_export
import ngsolve

# Create mesh in Cubit
cubit.cmd("create sphere radius 1")
cubit.cmd("volume 1 scheme tetmesh")
cubit.cmd("mesh volume 1")
cubit.cmd("block 1 add tet all in volume 1")
cubit.cmd("block 1 name 'domain'")
cubit.cmd("block 2 add tri all in surface all")
cubit.cmd("block 2 name 'boundary'")

# Export geometry for Curve() support
cubit.cmd('export step "geometry.step" overwrite')

# Convert to NGSolve mesh with high-order curving
ngmesh = cubit_mesh_export.export_Netgen(cubit, geometry_file="geometry.step")
mesh = ngsolve.Mesh(ngmesh)
mesh.Curve(3)  # 3rd order curved elements

# Use in FEM analysis
print(mesh.GetMaterials())   # ('domain',)
print(mesh.GetBoundaries())  # ('boundary',)
```

See [docs/export_Netgen.md](docs/export_Netgen.md) for detailed documentation.

### Usage within Cubit

After generating a mesh in Cubit, execute a Python script as follows:

```python
# Cubit command line
play "export_mesh.py"
```

Example content of `export_mesh.py`:

```python
import cubit_mesh_export

# Export to Nastran format (3D)
FileName = 'output/model.nas'
cubit_mesh_export.export_Nastran(cubit, FileName, DIM="3D")

# Export to Gmsh format (v2.2, supports 2nd-order elements)
FileName = 'output/model.msh'
cubit_mesh_export.export_Gmsh_ver2(cubit, FileName)

# Export to VTK format (auto-detects element order)
FileName = 'output/model.vtk'
cubit_mesh_export.export_vtk(cubit, FileName)
```

## Function Reference

### Netgen Format
- `export_Netgen(cubit, geometry_file=None)` - Export to `netgen.meshing.Mesh` object
  - Returns mesh ready for `ngsolve.Mesh()` conversion
  - With `geometry_file`: enables `mesh.Curve(order)` for high-order elements
  - Supports: Tet, Hex, Wedge, Pyramid, Tri, Quad

### Gmsh Format
- `export_Gmsh_ver4(cubit, filename, DIM="auto")` - Export to Gmsh v4.1 format with $Entities section, DIM: "auto"/"2D"/"3D"
- `export_Gmsh_ver2(cubit, filename)` - Export 3D mesh to Gmsh v2.2 format with 2nd-order element support

### Nastran Format
- `export_Nastran(cubit, filename, DIM="2D|3D", PYRAM=True|False)` - Export 2D/3D mesh to Nastran format, convert pyramids to hex, supports 1st-order elements only

### MEG Format (for ELF)
- `export_meg(cubit, filename, DIM="T|R|K", MGR2=[])` - T: 3D, R: axisymmetric, K: 2D, MGR2 specifies spatial nodes

### VTK Format
- `export_vtk(cubit, filename)` - Export to Legacy VTK format, auto-detects element order (1st/2nd) based on node count
- `export_vtu(cubit, filename, binary=False)` - Export to VTK XML format (.vtu), supports binary mode for efficiency

## High-Order Element Support

| Format | 1st Order | 2nd Order | 3rd+ Order |
|--------|-----------|-----------|------------|
| NGSolve | ✅ | ✅ (via Curve) | ✅ (via Curve) |
| Gmsh v4.1 | ✅ | ✅ | ❌ |
| Gmsh v2.2 | ✅ | ✅ | ❌ |
| VTK/VTU | ✅ | ✅ | ❌ |
| Nastran | ✅ | ❌ | ❌ |

**Note**: NGSolve's `mesh.Curve(order)` generates high-order nodes from geometry, enabling arbitrary order curved elements from a 1st-order Cubit mesh.

## Block Registration

This module uses **blocks only** for mesh export (not nodesets or sidesets).

**Why?** In Cubit, only blocks support element order control via `block X element type tetra10`. Nodesets and sidesets lack this capability. By standardizing on blocks, we ensure consistent 2nd order element support across all export formats.

**Boundary conditions** can still be defined using separate blocks:
```
block 1 add tet all in volume 1    # Domain
block 1 name "domain"
block 2 add tri all in surface 1   # Boundary
block 2 name "boundary"
block 1 element type tetra10       # Convert to 2nd order
```

**Important**: Register mesh elements, not geometry:
```
# Correct
block 1 add tet all

# Incorrect (2nd order not supported)
block 1 add volume 1
```

A warning will be displayed if geometry is detected in blocks.

## Requirements

- Coreform Cubit 2024.3 or later (provides Python environment and `cubit` module)
- NGSolve/Netgen (optional, for `export_NetgenMesh()` function)

## License

LGPL-2.1 (GNU Lesser General Public License version 2.1)

## Author

Kengo Sugahara (ksugahar@kindai.ac.jp)

## Repository

- GitHub: [https://github.com/ksugahar/Coreform_Cubit_Mesh_Export](https://github.com/ksugahar/Coreform_Cubit_Mesh_Export)
- PyPI: [https://pypi.org/project/coreform-cubit-mesh-export/](https://pypi.org/project/coreform-cubit-mesh-export/)

## Bug Reports & Feature Requests

Please submit via [GitHub Issues](https://github.com/ksugahar/Coreform_Cubit_Mesh_Export/issues).
