"""
Ported to delayed_image
"""
from delayed_image.lazy_loaders import LazyGDalFrameFile
from delayed_image.lazy_loaders import LazyRasterIOFrameFile
from delayed_image.lazy_loaders import LazySpectralFrameFile
