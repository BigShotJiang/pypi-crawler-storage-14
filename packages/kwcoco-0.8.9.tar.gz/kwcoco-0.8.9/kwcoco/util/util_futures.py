"""
Deprecated and functionality moved to ubelt
"""
from ubelt import Executor, JobPool
__all__ = ['Executor', 'JobPool']

# def __getattr__(self, key):
#     # TODO: DEPRECATE WARNING
