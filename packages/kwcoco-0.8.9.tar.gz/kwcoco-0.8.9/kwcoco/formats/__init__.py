"""
This subpackage contains readers and writers for other common dataset formats
to help with conversion.
"""
