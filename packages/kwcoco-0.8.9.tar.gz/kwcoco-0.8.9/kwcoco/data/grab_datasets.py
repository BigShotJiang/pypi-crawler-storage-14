"""
TODO:
    - [ ] UCF101 - Action Recognition Data Set - https://www.crcv.ucf.edu/data/UCF101.php
    - [ ] HMDB: a large human motion database - https://serre-lab.clps.brown.edu/resource/hmdb-a-large-human-motion-database/
    - [ ] https://paperswithcode.com/dataset/imagenet
    - [ ] https://paperswithcode.com/dataset/coco
    - [ ] https://paperswithcode.com/dataset/fashion-mnist
    - [ ] https://paperswithcode.com/dataset/visual-question-answering
    - [ ] https://paperswithcode.com/dataset/lfw
    - [ ] https://paperswithcode.com/dataset/lsun
    - [ ] https://paperswithcode.com/dataset/ava
    - [ ] https://paperswithcode.com/dataset/activitynet
    - [ ] https://paperswithcode.com/dataset/clevr
"""
