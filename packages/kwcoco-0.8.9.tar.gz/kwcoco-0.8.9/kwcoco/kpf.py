import ubelt as ub
ub.schedule_deprecation(
    'kwcoco', 'kwcoco.kpf', 'module', 'use kwcoco.formats.kpf instead',
    deprecate='0.8.4', error='0.9.0', remove='0.10.0')
