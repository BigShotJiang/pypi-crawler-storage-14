def test_import():
    import kwcoco