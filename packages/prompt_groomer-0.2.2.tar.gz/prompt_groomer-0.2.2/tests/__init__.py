"""Tests for prompt-groomer."""
