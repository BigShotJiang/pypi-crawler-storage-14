from tg_tools import mcp
# import .tg_resources  # Ensure resources are registered

def main():
    """Main entry point for the MCP server."""
    mcp.run()

# If running directly, launch the MCP app
if __name__ == "__main__":
    main()
