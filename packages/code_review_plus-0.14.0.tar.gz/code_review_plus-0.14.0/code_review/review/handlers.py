import logging
from datetime import datetime
from pathlib import Path

from code_review.enums import ReviewRuleLevelIcon
from code_review.review.schemas import CodeReviewSchema
from code_review.settings import CLI_CONSOLE

logger = logging.getLogger(__name__)


def display_review(review: CodeReviewSchema, base_branch_name: str = "develop") -> None:
    """Display the details of a code review.

    Args:
        review: Review schema to display.
        base_branch_name: base branch name for comparison.
    """
    CLI_CONSOLE.print(f"[bold blue]Code Review for Project:[/bold blue] {review.name} by {review.target_branch.author}")
    CLI_CONSOLE.print(f"[bold blue]Branch: {review.target_branch.name}[/bold blue]")
    if review.is_rebased:
        CLI_CONSOLE.print(
            f"[bold green]{ReviewRuleLevelIcon.INFO.value} Branch {review.target_branch.name} is rebased on {base_branch_name}.[/bold green]"
        )
    else:
        CLI_CONSOLE.print(
            f"[bold red]{ReviewRuleLevelIcon.ERROR.value} Branch {review.target_branch.name} is not rebased on {base_branch_name}![/bold red]"
        )
    # Linting comparison
    if review.target_branch.linting_errors > review.base_branch.linting_errors:
        CLI_CONSOLE.print(
            f"[bold red]{ReviewRuleLevelIcon.ERROR.value} Linting Issues Increased![/bold red] base has "
            f"{review.base_branch.linting_errors} while {review.target_branch.name} "
            f"has {review.target_branch.linting_errors}"
        )
    elif (
        review.target_branch.linting_errors == review.base_branch.linting_errors
        and review.target_branch.linting_errors != 0
    ):
        CLI_CONSOLE.print(
            f"[bold yellow]{ReviewRuleLevelIcon.WARNING.value} Linting Issues Stayed the Same![/bold yellow] base has "
            f"{review.base_branch.linting_errors} while {review.target_branch.name} "
            f"has {review.target_branch.linting_errors}"
        )
    else:
        CLI_CONSOLE.print(
            f"[bold green]{ReviewRuleLevelIcon.INFO.value} Linting Issues Decreased or Stayed the Same.[/bold green] base has "
            f"{review.base_branch.linting_errors} while {review.target_branch.name} "
            f"has {review.target_branch.linting_errors}"
        )
    logger.debug("Review Details: %s", review.target_branch.changelog_versions)
    logger.debug("Review version: %s", review.target_branch.version)
    print("-" * 80)
    # Rules validated
    CLI_CONSOLE.print("[bold blue]>>> Rules Validated <<<[/bold blue]")

    filtered_rules = [rule for rule in review.rules_validated if not rule.passed or rule.level == "WARNING"]
    if filtered_rules:
        for rule in filtered_rules:
            if rule.passed:
                CLI_CONSOLE.print(
                    f"[bold green]{ReviewRuleLevelIcon.INFO.value} Rule Passed: {rule.name} {rule.message}[/bold green]"
                )
            elif rule.level == "WARNING":
                CLI_CONSOLE.print(
                    f"[bold yellow]{ReviewRuleLevelIcon.WARNING.value} Rule Warning: {rule.name} {rule.message}[/bold yellow]"
                )
            else:
                CLI_CONSOLE.print(
                    f"[bold red]{ReviewRuleLevelIcon.ERROR.value} Rule Failed: {rule.name} {rule.message}[/bold red]"
                )

    print("-" * 80)
    if len(review.target_branch.changelog_versions) == 0 or review.target_branch.version is None:
        logger.error("Skipping version check due to missing information")
        return

    changelog_latest_version = review.target_branch.changelog_versions[0]
    logger.debug("Latest changelog version: %s", changelog_latest_version)
    if review.target_branch.version < changelog_latest_version:
        CLI_CONSOLE.print(
            f"[bold green]{ReviewRuleLevelIcon.INFO.value} Versioning is correct expected to move from {review.target_branch.version} "
            f"to {changelog_latest_version}![/bold green] "
        )
    else:
        CLI_CONSOLE.print(
            f"[bold red]{ReviewRuleLevelIcon.ERROR.value} Versioning is not correct expected to move from {review.target_branch.version} "
            f"to {changelog_latest_version}![/bold red] "
        )


def get_dated_folder_for_code_reviews(folder: Path) -> Path:
    """Gets or creates a dated folder for code reviews.

    Args:
        folder: Root folder where the code_reviews folder will be created.

    Returns:
        Path: Path where the dated folder will be created.
    """
    dated_folder = folder / "code_reviews" / datetime.now().strftime("%Y-%m-%d")
    dated_folder.mkdir(parents=True, exist_ok=True)
    return dated_folder
