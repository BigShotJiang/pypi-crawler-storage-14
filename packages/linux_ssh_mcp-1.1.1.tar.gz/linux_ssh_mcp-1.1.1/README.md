# Linux SSH MCP (Model Context Protocol) v1.1.0

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyPI version](https://img.shields.io/pypi/v/linux-ssh-mcp.svg)](https://pypi.org/project/linux-ssh-mcp/)

一个强大的Linux服务器管理系统，通过Model Context Protocol (MCP)提供AI助手集成，支持动态服务器管理、批量操作和高性能SSH连接管理。

## 🚀 核心功能

- **🤖 AI助手集成**: 通过MCP协议与Claude、Cursor等AI助手无缝集成
- **🔧 动态服务器管理**: 运行时添加、更新、删除服务器，无需重启服务
- **🔍 智能版本检查**: 详细的系统和版本信息报告
- **🛡️ 智能去重机制**: 服务器冲突检测和用户确认覆盖
- **⚡ 连接池优化**: 高性能SSH连接复用和管理
- **📦 批量操作**: 支持多服务器并发命令执行
- **🔄 实时监控**: 连接状态、性能指标全面监控
- **🔒 安全设计**: 密码掩码、安全凭证管理
- **📊 配置导入导出**: 灵活的服务器配置管理

## 🆕 v1.1.0 新功能

### 🔍 版本检查系统
- **`get_mcp_version` 工具**: 获取完整的版本和系统信息
- **统一版本管理**: 消除版本不一致问题
- **系统监控**: CPU、内存、磁盘使用情况报告
- **运行时状态**: 进程信息、配置状态等

### 🛡️ 智能服务器去重
- **多维度检测**: ID和主机+端口重复检测
- **用户确认**: 详细的配置对比和覆盖确认
- **智能警告**: 冲突识别和建议
- **批量处理**: 支持覆盖和跳过模式

## 📋 系统要求

- Python 3.8+

## 🛠️ 快速开始

### 🤖 AI助手集成 (推荐)

#### 安装
```bash
# 从PyPI安装
pip install linux-ssh-mcp

# Claude Code配置
claude mcp add linux-ssh-mcp python -m linux_ssh_mcp.cli
```

#### 服务器配置
创建 `~/.ssh-mcp/config.json`:
```json
{
  "servers": [
    {
      "id": "server-01",
      "host": "192.168.1.100",
      "port": 22,
      "username": "root",
      "password": "your_password"
    }
  ]
}
```

#### AI助手命令示例
- "列出所有可管理的服务器"
- "在server-01上执行 'uptime' 命令"
- "批量检查所有服务器的磁盘使用情况"
- "添加新服务器 prod-db 192.168.1.200"
- "获取当前MCP服务器版本信息"
- "检查服务器配置冲突"

### 🖥️ 命令行工具

#### 服务器管理
```bash
# 添加服务器
python -m linux_ssh_mcp.cli server add web01 192.168.1.100 --username root

# 列出服务器
python -m linux_ssh_mcp.cli server list

# 测试连接
python -m linux_ssh_mcp.cli server test web01
```

#### 命令执行
```bash
# 执行命令
python -m linux_ssh_mcp.cli exec web01 "uptime"

# 批量执行
python -m linux_ssh_mcp.cli batch --servers web01 web02 "uptime"

# 全部服务器执行
python -m linux_ssh_mcp.cli batch --all "df -h"
```

## 📚 文档与示例

### 配置与使用
- **[动态服务器管理](DYNAMIC_SERVER_MANAGEMENT.md)** - 运行时服务器管理功能
- **[MCP安装指南](MCP_INSTALLATION.md)** - Model Context Protocol配置
- [基本使用示例](examples/basic_usage.py) - 入门示例
- [批量操作示例](examples/batch_operations.py) - 高级批处理

### 技术架构
- **SSH连接管理**: 高性能连接池，支持并发操作
- **动态配置**: 运行时添加/删除服务器，无需重启
- **MCP协议集成**: 与Claude、Cursor等AI助手无缝集成
- **性能监控**: 实时连接状态和命令执行统计

## ⚙️ 高级配置

### Python API使用
```python
from linux_ssh_mcp import SSHManager, ServerConfig

# 创建管理器
ssh_manager = SSHManager(use_pooling=True)

# 添加服务器
config = ServerConfig(
    id="web-server-01",
    host="192.168.1.100",
    port=22,
    username="admin",
    password="password",
    timeout=30
)
ssh_manager.add_server(config)

# 执行命令
result = await ssh_manager.execute_command("web-server-01", "uptime")
print(f"输出: {result.stdout}")
```

### MCP集成示例
```json
{
  "name": "add_server_runtime",
  "arguments": {
    "name": "prod-server",
    "host": "192.168.1.100",
    "username": "admin",
    "password": "secure_password",
    "persistent": true
  }
}
```

## 🔒 安全特性

- **多种认证方式**: 密码、SSH密钥、API密钥
- **连接安全**: SSL/TLS加密，密码掩码显示
- **访问控制**: IP白名单，速率限制
- **审计日志**: 完整的操作记录和追踪

## 🚀 性能特点

- **连接管理**: <100ms建立连接(池化)，<500ms(新建)
- **命令执行**: 简单命令平均<1秒
- **批量操作**: 支持并发执行，线性扩展
- **资源占用**: 基础~50MB，每连接~1MB
- **并发能力**: 单实例支持1000+并发连接

## 🧪 测试

```bash
# 运行测试
python -m pytest tests/

# 基本功能测试
python examples/basic_usage.py

# 批量操作测试
python examples/batch_operations.py
```

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 🆘 支持

- **文档**: [API文档](docs/API_DOCUMENTATION.md), [配置指南](docs/CONFIGURATION.md)
- **问题反馈**: GitHub Issues
- **讨论**: GitHub Discussions

---

**Built with ❤️ for the Linux SSH management community**