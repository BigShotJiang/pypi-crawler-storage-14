"""Version information for linux_ssh_mcp package."""

__version__ = "1.1.1"
__author__ = "SSH MCP Development Team"
__license__ = "MIT"