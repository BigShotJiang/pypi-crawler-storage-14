#!/usr/bin/env python3
"""
Linux SSH MCP Server - Model Context Protocol Server
"""

import asyncio
import json
import sys
import logging
import os
import platform
import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence

# Try to import psutil for system resource monitoring, but make it optional
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.types import (
    Resource, Tool, TextContent, ImageContent, EmbeddedResource,
    LoggingLevel, CallToolRequest, ListToolsRequest
)

from .ssh_manager import SSHManager, ServerConfig
from .auth import AuthManager, UserRole
from . import __version__


# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global SSH Manager - use absolute path for config file
def get_config_file_path():
    """Get absolute path to servers.json"""
    # Try to find servers.json in the project directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(os.path.dirname(current_dir))  # Go up to project root
    config_path = os.path.join(project_dir, "servers.json")

    # If not found in project root, try current working directory
    if not os.path.exists(config_path):
        config_path = os.path.join(os.getcwd(), "servers.json")

    logger.info(f"Using config file: {config_path}")
    return config_path

ssh_manager = SSHManager(config_file=get_config_file_path())


class LinuxSSHMCP:
    """Linux SSH MCP Server"""

    def __init__(self):
        self.server = Server("linux-ssh-mcp")
        self.setup_handlers()

    def setup_handlers(self):
        """Setup MCP server handlers"""

        @self.server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            """List available tools"""
            return [
                Tool(
                    name="list_servers",
                    description="List all configured SSH servers",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    }
                ),
                Tool(
                    name="execute_command",
                    description="Execute a command on a remote SSH server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID"
                            },
                            "command": {
                                "type": "string",
                                "description": "Command to execute"
                            },
                            "timeout": {
                                "type": "number",
                                "description": "Command timeout in seconds (optional)"
                            }
                        },
                        "required": ["server", "command"]
                    }
                ),
                Tool(
                    name="add_server",
                    description="Add a new SSH server configuration",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "description": "Server name/ID"},
                            "host": {"type": "string", "description": "Server hostname or IP"},
                            "port": {"type": "number", "description": "SSH port (default: 22)"},
                            "username": {"type": "string", "description": "SSH username"},
                            "password": {"type": "string", "description": "SSH password (optional)"},
                            "timeout": {"type": "number", "description": "Connection timeout (default: 30)"},
                            "confirm_overwrite": {"type": "boolean", "description": "Whether to confirm before overwriting existing servers (default: true)"}
                        },
                        "required": ["name", "host", "username"]
                    }
                ),
                Tool(
                    name="test_connection",
                    description="Test SSH connection to a server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID"
                            }
                        },
                        "required": ["server"]
                    }
                ),
                Tool(
                    name="get_server_status",
                    description="Get status information for servers",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID (optional, if not provided returns all servers)"
                            }
                        }
                    }
                ),
                Tool(
                    name="remove_server",
                    description="Remove a server configuration",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID"
                            }
                        },
                        "required": ["server"]
                    }
                ),
                Tool(
                    name="update_server",
                    description="Update an existing server configuration",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {"type": "string", "description": "Server name/ID"},
                            "host": {"type": "string", "description": "Server hostname or IP (optional)"},
                            "port": {"type": "number", "description": "SSH port (optional)"},
                            "username": {"type": "string", "description": "SSH username (optional)"},
                            "password": {"type": "string", "description": "SSH password (optional)"},
                            "timeout": {"type": "number", "description": "Connection timeout (optional)"}
                        },
                        "required": ["server"]
                    }
                ),
                Tool(
                    name="import_servers",
                    description="Import multiple servers from a dictionary or file",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "servers": {
                                "type": "object",
                                "description": "Dictionary of server configurations",
                                "patternProperties": {
                                    ".*": {
                                        "type": "object",
                                        "properties": {
                                            "host": {"type": "string"},
                                            "port": {"type": "number"},
                                            "username": {"type": "string"},
                                            "password": {"type": "string"},
                                            "timeout": {"type": "number"}
                                        },
                                        "required": ["host", "username"]
                                    }
                                }
                            },
                            "file_path": {
                                "type": "string",
                                "description": "Path to JSON file containing server configurations"
                            },
                            "overwrite": {
                                "type": "boolean",
                                "description": "Overwrite existing servers (default: false)"
                            }
                        },
                        "oneOf": [
                            {"required": ["servers"]},
                            {"required": ["file_path"]}
                        ]
                    }
                ),
                Tool(
                    name="export_servers",
                    description="Export server configurations",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Path to save the exported configuration (optional)"
                            },
                            "include_passwords": {
                                "type": "boolean",
                                "description": "Include passwords in export (default: false)"
                            }
                        }
                    }
                ),
                Tool(
                    name="add_server_runtime",
                    description="Add a server at runtime with optional persistence",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "description": "Server name/ID"},
                            "host": {"type": "string", "description": "Server hostname or IP"},
                            "port": {"type": "number", "description": "SSH port (default: 22)"},
                            "username": {"type": "string", "description": "SSH username"},
                            "password": {"type": "string", "description": "SSH password (optional)"},
                            "timeout": {"type": "number", "description": "Connection timeout (default: 30)"},
                            "persistent": {"type": "boolean", "description": "Persist to config file (default: true)"}
                        },
                        "required": ["name", "host", "username"]
                    }
                ),
                Tool(
                    name="batch_execute",
                    description="Execute command on multiple servers",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "servers": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "List of server names/IDs (optional, if not provided executes on all servers)"
                            },
                            "command": {"type": "string", "description": "Command to execute"},
                            "timeout": {"type": "number", "description": "Command timeout in seconds (optional)"}
                        },
                        "required": ["command"]
                    }
                ),
                Tool(
                    name="get_performance_metrics",
                    description="Get system performance metrics and statistics",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    }
                ),
                Tool(
                    name="get_mcp_version",
                    description="Get MCP server version information and system status",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    }
                )
            ]

        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            """Handle tool calls"""
            try:
                if name == "list_servers":
                    servers = ssh_manager.list_servers()
                    result = []
                    for server_id in servers:
                        config = ssh_manager.get_server_config(server_id)
                        if config:
                            result.append({
                                "id": server_id,
                                "host": config.host,
                                "port": config.port,
                                "username": config.username
                            })

                    return [TextContent(
                        type="text",
                        text=json.dumps(result, indent=2)
                    )]

                elif name == "execute_command":
                    server = arguments.get("server")
                    command = arguments.get("command")
                    timeout = arguments.get("timeout")

                    if not server or not command:
                        return [TextContent(
                            type="text",
                            text="Error: server and command are required"
                        )]

                    result = await ssh_manager.execute_command(server, command, timeout)

                    response = {
                        "success": result.success,
                        "stdout": result.stdout,
                        "stderr": result.stderr,
                        "exit_code": result.exit_code,
                        "execution_time": result.execution_time,
                        "command": result.command
                    }

                    return [TextContent(
                        type="text",
                        text=json.dumps(response, indent=2)
                    )]

                elif name == "add_server":
                    name_arg = arguments.get("name")
                    host = arguments.get("host")
                    port = arguments.get("port", 22)
                    username = arguments.get("username")
                    password = arguments.get("password")
                    timeout = arguments.get("timeout", 30)
                    confirm_overwrite = arguments.get("confirm_overwrite", True)

                    if not all([name_arg, host, username]):
                        return [TextContent(
                            type="text",
                            text="Error: name, host, and username are required"
                        )]

                    config = ServerConfig(
                        id=name_arg,
                        host=host,
                        port=port,
                        username=username,
                        password=password,
                        timeout=timeout
                    )

                    try:
                        success = ssh_manager.add_server(config, confirm_overwrite=confirm_overwrite)

                        if not success:
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "success": False,
                                    "error": "Failed to add server (operation cancelled or validation failed)"
                                }, indent=2)
                            )]

                        # Test connection
                        connection_test = await ssh_manager.test_connection(name_arg)

                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": True,
                                "message": f"Server '{name_arg}' added successfully",
                                "connection_test": connection_test
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "test_connection":
                    server = arguments.get("server")
                    if not server:
                        return [TextContent(
                            type="text",
                            text="Error: server name is required"
                        )]

                    try:
                        is_connected = await ssh_manager.test_connection(server)
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "server": server,
                                "connected": is_connected,
                                "message": "Connection successful" if is_connected else "Connection failed"
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "server": server,
                                "connected": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "get_server_status":
                    server = arguments.get("server")

                    if server:
                        # Get specific server status
                        config = ssh_manager.get_server_config(server)
                        if not config:
                            return [TextContent(
                                type="text",
                                text=json.dumps({"error": f"Server '{server}' not found"}, indent=2)
                            )]

                        try:
                            status = await ssh_manager.get_server_status(server)
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "server": server,
                                    "host": config.host,
                                    "port": config.port,
                                    "username": config.username,
                                    "status": status.value
                                }, indent=2)
                            )]
                        except Exception as e:
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "server": server,
                                    "status": "error",
                                    "error": str(e)
                                }, indent=2)
                            )]
                    else:
                        # Get all servers status
                        servers = ssh_manager.list_servers()
                        result = []
                        for server_id in servers:
                            config = ssh_manager.get_server_config(server_id)
                            if config:
                                try:
                                    status = await ssh_manager.get_server_status(server_id)
                                    result.append({
                                        "server": server_id,
                                        "host": config.host,
                                        "port": config.port,
                                        "username": config.username,
                                        "status": status.value
                                    })
                                except Exception as e:
                                    result.append({
                                        "server": server_id,
                                        "host": config.host,
                                        "port": config.port,
                                        "username": config.username,
                                        "status": "error",
                                        "error": str(e)
                                    })

                        return [TextContent(
                            type="text",
                            text=json.dumps(result, indent=2)
                        )]

                elif name == "remove_server":
                    server = arguments.get("server")
                    if not server:
                        return [TextContent(
                            type="text",
                            text="Error: server name is required"
                        )]

                    try:
                        success = ssh_manager.remove_server(server)
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": success,
                                "message": f"Server '{server}' removed successfully" if success else f"Server '{server}' not found"
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "update_server":
                    server = arguments.get("server")
                    if not server:
                        return [TextContent(
                            type="text",
                            text="Error: server name is required"
                        )]

                    try:
                        # Extract updateable parameters
                        update_params = {}
                        for param in ["host", "port", "username", "password", "timeout"]:
                            if param in arguments:
                                update_params[param] = arguments[param]

                        success = ssh_manager.update_server_config(server, **update_params)
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": success,
                                "message": f"Server '{server}' updated successfully" if success else f"Server '{server}' not found",
                                "updated_params": update_params
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "import_servers":
                    servers = arguments.get("servers")
                    file_path = arguments.get("file_path")
                    overwrite = arguments.get("overwrite", False)

                    try:
                        if file_path:
                            # Import from file
                            count = ssh_manager.load_servers_from_file(file_path, overwrite)
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "success": True,
                                    "imported_count": count,
                                    "file_path": file_path
                                }, indent=2)
                            )]
                        elif servers:
                            # Import from dictionary
                            count = ssh_manager.import_servers_from_dict(servers, overwrite)
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "success": True,
                                    "imported_count": count,
                                    "overwrite": overwrite
                                }, indent=2)
                            )]
                        else:
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "success": False,
                                    "error": "Either 'servers' or 'file_path' must be provided"
                                }, indent=2)
                            )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "export_servers":
                    file_path = arguments.get("file_path")
                    include_passwords = arguments.get("include_passwords", False)

                    try:
                        if file_path:
                            # Export to file
                            success = ssh_manager.save_servers_to_file(file_path, include_passwords)
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "success": success,
                                    "file_path": file_path,
                                    "include_passwords": include_passwords
                                }, indent=2)
                            )]
                        else:
                            # Export as JSON response
                            data = ssh_manager.export_servers_to_dict()
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "success": True,
                                    "servers": data,
                                    "count": len(data)
                                }, indent=2)
                            )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "add_server_runtime":
                    name_arg = arguments.get("name")
                    host = arguments.get("host")
                    port = arguments.get("port", 22)
                    username = arguments.get("username")
                    password = arguments.get("password")
                    timeout = arguments.get("timeout", 30)
                    persistent = arguments.get("persistent", True)

                    if not all([name_arg, host, username]):
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": "name, host, and username are required"
                            })
                        )]

                    try:
                        success = ssh_manager.add_server_runtime(
                            name_arg, host, port, username, password, timeout, None, persistent
                        )

                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": success,
                                "message": f"Server '{name_arg}' added successfully",
                                "persistent": persistent
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "batch_execute":
                    command = arguments.get("command")
                    servers = arguments.get("servers")
                    timeout = arguments.get("timeout")

                    if not command:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": "command is required"
                            })
                        )]

                    try:
                        if not servers:
                            servers = ssh_manager.list_servers()

                        if not servers:
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "success": False,
                                    "error": "No servers available"
                                })
                            )]

                        # Execute command on all specified servers concurrently
                        results = []
                        for server in servers:
                            try:
                                result = await ssh_manager.execute_command(server, command, timeout)
                                results.append({
                                    "server": server,
                                    "success": result.success,
                                    "stdout": result.stdout,
                                    "stderr": result.stderr,
                                    "exit_code": result.exit_code,
                                    "execution_time": result.execution_time
                                })
                            except Exception as e:
                                results.append({
                                    "server": server,
                                    "success": False,
                                    "error": str(e)
                                })

                        success_count = sum(1 for r in results if r.get("success", False))

                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": success_count > 0,
                                "total_servers": len(servers),
                                "successful_executions": success_count,
                                "failed_executions": len(servers) - success_count,
                                "results": results
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "get_performance_metrics":
                    try:
                        metrics = ssh_manager.get_performance_metrics()
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": True,
                                "metrics": metrics,
                                "timestamp": asyncio.get_event_loop().time()
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "get_mcp_version":
                    try:
                        # Import version info
                        from . import __version__
                        from .__version__ import __author__, __license__

                        # Basic system info
                        server_count = len(ssh_manager.servers)
                        config_file_path = ssh_manager.get_config_file_path()

                        # Build response
                        version_info = {
                            "package_info": {
                                "version": __version__,
                                "author": __author__,
                                "license": __license__,
                                "server_name": "Linux SSH MCP Server",
                                "mcp_protocol_version": "2024-11-05"
                            },
                            "system_info": {
                                "python_version": sys.version,
                                "python_executable": sys.executable,
                                "platform": platform.platform(),
                                "architecture": platform.architecture(),
                                "processor": platform.processor(),
                                "hostname": platform.node()
                            },
                            "runtime_status": {
                                "current_time": datetime.now().isoformat(),
                                "process_id": os.getpid(),
                                "config_file_path": config_file_path
                            },
                            "server_status": {
                                "total_servers": server_count,
                                "config_file_exists": os.path.exists(config_file_path)
                            },
                            "supported_features": [
                                "server_management",
                                "command_execution",
                                "batch_operations",
                                "connection_testing",
                                "runtime_server_addition",
                                "configuration_import_export",
                                "performance_monitoring"
                            ],
                            "available_tools": [
                                "list_servers",
                                "add_server",
                                "remove_server",
                                "update_server",
                                "execute_command",
                                "test_connection",
                                "get_server_status",
                                "get_performance_metrics",
                                "import_servers",
                                "export_servers",
                                "batch_execute",
                                "add_server_runtime",
                                "get_mcp_version"
                            ]
                        }

                        # Add system resources if psutil is available
                        if PSUTIL_AVAILABLE:
                            try:
                                memory = psutil.virtual_memory()
                                disk = psutil.disk_usage('/')

                                version_info["system_resources"] = {
                                    "cpu_count": psutil.cpu_count(),
                                    "memory": {
                                        "total_gb": round(memory.total / (1024**3), 2),
                                        "available_gb": round(memory.available / (1024**3), 2),
                                        "usage_percent": memory.percent
                                    },
                                    "disk": {
                                        "total_gb": round(disk.total / (1024**3), 2),
                                        "free_gb": round(disk.free / (1024**3), 2),
                                        "usage_percent": round((disk.used / disk.total) * 100, 2)
                                    }
                                }
                            except Exception as e:
                                version_info["system_resources"] = {
                                    "error": f"Failed to get system resources: {str(e)}"
                                }
                        else:
                            version_info["system_resources"] = {
                                "note": "Install psutil package for detailed system resource monitoring"
                            }

                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": True,
                                "version_info": version_info,
                                "timestamp": asyncio.get_event_loop().time()
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                else:
                    return [TextContent(
                        type="text",
                        text=f"Unknown tool: {name}"
                    )]

            except Exception as e:
                logger.error(f"Error in tool {name}: {e}")
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": str(e)}, indent=2)
                )]

    async def run(self):
        """Run the MCP server"""
        # Setup stdin/stdout communication using the current MCP API
        from mcp.server.stdio import stdio_server

        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="linux-ssh-mcp",
                    server_version=__version__,
                    capabilities=self.server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={}
                    )
                )
            )


async def main():
    """Main entry point"""
    try:
        logger.info("Starting Linux SSH MCP Server")
        mcp_server = LinuxSSHMCP()
        await mcp_server.run()
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}")
        sys.exit(1)


def main_sync():
    """Synchronous entry point"""
    asyncio.run(main())


if __name__ == "__main__":
    main_sync()