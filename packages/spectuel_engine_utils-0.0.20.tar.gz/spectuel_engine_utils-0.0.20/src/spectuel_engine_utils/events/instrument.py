from typing import Literal
from uuid import UUID

from spectuel_engine_utils.events.base import EngineEventBase
from .enums import InstrumentEventType


class NewInstrumentEvent(EngineEventBase):
    type: Literal[InstrumentEventType.NEW_INSTRUMENT] = (
        InstrumentEventType.NEW_INSTRUMENT
    )
    version: int = 1
    instrument_id: UUID
