"""CLI module for idealista-scraper."""
from idealista_scraper.cli.app import app, main
from idealista_scraper.cli.config import PropertyType, RegionSelection, ScraperConfig
from idealista_scraper.cli.interactive import InteractiveWizard
from idealista_scraper.cli.presets import (
    delete_preset,
    list_presets,
    load_preset,
    save_preset,
)

__all__ = [
    "app",
    "main",
    "ScraperConfig",
    "RegionSelection",
    "PropertyType",
    "InteractiveWizard",
    "save_preset",
    "load_preset",
    "list_presets",
    "delete_preset",
]
