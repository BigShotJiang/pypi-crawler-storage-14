"""
Parsing module for HTML content extraction.

This module provides HTML parsing utilities for extracting
property data from Idealista listings.
"""

from .html_parser import HTMLParser, clean_html_content

__all__ = ["HTMLParser", "clean_html_content"]
