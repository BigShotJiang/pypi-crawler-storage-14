"""
Upload module for idealistaScraper.

This module handles uploading scraped images to cloud storage services.
Currently supports S3 with streaming uploads and resume capabilities.
"""

from .s3 import S3ImageUploader

__all__ = ["S3ImageUploader"]
