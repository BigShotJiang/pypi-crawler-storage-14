"""Entry point for running as module: python -m idealista_scraper."""
from idealista_scraper.cli.app import main

if __name__ == "__main__":
    main()
