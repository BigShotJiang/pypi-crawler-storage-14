# LinkBay-Templates

**Version**: 0.1.0  
**License**: Proprietary  
**Python**: 3.8+

Protocol-based, database-agnostic, multi-format template management and rendering system for multi-tenant SaaS.

---

## Overview

LinkBay-Templates provides complete template management with support for multiple formats (email HTML/text, PDF, SMS, push notifications), Jinja2 rendering, versioning, branding integration, and multi-language support.

**Key Features:**
- Multi-format templates (email, PDF, SMS, push, print)
- Jinja2 rendering engine (extensible to Handlebars, Liquid)
- Template versioning & rollback
- Branding integration (auto-inject logos, colors)
- Multi-language support with fallback
- Preview & testing before deployment
- PDF generation from HTML
- Email sending integration
- Starter templates (order confirmation, invoice, etc.)
- Import/export & cloning

---

## Installation

```bash
pip install linkbay-templates
```

With optional dependencies:

```bash
# Jinja2 rendering
pip install linkbay-templates[jinja2]

# FastAPI router
pip install linkbay-templates[fastapi]

# PDF generation (WeasyPrint)
pip install linkbay-templates[pdf]

# All dependencies
pip install linkbay-templates[all]
```

---

## Quick Start

See EXAMPLES.md for 15+ comprehensive usage examples covering:
- Creating email templates (HTML + text)
- Rendering with variables and branding
- Preview with sample data
- Sending test emails
- Generating PDF invoices
- Multi-language templates
- Version management & rollback
- Template cloning
- Starter template installation

---

## Architecture

**Protocol-based**: Zero coupling to databases. User implements storage protocols.

**Multi-tenant**: All operations require `tenant_id` for strict isolation.

**Flexible Engines**: Support for Jinja2 (built-in), extensible for Handlebars, Liquid.

**Core Components:**
- **Protocols**: `TemplateStorage`, `TemplateRenderer`, `TemplateVersionProvider`, `PDFRenderer`, `EmailSender`
- **Services**: `TemplateService`, `RenderService`, `EmailService`, `PDFService`
- **Engines**: `Jinja2Renderer` (built-in)
- **Schemas**: 15+ Pydantic models
- **Router**: FastAPI with 15 endpoints (optional)

---

## License

Proprietary - Copyright (c) 2025 Alessio Quagliara
