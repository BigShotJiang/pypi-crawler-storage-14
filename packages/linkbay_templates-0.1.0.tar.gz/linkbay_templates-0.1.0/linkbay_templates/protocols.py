"""Protocol definitions for template management."""

from typing import Protocol, Dict, Any, List, Optional
from datetime import datetime


class TemplateStorage(Protocol):
    """
    Protocol for template persistence.
    
    User implements with their database (PostgreSQL, MongoDB, etc.).
    """
    
    async def create_template(
        self,
        template_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create new template."""
        ...
    
    async def get_template(
        self,
        template_id: str,
        tenant_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get template by ID."""
        ...
    
    async def get_template_by_slug(
        self,
        slug: str,
        tenant_id: str,
        language: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Get template by slug and language."""
        ...
    
    async def update_template(
        self,
        template_id: str,
        tenant_id: str,
        update_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update template."""
        ...
    
    async def delete_template(
        self,
        template_id: str,
        tenant_id: str,
    ) -> bool:
        """Delete template."""
        ...
    
    async def list_templates(
        self,
        tenant_id: str,
        category: Optional[str] = None,
        format: Optional[str] = None,
        language: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> List[Dict[str, Any]]:
        """List templates with filters."""
        ...
    
    async def get_base_template(
        self,
        tenant_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get base/layout template for tenant."""
        ...


class TemplateRenderer(Protocol):
    """
    Protocol for template rendering.
    
    Implements specific template engine (Jinja2, Handlebars, etc.).
    """
    
    def render(
        self,
        template_content: str,
        variables: Dict[str, Any],
    ) -> str:
        """Render template with variables."""
        ...
    
    def validate_syntax(
        self,
        template_content: str,
    ) -> bool:
        """Validate template syntax."""
        ...
    
    def extract_variables(
        self,
        template_content: str,
    ) -> List[str]:
        """Extract variable names from template."""
        ...


class TemplateVersionProvider(Protocol):
    """
    Protocol for template versioning.
    
    Tracks template history and allows rollback.
    """
    
    async def save_version(
        self,
        template_id: str,
        tenant_id: str,
        version_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Save template version."""
        ...
    
    async def list_versions(
        self,
        template_id: str,
        tenant_id: str,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """List all versions of template."""
        ...
    
    async def get_version(
        self,
        template_id: str,
        tenant_id: str,
        version: int,
    ) -> Optional[Dict[str, Any]]:
        """Get specific version."""
        ...
    
    async def restore_version(
        self,
        template_id: str,
        tenant_id: str,
        version: int,
    ) -> Dict[str, Any]:
        """Restore template to specific version."""
        ...


class PDFRenderer(Protocol):
    """
    Protocol for PDF generation.
    
    Converts HTML to PDF (WeasyPrint, wkhtmltopdf, Puppeteer, etc.).
    """
    
    async def render_pdf(
        self,
        html_content: str,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Render HTML to PDF bytes."""
        ...
    
    async def render_pdf_with_header_footer(
        self,
        html_content: str,
        header_html: Optional[str] = None,
        footer_html: Optional[str] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Render PDF with custom header/footer."""
        ...


class EmailSender(Protocol):
    """
    Protocol for email sending.
    
    Integrates with SMTP, SendGrid, AWS SES, etc.
    """
    
    async def send_email(
        self,
        to: str,
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
        from_name: Optional[str] = None,
        reply_to: Optional[str] = None,
        attachments: Optional[List[Dict[str, Any]]] = None,
        tenant_id: str = None,
    ) -> bool:
        """Send email."""
        ...
    
    async def send_bulk_email(
        self,
        recipients: List[str],
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        tenant_id: str = None,
    ) -> Dict[str, Any]:
        """Send bulk email (newsletter, etc.)."""
        ...
