"""Template rendering service."""

from typing import Optional, Dict, Any
from datetime import datetime

from ..protocols import TemplateStorage, TemplateRenderer
from ..schemas import RenderRequest, RenderResult, TemplateDTO
from ..exceptions import RenderError, TemplateNotFoundError, MissingVariableError


class RenderService:
    """
    Service for rendering templates with variables.
    
    Handles variable injection, branding integration, rendering.
    """
    
    def __init__(
        self,
        storage: TemplateStorage,
        renderer: TemplateRenderer,
        branding_provider: Optional[Any] = None,  # From linkbay-settings
    ):
        self.storage = storage
        self.renderer = renderer
        self.branding_provider = branding_provider
    
    async def render(
        self,
        template_id: Optional[str],
        template_slug: Optional[str],
        variables: Dict[str, Any],
        tenant_id: str,
        language: Optional[str] = "en",
    ) -> RenderResult:
        """Render template with variables."""
        # Get template
        if template_id:
            template_data = await self.storage.get_template(
                template_id=template_id,
                tenant_id=tenant_id,
            )
        elif template_slug:
            template_data = await self.storage.get_template_by_slug(
                slug=template_slug,
                tenant_id=tenant_id,
                language=language,
            )
        else:
            raise ValueError("Either template_id or template_slug required")
        
        if not template_data:
            raise TemplateNotFoundError(
                template_id=template_id,
                slug=template_slug,
                tenant_id=tenant_id,
            )
        
        template = TemplateDTO(**template_data)
        
        # Inject branding variables
        variables = await self._inject_branding(variables, tenant_id)
        
        # Validate required variables
        self._validate_variables(template, variables)
        
        # Render template
        try:
            rendered_content = self.renderer.render(
                template_content=template.content,
                variables=variables,
            )
            
            # Render subject if present
            rendered_subject = None
            if template.subject:
                rendered_subject = self.renderer.render(
                    template_content=template.subject,
                    variables=variables,
                )
            
            return RenderResult(
                template_id=template.id,
                format=template.format,
                content=rendered_content,
                subject=rendered_subject,
                rendered_at=datetime.utcnow(),
            )
        
        except Exception as e:
            raise RenderError(
                template_id=template.id,
                reason=str(e),
                original_error=e,
            )
    
    async def preview(
        self,
        template_id: Optional[str],
        template_content: Optional[str],
        variables: Dict[str, Any],
        tenant_id: str,
    ) -> str:
        """Preview template with sample variables."""
        # Inject branding
        variables = await self._inject_branding(variables, tenant_id)
        
        # Use provided content or fetch template
        if template_content:
            content = template_content
        elif template_id:
            template_data = await self.storage.get_template(
                template_id=template_id,
                tenant_id=tenant_id,
            )
            if not template_data:
                raise TemplateNotFoundError(
                    template_id=template_id,
                    tenant_id=tenant_id,
                )
            content = template_data["content"]
        else:
            raise ValueError("Either template_id or template_content required")
        
        # Render
        try:
            return self.renderer.render(
                template_content=content,
                variables=variables,
            )
        except Exception as e:
            raise RenderError(
                template_id=template_id or "preview",
                reason=str(e),
                original_error=e,
            )
    
    async def _inject_branding(
        self,
        variables: Dict[str, Any],
        tenant_id: str,
    ) -> Dict[str, Any]:
        """Inject tenant branding variables."""
        if not self.branding_provider:
            return variables
        
        # Get branding from linkbay-settings
        try:
            branding = await self.branding_provider.get_branding(tenant_id=tenant_id)
            
            variables["branding"] = {
                "logo_url": branding.logo_url,
                "primary_color": branding.primary_color,
                "secondary_color": branding.secondary_color,
                "company_name": branding.company_name,
                "domain": branding.domain_name,
                "font_family": branding.font_family,
            }
        except:
            # Fallback to defaults if branding not available
            variables["branding"] = {
                "logo_url": "",
                "primary_color": "#0066CC",
                "secondary_color": "#6C757D",
                "company_name": "Company",
                "domain": "",
                "font_family": "Inter, sans-serif",
            }
        
        return variables
    
    def _validate_variables(
        self,
        template: TemplateDTO,
        variables: Dict[str, Any],
    ) -> None:
        """Validate that all required variables are provided."""
        for var in template.variables:
            if hasattr(var, 'required'):
                is_required = var.required
                var_name = var.name
            else:
                is_required = var.get("required", False)
                var_name = var.get("name")
            
            if is_required and var_name not in variables:
                raise MissingVariableError(
                    template_id=template.id,
                    variable=var_name,
                )
