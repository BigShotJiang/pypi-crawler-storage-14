"""PDF generation service."""

from typing import Optional, Dict, Any

from ..protocols import PDFRenderer
from ..services.render_service import RenderService
from ..constants import TemplateFormat


class PDFService:
    """
    Service for generating PDFs from templates.
    
    Converts HTML templates to PDF documents.
    """
    
    def __init__(
        self,
        render_service: RenderService,
        pdf_renderer: PDFRenderer,
    ):
        self.render_service = render_service
        self.pdf_renderer = pdf_renderer
    
    async def render_pdf(
        self,
        template_id: Optional[str],
        template_slug: Optional[str],
        variables: Dict[str, Any],
        tenant_id: str,
        language: Optional[str] = "en",
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Render template as PDF."""
        # Render HTML
        result = await self.render_service.render(
            template_id=template_id,
            template_slug=template_slug,
            variables=variables,
            tenant_id=tenant_id,
            language=language,
        )
        
        # Convert to PDF
        pdf_bytes = await self.pdf_renderer.render_pdf(
            html_content=result.content,
            options=options or {},
        )
        
        return pdf_bytes
    
    async def render_pdf_with_header_footer(
        self,
        template_id: Optional[str],
        template_slug: Optional[str],
        variables: Dict[str, Any],
        tenant_id: str,
        header_template_id: Optional[str] = None,
        footer_template_id: Optional[str] = None,
        language: Optional[str] = "en",
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Render PDF with custom header/footer."""
        # Render main content
        result = await self.render_service.render(
            template_id=template_id,
            template_slug=template_slug,
            variables=variables,
            tenant_id=tenant_id,
            language=language,
        )
        
        # Render header
        header_html = None
        if header_template_id:
            header_result = await self.render_service.render(
                template_id=header_template_id,
                template_slug=None,
                variables=variables,
                tenant_id=tenant_id,
                language=language,
            )
            header_html = header_result.content
        
        # Render footer
        footer_html = None
        if footer_template_id:
            footer_result = await self.render_service.render(
                template_id=footer_template_id,
                template_slug=None,
                variables=variables,
                tenant_id=tenant_id,
                language=language,
            )
            footer_html = footer_result.content
        
        # Generate PDF
        pdf_bytes = await self.pdf_renderer.render_pdf_with_header_footer(
            html_content=result.content,
            header_html=header_html,
            footer_html=footer_html,
            options=options or {},
        )
        
        return pdf_bytes
