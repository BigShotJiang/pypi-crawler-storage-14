"""Core template management service."""

from typing import Optional, Dict, Any, List
from datetime import datetime
import uuid

from ..protocols import (
    TemplateStorage,
    TemplateRenderer,
    TemplateVersionProvider,
)
from ..schemas import (
    TemplateDTO,
    TemplateCreate,
    TemplateUpdate,
    TemplateFilter,
    TemplateVersion,
)
from ..exceptions import TemplateNotFoundError, ValidationError


class TemplateService:
    """
    Core template management service.
    
    Handles CRUD operations, versioning, validation.
    """
    
    def __init__(
        self,
        storage: TemplateStorage,
        renderer: TemplateRenderer,
        version_provider: Optional[TemplateVersionProvider] = None,
    ):
        self.storage = storage
        self.renderer = renderer
        self.version_provider = version_provider
    
    async def create_template(
        self,
        tenant_id: str,
        template_create: TemplateCreate,
        created_by: str,
    ) -> TemplateDTO:
        """Create new template."""
        # Validate syntax
        if not self.renderer.validate_syntax(template_create.content):
            raise ValidationError(
                template_id=template_create.slug,
                reason="Invalid template syntax",
            )
        
        # Auto-extract variables if not provided
        if not template_create.variables:
            extracted_vars = self.renderer.extract_variables(template_create.content)
            template_create.variables = [
                {"name": var, "type": "string", "required": False}
                for var in extracted_vars
            ]
        
        # Create template
        template_data = {
            "id": str(uuid.uuid4()),
            "tenant_id": tenant_id,
            "name": template_create.name,
            "slug": template_create.slug,
            "category": template_create.category.value,
            "format": template_create.format.value,
            "engine": template_create.engine.value,
            "content": template_create.content,
            "subject": template_create.subject,
            "variables": [v.model_dump() if hasattr(v, 'model_dump') else v for v in template_create.variables],
            "language": template_create.language,
            "version": 1,
            "is_active": True,
            "base_template_id": template_create.base_template_id,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": created_by,
        }
        
        saved_template = await self.storage.create_template(template_data)
        
        # Save version
        if self.version_provider:
            await self.version_provider.save_version(
                template_id=saved_template["id"],
                tenant_id=tenant_id,
                version_data={
                    "version": 1,
                    "content": template_create.content,
                    "subject": template_create.subject,
                    "variables": template_data["variables"],
                    "created_at": datetime.utcnow(),
                    "created_by": created_by,
                },
            )
        
        return TemplateDTO(**saved_template)
    
    async def get_template(
        self,
        template_id: str,
        tenant_id: str,
    ) -> TemplateDTO:
        """Get template by ID."""
        template_data = await self.storage.get_template(
            template_id=template_id,
            tenant_id=tenant_id,
        )
        
        if not template_data:
            raise TemplateNotFoundError(
                template_id=template_id,
                tenant_id=tenant_id,
            )
        
        return TemplateDTO(**template_data)
    
    async def get_template_by_slug(
        self,
        slug: str,
        tenant_id: str,
        language: Optional[str] = None,
    ) -> TemplateDTO:
        """Get template by slug and language."""
        template_data = await self.storage.get_template_by_slug(
            slug=slug,
            tenant_id=tenant_id,
            language=language,
        )
        
        if not template_data:
            # Try fallback to default language
            if language and language != "en":
                template_data = await self.storage.get_template_by_slug(
                    slug=slug,
                    tenant_id=tenant_id,
                    language="en",
                )
        
        if not template_data:
            raise TemplateNotFoundError(
                slug=slug,
                tenant_id=tenant_id,
            )
        
        return TemplateDTO(**template_data)
    
    async def update_template(
        self,
        template_id: str,
        tenant_id: str,
        template_update: TemplateUpdate,
        updated_by: str,
    ) -> TemplateDTO:
        """Update template."""
        # Get existing template
        existing = await self.get_template(template_id, tenant_id)
        
        # Validate new content if provided
        if template_update.content:
            if not self.renderer.validate_syntax(template_update.content):
                raise ValidationError(
                    template_id=template_id,
                    reason="Invalid template syntax",
                )
        
        # Prepare update data
        update_data = {
            "updated_at": datetime.utcnow(),
        }
        
        if template_update.name:
            update_data["name"] = template_update.name
        if template_update.content:
            update_data["content"] = template_update.content
            update_data["version"] = existing.version + 1
        if template_update.subject is not None:
            update_data["subject"] = template_update.subject
        if template_update.variables is not None:
            update_data["variables"] = [v.model_dump() for v in template_update.variables]
        if template_update.is_active is not None:
            update_data["is_active"] = template_update.is_active
        
        # Update template
        updated_template = await self.storage.update_template(
            template_id=template_id,
            tenant_id=tenant_id,
            update_data=update_data,
        )
        
        # Save version if content changed
        if template_update.content and self.version_provider:
            await self.version_provider.save_version(
                template_id=template_id,
                tenant_id=tenant_id,
                version_data={
                    "version": update_data["version"],
                    "content": template_update.content,
                    "subject": template_update.subject or existing.subject,
                    "variables": update_data.get("variables", [v.model_dump() for v in existing.variables]),
                    "created_at": datetime.utcnow(),
                    "created_by": updated_by,
                },
            )
        
        return TemplateDTO(**updated_template)
    
    async def delete_template(
        self,
        template_id: str,
        tenant_id: str,
    ) -> bool:
        """Delete template."""
        return await self.storage.delete_template(
            template_id=template_id,
            tenant_id=tenant_id,
        )
    
    async def list_templates(
        self,
        tenant_id: str,
        filters: TemplateFilter,
    ) -> List[TemplateDTO]:
        """List templates with filters."""
        templates_data = await self.storage.list_templates(
            tenant_id=tenant_id,
            category=filters.category.value if filters.category else None,
            format=filters.format.value if filters.format else None,
            language=filters.language,
            is_active=filters.is_active,
        )
        
        templates = [TemplateDTO(**t) for t in templates_data]
        
        # Apply search filter
        if filters.search_query:
            query_lower = filters.search_query.lower()
            templates = [
                t for t in templates
                if query_lower in t.name.lower()
                or query_lower in t.slug.lower()
            ]
        
        return templates
    
    async def list_versions(
        self,
        template_id: str,
        tenant_id: str,
        limit: int = 50,
    ) -> List[TemplateVersion]:
        """List all versions of template."""
        if not self.version_provider:
            return []
        
        versions_data = await self.version_provider.list_versions(
            template_id=template_id,
            tenant_id=tenant_id,
            limit=limit,
        )
        
        return [TemplateVersion(**v) for v in versions_data]
    
    async def restore_version(
        self,
        template_id: str,
        tenant_id: str,
        version: int,
        updated_by: str,
    ) -> TemplateDTO:
        """Restore template to specific version."""
        if not self.version_provider:
            raise ValueError("Version provider not configured")
        
        version_data = await self.version_provider.get_version(
            template_id=template_id,
            tenant_id=tenant_id,
            version=version,
        )
        
        if not version_data:
            from ..exceptions import VersionNotFoundError
            raise VersionNotFoundError(template_id=template_id, version=version)
        
        # Update template with version content
        update_data = {
            "content": version_data["content"],
            "subject": version_data.get("subject"),
            "variables": version_data.get("variables", []),
            "updated_at": datetime.utcnow(),
        }
        
        updated_template = await self.storage.update_template(
            template_id=template_id,
            tenant_id=tenant_id,
            update_data=update_data,
        )
        
        return TemplateDTO(**updated_template)
    
    async def clone_template(
        self,
        source_template_id: str,
        source_tenant_id: str,
        target_tenant_id: str,
        new_name: Optional[str] = None,
        new_slug: Optional[str] = None,
        created_by: str = "system",
    ) -> TemplateDTO:
        """Clone template to another tenant."""
        # Get source template
        source = await self.get_template(source_template_id, source_tenant_id)
        
        # Create new template
        from ..schemas import TemplateCreate
        template_create = TemplateCreate(
            name=new_name or f"{source.name} (copy)",
            slug=new_slug or f"{source.slug}_copy",
            category=source.category,
            format=source.format,
            engine=source.engine,
            content=source.content,
            subject=source.subject,
            variables=source.variables,
            language=source.language,
            base_template_id=source.base_template_id,
        )
        
        return await self.create_template(
            tenant_id=target_tenant_id,
            template_create=template_create,
            created_by=created_by,
        )
