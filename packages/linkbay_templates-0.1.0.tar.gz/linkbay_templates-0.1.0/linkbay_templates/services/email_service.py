"""Email sending service."""

from typing import Optional, Dict, Any, List

from ..protocols import TemplateStorage, EmailSender
from ..services.render_service import RenderService
from ..schemas import EmailRequest
from ..constants import TemplateFormat


class EmailService:
    """
    Service for sending emails from templates.
    
    Integrates with email sender and render service.
    """
    
    def __init__(
        self,
        storage: TemplateStorage,
        render_service: RenderService,
        email_sender: EmailSender,
        smtp_config_provider: Optional[Any] = None,  # From linkbay-settings
    ):
        self.storage = storage
        self.render_service = render_service
        self.email_sender = email_sender
        self.smtp_config_provider = smtp_config_provider
    
    async def send_email(
        self,
        template_slug: str,
        recipient: str,
        variables: Dict[str, Any],
        tenant_id: str,
        language: Optional[str] = "en",
        attachments: Optional[List[Dict[str, Any]]] = None,
    ) -> bool:
        """Send email from template."""
        # Render HTML version
        html_result = await self.render_service.render(
            template_id=None,
            template_slug=template_slug,
            variables=variables,
            tenant_id=tenant_id,
            language=language,
        )
        
        # Try to render text version
        text_body = None
        try:
            text_slug = f"{template_slug}_text"
            text_result = await self.render_service.render(
                template_id=None,
                template_slug=text_slug,
                variables=variables,
                tenant_id=tenant_id,
                language=language,
            )
            text_body = text_result.content
        except:
            # No text version available
            pass
        
        # Get SMTP config
        from_email = None
        from_name = None
        reply_to = None
        
        if self.smtp_config_provider:
            try:
                smtp_config = await self.smtp_config_provider.get_email_config(tenant_id)
                from_email = smtp_config.from_email
                from_name = smtp_config.from_name
                reply_to = smtp_config.reply_to
            except:
                pass
        
        # Send email
        return await self.email_sender.send_email(
            to=recipient,
            subject=html_result.subject or "Notification",
            html_body=html_result.content,
            text_body=text_body,
            from_email=from_email,
            from_name=from_name,
            reply_to=reply_to,
            attachments=attachments,
            tenant_id=tenant_id,
        )
    
    async def send_test_email(
        self,
        template_id: str,
        recipient: str,
        sample_variables: Dict[str, Any],
        tenant_id: str,
    ) -> bool:
        """Send test email with sample variables."""
        # Get template
        template_data = await self.storage.get_template(
            template_id=template_id,
            tenant_id=tenant_id,
        )
        
        if not template_data:
            from ..exceptions import TemplateNotFoundError
            raise TemplateNotFoundError(
                template_id=template_id,
                tenant_id=tenant_id,
            )
        
        # Render
        result = await self.render_service.render(
            template_id=template_id,
            template_slug=None,
            variables=sample_variables,
            tenant_id=tenant_id,
        )
        
        # Send
        return await self.email_sender.send_email(
            to=recipient,
            subject=f"[TEST] {result.subject or 'Template Test'}",
            html_body=result.content,
            tenant_id=tenant_id,
        )
    
    async def send_bulk_email(
        self,
        template_slug: str,
        recipients: List[str],
        variables: Dict[str, Any],
        tenant_id: str,
        language: Optional[str] = "en",
    ) -> Dict[str, Any]:
        """Send bulk email (newsletter, marketing)."""
        # Render template once
        result = await self.render_service.render(
            template_id=None,
            template_slug=template_slug,
            variables=variables,
            tenant_id=tenant_id,
            language=language,
        )
        
        # Send bulk
        return await self.email_sender.send_bulk_email(
            recipients=recipients,
            subject=result.subject or "Newsletter",
            html_body=result.content,
            tenant_id=tenant_id,
        )
