"""LinkBay-Templates: Protocol-based template management and rendering for multi-tenant SaaS."""

from .constants import (
    TemplateCategory,
    TemplateFormat,
    TemplateEngine,
)

from .exceptions import (
    TemplateError,
    TemplateNotFoundError,
    RenderError,
    ValidationError,
    VersionNotFoundError,
)

from .protocols import (
    TemplateStorage,
    TemplateRenderer,
    TemplateVersionProvider,
    PDFRenderer,
    EmailSender,
)

from .schemas import (
    TemplateDTO,
    TemplateCreate,
    TemplateUpdate,
    TemplateFilter,
    TemplateResponse,
    TemplateListResponse,
    TemplateVersion,
    RenderRequest,
    RenderResult,
    EmailRequest,
    PreviewRequest,
    TemplateVariable,
    TemplateExport,
)

from .services import (
    TemplateService,
    RenderService,
    EmailService,
    PDFService,
)

from .engines import (
    Jinja2Renderer,
)

from .router import create_templates_router

__all__ = [
    # Constants
    "TemplateCategory",
    "TemplateFormat",
    "TemplateEngine",
    # Exceptions
    "TemplateError",
    "TemplateNotFoundError",
    "RenderError",
    "ValidationError",
    "VersionNotFoundError",
    # Protocols
    "TemplateStorage",
    "TemplateRenderer",
    "TemplateVersionProvider",
    "PDFRenderer",
    "EmailSender",
    # Schemas
    "TemplateDTO",
    "TemplateCreate",
    "TemplateUpdate",
    "TemplateFilter",
    "TemplateResponse",
    "TemplateListResponse",
    "TemplateVersion",
    "RenderRequest",
    "RenderResult",
    "EmailRequest",
    "PreviewRequest",
    "TemplateVariable",
    "TemplateExport",
    # Services
    "TemplateService",
    "RenderService",
    "EmailService",
    "PDFService",
    # Engines
    "Jinja2Renderer",
    # Router
    "create_templates_router",
]

__version__ = "0.1.0"
