"""Pydantic schemas for templates."""

from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field

from .constants import TemplateCategory, TemplateFormat, TemplateEngine


class TemplateVariable(BaseModel):
    """Template variable definition."""
    name: str
    type: str = "string"  # string, number, boolean, object, array
    description: Optional[str] = None
    required: bool = False
    default_value: Optional[Any] = None


class TemplateDTO(BaseModel):
    """Complete template metadata."""
    id: str
    tenant_id: str
    name: str
    slug: str
    category: TemplateCategory
    format: TemplateFormat
    engine: TemplateEngine
    content: str
    subject: Optional[str] = None  # For email templates
    variables: List[TemplateVariable] = Field(default_factory=list)
    language: str = "en"
    version: int = 1
    is_active: bool = True
    base_template_id: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    created_by: str


class TemplateCreate(BaseModel):
    """Request to create template."""
    name: str
    slug: str
    category: TemplateCategory
    format: TemplateFormat
    engine: TemplateEngine = TemplateEngine.JINJA2
    content: str
    subject: Optional[str] = None
    variables: List[TemplateVariable] = Field(default_factory=list)
    language: str = "en"
    base_template_id: Optional[str] = None


class TemplateUpdate(BaseModel):
    """Request to update template."""
    name: Optional[str] = None
    content: Optional[str] = None
    subject: Optional[str] = None
    variables: Optional[List[TemplateVariable]] = None
    is_active: Optional[bool] = None


class TemplateFilter(BaseModel):
    """Filters for listing templates."""
    category: Optional[TemplateCategory] = None
    format: Optional[TemplateFormat] = None
    language: Optional[str] = None
    is_active: Optional[bool] = None
    search_query: Optional[str] = None


class TemplateResponse(BaseModel):
    """Response with single template."""
    template: TemplateDTO


class TemplateListResponse(BaseModel):
    """Paginated list of templates."""
    templates: List[TemplateDTO]
    total: int


class TemplateVersion(BaseModel):
    """Template version metadata."""
    template_id: str
    tenant_id: str
    version: int
    content: str
    subject: Optional[str] = None
    variables: List[TemplateVariable]
    created_at: datetime
    created_by: str
    change_note: Optional[str] = None


class RenderRequest(BaseModel):
    """Request to render template."""
    template_id: Optional[str] = None
    template_slug: Optional[str] = None
    variables: Dict[str, Any]
    language: Optional[str] = "en"


class RenderResult(BaseModel):
    """Result of template rendering."""
    template_id: str
    format: TemplateFormat
    content: str  # HTML, text, or base64 for PDF/images
    subject: Optional[str] = None
    rendered_at: datetime


class EmailRequest(BaseModel):
    """Request to send email from template."""
    template_slug: str
    recipient: str
    variables: Dict[str, Any]
    language: Optional[str] = "en"
    attachments: Optional[List[Dict[str, Any]]] = None


class PreviewRequest(BaseModel):
    """Request to preview template."""
    template_id: Optional[str] = None
    template_content: Optional[str] = None  # For preview before saving
    variables: Dict[str, Any]
    format: Optional[TemplateFormat] = None


class TemplateExport(BaseModel):
    """Template export format."""
    tenant_id: str
    exported_at: datetime
    templates: List[TemplateDTO]
    versions: Optional[List[TemplateVersion]] = None


class CloneTemplateRequest(BaseModel):
    """Request to clone template."""
    source_template_id: str
    new_name: Optional[str] = None
    new_slug: Optional[str] = None
    target_tenant_id: Optional[str] = None  # For cross-tenant clone


class TestEmailRequest(BaseModel):
    """Request to send test email."""
    template_id: str
    recipient: str
    sample_variables: Dict[str, Any]
