"""Jinja2 template renderer implementation."""

from typing import Dict, Any, List
import re


class Jinja2Renderer:
    """
    Jinja2 template rendering engine.
    
    Default renderer for LinkBay-Templates.
    """
    
    def __init__(self):
        try:
            from jinja2 import Environment, Template, TemplateSyntaxError
            self.jinja_env = Environment(autoescape=True)
            self.Template = Template
            self.TemplateSyntaxError = TemplateSyntaxError
        except ImportError:
            raise ImportError("jinja2 is required. Install with: pip install jinja2")
    
    def render(
        self,
        template_content: str,
        variables: Dict[str, Any],
    ) -> str:
        """Render template with variables."""
        template = self.jinja_env.from_string(template_content)
        return template.render(**variables)
    
    def validate_syntax(
        self,
        template_content: str,
    ) -> bool:
        """Validate Jinja2 template syntax."""
        try:
            self.jinja_env.from_string(template_content)
            return True
        except self.TemplateSyntaxError:
            return False
        except Exception:
            return False
    
    def extract_variables(
        self,
        template_content: str,
    ) -> List[str]:
        """Extract variable names from Jinja2 template."""
        # Pattern to match {{ variable }}, {{ obj.attr }}, {{ dict['key'] }}
        pattern = r'\{\{\s*([a-zA-Z_][a-zA-Z0-9_\.]*)\s*\}\}'
        matches = re.findall(pattern, template_content)
        
        # Get unique root variables (before first dot)
        variables = set()
        for match in matches:
            root_var = match.split('.')[0].split('[')[0]
            variables.add(root_var)
        
        return sorted(list(variables))
