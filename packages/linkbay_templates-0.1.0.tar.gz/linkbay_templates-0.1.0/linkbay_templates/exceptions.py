"""Custom exceptions for template management."""


class TemplateError(Exception):
    """Base exception for template errors."""
    pass


class TemplateNotFoundError(TemplateError):
    """Template not found."""
    
    def __init__(self, template_id: str = None, slug: str = None, tenant_id: str = None):
        self.template_id = template_id
        self.slug = slug
        self.tenant_id = tenant_id
        identifier = template_id or slug
        super().__init__(f"Template '{identifier}' not found for tenant {tenant_id}")


class RenderError(TemplateError):
    """Template rendering failed."""
    
    def __init__(self, template_id: str, reason: str, original_error: Exception = None):
        self.template_id = template_id
        self.reason = reason
        self.original_error = original_error
        super().__init__(f"Render failed for template '{template_id}': {reason}")


class ValidationError(TemplateError):
    """Template validation failed."""
    
    def __init__(self, template_id: str, reason: str):
        self.template_id = template_id
        self.reason = reason
        super().__init__(f"Validation failed for template '{template_id}': {reason}")


class VersionNotFoundError(TemplateError):
    """Template version not found."""
    
    def __init__(self, template_id: str, version: int):
        self.template_id = template_id
        self.version = version
        super().__init__(f"Version {version} not found for template '{template_id}'")


class MissingVariableError(TemplateError):
    """Required variable missing."""
    
    def __init__(self, template_id: str, variable: str):
        self.template_id = template_id
        self.variable = variable
        super().__init__(f"Missing required variable '{variable}' for template '{template_id}'")
