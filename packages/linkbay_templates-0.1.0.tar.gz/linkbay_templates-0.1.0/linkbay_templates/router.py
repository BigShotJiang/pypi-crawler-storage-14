"""FastAPI router for template management."""

from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import StreamingResponse
import io

from .protocols import (
    TemplateStorage,
    TemplateRenderer,
    TemplateVersionProvider,
    PDFRenderer,
    EmailSender,
)
from .schemas import (
    TemplateDTO,
    TemplateCreate,
    TemplateUpdate,
    TemplateFilter,
    TemplateResponse,
    TemplateListResponse,
    TemplateVersion,
    RenderRequest,
    RenderResult,
    EmailRequest,
    PreviewRequest,
    CloneTemplateRequest,
    TestEmailRequest,
)
from .services import (
    TemplateService,
    RenderService,
    EmailService,
    PDFService,
)
from .exceptions import TemplateNotFoundError, RenderError, ValidationError


def create_templates_router(
    storage: TemplateStorage,
    renderer: TemplateRenderer,
    version_provider: Optional[TemplateVersionProvider] = None,
    pdf_renderer: Optional[PDFRenderer] = None,
    email_sender: Optional[EmailSender] = None,
    branding_provider: Optional[any] = None,
    smtp_config_provider: Optional[any] = None,
    prefix: str = "/templates",
) -> APIRouter:
    """
    Create FastAPI router for template management.
    
    Args:
        storage: Template storage implementation
        renderer: Template renderer (Jinja2, etc.)
        version_provider: Optional version provider
        pdf_renderer: Optional PDF renderer
        email_sender: Optional email sender
        branding_provider: Optional branding provider (from linkbay-settings)
        smtp_config_provider: Optional SMTP config provider
        prefix: Router prefix
    
    Returns:
        Configured APIRouter
    """
    router = APIRouter(prefix=prefix, tags=["templates"])
    
    # Initialize services
    template_service = TemplateService(
        storage=storage,
        renderer=renderer,
        version_provider=version_provider,
    )
    
    render_service = RenderService(
        storage=storage,
        renderer=renderer,
        branding_provider=branding_provider,
    )
    
    email_service = None
    if email_sender:
        email_service = EmailService(
            storage=storage,
            render_service=render_service,
            email_sender=email_sender,
            smtp_config_provider=smtp_config_provider,
        )
    
    pdf_service = None
    if pdf_renderer:
        pdf_service = PDFService(
            render_service=render_service,
            pdf_renderer=pdf_renderer,
        )
    
    # CRUD ENDPOINTS
    
    @router.post("/{tenant_id}/templates", response_model=TemplateResponse, status_code=status.HTTP_201_CREATED)
    async def create_template(
        tenant_id: str,
        template: TemplateCreate,
        created_by: str = "system",
    ):
        """Create new template."""
        try:
            created = await template_service.create_template(
                tenant_id=tenant_id,
                template_create=template,
                created_by=created_by,
            )
            return TemplateResponse(template=created)
        except ValidationError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.get("/{tenant_id}/templates/{template_id}", response_model=TemplateResponse)
    async def get_template(tenant_id: str, template_id: str):
        """Get template by ID."""
        try:
            template = await template_service.get_template(
                template_id=template_id,
                tenant_id=tenant_id,
            )
            return TemplateResponse(template=template)
        except TemplateNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    @router.get("/{tenant_id}/templates/slug/{slug}", response_model=TemplateResponse)
    async def get_template_by_slug(
        tenant_id: str,
        slug: str,
        language: Optional[str] = "en",
    ):
        """Get template by slug and language."""
        try:
            template = await template_service.get_template_by_slug(
                slug=slug,
                tenant_id=tenant_id,
                language=language,
            )
            return TemplateResponse(template=template)
        except TemplateNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    @router.put("/{tenant_id}/templates/{template_id}", response_model=TemplateResponse)
    async def update_template(
        tenant_id: str,
        template_id: str,
        update: TemplateUpdate,
        updated_by: str = "system",
    ):
        """Update template."""
        try:
            updated = await template_service.update_template(
                template_id=template_id,
                tenant_id=tenant_id,
                template_update=update,
                updated_by=updated_by,
            )
            return TemplateResponse(template=updated)
        except TemplateNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except ValidationError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.delete("/{tenant_id}/templates/{template_id}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_template(tenant_id: str, template_id: str):
        """Delete template."""
        deleted = await template_service.delete_template(
            template_id=template_id,
            tenant_id=tenant_id,
        )
        if not deleted:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Template {template_id} not found",
            )
    
    @router.get("/{tenant_id}/templates", response_model=TemplateListResponse)
    async def list_templates(
        tenant_id: str,
        category: Optional[str] = None,
        format: Optional[str] = None,
        language: Optional[str] = None,
        is_active: Optional[bool] = None,
        search_query: Optional[str] = None,
    ):
        """List templates with filters."""
        from .constants import TemplateCategory, TemplateFormat
        
        filters = TemplateFilter(
            category=TemplateCategory(category) if category else None,
            format=TemplateFormat(format) if format else None,
            language=language,
            is_active=is_active,
            search_query=search_query,
        )
        
        templates = await template_service.list_templates(
            tenant_id=tenant_id,
            filters=filters,
        )
        
        return TemplateListResponse(
            templates=templates,
            total=len(templates),
        )
    
    # RENDER ENDPOINTS
    
    @router.post("/{tenant_id}/render", response_model=RenderResult)
    async def render_template(
        tenant_id: str,
        request: RenderRequest,
    ):
        """Render template with variables."""
        try:
            result = await render_service.render(
                template_id=request.template_id,
                template_slug=request.template_slug,
                variables=request.variables,
                tenant_id=tenant_id,
                language=request.language,
            )
            return result
        except (TemplateNotFoundError, RenderError) as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.post("/{tenant_id}/preview")
    async def preview_template(
        tenant_id: str,
        request: PreviewRequest,
    ):
        """Preview template with sample variables."""
        try:
            rendered = await render_service.preview(
                template_id=request.template_id,
                template_content=request.template_content,
                variables=request.variables,
                tenant_id=tenant_id,
            )
            return {"html": rendered}
        except RenderError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    # EMAIL ENDPOINTS
    
    @router.post("/{tenant_id}/send-email")
    async def send_email(
        tenant_id: str,
        request: EmailRequest,
    ):
        """Send email from template."""
        if not email_service:
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Email service not configured",
            )
        
        try:
            sent = await email_service.send_email(
                template_slug=request.template_slug,
                recipient=request.recipient,
                variables=request.variables,
                tenant_id=tenant_id,
                language=request.language,
                attachments=request.attachments,
            )
            return {"sent": sent}
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.post("/{tenant_id}/send-test-email")
    async def send_test_email(
        tenant_id: str,
        request: TestEmailRequest,
    ):
        """Send test email with sample variables."""
        if not email_service:
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Email service not configured",
            )
        
        try:
            sent = await email_service.send_test_email(
                template_id=request.template_id,
                recipient=request.recipient,
                sample_variables=request.sample_variables,
                tenant_id=tenant_id,
            )
            return {"sent": sent}
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    # PDF ENDPOINTS
    
    @router.post("/{tenant_id}/render-pdf")
    async def render_pdf(
        tenant_id: str,
        request: RenderRequest,
    ):
        """Render template as PDF."""
        if not pdf_service:
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="PDF service not configured",
            )
        
        try:
            pdf_bytes = await pdf_service.render_pdf(
                template_id=request.template_id,
                template_slug=request.template_slug,
                variables=request.variables,
                tenant_id=tenant_id,
                language=request.language,
            )
            
            return StreamingResponse(
                io.BytesIO(pdf_bytes),
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"attachment; filename=document.pdf"
                },
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    # VERSION ENDPOINTS
    
    @router.get("/{tenant_id}/templates/{template_id}/versions", response_model=List[TemplateVersion])
    async def list_versions(
        tenant_id: str,
        template_id: str,
        limit: int = 50,
    ):
        """List template versions."""
        versions = await template_service.list_versions(
            template_id=template_id,
            tenant_id=tenant_id,
            limit=limit,
        )
        return versions
    
    @router.post("/{tenant_id}/templates/{template_id}/restore/{version}", response_model=TemplateResponse)
    async def restore_version(
        tenant_id: str,
        template_id: str,
        version: int,
        updated_by: str = "system",
    ):
        """Restore template to specific version."""
        try:
            restored = await template_service.restore_version(
                template_id=template_id,
                tenant_id=tenant_id,
                version=version,
                updated_by=updated_by,
            )
            return TemplateResponse(template=restored)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    # CLONE ENDPOINT
    
    @router.post("/{tenant_id}/templates/{template_id}/clone", response_model=TemplateResponse)
    async def clone_template(
        tenant_id: str,
        template_id: str,
        request: CloneTemplateRequest,
    ):
        """Clone template."""
        try:
            cloned = await template_service.clone_template(
                source_template_id=template_id,
                source_tenant_id=tenant_id,
                target_tenant_id=request.target_tenant_id or tenant_id,
                new_name=request.new_name,
                new_slug=request.new_slug,
            )
            return TemplateResponse(template=cloned)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    return router
