"""Constants for template management."""

from enum import Enum


class TemplateCategory(str, Enum):
    """Template categories."""
    # Transactional emails
    TRANSACTIONAL = "transactional"
    # Marketing campaigns
    MARKETING = "marketing"
    # System notifications
    SYSTEM = "system"
    # Custom user-defined
    CUSTOM = "custom"


class TemplateFormat(str, Enum):
    """Template output formats."""
    EMAIL_HTML = "email_html"
    EMAIL_TEXT = "email_text"
    PDF = "pdf"
    SMS = "sms"
    PUSH = "push"
    PRINT = "print"
    WEB = "web"


class TemplateEngine(str, Enum):
    """Template rendering engines."""
    JINJA2 = "jinja2"
    HANDLEBARS = "handlebars"
    LIQUID = "liquid"


# Common transactional template slugs
TRANSACTIONAL_TEMPLATES = {
    "order_confirmation": "Order Confirmation",
    "payment_receipt": "Payment Receipt",
    "shipping_notification": "Shipping Notification",
    "password_reset": "Password Reset",
    "invoice": "Invoice",
    "account_created": "Account Created",
    "email_verification": "Email Verification",
    "order_cancelled": "Order Cancelled",
    "refund_processed": "Refund Processed",
}

# Marketing template slugs
MARKETING_TEMPLATES = {
    "newsletter": "Newsletter",
    "promotion": "Promotion",
    "abandoned_cart": "Abandoned Cart",
    "product_launch": "Product Launch",
    "survey": "Survey",
    "welcome_series": "Welcome Series",
    "win_back": "Win Back Campaign",
}

# System template slugs
SYSTEM_TEMPLATES = {
    "welcome_email": "Welcome Email",
    "trial_expiring": "Trial Expiring",
    "subscription_renewed": "Subscription Renewed",
    "low_stock_alert": "Low Stock Alert",
    "support_ticket_created": "Support Ticket Created",
    "account_suspended": "Account Suspended",
    "payment_failed": "Payment Failed",
}

# Default supported languages
SUPPORTED_LANGUAGES = ["en", "it", "es", "fr", "de"]

# Default branding variables injected into all templates
BRANDING_VARIABLES = [
    "branding.logo_url",
    "branding.primary_color",
    "branding.secondary_color",
    "branding.company_name",
    "branding.domain",
    "branding.support_email",
]
