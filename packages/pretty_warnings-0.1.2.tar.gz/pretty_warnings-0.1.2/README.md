# pretty_warnings

A Python module for displaying formatted warnings.

## Installation

```
pip install pretty_warnings
```

## Usage

```python
from pretty_warnings import warn

try:
    bad_function()
except Exception as e:
    warn("Bad function has run.")
```