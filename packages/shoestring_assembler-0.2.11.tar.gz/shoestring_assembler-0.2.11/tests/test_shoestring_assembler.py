#!/usr/bin/env python

"""Tests for `shoestring_assembler` package."""


import unittest

from shoestring_assembler import shoestring_assembler


class TestShoestring_assembler(unittest.TestCase):
    """Tests for `shoestring_assembler` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
