"""Unit test package for shoestring_assembler."""
