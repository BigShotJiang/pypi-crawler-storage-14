shoestring\_assembler.view package
==================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   shoestring_assembler.view.cli_app
   shoestring_assembler.view.plain_cli

Module contents
---------------

.. automodule:: shoestring_assembler.view
   :members:
   :undoc-members:
   :show-inheritance:
