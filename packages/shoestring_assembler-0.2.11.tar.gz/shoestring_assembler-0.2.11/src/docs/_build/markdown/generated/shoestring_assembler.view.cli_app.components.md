# shoestring_assembler.view.cli_app.components package

## Module contents
