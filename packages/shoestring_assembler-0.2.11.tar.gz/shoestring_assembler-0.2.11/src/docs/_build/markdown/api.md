# API

| [`shoestring_assembler`](generated/shoestring_assembler.md#module-shoestring_assembler)   | Top-level package for Shoestring Assembler.   |
|-------------------------------------------------------------------------------------------|-----------------------------------------------|
