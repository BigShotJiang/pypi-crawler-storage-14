def test_placeholder():
    from plugins.module_utils.helper.utils import \
        profiler
