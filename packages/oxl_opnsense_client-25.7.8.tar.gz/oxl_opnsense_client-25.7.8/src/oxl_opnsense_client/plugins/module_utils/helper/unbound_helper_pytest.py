def test_placeholder():
    from plugins.module_utils.helper.unbound import \
        validate_domain
