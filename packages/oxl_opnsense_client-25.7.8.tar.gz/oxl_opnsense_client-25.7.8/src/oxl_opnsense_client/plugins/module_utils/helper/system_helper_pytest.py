def test_placeholder():
    from plugins.module_utils.helper.system import \
        _opn_reachable_ipv, _opn_reachable, _wait_msg, wait_for_response, get_upgrade_status, \
        wait_for_update
