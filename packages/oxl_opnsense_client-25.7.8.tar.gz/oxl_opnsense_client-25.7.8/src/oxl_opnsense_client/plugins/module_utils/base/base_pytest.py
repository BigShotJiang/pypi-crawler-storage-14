def test_placeholder():
    from plugins.module_utils.base.base import Base
