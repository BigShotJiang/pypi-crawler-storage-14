def test_placeholder():
    from plugins.module_utils.base.handler import \
        ModuleSoftError, ModuleValidationError
