def test_placeholder():
    from plugins.module_utils.base.cls import \
        BaseShared, BaseModule, GeneralModule
