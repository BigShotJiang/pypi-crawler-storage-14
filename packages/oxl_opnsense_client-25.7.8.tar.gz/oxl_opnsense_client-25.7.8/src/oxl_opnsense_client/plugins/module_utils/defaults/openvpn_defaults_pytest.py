def test_placeholder():
    from plugins.module_utils.defaults.openvpn import \
        OPENVPN_INSTANCE_MOD_ARGS
