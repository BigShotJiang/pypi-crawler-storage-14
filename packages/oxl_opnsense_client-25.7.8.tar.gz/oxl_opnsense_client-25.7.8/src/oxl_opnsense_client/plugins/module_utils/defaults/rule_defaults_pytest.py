def test_placeholder():
    from plugins.module_utils.defaults.rule import \
        RULE_MOD_ARGS
