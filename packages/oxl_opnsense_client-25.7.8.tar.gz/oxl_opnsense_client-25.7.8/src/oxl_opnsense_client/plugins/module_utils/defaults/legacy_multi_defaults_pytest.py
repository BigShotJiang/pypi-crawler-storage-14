def test_placeholder():
    from plugins.module_utils.defaults.legacy_multi import \
        PURGE_MOD_ARGS, STATE_MOD_ARG_MULTI, FAIL_MOD_ARG_MULTI, INFO_MOD_ARG, RULE_MOD_ARG_KEY_FIELD
