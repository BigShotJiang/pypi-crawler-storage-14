
def test_placeholder():
    from basic.client import Client
