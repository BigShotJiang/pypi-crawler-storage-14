(api-configlist)=

# ciscoconfparse2.ConfigList Object

```{eval-rst}
.. autoclass:: ciscoconfparse2.ConfigList
   :members:
   :undoc-members:
   :inherited-members:
```
