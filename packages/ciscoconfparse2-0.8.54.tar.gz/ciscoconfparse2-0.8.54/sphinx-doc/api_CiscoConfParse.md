(api-ciscoconfparse)=

# ciscoconfparse2 functions

```{eval-rst}
.. autofunction:: ciscoconfparse2.ciscoconfparse2.initialize_ciscoconfparse2
```

```{eval-rst}
.. autofunction:: ciscoconfparse2.ciscoconfparse2.cfgobj_from_text
```

```{eval-rst}
.. autofunction:: ciscoconfparse2.ciscoconfparse2.build_space_tolerant_regex
```

```{eval-rst}
.. autofunction:: ciscoconfparse2.convert_junos_to_ios

```

# ciscoconfparse2.CiscoConfParse Object

```{eval-rst}
.. autoclass:: ciscoconfparse2.CiscoConfParse
   :members:
   :undoc-members:
   :inherited-members:
```

# ciscoconfparse2.Diff Object

```{eval-rst}
.. autoclass:: ciscoconfparse2.Diff
   :members:
   :undoc-members:
   :inherited-members:
```
