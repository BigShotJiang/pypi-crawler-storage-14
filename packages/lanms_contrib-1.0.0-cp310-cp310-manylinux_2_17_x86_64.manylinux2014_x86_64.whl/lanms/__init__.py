import numpy as np

from .lanmslib import merge_quadrangle_n9 as nms_impl
from .lanmslib import merge_quadrangle_standard as nms_impl_standard

__all__ = ['merge_quadrangle_n9', 'merge_quadrangle_standard']    

def merge_quadrangle_n9(polys: np.ndarray, nms_thresh: float = 0.3, precision: int = 10000) -> np.ndarray:
    if len(polys) == 0:
        return np.array([], dtype='float32')

    p = polys.copy()
    p[:, :8] *= precision
    ret = np.array(nms_impl(p, nms_thresh), dtype='float32')
    ret[:, :8] /= precision

    return ret

def merge_quadrangle_standard(rbbox: np.ndarray, scores: np.ndarray, thres: float = 0.3, precision: int = 10000) -> np.ndarray:
    """
    Args
      rbbox: [n, 8], np.ndarray
      scores (n,), np.ndarray
    """
    if len(rbbox) == 0:
        return np.array([], dtype=np.int32)

    p = np.concatenate([rbbox, scores.reshape(-1, 1)], axis=1)
    p[:, :8] *= precision
    return np.array(nms_impl_standard(p, thres), dtype='int32')
    