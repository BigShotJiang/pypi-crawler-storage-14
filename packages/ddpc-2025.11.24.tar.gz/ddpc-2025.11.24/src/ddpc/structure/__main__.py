"""Entry point for ddpc-structure CLI when run as a module or compiled with Nuitka."""

from ddpc.structure.cli import cli

if __name__ == "__main__":
    cli()
