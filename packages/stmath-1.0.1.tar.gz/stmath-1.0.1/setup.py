from setuptools import setup, find_packages

setup(
    name="stmath",
    version="1.0.1",
    packages=find_packages(),
    description="AI-powered universal math library",
    author="Saksham Tomar",
)
