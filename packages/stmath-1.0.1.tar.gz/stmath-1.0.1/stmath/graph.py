# # graph.py

import heapq
from collections import deque


# ---------------------------
# DIJKSTRA (Already Correct)
# ---------------------------
def dijkstra_shortest_path(adj, start):
    dist = {n: float("inf") for n in adj}
    prev = {n: None for n in adj}

    dist[start] = 0
    pq = [(0, start)]

    while pq:
        d, u = heapq.heappop(pq)
        if d > dist[u]:
            continue
        for v, w in adj.get(u, []):
            nd = d + w
            if nd < dist.get(v, float("inf")):
                dist[v] = nd
                prev[v] = u
                heapq.heappush(pq, (nd, v))

    return dist, prev


# ----------------------------------------------------------
# FIXED BFS — SUPPORTS BOTH WEIGHTED AND UNWEIGHTED GRAPHS
# ----------------------------------------------------------
def bfs_distance(adj, start):
    """
    BFS distance that works for:
      - Unweighted graph: {'A':['B','C'], 'B':['D'], ...}
      - Weighted graph:   {'A':[('B',3),('C',2)], ...}

    Returns: dict of node distances (in edges or weighted cost)
    """

    q = deque([start])
    visited = {start}
    cost = {start: 0}

    while q:
        u = q.popleft()

        for edge in adj.get(u, []):

            # Case 1: unweighted edge → a string like 'B'
            if isinstance(edge, str):
                v = edge
                w = 1  # default weight for BFS

            # Case 2: weighted edge → tuple ('B', 3)
            else:
                v, w = edge

            if v not in visited:
                visited.add(v)
                cost[v] = cost[u] + w
                q.append(v)

    return cost
