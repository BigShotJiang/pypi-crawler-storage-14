"""
Tests for intelligent error recovery system.
"""

import asyncio
import pytest

from erosolar_cli.core.error_recovery import (
    ErrorAnalysis,
    ErrorAnalyzer,
    ErrorCategory,
    ErrorRecoveryManager,
)


class TestErrorAnalyzer:
    """Test error analysis and categorization."""

    def test_rate_limit_detection(self):
        """Test detection of rate limit errors."""
        error = Exception("Rate limit exceeded. Too many requests")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.RATE_LIMIT
        assert analysis.is_retryable is True
        assert analysis.retry_delay_seconds > 0

    def test_auth_error_detection(self):
        """Test detection of authentication errors."""
        error = Exception("401 Unauthorized: Invalid API key")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.AUTH_ERROR
        assert analysis.is_retryable is False
        assert analysis.requires_user_action is True

    def test_invalid_request_detection(self):
        """Test detection of invalid request errors."""
        error = Exception("400 Bad Request: Missing required parameter 'name'")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.INVALID_REQUEST
        assert analysis.is_retryable is True
        assert "fix" in analysis.suggested_fix.lower()

    def test_model_error_detection(self):
        """Test detection of model errors."""
        error = Exception("Model 'gpt-99' not found")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.MODEL_ERROR
        assert analysis.is_retryable is True
        assert len(analysis.alternative_providers) > 0

    def test_network_error_detection(self):
        """Test detection of network errors."""
        error = Exception("Connection timeout after 30 seconds")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.NETWORK_ERROR
        assert analysis.is_retryable is True
        assert analysis.retry_delay_seconds > 0

    def test_context_length_detection(self):
        """Test detection of context length errors."""
        error = Exception("Context length exceeded: maximum 4096 tokens")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.CONTEXT_LENGTH
        assert analysis.is_retryable is True
        assert analysis.metadata.get("action") == "prune_context"

    def test_schema_error_detection(self):
        """Test detection of schema validation errors."""
        error = Exception("Schema validation failed: invalid JSON")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.SCHEMA_ERROR
        assert analysis.is_retryable is True
        assert analysis.metadata.get("action") == "fix_schema"

    def test_quota_exceeded_detection(self):
        """Test detection of quota exceeded errors."""
        error = Exception("Quota exceeded for this billing period")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.QUOTA_EXCEEDED
        assert analysis.is_retryable is False
        assert len(analysis.alternative_providers) > 0

    def test_retry_delay_extraction(self):
        """Test extraction of retry delay from error message."""
        error = Exception("Rate limit exceeded. Retry after 60 seconds")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.retry_delay_seconds == 60.0

    def test_unknown_error_handling(self):
        """Test handling of unknown error types."""
        error = Exception("Something completely unexpected happened")
        analysis = ErrorAnalyzer.analyze(error)

        assert analysis.category == ErrorCategory.UNKNOWN
        assert analysis.is_retryable is True  # Try anyway
        assert analysis.max_retries <= 2  # But not too many times


class TestErrorRecoveryManager:
    """Test error recovery manager functionality."""

    @pytest.mark.asyncio
    async def test_successful_execution_no_retry(self):
        """Test that successful operations don't trigger retries."""
        manager = ErrorRecoveryManager()
        call_count = 0

        async def successful_operation():
            nonlocal call_count
            call_count += 1
            return "success"

        result = await manager.execute_with_recovery(successful_operation)

        assert result == "success"
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_retry_on_retryable_error(self):
        """Test automatic retry on retryable errors."""
        manager = ErrorRecoveryManager()
        call_count = 0

        async def flaky_operation():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise Exception("Network timeout")
            return "success"

        result = await manager.execute_with_recovery(flaky_operation)

        assert result == "success"
        assert call_count == 3
        assert len(manager.recovery_history) == 2  # 2 failures before success

    @pytest.mark.asyncio
    async def test_no_retry_on_non_retryable_error(self):
        """Test that non-retryable errors fail immediately."""
        manager = ErrorRecoveryManager()
        call_count = 0

        async def failing_operation():
            nonlocal call_count
            call_count += 1
            raise Exception("401 Unauthorized: Invalid API key")

        with pytest.raises(Exception) as exc_info:
            await manager.execute_with_recovery(failing_operation)

        assert "unauthorized" in str(exc_info.value).lower()
        assert call_count == 1  # No retries

    @pytest.mark.asyncio
    async def test_max_retries_exhausted(self):
        """Test that retries stop after max attempts."""
        manager = ErrorRecoveryManager(max_recovery_attempts=2)
        call_count = 0

        async def always_failing_operation():
            nonlocal call_count
            call_count += 1
            raise Exception("Network timeout")

        with pytest.raises(Exception):
            await manager.execute_with_recovery(always_failing_operation)

        assert call_count == 2  # Initial + 1 retry

    @pytest.mark.asyncio
    async def test_error_callback(self):
        """Test that error callback is invoked."""
        manager = ErrorRecoveryManager()
        errors_seen = []

        def on_error(analysis: ErrorAnalysis):
            errors_seen.append(analysis)

        async def failing_once():
            if len(errors_seen) == 0:
                raise Exception("Network timeout")
            return "success"

        result = await manager.execute_with_recovery(failing_once, on_error=on_error)

        assert result == "success"
        assert len(errors_seen) == 1
        assert errors_seen[0].category == ErrorCategory.NETWORK_ERROR

    @pytest.mark.asyncio
    async def test_exponential_backoff(self):
        """Test that retry delays increase exponentially."""
        manager = ErrorRecoveryManager()
        start_time = asyncio.get_event_loop().time()
        call_count = 0

        async def failing_operation():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise Exception("Rate limit exceeded")
            return "success"

        await manager.execute_with_recovery(failing_operation)

        # Verify exponential backoff occurred (takes time)
        elapsed = asyncio.get_event_loop().time() - start_time
        assert elapsed > 5.0  # At least 5 seconds for 2 retries with backoff

    @pytest.mark.asyncio
    async def test_recovery_disabled(self):
        """Test that recovery can be disabled."""
        manager = ErrorRecoveryManager(enable_auto_recovery=False)
        call_count = 0

        async def failing_operation():
            nonlocal call_count
            call_count += 1
            raise Exception("Network timeout")

        with pytest.raises(Exception):
            await manager.execute_with_recovery(failing_operation)

        assert call_count == 1  # No retries when disabled

    def test_recovery_stats(self):
        """Test recovery statistics tracking."""
        manager = ErrorRecoveryManager()

        # Simulate some errors
        manager.recovery_history.extend(
            [
                ErrorAnalysis(
                    category=ErrorCategory.RATE_LIMIT,
                    original_error=Exception("rate limit"),
                    error_message="rate limit",
                    is_retryable=True,
                ),
                ErrorAnalysis(
                    category=ErrorCategory.NETWORK_ERROR,
                    original_error=Exception("network"),
                    error_message="network",
                    is_retryable=True,
                ),
                ErrorAnalysis(
                    category=ErrorCategory.AUTH_ERROR,
                    original_error=Exception("auth"),
                    error_message="auth",
                    is_retryable=False,
                ),
            ]
        )

        stats = manager.get_recovery_stats()

        assert stats["total_errors"] == 3
        assert stats["retryable"] == 2
        assert "rate_limit" in stats["by_category"]
        assert "network_error" in stats["by_category"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
