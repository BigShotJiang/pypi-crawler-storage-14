"""
Alpha Zero 2 - Multi-Agent Competitive RL Framework

A competitive reinforcement learning framework where autonomous agents
compete on code optimization tasks while recursively improving their
own implementations.

Principal Investigator: Bo Shang
Framework: erosolar-cli

Structure:
- Core RL: competitive_framework, reward_system, tournament, metrics
- Self-Improvement: self_modification, introspection
- Security (optional): security/ submodule

Citation:
    @software{alpha_zero_2,
      title={Alpha Zero 2: Recursive Self-Improvement in Competitive Multi-Agent Systems},
      author={Bo Shang},
      year={2024},
      framework={erosolar_cli}
    }
"""

# Core RL Framework
from .competitive_framework import CompetitiveFramework, AgentConfig, CompetitionHistory
from .reward_system import RewardSystem, CompetitionMetrics
from .tournament import (
    TournamentRunner,
    TournamentConfig,
    TournamentResult,
    TournamentStatus,
    TournamentCallbacks,
    VerboseCallbacks,
    run_simple_tournament,
)
from .metrics import (
    MetricsDashboard,
    AgentMetrics,
    TournamentMetrics,
    CodeEvolutionTracker,
    CodeEvolutionMetrics,
)

# Self-Improvement Components
from .self_modification import SelfModificationEngine, ModificationResult, ToolVersion

# Agent Wrapper
from .provider_adapter import AlphaZeroAgentWrapper
from .introspection import (
    IntrospectionEngine,
    ExecutionTrace,
    PerformanceProfile,
    CodeAnalysis,
    ImprovementSuggestion,
)

# Research Metadata
from .research_metadata import (
    ALPHA_ZERO_2,
    BO_SHANG,
    EROSOLAR_TECH_STACK,
    ResearcherProfile,
    ResearchProject,
    TechStackComponent,
    get_project_summary,
    get_research_citation,
)

# Security module (optional, loaded on demand)
_security_module = None


def is_security_enabled() -> bool:
    """Check if security research module is available."""
    global _security_module
    if _security_module is not None:
        return True
    try:
        from . import security as _sec
        _security_module = _sec
        return True
    except ImportError:
        return False


def get_security_module():
    """Get the security research module (lazy load)."""
    global _security_module
    if _security_module is None:
        from . import security as _sec
        _security_module = _sec
    return _security_module


# Lazy security imports for backward compatibility
def OffensiveResearchEngine(*args, **kwargs):
    """Create an offensive research engine (lazy load)."""
    mod = get_security_module()
    return mod.SecurityResearchEngine(*args, **kwargs)


def AuthorizationRecord(*args, **kwargs):
    """Create an authorization record (lazy load)."""
    mod = get_security_module()
    return mod.AuthorizationRecord(*args, **kwargs)


def AuthorizationScope(*args, **kwargs):
    """Get authorization scope enum (lazy load)."""
    mod = get_security_module()
    return mod.AuthorizationScope


def create_bug_bounty_authorization(*args, **kwargs):
    """Create bug bounty authorization (lazy load)."""
    mod = get_security_module()
    return mod.create_bug_bounty_authorization(*args, **kwargs)


def create_pentest_authorization(*args, **kwargs):
    """Create pentest authorization (lazy load)."""
    mod = get_security_module()
    return mod.create_pentest_authorization(*args, **kwargs)


# Attack simulation (lazy)
def AttackSimulator(*args, **kwargs):
    """Create attack simulator (lazy load)."""
    mod = get_security_module()
    return mod.AttackSimulator(*args, **kwargs)


def get_attack_vectors():
    """Get attack vectors (lazy load)."""
    mod = get_security_module()
    return mod.ATTACK_VECTORS


# Google security (optional, lazy)
def GooglePersistenceResearcher(*args, **kwargs):
    """Create Google persistence researcher (lazy load)."""
    mod = get_security_module()
    if hasattr(mod, 'GooglePersistenceResearcher'):
        return mod.GooglePersistenceResearcher(*args, **kwargs)
    raise ImportError("Google security module not available")


def create_google_authorization(*args, **kwargs):
    """Create Google authorization (lazy load)."""
    mod = get_security_module()
    if hasattr(mod, 'create_google_authorization'):
        return mod.create_google_authorization(*args, **kwargs)
    raise ImportError("Google security module not available")


__version__ = "1.0.0"
__author__ = "Bo Shang"
__framework__ = "erosolar_cli"

__all__ = [
    # Core RL Framework
    "CompetitiveFramework",
    "AgentConfig",
    "CompetitionHistory",
    "RewardSystem",
    "CompetitionMetrics",

    # Tournament
    "TournamentRunner",
    "TournamentConfig",
    "TournamentResult",
    "TournamentStatus",
    "TournamentCallbacks",
    "VerboseCallbacks",
    "run_simple_tournament",

    # Metrics
    "MetricsDashboard",
    "AgentMetrics",
    "TournamentMetrics",
    "CodeEvolutionTracker",
    "CodeEvolutionMetrics",

    # Self-Improvement
    "SelfModificationEngine",
    "ModificationResult",
    "ToolVersion",
    "AlphaZeroAgentWrapper",
    "IntrospectionEngine",
    "ExecutionTrace",
    "PerformanceProfile",
    "CodeAnalysis",
    "ImprovementSuggestion",

    # Research Metadata
    "ALPHA_ZERO_2",
    "BO_SHANG",
    "EROSOLAR_TECH_STACK",
    "ResearcherProfile",
    "ResearchProject",
    "TechStackComponent",
    "get_project_summary",
    "get_research_citation",

    # Security (lazy loaded)
    "is_security_enabled",
    "get_security_module",
    "OffensiveResearchEngine",
    "AuthorizationRecord",
    "AuthorizationScope",
    "create_bug_bounty_authorization",
    "create_pentest_authorization",
    "AttackSimulator",
    "get_attack_vectors",
    "GooglePersistenceResearcher",
    "create_google_authorization",
]
