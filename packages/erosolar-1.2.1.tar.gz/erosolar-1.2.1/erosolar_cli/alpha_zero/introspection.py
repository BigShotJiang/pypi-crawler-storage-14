"""
Introspection Engine for Alpha Zero 2

Provides runtime analysis capabilities for agents to understand
their own execution patterns and identify improvement opportunities.

This enables the recursive self-improvement loop described in Bo Shang's
Alpha Zero 2 research.
"""

from __future__ import annotations

import ast
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
from pathlib import Path
import json
import traceback


@dataclass
class ExecutionTrace:
    """Trace of a single execution."""

    timestamp: float
    function_name: str
    execution_time_ms: float
    success: bool
    error_message: Optional[str] = None
    input_summary: str = ""
    output_summary: str = ""
    memory_delta_kb: float = 0.0


@dataclass
class PerformanceProfile:
    """Performance profile for a function or tool."""

    name: str
    total_calls: int = 0
    total_time_ms: float = 0.0
    min_time_ms: float = float("inf")
    max_time_ms: float = 0.0
    error_count: int = 0
    success_rate: float = 1.0

    traces: list[ExecutionTrace] = field(default_factory=list)

    def add_trace(self, trace: ExecutionTrace) -> None:
        """Add a trace and update statistics."""
        self.traces.append(trace)
        self.total_calls += 1
        self.total_time_ms += trace.execution_time_ms
        self.min_time_ms = min(self.min_time_ms, trace.execution_time_ms)
        self.max_time_ms = max(self.max_time_ms, trace.execution_time_ms)

        if not trace.success:
            self.error_count += 1

        self.success_rate = (self.total_calls - self.error_count) / self.total_calls

    @property
    def avg_time_ms(self) -> float:
        """Average execution time."""
        return self.total_time_ms / self.total_calls if self.total_calls > 0 else 0.0


@dataclass
class CodeAnalysis:
    """Analysis of a Python code structure."""

    file_path: str
    num_functions: int = 0
    num_classes: int = 0
    num_imports: int = 0
    cyclomatic_complexity: int = 0
    lines_of_code: int = 0
    comment_ratio: float = 0.0
    has_type_hints: bool = False
    has_docstrings: bool = False
    syntax_validity: Optional[bool] = None
    potential_issues: list[str] = field(default_factory=list)


@dataclass
class ImprovementSuggestion:
    """Suggestion for code improvement."""

    category: str  # performance, quality, maintainability, correctness
    priority: str  # high, medium, low
    description: str
    affected_code: str
    suggested_change: str
    estimated_impact: str


class IntrospectionEngine:
    """
    Engine for runtime introspection and self-analysis.

    Enables agents to:
    - Profile their own execution
    - Analyze code quality
    - Identify improvement opportunities
    - Track performance over time
    """

    def __init__(
        self,
        data_dir: Optional[Path] = None,
        max_traces_per_profile: int = 100,
        verbose: bool = False,
    ):
        """
        Initialize introspection engine.

        Args:
            data_dir: Directory for storing introspection data
            max_traces_per_profile: Maximum traces to keep per function
            verbose: Enable verbose logging
        """
        self.data_dir = data_dir or Path(".alpha_zero_introspection")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.max_traces = max_traces_per_profile
        self.verbose = verbose

        self.profiles: dict[str, PerformanceProfile] = {}
        self._load_profiles()

    def profile_execution(
        self,
        func: Callable,
        *args,
        **kwargs,
    ) -> tuple[Any, ExecutionTrace]:
        """
        Profile execution of a function.

        Args:
            func: Function to execute and profile
            *args: Function arguments
            **kwargs: Function keyword arguments

        Returns:
            Tuple of (function result, execution trace)
        """
        func_name = func.__name__
        start_time = time.time()

        # Summarize inputs
        input_summary = self._summarize_args(args, kwargs)

        try:
            result = func(*args, **kwargs)
            success = True
            error_message = None
            output_summary = self._summarize_output(result)
        except Exception as e:
            result = None
            success = False
            error_message = f"{type(e).__name__}: {str(e)}"
            output_summary = ""

        execution_time = (time.time() - start_time) * 1000

        trace = ExecutionTrace(
            timestamp=time.time(),
            function_name=func_name,
            execution_time_ms=execution_time,
            success=success,
            error_message=error_message,
            input_summary=input_summary,
            output_summary=output_summary,
        )

        # Update profile
        if func_name not in self.profiles:
            self.profiles[func_name] = PerformanceProfile(name=func_name)
        self.profiles[func_name].add_trace(trace)

        # Trim old traces
        if len(self.profiles[func_name].traces) > self.max_traces:
            self.profiles[func_name].traces = self.profiles[func_name].traces[-self.max_traces:]

        if self.verbose:
            status = "SUCCESS" if success else "FAILED"
            print(f"[Introspection] {func_name}: {execution_time:.2f}ms [{status}]")

        return result, trace

    async def profile_async_execution(
        self,
        func: Callable,
        *args,
        **kwargs,
    ) -> tuple[Any, ExecutionTrace]:
        """
        Profile execution of an async function.

        Args:
            func: Async function to execute and profile
            *args: Function arguments
            **kwargs: Function keyword arguments

        Returns:
            Tuple of (function result, execution trace)
        """
        func_name = func.__name__
        start_time = time.time()

        input_summary = self._summarize_args(args, kwargs)

        try:
            result = await func(*args, **kwargs)
            success = True
            error_message = None
            output_summary = self._summarize_output(result)
        except Exception as e:
            result = None
            success = False
            error_message = f"{type(e).__name__}: {str(e)}"
            output_summary = ""

        execution_time = (time.time() - start_time) * 1000

        trace = ExecutionTrace(
            timestamp=time.time(),
            function_name=func_name,
            execution_time_ms=execution_time,
            success=success,
            error_message=error_message,
            input_summary=input_summary,
            output_summary=output_summary,
        )

        if func_name not in self.profiles:
            self.profiles[func_name] = PerformanceProfile(name=func_name)
        self.profiles[func_name].add_trace(trace)

        if len(self.profiles[func_name].traces) > self.max_traces:
            self.profiles[func_name].traces = self.profiles[func_name].traces[-self.max_traces:]

        if self.verbose:
            status = "SUCCESS" if success else "FAILED"
            print(f"[Introspection] {func_name}: {execution_time:.2f}ms [{status}]")

        return result, trace

    def analyze_code(self, code: str, file_path: str = "<unknown>") -> CodeAnalysis:
        """
        Analyze Python code structure.

        Args:
            code: Python source code
            file_path: Path to the file (for reporting)

        Returns:
            Code analysis results
        """
        analysis = CodeAnalysis(file_path=file_path)

        try:
            tree = ast.parse(code)

            # Count elements
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    analysis.num_functions += 1
                    if ast.get_docstring(node):
                        analysis.has_docstrings = True
                    # Check for type hints
                    if node.returns or any(arg.annotation for arg in node.args.args):
                        analysis.has_type_hints = True
                elif isinstance(node, ast.AsyncFunctionDef):
                    analysis.num_functions += 1
                    if ast.get_docstring(node):
                        analysis.has_docstrings = True
                    if node.returns or any(arg.annotation for arg in node.args.args):
                        analysis.has_type_hints = True
                elif isinstance(node, ast.ClassDef):
                    analysis.num_classes += 1
                    if ast.get_docstring(node):
                        analysis.has_docstrings = True
                elif isinstance(node, (ast.Import, ast.ImportFrom)):
                    analysis.num_imports += 1

            # Lines of code
            lines = code.splitlines()
            analysis.lines_of_code = len([l for l in lines if l.strip() and not l.strip().startswith("#")])

            # Comment ratio
            comment_lines = len([l for l in lines if l.strip().startswith("#")])
            total_lines = len([l for l in lines if l.strip()])
            analysis.comment_ratio = comment_lines / total_lines if total_lines > 0 else 0.0

            # Cyclomatic complexity (simplified)
            analysis.cyclomatic_complexity = self._calculate_complexity(tree)

            # Check for potential issues
            analysis.potential_issues = self._find_code_issues(tree, code)

        except SyntaxError as e:
            analysis.potential_issues.append(f"Syntax error: {e}")
        except Exception as e:
            analysis.potential_issues.append(f"Analysis error: {e}")

        return analysis

    def _calculate_complexity(self, tree: ast.AST) -> int:
        """Calculate cyclomatic complexity."""
        complexity = 1  # Base complexity

        for node in ast.walk(tree):
            # Each branch point increases complexity
            if isinstance(node, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(node, ast.BoolOp):
                complexity += len(node.values) - 1
            elif isinstance(node, ast.comprehension):
                complexity += 1
                if node.ifs:
                    complexity += len(node.ifs)

        return complexity

    def _find_code_issues(self, tree: ast.AST, code: str) -> list[str]:
        """Find potential code issues."""
        issues = []

        # Check for deeply nested loops
        max_loop_depth = self._max_loop_depth(tree)
        if max_loop_depth > 3:
            issues.append(f"Deeply nested loops (depth: {max_loop_depth})")

        # Check for bare except
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler) and node.type is None:
                issues.append("Bare except clause detected")

        # Check for mutable default arguments
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for default in node.args.defaults:
                    if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                        issues.append(f"Mutable default argument in {node.name}")

        # Check for unused imports (simplified)
        imports = set()
        used_names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.add(alias.asname or alias.name)
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    imports.add(alias.asname or alias.name)
            elif isinstance(node, ast.Name):
                used_names.add(node.id)

        unused = imports - used_names
        if unused:
            issues.append(f"Potentially unused imports: {', '.join(sorted(unused))}")

        return issues

    def _max_loop_depth(self, tree: ast.AST) -> int:
        """Calculate maximum loop nesting depth."""
        max_depth = 0

        def count_depth(node: ast.AST, depth: int = 0) -> None:
            nonlocal max_depth
            if isinstance(node, (ast.For, ast.While)):
                depth += 1
                max_depth = max(max_depth, depth)

            for child in ast.iter_child_nodes(node):
                count_depth(child, depth)

        count_depth(tree)
        return max_depth

    def generate_suggestions(
        self,
        code_analysis: CodeAnalysis,
        performance_profile: Optional[PerformanceProfile] = None,
    ) -> list[ImprovementSuggestion]:
        """
        Generate improvement suggestions based on analysis.

        Args:
            code_analysis: Code analysis results
            performance_profile: Optional performance profile

        Returns:
            List of improvement suggestions
        """
        suggestions = []

        # Performance suggestions
        if performance_profile:
            if performance_profile.avg_time_ms > 1000:
                suggestions.append(ImprovementSuggestion(
                    category="performance",
                    priority="high",
                    description="Function execution time is high",
                    affected_code=performance_profile.name,
                    suggested_change="Consider adding caching or optimizing the algorithm",
                    estimated_impact="Could reduce execution time by 50%+",
                ))

            if performance_profile.success_rate < 0.95:
                suggestions.append(ImprovementSuggestion(
                    category="correctness",
                    priority="high",
                    description=f"Function has {100 - performance_profile.success_rate * 100:.1f}% error rate",
                    affected_code=performance_profile.name,
                    suggested_change="Add error handling and input validation",
                    estimated_impact="Improve reliability",
                ))

        # Code quality suggestions
        if code_analysis.cyclomatic_complexity > 10:
            suggestions.append(ImprovementSuggestion(
                category="maintainability",
                priority="medium",
                description="High cyclomatic complexity",
                affected_code=code_analysis.file_path,
                suggested_change="Break down complex functions into smaller, focused functions",
                estimated_impact="Improved readability and testability",
            ))

        if not code_analysis.has_docstrings:
            suggestions.append(ImprovementSuggestion(
                category="quality",
                priority="low",
                description="Missing docstrings",
                affected_code=code_analysis.file_path,
                suggested_change="Add docstrings to functions and classes",
                estimated_impact="Better documentation",
            ))

        if not code_analysis.has_type_hints:
            suggestions.append(ImprovementSuggestion(
                category="quality",
                priority="low",
                description="Missing type hints",
                affected_code=code_analysis.file_path,
                suggested_change="Add type hints to function signatures",
                estimated_impact="Better IDE support and error detection",
            ))

        if code_analysis.comment_ratio < 0.1:
            suggestions.append(ImprovementSuggestion(
                category="quality",
                priority="low",
                description="Low comment ratio",
                affected_code=code_analysis.file_path,
                suggested_change="Add comments explaining complex logic",
                estimated_impact="Better maintainability",
            ))

        # Add suggestions from detected issues
        for issue in code_analysis.potential_issues:
            priority = "high" if "error" in issue.lower() else "medium"
            suggestions.append(ImprovementSuggestion(
                category="correctness",
                priority=priority,
                description=issue,
                affected_code=code_analysis.file_path,
                suggested_change="Review and fix the identified issue",
                estimated_impact="Improved code quality",
            ))

        return suggestions

    def get_profile(self, func_name: str) -> Optional[PerformanceProfile]:
        """Get performance profile for a function."""
        return self.profiles.get(func_name)

    def get_all_profiles(self) -> dict[str, PerformanceProfile]:
        """Get all performance profiles."""
        return self.profiles.copy()

    def save_profiles(self) -> None:
        """Save performance profiles to disk."""
        data = {}
        for name, profile in self.profiles.items():
            data[name] = {
                "name": profile.name,
                "total_calls": profile.total_calls,
                "total_time_ms": profile.total_time_ms,
                "min_time_ms": profile.min_time_ms,
                "max_time_ms": profile.max_time_ms,
                "error_count": profile.error_count,
                "success_rate": profile.success_rate,
                "recent_traces": [
                    {
                        "timestamp": t.timestamp,
                        "execution_time_ms": t.execution_time_ms,
                        "success": t.success,
                        "error_message": t.error_message,
                    }
                    for t in profile.traces[-10:]  # Keep last 10 traces
                ],
            }

        profile_file = self.data_dir / "performance_profiles.json"
        with open(profile_file, "w") as f:
            json.dump(data, f, indent=2)

    def _load_profiles(self) -> None:
        """Load performance profiles from disk."""
        profile_file = self.data_dir / "performance_profiles.json"
        if not profile_file.exists():
            return

        try:
            with open(profile_file) as f:
                data = json.load(f)

            for name, profile_data in data.items():
                profile = PerformanceProfile(
                    name=profile_data["name"],
                    total_calls=profile_data["total_calls"],
                    total_time_ms=profile_data["total_time_ms"],
                    min_time_ms=profile_data.get("min_time_ms", float("inf")),
                    max_time_ms=profile_data.get("max_time_ms", 0.0),
                    error_count=profile_data["error_count"],
                    success_rate=profile_data["success_rate"],
                )
                self.profiles[name] = profile

        except Exception as e:
            if self.verbose:
                print(f"Error loading profiles: {e}")

    def _summarize_args(self, args: tuple, kwargs: dict) -> str:
        """Summarize function arguments."""
        parts = []
        for arg in args:
            parts.append(self._summarize_value(arg))
        for key, value in kwargs.items():
            parts.append(f"{key}={self._summarize_value(value)}")
        return ", ".join(parts)[:200]

    def _summarize_value(self, value: Any) -> str:
        """Summarize a single value."""
        if isinstance(value, str):
            return f"str({len(value)})" if len(value) > 50 else repr(value)
        elif isinstance(value, (list, tuple)):
            return f"{type(value).__name__}({len(value)})"
        elif isinstance(value, dict):
            return f"dict({len(value)})"
        else:
            return str(type(value).__name__)

    def _summarize_output(self, output: Any) -> str:
        """Summarize function output."""
        return self._summarize_value(output)

    def get_summary_report(self) -> str:
        """Generate a summary report of all profiles."""
        if not self.profiles:
            return "No execution data collected yet."

        lines = ["Performance Summary", "=" * 40]

        for name, profile in sorted(self.profiles.items(), key=lambda x: x[1].total_time_ms, reverse=True):
            lines.append(f"\n{name}:")
            lines.append(f"  Calls: {profile.total_calls}")
            lines.append(f"  Avg Time: {profile.avg_time_ms:.2f}ms")
            lines.append(f"  Min/Max: {profile.min_time_ms:.2f}ms / {profile.max_time_ms:.2f}ms")
            lines.append(f"  Success Rate: {profile.success_rate:.1%}")
            if profile.error_count > 0:
                lines.append(f"  Errors: {profile.error_count}")

        return "\n".join(lines)
