"""
Grep tools for powerful text search with regex support.

Features:
- Full regex syntax support
- Multiple output modes (content, files_with_matches, count)
- Context lines (-A, -B, -C)
- Case insensitivity
- Type and glob filtering
- Multiline matching
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from ..core.tool_runtime import ToolDefinition
from ..core.types import (
    JSONSchemaArray,
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
)


# Directories to ignore during search
IGNORED_DIRS = {
    ".git",
    "node_modules",
    "dist",
    ".next",
    "build",
    "coverage",
    ".turbo",
    ".cache",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
}


# File type mappings
FILE_TYPE_MAP = {
    "js": [".js", ".jsx", ".mjs", ".cjs"],
    "ts": [".ts", ".tsx"],
    "py": [".py", ".pyw"],
    "rust": [".rs"],
    "go": [".go"],
    "java": [".java"],
    "cpp": [".cpp", ".cc", ".cxx", ".hpp", ".h"],
    "c": [".c", ".h"],
    "ruby": [".rb"],
    "php": [".php"],
    "html": [".html", ".htm"],
    "css": [".css", ".scss", ".sass", ".less"],
    "json": [".json"],
    "yaml": [".yaml", ".yml"],
    "xml": [".xml"],
    "md": [".md", ".markdown"],
    "txt": [".txt"],
}


@dataclass
class SearchMatch:
    """A search result match."""

    file: Path
    line: int
    content: str
    match: str


def create_grep_tools(working_dir: str) -> list[ToolDefinition]:
    """
    Create grep search tool.

    Args:
        working_dir: Working directory for searching

    Returns:
        List containing the Grep tool definition
    """
    working_path = Path(working_dir).resolve()

    async def grep_handler(args: dict[str, Any]) -> str:
        try:
            # Extract parameters
            pattern = args.get("pattern", "")
            if not pattern or not isinstance(pattern, str) or not pattern.strip():
                return "Error: pattern must be a non-empty string."

            path_arg = args.get("path")
            output_mode = args.get("output_mode", "files_with_matches")
            case_insensitive = args.get("-i", False)
            show_line_numbers = args.get("-n", True)  # Default true
            after_context = args.get("-A", 0)
            before_context = args.get("-B", 0)
            context_lines = args.get("-C", 0)
            glob_pattern = args.get("glob")
            file_type = args.get("type")
            multiline = args.get("multiline", False)

            # Determine head_limit based on output mode
            default_limit = 20 if output_mode == "content" else (50 if output_mode == "count" else 30)
            head_limit = args.get("head_limit", default_limit)
            offset = args.get("offset", 0)

            # Validate output_mode
            if output_mode not in ("content", "files_with_matches", "count"):
                return 'Error: output_mode must be "content", "files_with_matches", or "count".'

            # Resolve search path
            if path_arg and isinstance(path_arg, str):
                search_path = _resolve_path(working_path, path_arg)
            else:
                search_path = working_path

            # Create regex with appropriate flags
            flags = re.IGNORECASE if case_insensitive else 0
            if multiline:
                flags |= re.DOTALL

            try:
                regex = re.compile(pattern, flags)
            except re.error as error:
                return f"Error: Invalid regex pattern: {error}"

            # Perform search
            matches = _search_files(
                search_path,
                regex,
                glob_pattern=glob_pattern if isinstance(glob_pattern, str) else None,
                file_type=file_type if isinstance(file_type, str) else None,
                multiline=multiline,
            )

            # Apply offset and head_limit
            total_matches = len(matches)
            filtered_matches = _apply_offset_and_limit(matches, offset, head_limit)
            truncated = total_matches > len(filtered_matches)

            # Format output based on mode
            if output_mode == "content":
                result = _format_content_output(
                    filtered_matches,
                    show_line_numbers=show_line_numbers,
                    before_context=context_lines or before_context,
                    after_context=context_lines or after_context,
                    search_path=search_path,
                    working_path=working_path,
                )
            elif output_mode == "count":
                result = _format_count_output(filtered_matches, working_path)
            else:  # files_with_matches
                result = _format_files_output(filtered_matches, working_path)

            # Add truncation notice
            if truncated:
                remaining = total_matches - len(filtered_matches)
                result += f"\n\n... [{remaining} more matches truncated. Use head_limit parameter to see more]"

            return result

        except Exception as error:
            return f"Error during grep search: {error}"

    return [
        ToolDefinition(
            name="Grep",
            description="A powerful search tool built on ripgrep patterns. Supports full regex syntax, multiple output modes, and context lines. Use for searching file contents.",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "pattern": JSONSchemaString(type="string",
                        description="The regular expression pattern to search for in file contents",
                    ),
                    "path": JSONSchemaString(type="string",
                        description="File or directory to search in (defaults to current working directory)",
                    ),
                    "output_mode": JSONSchemaString(type="string",
                        description='Output mode: "content" shows matching lines, "files_with_matches" shows file paths (default), "count" shows match counts',
                    ),
                    "-i": JSONSchemaBoolean(type="boolean",
                        description="Case insensitive search",
                    ),
                    "-n": JSONSchemaBoolean(type="boolean",
                        description='Show line numbers in output (requires output_mode: "content"). Defaults to true.',
                    ),
                    "-A": JSONSchemaNumber(type="number",
                        description='Number of lines to show after each match (requires output_mode: "content")',
                    ),
                    "-B": JSONSchemaNumber(type="number",
                        description='Number of lines to show before each match (requires output_mode: "content")',
                    ),
                    "-C": JSONSchemaNumber(type="number",
                        description='Number of lines to show before and after each match (requires output_mode: "content")',
                    ),
                    "glob": JSONSchemaString(type="string",
                        description='Glob pattern to filter files (e.g. "*.js", "*.{ts,tsx}")',
                    ),
                    "type": JSONSchemaString(type="string",
                        description='File type to search (e.g. "js", "py", "rust", "go")',
                    ),
                    "multiline": JSONSchemaBoolean(type="boolean",
                        description="Enable multiline mode where . matches newlines. Default: false.",
                    ),
                    "head_limit": JSONSchemaNumber(type="number",
                        description="Limit output to first N entries. Defaults: content=20, files=30, count=50.",
                    ),
                    "offset": JSONSchemaNumber(type="number",
                        description="Skip first N lines/entries before applying head_limit. Defaults to 0.",
                    ),
                },
                required=["pattern"],
                additional_properties=False,
            ),
            handler=grep_handler,
            cacheable=True,
        )
    ]


def _resolve_path(working_dir: Path, path: str) -> Path:
    """Resolve a path relative to working directory."""
    path_str = path.strip()
    if os.path.isabs(path_str):
        return Path(path_str)
    return (working_dir / path_str).resolve()


def _search_files(
    search_path: Path,
    regex: re.Pattern,
    glob_pattern: Optional[str] = None,
    file_type: Optional[str] = None,
    multiline: bool = False,
) -> list[SearchMatch]:
    """
    Search files for regex matches.

    Args:
        search_path: Path to search in
        regex: Compiled regex pattern
        glob_pattern: Optional glob filter
        file_type: Optional file type filter
        multiline: Whether to use multiline mode

    Returns:
        List of search matches
    """
    results: list[SearchMatch] = []

    def search(current_path: Path) -> None:
        try:
            if current_path.is_dir():
                for entry in current_path.iterdir():
                    if entry.name in IGNORED_DIRS:
                        continue
                    search(entry)
            elif current_path.is_file():
                # Filter by file type
                if file_type and not _matches_file_type(current_path, file_type):
                    return

                # Filter by glob pattern
                if glob_pattern and not _matches_glob(current_path, glob_pattern):
                    return

                # Skip binary files
                if _is_binary_file(current_path):
                    return

                # Read and search file
                try:
                    content = current_path.read_text(encoding="utf-8")

                    if multiline:
                        # Multiline mode: search entire content
                        for match_obj in regex.finditer(content):
                            results.append(
                                SearchMatch(
                                    file=current_path,
                                    line=1,  # Line numbers are approximate in multiline
                                    content=match_obj.group(),
                                    match=match_obj.group(),
                                )
                            )
                    else:
                        # Line-by-line mode
                        lines = content.split("\n")
                        for line_num, line in enumerate(lines, start=1):
                            match_obj = regex.search(line)
                            if match_obj:
                                results.append(
                                    SearchMatch(
                                        file=current_path,
                                        line=line_num,
                                        content=line,
                                        match=match_obj.group(),
                                    )
                                )
                except (UnicodeDecodeError, OSError):
                    # Skip files that can't be read
                    pass
        except (PermissionError, OSError):
            # Silently ignore permission errors
            pass

    search(search_path)
    return results


def _apply_offset_and_limit(matches: list[SearchMatch], offset: int, head_limit: int) -> list[SearchMatch]:
    """Apply offset and head limit to matches."""
    result = matches

    if offset > 0:
        result = result[offset:]

    if head_limit > 0:
        result = result[:head_limit]

    return result


def _format_content_output(
    matches: list[SearchMatch],
    show_line_numbers: bool,
    before_context: int,
    after_context: int,
    search_path: Path,
    working_path: Path,
) -> str:
    """Format matches as content with line numbers."""
    if not matches:
        return "No matches found."

    lines = []
    for match in matches:
        try:
            rel_path = match.file.relative_to(working_path)
            display_path = str(rel_path)
        except ValueError:
            display_path = str(match.file)

        if show_line_numbers:
            lines.append(f"{display_path}:{match.line}:{match.content}")
        else:
            lines.append(f"{display_path}:{match.content}")

    return "\n".join(lines)


def _format_files_output(matches: list[SearchMatch], working_path: Path) -> str:
    """Format matches as list of unique file paths."""
    if not matches:
        return "No matches found."

    # Get unique file paths
    unique_files = list({match.file for match in matches})

    relative_paths = []
    for file_path in unique_files:
        try:
            rel_path = file_path.relative_to(working_path)
            relative_paths.append(str(rel_path))
        except ValueError:
            relative_paths.append(str(file_path))

    return "\n".join(relative_paths)


def _format_count_output(matches: list[SearchMatch], working_path: Path) -> str:
    """Format matches as counts per file."""
    if not matches:
        return "No matches found."

    # Count matches per file
    counts: dict[Path, int] = {}
    for match in matches:
        counts[match.file] = counts.get(match.file, 0) + 1

    lines = []
    for file_path, count in counts.items():
        try:
            rel_path = file_path.relative_to(working_path)
            display_path = str(rel_path)
        except ValueError:
            display_path = str(file_path)
        lines.append(f"{count}:{display_path}")

    return "\n".join(lines)


def _matches_file_type(file_path: Path, file_type: str) -> bool:
    """Check if file matches the specified type."""
    extensions = FILE_TYPE_MAP.get(file_type.lower(), [])
    return file_path.suffix.lower() in extensions


def _matches_glob(file_path: Path, glob_pattern: str) -> bool:
    """Check if file matches glob pattern."""
    # Simple glob matching using fnmatch
    import fnmatch

    return fnmatch.fnmatch(str(file_path), f"*{glob_pattern}")


def _is_binary_file(file_path: Path) -> bool:
    """Check if file is likely binary."""
    try:
        # Read first 8KB to check for null bytes
        with open(file_path, "rb") as f:
            chunk = f.read(8192)
            return b"\x00" in chunk
    except Exception:
        return True  # Assume binary if we can't read it
