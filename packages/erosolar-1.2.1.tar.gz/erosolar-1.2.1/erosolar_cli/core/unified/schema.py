"""
Unified Schema Loader and Validator

Provides cached loading of the unified schema and validation utilities.
Single source of truth for all schema operations.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .types import (
    JSONSchemaObject,
    JSONSchemaProperty,
    ProviderCapability,
    ProviderConfig,
    ProviderId,
    RateLimitConfig,
    SchemaToolDefinition,
    TaskTypeConfig,
    TaskTypeId,
    ToolCategoryConfig,
    UnifiedSchema,
)

# ============================================================================
# Schema Cache
# ============================================================================

_schema_cache: Optional[UnifiedSchema] = None
_schema_cache_time: float = 0
CACHE_TTL_MS = 60 * 1000  # 1 minute


def _find_schema_path() -> Optional[Path]:
    """Find the unified schema file, returns None if not found."""
    # Try multiple possible locations
    possible_paths = [
        # Python package's own contracts directory (installed package)
        Path(__file__).parent.parent.parent / "contracts" / "unified-schema.json",
        # User's erosolar config directory
        Path.home() / ".erosolar" / "contracts" / "unified-schema.json",
        # Monorepo src/contracts (development)
        Path(__file__).parent.parent.parent.parent.parent / "src" / "contracts" / "unified-schema.json",
        Path.cwd() / "src" / "contracts" / "unified-schema.json",
        Path.cwd().parent / "src" / "contracts" / "unified-schema.json",
        # Development fallback
        Path.cwd() / "erosolar_cli" / "contracts" / "unified-schema.json",
        Path.cwd() / "python-bo-cli" / "erosolar_cli" / "contracts" / "unified-schema.json",
    ]

    for path in possible_paths:
        if path.exists():
            return path

    return None  # Schema not found - will use defaults


def load_unified_schema(force_reload: bool = False) -> UnifiedSchema:
    """Load the unified schema with caching. Returns default schema if file not found."""
    global _schema_cache, _schema_cache_time

    now = time.time() * 1000  # Convert to milliseconds

    if not force_reload and _schema_cache and (now - _schema_cache_time) < CACHE_TTL_MS:
        return _schema_cache

    schema_path = _find_schema_path()

    if schema_path is None:
        # Return a minimal default schema when file not found
        _schema_cache = _create_default_schema()
        _schema_cache_time = now
        return _schema_cache

    with open(schema_path, "r") as f:
        data = json.load(f)

    _schema_cache = _parse_schema(data)
    _schema_cache_time = now

    return _schema_cache


def _create_default_schema() -> UnifiedSchema:
    """Create a minimal default schema for when the file is not found."""
    return UnifiedSchema(
        contract_version="1.0.0",
        version="1.2.0",
        label="Erosolar CLI",
        description="Unified AI Agent Framework",
        providers=[
            ProviderConfig(
                id=ProviderId.OPENAI,
                label="OpenAI",
                models=["gpt-4o", "gpt-4-turbo", "gpt-4o-mini"],
                default_model="gpt-4o",
                rate_limits=RateLimitConfig(requests_per_minute=60, tokens_per_minute=100000),
                capabilities=[ProviderCapability.TEXT_GENERATION, ProviderCapability.TOOL_USE],
            ),
            ProviderConfig(
                id=ProviderId.DEEPSEEK,
                label="DeepSeek",
                models=["deepseek-chat", "deepseek-reasoner"],
                default_model="deepseek-chat",
                rate_limits=RateLimitConfig(requests_per_minute=60, tokens_per_minute=100000),
                capabilities=[ProviderCapability.TEXT_GENERATION, ProviderCapability.TOOL_USE],
                openai_compatible=True,
            ),
            ProviderConfig(
                id=ProviderId.GOOGLE,
                label="Google",
                models=["gemini-2.0-flash-exp", "gemini-1.5-pro"],
                default_model="gemini-2.0-flash-exp",
                rate_limits=RateLimitConfig(requests_per_minute=60, tokens_per_minute=100000),
                capabilities=[ProviderCapability.TEXT_GENERATION, ProviderCapability.TOOL_USE],
            ),
        ],
        task_types=[],
        tool_categories=[],
        tools=[],
    )


def _parse_schema(data: Dict[str, Any]) -> UnifiedSchema:
    """Parse raw JSON into UnifiedSchema."""
    providers = [_parse_provider(p) for p in data.get("providers", [])]
    task_types = [_parse_task_type(t) for t in data.get("taskTypes", [])]
    tool_categories = [_parse_tool_category(c) for c in data.get("toolCategories", [])]
    tools = [_parse_tool(t) for t in data.get("tools", [])]

    return UnifiedSchema(
        contract_version=data.get("contractVersion", "1.0.0"),
        version=data.get("version", ""),
        label=data.get("label", ""),
        description=data.get("description", ""),
        providers=providers,
        task_types=task_types,
        tool_categories=tool_categories,
        tools=tools,
        defaults=data.get("defaults", {}),
        metadata=data.get("metadata", {}),
    )


def _parse_provider(data: Dict[str, Any]) -> ProviderConfig:
    """Parse provider configuration."""
    rate_limit = None
    if "rateLimiting" in data:
        rl = data["rateLimiting"]
        rate_limit = RateLimitConfig(
            max_retries=rl.get("maxRetries", 4),
            base_delay_ms=rl.get("baseDelayMs", 750),
            max_delay_ms=rl.get("maxDelayMs", 40000),
            backoff_multiplier=rl.get("backoffMultiplier", 2.0),
        )

    return ProviderConfig(
        id=data["id"],
        label=data["label"],
        description=data.get("description"),
        base_url=data.get("baseUrl"),
        api_version=data.get("apiVersion"),
        env_vars=data.get("envVars", {}),
        capabilities=data.get("capabilities", []),
        models=data.get("models", []),
        default_model=data.get("defaultModel", ""),
        reasoning_models=data.get("reasoningModels"),
        openai_compatible=data.get("openaiCompatible", False),
        status=data.get("status", "production"),
        rate_limiting=rate_limit,
    )


def _parse_task_type(data: Dict[str, Any]) -> TaskTypeConfig:
    """Parse task type configuration."""
    return TaskTypeConfig(
        id=data["id"],
        label=data["label"],
        description=data["description"],
        required_capabilities=data.get("requiredCapabilities", []),
        preferred_capabilities=data.get("preferredCapabilities", []),
        default_temperature=data.get("defaultTemperature", 0.0),
        recommended_providers=data.get("recommendedProviders", []),
        tools=data.get("tools", []),
        requires_auth=data.get("requiresAuth", False),
    )


def _parse_tool_category(data: Dict[str, Any]) -> ToolCategoryConfig:
    """Parse tool category configuration."""
    return ToolCategoryConfig(
        id=data["id"],
        label=data["label"],
        description=data["description"],
        always_enabled=data.get("alwaysEnabled", False),
        requires_auth=data.get("requiresAuth", False),
        tools=data.get("tools", []),
    )


def _parse_tool(data: Dict[str, Any]) -> SchemaToolDefinition:
    """Parse tool definition."""
    return SchemaToolDefinition(
        id=data["id"],
        name=data["name"],
        description=data["description"],
        category=data["category"],
        cacheable=data.get("cacheable", False),
        requires_auth=data.get("requiresAuth", False),
        parameters=data.get("parameters"),
    )


def clear_schema_cache() -> None:
    """Clear the schema cache."""
    global _schema_cache, _schema_cache_time
    _schema_cache = None
    _schema_cache_time = 0


# ============================================================================
# Provider Lookups
# ============================================================================

def get_provider_config(provider_id: ProviderId) -> Optional[ProviderConfig]:
    """Get provider configuration by ID."""
    schema = load_unified_schema()
    for provider in schema.providers:
        if provider.id == provider_id:
            return provider
    return None


def get_all_providers() -> List[ProviderConfig]:
    """Get all available providers."""
    return load_unified_schema().providers


def get_providers_with_capabilities(
    required: List[ProviderCapability],
    preferred: Optional[List[ProviderCapability]] = None
) -> List[ProviderConfig]:
    """Get providers with specific capabilities."""
    schema = load_unified_schema()
    preferred = preferred or []

    matching = [
        p for p in schema.providers
        if all(cap in p.capabilities for cap in required)
    ]

    # Sort by preferred capabilities matched (descending)
    matching.sort(
        key=lambda p: sum(1 for cap in preferred if cap in p.capabilities),
        reverse=True
    )

    return matching


def get_recommended_providers(task_type: TaskTypeId) -> List[ProviderConfig]:
    """Get recommended providers for a task type."""
    schema = load_unified_schema()
    task_config = get_task_type_config(task_type)

    if not task_config:
        return []

    return [
        p for p in schema.providers
        if p.id in task_config.recommended_providers
    ]


# ============================================================================
# Task Type Lookups
# ============================================================================

def get_task_type_config(task_type_id: TaskTypeId) -> Optional[TaskTypeConfig]:
    """Get task type configuration."""
    schema = load_unified_schema()
    for task_type in schema.task_types:
        if task_type.id == task_type_id:
            return task_type
    return None


def get_all_task_types() -> List[TaskTypeConfig]:
    """Get all task types."""
    return load_unified_schema().task_types


def infer_task_type(prompt: str) -> TaskTypeId:
    """Determine best task type for a given prompt."""
    prompt_lower = prompt.lower()

    if any(kw in prompt_lower for kw in ["security", "vulnerability", "audit"]):
        return "security"
    if any(kw in prompt_lower for kw in ["test", "spec"]):
        return "testing"
    if any(kw in prompt_lower for kw in ["document", "readme"]):
        return "documentation"
    if any(kw in prompt_lower for kw in ["search", "find information"]):
        return "research"
    if any(kw in prompt_lower for kw in ["image", "screenshot"]):
        return "multimodal"
    if any(kw in prompt_lower for kw in ["analyze", "review", "complexity"]):
        return "analysis"
    if any(kw in prompt_lower for kw in ["think", "reason", "plan"]):
        return "reasoning"
    if any(kw in prompt_lower for kw in ["code", "function", "implement", "fix", "refactor"]):
        return "coding"

    return "chat"


# ============================================================================
# Tool Lookups
# ============================================================================

def get_tool_definition(tool_id: str) -> Optional[SchemaToolDefinition]:
    """Get tool definition by ID."""
    schema = load_unified_schema()
    for tool in schema.tools:
        if tool.id == tool_id:
            return tool
    return None


def get_tools_by_category(category_id: str) -> List[SchemaToolDefinition]:
    """Get all tools in a category."""
    schema = load_unified_schema()
    return [t for t in schema.tools if t.category == category_id]


def get_tool_category(category_id: str) -> Optional[ToolCategoryConfig]:
    """Get tool category configuration."""
    schema = load_unified_schema()
    for category in schema.tool_categories:
        if category.id == category_id:
            return category
    return None


def get_enabled_tools(enabled_categories: Optional[List[str]] = None) -> List[SchemaToolDefinition]:
    """Get all enabled tools."""
    schema = load_unified_schema()
    enabled_categories = enabled_categories or []

    enabled_category_ids = set(
        c.id for c in schema.tool_categories if c.always_enabled
    ) | set(enabled_categories)

    return [t for t in schema.tools if t.category in enabled_category_ids]


def tool_requires_auth(tool_id: str) -> bool:
    """Check if a tool requires authentication."""
    tool = get_tool_definition(tool_id)
    if not tool:
        return False

    if tool.requires_auth:
        return True

    category = get_tool_category(tool.category)
    return category.requires_auth if category else False


# ============================================================================
# Schema Validation
# ============================================================================

class ToolArgumentValidationError(Exception):
    """Validation error for tool arguments."""

    def __init__(self, tool_name: str, field: str, reason: str, value: Any = None):
        self.tool_name = tool_name
        self.field = field
        self.reason = reason
        self.value = value
        super().__init__(f"Tool {tool_name}: {field} - {reason}")


def validate_tool_arguments(
    tool_name: str,
    schema: Optional[Any],
    args: Dict[str, Any]
) -> None:
    """Validate tool arguments against schema."""
    if not schema:
        return

    # Handle both dict and dataclass schemas
    if isinstance(schema, dict):
        required = schema.get("required", [])
        properties = schema.get("properties", {})
        additional_props = schema.get("additionalProperties", True)
    else:
        # Dataclass (JSONSchemaObject)
        required = getattr(schema, "required", None) or []
        properties = getattr(schema, "properties", None) or {}
        additional_props = getattr(schema, "additional_properties", True)
        if additional_props is None:
            additional_props = True

    # Check required fields
    for field in required:
        if field not in args or args[field] is None:
            raise ToolArgumentValidationError(tool_name, field, "Required field is missing")

    # Validate each property
    for field, value in args.items():
        if field not in properties:
            if not additional_props:
                raise ToolArgumentValidationError(tool_name, field, "Unknown field")
            continue

        prop_schema = properties[field]
        # Convert dataclass property to dict if needed
        if not isinstance(prop_schema, dict):
            prop_dict = {
                "type": getattr(prop_schema, "type", None),
                "enum": getattr(prop_schema, "enum", None),
                "description": getattr(prop_schema, "description", None),
            }
        else:
            prop_dict = prop_schema
        _validate_property(tool_name, field, prop_dict, value)


def _validate_property(
    tool_name: str,
    field: str,
    schema: Dict[str, Any],
    value: Any
) -> None:
    """Validate a single property."""
    if value is None:
        return  # Required check is done separately

    expected_type = schema.get("type")
    if expected_type:
        types = expected_type if isinstance(expected_type, list) else [expected_type]
        actual_type = _get_value_type(value)

        if actual_type not in types and not (actual_type == "integer" and "number" in types):
            raise ToolArgumentValidationError(
                tool_name, field,
                f"Expected {' | '.join(types)}, got {actual_type}",
                value
            )

    # Enum validation
    enum = schema.get("enum")
    if enum and value not in enum:
        raise ToolArgumentValidationError(
            tool_name, field,
            f"Value must be one of: {', '.join(str(e) for e in enum)}",
            value
        )

    # String validations
    if isinstance(value, str):
        min_length = schema.get("minLength")
        if min_length and len(value) < min_length:
            raise ToolArgumentValidationError(
                tool_name, field,
                f"String length must be at least {min_length}",
                value
            )

        max_length = schema.get("maxLength")
        if max_length and len(value) > max_length:
            raise ToolArgumentValidationError(
                tool_name, field,
                f"String length must be at most {max_length}",
                value
            )

        pattern = schema.get("pattern")
        if pattern and not re.match(pattern, value):
            raise ToolArgumentValidationError(
                tool_name, field,
                f"String must match pattern: {pattern}",
                value
            )

    # Number validations
    if isinstance(value, (int, float)):
        minimum = schema.get("minimum")
        if minimum is not None and value < minimum:
            raise ToolArgumentValidationError(
                tool_name, field,
                f"Value must be at least {minimum}",
                value
            )

        maximum = schema.get("maximum")
        if maximum is not None and value > maximum:
            raise ToolArgumentValidationError(
                tool_name, field,
                f"Value must be at most {maximum}",
                value
            )

    # Array validations
    if isinstance(value, list) and "items" in schema:
        for i, item in enumerate(value):
            _validate_property(tool_name, f"{field}[{i}]", schema["items"], item)

    # Object validations
    if isinstance(value, dict) and "properties" in schema:
        for key, val in value.items():
            if key in schema["properties"]:
                _validate_property(tool_name, f"{field}.{key}", schema["properties"][key], val)


def _get_value_type(value: Any) -> str:
    """Get the JSON Schema type of a value."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "unknown"


# ============================================================================
# Schema Utilities
# ============================================================================

def get_schema_defaults() -> Dict[str, Any]:
    """Get schema defaults."""
    return load_unified_schema().defaults


def get_schema_metadata() -> Dict[str, Any]:
    """Get schema metadata."""
    return load_unified_schema().metadata


def get_schema_version() -> str:
    """Get schema version."""
    return load_unified_schema().contract_version


def provider_supports_capability(
    provider_id: ProviderId,
    capability: ProviderCapability
) -> bool:
    """Check if provider supports a capability."""
    provider = get_provider_config(provider_id)
    return capability in provider.capabilities if provider else False


def select_best_provider(
    required: List[ProviderCapability],
    preferred: Optional[List[ProviderCapability]] = None
) -> Optional[ProviderConfig]:
    """Get best provider for capabilities."""
    providers = get_providers_with_capabilities(required, preferred)
    return providers[0] if providers else None
