"""
Unified Tool Implementations

Complete implementation of all tools defined in the unified schema.
Single source of truth for tool executors in Python.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import fnmatch
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from .types import ToolDefinition, ToolSuite, JSONSchemaObject, JSONSchemaProperty


# ============================================================================
# Utility Functions
# ============================================================================

IGNORED_DIRS: Set[str] = {
    ".git",
    "node_modules",
    "dist",
    ".next",
    "build",
    "coverage",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
}


def resolve_path(working_dir: Path, path: str) -> Path:
    """Resolve a path relative to working directory."""
    if not path or not isinstance(path, str):
        raise ValueError("Path must be a non-empty string")
    trimmed = path.strip()
    if os.path.isabs(trimmed):
        return Path(trimmed)
    return (working_dir / trimmed).resolve()


def glob_to_regex(pattern: str) -> re.Pattern:
    """Convert glob pattern to regex."""
    escaped = re.escape(pattern)
    escaped = (
        escaped.replace(r"\*\*", "<!GLOBSTAR!>")
        .replace(r"\*", "[^/]*")
        .replace("<!GLOBSTAR!>", ".*")
        .replace(r"\?", ".")
    )
    return re.compile(escaped + "$")


def glob_search(base_dir: Path, pattern: str) -> List[Path]:
    """Search for files matching glob pattern."""
    results: List[Path] = []
    regex = glob_to_regex(pattern)

    def search(current_dir: Path) -> None:
        try:
            for entry in current_dir.iterdir():
                if entry.name in IGNORED_DIRS:
                    continue
                if entry.is_dir():
                    search(entry)
                elif entry.is_file() and regex.search(str(entry)):
                    results.append(entry)
        except (PermissionError, OSError):
            pass

    search(base_dir)
    return results


@dataclass
class GrepMatch:
    """A grep search result."""
    file: Path
    line: int
    content: str


def grep_search(
    search_path: Path,
    regex: re.Pattern,
    multiline: bool = False
) -> List[GrepMatch]:
    """Search files for regex matches."""
    results: List[GrepMatch] = []

    def search(current_path: Path) -> None:
        try:
            if current_path.is_dir():
                for entry in current_path.iterdir():
                    if entry.name in IGNORED_DIRS:
                        continue
                    search(entry)
            elif current_path.is_file():
                try:
                    content = current_path.read_text(encoding="utf-8")
                    if multiline:
                        for match in regex.finditer(content):
                            results.append(GrepMatch(
                                file=current_path,
                                line=1,
                                content=match.group()
                            ))
                    else:
                        for i, line in enumerate(content.split("\n"), 1):
                            if regex.search(line):
                                results.append(GrepMatch(
                                    file=current_path,
                                    line=i,
                                    content=line
                                ))
                except (UnicodeDecodeError, OSError):
                    pass
        except (PermissionError, OSError):
            pass

    search(search_path)
    return results


# ============================================================================
# Core Tools
# ============================================================================

def create_read_tool(working_dir: str) -> ToolDefinition:
    """Create Read tool - Read file contents."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        file_path = resolve_path(working_path, args.get("file_path", ""))
        offset = args.get("offset", 0) or 0
        limit = args.get("limit", 2000) or 2000

        if not file_path.exists():
            return f"Error: File not found: {file_path}"

        try:
            content = file_path.read_text(encoding="utf-8")
            lines = content.split("\n")
            selected = lines[offset:offset + limit]

            numbered = [
                f"{str(offset + i + 1).rjust(6)}→{line}"
                for i, line in enumerate(selected)
            ]
            return "\n".join(numbered)
        except Exception as e:
            return f"Error reading file: {e}"

    return ToolDefinition(
        name="Read",
        description="Read file contents from the filesystem",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "file_path": JSONSchemaProperty(type="string", description="Absolute path to the file"),
                "offset": JSONSchemaProperty(type="number", description="Line number to start from"),
                "limit": JSONSchemaProperty(type="number", description="Number of lines to read"),
            },
            required=["file_path"],
        ),
        cacheable=True,
        category="core",
    )


def create_write_tool(working_dir: str) -> ToolDefinition:
    """Create Write tool - Write content to a file."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        file_path = resolve_path(working_path, args.get("file_path", ""))
        content = args.get("content", "")

        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            existed = file_path.exists()
            file_path.write_text(content, encoding="utf-8")

            action = "Updated" if existed else "Created"
            lines = len(content.split("\n"))
            rel_path = file_path.relative_to(working_path) if file_path.is_relative_to(working_path) else file_path
            return f"✓ {action} {rel_path} ({lines} lines)"
        except Exception as e:
            return f"Error writing file: {e}"

    return ToolDefinition(
        name="Write",
        description="Write content to a file",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "file_path": JSONSchemaProperty(type="string", description="Absolute path to the file"),
                "content": JSONSchemaProperty(type="string", description="Content to write"),
            },
            required=["file_path", "content"],
        ),
        cacheable=False,
        category="core",
    )


def create_edit_tool(working_dir: str) -> ToolDefinition:
    """Create Edit tool - Make surgical edits to a file."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        file_path = resolve_path(working_path, args.get("file_path", ""))
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        replace_all = args.get("replace_all", False)

        if not file_path.exists():
            return f"Error: File not found: {file_path}"

        try:
            content = file_path.read_text(encoding="utf-8")

            if old_string not in content:
                return "Error: old_string not found in file"

            count = content.count(old_string)
            if not replace_all and count > 1:
                return f"Error: old_string appears {count} times. Use replace_all: true or provide more context."

            new_content = content.replace(old_string, new_string) if replace_all else content.replace(old_string, new_string, 1)
            file_path.write_text(new_content, encoding="utf-8")

            rel_path = file_path.relative_to(working_path) if file_path.is_relative_to(working_path) else file_path
            return f"✓ Edited {rel_path} ({count} occurrence{'s' if count > 1 else ''})"
        except Exception as e:
            return f"Error editing file: {e}"

    return ToolDefinition(
        name="Edit",
        description="Make surgical edits to a file",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "file_path": JSONSchemaProperty(type="string", description="Absolute path to the file"),
                "old_string": JSONSchemaProperty(type="string", description="Text to replace"),
                "new_string": JSONSchemaProperty(type="string", description="Replacement text"),
                "replace_all": JSONSchemaProperty(type="boolean", description="Replace all occurrences"),
            },
            required=["file_path", "old_string", "new_string"],
        ),
        cacheable=False,
        category="core",
    )


def create_bash_tool(working_dir: str) -> ToolDefinition:
    """Create Bash tool - Execute shell commands."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        command = args.get("command", "")
        timeout = (args.get("timeout") or 120000) / 1000  # Convert to seconds

        if not command:
            return "Error: command must be a non-empty string"

        # Basic safety check
        dangerous_patterns = [
            r"rm\s+-rf\s+[\/~]",
            r">\s*\/dev\/sd",
            r"mkfs\.",
            r"dd\s+if=.*of=\/dev",
        ]
        for pattern in dangerous_patterns:
            if re.search(pattern, command):
                return "Error: Potentially dangerous command blocked for safety"

        try:
            result = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(working_path),
            )

            try:
                stdout, stderr = await asyncio.wait_for(result.communicate(), timeout=timeout)
                stdout_text = stdout.decode("utf-8", errors="replace") if stdout else ""
                stderr_text = stderr.decode("utf-8", errors="replace") if stderr else ""

                parts = []
                if stdout_text:
                    parts.append(f"stdout:\n{stdout_text}")
                if stderr_text:
                    parts.append(f"stderr:\n{stderr_text}")

                return "\n".join(parts) if parts else "Command executed successfully (no output)"
            except asyncio.TimeoutError:
                result.kill()
                return f"Error: Command timed out after {timeout}s"
        except Exception as e:
            return f"Error executing command: {e}"

    return ToolDefinition(
        name="Bash",
        description="Execute shell commands",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "command": JSONSchemaProperty(type="string", description="Command to execute"),
                "timeout": JSONSchemaProperty(type="number", description="Timeout in milliseconds"),
                "description": JSONSchemaProperty(type="string", description="What this command does"),
            },
            required=["command"],
        ),
        cacheable=False,
        category="core",
    )


def create_glob_tool(working_dir: str) -> ToolDefinition:
    """Create Glob tool - Find files matching a pattern."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        pattern = args.get("pattern", "")
        path_arg = args.get("path")
        search_path = resolve_path(working_path, path_arg) if path_arg else working_path

        if not pattern.strip():
            return "Error: pattern must be a non-empty string"

        if pattern.strip() in ["*", ".", "**/*"]:
            return f'Warning: Pattern "{pattern}" is too broad. Use a more specific pattern.'

        try:
            matches = glob_search(search_path, pattern)
            relative_paths = []
            for match in matches:
                try:
                    relative_paths.append(str(match.relative_to(working_path)))
                except ValueError:
                    relative_paths.append(str(match))

            if not relative_paths:
                return f"No files found matching pattern: {pattern}"

            limit = 50
            limited = relative_paths[:limit]
            truncated = len(relative_paths) > limit

            result = f'{len(relative_paths)} files found matching "{pattern}":\n\n' + "\n".join(limited)
            if truncated:
                result += f"\n\n... [{len(relative_paths) - limit} more files truncated]"

            return result
        except Exception as e:
            return f"Error during glob search: {e}"

    return ToolDefinition(
        name="Glob",
        description="Find files matching a pattern",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "pattern": JSONSchemaProperty(type="string", description="Glob pattern to match"),
                "path": JSONSchemaProperty(type="string", description="Directory to search in"),
            },
            required=["pattern"],
        ),
        cacheable=True,
        category="core",
    )


def create_grep_tool(working_dir: str) -> ToolDefinition:
    """Create Grep tool - Search file contents with regex."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        pattern = args.get("pattern", "")
        path_arg = args.get("path")
        search_path = resolve_path(working_path, path_arg) if path_arg else working_path
        output_mode = args.get("output_mode", "files_with_matches")
        case_insensitive = args.get("-i", False)
        multiline = args.get("multiline", False)

        try:
            flags = re.IGNORECASE if case_insensitive else 0
            if multiline:
                flags |= re.DOTALL
            regex = re.compile(pattern, flags)
        except re.error as e:
            return f"Error: Invalid regex pattern: {e}"

        try:
            matches = grep_search(search_path, regex, multiline)

            if not matches:
                return "No matches found."

            if output_mode == "files_with_matches":
                files = list({str(m.file.relative_to(working_path)) if m.file.is_relative_to(working_path) else str(m.file) for m in matches})
                return "\n".join(files)

            if output_mode == "count":
                counts: Dict[str, int] = {}
                for m in matches:
                    key = str(m.file.relative_to(working_path)) if m.file.is_relative_to(working_path) else str(m.file)
                    counts[key] = counts.get(key, 0) + 1
                return "\n".join(f"{count}:{path}" for path, count in counts.items())

            # content mode
            limit = 50
            limited = matches[:limit]
            result = "\n".join(
                f"{str(m.file.relative_to(working_path)) if m.file.is_relative_to(working_path) else str(m.file)}:{m.line}:{m.content}"
                for m in limited
            )

            if len(matches) > limit:
                result += f"\n\n... [{len(matches) - limit} more matches truncated]"

            return result
        except Exception as e:
            return f"Error during grep search: {e}"

    return ToolDefinition(
        name="Grep",
        description="Search file contents with regex",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "pattern": JSONSchemaProperty(type="string", description="Regex pattern to search for"),
                "path": JSONSchemaProperty(type="string", description="File or directory to search"),
                "output_mode": JSONSchemaProperty(
                    type="string",
                    enum=["content", "files_with_matches", "count"],
                    description="Output mode",
                ),
                "-i": JSONSchemaProperty(type="boolean", description="Case insensitive search"),
                "multiline": JSONSchemaProperty(type="boolean", description="Enable multiline mode"),
            },
            required=["pattern"],
        ),
        cacheable=True,
        category="core",
    )


# ============================================================================
# Web Tools
# ============================================================================

def create_web_search_tool() -> ToolDefinition:
    """Create WebSearch tool."""
    async def execute(args: Dict[str, Any]) -> str:
        query = args.get("query", "")
        return f'[WebSearch] Would search for: "{query}"\n\nNote: WebSearch requires API configuration.'

    return ToolDefinition(
        name="WebSearch",
        description="Search the web for information",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "query": JSONSchemaProperty(type="string", description="Search query"),
            },
            required=["query"],
        ),
        cacheable=True,
        category="web",
    )


def create_web_fetch_tool() -> ToolDefinition:
    """Create WebFetch tool."""
    async def execute(args: Dict[str, Any]) -> str:
        url = args.get("url", "")
        prompt = args.get("prompt", "")
        return f"[WebFetch] Would fetch: {url}\nPrompt: {prompt}\n\nNote: WebFetch requires network access."

    return ToolDefinition(
        name="WebFetch",
        description="Fetch and analyze web page content",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "url": JSONSchemaProperty(type="string", description="URL to fetch"),
                "prompt": JSONSchemaProperty(type="string", description="What to extract from the page"),
            },
            required=["url", "prompt"],
        ),
        cacheable=True,
        category="web",
    )


# ============================================================================
# Coding Tools
# ============================================================================

def create_analyze_complexity_tool() -> ToolDefinition:
    """Create AnalyzeComplexity tool."""
    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        language = args.get("language", "unknown")

        lines = code.split("\n")
        non_empty = [l for l in lines if l.strip()]
        functions = len(re.findall(r"function\s+\w+|def\s+\w+|const\s+\w+\s*=\s*(?:async\s*)?\(", code))
        loops = len(re.findall(r"\b(for|while|do)\b", code))
        conditions = len(re.findall(r"\b(if|else|switch|case|\?|elif)\b", code))

        return f"""Code Complexity Analysis ({language}):
- Total lines: {len(lines)}
- Non-empty lines: {len(non_empty)}
- Functions/methods: {functions}
- Loops: {loops}
- Conditionals: {conditions}
- Estimated cyclomatic complexity: {1 + loops + conditions}"""

    return ToolDefinition(
        name="AnalyzeComplexity",
        description="Analyze code complexity metrics",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to analyze"),
                "language": JSONSchemaProperty(type="string", description="Programming language"),
            },
            required=["code"],
        ),
        cacheable=True,
        category="coding",
    )


def create_find_dependencies_tool() -> ToolDefinition:
    """Create FindDependencies tool."""
    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        language = args.get("language", "unknown")

        imports: List[str] = []

        # JavaScript/TypeScript
        imports.extend(re.findall(r"import\s+.*?from\s+['\"]([^'\"]+)['\"]", code))
        imports.extend(re.findall(r"require\s*\(\s*['\"]([^'\"]+)['\"]\s*\)", code))

        # Python
        imports.extend(re.findall(r"(?:from\s+(\S+)\s+)?import\s+(\S+)", code))

        if not imports:
            return f"No dependencies found in {language} code."

        # Flatten tuples from Python regex
        flat_imports = []
        for item in imports:
            if isinstance(item, tuple):
                flat_imports.extend([x for x in item if x])
            else:
                flat_imports.append(item)

        return f"Dependencies found ({language}):\n" + "\n".join(f"- {dep}" for dep in flat_imports)

    return ToolDefinition(
        name="FindDependencies",
        description="Find imports and dependencies in code",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to analyze"),
                "language": JSONSchemaProperty(type="string", description="Programming language"),
            },
            required=["code"],
        ),
        cacheable=True,
        category="coding",
    )


def create_generate_docstring_tool() -> ToolDefinition:
    """Create GenerateDocstring tool."""
    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        style = args.get("style", "google")

        # Extract function signature
        func_match = re.search(r"(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)", code)
        arrow_match = re.search(r"(?:const|let)\s+(\w+)\s*=\s*(?:async\s*)?\(([^)]*)\)", code)
        py_match = re.search(r"def\s+(\w+)\s*\(([^)]*)\)", code)

        match = func_match or arrow_match or py_match
        if not match:
            return "Could not detect function signature. Provide a function to document."

        name, params = match.groups()
        param_list = [p.strip().split(":")[0].strip() for p in params.split(",") if p.strip()]

        if style == "jsdoc":
            param_docs = "\n".join(f" * @param {{*}} {p} - Description" for p in param_list)
            return f"""/**
 * {name} - Description of what this function does
 *
{param_docs}
 * @returns {{*}} Description of return value
 */"""

        # Google style (Python)
        param_docs = "\n".join(f"        {p}: Description" for p in param_list)
        return f'''"""{name} - Description of what this function does

    Args:
{param_docs}

    Returns:
        Description of return value
    """'''

    return ToolDefinition(
        name="GenerateDocstring",
        description="Generate documentation for code",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to document"),
                "style": JSONSchemaProperty(
                    type="string",
                    enum=["google", "numpy", "sphinx", "jsdoc"],
                    description="Doc style",
                ),
            },
            required=["code"],
        ),
        cacheable=False,
        category="coding",
    )


def create_suggest_refactorings_tool() -> ToolDefinition:
    """Create SuggestRefactorings tool."""
    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        suggestions: List[str] = []

        lines = code.split("\n")
        if len(lines) > 50:
            suggestions.append("- Consider breaking this into smaller functions (>50 lines)")

        max_indent = max((len(l) - len(l.lstrip()) for l in lines if l.strip()), default=0)
        if max_indent > 16:
            suggestions.append("- Reduce nesting depth - consider early returns or extracting functions")

        if re.search(r"[^a-zA-Z0-9_]\d{2,}[^a-zA-Z0-9_]", code):
            suggestions.append("- Extract magic numbers into named constants")

        if len(re.findall(r"console\.log|print\(", code)) > 3:
            suggestions.append("- Consider using a proper logging framework")

        if not suggestions:
            return "No immediate refactoring suggestions. Code looks clean!"

        return f"Refactoring Suggestions:\n" + "\n".join(suggestions)

    return ToolDefinition(
        name="SuggestRefactorings",
        description="Suggest code refactoring improvements",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to analyze"),
                "focus": JSONSchemaProperty(type="array", items=JSONSchemaProperty(type="string"), description="Areas to focus on"),
            },
            required=["code"],
        ),
        cacheable=True,
        category="coding",
    )


def create_generate_test_stub_tool() -> ToolDefinition:
    """Create GenerateTestStub tool."""
    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        framework = args.get("framework", "jest")

        # Extract function names
        js_funcs = re.findall(r"(?:async\s+)?function\s+(\w+)|(?:const|let)\s+(\w+)\s*=\s*(?:async\s*)?\(", code)
        py_funcs = re.findall(r"def\s+(\w+)", code)

        names = [n for match in js_funcs for n in match if n] + py_funcs

        if not names:
            return "No functions found to generate tests for."

        if framework == "pytest":
            return "\n\n".join(
                f'''def test_{name}():
    """Test {name} function."""
    # Arrange

    # Act
    result = {name}()

    # Assert
    assert result is not None'''
                for name in names
            )

        # Jest style
        test_cases = "\n\n".join(
            f'''  describe('{name}', () => {{
    it('should work correctly', () => {{
      // Arrange

      // Act
      const result = {name}();

      // Assert
      expect(result).toBeDefined();
    }});
  }});'''
            for name in names
        )
        return f"describe('Module Tests', () => {{\n{test_cases}\n}});"

    return ToolDefinition(
        name="GenerateTestStub",
        description="Generate test stubs for code",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to test"),
                "framework": JSONSchemaProperty(type="string", description="Test framework"),
            },
            required=["code"],
        ),
        cacheable=False,
        category="coding",
    )


# ============================================================================
# Security Tools
# ============================================================================

def create_dependency_audit_tool(working_dir: str) -> ToolDefinition:
    """Create DependencyAudit tool."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        package_file = resolve_path(working_path, args.get("packageFile", ""))
        threshold = args.get("severityThreshold", "low")

        if not package_file.exists():
            return f"Error: Package file not found: {package_file}"

        filename = package_file.name

        if filename in ("package.json", "package-lock.json"):
            try:
                result = await asyncio.create_subprocess_shell(
                    "npm audit --json",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(package_file.parent),
                )
                stdout, _ = await result.communicate()
                return f"NPM Audit Results:\n{stdout.decode('utf-8', errors='replace')}"
            except Exception as e:
                return f"NPM Audit error: {e}"

        if filename in ("requirements.txt", "Pipfile"):
            return f"[DependencyAudit] Python audit for {filename}\nNote: Run 'pip-audit' or 'safety check' manually."

        return f"[DependencyAudit] Unknown package format: {filename}"

    return ToolDefinition(
        name="DependencyAudit",
        description="Audit dependencies for vulnerabilities",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "packageFile": JSONSchemaProperty(type="string", description="Path to package file"),
                "severityThreshold": JSONSchemaProperty(
                    type="string",
                    enum=["critical", "high", "medium", "low"],
                    description="Minimum severity to report",
                ),
            },
            required=["packageFile"],
        ),
        cacheable=True,
        requires_auth=True,
        category="security",
    )


def create_code_security_scan_tool() -> ToolDefinition:
    """Create CodeSecurityScan tool."""
    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        language = args.get("language", "unknown")
        findings: List[str] = []

        patterns = [
            (r"eval\s*\(", "Dangerous use of eval()"),
            (r"innerHTML\s*=", "Potential XSS via innerHTML"),
            (r"document\.write", "Potential XSS via document.write"),
            (r"exec\s*\(", "Command injection risk via exec()"),
            (r"shell\s*=\s*True", "Shell injection risk"),
            (r"password\s*=\s*[\"'][^\"']+[\"']", "Hardcoded password detected"),
            (r"api[_-]?key\s*=\s*[\"'][^\"']+[\"']", "Hardcoded API key detected"),
            (r"SELECT.*FROM.*WHERE.*\+", "Potential SQL injection"),
            (r"\.readFile\s*\(.*\+", "Path traversal risk"),
        ]

        for pattern, issue in patterns:
            if re.search(pattern, code, re.IGNORECASE):
                findings.append(f"- {issue}")

        if not findings:
            return f"Security scan complete ({language}): No vulnerabilities detected."

        return f"Security Findings ({language}):\n" + "\n".join(findings) + "\n\nReview and address these issues."

    return ToolDefinition(
        name="CodeSecurityScan",
        description="Scan code for security vulnerabilities",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to scan"),
                "language": JSONSchemaProperty(type="string", description="Programming language"),
            },
            required=["code", "language"],
        ),
        cacheable=True,
        requires_auth=True,
        category="security",
    )


def create_analyze_attack_surface_tool() -> ToolDefinition:
    """Create AnalyzeAttackSurface tool."""
    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        context = args.get("context", "unknown")
        surfaces: List[str] = []

        if re.search(r"req\.(body|params|query|headers)", code):
            surfaces.append("- HTTP request parameters")
        if re.search(r"process\.argv|sys\.argv", code):
            surfaces.append("- Command line arguments")
        if re.search(r"process\.env|os\.environ", code):
            surfaces.append("- Environment variables")
        if re.search(r"readFile|open\(|createReadStream", code):
            surfaces.append("- File system reads")
        if re.search(r"fetch\(|axios|http\.get|requests\.", code):
            surfaces.append("- External HTTP requests")
        if re.search(r"\.query\(|\.execute\(|cursor\.", code):
            surfaces.append("- Database queries")

        if not surfaces:
            return f"Attack surface analysis ({context}): No obvious input points detected."

        return f"""Attack Surface Analysis ({context}):

Input Points:
{chr(10).join(surfaces)}

Recommendation: Validate and sanitize all inputs."""

    return ToolDefinition(
        name="AnalyzeAttackSurface",
        description="Analyze code attack surface",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to analyze"),
                "context": JSONSchemaProperty(
                    type="string",
                    enum=["web_app", "api", "cli", "library"],
                    description="App context",
                ),
            },
            required=["code"],
        ),
        cacheable=True,
        requires_auth=True,
        category="security",
    )


# ============================================================================
# Alpha Zero Tools
# ============================================================================

def create_alpha_zero_evaluate_tool() -> ToolDefinition:
    """Create AlphaZeroEvaluate tool."""
    import random

    async def execute(args: Dict[str, Any]) -> str:
        code = args.get("code", "")
        lines = code.split("\n")

        metrics = {
            "code_quality": min(100, max(0, 100 - (20 if len(lines) > 100 else 0))),
            "algorithm_efficiency": 75 + random.random() * 25,
            "error_handling": 85 if "try" in code and ("catch" in code or "except" in code) else 50,
            "documentation": 80 if len(re.findall(r'/\*\*|//|#.*|"""', code)) > 3 else 40,
            "maintainability": 90 if len(lines) < 50 else (70 if len(lines) < 100 else 50),
            "security": 30 if "eval" in code or "exec" in code else 80,
        }

        overall = sum(metrics.values()) / len(metrics)

        return f"""Alpha Zero 2 Code Evaluation:

Overall Score: {overall:.1f}/100

Metrics:
- Code Quality: {metrics['code_quality']:.1f}
- Algorithm Efficiency: {metrics['algorithm_efficiency']:.1f}
- Error Handling: {metrics['error_handling']:.1f}
- Documentation: {metrics['documentation']:.1f}
- Maintainability: {metrics['maintainability']:.1f}
- Security: {metrics['security']:.1f}"""

    return ToolDefinition(
        name="AlphaZeroEvaluate",
        description="Evaluate code quality with Alpha Zero 2 metrics",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "code": JSONSchemaProperty(type="string", description="Code to evaluate"),
            },
            required=["code"],
        ),
        cacheable=True,
        category="alpha_zero",
    )


def create_alpha_zero_tournament_tool() -> ToolDefinition:
    """Create AlphaZeroTournament tool."""
    async def execute(args: Dict[str, Any]) -> str:
        prompts = args.get("taskPrompts", [])
        rounds = args.get("numRounds", 3)

        return f"""[AlphaZeroTournament] Would run tournament:
- Prompts: {len(prompts)}
- Rounds: {rounds}

Note: Tournament execution requires agent configuration."""

    return ToolDefinition(
        name="AlphaZeroTournament",
        description="Run a competitive tournament between agents",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "taskPrompts": JSONSchemaProperty(type="array", items=JSONSchemaProperty(type="string"), description="Task prompts"),
                "numRounds": JSONSchemaProperty(type="integer", description="Number of rounds"),
            },
            required=["taskPrompts"],
        ),
        cacheable=False,
        category="alpha_zero",
    )


def create_alpha_zero_introspect_tool() -> ToolDefinition:
    """Create AlphaZeroIntrospect tool."""
    async def execute(args: Dict[str, Any]) -> str:
        return """[AlphaZeroIntrospect] Agent Performance Analysis

Current session metrics would be displayed here.
Note: Introspection requires active session tracking."""

    return ToolDefinition(
        name="AlphaZeroIntrospect",
        description="Analyze agent performance and get improvement suggestions",
        execute=execute,
        parameters=JSONSchemaObject(type="object", properties={}),
        cacheable=False,
        category="alpha_zero",
    )


def create_alpha_zero_history_tool() -> ToolDefinition:
    """Create AlphaZeroHistory tool."""
    async def execute(args: Dict[str, Any]) -> str:
        return """[AlphaZeroHistory] Historical Data

No historical data available in current session.
Note: History requires persistent storage configuration."""

    return ToolDefinition(
        name="AlphaZeroHistory",
        description="Get historical competition data",
        execute=execute,
        parameters=JSONSchemaObject(type="object", properties={}),
        cacheable=True,
        category="alpha_zero",
    )


def create_alpha_zero_metrics_tool() -> ToolDefinition:
    """Create AlphaZeroMetrics tool."""
    async def execute(args: Dict[str, Any]) -> str:
        timeframe = args.get("timeframe", "all")
        include_trends = args.get("includeTrends", False)

        return f"""[AlphaZeroMetrics] Performance Metrics ({timeframe})

Metrics collection would be displayed here.
Include trends: {include_trends}

Note: Requires metrics collection to be enabled."""

    return ToolDefinition(
        name="AlphaZeroMetrics",
        description="Get comprehensive performance metrics",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "timeframe": JSONSchemaProperty(
                    type="string",
                    enum=["hour", "day", "week", "month", "all"],
                    description="Time range",
                ),
                "includeTrends": JSONSchemaProperty(type="boolean", description="Include trend analysis"),
            },
        ),
        cacheable=False,
        category="alpha_zero",
    )


# ============================================================================
# Intelligence Tools
# ============================================================================

def create_intelligence_analyze_tool(working_dir: str) -> ToolDefinition:
    """Create IntelligenceAnalyze tool - Analyze codebase for issues."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        patterns = args.get("patterns", ["**/*.py"])
        exclude = args.get("exclude", [])

        try:
            from ...intelligence import CodeIntelligenceSuite
            suite = CodeIntelligenceSuite(str(working_path))
            report = suite.analyze(patterns, exclude)

            # Format report
            severity_counts = {
                "critical": len([i for i in report.issues if i.severity == "critical"]),
                "high": len([i for i in report.issues if i.severity == "high"]),
                "medium": len([i for i in report.issues if i.severity == "medium"]),
                "low": len([i for i in report.issues if i.severity == "low"]),
                "info": len([i for i in report.issues if i.severity == "info"]),
            }

            lines = [
                "=" * 60,
                "CODE INTELLIGENCE REPORT",
                "=" * 60,
                "",
                f"Files analyzed: {report.files_analyzed}",
                f"Lines of code: {report.lines_of_code}",
                f"Issues found: {len(report.issues)}",
                "",
                "ISSUES BY SEVERITY",
                "-" * 40,
            ]

            for sev, count in severity_counts.items():
                if count > 0:
                    lines.append(f"  {sev.upper()}: {count}")

            lines.extend(["", "METRICS", "-" * 40])
            for name, metric in report.metrics.items():
                bar = "#" * int(metric.value / 5) + "." * (20 - int(metric.value / 5))
                lines.append(f"  {name}: [{bar}] {metric.value:.0f}%")

            if report.good_patterns:
                lines.extend(["", "GOOD PATTERNS", "-" * 40])
                for name, count in report.good_patterns.items():
                    lines.append(f"  {name}: {count}")

            return "\n".join(lines)
        except Exception as e:
            return f"Error during analysis: {e}"

    return ToolDefinition(
        name="IntelligenceAnalyze",
        description="Analyze codebase for issues, patterns, and metrics",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "patterns": JSONSchemaProperty(type="array", items=JSONSchemaProperty(type="string"), description="Glob patterns for files to analyze"),
                "exclude": JSONSchemaProperty(type="array", items=JSONSchemaProperty(type="string"), description="Patterns to exclude"),
            },
        ),
        cacheable=True,
        category="intelligence",
    )


def create_intelligence_refactor_tool(working_dir: str) -> ToolDefinition:
    """Create IntelligenceRefactor tool - Suggest and apply refactorings."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        file_path = args.get("filePath", "")
        apply_changes = args.get("apply", False)
        types = args.get("types", [])

        try:
            from ...intelligence import CodeIntelligenceSuite
            suite = CodeIntelligenceSuite(str(working_path))
            actions = suite.suggest_refactorings(file_path, types if types else None)

            if not actions:
                return f"No refactoring suggestions for {file_path}"

            if apply_changes:
                result = suite.refactorer.apply(actions, dry_run=False)
                return f"Applied {result['applied_count']}/{result['total_count']} refactorings"

            lines = [f"Refactoring Suggestions for {file_path}:", ""]
            for action in actions:
                lines.extend([
                    f"Line {action.line}: {action.action}",
                    f"  Risk: {action.risk}",
                    f"  Before: {action.old_code[:50]}...",
                    f"  After: {action.new_code[:50]}...",
                    "",
                ])

            return "\n".join(lines)
        except Exception as e:
            return f"Error during refactoring: {e}"

    return ToolDefinition(
        name="IntelligenceRefactor",
        description="Suggest and apply code refactorings",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "filePath": JSONSchemaProperty(type="string", description="Path to file to refactor"),
                "apply": JSONSchemaProperty(type="boolean", description="Apply changes (false = dry run)"),
                "types": JSONSchemaProperty(type="array", items=JSONSchemaProperty(type="string"), description="Refactoring types to apply"),
            },
            required=["filePath"],
        ),
        cacheable=False,
        category="intelligence",
    )


def create_intelligence_document_tool(working_dir: str) -> ToolDefinition:
    """Create IntelligenceDocument tool - Generate documentation."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        patterns = args.get("patterns", ["**/*.py"])
        format_type = args.get("format", "markdown")
        output_path = args.get("outputPath")

        try:
            from ...intelligence import CodeIntelligenceSuite
            suite = CodeIntelligenceSuite(str(working_path))
            docs = suite.generate_docs(patterns, format_type)

            if output_path:
                out_file = working_path / output_path
                out_file.parent.mkdir(parents=True, exist_ok=True)
                out_file.write_text(docs, encoding="utf-8")
                return f"Documentation written to {output_path} ({len(docs)} bytes)"

            # Truncate if too long
            if len(docs) > 5000:
                return docs[:5000] + f"\n\n... [truncated, {len(docs) - 5000} more bytes]"
            return docs
        except Exception as e:
            return f"Error generating documentation: {e}"

    return ToolDefinition(
        name="IntelligenceDocument",
        description="Generate API documentation",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "patterns": JSONSchemaProperty(type="array", items=JSONSchemaProperty(type="string"), description="Glob patterns for files"),
                "format": JSONSchemaProperty(type="string", enum=["markdown", "json"], description="Output format"),
                "outputPath": JSONSchemaProperty(type="string", description="Path to write documentation"),
            },
        ),
        cacheable=True,
        category="intelligence",
    )


def create_intelligence_test_tool(working_dir: str) -> ToolDefinition:
    """Create IntelligenceTest tool - Generate tests."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        file_path = args.get("filePath", "")
        framework = args.get("framework", "pytest")
        output_path = args.get("outputPath")

        try:
            from ...intelligence import CodeIntelligenceSuite
            suite = CodeIntelligenceSuite(str(working_path))
            tests = suite.generate_tests(file_path, framework)

            if output_path:
                out_file = working_path / output_path
                out_file.parent.mkdir(parents=True, exist_ok=True)
                out_file.write_text(tests, encoding="utf-8")
                return f"Tests written to {output_path}"

            return tests
        except Exception as e:
            return f"Error generating tests: {e}"

    return ToolDefinition(
        name="IntelligenceTest",
        description="Generate test suites for code",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "filePath": JSONSchemaProperty(type="string", description="Path to file to test"),
                "framework": JSONSchemaProperty(type="string", enum=["pytest", "unittest"], description="Test framework"),
                "outputPath": JSONSchemaProperty(type="string", description="Path to write tests"),
            },
            required=["filePath"],
        ),
        cacheable=False,
        category="intelligence",
    )


def create_intelligence_full_tool(working_dir: str) -> ToolDefinition:
    """Create IntelligenceFull tool - Run full intelligence suite."""
    working_path = Path(working_dir).resolve()

    async def execute(args: Dict[str, Any]) -> str:
        patterns = args.get("patterns", ["**/*.py"])
        output_dir = args.get("outputDir", ".intelligence")

        try:
            from ...intelligence import CodeIntelligenceSuite
            import json

            suite = CodeIntelligenceSuite(str(working_path))
            result = suite.full_analysis(patterns)

            # Write outputs
            out_path = working_path / output_dir
            out_path.mkdir(parents=True, exist_ok=True)

            # Write analysis report
            report_file = out_path / "analysis.json"
            report_file.write_text(json.dumps(result, indent=2), encoding="utf-8")

            # Generate and write docs
            docs = suite.generate_docs(patterns)
            docs_file = out_path / "API-documentation.md"
            docs_file.write_text(docs, encoding="utf-8")

            lines = [
                "=" * 60,
                "FULL INTELLIGENCE ANALYSIS COMPLETE",
                "=" * 60,
                "",
                f"Files analyzed: {result['analysis']['files_analyzed']}",
                f"Lines of code: {result['analysis']['lines_of_code']}",
                "",
                "Issues by severity:",
            ]

            for sev, count in result["analysis"]["issues_by_severity"].items():
                if count > 0:
                    lines.append(f"  {sev}: {count}")

            lines.extend([
                "",
                "Output files:",
                f"  - {output_dir}/analysis.json",
                f"  - {output_dir}/API-documentation.md ({len(docs)} bytes)",
            ])

            return "\n".join(lines)
        except Exception as e:
            return f"Error during full analysis: {e}"

    return ToolDefinition(
        name="IntelligenceFull",
        description="Run complete code intelligence analysis",
        execute=execute,
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "patterns": JSONSchemaProperty(type="array", items=JSONSchemaProperty(type="string"), description="Glob patterns for files"),
                "outputDir": JSONSchemaProperty(type="string", description="Directory for output files"),
            },
        ),
        cacheable=False,
        category="intelligence",
    )


# ============================================================================
# Suite Factory
# ============================================================================

def create_unified_tool_suite(working_dir: str) -> ToolSuite:
    """Create the complete unified tool suite."""
    return ToolSuite(
        name="unified",
        version="2.0.0",
        description="Complete unified tool suite for erosolar-cli",
        tools=[
            # Core tools
            create_read_tool(working_dir),
            create_write_tool(working_dir),
            create_edit_tool(working_dir),
            create_bash_tool(working_dir),
            create_glob_tool(working_dir),
            create_grep_tool(working_dir),

            # Web tools
            create_web_search_tool(),
            create_web_fetch_tool(),

            # Coding tools
            create_analyze_complexity_tool(),
            create_find_dependencies_tool(),
            create_generate_docstring_tool(),
            create_suggest_refactorings_tool(),
            create_generate_test_stub_tool(),

            # Security tools
            create_dependency_audit_tool(working_dir),
            create_code_security_scan_tool(),
            create_analyze_attack_surface_tool(),

            # Alpha Zero tools
            create_alpha_zero_evaluate_tool(),
            create_alpha_zero_tournament_tool(),
            create_alpha_zero_introspect_tool(),
            create_alpha_zero_history_tool(),
            create_alpha_zero_metrics_tool(),

            # Intelligence tools
            create_intelligence_analyze_tool(working_dir),
            create_intelligence_refactor_tool(working_dir),
            create_intelligence_document_tool(working_dir),
            create_intelligence_test_tool(working_dir),
            create_intelligence_full_tool(working_dir),
        ],
    )


def create_core_tool_suite(working_dir: str) -> ToolSuite:
    """Create core file and system tools."""
    return ToolSuite(
        name="core",
        version="2.0.0",
        description="Core file and system tools",
        tools=[
            create_read_tool(working_dir),
            create_write_tool(working_dir),
            create_edit_tool(working_dir),
            create_bash_tool(working_dir),
            create_glob_tool(working_dir),
            create_grep_tool(working_dir),
        ],
    )


def create_web_tool_suite() -> ToolSuite:
    """Create web tools suite."""
    return ToolSuite(
        name="web",
        version="2.0.0",
        description="Web search and fetch tools",
        tools=[
            create_web_search_tool(),
            create_web_fetch_tool(),
        ],
    )


def create_coding_tool_suite() -> ToolSuite:
    """Create coding tools suite."""
    return ToolSuite(
        name="coding",
        version="2.0.0",
        description="Code analysis and generation tools",
        tools=[
            create_analyze_complexity_tool(),
            create_find_dependencies_tool(),
            create_generate_docstring_tool(),
            create_suggest_refactorings_tool(),
            create_generate_test_stub_tool(),
        ],
    )


def create_security_tool_suite(working_dir: str) -> ToolSuite:
    """Create security tools suite."""
    return ToolSuite(
        name="security",
        version="2.0.0",
        description="Security analysis tools",
        tools=[
            create_dependency_audit_tool(working_dir),
            create_code_security_scan_tool(),
            create_analyze_attack_surface_tool(),
        ],
    )


def create_alpha_zero_tool_suite() -> ToolSuite:
    """Create Alpha Zero tools suite."""
    return ToolSuite(
        name="alpha_zero",
        version="2.0.0",
        description="Alpha Zero 2 competitive RL tools",
        tools=[
            create_alpha_zero_evaluate_tool(),
            create_alpha_zero_tournament_tool(),
            create_alpha_zero_introspect_tool(),
            create_alpha_zero_history_tool(),
            create_alpha_zero_metrics_tool(),
        ],
    )


def create_intelligence_tool_suite(working_dir: str) -> ToolSuite:
    """Create intelligence tools suite."""
    return ToolSuite(
        name="intelligence",
        version="2.0.0",
        description="Code intelligence - analysis, refactoring, documentation, testing",
        tools=[
            create_intelligence_analyze_tool(working_dir),
            create_intelligence_refactor_tool(working_dir),
            create_intelligence_document_tool(working_dir),
            create_intelligence_test_tool(working_dir),
            create_intelligence_full_tool(working_dir),
        ],
    )
