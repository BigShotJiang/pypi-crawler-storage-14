"""
Unified Provider Interface

Bridge module providing provider access from the unified schema.
This module wraps the schema functions to provide a consistent API.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Dict, Any, Tuple

from .unified import (
    get_provider_config,
    get_all_providers,
    get_schema_defaults,
    load_unified_schema,
    ProviderCapability,
    ProviderConfig,
)


# Re-export ProviderCapability for backward compatibility
__all__ = [
    "get_provider",
    "get_providers",
    "get_defaults",
    "create_unified_provider",
    "validate_provider_env",
    "is_openai_compatible",
    "UnifiedProviderConfig",
    "UnifiedProviderInstance",
    "ProviderCapability",
]


@dataclass
class UnifiedProviderConfig:
    """Provider configuration from unified schema."""
    id: str
    label: str
    description: str
    base_url: str
    api_version: Optional[str]
    env_vars: Dict[str, str]
    capabilities: List[ProviderCapability]
    models: List[str]
    default_model: str
    max_context: int
    supports_tools: bool
    supports_streaming: bool
    supports_vision: bool
    openai_compatible: bool


@dataclass
class UnifiedProviderInstance:
    """A configured provider instance ready for use."""
    config: UnifiedProviderConfig
    api_key: Optional[str]
    base_url: str


def _config_to_unified(config: ProviderConfig) -> UnifiedProviderConfig:
    """Convert ProviderConfig to UnifiedProviderConfig."""
    # ProviderCapability is a Literal type with string values
    capabilities = list(config.capabilities) if config.capabilities else []
    return UnifiedProviderConfig(
        id=config.id,
        label=config.label,
        description=config.description or "",
        base_url=config.base_url or "",
        api_version=config.api_version,
        env_vars=config.env_vars,
        capabilities=capabilities,
        models=config.models,
        default_model=config.default_model,
        max_context=getattr(config, 'max_context', 200000),  # Default to 200k
        supports_tools="tools" in capabilities or "tool_use" in capabilities,
        supports_streaming="streaming" in capabilities,
        supports_vision="vision" in capabilities or "multimodal" in capabilities,
        openai_compatible=config.openai_compatible,
    )


def get_provider(provider_id: str) -> Optional[UnifiedProviderConfig]:
    """
    Get provider configuration from unified schema.

    Args:
        provider_id: Provider identifier (e.g., 'anthropic', 'openai')

    Returns:
        Provider configuration or None if not found
    """
    config = get_provider_config(provider_id)
    if config:
        return _config_to_unified(config)
    return None


def get_providers() -> List[UnifiedProviderConfig]:
    """
    Get all provider configurations from unified schema.

    Returns:
        List of all provider configurations
    """
    return [_config_to_unified(p) for p in get_all_providers()]


def get_defaults() -> Dict[str, Any]:
    """
    Get default configuration values from schema.

    Returns:
        Dictionary of default settings
    """
    return get_schema_defaults()


def create_unified_provider(provider_id: str, api_key: Optional[str] = None) -> UnifiedProviderInstance:
    """
    Create a configured provider instance.

    Args:
        provider_id: Provider identifier
        api_key: Optional API key (uses environment if not provided)

    Returns:
        Configured provider instance

    Raises:
        ValueError: If provider not found
    """
    config = get_provider(provider_id)
    if not config:
        raise ValueError(f"Provider not found: {provider_id}")

    # Get API key from environment if not provided
    if not api_key and config.env_vars.get("apiKey"):
        api_key = os.environ.get(config.env_vars["apiKey"])

    # Get base URL (may be overridden by environment)
    base_url = config.base_url
    if config.env_vars.get("baseUrl"):
        base_url = os.environ.get(config.env_vars["baseUrl"], base_url)

    return UnifiedProviderInstance(
        config=config,
        api_key=api_key,
        base_url=base_url,
    )


def validate_provider_env(provider_id: str) -> Tuple[bool, List[str]]:
    """
    Validate that required environment variables are set for a provider.

    Args:
        provider_id: Provider identifier

    Returns:
        Tuple of (is_valid, missing_vars)
    """
    config = get_provider(provider_id)
    if not config:
        return False, [f"Unknown provider: {provider_id}"]

    missing = []

    # Check API key
    api_key_var = config.env_vars.get("apiKey")
    if api_key_var and not os.environ.get(api_key_var):
        missing.append(api_key_var)

    return len(missing) == 0, missing


def is_openai_compatible(provider_id: str) -> bool:
    """
    Check if a provider uses the OpenAI-compatible API.

    Args:
        provider_id: Provider identifier

    Returns:
        True if provider is OpenAI-compatible
    """
    config = get_provider(provider_id)
    return config.openai_compatible if config else False
