"""
Version Manager Bridge

Provides backward-compatible version management functions by wrapping
the unified version module.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from dataclasses import dataclass
from typing import Dict, List, Optional

from .unified import (
    SemanticVersion,
    VersionConstraint,
    parse_version,
    format_version,
    VersionManager as UnifiedVersionManager,
    PluginDependencyResolver,
    SelfUpgradeManager,
    PluginDependency,
)


@dataclass
class VersionInfo:
    """Version information for a component."""
    version: SemanticVersion
    description: str
    status: str
    upgradeable: bool
    dependencies: List[str]


@dataclass
class ToolVersionInfo:
    """Version information for a tool."""
    version: SemanticVersion
    status: str


@dataclass
class PluginVersion:
    """Version information for a plugin."""
    version: SemanticVersion
    min_cli_version: Optional[str] = None
    max_cli_version: Optional[str] = None


# Re-export VersionManager
VersionManager = UnifiedVersionManager


def get_cli_version() -> SemanticVersion:
    """Get the CLI version."""
    return parse_version("1.2.1")


def get_component_versions() -> Dict[str, VersionInfo]:
    """Get versions of all components."""
    return {
        "core": VersionInfo(
            version=parse_version("2.0.0"),
            description="Core CLI runtime",
            status="production",
            upgradeable=False,
            dependencies=[],
        ),
        "unified_schema": VersionInfo(
            version=parse_version("2.0.0"),
            description="Unified schema system",
            status="production",
            upgradeable=False,
            dependencies=["core"],
        ),
        "tool_runtime": VersionInfo(
            version=parse_version("2.0.0"),
            description="Tool execution runtime",
            status="production",
            upgradeable=False,
            dependencies=["unified_schema"],
        ),
        "alpha_zero": VersionInfo(
            version=parse_version("1.0.0"),
            description="Alpha Zero 2 RL framework",
            status="production",
            upgradeable=True,
            dependencies=["tool_runtime"],
        ),
    }


def get_tool_versions() -> Dict[str, ToolVersionInfo]:
    """Get versions of all tools."""
    from .unified import load_unified_schema

    schema = load_unified_schema()
    tools = {}

    for tool in schema.tools:
        tools[tool.id] = ToolVersionInfo(
            version=parse_version("2.0.0"),
            status="production",
        )

    return tools
