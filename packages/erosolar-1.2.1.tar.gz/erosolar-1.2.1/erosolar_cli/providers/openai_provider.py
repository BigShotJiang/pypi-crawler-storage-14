"""
OpenAI GPT provider with streaming and tool calling support.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, AsyncIterator, Optional

from openai import AsyncOpenAI, OpenAI

from ..core.types import (
    AssistantMessage,
    ConversationMessage,
    LLMProvider,
    ProviderMessageResponse,
    ProviderResponse,
    ProviderToolCallsResponse,
    ProviderToolDefinition,
    ProviderUsage,
    StreamChunk,
    SystemMessage,
    ToolCallRequest,
    ToolMessage,
    UserMessage,
)


@dataclass
class OpenAIProviderOptions:
    """Options for OpenAI provider."""

    api_key: str
    model: str
    max_tokens: int = 2048
    temperature: float = 0.0


class OpenAIProvider(LLMProvider):
    """OpenAI GPT provider with streaming and tool calling support."""

    def __init__(self, options: OpenAIProviderOptions):
        """Initialize OpenAI provider."""
        super().__init__("openai", options.model)
        self.client = AsyncOpenAI(api_key=options.api_key)
        self.sync_client = OpenAI(api_key=options.api_key)
        self.max_tokens = options.max_tokens
        self.temperature = options.temperature

    async def generate(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderResponse:
        """Generate a response from OpenAI."""
        converted_messages = _convert_messages(messages)

        # Build request parameters
        params: dict[str, Any] = {
            "model": self.model,
            "messages": converted_messages,
            "temperature": self.temperature,
        }

        if self.max_tokens:
            params["max_tokens"] = self.max_tokens

        if tools:
            params["tools"] = [_map_tool(tool) for tool in tools]
            params["tool_choice"] = "auto"

        # Make API call
        response = await self.client.chat.completions.create(**params)

        # Extract message
        message = response.choices[0].message

        # Extract usage
        usage = None
        if response.usage:
            usage = ProviderUsage(
                input_tokens=response.usage.prompt_tokens,
                output_tokens=response.usage.completion_tokens,
                total_tokens=response.usage.total_tokens,
            )

        # Check for tool calls
        if message.tool_calls:
            tool_calls = [
                ToolCallRequest(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=json.loads(tc.function.arguments) if isinstance(tc.function.arguments, str) else tc.function.arguments,
                )
                for tc in message.tool_calls
            ]

            return ProviderToolCallsResponse(
                type="tool_calls",
                tool_calls=tool_calls,
                content=message.content or "",
                usage=usage,
            )

        return ProviderMessageResponse(
            type="message",
            content=message.content or "",
            usage=usage,
        )

    async def generate_stream(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> AsyncIterator[StreamChunk]:
        """Generate a streaming response from OpenAI."""
        converted_messages = _convert_messages(messages)

        # Build request parameters
        params: dict[str, Any] = {
            "model": self.model,
            "messages": converted_messages,
            "temperature": self.temperature,
            "stream": True,
        }

        if self.max_tokens:
            params["max_tokens"] = self.max_tokens

        if tools:
            params["tools"] = [_map_tool(tool) for tool in tools]
            params["tool_choice"] = "auto"

        # Stream response
        stream = await self.client.chat.completions.create(**params)

        current_tool_calls: dict[int, dict[str, Any]] = {}

        async for chunk in stream:
            delta = chunk.choices[0].delta

            # Handle content
            if delta.content:
                yield StreamChunk(
                    type="content",
                    content=delta.content,
                )

            # Handle tool calls
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index

                    if idx not in current_tool_calls:
                        current_tool_calls[idx] = {
                            "id": tc.id or "",
                            "name": tc.function.name if tc.function else "",
                            "arguments": "",
                        }

                    if tc.function and tc.function.arguments:
                        current_tool_calls[idx]["arguments"] += tc.function.arguments

            # Check if stream is done
            if chunk.choices[0].finish_reason:
                # Emit any accumulated tool calls
                for tool_call in current_tool_calls.values():
                    try:
                        args = json.loads(tool_call["arguments"]) if tool_call["arguments"] else {}
                    except json.JSONDecodeError:
                        args = {}

                    yield StreamChunk(
                        type="tool_call",
                        tool_call=ToolCallRequest(
                            id=tool_call["id"],
                            name=tool_call["name"],
                            arguments=args,
                        ),
                    )

                # Emit usage if available
                if hasattr(chunk, "usage") and chunk.usage:
                    yield StreamChunk(
                        type="usage",
                        usage=ProviderUsage(
                            input_tokens=chunk.usage.prompt_tokens,
                            output_tokens=chunk.usage.completion_tokens,
                            total_tokens=chunk.usage.total_tokens,
                        ),
                    )

                yield StreamChunk(type="done")

    def get_capabilities(self):
        """Get provider capabilities."""
        return {
            "streaming": True,
            "tool_calling": True,
            "vision": "vision" in self.model or "gpt-4" in self.model,
            "function_calling": True,
            "max_tokens": self.max_tokens,
            "supported_modalities": ["text", "image"],
        }


def _convert_messages(messages: list[ConversationMessage]) -> list[dict[str, Any]]:
    """Convert conversation messages to OpenAI format."""
    result: list[dict[str, Any]] = []

    for message in messages:
        if isinstance(message, SystemMessage):
            result.append({"role": "system", "content": message.content})

        elif isinstance(message, UserMessage):
            result.append({"role": "user", "content": message.content})

        elif isinstance(message, AssistantMessage):
            msg: dict[str, Any] = {"role": "assistant"}

            if message.content:
                msg["content"] = message.content

            if message.tool_calls:
                msg["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments),
                        },
                    }
                    for tc in message.tool_calls
                ]

            result.append(msg)

        elif isinstance(message, ToolMessage):
            result.append(
                {
                    "role": "tool",
                    "tool_call_id": message.tool_call_id,
                    "content": message.content,
                }
            )

    return result


def _map_tool(definition: ProviderToolDefinition) -> dict[str, Any]:
    """Map tool definition to OpenAI format."""
    return {
        "type": "function",
        "function": {
            "name": definition.name,
            "description": definition.description,
            "parameters": definition.parameters.model_dump() if definition.parameters else {"type": "object", "properties": {}},
        },
    }
