"""
Google Gemini provider with tool calling support.

Implements the same interface as other providers so it can be swapped via provider_factory.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional

import google.generativeai as genai

from ..core.types import (
    AssistantMessage,
    ConversationMessage,
    LLMProvider,
    ProviderMessageResponse,
    ProviderResponse,
    ProviderToolCallsResponse,
    ProviderToolDefinition,
    ProviderUsage,
    SystemMessage,
    ToolCallRequest,
    ToolMessage,
    UserMessage,
)


@dataclass
class GoogleProviderOptions:
    """Options for Google Gemini provider."""

    api_key: str
    model: str
    temperature: float = 0.0
    max_output_tokens: Optional[int] = None


class GoogleProvider(LLMProvider):
    """Google Gemini provider with tool calling support."""

    def __init__(self, options: GoogleProviderOptions):
        super().__init__("google", options.model)
        genai.configure(api_key=options.api_key)
        self.temperature = options.temperature
        self.max_output_tokens = options.max_output_tokens

    async def generate(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderResponse:
        """Generate a response using Gemini."""
        mapped = _map_conversation(messages)

        generation_config: dict[str, Any] = {}
        if self.temperature is not None:
            generation_config["temperature"] = self.temperature
        if self.max_output_tokens is not None:
            generation_config["max_output_tokens"] = self.max_output_tokens

        tool_defs = _map_tools(tools)
        model = genai.GenerativeModel(model_name=self.model, tools=tool_defs or None)

        response = await model.generate_content_async(
            contents=mapped["contents"] or _empty_user_content(),
            system_instruction=mapped.get("system"),
            generation_config=generation_config or None,
        )

        usage = _map_usage(getattr(response, "usage_metadata", None))
        tool_calls = _extract_tool_calls(response)
        content = (getattr(response, "text", None) or "").strip()

        if tool_calls:
            return ProviderToolCallsResponse(
                type="tool_calls",
                tool_calls=tool_calls,
                content=content,
                usage=usage,
            )

        return ProviderMessageResponse(
            type="message",
            content=content,
            usage=usage,
        )

    def get_capabilities(self):
        return {
            "streaming": False,
            "tool_calling": True,
            "vision": "vision" in self.model.lower(),
            "function_calling": True,
            "max_tokens": self.max_output_tokens,
            "supported_modalities": ["text"],
        }


def _map_conversation(messages: list[ConversationMessage]) -> dict[str, Any]:
    contents: list[dict[str, Any]] = []
    system_parts: list[str] = []

    for message in messages:
        if isinstance(message, SystemMessage):
            if message.content.strip():
                system_parts.append(message.content.strip())
        elif isinstance(message, UserMessage):
            contents.append({"role": "user", "parts": [{"text": message.content}]})
        elif isinstance(message, AssistantMessage):
            parts: list[dict[str, Any]] = []
            if message.content:
                parts.append({"text": message.content})
            if message.tool_calls:
                for call in message.tool_calls:
                    parts.append(
                        {
                            "function_call": {
                                "id": call.id or None,
                                "name": call.name,
                                "args": call.arguments or {},
                            }
                        }
                    )
            contents.append({"role": "model", "parts": parts or [{"text": ""}]})
        elif isinstance(message, ToolMessage):
            # Tool responses are fed back as functionResponse parts
            if not message.tool_call_id:
                continue
            parts = [
                {
                    "function_response": {
                        "name": getattr(message, "name", None) or "tool",
                        "response": _safe_json(message.content),
                        "id": message.tool_call_id,
                    }
                }
            ]
            contents.append({"role": "user", "parts": parts})

    return {
        "contents": contents,
        "system": "\n\n".join(system_parts) if system_parts else None,
    }


def _map_tools(tools: list[ProviderToolDefinition]) -> list[dict[str, Any]]:
    if not tools:
        return []

    declarations = []
    for tool in tools:
        parameters = tool.parameters.model_dump(by_alias=True) if tool.parameters else {"type": "object", "properties": {}}
        declarations.append(
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": parameters,
            }
        )

    return [{"function_declarations": declarations}]


def _extract_tool_calls(response: Any) -> list[ToolCallRequest]:
    tool_calls: list[ToolCallRequest] = []

    candidates = getattr(response, "candidates", None) or []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        parts = getattr(content, "parts", None) or []
        for part in parts:
            function_call = None
            if hasattr(part, "function_call"):
                function_call = getattr(part, "function_call")
            elif hasattr(part, "functionCall"):
                function_call = getattr(part, "functionCall")
            elif isinstance(part, dict):
                function_call = part.get("function_call") or part.get("functionCall")

            if not function_call:
                continue

            if isinstance(function_call, dict):
                name = function_call.get("name")
                arguments = function_call.get("args")
                call_id = function_call.get("id")
            else:
                name = getattr(function_call, "name", None)
                arguments = getattr(function_call, "args", None)
                call_id = getattr(function_call, "id", None)

            if not name:
                continue

            tool_calls.append(
                ToolCallRequest(
                    id=str(call_id or name),
                    name=str(name),
                    arguments=_to_record(arguments),
                )
            )

    return tool_calls


def _map_usage(metadata: Any) -> Optional[ProviderUsage]:
    if not metadata:
        return None

    return ProviderUsage(
        input_tokens=getattr(metadata, "prompt_token_count", None),
        output_tokens=getattr(metadata, "candidates_token_count", None),
        total_tokens=getattr(metadata, "total_token_count", None),
    )


def _safe_json(content: str) -> dict[str, Any]:
    text = content.strip() if isinstance(content, str) else ""
    if not text:
        return {"output": ""}

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    return {"output": text}


def _to_record(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def _empty_user_content() -> list[dict[str, Any]]:
    return [{"role": "user", "parts": [{"text": ""}]}]
