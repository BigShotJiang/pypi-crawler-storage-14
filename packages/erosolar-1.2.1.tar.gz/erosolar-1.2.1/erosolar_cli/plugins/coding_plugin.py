"""
Coding Plugin - Enhanced Code Analysis and Development Tools

Provides advanced coding capabilities beyond the core file operations:
- Code analysis (complexity, dependencies, patterns)
- Code generation templates
- Refactoring assistance
- Testing tools
- Dependency management

This plugin is OPTIONAL. Enable it for enhanced coding assistance.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core.tool_runtime import ToolDefinition, ToolSuite
from ..core.types import JSONSchemaObject
from . import Plugin, PluginCategory, PluginMetadata, register_plugin


@register_plugin
class CodingPlugin(Plugin):
    """Enhanced coding and development tools."""

    metadata = PluginMetadata(
        id="coding",
        name="Coding Tools",
        version="1.0.0",
        description="Enhanced code analysis, generation, refactoring, and testing tools",
        category=PluginCategory.CODING,
        author="Erosolar Team",
        requires_auth=False,
        dependencies=[],
        cli_commands=[],
    )

    def __init__(self, working_dir: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(working_dir, config)

    def get_tool_suites(self) -> List[ToolSuite]:
        """Return coding tool suites."""
        return [
            self._create_analysis_suite(),
            self._create_generation_suite(),
            self._create_refactoring_suite(),
            self._create_testing_suite(),
        ]

    def _create_analysis_suite(self) -> ToolSuite:
        """Create code analysis tools."""
        tools = []

        async def analyze_complexity(file_path: str) -> Dict[str, Any]:
            """Analyze code complexity metrics."""
            import ast
            import math

            full_path = Path(self.working_dir) / file_path
            if not full_path.exists():
                return {"error": f"File not found: {file_path}"}

            code = full_path.read_text()

            try:
                tree = ast.parse(code)
            except SyntaxError as e:
                return {"error": f"Syntax error: {e}"}

            # Count complexity indicators
            functions = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
            branches = sum(1 for n in ast.walk(tree) if isinstance(n, (ast.If, ast.For, ast.While, ast.Try)))

            # Cyclomatic complexity estimation
            cyclomatic = 1 + branches

            # Lines of code
            lines = code.split('\n')
            loc = len([l for l in lines if l.strip() and not l.strip().startswith('#')])

            # Halstead metrics (simplified)
            operators = sum(1 for n in ast.walk(tree) if isinstance(n, (ast.BinOp, ast.UnaryOp, ast.Compare)))
            operands = sum(1 for n in ast.walk(tree) if isinstance(n, (ast.Name, ast.Constant)))

            return {
                "file": file_path,
                "lines_of_code": loc,
                "functions": len(functions),
                "classes": len(classes),
                "cyclomatic_complexity": cyclomatic,
                "complexity_rating": "low" if cyclomatic < 10 else "medium" if cyclomatic < 20 else "high",
                "operators": operators,
                "operands": operands,
                "maintainability_index": max(0, min(100, 171 - 5.2 * math.log(max(1, loc)) - 0.23 * cyclomatic)),
            }

        tools.append(ToolDefinition(
            name="analyze_complexity",
            description="Analyze code complexity metrics including cyclomatic complexity and maintainability index",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to analyze",
                    }
                },
                required=["file_path"],
            ),
            handler=analyze_complexity,
        ))

        async def find_dependencies(file_path: str) -> Dict[str, Any]:
            """Find imports and dependencies in a file."""
            import ast

            full_path = Path(self.working_dir) / file_path
            if not full_path.exists():
                return {"error": f"File not found: {file_path}"}

            code = full_path.read_text()

            try:
                tree = ast.parse(code)
            except SyntaxError as e:
                return {"error": f"Syntax error: {e}"}

            imports = []
            from_imports = []

            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    module = node.module or ""
                    for alias in node.names:
                        from_imports.append(f"{module}.{alias.name}")

            # Classify as stdlib, third-party, or local
            import sys
            stdlib_modules = set(sys.stdlib_module_names) if hasattr(sys, 'stdlib_module_names') else set()

            stdlib = []
            third_party = []
            local = []

            for imp in imports + from_imports:
                base = imp.split('.')[0]
                if base in stdlib_modules:
                    stdlib.append(imp)
                elif imp.startswith('.') or any(
                    (Path(self.working_dir) / f"{base}.py").exists()
                    or (Path(self.working_dir) / base).is_dir()
                    for _ in [None]
                ):
                    local.append(imp)
                else:
                    third_party.append(imp)

            return {
                "file": file_path,
                "total_imports": len(imports) + len(from_imports),
                "stdlib": sorted(set(stdlib)),
                "third_party": sorted(set(third_party)),
                "local": sorted(set(local)),
            }

        tools.append(ToolDefinition(
            name="find_dependencies",
            description="Find and categorize imports in a Python file",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to analyze",
                    }
                },
                required=["file_path"],
            ),
            handler=find_dependencies,
        ))

        return ToolSuite(
            id="plugin.coding.analysis",
            name="Code Analysis",
            description="Analyze code complexity, dependencies, and patterns",
            tools=tools,
        )

    def _create_generation_suite(self) -> ToolSuite:
        """Create code generation tools."""
        tools = []

        async def generate_docstring(
            code: str,
            style: str = "google",
        ) -> Dict[str, Any]:
            """Generate a docstring for given code."""
            import ast

            try:
                tree = ast.parse(code)
            except SyntaxError as e:
                return {"error": f"Syntax error: {e}"}

            # Find the first function or class
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    params = [arg.arg for arg in node.args.args if arg.arg != 'self']

                    if style == "google":
                        docstring = f'"""Brief description.\n\nArgs:'
                        for param in params:
                            docstring += f'\n    {param}: Description of {param}.'
                        docstring += '\n\nReturns:\n    Description of return value.\n"""'
                    elif style == "numpy":
                        docstring = f'"""\nBrief description.\n\nParameters\n----------'
                        for param in params:
                            docstring += f'\n{param} : type\n    Description of {param}.'
                        docstring += '\n\nReturns\n-------\ntype\n    Description.\n"""'
                    else:
                        docstring = f'"""Brief description."""'

                    return {
                        "function_name": node.name,
                        "parameters": params,
                        "docstring": docstring,
                        "style": style,
                    }

            return {"error": "No function found in code"}

        tools.append(ToolDefinition(
            name="generate_docstring",
            description="Generate a docstring template for a function",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "code": {
                        "type": "string",
                        "description": "Function code to generate docstring for",
                    },
                    "style": {
                        "type": "string",
                        "enum": ["google", "numpy", "sphinx"],
                        "default": "google",
                        "description": "Docstring style",
                    },
                },
                required=["code"],
            ),
            handler=generate_docstring,
        ))

        return ToolSuite(
            id="plugin.coding.generation",
            name="Code Generation",
            description="Generate code templates, docstrings, and boilerplate",
            tools=tools,
        )

    def _create_refactoring_suite(self) -> ToolSuite:
        """Create refactoring tools."""
        tools = []

        async def suggest_refactorings(file_path: str) -> Dict[str, Any]:
            """Suggest refactorings for a file."""
            import ast

            full_path = Path(self.working_dir) / file_path
            if not full_path.exists():
                return {"error": f"File not found: {file_path}"}

            code = full_path.read_text()
            lines = code.split('\n')

            try:
                tree = ast.parse(code)
            except SyntaxError as e:
                return {"error": f"Syntax error: {e}"}

            suggestions = []

            for node in ast.walk(tree):
                # Long functions
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    func_lines = node.end_lineno - node.lineno if hasattr(node, 'end_lineno') else 0
                    if func_lines > 50:
                        suggestions.append({
                            "type": "extract_function",
                            "location": f"line {node.lineno}",
                            "message": f"Function '{node.name}' is {func_lines} lines long. Consider extracting smaller functions.",
                            "severity": "medium",
                        })

                    # Too many parameters
                    param_count = len(node.args.args)
                    if param_count > 5:
                        suggestions.append({
                            "type": "parameter_object",
                            "location": f"line {node.lineno}",
                            "message": f"Function '{node.name}' has {param_count} parameters. Consider using a parameter object.",
                            "severity": "low",
                        })

                # Deeply nested code
                if isinstance(node, (ast.If, ast.For, ast.While)):
                    depth = sum(1 for _ in ast.walk(node) if isinstance(_, (ast.If, ast.For, ast.While)))
                    if depth > 3:
                        suggestions.append({
                            "type": "flatten_nesting",
                            "location": f"line {node.lineno}",
                            "message": "Deeply nested code detected. Consider early returns or guard clauses.",
                            "severity": "medium",
                        })

            # Long lines
            for i, line in enumerate(lines, 1):
                if len(line) > 120:
                    suggestions.append({
                        "type": "line_length",
                        "location": f"line {i}",
                        "message": f"Line is {len(line)} characters. Consider breaking it up.",
                        "severity": "low",
                    })

            return {
                "file": file_path,
                "total_suggestions": len(suggestions),
                "suggestions": suggestions[:20],  # Limit to 20
            }

        tools.append(ToolDefinition(
            name="suggest_refactorings",
            description="Analyze code and suggest refactoring opportunities",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to analyze",
                    }
                },
                required=["file_path"],
            ),
            handler=suggest_refactorings,
        ))

        return ToolSuite(
            id="plugin.coding.refactoring",
            name="Refactoring",
            description="Suggest and assist with code refactoring",
            tools=tools,
        )

    def _create_testing_suite(self) -> ToolSuite:
        """Create testing tools."""
        tools = []

        async def generate_test_stub(
            file_path: str,
            framework: str = "pytest",
        ) -> Dict[str, Any]:
            """Generate test stubs for functions in a file."""
            import ast

            full_path = Path(self.working_dir) / file_path
            if not full_path.exists():
                return {"error": f"File not found: {file_path}"}

            code = full_path.read_text()

            try:
                tree = ast.parse(code)
            except SyntaxError as e:
                return {"error": f"Syntax error: {e}"}

            # Find all functions
            functions = []
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if not node.name.startswith('_'):  # Skip private functions
                        functions.append({
                            "name": node.name,
                            "params": [arg.arg for arg in node.args.args if arg.arg != 'self'],
                            "is_async": isinstance(node, ast.AsyncFunctionDef),
                        })

            # Generate test stubs
            module_name = Path(file_path).stem
            test_code = f'"""Tests for {module_name}."""\n\n'

            if framework == "pytest":
                test_code += "import pytest\n"
                test_code += f"from {module_name} import *\n\n"

                for func in functions:
                    test_name = f"test_{func['name']}"
                    if func['is_async']:
                        test_code += f"@pytest.mark.asyncio\n"
                        test_code += f"async def {test_name}():\n"
                    else:
                        test_code += f"def {test_name}():\n"

                    test_code += f'    """Test {func["name"]} function."""\n'
                    test_code += "    # Arrange\n"
                    test_code += "    # TODO: Set up test data\n\n"
                    test_code += "    # Act\n"
                    if func['is_async']:
                        test_code += f"    # result = await {func['name']}(...)\n\n"
                    else:
                        test_code += f"    # result = {func['name']}(...)\n\n"
                    test_code += "    # Assert\n"
                    test_code += "    # TODO: Add assertions\n"
                    test_code += "    pass\n\n"

            return {
                "source_file": file_path,
                "framework": framework,
                "functions_found": len(functions),
                "test_code": test_code,
                "suggested_filename": f"test_{module_name}.py",
            }

        tools.append(ToolDefinition(
            name="generate_test_stub",
            description="Generate test stubs for functions in a file",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "file_path": {
                        "type": "string",
                        "description": "Path to the source file",
                    },
                    "framework": {
                        "type": "string",
                        "enum": ["pytest", "unittest"],
                        "default": "pytest",
                        "description": "Testing framework to use",
                    },
                },
                required=["file_path"],
            ),
            handler=generate_test_stub,
        ))

        return ToolSuite(
            id="plugin.coding.testing",
            name="Testing",
            description="Generate tests and run test suites",
            tools=tools,
        )
