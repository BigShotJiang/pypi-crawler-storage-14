"""
erosolar_cli - Python AI Agent Framework

A full-featured Python CLI for autonomous AI agents with multi-provider support,
recursive self-improvement capabilities, and competitive multi-agent reinforcement
learning through the Alpha Zero 2 framework.

Author: Bo Shang
Education: Tufts University, 2010
GitHub: github.com/dragonghidra
Repository: github.com/dragonghidra/erosolar-cli-RE-claude-code

Tech Stack:
    Languages:
        - Python 3.10+ (primary)
        - TypeScript (Node.js 20+)

    AI Provider Integration:
        - anthropic / @anthropic-ai/sdk (Claude API)
        - openai (OpenAI API)
        - google-generativeai / @google/genai (Gemini API)
        - tiktoken (token counting)

    CLI & Terminal UI:
        Python: typer, rich, prompt-toolkit
        TypeScript: chalk, boxen, gradient-string, ora, nanospinner

    Async & Data:
        - aiohttp, aiofiles (async operations)
        - pydantic, jsonschema (validation)
        - python-dotenv (configuration)

    Development & Testing:
        - pytest, pytest-asyncio (testing)
        - mypy (type checking)
        - ruff, eslint (linting)

Key Features:
    - Multi-provider AI integration (Anthropic, OpenAI, Google)
    - Rich terminal UI with streaming indicators
    - Interactive shell with prompt-toolkit
    - Tool runtime with caching and validation
    - Context management and pruning
    - Session persistence

Alpha Zero 2 Research Initiative:
    A competitive multi-agent RL framework where two autonomous erosolar_cli agents
    compete on code optimization tasks while recursively improving their own
    implementations through self-modification.

    Components:
        - CompetitiveFramework: Dual-agent tournament orchestration
        - RewardSystem: AST-based code quality metrics
        - SelfModificationEngine: Version-controlled self-improvement

    See: erosolar_cli/alpha_zero/

License: MIT
"""

__version__ = "1.2.1"
__author__ = "Bo Shang"
__email__ = "bo@shang.software"
__license__ = "MIT"

__all__ = [
    "config",
    "rulebook",
    "langgraph_app",
    "tooling",
    "cli",
    "alpha_zero",
]

# Tech stack metadata (strictly erosolar_cli dependencies)
TECH_STACK = {
    "languages": {
        "python": ">=3.10",
        "typescript": ">=5.3",
        "nodejs": ">=20.0",
    },
    "ai_providers": {
        "anthropic": ">=0.32.0",
        "openai": ">=1.0.0",
        "google-generativeai": ">=0.4.0",
        "tiktoken": ">=0.5.0",
    },
    "cli_python": {
        "typer": ">=0.12.3",
        "rich": ">=13.7.0",
        "prompt-toolkit": ">=3.0.43",
    },
    "cli_typescript": {
        "@anthropic-ai/sdk": ">=0.32.0",
        "@google/genai": ">=1.29.1",
        "chalk": ">=4.1.2",
        "boxen": ">=5.1.2",
        "gradient-string": ">=2.0.2",
        "ora": ">=5.4.1",
        "nanospinner": ">=1.1.0",
    },
    "async_data": {
        "aiohttp": ">=3.9.0",
        "aiofiles": ">=23.2.0",
        "pydantic": ">=2.5.0",
        "jsonschema": ">=4.20.0",
        "python-dotenv": ">=1.0.0",
    },
    "development": {
        "pytest": ">=7.4.0",
        "pytest-asyncio": ">=0.21.0",
        "mypy": ">=1.7.0",
        "ruff": ">=0.6.8",
        "eslint": ">=8.45.0",
        "ts-node": ">=10.9.2",
    },
}
