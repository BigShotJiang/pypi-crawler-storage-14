"""
Workspace context capture with intelligent file tree generation and
priority document extraction.

Features:
- File tree generation with configurable depth
- Priority document capture (README.md)
- Strict validation to prevent context overflow
- Environment variable configuration
- Auto-truncation safety
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .core.errors.error_types import ContextOverflowError, ResourceLimitError

# Priority documents to capture
PRIORITY_DOCS = ["README.md"]

# Directories to ignore during traversal
IGNORED_DIRS = {
    ".git",
    "node_modules",
    "dist",
    ".erosolar",
    "build",
    "coverage",
    ".next",
    "out",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    "venv",
    ".venv",
    "env",
    "target",
    "bin",
    "obj",
    ".idea",
    ".vscode",
    ".DS_Store",
}

# Default configuration
DEFAULT_TREE_DEPTH = 1
DEFAULT_MAX_ENTRIES = 30
DEFAULT_DOC_LIMIT = 200

# Absolute safety limits
ABSOLUTE_MAX_CHARS = 5000
ABSOLUTE_MAX_LINES = 100
ABSOLUTE_MAX_FILE_ENTRIES = 50
ABSOLUTE_MAX_DOC_CHARS = 300
WARNING_THRESHOLD = 0.7


@dataclass
class WorkspaceCaptureOptions:
    """Options for workspace context capture."""

    tree_depth: Optional[int] = None
    max_entries: Optional[int] = None
    doc_excerpt_limit: Optional[int] = None


@dataclass
class ContextStats:
    """Statistics about workspace context size."""

    total_chars: int
    total_lines: int
    estimated_tokens: int
    file_entries: int
    doc_chars: int


@dataclass
class ValidationResult:
    """Result of validation with errors and warnings."""

    valid: bool
    errors: list[str]
    warnings: list[str]
    stats: ContextStats


@dataclass
class WorkspaceContextSafe:
    """Validated and safe workspace context."""

    content: str
    stats: ContextStats


def resolve_workspace_capture_options(env: Optional[dict[str, str]] = None) -> WorkspaceCaptureOptions:
    """
    Resolve workspace capture options from environment variables.

    Args:
        env: Environment variables dict (defaults to os.environ)

    Returns:
        Workspace capture options
    """
    if env is None:
        env = os.environ

    return WorkspaceCaptureOptions(
        tree_depth=_parse_positive_int(env.get("EROSOLAR_CONTEXT_TREE_DEPTH")),
        max_entries=_parse_positive_int(env.get("EROSOLAR_CONTEXT_MAX_ENTRIES")),
        doc_excerpt_limit=_parse_positive_int(env.get("EROSOLAR_CONTEXT_DOC_LIMIT")),
    )


def build_workspace_context(root: str, options: Optional[WorkspaceCaptureOptions] = None) -> str:
    """
    Build workspace context string with file tree and priority documents.

    Args:
        root: Root directory path
        options: Capture options (defaults to environment-based config)

    Returns:
        Formatted workspace context string
    """
    if options is None:
        options = WorkspaceCaptureOptions()

    # Validate options before building
    options_validation = validate_workspace_options(options)
    if not options_validation.valid:
        print(f"[Workspace Context] Invalid options: {options_validation.errors}")
        raise ValueError(f"Invalid workspace options: {', '.join(options_validation.errors)}")

    # Log warnings if any
    if options_validation.warnings:
        print(f"[Workspace Context] Warnings: {options_validation.warnings}")

    tree_depth = options.tree_depth if options.tree_depth is not None else DEFAULT_TREE_DEPTH
    max_entries = options.max_entries if options.max_entries is not None else DEFAULT_MAX_ENTRIES
    doc_limit = options.doc_excerpt_limit if options.doc_excerpt_limit is not None else DEFAULT_DOC_LIMIT

    try:
        tree_lines = _format_file_tree(root, tree_depth, max_entries)
        doc_snippets = _capture_priority_docs(root, doc_limit)

        sections = [f"cwd: {root}", "files:", *tree_lines]
        if doc_snippets:
            sections.append("\n".join(doc_snippets))

        raw_content = "\n".join(section for section in sections if section.strip())

        # Validate and enforce limits on final output
        safe = safe_workspace_context(
            raw_content,
            truncate=True,
            throw_on_error=False,
        )

        # Log stats if debugging enabled
        if os.environ.get("DEBUG_CONTEXT"):
            print(f"[Workspace Context] Stats: {safe.stats}")

        return safe.content
    except Exception as error:
        message = str(error)
        return f"Workspace context unavailable ({message})."


def validate_workspace_options(options: WorkspaceCaptureOptions) -> ValidationResult:
    """
    Validate workspace capture options BEFORE building context.

    Args:
        options: Options to validate

    Returns:
        Validation result with errors and warnings
    """
    errors: list[str] = []
    warnings: list[str] = []

    # Validate tree depth
    if options.tree_depth is not None:
        if options.tree_depth < 0:
            errors.append("tree_depth cannot be negative")
        if options.tree_depth > 2:
            errors.append(f"tree_depth {options.tree_depth} exceeds maximum of 2")
        if options.tree_depth > 1:
            warnings.append("tree_depth > 1 can significantly increase context size")

    # Validate max entries
    if options.max_entries is not None:
        if options.max_entries < 0:
            errors.append("max_entries cannot be negative")
        if options.max_entries > ABSOLUTE_MAX_FILE_ENTRIES:
            errors.append(f"max_entries {options.max_entries} exceeds maximum of {ABSOLUTE_MAX_FILE_ENTRIES}")
        if options.max_entries > 40:
            warnings.append("max_entries > 40 may use significant context")

    # Validate doc excerpt limit
    if options.doc_excerpt_limit is not None:
        if options.doc_excerpt_limit < 0:
            errors.append("doc_excerpt_limit cannot be negative")
        if options.doc_excerpt_limit > ABSOLUTE_MAX_DOC_CHARS:
            errors.append(f"doc_excerpt_limit {options.doc_excerpt_limit} exceeds maximum of {ABSOLUTE_MAX_DOC_CHARS}")
        if options.doc_excerpt_limit > 250:
            warnings.append("doc_excerpt_limit > 250 may use significant context")

    return ValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        stats=ContextStats(
            total_chars=0,
            total_lines=0,
            estimated_tokens=0,
            file_entries=options.max_entries or 0,
            doc_chars=options.doc_excerpt_limit or 0,
        ),
    )


def validate_workspace_context(content: str) -> ValidationResult:
    """
    Validate workspace context AFTER building - CRITICAL SAFETY CHECK.

    This is the final line of defense against context explosion.

    Args:
        content: Workspace context content

    Returns:
        Validation result with errors, warnings, and stats
    """
    errors: list[str] = []
    warnings: list[str] = []

    # Count basic metrics
    total_chars = len(content)
    lines = content.split("\n")
    total_lines = len(lines)
    estimated_tokens = _estimate_tokens(content)

    # Count file entries (lines that look like file paths)
    file_entries = sum(
        1
        for line in lines
        if line.strip() and not line.startswith("---") and not line.startswith("cwd:")
    )

    # Count chars in priority docs section
    doc_chars = 0
    if "---" in content:
        for doc in PRIORITY_DOCS:
            if f"--- {doc} ---" in content:
                start = content.find(f"--- {doc} ---")
                end = content.find("\n\n", start)
                if end == -1:
                    end = len(content)
                doc_chars += end - start

    stats = ContextStats(
        total_chars=total_chars,
        total_lines=total_lines,
        estimated_tokens=estimated_tokens,
        file_entries=file_entries,
        doc_chars=doc_chars,
    )

    # CRITICAL: Check absolute maximum character limit
    if total_chars > ABSOLUTE_MAX_CHARS:
        error = ContextOverflowError(total_chars, ABSOLUTE_MAX_CHARS, "chars", is_recoverable=True)
        errors.append(str(error))

    # CRITICAL: Check absolute maximum line limit
    if total_lines > ABSOLUTE_MAX_LINES:
        error = ContextOverflowError(total_lines, ABSOLUTE_MAX_LINES, "lines", is_recoverable=True)
        errors.append(str(error))

    # CRITICAL: Check absolute maximum file entries
    if file_entries > ABSOLUTE_MAX_FILE_ENTRIES:
        error = ResourceLimitError("file entries", file_entries, ABSOLUTE_MAX_FILE_ENTRIES, is_recoverable=False)
        errors.append(str(error))

    # WARNING: Approaching limits
    if total_chars > ABSOLUTE_MAX_CHARS * WARNING_THRESHOLD:
        pct = round(total_chars / ABSOLUTE_MAX_CHARS * 100)
        warnings.append(
            f"Context size {total_chars} chars is {pct}% of maximum. "
            f"Consider reducing tree_depth, max_entries, or doc_excerpt_limit."
        )

    if estimated_tokens > 1000:
        warnings.append(f"Estimated {estimated_tokens} tokens in workspace context. This is high and may impact performance.")

    return ValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        stats=stats,
    )


def truncate_workspace_context(content: str) -> WorkspaceContextSafe:
    """
    Safe truncation - if content exceeds limits, truncate intelligently.

    Args:
        content: Content to truncate

    Returns:
        Truncated content with stats
    """
    validation = validate_workspace_context(content)

    # If valid, return as-is
    if validation.valid:
        return WorkspaceContextSafe(content=content, stats=validation.stats)

    # CRITICAL: Content exceeds limits, must truncate
    lines = content.split("\n")
    truncated_lines: list[str] = []
    char_count = 0

    # Keep up to absolute maximums
    for line in lines:
        if len(truncated_lines) >= ABSOLUTE_MAX_LINES:
            break
        if char_count + len(line) > ABSOLUTE_MAX_CHARS:
            break

        truncated_lines.append(line)
        char_count += len(line) + 1  # +1 for newline

    # Add truncation notice
    if len(truncated_lines) < len(lines):
        truncated_lines.append("")
        truncated_lines.append("[Workspace context truncated to prevent context overflow]")
        truncated_lines.append(f"[Showing {len(truncated_lines)} of {len(lines)} lines]")

    truncated_content = "\n".join(truncated_lines)
    stats = validate_workspace_context(truncated_content).stats

    return WorkspaceContextSafe(content=truncated_content, stats=stats)


def safe_workspace_context(
    content: Optional[str],
    truncate: bool = True,
    throw_on_error: bool = False,
) -> WorkspaceContextSafe:
    """
    Validate and enforce limits in a single call - RECOMMENDED USAGE.

    Args:
        content: Content to validate
        truncate: Whether to auto-truncate if too large
        throw_on_error: Whether to throw on validation errors

    Returns:
        Safe workspace context with stats
    """
    if not content:
        return WorkspaceContextSafe(
            content="",
            stats=ContextStats(
                total_chars=0,
                total_lines=0,
                estimated_tokens=0,
                file_entries=0,
                doc_chars=0,
            ),
        )

    validation = validate_workspace_context(content)

    # Log warnings to console
    if validation.warnings:
        print("[Workspace Context Validator] Warnings:")
        for warning in validation.warnings:
            print(f"  - {warning}")

    # Handle errors
    if not validation.valid:
        print("[Workspace Context Validator] CRITICAL ERRORS:")
        for error in validation.errors:
            print(f"  - {error}")

        if throw_on_error:
            raise ValueError(f"Workspace context validation failed:\n{chr(10).join(validation.errors)}")

        if truncate:
            print("[Workspace Context Validator] Auto-truncating to safe limits...")
            return truncate_workspace_context(content)

    return WorkspaceContextSafe(content=content, stats=validation.stats)


def _capture_priority_docs(root: str, doc_limit: int) -> list[str]:
    """
    Capture priority documentation files.

    Args:
        root: Root directory
        doc_limit: Character limit per document

    Returns:
        List of formatted document snippets
    """
    root_path = Path(root)
    result: list[str] = []

    for name in PRIORITY_DOCS:
        doc_path = root_path / name
        if doc_path.exists():
            try:
                content = doc_path.read_text(encoding="utf-8")
                # Safety: Hard limit to prevent context explosion
                safe_limit = min(doc_limit, ABSOLUTE_MAX_DOC_CHARS)
                snippet = content[:safe_limit] + "\n..." if len(content) > safe_limit else content
                result.append(f"--- {name} ---\n{snippet.strip()}")
            except Exception:
                result.append(f"--- {name} ---\n[Could not read file]")

    return result


def _format_file_tree(root: str, max_depth: int, max_entries: int) -> list[str]:
    """
    Format file tree with indentation.

    Args:
        root: Root directory
        max_depth: Maximum depth to traverse
        max_entries: Maximum entries to include

    Returns:
        List of formatted tree lines
    """
    lines: list[str] = []
    root_path = Path(root)

    def walk(current: Path, depth: int, prefix: str) -> None:
        if depth > max_depth or len(lines) >= max_entries:
            return

        try:
            entries = sorted(
                [e for e in current.iterdir() if e.name not in IGNORED_DIRS],
                key=lambda e: e.name.lower(),
            )
        except (PermissionError, OSError):
            return

        for entry in entries:
            if len(lines) >= max_entries:
                break

            is_dir = entry.is_dir()
            lines.append(f"{prefix}{entry.name}{'/' if is_dir else ''}")

            if is_dir and depth < max_depth:
                walk(entry, depth + 1, f"{prefix}  ")

    walk(root_path, 0, "")
    return lines


def _parse_positive_int(raw: Optional[str]) -> Optional[int]:
    """Parse positive integer from string."""
    if not raw:
        return None
    try:
        value = int(raw)
        return value if value > 0 else None
    except ValueError:
        return None


def _estimate_tokens(text: str) -> int:
    """Estimate token count (rough: 1 token ≈ 4 characters)."""
    return (len(text) + 3) // 4
