# ARSC/__init__.py
from .core import process_faa, compute_ARSC_extended

__version__ = "0.1.4"
__author__ = "Satoshi Nishino"