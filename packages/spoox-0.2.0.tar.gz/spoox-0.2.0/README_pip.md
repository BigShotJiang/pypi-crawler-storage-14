## SPOOX

<br>
  
**SPOOX – SPlit lOOp eXplore**

A terminal-integrated, LLM-powered multi-agent system designed to assist directly within the terminal.
The agent architecture is based on the SPOOX MAS framework,
providing a structured approach to multi-agent topology and communication design.

More information and code are available on the [Spoox GitHub repository](https://github.com/plaume8/spoox).

<br>

Authors: 
[Linus Sander](mailto:linus.sander@tum.de),
[Fengjunjie Pan](mailto:f.pan@tum.de),
[Alois Knoll](mailto:k@tum.de)

