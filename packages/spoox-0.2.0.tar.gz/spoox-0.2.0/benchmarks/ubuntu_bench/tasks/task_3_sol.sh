# 1. copy sample solution .gitignore file
cp -f /opt/.gitignore ~/new_project/.gitignore