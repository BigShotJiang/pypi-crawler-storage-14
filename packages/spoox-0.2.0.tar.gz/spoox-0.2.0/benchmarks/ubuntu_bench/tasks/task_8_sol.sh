# 1. copy sample solution template file
cp /opt/expected_template.md ~/template.md