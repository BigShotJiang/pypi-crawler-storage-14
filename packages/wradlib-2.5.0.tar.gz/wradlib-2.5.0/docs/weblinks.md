# Web resources

```{bibliography} refs_links.bib
---
all:
style: plain
labelprefix: B
---
```
