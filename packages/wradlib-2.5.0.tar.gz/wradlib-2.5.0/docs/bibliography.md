# Bibliography

This page lists the referenced papers describing implemented algorithms.

```{bibliography} refs.bib
---
all:
style: wrlstyle
labelprefix:
---
```
