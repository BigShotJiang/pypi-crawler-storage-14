import logging

log = logging.getLogger('david8')
