"""Package for models defined by the Document type."""
