"""Package for models defining NLP artifacts."""
