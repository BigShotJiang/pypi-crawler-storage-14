"""Tests for chart backends."""
