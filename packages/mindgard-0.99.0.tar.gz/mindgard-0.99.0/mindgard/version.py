# Standard library imports
from importlib.metadata import version

VERSION = version("mindgard")
