"""Internal package for certbot-dns-hostinger."""
