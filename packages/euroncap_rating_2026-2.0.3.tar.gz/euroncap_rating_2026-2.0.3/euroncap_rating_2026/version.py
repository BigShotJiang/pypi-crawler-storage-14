import importlib.metadata

VERSION = importlib.metadata.version(__package__ or "euroncap_rating_2026")
