"""
Plugin SDK Configuration and Factory Functions.

Provides convenient configuration classes and factory functions for creating
PluginManager instances with different backend modes.
"""

import os
import logging
from typing import Optional, Literal
from dataclasses import dataclass

from plugin_adk.core.plugin.manager import PluginManager
from plugin_adk.core.coordination.discovery import ServiceDiscovery
from plugin_adk.core.coordination.backends import (
    MemoryDiscoveryBackend,
    RedisDiscoveryBackend
)
from plugin_adk.core.coordination.redis.pool import RedisPoolConfig
from plugin_adk.core.communication.memory_bus import MemoryEventBus
from plugin_adk.core.communication.redis_bus import RedisEventBus
from plugin_adk.core.coordination.backends.smart import SmartDiscoveryBackend
from plugin_adk.core.coordination.backends.sqlite import SqliteDiscoveryBackend
from plugin_adk.core.storage.sqlite import SqliteSessionStorage
from plugin_adk.core.memory.lancedb import LanceDBMemoryService


logger = logging.getLogger(__name__)


@dataclass
class SDKConfig:
    """
    Plugin SDK configuration.
    
    Args:
        discovery_mode: Service discovery mode ('memory' or 'redis')
        event_bus_mode: Event bus mode ('memory' or 'redis')
        redis_host: Redis host (default: localhost)
        redis_port: Redis port (default: 6379)
        redis_db: Redis database number (default: 0)
        redis_password: Redis password (optional)
        redis_url: Redis URL (optional, overrides host/port/db if provided)
        enable_security: Enable security checks (default: True)
    """
    discovery_mode: Literal['memory', 'redis', 'smart'] = 'memory'
    event_bus_mode: Literal['memory', 'redis'] = 'memory'
    
    # Redis configuration
    redis_host: str = 'localhost'
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: Optional[str] = None
    redis_url: Optional[str] = None
    
    # Storage configuration
    storage_mode: Literal['memory', 'sqlite'] = 'sqlite'
    sqlite_path: str = 'data/storage.db'
    
    # Memory configuration
    enable_memory: bool = False
    memory_provider: Literal['lancedb'] = 'lancedb'
    lancedb_path: str = 'data/lancedb'
    
    # PluginManager configuration
    enable_security: bool = True
    
    @classmethod
    def from_env(cls) -> 'SDKConfig':
        """
        Create configuration from environment variables.
        
        Environment variables:
            DISCOVERY_MODE: 'memory' or 'redis'
            EVENT_BUS_MODE: 'memory' or 'redis'
            REDIS_HOST: Redis host
            REDIS_PORT: Redis port
            REDIS_DB: Redis database
            REDIS_PASSWORD: Redis password
            REDIS_URL: Redis URL (overrides other Redis settings)
        """
        return cls(
            discovery_mode=os.getenv('DISCOVERY_MODE', 'memory'),
            event_bus_mode=os.getenv('EVENT_BUS_MODE', 'memory'),
            redis_host=os.getenv('REDIS_HOST', 'localhost'),
            redis_port=int(os.getenv('REDIS_PORT', '6379')),
            redis_db=int(os.getenv('REDIS_DB', '0')),
            redis_password=os.getenv('REDIS_PASSWORD'),
            redis_url=os.getenv('REDIS_URL'),
            storage_mode=os.getenv('STORAGE_MODE', 'sqlite'),
            sqlite_path=os.getenv('SQLITE_PATH', 'data/storage.db'),
            enable_memory=os.getenv('ENABLE_MEMORY', 'false').lower() == 'true',
            memory_provider=os.getenv('MEMORY_PROVIDER', 'lancedb'),
            lancedb_path=os.getenv('LANCEDB_PATH', 'data/lancedb'),
        )
    
    def get_redis_pool_config(self) -> RedisPoolConfig:
        """Get RedisPoolConfig from this config"""
        if self.redis_url:
            # Parse URL
            import urllib.parse as urlparse
            parsed = urlparse.urlparse(self.redis_url)
            return RedisPoolConfig(
                host=parsed.hostname or self.redis_host,
                port=parsed.port or self.redis_port,
                db=int(parsed.path.lstrip('/')) if parsed.path and parsed.path != '/' else self.redis_db,
                password=parsed.password or self.redis_password
            )
        else:
            return RedisPoolConfig(
                host=self.redis_host,
                port=self.redis_port,
                db=self.redis_db,
                password=self.redis_password
            )


async def create_manager(config: Optional[SDKConfig] = None) -> PluginManager:
    """
    Create a PluginManager with the specified configuration.
    
    Args:
        config: SDK configuration. If None, uses default (all memory)
        
    Returns:
        Configured PluginManager instance
        
    Example:
        >>> # Memory mode (default)
        >>> manager = await create_manager()
        
        >>> # Redis mode
        >>> config = SDKConfig(
        ...     discovery_mode='redis',
        ...     event_bus_mode='redis',
        ...     redis_url='redis://localhost:6379'
        ... )
        >>> manager = await create_manager(config)
        
        >>> # From environment
        >>> config = SDKConfig.from_env()
        >>> manager = await create_manager(config)
    """
    if config is None:
        config = SDKConfig()
    
    # Create service discovery
    discovery = None
    if config.discovery_mode == 'redis':
        logger.info("Initializing Redis service discovery...")
        redis_config = config.get_redis_pool_config()
        backend = RedisDiscoveryBackend(redis_config)
        await backend.start()
        discovery = ServiceDiscovery(backend=backend)
        await discovery.start()
        logger.info("Redis service discovery started")
    elif config.discovery_mode == 'memory':
        logger.info("Initializing memory service discovery...")
        backend = MemoryDiscoveryBackend()
        discovery = ServiceDiscovery(backend=backend)
        await discovery.start()
        logger.info("Memory service discovery started")
    elif config.discovery_mode == 'smart':
        logger.info("Initializing Smart (Hybrid) service discovery...")
        redis_config = config.get_redis_pool_config()
        # Use sqlite_path for local cache, maybe with a suffix or separate file
        cache_path = config.sqlite_path.replace('.db', '_discovery_cache.db')
        backend = SmartDiscoveryBackend(redis_config=redis_config, sqlite_path=cache_path)
        await backend.start()
        discovery = ServiceDiscovery(backend=backend)
        await discovery.start()
        logger.info("Smart service discovery started")
    
    # Create event bus
    event_bus = None
    if config.event_bus_mode == 'redis':
        logger.info("Initializing Redis event bus...")
        redis_config = config.get_redis_pool_config()
        event_bus = RedisEventBus(redis_config)
        await event_bus.start()
        logger.info("Redis event bus started")
    elif config.event_bus_mode == 'memory':
        logger.info("Initializing memory event bus...")
        event_bus = MemoryEventBus()
        await event_bus.start()
        logger.info("Memory event bus started")
        
    # Create storage
    storage = None
    if config.storage_mode == 'sqlite':
        logger.info(f"Initializing SQLite storage at {config.sqlite_path}...")
        storage = SqliteSessionStorage(db_path=config.sqlite_path)
        await storage.start()
        logger.info("SQLite storage started")
        
    # Create memory
    memory = None
    if config.enable_memory:
        if config.memory_provider == 'lancedb':
            logger.info(f"Initializing LanceDB memory at {config.lancedb_path}...")
            memory = LanceDBMemoryService(db_path=config.lancedb_path)
            await memory.start()
            logger.info("LanceDB memory started")
    
    # Create PluginManager
    manager = PluginManager(
        event_bus=event_bus,
        service_discovery=discovery,
        storage=storage,
        memory=memory,
        enable_security=config.enable_security
    )
    
    logger.info(f"PluginManager created (discovery: {config.discovery_mode}, event_bus: {config.event_bus_mode})")
    return manager


async def create_distributed_manager(
    redis_url: Optional[str] = None,
    redis_host: str = 'localhost',
    redis_port: int = 6379,
    enable_security: bool = True
) -> PluginManager:
    """
    Convenience function to create a fully distributed PluginManager.
    
    This is a shorthand for creating a manager with both Redis service discovery
    and Redis event bus enabled.
    
    Args:
        redis_url: Redis URL (e.g., 'redis://localhost:6379/0')
        redis_host: Redis host (used if redis_url not provided)
        redis_port: Redis port (used if redis_url not provided)
        enable_security: Enable security checks
        
    Returns:
        PluginManager with Redis backends
        
    Example:
        >>> manager = await create_distributed_manager(
        ...     redis_url='redis://localhost:6379'
        ... )
    """
    config = SDKConfig(
        discovery_mode='redis',
        event_bus_mode='redis',
        redis_url=redis_url,
        redis_host=redis_host,
        redis_port=redis_port,
        enable_security=enable_security
    )
    return await create_manager(config)


async def create_hybrid_manager(
    discovery_mode: Literal['memory', 'redis'] = 'memory',
    event_bus_mode: Literal['memory', 'redis'] = 'redis',
    redis_url: Optional[str] = None,
    enable_security: bool = True
) -> PluginManager:
    """
    Create a hybrid PluginManager with mixed backends.
    
    Args:
        discovery_mode: Service discovery mode
        event_bus_mode: Event bus mode
        redis_url: Redis URL (if using Redis for either component)
        enable_security: Enable security checks
        
    Returns:
        PluginManager with mixed backends
        
    Example:
        >>> # Memory discovery + Redis events
        >>> manager = await create_hybrid_manager(
        ...     discovery_mode='memory',
        ...     event_bus_mode='redis',
        ...     redis_url='redis://localhost:6379'
        ... )
    """
    config = SDKConfig(
        discovery_mode=discovery_mode,
        event_bus_mode=event_bus_mode,
        redis_url=redis_url,
        enable_security=enable_security
    )
    return await create_manager(config)
