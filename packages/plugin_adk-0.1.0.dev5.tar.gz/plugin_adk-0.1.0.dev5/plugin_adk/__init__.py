"""
Plugin SDK - A comprehensive plugin ecosystem framework.

A standalone, pip-installable Python package providing a complete plugin ecosystem,
including plugin development, runtime environment, communication mechanisms,
service discovery, storage caching, AI capabilities, and sandbox execution.
"""

__version__ = "0.1.0-dev"
__author__ = "OpenMind Development Team"
__license__ = "MIT"

