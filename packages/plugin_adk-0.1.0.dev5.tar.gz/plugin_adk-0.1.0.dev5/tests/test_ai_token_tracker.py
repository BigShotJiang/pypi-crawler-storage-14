"""
Tests for TokenTracker.

Comprehensive tests for token usage tracking and cost calculation.
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from plugin_adk.core.ai.token_tracker import (
    TokenTracker,
    TokenUsage,
    TokenCost,
    DEFAULT_PRICING,
)


class TestTokenUsage:
    """Tests for TokenUsage dataclass"""
    
    def test_token_usage_creation(self):
        """Test TokenUsage creation"""
        usage = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo"
        )
        assert usage.prompt_tokens == 100
        assert usage.completion_tokens == 50
        assert usage.total_tokens == 150
        assert usage.model == "gpt-3.5-turbo"
        assert isinstance(usage.timestamp, datetime)
        assert isinstance(usage.metadata, dict)
    
    def test_token_usage_with_metadata(self):
        """Test TokenUsage with metadata"""
        metadata = {"request_id": "123", "user": "test"}
        usage = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            metadata=metadata
        )
        assert usage.metadata == metadata


class TestTokenCost:
    """Tests for TokenCost dataclass"""
    
    def test_token_cost_creation(self):
        """Test TokenCost creation"""
        cost = TokenCost(
            model="gpt-4",
            prompt_cost_per_1k=0.03,
            completion_cost_per_1k=0.06
        )
        assert cost.model == "gpt-4"
        assert cost.prompt_cost_per_1k == 0.03
        assert cost.completion_cost_per_1k == 0.06
    
    def test_calculate_cost(self):
        """Test cost calculation"""
        cost = TokenCost(
            model="gpt-4",
            prompt_cost_per_1k=0.03,
            completion_cost_per_1k=0.06
        )
        usage = TokenUsage(
            prompt_tokens=2000,  # 2k tokens
            completion_tokens=1000,  # 1k tokens
            total_tokens=3000,
            model="gpt-4"
        )
        total_cost = cost.calculate_cost(usage)
        # 2 * 0.03 + 1 * 0.06 = 0.06 + 0.06 = 0.12
        assert total_cost == pytest.approx(0.12, rel=1e-6)
    
    def test_calculate_cost_zero_tokens(self):
        """Test cost calculation with zero tokens"""
        cost = TokenCost(
            model="gpt-4",
            prompt_cost_per_1k=0.03,
            completion_cost_per_1k=0.06
        )
        usage = TokenUsage(
            prompt_tokens=0,
            completion_tokens=0,
            total_tokens=0,
            model="gpt-4"
        )
        total_cost = cost.calculate_cost(usage)
        assert total_cost == 0.0


class TestTokenTracker:
    """Tests for TokenTracker class"""
    
    @pytest.mark.asyncio
    async def test_tracker_init_default(self):
        """Test TokenTracker initialization with default pricing"""
        tracker = TokenTracker()
        assert tracker.pricing == DEFAULT_PRICING
        assert len(tracker._usage_records) == 0
    
    @pytest.mark.asyncio
    async def test_tracker_init_custom_pricing(self):
        """Test TokenTracker initialization with custom pricing"""
        custom_pricing = {
            "custom-model": TokenCost("custom-model", 0.01, 0.02)
        }
        tracker = TokenTracker(custom_pricing=custom_pricing)
        assert "custom-model" in tracker.pricing
        assert tracker.pricing["custom-model"].prompt_cost_per_1k == 0.01
        # Default pricing should still be present
        assert "gpt-4" in tracker.pricing
    
    @pytest.mark.asyncio
    async def test_record_usage(self):
        """Test recording token usage"""
        tracker = TokenTracker()
        usage = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo"
        )
        await tracker.record_usage(usage)
        assert len(tracker._usage_records) == 1
        assert tracker._usage_records[0] == usage
    
    @pytest.mark.asyncio
    async def test_record_multiple_usage(self):
        """Test recording multiple token usages"""
        tracker = TokenTracker()
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        assert len(tracker._usage_records) == 2
    
    @pytest.mark.asyncio
    async def test_get_total_usage_no_filters(self):
        """Test get_total_usage without filters"""
        tracker = TokenTracker()
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        total = await tracker.get_total_usage()
        assert total.prompt_tokens == 300
        assert total.completion_tokens == 150
        assert total.total_tokens == 450
        assert total.model == "all"
    
    @pytest.mark.asyncio
    async def test_get_total_usage_with_model_filter(self):
        """Test get_total_usage with model filter"""
        tracker = TokenTracker()
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        total = await tracker.get_total_usage(model="gpt-3.5-turbo")
        assert total.prompt_tokens == 100
        assert total.completion_tokens == 50
        assert total.total_tokens == 150
        assert total.model == "gpt-3.5-turbo"
    
    @pytest.mark.asyncio
    async def test_get_total_usage_with_time_filters(self):
        """Test get_total_usage with time filters"""
        tracker = TokenTracker()
        now = datetime.now()
        past = now - timedelta(hours=2)
        future = now + timedelta(hours=1)
        
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage1.timestamp = past
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        usage2.timestamp = now
        
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        # Filter by start_time
        total = await tracker.get_total_usage(start_time=now - timedelta(hours=1))
        assert total.total_tokens == 300  # Only usage2
        
        # Filter by end_time
        total = await tracker.get_total_usage(end_time=past + timedelta(minutes=30))
        assert total.total_tokens == 150  # Only usage1
        
        # Filter by both
        total = await tracker.get_total_usage(
            start_time=past - timedelta(minutes=30),
            end_time=past + timedelta(minutes=30)
        )
        assert total.total_tokens == 150  # Only usage1
    
    @pytest.mark.asyncio
    async def test_get_total_cost_no_filters(self):
        """Test get_total_cost without filters"""
        tracker = TokenTracker()
        usage1 = TokenUsage(1000, 500, 1500, "gpt-3.5-turbo")
        usage2 = TokenUsage(2000, 1000, 3000, "gpt-4")
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        cost = await tracker.get_total_cost()
        # gpt-3.5-turbo: 1 * 0.0015 + 0.5 * 0.002 = 0.0015 + 0.001 = 0.0025
        # gpt-4: 2 * 0.03 + 1 * 0.06 = 0.06 + 0.06 = 0.12
        # Total: 0.0025 + 0.12 = 0.1225
        assert cost > 0
        assert cost == pytest.approx(0.1225, rel=1e-3)
    
    @pytest.mark.asyncio
    async def test_get_total_cost_with_model_filter(self):
        """Test get_total_cost with model filter"""
        tracker = TokenTracker()
        usage1 = TokenUsage(1000, 500, 1500, "gpt-3.5-turbo")
        usage2 = TokenUsage(2000, 1000, 3000, "gpt-4")
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        cost = await tracker.get_total_cost(model="gpt-3.5-turbo")
        # gpt-3.5-turbo: 1 * 0.0015 + 0.5 * 0.002 = 0.0025
        assert cost == pytest.approx(0.0025, rel=1e-3)
    
    @pytest.mark.asyncio
    async def test_get_total_cost_with_unknown_model(self):
        """Test get_total_cost with unknown model (not in pricing)"""
        tracker = TokenTracker()
        usage = TokenUsage(1000, 500, 1500, "unknown-model")
        await tracker.record_usage(usage)
        
        cost = await tracker.get_total_cost()
        # Unknown model should not contribute to cost
        assert cost == 0.0
    
    @pytest.mark.asyncio
    async def test_get_total_cost_with_time_filters(self):
        """Test get_total_cost with time filters"""
        tracker = TokenTracker()
        now = datetime.now()
        past = now - timedelta(hours=2)
        
        usage1 = TokenUsage(1000, 500, 1500, "gpt-3.5-turbo")
        usage1.timestamp = past
        usage2 = TokenUsage(2000, 1000, 3000, "gpt-4")
        usage2.timestamp = now
        
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        # Filter by start_time
        cost = await tracker.get_total_cost(start_time=now - timedelta(hours=1))
        # Only usage2 should be counted
        assert cost > 0
    
    @pytest.mark.asyncio
    async def test_get_usage_by_model(self):
        """Test get_usage_by_model"""
        tracker = TokenTracker()
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        usage3 = TokenUsage(150, 75, 225, "gpt-3.5-turbo")
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        await tracker.record_usage(usage3)
        
        usage_by_model = await tracker.get_usage_by_model()
        assert "gpt-3.5-turbo" in usage_by_model
        assert "gpt-4" in usage_by_model
        assert usage_by_model["gpt-3.5-turbo"].total_tokens == 375  # 150 + 225
        assert usage_by_model["gpt-4"].total_tokens == 300
    
    @pytest.mark.asyncio
    async def test_get_usage_by_model_with_time_filters(self):
        """Test get_usage_by_model with time filters"""
        tracker = TokenTracker()
        now = datetime.now()
        past = now - timedelta(hours=2)
        
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage1.timestamp = past
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        usage2.timestamp = now
        
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        # Filter by start_time
        usage_by_model = await tracker.get_usage_by_model(
            start_time=now - timedelta(hours=1)
        )
        assert "gpt-4" in usage_by_model
        assert "gpt-3.5-turbo" not in usage_by_model
    
    @pytest.mark.asyncio
    async def test_clear_usage_all(self):
        """Test clear_usage without before parameter (clear all)"""
        tracker = TokenTracker()
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        count = await tracker.clear_usage()
        assert count == 2
        assert len(tracker._usage_records) == 0
    
    @pytest.mark.asyncio
    async def test_clear_usage_before(self):
        """Test clear_usage with before parameter"""
        tracker = TokenTracker()
        now = datetime.now()
        past = now - timedelta(hours=2)
        recent = now - timedelta(minutes=30)
        
        usage1 = TokenUsage(100, 50, 150, "gpt-3.5-turbo")
        usage1.timestamp = past
        usage2 = TokenUsage(200, 100, 300, "gpt-4")
        usage2.timestamp = recent
        
        await tracker.record_usage(usage1)
        await tracker.record_usage(usage2)
        
        # Clear records before recent
        count = await tracker.clear_usage(before=recent)
        assert count == 1  # Only usage1 should be cleared
        assert len(tracker._usage_records) == 1
        assert tracker._usage_records[0] == usage2
    
    @pytest.mark.asyncio
    async def test_clear_usage_empty(self):
        """Test clear_usage when no records exist"""
        tracker = TokenTracker()
        count = await tracker.clear_usage()
        assert count == 0
    
    @pytest.mark.asyncio
    async def test_concurrent_record_usage(self):
        """Test concurrent record_usage calls"""
        tracker = TokenTracker()
        
        async def record(i):
            usage = TokenUsage(100 * i, 50 * i, 150 * i, f"model-{i}")
            await tracker.record_usage(usage)
        
        # Record 10 usages concurrently
        await asyncio.gather(*[record(i) for i in range(10)])
        
        assert len(tracker._usage_records) == 10
        total = await tracker.get_total_usage()
        assert total.total_tokens == sum(150 * i for i in range(10))

