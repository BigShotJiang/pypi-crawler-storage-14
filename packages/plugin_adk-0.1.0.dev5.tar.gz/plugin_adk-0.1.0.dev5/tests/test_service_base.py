"""
Unit tests for BaseServiceClient.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timedelta

from plugin_adk.core.service.base import (
    BaseServiceClient,
    ServiceClientConfig,
    CallTrace,
    CallStatus,
    ServiceError,
)
from plugin_adk.core.coordination.discovery import ServiceDiscovery, ServiceInfo
from plugin_adk.core.coordination.load_balancer import RoundRobinLoadBalancer


@pytest.fixture
def service_discovery():
    """Create a mock service discovery"""
    discovery = Mock(spec=ServiceDiscovery)
    discovery.discover_services = AsyncMock(return_value=[
        ServiceInfo(
            service_id="instance1",
            service_type="test_service",
            endpoint="http://localhost:8000",
            metadata={},
        )
    ])
    return discovery


@pytest.fixture
def service_client_config(service_discovery):
    """Create service client config"""
    return ServiceClientConfig(
        service_discovery=service_discovery,
        max_retries=3,
        retry_delay=0.01,  # 减少延迟以加快测试速度
        enable_tracing=True,
    )


@pytest.fixture
def service_client(service_client_config):
    """Create base service client"""
    return BaseServiceClient(config=service_client_config)


@pytest.mark.asyncio
async def test_service_client_init(service_client):
    """Test service client initialization"""
    assert service_client.config is not None
    assert service_client.service_discovery is not None
    assert service_client.load_balancer is not None


@pytest.mark.asyncio
async def test_discover_service(service_client, service_discovery):
    """Test service discovery"""
    services = await service_client._discover_service("test_service")
    assert services is not None
    assert len(services) > 0
    assert services[0].service_type == "test_service"


@pytest.mark.asyncio
async def test_call_service_success(service_client):
    """Test successful service call"""
    with patch.object(service_client, '_execute_call', new_callable=AsyncMock) as mock_call:
        mock_call.return_value = {"result": "success"}
        
        result = await service_client.call_service(
            service_name="test_service",
            method="test_method",
            params={"key": "value"},
        )
        
        assert result == {"result": "success"}
        mock_call.assert_called_once()


@pytest.mark.asyncio
async def test_call_service_retry(service_client):
    """Test service call with retry"""
    call_count = 0
    
    async def mock_call(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise Exception("Temporary error")
        return {"result": "success"}
    
    with patch.object(service_client, '_execute_call', side_effect=mock_call):
        result = await service_client.call_service(
            service_name="test_service",
            method="test_method",
            params={},
        )
        
        assert result == {"result": "success"}
        assert call_count == 3


@pytest.mark.asyncio
async def test_call_service_failure(service_client):
    """Test service call failure after retries"""
    with patch.object(service_client, '_execute_call', new_callable=AsyncMock) as mock_call:
        mock_call.side_effect = Exception("Service error")
        
        with pytest.raises(ServiceError):
            await service_client.call_service(
                service_name="test_service",
                method="test_method",
                params={},
            )


@pytest.mark.asyncio
async def test_call_http(service_client):
    """Test HTTP call"""
    service_info = ServiceInfo(
        service_id="instance1",
        service_type="test_service",
        endpoint="http://localhost:8000",
        metadata={},
    )
    
    with patch('httpx.AsyncClient') as mock_client:
        mock_response = Mock()
        mock_response.json.return_value = {"result": "success"}
        mock_response.raise_for_status = Mock()
        
        mock_client.return_value.__aenter__.return_value.post = AsyncMock(return_value=mock_response)
        
        result = await service_client._call_http(
            service_info,
            "test_method",
            {"key": "value"},
            timeout=10.0,
        )
        
        assert result == {"result": "success"}


@pytest.mark.asyncio
async def test_get_trace(service_client):
    """Test getting call trace"""
    trace_id = "test-trace-id"
    trace = CallTrace(
        trace_id=trace_id,
        service_name="test_service",
        method="test_method",
        params={},
        status=CallStatus.SUCCESS,
        start_time=None,
    )
    
    service_client._call_traces[trace_id] = trace
    
    retrieved_trace = service_client.get_trace(trace_id)
    assert retrieved_trace is not None
    assert retrieved_trace.trace_id == trace_id


@pytest.mark.asyncio
async def test_get_traces_filtered(service_client):
    """Test getting filtered traces"""
    # Add some traces
    trace1 = CallTrace(
        trace_id="trace1",
        service_name="service1",
        method="method1",
        params={},
        status=CallStatus.SUCCESS,
        start_time=None,
    )
    trace2 = CallTrace(
        trace_id="trace2",
        service_name="service2",
        method="method2",
        params={},
        status=CallStatus.FAILED,
        start_time=None,
    )
    
    service_client._call_traces["trace1"] = trace1
    service_client._call_traces["trace2"] = trace2
    
    # Filter by service name
    traces = service_client.get_traces(service_name="service1")
    assert len(traces) == 1
    assert traces[0].service_name == "service1"
    
    # Filter by status
    traces = service_client.get_traces(status=CallStatus.FAILED)
    assert len(traces) == 1
    assert traces[0].status == CallStatus.FAILED


@pytest.mark.asyncio
async def test_service_client_init_no_load_balancing():
    """Test service client initialization without load balancing (line 94)"""
    config = ServiceClientConfig(enable_load_balancing=False)
    client = BaseServiceClient(config=config)
    assert client.load_balancer is None


@pytest.mark.asyncio
async def test_call_service_not_found(service_client):
    """Test service call when service is not found (line 158-162)"""
    service_client.service_discovery.discover_services = AsyncMock(return_value=[])
    
    with pytest.raises(ServiceError, match="Service.*not found"):
        await service_client.call_service("test_service", "test_method")


@pytest.mark.asyncio
async def test_call_service_load_balancing(service_client):
    """Test service call with load balancing (line 165-168)"""
    # Create multiple service instances
    services = [
        ServiceInfo(
            service_id="instance1",
            service_type="test_service",
            endpoint="http://localhost:8000",
            metadata={},
        ),
        ServiceInfo(
            service_id="instance2",
            service_type="test_service",
            endpoint="http://localhost:8001",
            metadata={},
        ),
    ]
    service_client.service_discovery.discover_services = AsyncMock(return_value=services)
    
    # Mock load balancer's select method (it's called 'select', not 'select_backend')
    service_client.load_balancer.select = Mock(return_value=services[0])
    
    with patch.object(service_client, '_execute_call', new_callable=AsyncMock) as mock_call:
        mock_call.return_value = {"result": "success"}
        
        result = await service_client.call_service("test_service", "test_method")
        
        assert result == {"result": "success"}
        # Verify load balancer was used
        assert service_client.load_balancer.select.called


@pytest.mark.asyncio
async def test_call_service_no_available_instance(service_client):
    """Test service call when no available instance (line 170-174)"""
    service_client.service_discovery.discover_services = AsyncMock(return_value=[])
    
    with pytest.raises(ServiceError, match="Service.*not found"):
        await service_client.call_service("test_service", "test_method")


@pytest.mark.asyncio
async def test_call_service_tracing_disabled(service_client):
    """Test service call with tracing disabled"""
    service_client.config.enable_tracing = False
    
    with patch.object(service_client, '_execute_call', new_callable=AsyncMock) as mock_call:
        mock_call.return_value = {"result": "success"}
        
        result = await service_client.call_service("test_service", "test_method")
        
        assert result == {"result": "success"}
        # Verify no trace was added
        assert len(service_client._call_traces) == 0


@pytest.mark.asyncio
async def test_discover_service_cache_expired(service_client):
    """Test service discovery with expired cache (line 258-259)"""
    # Add expired cache
    service_client._service_cache["test_service"] = [
        ServiceInfo(
            service_id="instance1",
            service_type="test_service",
            endpoint="http://localhost:8000",
            metadata={},
        )
    ]
    service_client._cache_timestamp["test_service"] = datetime.now() - timedelta(seconds=120)
    
    # Service discovery returns empty
    service_client.service_discovery.discover_services = AsyncMock(return_value=[])
    
    # Should return expired cache
    services = await service_client._discover_service("test_service")
    assert services is not None
    assert len(services) == 1


@pytest.mark.asyncio
async def test_execute_call_event_bus(service_client):
    """Test execute call via event bus (line 284-286)"""
    from plugin_adk.core.communication.memory_bus import MemoryEventBus
    from plugin_adk.core.communication.request_response import RequestResponse
    
    service_client.event_bus = MemoryEventBus()
    service_info = ServiceInfo(
        service_id="instance1",
        service_type="test_service",
        endpoint="event://test_service",
        metadata={},
    )
    
    with patch('plugin_adk.core.communication.request_response.RequestResponse') as mock_client_class:
        mock_client = AsyncMock()
        mock_client.request = AsyncMock(return_value={"result": "success"})
        mock_client_class.return_value = mock_client
        
        result = await service_client._execute_call(service_info, "test_method", {}, None)
        
        assert result == {"result": "success"}


@pytest.mark.asyncio
async def test_execute_call_local(service_client):
    """Test execute call locally (line 288-289, 343-346)"""
    service_info = ServiceInfo(
        service_id="instance1",
        service_type="test_service",
        endpoint="local://test_service",
        metadata={},
    )
    
    with pytest.raises(ServiceError, match="Local service calls not yet implemented"):
        await service_client._execute_call(service_info, "test_method", {}, None)


@pytest.mark.asyncio
async def test_call_http_no_httpx(service_client):
    """Test HTTP call when httpx is not available (line 301-305)"""
    service_info = ServiceInfo(
        service_id="instance1",
        service_type="test_service",
        endpoint="http://localhost:8000",
        metadata={},
    )
    
    with patch('builtins.__import__', side_effect=ImportError("No module named 'httpx'")):
        with pytest.raises(ServiceError, match="httpx is required"):
            await service_client._call_http(service_info, "test_method", {}, None)


@pytest.mark.asyncio
async def test_call_event_bus_not_available(service_client):
    """Test event bus call when event bus is not available (line 322-323)"""
    service_client.event_bus = None
    service_info = ServiceInfo(
        service_id="instance1",
        service_type="test_service",
        endpoint="event://test_service",
        metadata={},
    )
    
    with pytest.raises(ServiceError, match="Event bus not available"):
        await service_client._call_event_bus(service_info, "test_method", {}, None)


@pytest.mark.asyncio
async def test_add_trace_limit(service_client):
    """Test add trace with limit (line 353-360)"""
    # Set max traces to 2
    service_client._max_traces = 2
    
    # Add 3 traces
    trace1 = CallTrace(
        trace_id="trace1",
        service_name="service1",
        method="method1",
        params={},
        status=CallStatus.SUCCESS,
        start_time=datetime.now() - timedelta(seconds=10),
    )
    trace2 = CallTrace(
        trace_id="trace2",
        service_name="service2",
        method="method2",
        params={},
        status=CallStatus.SUCCESS,
        start_time=datetime.now() - timedelta(seconds=5),
    )
    trace3 = CallTrace(
        trace_id="trace3",
        service_name="service3",
        method="method3",
        params={},
        status=CallStatus.SUCCESS,
        start_time=datetime.now(),
    )
    
    service_client._add_trace(trace1)
    service_client._add_trace(trace2)
    service_client._add_trace(trace3)
    
    # Should only have 2 traces (oldest removed)
    assert len(service_client._call_traces) == 2
    assert "trace1" not in service_client._call_traces
    assert "trace2" in service_client._call_traces
    assert "trace3" in service_client._call_traces


@pytest.mark.asyncio
async def test_update_trace_not_exists(service_client):
    """Test update trace when trace does not exist (line 364-365)"""
    trace = CallTrace(
        trace_id="nonexistent",
        service_name="service1",
        method="method1",
        params={},
        status=CallStatus.SUCCESS,
        start_time=datetime.now(),
    )
    
    # Update non-existent trace (should not raise error, but also not add it)
    service_client._update_trace(trace)
    
    # Trace should not be added
    assert "nonexistent" not in service_client._call_traces


@pytest.mark.asyncio
async def test_get_traces_with_limit(service_client):
    """Test get traces with limit (line 400-401)"""
    # Add multiple traces
    for i in range(5):
        trace = CallTrace(
            trace_id=f"trace{i}",
            service_name="service1",
            method="method1",
            params={},
            status=CallStatus.SUCCESS,
            start_time=datetime.now() - timedelta(seconds=i),
        )
        service_client._call_traces[f"trace{i}"] = trace
    
    # Get traces with limit
    traces = service_client.get_traces(limit=3)
    
    assert len(traces) == 3


@pytest.mark.asyncio
async def test_get_trace_not_found(service_client):
    """Test get trace when trace does not exist"""
    trace = service_client.get_trace("nonexistent")
    assert trace is None


@pytest.mark.asyncio
async def test_service_error_init():
    """Test ServiceError initialization"""
    error = ServiceError(
        "Test error",
        service_name="test_service",
        method="test_method",
        solution="Test solution",
    )
    
    assert str(error) == "Test error"
    assert error.service_name == "test_service"
    assert error.method == "test_method"
    assert error.solution == "Test solution"
