"""
Tests for PluginManager.
"""

import pytest
import asyncio
from plugin_adk.core.plugin.manager import PluginManager, PluginError
from plugin_adk.core.plugin.base import BasePlugin
from plugin_adk.core.models.plugins import PluginStatus
from plugin_adk.core.models.events import Event, EventType
from plugin_adk.core.models.responses import Response


class MockPlugin(BasePlugin):
    """Test plugin implementation"""
    
    async def on_initialize(self) -> bool:
        return True
    
    async def on_start(self) -> bool:
        return True
    
    async def on_stop(self) -> bool:
        return True
    
    async def on_get_supported_actions(self):
        return ["test_service"]
    
    async def execute(self, **kwargs):
        return {"result": "success", **kwargs}


class MockEventPlugin(BasePlugin):
    """Test plugin that handles events"""
    
    async def on_initialize(self) -> bool:
        return True
    
    async def on_start(self) -> bool:
        return True
    
    async def on_stop(self) -> bool:
        return True
    
    async def on_get_supported_event_types(self):
        return ["message"]
    
    async def on_event(self, event):
        return Response.success("Event handled", data={"event_id": event.event_id})


class TestPluginManager:
    """Tests for PluginManager"""
    
    @pytest.mark.asyncio
    async def test_register_plugin_type(self):
        """Test plugin type registration"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        assert "test_plugin" in manager.plugin_types
        assert manager.plugin_types["test_plugin"] == MockPlugin
    
    @pytest.mark.asyncio
    async def test_create_plugin(self):
        """Test plugin creation"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        
        assert plugin.name == "plugin1"
        assert isinstance(plugin, MockPlugin)
    
    @pytest.mark.asyncio
    async def test_register_plugin(self):
        """Test plugin registration"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        assert "plugin1" in manager.plugins
        assert manager.plugins["plugin1"] == plugin
    
    @pytest.mark.asyncio
    async def test_plugin_lifecycle(self):
        """Test plugin lifecycle management"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # Start plugin
        result = await manager.start_plugin("plugin1")
        assert result is True
        assert plugin.status == PluginStatus.RUNNING
        
        # Stop plugin
        result = await manager.stop_plugin("plugin1")
        assert result is True
        assert plugin.status == PluginStatus.STOPPED
    
    @pytest.mark.asyncio
    async def test_start_all_stop_all(self):
        """Test starting and stopping all plugins"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Create and register multiple plugins
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        plugin2 = await manager.create_plugin("test_plugin", "plugin2")
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        
        # Start all
        result = await manager.start_all()
        assert result is True
        assert plugin1.status == PluginStatus.RUNNING
        assert plugin2.status == PluginStatus.RUNNING
        
        # Stop all
        result = await manager.stop_all()
        assert result is True
        assert plugin1.status == PluginStatus.STOPPED
        assert plugin2.status == PluginStatus.STOPPED
    
    @pytest.mark.asyncio
    async def test_event_routing(self):
        """Test event routing"""
        manager = PluginManager()
        manager.register_plugin_type(MockEventPlugin, "event_plugin")
        
        plugin = await manager.create_plugin("event_plugin", "event_handler")
        await manager.register_plugin(plugin)
        await manager.start_plugin("event_handler")
        
        # Create event
        event = Event(topic="test.topic", data={"key": "value"}, event_type=EventType.MESSAGE)
        
        # Route event
        responses = await manager.route_event(event)
        
        assert len(responses) == 1
        assert responses[0].is_success()
    
    @pytest.mark.asyncio
    async def test_service_call(self):
        """Test service call"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "service_provider")
        await manager.register_plugin(plugin)
        await manager.start_plugin("service_provider")
        
        # Call service
        result = await manager.call_service("test_service", "execute", input_data="test")
        
        assert result["result"] == "success"
        assert result["input_data"] == "test"
    
    @pytest.mark.asyncio
    async def test_unregister_plugin(self):
        """Test plugin unregistration"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        await manager.start_plugin("plugin1")
        
        # Unregister
        await manager.unregister_plugin("plugin1")
        
        assert "plugin1" not in manager.plugins
        assert plugin.status == PluginStatus.STOPPED
    
    @pytest.mark.asyncio
    async def test_error_handling(self):
        """Test error handling"""
        manager = PluginManager()
        
        # Test unknown plugin type
        with pytest.raises(PluginError):
            await manager.create_plugin("unknown_type", "plugin1")
        
        # Test duplicate plugin name
        manager.register_plugin_type(MockPlugin, "test_plugin")
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin1)
        
        with pytest.raises(PluginError):
            plugin2 = await manager.create_plugin("test_plugin", "plugin1")
        
        # Test unknown service
        with pytest.raises(PluginError):
            await manager.call_service("unknown_service", "execute")
    
    @pytest.mark.asyncio
    async def test_plugin_dependencies(self):
        """Test plugin dependency management"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Create plugins with dependencies
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        plugin1.config = {"dependencies": []}  # No dependencies
        
        plugin2 = await manager.create_plugin("test_plugin", "plugin2")
        plugin2.config = {"dependencies": ["plugin1"]}  # Depends on plugin1
        
        plugin3 = await manager.create_plugin("test_plugin", "plugin3")
        plugin3.config = {"dependencies": ["plugin1", "plugin2"]}  # Depends on plugin1 and plugin2
        
        # Register plugins (plugin1 first, then plugin2, then plugin3)
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        await manager.register_plugin(plugin3)
        
        # Check dependencies
        assert manager.get_plugin_dependencies("plugin2") == {"plugin1"}
        assert manager.get_plugin_dependencies("plugin3") == {"plugin1", "plugin2"}
        
        # Check dependents
        assert manager.get_plugin_dependents("plugin1") == {"plugin2", "plugin3"}
        assert manager.get_plugin_dependents("plugin2") == {"plugin3"}
        
        # Validate dependencies
        is_valid, error = manager.validate_dependencies()
        assert is_valid is True
        assert error is None
    
    @pytest.mark.asyncio
    async def test_startup_order_with_dependencies(self):
        """Test that plugins start in dependency order"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Track startup order
        startup_order = []
        
        class TrackedPlugin(MockPlugin):
            async def on_start(self) -> bool:
                startup_order.append(self.name)
                return True
        
        manager.register_plugin_type(TrackedPlugin, "tracked_plugin")
        
        # Create plugins with dependencies
        plugin1 = await manager.create_plugin("tracked_plugin", "plugin1")
        plugin1.config = {"dependencies": []}
        
        plugin2 = await manager.create_plugin("tracked_plugin", "plugin2")
        plugin2.config = {"dependencies": ["plugin1"]}
        
        plugin3 = await manager.create_plugin("tracked_plugin", "plugin3")
        plugin3.config = {"dependencies": ["plugin2"]}
        
        # Register in reverse order (to test that dependency order is respected)
        await manager.register_plugin(plugin3)
        await manager.register_plugin(plugin2)
        await manager.register_plugin(plugin1)
        
        # Start all - should start in dependency order
        await manager.start_all()
        
        # Verify startup order: plugin1 -> plugin2 -> plugin3
        assert startup_order == ["plugin1", "plugin2", "plugin3"]
    
    @pytest.mark.asyncio
    async def test_circular_dependency_detection(self):
        """Test circular dependency detection"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Create plugins with circular dependency
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        plugin1.config = {"dependencies": ["plugin2"]}
        
        plugin2 = await manager.create_plugin("test_plugin", "plugin2")
        plugin2.config = {"dependencies": ["plugin1"]}
        
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        
        # Validate should detect circular dependency
        is_valid, error = manager.validate_dependencies()
        assert is_valid is False
        assert "circular" in error.lower() or "Circular" in error
    
    @pytest.mark.asyncio
    async def test_service_call_graph(self):
        """Test service call graph tracking"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Create plugins
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        plugin1.config = {"dependencies": []}
        
        plugin2 = await manager.create_plugin("test_plugin", "plugin2")
        plugin2.config = {"dependencies": []}
        
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        await manager.start_all()
        
        # Get call graph (initially empty)
        call_graph = manager.get_service_call_graph()
        assert call_graph == {}
        
        # Note: Full call graph tracking would require context tracking
        # which is more complex. This test verifies the structure exists.
    
    @pytest.mark.asyncio
    async def test_register_plugin_type_with_class_name(self):
        """Test register_plugin_type using class name"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin)  # No name provided
        
        assert "MockPlugin" in manager.plugin_types
        assert manager.plugin_types["MockPlugin"] == MockPlugin
    
    @pytest.mark.asyncio
    async def test_create_plugin_config_validation_failure(self):
        """Test create_plugin with config validation failure"""
        manager = PluginManager()
        
        class ValidatingPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
            async def validate_config(self, config):
                return False  # Always fail validation
        
        manager.register_plugin_type(ValidatingPlugin, "validating_plugin")
        
        with pytest.raises(PluginError) as exc_info:
            await manager.create_plugin("validating_plugin", "plugin1", invalid_param="value")
        assert "configuration validation failed" in str(exc_info.value).lower()
    
    @pytest.mark.asyncio
    async def test_register_plugin_service_override_warning(self):
        """Test register_plugin with service override warning"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Register first plugin
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin1)
        
        # Register second plugin with same service (should warn)
        plugin2 = await manager.create_plugin("test_plugin", "plugin2")
        # Service should be overridden
        assert "test_service" in manager.service_handlers
    
    @pytest.mark.asyncio
    async def test_get_plugin(self):
        """Test get_plugin method"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # Get existing plugin
        retrieved = manager.get_plugin("plugin1")
        assert retrieved == plugin
        
        # Get non-existent plugin
        assert manager.get_plugin("nonexistent") is None
    
    @pytest.mark.asyncio
    async def test_list_plugins(self):
        """Test list_plugins method"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        plugin2 = await manager.create_plugin("test_plugin", "plugin2")
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        
        plugins = manager.list_plugins()
        assert "plugin1" in plugins
        assert "plugin2" in plugins
        assert len(plugins) == 2
    
    @pytest.mark.asyncio
    async def test_list_plugin_types(self):
        """Test list_plugin_types method"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        manager.register_plugin_type(MockEventPlugin, "event_plugin")
        
        types = manager.list_plugin_types()
        assert "test_plugin" in types
        assert "event_plugin" in types
    
    @pytest.mark.asyncio
    async def test_call_plugin_method(self):
        """Test call_plugin_method"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        await manager.start_plugin("plugin1")
        
        # Call method
        result = await manager.call_plugin_method("plugin1", "execute", data="test")
        assert result["result"] == "success"
        assert result["data"] == "test"
    
    @pytest.mark.asyncio
    async def test_call_plugin_method_nonexistent_plugin(self):
        """Test call_plugin_method with nonexistent plugin"""
        manager = PluginManager()
        
        with pytest.raises(PluginError) as exc_info:
            await manager.call_plugin_method("nonexistent", "execute")
        assert "not found" in str(exc_info.value).lower()
    
    @pytest.mark.asyncio
    async def test_call_plugin_method_not_running(self):
        """Test call_plugin_method when plugin is not running"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        # Don't start plugin
        
        with pytest.raises(PluginError) as exc_info:
            await manager.call_plugin_method("plugin1", "execute")
        assert "not running" in str(exc_info.value).lower()
    
    @pytest.mark.asyncio
    async def test_validate_dependencies_missing_dependency(self):
        """Test validate_dependencies with missing dependency"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Create plugin with non-existent dependency
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        plugin.config = {"dependencies": ["nonexistent"]}
        await manager.register_plugin(plugin)
        
        is_valid, error = manager.validate_dependencies()
        assert is_valid is False
        assert "nonexistent" in error.lower()
    
    @pytest.mark.asyncio
    async def test_start_all_with_startup_failure_rollback(self):
        """Test start_all with startup failure and rollback"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        startup_order = []
        
        class FailingPlugin(MockPlugin):
            async def on_start(self) -> bool:
                startup_order.append(self.name)
                if self.name == "plugin2":
                    raise Exception("Startup failed")
                return True
        
        manager.register_plugin_type(FailingPlugin, "failing_plugin")
        
        plugin1 = await manager.create_plugin("failing_plugin", "plugin1")
        plugin1.config = {"dependencies": []}
        plugin2 = await manager.create_plugin("failing_plugin", "plugin2")
        plugin2.config = {"dependencies": ["plugin1"]}
        
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        
        # Start all - should fail and rollback
        result = await manager.start_all()
        assert result is False
        
        # plugin1 should be stopped due to rollback
        assert plugin1.status == PluginStatus.STOPPED
    
    @pytest.mark.asyncio
    async def test_register_plugin_with_event_bus(self):
        """Test register_plugin with event bus injection"""
        from plugin_adk.core.communication.memory_bus import MemoryEventBus
        
        event_bus = MemoryEventBus()
        manager = PluginManager(event_bus=event_bus)
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        assert plugin.event_bus == event_bus
    
    @pytest.mark.asyncio
    async def test_create_plugin_with_event_bus(self):
        """Test create_plugin with event bus injection"""
        from plugin_adk.core.communication.memory_bus import MemoryEventBus
        
        event_bus = MemoryEventBus()
        manager = PluginManager(event_bus=event_bus)
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        
        assert plugin.event_bus == event_bus
    
    @pytest.mark.asyncio
    async def test_plugin_error_default_solution(self):
        """Test PluginError with default solution"""
        error = PluginError("Test error")
        assert error.solution == "请查看插件文档了解如何正确使用插件系统"
        assert error.documentation_url == "https://docs.plugin-sdk.dev/plugins/guide"
    
    @pytest.mark.asyncio
    async def test_plugin_error_custom_solution(self):
        """Test PluginError with custom solution"""
        error = PluginError(
            "Test error",
            solution="Custom solution",
            documentation_url="https://custom.url"
        )
        assert error.solution == "Custom solution"
        assert error.documentation_url == "https://custom.url"
    
    @pytest.mark.asyncio
    async def test_unregister_plugin_not_registered(self):
        """Test unregister_plugin when plugin not registered"""
        manager = PluginManager()
        
        # Should not raise error, just log warning
        await manager.unregister_plugin("nonexistent")
    
    @pytest.mark.asyncio
    async def test_unregister_plugin_with_service_discovery(self):
        """Test unregister_plugin with service discovery"""
        from plugin_adk.core.coordination.discovery import ServiceDiscovery
        from unittest.mock import AsyncMock
        
        service_discovery = ServiceDiscovery()
        manager = PluginManager(service_discovery=service_discovery)
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # Mock service discovery unregister
        service_discovery.unregister = AsyncMock()
        
        await manager.unregister_plugin("plugin1")
        
        # Should have attempted to unregister services
        # (actual behavior depends on implementation)
    
    @pytest.mark.asyncio
    async def test_start_plugin_not_found(self):
        """Test start_plugin when plugin not found"""
        manager = PluginManager()
        
        with pytest.raises(PluginError, match="not found"):
            await manager.start_plugin("nonexistent")
    
    @pytest.mark.asyncio
    async def test_stop_plugin_not_found(self):
        """Test stop_plugin when plugin not found"""
        manager = PluginManager()
        
        with pytest.raises(PluginError, match="not found"):
            await manager.stop_plugin("nonexistent")
    
    @pytest.mark.asyncio
    async def test_start_all_already_running(self):
        """Test start_all when already running"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # Start first time
        await manager.start_all()
        assert manager.is_running is True
        
        # Try to start again (should warn but return True)
        result = await manager.start_all()
        assert result is True
    
    @pytest.mark.asyncio
    async def test_stop_all_not_running(self):
        """Test stop_all when not running"""
        manager = PluginManager()
        
        # Should warn but return True
        result = await manager.stop_all()
        assert result is True
    
    @pytest.mark.asyncio
    async def test_stop_all_with_stop_failure(self):
        """Test stop_all with plugin stop failure"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        class FailingStopPlugin(MockPlugin):
            async def on_stop(self) -> bool:
                raise Exception("Stop failed")
        
        manager.register_plugin_type(FailingStopPlugin, "failing_plugin")
        
        plugin = await manager.create_plugin("failing_plugin", "plugin1")
        await manager.register_plugin(plugin)
        await manager.start_plugin("plugin1")
        
        # Stop all should handle exception gracefully
        result = await manager.stop_all()
        # Should still return True (doesn't fail on individual stop failures)
        assert result is True
    
    @pytest.mark.asyncio
    async def test_route_event_plugin_not_running(self):
        """Test route_event when plugin is not running"""
        manager = PluginManager()
        manager.register_plugin_type(MockEventPlugin, "event_plugin")
        
        plugin = await manager.create_plugin("event_plugin", "event_handler")
        await manager.register_plugin(plugin)
        # Don't start plugin
        
        event = Event(topic="test.topic", data={"key": "value"}, event_type=EventType.MESSAGE)
        
        # Should skip non-running plugins
        responses = await manager.route_event(event)
        assert len(responses) == 0
    
    @pytest.mark.asyncio
    async def test_route_event_plugin_not_in_handlers(self):
        """Test route_event when plugin not in handlers list"""
        manager = PluginManager()
        manager.register_plugin_type(MockEventPlugin, "event_plugin")
        
        plugin = await manager.create_plugin("event_plugin", "event_handler")
        await manager.register_plugin(plugin)
        await manager.start_plugin("event_handler")
        
        # Remove from handlers manually
        manager.event_handlers["message"] = []
        
        event = Event(topic="test.topic", data={"key": "value"}, event_type=EventType.MESSAGE)
        
        # Should return empty list
        responses = await manager.route_event(event)
        assert len(responses) == 0
    
    @pytest.mark.asyncio
    async def test_route_event_plugin_exception(self):
        """Test route_event when plugin raises exception"""
        manager = PluginManager()
        
        class ExceptionPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
            async def on_get_supported_event_types(self):
                return ["message"]
            async def on_event(self, event):
                raise Exception("Event handling error")
        
        manager.register_plugin_type(ExceptionPlugin, "exception_plugin")
        
        plugin = await manager.create_plugin("exception_plugin", "exception_handler")
        await manager.register_plugin(plugin)
        await manager.start_plugin("exception_handler")
        
        event = Event(topic="test.topic", data={"key": "value"}, event_type=EventType.MESSAGE)
        
        # Should handle exception gracefully
        responses = await manager.route_event(event)
        # handle_event catches exception and returns error response, so responses may contain error response
        # The exception is logged but not re-raised
        assert isinstance(responses, list)
    
    @pytest.mark.asyncio
    async def test_call_service_method_not_found(self):
        """Test call_service when method not found"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        await manager.start_plugin("plugin1")
        
        with pytest.raises(PluginError, match="not found"):
            await manager.call_service("test_service", "nonexistent_method")
    
    @pytest.mark.asyncio
    async def test_call_service_sync_method(self):
        """Test call_service with sync method"""
        manager = PluginManager()
        
        class SyncMethodPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
            async def on_get_supported_actions(self):
                return ["sync_service"]
            def sync_method(self, value: int) -> int:
                return value * 2
        
        manager.register_plugin_type(SyncMethodPlugin, "sync_plugin")
        
        plugin = await manager.create_plugin("sync_plugin", "plugin1")
        await manager.register_plugin(plugin)
        await manager.start_plugin("plugin1")
        
        result = await manager.call_service("sync_service", "sync_method", value=5)
        assert result == 10
    
    @pytest.mark.asyncio
    async def test_call_service_with_service_discovery(self):
        """Test call_service with service discovery"""
        from plugin_adk.core.coordination.discovery import ServiceDiscovery, ServiceInfo
        from unittest.mock import AsyncMock
        
        service_discovery = ServiceDiscovery()
        manager = PluginManager(service_discovery=service_discovery)
        
        # Mock service discovery
        mock_service = ServiceInfo(
            service_id="remote.service",
            service_type="test_service",
            endpoint="http://remote:8080",
        )
        service_discovery.discover = AsyncMock(return_value=[mock_service])
        
        # Should try service discovery, but service not found locally
        with pytest.raises(PluginError, match="remote service calls are not yet fully implemented"):
            await manager.call_service("test_service", "execute")
    
    @pytest.mark.asyncio
    async def test_call_service_service_discovery_exception(self):
        """Test call_service when service discovery raises exception"""
        from plugin_adk.core.coordination.discovery import ServiceDiscovery
        from unittest.mock import AsyncMock
        
        service_discovery = ServiceDiscovery()
        manager = PluginManager(service_discovery=service_discovery)
        
        # Mock service discovery to raise exception
        service_discovery.discover = AsyncMock(side_effect=Exception("Discovery error"))
        
        # Should handle exception and continue
        with pytest.raises(PluginError, match="not found"):
            await manager.call_service("test_service", "execute")
    
    @pytest.mark.asyncio
    async def test_register_plugin_with_service_discovery(self):
        """Test register_plugin with service discovery"""
        from plugin_adk.core.coordination.discovery import ServiceDiscovery
        from unittest.mock import AsyncMock
        
        service_discovery = ServiceDiscovery()
        manager = PluginManager(service_discovery=service_discovery)
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Mock service discovery register
        service_discovery.register = AsyncMock()
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # Should have attempted to register services
        # (actual behavior depends on implementation)
    
    @pytest.mark.asyncio
    async def test_register_plugin_service_discovery_exception(self):
        """Test register_plugin when service discovery raises exception"""
        from plugin_adk.core.coordination.discovery import ServiceDiscovery
        from unittest.mock import AsyncMock
        
        service_discovery = ServiceDiscovery()
        manager = PluginManager(service_discovery=service_discovery)
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Mock service discovery to raise exception
        service_discovery.register = AsyncMock(side_effect=Exception("Registration error"))
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        # Should handle exception gracefully
        await manager.register_plugin(plugin)
        assert "plugin1" in manager.plugins
    
    @pytest.mark.asyncio
    async def test_unregister_plugin_service_discovery_exception(self):
        """Test unregister_plugin when service discovery raises exception"""
        from plugin_adk.core.coordination.discovery import ServiceDiscovery
        from unittest.mock import AsyncMock
        
        service_discovery = ServiceDiscovery()
        manager = PluginManager(service_discovery=service_discovery)
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # Mock service discovery to raise exception
        service_discovery.unregister = AsyncMock(side_effect=Exception("Unregistration error"))
        
        # Should handle exception gracefully
        await manager.unregister_plugin("plugin1")
        assert "plugin1" not in manager.plugins
    
    @pytest.mark.asyncio
    async def test_get_plugin_dependencies_from_manifest(self):
        """Test _get_plugin_dependencies from manifest"""
        manager = PluginManager()
        
        class ManifestPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
        
        plugin = ManifestPlugin(name="plugin1", version="1.0.0")
        
        # Create mock manifest
        from unittest.mock import Mock
        manifest = Mock()
        manifest.dependencies = ["dep1", "dep2"]
        plugin.manifest = manifest
        
        deps = await manager._get_plugin_dependencies(plugin)
        assert deps == {"dep1", "dep2"}
    
    @pytest.mark.asyncio
    async def test_get_plugin_dependencies_from_info_metadata(self):
        """Test _get_plugin_dependencies from info metadata"""
        manager = PluginManager()
        
        class MetadataPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
        
        plugin = MetadataPlugin(name="plugin1", version="1.0.0")
        plugin.info.metadata = {"dependencies": ["dep1", "dep2"]}
        
        deps = await manager._get_plugin_dependencies(plugin)
        assert deps == {"dep1", "dep2"}
    
    async def test_get_plugin_dependencies_combined(self):
        """Test _get_plugin_dependencies combining all sources"""
        manager = PluginManager()
        
        class CombinedPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
        
        plugin = CombinedPlugin(name="plugin1", version="1.0.0")
        plugin.config = {"dependencies": ["dep1"]}
        plugin.info.metadata = {"dependencies": ["dep2"]}
        
        deps = await manager._get_plugin_dependencies(plugin)
        assert deps == {"dep1", "dep2"}
    
    @pytest.mark.asyncio
    async def test_get_service_call_graph_with_plugin_name(self):
        """Test get_service_call_graph with plugin name filter"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin1 = await manager.create_plugin("test_plugin", "plugin1")
        plugin2 = await manager.create_plugin("test_plugin", "plugin2")
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        await manager.start_all()
        
        # Manually add to call graph
        manager.service_call_graph["plugin1"].add("plugin2")
        
        # Get graph for specific plugin
        graph = manager.get_service_call_graph("plugin1")
        assert "plugin1" in graph
        assert "plugin2" in graph["plugin1"]
    
    @pytest.mark.asyncio
    async def test_get_service_call_graph_nonexistent_plugin(self):
        """Test get_service_call_graph with nonexistent plugin"""
        manager = PluginManager()
        
        graph = manager.get_service_call_graph("nonexistent")
        assert graph == {"nonexistent": set()}
    
    @pytest.mark.asyncio
    async def test_start_all_plugin_not_in_plugins(self):
        """Test start_all when plugin in startup order but not in plugins"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        plugin = await manager.create_plugin("test_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # Manually add to startup order but remove from plugins
        manager._startup_order = ["plugin1", "nonexistent"]
        del manager.plugins["plugin1"]
        
        # Should skip nonexistent plugins
        result = await manager.start_all()
        # Should handle gracefully
        assert result is False or result is True
    
    @pytest.mark.asyncio
    async def test_start_all_plugin_start_returns_false(self):
        """Test start_all when plugin start returns False"""
        manager = PluginManager()
        
        class FailingStartPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return False  # Start fails
            async def on_stop(self) -> bool:
                return True
        
        manager.register_plugin_type(FailingStartPlugin, "failing_plugin")
        
        plugin = await manager.create_plugin("failing_plugin", "plugin1")
        await manager.register_plugin(plugin)
        
        # PluginError is raised but caught by outer exception handler, which returns False
        result = await manager.start_all()
        assert result is False
    
    @pytest.mark.asyncio
    async def test_start_all_rollback_exception(self):
        """Test start_all rollback with exception"""
        manager = PluginManager()
        
        startup_order = []
        
        class FailingPlugin(MockPlugin):
            async def on_start(self) -> bool:
                startup_order.append(self.name)
                if self.name == "plugin2":
                    raise Exception("Startup failed")
                return True
            async def on_stop(self) -> bool:
                raise Exception("Stop failed")  # Rollback also fails
        
        manager.register_plugin_type(FailingPlugin, "failing_plugin")
        
        plugin1 = await manager.create_plugin("failing_plugin", "plugin1")
        plugin1.config = {"dependencies": []}
        plugin2 = await manager.create_plugin("failing_plugin", "plugin2")
        plugin2.config = {"dependencies": ["plugin1"]}
        
        await manager.register_plugin(plugin1)
        await manager.register_plugin(plugin2)
        
        # PluginError is raised but caught by outer exception handler, which returns False
        # Rollback exception is logged but doesn't prevent the outer exception handler from catching the PluginError
        result = await manager.start_all()
        assert result is False
    
    @pytest.mark.asyncio
    async def test_start_all_general_exception(self):
        """Test start_all with general exception"""
        manager = PluginManager()
        manager.register_plugin_type(MockPlugin, "test_plugin")
        
        # Mock _calculate_startup_order to raise exception
        from unittest.mock import patch
        with patch.object(manager, '_calculate_startup_order', side_effect=Exception("General error")):
            result = await manager.start_all()
            assert result is False
            assert manager.is_running is False

