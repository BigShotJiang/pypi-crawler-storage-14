"""
Security tests for sandbox system.

Tests file system access restrictions, network access control, and other security features.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
import tempfile
import os

from plugin_adk.core.sandbox.smolagents_sandbox import SmolagentsSandbox
from plugin_adk.core.sandbox.base import SandboxResult, SandboxStatus
from plugin_adk.core.models.plugins import SandboxConfig, SandboxLevel


class TestSandboxSecurity:
    """Tests for sandbox security features"""
    
    @pytest.fixture
    def strict_config(self):
        """Create strict sandbox config"""
        return SandboxConfig(
            level=SandboxLevel.STRICT,
            allowed_imports={'json', 'math', 'datetime'},
            denied_imports={'os', 'sys', 'subprocess', 'socket', 'urllib'},
            allowed_network_hosts={'api.example.com'},
            denied_network_hosts={'internal.example.com', 'localhost'},
        )
    
    @pytest.mark.asyncio
    async def test_file_system_access_restriction(self, strict_config):
        """Test file system access restrictions"""
        # This test verifies that file system access is restricted
        # Actual implementation would need to intercept file operations
        
        sandbox = SmolagentsSandbox(config=strict_config)
        
        # Test code that tries to access file system
        dangerous_code = """
import os
with open('/etc/passwd', 'r') as f:
    content = f.read()
"""
        
        # Code should be rejected during validation
        is_valid, error = await sandbox.validate_code(dangerous_code)
        assert is_valid is False
        assert "os" in error.lower() or "dangerous" in error.lower()
    
    @pytest.mark.asyncio
    async def test_network_access_restriction(self, strict_config):
        """Test network access restrictions"""
        sandbox = SmolagentsSandbox(config=strict_config)
        
        # Test code that tries to make network requests
        dangerous_code = """
import urllib.request
response = urllib.request.urlopen('http://internal.example.com')
"""
        
        # Code should be rejected during validation
        is_valid, error = await sandbox.validate_code(dangerous_code)
        assert is_valid is False
        assert "urllib" in error.lower() or "dangerous" in error.lower()
    
    @pytest.mark.asyncio
    async def test_module_whitelist_enforcement(self, strict_config):
        """Test module whitelist enforcement"""
        sandbox = SmolagentsSandbox(config=strict_config)
        
        # Allowed module
        is_valid, error = await sandbox.validate_code("import json")
        # Note: This might pass validation but fail at execution
        # depending on implementation
        
        # Disallowed module
        is_valid, error = await sandbox.validate_code("import os")
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_module_blacklist_enforcement(self, strict_config):
        """Test module blacklist enforcement"""
        sandbox = SmolagentsSandbox(config=strict_config)
        
        # Denied module
        is_valid, error = await sandbox.validate_code("import sys")
        assert is_valid is False
        assert "denied" in error.lower() or "dangerous" in error.lower()
    
    @pytest.mark.asyncio
    async def test_resource_limits_enforcement(self, strict_config):
        """Test resource limits enforcement"""
        # This test verifies that resource limits are configured
        # Actual enforcement depends on smolagents implementation
        
        sandbox = SmolagentsSandbox(config=strict_config)
        limits = sandbox.get_resource_limits()
        
        assert limits["memory_limit_mb"] == strict_config.memory_limit_mb
        assert limits["cpu_limit_percent"] == strict_config.cpu_limit_percent
        if strict_config.timeout_seconds:
            assert limits["timeout_seconds"] == strict_config.timeout_seconds
    
    @pytest.mark.asyncio
    async def test_code_injection_prevention(self, strict_config):
        """Test code injection prevention"""
        sandbox = SmolagentsSandbox(config=strict_config)
        
        # Test various injection patterns
        injection_patterns = [
            "__import__('os').system('rm -rf /')",
            "eval('__import__(\"os\").system(\"rm -rf /\")')",
            "exec('import os; os.system(\"rm -rf /\")')",
            "compile('__import__(\"os\").system(\"rm -rf /\")', '<string>', 'exec')",
        ]
        
        for code in injection_patterns:
            is_valid, error = await sandbox.validate_code(code)
            assert is_valid is False, f"Code injection pattern should be rejected: {code}"
            assert "dangerous" in error.lower() or "eval" in error.lower() or "exec" in error.lower()
    
    @pytest.mark.asyncio
    async def test_sandbox_level_strict(self):
        """Test strict sandbox level configuration"""
        strict_config = SandboxConfig(level=SandboxLevel.STRICT)
        sandbox = SmolagentsSandbox(config=strict_config)
        
        # Strict level should have more restrictions
        assert sandbox.config.level == SandboxLevel.STRICT
        
        # Test that dangerous operations are rejected
        is_valid, error = await sandbox.validate_code("import os; os.system('ls')")
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_sandbox_level_basic(self):
        """Test basic sandbox level configuration"""
        basic_config = SandboxConfig(level=SandboxLevel.BASIC)
        sandbox = SmolagentsSandbox(config=basic_config)
        
        assert sandbox.config.level == SandboxLevel.BASIC
        
        # Basic level might allow more operations
        # This depends on implementation
    
    @pytest.mark.asyncio
    async def test_timeout_enforcement(self):
        """Test execution timeout enforcement"""
        config = SandboxConfig(timeout_seconds=0.1)  # Very short timeout
        
        try:
            sandbox = SmolagentsSandbox(config=config)
            
            # Code that runs longer than timeout
            long_running_code = """
import time
time.sleep(1)  # Sleep for 1 second
"""
            
            # This test depends on actual smolagents implementation
            # For now, we just verify timeout is configured
            limits = sandbox.get_resource_limits()
            assert limits["timeout_seconds"] == 0.1
        except Exception as e:
            if "smolagents" in str(e).lower():
                pytest.skip(f"Skipping test: smolagents not available - {e}")
            raise
    
    def test_allowed_network_hosts_config(self, strict_config):
        """Test allowed network hosts configuration"""
        assert 'api.example.com' in strict_config.allowed_network_hosts
        assert len(strict_config.allowed_network_hosts) > 0
    
    def test_denied_network_hosts_config(self, strict_config):
        """Test denied network hosts configuration"""
        assert 'internal.example.com' in strict_config.denied_network_hosts
        assert 'localhost' in strict_config.denied_network_hosts
        assert len(strict_config.denied_network_hosts) > 0

