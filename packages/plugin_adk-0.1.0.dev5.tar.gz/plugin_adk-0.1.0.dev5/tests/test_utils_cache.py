"""
Tests for cache decorator utilities.
"""

import pytest
import asyncio
import time
from plugin_adk.core.utils.cache_decorator import (
    cache_result,
    cache_async_result,
    clear_cache,
    get_cache_stats,
)


class TestCacheResult:
    """Tests for cache_result decorator"""
    
    def test_cache_result_basic(self):
        """Test basic caching"""
        clear_cache()
        
        call_count = [0]
        
        @cache_result(ttl=1.0)
        def test_func(x):
            call_count[0] += 1
            return x * 2
        
        # First call - should execute
        result1 = test_func(5)
        assert result1 == 10
        assert call_count[0] == 1
        
        # Second call - should use cache
        result2 = test_func(5)
        assert result2 == 10
        assert call_count[0] == 1  # Not incremented
    
    def test_cache_result_different_args(self):
        """Test caching with different arguments"""
        clear_cache()
        
        call_count = [0]
        
        @cache_result(ttl=1.0)
        def test_func(x):
            call_count[0] += 1
            return x * 2
        
        test_func(5)
        test_func(6)  # Different argument
        
        assert call_count[0] == 2  # Both should execute
    
    def test_cache_result_expiration(self):
        """Test cache expiration"""
        clear_cache()
        
        call_count = [0]
        
        @cache_result(ttl=0.05)  # Very short TTL for faster test
        def test_func(x):
            call_count[0] += 1
            return x * 2
        
        test_func(5)
        assert call_count[0] == 1
        
        # Wait for expiration
        time.sleep(0.1)  # Reduced wait time
        
        test_func(5)  # Should execute again
        assert call_count[0] == 2
    
    @pytest.mark.asyncio
    async def test_cache_async_result(self):
        """Test async caching"""
        clear_cache()
        
        call_count = [0]
        
        @cache_async_result(ttl=1.0)
        async def test_async_func(x):
            call_count[0] += 1
            return x * 2
        
        # First call
        result1 = await test_async_func(5)
        assert result1 == 10
        assert call_count[0] == 1
        
        # Second call - should use cache
        result2 = await test_async_func(5)
        assert result2 == 10
        assert call_count[0] == 1  # Not incremented


class TestCacheStats:
    """Tests for cache statistics"""
    
    def test_get_cache_stats(self):
        """Test getting cache statistics"""
        clear_cache()
        
        @cache_result(ttl=1.0)
        def test_func(x):
            return x * 2
        
        # Add some entries
        test_func(1)
        test_func(2)
        test_func(3)
        
        stats = get_cache_stats()
        
        assert stats["total_entries"] == 3
        assert stats["valid_entries"] == 3
        assert stats["expired_entries"] == 0
    
    def test_clear_cache(self):
        """Test clearing cache"""
        @cache_result(ttl=1.0)
        def test_func(x):
            return x * 2
        
        test_func(1)
        test_func(2)
        
        stats_before = get_cache_stats()
        assert stats_before["total_entries"] > 0
        
        clear_cache()
        
        stats_after = get_cache_stats()
        assert stats_after["total_entries"] == 0
    
    def test_cache_result_with_custom_key_func(self):
        """Test cache_result with custom key function"""
        clear_cache()
        
        call_count = [0]
        
        def custom_key(x, y):
            return f"{x}_{y}"
        
        @cache_result(ttl=1.0, key_func=custom_key)
        def test_func(x, y):
            call_count[0] += 1
            return x + y
        
        # First call
        result1 = test_func(1, 2)
        assert result1 == 3
        assert call_count[0] == 1
        
        # Second call with same args - should use cache
        result2 = test_func(1, 2)
        assert result2 == 3
        assert call_count[0] == 1
    
    def test_cache_result_max_size(self):
        """Test cache_result with max_size limit"""
        clear_cache()
        
        call_count = [0]
        
        @cache_result(ttl=10.0, max_size=3)
        def test_func(x):
            call_count[0] += 1
            return x * 2
        
        # Fill cache to max_size
        test_func(1)
        test_func(2)
        test_func(3)
        
        assert call_count[0] == 3
        stats = get_cache_stats()
        assert stats["total_entries"] == 3
        
        # Add one more - should evict oldest
        test_func(4)
        assert call_count[0] == 4
        stats = get_cache_stats()
        assert stats["total_entries"] == 3  # Should still be max_size
    
    def test_cache_result_max_size_with_expired(self):
        """Test cache_result max_size eviction with expired entries"""
        clear_cache()
        
        call_count = [0]
        
        @cache_result(ttl=0.05, max_size=3)
        def test_func(x):
            call_count[0] += 1
            return x * 2
        
        # Fill cache
        test_func(1)
        test_func(2)
        test_func(3)
        
        # Wait for expiration
        time.sleep(0.1)
        
        # Add new entry - should evict expired first
        test_func(4)
        assert call_count[0] == 4
        stats = get_cache_stats()
        # Should have 3 entries (2 valid + 1 new)
        assert stats["total_entries"] == 3
    
    @pytest.mark.asyncio
    async def test_cache_async_result_with_custom_key_func(self):
        """Test cache_async_result with custom key function"""
        clear_cache()
        
        call_count = [0]
        
        def custom_key(x, y):
            return f"{x}_{y}"
        
        @cache_async_result(ttl=1.0, key_func=custom_key)
        async def test_async_func(x, y):
            call_count[0] += 1
            return x + y
        
        # First call
        result1 = await test_async_func(1, 2)
        assert result1 == 3
        assert call_count[0] == 1
        
        # Second call - should use cache
        result2 = await test_async_func(1, 2)
        assert result2 == 3
        assert call_count[0] == 1
    
    @pytest.mark.asyncio
    async def test_cache_async_result_max_size(self):
        """Test cache_async_result with max_size limit"""
        clear_cache()
        
        call_count = [0]
        
        @cache_async_result(ttl=10.0, max_size=3)
        async def test_async_func(x):
            call_count[0] += 1
            return x * 2
        
        # Fill cache to max_size
        await test_async_func(1)
        await test_async_func(2)
        await test_async_func(3)
        
        assert call_count[0] == 3
        stats = get_cache_stats()
        assert stats["total_entries"] == 3
        
        # Add one more - should evict oldest
        await test_async_func(4)
        assert call_count[0] == 4
        stats = get_cache_stats()
        assert stats["total_entries"] == 3
    
    @pytest.mark.asyncio
    async def test_cache_async_result_max_size_with_expired(self):
        """Test cache_async_result max_size eviction with expired entries"""
        clear_cache()
        
        call_count = [0]
        
        @cache_async_result(ttl=0.05, max_size=3)
        async def test_async_func(x):
            call_count[0] += 1
            return x * 2
        
        # Fill cache
        await test_async_func(1)
        await test_async_func(2)
        await test_async_func(3)
        
        # Wait for expiration
        await asyncio.sleep(0.1)
        
        # Add new entry - should evict expired first
        await test_async_func(4)
        assert call_count[0] == 4
        stats = get_cache_stats()
        assert stats["total_entries"] == 3
    
    def test_get_cache_stats_with_expired(self):
        """Test get_cache_stats with expired entries"""
        clear_cache()
        
        @cache_result(ttl=0.05)
        def test_func(x):
            return x * 2
        
        # Add entries
        test_func(1)
        test_func(2)
        
        # Wait for expiration
        time.sleep(0.1)
        
        stats = get_cache_stats()
        assert stats["total_entries"] == 2
        assert stats["expired_entries"] == 2
        assert stats["valid_entries"] == 0

