"""
Tests for validation utilities.
"""

import pytest
from plugin_adk.core.utils.validation import (
    validate_email,
    validate_url,
    validate_phone,
    validate_json,
    validate_dict,
    validate_string,
    validate_number,
)


class TestValidateEmail:
    """Tests for validate_email"""
    
    def test_valid_emails(self):
        """Test valid email addresses"""
        assert validate_email("test@example.com") is True
        assert validate_email("user.name@domain.co.uk") is True
        assert validate_email("test+tag@example.com") is True
    
    def test_invalid_emails(self):
        """Test invalid email addresses"""
        assert validate_email("") is False
        assert validate_email("invalid") is False
        assert validate_email("@example.com") is False
        assert validate_email("test@") is False
        assert validate_email("test@.com") is False
        assert validate_email(None) is False


class TestValidateURL:
    """Tests for validate_url"""
    
    def test_valid_urls(self):
        """Test valid URLs"""
        assert validate_url("https://example.com") is True
        assert validate_url("http://example.com/path") is True
        assert validate_url("https://example.com:8080/path?query=value") is True
    
    def test_invalid_urls(self):
        """Test invalid URLs"""
        assert validate_url("") is False
        assert validate_url("not-a-url") is False
        assert validate_url("ftp://example.com") is False  # Only http/https
        assert validate_url(None) is False


class TestValidatePhone:
    """Tests for validate_phone"""
    
    def test_valid_phones(self):
        """Test valid phone numbers"""
        assert validate_phone("1234567890") is True
        assert validate_phone("+1234567890") is True
        assert validate_phone("123-456-7890") is True  # Hyphens removed
        assert validate_phone("123 456 7890") is True  # Spaces removed
    
    def test_invalid_phones(self):
        """Test invalid phone numbers"""
        assert validate_phone("") is False
        assert validate_phone("123") is False  # Too short
        assert validate_phone("1234567890123456") is False  # Too long
        assert validate_phone("abc123") is False  # Contains letters
        assert validate_phone(None) is False


class TestValidateJSON:
    """Tests for validate_json"""
    
    def test_valid_json(self):
        """Test valid JSON strings"""
        assert validate_json('{"key": "value"}') is True
        assert validate_json('[1, 2, 3]') is True
        assert validate_json('"string"') is True
    
    def test_invalid_json(self):
        """Test invalid JSON strings"""
        assert validate_json("") is False
        assert validate_json("{invalid}") is False
        assert validate_json("not json") is False
        assert validate_json(None) is False


class TestValidateDict:
    """Tests for validate_dict"""
    
    def test_valid_dict(self):
        """Test valid dictionary"""
        data = {"key1": "value1", "key2": 123}
        is_valid, error = validate_dict(data)
        assert is_valid is True
        assert error is None
    
    def test_required_keys(self):
        """Test required keys validation"""
        data = {"key1": "value1"}
        is_valid, error = validate_dict(data, required_keys=["key1", "key2"])
        assert is_valid is False
        assert "key2" in error
    
    def test_allowed_keys(self):
        """Test allowed keys validation"""
        data = {"key1": "value1", "key3": "value3"}
        is_valid, error = validate_dict(data, allowed_keys=["key1", "key2"])
        assert is_valid is False
        assert "key3" in error
    
    def test_value_types(self):
        """Test value types validation"""
        data = {"key1": "value1", "key2": "not_int"}
        is_valid, error = validate_dict(data, value_types={"key2": int})
        assert is_valid is False
        assert "key2" in error


class TestValidateString:
    """Tests for validate_string"""
    
    def test_valid_string(self):
        """Test valid string"""
        is_valid, error = validate_string("test", min_length=2, max_length=10)
        assert is_valid is True
        assert error is None
    
    def test_min_length(self):
        """Test minimum length validation"""
        is_valid, error = validate_string("a", min_length=2)
        assert is_valid is False
        assert "小" in error
    
    def test_max_length(self):
        """Test maximum length validation"""
        is_valid, error = validate_string("very long string", max_length=5)
        assert is_valid is False
        assert "大" in error
    
    def test_pattern(self):
        """Test pattern validation"""
        is_valid, error = validate_string("test123", pattern=r"^[a-z]+$")
        assert is_valid is False
        assert "模式" in error


class TestValidateNumber:
    """Tests for validate_number"""
    
    def test_valid_number(self):
        """Test valid number"""
        is_valid, error = validate_number(5, min_value=1, max_value=10)
        assert is_valid is True
        assert error is None
    
    def test_min_value(self):
        """Test minimum value validation"""
        is_valid, error = validate_number(0, min_value=1)
        assert is_valid is False
        assert "小于" in error
    
    def test_max_value(self):
        """Test maximum value validation"""
        is_valid, error = validate_number(11, max_value=10)
        assert is_valid is False
        assert "大于" in error
    
    def test_integer_only(self):
        """Test integer-only validation"""
        is_valid, error = validate_number(5.5, integer_only=True)
        assert is_valid is False
        assert "整数" in error

