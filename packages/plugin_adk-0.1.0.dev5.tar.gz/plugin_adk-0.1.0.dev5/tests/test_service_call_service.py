"""
Unit tests for CallServiceClient.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock

from plugin_adk.core.service.call_service import CallServiceClient
from plugin_adk.core.service.base import ServiceClientConfig
from plugin_adk.core.coordination.discovery import ServiceDiscovery
from unittest.mock import patch


@pytest.fixture
def service_discovery():
    """Create a mock service discovery"""
    discovery = Mock(spec=ServiceDiscovery)
    discovery.discover_services = AsyncMock(return_value=[])
    return discovery


@pytest.fixture
def call_service_client(service_discovery):
    """Create call service client"""
    config = ServiceClientConfig(service_discovery=service_discovery)
    return CallServiceClient(config=config)


@pytest.mark.asyncio
async def test_call_service_client_init(call_service_client):
    """Test call service client initialization"""
    assert call_service_client.config is not None
    assert isinstance(call_service_client, CallServiceClient)


@pytest.mark.asyncio
async def test_call_method(call_service_client):
    """Test call method"""
    with patch.object(call_service_client, 'call_service', new_callable=AsyncMock) as mock_call:
        mock_call.return_value = {"result": "success"}
        
        result = await call_service_client.call(
            service_name="test_service",
            method="test_method",
            params={"key": "value"},
        )
        
        assert result == {"result": "success"}
        mock_call.assert_called_once_with(
            service_name="test_service",
            method="test_method",
            params={"key": "value"},
            timeout=None,
        )


@pytest.mark.asyncio
async def test_call_batch(call_service_client):
    """Test batch call"""
    with patch.object(call_service_client, 'call', new_callable=AsyncMock) as mock_call:
        mock_call.side_effect = [
            {"result": "result1"},
            {"result": "result2"},
        ]
        
        calls = [
            {"service_name": "service1", "method": "method1", "params": {}},
            {"service_name": "service2", "method": "method2", "params": {}},
        ]
        
        results = await call_service_client.call_batch(calls)
        
        assert len(results) == 2
        assert results[0] == {"result": "result1"}
        assert results[1] == {"result": "result2"}

