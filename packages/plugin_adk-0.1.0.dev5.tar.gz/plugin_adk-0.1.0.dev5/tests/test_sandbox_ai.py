"""
Unit tests for AISandbox.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from plugin_adk.core.sandbox.ai_sandbox import AISandbox
from plugin_adk.core.sandbox.smolagents_sandbox import SmolagentsSandbox
from plugin_adk.core.models.plugins import SandboxConfig, SandboxLevel
from plugin_adk.core.ai import AICapabilitiesManager
from plugin_adk.core.plugin.sdk import PluginSDK


@pytest.fixture
def sandbox_config():
    """Create sandbox config"""
    return SandboxConfig(level=SandboxLevel.STRICT)


@pytest.fixture
def ai_manager():
    """Create AI manager"""
    return AICapabilitiesManager()


@pytest.mark.asyncio
async def test_ai_sandbox_init(sandbox_config, ai_manager):
    """Test AI sandbox initialization"""
    # Skip if smolagents not available
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        assert sandbox.config.level == SandboxLevel.STRICT
        assert sandbox.ai_manager is not None
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_execute_agent(sandbox_config, ai_manager):
    """Test AI sandbox execute agent"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            result = await sandbox.execute_agent(
                task="Test task",
                context={"key": "value"},
            )
            
            assert result.status == "completed"
            mock_execute.assert_called_once()
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_execute_with_tools(sandbox_config, ai_manager):
    """Test AI sandbox execute with tools"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            result = await sandbox.execute_with_tools(
                code="print('test')",
                tools=["tool1", "tool2"],
            )
            
            assert result.status == "completed"
            mock_execute.assert_called_once()
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_init_without_params():
    """Test AI sandbox initialization without parameters"""
    try:
        sandbox = AISandbox()
        assert sandbox.config is not None
        assert sandbox.ai_manager is not None
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_init_with_sdk(ai_manager):
    """Test AI sandbox initialization with SDK"""
    try:
        from plugin_adk.core.plugin.manager import PluginManager
        from plugin_adk.core.plugin.base import BasePlugin
        
        # Create a mock plugin instance
        plugin_instance = Mock(spec=BasePlugin)
        plugin_instance.name = "test_plugin"
        
        sdk = PluginSDK(plugin_instance=plugin_instance)
        sandbox = AISandbox(sdk=sdk, ai_manager=ai_manager)
        assert sandbox.sdk == sdk
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_init_with_llm_model(ai_manager):
    """Test AI sandbox initialization with LLM model"""
    try:
        sandbox = AISandbox(ai_manager=ai_manager, llm_model="gpt-4")
        assert sandbox.ai_manager == ai_manager
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_create_agent_prompt(sandbox_config, ai_manager):
    """Test _create_agent_prompt method"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        # Test without context
        prompt = sandbox._create_agent_prompt("Test task")
        assert "Task: Test task" in prompt
        assert "Please write and execute Python code" in prompt
        
        # Test with context
        prompt = sandbox._create_agent_prompt(
            "Test task",
            context={"key1": "value1", "key2": "value2"}
        )
        assert "Task: Test task" in prompt
        assert "Context:" in prompt
        assert "key1: value1" in prompt
        assert "key2: value2" in prompt
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_execute_agent_without_context(sandbox_config, ai_manager):
    """Test execute_agent without context"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            result = await sandbox.execute_agent(task="Test task")
            
            assert result.status == "completed"
            mock_execute.assert_called_once()
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_execute_with_tools_none(sandbox_config, ai_manager):
    """Test execute_with_tools with tools=None"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            result = await sandbox.execute_with_tools(
                code="print('test')",
                tools=None,
            )
            
            assert result.status == "completed"
            mock_execute.assert_called_once()
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_execute_with_tools_empty_list(sandbox_config, ai_manager):
    """Test execute_with_tools with empty tools list"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            result = await sandbox.execute_with_tools(
                code="print('test')",
                tools=[],
            )
            
            assert result.status == "completed"
            mock_execute.assert_called_once()
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_success(ai_manager):
    """Test _create_litellm_llm with successful creation"""
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
        
        llm_service = ai_manager.get_llm_service()
        llm = sandbox._create_litellm_llm(llm_service, model="gpt-3.5-turbo")
        
        assert llm is not None
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_with_default_model(ai_manager):
    """Test _create_litellm_llm with default model"""
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
        
        llm_service = ai_manager.get_llm_service()
        llm = sandbox._create_litellm_llm(llm_service, model=None)
        
        assert llm is not None
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_import_error(ai_manager):
    """Test _create_litellm_llm with litellm import error"""
    from plugin_adk.core.sandbox.ai_sandbox import SandboxError
    from plugin_adk.core.ai import LLMService
    
    llm_service = Mock(spec=LLMService)
    
    # Mock the import inside the method
    with patch('builtins.__import__', side_effect=ImportError("No module named 'litellm'")):
        try:
            sandbox = AISandbox(ai_manager=ai_manager)
            # The _create_litellm_llm is called during init, so we need to test it differently
            # Instead, test the import error path by patching the import
            with patch('plugin_adk.core.sandbox.ai_sandbox.litellm', create=False):
                # Try to call _create_litellm_llm which will try to import litellm
                try:
                    llm = sandbox._create_litellm_llm(llm_service)
                    # If we get here, the import succeeded, so skip
                    pytest.skip("litellm is available, cannot test import error")
                except SandboxError as e:
                    assert "litellm is not installed" in str(e) or "Failed to create LLM instance" in str(e)
        except Exception as e:
            # If smolagents is not available, skip
            if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
                pytest.skip(f"Skipping test: {e}")
            raise


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_default_model_fallback(ai_manager):
    """Test _create_litellm_llm with default model fallback"""
    from unittest.mock import patch, Mock
    
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise
    
    # Mock llm_service without default_model
    llm_service = Mock()
    # Remove default_model attribute if it exists
    if hasattr(llm_service, 'default_model'):
        delattr(llm_service, 'default_model')
    
    # Mock smolagents to succeed
    with patch('smolagents.LiteLLMModel') as mock_llm:
        mock_llm.return_value = Mock()
        result = sandbox._create_litellm_llm(llm_service, None)
        # Should use default fallback model
        mock_llm.assert_called_once()
        assert result is not None


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_smolagents_exception(ai_manager):
    """Test _create_litellm_llm when smolagents raises exception"""
    from unittest.mock import patch, Mock
    
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise
    
    # Mock llm_service
    llm_service = Mock()
    llm_service.default_model = "gpt-4"
    
    # Mock smolagents to raise exception
    with patch('smolagents.LiteLLMModel', side_effect=Exception("Smolagents error")):
        # Should fallback to litellm
        with patch('litellm.LiteLLM') as mock_litellm:
            mock_litellm.return_value = Mock()
            result = sandbox._create_litellm_llm(llm_service, None)
            # Should use litellm fallback
            mock_litellm.assert_called_once()
            assert result is not None


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_litellm_fallback_exception(ai_manager):
    """Test _create_litellm_llm when both smolagents and litellm fail"""
    from unittest.mock import patch, Mock
    from plugin_adk.core.sandbox.ai_sandbox import SandboxError
    
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise
    
    # Mock llm_service
    llm_service = Mock()
    llm_service.default_model = "gpt-4"
    
    # Mock both to raise exception
    with patch('smolagents.LiteLLMModel', side_effect=Exception("Smolagents error")):
        with patch('litellm.LiteLLM', side_effect=Exception("Litellm error")):
            # Should raise SandboxError
            with pytest.raises(SandboxError, match="Failed to create LLM instance"):
                sandbox._create_litellm_llm(llm_service, None)


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_with_service_default_model(ai_manager):
    """Test _create_litellm_llm using service default_model"""
    from unittest.mock import patch, Mock
    
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise
    
    # Mock llm_service with default_model
    llm_service = Mock()
    llm_service.default_model = "gpt-4"
    
    # Mock smolagents to succeed
    with patch('smolagents.LiteLLMModel') as mock_llm:
        mock_llm.return_value = Mock()
        result = sandbox._create_litellm_llm(llm_service, None)
        # Should use service default_model
        mock_llm.assert_called_once_with(model_id="gpt-4")
        assert result is not None


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_smolagents_exception_fallback(ai_manager):
    """Test _create_litellm_llm when smolagents.LiteLLMModel raises exception and falls back to litellm"""
    from unittest.mock import patch, Mock
    
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise
    
    llm_service = Mock()
    
    # Mock smolagents.LiteLLMModel to raise exception
    with patch('smolagents.LiteLLMModel', side_effect=Exception("smolagents error")):
        # Mock litellm.LiteLLM to succeed
        with patch('litellm.LiteLLM') as mock_litellm:
            mock_litellm.return_value = Mock()
            result = sandbox._create_litellm_llm(llm_service, "gpt-3.5-turbo")
            # Should fallback to litellm.LiteLLM
            mock_litellm.assert_called_once_with(model="gpt-3.5-turbo")
            assert result is not None


@pytest.mark.asyncio
async def test_ai_sandbox_create_litellm_llm_all_fail(ai_manager):
    """Test _create_litellm_llm when both smolagents and litellm fail"""
    from unittest.mock import patch, Mock
    
    try:
        sandbox = AISandbox(ai_manager=ai_manager)
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise
    
    llm_service = Mock()
    
    # Mock both to fail
    with patch('smolagents.LiteLLMModel', side_effect=Exception("smolagents error")):
        with patch('litellm.LiteLLM', side_effect=Exception("litellm error")):
            # Should raise SandboxError
            from plugin_adk.core.sandbox.base import SandboxError
            with pytest.raises(SandboxError, match="Failed to create LLM instance"):
                sandbox._create_litellm_llm(llm_service, "gpt-3.5-turbo")


@pytest.mark.asyncio
async def test_ai_sandbox_execute_with_tools_filtering(sandbox_config, ai_manager):
    """Test execute_with_tools with tool filtering"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        # Mock tools
        tool1 = Mock()
        tool1.name = "tool1"
        tool2 = Mock()
        tool2.name = "tool2"
        tool3 = Mock()
        tool3.name = "tool3"
        original_tools = [tool1, tool2, tool3]
        sandbox.tools = original_tools.copy()
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            # Filter to only tool1 and tool2
            result = await sandbox.execute_with_tools(
                code="print('test')",
                tools=["tool1", "tool2"],
            )
            
            assert result.status == "completed"
            # Tools should be restored after execution (finally block)
            assert len(sandbox.tools) == 3
            assert sandbox.tools == original_tools
            mock_execute.assert_called_once()
            
            # Verify that execute was called with filtered tools
            # We can't directly check the tools during execution, but we can verify
            # the method was called correctly
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_execute_with_tools_empty_list(sandbox_config, ai_manager):
    """Test execute_with_tools with empty tools list"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        # Mock tools
        tool1 = Mock()
        tool1.name = "tool1"
        original_tools = [tool1]
        sandbox.tools = original_tools.copy()
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            # Empty tools list should result in no tools during execution
            result = await sandbox.execute_with_tools(
                code="print('test')",
                tools=[],
            )
            
            assert result.status == "completed"
            # Tools should be restored after execution (finally block)
            assert len(sandbox.tools) == 1
            assert sandbox.tools == original_tools
            mock_execute.assert_called_once()
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_sandbox_execute_with_tools_none(sandbox_config, ai_manager):
    """Test execute_with_tools with tools=None (should use all tools)"""
    try:
        sandbox = AISandbox(
            config=sandbox_config,
            ai_manager=ai_manager,
        )
        
        # Mock tools
        tool1 = Mock()
        tool1.name = "tool1"
        tool2 = Mock()
        tool2.name = "tool2"
        sandbox.tools = [tool1, tool2]
        
        with patch.object(sandbox, 'execute', new_callable=AsyncMock) as mock_execute:
            mock_execute.return_value = Mock(status="completed", result="success")
            
            # None tools should use all tools
            result = await sandbox.execute_with_tools(
                code="print('test')",
                tools=None,
            )
            
            assert result.status == "completed"
            # Should have all tools
            assert len(sandbox.tools) == 2
            mock_execute.assert_called_once()
    except Exception as e:
        if "smolagents" in str(e).lower() or "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise