"""
Unit tests for IntelligentCache.
"""

import pytest
import asyncio
import tempfile
from plugin_adk.core.storage.intelligent_cache import IntelligentCache
from plugin_adk.core.storage.cache_models import CacheLevel, WriteMode


class TestIntelligentCache:
    """Tests for IntelligentCache"""
    
    @pytest.mark.asyncio
    async def test_get_with_prefer_level(self):
        """Test get with prefer_level parameter"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set value in L3
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Get with prefer_level=L3
            value = await cache.get("key1", prefer_level=CacheLevel.L3)
            assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_get_from_level_l1(self):
        """Test _get_from_level for L1"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        await cache.set("key1", "value1")
        value = await cache._get_from_level("key1", CacheLevel.L1)
        assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_get_from_level_l3(self):
        """Test _get_from_level for L3"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            await cache.set("key1", "value1", level=CacheLevel.L3)
            value = await cache._get_from_level("key1", CacheLevel.L3)
            assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_get_from_level_disabled(self):
        """Test _get_from_level for disabled level"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        value = await cache._get_from_level("key1", CacheLevel.L2)
        assert value is None
        
        value = await cache._get_from_level("key1", CacheLevel.L3)
        assert value is None
    
    @pytest.mark.asyncio
    async def test_set_with_level(self):
        """Test set with level parameter"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set to L3 directly
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Should be in L3
            value = await cache._get_from_level("key1", CacheLevel.L3)
            assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_set_write_around_mode(self):
        """Test set with WRITE_AROUND mode"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
                write_mode=WriteMode.WRITE_AROUND,
            )
            
            # Write around should skip L1
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Should be in L3 but not in L1
            l3_value = await cache._get_from_level("key1", CacheLevel.L3)
            assert l3_value == "value1"
            
            # L1 should not have it (write around skips L1)
            l1_value = await cache._get_from_level("key1", CacheLevel.L1)
            # In write around, L1 might still be empty initially
    
    @pytest.mark.asyncio
    async def test_set_write_back_mode(self):
        """Test set with WRITE_BACK mode"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
                write_mode=WriteMode.WRITE_BACK,
            )
            
            # Write back should write to L1 first
            await cache.set("key1", "value1")
            
            # Should be in L1
            l1_value = await cache._get_from_level("key1", CacheLevel.L1)
            assert l1_value == "value1"
    
    @pytest.mark.asyncio
    async def test_delete(self):
        """Test delete"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        await cache.set("key1", "value1")
        result = await cache.delete("key1")
        assert result is True
        
        value = await cache.get("key1")
        assert value is None
    
    @pytest.mark.asyncio
    async def test_delete_nonexistent(self):
        """Test delete nonexistent key"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        result = await cache.delete("nonexistent")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_clear(self):
        """Test clear"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        
        await cache.clear()
        
        assert await cache.get("key1") is None
        assert await cache.get("key2") is None
    
    @pytest.mark.asyncio
    async def test_get_stats(self):
        """Test get_stats"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        await cache.set("key1", "value1")
        await cache.get("key1")  # Hit
        await cache.get("key1")  # Hit
        await cache.get("key2")  # Miss
        
        stats = cache.get_stats()
        assert stats is not None
        assert stats.hits >= 2
        assert stats.misses >= 1
        assert stats.total_requests >= 3
    
    @pytest.mark.asyncio
    async def test_get_stats_detailed(self):
        """Test get_stats with detailed information"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        await cache.set("key1", "value1")
        await cache.get("key1")
        await cache.get("key1")  # Another hit
        
        stats = cache.get_stats()
        assert stats is not None
        assert stats.hits >= 2
        assert stats.total_requests >= 2
        assert stats.get_hit_rate() > 0
    
    @pytest.mark.asyncio
    async def test_record_hit_miss_error(self):
        """Test internal record methods"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        # Record hit
        await cache._record_hit(CacheLevel.L1, 0.001)
        stats = cache.get_stats()
        assert stats.hits >= 1
        
        # Record miss
        await cache._record_miss(0.001)
        stats = cache.get_stats()
        assert stats.misses >= 1
        
        # Record error
        initial_errors = cache.get_stats().errors
        await cache._record_error()
        stats = cache.get_stats()
        assert stats.errors >= initial_errors + 1
    
    @pytest.mark.asyncio
    async def test_get_with_error_handling(self):
        """Test get with error handling"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        # Normal get should work
        await cache.set("key1", "value1")
        value = await cache.get("key1")
        assert value == "value1"
        
        # Get nonexistent key should return None (not raise error)
        value = await cache.get("nonexistent")
        assert value is None
    
    @pytest.mark.asyncio
    async def test_intelligent_routing(self):
        """Test intelligent routing"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=2,  # Small L1 to force eviction
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Fill L1 to capacity
            await cache.set("key1", "value1")
            await cache.set("key2", "value2")
            
            # Add more to trigger eviction to L3
            await cache.set("key3", "value3")
            
            # Router should learn and predict
            # Access key1 multiple times to build pattern
            await cache.get("key1")
            await cache.get("key1")
            
            # Router should have learned
            assert cache.router is not None
    
    @pytest.mark.asyncio
    async def test_promotion_to_l1(self):
        """Test automatic promotion to L1"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set in L3
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Get from L3 should promote to L1
            value = await cache.get("key1")
            assert value == "value1"
            
            # Should now be in L1
            l1_value = await cache._get_from_level("key1", CacheLevel.L1)
            assert l1_value == "value1"
    
    @pytest.mark.asyncio
    async def test_get_with_predicted_level(self):
        """Test get with intelligent routing prediction"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set value in L3
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Access multiple times to build pattern
            await cache.get("key1")
            await cache.get("key1")
            
            # Router should predict L3 for this key
            predicted = cache.router.predict_best_level("key1")
            # May predict L3 or L1 depending on learning
            assert predicted in [CacheLevel.L1, CacheLevel.L3, None]
    
    @pytest.mark.asyncio
    async def test_get_with_l2_enabled(self):
        """Test get with L2 enabled"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=True,
            enable_l3=False,
        )
        
        # L2 is placeholder, so get should work through L1
        await cache.set("key1", "value1")
        value = await cache.get("key1")
        assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_set_write_through_mode(self):
        """Test set with WRITE_THROUGH mode"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
                write_mode=WriteMode.WRITE_THROUGH,
            )
            
            # Write-through should write to all enabled levels
            await cache.set("key1", "value1")
            
            # Should be in both L1 and L3
            l1_value = await cache._get_from_level("key1", CacheLevel.L1)
            l3_value = await cache._get_from_level("key1", CacheLevel.L3)
            assert l1_value == "value1"
            assert l3_value == "value1"
    
    @pytest.mark.asyncio
    async def test_set_write_around_l1(self):
        """Test set with WRITE_AROUND mode when level is L1"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
            write_mode=WriteMode.WRITE_AROUND,
        )
        
        # Write-around with L1 level should still write to L1
        await cache.set("key1", "value1", level=CacheLevel.L1)
        
        value = await cache.get("key1")
        assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_set_with_l2_enabled(self):
        """Test set with L2 enabled"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=True,
            enable_l3=False,
        )
        
        # Should work even with L2 placeholder
        await cache.set("key1", "value1")
        value = await cache.get("key1")
        assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_set_exception_handling(self):
        """Test set with exception handling"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        # Normal set should work
        await cache.set("key1", "value1")
        assert await cache.get("key1") == "value1"
        
        # Set with invalid data should handle gracefully
        # (actual behavior depends on implementation)
        try:
            await cache.set("key2", object())  # May or may not work
        except Exception:
            pass  # Exception handling is tested
    
    @pytest.mark.asyncio
    async def test_get_exception_handling(self):
        """Test get with exception handling"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        # Normal get should work
        await cache.set("key1", "value1")
        value = await cache.get("key1")
        assert value == "value1"
        
        # Get with invalid key should return None (not raise)
        value = await cache.get("invalid_key")
        assert value is None
    
    @pytest.mark.asyncio
    async def test_get_with_router_prediction(self):
        """Test get with router prediction for non-L1 level"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set in L3
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Access to build pattern
            await cache.get("key1")
            
            # Router may predict L3 for subsequent accesses
            # Get should find it via prediction
            value = await cache.get("key1")
            assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_set_to_level_l2(self):
        """Test _set_to_level for L2"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=True,
            enable_l3=False,
        )
        
        # Should handle L2 (even if placeholder)
        await cache._set_to_level("key1", "value1", None, CacheLevel.L2, None)
        # L2 is placeholder, so may not actually store
        # But should not raise exception
    
    @pytest.mark.asyncio
    async def test_get_from_level_l2(self):
        """Test _get_from_level for L2"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=True,
            enable_l3=False,
        )
        
        # L2 is placeholder, should return None
        value = await cache._get_from_level("key1", CacheLevel.L2)
        assert value is None
    
    @pytest.mark.asyncio
    async def test_get_with_predicted_level_l2(self):
        """Test get with predicted level L2"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=True,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set value in L2 (via set with level)
            await cache.set("key1", "value1", level=CacheLevel.L2)
            
            # Make router predict L2
            cache.router.learn_from_access("key1", CacheLevel.L2, hit=True)
            
            # Get should try predicted level
            value = await cache.get("key1")
            # May return None if L2 is placeholder, but should not raise exception
            assert value is None or value == "value1"
    
    @pytest.mark.asyncio
    async def test_get_with_predicted_level_l3(self):
        """Test get with predicted level L3"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set value in L3
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Make router predict L3
            cache.router.learn_from_access("key1", CacheLevel.L3, hit=True)
            
            # Get should try predicted level
            value = await cache.get("key1")
            assert value == "value1"
    
    @pytest.mark.asyncio
    async def test_get_exception_in_get_from_level(self):
        """Test get when _get_from_level raises exception"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        # Mock l1.get to raise exception
        original_get = cache.l1.get
        async def failing_get(key):
            raise Exception("L1 get error")
        cache.l1.get = failing_get
        
        # Should handle exception gracefully
        value = await cache.get("key1")
        assert value is None
        
        # Restore
        cache.l1.get = original_get
    
    @pytest.mark.asyncio
    async def test_set_write_back_mode_batch(self):
        """Test set with WRITE_BACK mode and batch write"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=False,
                enable_l3=True,
                l3_cache_dir=temp_dir,
                write_mode=WriteMode.WRITE_BACK,
            )
            
            # Set multiple values
            await cache.set("key1", "value1")
            await cache.set("key2", "value2")
            
            # Values should be in L1
            assert await cache.l1.get("key1") == "value1"
            assert await cache.l1.get("key2") == "value2"
            
            # Wait for write-back
            await asyncio.sleep(0.1)
            
            # Clear L1 to force read from L3
            await cache.l1.clear()
            
            # Should be written to L3 by write-back
            value1 = await cache.get("key1")
            value2 = await cache.get("key2")
            # May be None if write-back hasn't completed, but should not raise exception
            assert value1 is None or value1 == "value1"
            assert value2 is None or value2 == "value2"
    
    @pytest.mark.asyncio
    async def test_delete_with_l2_l3(self):
        """Test delete with L2 and L3 enabled"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=True,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set values in different levels
            await cache.set("key1", "value1")
            await cache.set("key2", "value2", level=CacheLevel.L3)
            
            # Delete
            result1 = await cache.delete("key1")
            result2 = await cache.delete("key2")
            
            # Should return True if deleted from at least one level
            assert result1 is True or result2 is True
    
    @pytest.mark.asyncio
    async def test_delete_exception(self):
        """Test delete when exception occurs"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        # Mock l1.delete to raise exception
        original_delete = cache.l1.delete
        async def failing_delete(key):
            raise Exception("Delete error")
        cache.l1.delete = failing_delete
        
        # Should handle exception gracefully
        result = await cache.delete("key1")
        assert result is False
        
        # Restore
        cache.l1.delete = original_delete
    
    @pytest.mark.asyncio
    async def test_clear_with_write_back_task(self):
        """Test clear with write-back task running"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=True,
                enable_l3=True,
                l3_cache_dir=temp_dir,
                write_mode=WriteMode.WRITE_BACK,
            )
            
            # Set value to trigger write-back task
            await cache.set("key1", "value1")
            
            # Clear should cancel write-back task
            await cache.clear()
            
            # Should not raise exception
            assert cache._write_back_task is None or cache._write_back_task.done()
    
    @pytest.mark.asyncio
    async def test_clear_with_l2_l3(self):
        """Test clear with L2 and L3 enabled"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=True,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set values
            await cache.set("key1", "value1")
            await cache.set("key2", "value2", level=CacheLevel.L3)
            
            # Clear
            await cache.clear()
            
            # Should clear all levels
            assert await cache.l1.get("key1") is None
            assert await cache.get("key2") is None
    
    @pytest.mark.asyncio
    async def test_clear_exception(self):
        """Test clear when exception occurs"""
        cache = IntelligentCache(
            l1_max_size=10,
            enable_l2=False,
            enable_l3=False,
        )
        
        # Mock l1.clear to raise exception
        original_clear = cache.l1.clear
        async def failing_clear():
            raise Exception("Clear error")
        cache.l1.clear = failing_clear
        
        # Should handle exception gracefully
        await cache.clear()
        
        # Restore
        cache.l1.clear = original_clear
    
    @pytest.mark.asyncio
    async def test_get_fallback_to_l2_l3(self):
        """Test get fallback to L2 and L3 when L1 misses"""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = IntelligentCache(
                l1_max_size=10,
                enable_l2=True,
                enable_l3=True,
                l3_cache_dir=temp_dir,
            )
            
            # Set value in L3 only
            await cache.set("key1", "value1", level=CacheLevel.L3)
            
            # Clear L1 to force fallback
            await cache.l1.clear()
            
            # Get should try L2 first, then L3
            value = await cache.get("key1")
            assert value == "value1"

