"""
Tests for Plugin models.
"""

import pytest
from datetime import datetime
from plugin_adk.core.models.plugins import (
    PluginInfo,
    PluginStatus,
    PluginMetadata,
    PluginManifest,
    SandboxConfig,
    SandboxLevel,
)


class TestPluginInfo:
    """Tests for PluginInfo"""
    
    def test_plugin_info_creation(self):
        """Test PluginInfo creation"""
        info = PluginInfo(
            name="test-plugin",
            version="1.0.0",
            description="Test plugin",
            author="Test Author"
        )
        
        assert info.name == "test-plugin"
        assert info.version == "1.0.0"
        assert info.description == "Test plugin"
        assert info.author == "Test Author"
        assert info.status == PluginStatus.INITIALIZED
        assert isinstance(info.created_at, datetime)


class TestSandboxConfig:
    """Tests for SandboxConfig"""
    
    def test_sandbox_config_creation(self):
        """Test SandboxConfig creation"""
        config = SandboxConfig(
            level=SandboxLevel.STRICT,
            memory_limit_mb=1024.0,
            cpu_limit_percent=75.0
        )
        
        assert config.level == SandboxLevel.STRICT
        assert config.memory_limit_mb == 1024.0
        assert config.cpu_limit_percent == 75.0
        assert isinstance(config.allowed_imports, set)
        assert isinstance(config.denied_imports, set)


class TestPluginManifest:
    """Tests for PluginManifest"""
    
    def test_plugin_manifest_creation(self):
        """Test PluginManifest creation"""
        manifest = PluginManifest(
            plugin_id="test-plugin-123",
            name="test-plugin",
            version="1.0.0",
            description="Test plugin",
            dependencies=["dep1", "dep2"]
        )
        
        assert manifest.plugin_id == "test-plugin-123"
        assert manifest.name == "test-plugin"
        assert manifest.version == "1.0.0"
        assert manifest.dependencies == ["dep1", "dep2"]
    
    def test_plugin_manifest_to_dict(self):
        """Test PluginManifest serialization"""
        manifest = PluginManifest(
            plugin_id="test-plugin-123",
            name="test-plugin",
            version="1.0.0",
            dependencies=["dep1"],
            tools=[{"name": "tool1"}],
            events=["event1"],
            services=["service1"]
        )
        
        manifest_dict = manifest.to_dict()
        
        assert manifest_dict["plugin_id"] == "test-plugin-123"
        assert manifest_dict["name"] == "test-plugin"
        assert manifest_dict["dependencies"] == ["dep1"]
        assert manifest_dict["tools"] == [{"name": "tool1"}]
    
    def test_plugin_manifest_from_dict(self):
        """Test PluginManifest deserialization"""
        manifest_dict = {
            "plugin_id": "test-plugin-123",
            "name": "test-plugin",
            "version": "1.0.0",
            "description": "Test plugin",
            "dependencies": ["dep1"],
            "tools": [],
            "events": [],
            "services": [],
            "config_schema": {},
            "permissions": [],
            "metadata": {}
        }
        
        manifest = PluginManifest.from_dict(manifest_dict)
        
        assert manifest.plugin_id == "test-plugin-123"
        assert manifest.name == "test-plugin"
        assert manifest.version == "1.0.0"
        assert manifest.dependencies == ["dep1"]

