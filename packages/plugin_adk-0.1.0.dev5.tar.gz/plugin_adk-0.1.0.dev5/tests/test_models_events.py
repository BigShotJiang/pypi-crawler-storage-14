"""
Tests for Event models.
"""

import pytest
from datetime import datetime
from plugin_adk.core.models.events import (
    Event,
    EventType,
    EventAction,
    StateDelta,
)


class TestStateDelta:
    """Tests for StateDelta"""
    
    def test_state_delta_creation(self):
        """Test StateDelta creation"""
        delta = StateDelta()
        assert delta.is_empty()
        assert len(delta.changes) == 0
    
    def test_state_delta_add_change(self):
        """Test adding changes to StateDelta"""
        delta = StateDelta()
        delta.add_change("key1", "old_value", "new_value")
        
        assert not delta.is_empty()
        assert "key1" in delta.changes
        assert delta.changes["key1"]["old"] == "old_value"
        assert delta.changes["key1"]["new"] == "new_value"
    
    def test_state_delta_apply_to_state(self):
        """Test applying delta to state"""
        delta = StateDelta()
        delta.add_change("key1", "old", "new")
        delta.add_change("key2", None, "value2")
        
        state = {"key1": "old", "key3": "unchanged"}
        new_state = delta.apply_to_state(state)
        
        assert new_state["key1"] == "new"
        assert new_state["key2"] == "value2"
        assert new_state["key3"] == "unchanged"
    
    def test_state_delta_reverse_from_state(self):
        """Test reversing delta from state"""
        delta = StateDelta()
        delta.add_change("key1", "old", "new")
        delta.add_change("key2", "old2", "new2")
        
        state = {"key1": "new", "key2": "new2", "key3": "unchanged"}
        reversed_state = delta.reverse_from_state(state)
        
        assert reversed_state["key1"] == "old"
        assert reversed_state["key2"] == "old2"
        assert reversed_state["key3"] == "unchanged"


class TestEvent:
    """Tests for Event model"""
    
    def test_event_creation(self):
        """Test basic event creation"""
        event = Event(
            topic="test.topic",
            data={"key": "value"}
        )
        
        assert event.topic == "test.topic"
        assert event.data == {"key": "value"}
        assert event.event_type == EventType.MESSAGE
        assert event.event_id is not None
        assert isinstance(event.timestamp, datetime)
    
    def test_event_with_action(self):
        """Test event with action"""
        event = Event(
            topic="test.topic",
            data={"key": "value"},
            action=EventAction.CREATE
        )
        
        assert event.action == EventAction.CREATE
    
    def test_event_with_state_delta(self):
        """Test event with state delta"""
        delta = StateDelta()
        delta.add_change("key1", "old", "new")
        
        event = Event(
            topic="test.topic",
            data={"key": "value"},
            state_delta=delta
        )
        
        assert event.state_delta is not None
        assert not event.state_delta.is_empty()
    
    def test_event_fluent_api(self):
        """Test event fluent API"""
        delta = StateDelta()
        delta.add_change("key1", "old", "new")
        
        event = Event(
            topic="test.topic",
            data={"key": "value"}
        ).with_action(EventAction.UPDATE).with_state_delta(delta).with_session("session123")
        
        assert event.action == EventAction.UPDATE
        assert event.state_delta is not None
        assert event.session_id == "session123"
    
    def test_event_to_dict(self):
        """Test event serialization to dict"""
        event = Event(
            topic="test.topic",
            data={"key": "value"},
            source="source1",
            target="target1",
            action=EventAction.CREATE
        )
        
        event_dict = event.to_dict()
        
        assert event_dict["topic"] == "test.topic"
        assert event_dict["data"] == {"key": "value"}
        assert event_dict["source"] == "source1"
        assert event_dict["target"] == "target1"
        assert event_dict["action"] == "create"
        assert "event_id" in event_dict
        assert "timestamp" in event_dict
    
    def test_event_from_dict(self):
        """Test event deserialization from dict"""
        event_dict = {
            "event_id": "test-id",
            "event_type": "message",
            "topic": "test.topic",
            "data": {"key": "value"},
            "source": "source1",
            "target": "target1",
            "timestamp": "2025-01-01T00:00:00",
            "metadata": {},
            "action": "create"
        }
        
        event = Event.from_dict(event_dict)
        
        assert event.event_id == "test-id"
        assert event.topic == "test.topic"
        assert event.data == {"key": "value"}
        assert event.source == "source1"
        assert event.target == "target1"
        assert event.action == EventAction.CREATE
    
    def test_event_json_serialization(self):
        """Test event JSON serialization"""
        event = Event(
            topic="test.topic",
            data={"key": "value"},
            action=EventAction.CREATE
        )
        
        json_str = event.to_json()
        assert isinstance(json_str, str)
        assert "test.topic" in json_str
        
        # Deserialize
        event2 = Event.from_json(json_str)
        assert event2.topic == event.topic
        assert event2.data == event.data
        assert event2.action == event.action

