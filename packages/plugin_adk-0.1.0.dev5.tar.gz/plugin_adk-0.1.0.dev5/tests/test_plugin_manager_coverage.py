"""
Coverage tests for PluginManager.
"""

import pytest
import asyncio
import sys
from unittest.mock import MagicMock, AsyncMock, patch
from plugin_adk.core.plugin.manager import PluginManager, PluginError
from plugin_adk.core.plugin.base import BasePlugin
from plugin_adk.core.models.events import Event, EventType
from plugin_adk.core.models.plugins import PluginStatus
import plugin_adk.core.plugin.manager as pm_module

class MockPlugin(BasePlugin):
    def __init__(self, name, **kwargs):
        super().__init__(name=name, **kwargs)
        self.handle_event = AsyncMock()
        self.validate_config = AsyncMock(return_value=True)
        # We don't mock start/stop here, we rely on BasePlugin implementation
        # and mock the hooks on_start/on_stop

    async def on_initialize(self):
        return True

    async def on_start(self):
        return True

    async def on_stop(self):
        return True
        
    async def on_get_supported_event_types(self):
        return []
        
    async def on_get_supported_actions(self):
        return []

@pytest.fixture
def manager():
    # Ensure we use the current PluginManager class
    return pm_module.PluginManager()

@pytest.mark.asyncio
class TestPluginManagerCoverage:

    async def test_unregister_cleanup(self, manager):
        """Test cleanup of dependencies and call graph on unregister"""
        p1 = MockPlugin("p1")
        p2 = MockPlugin("p2")
        
        # Mock dependencies
        with patch.object(manager, '_get_plugin_dependencies', return_value={"p2"}):
            await manager.register_plugin(p2)
            await manager.register_plugin(p1)
        
        # Verify setup
        assert "p1" in manager.plugin_dependencies
        assert "p2" in manager.plugin_dependents
        
        # Add call graph entry
        manager.service_call_graph["p1"].add("p2")
        manager.service_call_graph["p2"].add("p1")
        
        # Unregister p1
        await manager.unregister_plugin("p1")
        
        # Verify cleanup
        assert "p1" not in manager.plugin_dependencies
        assert "p1" not in manager.plugin_dependents.get("p2", set())
        assert "p1" not in manager.service_call_graph
        assert "p1" not in manager.service_call_graph.get("p2", set())

    async def test_start_all_rollback(self, manager):
        """Test rollback when start_all fails"""
        p1 = MockPlugin("p1")
        p2 = MockPlugin("p2")
        p3 = MockPlugin("p3")
        
        # p3 fails to start
        p3.on_start = AsyncMock(return_value=False)
        
        # Mock dependencies: p3 -> p2 -> p1
        async def get_deps(plugin):
            if plugin.name == "p2": return {"p1"}
            if plugin.name == "p3": return {"p2"}
            return set()
            
        with patch.object(manager, '_get_plugin_dependencies', side_effect=get_deps):
            await manager.register_plugin(p1)
            await manager.register_plugin(p2)
            await manager.register_plugin(p3)
            
            # Start all should return False (caught exception)
            result = await manager.start_all()
            assert result is False
            
            # Verify p1 and p2 were stopped (rollback)
            assert p1.status == PluginStatus.STOPPED
            assert p2.status == PluginStatus.STOPPED
            assert p3.status == PluginStatus.ERROR # Failed start

    async def test_stop_all_exception(self, manager):
        """Test stop_all continues on exception"""
        p1 = MockPlugin("p1")
        p2 = MockPlugin("p2")
        
        # Set running state manually
        p1._status = PluginStatus.RUNNING
        p2._status = PluginStatus.RUNNING
        
        # Mock on_stop to raise exception for p1
        p1.on_stop = AsyncMock(side_effect=Exception("Stop failed"))
        
        await manager.register_plugin(p1)
        await manager.register_plugin(p2)
        manager.is_running = True
        
        # Should not raise exception
        result = await manager.stop_all()
        
        assert result is True
        assert p1.status == PluginStatus.ERROR # Exception in stop sets ERROR
        assert p2.status == PluginStatus.STOPPED

    async def test_route_event_exception(self, manager):
        """Test route_event continues on exception"""
        p1 = MockPlugin("p1")
        p2 = MockPlugin("p2")
        
        p1._status = PluginStatus.RUNNING
        p2._status = PluginStatus.RUNNING
        
        # Mock handle_event (which calls on_event)
        p1.handle_event = AsyncMock(side_effect=Exception("Handle failed"))
        p2.handle_event = AsyncMock(return_value=None)
        
        # Mock supported events
        p1.on_get_supported_event_types = AsyncMock(return_value=["custom"])
        p2.on_get_supported_event_types = AsyncMock(return_value=["custom"])
        
        await manager.register_plugin(p1)
        await manager.register_plugin(p2)
        
        event = Event(topic="test", data={}, event_type=EventType.CUSTOM)
        
        # Should not raise exception
        responses = await manager.route_event(event)
        
        assert len(responses) == 0
        assert p1.handle_event.called
        assert p2.handle_event.called

    async def test_call_service_errors(self, manager):
        """Test call_service error conditions"""
        # Get the current PluginError class
        CurrentPluginError = pm_module.PluginError

        p1 = MockPlugin("p1")
        p1.on_get_supported_actions = AsyncMock(return_value=["s1"])
        p1.execute = MagicMock(return_value="result")
        
        await manager.register_plugin(p1)
        
        # 1. Plugin not found for service
        manager.service_handlers["s2"] = "non_existent_plugin"
        try:
            await manager.call_service("s2")
            pytest.fail("Should have raised PluginError")
        except Exception as e:
            assert isinstance(e, CurrentPluginError)
            assert "Plugin not found for service" in str(e)
            
        # 2. Plugin not running
        p1._status = PluginStatus.STOPPED
        try:
            await manager.call_service("s1")
            pytest.fail("Should have raised PluginError")
        except Exception as e:
            assert isinstance(e, CurrentPluginError)
            assert "is not running" in str(e)
            
        # 3. Method not found
        p1._status = PluginStatus.RUNNING
        try:
            await manager.call_service("s1", method="missing")
            pytest.fail("Should have raised PluginError")
        except Exception as e:
            assert isinstance(e, CurrentPluginError)
            assert "Method 'missing' not found" in str(e)

    async def test_service_discovery_remote_call(self, manager):
        """Test remote service discovery placeholder error"""
        # Get the current PluginError class
        CurrentPluginError = pm_module.PluginError

        mock_sd = AsyncMock()
        # Explicitly set discover as AsyncMock
        mock_sd.discover = AsyncMock(return_value=[MagicMock(endpoint="remote://")])
        
        manager.service_discovery = mock_sd
        
        # Force HAS_SERVICE_DISCOVERY to True
        with patch("plugin_adk.core.plugin.manager.HAS_SERVICE_DISCOVERY", True):
            # Must ensure service is NOT found locally first
            try:
                await manager.call_service("remote_service")
                pytest.fail("Should have raised PluginError")
            except Exception as e:
                assert isinstance(e, CurrentPluginError)
                assert "remote service calls are not yet fully implemented" in str(e)

    async def test_register_unregister_services(self, manager):
        """Test service registration/unregistration with discovery"""
        mock_sd = AsyncMock()
        manager.service_discovery = mock_sd
        
        p1 = MockPlugin("p1")
        p1.on_get_supported_actions = AsyncMock(return_value=["s1"])
        
        # Force HAS_SERVICE_DISCOVERY to True
        with patch("plugin_adk.core.plugin.manager.HAS_SERVICE_DISCOVERY", True):
            # Register
            await manager.register_plugin(p1)
            assert mock_sd.register.called
            
            # Unregister
            await manager.unregister_plugin("p1")
            assert mock_sd.unregister.called

    async def test_register_service_override_warning(self, manager):
        """Test warning when overriding service"""
        p1 = MockPlugin("p1")
        p1.on_get_supported_actions = AsyncMock(return_value=["s1"])
        
        p2 = MockPlugin("p2")
        p2.on_get_supported_actions = AsyncMock(return_value=["s1"])
        
        await manager.register_plugin(p1)
        
        # Register p2 providing same service
        with patch.object(manager.logger, 'warning') as mock_warn:
            await manager.register_plugin(p2)
            mock_warn.assert_called_with(
                "Service 's1' has been registered by plugin 'p1', now being overridden by plugin 'p2'"
            )

    async def test_service_discovery_import_error(self):
        """Test ImportError handling for ServiceDiscovery.
        NOTE: This test reloads the module, so it must be the LAST test to run
        to avoid affecting other tests with class mismatches.
        """
        with patch.dict('sys.modules', {'plugin_adk.core.coordination.discovery': None}):
            import importlib
            import plugin_adk.core.plugin.manager
            importlib.reload(plugin_adk.core.plugin.manager)
            
            assert not plugin_adk.core.plugin.manager.HAS_SERVICE_DISCOVERY
            assert plugin_adk.core.plugin.manager.ServiceDiscovery is None
            
            # Restore
            importlib.reload(plugin_adk.core.plugin.manager)
