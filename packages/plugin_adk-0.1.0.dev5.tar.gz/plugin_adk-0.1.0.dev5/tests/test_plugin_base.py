"""
Tests for BasePlugin.
"""

import pytest
from plugin_adk.core.plugin.base import BasePlugin
from plugin_adk.core.models.plugins import PluginStatus
from plugin_adk.core.models.events import Event, EventType


class MockPlugin(BasePlugin):
    """Test plugin implementation"""
    
    async def on_initialize(self) -> bool:
        return True
    
    async def on_start(self) -> bool:
        return True
    
    async def on_stop(self) -> bool:
        return True


class TestBasePlugin:
    """Tests for BasePlugin"""
    
    def test_plugin_creation(self):
        """Test plugin creation"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        assert plugin.name == "test-plugin"
        assert plugin.version == "1.0.0"
        assert plugin.status == PluginStatus.INITIALIZED
        assert plugin.is_running is False
    
    @pytest.mark.asyncio
    async def test_plugin_lifecycle(self):
        """Test plugin lifecycle"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        # Initialize
        result = await plugin.initialize()
        assert result is True
        assert plugin.status == PluginStatus.INITIALIZED
        
        # Start
        result = await plugin.start()
        assert result is True
        assert plugin.status == PluginStatus.RUNNING
        assert plugin.is_running is True
        
        # Stop
        result = await plugin.stop()
        assert result is True
        assert plugin.status == PluginStatus.STOPPED
        assert plugin.is_running is False
    
    @pytest.mark.asyncio
    async def test_plugin_info(self):
        """Test plugin info"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0", description="Test")
        
        info = plugin.info
        assert info.name == "test-plugin"
        assert info.version == "1.0.0"
        assert info.description == "Test"
        assert info.plugin_type == "MockPlugin"
    
    @pytest.mark.asyncio
    async def test_handle_event(self):
        """Test handle_event"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        await plugin.start()
        
        event = Event(
            topic="test.topic",
            data={"key": "value"}
        )
        
        # Plugin not handling events, should return None
        result = await plugin.handle_event(event)
        assert result is None
    
    @pytest.mark.asyncio
    async def test_handle_event_not_running(self):
        """Test handle_event when plugin is not running"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        # Don't start plugin
        
        event = Event(
            topic="test.topic",
            data={"key": "value"}
        )
        
        result = await plugin.handle_event(event)
        assert result is None
    
    @pytest.mark.asyncio
    async def test_get_supported_actions(self):
        """Test get_supported_actions"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        # Default implementation should return empty list
        actions = await plugin.get_supported_actions()
        assert isinstance(actions, list)
    
    @pytest.mark.asyncio
    async def test_get_supported_event_types(self):
        """Test get_supported_event_types"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        # Default implementation should return empty list
        event_types = await plugin.get_supported_event_types()
        assert isinstance(event_types, list)
    
    @pytest.mark.asyncio
    async def test_validate_config(self):
        """Test validate_config"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        # Default implementation should return True
        result = await plugin.validate_config({"key": "value"})
        assert result is True
    
    @pytest.mark.asyncio
    async def test_cleanup(self):
        """Test cleanup"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        await plugin.start()
        await plugin.stop()
        
        # Cleanup should succeed
        result = await plugin.cleanup()
        assert result is True
    
    @pytest.mark.asyncio
    async def test_cleanup_not_stopped(self):
        """Test cleanup when plugin is not stopped"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        await plugin.start()
        # Don't stop plugin
        
        # Cleanup should still succeed (default implementation)
        # The plugin will be unloaded during cleanup
        result = await plugin.cleanup()
        assert result is True
        assert plugin.status == PluginStatus.UNLOADED
    
    @pytest.mark.asyncio
    async def test_handle_event_with_exception(self):
        """Test handle_event when on_event raises exception"""
        class EventPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
            async def on_event(self, event):
                raise ValueError("Test error")
        
        plugin = EventPlugin(name="event-plugin", version="1.0.0")
        await plugin.start()
        
        event = Event(
            topic="test.topic",
            data={"key": "value"}
        )
        
        result = await plugin.handle_event(event)
        # Should return error response
        assert result is not None
        # Response should have message or error field
        # Check if it's a Response object with error information
        if hasattr(result, 'message'):
            assert "error" in result.message.lower() or "failed" in result.message.lower()
        elif hasattr(result, 'error'):
            assert result.error is not None
        else:
            # Just check it's not None
            assert result is not None
    
    @pytest.mark.asyncio
    async def test_get_supported_event_types_default(self):
        """Test get_supported_event_types default implementation"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        event_types = await plugin.get_supported_event_types()
        assert event_types == []
    
    @pytest.mark.asyncio
    async def test_get_supported_actions_default(self):
        """Test get_supported_actions default implementation"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        actions = await plugin.get_supported_actions()
        assert actions == []
    
    @pytest.mark.asyncio
    async def test_validate_config_default(self):
        """Test validate_config default implementation"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        result = await plugin.validate_config({"key": "value"})
        assert result is True
    
    @pytest.mark.asyncio
    async def test_on_event_default(self):
        """Test on_event default implementation"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        await plugin.start()
        
        event = Event(
            topic="test.topic",
            data={"key": "value"}
        )
        
        result = await plugin.on_event(event)
        assert result is None
    
    @pytest.mark.asyncio
    async def test_on_cleanup_default(self):
        """Test on_cleanup default implementation"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        result = await plugin.on_cleanup()
        assert result is True
    
    @pytest.mark.asyncio
    async def test_initialize_failure(self):
        """Test initialize when on_initialize returns False"""
        class FailingPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return False
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
        
        plugin = FailingPlugin(name="failing", version="1.0.0")
        result = await plugin.initialize()
        
        assert result is False
        assert plugin.status == PluginStatus.ERROR
        assert plugin.info.status == PluginStatus.ERROR
        assert plugin.info.error_message == "Initialization failed"
    
    @pytest.mark.asyncio
    async def test_initialize_exception(self):
        """Test initialize when on_initialize raises exception"""
        class ExceptionPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                raise ValueError("Init error")
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
        
        plugin = ExceptionPlugin(name="exception", version="1.0.0")
        result = await plugin.initialize()
        
        assert result is False
        assert plugin.status == PluginStatus.ERROR
        assert plugin.info.status == PluginStatus.ERROR
        assert "Init error" in plugin.info.error_message
    
    @pytest.mark.asyncio
    async def test_initialize_wrong_status(self):
        """Test initialize when status is not INITIALIZED"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        await plugin.start()  # Change status to RUNNING
        
        result = await plugin.initialize()
        assert result is False
    
    @pytest.mark.asyncio
    async def test_start_failure(self):
        """Test start when on_start returns False"""
        class FailingStartPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return False
            async def on_stop(self) -> bool:
                return True
        
        plugin = FailingStartPlugin(name="failing-start", version="1.0.0")
        await plugin.initialize()
        result = await plugin.start()
        
        assert result is False
        assert plugin.status == PluginStatus.ERROR
        assert plugin.info.status == PluginStatus.ERROR
        assert plugin.info.error_message == "Startup failed"
    
    @pytest.mark.asyncio
    async def test_start_exception(self):
        """Test start when on_start raises exception"""
        class ExceptionStartPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                raise ValueError("Start error")
            async def on_stop(self) -> bool:
                return True
        
        plugin = ExceptionStartPlugin(name="exception-start", version="1.0.0")
        await plugin.initialize()
        result = await plugin.start()
        
        assert result is False
        assert plugin.status == PluginStatus.ERROR
        assert plugin.info.status == PluginStatus.ERROR
        assert "Start error" in plugin.info.error_message
    
    @pytest.mark.asyncio
    async def test_start_wrong_status(self):
        """Test start when status does not allow startup"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        # Status is INITIALIZED, should work
        result = await plugin.start()
        assert result is True
        
        # Try to start again (status is RUNNING, should fail)
        result = await plugin.start()
        assert result is False
    
    @pytest.mark.asyncio
    async def test_stop_failure(self):
        """Test stop when on_stop returns False"""
        class FailingStopPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return False
        
        plugin = FailingStopPlugin(name="failing-stop", version="1.0.0")
        await plugin.initialize()
        await plugin.start()
        result = await plugin.stop()
        
        assert result is False
        assert plugin.status == PluginStatus.ERROR
        assert plugin.info.status == PluginStatus.ERROR
        assert plugin.info.error_message == "Shutdown failed"
    
    @pytest.mark.asyncio
    async def test_stop_exception(self):
        """Test stop when on_stop raises exception"""
        class ExceptionStopPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                raise ValueError("Stop error")
        
        plugin = ExceptionStopPlugin(name="exception-stop", version="1.0.0")
        await plugin.initialize()
        await plugin.start()
        result = await plugin.stop()
        
        assert result is False
        assert plugin.status == PluginStatus.ERROR
        assert plugin.info.status == PluginStatus.ERROR
        assert "Stop error" in plugin.info.error_message
    
    @pytest.mark.asyncio
    async def test_stop_not_running(self):
        """Test stop when plugin is not running"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        # Plugin is INITIALIZED, not RUNNING
        result = await plugin.stop()
        assert result is False
    
    @pytest.mark.asyncio
    async def test_cleanup_exception(self):
        """Test cleanup when on_cleanup raises exception"""
        class ExceptionCleanupPlugin(BasePlugin):
            async def on_initialize(self) -> bool:
                return True
            async def on_start(self) -> bool:
                return True
            async def on_stop(self) -> bool:
                return True
            async def on_cleanup(self) -> bool:
                raise ValueError("Cleanup error")
        
        plugin = ExceptionCleanupPlugin(name="exception-cleanup", version="1.0.0")
        await plugin.start()
        await plugin.stop()
        
        # Cleanup should catch exception and return False
        # Status should remain STOPPED (not set to UNLOADED on exception)
        result = await plugin.cleanup()
        assert result is False
        # Status remains STOPPED because exception prevented setting to UNLOADED
        assert plugin.status == PluginStatus.STOPPED
    
    @pytest.mark.asyncio
    async def test_start_status_transitions(self):
        """Test status transitions during start"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        
        assert plugin.status == PluginStatus.INITIALIZED
        
        # Start should transition: INITIALIZED -> STARTING -> RUNNING
        await plugin.start()
        assert plugin.status == PluginStatus.RUNNING
        assert plugin.info.started_at is not None
    
    @pytest.mark.asyncio
    async def test_stop_status_transitions(self):
        """Test status transitions during stop"""
        plugin = MockPlugin(name="test-plugin", version="1.0.0")
        await plugin.start()
        
        # Stop should transition: RUNNING -> STOPPING -> STOPPED
        await plugin.stop()
        assert plugin.status == PluginStatus.STOPPED
        assert plugin.info.stopped_at is not None

