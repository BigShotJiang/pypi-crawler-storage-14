"""
Coverage tests for SmolagentsSandbox.
"""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch
from plugin_adk.core.sandbox.smolagents_sandbox import SmolagentsSandbox
from plugin_adk.core.models.plugins import SandboxConfig, SandboxLevel
from plugin_adk.core.sandbox.base import SandboxStatus

# Mock smolagents if not installed
import sys
mock_smolagents = MagicMock()
mock_smolagents.CodeAgent = MagicMock
mock_smolagents.Tool = MagicMock
sys.modules["smolagents"] = mock_smolagents

@pytest.fixture
def mock_code_agent():
    with patch("plugin_adk.core.sandbox.smolagents_sandbox.CodeAgent") as mock:
        yield mock

@pytest.fixture
def mock_tool():
    with patch("plugin_adk.core.sandbox.smolagents_sandbox.Tool") as mock:
        yield mock

@pytest.fixture
def sandbox():
    config = SandboxConfig(level=SandboxLevel.BASIC)
    # Ensure HAS_SMOLAGENTS is True for tests
    with patch("plugin_adk.core.sandbox.smolagents_sandbox.HAS_SMOLAGENTS", True):
        yield SmolagentsSandbox(config=config)

class TestSmolagentsSandboxCoverage:
    """Tests for SmolagentsSandbox coverage"""

    def test_create_agent_with_limits(self, sandbox, mock_code_agent):
        """Test _create_agent with resource limits"""
        sandbox.config.memory_limit_mb = 512
        sandbox.config.timeout_seconds = 30
        sandbox.config.allowed_imports = ["math", "json"]
        
        agent = sandbox._create_agent()
        
        assert mock_code_agent.called
        call_kwargs = mock_code_agent.call_args[1]
        assert call_kwargs["max_memory_mb"] == 512
        assert call_kwargs["max_execution_time"] == 30
        assert call_kwargs["allowed_modules"] == {"math", "json"}

    def test_create_agent_exception_fallback(self, sandbox, mock_code_agent):
        """Test _create_agent fallback when exception occurs"""
        # First call raises exception (e.g. unsupported arg)
        mock_code_agent.side_effect = [TypeError("Unexpected argument"), MagicMock()]
        
        sandbox.config.memory_limit_mb = 512
        
        agent = sandbox._create_agent()
        
        # Should have been called twice
        assert mock_code_agent.call_count == 2
        # Second call should be without extra args
        call_kwargs = mock_code_agent.call_args[1]
        assert "max_memory_mb" not in call_kwargs

    @pytest.mark.asyncio
    async def test_execute_async_run(self, sandbox, mock_code_agent):
        """Test execute using run_async"""
        mock_agent_instance = MagicMock()
        mock_agent_instance.run_async = AsyncMock(return_value="result")
        mock_code_agent.return_value = mock_agent_instance
        
        result = await sandbox.execute("print('hello')")
        
        assert result.status == SandboxStatus.COMPLETED
        assert result.result == "result"
        assert mock_agent_instance.run_async.called

    @pytest.mark.asyncio
    async def test_execute_sync_run(self, sandbox, mock_code_agent):
        """Test execute using run (sync)"""
        mock_agent_instance = MagicMock()
        del mock_agent_instance.run_async # Ensure run_async is missing
        mock_agent_instance.run = MagicMock(return_value="result")
        mock_code_agent.return_value = mock_agent_instance
        
        result = await sandbox.execute("print('hello')")
        
        assert result.status == SandboxStatus.COMPLETED
        assert result.result == "result"
        assert mock_agent_instance.run.called

    @pytest.mark.asyncio
    async def test_execute_fallback(self, sandbox, mock_code_agent):
        """Test execute using fallback execute method"""
        mock_agent_instance = MagicMock()
        del mock_agent_instance.run_async
        del mock_agent_instance.run
        mock_agent_instance.execute = MagicMock(return_value="result")
        mock_code_agent.return_value = mock_agent_instance
        
        result = await sandbox.execute("print('hello')")
        
        assert result.status == SandboxStatus.COMPLETED
        assert result.result == "result"
        assert mock_agent_instance.execute.called

    @pytest.mark.asyncio
    async def test_execute_timeout(self, sandbox, mock_code_agent):
        """Test execute timeout"""
        mock_agent_instance = MagicMock()
        # Simulate timeout by sleeping
        async def slow_run(*args, **kwargs):
            await asyncio.sleep(0.2)
            return "result"
        
        mock_agent_instance.run_async = slow_run
        mock_code_agent.return_value = mock_agent_instance
        
        # Set short timeout
        result = await sandbox.execute("code", timeout=0.1)
        
        assert result.status == SandboxStatus.TIMEOUT
        assert "timeout" in result.error

    @pytest.mark.asyncio
    async def test_validate_code_imports(self, sandbox):
        """Test validate_code with import restrictions"""
        # BaseSandbox checks dangerous patterns first.
        # We need to use safe imports to test SmolagentsSandbox logic.
        
        sandbox.config.allowed_imports = ["math"]
        
        # Allowed
        valid, _ = await sandbox.validate_code("import math")
        assert valid
        
        # Not allowed (but safe for BaseSandbox)
        # "import json" is safe for BaseSandbox, but not in allowed_imports
        valid, msg = await sandbox.validate_code("import json")
        assert not valid
        assert "not in allowed imports" in msg
        
        # Denied
        sandbox.config.allowed_imports = None
        sandbox.config.denied_imports = ["time"]
        
        # "import time" is safe for BaseSandbox, but in denied_imports
        valid, msg = await sandbox.validate_code("import time")
        assert not valid
        assert "in denied imports" in msg

    def test_sdk_to_tools(self, sandbox, mock_tool):
        """Test _sdk_to_tools conversion"""
        mock_sdk = MagicMock()
        mock_sdk.list_services.return_value = {
            "service1": {"description": "desc", "parameters": {}}
        }
        mock_sdk.call_service = AsyncMock(return_value="service_result")
        
        sandbox.sdk = mock_sdk
        tools = sandbox._sdk_to_tools(mock_sdk)
        
        assert len(tools) == 1
        assert mock_tool.called
        
        # Verify tool function calls sdk
        tool_instance = tools[0]
        # In our mock, tool_instance is the return value of Tool constructor
        # We can't easily execute the 'func' passed to Tool constructor unless we capture it
        
        # Capture the func passed to Tool
        call_args = mock_tool.call_args[1]
        tool_func = call_args["func"]
        
        # Execute tool func
        loop = asyncio.new_event_loop()
        res = loop.run_until_complete(tool_func(arg="val"))
        loop.close()
        
        assert res == "service_result"
        mock_sdk.call_service.assert_called_with("service1", arg="val")

    def test_create_tool_failure(self, sandbox, mock_tool):
        """Test _create_tool_from_service failure handling"""
        mock_tool.side_effect = Exception("Tool creation failed")
        
        tool = sandbox._create_tool_from_service("test", {})
        assert tool is None
