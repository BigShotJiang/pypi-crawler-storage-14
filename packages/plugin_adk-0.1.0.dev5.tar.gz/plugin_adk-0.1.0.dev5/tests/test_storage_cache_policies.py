"""
Tests for cache policies.
"""

import pytest
import time
from datetime import datetime, timedelta

from plugin_adk.core.storage.cache_policies import (
    CachePolicy,
    LRUPolicy,
    LFUPolicy,
    TTLPolicy,
    AdaptivePolicy,
)
from plugin_adk.core.storage.cache_models import CacheEntry, CacheLevel


class TestLRUPolicy:
    """Tests for LRUPolicy"""
    
    def test_lru_policy_init(self):
        """Test LRU policy initialization"""
        policy = LRUPolicy()
        assert len(policy.access_times) == 0
    
    def test_lru_policy_should_evict(self):
        """Test LRU policy should evict"""
        policy = LRUPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        # Should evict when cache is full
        assert policy.should_evict(entry, cache_size=10, max_size=10) is True
        assert policy.should_evict(entry, cache_size=5, max_size=10) is False
    
    def test_lru_policy_calculate_eviction_score(self):
        """Test LRU policy eviction score"""
        policy = LRUPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        # Wait a bit to ensure different timestamps
        time.sleep(0.02)
        entry2 = CacheEntry("key2", "value2", CacheLevel.L1)
        
        score1 = policy.calculate_eviction_score(entry)
        score2 = policy.calculate_eviction_score(entry2)
        
        # entry1 is older, so score1 should be more negative (smaller)
        # Both are negative timestamps, older = more negative = smaller
        # Allow for small timing differences
        assert score1 <= score2 or abs(score1 - score2) < 0.1
    
    def test_lru_policy_on_access(self):
        """Test LRU policy on access"""
        policy = LRUPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        initial_count = entry.access_count
        
        policy.on_access(entry)
        
        assert entry.access_count == initial_count + 1
        assert entry.key in policy.access_times
    
    def test_lru_policy_on_insert(self):
        """Test LRU policy on insert"""
        policy = LRUPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        policy.on_insert(entry)
        
        assert entry.key in policy.access_times


class TestLFUPolicy:
    """Tests for LFUPolicy"""
    
    def test_lfu_policy_init(self):
        """Test LFU policy initialization"""
        policy = LFUPolicy()
        assert len(policy.access_counts) == 0
    
    def test_lfu_policy_should_evict(self):
        """Test LFU policy should evict"""
        policy = LFUPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        assert policy.should_evict(entry, cache_size=10, max_size=10) is True
        assert policy.should_evict(entry, cache_size=5, max_size=10) is False
    
    def test_lfu_policy_calculate_eviction_score(self):
        """Test LFU policy eviction score"""
        policy = LFUPolicy()
        entry1 = CacheEntry("key1", "value1", CacheLevel.L1)
        entry2 = CacheEntry("key2", "value2", CacheLevel.L1)
        
        # Access entry1 more times
        policy.on_access(entry1)
        policy.on_access(entry1)
        policy.on_access(entry2)
        
        score1 = policy.calculate_eviction_score(entry1)
        score2 = policy.calculate_eviction_score(entry2)
        
        # entry2 should have higher score (less frequently used)
        assert score2 > score1
    
    def test_lfu_policy_on_access(self):
        """Test LFU policy on access"""
        policy = LFUPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        policy.on_access(entry)
        assert policy.access_counts[entry.key] == 1
        
        policy.on_access(entry)
        assert policy.access_counts[entry.key] == 2
    
    def test_lfu_policy_on_insert(self):
        """Test LFU policy on insert"""
        policy = LFUPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        policy.on_insert(entry)
        assert policy.access_counts[entry.key] == 1  # Initialized to 1


class TestTTLPolicy:
    """Tests for TTLPolicy"""
    
    def test_ttl_policy_init(self):
        """Test TTL policy initialization"""
        policy = TTLPolicy()
        assert policy is not None
    
    def test_ttl_policy_should_evict(self):
        """Test TTL policy should evict"""
        policy = TTLPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        assert policy.should_evict(entry, cache_size=10, max_size=10) is True
        assert policy.should_evict(entry, cache_size=5, max_size=10) is False
    
    def test_ttl_policy_calculate_eviction_score_expired(self):
        """Test TTL policy eviction score for expired entry"""
        policy = TTLPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        entry.expires_at = datetime.now() - timedelta(seconds=10)  # Expired
        
        score = policy.calculate_eviction_score(entry)
        assert score > 0  # Expired entries should have high score
    
    def test_ttl_policy_calculate_eviction_score_not_expired(self):
        """Test TTL policy eviction score for non-expired entry"""
        policy = TTLPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        entry.expires_at = datetime.now() + timedelta(seconds=10)  # Not expired
        
        score = policy.calculate_eviction_score(entry)
        # Score is negative time until expiry, so not expired = negative score
        assert score < 0  # Negative because time_until_expiry is positive
    
    def test_ttl_policy_on_access(self):
        """Test TTL policy on access"""
        policy = TTLPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        # Should not raise error
        policy.on_access(entry)
    
    def test_ttl_policy_on_insert(self):
        """Test TTL policy on insert"""
        policy = TTLPolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        # Should not raise error
        policy.on_insert(entry)


class TestAdaptivePolicy:
    """Tests for AdaptivePolicy"""
    
    def test_adaptive_policy_init(self):
        """Test adaptive policy initialization"""
        policy = AdaptivePolicy()
        assert policy.lru_policy is not None
        assert policy.lfu_policy is not None
        # AdaptivePolicy doesn't have ttl_policy, only lru and lfu
    
    def test_adaptive_policy_should_evict(self):
        """Test adaptive policy should evict"""
        policy = AdaptivePolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        assert policy.should_evict(entry, cache_size=10, max_size=10) is True
        assert policy.should_evict(entry, cache_size=5, max_size=10) is False
    
    def test_adaptive_policy_calculate_eviction_score(self):
        """Test adaptive policy eviction score"""
        policy = AdaptivePolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        score = policy.calculate_eviction_score(entry)
        assert isinstance(score, float)
    
    def test_adaptive_policy_on_access(self):
        """Test adaptive policy on access"""
        policy = AdaptivePolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        initial_count = entry.access_count
        
        policy.on_access(entry)
        
        # Should update access count
        assert entry.access_count >= initial_count
    
    def test_adaptive_policy_on_insert(self):
        """Test adaptive policy on insert"""
        policy = AdaptivePolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        # Should not raise error
        policy.on_insert(entry)
    
    def test_adaptive_policy_with_expired_entry(self):
        """Test adaptive policy with expired entry"""
        policy = AdaptivePolicy()
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        entry.expires_at = datetime.now() - timedelta(seconds=10)  # Expired
        
        score = policy.calculate_eviction_score(entry)
        # Score is combined LRU and LFU, both negative, so score will be negative
        assert isinstance(score, float)

