"""
Tests for Event Sourcing.
"""

import pytest
import asyncio
from plugin_adk.core.communication import (
    EventStore,
    EventSourcing,
    EventSourcingError,
)
from plugin_adk.core.models.events import Event, EventType, EventAction, StateDelta


class TestEventStore:
    """Tests for EventStore"""
    
    @pytest.mark.asyncio
    async def test_append_event(self):
        """Test appending events"""
        store = EventStore()
        
        event = Event(
            topic="test",
            data={"key": "value"},
            session_id="session1"
        )
        
        await store.append(event)
        
        events = await store.get_events("session1")
        assert len(events) == 1
        assert events[0].event_id == event.event_id
    
    @pytest.mark.asyncio
    async def test_replay_events(self):
        """Test replaying events"""
        store = EventStore()
        
        # Create events with state deltas
        delta1 = StateDelta()
        delta1.add_change("counter", 0, 1)
        
        event1 = Event(
            topic="test",
            data={"action": "increment"},
            session_id="session1",
            state_delta=delta1
        )
        
        delta2 = StateDelta()
        delta2.add_change("counter", 1, 2)
        
        event2 = Event(
            topic="test",
            data={"action": "increment"},
            session_id="session1",
            state_delta=delta2
        )
        
        await store.append(event1)
        await store.append(event2)
        
        # Replay events
        state = await store.replay("session1")
        
        assert state["counter"] == 2
    
    @pytest.mark.asyncio
    async def test_rewind(self):
        """Test rewinding state"""
        store = EventStore()
        
        # Create events with state deltas
        for i in range(3):
            delta = StateDelta()
            delta.add_change("counter", i, i + 1)
            
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1",
                state_delta=delta
            )
            
            await store.append(event)
        
        # Rewind by 1 step
        state = await store.rewind("session1", steps=1)
        
        assert state["counter"] == 2
    
    @pytest.mark.asyncio
    async def test_get_event(self):
        """Test getting event by ID"""
        store = EventStore()
        
        event = Event(
            topic="test",
            data={"key": "value"},
            session_id="session1"
        )
        
        await store.append(event)
        
        retrieved = await store.get_event(event.event_id)
        
        assert retrieved is not None
        assert retrieved.event_id == event.event_id
    
    @pytest.mark.asyncio
    async def test_find_event_index(self):
        """Test finding event index"""
        store = EventStore()
        
        event1 = Event(topic="test", data={}, session_id="session1")
        event2 = Event(topic="test", data={}, session_id="session1")
        
        await store.append(event1)
        await store.append(event2)
        
        index = await store.find_event_index("session1", event2.event_id)
        
        assert index == 1


class TestEventSourcing:
    """Tests for EventSourcing"""
    
    @pytest.mark.asyncio
    async def test_record_event_with_delta(self):
        """Test recording event with state delta"""
        sourcing = EventSourcing()
        
        old_state = {"counter": 0}
        new_state = {"counter": 1}
        
        event = Event(
            topic="test",
            data={"action": "increment"},
            session_id="session1"
        )
        
        recorded = await sourcing.record_event(
            event,
            compute_state_delta=True,
            old_state=old_state,
            new_state=new_state
        )
        
        assert recorded.state_delta is not None
        assert "counter" in recorded.state_delta.changes
    
    @pytest.mark.asyncio
    async def test_replay_to_state(self):
        """Test replaying to specific state"""
        sourcing = EventSourcing()
        
        # Record events
        for i in range(3):
            old_state = {"counter": i}
            new_state = {"counter": i + 1}
            
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1"
            )
            
            await sourcing.record_event(
                event,
                compute_state_delta=True,
                old_state=old_state,
                new_state=new_state
            )
        
        # Replay to state before last event
        events = await sourcing.event_store.get_events("session1")
        target_event_id = events[-1].event_id
        
        state = await sourcing.replay_to_state("session1", steps=1)
        
        assert state["counter"] == 2
    
    @pytest.mark.asyncio
    async def test_get_state_at_index(self):
        """Test getting state at specific index"""
        sourcing = EventSourcing()
        
        # Record events
        for i in range(3):
            old_state = {"counter": i}
            new_state = {"counter": i + 1}
            
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1"
            )
            
            await sourcing.record_event(
                event,
                compute_state_delta=True,
                old_state=old_state,
                new_state=new_state
            )
        
        # Get state at index 2
        state = await sourcing.get_state_at("session1", 2)
        
        assert state["counter"] == 2
    
    @pytest.mark.asyncio
    async def test_find_event_index_not_found(self):
        """Test find_event_index when event not found"""
        store = EventStore()
        
        index = await store.find_event_index("session1", "nonexistent-id")
        
        assert index is None
    
    @pytest.mark.asyncio
    async def test_find_event_index_wrong_session(self):
        """Test find_event_index when event in different session"""
        store = EventStore()
        
        event = Event(topic="test", data={}, session_id="session1")
        await store.append(event)
        
        # Try to find in different session
        index = await store.find_event_index("session2", event.event_id)
        
        assert index is None
    
    @pytest.mark.asyncio
    async def test_rewind_with_target_event_id(self):
        """Test rewind with target_event_id"""
        store = EventStore()
        
        # Create events
        events = []
        for i in range(3):
            delta = StateDelta()
            delta.add_change("counter", i, i + 1)
            
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1",
                state_delta=delta
            )
            await store.append(event)
            events.append(event)
        
        # Rewind to before second event
        state = await store.rewind("session1", target_event_id=events[1].event_id)
        
        assert state["counter"] == 1
    
    @pytest.mark.asyncio
    async def test_rewind_event_not_found(self):
        """Test rewind when target event not found"""
        store = EventStore()
        
        with pytest.raises(EventSourcingError, match="Event .* not found"):
            await store.rewind("session1", target_event_id="nonexistent-id")
    
    @pytest.mark.asyncio
    async def test_rewind_no_parameters(self):
        """Test rewind with no parameters"""
        store = EventStore()
        
        with pytest.raises(EventSourcingError, match="Either target_event_id or steps"):
            await store.rewind("session1")
    
    @pytest.mark.asyncio
    async def test_clear_session(self):
        """Test clear_session"""
        store = EventStore()
        
        event = Event(topic="test", data={}, session_id="session1")
        await store.append(event)
        
        assert store.get_event_count("session1") == 1
        
        await store.clear_session("session1")
        
        assert store.get_event_count("session1") == 0
    
    @pytest.mark.asyncio
    async def test_get_event_count(self):
        """Test get_event_count"""
        store = EventStore()
        
        assert store.get_event_count("session1") == 0
        
        for i in range(3):
            event = Event(topic="test", data={}, session_id="session1")
            await store.append(event)
        
        assert store.get_event_count("session1") == 3
    
    @pytest.mark.asyncio
    async def test_get_current_state(self):
        """Test get_current_state"""
        store = EventStore()
        
        # Create events with state deltas
        for i in range(3):
            delta = StateDelta()
            delta.add_change("counter", i, i + 1)
            
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1",
                state_delta=delta
            )
            await store.append(event)
        
        state = await store.get_current_state("session1")
        
        assert state["counter"] == 3
    
    @pytest.mark.asyncio
    async def test_compute_state_delta(self):
        """Test _compute_state_delta"""
        sourcing = EventSourcing()
        
        old_state = {"a": 1, "b": 2, "c": 3}
        new_state = {"a": 1, "b": 20, "d": 4}  # b changed, c removed, d added
        
        delta = sourcing._compute_state_delta(old_state, new_state)
        
        assert "b" in delta.changes
        assert "c" in delta.changes
        assert "d" in delta.changes
        assert "a" not in delta.changes  # Unchanged
    
    @pytest.mark.asyncio
    async def test_record_event_no_delta_params(self):
        """Test record_event when compute_state_delta is True but params missing"""
        sourcing = EventSourcing()
        
        event = Event(topic="test", data={}, session_id="session1")
        
        with pytest.raises(EventSourcingError, match="old_state and new_state are required"):
            await sourcing.record_event(
                event,
                compute_state_delta=True,
                old_state=None,
                new_state=None
            )
    
    @pytest.mark.asyncio
    async def test_get_current_state_via_sourcing(self):
        """Test get_current_state via EventSourcing"""
        sourcing = EventSourcing()
        
        # Record events
        for i in range(2):
            old_state = {"counter": i}
            new_state = {"counter": i + 1}
            
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1"
            )
            
            await sourcing.record_event(
                event,
                compute_state_delta=True,
                old_state=old_state,
                new_state=new_state
            )
        
        state = await sourcing.get_current_state("session1")
        
        assert state["counter"] == 2
    
    @pytest.mark.asyncio
    async def test_replay_to_state_with_target_event_id(self):
        """Test replay_to_state with target_event_id"""
        sourcing = EventSourcing()
        
        # Record events
        events = []
        for i in range(3):
            old_state = {"counter": i}
            new_state = {"counter": i + 1}
            
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1"
            )
            
            await sourcing.record_event(
                event,
                compute_state_delta=True,
                old_state=old_state,
                new_state=new_state
            )
            events.append(event)
        
        # Replay to before second event
        state = await sourcing.replay_to_state("session1", target_event_id=events[1].event_id)
        
        assert state["counter"] == 1
    
    @pytest.mark.asyncio
    async def test_get_events_with_index_range(self):
        """Test get_events with from_index and to_index"""
        store = EventStore()
        
        # Create 5 events
        for i in range(5):
            event = Event(topic="test", data={"index": i}, session_id="session1")
            await store.append(event)
        
        # Get events from index 1 to 3
        events = await store.get_events("session1", from_index=1, to_index=3)
        assert len(events) == 2
        assert events[0].data["index"] == 1
        assert events[1].data["index"] == 2
    
    @pytest.mark.asyncio
    async def test_get_events_with_from_index_only(self):
        """Test get_events with only from_index"""
        store = EventStore()
        
        # Create 5 events
        for i in range(5):
            event = Event(topic="test", data={"index": i}, session_id="session1")
            await store.append(event)
        
        # Get events from index 2 onwards
        events = await store.get_events("session1", from_index=2)
        assert len(events) == 3
        assert events[0].data["index"] == 2
    
    @pytest.mark.asyncio
    async def test_get_events_empty_session(self):
        """Test get_events for empty session"""
        store = EventStore()
        
        events = await store.get_events("nonexistent")
        assert len(events) == 0
    
    @pytest.mark.asyncio
    async def test_replay_with_index_range(self):
        """Test replay with from_index and to_index"""
        store = EventStore()
        
        # Create events with state deltas
        for i in range(5):
            delta = StateDelta()
            delta.add_change("counter", i, i + 1)
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1",
                state_delta=delta
            )
            await store.append(event)
        
        # Replay from index 1 to 3
        state = await store.replay("session1", from_index=1, to_index=3)
        assert state["counter"] == 3  # Applied 2 deltas (from 1 to 3)
    
    @pytest.mark.asyncio
    async def test_replay_with_initial_state(self):
        """Test replay with initial_state"""
        store = EventStore()
        
        # Create events with state deltas
        delta = StateDelta()
        delta.add_change("counter", 0, 1)
        event = Event(
            topic="test",
            data={"action": "increment"},
            session_id="session1",
            state_delta=delta
        )
        await store.append(event)
        
        # Replay with initial state
        initial_state = {"counter": 10, "other": "value"}
        state = await store.replay("session1", initial_state=initial_state)
        assert state["counter"] == 1  # Delta applied
        assert state["other"] == "value"  # Preserved from initial state
    
    @pytest.mark.asyncio
    async def test_replay_async(self):
        """Test replay_async generator"""
        store = EventStore()
        
        # Create events
        events = []
        for i in range(3):
            event = Event(topic="test", data={"index": i}, session_id="session1")
            await store.append(event)
            events.append(event)
        
        # Replay asynchronously
        replayed = []
        async for event in store.replay_async("session1"):
            replayed.append(event)
        
        assert len(replayed) == 3
        assert replayed[0].event_id == events[0].event_id
        assert replayed[1].event_id == events[1].event_id
        assert replayed[2].event_id == events[2].event_id
    
    @pytest.mark.asyncio
    async def test_replay_async_with_index_range(self):
        """Test replay_async with index range"""
        store = EventStore()
        
        # Create events
        for i in range(5):
            event = Event(topic="test", data={"index": i}, session_id="session1")
            await store.append(event)
        
        # Replay from index 1 to 3
        replayed = []
        async for event in store.replay_async("session1", from_index=1, to_index=3):
            replayed.append(event)
        
        assert len(replayed) == 2
        assert replayed[0].data["index"] == 1
        assert replayed[1].data["index"] == 2
    
    @pytest.mark.asyncio
    async def test_append_with_session_id_parameter(self):
        """Test append with session_id parameter (line 75-81)"""
        store = EventStore()
        
        # Event without session_id
        event = Event(topic="test", data={"key": "value"})
        assert event.session_id is None or event.session_id == ""
        
        # Append with session_id parameter
        await store.append(event, session_id="session1")
        
        # Event should have session_id set
        assert event.session_id == "session1"
        
        # Event should be stored
        events = await store.get_events("session1")
        assert len(events) == 1
    
    @pytest.mark.asyncio
    async def test_append_no_session_id_error(self):
        """Test append without session_id raises error"""
        store = EventStore()
        
        # Event without session_id and no parameter
        event = Event(topic="test", data={"key": "value"})
        event.session_id = None
        
        with pytest.raises(EventSourcingError, match="Session ID is required"):
            await store.append(event)
    
    @pytest.mark.asyncio
    async def test_clear_session_nonexistent(self):
        """Test clear_session for nonexistent session (line 280)"""
        store = EventStore()
        
        # Clear nonexistent session should not raise error
        await store.clear_session("nonexistent")
        
        # Should still work
        assert store.get_event_count("nonexistent") == 0
    
    @pytest.mark.asyncio
    async def test_get_event_index_out_of_bounds(self):
        """Test get_event when index is out of bounds (line 140-143)"""
        store = EventStore()
        
        event = Event(topic="test", data={}, session_id="session1")
        await store.append(event)
        
        # Manually corrupt the index to test out-of-bounds handling
        store._event_index[event.event_id] = ("session1", 999)  # Out of bounds
        
        retrieved = await store.get_event(event.event_id)
        assert retrieved is None
    
    @pytest.mark.asyncio
    async def test_rewind_steps_zero(self):
        """Test rewind with steps=0"""
        store = EventStore()
        
        # Create events
        for i in range(3):
            delta = StateDelta()
            delta.add_change("counter", i, i + 1)
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1",
                state_delta=delta
            )
            await store.append(event)
        
        # Rewind 0 steps (should return current state)
        state = await store.rewind("session1", steps=0)
        assert state["counter"] == 3
    
    @pytest.mark.asyncio
    async def test_rewind_steps_more_than_events(self):
        """Test rewind with steps more than total events"""
        store = EventStore()
        
        # Create 2 events
        for i in range(2):
            delta = StateDelta()
            delta.add_change("counter", i, i + 1)
            event = Event(
                topic="test",
                data={"action": "increment"},
                session_id="session1",
                state_delta=delta
            )
            await store.append(event)
        
        # Rewind 10 steps (more than total)
        # target_index = max(0, 2 - 10) = 0
        # replay from 0 to 0 returns empty state
        state = await store.rewind("session1", steps=10)
        assert state == {}  # Should return empty state (no events replayed)

