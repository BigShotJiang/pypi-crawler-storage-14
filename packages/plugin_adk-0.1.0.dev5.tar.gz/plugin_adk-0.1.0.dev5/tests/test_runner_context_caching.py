"""
Unit tests for Runner context caching.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from plugin_adk.core.runner import Runner, RunnerConfig
from plugin_adk.core.ai import AICapabilitiesManager
from plugin_adk.core.communication.event_sourcing import EventStore


@pytest.fixture
def runner_config():
    """Create runner config with context caching enabled"""
    return RunnerConfig(
        session_id="test-session",
        enable_context_caching=True,
        context_cache_ttl=3600,
    )


@pytest.fixture
def runner(runner_config):
    """Create runner"""
    return Runner(config=runner_config)


def test_get_context_cache_key(runner):
    """Test context cache key generation"""
    messages = [
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": "Hello"},
    ]
    
    cache_key = runner._get_context_cache_key(messages)
    
    assert cache_key is not None
    assert isinstance(cache_key, str)
    assert len(cache_key) > 0
    
    # Same messages should generate same key
    cache_key2 = runner._get_context_cache_key(messages)
    assert cache_key == cache_key2
    
    # Different messages should generate different key
    messages2 = [
        {"role": "system", "content": "You are a different assistant"},
        {"role": "user", "content": "Hi"},
    ]
    cache_key3 = runner._get_context_cache_key(messages2)
    assert cache_key != cache_key3


def test_get_context_cache_key_with_tools(runner):
    """Test context cache key generation with tools"""
    messages = [
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": "Hello", "tools": [{"name": "test_tool"}]},
    ]
    
    cache_key = runner._get_context_cache_key(messages)
    
    assert cache_key is not None
    assert isinstance(cache_key, str)


def test_cache_context(runner):
    """Test context caching"""
    cache_key = "test_key"
    context = {"context_id": "test-id", "metadata": {"model": "gpt-3.5-turbo"}}
    
    # Cache context
    runner._cache_context(cache_key, context)
    
    # Retrieve cached context
    cached = runner._get_cached_context(cache_key)
    
    assert cached is not None
    assert cached["context_id"] == "test-id"
    assert cached["metadata"]["model"] == "gpt-3.5-turbo"


def test_get_cached_context_none(runner):
    """Test getting non-existent cached context"""
    cache_key = "non_existent_key"
    
    cached = runner._get_cached_context(cache_key)
    
    assert cached is None


def test_cache_context_ttl(runner):
    """Test context cache TTL"""
    from datetime import datetime, timedelta
    
    cache_key = "test_key"
    context = {"context_id": "test-id"}
    
    # Cache context
    runner._cache_context(cache_key, context)
    
    # Should be available immediately
    cached = runner._get_cached_context(cache_key)
    assert cached is not None
    
    # Simulate TTL expiration by manually setting old timestamp
    runner._context_cache_timestamps[cache_key] = datetime.now() - timedelta(seconds=3700)
    
    # Should be expired
    cached = runner._get_cached_context(cache_key)
    assert cached is None


@pytest.mark.asyncio
async def test_llm_call_with_context_caching(runner):
    """Test LLM call with context caching"""
    # Mock AI manager
    ai_manager = Mock(spec=AICapabilitiesManager)
    ai_manager.complete = AsyncMock(return_value={
        "content": "Hello!",
        "usage": {"prompt_tokens": 10, "completion_tokens": 5},
        "context_id": "cached-context-id",
    })
    runner.ai_manager = ai_manager
    
    messages = [
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": "Hello"},
    ]
    
    # First call
    result1 = await runner._handle_llm_call({
        "messages": messages,
        "model": "gpt-3.5-turbo",
    })
    
    assert "content" in result1
    assert result1["content"] == "Hello!"
    
    # Check if context was cached
    cache_key = runner._get_context_cache_key(messages)
    cached = runner._get_cached_context(cache_key)
    
    # Context should be cached if context_id was returned
    if cached:
        assert cached.get("context_id") == "cached-context-id"


@pytest.mark.asyncio
async def test_llm_call_without_context_caching(runner):
    """Test LLM call without context caching"""
    # Disable context caching
    runner.config.enable_context_caching = False
    
    # Mock AI manager
    ai_manager = Mock(spec=AICapabilitiesManager)
    ai_manager.complete = AsyncMock(return_value={
        "content": "Hello!",
        "usage": {"prompt_tokens": 10, "completion_tokens": 5},
    })
    runner.ai_manager = ai_manager
    
    messages = [
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": "Hello"},
    ]
    
    result = await runner._handle_llm_call({
        "messages": messages,
        "model": "gpt-3.5-turbo",
    })
    
    assert "content" in result
    assert result["content"] == "Hello!"

