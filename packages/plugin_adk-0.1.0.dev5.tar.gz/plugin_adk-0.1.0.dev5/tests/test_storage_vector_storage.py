"""
Unit tests for Vector Storage.
"""

import pytest
from plugin_adk.core.storage.vector_storage import (
    MemoryVectorStorage,
    BaseVectorStorage,
    PgVectorStorage,
)
from plugin_adk.core.storage.interface import StorageConfig, StorageType


class TestMemoryVectorStorage:
    """Tests for MemoryVectorStorage"""
    
    @pytest.mark.asyncio
    async def test_init_with_config(self):
        """Test initialization with config"""
        config = StorageConfig(storage_type=StorageType.VECTOR)
        storage = MemoryVectorStorage(config=config)
        
        assert storage.config == config
        assert storage._connected is False
    
    @pytest.mark.asyncio
    async def test_init_without_config(self):
        """Test initialization without config"""
        storage = MemoryVectorStorage()
        
        assert storage.config is not None
        assert storage.config.storage_type == StorageType.VECTOR
    
    @pytest.mark.asyncio
    async def test_connect_disconnect(self):
        """Test connect and disconnect"""
        storage = MemoryVectorStorage()
        
        result = await storage.connect()
        assert result is True
        assert await storage.is_connected() is True
        
        result = await storage.disconnect()
        assert result is True
        assert await storage.is_connected() is False
    
    @pytest.mark.asyncio
    async def test_get_status(self):
        """Test get_status"""
        storage = MemoryVectorStorage()
        
        status = await storage.get_status()
        assert status["type"] == "vector"
        assert status["connected"] is False
        
        await storage.connect()
        status = await storage.get_status()
        assert status["connected"] is True
    
    @pytest.mark.asyncio
    async def test_create_collection_duplicate(self):
        """Test create_collection with duplicate name"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        result = await storage.create_collection("test_collection", dimension=128)
        assert result is True
        
        result = await storage.create_collection("test_collection", dimension=128)
        assert result is False
    
    @pytest.mark.asyncio
    async def test_create_collection_with_metadata(self):
        """Test create_collection with metadata"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        result = await storage.create_collection(
            "test_collection",
            dimension=128,
            metadata={"description": "Test collection"}
        )
        assert result is True
    
    @pytest.mark.asyncio
    async def test_insert_vector_dimension_mismatch(self):
        """Test insert_vector with dimension mismatch"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        await storage.create_collection("test_collection", dimension=128)
        
        # Wrong dimension
        result = await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.1] * 64,  # Wrong dimension
            id="vec1"
        )
        assert result is None
    
    @pytest.mark.asyncio
    async def test_insert_vector_auto_id(self):
        """Test insert_vector with auto-generated ID"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        await storage.create_collection("test_collection", dimension=128)
        
        # No ID provided
        vec_id = await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.1] * 128
        )
        assert vec_id is not None
        assert vec_id.startswith("vec_")
    
    @pytest.mark.asyncio
    async def test_insert_vector_nonexistent_collection(self):
        """Test insert_vector with nonexistent collection"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        result = await storage.insert_vector(
            collection_name="nonexistent",
            vector=[0.1] * 128,
            id="vec1"
        )
        assert result is None
    
    @pytest.mark.asyncio
    async def test_search_vectors_with_filter(self):
        """Test search_vectors with filter"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        await storage.create_collection("test_collection", dimension=128)
        
        # Insert vectors with different metadata
        await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.1] * 128,
            id="vec1",
            metadata={"label": "A", "category": "test"}
        )
        
        await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.2] * 128,
            id="vec2",
            metadata={"label": "B", "category": "test"}
        )
        
        await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.3] * 128,
            id="vec3",
            metadata={"label": "A", "category": "other"}
        )
        
        # Search with filter
        results = await storage.search_vectors(
            collection_name="test_collection",
            query_vector=[0.15] * 128,
            limit=10,
            filter={"label": "A"}
        )
        
        # Should return vec1 and vec3 (both have label="A")
        assert len(results) == 2
        result_ids = [r["id"] for r in results]
        assert "vec1" in result_ids
        assert "vec3" in result_ids
    
    @pytest.mark.asyncio
    async def test_search_vectors_nonexistent_collection(self):
        """Test search_vectors with nonexistent collection"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        results = await storage.search_vectors(
            collection_name="nonexistent",
            query_vector=[0.1] * 128
        )
        assert results == []
    
    @pytest.mark.asyncio
    async def test_delete_vector(self):
        """Test delete_vector"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        await storage.create_collection("test_collection", dimension=128)
        
        vec_id = await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.1] * 128,
            id="vec1"
        )
        assert vec_id == "vec1"
        
        result = await storage.delete_vector("test_collection", "vec1")
        assert result is True
        
        # Verify deletion
        results = await storage.search_vectors(
            collection_name="test_collection",
            query_vector=[0.1] * 128
        )
        assert len(results) == 0
    
    @pytest.mark.asyncio
    async def test_delete_vector_nonexistent(self):
        """Test delete_vector with nonexistent vector"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        await storage.create_collection("test_collection", dimension=128)
        
        result = await storage.delete_vector("test_collection", "nonexistent")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_delete_vector_nonexistent_collection(self):
        """Test delete_vector with nonexistent collection"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        result = await storage.delete_vector("nonexistent", "vec1")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_cosine_similarity(self):
        """Test _cosine_similarity calculation"""
        storage = MemoryVectorStorage()
        
        # Same vectors should have similarity 1.0
        vec1 = [1.0, 0.0, 0.0]
        vec2 = [1.0, 0.0, 0.0]
        similarity = storage._cosine_similarity(vec1, vec2)
        assert abs(similarity - 1.0) < 0.001
        
        # Orthogonal vectors should have similarity 0.0
        vec1 = [1.0, 0.0]
        vec2 = [0.0, 1.0]
        similarity = storage._cosine_similarity(vec1, vec2)
        assert abs(similarity - 0.0) < 0.001
        
        # Different length vectors should return 0.0
        vec1 = [1.0, 0.0]
        vec2 = [1.0, 0.0, 0.0]
        similarity = storage._cosine_similarity(vec1, vec2)
        assert similarity == 0.0
    
    @pytest.mark.asyncio
    async def test_cosine_similarity_zero_vector(self):
        """Test _cosine_similarity with zero vector"""
        storage = MemoryVectorStorage()
        
        vec1 = [0.0, 0.0, 0.0]
        vec2 = [1.0, 0.0, 0.0]
        similarity = storage._cosine_similarity(vec1, vec2)
        assert similarity == 0.0
    
    @pytest.mark.asyncio
    async def test_matches_filter(self):
        """Test _matches_filter"""
        storage = MemoryVectorStorage()
        
        metadata = {"label": "A", "category": "test", "value": 10}
        
        # Match all
        assert storage._matches_filter(metadata, {"label": "A", "category": "test"}) is True
        
        # Partial match
        assert storage._matches_filter(metadata, {"label": "A"}) is True
        
        # No match
        assert storage._matches_filter(metadata, {"label": "B"}) is False
        
        # Missing key
        assert storage._matches_filter(metadata, {"missing": "value"}) is False
    
    @pytest.mark.asyncio
    async def test_delete_collection_nonexistent(self):
        """Test delete_collection with nonexistent collection"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        result = await storage.delete_collection("nonexistent")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_disconnect_clears_data(self):
        """Test disconnect clears data"""
        storage = MemoryVectorStorage()
        await storage.connect()
        
        await storage.create_collection("test_collection", dimension=128)
        await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.1] * 128,
            id="vec1"
        )
        
        await storage.disconnect()
        
        # Data should be cleared
        await storage.connect()
        collections = await storage.list_collections() if hasattr(storage, 'list_collections') else []
        # After disconnect, collections should be empty
        # We can verify by trying to insert into the collection
        result = await storage.insert_vector(
            collection_name="test_collection",
            vector=[0.1] * 128,
            id="vec1"
        )
        assert result is None  # Collection doesn't exist after disconnect


class TestBaseVectorStorage:
    """Tests for BaseVectorStorage"""
    
    @pytest.mark.asyncio
    async def test_connect_error_handling(self):
        """Test connect error handling"""
        class ErrorStorage(BaseVectorStorage):
            async def _connect_impl(self) -> bool:
                raise Exception("Connection error")
            async def _disconnect_impl(self) -> bool:
                return True
            async def create_collection(self, *args, **kwargs):
                return False
            async def delete_collection(self, *args, **kwargs):
                return False
            async def insert_vector(self, *args, **kwargs):
                return None
            async def search_vectors(self, *args, **kwargs):
                return []
            async def delete_vector(self, *args, **kwargs):
                return False
        
        storage = ErrorStorage(StorageConfig(storage_type=StorageType.VECTOR))
        result = await storage.connect()
        assert result is False
        assert await storage.is_connected() is False
    
    @pytest.mark.asyncio
    async def test_disconnect_error_handling(self):
        """Test disconnect error handling"""
        class ErrorStorage(BaseVectorStorage):
            async def _connect_impl(self) -> bool:
                return True
            async def _disconnect_impl(self) -> bool:
                raise Exception("Disconnection error")
            async def create_collection(self, *args, **kwargs):
                return False
            async def delete_collection(self, *args, **kwargs):
                return False
            async def insert_vector(self, *args, **kwargs):
                return None
            async def search_vectors(self, *args, **kwargs):
                return []
            async def delete_vector(self, *args, **kwargs):
                return False
        
        storage = ErrorStorage(StorageConfig(storage_type=StorageType.VECTOR))
        await storage.connect()
        assert await storage.is_connected() is True
        
        result = await storage.disconnect()
        assert result is False
        # On error, _disconnect_impl raises exception before _connected is set to False
        # So _connected remains True (this is the actual behavior)
        # The method returns False to indicate error, but connection state is not updated
        assert await storage.is_connected() is True


class TestPgVectorStorage:
    """Tests for PgVectorStorage"""
    
    @pytest.mark.asyncio
    async def test_pgvector_storage_placeholder_methods(self):
        """Test PgVectorStorage placeholder methods"""
        config = StorageConfig(
            storage_type=StorageType.VECTOR,
            host="localhost",
            port=5432,
            database="test"
        )
        storage = PgVectorStorage(config)
        
        await storage.connect()
        
        # Placeholder methods should return expected values
        result = await storage.create_collection("test", dimension=128)
        assert result is False  # Not implemented
        
        result = await storage.insert_vector("test", [0.1] * 128)
        assert result is None  # Not implemented
        
        results = await storage.search_vectors("test", [0.1] * 128)
        assert results == []  # Not implemented
        
        result = await storage.delete_vector("test", "vec1")
        assert result is False  # Not implemented

