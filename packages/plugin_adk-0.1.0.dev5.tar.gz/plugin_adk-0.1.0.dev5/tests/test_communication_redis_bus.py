"""
Unit tests for RedisEventBus.
"""

import pytest
import asyncio
import json
from unittest.mock import Mock, AsyncMock, patch, MagicMock

from plugin_adk.core.communication.redis_bus import RedisEventBus
from plugin_adk.core.models.events import Event, EventType
from plugin_adk.core.coordination.redis.pool import RedisPoolConfig


class MockRedisClient:
    """Mock Redis client for testing"""
    def __init__(self):
        self.pubsub_mock = AsyncMock()
        self.ping_called = False
        
    async def ping(self):
        self.ping_called = True
        return True
        
    async def publish(self, topic, message):
        return 1
        
    def pubsub(self):
        return self.pubsub_mock


class MockRedisPool:
    """Mock Redis pool for testing"""
    def __init__(self):
        self._started = False
        self._client = MockRedisClient()
        self.connection_kwargs = {}
        
    async def start(self):
        self._started = True
        
    async def stop(self):
        self._started = False
        
    def get_client(self):
        return self._client
        
    @property
    def redis_client(self):
        return self._client


@pytest.fixture
def mock_redis_pool():
    """Create a mock Redis pool"""
    return MockRedisPool()


@pytest.fixture
def redis_config():
    """Create a Redis config"""
    return RedisPoolConfig(
        host='localhost',
        port=6379,
        db=0
    )


@pytest.mark.asyncio
async def test_redis_event_bus_init(redis_config):
    """Test RedisEventBus initialization"""
    bus = RedisEventBus(redis_config)
    
    assert bus.config == redis_config
    assert bus.pool is None
    assert bus.publisher_client is None
    assert bus._is_connected is False
    assert bus._started is False


@pytest.mark.asyncio
async def test_redis_event_bus_init_default_config():
    """Test RedisEventBus initialization with default config"""
    with patch('plugin_adk.core.communication.redis_bus.RedisPoolConfig') as mock_config_class:
        mock_config = Mock()
        mock_config_class.from_env.return_value = mock_config
        
        bus = RedisEventBus()
        
        assert bus.config == mock_config


@pytest.mark.asyncio
async def test_redis_event_bus_start(mock_redis_pool, redis_config):
    """Test RedisEventBus start"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        assert bus._started is True
        assert bus._is_connected is True
        assert bus.publisher_client is not None
        assert mock_redis_pool._started is True
        
        # Cleanup
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_start_idempotent(mock_redis_pool, redis_config):
    """Test that start() can be called multiple times safely"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        await bus.start()  # Should not raise
        
        assert bus._started is True
        
        # Cleanup
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_start_failure(mock_redis_pool, redis_config):
    """Test RedisEventBus start failure"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_pool = Mock()
        mock_pool.start = AsyncMock(side_effect=Exception("Connection error"))
        mock_manager_instance.create_pool.return_value = mock_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        
        with pytest.raises(Exception, match="Connection error"):
            await bus.start()
        
        assert bus._started is False
        assert bus._is_connected is False
        assert bus.pool is None
        assert bus.publisher_client is None


@pytest.mark.asyncio
async def test_redis_event_bus_stop(mock_redis_pool, redis_config):
    """Test RedisEventBus stop"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        await bus.stop()
        
        assert bus._started is False
        assert bus._is_connected is False


@pytest.mark.asyncio
async def test_redis_event_bus_stop_not_started(redis_config):
    """Test stop() when not started"""
    bus = RedisEventBus(redis_config)
    
    # Should not raise
    await bus.stop()
    assert bus._started is False


@pytest.mark.asyncio
async def test_redis_event_bus_stop_with_subscriptions(mock_redis_pool, redis_config):
    """Test stop() with active subscriptions"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        # Create a mock subscription task
        mock_task = asyncio.create_task(asyncio.sleep(100))
        bus._subscription_tasks["test.topic"] = mock_task
        
        await bus.stop()
        
        assert mock_task.cancelled()
        assert len(bus._subscription_tasks) == 0


@pytest.mark.asyncio
async def test_redis_event_bus_is_connected(mock_redis_pool, redis_config):
    """Test is_connected property"""
    bus = RedisEventBus(redis_config)
    assert bus.is_connected is False
    
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        await bus.start()
        assert bus.is_connected is True
        
        await bus.stop()
        assert bus.is_connected is False


@pytest.mark.asyncio
async def test_redis_event_bus_publish(mock_redis_pool, redis_config):
    """Test publish event"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        event = Event(
            topic="test.topic",
            event_type=EventType.MESSAGE,
            data={"key": "value"}
        )
        
        await bus.publish("test.topic", event)
        
        # Verify publish was called
        assert mock_redis_pool._client.ping_called
        
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_publish_not_connected(redis_config):
    """Test publish when not connected"""
    bus = RedisEventBus(redis_config)
    
    event = Event(
        topic="test.topic",
        event_type=EventType.MESSAGE,
        data={"key": "value"}
    )
    
    with pytest.raises(ConnectionError, match="RedisEventBus not connected"):
        await bus.publish("test.topic", event)


@pytest.mark.asyncio
async def test_redis_event_bus_publish_error(mock_redis_pool, redis_config):
    """Test publish error handling"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        # Mock publish to raise error
        async def failing_publish(topic, message):
            raise Exception("Publish error")
        
        bus.publisher_client.publish = failing_publish
        
        event = Event(
            topic="test.topic",
            event_type=EventType.MESSAGE,
            data={"key": "value"}
        )
        
        with pytest.raises(Exception, match="Publish error"):
            await bus.publish("test.topic", event)
        
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_subscribe(mock_redis_pool, redis_config):
    """Test subscribe to topic"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        # Mock pubsub
        mock_pubsub = AsyncMock()
        mock_pubsub.subscribe = AsyncMock()
        mock_pubsub.get_message = AsyncMock(return_value=None)
        mock_pubsub.close = AsyncMock()
        mock_redis_pool._client.pubsub_mock = mock_pubsub
        
        callback_called = []
        async def callback(event):
            callback_called.append(event)
        
        task = await bus.subscribe("test.topic", callback)
        
        assert task is not None
        assert "test.topic" in bus._subscription_tasks
        
        # Cancel task
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_subscribe_not_connected(redis_config):
    """Test subscribe when not connected"""
    bus = RedisEventBus(redis_config)
    
    async def callback(event):
        pass
    
    with pytest.raises(ConnectionError, match="RedisEventBus not connected"):
        await bus.subscribe("test.topic", callback)


@pytest.mark.asyncio
async def test_redis_event_bus_subscribe_already_subscribed(mock_redis_pool, redis_config):
    """Test subscribe when already subscribed"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        # Mock pubsub
        mock_pubsub = AsyncMock()
        mock_pubsub.subscribe = AsyncMock()
        mock_pubsub.get_message = AsyncMock(return_value=None)
        mock_pubsub.close = AsyncMock()
        mock_redis_pool._client.pubsub_mock = mock_pubsub
        
        async def callback(event):
            pass
        
        task1 = await bus.subscribe("test.topic", callback)
        
        # Subscribe again (should unsubscribe first)
        task2 = await bus.subscribe("test.topic", callback)
        
        # First task should be cancelled
        assert task1.cancelled() or task1.done()
        
        # Cancel second task
        task2.cancel()
        try:
            await task2
        except asyncio.CancelledError:
            pass
        
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_unsubscribe(mock_redis_pool, redis_config):
    """Test unsubscribe from topic"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        # Mock pubsub
        mock_pubsub = AsyncMock()
        mock_pubsub.subscribe = AsyncMock()
        mock_pubsub.get_message = AsyncMock(return_value=None)
        mock_pubsub.close = AsyncMock()
        mock_redis_pool._client.pubsub_mock = mock_pubsub
        
        async def callback(event):
            pass
        
        task = await bus.subscribe("test.topic", callback)
        
        await bus.unsubscribe("test.topic")
        
        assert task.cancelled()
        assert "test.topic" not in bus._subscription_tasks
        
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_unsubscribe_not_subscribed(mock_redis_pool, redis_config):
    """Test unsubscribe when not subscribed"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        # Should not raise, just log warning
        await bus.unsubscribe("nonexistent.topic")
        
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_await_if_needed(redis_config):
    """Test _await_if_needed helper"""
    bus = RedisEventBus(redis_config)
    
    # Test with coroutine
    async def coro():
        return "result"
    
    result = await bus._await_if_needed(coro())
    assert result == "result"
    
    # Test with regular value
    result = await bus._await_if_needed("direct_value")
    assert result == "direct_value"


@pytest.mark.asyncio
async def test_redis_event_bus_subscription_message_handling(mock_redis_pool, redis_config):
    """Test subscription message handling"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        # Mock pubsub with message
        received_events = []
        async def callback(event):
            received_events.append(event)
        
        mock_pubsub = AsyncMock()
        mock_pubsub.subscribe = AsyncMock()
        
        # Create a test event
        test_event = Event(
            topic="test.topic",
            event_type=EventType.MESSAGE,
            data={"key": "value"}
        )
        
        # Mock get_message to return the event once, then None
        call_count = 0
        async def mock_get_message(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return {'data': test_event.model_dump_json()}
            return None
        
        mock_pubsub.get_message = AsyncMock(side_effect=mock_get_message)
        mock_pubsub.close = AsyncMock()
        mock_redis_pool._client.pubsub_mock = mock_pubsub
        
        task = await bus.subscribe("test.topic", callback)
        
        # Wait a bit for message processing
        await asyncio.sleep(0.1)
        
        # Cancel task
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        
        await bus.stop()


@pytest.mark.asyncio
async def test_redis_event_bus_subscription_validation_error(mock_redis_pool, redis_config):
    """Test subscription handles validation errors"""
    with patch('plugin_adk.core.communication.redis_bus.get_redis_manager') as mock_manager:
        mock_manager_instance = Mock()
        mock_manager_instance.create_pool.return_value = mock_redis_pool
        mock_manager.return_value = mock_manager_instance
        
        bus = RedisEventBus(redis_config)
        await bus.start()
        
        callback_called = []
        async def callback(event):
            callback_called.append(event)
        
        mock_pubsub = AsyncMock()
        mock_pubsub.subscribe = AsyncMock()
        
        # Mock get_message to return invalid JSON
        async def mock_get_message(*args, **kwargs):
            return {'data': b'invalid json'}
        
        mock_pubsub.get_message = AsyncMock(side_effect=mock_get_message)
        mock_pubsub.close = AsyncMock()
        mock_redis_pool._client.pubsub_mock = mock_pubsub
        
        task = await bus.subscribe("test.topic", callback)
        
        # Wait a bit
        await asyncio.sleep(0.1)
        
        # Cancel task
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        
        # Callback should not be called due to validation error
        assert len(callback_called) == 0
        
        await bus.stop()

