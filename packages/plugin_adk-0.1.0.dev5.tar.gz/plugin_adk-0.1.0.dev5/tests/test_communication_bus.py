"""
Tests for event bus.
"""

import pytest
import asyncio
from plugin_adk.core.communication import MemoryEventBus, EventBusError
from plugin_adk.core.models.events import Event, EventType


class TestMemoryEventBus:
    """Tests for MemoryEventBus"""
    
    @pytest.mark.asyncio
    async def test_bus_start_stop(self):
        """Test bus start and stop"""
        bus = MemoryEventBus()
        
        assert not bus.is_running
        
        await bus.start()
        assert bus.is_running
        
        await bus.stop()
        assert not bus.is_running
    
    @pytest.mark.asyncio
    async def test_publish_subscribe(self):
        """Test publish and subscribe"""
        bus = MemoryEventBus()
        await bus.start()
        
        received_events = []
        event_received = asyncio.Event()
        
        async def handler(event: Event):
            received_events.append(event)
            event_received.set()
        
        await bus.subscribe("test.topic", handler)
        
        event = Event(topic="test.topic", data={"key": "value"})
        await bus.publish(event)
        
        # Wait for event processing with timeout
        try:
            await asyncio.wait_for(event_received.wait(), timeout=0.1)
        except asyncio.TimeoutError:
            pass
        
        assert len(received_events) == 1
        assert received_events[0].data == {"key": "value"}
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_wildcard_subscription(self):
        """Test wildcard subscription"""
        bus = MemoryEventBus()
        await bus.start()
        
        received_events = []
        events_received = asyncio.Event()
        
        async def handler(event: Event):
            received_events.append(event)
            if len(received_events) >= 2:
                events_received.set()
        
        await bus.subscribe("test.*", handler)
        
        event1 = Event(topic="test.hello", data={"msg": "hello"})
        event2 = Event(topic="test.world", data={"msg": "world"})
        event3 = Event(topic="other.topic", data={"msg": "other"})
        
        await bus.publish(event1)
        await bus.publish(event2)
        await bus.publish(event3)
        
        # Wait for event processing with timeout
        try:
            await asyncio.wait_for(events_received.wait(), timeout=0.1)
        except asyncio.TimeoutError:
            pass
        
        assert len(received_events) == 2
        assert received_events[0].topic == "test.hello"
        assert received_events[1].topic == "test.world"
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_multiple_handlers(self):
        """Test multiple handlers for same topic"""
        bus = MemoryEventBus()
        await bus.start()
        
        handler1_calls = []
        handler2_calls = []
        all_handlers_done = asyncio.Event()
        
        async def handler1(event: Event):
            handler1_calls.append(event)
            if len(handler1_calls) == 1 and len(handler2_calls) == 1:
                all_handlers_done.set()
        
        async def handler2(event: Event):
            handler2_calls.append(event)
            if len(handler1_calls) == 1 and len(handler2_calls) == 1:
                all_handlers_done.set()
        
        await bus.subscribe("test.topic", handler1)
        await bus.subscribe("test.topic", handler2)
        
        event = Event(topic="test.topic", data={"key": "value"})
        await bus.publish(event)
        
        # Wait for event processing with timeout
        try:
            await asyncio.wait_for(all_handlers_done.wait(), timeout=0.1)
        except asyncio.TimeoutError:
            pass
        
        assert len(handler1_calls) == 1
        assert len(handler2_calls) == 1
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_unsubscribe(self):
        """Test unsubscribe"""
        bus = MemoryEventBus()
        await bus.start()
        
        received_events = []
        first_event_received = asyncio.Event()
        
        async def handler(event: Event):
            received_events.append(event)
            if len(received_events) == 1:
                first_event_received.set()
        
        await bus.subscribe("test.topic", handler)
        
        event = Event(topic="test.topic", data={"key": "value"})
        await bus.publish(event)
        
        try:
            await asyncio.wait_for(first_event_received.wait(), timeout=0.1)
        except asyncio.TimeoutError:
            pass
        assert len(received_events) == 1
        
        await bus.unsubscribe("test.topic", handler)
        
        # Give a small delay to ensure unsubscribe is processed
        await asyncio.sleep(0.01)
        
        event2 = Event(topic="test.topic", data={"key": "value2"})
        await bus.publish(event2)
        
        # Wait a bit to ensure no new event is received
        await asyncio.sleep(0.01)
        assert len(received_events) == 1  # Should not receive new event
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_publish_when_stopped(self):
        """Test publish when bus is stopped"""
        bus = MemoryEventBus()
        
        event = Event(topic="test.topic", data={"key": "value"})
        
        with pytest.raises(EventBusError):
            await bus.publish(event)
    
    @pytest.mark.asyncio
    async def test_handler_error_handling(self):
        """Test handler error handling"""
        bus = MemoryEventBus()
        await bus.start()
        
        received_events = []
        good_handler_done = asyncio.Event()
        
        async def error_handler(event: Event):
            raise ValueError("Handler error")
        
        async def good_handler(event: Event):
            received_events.append(event)
            good_handler_done.set()
        
        await bus.subscribe("test.topic", error_handler)
        await bus.subscribe("test.topic", good_handler)
        
        event = Event(topic="test.topic", data={"key": "value"})
        await bus.publish(event)
        
        # Wait for event processing with timeout
        try:
            await asyncio.wait_for(good_handler_done.wait(), timeout=0.1)
        except asyncio.TimeoutError:
            pass
        
        # Good handler should still receive event
        assert len(received_events) == 1
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_match_topic_exact_match(self):
        """Test _match_topic with exact match"""
        bus = MemoryEventBus()
        assert bus._match_topic("test.topic", "test.topic") is True
        assert bus._match_topic("test.topic", "test.other") is False
    
    @pytest.mark.asyncio
    async def test_match_topic_wildcard_single(self):
        """Test _match_topic with single wildcard"""
        bus = MemoryEventBus()
        assert bus._match_topic("test.*", "test.hello") is True
        assert bus._match_topic("test.*", "test.world") is True
        assert bus._match_topic("test.*", "test.hello.world") is False  # Different length
        assert bus._match_topic("*.topic", "test.topic") is True
        assert bus._match_topic("test.*", "other.hello") is False
    
    @pytest.mark.asyncio
    async def test_match_topic_wildcard_double(self):
        """Test _match_topic with double wildcard (**)"""
        bus = MemoryEventBus()
        assert bus._match_topic("test.**", "test.hello") is True
        assert bus._match_topic("test.**", "test.hello.world") is True
        assert bus._match_topic("test.**", "test.hello.world.deep") is True
        assert bus._match_topic("test.**", "other.hello") is False
    
    @pytest.mark.asyncio
    async def test_match_topic_wildcard_double_prefix(self):
        """Test _match_topic with ** matching prefix"""
        bus = MemoryEventBus()
        # Pattern with ** should match prefix
        assert bus._match_topic("test.**.end", "test.hello.end") is True
        assert bus._match_topic("test.**", "test.hello.world.deep") is True
    
    @pytest.mark.asyncio
    async def test_match_topic_wildcard_mixed(self):
        """Test _match_topic with mixed wildcards"""
        bus = MemoryEventBus()
        assert bus._match_topic("test.*.world", "test.hello.world") is True
        assert bus._match_topic("test.*.world", "test.other.world") is True
        assert bus._match_topic("test.*.world", "test.hello.other") is False
    
    @pytest.mark.asyncio
    async def test_get_matching_subscribers_direct(self):
        """Test _get_matching_subscribers with direct match"""
        bus = MemoryEventBus()
        
        async def handler1(event):
            pass
        
        async def handler2(event):
            pass
        
        bus._subscribers["test.topic"] = [handler1, handler2]
        
        handlers = bus._get_matching_subscribers("test.topic")
        assert len(handlers) == 2
        assert handler1 in handlers
        assert handler2 in handlers
    
    @pytest.mark.asyncio
    async def test_get_matching_subscribers_pattern(self):
        """Test _get_matching_subscribers with pattern match"""
        bus = MemoryEventBus()
        
        async def handler1(event):
            pass
        
        async def handler2(event):
            pass
        
        # Direct subscriber
        bus._subscribers["test.hello"] = [handler1]
        # Pattern subscriber
        bus._subscribers["test.*"] = [handler2]
        
        handlers = bus._get_matching_subscribers("test.hello")
        assert len(handlers) == 2
        assert handler1 in handlers
        assert handler2 in handlers
    
    @pytest.mark.asyncio
    async def test_get_matching_subscribers_no_match(self):
        """Test _get_matching_subscribers with no match"""
        bus = MemoryEventBus()
        
        async def handler(event):
            pass
        
        bus._subscribers["other.topic"] = [handler]
        
        handlers = bus._get_matching_subscribers("test.topic")
        assert len(handlers) == 0
    
    @pytest.mark.asyncio
    async def test_event_bus_error(self):
        """Test EventBusError initialization"""
        from plugin_adk.core.communication import EventBusError
        from plugin_adk.core.models.exceptions import ErrorCategory
        
        error = EventBusError("Test error", solution="Test solution")
        assert error.message == "Test error"
        assert error.category == ErrorCategory.INTERNAL
        assert error.solution == "Test solution"
    
    @pytest.mark.asyncio
    async def test_start_already_running(self):
        """Test start when already running (line 54)"""
        bus = MemoryEventBus()
        await bus.start()
        assert bus._is_running
        
        # Start again should be idempotent
        await bus.start()
        assert bus._is_running
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_stop_not_running(self):
        """Test stop when not running (line 63)"""
        bus = MemoryEventBus()
        assert not bus._is_running
        
        # Stop when not running should be safe
        await bus.stop()
        assert not bus._is_running
    
    @pytest.mark.asyncio
    async def test_stop_clears_queue(self):
        """Test stop clears queue (line 77-80)"""
        bus = MemoryEventBus()
        await bus.start()
        
        # Add events to queue
        event1 = Event(topic="test.topic", data={"key": "value1"})
        event2 = Event(topic="test.topic", data={"key": "value2"})
        await bus._event_queue.put(event1)
        await bus._event_queue.put(event2)
        
        # Stop should clear queue
        await bus.stop()
        
        # Queue should be empty
        assert bus._event_queue.empty()
    
    @pytest.mark.asyncio
    async def test_unsubscribe_topic_not_found(self):
        """Test unsubscribe when topic not found (line 128)"""
        bus = MemoryEventBus()
        await bus.start()
        
        # Unsubscribe from non-existent topic should be safe
        await bus.unsubscribe("nonexistent.topic")
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_unsubscribe_all_handlers(self):
        """Test unsubscribe all handlers for topic (line 132-133)"""
        bus = MemoryEventBus()
        await bus.start()
        
        async def handler1(event):
            pass
        
        async def handler2(event):
            pass
        
        await bus.subscribe("test.topic", handler1)
        await bus.subscribe("test.topic", handler2)
        
        # Unsubscribe all handlers
        await bus.unsubscribe("test.topic")
        
        # Topic should be removed
        assert "test.topic" not in bus._subscribers
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_process_events_timeout(self):
        """Test _process_events timeout handling (line 151)"""
        bus = MemoryEventBus()
        await bus.start()
        
        # Wait a bit to let timeout occur
        await asyncio.sleep(0.15)
        
        # Bus should still be running
        assert bus._is_running
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_process_events_cancelled_error(self):
        """Test _process_events handles CancelledError (line 171-172)"""
        bus = MemoryEventBus()
        await bus.start()
        
        # Cancel the processing task
        if bus._processing_task:
            bus._processing_task.cancel()
            try:
                await bus._processing_task
            except asyncio.CancelledError:
                pass
        
        # Task should be cancelled
        assert bus._processing_task.cancelled() or bus._processing_task.done()
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_process_events_exception_handling(self):
        """Test _process_events exception handling (line 173-174)"""
        bus = MemoryEventBus()
        await bus.start()
        
        # Create a handler that raises an exception
        async def error_handler(event):
            raise Exception("Test error")
        
        await bus.subscribe("test.topic", error_handler)
        
        # Publish event that will cause exception
        event = Event(topic="test.topic", data={"key": "value"})
        await bus.publish(event)
        
        # Wait for processing
        await asyncio.sleep(0.05)
        
        # Exception should be caught and logged, bus should still be running
        assert bus._is_running
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_unsubscribe_handler_not_in_list(self):
        """Test unsubscribe when handler not in subscribers list (line 136-140)"""
        bus = MemoryEventBus()
        await bus.start()
        
        async def handler1(event):
            pass
        
        async def handler2(event):
            pass
        
        # Subscribe handler1 only
        await bus.subscribe("test.topic", handler1)
        
        # Try to unsubscribe handler2 (not subscribed)
        await bus.unsubscribe("test.topic", handler2)
        
        # handler1 should still be subscribed
        assert "test.topic" in bus._subscribers
        assert handler1 in bus._subscribers["test.topic"]
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_unsubscribe_specific_handler_removes_topic_when_empty(self):
        """Test unsubscribe specific handler removes topic when list becomes empty (line 138-139)"""
        bus = MemoryEventBus()
        await bus.start()
        
        async def handler(event):
            pass
        
        await bus.subscribe("test.topic", handler)
        
        # Unsubscribe the only handler
        await bus.unsubscribe("test.topic", handler)
        
        # Topic should be removed when list becomes empty
        assert "test.topic" not in bus._subscribers
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_stop_with_no_processing_task(self):
        """Test stop when _processing_task is None (line 68)"""
        bus = MemoryEventBus()
        # Don't start, so _processing_task is None
        assert bus._processing_task is None
        
        # Stop should be safe even without task
        await bus.stop()
        assert not bus._is_running

