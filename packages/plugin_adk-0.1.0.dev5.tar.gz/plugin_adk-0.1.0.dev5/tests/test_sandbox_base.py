"""
Tests for BaseSandbox.
"""

import pytest
from plugin_adk.core.sandbox.base import (
    BaseSandbox,
    SandboxResult,
    SandboxStatus,
    SandboxError,
)
from plugin_adk.core.models.plugins import SandboxConfig, SandboxLevel


class MockSandbox(BaseSandbox):
    """Test sandbox implementation"""
    
    async def execute(self, code: str, timeout=None, **kwargs):
        # Simple test implementation
        return SandboxResult(
            status=SandboxStatus.COMPLETED,
            result=f"Executed: {code}",
            execution_time=0.1,
        )
    
    async def execute_with_context(self, code: str, context: dict, timeout=None, **kwargs):
        return SandboxResult(
            status=SandboxStatus.COMPLETED,
            result=f"Executed with context: {code}",
            execution_time=0.1,
        )


class TestBaseSandbox:
    """Tests for BaseSandbox"""
    
    def test_sandbox_creation(self):
        """Test sandbox creation"""
        config = SandboxConfig(level=SandboxLevel.STRICT)
        sandbox = MockSandbox(config=config)
        
        assert sandbox.config.level == SandboxLevel.STRICT
    
    @pytest.mark.asyncio
    async def test_validate_code(self):
        """Test code validation"""
        sandbox = MockSandbox()
        
        # Valid code
        is_valid, error = await sandbox.validate_code("x = 1 + 1")
        assert is_valid is True
        
        # Invalid code (empty)
        is_valid, error = await sandbox.validate_code("")
        assert is_valid is False
        
        # Invalid code (dangerous)
        is_valid, error = await sandbox.validate_code("import os; os.system('rm -rf /')")
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_execute(self):
        """Test code execution"""
        sandbox = MockSandbox()
        
        result = await sandbox.execute("test code")
        
        assert result.is_success()
        assert result.status == SandboxStatus.COMPLETED
        assert "Executed: test code" in str(result.result)
    
    @pytest.mark.asyncio
    async def test_execute_with_context(self):
        """Test code execution with context"""
        sandbox = MockSandbox()
        
        result = await sandbox.execute_with_context(
            "print(x)",
            context={"x": 42}
        )
        
        assert result.is_success()
        assert result.status == SandboxStatus.COMPLETED
    
    def test_get_resource_limits(self):
        """Test resource limits"""
        config = SandboxConfig(
            memory_limit_mb=1024.0,
            cpu_limit_percent=75.0,
            timeout_seconds=30.0
        )
        sandbox = MockSandbox(config=config)
        
        limits = sandbox.get_resource_limits()
        
        assert limits["memory_limit_mb"] == 1024.0
        assert limits["cpu_limit_percent"] == 75.0
        assert limits["timeout_seconds"] == 30.0
    
    @pytest.mark.asyncio
    async def test_validate_code_with_allowed_imports(self):
        """Test code validation with allowed imports"""
        config = SandboxConfig(
            allowed_imports={'json', 'math', 'datetime'}
        )
        sandbox = MockSandbox(config=config)
        
        # Allowed import
        is_valid, error = await sandbox.validate_code("import json")
        assert is_valid is True
        
        # Disallowed import
        is_valid, error = await sandbox.validate_code("import os")
        assert is_valid is False
        assert "Dangerous operation" in error or "not in allowed" in error
    
    @pytest.mark.asyncio
    async def test_validate_code_with_denied_imports(self):
        """Test code validation with denied imports"""
        config = SandboxConfig(
            denied_imports={'os', 'sys', 'subprocess'}
        )
        sandbox = MockSandbox(config=config)
        
        # Denied import
        is_valid, error = await sandbox.validate_code("import os")
        assert is_valid is False
        assert "denied" in error.lower() or "dangerous" in error.lower()
    
    @pytest.mark.asyncio
    async def test_validate_code_dangerous_operations(self):
        """Test code validation for dangerous operations"""
        sandbox = MockSandbox()
        
        # Test eval
        is_valid, error = await sandbox.validate_code("result = eval('1+1')")
        assert is_valid is False
        assert "dangerous" in error.lower()
        
        # Test exec
        is_valid, error = await sandbox.validate_code("exec('print(1)')")
        assert is_valid is False
        assert "dangerous" in error.lower()
        
        # Test compile
        is_valid, error = await sandbox.validate_code("compile('1+1', '<string>', 'eval')")
        assert is_valid is False
        assert "dangerous" in error.lower()


class TestSandboxResult:
    """Tests for SandboxResult"""
    
    def test_sandbox_result_creation(self):
        """Test SandboxResult creation"""
        result = SandboxResult(
            status=SandboxStatus.COMPLETED,
            result="test result",
            execution_time=1.5,
            memory_used_mb=128.0
        )
        
        assert result.is_success()
        assert result.result == "test result"
        assert result.execution_time == 1.5
        assert result.memory_used_mb == 128.0
    
    def test_sandbox_result_failed(self):
        """Test failed SandboxResult"""
        result = SandboxResult(
            status=SandboxStatus.FAILED,
            error="Test error",
            execution_time=0.5
        )
        
        assert result.is_failed()
        assert not result.is_success()
        assert result.error == "Test error"
    
    def test_sandbox_result_to_dict(self):
        """Test SandboxResult serialization"""
        result = SandboxResult(
            status=SandboxStatus.COMPLETED,
            result="test",
            execution_time=1.0
        )
        
        result_dict = result.to_dict()
        
        assert result_dict["status"] == "completed"
        assert result_dict["result"] == "test"
        assert result_dict["execution_time"] == 1.0
        assert "timestamp" in result_dict

