"""
Tests for logging utilities.
"""

import pytest
import logging
import os
import asyncio
from unittest.mock import Mock, patch, MagicMock
from plugin_adk.core.utils.logging_utils import (
    setup_logger,
    get_logger,
    log_performance,
    log_error,
    log_info,
    log_function_call
)

class TestLoggingUtils:
    
    def test_setup_logger_basic(self):
        """Test basic logger setup"""
        logger = setup_logger("test_basic")
        assert logger.name == "test_basic"
        assert logger.level == logging.INFO
        assert len(logger.handlers) > 0
        assert isinstance(logger.handlers[0], logging.StreamHandler)

    def test_setup_logger_with_file(self, tmp_path):
        """Test logger setup with file"""
        log_file = tmp_path / "test.log"
        logger = setup_logger("test_file", file_path=str(log_file))
        
        assert len(logger.handlers) >= 2
        # Find file handler
        file_handler = next((h for h in logger.handlers if isinstance(h, logging.FileHandler)), None)
        assert file_handler is not None
        
        logger.info("Test message")
        
        # Close handlers to flush
        for handler in logger.handlers:
            handler.close()
            
        # Verify file content
        with open(log_file, "r", encoding="utf-8") as f:
            content = f.read()
            assert "Test message" in content

    def test_setup_logger_existing(self):
        """Test setup returns existing logger if handlers exist"""
        logger1 = setup_logger("test_existing")
        logger2 = setup_logger("test_existing")
        assert logger1 is logger2
        
    def test_get_logger(self):
        """Test get_logger"""
        logger = get_logger("test_get")
        assert isinstance(logger, logging.Logger)
        assert logger.name == "test_get"

    def test_log_performance_sync(self):
        """Test log_performance with sync function"""
        mock_logger = Mock()
        
        @log_performance(logger=mock_logger)
        def sync_func(x):
            return x * 2
            
        result = sync_func(10)
        assert result == 20
        assert mock_logger.log.called
        assert "sync_func 执行时间" in mock_logger.log.call_args[0][1]

    def test_log_performance_sync_error(self):
        """Test log_performance with sync function error"""
        mock_logger = Mock()
        
        @log_performance(logger=mock_logger)
        def sync_fail():
            raise ValueError("Fail")
            
        with pytest.raises(ValueError):
            sync_fail()
            
        assert mock_logger.log.called
        assert "sync_fail 执行失败" in mock_logger.log.call_args[0][1]

    @pytest.mark.asyncio
    async def test_log_performance_async(self):
        """Test log_performance with async function"""
        mock_logger = Mock()
        
        @log_performance(logger=mock_logger)
        async def async_func(x):
            await asyncio.sleep(0.01)
            return x * 2
            
        result = await async_func(10)
        assert result == 20
        assert mock_logger.log.called
        assert "async_func 执行时间" in mock_logger.log.call_args[0][1]

    @pytest.mark.asyncio
    async def test_log_performance_async_error(self):
        """Test log_performance with async function error"""
        mock_logger = Mock()
        
        @log_performance(logger=mock_logger)
        async def async_fail():
            await asyncio.sleep(0.01)
            raise ValueError("Fail")
            
        with pytest.raises(ValueError):
            await async_fail()
            
        assert mock_logger.log.called
        assert "async_fail 执行失败" in mock_logger.log.call_args[0][1]

    def test_log_error(self):
        """Test log_error decorator"""
        mock_logger = Mock()
        
        @log_error(logger=mock_logger, message="Custom Error")
        def fail_func():
            raise ValueError("Original Error")
            
        with pytest.raises(ValueError):
            fail_func()
            
        mock_logger.error.assert_called_with("Custom Error", exc_info=True)

    def test_log_error_default_message(self):
        """Test log_error with default message"""
        mock_logger = Mock()
        
        @log_error(logger=mock_logger)
        def fail_func_default():
            raise ValueError("Original Error")
            
        with pytest.raises(ValueError):
            fail_func_default()
            
        mock_logger.error.assert_called()
        assert "fail_func_default 执行失败" in mock_logger.error.call_args[0][0]

    def test_log_info(self):
        """Test log_info decorator"""
        mock_logger = Mock()
        
        @log_info(logger=mock_logger, message="Custom Info")
        def info_func():
            return "ok"
            
        info_func()
        mock_logger.info.assert_called_with("Custom Info")

    def test_log_info_default_message(self):
        """Test log_info with default message"""
        mock_logger = Mock()
        
        @log_info(logger=mock_logger)
        def info_func_default():
            return "ok"
            
        info_func_default()
        mock_logger.info.assert_called()
        assert "info_func_default 执行" in mock_logger.info.call_args[0][0]

    def test_log_function_call(self):
        """Test log_function_call decorator"""
        mock_logger = Mock()
        
        @log_function_call(logger=mock_logger, log_args=True, log_result=True)
        def call_func(a, b=1):
            return a + b
            
        call_func(1, b=2)
        
        assert mock_logger.debug.call_count == 2
        # First call logs args
        args_log = mock_logger.debug.call_args_list[0][0][0]
        assert "调用 call_func" in args_log
        assert "args=(1,)" in args_log
        assert "kwargs={'b': 2}" in args_log
        
        # Second call logs result
        result_log = mock_logger.debug.call_args_list[1][0][0]
        assert "call_func 返回: 3" in result_log

    def test_log_function_call_no_details(self):
        """Test log_function_call without args/result"""
        mock_logger = Mock()
        
        @log_function_call(logger=mock_logger)
        def call_func_simple():
            pass
            
        call_func_simple()
        
        assert mock_logger.debug.call_count == 1
        assert "调用 call_func_simple" in mock_logger.debug.call_args[0][0]
