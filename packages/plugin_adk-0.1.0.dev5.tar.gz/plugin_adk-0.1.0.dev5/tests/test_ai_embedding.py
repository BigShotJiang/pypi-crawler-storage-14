"""
Complete unit tests for Embedding Service - using proper patching for full suite compatibility.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from plugin_adk.core.ai.embedding import (
    EmbeddingService,
    EmbeddingModel,
    EmbeddingProvider,
    TokenUsage
)
from plugin_adk.core.ai.token_tracker import TokenTracker

# Fixture to patch aembedding in the embedding module
@pytest.fixture
def mock_aembedding():
    with patch("plugin_adk.core.ai.embedding.aembedding", new_callable=AsyncMock) as mock:
        # Default return value structure matching litellm response
        mock.return_value = MagicMock(
            data=[MagicMock(embedding=[0.1] * 128)]
        )
        yield mock

class TestEmbeddingModelDataclass:
    """Test EmbeddingModel"""
    
    def test_model_minimal(self):
        """Test minimal model creation"""
        model = EmbeddingModel(name="test", provider=EmbeddingProvider.OPENAI)
        assert model.name == "test"
        assert model.provider == EmbeddingProvider.OPENAI
        assert model.timeout == 60  # default
        assert model.api_key is None
        assert model.base_url is None
    
    def test_model_full(self):
        """Test model with all fields"""
        model = EmbeddingModel(
            name="custom",
            provider=EmbeddingProvider.CUSTOM,
            api_key="key-123",
            base_url="https://api.com",
            dimensions=768,
            timeout=30,
            metadata={"version": "1.0"},
        )
        assert model.name == "custom"
        assert model.api_key == "key-123"
        assert model.base_url == "https://api.com"
        assert model.dimensions == 768
        assert model.timeout == 30
        assert model.metadata["version"] == "1.0"


class TestEmbeddingServiceInitialization:
    """Test service initialization"""
    
    def test_init_no_default_model(self):
        """Test init with no default model"""
        service = EmbeddingService()
        assert service.default_model is None
        assert service.token_tracker is not None
        assert isinstance(service.token_tracker, TokenTracker)
    
    def test_init_with_string_model(self):
        """Test init with string model"""
        service = EmbeddingService(default_model="text-embedding-ada-002")
        assert service.default_model is not None
        assert service.default_model.name == "text-embedding-ada-002"
        assert service.default_model.provider == EmbeddingProvider.OPENAI
    
    def test_init_with_embedding_model_instance(self):
        """Test init with EmbeddingModel"""
        model = EmbeddingModel(name="custom", provider=EmbeddingProvider.COHERE, api_key="key")
        service = EmbeddingService(default_model=model)
        assert service.default_model is model
        assert service.default_model.name == "custom"
    
    def test_init_with_custom_token_tracker(self):
        """Test init with custom token tracker"""
        custom_tracker = TokenTracker()
        service = EmbeddingService(token_tracker=custom_tracker)
        assert service.token_tracker is custom_tracker
    
    def test_logger_created(self):
        """Test logger is created"""
        service = EmbeddingService()
        assert hasattr(service, 'logger')
        assert service.logger is not None

    def test_init_raises_import_error(self):
        """Test ImportError raised when litellm not available"""
        with patch('plugin_adk.core.ai.embedding.LITELLM_AVAILABLE', False):
            with pytest.raises(ImportError, match="litellm is not installed"):
                EmbeddingService()


class TestEmbeddingServiceEmbedMethod:
    """Test embed method"""
    
    @pytest.mark.asyncio
    async def test_embed_no_model_raises_error(self):
        """Test ValueError when no model"""
        service = EmbeddingService()  # No default model
        
        with pytest.raises(ValueError) as exc_info:
            await service.embed("test")
        
        assert "No model specified" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_embed_string_converted_to_list(self, mock_aembedding):
        """Test string input converted to list"""
        service = EmbeddingService(default_model="test")
        result = await service.embed("hello world")
        
        # Verify string was converted to list
        assert mock_aembedding.call_args[1]["input"] == ["hello world"]
        assert isinstance(result, list)
        assert len(result) == 1
    
    @pytest.mark.asyncio
    async def test_embed_uses_default_model(self, mock_aembedding):
        """Test uses default model when model=None"""
        service = EmbeddingService(default_model="default-model")
        await service.embed(["test"])
        
        assert mock_aembedding.call_args[1]["model"] == "default-model"
    
    @pytest.mark.asyncio
    async def test_embed_string_model_parameter(self, mock_aembedding):
        """Test model as string parameter"""
        service = EmbeddingService()
        await service.embed("test", model="override-model")
        
        assert mock_aembedding.call_args[1]["model"] == "override-model"
    
    @pytest.mark.asyncio
    async def test_embed_params_basic(self, mock_aembedding):
        """Test basic params preparation"""
        service = EmbeddingService(default_model="test-model")
        await service.embed(["text1", "text2"])
        
        assert mock_aembedding.call_args[1]["model"] == "test-model"
        assert mock_aembedding.call_args[1]["input"] == ["text1", "text2"]
    
    @pytest.mark.asyncio
    async def test_embed_api_key_added(self, mock_aembedding):
        """Test api_key added to params"""
        model = EmbeddingModel(name="test", provider=EmbeddingProvider.OPENAI, api_key="secret-key")
        service = EmbeddingService()
        await service.embed("test", model=model)
        
        assert mock_aembedding.call_args[1]["api_key"] == "secret-key"
    
    @pytest.mark.asyncio
    async def test_embed_base_url_added(self, mock_aembedding):
        """Test base_url added as api_base"""
        model = EmbeddingModel(name="test", provider=EmbeddingProvider.CUSTOM, base_url="https://custom.api")
        service = EmbeddingService()
        await service.embed("test", model=model)
        
        assert mock_aembedding.call_args[1]["api_base"] == "https://custom.api"
    
    @pytest.mark.asyncio
    async def test_embed_timeout_added(self, mock_aembedding):
        """Test timeout added to params"""
        model = EmbeddingModel(name="test", provider=EmbeddingProvider.OPENAI, timeout=30)
        service = EmbeddingService()
        await service.embed("test", model=model)
        
        assert mock_aembedding.call_args[1]["timeout"] == 30
    
    @pytest.mark.asyncio
    async def test_embed_kwargs_updated(self, mock_aembedding):
        """Test kwargs updated"""
        service = EmbeddingService(default_model="test")
        await service.embed("test", user="test-user", custom_param="value")
        
        assert mock_aembedding.call_args[1]["user"] == "test-user"
        assert mock_aembedding.call_args[1]["custom_param"] == "value"
    
    @pytest.mark.asyncio
    async def test_embed_extracts_embeddings(self, mock_aembedding):
        """Test embeddings extraction"""
        mock_aembedding.return_value = MagicMock(
            data=[
                MagicMock(embedding=[0.1, 0.2, 0.3]),
                MagicMock(embedding=[0.4, 0.5, 0.6])
            ]
        )
        
        service = EmbeddingService(default_model="test")
        result = await service.embed(["text1", "text2"])
        
        assert len(result) == 2
        assert result[0] == [0.1, 0.2, 0.3]
        assert result[1] == [0.4, 0.5, 0.6]
    
    @pytest.mark.asyncio
    async def test_embed_tracks_tokens(self, mock_aembedding):
        """Test token tracking"""
        service = EmbeddingService(default_model="test-model-tokens")
        
        # Mock token tracker to avoid actual calculation overhead/dependencies
        service.token_tracker = MagicMock(spec=TokenTracker)
        # The service calls record_usage, not track_request
        service.token_tracker.record_usage = AsyncMock()
        
        # Embed some text
        await service.embed("hello world test")
        
        # Check record_usage was called
        assert service.token_tracker.record_usage.called
    
    @pytest.mark.asyncio
    async def test_embed_exception_logged_and_raised(self, mock_aembedding):
        """Test exception handling"""
        mock_aembedding.side_effect = RuntimeError("API connection failed")
        
        service = EmbeddingService(default_model="test")
        
        with pytest.raises(RuntimeError, match="API connection failed"):
            await service.embed("test")


class TestEmbeddingServiceMethods:
    """Test other service methods"""
    
    def test_get_token_tracker(self):
        """Test get_token_tracker"""
        service = EmbeddingService()
        tracker = service.get_token_tracker()
        
        assert tracker is not None
        assert tracker is service.token_tracker
        assert isinstance(tracker, TokenTracker)
