"""
Tests for Exception models.
"""

import pytest
from plugin_adk.core.models.exceptions import (
    PluginSDKError,
    ErrorSeverity,
    ErrorCategory,
    ValidationError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ConflictError,
    RateLimitError,
    ServiceUnavailableError,
    ConfigurationError,
    InternalError,
    NetworkError,
    TimeoutError,
)


class TestPluginSDKError:
    """Tests for PluginSDKError base class"""
    
    def test_error_creation(self):
        """Test basic error creation"""
        error = PluginSDKError(
            message="Test error",
            error_code="ERR001"
        )
        
        assert str(error) == "[ERR001] Test error"
        assert error.message == "Test error"
        assert error.error_code == "ERR001"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.INTERNAL
    
    def test_error_to_dict(self):
        """Test error serialization to dict"""
        error = PluginSDKError(
            message="Test error",
            error_code="ERR001",
            severity=ErrorSeverity.HIGH,
            category=ErrorCategory.NETWORK,
            solution="Try again",
            documentation_url="https://example.com/docs"
        )
        
        error_dict = error.to_dict()
        
        assert error_dict["message"] == "Test error"
        assert error_dict["error_code"] == "ERR001"
        assert error_dict["severity"] == "high"
        assert error_dict["category"] == "network"
        assert error_dict["solution"] == "Try again"
        assert error_dict["documentation_url"] == "https://example.com/docs"
    
    def test_error_user_friendly_message(self):
        """Test user-friendly error message"""
        error = PluginSDKError(
            message="Test error",
            solution="Try again",
            documentation_url="https://example.com/docs"
        )
        
        message = error.get_user_friendly_message()
        assert "错误代码" in message
        assert "错误信息" in message
        assert "解决方案" in message
        assert "参考文档" in message


class TestValidationError:
    """Tests for ValidationError"""
    
    def test_validation_error_creation(self):
        """Test ValidationError creation"""
        error = ValidationError(
            message="Invalid value",
            field="email",
            value="invalid-email"
        )
        
        assert error.message == "Invalid value"
        assert error.field == "email"
        assert error.value == "invalid-email"
        assert error.severity == ErrorSeverity.LOW
        assert error.category == ErrorCategory.VALIDATION
        assert error.details["field"] == "email"


class TestAuthenticationError:
    """Tests for AuthenticationError"""
    
    def test_authentication_error_creation(self):
        """Test AuthenticationError creation"""
        error = AuthenticationError("Authentication failed")
        
        assert error.message == "Authentication failed"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.AUTHENTICATION


class TestAuthorizationError:
    """Tests for AuthorizationError"""
    
    def test_authorization_error_creation(self):
        """Test AuthorizationError creation"""
        error = AuthorizationError("Permission denied")
        
        assert error.message == "Permission denied"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.AUTHORIZATION


class TestNotFoundError:
    """Tests for NotFoundError"""
    
    def test_not_found_error_creation(self):
        """Test NotFoundError creation"""
        error = NotFoundError(
            message="Resource not found",
            resource_type="plugin",
            resource_id="plugin123"
        )
        
        assert error.message == "Resource not found"
        assert error.resource_type == "plugin"
        assert error.resource_id == "plugin123"
        assert error.severity == ErrorSeverity.LOW
        assert error.category == ErrorCategory.NOT_FOUND
        assert error.details["resource_type"] == "plugin"
        assert error.details["resource_id"] == "plugin123"


class TestRateLimitError:
    """Tests for RateLimitError"""
    
    def test_rate_limit_error_creation(self):
        """Test RateLimitError creation"""
        error = RateLimitError(
            message="Rate limit exceeded",
            limit=100,
            retry_after=60
        )
        
        assert error.message == "Rate limit exceeded"
        assert error.limit == 100
        assert error.retry_after == 60
        assert error.recoverable is True
        assert error.details["limit"] == 100
        assert error.details["retry_after"] == 60


class TestTimeoutError:
    """Tests for TimeoutError"""
    
    def test_timeout_error_creation(self):
        """Test TimeoutError creation"""
        error = TimeoutError(
            message="Operation timeout",
            timeout=30.0
        )
        
        assert error.message == "Operation timeout"
        assert error.timeout == 30.0
        assert error.recoverable is True
        assert error.details["timeout"] == 30.0
    
    def test_timeout_error_without_timeout(self):
        """Test TimeoutError without timeout (line 315-316)"""
        error = TimeoutError(message="Operation timeout")
        
        assert error.message == "Operation timeout"
        assert error.timeout is None
        assert "timeout" not in error.details


class TestPluginSDKErrorAdvanced:
    """Advanced tests for PluginSDKError"""
    
    def test_error_with_all_parameters(self):
        """Test PluginSDKError with all parameters (line 65-73)"""
        error = PluginSDKError(
            message="Test error",
            error_code="ERR001",
            severity=ErrorSeverity.HIGH,
            category=ErrorCategory.NETWORK,
            details={"key": "value"},
            recoverable=False,
            solution="Try again",
            documentation_url="https://example.com/docs"
        )
        
        assert error.message == "Test error"
        assert error.error_code == "ERR001"
        assert error.severity == ErrorSeverity.HIGH
        assert error.category == ErrorCategory.NETWORK
        assert error.details == {"key": "value"}
        assert error.recoverable is False
        assert error.solution == "Try again"
        assert error.documentation_url == "https://example.com/docs"
    
    def test_error_to_dict_with_optional_fields(self):
        """Test to_dict with optional fields (line 77-89)"""
        error = PluginSDKError(
            message="Test error",
            solution="Try again",
            documentation_url="https://example.com/docs"
        )
        
        error_dict = error.to_dict()
        
        assert "solution" in error_dict
        assert "documentation_url" in error_dict
        assert error_dict["solution"] == "Try again"
        assert error_dict["documentation_url"] == "https://example.com/docs"
    
    def test_error_to_dict_without_optional_fields(self):
        """Test to_dict without optional fields"""
        error = PluginSDKError(message="Test error")
        
        error_dict = error.to_dict()
        
        assert "solution" not in error_dict
        assert "documentation_url" not in error_dict
    
    def test_error_str_with_solution_and_docs(self):
        """Test __str__ with solution and documentation (line 93-98)"""
        error = PluginSDKError(
            message="Test error",
            solution="Try again",
            documentation_url="https://example.com/docs"
        )
        
        error_str = str(error)
        assert "Test error" in error_str
        assert "解决方案" in error_str
        assert "Try again" in error_str
        assert "文档" in error_str
        assert "https://example.com/docs" in error_str
    
    def test_error_str_without_optional_fields(self):
        """Test __str__ without optional fields"""
        error = PluginSDKError(message="Test error")
        
        error_str = str(error)
        assert "[PluginSDKError] Test error" in error_str
        assert "解决方案" not in error_str
        assert "文档" not in error_str
    
    def test_get_user_friendly_message_with_details(self):
        """Test get_user_friendly_message with details (line 107-118)"""
        error = PluginSDKError(
            message="Test error",
            solution="Try again",
            documentation_url="https://example.com/docs",
            details={"key": "value"}
        )
        
        message = error.get_user_friendly_message()
        assert "错误代码" in message
        assert "错误信息" in message
        assert "解决方案" in message
        assert "参考文档" in message
        assert "详细信息" in message
        assert "key" in message or "value" in message
    
    def test_get_user_friendly_message_without_optional_fields(self):
        """Test get_user_friendly_message without optional fields"""
        error = PluginSDKError(message="Test error")
        
        message = error.get_user_friendly_message()
        assert "错误代码" in message
        assert "错误信息" in message
        assert "解决方案" not in message
        assert "参考文档" not in message
        assert "详细信息" not in message


class TestValidationErrorAdvanced:
    """Advanced tests for ValidationError"""
    
    def test_validation_error_without_field_and_value(self):
        """Test ValidationError without field and value (line 131-142)"""
        error = ValidationError(message="Invalid value")
        
        assert error.message == "Invalid value"
        assert error.field is None
        assert error.value is None
        assert "field" not in error.details
        assert "value" not in error.details
    
    def test_validation_error_with_value_none(self):
        """Test ValidationError with value=None"""
        error = ValidationError(
            message="Invalid value",
            field="email",
            value=None
        )
        
        assert error.field == "email"
        assert error.value is None
        assert error.details["field"] == "email"
        assert "value" not in error.details


class TestAuthenticationErrorAdvanced:
    """Advanced tests for AuthenticationError"""
    
    def test_authentication_error_default_message(self):
        """Test AuthenticationError with default message (line 149)"""
        error = AuthenticationError()
        
        assert error.message == "认证失败"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.AUTHENTICATION


class TestAuthorizationErrorAdvanced:
    """Advanced tests for AuthorizationError"""
    
    def test_authorization_error_default_message(self):
        """Test AuthorizationError with default message (line 161)"""
        error = AuthorizationError()
        
        assert error.message == "权限不足"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.AUTHORIZATION


class TestNotFoundErrorAdvanced:
    """Advanced tests for NotFoundError"""
    
    def test_not_found_error_without_resource_info(self):
        """Test NotFoundError without resource info (line 179-190)"""
        error = NotFoundError(message="Resource not found")
        
        assert error.message == "Resource not found"
        assert error.resource_type is None
        assert error.resource_id is None
        assert "resource_type" not in error.details
        assert "resource_id" not in error.details
    
    def test_not_found_error_default_message(self):
        """Test NotFoundError with default message"""
        error = NotFoundError()
        
        assert error.message == "资源未找到"
        assert error.severity == ErrorSeverity.LOW
        assert error.category == ErrorCategory.NOT_FOUND


class TestConflictError:
    """Tests for ConflictError"""
    
    def test_conflict_error_creation(self):
        """Test ConflictError creation (line 197)"""
        error = ConflictError(message="Resource conflict")
        
        assert error.message == "Resource conflict"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.CONFLICT
    
    def test_conflict_error_default_message(self):
        """Test ConflictError with default message"""
        error = ConflictError()
        
        assert error.message == "资源冲突"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.CONFLICT


class TestRateLimitErrorAdvanced:
    """Advanced tests for RateLimitError"""
    
    def test_rate_limit_error_without_limit_and_retry(self):
        """Test RateLimitError without limit and retry_after (line 215-227)"""
        error = RateLimitError(message="Rate limit exceeded")
        
        assert error.message == "Rate limit exceeded"
        assert error.limit is None
        assert error.retry_after is None
        assert "limit" not in error.details
        assert "retry_after" not in error.details
    
    def test_rate_limit_error_default_message(self):
        """Test RateLimitError with default message"""
        error = RateLimitError()
        
        assert error.message == "请求速率超限"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.RATE_LIMIT
        assert error.recoverable is True


class TestServiceUnavailableError:
    """Tests for ServiceUnavailableError"""
    
    def test_service_unavailable_error_creation(self):
        """Test ServiceUnavailableError creation (line 239-248)"""
        error = ServiceUnavailableError(
            message="Service unavailable",
            service_name="test_service"
        )
        
        assert error.message == "Service unavailable"
        assert error.service_name == "test_service"
        assert error.severity == ErrorSeverity.HIGH
        assert error.category == ErrorCategory.SERVICE_UNAVAILABLE
        assert error.recoverable is True
        assert error.details["service_name"] == "test_service"
    
    def test_service_unavailable_error_without_service_name(self):
        """Test ServiceUnavailableError without service_name"""
        error = ServiceUnavailableError(message="Service unavailable")
        
        assert error.message == "Service unavailable"
        assert error.service_name is None
        assert "service_name" not in error.details
    
    def test_service_unavailable_error_default_message(self):
        """Test ServiceUnavailableError with default message"""
        error = ServiceUnavailableError()
        
        assert error.message == "服务不可用"
        assert error.severity == ErrorSeverity.HIGH
        assert error.category == ErrorCategory.SERVICE_UNAVAILABLE
        assert error.recoverable is True


class TestConfigurationError:
    """Tests for ConfigurationError"""
    
    def test_configuration_error_creation(self):
        """Test ConfigurationError creation (line 260-269)"""
        error = ConfigurationError(
            message="Configuration error",
            config_key="api_key"
        )
        
        assert error.message == "Configuration error"
        assert error.config_key == "api_key"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.INTERNAL
        assert error.recoverable is False
        assert error.details["config_key"] == "api_key"
    
    def test_configuration_error_without_config_key(self):
        """Test ConfigurationError without config_key"""
        error = ConfigurationError(message="Configuration error")
        
        assert error.message == "Configuration error"
        assert error.config_key is None
        assert "config_key" not in error.details
    
    def test_configuration_error_default_message(self):
        """Test ConfigurationError with default message"""
        error = ConfigurationError()
        
        assert error.message == "配置错误"
        assert error.severity == ErrorSeverity.MEDIUM
        assert error.category == ErrorCategory.INTERNAL
        assert error.recoverable is False


class TestInternalError:
    """Tests for InternalError"""
    
    def test_internal_error_creation(self):
        """Test InternalError creation (line 276)"""
        error = InternalError(message="Internal error")
        
        assert error.message == "Internal error"
        assert error.severity == ErrorSeverity.CRITICAL
        assert error.category == ErrorCategory.INTERNAL
        assert error.recoverable is False
    
    def test_internal_error_default_message(self):
        """Test InternalError with default message"""
        error = InternalError()
        
        assert error.message == "内部错误"
        assert error.severity == ErrorSeverity.CRITICAL
        assert error.category == ErrorCategory.INTERNAL
        assert error.recoverable is False


class TestNetworkError:
    """Tests for NetworkError"""
    
    def test_network_error_creation(self):
        """Test NetworkError creation (line 289)"""
        error = NetworkError(message="Network error")
        
        assert error.message == "Network error"
        assert error.severity == ErrorSeverity.HIGH
        assert error.category == ErrorCategory.NETWORK
        assert error.recoverable is True
    
    def test_network_error_default_message(self):
        """Test NetworkError with default message"""
        error = NetworkError()
        
        assert error.message == "网络错误"
        assert error.severity == ErrorSeverity.HIGH
        assert error.category == ErrorCategory.NETWORK
        assert error.recoverable is True

