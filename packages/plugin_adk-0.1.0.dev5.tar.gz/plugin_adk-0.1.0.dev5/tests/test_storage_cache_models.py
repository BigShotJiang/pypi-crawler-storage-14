"""
Tests for Cache Models.
"""

import pytest
from datetime import datetime, timedelta
from plugin_adk.core.storage import (
    CacheLevel,
    WriteMode,
    CacheEntry,
    CacheStats,
    CacheMetrics,
)


class TestCacheLevel:
    """Tests for CacheLevel"""
    
    def test_cache_level_values(self):
        """Test cache level values"""
        assert CacheLevel.L1 == "l1"
        assert CacheLevel.L2 == "l2"
        assert CacheLevel.L3 == "l3"


class TestWriteMode:
    """Tests for WriteMode"""
    
    def test_write_mode_values(self):
        """Test write mode values"""
        assert WriteMode.WRITE_THROUGH == "write_through"
        assert WriteMode.WRITE_BACK == "write_back"
        assert WriteMode.WRITE_AROUND == "write_around"


class TestCacheEntry:
    """Tests for CacheEntry"""
    
    def test_cache_entry_creation(self):
        """Test cache entry creation"""
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        assert entry.key == "key1"
        assert entry.value == "value1"
        assert entry.level == CacheLevel.L1
        assert entry.access_count == 0
        assert entry.expires_at is None
    
    def test_cache_entry_expiration(self):
        """Test cache entry expiration"""
        # Not expired
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        assert not entry.is_expired()
        
        # Expired
        entry.expires_at = datetime.now() - timedelta(seconds=10)
        assert entry.is_expired()
        
        # Not expired (future)
        entry.expires_at = datetime.now() + timedelta(seconds=10)
        assert not entry.is_expired()
    
    def test_cache_entry_touch(self):
        """Test cache entry touch"""
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        initial_count = entry.access_count
        initial_time = entry.last_accessed
        
        import time
        time.sleep(0.001)
        entry.touch()
        
        assert entry.access_count == initial_count + 1
        assert entry.last_accessed > initial_time
    
    def test_cache_entry_age(self):
        """Test cache entry age calculation"""
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        age = entry.get_age_seconds()
        assert age >= 0
    
    def test_cache_entry_idle(self):
        """Test cache entry idle time calculation"""
        entry = CacheEntry("key1", "value1", CacheLevel.L1)
        
        idle = entry.get_idle_seconds()
        assert idle >= 0


class TestCacheStats:
    """Tests for CacheStats"""
    
    def test_cache_stats_initialization(self):
        """Test cache stats initialization"""
        stats = CacheStats()
        
        assert stats.total_requests == 0
        assert stats.hits == 0
        assert stats.misses == 0
        assert stats.evictions == 0
        assert stats.errors == 0
    
    def test_cache_stats_hit_rate(self):
        """Test cache stats hit rate calculation"""
        stats = CacheStats()
        
        # No requests
        assert stats.get_hit_rate() == 0.0
        
        # With requests
        stats.total_requests = 100
        stats.hits = 75
        stats.misses = 25
        
        assert stats.get_hit_rate() == 0.75
    
    def test_cache_stats_level_hit_rates(self):
        """Test cache stats level hit rates"""
        stats = CacheStats()
        
        # L1
        stats.l1_hits = 80
        stats.l1_misses = 20
        assert stats.get_l1_hit_rate() == 0.8
        
        # L2
        stats.l2_hits = 60
        stats.l2_misses = 40
        assert stats.get_l2_hit_rate() == 0.6
        
        # L3
        stats.l3_hits = 50
        stats.l3_misses = 50
        assert stats.get_l3_hit_rate() == 0.5
    
    def test_cache_stats_to_dict(self):
        """Test cache stats to dict conversion"""
        stats = CacheStats()
        stats.total_requests = 100
        stats.hits = 75
        stats.misses = 25
        
        result = stats.to_dict()
        
        assert "total_requests" in result
        assert "hits" in result
        assert "misses" in result
        assert "hit_rate" in result
        assert result["hit_rate"] == 0.75


class TestCacheMetrics:
    """Tests for CacheMetrics"""
    
    def test_cache_metrics_initialization(self):
        """Test cache metrics initialization"""
        metrics = CacheMetrics()
        
        assert metrics.stats is not None
        assert metrics.memory_usage_mb == 0.0
        assert metrics.cpu_percent == 0.0
    
    def test_cache_metrics_to_dict(self):
        """Test cache metrics to dict conversion"""
        metrics = CacheMetrics()
        metrics.memory_usage_mb = 128.5
        metrics.cpu_percent = 25.0
        
        result = metrics.to_dict()
        
        assert "timestamp" in result
        assert "stats" in result
        assert "memory_usage_mb" in result
        assert "cpu_percent" in result
        assert result["memory_usage_mb"] == 128.5
        assert result["cpu_percent"] == 25.0

