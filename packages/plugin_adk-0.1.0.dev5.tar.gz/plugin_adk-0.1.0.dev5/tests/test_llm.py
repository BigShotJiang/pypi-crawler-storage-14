"""
Unit tests for LLMService.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from datetime import datetime

from plugin_adk.core.ai.llm import LLMService, LLMModel, LLMProvider
from plugin_adk.core.ai.token_tracker import TokenTracker, TokenUsage


@pytest.fixture
def token_tracker():
    """Create token tracker"""
    return TokenTracker()


@pytest.mark.asyncio
async def test_llm_service_init_with_string_model(token_tracker):
    """Test LLMService initialization with string model"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        assert service.default_model is not None
        assert service.default_model.name == "gpt-3.5-turbo"
        assert service.default_model.provider == LLMProvider.OPENAI
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_init_with_llm_model(token_tracker):
    """Test LLMService initialization with LLMModel instance"""
    try:
        model = LLMModel(name="gpt-4", provider=LLMProvider.OPENAI)
        service = LLMService(default_model=model, token_tracker=token_tracker)
        assert service.default_model == model
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_init_no_litellm():
    """Test LLMService initialization when litellm is not available"""
    with patch('plugin_adk.core.ai.llm.LITELLM_AVAILABLE', False):
        with pytest.raises(ImportError, match="litellm is not installed"):
            LLMService()


@pytest.mark.asyncio
async def test_llm_service_complete_with_default_model(token_tracker):
    """Test complete with default model"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = Mock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            result = await service.complete([
                {"role": "user", "content": "Hello"}
            ])
            
            assert result["content"] == "Hello!"
            assert result["usage"]["total_tokens"] == 15
            assert result["model"] == "gpt-3.5-turbo"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_with_string_model(token_tracker):
    """Test complete with string model parameter"""
    try:
        service = LLMService(token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = Mock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            # Set default model first
            service.default_model = LLMModel(name="gpt-3.5-turbo", provider=LLMProvider.OPENAI)
            
            result = await service.complete(
                [{"role": "user", "content": "Hello"}],
                model="gpt-4"
            )
            
            assert result["content"] == "Hello!"
            assert result["model"] == "gpt-4"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_with_llm_model(token_tracker):
    """Test complete with LLMModel parameter"""
    try:
        service = LLMService(token_tracker=token_tracker)
        
        model = LLMModel(
            name="gpt-4",
            provider=LLMProvider.OPENAI,
            temperature=0.9,
            max_tokens=100,
            api_key="test-key",
            base_url="https://api.test.com"
        )
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = Mock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            result = await service.complete(
                [{"role": "user", "content": "Hello"}],
                model=model
            )
            
            assert result["content"] == "Hello!"
            # Verify parameters were passed
            mock_acomplete.assert_called_once()
            call_kwargs = mock_acomplete.call_args[1]
            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs.get("api_key") == "test-key"
            assert call_kwargs.get("api_base") == "https://api.test.com"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_no_model_no_default(token_tracker):
    """Test complete with no model and no default"""
    try:
        service = LLMService(token_tracker=token_tracker)
        service.default_model = None
        
        with pytest.raises(ValueError, match="No model specified"):
            await service.complete([{"role": "user", "content": "Hello"}])
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_with_temperature(token_tracker):
    """Test complete with temperature parameter"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = Mock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            await service.complete(
                [{"role": "user", "content": "Hello"}],
                temperature=0.9
            )
            
            # Verify temperature was passed
            call_kwargs = mock_acomplete.call_args[1]
            assert call_kwargs["temperature"] == 0.9
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_with_max_tokens(token_tracker):
    """Test complete with max_tokens parameter"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = Mock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            await service.complete(
                [{"role": "user", "content": "Hello"}],
                max_tokens=100
            )
            
            # Verify max_tokens was passed
            call_kwargs = mock_acomplete.call_args[1]
            assert call_kwargs["max_tokens"] == 100
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_with_model_temperature(token_tracker):
    """Test complete using model's temperature"""
    try:
        model = LLMModel(name="gpt-4", provider=LLMProvider.OPENAI, temperature=0.8)
        service = LLMService(default_model=model, token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = Mock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            await service.complete([{"role": "user", "content": "Hello"}])
            
            # Verify model's temperature was used
            call_kwargs = mock_acomplete.call_args[1]
            assert call_kwargs["temperature"] == 0.8
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_with_model_max_tokens(token_tracker):
    """Test complete using model's max_tokens"""
    try:
        model = LLMModel(name="gpt-4", provider=LLMProvider.OPENAI, max_tokens=200)
        service = LLMService(default_model=model, token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = Mock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            await service.complete([{"role": "user", "content": "Hello"}])
            
            # Verify model's max_tokens was used
            call_kwargs = mock_acomplete.call_args[1]
            assert call_kwargs["max_tokens"] == 200
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_exception(token_tracker):
    """Test complete exception handling"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.side_effect = Exception("API error")
            
            with pytest.raises(Exception, match="API error"):
                await service.complete([{"role": "user", "content": "Hello"}])
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_complete_no_usage(token_tracker):
    """Test complete when response has no usage"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.usage = None  # No usage
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_response
            
            result = await service.complete([{"role": "user", "content": "Hello"}])
            
            assert result["content"] == "Hello!"
            assert result["usage"]["total_tokens"] == 0
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_stream_complete(token_tracker):
    """Test stream_complete method"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        
        # Mock stream response
        mock_chunk1 = Mock()
        mock_chunk1.choices = [Mock()]
        mock_chunk1.choices[0].delta = Mock()
        mock_chunk1.choices[0].delta.content = "Hello"
        mock_chunk1.choices[0].finish_reason = None
        
        mock_chunk2 = Mock()
        mock_chunk2.choices = [Mock()]
        mock_chunk2.choices[0].delta = Mock()
        mock_chunk2.choices[0].delta.content = "!"
        mock_chunk2.choices[0].finish_reason = "stop"
        
        async def mock_stream():
            yield mock_chunk1
            yield mock_chunk2
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.return_value = mock_stream()
            
            chunks = []
            async for chunk in service.stream_complete([{"role": "user", "content": "Hello"}]):
                chunks.append(chunk)
            
            assert len(chunks) == 2
            assert chunks[0]["content"] == "Hello"
            assert chunks[1]["content"] == "!"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_stream_complete_no_model(token_tracker):
    """Test stream_complete with no model and no default"""
    try:
        service = LLMService(token_tracker=token_tracker)
        service.default_model = None
        
        with pytest.raises(ValueError, match="No model specified"):
            async for _ in service.stream_complete([{"role": "user", "content": "Hello"}]):
                pass
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_stream_complete_exception(token_tracker):
    """Test stream_complete exception handling"""
    try:
        service = LLMService(default_model="gpt-3.5-turbo", token_tracker=token_tracker)
        
        with patch('plugin_adk.core.ai.llm.acompletion', new_callable=AsyncMock) as mock_acomplete:
            mock_acomplete.side_effect = Exception("Stream error")
            
            with pytest.raises(Exception, match="Stream error"):
                async for _ in service.stream_complete([{"role": "user", "content": "Hello"}]):
                    pass
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_llm_service_get_token_tracker(token_tracker):
    """Test get_token_tracker method"""
    try:
        service = LLMService(token_tracker=token_tracker)
        assert service.get_token_tracker() == token_tracker
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise

