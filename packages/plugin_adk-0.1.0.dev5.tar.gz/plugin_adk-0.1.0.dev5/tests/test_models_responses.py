"""
Tests for Response models.
"""

import pytest
from plugin_adk.core.models.responses import (
    Response,
    ResponseStatus,
    ResponseCode,
    SuccessResponse,
    ErrorResponse,
    DataResponse,
    PaginatedResponse,
    StreamResponse,
)


class TestResponse:
    """Tests for Response base class"""
    
    def test_response_creation(self):
        """Test basic response creation"""
        response = Response(
            message="Test message",
            data={"key": "value"}
        )
        
        assert response.message == "Test message"
        assert response.data == {"key": "value"}
        assert response.status == ResponseStatus.SUCCESS
        assert response.code == ResponseCode.OK
        assert response.request_id is not None
    
    def test_response_is_success(self):
        """Test is_success method"""
        success_response = Response(status=ResponseStatus.SUCCESS)
        error_response = Response(status=ResponseStatus.ERROR)
        
        assert success_response.is_success()
        assert not error_response.is_success()
    
    def test_response_is_error(self):
        """Test is_error method"""
        success_response = Response(status=ResponseStatus.SUCCESS)
        error_response = Response(status=ResponseStatus.ERROR)
        
        assert not success_response.is_error()
        assert error_response.is_error()
    
    def test_response_fluent_api(self):
        """Test response fluent API"""
        response = Response(
            message="Test"
        ).with_metadata(key1="value1", key2="value2").with_source("source1").with_execution_time(1.5)
        
        assert response.metadata["key1"] == "value1"
        assert response.metadata["key2"] == "value2"
        assert response.source == "source1"
        assert response.execution_time == 1.5
    
    def test_response_success_factory(self):
        """Test success factory method"""
        response = Response.success(
            message="Success",
            data={"result": "ok"}
        )
        
        assert response.status == ResponseStatus.SUCCESS
        assert response.message == "Success"
        assert response.data == {"result": "ok"}
    
    def test_response_error_factory(self):
        """Test error factory method"""
        response = Response.failure(
            message="Error occurred",
            error="Something went wrong",
            error_code="ERR001"
        )
        
        assert response.status == ResponseStatus.ERROR
        assert response.message == "Error occurred"
        assert response.error == "Something went wrong"
        assert response.error_code == "ERR001"
    
    def test_response_to_dict(self):
        """Test response serialization to dict"""
        response = Response(
            message="Test",
            data={"key": "value"},
            source="source1",
            execution_time=1.5
        )
        
        response_dict = response.to_dict()
        
        assert response_dict["message"] == "Test"
        assert response_dict["data"] == {"key": "value"}
        assert response_dict["source"] == "source1"
        assert response_dict["execution_time"] == 1.5
        assert response_dict["status"] == "success"
        assert "request_id" in response_dict
    
    def test_response_to_json(self):
        """Test response JSON serialization"""
        response = Response(
            message="Test",
            data={"key": "value"}
        )
        
        json_str = response.to_json()
        assert isinstance(json_str, str)
        assert "Test" in json_str


class TestSuccessResponse:
    """Tests for SuccessResponse"""
    
    def test_success_response_creation(self):
        """Test SuccessResponse creation"""
        response = SuccessResponse(
            message="Operation successful",
            data={"result": "ok"}
        )
        
        assert response.status == ResponseStatus.SUCCESS
        assert response.message == "Operation successful"
        assert response.data == {"result": "ok"}
        assert response.error is None


class TestErrorResponse:
    """Tests for ErrorResponse"""
    
    def test_error_response_creation(self):
        """Test ErrorResponse creation"""
        response = ErrorResponse(
            message="Operation failed",
            error="Something went wrong",
            error_code="ERR001"
        )
        
        assert response.status == ResponseStatus.ERROR
        assert response.message == "Operation failed"
        assert response.error == "Something went wrong"
        assert response.error_code == "ERR001"
    
    def test_error_response_compatibility_properties(self):
        """Test ErrorResponse compatibility properties"""
        response = ErrorResponse(
            message="Failed",
            error="Error message",
            error_details={"detail": "value"}
        )
        
        assert response.error_message == "Error message"
        assert response.details == {"detail": "value"}


class TestDataResponse:
    """Tests for DataResponse"""
    
    def test_data_response_creation(self):
        """Test DataResponse creation"""
        response = DataResponse(
            data={"items": [1, 2, 3]},
            message="Data retrieved"
        )
        
        assert response.status == ResponseStatus.SUCCESS
        assert response.data == {"items": [1, 2, 3]}
        assert response.message == "Data retrieved"


class TestPaginatedResponse:
    """Tests for PaginatedResponse"""
    
    def test_paginated_response_creation(self):
        """Test PaginatedResponse creation"""
        response = PaginatedResponse(
            data=[1, 2, 3],
            total=100,
            page=1,
            page_size=10
        )
        
        assert response.status == ResponseStatus.SUCCESS
        assert response.data == [1, 2, 3]
        assert response.pagination is not None
        assert response.pagination["total"] == 100
        assert response.pagination["page"] == 1
        assert response.pagination["page_size"] == 10
        assert response.pagination["total_pages"] == 10
        assert response.pagination["has_next"] is True
        assert response.pagination["has_prev"] is False


class TestStreamResponse:
    """Tests for StreamResponse"""
    
    def test_stream_response_creation(self):
        """Test StreamResponse creation"""
        response = StreamResponse(stream_id="stream123")
        
        assert response.status == ResponseStatus.SUCCESS
        assert response.data["stream_id"] == "stream123"
        assert response.data["type"] == "stream_start"
    
    def test_stream_response_chunk(self):
        """Test StreamResponse chunk factory"""
        response = StreamResponse.chunk("stream123", "chunk data")
        
        assert response.data["stream_id"] == "stream123"
        assert response.data["type"] == "stream_chunk"
    
    def test_stream_response_end(self):
        """Test StreamResponse end factory"""
        response = StreamResponse.end("stream123")
        
        assert response.data["stream_id"] == "stream123"
        assert response.data["type"] == "stream_end"

