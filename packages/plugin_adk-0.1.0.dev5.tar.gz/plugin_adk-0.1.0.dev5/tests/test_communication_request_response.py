"""
Tests for Request/Response pattern.
"""

import pytest
import asyncio
from plugin_adk.core.communication import (
    MemoryEventBus,
    RequestResponse,
    RequestResponseError,
    RequestTimeoutError,
)


class TestRequestResponse:
    """Tests for RequestResponse"""
    
    @pytest.mark.asyncio
    async def test_request_response_start_stop(self):
        """Test Request/Response start and stop"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        
        assert not rr._is_running
        
        await rr.start()
        assert rr._is_running
        
        await rr.stop()
        assert not rr._is_running
        
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_register_handler(self):
        """Test handler registration"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        async def handler(request: dict) -> dict:
            return {"result": request["data"] * 2}
        
        await rr.register_handler("test.service", handler)
        
        assert "test.service" in rr._handlers
        
        await rr.stop()
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_request_response(self):
        """Test request/response communication"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        # Register handler
        async def handler(request: dict) -> dict:
            return {"result": request["data"] * 2}
        
        await rr.register_handler("test.service", handler)
        
        # Make request
        response = await rr.request("test.service", {"data": 42})
        
        assert response["result"] == 84
        
        await rr.stop()
        await bus.stop()
    
    @pytest.mark.asyncio
    async def test_request_timeout(self):
        """Test request timeout"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus, timeout=0.1)
        await rr.start()
        
        try:
            # Make request to non-existent service
            with pytest.raises(RequestTimeoutError):
                await rr.request("nonexistent.service", {"data": 42}, timeout=0.1)
        finally:
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_handler_error(self):
        """Test handler error handling"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            # Register error handler
            async def error_handler(request: dict) -> dict:
                raise ValueError("Handler error")
            
            await rr.register_handler("test.error", error_handler)
            
            # Make request
            with pytest.raises(RequestResponseError):
                await rr.request("test.error", {"data": 42})
        finally:
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_multiple_requests(self):
        """Test multiple concurrent requests"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            # Register handler
            async def handler(request: dict) -> dict:
                await asyncio.sleep(0.01)  # Simulate processing
                return {"result": request["data"] * 2}
            
            await rr.register_handler("test.service", handler)
            
            # Make multiple requests
            tasks = [
                rr.request("test.service", {"data": i})
                for i in range(5)
            ]
            
            responses = await asyncio.gather(*tasks)
            
            assert len(responses) == 5
            for i, response in enumerate(responses):
                assert response["result"] == i * 2
        finally:
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_unregister_handler(self):
        """Test handler unregistration"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            async def handler(request: dict) -> dict:
                return {"result": "ok"}
            
            await rr.register_handler("test.service", handler)
            assert "test.service" in rr._handlers
            
            await rr.unregister_handler("test.service")
            assert "test.service" not in rr._handlers
        finally:
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_request_exception_cleanup(self):
        """Test request exception cleanup"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            # Mock publish to raise exception
            original_publish = bus.publish
            async def failing_publish(event):
                raise Exception("Publish error")
            
            bus.publish = failing_publish
            
            # Request should clean up even on exception
            with pytest.raises(RequestResponseError):
                await rr.request("test.service", {"data": 42})
            
            # Verify cleanup happened
            assert len(rr._pending_requests) == 0
        finally:
            bus.publish = original_publish
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_request_custom_timeout(self):
        """Test request with custom timeout"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus, timeout=1.0)
        await rr.start()
        
        try:
            # Register handler with delay
            async def slow_handler(request: dict) -> dict:
                await asyncio.sleep(0.05)
                return {"result": request["data"]}
            
            await rr.register_handler("test.service", slow_handler)
            
            # Request with shorter timeout should succeed
            response = await rr.request("test.service", {"data": 42}, timeout=0.1)
            assert response["result"] == 42
        finally:
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_handle_response_no_pending_request(self):
        """Test _handle_response when no pending request"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            # Create a response event for non-existent request
            from plugin_adk.core.models.events import Event, EventType
            
            response_event = Event(
                topic="response.test-id",
                event_type=EventType.MESSAGE,
                data={"request_id": "test-id", "data": {"result": "test"}},
            )
            
            # Should not raise error, just ignore
            await rr._handle_response(response_event)
        finally:
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_handle_response_invalid_data(self):
        """Test _handle_response with invalid data"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            from plugin_adk.core.models.events import Event, EventType
            
            # Create future for request
            future = asyncio.Future()
            rr._pending_requests["test-id"] = future
            
            # Create response event with invalid data
            response_event = Event(
                topic="response.test-id",
                event_type=EventType.MESSAGE,
                data={"invalid": "data"},  # Missing request_id
            )
            
            # Should handle gracefully
            await rr._handle_response(response_event)
            
            # Future should not be set
            assert not future.done()
        finally:
            await rr.stop()
            await bus.stop()
    
    @pytest.mark.asyncio
    async def test_request_response_error(self):
        """Test RequestResponseError"""
        from plugin_adk.core.communication import RequestResponseError
        
        error = RequestResponseError("Test error", solution="Test solution")
        assert error.message == "Test error"
        assert error.solution == "Test solution"
    
    @pytest.mark.asyncio
    async def test_request_timeout_error(self):
        """Test RequestTimeoutError"""
        from plugin_adk.core.communication import RequestTimeoutError
        
        error = RequestTimeoutError("Timeout error", solution="Test solution")
        assert error.message == "Timeout error"
        assert isinstance(error, RequestResponseError)

    @pytest.mark.asyncio
    async def test_start_idempotent(self):
        """Test start() can be called multiple times safely"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        await rr.start()  # Should not raise
        
        assert rr._is_running
        
        await rr.stop()
        await bus.stop()

    @pytest.mark.asyncio
    async def test_stop_not_running(self):
        """Test stop() when not running"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        # Don't start
        
        # Should not raise
        await rr.stop()
        assert not rr._is_running
        
        await bus.stop()

    @pytest.mark.asyncio
    async def test_register_handler_after_start(self):
        """Test register_handler after start subscribes to topic"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        async def handler(request: dict) -> dict:
            return {"result": "ok"}
        
        await rr.register_handler("test.service", handler)
        
        assert "test.service" in rr._handlers
        
        await rr.stop()
        await bus.stop()

    @pytest.mark.asyncio
    async def test_unregister_handler_not_registered(self):
        """Test unregister_handler when handler not registered"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        # Should not raise
        await rr.unregister_handler("nonexistent.service")
        
        await rr.stop()
        await bus.stop()

    @pytest.mark.asyncio
    async def test_request_not_running(self):
        """Test request when service not running"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        # Don't start
        
        with pytest.raises(RequestResponseError, match="Request/Response service is not running"):
            await rr.request("test.service", {"data": 42})
        
        await bus.stop()

    @pytest.mark.asyncio
    async def test_request_no_handler(self):
        """Test request to service with no handler"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            # Request to non-existent service should timeout
            with pytest.raises(RequestTimeoutError):
                await rr.request("nonexistent.service", {"data": 42}, timeout=0.1)
        finally:
            await rr.stop()
            await bus.stop()

    @pytest.mark.asyncio
    async def test_handle_response_with_error(self):
        """Test _handle_response with error in response data"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        try:
            from plugin_adk.core.models.events import Event, EventType
            
            # Create future for request
            future = asyncio.Future()
            rr._pending_requests["test-id"] = future
            
            # Create response event with error
            response_event = Event(
                topic="response.test-id",
                event_type=EventType.MESSAGE,
                data={
                    "request_id": "test-id",
                    "error": "Test error",
                    "data": None
                },
            )
            
            await rr._handle_response(response_event)
            
            # Future should be set with error
            assert future.done()
            with pytest.raises(RequestResponseError, match="Test error"):
                await future
        finally:
            await rr.stop()
            await bus.stop()

    @pytest.mark.asyncio
    async def test_stop_cancels_pending_requests(self):
        """Test stop() cancels pending requests"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(bus)
        await rr.start()
        
        # Create a pending request
        future = asyncio.Future()
        rr._pending_requests["test-id"] = future
        
        await rr.stop()
        
        # Future should be cancelled
        assert future.cancelled()
        assert len(rr._pending_requests) == 0
        
        await bus.stop()

    @pytest.mark.asyncio
    async def test_custom_topic_prefixes(self):
        """Test RequestResponse with custom topic prefixes"""
        bus = MemoryEventBus()
        await bus.start()
        
        rr = RequestResponse(
            bus,
            request_topic_prefix="custom.request",
            response_topic_prefix="custom.response"
        )
        await rr.start()
        
        try:
            async def handler(request: dict) -> dict:
                return {"result": request["data"] * 2}
            
            await rr.register_handler("test.service", handler)
            
            response = await rr.request("test.service", {"data": 21})
            assert response["result"] == 42
        finally:
            await rr.stop()
            await bus.stop()

