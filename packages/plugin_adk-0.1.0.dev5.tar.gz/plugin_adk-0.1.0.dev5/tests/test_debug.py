
import pytest
import plugin_adk.core.ai.embedding as embedding_module

def test_debug_environment():
    print(f"LITELLM_AVAILABLE: {embedding_module.LITELLM_AVAILABLE}")
    print(f"Module attributes: {dir(embedding_module)}")
    assert embedding_module.LITELLM_AVAILABLE
    assert hasattr(embedding_module, 'aembedding')
