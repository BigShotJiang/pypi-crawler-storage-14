"""
Unit tests for Plugin SDK Configuration.
"""

import pytest
import asyncio
import os
from unittest.mock import Mock, AsyncMock, patch, MagicMock

from plugin_adk.config import SDKConfig, create_manager, create_distributed_manager, create_hybrid_manager
from plugin_adk.core.plugin.manager import PluginManager


class TestSDKConfig:
    """Tests for SDKConfig"""
    
    def test_sdk_config_defaults(self):
        """Test SDKConfig with default values"""
        config = SDKConfig()
        
        assert config.discovery_mode == 'memory'
        assert config.event_bus_mode == 'memory'
        assert config.redis_host == 'localhost'
        assert config.redis_port == 6379
        assert config.redis_db == 0
        assert config.redis_password is None
        assert config.redis_url is None
        assert config.storage_mode == 'sqlite'
        assert config.sqlite_path == 'data/storage.db'
        assert config.enable_memory is False
        assert config.memory_provider == 'lancedb'
        assert config.lancedb_path == 'data/lancedb'
        assert config.enable_security is True
    
    def test_sdk_config_custom_values(self):
        """Test SDKConfig with custom values"""
        config = SDKConfig(
            discovery_mode='redis',
            event_bus_mode='redis',
            redis_host='redis.example.com',
            redis_port=6380,
            redis_db=1,
            redis_password='secret',
            storage_mode='memory',
            enable_memory=True,
            enable_security=False
        )
        
        assert config.discovery_mode == 'redis'
        assert config.event_bus_mode == 'redis'
        assert config.redis_host == 'redis.example.com'
        assert config.redis_port == 6380
        assert config.redis_db == 1
        assert config.redis_password == 'secret'
        assert config.storage_mode == 'memory'
        assert config.enable_memory is True
        assert config.enable_security is False
    
    def test_sdk_config_from_env(self):
        """Test SDKConfig.from_env()"""
        env_vars = {
            'DISCOVERY_MODE': 'redis',
            'EVENT_BUS_MODE': 'redis',
            'REDIS_HOST': 'test-host',
            'REDIS_PORT': '6380',
            'REDIS_DB': '2',
            'REDIS_PASSWORD': 'test-password',
            'REDIS_URL': 'redis://test-host:6380/2',
            'STORAGE_MODE': 'memory',
            'SQLITE_PATH': 'test.db',
            'ENABLE_MEMORY': 'true',
            'MEMORY_PROVIDER': 'lancedb',
            'LANCEDB_PATH': 'test-lancedb'
        }
        
        with patch.dict(os.environ, env_vars):
            config = SDKConfig.from_env()
            
            assert config.discovery_mode == 'redis'
            assert config.event_bus_mode == 'redis'
            assert config.redis_host == 'test-host'
            assert config.redis_port == 6380
            assert config.redis_db == 2
            assert config.redis_password == 'test-password'
            assert config.redis_url == 'redis://test-host:6380/2'
            assert config.storage_mode == 'memory'
            assert config.sqlite_path == 'test.db'
            assert config.enable_memory is True
            assert config.memory_provider == 'lancedb'
            assert config.lancedb_path == 'test-lancedb'
    
    def test_sdk_config_from_env_defaults(self):
        """Test SDKConfig.from_env() with no env vars (uses defaults)"""
        # Remove relevant env vars (don't use clear=True to avoid clearing all env)
        env_vars_to_remove = [
            'DISCOVERY_MODE', 'EVENT_BUS_MODE', 'REDIS_HOST', 'REDIS_PORT',
            'REDIS_DB', 'REDIS_PASSWORD', 'REDIS_URL', 'STORAGE_MODE',
            'SQLITE_PATH', 'ENABLE_MEMORY', 'MEMORY_PROVIDER', 'LANCEDB_PATH'
        ]
        
        # Save original values
        original_values = {k: os.environ.get(k) for k in env_vars_to_remove if k in os.environ}
        
        try:
            # Remove env vars
            for k in env_vars_to_remove:
                os.environ.pop(k, None)
            
            config = SDKConfig.from_env()
            
            assert config.discovery_mode == 'memory'
            assert config.event_bus_mode == 'memory'
            assert config.redis_host == 'localhost'
            assert config.redis_port == 6379
            assert config.redis_db == 0
            assert config.storage_mode == 'sqlite'
            assert config.enable_memory is False
        finally:
            # Restore original values
            for k, v in original_values.items():
                if v is not None:
                    os.environ[k] = v
    
    def test_get_redis_pool_config_from_url(self):
        """Test get_redis_pool_config() with redis_url"""
        config = SDKConfig(
            redis_url='redis://user:pass@redis.example.com:6380/3'
        )
        
        pool_config = config.get_redis_pool_config()
        
        assert pool_config.host == 'redis.example.com'
        assert pool_config.port == 6380
        assert pool_config.db == 3
        assert pool_config.password == 'pass'
    
    def test_get_redis_pool_config_from_url_no_password(self):
        """Test get_redis_pool_config() with redis_url without password"""
        config = SDKConfig(
            redis_url='redis://redis.example.com:6380/3',
            redis_password='fallback-password'
        )
        
        pool_config = config.get_redis_pool_config()
        
        assert pool_config.host == 'redis.example.com'
        assert pool_config.port == 6380
        assert pool_config.db == 3
        assert pool_config.password == 'fallback-password'
    
    def test_get_redis_pool_config_from_url_root_path(self):
        """Test get_redis_pool_config() with redis_url with root path"""
        config = SDKConfig(
            redis_url='redis://localhost:6379/',
            redis_db=5  # Should use this as fallback
        )
        
        pool_config = config.get_redis_pool_config()
        
        assert pool_config.host == 'localhost'
        assert pool_config.port == 6379
        assert pool_config.db == 5  # Fallback to config value
    
    def test_get_redis_pool_config_without_url(self):
        """Test get_redis_pool_config() without redis_url"""
        config = SDKConfig(
            redis_host='custom-host',
            redis_port=6380,
            redis_db=2,
            redis_password='custom-password'
        )
        
        pool_config = config.get_redis_pool_config()
        
        assert pool_config.host == 'custom-host'
        assert pool_config.port == 6380
        assert pool_config.db == 2
        assert pool_config.password == 'custom-password'


class TestCreateManager:
    """Tests for create_manager factory function"""
    
    @pytest.mark.asyncio
    async def test_create_manager_default(self):
        """Test create_manager() with default config"""
        manager = await create_manager()
        
        assert isinstance(manager, PluginManager)
        assert manager.event_bus is not None
        assert manager.service_discovery is not None
    
    @pytest.mark.asyncio
    async def test_create_manager_memory_mode(self):
        """Test create_manager() with memory mode"""
        config = SDKConfig(
            discovery_mode='memory',
            event_bus_mode='memory'
        )
        
        manager = await create_manager(config)
        
        assert isinstance(manager, PluginManager)
        assert manager.event_bus is not None
        assert manager.service_discovery is not None
        
        # Cleanup
        if manager.service_discovery:
            await manager.service_discovery.stop()
        if manager.event_bus:
            await manager.event_bus.stop()
    
    @pytest.mark.asyncio
    async def test_create_manager_smart_mode(self):
        """Test create_manager() with smart discovery mode"""
        config = SDKConfig(
            discovery_mode='smart',
            event_bus_mode='memory',
            sqlite_path='test_smart.db'
        )
        
        # Mock Redis to avoid connection
        with patch('plugin_adk.config.RedisDiscoveryBackend') as mock_redis_backend:
            mock_backend = AsyncMock()
            mock_backend.start = AsyncMock()
            mock_redis_backend.return_value = mock_backend
            
            manager = await create_manager(config)
            
            assert isinstance(manager, PluginManager)
            
            # Cleanup
            if manager.service_discovery:
                await manager.service_discovery.stop()
            if manager.event_bus:
                await manager.event_bus.stop()
    
    @pytest.mark.asyncio
    async def test_create_manager_with_sqlite_storage(self):
        """Test create_manager() with SQLite storage"""
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            config = SDKConfig(
                storage_mode='sqlite',
                sqlite_path=db_path
            )
            
            manager = await create_manager(config)
            
            assert isinstance(manager, PluginManager)
            assert manager.storage is not None
            
            # Cleanup
            if manager.storage:
                await manager.storage.stop()
            if manager.service_discovery:
                await manager.service_discovery.stop()
            if manager.event_bus:
                await manager.event_bus.stop()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @pytest.mark.asyncio
    async def test_create_manager_with_lancedb_memory(self):
        """Test create_manager() with LanceDB memory"""
        import tempfile
        import shutil
        
        memory_path = tempfile.mkdtemp()
        
        try:
            config = SDKConfig(
                enable_memory=True,
                memory_provider='lancedb',
                lancedb_path=memory_path
            )
            
            # Skip if lancedb not available
            try:
                manager = await create_manager(config)
                
                assert isinstance(manager, PluginManager)
                # Memory may be None if lancedb not installed
                
                # Cleanup
                if manager.memory:
                    await manager.memory.stop()
                if manager.service_discovery:
                    await manager.service_discovery.stop()
                if manager.event_bus:
                    await manager.event_bus.stop()
            except ImportError:
                pytest.skip("lancedb not installed")
        finally:
            if os.path.exists(memory_path):
                shutil.rmtree(memory_path)


class TestCreateDistributedManager:
    """Tests for create_distributed_manager convenience function"""
    
    @pytest.mark.asyncio
    async def test_create_distributed_manager_with_url(self):
        """Test create_distributed_manager() with redis_url"""
        # Mock Redis to avoid connection
        with patch('plugin_adk.config.RedisDiscoveryBackend') as mock_redis_backend, \
             patch('plugin_adk.config.RedisEventBus') as mock_redis_bus:
            
            mock_backend = AsyncMock()
            mock_backend.start = AsyncMock()
            mock_redis_backend.return_value = mock_backend
            
            mock_bus = AsyncMock()
            mock_bus.start = AsyncMock()
            mock_redis_bus.return_value = mock_bus
            
            manager = await create_distributed_manager(
                redis_url='redis://localhost:6379'
            )
            
            assert isinstance(manager, PluginManager)
            
            # Cleanup
            if manager.service_discovery:
                await manager.service_discovery.stop()
            if manager.event_bus:
                await manager.event_bus.stop()
    
    @pytest.mark.asyncio
    async def test_create_distributed_manager_with_host_port(self):
        """Test create_distributed_manager() with host and port"""
        # Mock Redis to avoid connection
        with patch('plugin_adk.config.RedisDiscoveryBackend') as mock_redis_backend, \
             patch('plugin_adk.config.RedisEventBus') as mock_redis_bus:
            
            mock_backend = AsyncMock()
            mock_backend.start = AsyncMock()
            mock_redis_backend.return_value = mock_backend
            
            mock_bus = AsyncMock()
            mock_bus.start = AsyncMock()
            mock_redis_bus.return_value = mock_bus
            
            manager = await create_distributed_manager(
                redis_host='custom-host',
                redis_port=6380
            )
            
            assert isinstance(manager, PluginManager)
            
            # Cleanup
            if manager.service_discovery:
                await manager.service_discovery.stop()
            if manager.event_bus:
                await manager.event_bus.stop()


class TestCreateHybridManager:
    """Tests for create_hybrid_manager convenience function"""
    
    @pytest.mark.asyncio
    async def test_create_hybrid_manager_memory_discovery_redis_events(self):
        """Test create_hybrid_manager() with memory discovery and Redis events"""
        # Mock Redis to avoid connection
        with patch('plugin_adk.config.RedisEventBus') as mock_redis_bus:
            mock_bus = AsyncMock()
            mock_bus.start = AsyncMock()
            mock_redis_bus.return_value = mock_bus
            
            manager = await create_hybrid_manager(
                discovery_mode='memory',
                event_bus_mode='redis',
                redis_url='redis://localhost:6379'
            )
            
            assert isinstance(manager, PluginManager)
            assert manager.service_discovery is not None
            assert manager.event_bus is not None
            
            # Cleanup
            if manager.service_discovery:
                await manager.service_discovery.stop()
            if manager.event_bus:
                await manager.event_bus.stop()
    
    @pytest.mark.asyncio
    async def test_create_hybrid_manager_redis_discovery_memory_events(self):
        """Test create_hybrid_manager() with Redis discovery and memory events"""
        # Mock Redis to avoid connection
        with patch('plugin_adk.config.RedisDiscoveryBackend') as mock_redis_backend:
            mock_backend = AsyncMock()
            mock_backend.start = AsyncMock()
            mock_redis_backend.return_value = mock_backend
            
            manager = await create_hybrid_manager(
                discovery_mode='redis',
                event_bus_mode='memory',
                redis_url='redis://localhost:6379'
            )
            
            assert isinstance(manager, PluginManager)
            assert manager.service_discovery is not None
            assert manager.event_bus is not None
            
            # Cleanup
            if manager.service_discovery:
                await manager.service_discovery.stop()
            if manager.event_bus:
                await manager.event_bus.stop()

