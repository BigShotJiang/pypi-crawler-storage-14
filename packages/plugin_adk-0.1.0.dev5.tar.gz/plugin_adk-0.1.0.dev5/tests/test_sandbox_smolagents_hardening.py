import pytest
from unittest.mock import MagicMock, patch
import sys

from plugin_adk.core.sandbox.smolagents_sandbox import SmolagentsSandbox, SandboxError
from plugin_adk.core.models.plugins import SandboxConfig

class MockTool:
    def __init__(self, name, description, func):
        self.name = name
        self.description = description
        self.func = func

class TestSmolagentsSandboxHardening:
    
    @pytest.fixture
    def mock_smolagents(self):
        with patch.dict(sys.modules, {'smolagents': MagicMock()}):
            with patch('plugin_adk.core.sandbox.smolagents_sandbox.HAS_SMOLAGENTS', True):
                yield

    @pytest.fixture
    def mock_no_smolagents(self):
        with patch('plugin_adk.core.sandbox.smolagents_sandbox.HAS_SMOLAGENTS', False):
            yield

    def test_init_without_smolagents(self, mock_no_smolagents):
        """Test initialization when smolagents is not installed"""
        with pytest.raises(SandboxError, match="smolagents is not installed"):
            SmolagentsSandbox()

    def test_add_tool_resets_agent(self, mock_smolagents):
        """Test that add_tool resets the internal agent"""
        sandbox = SmolagentsSandbox()
        
        # Force agent creation
        with patch('plugin_adk.core.sandbox.smolagents_sandbox.CodeAgent') as MockAgent:
            sandbox._create_agent()
            assert sandbox._agent is not None
            
            # Add tool
            tool = MockTool("test", "desc", lambda: None)
            sandbox.add_tool(tool)
            
            # Agent should be reset to None
            assert sandbox._agent is None
            assert tool in sandbox.tools

    def test_set_llm_resets_agent(self, mock_smolagents):
        """Test that set_llm resets the internal agent"""
        sandbox = SmolagentsSandbox()
        
        # Force agent creation
        with patch('plugin_adk.core.sandbox.smolagents_sandbox.CodeAgent') as MockAgent:
            sandbox._create_agent()
            assert sandbox._agent is not None
            
            # Set LLM
            llm = MagicMock()
            sandbox.set_llm(llm)
            
            # Agent should be reset to None
            assert sandbox._agent is None
            assert sandbox.llm == llm

    @pytest.mark.asyncio
    async def test_tool_func_error_no_sdk(self, mock_smolagents):
        """Test tool function raises RuntimeError when SDK is missing"""
        # Create sandbox with a mock service info but NO SDK
        sandbox = SmolagentsSandbox(sdk=None)
        
        service_info = {
            "description": "Test Service",
            "parameters": {}
        }
        
        # Mock Tool class to capture the function
        with patch('plugin_adk.core.sandbox.smolagents_sandbox.Tool') as MockToolClass:
            # Manually create tool from service
            sandbox._create_tool_from_service("test_service", service_info)
            
            # Get the function passed to Tool constructor
            # call_args[1] is kwargs, 'func' is the key
            call_args = MockToolClass.call_args
            assert call_args is not None
            tool_func = call_args[1]['func']
            
            # Execute the tool function
            # It should raise RuntimeError because self.sdk is None
            with pytest.raises(RuntimeError, match="SDK not available"):
                await tool_func()

    @pytest.mark.asyncio
    async def test_tool_func_error_no_call_service(self, mock_smolagents):
        """Test tool function raises RuntimeError when SDK has no call_service"""
        # Create sandbox with a mock SDK that lacks call_service
        mock_sdk = MagicMock()
        del mock_sdk.call_service # Ensure it doesn't have the method
        
        sandbox = SmolagentsSandbox(sdk=mock_sdk)
        
        service_info = {
            "description": "Test Service",
            "parameters": {}
        }
        
        # Mock Tool class to capture the function
        with patch('plugin_adk.core.sandbox.smolagents_sandbox.Tool') as MockToolClass:
            sandbox._create_tool_from_service("test_service", service_info)
            
            call_args = MockToolClass.call_args
            assert call_args is not None
            tool_func = call_args[1]['func']
            
            # Execute the tool function
            with pytest.raises(RuntimeError, match="call_service not implemented"):
                await tool_func()
