"""
Tests for cache router coverage.
"""

import pytest
import time
from unittest.mock import Mock, patch
from plugin_adk.core.storage.cache_router import IntelligentRouter
from plugin_adk.core.storage.cache_models import CacheLevel

class TestIntelligentRouterCoverage:
    
    def test_route_predicted_level(self):
        """Test route when prediction returns a level - line 79"""
        router = IntelligentRouter()
        
        # Mock predict_best_level to return L2
        with patch.object(router, 'predict_best_level', return_value=CacheLevel.L2):
            level = router.route("key", "read")
            assert level == CacheLevel.L2

    def test_route_default_read(self):
        """Test route default for read operation - line 84"""
        router = IntelligentRouter()
        
        # Mock predict_best_level to return None
        with patch.object(router, 'predict_best_level', return_value=None):
            level = router.route("key", "read")
            assert level == CacheLevel.L1

    def test_route_default_write(self):
        """Test route default for write operation - line 87"""
        router = IntelligentRouter()
        with patch.object(router, 'predict_best_level', return_value=None):
            level = router.route("key", "write")
            assert level == CacheLevel.L1

    def test_predict_best_level_empty_history(self):
        """Test predict_best_level with empty history - line 103"""
        router = IntelligentRouter()
        level = router.predict_best_level("key_no_history")
        assert level is None

    def test_predict_best_level_calculation(self):
        """Test predict_best_level calculation - lines 113, 125-128, 134"""
        router = IntelligentRouter()
        
        # Add history: L1 has 1 hit 1 miss (50%), L2 has 2 hits 0 misses (100%)
        router.access_patterns["key"].append((CacheLevel.L1, True, time.time()))
        router.access_patterns["key"].append((CacheLevel.L1, False, time.time()))
        router.access_patterns["key"].append((CacheLevel.L2, True, time.time()))
        router.access_patterns["key"].append((CacheLevel.L2, True, time.time()))
        
        # L1 score: 0.5 + 0.3 = 0.8
        # L2 score: 1.0 + 0.2 = 1.2
        # Should pick L2
        
        level = router.predict_best_level("key")
        assert level == CacheLevel.L2

    def test_learn_from_access(self):
        """Test learn_from_access - lines 150-168"""
        router = IntelligentRouter()
        
        # Test hit
        router.learn_from_access("key", CacheLevel.L1, True)
        
        assert len(router.access_patterns["key"]) == 1
        assert router.access_patterns["key"][0][0] == CacheLevel.L1
        assert router.access_patterns["key"][0][1] is True
        
        assert router.level_performance[CacheLevel.L1]["hits"] == 1
        assert router.level_performance[CacheLevel.L1]["misses"] == 0
        
        assert router.key_frequency["key"] > 0
        assert "key" in router.key_last_access
        
        # Test miss
        router.learn_from_access("key", CacheLevel.L1, False)
        assert router.level_performance[CacheLevel.L1]["misses"] == 1

    def test_predict_best_level_no_scores(self):
        """Test predict_best_level when no scores calculated - line 131"""
        router = IntelligentRouter()
        
        # Add history but make it so no level has hits/misses (impossible with normal logic, but maybe with manual manipulation)
        # Actually, if history exists, we iterate it.
        # If we manually add history with a level that is NOT in [L1, L2, L3] loop?
        # Or if total is 0?
        
        # Let's add history for a level that is valid, but ensure total is 0? 
        # No, if it's in history, hit or miss is recorded.
        
        # If history is not empty, but the loop over [L1, L2, L3] finds no matching records in history?
        # Yes, if history contains records for a level NOT in [L1, L2, L3] (e.g. None or some other enum if it existed).
        # But history stores (level, hit, timestamp).
        
        # Let's try adding history for a fake level
        router.access_patterns["key"].append(("FAKE_LEVEL", True, time.time()))
        
        level = router.predict_best_level("key")
        assert level is None

    def test_get_key_frequency(self):
        """Test get_key_frequency - line 195"""
        router = IntelligentRouter()
        freq = router.get_key_frequency("nonexistent")
        assert freq == 0.0
        
        router.key_frequency["key"] = 5.0
        freq = router.get_key_frequency("key")
        assert freq == 5.0

    def test_get_level_performance(self):
        """Test get_level_performance - lines 207-212"""
        router = IntelligentRouter()
        
        # Manually set performance
        router.level_performance[CacheLevel.L1]["hits"] = 10
        router.level_performance[CacheLevel.L1]["misses"] = 5
        router.level_performance[CacheLevel.L1]["avg_latency"] = 0.1
        
        perf = router.get_level_performance(CacheLevel.L1)
        
        assert perf["hits"] == 10
        assert perf["misses"] == 5
        assert perf["total"] == 15
        assert perf["hit_rate"] == 10/15
        assert perf["avg_latency"] == 0.1
        
        # Test zero total
        perf_l2 = router.get_level_performance(CacheLevel.L2)
        assert perf_l2["hit_rate"] == 0.0

    def test_reset(self):
        """Test reset - lines 222-227"""
        router = IntelligentRouter()
        
        # Set some state
        router.access_patterns["key"].append((CacheLevel.L1, True, time.time()))
        router.key_frequency["key"] = 10.0
        router.key_last_access["key"] = time.time()
        router.level_performance[CacheLevel.L1]["hits"] = 10
        
        router.reset()
        
        assert len(router.access_patterns) == 0
        assert len(router.key_frequency) == 0
        assert len(router.key_last_access) == 0
        assert router.level_performance[CacheLevel.L1]["hits"] == 0
