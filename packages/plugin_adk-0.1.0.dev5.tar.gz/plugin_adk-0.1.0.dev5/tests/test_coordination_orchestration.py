"""
Tests for Task Orchestration.
"""

import pytest
import asyncio
from plugin_adk.core.coordination import (
    Orchestration,
    Task,
    TaskStatus,
    OrchestrationError,
)


class TestOrchestration:
    """Tests for Orchestration"""
    
    @pytest.mark.asyncio
    async def test_add_task(self):
        """Test adding tasks"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        task = await orchestration.add_task("t1", "Task 1", handler)
        
        assert task.task_id == "t1"
        assert task.name == "Task 1"
        assert task.status == TaskStatus.PENDING
    
    @pytest.mark.asyncio
    async def test_add_duplicate_task(self):
        """Test adding duplicate task"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        await orchestration.add_task("t1", "Task 1", handler)
        
        with pytest.raises(OrchestrationError):
            await orchestration.add_task("t1", "Task 1", handler)
    
    @pytest.mark.asyncio
    async def test_simple_execution(self):
        """Test simple task execution"""
        orchestration = Orchestration()
        
        async def task1():
            return "result1"
        
        await orchestration.add_task("t1", "Task 1", task1)
        
        results = await orchestration.execute()
        
        assert results["t1"] == "result1"
        assert orchestration.get_task_status("t1") == TaskStatus.COMPLETED
    
    @pytest.mark.asyncio
    async def test_dependency_execution(self):
        """Test execution with dependencies"""
        orchestration = Orchestration()
        
        async def task1():
            return "result1"
        
        async def task2(t1):
            return f"result2 from {t1}"
        
        await orchestration.add_task("t1", "Task 1", task1)
        await orchestration.add_task("t2", "Task 2", task2, dependencies={"t1"})
        
        results = await orchestration.execute()
        
        assert results["t1"] == "result1"
        assert results["t2"] == "result2 from result1"
    
    @pytest.mark.asyncio
    async def test_parallel_execution(self):
        """Test parallel execution of independent tasks"""
        orchestration = Orchestration()
        
        execution_order = []
        
        async def task1():
            await asyncio.sleep(0.1)
            execution_order.append("t1")
            return "result1"
        
        async def task2():
            await asyncio.sleep(0.1)
            execution_order.append("t2")
            return "result2"
        
        async def task3(t1, t2):
            execution_order.append("t3")
            return f"result3 from {t1} and {t2}"
        
        await orchestration.add_task("t1", "Task 1", task1)
        await orchestration.add_task("t2", "Task 2", task2)
        await orchestration.add_task("t3", "Task 3", task3, dependencies={"t1", "t2"})
        
        results = await orchestration.execute()
        
        assert results["t1"] == "result1"
        assert results["t2"] == "result2"
        assert results["t3"] == "result3 from result1 and result2"
        
        # t1 and t2 should execute in parallel (order may vary)
        assert "t1" in execution_order
        assert "t2" in execution_order
        assert execution_order[-1] == "t3"  # t3 should be last
    
    @pytest.mark.asyncio
    async def test_task_failure(self):
        """Test task failure handling"""
        orchestration = Orchestration()
        
        async def task1():
            raise ValueError("Task failed")
        
        async def task2():
            return "result2"
        
        await orchestration.add_task("t1", "Task 1", task1)
        await orchestration.add_task("t2", "Task 2", task2, dependencies={"t1"})
        
        with pytest.raises(OrchestrationError):
            await orchestration.execute()
        
        assert orchestration.get_task_status("t1") == TaskStatus.FAILED
        assert "t1" in orchestration.get_failed_tasks()
    
    @pytest.mark.asyncio
    async def test_validate_dependencies(self):
        """Test dependency validation"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        await orchestration.add_task("t1", "Task 1", handler)
        await orchestration.add_task("t2", "Task 2", handler, dependencies={"t1"})
        
        is_valid, error = orchestration.validate_dependencies()
        assert is_valid is True
        assert error is None
    
    @pytest.mark.asyncio
    async def test_validate_missing_dependency(self):
        """Test validation with missing dependency"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        await orchestration.add_task("t1", "Task 1", handler, dependencies={"nonexistent"})
        
        is_valid, error = orchestration.validate_dependencies()
        assert is_valid is False
        assert "nonexistent" in error
    
    @pytest.mark.asyncio
    async def test_validate_circular_dependency(self):
        """Test validation with circular dependency"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        await orchestration.add_task("t1", "Task 1", handler, dependencies={"t2"})
        await orchestration.add_task("t2", "Task 2", handler, dependencies={"t1"})
        
        is_valid, error = orchestration.validate_dependencies()
        assert is_valid is False
        assert "Circular dependency" in error
    
    @pytest.mark.asyncio
    async def test_get_task(self):
        """Test getting task"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        await orchestration.add_task("t1", "Task 1", handler)
        
        task = orchestration.get_task("t1")
        assert task is not None
        assert task.task_id == "t1"
        
        task = orchestration.get_task("nonexistent")
        assert task is None
    
    @pytest.mark.asyncio
    async def test_remove_task(self):
        """Test removing task"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        await orchestration.add_task("t1", "Task 1", handler)
        await orchestration.add_task("t2", "Task 2", handler)
        
        result = await orchestration.remove_task("t1")
        assert result is True
        
        task = orchestration.get_task("t1")
        assert task is None
    
    @pytest.mark.asyncio
    async def test_remove_task_with_dependency(self):
        """Test removing task with dependencies"""
        orchestration = Orchestration()
        
        async def handler():
            return "result"
        
        await orchestration.add_task("t1", "Task 1", handler)
        await orchestration.add_task("t2", "Task 2", handler, dependencies={"t1"})
        
        with pytest.raises(OrchestrationError):
            await orchestration.remove_task("t1")

