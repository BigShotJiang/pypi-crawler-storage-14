"""
Unit tests for Storage Interface.
"""

import pytest
from plugin_adk.core.storage.interface import (
    StorageType,
    StorageConfig,
    StorageInterface,
    VectorStorageInterface,
    GraphStorageInterface,
    CacheStorageInterface,
    StorageAdapter,
)


class TestStorageType:
    """Tests for StorageType enum"""
    
    def test_storage_type_values(self):
        """Test StorageType enum values"""
        assert StorageType.VECTOR == "vector"
        assert StorageType.GRAPH == "graph"
        assert StorageType.CACHE == "cache"
        assert StorageType.DOCUMENT == "document"
    
    def test_storage_type_enum(self):
        """Test StorageType enum membership"""
        assert isinstance(StorageType.VECTOR, str)
        assert isinstance(StorageType.GRAPH, str)
        assert isinstance(StorageType.CACHE, str)
        assert isinstance(StorageType.DOCUMENT, str)


class TestStorageConfig:
    """Tests for StorageConfig"""
    
    def test_storage_config_defaults(self):
        """Test StorageConfig with defaults"""
        config = StorageConfig(storage_type=StorageType.VECTOR)
        
        assert config.storage_type == StorageType.VECTOR
        assert config.connection_string is None
        assert config.host is None
        assert config.port is None
        assert config.database is None
        assert config.username is None
        assert config.password is None
        assert config.timeout == 30
        assert config.max_connections == 10
        assert config.metadata == {}
    
    def test_storage_config_with_all_params(self):
        """Test StorageConfig with all parameters"""
        metadata = {"key": "value"}
        config = StorageConfig(
            storage_type=StorageType.GRAPH,
            connection_string="bolt://localhost:7687",
            host="localhost",
            port=7687,
            database="neo4j",
            username="user",
            password="pass",
            timeout=60,
            max_connections=20,
            metadata=metadata,
        )
        
        assert config.storage_type == StorageType.GRAPH
        assert config.connection_string == "bolt://localhost:7687"
        assert config.host == "localhost"
        assert config.port == 7687
        assert config.database == "neo4j"
        assert config.username == "user"
        assert config.password == "pass"
        assert config.timeout == 60
        assert config.max_connections == 20
        assert config.metadata == metadata
    
    def test_storage_config_metadata_default_factory(self):
        """Test StorageConfig metadata default factory"""
        config1 = StorageConfig(storage_type=StorageType.CACHE)
        config2 = StorageConfig(storage_type=StorageType.CACHE)
        
        # Metadata should be separate dicts
        config1.metadata["key1"] = "value1"
        assert "key1" not in config2.metadata


class TestStorageAdapter:
    """Tests for StorageAdapter"""
    
    def test_storage_adapter_init(self):
        """Test StorageAdapter initialization"""
        config = StorageConfig(storage_type=StorageType.VECTOR)
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return self._connected
            async def get_status(self):
                return {"connected": self._connected}
        
        adapter = TestAdapter(config)
        assert adapter.config == config
        assert adapter._connected is False
    
    def test_storage_adapter_validate_config_valid(self):
        """Test _validate_config with valid config"""
        config = StorageConfig(storage_type=StorageType.VECTOR)
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return self._connected
            async def get_status(self):
                return {"connected": self._connected}
        
        adapter = TestAdapter(config)
        assert adapter._validate_config() is True
    
    def test_storage_adapter_validate_config_invalid(self):
        """Test _validate_config with invalid config"""
        # Create config without storage_type (should not be possible with dataclass)
        # Instead, test with None storage_type by creating a mock config
        from unittest.mock import Mock
        config = Mock()
        config.storage_type = None
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return self._connected
            async def get_status(self):
                return {"connected": self._connected}
        
        adapter = TestAdapter(config)
        assert adapter._validate_config() is False


class TestStorageInterfaces:
    """Tests for storage interfaces (abstract classes)"""
    
    def test_storage_interface_is_abstract(self):
        """Test that StorageInterface is abstract"""
        with pytest.raises(TypeError):
            StorageInterface()
    
    def test_vector_storage_interface_is_abstract(self):
        """Test that VectorStorageInterface is abstract"""
        with pytest.raises(TypeError):
            VectorStorageInterface()
    
    def test_graph_storage_interface_is_abstract(self):
        """Test that GraphStorageInterface is abstract"""
        with pytest.raises(TypeError):
            GraphStorageInterface()
    
    def test_cache_storage_interface_is_abstract(self):
        """Test that CacheStorageInterface is abstract"""
        with pytest.raises(TypeError):
            CacheStorageInterface()
    
    @pytest.mark.asyncio
    async def test_storage_interface_implementation(self):
        """Test implementing StorageInterface"""
        class TestStorage(StorageInterface):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self):
                return {"status": "ok"}
        
        storage = TestStorage()
        assert await storage.connect() is True
        assert await storage.is_connected() is True
        assert await storage.disconnect() is True
        status = await storage.get_status()
        assert status["status"] == "ok"
    
    @pytest.mark.asyncio
    async def test_vector_storage_interface_implementation(self):
        """Test implementing VectorStorageInterface"""
        class TestVectorStorage(VectorStorageInterface):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self):
                return {"status": "ok"}
            async def create_collection(self, *args, **kwargs) -> bool:
                return True
            async def delete_collection(self, *args, **kwargs) -> bool:
                return True
            async def insert_vector(self, *args, **kwargs):
                return "vector_id"
            async def search_vectors(self, *args, **kwargs):
                return []
            async def delete_vector(self, *args, **kwargs) -> bool:
                return True
        
        storage = TestVectorStorage()
        assert await storage.create_collection("test", 128) is True
        assert await storage.insert_vector("test", [1.0, 2.0]) == "vector_id"
        assert await storage.search_vectors("test", [1.0, 2.0]) == []
        assert await storage.delete_vector("test", "vector_id") is True
        assert await storage.delete_collection("test") is True
    
    @pytest.mark.asyncio
    async def test_graph_storage_interface_implementation(self):
        """Test implementing GraphStorageInterface"""
        class TestGraphStorage(GraphStorageInterface):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self):
                return {"status": "ok"}
            async def create_node(self, *args, **kwargs):
                return "node_id"
            async def create_relationship(self, *args, **kwargs) -> bool:
                return True
            async def query(self, *args, **kwargs):
                return []
            async def delete_node(self, *args, **kwargs) -> bool:
                return True
        
        storage = TestGraphStorage()
        assert await storage.create_node("Person", {"name": "Alice"}) == "node_id"
        assert await storage.create_relationship("node1", "node2", "KNOWS") is True
        assert await storage.query("MATCH (n) RETURN n") == []
        assert await storage.delete_node("node_id") is True
    
    @pytest.mark.asyncio
    async def test_cache_storage_interface_implementation(self):
        """Test implementing CacheStorageInterface"""
        class TestCacheStorage(CacheStorageInterface):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self):
                return {"status": "ok"}
            async def get(self, *args, **kwargs):
                return None
            async def set(self, *args, **kwargs) -> bool:
                return True
            async def delete(self, *args, **kwargs) -> bool:
                return True
            async def exists(self, *args, **kwargs) -> bool:
                return False
            async def expire(self, *args, **kwargs) -> bool:
                return True
            async def keys(self, *args, **kwargs):
                return []
        
        storage = TestCacheStorage()
        assert await storage.get("key") is None
        assert await storage.set("key", "value") is True
        assert await storage.exists("key") is False
        assert await storage.expire("key", 60) is True
        assert await storage.delete("key") is True
        assert await storage.keys() == []
    
    def test_storage_adapter_validate_config_with_storage_type(self):
        """Test StorageAdapter._validate_config with storage_type"""
        from plugin_adk.core.storage.interface import StorageAdapter, StorageConfig, StorageType
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self) -> dict:
                return {}
        
        config = StorageConfig(storage_type=StorageType.VECTOR)
        adapter = TestAdapter(config)
        
        # Should validate successfully
        assert adapter._validate_config() is True
    
    def test_storage_adapter_validate_config_without_storage_type(self):
        """Test StorageAdapter._validate_config without storage_type"""
        from plugin_adk.core.storage.interface import StorageAdapter, StorageConfig
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self) -> dict:
                return {}
        
        # Create config without storage_type
        config = StorageConfig.__new__(StorageConfig)
        config.storage_type = None
        config.connection_string = None
        config.host = None
        config.port = None
        config.database = None
        config.username = None
        config.password = None
        config.timeout = 30
        config.max_connections = 10
        config.metadata = {}
        
        adapter = TestAdapter(config)
        
        # Should fail validation
        assert adapter._validate_config() is False
    
    def test_storage_adapter_validate_config_with_empty_storage_type(self):
        """Test StorageAdapter._validate_config with empty storage_type"""
        from plugin_adk.core.storage.interface import StorageAdapter, StorageConfig
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self) -> dict:
                return {}
        
        # Create config with empty storage_type (falsy value)
        config = StorageConfig.__new__(StorageConfig)
        config.storage_type = ""  # Empty string is falsy
        config.connection_string = None
        config.host = None
        config.port = None
        config.database = None
        config.username = None
        config.password = None
        config.timeout = 30
        config.max_connections = 10
        config.metadata = {}
        
        adapter = TestAdapter(config)
        
        # Should fail validation (empty string is falsy)
        assert adapter._validate_config() is False
    
    def test_storage_adapter_init_stores_config(self):
        """Test StorageAdapter.__init__ stores config"""
        from plugin_adk.core.storage.interface import StorageAdapter, StorageConfig, StorageType
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self) -> dict:
                return {}
        
        config = StorageConfig(storage_type=StorageType.VECTOR)
        adapter = TestAdapter(config)
        
        # Should store config
        assert adapter.config is config
        # Should initialize _connected to False
        assert adapter._connected is False
    
    @pytest.mark.asyncio
    async def test_storage_adapter_validate_config_with_falsy_storage_type(self):
        """Test StorageAdapter._validate_config with falsy storage_type values"""
        from plugin_adk.core.storage.interface import StorageAdapter, StorageConfig
        
        class TestAdapter(StorageAdapter):
            async def connect(self) -> bool:
                return True
            async def disconnect(self) -> bool:
                return True
            async def is_connected(self) -> bool:
                return True
            async def get_status(self) -> dict:
                return {}
        
        # Test with various falsy values
        falsy_values = [None, "", 0, False, []]
        for falsy_value in falsy_values:
            config = StorageConfig.__new__(StorageConfig)
            config.storage_type = falsy_value
            config.connection_string = None
            config.host = None
            config.port = None
            config.database = None
            config.username = None
            config.password = None
            config.timeout = 30
            config.max_connections = 10
            config.metadata = {}
            
            adapter = TestAdapter(config)
            # Should fail validation for falsy values
            assert adapter._validate_config() is False
    
    @pytest.mark.asyncio
    async def test_storage_interface_abstract_methods_cannot_be_instantiated(self):
        """Test that StorageInterface cannot be instantiated directly"""
        from plugin_adk.core.storage.interface import StorageInterface
        from abc import ABC
        
        # StorageInterface is abstract, cannot be instantiated
        with pytest.raises(TypeError):
            StorageInterface()
    
    @pytest.mark.asyncio
    async def test_vector_storage_interface_abstract_methods(self):
        """Test VectorStorageInterface abstract methods"""
        from plugin_adk.core.storage.interface import VectorStorageInterface
        
        # VectorStorageInterface is abstract, cannot be instantiated
        with pytest.raises(TypeError):
            VectorStorageInterface()
    
    @pytest.mark.asyncio
    async def test_graph_storage_interface_abstract_methods(self):
        """Test GraphStorageInterface abstract methods"""
        from plugin_adk.core.storage.interface import GraphStorageInterface
        
        # GraphStorageInterface is abstract, cannot be instantiated
        with pytest.raises(TypeError):
            GraphStorageInterface()
    
    @pytest.mark.asyncio
    async def test_cache_storage_interface_abstract_methods(self):
        """Test CacheStorageInterface abstract methods"""
        from plugin_adk.core.storage.interface import CacheStorageInterface
        
        # CacheStorageInterface is abstract, cannot be instantiated
        with pytest.raises(TypeError):
            CacheStorageInterface()
    
    @pytest.mark.asyncio
    async def test_storage_adapter_abstract_methods_cannot_be_instantiated(self):
        """Test that StorageAdapter cannot be instantiated directly"""
        from plugin_adk.core.storage.interface import StorageAdapter, StorageConfig, StorageType
        
        # StorageAdapter is abstract, cannot be instantiated
        config = StorageConfig(storage_type=StorageType.VECTOR)
        with pytest.raises(TypeError):
            StorageAdapter(config)

