"""
Unit tests for EmbeddingService.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from datetime import datetime

from plugin_adk.core.ai.embedding import EmbeddingService, EmbeddingModel, EmbeddingProvider
from plugin_adk.core.ai.token_tracker import TokenTracker, TokenUsage


@pytest.fixture
def token_tracker():
    """Create token tracker"""
    return TokenTracker()


@pytest.mark.asyncio
async def test_embedding_service_init_with_string_model(token_tracker):
    """Test EmbeddingService initialization with string model"""
    try:
        service = EmbeddingService(default_model="text-embedding-ada-002", token_tracker=token_tracker)
        assert service.default_model is not None
        assert service.default_model.name == "text-embedding-ada-002"
        assert service.default_model.provider == EmbeddingProvider.OPENAI
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_init_with_embedding_model(token_tracker):
    """Test EmbeddingService initialization with EmbeddingModel instance"""
    try:
        model = EmbeddingModel(name="text-embedding-ada-002", provider=EmbeddingProvider.OPENAI)
        service = EmbeddingService(default_model=model, token_tracker=token_tracker)
        assert service.default_model == model
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_init_no_litellm():
    """Test EmbeddingService initialization when litellm is not available"""
    with patch('plugin_adk.core.ai.embedding.LITELLM_AVAILABLE', False):
        with pytest.raises(ImportError, match="litellm is not installed"):
            EmbeddingService()


@pytest.mark.asyncio
async def test_embedding_service_embed_with_default_model(token_tracker):
    """Test embed with default model"""
    try:
        service = EmbeddingService(default_model="text-embedding-ada-002", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            result = await service.embed("Hello")
            
            assert isinstance(result, list)
            assert len(result) == 1
            assert len(result[0]) == 1536
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_with_string_model(token_tracker):
    """Test embed with string model parameter"""
    try:
        service = EmbeddingService(token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            # Set default model first
            service.default_model = EmbeddingModel(name="text-embedding-ada-002", provider=EmbeddingProvider.OPENAI)
            
            result = await service.embed("Hello", model="text-embedding-3-small")
            
            assert isinstance(result, list)
            # Verify model was passed
            mock_aembedding.assert_called_once()
            call_kwargs = mock_aembedding.call_args[1]
            assert call_kwargs["model"] == "text-embedding-3-small"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_with_embedding_model(token_tracker):
    """Test embed with EmbeddingModel parameter"""
    try:
        service = EmbeddingService(token_tracker=token_tracker)
        
        model = EmbeddingModel(
            name="text-embedding-3-small",
            provider=EmbeddingProvider.OPENAI,
            api_key="test-key",
            base_url="https://api.test.com",
            dimensions=1536
        )
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            result = await service.embed("Hello", model=model)
            
            assert isinstance(result, list)
            # Verify parameters were passed
            mock_aembedding.assert_called_once()
            call_kwargs = mock_aembedding.call_args[1]
            assert call_kwargs["model"] == "text-embedding-3-small"
            assert call_kwargs.get("api_key") == "test-key"
            assert call_kwargs.get("api_base") == "https://api.test.com"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_no_model_no_default(token_tracker):
    """Test embed with no model and no default"""
    try:
        service = EmbeddingService(token_tracker=token_tracker)
        service.default_model = None
        
        with pytest.raises(ValueError, match="No model specified"):
            await service.embed("Hello")
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_list_of_texts(token_tracker):
    """Test embed with list of texts"""
    try:
        service = EmbeddingService(default_model="text-embedding-ada-002", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock(), Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        mock_response.data[1].embedding = [0.2] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            result = await service.embed(["Hello", "World"])
            
            assert isinstance(result, list)
            assert len(result) == 2
            assert len(result[0]) == 1536
            assert len(result[1]) == 1536
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_single_string(token_tracker):
    """Test embed with single string (should be normalized to list)"""
    try:
        service = EmbeddingService(default_model="text-embedding-ada-002", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            result = await service.embed("Hello")
            
            assert isinstance(result, list)
            assert len(result) == 1
            # Verify input was normalized to list
            call_kwargs = mock_aembedding.call_args[1]
            assert isinstance(call_kwargs["input"], list)
            assert call_kwargs["input"] == ["Hello"]
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_exception(token_tracker):
    """Test embed exception handling"""
    try:
        service = EmbeddingService(default_model="text-embedding-ada-002", token_tracker=token_tracker)
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.side_effect = Exception("API error")
            
            with pytest.raises(Exception, match="API error"):
                await service.embed("Hello")
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_get_token_tracker(token_tracker):
    """Test get_token_tracker method"""
    try:
        service = EmbeddingService(token_tracker=token_tracker)
        assert service.get_token_tracker() == token_tracker
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_with_api_key(token_tracker):
    """Test embed with API key in model"""
    try:
        model = EmbeddingModel(
            name="text-embedding-ada-002",
            provider=EmbeddingProvider.OPENAI,
            api_key="test-api-key"
        )
        service = EmbeddingService(default_model=model, token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            await service.embed("Hello")
            
            # Verify API key was passed
            call_kwargs = mock_aembedding.call_args[1]
            assert call_kwargs.get("api_key") == "test-api-key"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_with_base_url(token_tracker):
    """Test embed with base_url in model"""
    try:
        model = EmbeddingModel(
            name="text-embedding-ada-002",
            provider=EmbeddingProvider.OPENAI,
            base_url="https://api.test.com"
        )
        service = EmbeddingService(default_model=model, token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            await service.embed("Hello")
            
            # Verify base_url was passed
            call_kwargs = mock_aembedding.call_args[1]
            assert call_kwargs.get("api_base") == "https://api.test.com"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_with_timeout(token_tracker):
    """Test embed with custom timeout"""
    try:
        model = EmbeddingModel(
            name="text-embedding-ada-002",
            provider=EmbeddingProvider.OPENAI,
            timeout=120
        )
        service = EmbeddingService(default_model=model, token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            await service.embed("Hello")
            
            # Verify timeout was passed
            call_kwargs = mock_aembedding.call_args[1]
            assert call_kwargs.get("timeout") == 120
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_with_kwargs(token_tracker):
    """Test embed with additional kwargs"""
    try:
        service = EmbeddingService(default_model="text-embedding-ada-002", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            await service.embed("Hello", custom_param="value")
            
            # Verify kwargs were passed
            call_kwargs = mock_aembedding.call_args[1]
            assert call_kwargs.get("custom_param") == "value"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_embedding_service_embed_token_tracking(token_tracker):
    """Test embed token usage tracking"""
    try:
        service = EmbeddingService(default_model="text-embedding-ada-002", token_tracker=token_tracker)
        
        mock_response = Mock()
        mock_response.data = [Mock()]
        mock_response.data[0].embedding = [0.1] * 1536
        
        with patch('plugin_adk.core.ai.embedding.aembedding', new_callable=AsyncMock) as mock_aembedding:
            mock_aembedding.return_value = mock_response
            
            await service.embed(["Hello", "World"])
            
            # Verify token usage was tracked
            total = await token_tracker.get_total_usage()
            assert total.total_tokens >= 0  # Should have tracked some tokens
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise

