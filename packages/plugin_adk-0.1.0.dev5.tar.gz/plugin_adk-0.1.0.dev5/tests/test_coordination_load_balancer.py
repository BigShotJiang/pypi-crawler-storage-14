"""
Tests for Load Balancer.
"""

import pytest
from plugin_adk.core.coordination import (
    LoadBalancer,
    LoadBalancingStrategy,
    RoundRobinLoadBalancer,
    RandomLoadBalancer,
    LeastConnectionsLoadBalancer,
    ServiceInfo,
    ServiceStatus,
)


class TestRoundRobinLoadBalancer:
    """Tests for RoundRobinLoadBalancer"""
    
    def test_round_robin_selection(self):
        """Test round-robin selection"""
        balancer = RoundRobinLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
            ServiceInfo("s3", "test", "http://localhost:8002", status=ServiceStatus.HEALTHY),
        ]
        
        # First selection
        selected1 = balancer.select(services)
        assert selected1.service_id == "s1"
        
        # Second selection
        selected2 = balancer.select(services)
        assert selected2.service_id == "s2"
        
        # Third selection
        selected3 = balancer.select(services)
        assert selected3.service_id == "s3"
        
        # Fourth selection (wraps around)
        selected4 = balancer.select(services)
        assert selected4.service_id == "s1"
    
    def test_round_robin_with_unhealthy(self):
        """Test round-robin with unhealthy services"""
        balancer = RoundRobinLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.UNHEALTHY),
            ServiceInfo("s3", "test", "http://localhost:8002", status=ServiceStatus.HEALTHY),
        ]
        
        # Should only select healthy services
        selected1 = balancer.select(services)
        assert selected1.service_id in ["s1", "s3"]
        
        selected2 = balancer.select(services)
        assert selected2.service_id in ["s1", "s3"]
        assert selected2.service_id != selected1.service_id


class TestRandomLoadBalancer:
    """Tests for RandomLoadBalancer"""
    
    def test_random_selection(self):
        """Test random selection"""
        balancer = RandomLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
            ServiceInfo("s3", "test", "http://localhost:8002", status=ServiceStatus.HEALTHY),
        ]
        
        # Random selection (should be one of the services)
        selected = balancer.select(services)
        assert selected is not None
        assert selected.service_id in ["s1", "s2", "s3"]
    
    def test_random_with_unhealthy(self):
        """Test random with unhealthy services"""
        balancer = RandomLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.UNHEALTHY),
        ]
        
        # Should only select healthy service
        selected = balancer.select(services)
        assert selected.service_id == "s1"


class TestLeastConnectionsLoadBalancer:
    """Tests for LeastConnectionsLoadBalancer"""
    
    def test_least_connections_selection(self):
        """Test least connections selection"""
        balancer = LeastConnectionsLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
        ]
        
        # First selection (both have 0 connections)
        selected1 = balancer.select(services)
        assert selected1 is not None
        
        # Record connection
        balancer.record_connection(selected1.service_id)
        
        # Second selection (should select the other service)
        selected2 = balancer.select(services)
        assert selected2.service_id != selected1.service_id
    
    def test_connection_tracking(self):
        """Test connection tracking"""
        balancer = LeastConnectionsLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
        ]
        
        # Record connections
        balancer.record_connection("s1")
        balancer.record_connection("s1")
        balancer.record_connection("s2")
        
        # Select should choose s2 (fewer connections)
        selected = balancer.select(services)
        assert selected.service_id == "s2"
        
        # Release connection
        balancer.release_connection("s1")
        
        # Now both have 1 connection, should select either
        selected = balancer.select(services)
        assert selected is not None


class TestLoadBalancer:
    """Tests for LoadBalancer"""
    
    def test_round_robin_strategy(self):
        """Test round-robin strategy"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.ROUND_ROBIN)
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
        ]
        
        selected1 = balancer.select(services)
        selected2 = balancer.select(services)
        
        assert selected1.service_id != selected2.service_id
    
    def test_random_strategy(self):
        """Test random strategy"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.RANDOM)
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
        ]
        
        selected = balancer.select(services)
        assert selected is not None
        assert selected.service_id in ["s1", "s2"]
    
    def test_least_connections_strategy(self):
        """Test least connections strategy"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.LEAST_CONNECTIONS)
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
        ]
        
        balancer.record_connection("s1")
        
        selected = balancer.select(services)
        assert selected.service_id == "s2"
    
    def test_strategy_change(self):
        """Test strategy change"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.ROUND_ROBIN)
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.HEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.HEALTHY),
        ]
        
        # Change strategy
        balancer.set_strategy(LoadBalancingStrategy.RANDOM)
        
        selected = balancer.select(services)
        assert selected is not None
    
    def test_empty_services(self):
        """Test with empty services list"""
        balancer = LoadBalancer()
        
        selected = balancer.select([])
        assert selected is None
    
    def test_all_unhealthy_services(self):
        """Test with all unhealthy services"""
        balancer = LoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.UNHEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.UNHEALTHY),
        ]
        
        selected = balancer.select(services)
        assert selected is None
    
    def test_base_load_balancer_abstract(self):
        """Test BaseLoadBalancer is abstract (line 56)"""
        from plugin_adk.core.coordination.load_balancer import BaseLoadBalancer
        
        # BaseLoadBalancer is abstract, cannot be instantiated
        with pytest.raises(TypeError):
            BaseLoadBalancer()
    
    def test_random_load_balancer_no_healthy_services(self):
        """Test RandomLoadBalancer with no healthy services (line 158)"""
        balancer = RandomLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.UNHEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.UNHEALTHY),
        ]
        
        selected = balancer.select(services)
        assert selected is None
    
    def test_least_connections_no_healthy_services(self):
        """Test LeastConnectionsLoadBalancer with no healthy services (line 200)"""
        balancer = LeastConnectionsLoadBalancer()
        
        services = [
            ServiceInfo("s1", "test", "http://localhost:8000", status=ServiceStatus.UNHEALTHY),
            ServiceInfo("s2", "test", "http://localhost:8001", status=ServiceStatus.UNHEALTHY),
        ]
        
        selected = balancer.select(services)
        assert selected is None
    
    def test_least_connections_get_connection_count(self):
        """Test LeastConnectionsLoadBalancer.get_connection_count (line 243)"""
        balancer = LeastConnectionsLoadBalancer()
        
        # Get count for non-existent service
        count = balancer.get_connection_count("nonexistent")
        assert count == 0
        
        # Record connection and get count
        balancer.record_connection("s1")
        count = balancer.get_connection_count("s1")
        assert count == 1
    
    def test_load_balancer_set_strategy_round_robin(self):
        """Test LoadBalancer.set_strategy with round-robin (line 321)"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.RANDOM)
        
        # Change to round-robin
        balancer.set_strategy(LoadBalancingStrategy.ROUND_ROBIN)
        
        assert isinstance(balancer._balancer, RoundRobinLoadBalancer)
        assert balancer.strategy == LoadBalancingStrategy.ROUND_ROBIN
    
    def test_load_balancer_set_strategy_random(self):
        """Test LoadBalancer.set_strategy with random (line 323)"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.ROUND_ROBIN)
        
        # Change to random
        balancer.set_strategy(LoadBalancingStrategy.RANDOM)
        
        assert isinstance(balancer._balancer, RandomLoadBalancer)
        assert balancer.strategy == LoadBalancingStrategy.RANDOM
    
    def test_load_balancer_set_strategy_least_connections(self):
        """Test LoadBalancer.set_strategy with least connections (line 325)"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.ROUND_ROBIN)
        
        # Change to least connections
        balancer.set_strategy(LoadBalancingStrategy.LEAST_CONNECTIONS)
        
        assert isinstance(balancer._balancer, LeastConnectionsLoadBalancer)
        assert balancer.strategy == LoadBalancingStrategy.LEAST_CONNECTIONS
    
    def test_load_balancer_release_connection(self):
        """Test LoadBalancer.release_connection (line 347-348)"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.LEAST_CONNECTIONS)
        
        # Record connection
        balancer.record_connection("s1")
        
        # Release connection
        balancer.release_connection("s1")
        
        # Should have 0 connections
        assert balancer._balancer.get_connection_count("s1") == 0
    
    def test_load_balancer_release_connection_not_least_connections(self):
        """Test LoadBalancer.release_connection when not using least connections strategy"""
        balancer = LoadBalancer(strategy=LoadBalancingStrategy.ROUND_ROBIN)
        
        # Release connection should not raise error
        balancer.release_connection("s1")
        
        # Should not affect anything
        assert True

