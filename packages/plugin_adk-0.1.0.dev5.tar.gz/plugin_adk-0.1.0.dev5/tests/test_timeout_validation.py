"""
Test timeout mechanism validation.

This test intentionally hangs to verify the pytest-timeout mechanism works.
"""

import pytest
import asyncio


@pytest.mark.asyncio
@pytest.mark.timeout(2)  # Should timeout after 2 seconds
async def test_timeout_mechanism_works():
    """
    Verify that pytest-timeout kills hanging tests.
    
    This test should FAIL with timeout error, proving the mechanism works.
    """
    # Intentionally sleep longer than timeout
    await asyncio.sleep(10)
    
    # This line should never be reached
    assert False, "This should never execute due to timeout"


@pytest.mark.asyncio
@pytest.mark.timeout(5)
async def test_timeout_mechanism_passes():
    """
    Verify that normal tests pass within timeout.
    """
    # Sleep less than timeout
    await asyncio.sleep(1)
    
    assert True, "This test should complete normally"
