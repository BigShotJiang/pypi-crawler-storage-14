"""
Integration tests for Runner and App.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from plugin_adk.core.runner import Runner, RunnerConfig, App, AppConfig
from plugin_adk.core.plugin.base import BasePlugin
from plugin_adk.core.plugin.manager import PluginManager
from plugin_adk.core.communication.event_sourcing import EventStore
from plugin_adk.core.ai import AICapabilitiesManager


class MockPlugin(BasePlugin):
    """Test plugin"""
    
    def __init__(self, name: str = "test_plugin"):
        super().__init__(
            name=name,
            version="1.0.0",
            description="Test plugin",
        )
    
    async def on_initialize(self) -> bool:
        return True
    
    async def on_start(self) -> bool:
        return True
    
    async def on_stop(self) -> bool:
        return True
        
    async def on_get_supported_actions(self):
        return ["test_method"]
    
    def test_method(self, data: str) -> str:
        """Test method"""
        return f"Processed: {data}"


@pytest.mark.asyncio
async def test_app_with_runner():
    """Test App with Runner integration"""
    # Create app config
    config = AppConfig(
        app_id="test-app",
        name="Test App",
        root_plugin="root_plugin",
    )
    
    # Create app
    app = App(config=config)
    
    # Verify runner is created
    assert app.runner is not None
    assert app.runner.config.session_id == "test-app"
    
    # Verify app is passed to runner
    assert app.runner.app == app


@pytest.mark.asyncio
async def test_app_plugin_management():
    """Test App plugin management"""
    # Create plugin manager
    manager = PluginManager()
    await manager.start_all()
    
    # Create test plugin
    plugin = MockPlugin("test_plugin")
    await manager.register_plugin(plugin)
    
    # Create app config
    config = AppConfig(
        app_id="test-app",
        name="Test App",
        root_plugin="test_plugin",
    )
    
    # Create app with plugin manager
    app = App(config=config, plugin_manager=manager)
    
    # Test get_plugin
    retrieved_plugin = await app.get_plugin("test_plugin")
    assert retrieved_plugin is not None
    assert retrieved_plugin.name == "test_plugin"
    
    # Test list_plugins
    plugins = await app.list_plugins()
    assert "test_plugin" in plugins


@pytest.mark.asyncio
async def test_runner_with_app_plugin_call():
    """Test Runner plugin call with App"""
    # Create plugin manager
    manager = PluginManager()
    await manager.start_all()
    
    # Create test plugin
    plugin = MockPlugin("test_plugin")
    await manager.register_plugin(plugin)
    await manager.start_plugin("test_plugin")
    
    # Create app config
    config = AppConfig(
        app_id="test-app",
        name="Test App",
        root_plugin="test_plugin",
    )
    
    # Create app
    app = App(config=config, plugin_manager=manager)
    await app.initialize()
    await app.start()
    
    # Get runner
    runner = app.get_runner()
    await runner.start()
    
    # Test plugin call via runner
    result = await runner._handle_plugin_call({
        "plugin_id": "test_plugin",
        "method": "test_method",
        "args": {"data": "test"},
    })
    
    assert "result" in result
    assert result["result"] == "Processed: test"


@pytest.mark.asyncio
async def test_app_lifecycle():
    """Test App lifecycle"""
    config = AppConfig(
        app_id="test-app",
        name="Test App",
    )
    
    app = App(config=config)
    
    # Initialize
    result = await app.initialize()
    assert result is True
    assert app._initialized is True
    
    # Start
    await app.start()
    assert app._running is True
    
    # Get status
    status = await app.get_status()
    assert status["initialized"] is True
    assert status["running"] is True
    
    # Stop
    await app.stop()
    assert app._running is False


@pytest.mark.asyncio
async def test_app_rewind():
    """Test App rewind functionality"""
    config = AppConfig(
        app_id="test-app",
        name="Test App",
    )
    
    app = App(config=config)
    await app.initialize()
    await app.start()
    
    # Rewind should work
    await app.rewind(to_step=0)
    
    # Verify runner state
    runner = app.get_runner()
    assert runner.current_step == 0

