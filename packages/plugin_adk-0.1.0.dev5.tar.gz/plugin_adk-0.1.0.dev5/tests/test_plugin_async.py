"""
Tests for AsyncPlugin.
"""

import pytest
import asyncio
from plugin_adk.core.plugin.async_plugin import AsyncPlugin
from plugin_adk.core.models.plugins import PluginStatus


class MockAsyncPlugin(AsyncPlugin):
    """Test async plugin implementation"""
    
    async def on_start_async(self):
        await asyncio.sleep(0.01)  # Simulate async work
    
    async def on_stop_async(self):
        await asyncio.sleep(0.01)  # Simulate async work


class TestAsyncPluginClass:
    """Tests for AsyncPlugin"""
    
    @pytest.mark.asyncio
    async def test_async_plugin_lifecycle(self):
        """Test async plugin lifecycle"""
        plugin = MockAsyncPlugin(name="test-async", version="1.0.0")
        
        # Start
        result = await plugin.start()
        assert result is True
        assert plugin.status == PluginStatus.RUNNING
        
        # Stop
        result = await plugin.stop()
        assert result is True
        assert plugin.status == PluginStatus.STOPPED
    
    @pytest.mark.asyncio
    async def test_background_tasks(self):
        """Test background tasks management"""
        plugin = MockAsyncPlugin(name="test-async", version="1.0.0")
        
        async def background_task():
            await asyncio.sleep(0.1)
            return "done"
        
        # Start background task
        task = plugin.start_background_task("test_task", background_task())
        assert task is not None
        assert "test_task" in plugin._background_tasks
        
        # Stop background task
        result = plugin.stop_background_task("test_task")
        assert result is True
        assert "test_task" not in plugin._background_tasks
        
        # Stop all tasks
        await plugin.start()
        plugin.start_background_task("task1", asyncio.sleep(1))
        plugin.start_background_task("task2", asyncio.sleep(1))
        await plugin.stop()  # Should stop all background tasks
        assert len(plugin._background_tasks) == 0
    
    @pytest.mark.asyncio
    async def test_start_background_task_duplicate(self):
        """Test starting duplicate background task"""
        plugin = MockAsyncPlugin(name="test-async", version="1.0.0")
        
        async def task():
            await asyncio.sleep(0.1)
        
        # Start first task
        task1 = plugin.start_background_task("test_task", task())
        assert task1 is not None
        
        # Start duplicate task (should cancel old one)
        task2 = plugin.start_background_task("test_task", task())
        assert task2 is not None
        assert task2 != task1
    
    @pytest.mark.asyncio
    async def test_stop_background_task_nonexistent(self):
        """Test stopping nonexistent background task"""
        plugin = MockAsyncPlugin(name="test-async", version="1.0.0")
        
        result = plugin.stop_background_task("nonexistent")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_on_start_async_exception(self):
        """Test on_start_async with exception"""
        class FailingAsyncPlugin(AsyncPlugin):
            async def on_start_async(self):
                raise ValueError("Startup failed")
            async def on_stop_async(self):
                pass
        
        plugin = FailingAsyncPlugin(name="failing", version="1.0.0")
        
        result = await plugin.start()
        assert result is False
    
    @pytest.mark.asyncio
    async def test_on_stop_async_exception(self):
        """Test on_stop_async with exception"""
        class FailingAsyncPlugin(AsyncPlugin):
            async def on_start_async(self):
                pass
            async def on_stop_async(self):
                raise ValueError("Stop failed")
        
        plugin = FailingAsyncPlugin(name="failing", version="1.0.0")
        await plugin.start()
        
        result = await plugin.stop()
        assert result is False
    
    @pytest.mark.asyncio
    async def test_on_event_async_exception(self):
        """Test on_event_async with exception"""
        from plugin_adk.core.models.events import Event
        
        class EventFailingPlugin(AsyncPlugin):
            async def on_start_async(self):
                pass
            async def on_stop_async(self):
                pass
            async def on_event_async(self, event):
                raise ValueError("Event handling failed")
        
        plugin = EventFailingPlugin(name="event-failing", version="1.0.0")
        await plugin.start()
        
        event = Event(topic="test", data={"key": "value"})
        result = await plugin.on_event(event)
        
        # Should return None on exception
        assert result is None
    
    @pytest.mark.asyncio
    async def test_stop_background_tasks_on_stop(self):
        """Test that background tasks are stopped on plugin stop"""
        plugin = MockAsyncPlugin(name="test-async", version="1.0.0")
        
        task_completed = [False]
        
        async def long_task():
            try:
                await asyncio.sleep(1.0)
                task_completed[0] = True
            except asyncio.CancelledError:
                pass
        
        await plugin.start()
        plugin.start_background_task("long_task", long_task())
        
        # Stop plugin - should cancel background task
        await plugin.stop()
        
        # Task should be cancelled, not completed
        await asyncio.sleep(0.1)  # Give it time to cancel
        assert task_completed[0] is False
        assert len(plugin._background_tasks) == 0
    
    @pytest.mark.asyncio
    async def test_on_event_async_default(self):
        """Test on_event_async default implementation"""
        from plugin_adk.core.models.events import Event
        
        class EventPlugin(AsyncPlugin):
            async def on_start_async(self):
                pass
            async def on_stop_async(self):
                pass
        
        plugin = EventPlugin(name="event-plugin", version="1.0.0")
        await plugin.start()
        
        event = Event(topic="test", data={"key": "value"})
        result = await plugin.on_event_async(event)
        
        # Default implementation should return None
        assert result is None
    
    @pytest.mark.asyncio
    async def test_on_stop_async_default(self):
        """Test on_stop_async default implementation"""
        class DefaultAsyncPlugin(AsyncPlugin):
            async def on_start_async(self):
                pass
        
        plugin = DefaultAsyncPlugin(name="default", version="1.0.0")
        await plugin.start()
        
        result = await plugin.stop()
        assert result is True

