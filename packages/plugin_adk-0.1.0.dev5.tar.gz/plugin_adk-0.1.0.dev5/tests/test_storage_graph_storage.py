"""
Unit tests for Graph Storage.
"""

import pytest
from plugin_adk.core.storage.graph_storage import (
    MemoryGraphStorage,
    BaseGraphStorage,
    Neo4jGraphStorage,
)
from plugin_adk.core.storage.interface import StorageConfig, StorageType


class TestMemoryGraphStorage:
    """Tests for MemoryGraphStorage"""
    
    @pytest.mark.asyncio
    async def test_init_with_config(self):
        """Test initialization with config"""
        config = StorageConfig(storage_type=StorageType.GRAPH)
        storage = MemoryGraphStorage(config=config)
        
        assert storage.config == config
        assert storage._connected is False
    
    @pytest.mark.asyncio
    async def test_init_without_config(self):
        """Test initialization without config"""
        storage = MemoryGraphStorage()
        
        assert storage.config is not None
        assert storage.config.storage_type == StorageType.GRAPH
    
    @pytest.mark.asyncio
    async def test_connect_disconnect(self):
        """Test connect and disconnect"""
        storage = MemoryGraphStorage()
        
        result = await storage.connect()
        assert result is True
        assert await storage.is_connected() is True
        
        result = await storage.disconnect()
        assert result is True
        assert await storage.is_connected() is False
    
    @pytest.mark.asyncio
    async def test_get_status(self):
        """Test get_status"""
        storage = MemoryGraphStorage()
        
        status = await storage.get_status()
        assert status["type"] == "graph"
        assert status["connected"] is False
        
        await storage.connect()
        status = await storage.get_status()
        assert status["connected"] is True
    
    @pytest.mark.asyncio
    async def test_create_node_with_id(self):
        """Test create_node with provided ID"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node_id = await storage.create_node(
            label="Person",
            properties={"name": "Alice"},
            node_id="node1"
        )
        assert node_id == "node1"
    
    @pytest.mark.asyncio
    async def test_create_node_auto_id(self):
        """Test create_node with auto-generated ID"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node_id = await storage.create_node(
            label="Person",
            properties={"name": "Alice"}
        )
        assert node_id is not None
        assert node_id.startswith("node_")
    
    @pytest.mark.asyncio
    async def test_create_node_duplicate_id(self):
        """Test create_node with duplicate ID"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node_id1 = await storage.create_node(
            label="Person",
            properties={"name": "Alice"},
            node_id="node1"
        )
        assert node_id1 == "node1"
        
        # Try to create with same ID
        node_id2 = await storage.create_node(
            label="Person",
            properties={"name": "Bob"},
            node_id="node1"
        )
        assert node_id2 is None  # Should fail
    
    @pytest.mark.asyncio
    async def test_create_relationship_nonexistent_nodes(self):
        """Test create_relationship with nonexistent nodes"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        result = await storage.create_relationship(
            from_node_id="nonexistent1",
            to_node_id="nonexistent2",
            relationship_type="KNOWS"
        )
        assert result is False
    
    @pytest.mark.asyncio
    async def test_create_relationship_duplicate(self):
        """Test create_relationship with duplicate"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node1_id = await storage.create_node("Person", {"name": "Alice"})
        node2_id = await storage.create_node("Person", {"name": "Bob"})
        
        # Create first relationship
        result1 = await storage.create_relationship(
            from_node_id=node1_id,
            to_node_id=node2_id,
            relationship_type="KNOWS"
        )
        assert result1 is True
        
        # Try to create duplicate
        result2 = await storage.create_relationship(
            from_node_id=node1_id,
            to_node_id=node2_id,
            relationship_type="KNOWS"
        )
        assert result2 is True  # May allow duplicates or update
    
    @pytest.mark.asyncio
    async def test_query_match_nodes(self):
        """Test query with MATCH nodes"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        await storage.create_node("Person", {"name": "Alice"})
        await storage.create_node("Person", {"name": "Bob"})
        await storage.create_node("Company", {"name": "Acme"})
        
        # Query all Person nodes
        results = await storage.query("MATCH (n:Person) RETURN n")
        assert len(results) == 2
    
    @pytest.mark.asyncio
    async def test_query_match_relationships(self):
        """Test query with MATCH relationships"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node1_id = await storage.create_node("Person", {"name": "Alice"})
        node2_id = await storage.create_node("Person", {"name": "Bob"})
        
        await storage.create_relationship(
            from_node_id=node1_id,
            to_node_id=node2_id,
            relationship_type="KNOWS"
        )
        
        # Query relationships
        results = await storage.query("MATCH (a)-[r:KNOWS]->(b) RETURN r")
        assert len(results) >= 0  # May return empty or results
    
    @pytest.mark.asyncio
    async def test_query_unsupported(self):
        """Test query with unsupported query type"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        results = await storage.query("DELETE n")
        assert results == []
    
    @pytest.mark.asyncio
    async def test_delete_node(self):
        """Test delete_node"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node_id = await storage.create_node("Person", {"name": "Alice"})
        
        result = await storage.delete_node(node_id)
        assert result is True
        
        # Verify deletion
        results = await storage.query("MATCH (n:Person) RETURN n")
        assert len(results) == 0
    
    @pytest.mark.asyncio
    async def test_delete_node_nonexistent(self):
        """Test delete_node with nonexistent node"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        result = await storage.delete_node("nonexistent")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_delete_node_cascade(self):
        """Test delete_node with cascade"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node1_id = await storage.create_node("Person", {"name": "Alice"})
        node2_id = await storage.create_node("Person", {"name": "Bob"})
        
        await storage.create_relationship(
            from_node_id=node1_id,
            to_node_id=node2_id,
            relationship_type="KNOWS"
        )
        
        # Delete with cascade
        result = await storage.delete_node(node1_id, cascade=True)
        assert result is True
    
    @pytest.mark.asyncio
    async def test_disconnect_clears_data(self):
        """Test disconnect clears data"""
        storage = MemoryGraphStorage()
        await storage.connect()
        
        node_id = await storage.create_node("Person", {"name": "Alice"})
        assert node_id is not None
        
        await storage.disconnect()
        
        # Data should be cleared
        await storage.connect()
        results = await storage.query("MATCH (n:Person) RETURN n")
        assert len(results) == 0


class TestBaseGraphStorage:
    """Tests for BaseGraphStorage"""
    
    @pytest.mark.asyncio
    async def test_connect_error_handling(self):
        """Test connect error handling"""
        class ErrorStorage(BaseGraphStorage):
            async def _connect_impl(self) -> bool:
                raise Exception("Connection error")
            async def _disconnect_impl(self) -> bool:
                return True
            async def create_node(self, *args, **kwargs):
                return None
            async def create_relationship(self, *args, **kwargs):
                return False
            async def query(self, *args, **kwargs):
                return []
            async def delete_node(self, *args, **kwargs):
                return False
        
        storage = ErrorStorage(StorageConfig(storage_type=StorageType.GRAPH))
        result = await storage.connect()
        assert result is False
        assert await storage.is_connected() is False
    
    @pytest.mark.asyncio
    async def test_disconnect_error_handling(self):
        """Test disconnect error handling"""
        class ErrorStorage(BaseGraphStorage):
            async def _connect_impl(self) -> bool:
                return True
            async def _disconnect_impl(self) -> bool:
                raise Exception("Disconnection error")
            async def create_node(self, *args, **kwargs):
                return None
            async def create_relationship(self, *args, **kwargs):
                return False
            async def query(self, *args, **kwargs):
                return []
            async def delete_node(self, *args, **kwargs):
                return False
        
        storage = ErrorStorage(StorageConfig(storage_type=StorageType.GRAPH))
        await storage.connect()
        result = await storage.disconnect()
        assert result is False
        # On error, _disconnect_impl raises exception before _connected is set to False
        # So _connected remains True (this is the actual behavior)
        assert await storage.is_connected() is True


class TestNeo4jGraphStorage:
    """Tests for Neo4jGraphStorage"""
    
    @pytest.mark.asyncio
    async def test_neo4j_storage_placeholder_methods(self):
        """Test Neo4jGraphStorage placeholder methods"""
        config = StorageConfig(
            storage_type=StorageType.GRAPH,
            host="localhost",
            port=7687,
            database="neo4j"
        )
        storage = Neo4jGraphStorage(config)
        
        await storage.connect()
        
        # Placeholder methods should return expected values
        result = await storage.create_node("Person", {"name": "Alice"})
        assert result is None  # Not implemented
        
        result = await storage.create_relationship("node1", "node2", "KNOWS")
        assert result is False  # Not implemented
        
        results = await storage.query("MATCH (n) RETURN n")
        assert results == []  # Not implemented
        
        result = await storage.delete_node("node1")
        assert result is False  # Not implemented

