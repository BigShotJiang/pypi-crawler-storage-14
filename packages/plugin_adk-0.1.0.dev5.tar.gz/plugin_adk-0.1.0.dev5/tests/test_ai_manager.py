"""
Unit tests for AICapabilitiesManager.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from datetime import datetime, timedelta

from plugin_adk.core.ai.manager import AICapabilitiesManager
from plugin_adk.core.ai.llm import LLMService, LLMModel, LLMProvider
from plugin_adk.core.ai.embedding import EmbeddingService, EmbeddingModel, EmbeddingProvider
from plugin_adk.core.ai.token_tracker import TokenTracker, TokenUsage


@pytest.fixture
def token_tracker():
    """Create token tracker"""
    return TokenTracker()


@pytest.mark.asyncio
async def test_ai_manager_init_with_models(token_tracker):
    """Test AICapabilitiesManager initialization with models"""
    try:
        manager = AICapabilitiesManager(
            default_llm_model="gpt-3.5-turbo",
            default_embedding_model="text-embedding-ada-002",
            token_tracker=token_tracker
        )
        assert manager.llm_service is not None
        assert manager.embedding_service is not None
        assert manager.token_tracker == token_tracker
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_complete(token_tracker):
    """Test complete method (line 75)"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        mock_response = {
            "content": "Hello!",
            "usage": {"total_tokens": 10},
            "model": "gpt-3.5-turbo"
        }
        
        with patch.object(manager.llm_service, 'complete', new_callable=AsyncMock) as mock_complete:
            mock_complete.return_value = mock_response
            
            result = await manager.complete([{"role": "user", "content": "Hello"}])
            
            assert result == mock_response
            mock_complete.assert_called_once_with(
                [{"role": "user", "content": "Hello"}],
                model=None
            )
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_stream_complete(token_tracker):
    """Test stream_complete method (line 94-95)"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        mock_chunks = [
            {"content": "Hello"},
            {"content": "!"}
        ]
        
        async def mock_stream():
            for chunk in mock_chunks:
                yield chunk
        
        with patch.object(manager.llm_service, 'stream_complete', return_value=mock_stream()):
            chunks = []
            async for chunk in manager.stream_complete([{"role": "user", "content": "Hello"}]):
                chunks.append(chunk)
            
            assert len(chunks) == 2
            assert chunks[0]["content"] == "Hello"
            assert chunks[1]["content"] == "!"
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_embed(token_tracker):
    """Test embed method (line 114)"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        mock_embeddings = [[0.1] * 1536, [0.2] * 1536]
        
        with patch.object(manager.embedding_service, 'embed', new_callable=AsyncMock) as mock_embed:
            mock_embed.return_value = mock_embeddings
            
            result = await manager.embed(["Hello", "World"])
            
            assert result == mock_embeddings
            mock_embed.assert_called_once_with(
                ["Hello", "World"],
                model=None
            )
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_llm_service(token_tracker):
    """Test get_llm_service method"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        assert manager.get_llm_service() == manager.llm_service
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_embedding_service(token_tracker):
    """Test get_embedding_service method (line 132)"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        assert manager.get_embedding_service() == manager.embedding_service
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_token_tracker(token_tracker):
    """Test get_token_tracker method (line 141)"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        assert manager.get_token_tracker() == token_tracker
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_token_usage_report(token_tracker):
    """Test get_token_usage_report method"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        # Record some usage
        usage = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            timestamp=datetime.now(),
        )
        await token_tracker.record_usage(usage)
        
        # Get report
        report = await manager.get_token_usage_report()
        
        assert "total_usage" in report
        assert "total_cost" in report
        assert "usage_by_model" in report
        assert "period" in report
        assert report["total_usage"]["total_tokens"] >= 150
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_token_usage_report_with_filters(token_tracker):
    """Test get_token_usage_report with filters"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        # Record usage at different times
        now = datetime.now()
        usage1 = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            timestamp=now - timedelta(hours=2),
        )
        usage2 = TokenUsage(
            prompt_tokens=200,
            completion_tokens=100,
            total_tokens=300,
            model="gpt-4",
            timestamp=now - timedelta(hours=1),
        )
        await token_tracker.record_usage(usage1)
        await token_tracker.record_usage(usage2)
        
        # Get report with time filter
        start_time = now - timedelta(hours=1.5)
        end_time = now
        report = await manager.get_token_usage_report(
            start_time=start_time,
            end_time=end_time
        )
        
        assert "period" in report
        assert report["period"]["start_time"] is not None
        assert report["period"]["end_time"] is not None
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_token_usage_report_with_model_filter(token_tracker):
    """Test get_token_usage_report with model filter"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        # Record usage for different models
        usage1 = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            timestamp=datetime.now(),
        )
        usage2 = TokenUsage(
            prompt_tokens=200,
            completion_tokens=100,
            total_tokens=300,
            model="gpt-4",
            timestamp=datetime.now(),
        )
        await token_tracker.record_usage(usage1)
        await token_tracker.record_usage(usage2)
        
        # Get report filtered by model
        report = await manager.get_token_usage_report(model="gpt-3.5-turbo")
        
        assert "total_usage" in report
        # Should only include gpt-3.5-turbo usage
        assert report["total_usage"]["total_tokens"] >= 150
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_cost_report(token_tracker):
    """Test get_cost_report method"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        # Record some usage
        usage = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            timestamp=datetime.now(),
        )
        await token_tracker.record_usage(usage)
        
        # Get cost report
        report = await manager.get_cost_report()
        
        assert "total_cost" in report
        assert "cost_by_model" in report
        assert "period" in report
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_get_cost_report_with_filters(token_tracker):
    """Test get_cost_report with time filters"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        # Record usage at different times
        now = datetime.now()
        usage = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            timestamp=now - timedelta(hours=1),
        )
        await token_tracker.record_usage(usage)
        
        # Get cost report with time filter
        start_time = now - timedelta(hours=2)
        end_time = now
        report = await manager.get_cost_report(
            start_time=start_time,
            end_time=end_time
        )
        
        assert "period" in report
        assert report["period"]["start_time"] is not None
        assert report["period"]["end_time"] is not None
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_reset_token_usage(token_tracker):
    """Test reset_token_usage method"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        # Record some usage
        usage = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            timestamp=datetime.now(),
        )
        await token_tracker.record_usage(usage)
        
        # Reset usage
        cleared = await manager.reset_token_usage()
        
        assert cleared >= 0
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_reset_token_usage_with_before(token_tracker):
    """Test reset_token_usage with before parameter"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        # Record usage at different times
        now = datetime.now()
        usage1 = TokenUsage(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            model="gpt-3.5-turbo",
            timestamp=now - timedelta(hours=2),
        )
        usage2 = TokenUsage(
            prompt_tokens=200,
            completion_tokens=100,
            total_tokens=300,
            model="gpt-4",
            timestamp=now - timedelta(hours=1),
        )
        await token_tracker.record_usage(usage1)
        await token_tracker.record_usage(usage2)
        
        # Reset usage before a specific time
        before = now - timedelta(hours=1.5)
        cleared = await manager.reset_token_usage(before=before)
        
        assert cleared >= 0
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_complete_with_model(token_tracker):
    """Test complete with model parameter"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        mock_response = {
            "content": "Hello!",
            "usage": {"total_tokens": 10},
            "model": "gpt-4"
        }
        
        with patch.object(manager.llm_service, 'complete', new_callable=AsyncMock) as mock_complete:
            mock_complete.return_value = mock_response
            
            result = await manager.complete(
                [{"role": "user", "content": "Hello"}],
                model="gpt-4"
            )
            
            assert result == mock_response
            mock_complete.assert_called_once_with(
                [{"role": "user", "content": "Hello"}],
                model="gpt-4"
            )
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise


@pytest.mark.asyncio
async def test_ai_manager_embed_with_model(token_tracker):
    """Test embed with model parameter"""
    try:
        manager = AICapabilitiesManager(token_tracker=token_tracker)
        
        mock_embeddings = [[0.1] * 1536]
        
        with patch.object(manager.embedding_service, 'embed', new_callable=AsyncMock) as mock_embed:
            mock_embed.return_value = mock_embeddings
            
            result = await manager.embed("Hello", model="text-embedding-3-small")
            
            assert result == mock_embeddings
            mock_embed.assert_called_once_with(
                "Hello",
                model="text-embedding-3-small"
            )
    except ImportError as e:
        if "litellm" in str(e).lower():
            pytest.skip(f"Skipping test: {e}")
        raise

