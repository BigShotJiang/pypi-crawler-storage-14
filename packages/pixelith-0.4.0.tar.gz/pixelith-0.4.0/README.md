# Pixelith

Pixelith, Python için basit ve çok amaçlı bir araç modülüdür.

## Kurulum
```
pip install pixelith
```

## Kullanım
```python
import pixelith

print(pixelith.hello("Murat"))
print(pixelith.add(5, 7))
```
# BU BİR TEST SÜRÜMÜDÜR! LÜTFEN YÜKLEMEYİN!!!
