import aiohttp
import asyncio

async def cevir(text: str, hedef: str, kaynak: str = "auto"):
    """
    Metni bir dilden başka bir dile çevirir ve doğrudan çeviriyi döndürür.
    
    Args:
        text (str): Çevrilecek metin
        hedef (str): Hedef dil kodu (örn: "tr", "en")
        kaynak (str): Kaynak dil kodu, default "auto"

    Returns:
        str: Çevrilmiş metin, hata olursa hata mesajı
    """
    url = "https://translate.googleapis.com/translate_a/single"
    params = {
        "client": "gtx",
        "sl": kaynak,
        "tl": hedef,
        "dt": "t",
        "q": text
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                if resp.status != 200:
                    return f"Hata: API yanıtı {resp.status}"
                data = await resp.json(content_type=None)
                translated = ''.join([chunk[0] for chunk in data[0]])
                return translated
    except aiohttp.ClientError as e:
        return f"Network hatası: {e}"
    except Exception as e:
        return f"Bilinmeyen hata: {e}"


# İngilizce isimlendirme kısayolu
async def translate(text: str, target: str, source: str = "auto"):
    return await cevir(text, target, source)


# Örnek kullanım
if __name__ == "__main__":
    async def test():
        result = await cevir("selam", "en", "tr")
        print("Çeviri:", result)

    asyncio.run(test())
