This module extends the functionality of Odoo Maintenance module by
allowing an equipment to have different preventive maintenance kinds.
