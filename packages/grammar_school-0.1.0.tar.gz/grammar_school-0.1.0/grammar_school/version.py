"""Version information for Grammar School."""

__version__ = "0.1.0"
