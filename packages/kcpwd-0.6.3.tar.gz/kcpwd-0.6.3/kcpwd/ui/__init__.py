"""
kcpwd.ui - Web UI Module
Optional web interface for password management
Install with: pip install kcpwd[ui]
"""

__version__ = "0.6.3"