from setuptools import setup, find_packages

setup(
    name="nbgen",
    version="0.3.4",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "nbgen=nbgen.cli:main",
        ],
    },
    install_requires=[
        # No external dependencies for the generator itself, 
        # but the generated notebooks might need pandas, gdown, etc.
    ],
    author="Your Name",
    description="A CLI tool to generate Jupyter Notebooks with data loading scripts.",
)
