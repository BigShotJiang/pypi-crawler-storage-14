from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="anylogic_design_time_api",
    version='8.9.7',
    author="AnyLogic",
    author_email="support@anylogic.com",
    description="Create AnyLogic markup by code",
    long_description=long_description,
    long_description_content_type="text/markdown",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent"
    ],
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.9',
    install_requires=[
        "py4j"
    ]
)
