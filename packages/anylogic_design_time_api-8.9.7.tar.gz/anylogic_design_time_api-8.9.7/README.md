# AnyLogic Design-Time Python API

The **AnyLogic Design-Time Python API** allows you to programmatically modify an AnyLogic model *while it is open in the graphical editor*.  
It provides the Python runtime with access to the model structure, allowing you to generate space markup automatically.

This package communicates with the AnyLogic editor using the built-in **Graphical Editor API Connector**, available in AnyLogic 8.9.7+.

---

## Features

- Connect to the AnyLogic editor using a secure one-time token  
- Create and configure model elements programmatically 
- Automatically generate data-driven layout structures  
- Access wrapper classes for AnyLogic objects (for example, `Conveyor`, `Path`, `PointNode`, `TurnStation`, `Robot`)

---

## Installation

```bash
pip install anylogic_design_time_api
```

---

## Requirements

- AnyLogic **8.9.7 or later**
- Python **3.9+** (tested on Python 3.13)
- Open port for API connector running inside AnyLogic (configurable)

When you start the connector from the AnyLogic toolbar, a dialog displays a **connection token**. Use this token in your Python script to attach to the editor.

---

## Basic usage

```python
from anylogic_design_time_api import *
from anylogic_design_time_api.generated import *

# Connect to the running AnyLogic editor
ws = Workspace("paste-your-token-here")

# Open the model
model = ws.getModel("My model")
agent = model.getAgent("Main")
level = agent.getLevels()[0]  # animation level where markup is created

# Create nodes
node1 = PointNode.create(level)
node2 = PointNode.create(level)
path = Path.create(level)

# Layout
node1.setX(100)
node1.setY(200)
node2.setX(300)
node2.setY(200)
path.setX(100)
path.setY(200)

# Define path geometry (relative to path position)
pathPoints = [0.0, 0.0, 0.0, 200.0, 0.0, 0.0]
pathPointList = Utils.createStraightPointsList(path, pathPoints)
path.setPointList(pathPointList)

# Connect network
path.setSource(node1)
path.setTarget(node2)
```

---

## Documentation

Full documentation, including wrapper classes, raw functions, and an extended example, is available in the AnyLogic documentation.

---

## License

© The AnyLogic Company.  
Distributed for use with the AnyLogic simulation environment.
