from typing import List

class Utils:
    def toggleArcSegment(path: 'BaseWorkspaceElement', index: int):
        path.workspace.getPolylineManager().makeArcSegment(path.item, index)

    def createStraightPointsList(path: 'BaseWorkspaceElement', arr: List[float]) -> List[float]:
        return list(path.workspace.getPolylineManager().makeStraightPointsList(path.javaDoubleArray(arr)))

    def getIntFromRGB(r: int, g: int, b: int):
        return Utils.getIntFromARGB(255, r, g, b)

    def getIntFromARGB(a: int, r: int, g: int, b: int):
        return Utils.unsigned_to_signed((a << 24) + (r << 16) + (g << 8) + b, 32)

    def unsigned_to_signed(unsigned_int, bit_size):
        signed_mask = 1 << (bit_size - 1)
        max_uint = (1 << bit_size) - 1

        if unsigned_int & signed_mask:
            return -((unsigned_int ^ max_uint) + 1)
        else:
            return unsigned_int