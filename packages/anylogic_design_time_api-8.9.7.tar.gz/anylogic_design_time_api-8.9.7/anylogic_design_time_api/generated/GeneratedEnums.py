from enum import StrEnum

class LengthUnits(StrEnum):
	KILOMETER='LengthUnits.KILOMETER'
	MILLIMETER='LengthUnits.MILLIMETER'
	MILE='LengthUnits.MILE'
	YARD='LengthUnits.YARD'
	METER='LengthUnits.METER'
	INCH='LengthUnits.INCH'
	CENTIMETER='LengthUnits.CENTIMETER'
	NAUTICAL_MILE='LengthUnits.NAUTICAL_MILE'
	FOOT='LengthUnits.FOOT'


class PathTypeEnum(StrEnum):
	CONVEYOR='PathTypeEnum.conveyor'
	RAILROAD='PathTypeEnum.railroad'
	ROAD='PathTypeEnum.road'
	LINE='PathTypeEnum.line'
	DASHEDLINE='PathTypeEnum.dashedLine'


class ConveyorSimpleStationDelayType(StrEnum):
	CONVEYOR_SIMPLE_STATION_DELAY_TYPE_MANUAL='CONVEYOR_SIMPLE_STATION_DELAY_TYPE_MANUAL'
	CONVEYOR_SIMPLE_STATION_DELAY_TYPE_TIMEOUT='CONVEYOR_SIMPLE_STATION_DELAY_TYPE_TIMEOUT'


class ConveyorCustomStationAgentLocation(StrEnum):
	CONVEYOR_CUSTOM_STATION_AGENT_LOCATION_NEAR_CONVEYOR='CONVEYOR_CUSTOM_STATION_AGENT_LOCATION_NEAR_CONVEYOR'
	CONVEYOR_CUSTOM_STATION_AGENT_LOCATION_CENTER='CONVEYOR_CUSTOM_STATION_AGENT_LOCATION_CENTER'
	CONVEYOR_CUSTOM_STATION_AGENT_LOCATION_RANDOM='CONVEYOR_CUSTOM_STATION_AGENT_LOCATION_RANDOM'


class RateUnits(StrEnum):
	PER_HOUR='RateUnits.PER_HOUR'
	PER_MINUTE='RateUnits.PER_MINUTE'
	PER_YEAR='RateUnits.PER_YEAR'
	PER_SECOND='RateUnits.PER_SECOND'
	PER_MILLISECOND='RateUnits.PER_MILLISECOND'
	PER_DAY='RateUnits.PER_DAY'
	PER_WEEK='RateUnits.PER_WEEK'
	PER_MONTH='RateUnits.PER_MONTH'


class ConveyorTurnStationMode(StrEnum):
	TURN_STATION_MODE_ORIENTATION='TURN_STATION_MODE_ORIENTATION'
	TURN_STATION_MODE_ANGLE='TURN_STATION_MODE_ANGLE'


class EscalatorPedestrianBehavior(StrEnum):
	ESCALATOR_WALK_ALL='EscalatorPedestrianBehavior.ESCALATOR_WALK_ALL'
	ESCALATOR_STAY_ALL='EscalatorPedestrianBehavior.ESCALATOR_STAY_ALL'
	ESCALATOR_WALK_ON_LEFT_SIDE='EscalatorPedestrianBehavior.ESCALATOR_WALK_ON_LEFT_SIDE'
	ESCALATOR_WALK_ON_RIGHT_SIDE='EscalatorPedestrianBehavior.ESCALATOR_WALK_ON_RIGHT_SIDE'


class ConveyorType(StrEnum):
	CONVEYOR_TYPE_CELL='CONVEYOR_TYPE_CELL'
	CONVEYOR_TYPE_ROLLER='CONVEYOR_TYPE_ROLLER'
	CONVEYOR_TYPE_BELT='CONVEYOR_TYPE_BELT'


class RailwaySwitchType(StrEnum):
	ALL_TO_ALL='RailwaySwitchType.ALL_TO_ALL'
	DOUBLE_SLIP='RailwaySwitchType.DOUBLE_SLIP'
	SINGLE_SLIP='RailwaySwitchType.SINGLE_SLIP'


class WallFillingTypeEnum(StrEnum):
	NO_FILL='WallFillingTypeEnum.NO_FILL'
	HATCHED_AREA='WallFillingTypeEnum.HATCHED_AREA'
	SOLID_FILL='WallFillingTypeEnum.SOLID_FILL'


class ShapeDrawModeEnum(StrEnum):
	SHAPE_DRAW_2D='ShapeDrawModeEnum.SHAPE_DRAW_2D'
	SHAPE_DRAW_3D='ShapeDrawModeEnum.SHAPE_DRAW_3D'
	SHAPE_DRAW_2D3D='ShapeDrawModeEnum.SHAPE_DRAW_2D3D'


class JibCraneMovementMode(StrEnum):
	JIB_CRANE_MOVEMENT_STEP_BY_STEP='JIB_CRANE_MOVEMENT_STEP_BY_STEP'
	JIB_CRANE_MOVEMENT_CONCURRENT='JIB_CRANE_MOVEMENT_CONCURRENT'


class ParkingTypeEnum(StrEnum):
	DIAGONAL='ParkingTypeEnum.DIAGONAL'
	PERPENDICULAR='ParkingTypeEnum.PERPENDICULAR'
	PARALLEL='ParkingTypeEnum.PARALLEL'


class EnumLineStyle(StrEnum):
	DOTTED='EnumLineStyle.DOTTED'
	DASHED='EnumLineStyle.DASHED'
	SOLID='EnumLineStyle.SOLID'


class OverheadCraneMovementMode(StrEnum):
	OVERHEAD_CRANE_MOVEMENT_STEP_BY_STEP='OVERHEAD_CRANE_MOVEMENT_STEP_BY_STEP'
	OVERHEAD_CRANE_MOVEMENT_CONCURRENT='OVERHEAD_CRANE_MOVEMENT_CONCURRENT'
	OVERHEAD_CRANE_MOVEMENT_INDEPENDENT_HOIST='OVERHEAD_CRANE_MOVEMENT_INDEPENDENT_HOIST'


class AgentOrientation(StrEnum):
	AGENT_ORIENTATION_REAR='AGENT_ORIENTATION_REAR'
	AGENT_ORIENTATION_FRONT='AGENT_ORIENTATION_FRONT'
	AGENT_ORIENTATION_LEFT='AGENT_ORIENTATION_LEFT'
	AGENT_ORIENTATION_RIGHT='AGENT_ORIENTATION_RIGHT'


class OverheadCraneType(StrEnum):
	GANTRY='OverheadCraneType.gantry'
	BRIDGE='OverheadCraneType.bridge'


class TimeUnits(StrEnum):
	MONTH='TimeUnits.MONTH'
	YEAR='TimeUnits.YEAR'
	HOUR='TimeUnits.HOUR'
	SECOND='TimeUnits.SECOND'
	MINUTE='TimeUnits.MINUTE'
	MILLISECOND='TimeUnits.MILLISECOND'
	WEEK='TimeUnits.WEEK'
	DAY='TimeUnits.DAY'


class ElevatorMovementMode(StrEnum):
	ELEVATOR_MOVEMENT_BY_SPEED='ELEVATOR_MOVEMENT_BY_SPEED'
	ELEVATOR_MOVEMENT_BY_TIME_PER_LEVEL='ELEVATOR_MOVEMENT_BY_TIME_PER_LEVEL'


class LiftPlatformDrawingTypeEnum(StrEnum):
	ROLLER='LiftPlatformDrawingTypeEnum.ROLLER'
	FLAT='LiftPlatformDrawingTypeEnum.FLAT'


class StorageUnitsDefinitionTypeEnum(StrEnum):
	RACK_DEPTH='StorageUnitsDefinitionTypeEnum.RACK_DEPTH'
	NUMBER_OF_UNITS='StorageUnitsDefinitionTypeEnum.NUMBER_OF_UNITS'


class AccelerationUnits(StrEnum):
	FPS_SQ='AccelerationUnits.FPS_SQ'
	MPS_SQ='AccelerationUnits.MPS_SQ'


class LiftSelectionMode(StrEnum):
	LIFT_SELECTION_MODE_COMPARISON='LIFT_SELECTION_MODE_COMPARISON'
	LIFT_SELECTION_MODE_PRIORITY='LIFT_SELECTION_MODE_PRIORITY'
	LIFT_SELECTION_MODE_FIFO='LIFT_SELECTION_MODE_FIFO'


class ElevatorDoorsConfiguration(StrEnum):
	FRONT_REAR='ElevatorDoorsConfiguration.FRONT_REAR'
	FRONT='ElevatorDoorsConfiguration.FRONT'


class JibCraneType(StrEnum):
	INDUSTRIAL='JibCraneType.industrial'
	TOWERCATHEAD='JibCraneType.towerCatHead'
	TOWERFLATTOP='JibCraneType.towerFlatTop'


class OverheadCraneGirderType(StrEnum):
	DOUBLETIE='OverheadCraneGirderType.doubleTie'
	SINGLEFLAT='OverheadCraneGirderType.singleFlat'


class ConveyorSimpleStationProcessingMode(StrEnum):
	SIMPLE_STATION_PROCESSING_WHEN_CAPACITY_FULL='SIMPLE_STATION_PROCESSING_WHEN_CAPACITY_FULL'
	SIMPLE_STATION_PROCESSING_WHEN_AGENT_ENTERS='SIMPLE_STATION_PROCESSING_WHEN_AGENT_ENTERS'


class RackTypeEnum(StrEnum):
	CUSTOM='RackTypeEnum.CUSTOM'
	DRIVE_THROUGH='RackTypeEnum.DRIVE_THROUGH'
	SELECTIVE='RackTypeEnum.SELECTIVE'
	GRAVITY='RackTypeEnum.GRAVITY'
	PUSH_BACK='RackTypeEnum.PUSH_BACK'


class AttractorsLayoutEnum(StrEnum):
	RANDOM='AttractorsLayoutEnum.random'
	ARRANGED='AttractorsLayoutEnum.arranged'


class EscalatorMovementDirection(StrEnum):
	DOWN='EscalatorMovementDirection.DOWN'
	UP='EscalatorMovementDirection.UP'


class TaskPreemptionPolicy(StrEnum):
	PP_CONTINUE_WITHOUT_RESOURCE='TaskPreemptionPolicy.PP_CONTINUE_WITHOUT_RESOURCE'
	PP_WAIT_FOR_ORIGINAL_RESOURCE='TaskPreemptionPolicy.PP_WAIT_FOR_ORIGINAL_RESOURCE'
	PP_TERMINATE_SERVING='TaskPreemptionPolicy.PP_TERMINATE_SERVING'
	PP_SEIZE_ANY_RESOURCE='TaskPreemptionPolicy.PP_SEIZE_ANY_RESOURCE'
	PP_NO_PREEMPTION='TaskPreemptionPolicy.PP_NO_PREEMPTION'


class RoadLineStyleEnum(StrEnum):
	SINGLE='RoadLineStyleEnum.SINGLE'
	DOUBLE='RoadLineStyleEnum.DOUBLE'
	DOUBLE_DASHED='RoadLineStyleEnum.DOUBLE_DASHED'
	SINGLE_DASHED='RoadLineStyleEnum.SINGLE_DASHED'


class RackConfigurationTypeEnum(StrEnum):
	SINGLE_BAY='RackConfigurationTypeEnum.SINGLE_BAY'
	BACK_TO_BACK='RackConfigurationTypeEnum.BACK_TO_BACK'


class boolean(StrEnum):
	FALSE='false'
	TRUE='true'


class processmodeling_Seize_DestinationType(StrEnum):
	DEST_XYZ='com.anylogic.libraries.processmodeling.Seize.DestinationType.DEST_XYZ'
	DEST_NODE='com.anylogic.libraries.processmodeling.Seize.DestinationType.DEST_NODE'
	DEST_ATTRACTOR='com.anylogic.libraries.processmodeling.Seize.DestinationType.DEST_ATTRACTOR'


class EscalatorSlopeTypeEnum(StrEnum):
	ANGLE='EscalatorSlopeTypeEnum.ANGLE'
	RISE='EscalatorSlopeTypeEnum.RISE'


class SpeedUnits(StrEnum):
	MPS='SpeedUnits.MPS'
	KPH='SpeedUnits.KPH'
	FPM='SpeedUnits.FPM'
	KN='SpeedUnits.KN'
	MPH='SpeedUnits.MPH'
	FPS='SpeedUnits.FPS'


class AreaAccessRestrictionType(StrEnum):
	AREA_ACCESS_RESTRICTION_BY_THROUGHPUT='AREA_ACCESS_RESTRICTION_BY_THROUGHPUT'
	AREA_ACCESS_RESTRICTION_BY_CAPACITY='AREA_ACCESS_RESTRICTION_BY_CAPACITY'
	AREA_ACCESS_RESTRICTION_MANUAL='AREA_ACCESS_RESTRICTION_MANUAL'
	AREA_ACCESS_RESTRICTION_BY_SCHEDULE='AREA_ACCESS_RESTRICTION_BY_SCHEDULE'
	AREA_ACCESS_RESTRICTION_BY_CONDITION='AREA_ACCESS_RESTRICTION_BY_CONDITION'


class RobotEndEffector(StrEnum):
	ROBOT_END_EFFECTOR_VACUUM_GRIPPER='RobotEndEffector.ROBOT_END_EFFECTOR_VACUUM_GRIPPER'
	ROBOT_END_EFFECTOR_WELDING_GUN='RobotEndEffector.ROBOT_END_EFFECTOR_WELDING_GUN'
	ROBOT_END_EFFECTOR_NONE='RobotEndEffector.ROBOT_END_EFFECTOR_NONE'
	ROBOT_END_EFFECTOR_GRIPPER='RobotEndEffector.ROBOT_END_EFFECTOR_GRIPPER'


class RoadDrivingDirectionEnum(StrEnum):
	RIGHT_HAND='RoadDrivingDirectionEnum.RIGHT_HAND'
	LEFT_HAND='RoadDrivingDirectionEnum.LEFT_HAND'


class SlopeTypeEnum(StrEnum):
	DZ='SlopeTypeEnum.dz'
	ANGLE='SlopeTypeEnum.angle'


class ConveyorSimpleStationLoadingMode(StrEnum):
	SIMPLE_STATION_LOADING_MODE_AFTER_UNLOADING='SIMPLE_STATION_LOADING_MODE_AFTER_UNLOADING'
	SIMPLE_STATION_LOADING_MODE_SIMULTANEOUS_WITH_UNLOADING='SIMPLE_STATION_LOADING_MODE_SIMULTANEOUS_WITH_UNLOADING'


class RotationSpeedUnits(StrEnum):
	RAD_PER_SECOND='RotationSpeedUnits.RAD_PER_SECOND'
	RPM='RotationSpeedUnits.RPM'
	DEG_PER_SECOND='RotationSpeedUnits.DEG_PER_SECOND'


class AngleUnits(StrEnum):
	RADIAN='AngleUnits.RADIAN'
	TURN='AngleUnits.TURN'
	DEGREE='AngleUnits.DEGREE'


class StorageBaysDefinitionTypeEnum(StrEnum):
	NUMBER_OF_BAYS='StorageBaysDefinitionTypeEnum.NUMBER_OF_BAYS'
	BAY_WIDTH='StorageBaysDefinitionTypeEnum.BAY_WIDTH'
