from datetime import datetime
from functools import reduce
from typing import List, Tuple

from ..BaseWorkspaceElement import BaseWorkspaceElement
from .GeneratedEnums import *

class Path(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Path(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Path'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getSource(self):
		return self.wrap(self.workspace.getElementManager().getSource(self.item))

	def setSource(self, source: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, source, True)

	def setTarget(self, target: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, target, False)

	def getTarget(self):
		return self.wrap(self.workspace.getElementManager().getTarget(self.item))

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))

	def getPathType(self) -> PathTypeEnum:
		return self.getPropertyValue("Path Type")

	def setPathType(self, value: PathTypeEnum):
		self.setPropertyValue("Path Type", value)

	def getWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Width", self.getUnitValue(float(value), unit))

	def isBidirectional(self) -> bool:
		return self.getPropertyValue("Path bidirection")

	def setBidirectional(self, value: bool):
		self.setPropertyValue("Path bidirection", bool(value))

	def isSpeedLimit(self) -> bool:
		return self.getPropertyValue("SPEED_LIMIT")

	def setSpeedLimit(self, value: bool):
		self.setPropertyValue("SPEED_LIMIT", bool(value))

	def getSpeedLimitValue(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "SPEED_LIMIT_VALUE")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeedLimitValue(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("SPEED_LIMIT_VALUE", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def isLimitNumberOfTransporters(self) -> bool:
		return self.getPropertyValue("LIMIT_NUMBER_OF_TRANSPORTERS")

	def setLimitNumberOfTransporters(self, value: bool):
		self.setPropertyValue("LIMIT_NUMBER_OF_TRANSPORTERS", bool(value))

	def getLimitNumberOfTransportersValue(self) -> int:
		return self.getPropertyValue("LIMIT_NUMBER_OF_TRANSPORTERS_VALUE")

	def setLimitNumberOfTransportersValue(self, value: int):
		self.setPropertyValue("LIMIT_NUMBER_OF_TRANSPORTERS_VALUE", int(value))



class RectangleNode(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RectangleNode(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RectangleNode'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getLineStyle(self) -> EnumLineStyle:
		return self.getPropertyValue("Line Style")

	def setLineStyle(self, value: EnumLineStyle):
		self.setPropertyValue("Line Style", value)

	def getAttractorsLayout(self) -> AttractorsLayoutEnum:
		return self.getPropertyValue("Attractors Layout")

	def setAttractorsLayout(self, value: AttractorsLayoutEnum):
		self.setPropertyValue("Attractors Layout", value)

	def isSloped(self) -> bool:
		return self.getPropertyValue("Sloped")

	def setSloped(self, value: bool):
		self.setPropertyValue("Sloped", bool(value))

	def getDX(self) -> float:
		return self.getPropertyValue("dX")

	def setDX(self, value: float):
		self.setPropertyValue("dX", float(value))

	def getDY(self) -> float:
		return self.getPropertyValue("dY")

	def setDY(self, value: float):
		self.setPropertyValue("dY", float(value))

	def getDZ(self) -> float:
		return self.getPropertyValue("dZ")

	def setDZ(self, value: float):
		self.setPropertyValue("dZ", float(value))

	def getAngleZ(self) -> float:
		return self.getPropertyValue("Angle Z")

	def setAngleZ(self, value: float):
		self.setPropertyValue("Angle Z", float(value))

	def getAngleX(self) -> float:
		return self.getPropertyValue("Angle X")

	def setAngleX(self, value: float):
		self.setPropertyValue("Angle X", float(value))

	def getType(self) -> SlopeTypeEnum:
		return self.getPropertyValue("Slope Type")

	def setType(self, value: SlopeTypeEnum):
		self.setPropertyValue("Slope Type", value)

	def getWidth(self) -> float:
		return self.getPropertyValue("Width")

	def setWidth(self, value: float):
		self.setPropertyValue("Width", float(value))

	def getHeight(self) -> float:
		return self.getPropertyValue("Height")

	def setHeight(self, value: float):
		self.setPropertyValue("Height", float(value))

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))

	def getAppliedClass(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "appliedClass")
		return result.getCode()

	def setAppliedClass(self, value: str):
		self.setPropertyValue("appliedClass", self.getCodeValue(value))

	def getSpeedRestricted(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "speedRestricted")
		return result.getCode()

	def setSpeedRestricted(self, value: bool | str):
		self.setPropertyValue("speedRestricted", self.getCodeValue(value))

	def getMaxSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "maxSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setMaxSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("maxSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getAccessRestricted(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "accessRestricted")
		return result.getCode()

	def setAccessRestricted(self, value: bool | str):
		self.setPropertyValue("accessRestricted", self.getCodeValue(value))

	def getAccessRestrictionType(self) -> AreaAccessRestrictionType:
		return self.getPropertyValue("accessRestrictionType")

	def setAccessRestrictionType(self, value: AreaAccessRestrictionType):
		self.setPropertyValue("accessRestrictionType", self.getCodeValue(value))

	def getAccessRestrictionCondition(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "accessRestrictionCondition")
		return result.getCode()

	def setAccessRestrictionCondition(self, value: bool | str):
		self.setPropertyValue("accessRestrictionCondition", self.getCodeValue(value))

	def getCapacity(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "capacity")
		return result.getCode()

	def setCapacity(self, value: int | str):
		self.setPropertyValue("capacity", self.getCodeValue(value))

	def getThroughput(self) -> Tuple[float | str, RateUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "throughput")
		return result.getCode(), RateUnits("RateUnits." + result.getUnit().name())

	def setThroughput(self, value: float | str, unit: RateUnits):
		self.setPropertyValue("throughput", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getSchedule(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "schedule")
		return result.getCode()

	def setSchedule(self, value: str):
		self.setPropertyValue("schedule", self.getCodeValue(value))

	def getAvoidedIfClosed(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "avoidedIfClosed")
		return result.getCode()

	def setAvoidedIfClosed(self, value: bool | str):
		self.setPropertyValue("avoidedIfClosed", self.getCodeValue(value))

	def getOnEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onEnter")
		return result.getCode()

	def setOnEnter(self, value: str):
		self.setPropertyValue("onEnter", self.getCodeValue(value))

	def getOnEnterDenied(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onEnterDenied")
		return result.getCode()

	def setOnEnterDenied(self, value: str):
		self.setPropertyValue("onEnterDenied", self.getCodeValue(value))

	def getOnExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onExit")
		return result.getCode()

	def setOnExit(self, value: str):
		self.setPropertyValue("onExit", self.getCodeValue(value))

	def getOnOpen(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onOpen")
		return result.getCode()

	def setOnOpen(self, value: str):
		self.setPropertyValue("onOpen", self.getCodeValue(value))

	def getOnClose(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onClose")
		return result.getCode()

	def setOnClose(self, value: str):
		self.setPropertyValue("onClose", self.getCodeValue(value))



class PolygonNode(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return PolygonNode(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'PolygonNode'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getLineStyle(self) -> EnumLineStyle:
		return self.getPropertyValue("Line Style")

	def setLineStyle(self, value: EnumLineStyle):
		self.setPropertyValue("Line Style", value)

	def getAttractorsLayout(self) -> AttractorsLayoutEnum:
		return self.getPropertyValue("Attractors Layout")

	def setAttractorsLayout(self, value: AttractorsLayoutEnum):
		self.setPropertyValue("Attractors Layout", value)

	def isSloped(self) -> bool:
		return self.getPropertyValue("Sloped")

	def setSloped(self, value: bool):
		self.setPropertyValue("Sloped", bool(value))

	def getDX(self) -> float:
		return self.getPropertyValue("dX")

	def setDX(self, value: float):
		self.setPropertyValue("dX", float(value))

	def getDY(self) -> float:
		return self.getPropertyValue("dY")

	def setDY(self, value: float):
		self.setPropertyValue("dY", float(value))

	def getDZ(self) -> float:
		return self.getPropertyValue("dZ")

	def setDZ(self, value: float):
		self.setPropertyValue("dZ", float(value))

	def getAngleZ(self) -> float:
		return self.getPropertyValue("Angle Z")

	def setAngleZ(self, value: float):
		self.setPropertyValue("Angle Z", float(value))

	def getAngleX(self) -> float:
		return self.getPropertyValue("Angle X")

	def setAngleX(self, value: float):
		self.setPropertyValue("Angle X", float(value))

	def getType(self) -> SlopeTypeEnum:
		return self.getPropertyValue("Slope Type")

	def setType(self, value: SlopeTypeEnum):
		self.setPropertyValue("Slope Type", value)

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))

	def getAppliedClass(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "appliedClass")
		return result.getCode()

	def setAppliedClass(self, value: str):
		self.setPropertyValue("appliedClass", self.getCodeValue(value))

	def getSpeedRestricted(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "speedRestricted")
		return result.getCode()

	def setSpeedRestricted(self, value: bool | str):
		self.setPropertyValue("speedRestricted", self.getCodeValue(value))

	def getMaxSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "maxSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setMaxSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("maxSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getAccessRestricted(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "accessRestricted")
		return result.getCode()

	def setAccessRestricted(self, value: bool | str):
		self.setPropertyValue("accessRestricted", self.getCodeValue(value))

	def getAccessRestrictionType(self) -> AreaAccessRestrictionType:
		return self.getPropertyValue("accessRestrictionType")

	def setAccessRestrictionType(self, value: AreaAccessRestrictionType):
		self.setPropertyValue("accessRestrictionType", self.getCodeValue(value))

	def getAccessRestrictionCondition(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "accessRestrictionCondition")
		return result.getCode()

	def setAccessRestrictionCondition(self, value: bool | str):
		self.setPropertyValue("accessRestrictionCondition", self.getCodeValue(value))

	def getCapacity(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "capacity")
		return result.getCode()

	def setCapacity(self, value: int | str):
		self.setPropertyValue("capacity", self.getCodeValue(value))

	def getThroughput(self) -> Tuple[float | str, RateUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "throughput")
		return result.getCode(), RateUnits("RateUnits." + result.getUnit().name())

	def setThroughput(self, value: float | str, unit: RateUnits):
		self.setPropertyValue("throughput", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getSchedule(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "schedule")
		return result.getCode()

	def setSchedule(self, value: str):
		self.setPropertyValue("schedule", self.getCodeValue(value))

	def getAvoidedIfClosed(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "avoidedIfClosed")
		return result.getCode()

	def setAvoidedIfClosed(self, value: bool | str):
		self.setPropertyValue("avoidedIfClosed", self.getCodeValue(value))

	def getOnEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onEnter")
		return result.getCode()

	def setOnEnter(self, value: str):
		self.setPropertyValue("onEnter", self.getCodeValue(value))

	def getOnEnterDenied(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onEnterDenied")
		return result.getCode()

	def setOnEnterDenied(self, value: str):
		self.setPropertyValue("onEnterDenied", self.getCodeValue(value))

	def getOnExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onExit")
		return result.getCode()

	def setOnExit(self, value: str):
		self.setPropertyValue("onExit", self.getCodeValue(value))

	def getOnOpen(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onOpen")
		return result.getCode()

	def setOnOpen(self, value: str):
		self.setPropertyValue("onOpen", self.getCodeValue(value))

	def getOnClose(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onClose")
		return result.getCode()

	def setOnClose(self, value: str):
		self.setPropertyValue("onClose", self.getCodeValue(value))



class PointNode(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return PointNode(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'PointNode'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isSpeedLimit(self) -> bool:
		return self.getPropertyValue("SPEED_LIMIT")

	def setSpeedLimit(self, value: bool):
		self.setPropertyValue("SPEED_LIMIT", bool(value))

	def getSpeedLimitValue(self) -> Tuple[float, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "SPEED_LIMIT_VALUE")
		return result.getValue(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeedLimitValue(self, value: float, unit: SpeedUnits):
		self.setPropertyValue("SPEED_LIMIT_VALUE", self.getUnitValue(float(value), unit))

	def getColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getRadius(self) -> float:
		return self.getPropertyValue("Radius")

	def setRadius(self, value: float):
		self.setPropertyValue("Radius", float(value))



class Attractor(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Attractor(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Attractor'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))



class Network(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Network(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Network'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))



class Conveyor(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Conveyor(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Conveyor'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getSource(self):
		return self.wrap(self.workspace.getElementManager().getSource(self.item))

	def setSource(self, source: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, source, True)

	def setTarget(self, target: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, target, False)

	def getTarget(self):
		return self.wrap(self.workspace.getElementManager().getTarget(self.item))

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Width", self.getUnitValue(float(value), unit))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))

	def isDrawStands(self) -> bool:
		return self.getPropertyValue("Draw stands")

	def setDrawStands(self, value: bool):
		self.setPropertyValue("Draw stands", bool(value))

	def getStandsLevel(self) -> float:
		return self.getPropertyValue("... from Z level")

	def setStandsLevel(self, value: float):
		self.setPropertyValue("... from Z level", float(value))

	def getType(self) -> ConveyorType:
		return self.getPropertyValue("type")

	def setType(self, value: ConveyorType):
		self.setPropertyValue("type", self.getCodeValue(value))

	def getReversible(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "reversible")
		return result.getCode()

	def setReversible(self, value: bool | str):
		self.setPropertyValue("reversible", self.getCodeValue(value))

	def getMaxSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "maxSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setMaxSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("maxSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getInitialSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "initialSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setInitialSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("initialSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getAcceleration(self) -> Tuple[float | str, AccelerationUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "acceleration")
		return result.getCode(), AccelerationUnits("AccelerationUnits." + result.getUnit().name())

	def setAcceleration(self, value: float | str, unit: AccelerationUnits):
		self.setPropertyValue("acceleration", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getDeceleration(self) -> Tuple[float | str, AccelerationUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "deceleration")
		return result.getCode(), AccelerationUnits("AccelerationUnits." + result.getUnit().name())

	def setDeceleration(self, value: float | str, unit: AccelerationUnits):
		self.setPropertyValue("deceleration", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getCellSize(self) -> Tuple[float | str, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "cellSize")
		return result.getCode(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setCellSize(self, value: float | str, unit: LengthUnits):
		self.setPropertyValue("cellSize", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getGap(self) -> Tuple[float | str, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "gap")
		return result.getCode(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setGap(self, value: float | str, unit: LengthUnits):
		self.setPropertyValue("gap", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getMaximumPriority(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "maximumPriority")
		return result.getCode()

	def setMaximumPriority(self, value: bool | str):
		self.setPropertyValue("maximumPriority", self.getCodeValue(value))

	def getPriority(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "priority")
		return result.getCode()

	def setPriority(self, value: float | str):
		self.setPropertyValue("priority", self.getCodeValue(value))

	def getOnLeadingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeEnter")
		return result.getCode()

	def setOnLeadingEdgeEnter(self, value: str):
		self.setPropertyValue("onLeadingEdgeEnter", self.getCodeValue(value))

	def getOnTrailingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeEnter")
		return result.getCode()

	def setOnTrailingEdgeEnter(self, value: str):
		self.setPropertyValue("onTrailingEdgeEnter", self.getCodeValue(value))

	def getOnLeadingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeExit")
		return result.getCode()

	def setOnLeadingEdgeExit(self, value: str):
		self.setPropertyValue("onLeadingEdgeExit", self.getCodeValue(value))

	def getOnTrailingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeExit")
		return result.getCode()

	def setOnTrailingEdgeExit(self, value: str):
		self.setPropertyValue("onTrailingEdgeExit", self.getCodeValue(value))

	def getOnStarted(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onStarted")
		return result.getCode()

	def setOnStarted(self, value: str):
		self.setPropertyValue("onStarted", self.getCodeValue(value))

	def getOnStopped(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onStopped")
		return result.getCode()

	def setOnStopped(self, value: str):
		self.setPropertyValue("onStopped", self.getCodeValue(value))

	def getOnDirectionChanged(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onDirectionChanged")
		return result.getCode()

	def setOnDirectionChanged(self, value: str):
		self.setPropertyValue("onDirectionChanged", self.getCodeValue(value))

	def getDowntimes(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "downtimes")
		return result.getCode()

	def setDowntimes(self, value: str):
		self.setPropertyValue("downtimes", self.getCodeValue(value))



class ConveyorSpur(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return ConveyorSpur(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'ConveyorSpur'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getOffset(self) -> float:
		return self.getPropertyValue("Offset")

	def setOffset(self, value: float):
		self.setPropertyValue("Offset", float(value))

	def isOnRightSide(self) -> bool:
		return self.getPropertyValue("On Right Side")

	def setOnRightSide(self, value: bool):
		self.setPropertyValue("On Right Side", bool(value))



class PositionOnConveyor(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return PositionOnConveyor(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'PositionOnConveyor'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getOffset(self) -> float:
		return self.getPropertyValue("Offset")

	def setOffset(self, value: float):
		self.setPropertyValue("Offset", float(value))

	def getInitiallyBlocked(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "initiallyBlocked")
		return result.getCode()

	def setInitiallyBlocked(self, value: bool | str):
		self.setPropertyValue("initiallyBlocked", self.getCodeValue(value))

	def getOnLeadingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeEnter")
		return result.getCode()

	def setOnLeadingEdgeEnter(self, value: str):
		self.setPropertyValue("onLeadingEdgeEnter", self.getCodeValue(value))

	def getOnTrailingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeExit")
		return result.getCode()

	def setOnTrailingEdgeExit(self, value: str):
		self.setPropertyValue("onTrailingEdgeExit", self.getCodeValue(value))

	def getOnCellEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onCellEnter")
		return result.getCode()

	def setOnCellEnter(self, value: str):
		self.setPropertyValue("onCellEnter", self.getCodeValue(value))

	def getOnCellExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onCellExit")
		return result.getCode()

	def setOnCellExit(self, value: str):
		self.setPropertyValue("onCellExit", self.getCodeValue(value))



class TransferTable(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return TransferTable(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'TransferTable'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getTakeSpeedOfConnectedConveyors(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "takeSpeedOfConnectedConveyors")
		return result.getCode()

	def setTakeSpeedOfConnectedConveyors(self, value: bool | str):
		self.setPropertyValue("takeSpeedOfConnectedConveyors", self.getCodeValue(value))

	def getSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "speed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("speed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getSwitchingDelay(self) -> Tuple[float | str, TimeUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "switchingDelay")
		return result.getCode(), TimeUnits("TimeUnits." + result.getUnit().name())

	def setSwitchingDelay(self, value: float | str, unit: TimeUnits):
		self.setPropertyValue("switchingDelay", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getOnLeadingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeEnter")
		return result.getCode()

	def setOnLeadingEdgeEnter(self, value: str):
		self.setPropertyValue("onLeadingEdgeEnter", self.getCodeValue(value))

	def getOnTrailingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeEnter")
		return result.getCode()

	def setOnTrailingEdgeEnter(self, value: str):
		self.setPropertyValue("onTrailingEdgeEnter", self.getCodeValue(value))

	def getOnLeadingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeExit")
		return result.getCode()

	def setOnLeadingEdgeExit(self, value: str):
		self.setPropertyValue("onLeadingEdgeExit", self.getCodeValue(value))

	def getOnTrailingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeExit")
		return result.getCode()

	def setOnTrailingEdgeExit(self, value: str):
		self.setPropertyValue("onTrailingEdgeExit", self.getCodeValue(value))



class Turntable(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Turntable(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Turntable'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getDiameter(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Diameter")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setDiameter(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Diameter", self.getUnitValue(float(value), unit))

	def getSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "speed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("speed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getRotationSpeed(self) -> Tuple[float | str, RotationSpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "rotationSpeed")
		return result.getCode(), RotationSpeedUnits("RotationSpeedUnits." + result.getUnit().name())

	def setRotationSpeed(self, value: float | str, unit: RotationSpeedUnits):
		self.setPropertyValue("rotationSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getOnLeadingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeEnter")
		return result.getCode()

	def setOnLeadingEdgeEnter(self, value: str):
		self.setPropertyValue("onLeadingEdgeEnter", self.getCodeValue(value))

	def getOnTrailingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeEnter")
		return result.getCode()

	def setOnTrailingEdgeEnter(self, value: str):
		self.setPropertyValue("onTrailingEdgeEnter", self.getCodeValue(value))

	def getOnLeadingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeExit")
		return result.getCode()

	def setOnLeadingEdgeExit(self, value: str):
		self.setPropertyValue("onLeadingEdgeExit", self.getCodeValue(value))

	def getOnTrailingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeExit")
		return result.getCode()

	def setOnTrailingEdgeExit(self, value: str):
		self.setPropertyValue("onTrailingEdgeExit", self.getCodeValue(value))



class TurnStation(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return TurnStation(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'TurnStation'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getDiameter(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Diameter")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setDiameter(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Diameter", self.getUnitValue(float(value), unit))

	def getMode(self) -> ConveyorTurnStationMode:
		return self.getPropertyValue("mode")

	def setMode(self, value: ConveyorTurnStationMode):
		self.setPropertyValue("mode", self.getCodeValue(value))

	def getAngle(self) -> Tuple[float | str, AngleUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "angle")
		return result.getCode(), AngleUnits("AngleUnits." + result.getUnit().name())

	def setAngle(self, value: float | str, unit: AngleUnits):
		self.setPropertyValue("angle", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getOrientation(self) -> AgentOrientation:
		return self.getPropertyValue("orientation")

	def setOrientation(self, value: AgentOrientation):
		self.setPropertyValue("orientation", self.getCodeValue(value))

	def getSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "speed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("speed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getRotationSpeed(self) -> Tuple[float | str, RotationSpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "rotationSpeed")
		return result.getCode(), RotationSpeedUnits("RotationSpeedUnits." + result.getUnit().name())

	def setRotationSpeed(self, value: float | str, unit: RotationSpeedUnits):
		self.setPropertyValue("rotationSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getOnLeadingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeEnter")
		return result.getCode()

	def setOnLeadingEdgeEnter(self, value: str):
		self.setPropertyValue("onLeadingEdgeEnter", self.getCodeValue(value))

	def getOnTrailingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeEnter")
		return result.getCode()

	def setOnTrailingEdgeEnter(self, value: str):
		self.setPropertyValue("onTrailingEdgeEnter", self.getCodeValue(value))

	def getOnLeadingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeExit")
		return result.getCode()

	def setOnLeadingEdgeExit(self, value: str):
		self.setPropertyValue("onLeadingEdgeExit", self.getCodeValue(value))

	def getOnTrailingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeExit")
		return result.getCode()

	def setOnTrailingEdgeExit(self, value: str):
		self.setPropertyValue("onTrailingEdgeExit", self.getCodeValue(value))



class ConveyorSimpleStation(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return ConveyorSimpleStation(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'ConveyorSimpleStation'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getOffset(self) -> float:
		return self.getPropertyValue("Offset")

	def setOffset(self, value: float):
		self.setPropertyValue("Offset", float(value))

	def getLength(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Length")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setLength(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Length", self.getUnitValue(float(value), unit))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getDelayType(self) -> ConveyorSimpleStationDelayType:
		return self.getPropertyValue("delayType")

	def setDelayType(self, value: ConveyorSimpleStationDelayType):
		self.setPropertyValue("delayType", self.getCodeValue(value))

	def getProcessTime(self) -> Tuple[float | str, TimeUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "processTime")
		return result.getCode(), TimeUnits("TimeUnits." + result.getUnit().name())

	def setProcessTime(self, value: float | str, unit: TimeUnits):
		self.setPropertyValue("processTime", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getCapacity(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "capacity")
		return result.getCode()

	def setCapacity(self, value: int | str):
		self.setPropertyValue("capacity", self.getCodeValue(value))

	def getProcessingMode(self) -> ConveyorSimpleStationProcessingMode:
		return self.getPropertyValue("processingMode")

	def setProcessingMode(self, value: ConveyorSimpleStationProcessingMode):
		self.setPropertyValue("processingMode", self.getCodeValue(value))

	def getLoadingMode(self) -> ConveyorSimpleStationLoadingMode:
		return self.getPropertyValue("loadingMode")

	def setLoadingMode(self, value: ConveyorSimpleStationLoadingMode):
		self.setPropertyValue("loadingMode", self.getCodeValue(value))

	def getUseResources(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "useResources")
		return result.getCode()

	def setUseResources(self, value: bool | str):
		self.setPropertyValue("useResources", self.getCodeValue(value))

	def getSeizeFromOnePool(self) -> boolean:
		return self.getPropertyValue("seizeFromOnePool")

	def setSeizeFromOnePool(self, value: boolean):
		self.setPropertyValue("seizeFromOnePool", self.getCodeValue(value))

	def getResourceSets(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceSets")
		return result.getCode()

	def setResourceSets(self, value: str):
		self.setPropertyValue("resourceSets", self.getCodeValue(value))

	def getResourcePool(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourcePool")
		return result.getCode()

	def setResourcePool(self, value: str):
		self.setPropertyValue("resourcePool", self.getCodeValue(value))

	def getResourceQuantity(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceQuantity")
		return result.getCode()

	def setResourceQuantity(self, value: int | str):
		self.setPropertyValue("resourceQuantity", self.getCodeValue(value))

	def getSendResources(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "sendResources")
		return result.getCode()

	def setSendResources(self, value: bool | str):
		self.setPropertyValue("sendResources", self.getCodeValue(value))

	def getResourceDestinationType(self) -> processmodeling_Seize_DestinationType:
		return self.getPropertyValue("resourceDestinationType")

	def setResourceDestinationType(self, value: processmodeling_Seize_DestinationType):
		self.setPropertyValue("resourceDestinationType", self.getCodeValue(value))

	def getResourceDestinationNode(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceDestinationNode")
		return result.getCode()

	def setResourceDestinationNode(self, value: str):
		self.setPropertyValue("resourceDestinationNode", self.getCodeValue(value))

	def getResourceDestinationAttractor(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceDestinationAttractor")
		return result.getCode()

	def setResourceDestinationAttractor(self, value: str):
		self.setPropertyValue("resourceDestinationAttractor", self.getCodeValue(value))

	def getResourceDestinationX(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceDestinationX")
		return result.getCode()

	def setResourceDestinationX(self, value: float | str):
		self.setPropertyValue("resourceDestinationX", self.getCodeValue(value))

	def getResourceDestinationY(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceDestinationY")
		return result.getCode()

	def setResourceDestinationY(self, value: float | str):
		self.setPropertyValue("resourceDestinationY", self.getCodeValue(value))

	def getResourceDestinationZ(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceDestinationZ")
		return result.getCode()

	def setResourceDestinationZ(self, value: float | str):
		self.setPropertyValue("resourceDestinationZ", self.getCodeValue(value))

	def getMovingGoHome(self) -> boolean:
		return self.getPropertyValue("movingGoHome")

	def setMovingGoHome(self, value: boolean):
		self.setPropertyValue("movingGoHome", self.getCodeValue(value))

	def getCustomizeResourceChoice(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "customizeResourceChoice")
		return result.getCode()

	def setCustomizeResourceChoice(self, value: bool | str):
		self.setPropertyValue("customizeResourceChoice", self.getCodeValue(value))

	def getResourceChoiceCondition(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "resourceChoiceCondition")
		return result.getCode()

	def setResourceChoiceCondition(self, value: bool | str):
		self.setPropertyValue("resourceChoiceCondition", self.getCodeValue(value))

	def getPriority(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "priority")
		return result.getCode()

	def setPriority(self, value: float | str):
		self.setPropertyValue("priority", self.getCodeValue(value))

	def getTaskMayPreemptOtherTasks(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "taskMayPreemptOtherTasks")
		return result.getCode()

	def setTaskMayPreemptOtherTasks(self, value: bool | str):
		self.setPropertyValue("taskMayPreemptOtherTasks", self.getCodeValue(value))

	def getTaskPreemptionPolicy(self) -> TaskPreemptionPolicy:
		return self.getPropertyValue("taskPreemptionPolicy")

	def setTaskPreemptionPolicy(self, value: TaskPreemptionPolicy):
		self.setPropertyValue("taskPreemptionPolicy", self.getCodeValue(value))

	def getOnProcessStarted(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onProcessStarted")
		return result.getCode()

	def setOnProcessStarted(self, value: str):
		self.setPropertyValue("onProcessStarted", self.getCodeValue(value))

	def getOnProcessFinished(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onProcessFinished")
		return result.getCode()

	def setOnProcessFinished(self, value: str):
		self.setPropertyValue("onProcessFinished", self.getCodeValue(value))

	def getOnLeadingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeEnter")
		return result.getCode()

	def setOnLeadingEdgeEnter(self, value: str):
		self.setPropertyValue("onLeadingEdgeEnter", self.getCodeValue(value))

	def getOnTrailingEdgeEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeEnter")
		return result.getCode()

	def setOnTrailingEdgeEnter(self, value: str):
		self.setPropertyValue("onTrailingEdgeEnter", self.getCodeValue(value))

	def getOnLeadingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLeadingEdgeExit")
		return result.getCode()

	def setOnLeadingEdgeExit(self, value: str):
		self.setPropertyValue("onLeadingEdgeExit", self.getCodeValue(value))

	def getOnTrailingEdgeExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrailingEdgeExit")
		return result.getCode()

	def setOnTrailingEdgeExit(self, value: str):
		self.setPropertyValue("onTrailingEdgeExit", self.getCodeValue(value))

	def getOnTaskSuspended(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTaskSuspended")
		return result.getCode()

	def setOnTaskSuspended(self, value: str):
		self.setPropertyValue("onTaskSuspended", self.getCodeValue(value))

	def getOnTaskResumed(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTaskResumed")
		return result.getCode()

	def setOnTaskResumed(self, value: str):
		self.setPropertyValue("onTaskResumed", self.getCodeValue(value))

	def getOnTaskTerminated(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTaskTerminated")
		return result.getCode()

	def setOnTaskTerminated(self, value: str):
		self.setPropertyValue("onTaskTerminated", self.getCodeValue(value))

	def getDowntimes(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "downtimes")
		return result.getCode()

	def setDowntimes(self, value: str):
		self.setPropertyValue("downtimes", self.getCodeValue(value))



class CustomStation(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return CustomStation(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'CustomStation'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))

	def getAgentLocation(self) -> ConveyorCustomStationAgentLocation:
		return self.getPropertyValue("agentLocation")

	def setAgentLocation(self, value: ConveyorCustomStationAgentLocation):
		self.setPropertyValue("agentLocation", self.getCodeValue(value))

	def getOnEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onEnter")
		return result.getCode()

	def setOnEnter(self, value: str):
		self.setPropertyValue("onEnter", self.getCodeValue(value))



class ConveyorNetwork(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return ConveyorNetwork(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'ConveyorNetwork'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))



class Robot(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Robot(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Robot'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def isBlockedZoneEnabled(self) -> bool:
		return self.getPropertyValue("CRANE_BLOCKED_ZONE_ENABLED")

	def setBlockedZoneEnabled(self, value: bool):
		self.setPropertyValue("CRANE_BLOCKED_ZONE_ENABLED", bool(value))

	def getBlockedZoneStartAngle(self) -> float:
		return self.getPropertyValue("CRANE_BLOCKED_ZONE_START_ANGLE")

	def setBlockedZoneStartAngle(self, value: float):
		self.setPropertyValue("CRANE_BLOCKED_ZONE_START_ANGLE", float(value))

	def getBlockedZoneAngle(self) -> float:
		return self.getPropertyValue("CRANE_BLOCKED_ZONE_ANGLE")

	def setBlockedZoneAngle(self, value: float):
		self.setPropertyValue("CRANE_BLOCKED_ZONE_ANGLE", float(value))

	def getMaximumArmReach(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "MAXIMUM_ARM_REACH")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setMaximumArmReach(self, value: float, unit: LengthUnits):
		self.setPropertyValue("MAXIMUM_ARM_REACH", self.getUnitValue(float(value), unit))

	def getInitialEndEffectorX(self) -> float:
		return self.getPropertyValue("ROBOT_INITIAL_END_EFFECTOR_X")

	def setInitialEndEffectorX(self, value: float):
		self.setPropertyValue("ROBOT_INITIAL_END_EFFECTOR_X", float(value))

	def getInitialEndEffectorY(self) -> float:
		return self.getPropertyValue("ROBOT_INITIAL_END_EFFECTOR_Y")

	def setInitialEndEffectorY(self, value: float):
		self.setPropertyValue("ROBOT_INITIAL_END_EFFECTOR_Y", float(value))

	def getInitialEndEffectorZ(self) -> float:
		return self.getPropertyValue("ROBOT_INITIAL_END_EFFECTOR_Z")

	def setInitialEndEffectorZ(self, value: float):
		self.setPropertyValue("ROBOT_INITIAL_END_EFFECTOR_Z", float(value))

	def getLinksColor(self) -> int:
		return self.getPropertyValue("ROBOT_LINKS_COLOR")

	def setLinksColor(self, value: int):
		self.setPropertyValue("ROBOT_LINKS_COLOR", int(value))

	def getEndEffectorColor(self) -> int:
		return self.getPropertyValue("ROBOT_END_EFFECTOR_COLOR")

	def setEndEffectorColor(self, value: int):
		self.setPropertyValue("ROBOT_END_EFFECTOR_COLOR", int(value))

	def getLinksLength(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "LINKS_LENGTH")
		return reduce(list.__add__, map(lambda r: [r],result))

	def setLinksLength(self, value: List[float]):
		self.setPropertyValue("LINKS_LENGTH", self.javaDoubleArray(value))

	def getOnSeize(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onSeize")
		return result.getCode()

	def setOnSeize(self, value: str):
		self.setPropertyValue("onSeize", self.getCodeValue(value))

	def getOnRobotMovementStart(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onRobotMovementStart")
		return result.getCode()

	def setOnRobotMovementStart(self, value: str):
		self.setPropertyValue("onRobotMovementStart", self.getCodeValue(value))

	def getOnRobotMovementEnd(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onRobotMovementEnd")
		return result.getCode()

	def setOnRobotMovementEnd(self, value: str):
		self.setPropertyValue("onRobotMovementEnd", self.getCodeValue(value))

	def getOnAgentProcessingStart(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onAgentProcessingStart")
		return result.getCode()

	def setOnAgentProcessingStart(self, value: str):
		self.setPropertyValue("onAgentProcessingStart", self.getCodeValue(value))

	def getOnAgentProcessingEnd(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onAgentProcessingEnd")
		return result.getCode()

	def setOnAgentProcessingEnd(self, value: str):
		self.setPropertyValue("onAgentProcessingEnd", self.getCodeValue(value))

	def getOnRelease(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onRelease")
		return result.getCode()

	def setOnRelease(self, value: str):
		self.setPropertyValue("onRelease", self.getCodeValue(value))

	def getOnRobotStateChanged(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onRobotStateChanged")
		return result.getCode()

	def setOnRobotStateChanged(self, value: str):
		self.setPropertyValue("onRobotStateChanged", self.getCodeValue(value))

	def getEndEffector(self) -> RobotEndEffector:
		return self.getPropertyValue("endEffector")

	def setEndEffector(self, value: RobotEndEffector):
		self.setPropertyValue("endEffector", self.getCodeValue(value))

	def getGripperLength(self) -> Tuple[float | str, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "gripperLength")
		return result.getCode(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setGripperLength(self, value: float | str, unit: LengthUnits):
		self.setPropertyValue("gripperLength", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getVacuumGripperWidth(self) -> Tuple[float | str, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "vacuumGripperWidth")
		return result.getCode(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setVacuumGripperWidth(self, value: float | str, unit: LengthUnits):
		self.setPropertyValue("vacuumGripperWidth", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getVacuumGripperLength(self) -> Tuple[float | str, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "vacuumGripperLength")
		return result.getCode(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setVacuumGripperLength(self, value: float | str, unit: LengthUnits):
		self.setPropertyValue("vacuumGripperLength", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getWeldingGunLength(self) -> Tuple[float | str, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "weldingGunLength")
		return result.getCode(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setWeldingGunLength(self, value: float | str, unit: LengthUnits):
		self.setPropertyValue("weldingGunLength", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))



class Crane(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Crane(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Crane'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getJibAngle(self) -> float:
		return self.getPropertyValue("CRANE_JIB_ANGLE")

	def setJibAngle(self, value: float):
		self.setPropertyValue("CRANE_JIB_ANGLE", float(value))

	def getTrolleyLocation(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "TROLLEY_LOCATION")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setTrolleyLocation(self, value: float, unit: LengthUnits):
		self.setPropertyValue("TROLLEY_LOCATION", self.getUnitValue(float(value), unit))

	def isBlockedZoneEnabled(self) -> bool:
		return self.getPropertyValue("CRANE_BLOCKED_ZONE_ENABLED")

	def setBlockedZoneEnabled(self, value: bool):
		self.setPropertyValue("CRANE_BLOCKED_ZONE_ENABLED", bool(value))

	def getBlockedZoneStartAngle(self) -> float:
		return self.getPropertyValue("CRANE_BLOCKED_ZONE_START_ANGLE")

	def setBlockedZoneStartAngle(self, value: float):
		self.setPropertyValue("CRANE_BLOCKED_ZONE_START_ANGLE", float(value))

	def getBlockedZoneAngle(self) -> float:
		return self.getPropertyValue("CRANE_BLOCKED_ZONE_ANGLE")

	def setBlockedZoneAngle(self, value: float):
		self.setPropertyValue("CRANE_BLOCKED_ZONE_ANGLE", float(value))

	def getJibLength(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "CRANE_JIB_LENGTH")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setJibLength(self, value: float, unit: LengthUnits):
		self.setPropertyValue("CRANE_JIB_LENGTH", self.getUnitValue(float(value), unit))

	def getCraneHeight(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "CRANE_HEIGHT")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setCraneHeight(self, value: float, unit: LengthUnits):
		self.setPropertyValue("CRANE_HEIGHT", self.getUnitValue(float(value), unit))

	def getType(self) -> JibCraneType:
		return self.getPropertyValue("CRANE_STYLE")

	def setType(self, value: JibCraneType):
		self.setPropertyValue("CRANE_STYLE", value)

	def getCabinColor(self) -> int:
		return self.getPropertyValue("CRANE_CABIN_COLOR_PROP")

	def setCabinColor(self, value: int):
		self.setPropertyValue("CRANE_CABIN_COLOR_PROP", int(value))

	def getColor(self) -> int:
		return self.getPropertyValue("CRANE_COLOR_PROP")

	def setColor(self, value: int):
		self.setPropertyValue("CRANE_COLOR_PROP", int(value))

	def getMovementMode(self) -> JibCraneMovementMode:
		return self.getPropertyValue("movementMode")

	def setMovementMode(self, value: JibCraneMovementMode):
		self.setPropertyValue("movementMode", self.getCodeValue(value))

	def getTrolleySpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "trolleySpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setTrolleySpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("trolleySpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getLiftingSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "liftingSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setLiftingSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("liftingSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getRotationSpeed(self) -> Tuple[float | str, RotationSpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "rotationSpeed")
		return result.getCode(), RotationSpeedUnits("RotationSpeedUnits." + result.getUnit().name())

	def setRotationSpeed(self, value: float | str, unit: RotationSpeedUnits):
		self.setPropertyValue("rotationSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getOnLoading(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLoading")
		return result.getCode()

	def setOnLoading(self, value: str):
		self.setPropertyValue("onLoading", self.getCodeValue(value))

	def getOnUnloading(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onUnloading")
		return result.getCode()

	def setOnUnloading(self, value: str):
		self.setPropertyValue("onUnloading", self.getCodeValue(value))

	def getOnSeize(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onSeize")
		return result.getCode()

	def setOnSeize(self, value: str):
		self.setPropertyValue("onSeize", self.getCodeValue(value))

	def getOnRelease(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onRelease")
		return result.getCode()

	def setOnRelease(self, value: str):
		self.setPropertyValue("onRelease", self.getCodeValue(value))

	def getDowntimes(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "downtimes")
		return result.getCode()

	def setDowntimes(self, value: str):
		self.setPropertyValue("downtimes", self.getCodeValue(value))



class OverheadCrane(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return OverheadCrane(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'OverheadCrane'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))

	def getRunwayLength(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Length")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setRunwayLength(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Length", self.getUnitValue(float(value), unit))

	def getCraneWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setCraneWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Width", self.getUnitValue(float(value), unit))

	def getCraneHeight(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "CRANE_HEIGHT")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setCraneHeight(self, value: float, unit: LengthUnits):
		self.setPropertyValue("CRANE_HEIGHT", self.getUnitValue(float(value), unit))

	def getBridgeWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "BRIDGE_WIDTH")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setBridgeWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("BRIDGE_WIDTH", self.getUnitValue(float(value), unit))

	def getBridgeSafetyGap(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "BRIDGE_SAFETY_GAP")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setBridgeSafetyGap(self, value: float, unit: LengthUnits):
		self.setPropertyValue("BRIDGE_SAFETY_GAP", self.getUnitValue(float(value), unit))

	def getType(self) -> OverheadCraneType:
		return self.getPropertyValue("CRANE_STYLE")

	def setType(self, value: OverheadCraneType):
		self.setPropertyValue("CRANE_STYLE", value)

	def getGirderType(self) -> OverheadCraneGirderType:
		return self.getPropertyValue("GIRDER_TYPE")

	def setGirderType(self, value: OverheadCraneGirderType):
		self.setPropertyValue("GIRDER_TYPE", value)

	def getTrolleyColor(self) -> int:
		return self.getPropertyValue("CRANE_TROLLEY_COLOR_PROP")

	def setTrolleyColor(self, value: int):
		self.setPropertyValue("CRANE_TROLLEY_COLOR_PROP", int(value))

	def getColor(self) -> int:
		return self.getPropertyValue("CRANE_COLOR_PROP")

	def setColor(self, value: int):
		self.setPropertyValue("CRANE_COLOR_PROP", int(value))

	def getMovementMode(self) -> OverheadCraneMovementMode:
		return self.getPropertyValue("movementMode")

	def setMovementMode(self, value: OverheadCraneMovementMode):
		self.setPropertyValue("movementMode", self.getCodeValue(value))

	def getBridgeSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "bridgeSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setBridgeSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("bridgeSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getTrolleySpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "trolleySpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setTrolleySpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("trolleySpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getHoistSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "hoistSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setHoistSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("hoistSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getAccelerationEnabled(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "accelerationEnabled")
		return result.getCode()

	def setAccelerationEnabled(self, value: bool | str):
		self.setPropertyValue("accelerationEnabled", self.getCodeValue(value))

	def getBridgeAcceleration(self) -> Tuple[float | str, AccelerationUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "bridgeAcceleration")
		return result.getCode(), AccelerationUnits("AccelerationUnits." + result.getUnit().name())

	def setBridgeAcceleration(self, value: float | str, unit: AccelerationUnits):
		self.setPropertyValue("bridgeAcceleration", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getBridgeDeceleration(self) -> Tuple[float | str, AccelerationUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "bridgeDeceleration")
		return result.getCode(), AccelerationUnits("AccelerationUnits." + result.getUnit().name())

	def setBridgeDeceleration(self, value: float | str, unit: AccelerationUnits):
		self.setPropertyValue("bridgeDeceleration", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getTrolleyAcceleration(self) -> Tuple[float | str, AccelerationUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "trolleyAcceleration")
		return result.getCode(), AccelerationUnits("AccelerationUnits." + result.getUnit().name())

	def setTrolleyAcceleration(self, value: float | str, unit: AccelerationUnits):
		self.setPropertyValue("trolleyAcceleration", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getTrolleyDeceleration(self) -> Tuple[float | str, AccelerationUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "trolleyDeceleration")
		return result.getCode(), AccelerationUnits("AccelerationUnits." + result.getUnit().name())

	def setTrolleyDeceleration(self, value: float | str, unit: AccelerationUnits):
		self.setPropertyValue("trolleyDeceleration", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getOnLoading(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onLoading")
		return result.getCode()

	def setOnLoading(self, value: str):
		self.setPropertyValue("onLoading", self.getCodeValue(value))

	def getOnUnloading(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onUnloading")
		return result.getCode()

	def setOnUnloading(self, value: str):
		self.setPropertyValue("onUnloading", self.getCodeValue(value))

	def getOnTargetReached(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTargetReached")
		return result.getCode()

	def setOnTargetReached(self, value: str):
		self.setPropertyValue("onTargetReached", self.getCodeValue(value))

	def getOnBridgeMovementFinished(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onBridgeMovementFinished")
		return result.getCode()

	def setOnBridgeMovementFinished(self, value: str):
		self.setPropertyValue("onBridgeMovementFinished", self.getCodeValue(value))

	def getOnBridgeStateChange(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onBridgeStateChange")
		return result.getCode()

	def setOnBridgeStateChange(self, value: str):
		self.setPropertyValue("onBridgeStateChange", self.getCodeValue(value))

	def getOnSeize(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onSeize")
		return result.getCode()

	def setOnSeize(self, value: str):
		self.setPropertyValue("onSeize", self.getCodeValue(value))

	def getOnRelease(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onRelease")
		return result.getCode()

	def setOnRelease(self, value: str):
		self.setPropertyValue("onRelease", self.getCodeValue(value))

	def getDowntimes(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "downtimes")
		return result.getCode()

	def setDowntimes(self, value: str):
		self.setPropertyValue("downtimes", self.getCodeValue(value))



class OverheadCraneBridge(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return OverheadCraneBridge(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'OverheadCraneBridge'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getParkingPosition(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "BRIDGE_PARKING_POSITION")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setParkingPosition(self, value: float, unit: LengthUnits):
		self.setPropertyValue("BRIDGE_PARKING_POSITION", self.getUnitValue(float(value), unit))

	def getTrolleyLocation(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "TROLLEY_LOCATION")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setTrolleyLocation(self, value: float, unit: LengthUnits):
		self.setPropertyValue("TROLLEY_LOCATION", self.getUnitValue(float(value), unit))

	def getColor(self) -> int:
		return self.getPropertyValue("CRANE_COLOR_PROP")

	def setColor(self, value: int):
		self.setPropertyValue("CRANE_COLOR_PROP", int(value))



class RackStorage(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RackStorage(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RackStorage'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getRackType(self) -> RackTypeEnum:
		return self.getPropertyValue("RACK_TYPE")

	def setRackType(self, value: RackTypeEnum):
		self.setPropertyValue("RACK_TYPE", value)

	def getRackConfigurationType(self) -> RackConfigurationTypeEnum:
		return self.getPropertyValue("STORAGE_RACK_CONFIGURATION_TYPE")

	def setRackConfigurationType(self, value: RackConfigurationTypeEnum):
		self.setPropertyValue("STORAGE_RACK_CONFIGURATION_TYPE", value)

	def isFlipped(self) -> bool:
		return self.getPropertyValue("STORAGE_FLIPPED")

	def setFlipped(self, value: bool):
		self.setPropertyValue("STORAGE_FLIPPED", bool(value))

	def getSlotDepth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "STORAGE_RACK_DEPTH")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setSlotDepth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("STORAGE_RACK_DEPTH", self.getUnitValue(float(value), unit))

	def getUnitsDefinitionType(self) -> StorageUnitsDefinitionTypeEnum:
		return self.getPropertyValue("STORAGE_UNITS_DEFINITION_TYPE")

	def setUnitsDefinitionType(self, value: StorageUnitsDefinitionTypeEnum):
		self.setPropertyValue("STORAGE_UNITS_DEFINITION_TYPE", value)

	def getAisleWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "STORAGE_RACK_AISLE_WIDTH")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setAisleWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("STORAGE_RACK_AISLE_WIDTH", self.getUnitValue(float(value), unit))

	def getNumberOfUnits(self) -> int:
		return self.getPropertyValue("STORAGE_NUMBER_OF_UNITS")

	def setNumberOfUnits(self, value: int):
		self.setPropertyValue("STORAGE_NUMBER_OF_UNITS", int(value))

	def isPlaceSingleRacksAtSides(self) -> bool:
		return self.getPropertyValue("STORAGE_PLACE_SINGLE_UNITS")

	def setPlaceSingleRacksAtSides(self, value: bool):
		self.setPropertyValue("STORAGE_PLACE_SINGLE_UNITS", bool(value))

	def isOddRackAtTheLeft(self) -> bool:
		return self.getPropertyValue("STORAGE_SINGLE_RACK")

	def setOddRackAtTheLeft(self, value: bool):
		self.setPropertyValue("STORAGE_SINGLE_RACK", bool(value))

	def getBayDefinitionType(self) -> StorageBaysDefinitionTypeEnum:
		return self.getPropertyValue("STORAGE_BAYS_DEFINITION_TYPE")

	def setBayDefinitionType(self, value: StorageBaysDefinitionTypeEnum):
		self.setPropertyValue("STORAGE_BAYS_DEFINITION_TYPE", value)

	def getNumberOfBays(self) -> int:
		return self.getPropertyValue("STORAGE_NUMBER_OF_BAYS")

	def setNumberOfBays(self, value: int):
		self.setPropertyValue("STORAGE_NUMBER_OF_BAYS", int(value))

	def getCellWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "RACK_CELL_WIDTH")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setCellWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("RACK_CELL_WIDTH", self.getUnitValue(float(value), unit))

	def getNumberOfCellsPerSlot(self) -> int:
		return self.getPropertyValue("STORAGE_NUMBER_OF_CELLS_PER_SLOT")

	def setNumberOfCellsPerSlot(self, value: int):
		self.setPropertyValue("STORAGE_NUMBER_OF_CELLS_PER_SLOT", int(value))

	def getNumberOfShelves(self) -> int:
		return self.getPropertyValue("STORAGE_NUMBER_OF_SHELVES")

	def setNumberOfShelves(self, value: int):
		self.setPropertyValue("STORAGE_NUMBER_OF_SHELVES", int(value))

	def getShelfHeight(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "STORAGE_SHELF_HEIGHT")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setShelfHeight(self, value: float, unit: LengthUnits):
		self.setPropertyValue("STORAGE_SHELF_HEIGHT", self.getUnitValue(float(value), unit))

	def getRotation(self) -> float:
		return self.getPropertyValue("STORAGE_RACK_ROTATION_PROP")

	def setRotation(self, value: float):
		self.setPropertyValue("STORAGE_RACK_ROTATION_PROP", float(value))

	def getWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "STORAGE_RACK_WIDTH")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("STORAGE_RACK_WIDTH", self.getUnitValue(float(value), unit))

	def getHeight(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "STORAGE_RACK_HEIGHT_PROP")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setHeight(self, value: float, unit: LengthUnits):
		self.setPropertyValue("STORAGE_RACK_HEIGHT_PROP", self.getUnitValue(float(value), unit))

	def getAccessZone(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "STORAGE_LEFT_PASSAGE")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setAccessZone(self, value: float, unit: LengthUnits):
		self.setPropertyValue("STORAGE_LEFT_PASSAGE", self.getUnitValue(float(value), unit))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getTiltAngle(self) -> float:
		return self.getPropertyValue("Angle")

	def setTiltAngle(self, value: float):
		self.setPropertyValue("Angle", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def isSimplifiedAgentAnimation(self) -> bool:
		return self.getPropertyValue("Storage simplified animation")

	def setSimplifiedAgentAnimation(self, value: bool):
		self.setPropertyValue("Storage simplified animation", bool(value))

	def isDrawLegs(self) -> bool:
		return self.getPropertyValue("Storage Draw Legs")

	def setDrawLegs(self, value: bool):
		self.setPropertyValue("Storage Draw Legs", bool(value))

	def getBaysBetweenLegs(self) -> int:
		return self.getPropertyValue("Storage Cells between Legs")

	def setBaysBetweenLegs(self, value: int):
		self.setPropertyValue("Storage Cells between Legs", int(value))

	def getSpecifiedInslotSpeed(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "specifiedInslotSpeed")
		return result.getCode()

	def setSpecifiedInslotSpeed(self, value: bool | str):
		self.setPropertyValue("specifiedInslotSpeed", self.getCodeValue(value))

	def getInslotSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "inslotSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setInslotSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("inslotSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getRestrictedAisleAccess(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "restrictedAisleAccess")
		return result.getCode()

	def setRestrictedAisleAccess(self, value: bool | str):
		self.setPropertyValue("restrictedAisleAccess", self.getCodeValue(value))

	def getAisleCapacityRestriction(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "aisleCapacityRestriction")
		return result.getCode()

	def setAisleCapacityRestriction(self, value: int | str):
		self.setPropertyValue("aisleCapacityRestriction", self.getCodeValue(value))

	def getOnAgentStorage(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onAgentStorage")
		return result.getCode()

	def setOnAgentStorage(self, value: str):
		self.setPropertyValue("onAgentStorage", self.getCodeValue(value))

	def getOnAgentRetrieval(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onAgentRetrieval")
		return result.getCode()

	def setOnAgentRetrieval(self, value: str):
		self.setPropertyValue("onAgentRetrieval", self.getCodeValue(value))



class Lift(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Lift(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Lift'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isObstacle(self) -> bool:
		return self.getPropertyValue("IS_OBSTACLE_PROP")

	def setObstacle(self, value: bool):
		self.setPropertyValue("IS_OBSTACLE_PROP", bool(value))

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))

	def getWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Width", self.getUnitValue(float(value), unit))

	def getDepth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Depth")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setDepth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Depth", self.getUnitValue(float(value), unit))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getFillColor(self) -> int:
		return self.getPropertyValue("Fill Color")

	def setFillColor(self, value: int):
		self.setPropertyValue("Fill Color", int(value))

	def getPlatformType(self) -> LiftPlatformDrawingTypeEnum:
		return self.getPropertyValue("LIFT_PLATFORM_TYPE")

	def setPlatformType(self, value: LiftPlatformDrawingTypeEnum):
		self.setPropertyValue("LIFT_PLATFORM_TYPE", value)

	def getFloorElevation(self) -> Tuple[float | str, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "floorElevation")
		return result.getCode(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setFloorElevation(self, value: float | str, unit: LengthUnits):
		self.setPropertyValue("floorElevation", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getMainLanding(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "mainLanding")
		return result.getCode()

	def setMainLanding(self, value: bool | str):
		self.setPropertyValue("mainLanding", self.getCodeValue(value))

	def getMainLift(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "mainLift")
		return result.getCode()

	def setMainLift(self, value: str):
		self.setPropertyValue("mainLift", self.getCodeValue(value))

	def getLiftingSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "liftingSpeed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setLiftingSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("liftingSpeed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getPickingUpTime(self) -> Tuple[float | str, TimeUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pickingUpTime")
		return result.getCode(), TimeUnits("TimeUnits." + result.getUnit().name())

	def setPickingUpTime(self, value: float | str, unit: TimeUnits):
		self.setPropertyValue("pickingUpTime", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getDroppingOffTime(self) -> Tuple[float | str, TimeUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "droppingOffTime")
		return result.getCode(), TimeUnits("TimeUnits." + result.getUnit().name())

	def setDroppingOffTime(self, value: float | str, unit: TimeUnits):
		self.setPropertyValue("droppingOffTime", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getSelectionMode(self) -> LiftSelectionMode:
		return self.getPropertyValue("selectionMode")

	def setSelectionMode(self, value: LiftSelectionMode):
		self.setPropertyValue("selectionMode", self.getCodeValue(value))

	def getPriority(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "priority")
		return result.getCode()

	def setPriority(self, value: float | str):
		self.setPropertyValue("priority", self.getCodeValue(value))

	def getComparison(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "comparison")
		return result.getCode()

	def setComparison(self, value: bool | str):
		self.setPropertyValue("comparison", self.getCodeValue(value))

	def getOnPickupStarted(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onPickupStarted")
		return result.getCode()

	def setOnPickupStarted(self, value: str):
		self.setPropertyValue("onPickupStarted", self.getCodeValue(value))

	def getOnDropoffFinished(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onDropoffFinished")
		return result.getCode()

	def setOnDropoffFinished(self, value: str):
		self.setPropertyValue("onDropoffFinished", self.getCodeValue(value))



class Wall(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Wall(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Wall'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getFillingType(self) -> WallFillingTypeEnum:
		return self.getPropertyValue("Wall Filling Type")

	def setFillingType(self, value: WallFillingTypeEnum):
		self.setPropertyValue("Wall Filling Type", value)

	def getZHeight(self) -> float:
		return self.getPropertyValue("z Height")

	def setZHeight(self, value: float):
		self.setPropertyValue("z Height", float(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))

	def isClosed(self) -> bool:
		return self.getPropertyValue("Polyline closed")

	def setClosed(self, value: bool):
		self.setPropertyValue("Polyline closed", bool(value))



class RectangleWall(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RectangleWall(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RectangleWall'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getFillingType(self) -> WallFillingTypeEnum:
		return self.getPropertyValue("Wall Filling Type")

	def setFillingType(self, value: WallFillingTypeEnum):
		self.setPropertyValue("Wall Filling Type", value)

	def getZHeight(self) -> float:
		return self.getPropertyValue("z Height")

	def setZHeight(self, value: float):
		self.setPropertyValue("z Height", float(value))

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))

	def getWidth(self) -> float:
		return self.getPropertyValue("Width")

	def setWidth(self, value: float):
		self.setPropertyValue("Width", float(value))

	def getHeight(self) -> float:
		return self.getPropertyValue("Height")

	def setHeight(self, value: float):
		self.setPropertyValue("Height", float(value))



class OvalWall(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return OvalWall(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'OvalWall'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getFillingType(self) -> WallFillingTypeEnum:
		return self.getPropertyValue("Wall Filling Type")

	def setFillingType(self, value: WallFillingTypeEnum):
		self.setPropertyValue("Wall Filling Type", value)

	def getZHeight(self) -> float:
		return self.getPropertyValue("z Height")

	def setZHeight(self, value: float):
		self.setPropertyValue("z Height", float(value))

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))

	def getRadiusX(self) -> float:
		return self.getPropertyValue("Radius X")

	def setRadiusX(self, value: float):
		self.setPropertyValue("Radius X", float(value))

	def getRadiusY(self) -> float:
		return self.getPropertyValue("Radius Y")

	def setRadiusY(self, value: float):
		self.setPropertyValue("Radius Y", float(value))

	def isCircle(self) -> bool:
		return self.getPropertyValue("Circle")

	def setCircle(self, value: bool):
		self.setPropertyValue("Circle", bool(value))



class TargetLine(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return TargetLine(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'TargetLine'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))



class EscalatorGroup(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return EscalatorGroup(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'EscalatorGroup'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Speed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("Speed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getStepDepth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Step Depth")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setStepDepth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Step Depth", self.getUnitValue(float(value), unit))

	def getSlopeType(self) -> EscalatorSlopeTypeEnum:
		return self.getPropertyValue("Slope Type")

	def setSlopeType(self, value: EscalatorSlopeTypeEnum):
		self.setPropertyValue("Slope Type", value)

	def getAngle(self) -> float:
		return self.getPropertyValue("Angle")

	def setAngle(self, value: float):
		self.setPropertyValue("Angle", float(value))

	def getRise(self) -> float:
		return self.getPropertyValue("Rise")

	def setRise(self, value: float):
		self.setPropertyValue("Rise", float(value))

	def getPedestrianBehaviorUp(self) -> EscalatorPedestrianBehavior:
		return self.getPropertyValue("Escalator Pedestrian Behavior Up")

	def setPedestrianBehaviorUp(self, value: EscalatorPedestrianBehavior):
		self.setPropertyValue("Escalator Pedestrian Behavior Up", value)

	def getWalkingPercentageUpCode(self) -> str:
		return self.getPropertyValue("Escalator Pedestrian Walking Percentage Up Code")

	def setWalkingPercentageUpCode(self, value: str):
		self.setPropertyValue("Escalator Pedestrian Walking Percentage Up Code", value)

	def getPedestrianBehaviorDown(self) -> EscalatorPedestrianBehavior:
		return self.getPropertyValue("Escalator Pedestrian Behavior Down")

	def setPedestrianBehaviorDown(self, value: EscalatorPedestrianBehavior):
		self.setPropertyValue("Escalator Pedestrian Behavior Down", value)

	def getWalkingPercentageDownCode(self) -> str:
		return self.getPropertyValue("Escalator Pedestrian Walking Percentage Down Code")

	def setWalkingPercentageDownCode(self, value: str):
		self.setPropertyValue("Escalator Pedestrian Walking Percentage Down Code", value)

	def getWidth(self) -> float:
		return self.getPropertyValue("Width")

	def setWidth(self, value: float):
		self.setPropertyValue("Width", float(value))

	def getLength(self) -> float:
		return self.getPropertyValue("Length")

	def setLength(self, value: float):
		self.setPropertyValue("Length", float(value))

	def getLowerLandingLength(self) -> float:
		return self.getPropertyValue("Lower Landing Length")

	def setLowerLandingLength(self, value: float):
		self.setPropertyValue("Lower Landing Length", float(value))

	def getUpperLandingLength(self) -> float:
		return self.getPropertyValue("Upper Landing Length")

	def setUpperLandingLength(self, value: float):
		self.setPropertyValue("Upper Landing Length", float(value))

	def getLeftBalustradeWidth(self) -> float:
		return self.getPropertyValue("Left Balustrade Width")

	def setLeftBalustradeWidth(self, value: float):
		self.setPropertyValue("Left Balustrade Width", float(value))

	def getRightBalustradeWidth(self) -> float:
		return self.getPropertyValue("Rigth Balustrade Width")

	def setRightBalustradeWidth(self, value: float):
		self.setPropertyValue("Rigth Balustrade Width", float(value))

	def getInternalBalustradeWidth(self) -> float:
		return self.getPropertyValue("Internal Balustrade Width")

	def setInternalBalustradeWidth(self, value: float):
		self.setPropertyValue("Internal Balustrade Width", float(value))

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))

	def getBalustradeColor(self) -> int:
		return self.getPropertyValue("Escalator Balustrade Color")

	def setBalustradeColor(self, value: int):
		self.setPropertyValue("Escalator Balustrade Color", int(value))

	def isSolidBalustrade(self) -> bool:
		return self.getPropertyValue("Escalator Solid Balustrade")

	def setSolidBalustrade(self, value: bool):
		self.setPropertyValue("Escalator Solid Balustrade", bool(value))



class Elevator(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Elevator(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Elevator'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getDoorsConfiguration(self) -> ElevatorDoorsConfiguration:
		return self.getPropertyValue("Elevator doors configuration")

	def setDoorsConfiguration(self, value: ElevatorDoorsConfiguration):
		self.setPropertyValue("Elevator doors configuration", value)

	def getRotation(self) -> float:
		return self.getPropertyValue("Rotation")

	def setRotation(self, value: float):
		self.setPropertyValue("Rotation", float(value))

	def getWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Width", self.getUnitValue(float(value), unit))

	def getDepth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Depth")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setDepth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Depth", self.getUnitValue(float(value), unit))

	def getWallColor(self) -> int:
		return self.getPropertyValue("Wall Color")

	def setWallColor(self, value: int):
		self.setPropertyValue("Wall Color", int(value))

	def getPlatformColor(self) -> int:
		return self.getPropertyValue("Platform Color")

	def setPlatformColor(self, value: int):
		self.setPropertyValue("Platform Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getCabinHeight(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Elevator Cabin Height")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setCabinHeight(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Elevator Cabin Height", self.getUnitValue(float(value), unit))

	def isDrawShaft(self) -> bool:
		return self.getPropertyValue("Draw shaft")

	def setDrawShaft(self, value: bool):
		self.setPropertyValue("Draw shaft", bool(value))

	def getCapacity(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "capacity")
		return result.getCode()

	def setCapacity(self, value: int | str):
		self.setPropertyValue("capacity", self.getCodeValue(value))

	def getMovementMode(self) -> ElevatorMovementMode:
		return self.getPropertyValue("movementMode")

	def setMovementMode(self, value: ElevatorMovementMode):
		self.setPropertyValue("movementMode", self.getCodeValue(value))

	def getSpeed(self) -> Tuple[float | str, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "speed")
		return result.getCode(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeed(self, value: float | str, unit: SpeedUnits):
		self.setPropertyValue("speed", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getTimePerLevel(self) -> Tuple[float | str, TimeUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "timePerLevel")
		return result.getCode(), TimeUnits("TimeUnits." + result.getUnit().name())

	def setTimePerLevel(self, value: float | str, unit: TimeUnits):
		self.setPropertyValue("timePerLevel", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getMinStayTime(self) -> Tuple[float | str, TimeUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "minStayTime")
		return result.getCode(), TimeUnits("TimeUnits." + result.getUnit().name())

	def setMinStayTime(self, value: float | str, unit: TimeUnits):
		self.setPropertyValue("minStayTime", self.getCodeUnitValue(value if isinstance(value, str) else float(value), unit))

	def getAllLevels(self) -> boolean:
		return self.getPropertyValue("allLevels")

	def setAllLevels(self, value: boolean):
		self.setPropertyValue("allLevels", self.getCodeValue(value))

	def getLevels(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "levels")
		return result.getCode()

	def setLevels(self, value: str):
		self.setPropertyValue("levels", self.getCodeValue(value))

	def getOnArrival(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onArrival")
		return result.getCode()

	def setOnArrival(self, value: str):
		self.setPropertyValue("onArrival", self.getCodeValue(value))

	def getOnDeparture(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onDeparture")
		return result.getCode()

	def setOnDeparture(self, value: str):
		self.setPropertyValue("onDeparture", self.getCodeValue(value))

	def getOnFailed(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onFailed")
		return result.getCode()

	def setOnFailed(self, value: str):
		self.setPropertyValue("onFailed", self.getCodeValue(value))

	def getOnRepaired(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onRepaired")
		return result.getCode()

	def setOnRepaired(self, value: str):
		self.setPropertyValue("onRepaired", self.getCodeValue(value))

	def getOnStateChanged(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onStateChanged")
		return result.getCode()

	def setOnStateChanged(self, value: str):
		self.setPropertyValue("onStateChanged", self.getCodeValue(value))



class Pathway(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Pathway(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Pathway'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))



class Escalator(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Escalator(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Escalator'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getMovementDirection(self) -> EscalatorMovementDirection:
		return self.getPropertyValue("Escalator Movement Direction")

	def setMovementDirection(self, value: EscalatorMovementDirection):
		self.setPropertyValue("Escalator Movement Direction", value)



class RailTrack(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RailTrack(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RailTrack'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getSource(self):
		return self.wrap(self.workspace.getElementManager().getSource(self.item))

	def setSource(self, source: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, source, True)

	def setTarget(self, target: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, target, False)

	def getTarget(self):
		return self.wrap(self.workspace.getElementManager().getTarget(self.item))

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getLineWidth(self) -> float:
		return self.getPropertyValue("Line Width")

	def setLineWidth(self, value: float):
		self.setPropertyValue("Line Width", float(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))

	def getPathType(self) -> PathTypeEnum:
		return self.getPropertyValue("Path Type")

	def setPathType(self, value: PathTypeEnum):
		self.setPropertyValue("Path Type", value)

	def getWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Width", self.getUnitValue(float(value), unit))

	def isBidirectional(self) -> bool:
		return self.getPropertyValue("Path bidirection")

	def setBidirectional(self, value: bool):
		self.setPropertyValue("Path bidirection", bool(value))



class RailStopline(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RailStopline(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RailStopline'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getOffset(self) -> float:
		return self.getPropertyValue("Offset")

	def setOffset(self, value: float):
		self.setPropertyValue("Offset", float(value))

	def getOnTrainEnter(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrainEnter")
		return result.getCode()

	def setOnTrainEnter(self, value: str):
		self.setPropertyValue("onTrainEnter", self.getCodeValue(value))

	def getOnTrainExit(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onTrainExit")
		return result.getCode()

	def setOnTrainExit(self, value: str):
		self.setPropertyValue("onTrainExit", self.getCodeValue(value))



class RailwayNetwork(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RailwayNetwork(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RailwayNetwork'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)



class RailroadSwitch(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RailroadSwitch(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RailroadSwitch'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getType(self) -> RailwaySwitchType:
		return self.getPropertyValue("RAILSWITCH_TYPE")

	def setType(self, value: RailwaySwitchType):
		self.setPropertyValue("RAILSWITCH_TYPE", value)

	def getSwitchingTrack(self) -> 'RailTrack':
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "RAILSWITCH_SWITCHING_TRACK")
		return self.wrap(result)

	def setSwitchingTrack(self, value: 'RailTrack'):
		self.setPropertyValue("RAILSWITCH_SWITCHING_TRACK", value.item)



class Road(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Road(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Road'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getSource(self):
		return self.wrap(self.workspace.getElementManager().getSource(self.item))

	def setSource(self, source: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, source, True)

	def setTarget(self, target: 'BaseWorkspaceElement'):
		BaseWorkspaceElement.connectTo(self, target, False)

	def getTarget(self):
		return self.wrap(self.workspace.getElementManager().getTarget(self.item))

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def isBidirectional(self) -> bool:
		return self.getPropertyValue("Path bidirection")

	def setBidirectional(self, value: bool):
		self.setPropertyValue("Path bidirection", bool(value))

	def getForwardLanesCount(self) -> int:
		return self.getPropertyValue("Forward Lanes Count")

	def setForwardLanesCount(self, value: int):
		self.setPropertyValue("Forward Lanes Count", int(value))

	def getBackwardLanesCount(self) -> int:
		return self.getPropertyValue("Backward Lanes Count")

	def setBackwardLanesCount(self, value: int):
		self.setPropertyValue("Backward Lanes Count", int(value))

	def getDelimiterWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Delimiter Width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setDelimiterWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Delimiter Width", self.getUnitValue(float(value), unit))

	def getRoadDelimiterColor(self) -> int:
		return self.getPropertyValue("Road Delimiter Color")

	def setRoadDelimiterColor(self, value: int):
		self.setPropertyValue("Road Delimiter Color", int(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))



class RoadJunction(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RoadJunction(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RoadJunction'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getIncomingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getIncomingConnections(self.item)))

	def getOutgoingConnections(self):
		return list(map(self.wrap, self.workspace.getElementManager().getOutgoingConnections(self.item)))

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))



class RoadStopline(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RoadStopline(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RoadStopline'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getOffset(self) -> float:
		return self.getPropertyValue("Offset")

	def setOffset(self, value: float):
		self.setPropertyValue("Offset", float(value))

	def isOnForwardSide(self) -> bool:
		return self.getPropertyValue("On Forward Side")

	def setOnForwardSide(self, value: bool):
		self.setPropertyValue("On Forward Side", bool(value))

	def isStartSpeedLimitSign(self) -> bool:
		return self.getPropertyValue("STOP_LINE_START_SPEED_LIMIT_SIGN")

	def setStartSpeedLimitSign(self, value: bool):
		self.setPropertyValue("STOP_LINE_START_SPEED_LIMIT_SIGN", bool(value))

	def getSpeedLimitValue(self) -> Tuple[float, SpeedUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "STOP_LINE_SPEED_LIMIT_VALUE")
		return result.getValue(), SpeedUnits("SpeedUnits." + result.getUnit().name())

	def setSpeedLimitValue(self, value: float, unit: SpeedUnits):
		self.setPropertyValue("STOP_LINE_SPEED_LIMIT_VALUE", self.getUnitValue(float(value), unit))

	def isEndOfSpeedLimitSign(self) -> bool:
		return self.getPropertyValue("STOP_LINE_END_OF_SPEED_LIMIT_SIGN")

	def setEndOfSpeedLimitSign(self, value: bool):
		self.setPropertyValue("STOP_LINE_END_OF_SPEED_LIMIT_SIGN", bool(value))

	def isYieldSign(self) -> bool:
		return self.getPropertyValue("STOP_LINE_YIELD_SIGN")

	def setYieldSign(self, value: bool):
		self.setPropertyValue("STOP_LINE_YIELD_SIGN", bool(value))

	def getOnCarPassed(self) -> str:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "onCarPassed")
		return result.getCode()

	def setOnCarPassed(self, value: str):
		self.setPropertyValue("onCarPassed", self.getCodeValue(value))



class BusStop(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return BusStop(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'BusStop'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getOffset(self) -> float:
		return self.getPropertyValue("Offset")

	def setOffset(self, value: float):
		self.setPropertyValue("Offset", float(value))

	def isOnForwardSide(self) -> bool:
		return self.getPropertyValue("On Forward Side")

	def setOnForwardSide(self, value: bool):
		self.setPropertyValue("On Forward Side", bool(value))

	def getLength(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Length")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setLength(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Length", self.getUnitValue(float(value), unit))



class ParkingLot(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return ParkingLot(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'ParkingLot'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getOffset(self) -> float:
		return self.getPropertyValue("Offset")

	def setOffset(self, value: float):
		self.setPropertyValue("Offset", float(value))

	def isOnForwardSide(self) -> bool:
		return self.getPropertyValue("On Forward Side")

	def setOnForwardSide(self, value: bool):
		self.setPropertyValue("On Forward Side", bool(value))

	def getType(self) -> ParkingTypeEnum:
		return self.getPropertyValue("Type")

	def setType(self, value: ParkingTypeEnum):
		self.setPropertyValue("Type", value)

	def getDiagonalParkingAngle(self) -> int:
		return self.getPropertyValue("Parking Space Angle")

	def setDiagonalParkingAngle(self, value: int):
		self.setPropertyValue("Parking Space Angle", int(value))

	def getParkingSpaceCount(self) -> int:
		return self.getPropertyValue("Parking Space Count")

	def setParkingSpaceCount(self, value: int):
		self.setPropertyValue("Parking Space Count", int(value))

	def getParkingSpaceLength(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Parking Space Length")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setParkingSpaceLength(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Parking Space Length", self.getUnitValue(float(value), unit))

	def isForceLeaving(self) -> bool:
		return self.getPropertyValue("Force parking space leaving")

	def setForceLeaving(self, value: bool):
		self.setPropertyValue("Force parking space leaving", bool(value))

	def getForceLeavingTimeout(self) -> Tuple[float, TimeUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Parking space force leaving time")
		return result.getValue(), TimeUnits("TimeUnits." + result.getUnit().name())

	def setForceLeavingTimeout(self, value: float, unit: TimeUnits):
		self.setPropertyValue("Parking space force leaving time", self.getUnitValue(float(value), unit))



class RoadNetwork(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return RoadNetwork(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'RoadNetwork'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getDrivingDirection(self) -> RoadDrivingDirectionEnum:
		return self.getPropertyValue("Driving Direction")

	def setDrivingDirection(self, value: RoadDrivingDirectionEnum):
		self.setPropertyValue("Driving Direction", value)

	def getLaneWidth(self) -> Tuple[float, LengthUnits]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "Lane width")
		return result.getValue(), LengthUnits("LengthUnits." + result.getUnit().name())

	def setLaneWidth(self, value: float, unit: LengthUnits):
		self.setPropertyValue("Lane width", self.getUnitValue(float(value), unit))

	def getRoadBackgroundColor(self) -> int:
		return self.getPropertyValue("Road Background Color")

	def setRoadBackgroundColor(self, value: int):
		self.setPropertyValue("Road Background Color", int(value))

	def getLanesDelimitingLineStyle(self) -> RoadLineStyleEnum:
		return self.getPropertyValue("Lanes Delimiting Line Style")

	def setLanesDelimitingLineStyle(self, value: RoadLineStyleEnum):
		self.setPropertyValue("Lanes Delimiting Line Style", value)

	def getLanesDelimitingLineColor(self) -> int:
		return self.getPropertyValue("Lanes Delimiting Line Color")

	def setLanesDelimitingLineColor(self, value: int):
		self.setPropertyValue("Lanes Delimiting Line Color", int(value))

	def getDirectionsDelimitingLineStyle(self) -> RoadLineStyleEnum:
		return self.getPropertyValue("Directions Delimiting Line Style")

	def setDirectionsDelimitingLineStyle(self, value: RoadLineStyleEnum):
		self.setPropertyValue("Directions Delimiting Line Style", value)

	def getDirectionsDelimitingLineColor(self) -> int:
		return self.getPropertyValue("Directions Delimiting Line Color")

	def setDirectionsDelimitingLineColor(self, value: int):
		self.setPropertyValue("Directions Delimiting Line Color", int(value))

	def isShowLaneConnectors(self) -> bool:
		return self.getPropertyValue("IS_SHOW_LANE_CONNECTORS")

	def setShowLaneConnectors(self, value: bool):
		self.setPropertyValue("IS_SHOW_LANE_CONNECTORS", bool(value))

	def isSignalStateAnimationVisible(self) -> bool:
		return self.getPropertyValue("IS_SIGNAL_STATE_ANIMATION_VISIBLE")

	def setSignalStateAnimationVisible(self, value: bool):
		self.setPropertyValue("IS_SIGNAL_STATE_ANIMATION_VISIBLE", bool(value))



class StorageTank(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return StorageTank(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'StorageTank'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getDiameter(self) -> float:
		return self.getPropertyValue("Diameter")

	def setDiameter(self, value: float):
		self.setPropertyValue("Diameter", float(value))

	def getHeight(self) -> float:
		return self.getPropertyValue("Height")

	def setHeight(self, value: float):
		self.setPropertyValue("Height", float(value))



class Pipe(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return Pipe(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'Pipe'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getDiameter(self) -> float:
		return self.getPropertyValue("Diameter")

	def setDiameter(self, value: float):
		self.setPropertyValue("Diameter", float(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))



class BulkConveyorBelt(BaseWorkspaceElement):
	def create(parent: BaseWorkspaceElement):
		return BulkConveyorBelt(parent.pyWorkspace, parent.workspace.getElementManager().createElement(parent.item, 'BulkConveyorBelt'))

	def __init__(self, workspace, item):
		super().__init__(workspace, item)

	def getName(self) -> str:
		return self.getPropertyValue("Name")

	def setName(self, value: str):
		self.setPropertyValue("Name", value)

	def getDescription(self) -> str:
		return self.getPropertyValue("Description")

	def setDescription(self, value: str):
		self.setPropertyValue("Description", value)

	def isExcludeFromBuild(self) -> bool:
		return self.getPropertyValue("Exclude From Build")

	def setExcludeFromBuild(self, value: bool):
		self.setPropertyValue("Exclude From Build", bool(value))

	def getX(self) -> float:
		return self.getPropertyValue("x")

	def setX(self, value: float):
		self.setPropertyValue("x", float(value))

	def getY(self) -> float:
		return self.getPropertyValue("y")

	def setY(self, value: float):
		self.setPropertyValue("y", float(value))

	def isPublicFlag(self) -> bool:
		return self.getPropertyValue("PublicElement")

	def setPublicFlag(self, value: bool):
		self.setPropertyValue("PublicElement", bool(value))

	def isShowAtRuntime(self) -> bool:
		return self.getPropertyValue("Show At Runtime")

	def setShowAtRuntime(self, value: bool):
		self.setPropertyValue("Show At Runtime", bool(value))

	def isShowLabel(self) -> bool:
		return self.getPropertyValue("Show label")

	def setShowLabel(self, value: bool):
		self.setPropertyValue("Show label", bool(value))

	def getDrawMode(self) -> ShapeDrawModeEnum:
		return self.getPropertyValue("Shape Draw Mode")

	def setDrawMode(self, value: ShapeDrawModeEnum):
		self.setPropertyValue("Shape Draw Mode", value)

	def isLock(self) -> bool:
		return self.getPropertyValue("Lock Shape")

	def setLock(self, value: bool):
		self.setPropertyValue("Lock Shape", bool(value))

	def getZ(self) -> float:
		return self.getPropertyValue("z")

	def setZ(self, value: float):
		self.setPropertyValue("z", float(value))

	def getLineColor(self) -> int:
		return self.getPropertyValue("Line Color")

	def setLineColor(self, value: int):
		self.setPropertyValue("Line Color", int(value))

	def getWidth(self) -> float:
		return self.getPropertyValue("Width")

	def setWidth(self, value: float):
		self.setPropertyValue("Width", float(value))

	def getPointList(self) -> List[float]:
		result = self.workspace.getPropertyManager().getPropertyValue(self.item, "pointlist changed")
		return reduce(list.__add__, map(lambda r: [r.getX(), r.getY(), r.getZ()],result))

	def setPointList(self, value: List[float]):
		self.setPropertyValue("pointlist changed", self.workspace.getPropertyManager().getPointsList(self.javaDoubleArray(value)))

	def isDrawStands(self) -> bool:
		return self.getPropertyValue("Draw stands")

	def setDrawStands(self, value: bool):
		self.setPropertyValue("Draw stands", bool(value))

	def getStandsLevel(self) -> float:
		return self.getPropertyValue("... from Z level")

	def setStandsLevel(self, value: float):
		self.setPropertyValue("... from Z level", float(value))



class GeneratedClasses:
	def wrap(workspace, item):
		if item is None:
			return None
		match item.typeName():
			case 'ConveyorNetwork':
				return ConveyorNetwork(workspace, item)

			case 'Wall':
				return Wall(workspace, item)

			case 'Pathway':
				return Pathway(workspace, item)

			case 'ConveyorSpur':
				return ConveyorSpur(workspace, item)

			case 'TargetLine':
				return TargetLine(workspace, item)

			case 'CustomStation':
				return CustomStation(workspace, item)

			case 'Crane':
				return Crane(workspace, item)

			case 'Attractor':
				return Attractor(workspace, item)

			case 'Conveyor':
				return Conveyor(workspace, item)

			case 'ConveyorSimpleStation':
				return ConveyorSimpleStation(workspace, item)

			case 'Lift':
				return Lift(workspace, item)

			case 'Escalator':
				return Escalator(workspace, item)

			case 'RailwayNetwork':
				return RailwayNetwork(workspace, item)

			case 'ParkingLot':
				return ParkingLot(workspace, item)

			case 'RackStorage':
				return RackStorage(workspace, item)

			case 'Elevator':
				return Elevator(workspace, item)

			case 'Network':
				return Network(workspace, item)

			case 'RoadNetwork':
				return RoadNetwork(workspace, item)

			case 'OverheadCraneBridge':
				return OverheadCraneBridge(workspace, item)

			case 'Path':
				return Path(workspace, item)

			case 'RailStopline':
				return RailStopline(workspace, item)

			case 'OvalWall':
				return OvalWall(workspace, item)

			case 'PointNode':
				return PointNode(workspace, item)

			case 'RectangleWall':
				return RectangleWall(workspace, item)

			case 'EscalatorGroup':
				return EscalatorGroup(workspace, item)

			case 'RectangleNode':
				return RectangleNode(workspace, item)

			case 'Road':
				return Road(workspace, item)

			case 'PolygonNode':
				return PolygonNode(workspace, item)

			case 'Pipe':
				return Pipe(workspace, item)

			case 'RailroadSwitch':
				return RailroadSwitch(workspace, item)

			case 'RoadStopline':
				return RoadStopline(workspace, item)

			case 'TurnStation':
				return TurnStation(workspace, item)

			case 'PositionOnConveyor':
				return PositionOnConveyor(workspace, item)

			case 'StorageTank':
				return StorageTank(workspace, item)

			case 'TransferTable':
				return TransferTable(workspace, item)

			case 'RailTrack':
				return RailTrack(workspace, item)

			case 'Turntable':
				return Turntable(workspace, item)

			case 'BulkConveyorBelt':
				return BulkConveyorBelt(workspace, item)

			case 'RoadJunction':
				return RoadJunction(workspace, item)

			case 'BusStop':
				return BusStop(workspace, item)

			case 'Robot':
				return Robot(workspace, item)

			case 'OverheadCrane':
				return OverheadCrane(workspace, item)

			case _:
				return BaseWorkspaceElement(workspace, item)

