from typing import List

from .Agent import Agent

class Model:
    def __init__(self, workspace: 'Workspace', item):
        self.pyWorkspace = workspace
        self.workspace = workspace.workspace
        self.item = item

    def getAgents(self) -> List[Agent]:
        return list(map(lambda a: Agent(self.workspace, a), self.workspace.getModelManager().getAgents(self.item)))

    def getAgent(self, name: str) -> Agent:
        return Agent(self.pyWorkspace, self.workspace.getModelManager().getAgent(self.item, name))
        
    def createAgent(self, name: str) -> Agent:
        return Agent(self.pyWorkspace, self.workspace.getModelManager().createAgent(self.item, name))
