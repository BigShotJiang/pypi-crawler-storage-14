class BaseWorkspaceElement:
    def __init__(self, workspace: 'Workspace', item):
        self.pyWorkspace = workspace
        self.workspace = workspace.workspace
        self.item = item

    def getName(self) -> str:
        return self.workspace.getPropertyManager().getPropertyValue(self.item, "Name")

    def delete(self):
        self.workspace.getElementManager().deleteElement(self.item)

    def javaDoubleArray(self, arr):
        object_class = self.pyWorkspace.gateway.jvm.java.lang.Double
        result = self.pyWorkspace.gateway.new_array(object_class, len(arr))
        for i in range(len(arr)):
            result[i] = arr[i]
        return result
        
    def getX(self) -> float:
        result = self.workspace.getPropertyManager().getPropertyValue(self.item, "x")
        return result

    def getY(self) -> float:
        result = self.workspace.getPropertyManager().getPropertyValue(self.item, "y")
        return result

    def getParent(self) -> 'BaseWorkspaceElement':
        return self.wrap(self.item.parent())

    def getChildren(self):
        return list(map(self.wrap, self.workspace.getElementManager().getChildren(self.item)))

    def getChild(self, name: str):
        return self.wrap(self.workspace.getElementManager().getElement(self.item, name))
    
    def connectTo(connection: 'BaseWorkspaceElement', connectable: 'BaseWorkspaceElement', connectAsSource: bool):
        connection.workspace.getElementManager().connect(connection.item, None if connectable is None else connectable.item, connectAsSource)
        newTarget = None
        if connectable:
            newTarget = connection.workspace.getElementManager().refreshElement(connectable.item)
        newSource = connection.workspace.getElementManager().refreshElement(connection.item)

        if newTarget:
            connectable.item = newTarget
        elif newSource:
            if connectable:
                connectable.item = newSource

        if newSource:
            connection.item = newSource
        elif newTarget:
            connection.item = newTarget

    def setPropertyValue(self, name: str, value):
        self.workspace.getPropertyManager().setProperty(self.item, name, value)

    def getPropertyValue(self, name: str):
        return self.workspace.getPropertyManager().getPropertyValue(self.item, name)

    def getCodeValue(self, value):
        return self.workspace.getPropertyManager().getCodeValue(value if isinstance(value, str)
                                                                else (
            ("true" if bool(value) == True else "false") if isinstance(value, bool) else str(value)))

    def getCodeUnitValue(self, value, unit):
        return self.workspace.getPropertyManager().getCodeUnitValue(value if isinstance(value,str) else str(value), unit)

    def getUnitValue(self, value, unit):
        return self.workspace.getPropertyManager().getUnitValue(value, unit)
        
    def wrap(self, item):
        from .generated.GeneratedClasses import GeneratedClasses
        return GeneratedClasses.wrap(self.pyWorkspace, item)
