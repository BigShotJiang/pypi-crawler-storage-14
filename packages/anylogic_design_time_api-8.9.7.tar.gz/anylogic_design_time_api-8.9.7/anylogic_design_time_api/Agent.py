from typing import List

from .BaseWorkspaceElement import BaseWorkspaceElement
from .generated.GeneratedClasses import GeneratedClasses

class Agent:
    def __init__(self, workspace: 'Workspace', item):
        self.pyWorkspace = workspace
        self.workspace = workspace.workspace
        self.item = item

    def getLevels(self) -> List[BaseWorkspaceElement]:
        return list(
            map(lambda e: GeneratedClasses.wrap(self.pyWorkspace, e), self.workspace.getElementManager().getAnimationElements(self.item)))

    def getLevel(self, name: str):
        return GeneratedClasses.wrap(self.pyWorkspace, self.workspace.getElementManager().getElement(self.item, name))

    def getName(self) -> str:
        return self.workspace.getPropertyManager().getPropertyValue(self.item, "Name")
    
    def setScale(self, metersInPixel: float):
        self.workspace.getModelManager().setScale(self.item, metersInPixel)