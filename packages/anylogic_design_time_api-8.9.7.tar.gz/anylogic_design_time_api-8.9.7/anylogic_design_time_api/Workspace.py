from typing import List

from py4j.java_gateway import JavaGateway, GatewayParameters

from .Model import Model

class Workspace:
    def __init__(self, authToken, connectionPort = 25333):
        self.gateway = JavaGateway(gateway_parameters=GatewayParameters(auth_token=authToken, port=connectionPort))
        self.workspace = self.gateway.entry_point
        self.workspace.init("8.9.7")

    def getModels(self) -> List[Model]:
        return list(map(lambda m: Model(self, m), self.workspace.getModelManager().getModels()))

    def getModel(self, name: str) -> Model:
        return Model(self, self.workspace.getModelManager().getModel(name))