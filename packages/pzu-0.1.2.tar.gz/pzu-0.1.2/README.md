<h1 align="center">
  <b>Petting Zoo Utils</b>
</h1>

<p align="center">
  <a href="https://pypi.org/project/pzu">
    <img alt="PyPI" src="https://img.shields.io/pypi/v/pzu">
  </a>
  <a href="https://pypi.org/project/pzu">
    <img alt="PyPI - Python Version" src="https://img.shields.io/pypi/pyversions/pzu" />
  </a>
  <a href="">
    <img alt="PyPI - Status" src="https://img.shields.io/pypi/status/pzu" />
  </a>
  <a href="">
    <img alt="PyPI - Implementation" src="https://img.shields.io/pypi/implementation/pzu">
  </a>
  <a href="">
    <img alt="PyPI - Wheel" src="https://img.shields.io/pypi/wheel/pzu">
  </a>
  <a href="https://github.com/nightly/pzu/blob/master/LICENSE">
    <img alt="GitHub" src="https://img.shields.io/github/license/nightly/pzu">
  </a>
</p>

Some helpful utils for Petting Zoo environments.

# Development
1. Clone the repository with `git`
2. Run `uv run pre-commit install`