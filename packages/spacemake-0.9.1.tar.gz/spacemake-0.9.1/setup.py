if __name__ == "__main__":
    from setuptools import setup

    setup()
