# codeprinter

Tiny utility package for keeping your solutions in one place and importing them from anywhere.

## Setup

```bash
cd /Users/shriyansnayak/code-printer
pip install -e .
```

The editable install exposes the package globally inside the current Python environment (or virtualenv).

## Usage

```python
import codeprinter as cp

print(cp.ques(1))
```

Add new answers by editing `codeprinter/_answers.py`. Each entry maps a question number to any serialisable value (strings, dicts, callables, etc.). Example:

```python
ANSWERS = {
    1: "print('Hello world')",
    2: lambda: 42,
}
```

Callables are invoked when retrieved so you can lazily compute data.

