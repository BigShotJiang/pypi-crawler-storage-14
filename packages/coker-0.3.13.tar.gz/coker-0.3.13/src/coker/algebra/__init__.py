from coker.algebra.tensor import SymbolicVector
from coker.algebra.dimensions import Dimension
from coker.algebra.ops import OP

from coker.algebra.helpers import is_scalar
from coker.algebra.factories import zeros
