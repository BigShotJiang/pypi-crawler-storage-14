"""
Tests for insert() and insert_batch() methods (Append-Only/Logs).

These tests verify the high-performance insertion path for log tables
and append-only data that doesn't require SCD2 versioning logic.
"""

import os
import tempfile

import pytest
from registro import DomainResource

from malha import connect


# =============================================================================
# Test Domain Resources
# =============================================================================


class AuditLog(DomainResource):
    """Append-only audit log entry."""

    action: str
    user_id: str
    ip_address: str | None = None
    details: str | None = None


class TelemetryEvent(DomainResource):
    """High-frequency telemetry event."""

    metric: str
    value: float
    tags: str | None = None


class PaymentTransaction(DomainResource):
    """Immutable payment transaction record."""

    amount: float
    currency: str = "BRL"
    status: str = "completed"


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test databases."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
async def kernel(temp_dir):
    """Create a kernel instance."""
    db_path = os.path.join(temp_dir, "insert_test.db")
    graph_path = os.path.join(temp_dir, "insert_graph")

    kernel = await connect(
        url=f"sqlite+aiosqlite:///{db_path}",
        kuzu_path=graph_path,
        enable_monitoring=False,
    )
    yield kernel
    await kernel.close()


# =============================================================================
# Tests: insert() - Single Record
# =============================================================================


class TestInsertSingle:
    """Tests for single record insertion."""

    @pytest.mark.asyncio
    async def test_insert_basic(self, kernel):
        """Test basic insert without replication."""
        log = AuditLog(
            action="user_login",
            user_id="user-123",
            ip_address="192.168.1.1",
        )

        result = await kernel.insert(log)

        assert result is not None
        assert result.rid is not None
        assert result.action == "user_login"
        assert result.user_id == "user-123"
        assert result.ip_address == "192.168.1.1"

    @pytest.mark.asyncio
    async def test_insert_generates_unique_ids(self, kernel):
        """Test that each insert generates a unique ID."""
        log1 = AuditLog(action="action1", user_id="user-1")
        log2 = AuditLog(action="action2", user_id="user-2")

        result1 = await kernel.insert(log1)
        result2 = await kernel.insert(log2)

        # Each should have unique RID
        assert result1.rid != result2.rid

    @pytest.mark.asyncio
    async def test_insert_no_version_locking(self, kernel):
        """Test that insert doesn't use SCD2 version locking.
        
        Multiple inserts with same logical data should create separate records,
        not close previous versions.
        """
        # Insert same "logical" data twice
        log1 = AuditLog(action="same_action", user_id="same_user")
        log2 = AuditLog(action="same_action", user_id="same_user")

        result1 = await kernel.insert(log1)
        result2 = await kernel.insert(log2)

        # Both should exist as separate records
        assert result1.rid != result2.rid

        # Both should be "active" (valid_to is None in envelope)
        # This is the key difference from save_versioned

    @pytest.mark.asyncio
    async def test_insert_with_replication(self, kernel):
        """Test insert with replication flag."""
        log = AuditLog(
            action="important_action",
            user_id="user-456",
            details="This should be replicated",
        )

        result = await kernel.insert(log, replicate=True)

        assert result is not None
        assert result.action == "important_action"
        # Outbox entry should be created (tested implicitly)

    @pytest.mark.asyncio
    async def test_insert_telemetry_high_frequency(self, kernel):
        """Test high-frequency telemetry insertion."""
        events = []
        for i in range(100):
            event = TelemetryEvent(
                metric="cpu_usage",
                value=50.0 + i * 0.1,
                tags=f"host=server-{i % 5}",
            )
            result = await kernel.insert(event)
            events.append(result)

        # All 100 events should be inserted
        assert len(events) == 100

        # All should have unique RIDs
        rids = {e.rid for e in events}
        assert len(rids) == 100

    @pytest.mark.asyncio
    async def test_insert_preserves_domain_fields(self, kernel):
        """Test that all domain fields are preserved."""
        transaction = PaymentTransaction(
            amount=1500.50,
            currency="USD",
            status="pending",
        )

        result = await kernel.insert(transaction)

        assert result.amount == 1500.50
        assert result.currency == "USD"
        assert result.status == "pending"


# =============================================================================
# Tests: insert_batch() - Multiple Records
# =============================================================================


class TestInsertBatch:
    """Tests for batch record insertion."""

    @pytest.mark.asyncio
    async def test_insert_batch_basic(self, kernel):
        """Test basic batch insertion."""
        logs = [
            AuditLog(action="page_view", user_id="user-1"),
            AuditLog(action="click", user_id="user-2"),
            AuditLog(action="scroll", user_id="user-3"),
        ]

        results = await kernel.insert_batch(logs)

        assert len(results) == 3
        assert results[0].action == "page_view"
        assert results[1].action == "click"
        assert results[2].action == "scroll"

    @pytest.mark.asyncio
    async def test_insert_batch_unique_ids(self, kernel):
        """Test that batch insert generates unique IDs for each record."""
        logs = [
            AuditLog(action=f"action_{i}", user_id=f"user_{i}")
            for i in range(50)
        ]

        results = await kernel.insert_batch(logs)

        # All should have unique RIDs
        rids = {r.rid for r in results}
        assert len(rids) == 50

    @pytest.mark.asyncio
    async def test_insert_batch_with_replication(self, kernel):
        """Test batch insert with replication."""
        transactions = [
            PaymentTransaction(amount=100.0, currency="BRL"),
            PaymentTransaction(amount=200.0, currency="USD"),
            PaymentTransaction(amount=300.0, currency="EUR"),
        ]

        results = await kernel.insert_batch(transactions, replicate=True)

        assert len(results) == 3
        # Outbox entries should be created for all

    @pytest.mark.asyncio
    async def test_insert_batch_empty_list(self, kernel):
        """Test batch insert with empty list."""
        results = await kernel.insert_batch([])

        assert results == []

    @pytest.mark.asyncio
    async def test_insert_batch_large(self, kernel):
        """Test batch insert with large number of records."""
        events = [
            TelemetryEvent(metric="memory", value=float(i))
            for i in range(500)
        ]

        results = await kernel.insert_batch(events)

        assert len(results) == 500

    @pytest.mark.asyncio
    async def test_insert_batch_mixed_types_same_base(self, kernel):
        """Test batch insert preserves correct types."""
        # All are DomainResource subclasses
        logs = [
            AuditLog(action="log1", user_id="u1"),
            AuditLog(action="log2", user_id="u2"),
        ]

        results = await kernel.insert_batch(logs)

        assert all(isinstance(r, AuditLog) for r in results)


# =============================================================================
# Tests: Performance Comparison
# =============================================================================


class TestPerformanceCharacteristics:
    """Tests verifying performance characteristics of insert vs save_versioned."""

    @pytest.mark.asyncio
    async def test_insert_faster_than_save_versioned(self, kernel):
        """Test that insert is faster than save_versioned for new records.
        
        This is a characteristic test, not a strict benchmark.
        insert() should be faster because it skips:
        - SELECT FOR UPDATE (pessimistic locking)
        - Version closing logic
        """
        import time

        # Measure insert time
        start = time.perf_counter()
        for i in range(20):
            log = AuditLog(action=f"insert_{i}", user_id=f"user_{i}")
            await kernel.insert(log)
        insert_time = time.perf_counter() - start

        # Measure save_versioned time
        start = time.perf_counter()
        for i in range(20):
            log = AuditLog(action=f"versioned_{i}", user_id=f"user_{i}")
            await kernel.save_versioned(log)
        versioned_time = time.perf_counter() - start

        # insert should generally be faster (no locking overhead)
        # We don't assert strict timing, just log for observation
        print(f"\ninsert: {insert_time:.3f}s, save_versioned: {versioned_time:.3f}s")

        # Both should complete successfully
        assert insert_time > 0
        assert versioned_time > 0

    @pytest.mark.asyncio
    async def test_insert_batch_faster_than_individual(self, kernel):
        """Test that batch insert is faster than individual inserts."""
        import time

        logs = [
            AuditLog(action=f"batch_{i}", user_id=f"user_{i}")
            for i in range(50)
        ]

        # Measure batch time
        start = time.perf_counter()
        await kernel.insert_batch(logs)
        batch_time = time.perf_counter() - start

        # Measure individual time
        logs2 = [
            AuditLog(action=f"individual_{i}", user_id=f"user_{i}")
            for i in range(50)
        ]
        start = time.perf_counter()
        for log in logs2:
            await kernel.insert(log)
        individual_time = time.perf_counter() - start

        print(f"\nbatch: {batch_time:.3f}s, individual: {individual_time:.3f}s")

        # Batch should be faster (single transaction)
        # We don't assert strict timing due to test environment variability
        assert batch_time > 0
        assert individual_time > 0


# =============================================================================
# Tests: Edge Cases
# =============================================================================


class TestEdgeCases:
    """Tests for edge cases and error handling."""

    @pytest.mark.asyncio
    async def test_insert_with_none_optional_fields(self, kernel):
        """Test insert with None optional fields."""
        log = AuditLog(
            action="minimal",
            user_id="user-min",
            ip_address=None,
            details=None,
        )

        result = await kernel.insert(log)

        assert result.action == "minimal"
        assert result.ip_address is None
        assert result.details is None

    @pytest.mark.asyncio
    async def test_insert_special_characters(self, kernel):
        """Test insert with special characters in fields."""
        log = AuditLog(
            action="special'\"action",
            user_id="user<>&",
            details="Details with émojis 🎉 and unicode: café",
        )

        result = await kernel.insert(log)

        assert result.action == "special'\"action"
        assert result.user_id == "user<>&"
        assert "🎉" in result.details

    @pytest.mark.asyncio
    async def test_insert_large_payload(self, kernel):
        """Test insert with large payload."""
        large_details = "x" * 10000  # 10KB of data

        log = AuditLog(
            action="large_payload",
            user_id="user-large",
            details=large_details,
        )

        result = await kernel.insert(log)

        assert len(result.details) == 10000
