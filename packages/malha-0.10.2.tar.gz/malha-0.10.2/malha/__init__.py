"""Malha v0.9.0 - "Fat Kernel" - Sistema Operacional Semântico.

Unified Data & Compute Kernel with P2P Replication and Zero-ETL Federation.

This version consolidates infrastructure responsibilities into the kernel:
- Context Management: Thread/async-safe kernel injection
- Stream Drivers: High-performance data lake writes (Parquet)
- Compute Drivers: Safe script execution (PEP 723 + uv)
- Transaction Management: UnitOfWork for atomic graph operations
- Process State: Durable workflow persistence (SysProcess)

Quick Start:
    ```python
    from malha import connect, get_kernel
    from registro import DomainResource, register

    class User(DomainResource):
        name: str
        email: str

    register("User", User)

    async def main():
        # Connect creates kernel and sets it in global context
        kernel = await connect()

        # Create and save a user
        user = User(name="Alice", email="alice@example.com")
        saved = await kernel.save_versioned(user)
        print(f"Saved: {saved.rid}")

        # Kernel is also available via get_kernel()
        assert get_kernel() is kernel

        # Cleanup
        await kernel.close()
    ```

Migration from v0.8:
    - Import set_kernel/get_kernel/clear_kernel from malha (not semantico)
    - Use kernel.stream.write() instead of DataLakeWriter
    - Use kernel.compute.execute() instead of EphemeralRuntime
    - Use UnitOfWork for atomic multi-object operations
"""

# Dynamic version from pyproject.toml
try:
    from importlib.metadata import version
    __version__ = version("malha")
except Exception:
    __version__ = "0.10.2"

# Core API
from .instrumentation import KernelInstrumentation

# Drivers and Core Components
from .malha import (
    # Core API (most users need only these)
    connect,
    create_manager,
    get_kernel,
    set_kernel,
    clear_kernel,
    UnifiedDataManager,
    BaseRepository,
    
    # Signals
    Signal,
    post_save,
    post_delete,
    post_ingest,
    Handler,
    
    # Errors
    OptimisticLockError,
    ValidationError,
    SystemOverloadedError,
    ConsistencyTimeoutError,
    RuntimeExecutionError,
    CodeSynthesisError,
    
    # Models
    SysOutbox,
    SysProcess,
    ProcessStatus,
    
    # Transaction Management (NEW in v0.9)
    UnitOfWork,
    
    # Stream Driver (NEW in v0.9)
    StreamDriver,
    ParquetStreamDriver,
    
    # Compute Driver (NEW in v0.9)
    ComputeDriver,
    ComputeResult,
    LocalComputeDriver,
    
    # Driver Protocols
    SQLDriver,
    GraphDriver,
    AnalyticsDriver,
    ReplicationDriver,
    
    # Driver Implementations
    AsyncSQLAlchemyDriver,
    KuzuActor,
    KuzuTask,
    KuzuConfig,
    DuckDBDriver,
    
    # Extensibility
    Interceptor,
)

# Observability
from .monitor import KernelMonitor, MetricTimer

# Services (Helix pattern)
from .services import TopologySyncService, generate_virtual_rid

# Boot & Maintenance (Lifecycle)
from .boot import (
    Bootloader,
    BootResult,
    boot_kernel,
    recoverable,
    register_recovery_handler,
    WORKFLOW_REGISTRY,
)
from .maintenance import (
    Janitor,
    CleanupResult,
    Migrator,
    MigrationResult,
    SchemaDrift,
    SmartCompactor,
    CompactionResult,
    run_cleanup,
    check_schema_drift,
)

# Backwards compatibility aliases
KuzuDriver = KuzuActor

__all__ = [
    # ==========================================================================
    # Core API (most users need only these)
    # ==========================================================================
    "connect",
    "get_kernel",
    "set_kernel",
    "clear_kernel",
    "UnifiedDataManager",
    "BaseRepository",

    # ==========================================================================
    # Signals
    # ==========================================================================
    "Signal",
    "post_save",
    "post_delete",
    "post_ingest",
    "Handler",

    # ==========================================================================
    # Errors
    # ==========================================================================
    "OptimisticLockError",
    "ValidationError",
    "SystemOverloadedError",
    "ConsistencyTimeoutError",
    "RuntimeExecutionError",
    "CodeSynthesisError",

    # ==========================================================================
    # Models
    # ==========================================================================
    "SysOutbox",
    "SysProcess",
    "ProcessStatus",

    # ==========================================================================
    # Transaction Management (NEW in v0.9)
    # ==========================================================================
    "UnitOfWork",

    # ==========================================================================
    # Stream Driver (NEW in v0.9)
    # ==========================================================================
    "StreamDriver",
    "ParquetStreamDriver",

    # ==========================================================================
    # Compute Driver (NEW in v0.9)
    # ==========================================================================
    "ComputeDriver",
    "ComputeResult",
    "LocalComputeDriver",

    # ==========================================================================
    # Observability
    # ==========================================================================
    "KernelMonitor",
    "KernelInstrumentation",
    "MetricTimer",
    "KuzuTask",

    # ==========================================================================
    # Services (Helix pattern)
    # ==========================================================================
    "TopologySyncService",
    "generate_virtual_rid",

    # ==========================================================================
    # Advanced: Driver Protocols
    # ==========================================================================
    "SQLDriver",
    "GraphDriver",
    "AnalyticsDriver",
    "ReplicationDriver",

    # ==========================================================================
    # Advanced: Driver Implementations
    # ==========================================================================
    "AsyncSQLAlchemyDriver",
    "KuzuActor",
    "KuzuConfig",
    "KuzuDriver",  # Backwards compatibility alias
    "DuckDBDriver",

    # ==========================================================================
    # Advanced: Extensibility
    # ==========================================================================
    "Interceptor",

    # ==========================================================================
    # Advanced: Boot & Maintenance (Lifecycle)
    # ==========================================================================
    "Bootloader",
    "BootResult",
    "boot_kernel",
    "recoverable",
    "register_recovery_handler",
    "WORKFLOW_REGISTRY",
    "Janitor",
    "CleanupResult",
    "Migrator",
    "MigrationResult",
    "SchemaDrift",
    "SmartCompactor",
    "CompactionResult",
    "run_cleanup",
    "check_schema_drift",

    # ==========================================================================
    # Metadata
    # ==========================================================================
    "__version__",
]
