"""
Malha Bootloader - System Recovery and Initialization
======================================================

The Bootloader is the "defibrillator" of the Malha OS. It runs before any
user requests are accepted and ensures the system recovers from crashes.

Responsibilities:
1. WAL Recovery: Process orphaned .wal files from StreamDriver
2. Process Recovery: Detect and handle zombie processes (workflows/sagas)
3. Sanity Checks: Verify database consistency

Usage:
    ```python
    from malha import connect
    
    # Boot is automatic when auto_boot=True (default)
    kernel = await connect(auto_boot=True)
    
    # Or manual boot
    from malha.boot import Bootloader
    bootloader = Bootloader(kernel)
    await bootloader.run()
    ```
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, UTC
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Any

from sqlalchemy import select, update

if TYPE_CHECKING:
    from .malha import UnifiedDataManager

logger = logging.getLogger("malha.boot")


# ==============================================================================
# WORKFLOW REGISTRY (For Process Recovery)
# ==============================================================================

# Registry mapping process_type -> recovery handler
# Populated by @recoverable decorator or manual registration
WORKFLOW_REGISTRY: dict[str, Callable] = {}


def recoverable(process_type: str):
    """Decorator to register a workflow class for crash recovery.
    
    Example:
        ```python
        @recoverable("order_workflow")
        class OrderWorkflow:
            @classmethod
            async def recover(cls, process: SysProcess, kernel):
                state = json.loads(process.state_payload)
                workflow = cls(order_id=state["order_id"])
                await workflow.resume_from_step(state["current_step"])
        ```
    """
    def decorator(cls):
        if hasattr(cls, "recover"):
            WORKFLOW_REGISTRY[process_type] = cls.recover
        else:
            logger.warning(
                f"[Boot] Class {cls.__name__} registered as recoverable "
                f"but has no 'recover' method"
            )
        return cls
    return decorator


def register_recovery_handler(process_type: str, handler: Callable):
    """Manually register a recovery handler for a process type.
    
    Args:
        process_type: The process_type string stored in SysProcess
        handler: Async function(process: SysProcess, kernel) -> None
    
    Example:
        ```python
        async def recover_order(process, kernel):
            state = json.loads(process.state_payload)
            # ... resume logic ...
        
        register_recovery_handler("order_workflow", recover_order)
        ```
    """
    WORKFLOW_REGISTRY[process_type] = handler
    logger.info(f"[Boot] Registered recovery handler for '{process_type}'")


# ==============================================================================
# BOOTLOADER
# ==============================================================================

class Bootloader:
    """System bootloader for crash recovery and initialization.
    
    The Bootloader runs during kernel startup to:
    1. Recover data from WAL files (StreamDriver)
    2. Detect and handle zombie processes
    3. Perform sanity checks on databases
    
    Attributes:
        kernel: The UnifiedDataManager instance
        heartbeat_timeout: Seconds before a process is considered dead (default: 300)
        auto_recover: Whether to automatically resume recoverable processes
    """
    
    def __init__(
        self, 
        kernel: "UnifiedDataManager",
        heartbeat_timeout: int = 300,
        auto_recover: bool = False,
    ):
        """Initialize the Bootloader.
        
        Args:
            kernel: The kernel instance to boot
            heartbeat_timeout: Seconds without heartbeat before process is dead
            auto_recover: If True, attempt to resume processes with registered handlers.
                         If False (default), just mark them as FAILED for manual review.
        """
        self.kernel = kernel
        self.heartbeat_timeout = heartbeat_timeout
        self.auto_recover = auto_recover
        self._recovered_count = 0
        self._failed_count = 0

    async def run(self) -> "BootResult":
        """Execute the full boot sequence.
        
        Returns:
            BootResult with statistics about recovery operations
        """
        logger.info("🚀 Malha OS Booting...")
        start_time = datetime.now(UTC)
        
        # 1. Recover Stream WAL (data that was in RAM buffers)
        wal_records = await self._recover_streams()
        
        # 2. Recover zombie processes (workflows that died mid-execution)
        zombies_found, zombies_recovered = await self._recover_processes()
        
        # 3. Sanity checks (optional, can be extended)
        await self._sanity_checks()
        
        duration = (datetime.now(UTC) - start_time).total_seconds()
        
        result = BootResult(
            duration_seconds=duration,
            wal_records_recovered=wal_records,
            zombies_found=zombies_found,
            zombies_recovered=zombies_recovered,
            zombies_failed=zombies_found - zombies_recovered,
        )
        
        logger.info(f"✅ Boot complete in {duration:.2f}s: {result}")
        return result

    async def _recover_streams(self) -> int:
        """Recover data from WAL files left by StreamDriver.
        
        The ParquetStreamDriver automatically recovers WAL on __init__,
        but we can force a flush here to ensure data is persisted.
        
        Returns:
            Number of records recovered from WAL
        """
        records_recovered = 0
        
        # Check if kernel has a stream driver
        if not hasattr(self.kernel, "stream") or self.kernel.stream is None:
            logger.debug("[Boot] No stream driver configured, skipping WAL recovery")
            return 0
        
        stream = self.kernel.stream
        
        # The ParquetStreamDriver recovers WAL in __init__ via _recover_from_wal()
        # Here we just ensure a flush happens to persist any recovered data
        try:
            # Check if it's our ParquetStreamDriver with WAL
            if hasattr(stream, "wal_enabled") and stream.wal_enabled:
                # Check for pending WAL records
                if hasattr(stream, "_wal_path") and stream._wal_path.exists():
                    with open(stream._wal_path, "r") as f:
                        records_recovered = sum(1 for _ in f)
                    
                    if records_recovered > 0:
                        logger.info(f"[Boot] Found {records_recovered} records in WAL, flushing...")
                        await stream.flush()
                        logger.info(f"[Boot] WAL recovery complete: {records_recovered} records")
                        
        except Exception as e:
            logger.error(f"[Boot] WAL recovery failed: {e}")
        
        return records_recovered

    async def _recover_processes(self) -> tuple[int, int]:
        """Detect and recover zombie processes.
        
        A zombie process is one with status=RUNNING but:
        - No heartbeat for > heartbeat_timeout seconds, OR
        - The system just started (all RUNNING processes are orphans)
        
        Returns:
            Tuple of (zombies_found, zombies_recovered)
        """
        from .malha import SysProcess, ProcessStatus
        
        zombies_found = 0
        zombies_recovered = 0
        
        try:
            async with await self.kernel.sql_driver.get_session() as session:
                # Find all RUNNING processes
                # On fresh boot, ALL running processes are zombies (their executor died)
                stmt = select(SysProcess).where(
                    SysProcess.status == ProcessStatus.RUNNING.value
                )
                result = await session.execute(stmt)
                zombies = result.scalars().all()
                zombies_found = len(zombies)
                
                if not zombies:
                    logger.info("[Boot] No zombie processes found")
                    return 0, 0
                
                logger.warning(f"[Boot] 🧟 Found {zombies_found} zombie processes")
                
                for proc in zombies:
                    recovered = await self._recover_single_process(session, proc)
                    if recovered:
                        zombies_recovered += 1
                
                await session.commit()
                
        except Exception as e:
            logger.error(f"[Boot] Process recovery failed: {e}")
        
        return zombies_found, zombies_recovered

    async def _recover_single_process(self, session, proc) -> bool:
        """Attempt to recover a single zombie process.
        
        Args:
            session: Database session
            proc: SysProcess instance
            
        Returns:
            True if process was successfully recovered/handled
        """
        from .malha import ProcessStatus
        
        logger.info(
            f"[Boot] Processing zombie: {proc.process_name} "
            f"(type={proc.process_type}, id={proc.id})"
        )
        
        # Check if we have a recovery handler
        handler = WORKFLOW_REGISTRY.get(proc.process_type)
        
        if handler and self.auto_recover:
            try:
                # Attempt automatic recovery
                logger.info(f"[Boot] Attempting auto-recovery for process {proc.id}")
                
                # Fire and forget - recovery runs in background
                asyncio.create_task(
                    self._execute_recovery(handler, proc)
                )
                
                # Mark as recovering (not failed yet)
                proc.status = ProcessStatus.RUNNING.value
                proc.heartbeat = datetime.now(UTC)
                proc.error = "Recovery initiated by bootloader"
                session.add(proc)
                return True
                
            except Exception as e:
                logger.error(f"[Boot] Auto-recovery failed for {proc.id}: {e}")
                # Fall through to mark as failed
        
        # No handler or auto_recover disabled: mark as failed
        proc.status = ProcessStatus.FAILED.value
        proc.completed_at = datetime.now(UTC)
        proc.error = (
            f"Process died during execution. "
            f"Last heartbeat: {proc.heartbeat}. "
            f"Recovery handler: {'available' if handler else 'not registered'}"
        )
        session.add(proc)
        
        logger.warning(
            f"[Boot] Marked process {proc.id} ({proc.process_name}) as FAILED"
        )
        return False

    async def _execute_recovery(self, handler: Callable, proc) -> None:
        """Execute a recovery handler in the background.
        
        Args:
            handler: The recovery function
            proc: SysProcess instance
        """
        from .malha import ProcessStatus
        
        try:
            await handler(proc, self.kernel)
            logger.info(f"[Boot] Recovery successful for process {proc.id}")
            
        except Exception as e:
            logger.error(f"[Boot] Recovery execution failed for {proc.id}: {e}")
            
            # Mark as dead letter (unrecoverable)
            try:
                async with await self.kernel.sql_driver.get_session() as session:
                    stmt = (
                        update(type(proc))
                        .where(type(proc).id == proc.id)
                        .values(
                            status=ProcessStatus.DEAD_LETTER.value,
                            error=f"Recovery failed: {e}",
                            completed_at=datetime.now(UTC),
                        )
                    )
                    await session.execute(stmt)
                    await session.commit()
            except Exception as db_error:
                logger.error(f"[Boot] Failed to update process status: {db_error}")

    async def _sanity_checks(self) -> None:
        """Perform sanity checks on the system.
        
        Currently checks:
        - SQL connection is working
        - Graph database is accessible
        - No critical inconsistencies
        """
        logger.debug("[Boot] Running sanity checks...")
        
        # Check SQL
        try:
            async with await self.kernel.sql_driver.get_session() as session:
                await session.execute(select(1))
            logger.debug("[Boot] SQL: OK")
        except Exception as e:
            logger.error(f"[Boot] SQL sanity check failed: {e}")
        
        # Check Graph (Kùzu)
        try:
            if hasattr(self.kernel, "graph_driver"):
                # Simple query to verify graph is accessible
                await self.kernel.graph_driver.query("RETURN 1")
            logger.debug("[Boot] Graph: OK")
        except Exception as e:
            logger.warning(f"[Boot] Graph sanity check failed: {e}")


# ==============================================================================
# BOOT RESULT
# ==============================================================================

class BootResult:
    """Result of a boot operation with statistics."""
    
    def __init__(
        self,
        duration_seconds: float = 0.0,
        wal_records_recovered: int = 0,
        zombies_found: int = 0,
        zombies_recovered: int = 0,
        zombies_failed: int = 0,
    ):
        self.duration_seconds = duration_seconds
        self.wal_records_recovered = wal_records_recovered
        self.zombies_found = zombies_found
        self.zombies_recovered = zombies_recovered
        self.zombies_failed = zombies_failed
    
    def __str__(self) -> str:
        return (
            f"BootResult(wal={self.wal_records_recovered}, "
            f"zombies={self.zombies_found}, "
            f"recovered={self.zombies_recovered}, "
            f"failed={self.zombies_failed})"
        )
    
    def __repr__(self) -> str:
        return self.__str__()


# ==============================================================================
# CONVENIENCE FUNCTION
# ==============================================================================

async def boot_kernel(
    kernel: "UnifiedDataManager",
    heartbeat_timeout: int = 300,
    auto_recover: bool = False,
) -> BootResult:
    """Convenience function to boot a kernel.
    
    Args:
        kernel: The kernel to boot
        heartbeat_timeout: Seconds before process is considered dead
        auto_recover: Attempt automatic recovery for registered handlers
        
    Returns:
        BootResult with recovery statistics
    """
    bootloader = Bootloader(
        kernel,
        heartbeat_timeout=heartbeat_timeout,
        auto_recover=auto_recover,
    )
    return await bootloader.run()
