from setuptools import setup, find_packages

setup(
    name="rafivector",
    version="0.5.0",
    description="A simple library for vector operations",
    author="Rafi",
    packages=find_packages(),
    install_requires=[],
)
