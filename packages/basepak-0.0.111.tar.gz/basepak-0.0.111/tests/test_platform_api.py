# this module is mostly hot garbage.
# Needs a complete refactor. Will write tests then
