# Nezuki

Nezuki è una libreria Python modulare per varie integrazioni relativi all'Home Server con Ubuntu.

Il modulo Nezuki include una serie di funzionalità relative alla gestioned el server ma anche della domotica ed offre funzionalità che possono essere usate anche fuori da questi contesti.

## Caratteristiche

Per visualizzare aggiornamenti, deprecazioni, nuove funzionalità vedere il file CHANGELOG.md

Ogni modulo ha la sua relativa documentazione specifica, per un uso specifico e dettagliato visualizzare la relativa documentazione (README.md), di seguito un uso generale e piccola demo su come installare Nezuki e qualche esempio di funzionamento.

## Installazione

Puoi installare Nezuki tramite pip:

```bash
pip install Nezuki
```

## Esempio

