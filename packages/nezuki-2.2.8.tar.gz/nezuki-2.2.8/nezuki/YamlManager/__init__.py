__version__ = "2.0.0"

from .YamlManager import YamlManager

__all__ = ['YamlManager']
