import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import ProductUpdate


@pytest.mark.asyncio
@pytest.mark.integration
class TestUpdateProduct:
    """
    Example with options: --product-id=1234-foo-bar --update-fields='{"foo":"bar"}'
    """

    async def test_method(
        self, real_client: MoyskladAPI, product_id: str | None, update_fields: dict
    ):
        product = await real_client.update_product(
            product_id=product_id, **update_fields
        )
        assert isinstance(product, ProductUpdate)
        assert product.id == product_id
        for key, value in update_fields.items():
            assert getattr(product, key) == value
