def assert_expand(expand: str | None, ms_object):
    if not expand:
        return

    expanded_fields = [field.strip() for field in expand.split(",")]
    object_data = ms_object.model_dump(by_alias=True)  # Используем aliases

    for field_name in expanded_fields:
        field_value = object_data.get(field_name)
        assert field_value is not None, f"Field '{field_name}' was not expanded"
