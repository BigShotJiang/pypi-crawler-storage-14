<p align="center">
  <a href="https://api.moysklad.ru"><img src="https://www.moysklad.ru/upload/logos/logoMS500.png" alt="MoyskladAPI"></a>
</p>

<div align="center">

# ⚠️ PRE-ALPHA VERSION

**This library is still in pre-alpha stage**

</div>

## 🚨 Important

This version is under active development and **NOT recommended for production use**.

## Installation

```console
pip install moysklad-api
```

### Simple usage

```Python
import asyncio

from moysklad_api import MoyskladAPI

ms_api = MoyskladAPI(token="my_token")


async def get_archived_products():
    return await ms_api.get_products(
        filters={"archived": True}
    )


if __name__ == __main__
    asyncio.run(get_archived_products())
```
