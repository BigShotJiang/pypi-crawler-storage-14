def build_filters(
    filters: dict[str, str | list[str]] | None = None,
) -> str:
    filter_groups: dict[str, list[str]] = {}

    supported_ops = ["~=", ">=", "<=", ">", "<", "="]

    if filters:
        for field, value in filters.items():
            operator = "="
            for op in supported_ops:
                if field.endswith(op):
                    operator = op
                    field = field[: -len(op)]
                    break

            values = value if isinstance(value, list) else [value]

            for v in values:
                filter_groups.setdefault(field, []).append(f"{field}{operator}{str(v)}")

    if filter_groups:
        return "&".join(";".join(conds) for conds in filter_groups.values())

    return ""
