"""Entry point for running the CLI as a module: python -m sentinel_cli."""

from sentinel_cli.main import app

if __name__ == "__main__":
    app()
