import enum

class COLOR(enum.Enum):
    BLINKING_GREEN = 3
    SUPER_GREEN = 2
    GREEN = 1
    WHITE = 0
    RED = -1
    SUPER_RED = -2
    BLINKING_RED = -3 