

## About The Project

XaiCSV is a collection of functions to convert XAI (eXplainable AI) like SHAP & LIME into Dictionary Object. The resulting Dictionary is used for easy CSV manipulation such as using Pandas. This package also includes visualization for the Dictionary. Example of Dictionary result : 
   ```
    {
    "class1": [
        ("feature1",weights1),
        ("feature2",weights2)
    ],
    "class2": [...]
    }

   ```

<!-- GETTING STARTED -->
## Getting Started

Examples can be found in `docs` and `results` folder
1. Tabular Regression & Classification for LIME & SHAP
2. Text Classification for LIME

### Prerequisites

Python >=3.9 Required

### Installation

   ```
   pip install xaicsv
   ```

## Usage

1. Use `lime_values_to_weights_dict` to get Dictionary of LIME Weights. 
2. Use `shap_values_to_weights_dict` to get Dictionary of SHAP Weights. 
3. Use `weights_dict_to_pyplot` to visualize Dictionary values. 

Import the xai_csv_utils
   ```
    from xaicsv import xai_csv_utils
   ```

### LIME
1. `lime_explanation` . LIME Explanation Object. 
2. `class_names` . list of classes . set ["target"] if Regression. 

Using iris dataset for classification task and using SVC model.

   ```
    list_labels = iris.target_names.tolist()
    list_index_labels= list(range(0, len(list_labels)))

    lime_weights = []
    for i in range(len(df_test)):
    exp = explainer.explain_instance(df_test.iloc[0].values,
                                    svc_iris.predict_proba,
                                    num_features=len(iris.feature_names),
                                    labels= list_index_labels)

    weight_val = xai_csv_utils.lime_values_to_weights_dict(
                                            lime_explanation=exp,
                                            class_names=list_labels)
    lime_weights.append(weight_val)
   ```

Add the resulting Dictionary object into a Dataframe
   ```
    df['lime_weights'] = lime_weights
   ```

### SHAP
1. `classification` . set True if Classification Task. set False if Regression Task. 
2. `shap_values` . SHAP values of one sample. 
3. `class_names` . list of classes . set ["target"] if Regression. 
4. `feature_names` . list of feature names. 

Using iris dataset for classification task and using SVC model.

   ```
    explainer_shap = shap.KernelExplainer(svc_iris.predict_proba,
                                        train,
                                        feature_names = iris.feature_names)
    shap_values = explainer_shap.shap_values(test)

    list_labels = iris.target_names.tolist()

    shap_weights = []
    for i in range(len(shap_values)):
    weight_val = shap_values_to_weights_dict(class_names=list_labels,
                                classification=True,
                                shap_values=shap_values[i],
                                feature_names=explainer_shap.data_feature_names)

    shap_weights.append(weight_val)
   ```

Add the resulting Dictionary object into a Dataframe
   ```
    df['shap_weights'] = shap_weights
   ```
### Weights Visualization

Add the resulting Dictionary object into a Dataframe
   ```
    sample_weights = df.iloc[25]["shap_weights"]
    for label in (list_labels):
        fig = weights_dict_to_pyplot(sample_weights, label)
   ```



