import shutil
from pathlib import Path

import typer
from typing_extensions import Annotated

from fasti.templates import get_templates

app = typer.Typer()


@app.command()
def init(
    project_name: Annotated[
        str | None,
        typer.Argument(show_default=False),
    ] = None,
    overwrite: Annotated[
        bool, typer.Option("--overwrite", "-o", help="Overwrite existing files")
    ] = False,
):
    """
    Initialize a new FastAPI project.

    If no project name is provided, the project will be initialized in the current directory.
    """
    project_path = Path.cwd()

    if project_name:
        project_path /= project_name

        if project_path.exists() and not overwrite:
            confirm = typer.confirm(
                f"The directory {project_path} already exists. Do you want to continue?",
                default=False,
            )
            if not confirm:
                print("Initialization aborted.")
                raise typer.Exit()

    project_path.mkdir(parents=True, exist_ok=True)

    templates = get_templates()

    # Temporary workaround until more templates are added
    if "hello_world" in templates:
        template_dir = templates["hello_world"]
        for item in template_dir.iterdir():
            dest_item = project_path / item.name
            if item.is_dir():
                shutil.copytree(item, dest_item, dirs_exist_ok=True)
            else:
                shutil.copy2(item, dest_item)

    print(f"Initializing FastAPI Project in: {project_path}")
