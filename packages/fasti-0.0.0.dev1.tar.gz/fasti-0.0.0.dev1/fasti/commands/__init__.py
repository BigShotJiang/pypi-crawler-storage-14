from .init import app as init

__all__ = ["init"]
