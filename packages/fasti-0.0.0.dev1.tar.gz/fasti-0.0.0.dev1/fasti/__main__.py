if __name__ == "__main__":
    from fasti.cli import app

    app()
