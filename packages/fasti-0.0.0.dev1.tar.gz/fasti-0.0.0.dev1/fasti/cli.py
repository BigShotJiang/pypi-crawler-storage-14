import typer

from fasti.commands import init

app = typer.Typer(
    name="fasti: FastAPI Project Manager",
    help="A CLI tool to initialize FastAPI projects",
)

app.add_typer(init)

if __name__ == "__main__":
    app()
