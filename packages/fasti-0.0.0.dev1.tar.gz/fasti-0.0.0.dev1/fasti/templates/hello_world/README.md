# 🚀 FastAPI Hello World Template

This is a minimal project template designed to quickly bootstrap new microservices or simple APIs using FastAPI.

## 📂 Project Structure

```text
.
├── .gitignore          # Files/directories to ignore for version control
├── main.py             # The entry point for the FastAPI application
├── pyproject.toml      # Project metadata and dependency definitions
├── README.md           # Project documentation
└── requirements        # Project dependencies
```

### 🛠️ Prerequisites

- [Python](https://www.python.org/) 3.11+ installed.
- [uv](https://docs.astral.sh/uv/) (recommended dependency manager).

### ⚡ Quick Start

We recommend using uv to manage dependencies and virtual environments based on the pyproject.toml file.

### Install Dependencies with uv

```bash
uv sync
```

### Install Dependencies with pip

Create a dedicated virtual environment, and install all required packages.

```bash
pip install -r requirements.txt
```

## 🏃‍♂️ Running the Server

### Running the Server with uv

```bash
uv run fastapi dev main.py
```

### Running the Server with Python

Once the environment is active, you can start the development server

```bash
fastapi dev main.py
```

### 🌐 Usage and Endpoints

| Endpoint | url                                                      |
| -------- | -------------------------------------------------------- |
| Root     | [http://127.0.0.1:8000/](http://127.0.0.1:8000/)         |
| Doc      | [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) |
