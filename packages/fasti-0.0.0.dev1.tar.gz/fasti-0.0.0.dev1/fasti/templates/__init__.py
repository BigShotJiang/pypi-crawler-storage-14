from pathlib import Path

templates_dir = Path(__file__).parent


def get_templates() -> dict[str, Path]:
    exclude_dirs = ["__pycache__"]
    templates = {
        entry.name: entry
        for entry in templates_dir.iterdir()
        if entry.is_dir() and entry.name not in exclude_dirs
    }
    return templates


__all__ = ["templates_dir", "get_templates"]
