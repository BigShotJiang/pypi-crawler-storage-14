# fasti ⚡

A CLI tool to bootstrap FastAPI projects from templates.

---

## Quickstart

Initialize a new project in the current directory:

```bash
fasti init
```

Initialize a named project (creates a new directory):

```bash
fasti init my-service
```

To overwrite an existing directory:

```bash
fasti init my-service --overwrite
```

If you didn't install `fasti` as a script, use `python -m fasti init ...` instead.

---

## Contributing

Contributions welcome. Open issues or PRs for bug fixes, features, template additions, or documentation improvements.

---

## License

This project is licensed under the MIT License - See [MIT License](./LICENSE) for details.
