"""Service management for ThreatWinds Pentest CLI.

This module provides local service installation for the ThreatWinds
Pentest Agent on Linux systems (Kali Linux, Ubuntu).
"""

from .agent_install import (
    # Agent installation
    download_agent,
    extract_agent,
    setup_python_environment,
    # Service management
    install_service,
    install_systemd_service,  # Backward compatibility alias
    start_agent_service,
    stop_agent_service,
    remove_agent_service,
    remove_agent_files,
    # Service status
    is_service_installed,
    is_service_running,
    # Paths and checks
    get_agent_path,
    check_linux_only,
    check_root_privileges,
)

__all__ = [
    # Agent installation
    "download_agent",
    "extract_agent",
    "setup_python_environment",
    # Service management
    "install_service",
    "install_systemd_service",
    "start_agent_service",
    "stop_agent_service",
    "remove_agent_service",
    "remove_agent_files",
    # Service status
    "is_service_installed",
    "is_service_running",
    # Paths and checks
    "get_agent_path",
    "check_linux_only",
    "check_root_privileges",
]
