from typing import NewType

URL = NewType("URL", str)
