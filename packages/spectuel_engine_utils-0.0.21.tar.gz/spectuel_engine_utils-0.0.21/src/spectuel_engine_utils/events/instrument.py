from typing import Literal
from uuid import UUID

from spectuel_engine_utils.events.base import EngineEventBase
from .enums import InstrumentEventType


class InstrumentEventBase(EngineEventBase):
    version: int = 1
    instrument_id: UUID


class NewInstrumentEvent(InstrumentEventBase):
    type: Literal[InstrumentEventType.NEW_INSTRUMENT] = (
        InstrumentEventType.NEW_INSTRUMENT
    )


class InstrumentPriceEvent(InstrumentEventBase):
    type: Literal[InstrumentEventType.PRICE] = InstrumentEventType.PRICE
    price: float
