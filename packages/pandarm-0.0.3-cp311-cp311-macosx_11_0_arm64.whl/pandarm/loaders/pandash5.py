import geopandas as gpd
import pandas as pd
from shapely.io import from_wkb, to_wkb


def remove_nodes(network, rm_nodes):
    """
    Create DataFrames of nodes and edges that do not include specified nodes.

    Parameters
    ----------
    network : pandarm.Network
    rm_nodes : array_like
        A list, array, Index, or Series of node IDs that should *not*
        be saved as part of the Network.

    Returns
    -------
    nodes, edges : pandas.DataFrame

    """
    rm_nodes = set(rm_nodes)
    ndf = network.nodes_df
    edf = network.edges_df

    nodes_to_keep = ~ndf.index.isin(rm_nodes)
    edges_to_keep = ~(edf["from"].isin(rm_nodes) | edf["to"].isin(rm_nodes))

    return ndf.loc[nodes_to_keep], edf.loc[edges_to_keep]


def network_to_pandas_hdf5(network, filename, rm_nodes=None):
    """
    Save a Network's data to a Pandas HDFStore.

    Parameters
    ----------
    network : pandarm.Network
    filename : str
    rm_nodes : array_like
        A list, array, Index, or Series of node IDs that should *not*
        be saved as part of the Network.

    """
    if rm_nodes is not None:
        nodes, edges = remove_nodes(network, rm_nodes)
    else:
        nodes, edges = network.nodes_df, network.edges_df

    with pd.HDFStore(filename, mode="w") as store:
        store["nodes"] = nodes.drop(columns="geometry")
        if isinstance(edges, gpd.GeoDataFrame):
            edges["geometry"] = edges[edges.geometry.name].apply(to_wkb)
        store["edges"] = edges
        store["two_way"] = pd.Series([network._twoway])
        store["impedance_names"] = pd.Series(network.impedance_names)
        store["crs"] = pd.Series([network.crs])


def network_from_pandas_hdf5(cls, filename):
    """
    Build a Network from data in a Pandas HDFStore.

    Parameters
    ----------
    cls : class
        Class to instantiate, usually pandana.Network.
    filename : str

    Returns
    -------
    network : pandarm.Network

    """
    with pd.HDFStore(filename) as store:
        nodes = store["nodes"]
        edges = store["edges"]
        crs = store['crs'].values[0] if 'crs' in store.keys() else None
        if "geometry" in edges.columns:
            edges["geometry"] = gpd.GeoSeries(edges["geometry"].apply(from_wkb), crs=crs)
            edge_geom = "geometry"
        two_way = store["two_way"][0]
        imp_names = store["impedance_names"].tolist()
        edge_geom = edges.geometry if 'geometry' in edges.columns.values else None
        

    return cls(
        nodes["x"],
        nodes["y"],
        edges["from"],
        edges["to"],
        edges[imp_names],
        twoway=two_way,
        edge_geom=edge_geom,
        crs=crs,
    )
