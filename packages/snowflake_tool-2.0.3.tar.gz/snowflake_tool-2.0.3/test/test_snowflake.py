#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: BeYoung
# Date: 2023/6/12 22:50
# Software: PyCharm
import logging
import time
import sys
import pathlib
sys.path.append(str(pathlib.Path.cwd()))
from snowflake_tool.snowflake import SnowflakeGenerator
    
log = logging.getLogger("test_generate")
log.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter('\n%(asctime)s - %(name)s - %(levelname)s - %(message)s\n'))
log.addHandler(handler)
bench = int(1e6)

def test_new_generate():
    generate_id = set()
    node1 = SnowflakeGenerator()
    node2 = SnowflakeGenerator()
    start = time.time()
    for _ in range(bench):
        generate_id.add(node1.g())
        generate_id.add(node2.g())
    assert len(generate_id) == bench * 2
    log.info(f"Time {bench=}: {int((time.time() - start) * 1000)} ms")