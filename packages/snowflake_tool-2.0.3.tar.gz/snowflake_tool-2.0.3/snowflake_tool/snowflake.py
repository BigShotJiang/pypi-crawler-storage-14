#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: BeYoung
# Date: 2023/6/12 17:37
# Software: PyCharm
"""
pysnowflake provides a simple Twitter snowflake generator and parser.
"""

import time
import typing
from warnings import deprecated
from threading import Lock
from asyncio import Lock as aLock

class SnowflakeGenerator:
    __epoch: int = 1288834974657
    __sequence_mask: int = 0xFFF
    __machine_id: int = 1
    __machine_shift: int = 12
    __timestamp_shift: int = 22

    def __init__(self, machine_id=1):
        """
        :param machine_id: min=0, max=(1<<machine_size)-1
        """
        self.__machine_id = machine_id
        self.__lock= Lock()
        self.__alock = aLock()
        self.__sequence = 0
        self._last_timestamp = -1
        
    
    @deprecated("Because threading safe")
    def g(self) -> typing.Generator[typing.Any, typing.Any, int]:
        """
        generate a snowflake id
        :return: id
        """
        while True:
            now = int(time.time() * 1000) - self.__epoch
            _id = (
                (now << self.__timestamp_shift)
                | (self.__machine_id << self.__machine_shift)
                | self.__sequence
            )
            yield _id
            self.__sequence = (self.__sequence + 1) & self.__sequence_mask

    def gen_id(self)->int:
        with self.__lock:
            timestamp = int(time.time() * 1000) - self.__epoch
            
            # 处理时钟回拨
            if timestamp < self._last_timestamp:
                raise RuntimeError("Clock moved backwards")
            
            # 等待下一毫秒（如果sequence用尽）
            if timestamp == self._last_timestamp:
                self.__sequence = (self.__sequence + 1) & self.__sequence_mask
                if self.__sequence == 0:  # sequence用尽
                    while timestamp <= self._last_timestamp:
                        timestamp = int(time.time() * 1000) - self.__epoch
            else:
                self.__sequence = 0
            
            self._last_timestamp = timestamp
            
            return (
                (timestamp << self.__timestamp_shift) |
                (self.__machine_id << self.__machine_shift) |
                self.__sequence
            )
    
    async def agen_id(self) -> int:
        async with self.__alock:
            timestamp = int(time.time() * 1000) - self.__epoch
            
            # 处理时钟回拨
            if timestamp < self._last_timestamp:
                raise RuntimeError("Clock moved backwards")
            
            # 等待下一毫秒（如果sequence用尽）
            if timestamp == self._last_timestamp:
                self.__sequence = (self.__sequence + 1) & self.__sequence_mask
                if self.__sequence == 0:  # sequence用尽
                    while timestamp <= self._last_timestamp:
                        timestamp = int(time.time() * 1000) - self.__epoch
            else:
                self.__sequence = 0
            
            self._last_timestamp = timestamp
            
            return (
                (timestamp << self.__timestamp_shift) |
                (self.__machine_id << self.__machine_shift) |
                self.__sequence
            )
        
    # @classmethod
    # def parse(
    #     cls, snowflake_id=0, machine_size=10, sequence_size=12, epoch=1288834974657
    # ) -> ID:
    #     """
    #     :param snowflake_id: snowflake id
    #     :param machine_size: min=1, max=21
    #     :param sequence_size: min=1, max=21
    #     :param epoch: min=0, max=now()
    #     Note: machine_size + sequence.size <= 22
    #     """
    #     return ID(snowflake_id, machine_size, sequence_size, epoch)

    @property
    def epoch(self):
        return self.__epoch

    @property
    def machine(self):
        return self.__machine_id

    def __str__(self):
        return str(self.__dir__())

    def __next__(self):
        return self.g()


Generator = SnowflakeGenerator
generator = Generator()