from enum import Enum, auto, IntEnum


class RoverCommands(Enum):
    SET_VELOCITY = auto()
    SET_DIFF_SPEED = auto()
    LED_CONTROL = auto()
    LED_CUSTOM = auto()
    STOP = auto()
    EMERGENCY_STOP = auto()
    GOTO_CANCEL = auto()
    MOO = auto()
    BEEP = auto()

class LedMode(IntEnum):
    OFF = 1,
    FLASHER = 2,
    STATIC = 3
