"""UI Widget components for Docker Monitor Manager."""
