from vdata.update.update import CURRENT_VERSION, update_vdata

__all__ = [
    "update_vdata",
    "CURRENT_VERSION",
]
