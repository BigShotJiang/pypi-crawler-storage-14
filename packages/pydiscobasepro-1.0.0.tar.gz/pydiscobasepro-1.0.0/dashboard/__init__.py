from aiohttp import web
import json

class Dashboard:
    def __init__(self, bot, database, config):
        self.bot = bot
        self.database = database
        self.config = config
        self.app = web.Application()
        self.setup_routes()

    def setup_routes(self):
        self.app.router.add_get('/', self.index)
        self.app.router.add_get('/stats', self.stats)

    async def index(self, request):
        return web.Response(text="<h1>PyDiscoBasePro Dashboard</h1><a href='/stats'>Stats</a>")

    async def stats(self, request):
        stats = {
            "guilds": len(self.bot.guilds),
            "users": sum(guild.member_count for guild in self.bot.guilds if guild.member_count),
            "commands": len(self.bot.commands),
            "uptime": str(self.bot.uptime) if self.bot.uptime else "Not started"
        }
        return web.json_response(stats)

    async def run(self):
        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, self.config["host"], self.config["port"])
        await site.start()
        print(f"Dashboard running on http://{self.config['host']}:{self.config['port']}")