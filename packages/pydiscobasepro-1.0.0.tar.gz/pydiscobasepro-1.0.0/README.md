# PyDiscoBasePro

A Python-based Discord bot framework inspired by Discobase, with advanced features for building scalable Discord bots.

## Features

- **Prefix-based commands** with aliases and cooldowns
- **Slash commands** with auto-registration
- **Context menus** support
- **Dynamic loading/unloading** of commands, events, and components
- **Hot-reloading** without restarting the bot
- **Permission checks** (roles, users, admin, bot permissions)
- **Error logging, crash reporting, and recovery**
- **Event hooks** for various Discord events
- **Optional web dashboard** for bot stats
- **Persistent storage** with MongoDB
- **Configurable** via JSON
- **Logging** to files and Discord channels
- **Automatic command help generation**
- **Support for embeds, buttons, selects, modals**
- **Built-in utilities** (timers, randomizers, cooldown helpers, API helpers)
- **Easy extension system** for plugins

## Installation

### Option 1: Manual Setup
1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/pydiscobasepro.git
   cd pydiscobasepro
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Set up MongoDB (local or cloud instance).

4. Configure `config/config.json` with your bot token and settings.

5. Run the bot:
   ```bash
   python bot.py
   ```

### Option 2: Use CLI Generator
1. Install the framework globally (optional):
   ```bash
   pip install -e .
   ```

2. Generate a new project:
   ```bash
   python cli.py create MyBotProject
   # or if installed: pydisco create MyBotProject
   ```

3. Navigate to the project:
   ```bash
   cd MyBotProject
   pip install -r requirements.txt
   ```

4. Configure and run as above.

## Configuration

Edit `config/config.json`:

```json
{
  "token": "YOUR_BOT_TOKEN",
  "prefix": "!",
  "intents": {
    "guilds": true,
    "members": true,
    "messages": true,
    "message_content": true,
    "voice_states": true,
    "reactions": true
  },
  "mongodb": {
    "uri": "mongodb://localhost:27017",
    "database": "pydiscobasepro"
  },
  "logging": {
    "level": "INFO",
    "file": "logs/bot.log",
    "discord_channel_id": null
  },
  "dashboard": {
    "enabled": false,
    "host": "0.0.0.0",
    "port": 8080
  }
}
```

## Usage

### Creating Commands

Create a new file in `commands/` directory. Example: `commands/ping.py`

```python
import discord
from discord import app_commands
from discord.ext import commands

class Ping:
    def __init__(self, bot, database):
        self.bot = bot
        self.database = database
        self.name = "ping"
        self.description = "Check bot latency"
        self.aliases = ["pong"]
        self.permissions = []
        self.cooldown = 5

        self.prefix_command = commands.command(name=self.name, aliases=self.aliases, help=self.description)(
            self.run_prefix
        )

        self.slash_command = app_commands.Command(
            name=self.name,
            description=self.description,
            callback=self.run_slash
        )

    async def run_prefix(self, ctx):
        latency = round(self.bot.latency * 1000)
        embed = discord.Embed(title="Pong!", description=f"Latency: {latency}ms", color=0x00ff00)
        await ctx.send(embed=embed)

    async def run_slash(self, interaction: discord.Interaction):
        latency = round(self.bot.latency * 1000)
        embed = discord.Embed(title="Pong!", description=f"Latency: {latency}ms", color=0x00ff00)
        await interaction.response.send_message(embed=embed)
```

### Creating Events

Create in `events/` directory. Example: `events/on_ready.py`

```python
import discord
from loguru import logger

class OnReady:
    def __init__(self, bot, database):
        self.bot = bot
        self.database = database

        @self.bot.event
        async def on_ready():
            logger.info("Bot is ready!")
```

### Creating Components

Create in `components/` directory. Example: `components/test_button.py`

```python
import discord
from discord.ui import Button, View

class TestButton:
    def __init__(self, bot, database):
        self.bot = bot
        self.database = database

        @self.bot.event
        async def on_interaction(interaction: discord.Interaction):
            if interaction.type == discord.InteractionType.component:
                if interaction.custom_id == "test_button":
                    await interaction.response.send_message("Button clicked!", ephemeral=True)
```

### Dashboard

If enabled in config, access at `http://localhost:8080` for basic stats.

### MongoDB Integration

The framework uses MongoDB for persistent storage. Example usage:

```python
# In a command
guild_config = await self.database.get_guild_config(ctx.guild.id)
if not guild_config:
    guild_config = GuildConfig(ctx.guild.id)
await self.database.update_guild_config(guild_config)

user_profile = await self.database.get_user_profile(ctx.author.id)
user_profile.xp += 10
await self.database.update_user_profile(user_profile)

# Track command usage
await self.database.increment_command_usage("ping")
```

## Production Deployment

- Use a process manager like PM2 or systemd
- Set up environment variables for sensitive data
- Configure MongoDB for production
- Enable dashboard for monitoring

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes
4. Submit a pull request

## Credits

- **Original Inspiration:** Code-X organization
- **Lead Developer:** Ramkrishna
- **Co-developer:** Razzak

## License

MIT License - see LICENSE file for details.