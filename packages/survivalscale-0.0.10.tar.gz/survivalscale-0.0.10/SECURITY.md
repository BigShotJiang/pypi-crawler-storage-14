# Security Policy

## Supported Versions

We are currently supporting version v0.x.

## Reporting a Vulnerability

Please report security errors to Ben Smith at bosmith@unomaha.edu.  Credit will be given to the reporter once a patch is issued.

