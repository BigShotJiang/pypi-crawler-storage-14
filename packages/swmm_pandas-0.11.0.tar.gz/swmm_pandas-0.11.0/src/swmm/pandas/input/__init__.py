from swmm.pandas.input.input import InputFile
from swmm.pandas.input.model import Input
