"""Nellika SCB C Extension Module"""

import json
import os
from . import _binding

__version__ = "1.2.1"

# Automatically initialize telemetry on module import (if database env vars are set)
def _auto_init_telemetry():
    """Internal function to initialize telemetry on module import"""
    # Only initialize if we're in an Odoo environment (PGDATABASE is set)
    if os.environ.get('PGDATABASE'):
        try:
            # Call C function to initialize (fetches all data from database)
            _binding._internal_telemetry_init()
        except Exception as e:
            # Silently ignore errors during auto-init
            pass

# Run auto-init
_auto_init_telemetry()

def version():
    """Get module version"""
    return __version__

def create_qr(config_id, amount, reference, channel='ecomm'):
    """
    Create SCB QR code payment
    
    Args:
        config_id: SCB API configuration ID
        amount: Payment amount
        reference: Payment reference
        channel: Payment channel (default: 'ecomm')
    
    Returns:
        dict: Response with 'status' and 'data' keys
              status.code: 1000 = success, other = error
              status.description: Error message if failed
    """
    return _binding.scb_api_create_qr(str(config_id), float(amount), reference, channel)

def check_payment(reference):
    """
    Check SCB payment status
    
    Args:
        reference: Payment reference
    
    Returns:
        dict: JSON response with payment status
    """
    return _binding.scb_api_check_payment(reference)

def refresh_token(api_key, api_secret, token_url):
    """
    Refresh SCB access token
    
    Args:
        api_key: SCB API key
        api_secret: SCB API secret
        token_url: Token endpoint URL
    
    Returns:
        dict: JSON response with access token data
    """
    return _binding.scb_api_refresh_token(api_key, api_secret, token_url)

def create_qr_full(api_key, access_token, qr_create_url, biller_id, amount, ref1, ref2, ref3="SCB"):
    """
    Create SCB QR code with full parameters
    
    Args:
        api_key: SCB API key
        access_token: Access token from refresh_token()
        qr_create_url: QR creation endpoint URL
        biller_id: PromptPay biller ID
        amount: Payment amount
        ref1: Reference 1 (max 20 chars)
        ref2: Reference 2 (max 12 chars)
        ref3: Reference 3 (default: "SCB")
    
    Returns:
        dict: JSON response with QR code data
    """
    return _binding.scb_api_create_qr_full(
        api_key, access_token, qr_create_url, biller_id,
        float(amount), ref1, ref2, ref3
    )

def create_qr_by_bank_account(bank_account_id, amount, ref1, ref2, ref3="SCB"):
    """
    Create SCB QR code using bank account ID - fetches config from database
    
    This is the recommended method for production use. It:
    - Connects to PostgreSQL (using PGHOST, PGDATABASE env vars)
    - Fetches SCB API config and biller ID from database
    - Automatically refreshes access token
    - Creates QR code via SCB API
    
    Args:
        bank_account_id: Bank account ID from res.partner.bank
        amount: Payment amount
        ref1: Reference 1 (max 20 chars, e.g. "P00001")
        ref2: Reference 2 (max 12 chars, e.g. "TEST")
        ref3: Reference 3 (default: "SCB")
    
    Returns:
        dict: JSON response with QR code data
    
    Environment variables required:
        PGDATABASE: Database name (default: nellika)
        PGHOST: PostgreSQL host (default: localhost)
        PGPORT: PostgreSQL port (default: 5432)
        PGUSER: PostgreSQL user (default: current user)
        PGPASSWORD: PostgreSQL password (optional)
    """
    return _binding.scb_api_create_qr_by_bank(
        str(bank_account_id), float(amount), ref1, ref2, ref3
    )
