from pathlib import Path

VERSION = "2.1.0"
ROOT_DIR = Path(__file__).parent
