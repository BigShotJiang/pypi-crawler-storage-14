# -*- coding: utf-8 -*-
"""
MassGen Tools Module

This module contains agent tools and utilities, including:
- Planning tools for task management and coordination
- MCP servers for agent capabilities
"""
