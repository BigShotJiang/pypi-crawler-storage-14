# File Locations

## Backend Features
- **Capabilities Registry**: `massgen/backend/capabilities.py`
- **Backend Implementation**: `massgen/backend/{provider}.py`

## Configuration
- **Validator**: `massgen/config_validator.py`
- **Interactive Builder**: `massgen/config_builder.py`
- **Example Configs**: `massgen/configs/`

## Documentation
- **Source**: `docs/source/`
- **User Guides**: `docs/source/user_guide/`
- **Reference**: `docs/source/reference/`

## Tests
- **Unit Tests**: `massgen/tests/`
