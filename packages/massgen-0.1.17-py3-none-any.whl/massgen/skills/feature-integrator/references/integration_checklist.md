# Integration Checklist

Complete this checklist before submitting a PR with new features.

## Core Codebase

### Backend Updates
- [ ] **Capabilities**: Updated `massgen/backend/capabilities.py` (new backends/models)?
- [ ] **Validation**: Updated `massgen/config_validator.py` (new validation rules)?
- [ ] **Config Builder**: Updated `massgen/config_builder.py` (interactive wizard)?

### API Parameters
When adding new YAML parameters, update **BOTH** files:
- [ ] **Base Backend**: `massgen/backend/base.py` → `get_base_excluded_config_params()`
- [ ] **API Handler**: `massgen/api_params_handler/_api_params_handler_base.py` → `get_base_excluded_config_params()`

### Other Core Files
- [ ] **CLI**: Updated `massgen/cli.py` (new CLI flags)?
- [ ] **Orchestrator**: Updated `massgen/orchestrator.py` (coordination changes)?
- [ ] **Agent Config**: Updated `massgen/agent_config.py` (agent behavior)?

## Documentation

### Primary Documentation (Sphinx)
- [ ] **User Guide**: Updated relevant `.rst` in `docs/source/user_guide/`
- [ ] **Reference**: Updated `docs/source/reference/` (yaml_schema, supported_models, etc.)
- [ ] **Quickstart**: Updated `docs/source/quickstart/` (if user-facing workflow changes)
- [ ] **Examples**: Added/updated `docs/source/examples/` (if new patterns)

### Changelog and README
- [ ] **Changelog**: Added entry to `CHANGELOG.md`
- [ ] **README**: Updated `README.md` (only for major features)

### Build Verification
- [ ] **Docs Build**: `cd docs && make html` builds without warnings
- [ ] **Link Check**: `cd docs && make linkcheck` passes

## Examples and Configs

### Example Configs
- [ ] **Basic Examples**: Added to `massgen/configs/basic/` (single/multi agent)
- [ ] **Tool Examples**: Added to `massgen/configs/tools/` (if tool-related)
- [ ] **Provider Examples**: Added to `massgen/configs/providers/` (if provider-specific)

### Config Guidelines
- [ ] Follows `docs/source/development/writing_configs.rst`
- [ ] Has unique workspace per agent
- [ ] Includes appropriate timeouts
- [ ] Uses economical models for examples

## Testing

### Unit Tests
- [ ] **Tests Added**: New tests in `massgen/tests/`
- [ ] **Tests Pass**: `uv run pytest massgen/tests/ -v`
- [ ] **Coverage**: Critical paths are tested

### Integration Testing
- [ ] **Real Run**: Tested with actual MassGen execution
- [ ] **Automation Mode**: Works with `--automation` flag

## Code Quality

### Pre-commit
- [ ] **Linting**: `uv run pre-commit run --all-files` passes
- [ ] **Formatting**: Code is properly formatted
- [ ] **Type Hints**: New code has type annotations

### Code Review
- [ ] **Docstrings**: Google-style docstrings for public functions
- [ ] **Comments**: Complex logic is commented
- [ ] **No Secrets**: No hardcoded credentials or sensitive data

## PR Preparation

### PR Documentation
- [ ] **PR_SCRATCHPAD.md**: Updated with PR context and notes
- [ ] **Issue Reference**: Linked to relevant GitHub issue
- [ ] **Description**: Clear summary of changes

### Final Checks
- [ ] **Branch**: Feature branch created (`feature/your-feature`)
- [ ] **Commits**: Clean commit history with descriptive messages
- [ ] **Conflicts**: No merge conflicts with main branch

## Quick Reference: File Locations

| Update Type | Primary File |
|-------------|-------------|
| New backend/model | `massgen/backend/capabilities.py` |
| Config validation | `massgen/config_validator.py` |
| New YAML params | `base.py` + `_api_params_handler_base.py` |
| CLI flags | `massgen/cli.py` |
| User docs | `docs/source/user_guide/` |
| API docs | `docs/source/reference/` |
| Example configs | `massgen/configs/` |
| Unit tests | `massgen/tests/` |
