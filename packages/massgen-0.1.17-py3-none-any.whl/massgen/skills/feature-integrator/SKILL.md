---
name: feature-integrator
description: Use when integrating a new MassGen feature into the codebase. Covers updating backends, documentation, configs, validation rules, and creating pull requests. Prevents "orphan features" that lack proper documentation and configuration support.
---

# Feature Integrator

Ensures new features are fully integrated into MassGen with proper documentation and config support.

## Integration Workflow

### 1. Update Core Files

**Backend capabilities** (new backends/models):
```python
# massgen/backend/capabilities.py
"your_backend": {
    "models": ["model-1"],
    "supports": ["web_search"],
}
```

**Config validation** (new config options):
```python
# massgen/config_validator.py
def _validate_your_feature(self, config, result):
    ...
```

**API params** (new YAML parameters) - update **BOTH**:
- `massgen/backend/base.py`
- `massgen/api_params_handler/_api_params_handler_base.py`

### 2. Update Documentation

**Primary docs** (Sphinx - source of truth):
- User guides: `docs/source/user_guide/`
- Reference: `docs/source/reference/`

**Build and verify**:
```bash
cd docs && make html
cd docs && make linkcheck
```

**Changelog**: Add to `CHANGELOG.md`

### 3. Create Examples

Add configs to appropriate directory in `massgen/configs/`:
- `basic/` - Simple examples
- `tools/` - Tool-specific
- `providers/` - Provider-specific

### 4. Add Tests

Location: `massgen/tests/`

```bash
uv run pytest massgen/tests/test_your_feature.py -v
```

## PR Workflow

```bash
# Before PR
uv run pre-commit run --all-files
uv run pytest massgen/tests/ -v
cd docs && make html

# Create PR
git checkout -b feature/your-feature
git add -u .
git commit -m "Add your feature"
git push -u origin feature/your-feature
gh pr create --title "Add feature" --body "..."
```

## Integration Checklist

See [integration_checklist.md](references/integration_checklist.md) for complete checklist.

**Core**:
- [ ] `massgen/backend/capabilities.py`
- [ ] `massgen/config_validator.py`
- [ ] Both `base.py` files (for new params)

**Docs**:
- [ ] `docs/source/user_guide/`
- [ ] `docs/source/reference/`
- [ ] `CHANGELOG.md`

**Examples/Tests**:
- [ ] `massgen/configs/`
- [ ] `massgen/tests/`

## References

- [Integration Checklist](references/integration_checklist.md) - Complete checklist
- [File Locations](references/file_locations.md) - File location map
- **Config guide**: `docs/source/development/writing_configs.rst`
