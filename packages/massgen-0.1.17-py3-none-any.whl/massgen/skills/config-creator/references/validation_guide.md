# Validation Guide

## Common Errors

### 1. Invalid Backend Type
- **Error**: `Unknown backend type: 'xyz'`
- **Fix**: Check `massgen/backend/capabilities.py` for valid types.

### 2. Missing Required Fields
- **Error**: `Agent missing required field 'backend'`
- **Fix**: Ensure all agents have `id` and `backend` sections.

### 3. Invalid Permission Mode
- **Error**: `Invalid permission_mode`
- **Fix**: Use one of: `default`, `acceptEdits`, `bypassPermissions`, `plan`.

## Troubleshooting

1. **Run Validator**: Always run `scripts/validate_config.py` first.
2. **Check Schema**: Refer to `massgen/config_validator.py` to see the exact validation logic.
3. **Minimal Config**: Try a minimal config with just one agent to isolate the issue.
