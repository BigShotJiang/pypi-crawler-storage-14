# Config Principles

## Core Structure

A MassGen configuration file has four main sections:

```yaml
agents:      # Required - LLM agent definitions
ui:          # Required - Display and logging settings
orchestrator: # Optional - Coordination settings
timeout_settings: # Optional - Timeout configuration
```

## 1. Agents (Required)

Each agent defines an LLM backend and its capabilities:

```yaml
agents:
  - id: "agent_a"              # Required: Unique identifier
    backend:                   # Required: LLM configuration
      type: "openai"           # Provider (openai, anthropic, google, etc.)
      model: "gpt-5-mini"      # Model identifier

      # Response tuning
      text:
        verbosity: "medium"    # low, medium, high
      reasoning:
        effort: "medium"       # low, medium, high
        summary: "auto"        # auto, always, never

      # Built-in tools
      enable_web_search: true
      enable_code_interpreter: true

      # MCP tools
      enable_mcp: true
      enable_mcp_command_line: true
      command_line_execution_mode: "docker"  # local, docker

      # Custom tools
      custom_tools:
        - name: ["tool_name"]
          category: "category"
          path: "path/to/tool.py"
          function: ["function_name"]

    # Filesystem access
    filesystem:
      cwd: "workspace1"        # Working directory (unique per agent!)

    # System message
    system_message: |
      You are a helpful assistant...
```

### Backend Types

| Type | Provider | Example Models |
|------|----------|----------------|
| `openai` | OpenAI | gpt-5, gpt-5-mini, gpt-5-nano, gpt-4o |
| `anthropic` | Anthropic | claude-sonnet-4-5 |
| `claude_code` | Anthropic (native filesystem) | claude-sonnet-4-5 |
| `google` | Google | gemini-2.0-flash, gemini-2.5-pro |
| `azure_openai` | Azure | (same as openai) |
| `inference` | OpenRouter/vLLM | qwen, mistral |
| `lmstudio` | Local | local models |
| `grok` | xAI | grok-3, grok-3-mini |

## 2. UI (Required)

Display and logging configuration:

```yaml
ui:
  display_type: "rich_terminal"  # rich_terminal, simple, silent
  logging_enabled: true          # Enable log file creation
```

## 3. Orchestrator (Optional)

Controls coordination behavior:

```yaml
orchestrator:
  # Workspace management
  agent_temporary_workspace: "temp"
  snapshot_storage: ".massgen/snapshots"

  # Coordination settings
  coordination:
    enable_planning_mode: true
    max_orchestration_restarts: 3
    max_new_answers_per_agent: 2

  # Shared context (read-only access for agents)
  context_paths:
    - path: "docs/"
      permission: "read"
    - path: "shared_resources/"
      permission: "read"
```

## 4. Timeout Settings (Optional)

```yaml
timeout_settings:
  orchestrator_timeout_seconds: 600  # Total coordination timeout
  agent_timeout_seconds: 180         # Per-agent timeout
```

## Best Practices

### 1. Unique Workspaces (Critical)

Each agent MUST have a unique `filesystem.cwd`:

```yaml
# GOOD - Unique workspaces
agents:
  - id: "agent_a"
    filesystem:
      cwd: "workspace_a"
  - id: "agent_b"
    filesystem:
      cwd: "workspace_b"

# BAD - Shared workspace causes conflicts
agents:
  - id: "agent_a"
    filesystem:
      cwd: "workspace"  # Same!
  - id: "agent_b"
    filesystem:
      cwd: "workspace"  # Conflict!
```

### 2. Cost Control

Use economical models for simple tasks:

| Cost Level | Models | Use For |
|------------|--------|---------|
| Low | gpt-5-nano, gpt-4o-mini | Simple tasks, testing |
| Medium | gpt-5-mini, gemini-2.0-flash | General use |
| High | gpt-5, claude-sonnet-4-5 | Complex reasoning |

### 3. Appropriate Timeouts

Set timeouts based on task complexity:

```yaml
# Quick tasks (2-5 minutes)
timeout_settings:
  orchestrator_timeout_seconds: 300
  agent_timeout_seconds: 120

# Complex tasks (10-30 minutes)
timeout_settings:
  orchestrator_timeout_seconds: 1800
  agent_timeout_seconds: 600
```

### 4. Context Sharing

Use `context_paths` for read-only shared resources:

```yaml
orchestrator:
  context_paths:
    - path: "docs/"
      permission: "read"
```

### 5. Consistent Agent Capabilities

For fair comparison, give agents similar capabilities:

```yaml
# Both agents have same tools
agents:
  - id: "agent_a"
    backend:
      enable_web_search: true
      enable_code_interpreter: true
  - id: "agent_b"
    backend:
      enable_web_search: true
      enable_code_interpreter: true
```

## Common Patterns

### Multi-Agent Collaboration

```yaml
agents:
  - id: "researcher"
    backend:
      model: "gpt-5-mini"
      enable_web_search: true
    system_message: "You are a research specialist..."

  - id: "analyzer"
    backend:
      model: "gemini-2.0-flash"
      enable_code_interpreter: true
    system_message: "You analyze and synthesize information..."
```

### Docker Code Execution

```yaml
backend:
  enable_mcp_command_line: true
  command_line_execution_mode: "docker"
  command_line_docker_enable_sudo: true
  command_line_docker_network_mode: "bridge"
```

### MCP Tool Integration

```yaml
backend:
  enable_mcp: true
  mcp_config_path: "path/to/mcp_servers.json"
```

## Source of Truth

For the most up-to-date information:
- **Backend capabilities**: `massgen/backend/capabilities.py`
- **Config validation**: `massgen/config_validator.py`
- **Use case templates**: `massgen/config_builder.py` (see `USE_CASES`)
- **Example configs**: `massgen/configs/`
