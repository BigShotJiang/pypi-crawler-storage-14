#!/usr/bin/env python3
import sys
import os

# Add project root to path
sys.path.append(os.getcwd())

try:
    from massgen.config_validator import ConfigValidator
except ImportError:
    print("Error: Could not import MassGen. Run this script from the project root.")
    sys.exit(1)

def validate(config_path):
    print(f"Validating {config_path}...")
    validator = ConfigValidator()
    result = validator.validate_config_file(config_path)
    
    if result.has_errors():
        print(result.format_errors())
        sys.exit(1)
    
    if result.has_warnings():
        print(result.format_warnings())
        
    print("✅ Config is valid!")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python validate_config.py <path_to_config.yaml>")
        sys.exit(1)
    
    validate(sys.argv[1])
