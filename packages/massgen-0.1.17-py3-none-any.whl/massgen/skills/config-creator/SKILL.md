---
name: config-creator
description: Use when creating or validating MassGen configuration files. Provides MassGen-specific config structure, backend types, and validation. Reference this skill for config syntax, backend capabilities, and common patterns.
---

# Config Creator

## Config Structure

```yaml
agents:
  - id: "agent_a"
    backend:
      type: "openai"           # openai, anthropic, google, claude_code, etc.
      model: "gpt-5-mini"
      enable_web_search: true
      enable_code_interpreter: true
    filesystem:
      cwd: "workspace1"        # MUST be unique per agent
    system_message: "..."

  - id: "agent_b"
    backend:
      type: "google"
      model: "gemini-2.0-flash"
    filesystem:
      cwd: "workspace2"        # Different from agent_a

ui:
  display_type: "rich_terminal"
  logging_enabled: true

orchestrator:                  # Optional
  context_paths:
    - path: "docs/"
      permission: "read"

timeout_settings:              # Optional
  orchestrator_timeout_seconds: 600
  agent_timeout_seconds: 180
```

## Backend Types

| Type | Models | Key Features |
|------|--------|--------------|
| `openai` | gpt-5, gpt-5-mini, gpt-5-nano | web_search, code_interpreter, reasoning |
| `anthropic` | claude-sonnet-4-5 | - |
| `claude_code` | claude-sonnet-4-5 | Native filesystem |
| `google` | gemini-2.0-flash, gemini-2.5-pro | web_search, code_execution |
| `grok` | grok-3, grok-3-mini | web_search |

Full capabilities: `massgen/backend/capabilities.py`

## Creating Configs

### Interactive Builder (Recommended)
```bash
uv run python -m massgen.config_builder
```

### Copy Examples
Browse `massgen/configs/`:
- `basic/single/` - Single agent
- `basic/multi/` - Multi-agent
- `tools/` - With tools (filesystem, MCP, code-execution)

## Validation

```bash
uv run python massgen/skills/config-creator/scripts/validate_config.py path/to/config.yaml
```

Or programmatically:
```python
from massgen.config_validator import ConfigValidator
validator = ConfigValidator()
result = validator.validate_config_file("config.yaml")
```

## Critical Rules

1. **Unique workspaces**: Each agent needs different `filesystem.cwd`
2. **Check capabilities**: Verify model supports features in `capabilities.py`
3. **Cost control**: Use gpt-5-nano/mini for simple tasks

## References

- [Config Principles](references/config_principles.md) - Full structure details
- [Validation Guide](references/validation_guide.md) - Common errors
- **Source of truth**: `massgen/backend/capabilities.py`, `massgen/config_validator.py`
