#!/usr/bin/env python
"""
Setup script for the MCP Server package.
"""

from setuptools import setup

# The setup script is a minimal version since we're using pyproject.toml
# This is here for compatibility with older tools
setup() 