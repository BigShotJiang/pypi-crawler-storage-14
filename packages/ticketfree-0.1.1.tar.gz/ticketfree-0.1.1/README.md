# ticketfree

Simple library to check if a user's next ticket is free.
Rule: Every 4th ticket is free.

Usage:

```python
from ticketfree import is_next_ticket_free
print(is_next_ticket_free(3))  # True
