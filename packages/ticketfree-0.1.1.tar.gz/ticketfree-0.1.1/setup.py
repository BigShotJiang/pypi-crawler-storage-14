from setuptools import setup, find_packages

setup(
    name='ticketfree',
    version='0.1.1',
    packages=find_packages(),
    description='A tiny library that checks if the next ticket is free after 3 bookings.',
    author='Himaja Jutur',
    author_email='himaja@example.com',
    license='MIT',
    python_requires='>=3.6',
)
