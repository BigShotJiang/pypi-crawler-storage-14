def is_free_ticket(bookings_count):
    """
    Returns True if the next ticket should be free.
    Rule: Every 4th ticket is free (after 3 paid bookings).
    """
    return (bookings_count + 1) % 4 == 0