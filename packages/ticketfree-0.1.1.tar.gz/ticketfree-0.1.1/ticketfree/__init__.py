from .checker import is_next_ticket_free

__all__ = ["is_next_ticket_free"]
