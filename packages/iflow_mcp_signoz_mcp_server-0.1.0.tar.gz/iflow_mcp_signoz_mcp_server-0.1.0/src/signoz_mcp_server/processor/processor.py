class Processor:
    def get_connection(self):
        pass

    def test_connection(self):
        pass
