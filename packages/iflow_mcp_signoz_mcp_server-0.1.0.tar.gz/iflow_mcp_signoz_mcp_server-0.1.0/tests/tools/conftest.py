import pytest

# Mark all tests in this file as 'tools'
pytestmark = pytest.mark.tools 