"""Python package for the tap-neon CLI."""

from __future__ import annotations
