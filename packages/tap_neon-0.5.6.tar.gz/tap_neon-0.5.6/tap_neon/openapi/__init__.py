"""Module containing the OpenAPI specification for the neon.tech API.

Copyright (c) 2024 Edgar Ramírez-Mondragón
"""
