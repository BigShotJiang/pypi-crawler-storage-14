"""
Core functionality subpackage

Contains the main training and testing modules.
"""

from wszzk.core.train import main as train_main
from wszzk.core.test import main as test_main

__all__ = [
    "train_main",
    "test_main",
]