"""
Pipelines subpackage

Contains all feature engineering and data processing pipelines.
"""

from wszzk.pipelines import (
    day3_features,
    day4_add_pipeline,
    day4_mul_pipeline,
    day7_bins_pipeline,
    day7_rec_pipeline,
    day7_time_pipeline,
    day8_cluster_pipeline,
    day8_cross_pipeline,
    day8_lag_pipeline,
    day8_poly_pipeline,
    day8_ratio_pipeline,
    day11_afford_pipeline,
    day11_behavior_flags_pipeline,
    day11_credit_behavior_pipeline,
    day11_expense_structure_pipeline,
    day11_geo_cohort_pipeline,
    day11_income_stab_pipeline,
    day11_liquidity_shock_pipeline,
    day11_team_features_pipeline,
)

__all__ = [
    "day3_features",
    "day4_add_pipeline",
    "day4_mul_pipeline", 
    "day7_bins_pipeline",
    "day7_rec_pipeline",
    "day7_time_pipeline",
    "day8_cluster_pipeline",
    "day8_cross_pipeline",
    "day8_lag_pipeline",
    "day8_poly_pipeline",
    "day8_ratio_pipeline",
    "day11_afford_pipeline",
    "day11_behavior_flags_pipeline",
    "day11_credit_behavior_pipeline",
    "day11_expense_structure_pipeline",
    "day11_geo_cohort_pipeline",
    "day11_income_stab_pipeline",
    "day11_liquidity_shock_pipeline",
    "day11_team_features_pipeline",
]