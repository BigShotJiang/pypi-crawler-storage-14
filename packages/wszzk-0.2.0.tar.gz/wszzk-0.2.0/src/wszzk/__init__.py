"""
ML Pipeline Toolkit

A comprehensive machine learning pipeline toolkit for feature engineering 
and model training with LightGBM and XGBoost support.
"""

__version__ = "0.2.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# 导入子模块
from . import pipelines
from . import core

__all__ = [
    "pipelines",
    "core", 
    "__version__",
]