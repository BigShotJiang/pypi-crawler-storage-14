"""Custom widgets for Plana Figura Workbench."""

from .dms_entry import DMSEntry

__all__ = [
    'DMSEntry',
]
