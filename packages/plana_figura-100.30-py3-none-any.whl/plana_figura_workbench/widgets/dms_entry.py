"""DMS (Degrees Minutes Seconds) Entry Widget.

Provides a compound entry widget for entering angles in DMS format.
"""

import tkinter as tk
import ttkbootstrap as ttk
from typing import Optional


class DMSEntry(ttk.Frame):
    """
    Entry widget for Degrees, Minutes, Seconds, and Fractional Seconds.
    
    Format: DD° MM' SS.SSSS"
    """
    
    def __init__(self, parent, **kwargs):
        """
        Initialize the DMS Entry widget.
        
        Args:
            parent: Parent widget
            **kwargs: Additional frame arguments
        """
        super().__init__(parent, **kwargs)
        
        # Variables for each component
        self.degrees_var = tk.StringVar(value="0")
        self.minutes_var = tk.StringVar(value="0")
        self.seconds_var = tk.StringVar(value="0")
        self.frac_seconds_var = tk.StringVar(value="0")
        
        self._setup_ui()
    
    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Degrees
        ttk.Entry(
            self,
            textvariable=self.degrees_var,
            width=4,
            justify=tk.RIGHT
        ).pack(side=tk.LEFT, padx=2)
        
        ttk.Label(self, text="°").pack(side=tk.LEFT)
        
        # Minutes
        ttk.Entry(
            self,
            textvariable=self.minutes_var,
            width=3,
            justify=tk.RIGHT
        ).pack(side=tk.LEFT, padx=2)
        
        ttk.Label(self, text="'").pack(side=tk.LEFT)
        
        # Seconds
        ttk.Entry(
            self,
            textvariable=self.seconds_var,
            width=3,
            justify=tk.RIGHT
        ).pack(side=tk.LEFT, padx=2)
        
        ttk.Label(self, text=".").pack(side=tk.LEFT)
        
        # Fractional seconds
        ttk.Entry(
            self,
            textvariable=self.frac_seconds_var,
            width=6,
            justify=tk.LEFT
        ).pack(side=tk.LEFT, padx=2)
        
        ttk.Label(self, text='"').pack(side=tk.LEFT)
    
    def get_decimal_degrees(self) -> float:
        """
        Get the value as decimal degrees.
        
        Returns:
            Angle in decimal degrees
            
        Raises:
            ValueError: If any component is not a valid number
        """
        try:
            degrees = float(self.degrees_var.get())
            minutes = float(self.minutes_var.get())
            seconds = float(self.seconds_var.get())
            frac_seconds = float(self.frac_seconds_var.get())
            
            # Validate ranges
            if minutes < 0 or minutes >= 60:
                raise ValueError("Minutes must be between 0 and 59")
            if seconds < 0 or seconds >= 60:
                raise ValueError("Seconds must be between 0 and 59")
            if frac_seconds < 0 or frac_seconds >= 1:
                raise ValueError("Fractional seconds must be between 0 and 0.9999...")
            
            # Convert to decimal degrees
            total_seconds = seconds + frac_seconds
            decimal_degrees = abs(degrees) + (minutes / 60.0) + (total_seconds / 3600.0)
            
            # Apply sign from degrees
            if degrees < 0:
                decimal_degrees = -decimal_degrees
            
            return decimal_degrees
            
        except ValueError as e:
            raise ValueError(f"Invalid DMS value: {e}")
    
    def set_decimal_degrees(self, decimal_degrees: float) -> None:
        """
        Set the value from decimal degrees.
        
        Args:
            decimal_degrees: Angle in decimal degrees
        """
        # Handle sign
        sign = 1 if decimal_degrees >= 0 else -1
        abs_degrees = abs(decimal_degrees)
        
        # Extract components
        degrees = int(abs_degrees) * sign
        remaining = (abs_degrees - abs(degrees)) * 60
        minutes = int(remaining)
        remaining = (remaining - minutes) * 60
        seconds = int(remaining)
        frac_seconds = remaining - seconds
        
        # Set variables
        self.degrees_var.set(str(degrees))
        self.minutes_var.set(str(minutes))
        self.seconds_var.set(str(seconds))
        self.frac_seconds_var.set(f"{frac_seconds:.7f}".lstrip('0'))
    
    def get_dms_string(self) -> str:
        """
        Get formatted DMS string.
        
        Returns:
            String in format: DD° MM' SS.SSSS"
        """
        try:
            degrees = self.degrees_var.get()
            minutes = self.minutes_var.get()
            seconds = self.seconds_var.get()
            frac_seconds = self.frac_seconds_var.get()
            
            return f"{degrees}° {minutes}' {seconds}.{frac_seconds}\""
        except Exception:
            return "Invalid"
