"""
Plana Figura Workbench - Unified Application.

This is the main application window that integrates all plugins, commands,
actions, and events using ttkbootstrap for modern styling.
"""

from plana_figura_workbench.workbench_controller import WorkbenchController
from plana_figura_workbench.dialogs.geometry_dialogs import (
    PointDialog,
    LineDialog,
    PolylineDialog,
)
from plana_figura_workbench.dialogs.transform_dialogs import (
    TranslateDialog,
    RotateDialog,
    ScaleDialog,
    MirrorDialog,
)
from plana_figura_workbench.events import (
    GeometrySelectedEvent,
    SelectionChangedEvent,
    GeometryAddedEvent,
)
from plana_figura_workbench.actions import WorkbenchActions
from plana_figura_workbench.plugins import GeometryOrganizer, MapView
from plana_figura_workbench.model import PlanaFiguraDocument, DataBucket, DataBucketKeys
from plana_figura_workbench.logging_config import setup_logging, ResourceMonitor
from plana_figura_workbench.error_handling import AutoSaveManager
from plana_figura import (
    Point,
    LineSegment,
    GeometryCollection,
    Geometry,
    GeometryManipulator,
)
from plana_figura.geometry import SurveyorsDirection, Vector2D
from vultus_serpentis.events import EventBus  # type: ignore
from vultus_serpentis.commands import CommandManager  # type: ignore
import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk
import logging
from typing import Optional, List
from pathlib import Path
import sys

# Add Local Packages to path for vultus_serpentis
_local_packages = Path(__file__).parent.parent / "Local Packages" / "vultus_serpentis"
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


class PlanaFiguraWorkbench(ttk.Window):
    """
    Main application window for Plana Figura Workbench.

    This application provides a modern, tabbed interface for geometry
    manipulation with full undo/redo support, event-driven architecture,
    and centralized action management.
    """

    def __init__(self):
        """Initialize the workbench application."""
        # Initialize logging system first
        self.logger_instance = setup_logging()
        self.logger = self.logger_instance.get_logger(__name__)
        self.logger.info("Starting Plana Figura Workbench")
        
        super().__init__(themename="darkly")

        self.title("Plana Figura Workbench")
        self.geometry("1400x900")

        # Initialize error handling components
        self.auto_save_manager = AutoSaveManager()
        self.resource_monitor = ResourceMonitor()
        
        # Core components - Controller handles business logic
        self.event_bus = EventBus.default()
        self.command_manager = CommandManager()
        self.controller = WorkbenchController(self.event_bus, self.command_manager)
        self.actions = WorkbenchActions(event_bus=self.event_bus)
        
        # DataBucket for plugin data sharing
        self.data_bucket = DataBucket()
        
        # Recent files manager
        from plana_figura_workbench.model.recent_files_manager import RecentFilesManager
        self.recent_files = RecentFilesManager(max_files=10)

        # Convenience references (delegate to controller)
        self.document: Optional[PlanaFiguraDocument] = None

        # Setup
        self._setup_actions()
        self._setup_document()
        self._setup_ui()
        self._setup_event_subscriptions()
        self._update_action_states()

        logger.info("Plana Figura Workbench started")

    def _setup_actions(self) -> None:
        """Wire up action commands to methods."""
        self.actions.set_command('new_action', self._on_new_document)
        self.actions.set_command('undo_action', self._on_undo)
        self.actions.set_command('redo_action', self._on_redo)
        self.actions.set_command('select_all_action', self._on_select_all)
        self.actions.set_command('deselect_all_action', self._on_deselect_all)
        # Wire action commands
        self.actions.set_command('create_point_action', self._on_create_point)
        self.actions.set_command('create_line_action', self._on_create_line)
        self.actions.set_command('create_polyline_action', self._on_create_polyline)
        self.actions.set_command('delete_action', self._on_delete)
        self.actions.set_command('duplicate_action', self._on_duplicate)
        self.actions.set_command('edit_properties_action', self._on_edit_properties)
        self.actions.set_command('translate_action', self._on_translate)
        self.actions.set_command('rotate_action', self._on_rotate)
        self.actions.set_command('scale_action', self._on_scale)
        self.actions.set_command('mirror_action', self._on_mirror)
        self.actions.set_command('zoom_in_action', self._on_zoom_in)
        self.actions.set_command('zoom_out_action', self._on_zoom_out)
        self.actions.set_command('zoom_fit_action', self._on_zoom_fit)
        self.actions.set_command('show_grid_action', self._on_toggle_grid)

        # Observe command stack for undo/redo state updates
        self.command_manager.stack.add_observer(self._on_command_stack_changed)

    def _setup_document(self) -> None:
        """Create initial document with sample data."""
        # Check for crash recovery first
        if self.auto_save_manager.check_for_recovery():
            self.logger.info("Recovery file found - checking for crash recovery")
            if self._offer_crash_recovery():
                recovery_file = self.auto_save_manager.load_recovery_file()
                if recovery_file:
                    try:
                        # Load recovery document (implementation depends on document format)
                        self.logger.info(f"Loading recovery file: {recovery_file}")
                        # For now, create sample document - actual recovery loading would go here
                        self.document = self.controller.create_sample_document()
                        self.auto_save_manager.clear_recovery_file()
                    except Exception as e:
                        self.logger.error(f"Failed to load recovery file: {e}")
                        self.document = self.controller.create_sample_document()
                else:
                    self.document = self.controller.create_sample_document()
            else:
                # User declined recovery, clear recovery file and create new document
                self.auto_save_manager.clear_recovery_file()
                self.document = self.controller.create_sample_document()
        else:
            # No recovery file, create normal document
            self.document = self.controller.create_sample_document()
        
        self.controller.set_document(self.document)
        
        # Start auto-save for the document
        self.auto_save_manager.start_auto_save(self.document)
        self.logger.info("Auto-save started")
        
        # Create selection manager
        from plana_figura_workbench.model import SelectionManager
        self.selection_manager = SelectionManager(self.document)
        
        # Populate DataBucket with core data
        self.data_bucket.set(DataBucketKeys.DOCUMENT, self.document, source='workbench')
        self.data_bucket.set(DataBucketKeys.EVENT_BUS, self.event_bus, source='workbench')
        self.data_bucket.set(DataBucketKeys.COMMAND_MANAGER, self.command_manager, source='workbench')
        self.data_bucket.set(DataBucketKeys.SELECTION_MANAGER, self.selection_manager, source='workbench')
        self.data_bucket.set(DataBucketKeys.GEOMETRY_COLLECTIONS, self.document.collections, source='workbench')
        
        # Publish recent files
        self.data_bucket.set('recent_files', self.recent_files.get_files(), source='workbench')
        
        # Observe recent files changes
        self.recent_files.add_observer(self._on_recent_files_changed)

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Create menu bar
        self._create_menu()

        # Create main content area with tabs
        self._create_tabs()

        # Create status bar
        self._create_status_bar()

        # Bind keyboard shortcuts
        self._bind_shortcuts()

    def _create_menu(self) -> None:
        """Create the menu bar."""
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        # File Menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(
            label="New",
            command=self.actions.new_action._command,
            accelerator="Ctrl+N"
        )
        file_menu.add_command(
            label="Open...",
            command=self._on_open_document,
            accelerator="Ctrl+O"
        )
        file_menu.add_command(
            label="Save",
            command=self._on_save_document,
            accelerator="Ctrl+S"
        )
        file_menu.add_command(
            label="Save As...",
            command=self._on_save_document_as,
            accelerator="Ctrl+Shift+S"
        )
        file_menu.add_separator()
        
        # Import submenu
        import_menu = tk.Menu(file_menu, tearoff=0)
        file_menu.add_cascade(label="Import", menu=import_menu)
        import_menu.add_command(
            label="DXF File...",
            command=self._on_import_dxf,
            accelerator="Ctrl+I"
        )
        import_menu.add_command(
            label="Single Line Plain Text...",
            command=self._on_import_slpt
        )
        import_menu.add_separator()
        import_menu.add_command(
            label="Layer Properties (XML)...",
            command=self._on_import_layer_xml
        )
        
        # Export submenu
        export_menu = tk.Menu(file_menu, tearoff=0)
        file_menu.add_cascade(label="Export", menu=export_menu)
        export_menu.add_command(
            label="DXF File...",
            command=self._on_export_dxf,
            accelerator="Ctrl+E"
        )
        export_menu.add_command(
            label="Single Line Plain Text...",
            command=self._on_export_slpt
        )
        export_menu.add_separator()
        export_menu.add_command(
            label="Layer Properties (XML)...",
            command=self._on_export_layer_xml
        )
        
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)

        # Geometry Menu
        geometry_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Geometry", menu=geometry_menu)
        geometry_menu.add_command(
            label="Create Point...",
            command=self.actions.create_point_action._command
        )
        geometry_menu.add_command(
            label="Create Line...",
            command=self.actions.create_line_action._command
        )
        geometry_menu.add_command(
            label="Create Polyline...",
            command=self.actions.create_polyline_action._command
        )
        geometry_menu.add_separator()
        geometry_menu.add_command(
            label="Delete",
            command=self.actions.delete_action._command,
            accelerator="Delete"
        )
        geometry_menu.add_command(
            label="Duplicate",
            command=self.actions.duplicate_action._command,
            accelerator="Ctrl+D"
        )
        geometry_menu.add_command(
            label="Properties...",
            command=self.actions.edit_properties_action._command,
            accelerator="Alt+Enter"
        )

        # Edit Menu
        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        edit_menu.add_command(
            label="Undo",
            command=self.actions.undo_action._command,
            accelerator="Ctrl+Z"
        )
        edit_menu.add_command(
            label="Redo",
            command=self.actions.redo_action._command,
            accelerator="Ctrl+Y"
        )
        edit_menu.add_separator()
        edit_menu.add_command(
            label="Select All",
            command=self.actions.select_all_action._command,
            accelerator="Ctrl+A"
        )
        edit_menu.add_command(
            label="Deselect All",
            command=self.actions.deselect_all_action._command,
            accelerator="Escape"
        )

        # Transform Menu
        transform_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Transform", menu=transform_menu)
        transform_menu.add_command(
            label="Translate...",
            command=self.actions.translate_action._command
        )
        transform_menu.add_command(
            label="Rotate...",
            command=self.actions.rotate_action._command
        )
        transform_menu.add_command(
            label="Scale...",
            command=self.actions.scale_action._command
        )
        transform_menu.add_command(
            label="Mirror...",
            command=self.actions.mirror_action._command
        )

        # Measurements Menu
        measurements_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Measurements", menu=measurements_menu)
        
        # Add Measurement submenu
        add_measurement_menu = tk.Menu(measurements_menu, tearoff=0)
        measurements_menu.add_cascade(label="Add Measurement", menu=add_measurement_menu)
        add_measurement_menu.add_command(
            label="Horizontal Angle...",
            command=self._add_horizontal_angle,
            accelerator="Ctrl+Shift+H"
        )
        add_measurement_menu.add_command(
            label="Vertical Angle...",
            command=self._add_vertical_angle,
            accelerator="Ctrl+Shift+V"
        )
        add_measurement_menu.add_command(
            label="Zenith Angle...",
            command=self._add_zenith_angle,
            accelerator="Ctrl+Shift+Z"
        )
        add_measurement_menu.add_separator()
        add_measurement_menu.add_command(
            label="Direction/Azimuth...",
            command=self._add_azimuth,
            accelerator="Ctrl+Shift+A"
        )
        add_measurement_menu.add_command(
            label="Bearing...",
            command=self._add_bearing,
            accelerator="Ctrl+Shift+B"
        )
        add_measurement_menu.add_separator()
        add_measurement_menu.add_command(
            label="Distance...",
            command=self._add_distance,
            accelerator="Ctrl+Shift+D"
        )
        add_measurement_menu.add_command(
            label="3D Vector...",
            command=self._add_vector,
            accelerator="Ctrl+Shift+3"
        )
        
        measurements_menu.add_separator()
        measurements_menu.add_command(
            label="Show Measurement Manager",
            command=self._show_measurement_manager,
            accelerator="Ctrl+M"
        )

        # View Menu
        view_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="View", menu=view_menu)
        view_menu.add_command(
            label="Zoom In",
            command=self.actions.zoom_in_action._command,
            accelerator="Ctrl++"
        )
        view_menu.add_command(
            label="Zoom Out",
            command=self.actions.zoom_out_action._command,
            accelerator="Ctrl+-"
        )
        view_menu.add_command(
            label="Zoom Fit",
            command=self.actions.zoom_fit_action._command,
            accelerator="Ctrl+0"
        )
        view_menu.add_separator()
        view_menu.add_checkbutton(
            label="Show Grid",
            command=self.actions.show_grid_action._command
        )

        # Help Menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self._show_about)

    def _create_tabs(self) -> None:
        """Create the tabbed interface with plugins."""
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self, bootstyle="dark")
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Tab 1: Map View
        map_frame = ttk.Frame(self.notebook)
        self.map_view = MapView(
            map_frame, 
            self.document, 
            self.event_bus,
            data_bucket=self.data_bucket
        )
        self.map_view.pack(fill=tk.BOTH, expand=True)
        self.notebook.add(map_frame, text="Map View")

        # Tab 2: Geometry Organizer
        organizer_frame = ttk.Frame(self.notebook)
        self.organizer = GeometryOrganizer(
            organizer_frame, 
            self.document, 
            self.event_bus,
            self.selection_manager,
            data_bucket=self.data_bucket
        )
        self.organizer.pack(fill=tk.BOTH, expand=True)
        self.notebook.add(organizer_frame, text="Geometry Organizer")

        # Tab 3: Geometry Manipulator
        from plana_figura_workbench.plugins import GeometryManipulator
        
        manipulator_frame = ttk.Frame(self.notebook)
        self.geometry_manipulator = GeometryManipulator(
            manipulator_frame,
            self.document,
            self.event_bus,
            self.command_manager,
            self.selection_manager,
            data_bucket=self.data_bucket
        )
        self.geometry_manipulator.pack(fill=tk.BOTH, expand=True)
        self.notebook.add(manipulator_frame, text="Geometry Manipulator")

        # Tab 4: Geometry Operations (placeholder)
        operations_frame = ttk.Frame(self.notebook)
        ttk.Label(
            operations_frame,
            text="Geometry Operations\n\nComing in Phase 5B",
            font=("Segoe UI", 16),
            bootstyle="secondary"
        ).pack(expand=True)
        self.notebook.add(operations_frame, text="Geometry Operations")

        # Tab 5: Grid Editor
        from plana_figura_workbench.plugins import GridEditor
        
        grid_frame = ttk.Frame(self.notebook)
        self.grid_editor = GridEditor(
            grid_frame,
            document=self.document,
            data_bucket=self.data_bucket,
            event_bus=self.event_bus
        )
        self.grid_editor.pack(fill=tk.BOTH, expand=True)
        self.notebook.add(grid_frame, text="Grid Editor")
        
        # Tab 6: Measurement Manager
        from plana_figura_workbench.plugins.measurement_manager import MeasurementManager
        measurement_frame = ttk.Frame(self.notebook)
        self.measurement_manager = MeasurementManager(
            measurement_frame,
            self.document,
            self.event_bus,
            self.command_manager
        )
        self.measurement_manager.pack(fill=tk.BOTH, expand=True)
        self.notebook.add(measurement_frame, text="Measurement Manager")

    def _create_status_bar(self) -> None:
        """Create the status bar."""
        self.status_bar = ttk.Frame(self, bootstyle="secondary")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Status label
        self.status_label = ttk.Label(
            self.status_bar,
            text="Ready",
            bootstyle="inverse-secondary"
        )
        self.status_label.pack(side=tk.LEFT, padx=5, pady=2)

        # Geometry count label
        self.geometry_count_label = ttk.Label(
            self.status_bar,
            text="0 geometries",
            bootstyle="inverse-secondary"
        )
        self.geometry_count_label.pack(side=tk.RIGHT, padx=5, pady=2)

        self._update_status_bar()

    def _bind_shortcuts(self) -> None:
        """Bind keyboard shortcuts."""
        self.bind("<Control-n>", lambda e: self._on_new_document())
        self.bind("<Control-i>", lambda e: self._on_import_dxf())
        self.bind("<Control-e>", lambda e: self._on_export_dxf())
        self.bind("<Control-z>", lambda e: self._on_undo())
        self.bind("<Control-y>", lambda e: self._on_redo())
        self.bind("<Control-a>", lambda e: self._on_select_all())
        self.bind("<Escape>", lambda e: self._on_deselect_all())
        self.bind("<Delete>", lambda e: self._on_delete())
        self.bind("<Control-d>", lambda e: self._on_duplicate())
        self.bind("<Alt-Return>", lambda e: self._on_edit_properties())
        self.bind("<Control-plus>", lambda e: self._on_zoom_in())
        self.bind("<Control-minus>", lambda e: self._on_zoom_out())
        self.bind("<Control-0>", lambda e: self._on_zoom_fit())
        
        # Measurement shortcuts
        self.bind("<Control-Shift-H>", lambda e: self._add_horizontal_angle())
        self.bind("<Control-Shift-V>", lambda e: self._add_vertical_angle())
        self.bind("<Control-Shift-Z>", lambda e: self._add_zenith_angle())
        self.bind("<Control-Shift-A>", lambda e: self._add_azimuth())
        self.bind("<Control-Shift-B>", lambda e: self._add_bearing())
        self.bind("<Control-Shift-D>", lambda e: self._add_distance())
        self.bind("<Control-Shift-Key-3>", lambda e: self._add_vector())
        self.bind("<Control-m>", lambda e: self._show_measurement_manager())

    def _setup_event_subscriptions(self) -> None:
        """Subscribe to EventBus events."""
        self.event_bus.subscribe(GeometrySelectedEvent, self._on_geometry_selected)
        self.event_bus.subscribe(SelectionChangedEvent, self._on_selection_changed)

    # Event Handlers

    def _on_geometry_selected(self, event: GeometrySelectedEvent) -> None:
        """Handle geometry selection event."""
        # Controller manages selection state
        self._update_action_states()
        self._update_status_bar()

    def _on_selection_changed(self, event: SelectionChangedEvent) -> None:
        """Handle selection changed event."""
        has_selection = len(event.selected_geometries) > 0
        self.actions.update_selection_actions(has_selection)
        self._update_status_bar()

    def _on_command_stack_changed(self) -> None:
        """Handle command stack changes (for undo/redo)."""
        can_undo, can_redo = self.controller.get_undo_redo_state()
        self.actions.update_undo_redo_actions(
            can_undo=can_undo,
            can_redo=can_redo
        )
        
        # Publish undo/redo state to DataBucket
        self.data_bucket.set('undo_available', can_undo, source='workbench')
        self.data_bucket.set('redo_available', can_redo, source='workbench')
    
    def _on_recent_files_changed(self, recent_files_manager) -> None:
        """Handle recent files changes."""
        # Publish updated recent files to DataBucket
        self.data_bucket.set('recent_files', recent_files_manager.get_files(), source='workbench')
        logger.debug(f"Recent files updated: {len(recent_files_manager)} files")

    # Action Handlers

    def _on_new_document(self) -> None:
        """Create a new document."""
        logger.info("New document requested")
        messagebox.showinfo("New Document", "New document feature coming soon!")

    def _on_open_document(self) -> None:
        """Open a document from file."""
        from tkinter import filedialog
        import pickle
        
        logger.info("Open document requested")
        
        filename = filedialog.askopenfilename(
            title="Open Document",
            filetypes=[
                ("Plana Figura Document", "*.pfd"),
                ("Pickle files", "*.pkl"),
                ("All files", "*.*")
            ],
            parent=self
        )
        
        if filename:
            try:
                with open(filename, 'rb') as f:
                    self.document = pickle.load(f)
                
                # Update UI
                self.organizer.document = self.document
                self.map_view.controller.document = self.document
                self.map_view.controller.refresh()
                
                self._current_file = Path(filename)
                self.title(f"Plana Figura - {self._current_file.name}")
                
                messagebox.showinfo(
                    "Document Opened",
                    f"Opened document from {self._current_file.name}",
                    parent=self
                )
                self._update_status_bar(f"Opened {self._current_file.name}")
                
            except Exception as e:
                logger.error(f"Error opening document: {e}", exc_info=True)
                messagebox.showerror(
                    "Open Error",
                    f"Failed to open document:\n{str(e)}",
                    parent=self
                )

    def _on_save_document(self) -> None:
        """Save the current document."""
        if hasattr(self, '_current_file') and self._current_file:
            self._save_to_file(self._current_file)
        else:
            self._on_save_document_as()

    def _on_save_document_as(self) -> None:
        """Save the current document to a new file."""
        from tkinter import filedialog
        import pickle
        
        logger.info("Save document as requested")
        
        filename = filedialog.asksaveasfilename(
            title="Save Document As",
            defaultextension=".pfd",
            filetypes=[
                ("Plana Figura Document", "*.pfd"),
                ("Pickle files", "*.pkl"),
                ("All files", "*.*")
            ],
            parent=self
        )
        
        if filename:
            self._current_file = Path(filename)
            self._save_to_file(self._current_file)

    def _save_to_file(self, filepath: Path) -> None:
        """Save document to specified file."""
        import pickle
        
        try:
            with open(filepath, 'wb') as f:
                pickle.dump(self.document, f)
            
            self.title(f"Plana Figura - {filepath.name}")
            
            messagebox.showinfo(
                "Document Saved",
                f"Saved document to {filepath.name}",
                parent=self
            )
            self._update_status_bar(f"Saved to {filepath.name}")
            
        except Exception as e:
            logger.error(f"Error saving document: {e}", exc_info=True)
            messagebox.showerror(
                "Save Error",
                f"Failed to save document:\n{str(e)}",
                parent=self
            )

    def _on_import_dxf(self) -> None:
        """Import geometries from a DXF file."""
        from plana_figura_workbench.dialogs import ImportDXFDialog
        from plana_figura_workbench.io.dxf import DXFReader
        
        logger.info("Import DXF requested")
        
        # Show import dialog
        dialog = ImportDXFDialog(self)
        result = dialog.show()
        
        if result:
            try:
                # Create reader with config
                reader = DXFReader(result['config'])
                
                # Get or create Imports folder
                imports_folder = self.document.geometry_folder_manager.find_folder("Imports")
                
                # Read file
                if result['layers']:
                    # Import specific layers
                    layer_collections = reader.read_all_layers(result['file'])
                    
                    # Add each layer as a collection to Imports folder
                    for layer_name, collection in layer_collections.items():
                        if layer_name in result['layers']:
                            # Use custom collection name if provided
                            if len(result['layers']) == 1:
                                collection.name = result['collection_name']
                            else:
                                collection.name = f"{result['collection_name']} - {layer_name}"
                            self.document.add_collection(collection, set_active=False)
                            
                            # Add to Imports folder
                            if imports_folder:
                                imports_folder.add_collection(collection)
                    
                    total_geometries = sum(c.count for c in layer_collections.values() if c.name.split(' - ')[-1] in result['layers'])
                    messagebox.showinfo(
                        "Import Successful",
                        f"Imported {total_geometries} geometries from {len(result['layers'])} layer(s).",
                        parent=self
                    )
                else:
                    # Import all geometries
                    collection = reader.read_file(result['file'])
                    collection.name = result['collection_name']
                    self.document.add_collection(collection, set_active=True)
                    
                    # Add to Imports folder
                    if imports_folder:
                        imports_folder.add_collection(collection)
                    
                    messagebox.showinfo(
                        "Import Successful",
                        f"Imported {collection.count} geometries.",
                        parent=self
                    )
                
                # Get import stats
                stats = reader.get_import_stats()
                logger.info(f"Import stats: {stats}")
                
                self._update_status_bar(f"Imported from {result['file'].name}")
                
            except Exception as e:
                logger.error(f"Error importing DXF file: {e}", exc_info=True)
                messagebox.showerror(
                    "Import Error",
                    f"Failed to import DXF file:\n{str(e)}",
                    parent=self
                )

    def _on_export_dxf(self) -> None:
        """Export geometries to a DXF file."""
        from plana_figura_workbench.dialogs import ExportDXFDialog
        from plana_figura_workbench.io.dxf import DXFWriter
        
        logger.info("Export DXF requested")
        
        # Check if there are geometries to export
        if not self.document.collections or all(c.count == 0 for c in self.document.collections):
            messagebox.showwarning(
                "No Geometries",
                "There are no geometries to export.",
                parent=self
            )
            return
        
        # Show export dialog
        dialog = ExportDXFDialog(self, self.document)
        result = dialog.show()
        
        if result:
            try:
                # Create writer with config
                writer = DXFWriter(result['config'])
                
                if result['export_as_layers'] and len(result['collections']) > 1:
                    # Export as multiple layers
                    layer_dict = {}
                    for idx, collection in enumerate(result['collections']):
                        # Get collection name for layer
                        if hasattr(collection, 'name') and collection.name:
                            layer_name = collection.name
                        else:
                            layer_name = f"Collection_{idx + 1}"
                        layer_dict[layer_name] = collection
                    
                    writer.write_with_layers(layer_dict, result['file'])
                    total_geometries = sum(c.count for c in result['collections'])
                    
                    messagebox.showinfo(
                        "Export Successful",
                        f"Exported {total_geometries} geometries to {len(result['collections'])} layer(s).",
                        parent=self
                    )
                else:
                    # Export to single layer
                    # Merge all selected collections
                    from plana_figura import GeometryCollection
                    merged = GeometryCollection()
                    for collection in result['collections']:
                        for geometry in collection.geometries:
                            merged.add(geometry)
                    
                    writer.write_file(merged, result['file'])
                    
                    messagebox.showinfo(
                        "Export Successful",
                        f"Exported {merged.count} geometries.",
                        parent=self
                    )
                
                # Get export stats
                stats = writer.get_export_stats()
                logger.info(f"Export stats: {stats}")
                
                self._update_status_bar(f"Exported to {result['file'].name}")
                
            except Exception as e:
                logger.error(f"Error exporting DXF file: {e}", exc_info=True)
                messagebox.showerror(
                    "Export Error",
                    f"Failed to export DXF file:\n{str(e)}",
                    parent=self
                )

    def _on_import_slpt(self) -> None:
        """Import geometries from Single Line Plain Text format."""
        from tkinter import filedialog
        logger.info("Import SLPT requested")
        
        filename = filedialog.askopenfilename(
            title="Import Single Line Plain Text",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            parent=self
        )
        
        if filename:
            try:
                from plana_figura.io import SLPTFReader
                reader = SLPTFReader(filename)
                geometries = reader.read_geometries()
                
                # Add to document
                from plana_figura import GeometryCollection
                collection = GeometryCollection(geometries)
                collection.name = f"Imported from {Path(filename).name}"
                self.document.add_collection(collection)
                
                messagebox.showinfo(
                    "Import Successful",
                    f"Imported {len(geometries)} geometries.",
                    parent=self
                )
                self._update_status_bar(f"Imported {len(geometries)} geometries from SLPT")
                
            except Exception as e:
                logger.error(f"Error importing SLPT file: {e}", exc_info=True)
                messagebox.showerror(
                    "Import Error",
                    f"Failed to import SLPT file:\n{str(e)}",
                    parent=self
                )

    def _on_export_slpt(self) -> None:
        """Export geometries to Single Line Plain Text format."""
        from tkinter import filedialog
        logger.info("Export SLPT requested")
        
        # Check if there are geometries to export
        if not self.document.collections or all(c.count == 0 for c in self.document.collections):
            messagebox.showwarning(
                "No Geometries",
                "There are no geometries to export.",
                parent=self
            )
            return
        
        filename = filedialog.asksaveasfilename(
            title="Export Single Line Plain Text",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            parent=self
        )
        
        if filename:
            try:
                from plana_figura.io import SLPTFWriter
                from plana_figura import GeometryCollection
                
                # Merge all collections
                merged = GeometryCollection()
                for collection in self.document.collections:
                    for geometry in collection.geometries:
                        merged.add(geometry)
                
                writer = SLPTFWriter(filename)
                writer.write_geometries(list(merged.geometries))
                
                messagebox.showinfo(
                    "Export Successful",
                    f"Exported {merged.count} geometries.",
                    parent=self
                )
                self._update_status_bar(f"Exported to {Path(filename).name}")
                
            except Exception as e:
                logger.error(f"Error exporting SLPT file: {e}", exc_info=True)
                messagebox.showerror(
                    "Export Error",
                    f"Failed to export SLPT file:\n{str(e)}",
                    parent=self
                )

    def _on_import_layer_xml(self) -> None:
        """Import layer properties from XML file."""
        from tkinter import filedialog
        logger.info("Import Layer XML requested")
        
        filename = filedialog.askopenfilename(
            title="Import Layer Properties",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")],
            parent=self
        )
        
        if filename:
            try:
                # Import layer properties and apply to matching layers
                from plana_figura_workbench.plugins.map_view.utilities.layer_io import load_layers_from_xml
                layers = load_layers_from_xml(filename)
                
                # Apply to map view if available
                if hasattr(self, 'map_view') and self.map_view:
                    applied_count = 0
                    for imported_layer in layers:
                        # Find matching layer in map view
                        for existing_layer in self.map_view.model.layers:
                            if existing_layer.name == imported_layer.name:
                                # Apply properties
                                existing_layer.style = imported_layer.style
                                existing_layer.visible = imported_layer.visible
                                applied_count += 1
                                break
                    
                    self.map_view.controller.refresh()
                    
                    messagebox.showinfo(
                        "Import Successful",
                        f"Applied properties to {applied_count} matching layer(s).",
                        parent=self
                    )
                    self._update_status_bar(f"Imported layer properties from {Path(filename).name}")
                else:
                    messagebox.showwarning(
                        "Map View Not Available",
                        "Map View is not initialized.",
                        parent=self
                    )
                
            except Exception as e:
                logger.error(f"Error importing layer XML: {e}", exc_info=True)
                messagebox.showerror(
                    "Import Error",
                    f"Failed to import layer properties:\n{str(e)}",
                    parent=self
                )

    def _on_export_layer_xml(self) -> None:
        """Export layer properties to XML file."""
        from tkinter import filedialog
        logger.info("Export Layer XML requested")
        
        if not hasattr(self, 'map_view') or not self.map_view:
            messagebox.showwarning(
                "Map View Not Available",
                "Map View is not initialized.",
                parent=self
            )
            return
        
        if not self.map_view.model.layers:
            messagebox.showwarning(
                "No Layers",
                "There are no layers to export.",
                parent=self
            )
            return
        
        filename = filedialog.asksaveasfilename(
            title="Export Layer Properties",
            defaultextension=".xml",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")],
            parent=self
        )
        
        if filename:
            try:
                from plana_figura_workbench.plugins.map_view.utilities.layer_io import save_layers_to_xml
                save_layers_to_xml(self.map_view.model.layers, filename)
                
                messagebox.showinfo(
                    "Export Successful",
                    f"Exported {len(self.map_view.model.layers)} layer(s).",
                    parent=self
                )
                self._update_status_bar(f"Exported layer properties to {Path(filename).name}")
                
            except Exception as e:
                logger.error(f"Error exporting layer XML: {e}", exc_info=True)
                messagebox.showerror(
                    "Export Error",
                    f"Failed to export layer properties:\n{str(e)}",
                    parent=self
                )

    def _on_undo(self) -> None:
        """Undo last command."""
        if self.controller.undo():
            self._update_status_bar("Undo successful")

    def _on_redo(self) -> None:
        """Redo last undone command."""
        if self.controller.redo():
            self._update_status_bar("Redo successful")

    def _on_select_all(self) -> None:
        """Select all geometries."""
        logger.info("Select all requested")
        messagebox.showinfo("Select All", "Select all feature coming soon!")

    def _on_deselect_all(self) -> None:
        """Deselect all geometries."""
        self.controller.select_geometry(None, source="main_app")
        self._update_status_bar("Selection cleared")

    def _on_create_point(self) -> None:
        """Open create point dialog."""
        dialog = PointDialog(self, title="Create Point")
        dialog.wait_window()

        if dialog.result:
            if self.controller.create_point(dialog.result):
                self._update_status_bar("Point created")
            else:
                messagebox.showerror("Error", "Failed to create point")

    def _on_create_line(self) -> None:
        """Open create line dialog."""
        dialog = LineDialog(self, title="Create Line")
        dialog.wait_window()

        if dialog.result:
            if self.controller.create_line(dialog.result):
                self._update_status_bar("Line created")
            else:
                messagebox.showerror("Error", "Failed to create line")

    def _on_create_polyline(self) -> None:
        """Open create polyline dialog."""
        dialog = PolylineDialog(self, title="Create Polyline")
        dialog.wait_window()

        if dialog.result:
            if self.controller.create_polyline(dialog.result):
                self._update_status_bar("Polyline created")
            else:
                messagebox.showerror("Error", "Failed to create polyline")

    def _on_delete(self) -> None:
        """Delete selected geometry."""
        if self.controller.has_selection():
            geom_type = type(self.controller.selected_geometry).__name__

            if messagebox.askyesno("Confirm Delete", f"Delete {geom_type}?"):
                if self.controller.delete_geometry(self.controller.selected_geometry):
                    self._update_status_bar(f"{geom_type} deleted")
                else:
                    messagebox.showerror("Error", "Failed to delete geometry")

    def _on_duplicate(self) -> None:
        """Duplicate selected geometry."""
        if self.controller.has_selection():
            geom_type = type(self.controller.selected_geometry).__name__
            logger.info(f"Duplicate requested for {geom_type}")
            messagebox.showinfo("Duplicate", "Duplicate feature coming soon!")

    def _on_edit_properties(self) -> None:
        """Open properties editor."""
        if self.controller.has_selection():
            geom_type = type(self.controller.selected_geometry).__name__
            logger.info(f"Edit properties requested for {geom_type}")
            messagebox.showinfo("Properties", "Properties dialog coming in Phase 5C!")

    def _on_translate(self) -> None:
        """Open translate dialog."""
        if not self.controller.has_selection():
            return
        
        dialog = TranslateDialog(self, title="Translate Geometry")
        dialog.wait_window()
        
        if dialog.result:
            dn, de, dz = dialog.result
            geometry = self.controller.selected_geometry
            
            try:
                # Create translation vector from deltas
                # Vector needs direction and distance, so calculate from deltas
                import math
                distance = math.sqrt(de**2 + dn**2)
                if distance == 0:
                    # Only elevation change
                    if isinstance(geometry, Point):
                        new_geometry = Point(
                            geometry.northing,
                            geometry.easting,
                            geometry.elevation + dz
                        )
                    else:
                        messagebox.showinfo("Info", "Only elevation change not supported for this geometry type")
                        return
                else:
                    # Calculate direction from deltas
                    angle_rad = math.atan2(de, dn)  # atan2(easting, northing) for surveying
                    direction = SurveyorsDirection(angle_rad)
                    vector = Vector(direction, distance)
                    
                    # Translate the geometry
                    new_geometry = GeometryManipulator.translate(geometry, vector)
                    
                    # Handle elevation change if needed
                    if dz != 0 and isinstance(new_geometry, Point):
                        new_geometry = Point(
                            new_geometry.northing,
                            new_geometry.easting,
                            new_geometry.elevation + dz
                        )
                
                # Delete old, add new (via commands for undo/redo)
                if self.controller.delete_geometry(geometry):
                    if self.controller.create_geometry(new_geometry):
                        self._update_status_bar(f"Translated by Δ N={dn}, Δ E={de}, Δ Z={dz}")
                    else:
                        messagebox.showerror("Error", "Failed to add translated geometry")
                else:
                    messagebox.showerror("Error", "Failed to delete original geometry")
            except Exception as e:
                logger.error(f"Translation failed: {e}")
                messagebox.showerror("Error", f"Translation failed: {e}")

    def _on_rotate(self) -> None:
        """Open rotate dialog."""
        if not self.controller.has_selection():
            return
        
        dialog = RotateDialog(self, title="Rotate Geometry")
        dialog.wait_window()
        
        if dialog.result:
            (center_n, center_e), angle_decimal = dialog.result
            geometry = self.controller.selected_geometry
            
            # Create center point and angle
            center = Point(center_n, center_e, 0)
            # Convert decimal degrees to radians for SurveyorsDirection
            import math
            angle_radians = math.radians(angle_decimal)
            direction = SurveyorsDirection(angle_radians)
            
            try:
                # Rotate the geometry based on type
                if isinstance(geometry, Point):
                    new_geometry = GeometryManipulator.rotate_point(geometry, direction, center)
                elif isinstance(geometry, LineSegment):
                    new_geometry = GeometryManipulator.rotate_line_segment(geometry, direction, center)
                else:
                    # Try generic rotate if available
                    new_geometry = GeometryManipulator.rotate_polyline(geometry, direction, center)
                
                # Delete old, add new (via commands for undo/redo)
                if self.controller.delete_geometry(geometry):
                    if self.controller.create_geometry(new_geometry):
                        self._update_status_bar(f"Rotated {angle_decimal:.2f}° around ({center_n}, {center_e})")
                    else:
                        messagebox.showerror("Error", "Failed to add rotated geometry")
                else:
                    messagebox.showerror("Error", "Failed to delete original geometry")
            except Exception as e:
                logger.error(f"Rotation failed: {e}")
                messagebox.showerror("Error", f"Rotation failed: {e}")

    def _on_scale(self) -> None:
        """Open scale dialog."""
        if not self.controller.has_selection():
            return
        
        dialog = ScaleDialog(self, title="Scale Geometry")
        dialog.wait_window()
        
        if dialog.result:
            (center_n, center_e), scale_factor = dialog.result
            geometry = self.controller.selected_geometry
            
            # Create center point
            center = Point(center_n, center_e, 0)
            
            try:
                # Scale the geometry based on type
                if isinstance(geometry, Point):
                    new_geometry = GeometryManipulator.scale_point(geometry, scale_factor, center)
                elif isinstance(geometry, LineSegment):
                    new_geometry = GeometryManipulator.scale_line_segment(geometry, scale_factor, center)
                else:
                    # Try polyline
                    new_geometry = GeometryManipulator.scale_polyline(geometry, scale_factor, center)
                
                # Delete old, add new (via commands for undo/redo)
                if self.controller.delete_geometry(geometry):
                    if self.controller.create_geometry(new_geometry):
                        self._update_status_bar(f"Scaled by {scale_factor}x from ({center_n}, {center_e})")
                    else:
                        messagebox.showerror("Error", "Failed to add scaled geometry")
                else:
                    messagebox.showerror("Error", "Failed to delete original geometry")
            except Exception as e:
                logger.error(f"Scaling failed: {e}")
                messagebox.showerror("Error", f"Scaling failed: {e}")

    def _on_mirror(self) -> None:
        """Open mirror dialog."""
        if not self.controller.has_selection():
            return
        
        dialog = MirrorDialog(self, title="Mirror Geometry")
        dialog.wait_window()
        
        if dialog.result:
            (p1_n, p1_e), (p2_n, p2_e) = dialog.result
            geometry = self.controller.selected_geometry
            
            # Create mirror line from two points
            point1 = Point(p1_n, p1_e, 0)
            point2 = Point(p2_n, p2_e, 0)
            mirror_line = LineSegment(point1, point2)
            
            try:
                # Mirror the geometry based on type
                if isinstance(geometry, Point):
                    new_geometry = GeometryManipulator.mirror_point_across_line(geometry, mirror_line)
                elif isinstance(geometry, LineSegment):
                    new_geometry = GeometryManipulator.mirror_line_segment_across_line(geometry, mirror_line)
                else:
                    # Try polyline
                    new_geometry = GeometryManipulator.mirror_polyline_across_line(geometry, mirror_line)
                
                # Delete old, add new (via commands for undo/redo)
                if self.controller.delete_geometry(geometry):
                    if self.controller.create_geometry(new_geometry):
                        self._update_status_bar(f"Mirrored across line from ({p1_n}, {p1_e}) to ({p2_n}, {p2_e})")
                    else:
                        messagebox.showerror("Error", "Failed to add mirrored geometry")
                else:
                    messagebox.showerror("Error", "Failed to delete original geometry")
            except Exception as e:
                logger.error(f"Mirroring failed: {e}")
                messagebox.showerror("Error", f"Mirroring failed: {e}")

    def _on_zoom_in(self) -> None:
        """Zoom in map view."""
        logger.info("Zoom in requested")
        # Will be implemented when map view is updated

    def _on_zoom_out(self) -> None:
        """Zoom out map view."""
        logger.info("Zoom out requested")
        # Will be implemented when map view is updated

    def _on_zoom_fit(self) -> None:
        """Fit all geometry in map view."""
        logger.info("Zoom fit requested")
        # Will be implemented when map view is updated

    def _on_toggle_grid(self) -> None:
        """Toggle grid display."""
        logger.info("Toggle grid requested")
        # Will be implemented when map view is updated

    # UI Update Methods

    def _update_action_states(self) -> None:
        """Update action enabled states based on current state."""
        has_selection = self.controller.has_selection()
        self.actions.update_selection_actions(has_selection)

    def _update_status_bar(self, message: Optional[str] = None) -> None:
        """Update status bar text."""
        if message:
            self.status_label.config(text=message)
        else:
            # Delegate to controller
            self.status_label.config(text=self.controller.get_status_message())

        # Update geometry count
        self.geometry_count_label.config(
            text=self.controller.get_geometry_count_message()
        )

    # Measurement Menu Methods
    
    def _add_horizontal_angle(self) -> None:
        """Add a horizontal angle measurement."""
        from plana_figura_workbench.dialogs import AddAngleDialog
        from plana_figura import MeasurementType
        
        dialog = AddAngleDialog(self, measurement_type=MeasurementType.HORIZONTAL_ANGLE)
        self.wait_window(dialog)
        
        if dialog.result:
            collection_name = self.document.active_measurement_collection
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                self.command_manager.execute(cmd)
                self._update_status_bar(f"Added horizontal angle: {dialog.result.name}")
    
    def _add_vertical_angle(self) -> None:
        """Add a vertical angle measurement."""
        from plana_figura_workbench.dialogs import AddAngleDialog
        from plana_figura import MeasurementType
        
        dialog = AddAngleDialog(self, measurement_type=MeasurementType.VERTICAL_ANGLE)
        self.wait_window(dialog)
        
        if dialog.result:
            collection_name = self.document.active_measurement_collection
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                self.command_manager.execute(cmd)
                self._update_status_bar(f"Added vertical angle: {dialog.result.name}")
    
    def _add_zenith_angle(self) -> None:
        """Add a zenith angle measurement."""
        from plana_figura_workbench.dialogs import AddAngleDialog
        from plana_figura import MeasurementType
        
        dialog = AddAngleDialog(self, measurement_type=MeasurementType.ZENITH_ANGLE)
        self.wait_window(dialog)
        
        if dialog.result:
            collection_name = self.document.active_measurement_collection
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                self.command_manager.execute(cmd)
                self._update_status_bar(f"Added zenith angle: {dialog.result.name}")
    
    def _add_azimuth(self) -> None:
        """Add an azimuth measurement."""
        from plana_figura_workbench.dialogs import AddDirectionDialog
        from plana_figura import MeasurementType
        
        dialog = AddDirectionDialog(self, measurement_type=MeasurementType.AZIMUTH)
        self.wait_window(dialog)
        
        if dialog.result:
            collection_name = self.document.active_measurement_collection
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                self.command_manager.execute(cmd)
                self._update_status_bar(f"Added azimuth: {dialog.result.name}")
    
    def _add_bearing(self) -> None:
        """Add a bearing measurement."""
        from plana_figura_workbench.dialogs import AddDirectionDialog
        from plana_figura import MeasurementType
        
        dialog = AddDirectionDialog(self, measurement_type=MeasurementType.BEARING)
        self.wait_window(dialog)
        
        if dialog.result:
            collection_name = self.document.active_measurement_collection
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                self.command_manager.execute(cmd)
                self._update_status_bar(f"Added bearing: {dialog.result.name}")
    
    def _add_distance(self) -> None:
        """Add a distance measurement."""
        from plana_figura_workbench.dialogs import AddDistanceDialog
        
        dialog = AddDistanceDialog(self)
        self.wait_window(dialog)
        
        if dialog.result:
            collection_name = self.document.active_measurement_collection
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                self.command_manager.execute(cmd)
                self._update_status_bar(f"Added distance: {dialog.result.name}")
    
    def _add_vector(self) -> None:
        """Add a 3D vector measurement."""
        from plana_figura_workbench.dialogs import AddVectorDialog
        
        dialog = AddVectorDialog(self)
        self.wait_window(dialog)
        
        if dialog.result:
            collection_name = self.document.active_measurement_collection
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                self.command_manager.execute(cmd)
                self._update_status_bar(f"Added vector: {dialog.result.name}")
    
    def _show_measurement_manager(self) -> None:
        """Show the Measurement Manager tab."""
        # Find the Measurement Manager tab and select it
        for i in range(self.notebook.index("end")):
            tab_text = self.notebook.tab(i, "text")
            if "Measurement" in tab_text:
                self.notebook.select(i)
                self._update_status_bar("Showing Measurement Manager")
                return
        
        # If not found, log a warning
        logger.warning("Measurement Manager tab not found")
        messagebox.showwarning("Warning", "Measurement Manager tab not found")

    def _show_about(self) -> None:
        """Show about dialog."""
        messagebox.showinfo(
            "About Plana Figura Workbench",
            "Plana Figura Workbench\n"
            "Version 0.1.0\n\n"
            "Phase 5A: Unified Application\n"
            "- Modern ttkbootstrap UI (Darkly theme)\n"
            "- Integrated CommandManager & EventBus\n"
            "- Centralized Action management\n"
            "- Full keyboard shortcuts\n"
            "- Five plugin tabs\n\n"
            "© 2025 Plana Figura Project"
        )

    def _offer_crash_recovery(self) -> bool:
        """Ask user if they want to recover from crash."""
        result = messagebox.askyesno(
            "Crash Recovery",
            "Plana Figura detected that it may have crashed previously.\n\n"
            "Would you like to recover your work from the last auto-save?",
            parent=self
        )
        self.logger.info(f"User {'accepted' if result else 'declined'} crash recovery")
        return result

    def destroy(self):
        """Clean up resources before closing."""
        self.logger.info("Shutting down Plana Figura Workbench")
        
        # Stop auto-save
        if hasattr(self, 'auto_save_manager'):
            self.auto_save_manager.stop_auto_save()
            self.logger.info("Auto-save stopped")
        
        # Clear recovery file on clean shutdown
        if hasattr(self, 'auto_save_manager'):
            self.auto_save_manager.clear_recovery_file()
        
        # Perform final resource check
        if hasattr(self, 'resource_monitor'):
            self.resource_monitor.check_resources()
        
        self.logger.info("Plana Figura Workbench shutdown complete")
        super().destroy()


def main():
    """Run the Plana Figura Workbench application."""
    app = PlanaFiguraWorkbench()
    app.mainloop()


if __name__ == "__main__":
    main()
