"""Demo application for testing geometry input forms."""

import tkinter as tk
from tkinter import ttk
import ttkbootstrap as ttk_bs
import logging

from plana_figura import Point, LineSegment, GeometryCollection
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.forms import PointCreationForm, LineCreationForm

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


class FormsDemo(ttk_bs.Window):
    """Demo application for testing geometry input forms."""

    def __init__(self):
        """Initialize the demo application."""
        super().__init__(themename="cosmo")  # Modern blue theme

        self.title("Plana Figura Forms - Demo")
        self.geometry("650x550")

        # Create document
        self.document = PlanaFiguraDocument("Forms Demo")

        # Setup UI
        self._setup_ui()

        logger.info("Forms demo started")

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Create notebook for tabs
        notebook = ttk_bs.Notebook(self, bootstyle="primary")
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Point creation tab
        point_frame = ttk.Frame(notebook)
        notebook.add(point_frame, text="Create Point")

        self.point_form = PointCreationForm(
            point_frame,
            on_create=self._on_point_created,
            on_cancel=self._on_cancel
        )
        self.point_form.pack(fill=tk.BOTH, expand=True)

        # Line creation tab
        line_frame = ttk.Frame(notebook)
        notebook.add(line_frame, text="Create Line")

        self.line_form = LineCreationForm(
            line_frame,
            on_create=self._on_line_created,
            on_cancel=self._on_cancel
        )
        self.line_form.pack(fill=tk.BOTH, expand=True)

        # Results display
        results_frame = ttk.LabelFrame(self, text="Created Geometries", padding=10)
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        # Scrolled text for results
        self.results_text = tk.Text(
            results_frame,
            height=8,
            wrap=tk.WORD,
            state=tk.DISABLED
        )
        self.results_text.pack(fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(
            results_frame,
            command=self.results_text.yview
        )
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.results_text.config(yscrollcommand=scrollbar.set)

        # Status bar
        self.status_label = ttk.Label(
            self,
            text="Ready",
            relief=tk.SUNKEN,
            anchor=tk.W
        )
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def _on_point_created(self, point: Point) -> None:
        """
        Handle point creation.

        Args:
            point: The created point
        """
        # Add to document
        collection = GeometryCollection([point])  # type: ignore[list-item]
        self.document.add_collection(collection, set_active=False)

        # Display result
        self._add_result(
            f"Point created: N={point.northing:.3f}, "
            f"E={point.easting:.3f}, Z={point.elevation:.3f}"
        )

        self.status_label.config(
            text=f"Created point at ({point.northing}, {point.easting})"
        )

    def _on_line_created(self, line: LineSegment) -> None:
        """
        Handle line segment creation.

        Args:
            line: The created line segment
        """
        # Add to document
        collection = GeometryCollection([line])
        self.document.add_collection(collection, set_active=False)

        # Display result
        self._add_result(
            f"Line created: Start({line.start_point.northing:.3f}, "
            f"{line.start_point.easting:.3f}), "
            f"End({line.end_point.northing:.3f}, "
            f"{line.end_point.easting:.3f}), "
            f"Length={line.length_2d:.3f}m"
        )

        self.status_label.config(
            text=f"Created line segment, length={line.length_2d:.3f}m"
        )

    def _on_cancel(self) -> None:
        """Handle form cancellation."""
        self.status_label.config(text="Cancelled")

    def _add_result(self, text: str) -> None:
        """
        Add result text to display.

        Args:
            text: Text to add
        """
        self.results_text.config(state=tk.NORMAL)
        self.results_text.insert(tk.END, text + "\n")
        self.results_text.see(tk.END)
        self.results_text.config(state=tk.DISABLED)


def main():
    """Run the demo application."""
    app = FormsDemo()
    app.mainloop()


if __name__ == "__main__":
    main()
