"""
Commands for document-level operations (add/remove geometries).

These commands support undo/redo for geometry creation and deletion.
"""

from typing import Optional
import logging

from plana_figura import Geometry
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.commands.base import Command

logger = logging.getLogger(__name__)


class AddGeometryCommand(Command):
    """
    Command to add a geometry to the active collection.
    
    Supports undo by removing the geometry.
    """
    
    def __init__(self, document: PlanaFiguraDocument, geometry: Geometry):
        """
        Initialize the command.
        
        Args:
            document: The document to modify
            geometry: The geometry to add
        """
        self.document = document
        self.geometry = geometry
        self.collection_index: Optional[int] = None
        self.geometry_index: Optional[int] = None
    
    def execute(self) -> bool:
        """
        Execute the command - add geometry to active collection.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            if not self.document.active_collection:
                logger.error("No active collection")
                return False
            
            # Add to active collection
            self.document.active_collection.add(self.geometry)
            
            # Store indices for undo
            self.collection_index = self.document.collections.index(
                self.document.active_collection
            )
            self.geometry_index = (
                self.document.active_collection.geometries.index(self.geometry)
            )
            
            logger.info(
                f"Added {type(self.geometry).__name__} to collection "
                f"{self.collection_index}"
            )
            return True
            
        except Exception as e:
            logger.error(f"Failed to add geometry: {e}")
            return False
    
    def undo(self) -> bool:
        """
        Undo the command - remove the geometry.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            if self.collection_index is None or self.geometry_index is None:
                logger.error("Cannot undo: indices not stored")
                return False
            
            collection = self.document.collections[self.collection_index]
            collection.remove(self.geometry)
            
            logger.info(
                f"Removed {type(self.geometry).__name__} from collection "
                f"{self.collection_index}"
            )
            return True
            
        except Exception as e:
            logger.error(f"Failed to undo add geometry: {e}")
            return False
    
    def redo(self) -> bool:
        """
        Redo the command - re-add the geometry.
        
        Returns:
            True if successful, False otherwise
        """
        return self.execute()
    
    def description(self) -> str:
        """Get command description."""
        return f"Add {type(self.geometry).__name__}"


class RemoveGeometryCommand(Command):
    """
    Command to remove a geometry from its collection.
    
    Supports undo by re-adding the geometry at its original position.
    """
    
    def __init__(self, document: PlanaFiguraDocument, geometry: Geometry):
        """
        Initialize the command.
        
        Args:
            document: The document to modify
            geometry: The geometry to remove
        """
        self.document = document
        self.geometry = geometry
        self.collection_index: Optional[int] = None
        self.geometry_index: Optional[int] = None
    
    def execute(self) -> bool:
        """
        Execute the command - remove geometry from its collection.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Find which collection contains this geometry
            for coll_idx, collection in enumerate(self.document.collections):
                if self.geometry in collection.geometries:
                    self.collection_index = coll_idx
                    self.geometry_index = collection.geometries.index(self.geometry)
                    collection.remove(self.geometry)
                    
                    logger.info(
                        f"Removed {type(self.geometry).__name__} from collection "
                        f"{self.collection_index}"
                    )
                    return True
            
            logger.error("Geometry not found in any collection")
            return False
            
        except Exception as e:
            logger.error(f"Failed to remove geometry: {e}")
            return False
    
    def undo(self) -> bool:
        """
        Undo the command - re-add the geometry at its original position.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            if self.collection_index is None or self.geometry_index is None:
                logger.error("Cannot undo: indices not stored")
                return False
            
            collection = self.document.collections[self.collection_index]
            
            # Re-add the geometry (position doesn't matter for functionality)
            collection.add(self.geometry)
            
            logger.info(
                f"Re-added {type(self.geometry).__name__} to collection "
                f"{self.collection_index}"
            )
            return True
            
        except Exception as e:
            logger.error(f"Failed to undo remove geometry: {e}")
            return False
    
    def redo(self) -> bool:
        """
        Redo the command - re-remove the geometry.
        
        Returns:
            True if successful, False otherwise
        """
        return self.execute()
    
    def description(self) -> str:
        """Get command description."""
        return f"Remove {type(self.geometry).__name__}"
