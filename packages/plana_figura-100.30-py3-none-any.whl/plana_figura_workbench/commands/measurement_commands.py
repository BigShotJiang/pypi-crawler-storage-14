"""Commands for measurement operations with undo/redo support."""

from typing import Optional, Dict, Any
import logging

from plana_figura import Measurement, MeasurementCollection
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.commands.base import Command

logger = logging.getLogger(__name__)


class AddMeasurementCommand(Command):
    """
    Command to add a measurement to a collection.

    This command supports undo by removing the measurement.

    Attributes:
        document: The document being modified
        measurement: The measurement to add
        collection_name: Name of the collection to add to
    """

    def __init__(
        self,
        document: PlanaFiguraDocument,
        measurement: Measurement,
        collection_name: str
    ):
        """
        Initialize the command.

        Args:
            document: The document to modify
            measurement: The measurement to add
            collection_name: Name of the collection
        """
        self.document = document
        self.measurement = measurement
        self.collection_name = collection_name
        self._executed = False

    def execute(self) -> bool:
        """
        Execute the command by adding the measurement.

        Returns:
            True if successful, False otherwise
        """
        try:
            collection = self.document.get_measurement_collection(
                self.collection_name
            )

            if collection is None:
                logger.error(
                    f"AddMeasurementCommand: Collection "
                    f"'{self.collection_name}' not found"
                )
                return False

            # Add measurement to collection
            collection.add(self.measurement)
            self.document.modified = True
            self._executed = True

            logger.info(
                f"AddMeasurementCommand: Added measurement "
                f"'{self.measurement.name}' (ID: {self.measurement.id}) "
                f"to collection '{self.collection_name}'"
            )
            return True

        except Exception as e:
            logger.error(
                f"AddMeasurementCommand failed: {e}",
                exc_info=True
            )
            return False

    def undo(self) -> None:
        """Undo the command by removing the measurement."""
        if not self._executed:
            return

        collection = self.document.get_measurement_collection(
            self.collection_name
        )

        if collection is not None:
            collection.remove(self.measurement.id)
            self.document.modified = True

            logger.info(
                f"AddMeasurementCommand: Undone (removed measurement "
                f"ID: {self.measurement.id})"
            )

    def get_description(self) -> str:
        """Get command description."""
        return f"Add Measurement '{self.measurement.name}'"


class RemoveMeasurementCommand(Command):
    """
    Command to remove a measurement from a collection.

    This command supports undo by restoring the measurement.

    Attributes:
        document: The document being modified
        measurement_id: ID of the measurement to remove
        collection_name: Name of the collection
        measurement: The removed measurement (stored for undo)
    """

    def __init__(
        self,
        document: PlanaFiguraDocument,
        measurement_id: int,
        collection_name: str
    ):
        """
        Initialize the command.

        Args:
            document: The document to modify
            measurement_id: ID of the measurement to remove
            collection_name: Name of the collection
        """
        self.document = document
        self.measurement_id = measurement_id
        self.collection_name = collection_name
        self.measurement: Optional[Measurement] = None
        self._executed = False

    def execute(self) -> bool:
        """
        Execute the command by removing the measurement.

        Returns:
            True if successful, False otherwise
        """
        try:
            collection = self.document.get_measurement_collection(
                self.collection_name
            )

            if collection is None:
                logger.error(
                    f"RemoveMeasurementCommand: Collection "
                    f"'{self.collection_name}' not found"
                )
                return False

            # Get measurement before removing (for undo)
            self.measurement = collection.get(self.measurement_id)

            if self.measurement is None:
                logger.error(
                    f"RemoveMeasurementCommand: Measurement "
                    f"ID {self.measurement_id} not found"
                )
                return False

            # Remove measurement
            collection.remove(self.measurement_id)
            self.document.modified = True
            self._executed = True

            logger.info(
                f"RemoveMeasurementCommand: Removed measurement "
                f"ID {self.measurement_id} from collection "
                f"'{self.collection_name}'"
            )
            return True

        except Exception as e:
            logger.error(
                f"RemoveMeasurementCommand failed: {e}",
                exc_info=True
            )
            return False

    def undo(self) -> None:
        """Undo the command by restoring the measurement."""
        if not self._executed or self.measurement is None:
            return

        collection = self.document.get_measurement_collection(
            self.collection_name
        )

        if collection is not None:
            collection.add(self.measurement)
            self.document.modified = True

            logger.info(
                f"RemoveMeasurementCommand: Undone (restored measurement "
                f"ID: {self.measurement_id})"
            )

    def get_description(self) -> str:
        """Get command description."""
        return f"Remove Measurement ID {self.measurement_id}"


class ModifyMeasurementCommand(Command):
    """
    Command to modify a measurement's properties.

    This command supports undo by restoring original values.

    Attributes:
        document: The document being modified
        measurement_id: ID of the measurement to modify
        collection_name: Name of the collection
        changes: Dictionary of field names to new values
        original_values: Original values (stored for undo)
    """

    def __init__(
        self,
        document: PlanaFiguraDocument,
        measurement_id: int,
        collection_name: str,
        **changes: Any
    ):
        """
        Initialize the command.

        Args:
            document: The document to modify
            measurement_id: ID of the measurement to modify
            collection_name: Name of the collection
            **changes: Field names and new values to apply
        """
        self.document = document
        self.measurement_id = measurement_id
        self.collection_name = collection_name
        self.changes = changes
        self.original_values: Dict[str, Any] = {}
        self._executed = False

    def execute(self) -> bool:
        """
        Execute the command by modifying the measurement.

        Returns:
            True if successful, False otherwise
        """
        try:
            collection = self.document.get_measurement_collection(
                self.collection_name
            )

            if collection is None:
                logger.error(
                    f"ModifyMeasurementCommand: Collection "
                    f"'{self.collection_name}' not found"
                )
                return False

            measurement = collection.get(self.measurement_id)

            if measurement is None:
                logger.error(
                    f"ModifyMeasurementCommand: Measurement "
                    f"ID {self.measurement_id} not found"
                )
                return False

            # Store original values for undo
            for field_name in self.changes.keys():
                if hasattr(measurement, field_name):
                    self.original_values[field_name] = getattr(
                        measurement, field_name
                    )

            # Apply changes
            for field_name, new_value in self.changes.items():
                if hasattr(measurement, field_name):
                    setattr(measurement, field_name, new_value)
                else:
                    logger.warning(
                        f"ModifyMeasurementCommand: Field '{field_name}' "
                        f"not found on measurement"
                    )

            self.document.modified = True
            self._executed = True

            logger.info(
                f"ModifyMeasurementCommand: Modified measurement "
                f"ID {self.measurement_id} "
                f"(fields: {', '.join(self.changes.keys())})"
            )
            return True

        except Exception as e:
            logger.error(
                f"ModifyMeasurementCommand failed: {e}",
                exc_info=True
            )
            return False

    def undo(self) -> None:
        """Undo the command by restoring original values."""
        if not self._executed:
            return

        collection = self.document.get_measurement_collection(
            self.collection_name
        )

        if collection is None:
            return

        measurement = collection.get(self.measurement_id)

        if measurement is not None:
            # Restore original values
            for field_name, original_value in self.original_values.items():
                setattr(measurement, field_name, original_value)

            self.document.modified = True

            logger.info(
                f"ModifyMeasurementCommand: Undone (restored measurement "
                f"ID {self.measurement_id})"
            )

    def get_description(self) -> str:
        """Get command description."""
        fields = ', '.join(self.changes.keys())
        return f"Modify Measurement ID {self.measurement_id} ({fields})"


class CreateMeasurementCollectionCommand(Command):
    """
    Command to create a new measurement collection.

    This command supports undo by removing the collection.

    Attributes:
        document: The document being modified
        collection_name: Name of the collection to create
        set_active: Whether to set as active collection
    """

    def __init__(
        self,
        document: PlanaFiguraDocument,
        collection_name: str,
        set_active: bool = True
    ):
        """
        Initialize the command.

        Args:
            document: The document to modify
            collection_name: Name of the collection to create
            set_active: Whether to set as active collection
        """
        self.document = document
        self.collection_name = collection_name
        self.set_active = set_active
        self._executed = False
        self._previous_active: Optional[str] = None

    def execute(self) -> bool:
        """
        Execute the command by creating the collection.

        Returns:
            True if successful, False otherwise
        """
        try:
            # Check if collection already exists
            if self.collection_name in self.document.measurement_collections:
                logger.error(
                    f"CreateMeasurementCollectionCommand: Collection "
                    f"'{self.collection_name}' already exists"
                )
                return False

            # Store previous active collection for undo
            self._previous_active = self.document.active_measurement_collection

            # Create collection
            self.document.add_measurement_collection(
                self.collection_name,
                set_active=self.set_active
            )

            self._executed = True

            logger.info(
                f"CreateMeasurementCollectionCommand: Created collection "
                f"'{self.collection_name}'"
            )
            return True

        except Exception as e:
            logger.error(
                f"CreateMeasurementCollectionCommand failed: {e}",
                exc_info=True
            )
            return False

    def undo(self) -> None:
        """Undo the command by removing the collection."""
        if not self._executed:
            return

        # Remove the collection
        if self.collection_name in self.document.measurement_collections:
            # Temporarily allow removing any collection for undo
            del self.document.measurement_collections[self.collection_name]

            # Restore previous active collection
            if self._previous_active is not None:
                self.document.active_measurement_collection = (
                    self._previous_active
                )

            self.document.modified = True

            logger.info(
                f"CreateMeasurementCollectionCommand: Undone "
                f"(removed collection '{self.collection_name}')"
            )

    def get_description(self) -> str:
        """Get command description."""
        return f"Create Measurement Collection '{self.collection_name}'"


class RemoveMeasurementCollectionCommand(Command):
    """
    Command to remove a measurement collection.

    This command supports undo by restoring the collection with all
    its measurements.

    Attributes:
        document: The document being modified
        collection_name: Name of the collection to remove
        collection: The removed collection (stored for undo)
        was_active: Whether this was the active collection
        previous_active: Previous active collection name
    """

    def __init__(
        self,
        document: PlanaFiguraDocument,
        collection_name: str
    ):
        """
        Initialize the command.

        Args:
            document: The document to modify
            collection_name: Name of the collection to remove
        """
        self.document = document
        self.collection_name = collection_name
        self.collection: Optional[MeasurementCollection] = None
        self.was_active = False
        self.previous_active: Optional[str] = None
        self._executed = False

    def execute(self) -> bool:
        """
        Execute the command by removing the collection.

        Returns:
            True if successful, False otherwise
        """
        try:
            # Get collection before removing (for undo)
            self.collection = self.document.get_measurement_collection(
                self.collection_name
            )

            if self.collection is None:
                logger.error(
                    f"RemoveMeasurementCollectionCommand: Collection "
                    f"'{self.collection_name}' not found"
                )
                return False

            # Store state for undo
            self.was_active = (
                self.document.active_measurement_collection ==
                self.collection_name
            )
            self.previous_active = self.document.active_measurement_collection

            # Remove collection
            success = self.document.remove_measurement_collection(
                self.collection_name
            )

            if not success:
                logger.error(
                    f"RemoveMeasurementCollectionCommand: Failed to remove "
                    f"collection '{self.collection_name}'"
                )
                return False

            self._executed = True

            logger.info(
                f"RemoveMeasurementCollectionCommand: Removed collection "
                f"'{self.collection_name}' "
                f"({len(self.collection)} measurements)"
            )
            return True

        except Exception as e:
            logger.error(
                f"RemoveMeasurementCollectionCommand failed: {e}",
                exc_info=True
            )
            return False

    def undo(self) -> None:
        """Undo the command by restoring the collection."""
        if not self._executed or self.collection is None:
            return

        # Restore the collection
        self.document.measurement_collections[self.collection_name] = (
            self.collection
        )

        # Restore active collection if needed
        if self.was_active:
            self.document.active_measurement_collection = self.collection_name

        self.document.modified = True

        logger.info(
            f"RemoveMeasurementCollectionCommand: Undone "
            f"(restored collection '{self.collection_name}' "
            f"with {len(self.collection)} measurements)"
        )

    def get_description(self) -> str:
        """Get command description."""
        return f"Remove Measurement Collection '{self.collection_name}'"
