"""Base command classes for undo/redo functionality."""

from typing import List, Optional
import logging
import copy

from plana_figura import Geometry
from plana_figura.exceptions import PlanaFiguraError, GeometryError, ValidationError as CoreValidationError
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.exceptions import CommandError

logger = logging.getLogger(__name__)


class Command:
    """
    Base class for all commands with transactional error handling.

    Commands encapsulate operations that can be undone and redone.
    This is the core of the undo/redo system with the Transactional Command Pattern.
    
    The execute() method implements the Firewall pattern - it catches Core exceptions
    and ensures the document remains in a consistent state.
    """

    def __init__(self):
        self._document_snapshot: Optional[dict] = None
        self._executed = False

    def execute(self) -> bool:
        """
        Execute the command with transactional error handling.
        
        This method implements the Transactional Command Pattern:
        1. Take a snapshot of the document state
        2. Execute the operation
        3. If Core exceptions occur, rollback and re-raise as CommandError
        4. Ensure document consistency

        Returns:
            True if command executed successfully, False otherwise
            
        Raises:
            CommandError: If the command fails due to Core exceptions
        """
        try:
            # Take snapshot before execution
            self._take_document_snapshot()
            
            # Execute the actual command logic
            result = self._execute_operation()
            
            if result:
                self._executed = True
                logger.info(f"Command {self.get_description()} executed successfully")
            else:
                # Rollback on failure
                self._rollback_document()
                logger.warning(f"Command {self.get_description()} failed")
            
            return result
            
        except (GeometryError, CoreValidationError, PlanaFiguraError) as core_error:
            # This is the Firewall - catch Core exceptions and handle them
            logger.error(f"Core error in command {self.get_description()}: {core_error}")
            
            # Rollback any partial changes
            self._rollback_document()
            
            # Re-raise as CommandError for the Controller to handle
            raise CommandError(
                f"Command failed: {core_error}",
                error_code=getattr(core_error, 'error_code', 'COMMAND_CORE_ERROR'),
                context={
                    'command': self.get_description(),
                    'original_error': str(core_error),
                    'original_error_type': type(core_error).__name__
                }
            ) from core_error
            
        except Exception as unexpected_error:
            # Handle unexpected errors
            logger.error(f"Unexpected error in command {self.get_description()}: {unexpected_error}")
            
            # Rollback any partial changes
            self._rollback_document()
            
            # Re-raise as CommandError
            raise CommandError(
                f"Unexpected command failure: {unexpected_error}",
                error_code='COMMAND_UNEXPECTED_ERROR',
                context={
                    'command': self.get_description(),
                    'error': str(unexpected_error)
                }
            ) from unexpected_error

    def _execute_operation(self) -> bool:
        """
        Execute the actual command operation.
        
        This method should be overridden in subclasses to implement
        the specific command logic.

        Returns:
            True if operation executed successfully, False otherwise
        """
        raise NotImplementedError("Subclasses must implement _execute_operation()")

    def _take_document_snapshot(self):
        """Take a snapshot of the document state for rollback."""
        # This is a placeholder - actual implementation depends on document structure
        # Subclasses should override this if they need specific snapshot logic
        pass

    def _rollback_document(self):
        """Rollback the document to the snapshot state."""
        # This is a placeholder - actual implementation depends on document structure
        # Subclasses should override this if they need specific rollback logic
        pass

    def undo(self) -> None:
        """Undo the command."""
        if not self._executed:
            logger.warning(f"Cannot undo command {self.get_description()} - not executed")
            return
            
        try:
            self._undo_operation()
            self._executed = False
            logger.info(f"Command {self.get_description()} undone successfully")
        except Exception as e:
            logger.error(f"Failed to undo command {self.get_description()}: {e}")
            raise CommandError(
                f"Undo failed: {e}",
                error_code='COMMAND_UNDO_ERROR',
                context={'command': self.get_description(), 'error': str(e)}
            ) from e

    def _undo_operation(self):
        """Perform the actual undo operation."""
        raise NotImplementedError("Subclasses must implement _undo_operation()")

    def get_description(self) -> str:
        """
        Get a human-readable description of the command.

        Returns:
            Description string for UI display
        """
        return self.__class__.__name__


class GeometryModificationCommand(Command):
    """
    Base class for commands that modify geometries with transactional error handling.

    This class handles the common pattern of:
    1. Store old geometries
    2. Perform operation to get new geometries
    3. Replace old with new in document
    4. Support undo by swapping back
    5. Implement transactional rollback on errors

    Attributes:
        document: The document being modified
        old_geometries: Geometries before modification
        new_geometries: Geometries after modification
    """

    def __init__(self, document: PlanaFiguraDocument):
        """
        Initialize the command.

        Args:
            document: The document to modify
        """
        super().__init__()
        self.document = document
        self.old_geometries: List[Geometry] = []
        self.new_geometries: List[Geometry] = []

    def _take_document_snapshot(self):
        """Take a snapshot of the geometries that will be modified."""
        # Store deep copies of the old geometries for rollback
        self._geometry_snapshot = [copy.deepcopy(geom) for geom in self.old_geometries]

    def _rollback_document(self):
        """Rollback any partial geometry modifications."""
        if hasattr(self, '_geometry_snapshot') and self._geometry_snapshot:
            # Restore original geometries
            for original in self._geometry_snapshot:
                # Find and restore the geometry in the document
                # This is a simplified approach - actual implementation may vary
                try:
                    self.document.restore_geometry(original)
                except Exception as e:
                    logger.error(f"Failed to rollback geometry {original.id}: {e}")

    def _execute_operation(self) -> bool:
        """
        Execute the geometry modification with error handling.

        Returns:
            True if successful, False otherwise
        """
        # Perform the operation (implemented in subclasses)
        self.new_geometries = self.perform_operation()

        if not self.new_geometries:
            logger.warning(
                f"{self.__class__.__name__}: "
                "No geometries produced by operation"
            )
            return False

        # Replace old geometries with new ones
        for old, new in zip(self.old_geometries, self.new_geometries):
            if not self.document.replace_geometry(old, new):
                logger.error(
                    f"{self.__class__.__name__}: "
                    f"Failed to replace geometry"
                )
                return False

        logger.info(
            f"{self.__class__.__name__}: "
            f"Modified {len(self.new_geometries)} geometries"
        )
        return True

    def _undo_operation(self) -> None:
        """Undo the geometry modification."""
        # Simply swap new geometries back to old ones
        for old, new in zip(self.old_geometries, self.new_geometries):
            self.document.replace_geometry(new, old)

        logger.info(
            f"{self.__class__.__name__}: "
            f"Undone ({len(self.old_geometries)} geometries restored)"
        )

    def perform_operation(self) -> List[Geometry]:
        """
        Perform the actual geometry operation.

        This method should be overridden in subclasses to call
        the appropriate GeometryManipulator method.

        Returns:
            List of new geometries after the operation

        Raises:
            NotImplementedError: If not overridden in subclass
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement perform_operation()"
        )
