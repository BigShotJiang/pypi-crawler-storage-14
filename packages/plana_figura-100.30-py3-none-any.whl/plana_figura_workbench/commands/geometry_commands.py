"""Geometry manipulation commands."""

from typing import List, TYPE_CHECKING
import logging

from plana_figura import Geometry, Point, LineSegment
from plana_figura_workbench.commands.base import GeometryModificationCommand

if TYPE_CHECKING:
    from plana_figura_workbench.model import PlanaFiguraDocument

logger = logging.getLogger(__name__)


class TranslateCommand(GeometryModificationCommand):
    """
    Command to translate (move) geometries by a delta.

    Attributes:
        delta_northing: Northing offset
        delta_easting: Easting offset
        delta_elevation: Elevation offset
    """

    def __init__(
        self,
        document: 'PlanaFiguraDocument',
        geometries: List[Geometry],
        delta_northing: float,
        delta_easting: float,
        delta_elevation: float = 0.0
    ):
        """
        Initialize translate command.

        Args:
            document: The document to modify
            geometries: Geometries to translate
            delta_northing: Northing offset
            delta_easting: Easting offset
            delta_elevation: Elevation offset
        """
        super().__init__(document)
        self.old_geometries = geometries
        self.delta_northing = delta_northing
        self.delta_easting = delta_easting
        self.delta_elevation = delta_elevation

    def perform_operation(self) -> List[Geometry]:
        """
        Perform the translation operation.

        Returns:
            List of translated geometries
        """
        result: List[Geometry] = []
        for geometry in self.old_geometries:
            new_geom: Geometry
            if isinstance(geometry, Point):
                new_geom = Point(
                    northing=geometry.northing + self.delta_northing,
                    easting=geometry.easting + self.delta_easting,
                    elevation=geometry.elevation + self.delta_elevation
                )
            elif isinstance(geometry, LineSegment):
                # Translate both endpoints
                new_start = Point(
                    northing=geometry.start_point.northing + self.delta_northing,
                    easting=geometry.start_point.easting + self.delta_easting,
                    elevation=(geometry.start_point.elevation +
                               self.delta_elevation)
                )
                new_end = Point(
                    northing=geometry.end_point.northing + self.delta_northing,
                    easting=geometry.end_point.easting + self.delta_easting,
                    elevation=(geometry.end_point.elevation +
                               self.delta_elevation)
                )
                new_geom = LineSegment(new_start, new_end)
            else:
                # For other geometry types, return as-is
                logger.warning(
                    f"Translation not implemented for "
                    f"{type(geometry).__name__}"
                )
                new_geom = geometry

            result.append(new_geom)

        return result

    def description(self) -> str:
        """Get command description."""
        return (
            f"Translate {len(self.old_geometries)} geometry(s) by "
            f"ΔN={self.delta_northing:.3f}, ΔE={self.delta_easting:.3f}, "
            f"ΔZ={self.delta_elevation:.3f}"
        )


class RotateCommand(GeometryModificationCommand):
    """
    Command to rotate geometries around a center point.

    Attributes:
        center: Center point of rotation
        angle_degrees: Rotation angle in degrees (counterclockwise)
    """

    def __init__(
        self,
        document: 'PlanaFiguraDocument',
        geometries: List[Geometry],
        center: Point,
        angle_degrees: float
    ):
        """
        Initialize rotate command.

        Args:
            document: The document to modify
            geometries: Geometries to rotate
            center: Center point of rotation
            angle_degrees: Rotation angle in degrees (counterclockwise)
        """
        super().__init__(document)
        self.old_geometries = geometries
        self.center = center
        self.angle_degrees = angle_degrees

    def _rotate_point(self, point: Point) -> Point:
        """
        Rotate a point around the center.

        Args:
            point: Point to rotate

        Returns:
            Rotated point
        """
        import math

        # Convert angle to radians
        angle_rad = math.radians(self.angle_degrees)

        # Translate to origin
        dx = point.easting - self.center.easting
        dy = point.northing - self.center.northing

        # Rotate
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)

        new_dx = dx * cos_a - dy * sin_a
        new_dy = dx * sin_a + dy * cos_a

        # Translate back
        return Point(
            northing=self.center.northing + new_dy,
            easting=self.center.easting + new_dx,
            elevation=point.elevation  # Keep elevation unchanged
        )

    def perform_operation(self) -> List[Geometry]:
        """
        Perform the rotation operation.

        Returns:
            List of rotated geometries
        """
        result: List[Geometry] = []
        for geometry in self.old_geometries:
            new_geom: Geometry
            if isinstance(geometry, Point):
                new_geom = self._rotate_point(geometry)
            elif isinstance(geometry, LineSegment):
                # Rotate both endpoints
                new_start = self._rotate_point(geometry.start_point)
                new_end = self._rotate_point(geometry.end_point)
                new_geom = LineSegment(new_start, new_end)
            else:
                logger.warning(
                    f"Rotation not implemented for {type(geometry).__name__}"
                )
                new_geom = geometry

            result.append(new_geom)

        return result

    def description(self) -> str:
        """Get command description."""
        return (
            f"Rotate {len(self.old_geometries)} geometry(s) by "
            f"{self.angle_degrees:.1f}° around "
            f"({self.center.northing:.3f}, {self.center.easting:.3f})"
        )


class ScaleCommand(GeometryModificationCommand):
    """
    Command to scale geometries relative to a center point.

    Attributes:
        center: Center point of scaling
        scale_factor: Scale factor (1.0 = no change, 2.0 = double size)
    """

    def __init__(
        self,
        document: 'PlanaFiguraDocument',
        geometries: List[Geometry],
        center: Point,
        scale_factor: float
    ):
        """
        Initialize scale command.

        Args:
            document: The document to modify
            geometries: Geometries to scale
            center: Center point of scaling
            scale_factor: Scale factor

        Raises:
            ValueError: If scale_factor is <= 0
        """
        if scale_factor <= 0:
            raise ValueError("Scale factor must be positive")

        super().__init__(document)
        self.old_geometries = geometries
        self.center = center
        self.scale_factor = scale_factor

    def perform_operation(self) -> List[Geometry]:
        """
        Perform the scale operation.

        Returns:
            List of scaled geometries
        """
        result: List[Geometry] = []
        for geometry in self.old_geometries:
            new_geom: Geometry
            if isinstance(geometry, Point):
                new_geom = self._scale_point(geometry)
            elif isinstance(geometry, LineSegment):
                # Scale both endpoints
                new_start = self._scale_point(geometry.start_point)
                new_end = self._scale_point(geometry.end_point)
                new_geom = LineSegment(new_start, new_end)
            else:
                logger.warning(
                    f"Scaling not implemented for {type(geometry).__name__}"
                )
                new_geom = geometry

            result.append(new_geom)

        return result

    def _scale_point(self, point: Point) -> Point:
        """
        Scale a point relative to the center.

        Args:
            point: Point to scale

        Returns:
            Scaled point
        """
        # Calculate offset from center
        dx = point.easting - self.center.easting
        dy = point.northing - self.center.northing

        # Scale offset
        new_dx = dx * self.scale_factor
        new_dy = dy * self.scale_factor

        # Apply scaled offset
        return Point(
            northing=self.center.northing + new_dy,
            easting=self.center.easting + new_dx,
            elevation=point.elevation  # Keep elevation unchanged
        )

    def description(self) -> str:
        """Get command description."""
        return (
            f"Scale {len(self.old_geometries)} geometry(s) by "
            f"{self.scale_factor:.2f}x around "
            f"({self.center.northing:.3f}, {self.center.easting:.3f})"
        )


class MirrorCommand(GeometryModificationCommand):
    """
    Command to mirror geometries across a line.

    Attributes:
        axis_point1: First point defining the mirror axis
        axis_point2: Second point defining the mirror axis
    """

    def __init__(
        self,
        document: 'PlanaFiguraDocument',
        geometries: List[Geometry],
        axis_point1: Point,
        axis_point2: Point
    ):
        """
        Initialize mirror command.

        Args:
            document: The document to modify
            geometries: Geometries to mirror
            axis_point1: First point defining the mirror axis
            axis_point2: Second point defining the mirror axis

        Raises:
            ValueError: If axis points are coincident
        """
        if axis_point1.is_coincident(axis_point2):
            raise ValueError("Mirror axis points must be different")

        super().__init__(document)
        self.old_geometries = geometries
        self.axis_point1 = axis_point1
        self.axis_point2 = axis_point2

    def _mirror_point(self, point: Point) -> Point:
        """
        Mirror a point across the axis.

        Args:
            point: Point to mirror

        Returns:
            Mirrored point
        """
        # Vector along the axis
        ax = self.axis_point2.easting - self.axis_point1.easting
        ay = self.axis_point2.northing - self.axis_point1.northing

        # Vector from axis_point1 to point
        px = point.easting - self.axis_point1.easting
        py = point.northing - self.axis_point1.northing

        # Project point onto axis
        axis_length_sq = ax * ax + ay * ay
        t = (px * ax + py * ay) / axis_length_sq

        # Point on axis closest to input point
        closest_x = self.axis_point1.easting + t * ax
        closest_y = self.axis_point1.northing + t * ay

        # Mirror point
        mirrored_x = 2 * closest_x - point.easting
        mirrored_y = 2 * closest_y - point.northing

        return Point(
            northing=mirrored_y,
            easting=mirrored_x,
            elevation=point.elevation  # Keep elevation unchanged
        )

    def perform_operation(self) -> List[Geometry]:
        """
        Perform the mirror operation.

        Returns:
            List of mirrored geometries
        """
        result: List[Geometry] = []
        for geometry in self.old_geometries:
            new_geom: Geometry
            if isinstance(geometry, Point):
                new_geom = self._mirror_point(geometry)
            elif isinstance(geometry, LineSegment):
                # Mirror both endpoints
                new_start = self._mirror_point(geometry.start_point)
                new_end = self._mirror_point(geometry.end_point)
                new_geom = LineSegment(new_start, new_end)
            else:
                logger.warning(
                    f"Mirroring not implemented for {type(geometry).__name__}"
                )
                new_geom = geometry

            result.append(new_geom)

        return result

    def description(self) -> str:
        """Get command description."""
        return (
            f"Mirror {len(self.old_geometries)} geometry(s) across axis "
            f"({self.axis_point1.northing:.3f}, "
            f"{self.axis_point1.easting:.3f}) to "
            f"({self.axis_point2.northing:.3f}, "
            f"{self.axis_point2.easting:.3f})"
        )
