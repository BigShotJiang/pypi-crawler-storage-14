"""Selection Manager for Plana Figura Workbench.

Centralized selection management that can be shared across all plugins
and properly unit tested.
"""

from typing import List, Dict, Optional, Set
import logging

from plana_figura import Geometry, GeometryCollection

logger = logging.getLogger(__name__)


class SelectionManager:
    """
    Manages geometry selection state across the workbench.
    
    Provides a single source of truth for what geometries are selected,
    with methods to query selection state and statistics.
    """
    
    def __init__(self, document):
        """
        Initialize the selection manager.
        
        Args:
            document: The PlanaFiguraDocument instance
        """
        self.document = document
        self._selection: List[Geometry] = []
        self._observers: List[callable] = []
    
    def select(self, geometries: List[Geometry], source: str = "unknown") -> None:
        """
        Set the current selection.
        
        Args:
            geometries: List of geometries to select
            source: Name of the plugin making the selection
        """
        if geometries is None:
            geometries = []
        
        # Update internal state
        self._selection = list(geometries)  # Make a copy
        
        # Update document
        self.document.selection = self._selection
        
        logger.debug(f"Selection changed by {source}: {len(self._selection)} geometries")
        
        # Notify observers
        self._notify_observers(source)
    
    def add_to_selection(self, geometry: Geometry, source: str = "unknown") -> None:
        """
        Add a geometry to the current selection.
        
        Args:
            geometry: Geometry to add
            source: Name of the plugin making the change
        """
        if geometry not in self._selection:
            self._selection.append(geometry)
            self.document.selection = self._selection
            logger.debug(f"Added to selection by {source}")
            self._notify_observers(source)
    
    def remove_from_selection(self, geometry: Geometry, source: str = "unknown") -> None:
        """
        Remove a geometry from the current selection.
        
        Args:
            geometry: Geometry to remove
            source: Name of the plugin making the change
        """
        if geometry in self._selection:
            self._selection.remove(geometry)
            self.document.selection = self._selection
            logger.debug(f"Removed from selection by {source}")
            self._notify_observers(source)
    
    def clear(self, source: str = "unknown") -> None:
        """
        Clear the selection.
        
        Args:
            source: Name of the plugin clearing selection
        """
        self._selection = []
        self.document.selection = []
        logger.debug(f"Selection cleared by {source}")
        self._notify_observers(source)
    
    def get_selection(self) -> List[Geometry]:
        """
        Get the current selection.
        
        Returns:
            List of selected geometries (copy)
        """
        return list(self._selection)
    
    def get_count(self) -> int:
        """
        Get the number of selected geometries.
        
        Returns:
            Selection count
        """
        return len(self._selection)
    
    def is_selected(self, geometry: Geometry) -> bool:
        """
        Check if a geometry is selected.
        
        Args:
            geometry: Geometry to check
            
        Returns:
            True if selected
        """
        return geometry in self._selection
    
    def has_selection(self) -> bool:
        """
        Check if any geometries are selected.
        
        Returns:
            True if selection is not empty
        """
        return len(self._selection) > 0
    
    def get_type_counts(self) -> Dict[str, int]:
        """
        Get count of selected geometries by type.
        
        Returns:
            Dictionary mapping type names to counts
        """
        type_counts = {}
        for geometry in self._selection:
            type_name = type(geometry).__name__
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
        return type_counts
    
    def get_collections_count(self) -> int:
        """
        Get count of collections containing selected geometries.
        
        Returns:
            Number of collections with selected geometries
        """
        if not self._selection:
            return 0
        
        # Find which collections contain selected geometries
        collections_with_selection = []
        for collection in self.document.collections:
            for geometry in self._selection:
                if geometry in collection.geometries:
                    if collection not in collections_with_selection:
                        collections_with_selection.append(collection)
                    break
        
        return len(collections_with_selection)
    
    def get_summary(self) -> str:
        """
        Get a human-readable summary of the selection.
        
        Returns:
            Summary string (e.g., "3 geometries selected: 2 Points, 1 LineSegment")
        """
        count = self.get_count()
        
        if count == 0:
            return "No geometries selected"
        elif count == 1:
            geometry = self._selection[0]
            type_name = type(geometry).__name__
            return f"1 {type_name} selected"
        else:
            # Count by type
            type_counts = self.get_type_counts()
            
            # Format summary
            parts = []
            for type_name, type_count in sorted(type_counts.items()):
                parts.append(f"{type_count} {type_name}{'s' if type_count > 1 else ''}")
            
            return f"{count} geometries selected: " + ", ".join(parts)
    
    def add_observer(self, callback: callable) -> None:
        """
        Add an observer to be notified of selection changes.
        
        Args:
            callback: Function to call when selection changes.
                     Should accept (selection_manager, source) parameters.
        """
        if callback not in self._observers:
            self._observers.append(callback)
            logger.debug(f"Added selection observer: {callback}")
    
    def remove_observer(self, callback: callable) -> None:
        """
        Remove an observer.
        
        Args:
            callback: Observer to remove
        """
        if callback in self._observers:
            self._observers.remove(callback)
            logger.debug(f"Removed selection observer: {callback}")
    
    def _notify_observers(self, source: str) -> None:
        """
        Notify all observers of selection change.
        
        Args:
            source: Name of the plugin that changed selection
        """
        for observer in self._observers:
            try:
                observer(self, source)
            except Exception as e:
                logger.error(f"Error notifying selection observer: {e}", exc_info=True)
    
    def toggle_selection(self, geometry: Geometry, source: str = "unknown") -> None:
        """
        Toggle selection state of a geometry.
        
        Args:
            geometry: Geometry to toggle
            source: Name of the plugin making the change
        """
        if self.is_selected(geometry):
            self.remove_from_selection(geometry, source)
        else:
            self.add_to_selection(geometry, source)
    
    def select_all_in_collection(self, collection: GeometryCollection, source: str = "unknown") -> None:
        """
        Select all geometries in a collection.
        
        Args:
            collection: Collection to select from
            source: Name of the plugin making the selection
        """
        self.select(list(collection.geometries), source)
    
    def get_selected_from_collection(self, collection: GeometryCollection) -> List[Geometry]:
        """
        Get selected geometries that belong to a specific collection.
        
        Args:
            collection: Collection to filter by
            
        Returns:
            List of selected geometries in the collection
        """
        return [g for g in self._selection if g in collection.geometries]
