"""Event type definitions for inter-plugin communication."""

from dataclasses import dataclass
from typing import List
from plana_figura import Geometry, GeometryCollection
from plana_figura.grid import Grid as TheGrid
from plana_figura.spatial import TwoDimensionalEnvelope


@dataclass
class GeometrySelectedEvent:
    """
    Published when geometries are selected.

    Attributes:
        geometries: List of selected geometries
        source_plugin: Name of the plugin that published the event
    """
    geometries: List[Geometry]
    source_plugin: str


@dataclass
class GeometryModifiedEvent:
    """
    Published when geometries are modified.

    Attributes:
        old_geometries: List of geometries before modification
        new_geometries: List of geometries after modification
    """
    old_geometries: List[Geometry]
    new_geometries: List[Geometry]


@dataclass
class CollectionChangedEvent:
    """
    Published when collections are added/removed/renamed.

    Attributes:
        collection: The affected collection
        action: Type of change ("added", "removed", "renamed")
    """
    collection: GeometryCollection
    action: str  # "added", "removed", "renamed"


@dataclass
class GridChangedEvent:
    """
    Published when grid settings change.

    Attributes:
        old_grid: Grid settings before change
        new_grid: Grid settings after change
    """
    old_grid: TheGrid
    new_grid: TheGrid


@dataclass
class ViewportChangedEvent:
    """
    Published when map viewport changes (zoom/pan).

    Attributes:
        envelope: The new viewport envelope
        zoom_level: The new zoom level
    """
    envelope: TwoDimensionalEnvelope
    zoom_level: float
