"""DataBucket - Centralized data sharing for plugins.

Provides a key-value store where plugins can contribute and access shared data.
Supports observer pattern for reactive updates when data changes.
"""

from typing import Any, Dict, Optional, List, Callable, Set
import logging

logger = logging.getLogger(__name__)


class DataBucket:
    """
    Centralized data store for plugin data sharing.
    
    Plugins can contribute data (e.g., collections, grid, measurements)
    and other plugins can access it. Supports observer pattern for
    reactive updates.
    
    Example usage:
        # Plugin contributes data
        data_bucket.set('measurement_collections', collections, source='measurement_manager')
        
        # Another plugin accesses data
        collections = data_bucket.get('measurement_collections')
        
        # Plugin observes changes
        data_bucket.observe('measurement_collections', callback)
    """
    
    def __init__(self):
        """Initialize the DataBucket."""
        self._data: Dict[str, Any] = {}
        self._observers: Dict[str, List[Callable]] = {}
        self._key_observers: List[Callable] = []  # Observers for any key change
    
    def set(self, key: str, value: Any, source: str = "unknown") -> None:
        """
        Set a value in the data bucket.
        
        Args:
            key: The data key
            value: The value to store
            source: Name of the plugin setting the value
        """
        old_value = self._data.get(key)
        self._data[key] = value
        
        logger.debug(f"DataBucket: '{key}' set by {source}")
        
        # Notify observers
        self._notify_observers(key, value, old_value, source)
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a value from the data bucket.
        
        Args:
            key: The data key
            default: Default value if key doesn't exist
            
        Returns:
            The stored value or default
        """
        return self._data.get(key, default)
    
    def has(self, key: str) -> bool:
        """
        Check if a key exists in the data bucket.
        
        Args:
            key: The data key
            
        Returns:
            True if key exists
        """
        return key in self._data
    
    def delete(self, key: str, source: str = "unknown") -> bool:
        """
        Delete a key from the data bucket.
        
        Args:
            key: The data key
            source: Name of the plugin deleting the value
            
        Returns:
            True if key was deleted, False if it didn't exist
        """
        if key in self._data:
            old_value = self._data[key]
            del self._data[key]
            logger.debug(f"DataBucket: '{key}' deleted by {source}")
            self._notify_observers(key, None, old_value, source)
            return True
        return False
    
    def keys(self) -> Set[str]:
        """
        Get all keys in the data bucket.
        
        Returns:
            Set of all keys
        """
        return set(self._data.keys())
    
    def clear(self, source: str = "unknown") -> None:
        """
        Clear all data from the bucket.
        
        Args:
            source: Name of the plugin clearing the bucket
        """
        keys_to_clear = list(self._data.keys())
        for key in keys_to_clear:
            self.delete(key, source)
        logger.debug(f"DataBucket: cleared by {source}")
    
    def observe(self, key: str, callback: Callable) -> None:
        """
        Observe changes to a specific key.
        
        Args:
            key: The data key to observe
            callback: Function to call when key changes.
                     Signature: callback(key, new_value, old_value, source)
        """
        if key not in self._observers:
            self._observers[key] = []
        
        if callback not in self._observers[key]:
            self._observers[key].append(callback)
            logger.debug(f"DataBucket: Added observer for '{key}'")
    
    def unobserve(self, key: str, callback: Callable) -> None:
        """
        Remove an observer for a specific key.
        
        Args:
            key: The data key
            callback: The callback to remove
        """
        if key in self._observers and callback in self._observers[key]:
            self._observers[key].remove(callback)
            logger.debug(f"DataBucket: Removed observer for '{key}'")
    
    def observe_all(self, callback: Callable) -> None:
        """
        Observe changes to any key.
        
        Args:
            callback: Function to call when any key changes.
                     Signature: callback(key, new_value, old_value, source)
        """
        if callback not in self._key_observers:
            self._key_observers.append(callback)
            logger.debug("DataBucket: Added global observer")
    
    def unobserve_all(self, callback: Callable) -> None:
        """
        Remove a global observer.
        
        Args:
            callback: The callback to remove
        """
        if callback in self._key_observers:
            self._key_observers.remove(callback)
            logger.debug("DataBucket: Removed global observer")
    
    def _notify_observers(self, key: str, new_value: Any, old_value: Any, source: str) -> None:
        """
        Notify observers of a change.
        
        Args:
            key: The key that changed
            new_value: The new value (None if deleted)
            old_value: The previous value
            source: Name of the plugin that made the change
        """
        # Notify key-specific observers
        if key in self._observers:
            for observer in self._observers[key][:]:  # Copy list to allow modification during iteration
                try:
                    observer(key, new_value, old_value, source)
                except Exception as e:
                    logger.error(f"Error notifying observer for '{key}': {e}", exc_info=True)
        
        # Notify global observers
        for observer in self._key_observers[:]:
            try:
                observer(key, new_value, old_value, source)
            except Exception as e:
                logger.error(f"Error notifying global observer: {e}", exc_info=True)
    
    def update(self, data: Dict[str, Any], source: str = "unknown") -> None:
        """
        Update multiple keys at once.
        
        Args:
            data: Dictionary of key-value pairs to set
            source: Name of the plugin updating the data
        """
        for key, value in data.items():
            self.set(key, value, source)
    
    def get_all(self) -> Dict[str, Any]:
        """
        Get all data in the bucket.
        
        Returns:
            Dictionary of all key-value pairs (copy)
        """
        return dict(self._data)
    
    def __contains__(self, key: str) -> bool:
        """
        Support 'in' operator.
        
        Args:
            key: The data key
            
        Returns:
            True if key exists
        """
        return key in self._data
    
    def __getitem__(self, key: str) -> Any:
        """
        Support bracket notation for getting values.
        
        Args:
            key: The data key
            
        Returns:
            The stored value
            
        Raises:
            KeyError: If key doesn't exist
        """
        return self._data[key]
    
    def __setitem__(self, key: str, value: Any) -> None:
        """
        Support bracket notation for setting values.
        
        Args:
            key: The data key
            value: The value to store
        """
        self.set(key, value, source="bracket_notation")
    
    def __delitem__(self, key: str) -> None:
        """
        Support del operator.
        
        Args:
            key: The data key
            
        Raises:
            KeyError: If key doesn't exist
        """
        if not self.delete(key, source="del_operator"):
            raise KeyError(key)
    
    def __len__(self) -> int:
        """
        Get number of keys in the bucket.
        
        Returns:
            Number of keys
        """
        return len(self._data)
    
    def __repr__(self) -> str:
        """
        String representation.
        
        Returns:
            String representation of the DataBucket
        """
        return f"DataBucket({len(self._data)} keys: {list(self._data.keys())})"


# Standard keys used by plugins (for documentation and consistency)
class DataBucketKeys:
    """Standard keys used in the DataBucket."""
    
    # Document data
    DOCUMENT = "document"
    ACTIVE_COLLECTION = "active_collection"
    
    # Geometry data
    GEOMETRY_COLLECTIONS = "geometry_collections"
    SELECTED_GEOMETRIES = "selected_geometries"
    
    # Measurement data
    MEASUREMENT_COLLECTIONS = "measurement_collections"
    ACTIVE_MEASUREMENT_COLLECTION = "active_measurement_collection"
    
    # Grid data
    GRID = "grid"
    GRID_VISIBLE = "grid_visible"
    
    # Viewport data
    VIEWPORT_CENTER = "viewport_center"
    VIEWPORT_ZOOM = "viewport_zoom"
    
    # Selection data
    SELECTION_MANAGER = "selection_manager"
    
    # Command data
    COMMAND_MANAGER = "command_manager"
    
    # Event bus
    EVENT_BUS = "event_bus"
