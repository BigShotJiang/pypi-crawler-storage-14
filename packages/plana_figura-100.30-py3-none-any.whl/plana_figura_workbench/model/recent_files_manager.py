"""Recent Files Manager for Plana Figura Workbench.

Manages a list of recently opened files with persistence to disk.
"""

import json
import logging
from pathlib import Path
from typing import List, Optional, Callable
from datetime import datetime

logger = logging.getLogger(__name__)


class RecentFilesManager:
    """
    Manages recently opened files.
    
    Features:
    - Maintains a list of recently opened files
    - Persists to disk
    - Configurable maximum number of recent files
    - Observer pattern for UI updates
    """
    
    def __init__(self, max_files: int = 10, config_file: Optional[Path] = None):
        """
        Initialize the Recent Files Manager.
        
        Args:
            max_files: Maximum number of recent files to track
            config_file: Path to config file (default: user home/.plana_figura/recent_files.json)
        """
        self.max_files = max_files
        self._recent_files: List[dict] = []
        self._observers: List[Callable] = []
        
        # Determine config file location
        if config_file:
            self.config_file = config_file
        else:
            # Use user home directory
            home = Path.home()
            config_dir = home / ".plana_figura"
            config_dir.mkdir(exist_ok=True)
            self.config_file = config_dir / "recent_files.json"
        
        # Load from disk
        self._load()
    
    def add_file(self, file_path: str, title: Optional[str] = None) -> None:
        """
        Add a file to the recent files list.
        
        Args:
            file_path: Path to the file
            title: Optional display title (defaults to filename)
        """
        file_path = str(Path(file_path).resolve())  # Normalize path
        
        # Remove if already in list
        self._recent_files = [f for f in self._recent_files if f['path'] != file_path]
        
        # Add to front
        entry = {
            'path': file_path,
            'title': title or Path(file_path).name,
            'timestamp': datetime.now().isoformat()
        }
        self._recent_files.insert(0, entry)
        
        # Trim to max
        if len(self._recent_files) > self.max_files:
            self._recent_files = self._recent_files[:self.max_files]
        
        # Save and notify
        self._save()
        self._notify_observers()
        
        logger.debug(f"Added recent file: {file_path}")
    
    def remove_file(self, file_path: str) -> bool:
        """
        Remove a file from the recent files list.
        
        Args:
            file_path: Path to the file
            
        Returns:
            True if file was removed, False if not found
        """
        file_path = str(Path(file_path).resolve())
        original_len = len(self._recent_files)
        
        self._recent_files = [f for f in self._recent_files if f['path'] != file_path]
        
        if len(self._recent_files) < original_len:
            self._save()
            self._notify_observers()
            logger.debug(f"Removed recent file: {file_path}")
            return True
        
        return False
    
    def clear(self) -> None:
        """Clear all recent files."""
        self._recent_files = []
        self._save()
        self._notify_observers()
        logger.debug("Cleared recent files")
    
    def get_files(self) -> List[dict]:
        """
        Get the list of recent files.
        
        Returns:
            List of file entries (each with 'path', 'title', 'timestamp')
        """
        return list(self._recent_files)  # Return copy
    
    def get_paths(self) -> List[str]:
        """
        Get just the file paths.
        
        Returns:
            List of file paths
        """
        return [f['path'] for f in self._recent_files]
    
    def has_files(self) -> bool:
        """
        Check if there are any recent files.
        
        Returns:
            True if there are recent files
        """
        return len(self._recent_files) > 0
    
    def add_observer(self, callback: Callable) -> None:
        """
        Add an observer to be notified of changes.
        
        Args:
            callback: Function to call when recent files change.
                     Signature: callback(recent_files_manager)
        """
        if callback not in self._observers:
            self._observers.append(callback)
            logger.debug("Added recent files observer")
    
    def remove_observer(self, callback: Callable) -> None:
        """
        Remove an observer.
        
        Args:
            callback: The callback to remove
        """
        if callback in self._observers:
            self._observers.remove(callback)
            logger.debug("Removed recent files observer")
    
    def _notify_observers(self) -> None:
        """Notify all observers of changes."""
        for observer in self._observers[:]:  # Copy list to allow modification
            try:
                observer(self)
            except Exception as e:
                logger.error(f"Error notifying recent files observer: {e}", exc_info=True)
    
    def _load(self) -> None:
        """Load recent files from disk."""
        if not self.config_file.exists():
            logger.debug("No recent files config found")
            return
        
        try:
            with open(self.config_file, 'r') as f:
                data = json.load(f)
                self._recent_files = data.get('recent_files', [])
                
                # Trim to max in case max_files changed
                if len(self._recent_files) > self.max_files:
                    self._recent_files = self._recent_files[:self.max_files]
                
                logger.debug(f"Loaded {len(self._recent_files)} recent files")
        except Exception as e:
            logger.error(f"Error loading recent files: {e}", exc_info=True)
            self._recent_files = []
    
    def _save(self) -> None:
        """Save recent files to disk."""
        try:
            data = {
                'recent_files': self._recent_files,
                'max_files': self.max_files
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug(f"Saved {len(self._recent_files)} recent files")
        except Exception as e:
            logger.error(f"Error saving recent files: {e}", exc_info=True)
    
    def __len__(self) -> int:
        """Get number of recent files."""
        return len(self._recent_files)
    
    def __repr__(self) -> str:
        """String representation."""
        return f"RecentFilesManager({len(self._recent_files)} files, max={self.max_files})"
