"""Document model for Plana Figura Workbench."""

from typing import List, Optional, Dict
import logging

from plana_figura import (
    Geometry,
    GeometryCollection,
    MeasurementCollection
)
from plana_figura.grid import Grid as TheGrid
from plana_figura_workbench.model.folder import Folder, FolderManager

logger = logging.getLogger(__name__)


class Observable:
    """
    Base class for observable objects.

    Provides observer pattern implementation for notifying views of changes.
    """

    def __init__(self) -> None:
        """Initialize the observable."""
        self._observers: List['Observer'] = []

    def add_observer(self, observer: 'Observer') -> None:
        """
        Add an observer to be notified of changes.

        Args:
            observer: The observer to add
        """
        if observer not in self._observers:
            self._observers.append(observer)

    def remove_observer(self, observer: 'Observer') -> None:
        """
        Remove an observer.

        Args:
            observer: The observer to remove
        """
        if observer in self._observers:
            self._observers.remove(observer)

    def _notify_observers(self) -> None:
        """Notify all observers of a change."""
        for observer in self._observers:
            observer.update(self)


class Observer:
    """Base class for observers."""

    def update(self, observable: Observable) -> None:
        """
        Called when the observed object changes.

        Args:
            observable: The object that changed
        """
        raise NotImplementedError


class PlanaFiguraDocument(Observable):
    """
    Represents a single Plana Figura document/project.

    This is the central model class that manages:
    - Multiple GeometryCollection objects
    - Multiple MeasurementCollection objects
    - The master Grid instance
    - Current selection (geometries and measurements)
    - Document modification state

    Attributes:
        name: Document name
        grid: The grid system for this document
        collections: List of geometry collections
        active_collection: Currently active geometry collection
        measurement_collections: Dictionary of measurement collections
        active_measurement_collection: Name of active measurement collection
        selection: Set of currently selected geometries
        measurement_selection: List of selected measurement IDs
        modified: Whether the document has unsaved changes
    """

    def __init__(self, name: str = "Untitled", grid: Optional[TheGrid] = None):
        """
        Initialize a new document.

        Args:
            name: Document name
            grid: Grid system (creates default if None)
        """
        super().__init__()

        self.name = name
        self.grid = grid if grid is not None else TheGrid()
        self.collections: List[GeometryCollection] = []
        self.active_collection: Optional[GeometryCollection] = None
        self.selection: List[Geometry] = []
        self._modified = False

        # Track all geometries in document (for "All Geometries" collection)
        self._all_geometries: List[Geometry] = []

        # Folder management
        self.geometry_folder_manager = FolderManager()
        self.measurement_folder_manager = FolderManager()
        
        # Create default virtual folders for geometries
        self._create_default_geometry_folders()

        # Measurement collections
        self.measurement_collections: Dict[str, MeasurementCollection] = {}
        self.active_measurement_collection: Optional[str] = None
        self.measurement_selection: List[int] = []

        # Create default measurement collection
        default_measurements = MeasurementCollection("Default Measurements")
        self.measurement_collections["Default Measurements"] = (
            default_measurements
        )
        self.active_measurement_collection = "Default Measurements"
        
        # Create default virtual folders for measurements
        self._create_default_measurement_folders()

        logger.info(f"Created new document: {name}")

    @property
    def modified(self) -> bool:
        """Get whether the document has unsaved changes."""
        return self._modified

    @modified.setter
    def modified(self, value: bool) -> None:
        """Set the modified state."""
        self._modified = value

    def add_collection(
        self, collection: GeometryCollection, set_active: bool = True
    ) -> None:
        """
        Add a geometry collection to the document.

        Args:
            collection: The collection to add
            set_active: Whether to set this as the active collection
        """
        self.collections.append(collection)

        if set_active or self.active_collection is None:
            self.active_collection = collection

        self.modified = True
        self._notify_observers()
        logger.info(f"Added collection with {collection.count} geometries")

    def remove_collection(self, collection: GeometryCollection) -> bool:
        """
        Remove a geometry collection from the document.

        Args:
            collection: The collection to remove

        Returns:
            True if collection was removed, False if not found
        """
        if collection not in self.collections:
            return False

        self.collections.remove(collection)

        # Clear active collection if it was removed
        if self.active_collection == collection:
            self.active_collection = (
                self.collections[0] if self.collections else None
            )

        # Clear selection of geometries from removed collection
        self.selection = [
            g for g in self.selection if g not in collection
        ]

        self.modified = True
        self._notify_observers()
        logger.info(f"Removed collection with {collection.count} geometries")
        return True

    def replace_geometry(self, old: Geometry, new: Geometry) -> bool:
        """
        Replace a geometry with a new one (used by commands).

        This is the core method for implementing undo/redo with
        Plana Figura's immutable geometries.

        Args:
            old: The geometry to replace
            new: The new geometry

        Returns:
            True if geometry was found and replaced
        """
        replaced = False

        for collection in self.collections:
            if old in collection:
                # Access internal list for replacement
                idx = collection._geometries.index(old)
                collection._geometries[idx] = new
                collection._envelope = None  # Invalidate cache
                replaced = True

        # Update selection if old geometry was selected
        if old in self.selection:
            idx = self.selection.index(old)
            self.selection[idx] = new

        if replaced:
            self.modified = True
            self._notify_observers()
            logger.debug(f"Replaced geometry: {type(old).__name__}")

        return replaced

    def select_geometries(
        self, geometries: List[Geometry], mode: str = "replace"
    ) -> None:
        """
        Select geometries with different modes.

        Args:
            geometries: Geometries to select
            mode: Selection mode ("replace", "add", "toggle")
        """
        if mode == "replace":
            self.selection = geometries.copy()
        elif mode == "add":
            for geom in geometries:
                if geom not in self.selection:
                    self.selection.append(geom)
        elif mode == "toggle":
            for geom in geometries:
                if geom in self.selection:
                    self.selection.remove(geom)
                else:
                    self.selection.append(geom)

        self._notify_observers()
        logger.debug(f"Selection changed: {len(self.selection)} geometries")

    def clear_selection(self) -> None:
        """Clear the current selection."""
        self.selection.clear()
        self._notify_observers()
        logger.debug("Selection cleared")

    def add_geometry(self, geometry: Geometry) -> None:
        """
        Add a geometry to the document's master list.

        This adds the geometry to the document but not to any collection.
        Use add_geometry_to_collection() to add to a specific collection.

        Args:
            geometry: The geometry to add
        """
        if geometry not in self._all_geometries:
            self._all_geometries.append(geometry)
            self.modified = True
            self._notify_observers()
            logger.debug(
                f"Added {type(geometry).__name__} to document "
                f"(total: {len(self._all_geometries)})"
            )

    def remove_geometry(self, geometry: Geometry) -> bool:
        """
        Remove a geometry from the document entirely.

        This removes it from the master list and all collections.

        Args:
            geometry: The geometry to remove

        Returns:
            True if geometry was removed, False if not found
        """
        if geometry not in self._all_geometries:
            return False

        # Remove from master list
        self._all_geometries.remove(geometry)

        # Remove from all collections
        for collection in self.collections:
            if geometry in collection:
                collection._geometries.remove(geometry)
                collection._envelope = None

        # Remove from selection
        if geometry in self.selection:
            self.selection.remove(geometry)

        self.modified = True
        self._notify_observers()
        logger.debug(f"Removed {type(geometry).__name__} from document")
        return True

    def add_geometry_to_collection(
        self,
        geometry: Geometry,
        collection: GeometryCollection
    ) -> None:
        """
        Add a geometry to a specific collection.

        The geometry must already be in the document's master list.

        Args:
            geometry: The geometry to add
            collection: The collection to add it to
        """
        if geometry not in self._all_geometries:
            self.add_geometry(geometry)

        if collection in self.collections and geometry not in collection:
            collection._geometries.append(geometry)
            collection._envelope = None
            self.modified = True
            self._notify_observers()
            logger.debug(
                f"Added {type(geometry).__name__} to collection "
                f"(collection size: {collection.count})"
            )

    def get_all_geometries(self) -> List[Geometry]:
        """
        Get all geometries in the document.

        This is the "All Geometries" special collection - it shows every
        geometry in the document regardless of collection membership.

        Returns:
            List of all geometries in the document
        """
        return self._all_geometries.copy()

    def get_unclaimed_geometries(self) -> List[Geometry]:
        """
        Get all geometries that are not in any user collection.

        This is the "Unclaimed Geometries" special collection - it shows
        geometries that exist in the document but haven't been added to
        any collection yet.

        Returns:
            List of geometries not in any collection
        """
        claimed_geoms = set()

        # Collect all geometries that are in at least one collection
        for collection in self.collections:
            claimed_geoms.update(collection.geometries)

        # Return geometries that aren't claimed
        return [g for g in self._all_geometries if g not in claimed_geoms]

    def get_geometry_count(self) -> int:
        """
        Get the total number of geometries in the document.

        Returns:
            Total geometry count
        """
        return sum(col.count for col in self.collections)

    def update_grid(self, new_grid: TheGrid) -> None:
        """
        Update the document's grid system.

        Args:
            new_grid: The new grid configuration
        """
        self.grid = new_grid
        self.modified = True
        self._notify_observers()
        logger.info("Grid configuration updated")

    def add_measurement_collection(
        self, name: str, set_active: bool = True
    ) -> MeasurementCollection:
        """
        Add a new measurement collection to the document.

        Args:
            name: Name of the collection
            set_active: Whether to set this as the active collection

        Returns:
            The created MeasurementCollection

        Raises:
            ValueError: If collection with this name already exists
        """
        if name in self.measurement_collections:
            raise ValueError(
                f"Measurement collection '{name}' already exists"
            )

        collection = MeasurementCollection(name)
        self.measurement_collections[name] = collection

        if set_active or self.active_measurement_collection is None:
            self.active_measurement_collection = name

        self.modified = True
        self._notify_observers()
        logger.info(f"Added measurement collection: {name}")
        return collection

    def remove_measurement_collection(self, name: str) -> bool:
        """
        Remove a measurement collection from the document.

        Args:
            name: Name of the collection to remove

        Returns:
            True if collection was removed, False if not found
        """
        if name not in self.measurement_collections:
            return False

        # Don't allow removing the last collection
        if len(self.measurement_collections) == 1:
            logger.warning(
                "Cannot remove last measurement collection"
            )
            return False

        del self.measurement_collections[name]

        # Update active collection if it was removed
        if self.active_measurement_collection == name:
            self.active_measurement_collection = next(
                iter(self.measurement_collections.keys())
            )

        # Clear measurement selection
        self.measurement_selection.clear()

        self.modified = True
        self._notify_observers()
        logger.info(f"Removed measurement collection: {name}")
        return True

    def get_measurement_collection(
        self, name: str
    ) -> Optional[MeasurementCollection]:
        """
        Get a measurement collection by name.

        Args:
            name: Name of the collection

        Returns:
            The MeasurementCollection or None if not found
        """
        return self.measurement_collections.get(name)

    def get_all_measurement_collections(self) -> List[MeasurementCollection]:
        """
        Get all measurement collections.

        Returns:
            List of all measurement collections
        """
        return list(self.measurement_collections.values())

    def set_active_measurement_collection(self, name: str) -> bool:
        """
        Set the active measurement collection.

        Args:
            name: Name of the collection to activate

        Returns:
            True if successful, False if collection not found
        """
        if name not in self.measurement_collections:
            return False

        self.active_measurement_collection = name
        self._notify_observers()
        logger.debug(f"Active measurement collection: {name}")
        return True

    def get_active_measurement_collection(
        self
    ) -> Optional[MeasurementCollection]:
        """
        Get the currently active measurement collection.

        Returns:
            The active MeasurementCollection or None
        """
        if self.active_measurement_collection is None:
            return None
        return self.measurement_collections.get(
            self.active_measurement_collection
        )

    def select_measurements(
        self, measurement_ids: List[int], mode: str = "replace"
    ) -> None:
        """
        Select measurements with different modes.

        Args:
            measurement_ids: Measurement IDs to select
            mode: Selection mode ("replace", "add", "toggle")
        """
        if mode == "replace":
            self.measurement_selection = measurement_ids.copy()
        elif mode == "add":
            for mid in measurement_ids:
                if mid not in self.measurement_selection:
                    self.measurement_selection.append(mid)
        elif mode == "toggle":
            for mid in measurement_ids:
                if mid in self.measurement_selection:
                    self.measurement_selection.remove(mid)
                else:
                    self.measurement_selection.append(mid)

        self._notify_observers()
        logger.debug(
            f"Measurement selection changed: "
            f"{len(self.measurement_selection)} measurements"
        )

    def clear_measurement_selection(self) -> None:
        """Clear the current measurement selection."""
        self.measurement_selection.clear()
        self._notify_observers()
        logger.debug("Measurement selection cleared")

    def get_all_measurements(self) -> List:
        """
        Get all measurements in the document.

        This is the "All Measurements" special collection - it shows every
        measurement in the document regardless of collection membership.

        Returns:
            List of all measurements in the document
        """
        from plana_figura.measurements import Measurement

        all_measurements: List[Measurement] = []
        seen_ids = set()

        # Deduplicate by ID (measurements can be in multiple collections)
        for collection in self.measurement_collections.values():
            for measurement in collection:
                if measurement.id not in seen_ids:
                    all_measurements.append(measurement)
                    seen_ids.add(measurement.id)

        return all_measurements

    def get_unclaimed_measurements(self) -> List:
        """
        Get all measurements that are not in any user collection.

        This is the "Unclaimed Measurements" special collection - it shows
        measurements that exist in the document but haven't been added to
        any named collection yet (only in "Default Measurements").

        Returns:
            List of measurements only in the default collection
        """
        from plana_figura.measurements import Measurement

        # Get measurements from default collection
        default_col = self.measurement_collections.get("Default Measurements")
        if not default_col:
            return []

        default_measurements = set(m.id for m in default_col)

        # Get measurements from all other collections
        claimed_measurements = set()
        for name, collection in self.measurement_collections.items():
            if name != "Default Measurements":
                claimed_measurements.update(m.id for m in collection)

        # Return measurements only in default, not in any other collection
        unclaimed: List[Measurement] = []
        for measurement in default_col:
            if measurement.id not in claimed_measurements:
                unclaimed.append(measurement)

        return unclaimed

    def get_measurement_count(self) -> int:
        """
        Get the total number of unique measurements in the document.

        Returns:
            Total unique measurement count
        """
        return len(self.get_all_measurements())
    
    def _create_default_geometry_folders(self) -> None:
        """Create default virtual folders for geometry organization."""
        # Create Imports folder (virtual)
        imports_folder = self.geometry_folder_manager.create_folder(
            "Imports",
            is_virtual=True
        )
        
        # Create Exports folder (virtual)
        exports_folder = self.geometry_folder_manager.create_folder(
            "Exports",
            is_virtual=True
        )
        
        logger.info("Created default geometry folders: Imports, Exports")
    
    def _create_default_measurement_folders(self) -> None:
        """Create default virtual folders for measurement organization."""
        # Create Imports folder (virtual)
        imports_folder = self.measurement_folder_manager.create_folder(
            "Imports",
            is_virtual=True
        )
        
        # Create Exports folder (virtual)
        exports_folder = self.measurement_folder_manager.create_folder(
            "Exports",
            is_virtual=True
        )
        
        logger.info("Created default measurement folders: Imports, Exports")

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"PlanaFiguraDocument(name='{self.name}', "
            f"collections={len(self.collections)}, "
            f"geometries={self.get_geometry_count()}, "
            f"measurement_collections={len(self.measurement_collections)}, "
            f"measurements={self.get_measurement_count()}, "
            f"modified={self.modified})"
        )
