"""Folder model for organizing collections hierarchically."""

from typing import List, Optional, Union
from plana_figura import GeometryCollection, MeasurementCollection
import logging

logger = logging.getLogger(__name__)


class Folder:
    """
    Represents a folder that can contain collections and other folders.
    
    Folders provide hierarchical organization for collections in the
    Geometry Organizer and Measurement Manager.
    
    Attributes:
        name: Folder name
        parent: Parent folder (None for root folders)
        children: List of child folders
        collections: List of collections in this folder
        is_virtual: Whether this is a virtual/system folder
        expanded: Whether the folder is expanded in the UI
    """
    
    def __init__(
        self,
        name: str,
        parent: Optional['Folder'] = None,
        is_virtual: bool = False
    ):
        """
        Initialize a folder.
        
        Args:
            name: Folder name
            parent: Parent folder
            is_virtual: Whether this is a virtual/system folder
        """
        self.name = name
        self.parent = parent
        self.children: List['Folder'] = []
        self.collections: List[Union[GeometryCollection, MeasurementCollection]] = []
        self.is_virtual = is_virtual
        self.expanded = True  # Folders are expanded by default
        
        logger.debug(f"Created folder: {name} (virtual={is_virtual})")
    
    def add_child(self, folder: 'Folder') -> None:
        """
        Add a child folder.
        
        Args:
            folder: Child folder to add
        """
        if folder not in self.children:
            self.children.append(folder)
            folder.parent = self
            logger.debug(f"Added child folder '{folder.name}' to '{self.name}'")
    
    def remove_child(self, folder: 'Folder') -> bool:
        """
        Remove a child folder.
        
        Args:
            folder: Child folder to remove
            
        Returns:
            True if removed, False if not found
        """
        if folder in self.children:
            self.children.remove(folder)
            folder.parent = None
            logger.debug(f"Removed child folder '{folder.name}' from '{self.name}'")
            return True
        return False
    
    def add_collection(
        self,
        collection: Union[GeometryCollection, MeasurementCollection]
    ) -> None:
        """
        Add a collection to this folder.
        
        Args:
            collection: Collection to add
        """
        if collection not in self.collections:
            self.collections.append(collection)
            logger.debug(f"Added collection to folder '{self.name}'")
    
    def remove_collection(
        self,
        collection: Union[GeometryCollection, MeasurementCollection]
    ) -> bool:
        """
        Remove a collection from this folder.
        
        Args:
            collection: Collection to remove
            
        Returns:
            True if removed, False if not found
        """
        if collection in self.collections:
            self.collections.remove(collection)
            logger.debug(f"Removed collection from folder '{self.name}'")
            return True
        return False
    
    def get_path(self) -> str:
        """
        Get the full path of this folder.
        
        Returns:
            Path string (e.g., "Root/Imports/Survey1")
        """
        if self.parent is None:
            return self.name
        return f"{self.parent.get_path()}/{self.name}"
    
    def find_folder(self, name: str) -> Optional['Folder']:
        """
        Find a child folder by name (recursive).
        
        Args:
            name: Folder name to find
            
        Returns:
            Folder if found, None otherwise
        """
        if self.name == name:
            return self
        
        for child in self.children:
            result = child.find_folder(name)
            if result:
                return result
        
        return None
    
    def get_all_collections(self) -> List[Union[GeometryCollection, MeasurementCollection]]:
        """
        Get all collections in this folder and its children (recursive).
        
        Returns:
            List of all collections
        """
        collections = list(self.collections)
        
        for child in self.children:
            collections.extend(child.get_all_collections())
        
        return collections
    
    def get_collection_count(self) -> int:
        """
        Get total number of collections (including children).
        
        Returns:
            Total collection count
        """
        count = len(self.collections)
        for child in self.children:
            count += child.get_collection_count()
        return count
    
    def __repr__(self) -> str:
        """String representation."""
        return f"Folder('{self.name}', collections={len(self.collections)}, children={len(self.children)})"


class FolderManager:
    """
    Manages folder structure for a document.
    
    Provides methods to create, organize, and query folders.
    """
    
    def __init__(self):
        """Initialize the folder manager."""
        self.root_folders: List[Folder] = []
        logger.debug("Initialized FolderManager")
    
    def create_folder(
        self,
        name: str,
        parent: Optional[Folder] = None,
        is_virtual: bool = False
    ) -> Folder:
        """
        Create a new folder.
        
        Args:
            name: Folder name
            parent: Parent folder (None for root folder)
            is_virtual: Whether this is a virtual/system folder
            
        Returns:
            Created folder
        """
        folder = Folder(name, parent, is_virtual)
        
        if parent is None:
            self.root_folders.append(folder)
        else:
            parent.add_child(folder)
        
        return folder
    
    def find_folder(self, name: str) -> Optional[Folder]:
        """
        Find a folder by name (searches all roots).
        
        Args:
            name: Folder name to find
            
        Returns:
            Folder if found, None otherwise
        """
        for root in self.root_folders:
            result = root.find_folder(name)
            if result:
                return result
        return None
    
    def get_all_folders(self) -> List[Folder]:
        """
        Get all folders (flat list).
        
        Returns:
            List of all folders
        """
        folders = []
        
        def collect_folders(folder: Folder):
            folders.append(folder)
            for child in folder.children:
                collect_folders(child)
        
        for root in self.root_folders:
            collect_folders(root)
        
        return folders
    
    def remove_folder(self, folder: Folder) -> bool:
        """
        Remove a folder.
        
        Args:
            folder: Folder to remove
            
        Returns:
            True if removed, False if not found
        """
        if folder.parent:
            return folder.parent.remove_child(folder)
        elif folder in self.root_folders:
            self.root_folders.remove(folder)
            return True
        return False
