"""Measurement Manager for Plana Figura Workbench.

Manages measurement collections and integrates with DataBucket.
"""

import logging
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .data_bucket import DataBucket

logger = logging.getLogger(__name__)


class MeasurementManager:
    """
    Manages measurement collections for the workbench.
    
    Integrates with DataBucket to share measurement data across plugins.
    """
    
    def __init__(self, data_bucket=None):
        """
        Initialize the Measurement Manager.
        
        Args:
            data_bucket: Optional DataBucket for data sharing
        """
        self.data_bucket = data_bucket
        self._measurement_collections: List = []
        self._active_collection = None
        
        logger.info("Measurement Manager initialized")
    
    def add_collection(self, collection) -> None:
        """
        Add a measurement collection.
        
        Args:
            collection: The measurement collection to add
        """
        if collection not in self._measurement_collections:
            self._measurement_collections.append(collection)
            logger.debug(f"Added measurement collection: {collection}")
            
            # Publish to DataBucket
            self._publish_to_data_bucket()
    
    def remove_collection(self, collection) -> bool:
        """
        Remove a measurement collection.
        
        Args:
            collection: The collection to remove
            
        Returns:
            True if removed, False if not found
        """
        if collection in self._measurement_collections:
            self._measurement_collections.remove(collection)
            
            # Clear active if it was the active collection
            if self._active_collection == collection:
                self._active_collection = None
            
            logger.debug(f"Removed measurement collection: {collection}")
            self._publish_to_data_bucket()
            return True
        
        return False
    
    def get_collections(self) -> List:
        """
        Get all measurement collections.
        
        Returns:
            List of measurement collections
        """
        return list(self._measurement_collections)
    
    def set_active_collection(self, collection) -> None:
        """
        Set the active measurement collection.
        
        Args:
            collection: The collection to make active
        """
        if collection in self._measurement_collections or collection is None:
            self._active_collection = collection
            logger.debug(f"Set active measurement collection: {collection}")
            self._publish_to_data_bucket()
        else:
            logger.warning(f"Cannot set active collection - not in collections list: {collection}")
    
    def get_active_collection(self):
        """
        Get the active measurement collection.
        
        Returns:
            The active collection or None
        """
        return self._active_collection
    
    def clear_collections(self) -> None:
        """Clear all measurement collections."""
        self._measurement_collections = []
        self._active_collection = None
        logger.debug("Cleared all measurement collections")
        self._publish_to_data_bucket()
    
    def _publish_to_data_bucket(self) -> None:
        """Publish measurement data to DataBucket."""
        if self.data_bucket is not None:
            try:
                # Import here to avoid circular dependency
                from plana_figura_workbench.model.data_bucket import DataBucketKeys
                
                self.data_bucket.set(
                    DataBucketKeys.MEASUREMENT_COLLECTIONS,
                    self._measurement_collections,
                    source='measurement_manager'
                )
                
                self.data_bucket.set(
                    DataBucketKeys.ACTIVE_MEASUREMENT_COLLECTION,
                    self._active_collection,
                    source='measurement_manager'
                )
                logger.debug(f"Published to DataBucket: {len(self._measurement_collections)} collections")
            except Exception as e:
                logger.error(f"Error publishing to DataBucket: {e}", exc_info=True)
    
    def __len__(self) -> int:
        """Get number of collections."""
        return len(self._measurement_collections)
    
    def __repr__(self) -> str:
        """String representation."""
        return f"MeasurementManager({len(self._measurement_collections)} collections)"
