"""DXF file writer for exporting Plana Figura geometries."""

import logging
from pathlib import Path
from typing import Optional, Dict, Union
import sys

# Add Local Packages to path for translatio_delineationis_recens
_local_packages = (
    Path(__file__).parent.parent.parent.parent / "Local Packages"
)
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

import translatio_delineationis_recens as tdr

from plana_figura import GeometryCollection, Geometry
from plana_figura_workbench.io.dxf.dxf_config import DXFConfig
from plana_figura_workbench.io.dxf.dxf_mapper import DXFMapper

logger = logging.getLogger(__name__)


class DXFWriter:
    """
    Write Plana Figura geometries to DXF files.
    
    Supports writing single collections or multiple collections as layers.
    Handles coordinate transformation and entity conversion.
    """
    
    def __init__(self, config: Optional[DXFConfig] = None):
        """
        Initialize the DXF writer.
        
        Args:
            config: Configuration for export operations
        """
        self.config = config or DXFConfig.default_export()
        self.mapper = DXFMapper(self.config)
    
    def write_file(self, collection: GeometryCollection, 
                   filepath: Union[str, Path],
                   layer_name: Optional[str] = None) -> None:
        """
        Write a GeometryCollection to a DXF file.
        
        Args:
            collection: GeometryCollection to export
            filepath: Path where DXF file will be saved
            layer_name: Layer name for exported entities (uses config default if None)
            
        Raises:
            ValueError: If export fails
        """
        filepath = Path(filepath)
        layer = layer_name or self.config.export_layer
        
        logger.info(f"Writing {collection.count} geometries to DXF file: {filepath}")
        
        try:
            # Create new DXF document
            doc = tdr.new(self.config.dxf_version.value)
            
            # Set metadata
            if self.config.author:
                try:
                    doc.header['$AUTHOR'] = self.config.author
                except:
                    pass
            
            if self.config.comments:
                try:
                    doc.header['$COMMENTS'] = self.config.comments
                except:
                    pass
            
            # Create layer if it doesn't exist
            if layer not in doc.layers:
                doc.layers.add(layer)
            
            # Get modelspace
            msp = doc.modelspace()
            
            # Export geometries
            self.mapper.reset_stats()
            
            for geometry in collection.geometries:
                self.mapper.export_geometry(geometry, msp, layer)
            
            # Save file
            doc.saveas(str(filepath))
            
            # Log statistics
            stats = self.mapper.get_stats()
            logger.info(f"Export complete: {stats}")
            
            if self.config.verbose:
                logger.info(f"Exported {collection.count} geometries to {filepath.name}")
            
        except Exception as e:
            logger.error(f"Error writing DXF file: {e}")
            raise ValueError(f"Failed to write DXF file: {e}")
    
    def write_with_layers(self, collections: Dict[str, GeometryCollection],
                         filepath: Union[str, Path]) -> None:
        """
        Write multiple collections as separate layers in a DXF file.
        
        Args:
            collections: Dictionary mapping layer names to GeometryCollections
            filepath: Path where DXF file will be saved
            
        Raises:
            ValueError: If export fails
        """
        filepath = Path(filepath)
        
        total_geometries = sum(col.count for col in collections.values())
        logger.info(f"Writing {total_geometries} geometries across "
                   f"{len(collections)} layers to DXF file: {filepath}")
        
        try:
            # Create new DXF document
            doc = tdr.new(self.config.dxf_version.value)
            
            # Set metadata
            if self.config.author:
                try:
                    doc.header['$AUTHOR'] = self.config.author
                except:
                    pass
            
            if self.config.comments:
                try:
                    doc.header['$COMMENTS'] = self.config.comments
                except:
                    pass
            
            # Get modelspace
            msp = doc.modelspace()
            
            # Export each collection to its layer
            self.mapper.reset_stats()
            
            for layer_name, collection in collections.items():
                # Create layer if it doesn't exist
                if layer_name not in doc.layers:
                    doc.layers.add(layer_name)
                
                # Export geometries
                for geometry in collection.geometries:
                    self.mapper.export_geometry(geometry, msp, layer_name)
                
                logger.info(f"Exported {collection.count} geometries to layer '{layer_name}'")
            
            # Save file
            doc.saveas(str(filepath))
            
            # Log statistics
            stats = self.mapper.get_stats()
            logger.info(f"Export complete: {stats}")
            
        except Exception as e:
            logger.error(f"Error writing DXF file: {e}")
            raise ValueError(f"Failed to write DXF file: {e}")
    
    def append_to_file(self, collection: GeometryCollection,
                      filepath: Union[str, Path],
                      layer_name: Optional[str] = None) -> None:
        """
        Append geometries to an existing DXF file.
        
        Args:
            collection: GeometryCollection to append
            filepath: Path to existing DXF file
            layer_name: Layer name for appended entities (uses config default if None)
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If append fails
        """
        filepath = Path(filepath)
        layer = layer_name or self.config.export_layer
        
        if not filepath.exists():
            raise FileNotFoundError(f"DXF file not found: {filepath}")
        
        logger.info(f"Appending {collection.count} geometries to DXF file: {filepath}")
        
        try:
            # Read existing DXF file
            doc = tdr.readfile(str(filepath))
            
            # Create layer if it doesn't exist
            if layer not in doc.layers:
                doc.layers.add(layer)
            
            # Get modelspace
            msp = doc.modelspace()
            
            # Export geometries
            self.mapper.reset_stats()
            
            for geometry in collection.geometries:
                self.mapper.export_geometry(geometry, msp, layer)
            
            # Save file
            doc.saveas(str(filepath))
            
            # Log statistics
            stats = self.mapper.get_stats()
            logger.info(f"Append complete: {stats}")
            
        except Exception as e:
            logger.error(f"Error appending to DXF file: {e}")
            raise ValueError(f"Failed to append to DXF file: {e}")
    
    def get_export_stats(self) -> Dict[str, int]:
        """
        Get statistics from the last export operation.
        
        Returns:
            Dictionary with conversion statistics
        """
        return self.mapper.get_stats()
    
    def set_metadata(self, author: Optional[str] = None, 
                    comments: Optional[str] = None) -> None:
        """
        Set metadata for exported DXF files.
        
        Args:
            author: Author name
            comments: File comments
        """
        if author is not None:
            self.config.author = author
        if comments is not None:
            self.config.comments = comments
