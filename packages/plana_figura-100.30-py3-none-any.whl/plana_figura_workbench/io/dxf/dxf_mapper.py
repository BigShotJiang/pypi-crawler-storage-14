"""Entity mapping between DXF and Plana Figura geometries."""

import logging
import math
from typing import Optional, List, Union
import sys
from pathlib import Path

# Add Local Packages to path for translatio_delineationis_recens
_local_packages = (
    Path(__file__).parent.parent.parent.parent.parent / "Local Packages"
)
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

import translatio_delineationis_recens as tdr

from plana_figura import Point, LineSegment, SimplePolyline, SimplePolygon, Geometry
from plana_figura.linear import CircularArc
from plana_figura_workbench.io.dxf.dxf_config import DXFConfig

logger = logging.getLogger(__name__)


class DXFMapper:
    """
    Maps between DXF entities and Plana Figura geometries.
    
    Handles coordinate transformation and entity conversion in both directions.
    """
    
    def __init__(self, config: Optional[DXFConfig] = None):
        """
        Initialize the mapper.
        
        Args:
            config: Configuration for coordinate transformation and conversion
        """
        self.config = config or DXFConfig.default_import()
        self._conversion_stats = {
            'points': 0,
            'lines': 0,
            'polylines': 0,
            'circles': 0,
            'arcs': 0,
            'unsupported': 0,
            'errors': 0
        }
    
    def get_stats(self) -> dict:
        """Get conversion statistics."""
        return self._conversion_stats.copy()
    
    def reset_stats(self):
        """Reset conversion statistics."""
        for key in self._conversion_stats:
            self._conversion_stats[key] = 0
    
    # ========================================================================
    # Import: DXF → Plana Figura
    # ========================================================================
    
    def convert_dxf_entity(self, entity) -> Optional[Union[Geometry, List[Geometry]]]:
        """
        Convert a DXF entity to Plana Figura geometry.
        
        Args:
            entity: DXF entity object
            
        Returns:
            Plana Figura geometry or list of geometries, or None if unsupported
        """
        entity_type = entity.dxftype()
        
        try:
            if entity_type == "POINT":
                return self._convert_point(entity)
            elif entity_type == "LINE":
                return self._convert_line(entity)
            elif entity_type == "LWPOLYLINE":
                return self._convert_lwpolyline(entity)
            elif entity_type == "POLYLINE":
                return self._convert_polyline(entity)
            elif entity_type == "CIRCLE":
                return self._convert_circle(entity)
            elif entity_type == "ARC":
                return self._convert_arc(entity)
            elif entity_type == "SPLINE":
                return self._convert_spline(entity)
            else:
                if self.config.verbose:
                    logger.debug(f"Unsupported entity type: {entity_type}")
                self._conversion_stats['unsupported'] += 1
                if not self.config.skip_unsupported:
                    raise ValueError(f"Unsupported entity type: {entity_type}")
                return None
                
        except Exception as e:
            logger.error(f"Error converting {entity_type}: {e}")
            self._conversion_stats['errors'] += 1
            if not self.config.skip_unsupported:
                raise
            return None
    
    def _convert_point(self, dxf_point) -> Point:
        """Convert DXF POINT to Plana Figura Point."""
        x, y, z = dxf_point.dxf.location
        northing, easting, elevation = self.config.transform_coordinate(x, y, z)
        
        self._conversion_stats['points'] += 1
        point = Point(northing, easting, elevation)
        
        # Set DXF handle if available
        if hasattr(dxf_point.dxf, 'handle'):
            point.dxf_handle = dxf_point.dxf.handle
        
        return point
    
    def _convert_line(self, dxf_line) -> LineSegment:
        """Convert DXF LINE to Plana Figura LineSegment."""
        # Start point
        x1, y1, z1 = dxf_line.dxf.start
        n1, e1, elev1 = self.config.transform_coordinate(x1, y1, z1)
        start = Point(n1, e1, elev1)
        
        # End point
        x2, y2, z2 = dxf_line.dxf.end
        n2, e2, elev2 = self.config.transform_coordinate(x2, y2, z2)
        end = Point(n2, e2, elev2)
        
        self._conversion_stats['lines'] += 1
        line = LineSegment(start, end)
        
        # Set DXF handle if available
        if hasattr(dxf_line.dxf, 'handle'):
            line.dxf_handle = dxf_line.dxf.handle
        
        return line
    
    def _convert_lwpolyline(self, dxf_lwpoly) -> Union[SimplePolyline, SimplePolygon]:
        """Convert DXF LWPOLYLINE to Plana Figura SimplePolyline or SimplePolygon."""
        points = []
        
        for x, y, start_width, end_width, bulge in dxf_lwpoly:
            # Get elevation from the polyline (constant for all vertices)
            z = dxf_lwpoly.dxf.elevation
            northing, easting, elevation = self.config.transform_coordinate(x, y, z)
            points.append(Point(northing, easting, elevation))
        
        # Check if polyline is closed
        is_closed = dxf_lwpoly.is_closed
        
        self._conversion_stats['polylines'] += 1
        
        if is_closed and len(points) >= 3:
            # Convert to polygon - must close the polygon explicitly
            if not points[0].is_coincident(points[-1]):
                points.append(points[0])  # Close the polygon
            polygon = SimplePolygon(points)
            # Set DXF handle if available
            if hasattr(dxf_lwpoly.dxf, 'handle'):
                polygon.dxf_handle = dxf_lwpoly.dxf.handle
            return polygon
        else:
            # Keep as polyline
            polyline = SimplePolyline(points)
            # Set DXF handle if available
            if hasattr(dxf_lwpoly.dxf, 'handle'):
                polyline.dxf_handle = dxf_lwpoly.dxf.handle
            return polyline
    
    def _convert_polyline(self, dxf_poly) -> Union[SimplePolyline, SimplePolygon]:
        """Convert DXF POLYLINE to Plana Figura SimplePolyline or SimplePolygon."""
        points = []
        
        for vertex in dxf_poly.vertices:
            x, y, z = vertex.dxf.location
            northing, easting, elevation = self.config.transform_coordinate(x, y, z)
            points.append(Point(northing, easting, elevation))
        
        # Check if polyline is closed
        is_closed = dxf_poly.is_closed
        
        self._conversion_stats['polylines'] += 1
        
        if is_closed and len(points) >= 3:
            # Convert to polygon - must close the polygon explicitly
            if not points[0].is_coincident(points[-1]):
                points.append(points[0])  # Close the polygon
            polygon = SimplePolygon(points)
            # Set DXF handle if available
            if hasattr(dxf_poly.dxf, 'handle'):
                polygon.dxf_handle = dxf_poly.dxf.handle
            return polygon
        else:
            # Keep as polyline
            polyline = SimplePolyline(points)
            # Set DXF handle if available
            if hasattr(dxf_poly.dxf, 'handle'):
                polyline.dxf_handle = dxf_poly.dxf.handle
            return polyline
    
    def _convert_circle(self, dxf_circle) -> SimplePolyline:
        """
        Convert DXF CIRCLE to Plana Figura Polyline (approximated).
        
        Note: If a Circle class is added to Plana Figura, this should be updated.
        """
        # Get center and radius
        cx, cy, cz = dxf_circle.dxf.center
        radius = dxf_circle.dxf.radius
        
        # Transform center
        cn, ce, celev = self.config.transform_coordinate(cx, cy, cz)
        
        # Create approximation with segments
        points = []
        num_segments = self.config.curve_segments
        
        for i in range(num_segments + 1):  # +1 to close the circle
            angle = 2 * math.pi * i / num_segments
            
            # Calculate point on circle (in DXF coordinates)
            x = cx + radius * math.cos(angle)
            y = cy + radius * math.sin(angle)
            
            # Transform to Plana Figura coordinates
            northing, easting, elevation = self.config.transform_coordinate(x, y, cz)
            points.append(Point(northing, easting, elevation))
        
        self._conversion_stats['circles'] += 1
        circle_polyline = SimplePolyline(points)
        
        # Set DXF handle if available
        if hasattr(dxf_circle.dxf, 'handle'):
            circle_polyline.dxf_handle = dxf_circle.dxf.handle
        
        return circle_polyline
    
    def _convert_arc(self, dxf_arc) -> Union[CircularArc, SimplePolyline]:
        """
        Convert DXF ARC to Plana Figura CircularArc or SimplePolyline.
        
        If approximate_curves is False, creates a CircularArc.
        If approximate_curves is True, creates a tessellated SimplePolyline.
        """
        # Get center, radius, and angles
        cx, cy, cz = dxf_arc.dxf.center
        radius = dxf_arc.dxf.radius
        start_angle = math.radians(dxf_arc.dxf.start_angle)
        end_angle = math.radians(dxf_arc.dxf.end_angle)
        
        # Handle angle wrapping
        if end_angle < start_angle:
            end_angle += 2 * math.pi
        
        # Transform center point
        cn, ce, celev = self.config.transform_coordinate(cx, cy, cz)
        center = Point(cn, ce, celev)
        
        # Calculate start and end points on the arc
        x_start = cx + radius * math.cos(start_angle)
        y_start = cy + radius * math.sin(start_angle)
        n_start, e_start, elev_start = self.config.transform_coordinate(x_start, y_start, cz)
        start_point = Point(n_start, e_start, elev_start)
        
        x_end = cx + radius * math.cos(end_angle)
        y_end = cy + radius * math.sin(end_angle)
        n_end, e_end, elev_end = self.config.transform_coordinate(x_end, y_end, cz)
        end_point = Point(n_end, e_end, elev_end)
        
        self._conversion_stats['arcs'] += 1
        
        # If not approximating curves, create a CircularArc
        if not self.config.approximate_curves:
            # Calculate the original DXF sweep for logging
            dxf_sweep = end_angle - start_angle
            if dxf_sweep < 0:
                dxf_sweep += 2 * math.pi
            
            logger.info(f"DXF_ARC_IMPORT: DXF center=({cx:.2f}, {cy:.2f}), radius={radius:.2f}")
            logger.info(f"DXF_ARC_IMPORT: DXF start_angle={math.degrees(start_angle):.2f}°, end_angle={math.degrees(end_angle):.2f}°, sweep={math.degrees(dxf_sweep):.2f}°")
            logger.info(f"DXF_ARC_IMPORT: DXF start point=({x_start:.2f}, {y_start:.2f})")
            logger.info(f"DXF_ARC_IMPORT: DXF end point=({x_end:.2f}, {y_end:.2f})")
            logger.info(f"DXF_ARC_IMPORT: Transformed center=({cn:.2f}, {ce:.2f})")
            logger.info(f"DXF_ARC_IMPORT: Transformed start=({n_start:.2f}, {e_start:.2f})")
            logger.info(f"DXF_ARC_IMPORT: Transformed end=({n_end:.2f}, {e_end:.2f})")
            
            # Create the arc with points in correct order (DXF start -> DXF end)
            # Note: CircularArc will recalculate sweep_angle using its own angle convention
            # (atan2(E,N) from North), which differs from DXF (atan2(Y,X) from East).
            # This may result in sweep_angle being the complement (360° - original),
            # but the arc geometry (start/end points) will be correct.
            arc = CircularArc(center, start_point, end_point)
            
            logger.info(
                f"DXF_ARC_IMPORT: Created CircularArc with sweep_angle={math.degrees(arc.sweep_angle):.2f}° "
                f"(DXF sweep was {math.degrees(dxf_sweep):.2f}°)"
            )
            
            # Set DXF handle if available
            if hasattr(dxf_arc.dxf, 'handle'):
                arc.dxf_handle = dxf_arc.dxf.handle
            
            return arc
        
        # Otherwise, create approximation with segments
        logger.debug(f"Tessellating arc with {self.config.curve_segments} segments")
        points = []
        num_segments = self.config.curve_segments
        angle_step = (end_angle - start_angle) / num_segments
        
        for i in range(num_segments + 1):
            angle = start_angle + angle_step * i
            
            # Calculate point on arc (in DXF coordinates)
            x = cx + radius * math.cos(angle)
            y = cy + radius * math.sin(angle)
            
            # Transform to Plana Figura coordinates
            northing, easting, elevation = self.config.transform_coordinate(x, y, cz)
            points.append(Point(northing, easting, elevation))
        
        arc_polyline = SimplePolyline(points)
        # Set DXF handle if available
        if hasattr(dxf_arc.dxf, 'handle'):
            arc_polyline.dxf_handle = dxf_arc.dxf.handle
        
        return arc_polyline
    
    def _convert_spline(self, dxf_spline) -> SimplePolyline:
        """Convert DXF SPLINE to Plana Figura Polyline (approximated)."""
        points = []
        
        # Sample the spline at regular intervals
        num_samples = self.config.curve_segments
        
        try:
            # Use the spline's flattening method to get sample points
            for point in dxf_spline.flattening(distance=None, segments=num_samples):
                x, y, z = point
                northing, easting, elevation = self.config.transform_coordinate(x, y, z)
                points.append(Point(northing, easting, elevation))
        except Exception as e:
            logger.warning(f"Error flattening spline, using control points: {e}")
            # Fallback: use control points
            for point in dxf_spline.control_points:
                x, y, z = point
                northing, easting, elevation = self.config.transform_coordinate(x, y, z)
                points.append(Point(northing, easting, elevation))
        
        self._conversion_stats['polylines'] += 1
        return SimplePolyline(points)
    
    # ========================================================================
    # Export: Plana Figura → DXF
    # ========================================================================
    
    def export_geometry(self, geometry: Geometry, modelspace, layer: Optional[str] = None):
        """
        Export a Plana Figura geometry to DXF modelspace.
        
        Args:
            geometry: Plana Figura geometry to export
            modelspace: DXF modelspace object
            layer: Layer name (uses config default if None)
        """
        layer_name = layer or self.config.export_layer
        
        if isinstance(geometry, Point):
            self._export_point(geometry, modelspace, layer_name)
        elif isinstance(geometry, LineSegment):
            self._export_line_segment(geometry, modelspace, layer_name)
        elif isinstance(geometry, SimplePolygon):
            self._export_polygon(geometry, modelspace, layer_name)
        elif isinstance(geometry, SimplePolyline):
            self._export_polyline(geometry, modelspace, layer_name)
        else:
            logger.warning(f"Unsupported geometry type for export: {type(geometry).__name__}")
            self._conversion_stats['unsupported'] += 1
    
    def _export_point(self, point: Point, modelspace, layer: str):
        """Export Plana Figura Point to DXF POINT."""
        x, y, z = self.config.reverse_transform_coordinate(
            point.northing, point.easting, point.elevation
        )
        
        modelspace.add_point((x, y, z), dxfattribs={'layer': layer})
        self._conversion_stats['points'] += 1
    
    def _export_line_segment(self, line: LineSegment, modelspace, layer: str):
        """Export Plana Figura LineSegment to DXF LINE."""
        x1, y1, z1 = self.config.reverse_transform_coordinate(
            line.start_point.northing,
            line.start_point.easting,
            line.start_point.elevation
        )
        
        x2, y2, z2 = self.config.reverse_transform_coordinate(
            line.end_point.northing,
            line.end_point.easting,
            line.end_point.elevation
        )
        
        modelspace.add_line((x1, y1, z1), (x2, y2, z2), dxfattribs={'layer': layer})
        self._conversion_stats['lines'] += 1
    
    def _export_polyline(self, polyline: SimplePolyline, modelspace, layer: str):
        """Export Plana Figura SimplePolyline to DXF LWPOLYLINE."""
        points_2d = []
        elevation = 0.0
        
        for i, point in enumerate(polyline.points):
            x, y, z = self.config.reverse_transform_coordinate(
                point.northing, point.easting, point.elevation
            )
            points_2d.append((x, y))
            
            # Use the first point's elevation for the entire polyline
            if i == 0:
                elevation = z
        
        modelspace.add_lwpolyline(
            points_2d,
            dxfattribs={
                'layer': layer,
                'elevation': elevation
            }
        )
        self._conversion_stats['polylines'] += 1
    
    def _export_polygon(self, polygon: SimplePolygon, modelspace, layer: str):
        """Export Plana Figura SimplePolygon to DXF LWPOLYLINE (closed)."""
        points_2d = []
        elevation = 0.0
        
        # SimplePolygon has duplicate closing point, so skip the last point
        # DXF uses the 'closed' flag instead
        points_to_export = polygon.points[:-1] if len(polygon.points) > 0 and polygon.points[0].is_coincident(polygon.points[-1]) else polygon.points
        
        for i, point in enumerate(points_to_export):
            x, y, z = self.config.reverse_transform_coordinate(
                point.northing, point.easting, point.elevation
            )
            points_2d.append((x, y))
            
            # Use the first point's elevation for the entire polygon
            if i == 0:
                elevation = z
        
        # Create closed polyline
        lwpoly = modelspace.add_lwpolyline(
            points_2d,
            dxfattribs={
                'layer': layer,
                'elevation': elevation
            }
        )
        lwpoly.close(True)  # Set closed flag
        
        self._conversion_stats['polylines'] += 1
