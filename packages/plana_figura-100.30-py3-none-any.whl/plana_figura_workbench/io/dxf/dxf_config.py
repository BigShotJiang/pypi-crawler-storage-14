"""Configuration settings for DXF import/export operations."""

from dataclasses import dataclass, field
from typing import Optional, Set, List
from enum import Enum


class DXFVersion(Enum):
    """Supported DXF versions for export."""
    R12 = "AC1009"
    R2000 = "AC1015"
    R2004 = "AC1018"
    R2007 = "AC1021"
    R2010 = "AC1024"
    R2013 = "AC1027"
    R2018 = "AC1032"


class CoordinateMapping(Enum):
    """Coordinate system mapping strategies."""
    STANDARD = "standard"  # X=Easting, Y=Northing, Z=Elevation
    SWAPPED = "swapped"    # X=Northing, Y=Easting, Z=Elevation


@dataclass
class DXFConfig:
    """
    Configuration for DXF import/export operations.
    
    Attributes:
        dxf_version: Target DXF version for export
        coordinate_mapping: How to map between DXF and Plana Figura coordinates
        import_layers: Specific layers to import (None = all layers)
        export_layer: Default layer name for exported entities
        import_entity_types: Entity types to import (None = all supported types)
        ignore_elevation: If True, set all Z coordinates to 0
        coordinate_precision: Number of decimal places for coordinates
        scale_factor: Scale factor to apply during import/export
        unit_conversion: Conversion factor for units (e.g., mm to meters)
        approximate_curves: If True, convert curves to polylines
        curve_segments: Number of segments for curve approximation
        skip_unsupported: If True, skip unsupported entities; if False, raise error
        verbose: Enable verbose logging
    """
    
    # Export settings
    dxf_version: DXFVersion = DXFVersion.R2018
    export_layer: str = "0"  # Default layer
    
    # Coordinate system
    coordinate_mapping: CoordinateMapping = CoordinateMapping.STANDARD
    ignore_elevation: bool = False
    coordinate_precision: int = 6
    scale_factor: float = 1.0
    unit_conversion: float = 1.0
    
    # Import settings
    import_layers: Optional[Set[str]] = None
    import_entity_types: Optional[Set[str]] = None
    
    # Curve handling
    approximate_curves: bool = True
    curve_segments: int = 32
    
    # Error handling
    skip_unsupported: bool = True
    verbose: bool = False
    
    # Metadata
    author: str = "Plana Figura"
    comments: str = ""
    
    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.coordinate_precision < 0:
            raise ValueError("coordinate_precision must be non-negative")
        if self.scale_factor <= 0:
            raise ValueError("scale_factor must be positive")
        if self.unit_conversion <= 0:
            raise ValueError("unit_conversion must be positive")
        if self.curve_segments < 3:
            raise ValueError("curve_segments must be at least 3")
    
    @classmethod
    def default_import(cls) -> 'DXFConfig':
        """Create default configuration for import operations."""
        return cls(
            import_layers=None,  # Import all layers
            import_entity_types=None,  # Import all supported types
            skip_unsupported=True,
            verbose=False
        )
    
    @classmethod
    def default_export(cls) -> 'DXFConfig':
        """Create default configuration for export operations."""
        return cls(
            dxf_version=DXFVersion.R2018,
            export_layer="0",
            coordinate_precision=6,
            verbose=False
        )
    
    def should_import_layer(self, layer_name: str) -> bool:
        """
        Check if a layer should be imported.
        
        Args:
            layer_name: Name of the layer
            
        Returns:
            True if layer should be imported
        """
        if self.import_layers is None:
            return True
        return layer_name in self.import_layers
    
    def should_import_entity_type(self, entity_type: str) -> bool:
        """
        Check if an entity type should be imported.
        
        Args:
            entity_type: DXF entity type (e.g., "POINT", "LINE")
            
        Returns:
            True if entity type should be imported
        """
        if self.import_entity_types is None:
            return True
        return entity_type in self.import_entity_types
    
    def transform_coordinate(self, x: float, y: float, z: float) -> tuple[float, float, float]:
        """
        Transform coordinates according to configuration.
        
        Args:
            x: X coordinate (DXF)
            y: Y coordinate (DXF)
            z: Z coordinate (DXF)
            
        Returns:
            Transformed (northing, easting, elevation) for Plana Figura
        """
        # Apply unit conversion and scale
        x = x * self.unit_conversion * self.scale_factor
        y = y * self.unit_conversion * self.scale_factor
        z = z * self.unit_conversion * self.scale_factor if not self.ignore_elevation else 0.0
        
        # Apply coordinate mapping
        if self.coordinate_mapping == CoordinateMapping.STANDARD:
            # DXF: X=Easting, Y=Northing → PF: (Northing, Easting, Elevation)
            northing = y
            easting = x
        else:  # SWAPPED
            # DXF: X=Northing, Y=Easting → PF: (Northing, Easting, Elevation)
            northing = x
            easting = y
        
        elevation = z
        
        # Apply precision
        northing = round(northing, self.coordinate_precision)
        easting = round(easting, self.coordinate_precision)
        elevation = round(elevation, self.coordinate_precision)
        
        return northing, easting, elevation
    
    def reverse_transform_coordinate(self, northing: float, easting: float, 
                                    elevation: float) -> tuple[float, float, float]:
        """
        Reverse transform coordinates for export.
        
        Args:
            northing: Northing coordinate (Plana Figura)
            easting: Easting coordinate (Plana Figura)
            elevation: Elevation (Plana Figura)
            
        Returns:
            Transformed (x, y, z) for DXF
        """
        # Apply coordinate mapping (reverse)
        if self.coordinate_mapping == CoordinateMapping.STANDARD:
            # PF: (Northing, Easting) → DXF: X=Easting, Y=Northing
            x = easting
            y = northing
        else:  # SWAPPED
            # PF: (Northing, Easting) → DXF: X=Northing, Y=Easting
            x = northing
            y = easting
        
        z = elevation if not self.ignore_elevation else 0.0
        
        # Apply scale and unit conversion (reverse)
        x = x / (self.unit_conversion * self.scale_factor)
        y = y / (self.unit_conversion * self.scale_factor)
        z = z / (self.unit_conversion * self.scale_factor) if not self.ignore_elevation else 0.0
        
        # Apply precision
        x = round(x, self.coordinate_precision)
        y = round(y, self.coordinate_precision)
        z = round(z, self.coordinate_precision)
        
        return x, y, z
