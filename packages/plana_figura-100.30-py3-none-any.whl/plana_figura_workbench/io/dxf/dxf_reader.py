"""DXF file reader for importing geometries into Plana Figura."""

import logging
from pathlib import Path
from typing import Optional, List, Dict, Any, Union
import sys

# Add Local Packages to path for translatio_delineationis_recens
_local_packages = (
    Path(__file__).parent.parent.parent.parent / "Local Packages"
)
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

import translatio_delineationis_recens as tdr

from plana_figura import GeometryCollection, Geometry
from plana_figura_workbench.io.dxf.dxf_config import DXFConfig
from plana_figura_workbench.io.dxf.dxf_mapper import DXFMapper

logger = logging.getLogger(__name__)


class DXFReader:
    """
    Read DXF files and convert to Plana Figura geometries.
    
    Supports reading entire files, specific layers, or filtered entity types.
    Handles coordinate transformation and entity conversion.
    """
    
    def __init__(self, config: Optional[DXFConfig] = None):
        """
        Initialize the DXF reader.
        
        Args:
            config: Configuration for import operations
        """
        self.config = config or DXFConfig.default_import()
        self.mapper = DXFMapper(self.config)
        self._last_doc = None
    
    def read_file(self, filepath: Union[str, Path]) -> GeometryCollection:
        """
        Read a DXF file and return all geometries as a collection.
        
        Args:
            filepath: Path to the DXF file
            
        Returns:
            GeometryCollection containing all imported geometries
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file is not a valid DXF file
        """
        filepath = Path(filepath)
        
        if not filepath.exists():
            raise FileNotFoundError(f"DXF file not found: {filepath}")
        
        logger.info(f"Reading DXF file: {filepath}")
        
        try:
            # Read the DXF file
            doc = tdr.readfile(str(filepath))
            self._last_doc = doc
            
            # Get modelspace
            msp = doc.modelspace()
            
            # Convert entities
            collection = GeometryCollection()
            self.mapper.reset_stats()
            
            for entity in msp:
                # Check if we should import this entity
                if not self._should_import_entity(entity):
                    continue
                
                # Convert entity
                geometry = self.mapper.convert_dxf_entity(entity)
                
                if geometry is not None:
                    if isinstance(geometry, list):
                        for geom in geometry:
                            collection.add(geom)
                    else:
                        collection.add(geometry)
            
            # Log statistics
            stats = self.mapper.get_stats()
            logger.info(f"Import complete: {stats}")
            
            if self.config.verbose:
                logger.info(f"Imported {collection.count} geometries from {filepath.name}")
            
            return collection
            
        except Exception as e:
            logger.error(f"Error reading DXF file: {e}")
            raise ValueError(f"Failed to read DXF file: {e}")
    
    def read_layer(self, filepath: Union[str, Path], layer_name: str) -> GeometryCollection:
        """
        Read a specific layer from a DXF file.
        
        Args:
            filepath: Path to the DXF file
            layer_name: Name of the layer to read
            
        Returns:
            GeometryCollection containing geometries from the specified layer
        """
        # Temporarily set layer filter
        original_layers = self.config.import_layers
        self.config.import_layers = {layer_name}
        
        try:
            collection = self.read_file(filepath)
            return collection
        finally:
            # Restore original layer filter
            self.config.import_layers = original_layers
    
    def read_layers(self, filepath: Union[str, Path], 
                   layer_names: List[str]) -> Dict[str, GeometryCollection]:
        """
        Read multiple layers from a DXF file.
        
        Args:
            filepath: Path to the DXF file
            layer_names: List of layer names to read
            
        Returns:
            Dictionary mapping layer names to GeometryCollections
        """
        result = {}
        
        for layer_name in layer_names:
            try:
                collection = self.read_layer(filepath, layer_name)
                result[layer_name] = collection
                logger.info(f"Read layer '{layer_name}': {collection.count} geometries")
            except Exception as e:
                logger.error(f"Error reading layer '{layer_name}': {e}")
                if not self.config.skip_unsupported:
                    raise
        
        return result
    
    def read_all_layers(self, filepath: Union[str, Path]) -> Dict[str, GeometryCollection]:
        """
        Read all layers from a DXF file as separate collections.
        
        Args:
            filepath: Path to the DXF file
            
        Returns:
            Dictionary mapping layer names to GeometryCollections
        """
        filepath = Path(filepath)
        
        if not filepath.exists():
            raise FileNotFoundError(f"DXF file not found: {filepath}")
        
        logger.info(f"Reading all layers from DXF file: {filepath}")
        
        try:
            # Read the DXF file
            doc = tdr.readfile(str(filepath))
            self._last_doc = doc
            
            # Get modelspace
            msp = doc.modelspace()
            
            # Group entities by layer
            layer_entities: Dict[str, List] = {}
            
            for entity in msp:
                if not self._should_import_entity(entity):
                    continue
                
                layer_name = entity.dxf.layer
                if layer_name not in layer_entities:
                    layer_entities[layer_name] = []
                layer_entities[layer_name].append(entity)
            
            # Convert entities for each layer
            result = {}
            self.mapper.reset_stats()
            
            for layer_name, entities in layer_entities.items():
                collection = GeometryCollection()
                
                for entity in entities:
                    geometry = self.mapper.convert_dxf_entity(entity)
                    
                    if geometry is not None:
                        if isinstance(geometry, list):
                            for geom in geometry:
                                collection.add(geom)
                        else:
                            collection.add(geometry)
                
                result[layer_name] = collection
                logger.info(f"Layer '{layer_name}': {collection.count} geometries")
            
            # Log statistics
            stats = self.mapper.get_stats()
            logger.info(f"Import complete: {stats}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error reading DXF file: {e}")
            raise ValueError(f"Failed to read DXF file: {e}")
    
    def get_layers(self, filepath: Union[str, Path]) -> List[str]:
        """
        Get list of layer names in a DXF file.
        
        Args:
            filepath: Path to the DXF file
            
        Returns:
            List of layer names
        """
        filepath = Path(filepath)
        
        if not filepath.exists():
            raise FileNotFoundError(f"DXF file not found: {filepath}")
        
        try:
            doc = tdr.readfile(str(filepath))
            self._last_doc = doc
            
            # Get all layer names
            layers = [layer.dxf.name for layer in doc.layers]
            
            logger.info(f"Found {len(layers)} layers in {filepath.name}")
            return layers
            
        except Exception as e:
            logger.error(f"Error reading DXF file: {e}")
            raise ValueError(f"Failed to read DXF file: {e}")
    
    def get_metadata(self, filepath: Union[str, Path]) -> Dict[str, Any]:
        """
        Extract metadata from a DXF file.
        
        Args:
            filepath: Path to the DXF file
            
        Returns:
            Dictionary containing file metadata
        """
        filepath = Path(filepath)
        
        if not filepath.exists():
            raise FileNotFoundError(f"DXF file not found: {filepath}")
        
        try:
            doc = tdr.readfile(str(filepath))
            self._last_doc = doc
            
            metadata = {
                'filename': filepath.name,
                'filepath': str(filepath),
                'dxf_version': doc.dxfversion,
                'encoding': doc.encoding,
                'layer_count': len(doc.layers),
                'layers': [layer.dxf.name for layer in doc.layers],
            }
            
            # Try to get header variables
            try:
                header = doc.header
                metadata['units'] = header.get('$INSUNITS', 'Unknown')
                metadata['author'] = header.get('$AUTHOR', '')
                metadata['comments'] = header.get('$COMMENTS', '')
            except Exception as e:
                logger.debug(f"Could not read header variables: {e}")
            
            # Count entities by type
            msp = doc.modelspace()
            entity_counts = {}
            for entity in msp:
                entity_type = entity.dxftype()
                entity_counts[entity_type] = entity_counts.get(entity_type, 0) + 1
            
            metadata['entity_counts'] = entity_counts
            metadata['total_entities'] = sum(entity_counts.values())
            
            return metadata
            
        except Exception as e:
            logger.error(f"Error reading DXF metadata: {e}")
            raise ValueError(f"Failed to read DXF metadata: {e}")
    
    def get_import_stats(self) -> Dict[str, int]:
        """
        Get statistics from the last import operation.
        
        Returns:
            Dictionary with conversion statistics
        """
        return self.mapper.get_stats()
    
    def _should_import_entity(self, entity) -> bool:
        """
        Check if an entity should be imported based on configuration.
        
        Args:
            entity: DXF entity
            
        Returns:
            True if entity should be imported
        """
        # Check layer filter
        if not self.config.should_import_layer(entity.dxf.layer):
            return False
        
        # Check entity type filter
        if not self.config.should_import_entity_type(entity.dxftype()):
            return False
        
        return True
