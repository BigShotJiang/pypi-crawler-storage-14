"""
Entry point for running Plana Figura Workbench as a module or executable.

This allows running the workbench with:
    python -m plana_figura_workbench
Or when packaged as an executable with PyInstaller.
"""

from plana_figura_workbench.workbench_app import main

if __name__ == "__main__":
    main()
