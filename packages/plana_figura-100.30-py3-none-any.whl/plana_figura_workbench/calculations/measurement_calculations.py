"""
Calculation utilities for measurements.

Provides functions for angle, direction, distance, vector, and coordinate calculations.
"""

import math
from typing import Tuple, Optional
from plana_figura import DecimalDegreesAngle


class AngleCalculations:
    """Utilities for angle calculations."""

    @staticmethod
    def add_angles(angle1: DecimalDegreesAngle, angle2: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """
        Add two angles.

        Args:
            angle1: First angle
            angle2: Second angle

        Returns:
            Sum of angles (normalized to 0-360°)
        """
        result = angle1.angle_degrees + angle2.angle_degrees
        return DecimalDegreesAngle(result % 360.0)

    @staticmethod
    def subtract_angles(angle1: DecimalDegreesAngle, angle2: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """
        Subtract angle2 from angle1.

        Args:
            angle1: First angle
            angle2: Second angle to subtract

        Returns:
            Difference of angles (normalized to 0-360°)
        """
        result = angle1.angle_degrees - angle2.angle_degrees
        return DecimalDegreesAngle(result % 360.0)

    @staticmethod
    def normalize_angle(angle: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """
        Normalize angle to 0-360° range.

        Args:
            angle: Angle to normalize

        Returns:
            Normalized angle
        """
        return DecimalDegreesAngle(angle.angle_degrees % 360.0)

    @staticmethod
    def complement_angle(angle: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """
        Calculate complement of angle (90° - angle).

        Args:
            angle: Angle

        Returns:
            Complement angle
        """
        return DecimalDegreesAngle(90.0 - angle.angle_degrees)

    @staticmethod
    def supplement_angle(angle: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """
        Calculate supplement of angle (180° - angle).

        Args:
            angle: Angle

        Returns:
            Supplement angle
        """
        return DecimalDegreesAngle(180.0 - angle.angle_degrees)

    @staticmethod
    def multiply_angle(angle: DecimalDegreesAngle, factor: float) -> DecimalDegreesAngle:
        """
        Multiply angle by a factor.

        Args:
            angle: Angle
            factor: Multiplication factor

        Returns:
            Multiplied angle (normalized)
        """
        result = angle.angle_degrees * factor
        return DecimalDegreesAngle(result % 360.0)

    @staticmethod
    def divide_angle(angle: DecimalDegreesAngle, divisor: float) -> DecimalDegreesAngle:
        """
        Divide angle by a divisor.

        Args:
            angle: Angle
            divisor: Division factor

        Returns:
            Divided angle

        Raises:
            ValueError: If divisor is zero
        """
        if divisor == 0:
            raise ValueError("Cannot divide by zero")
        return DecimalDegreesAngle(angle.angle_degrees / divisor)

    @staticmethod
    def average_angles(*angles: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """
        Calculate average of multiple angles.

        Uses vector averaging to handle angles near 0°/360° correctly.

        Args:
            *angles: Variable number of angles

        Returns:
            Average angle

        Raises:
            ValueError: If no angles provided
        """
        if not angles:
            raise ValueError("At least one angle required")

        # Convert to unit vectors and average
        x_sum = sum(math.cos(math.radians(a.angle_degrees)) for a in angles)
        y_sum = sum(math.sin(math.radians(a.angle_degrees)) for a in angles)

        avg_x = x_sum / len(angles)
        avg_y = y_sum / len(angles)

        # Convert back to angle
        avg_angle = math.degrees(math.atan2(avg_y, avg_x))
        if avg_angle < 0:
            avg_angle += 360.0

        return DecimalDegreesAngle(avg_angle)


class DirectionCalculations:
    """Utilities for direction calculations."""

    @staticmethod
    def azimuth_to_bearing(azimuth: DecimalDegreesAngle) -> Tuple[str, float, str]:
        """
        Convert azimuth to bearing notation.

        Args:
            azimuth: Azimuth angle (0-360° from north, clockwise)

        Returns:
            Tuple of (start_quadrant, degrees, end_quadrant)
            e.g., ("N", 45.5, "E") for N 45° 30' 0" E
        """
        az = azimuth.angle_degrees % 360.0

        if az <= 90.0:
            # NE quadrant
            return ("N", az, "E")
        elif az <= 180.0:
            # SE quadrant
            return ("S", 180.0 - az, "E")
        elif az <= 270.0:
            # SW quadrant
            return ("S", az - 180.0, "W")
        else:
            # NW quadrant
            return ("N", 360.0 - az, "W")

    @staticmethod
    def bearing_to_azimuth(start: str, degrees: float, end: str) -> DecimalDegreesAngle:
        """
        Convert bearing notation to azimuth.

        Args:
            start: Start quadrant ("N" or "S")
            degrees: Degrees (0-90)
            end: End quadrant ("E" or "W")

        Returns:
            Azimuth angle

        Raises:
            ValueError: If invalid quadrants or degrees
        """
        if start not in ["N", "S"]:
            raise ValueError("Start quadrant must be N or S")
        if end not in ["E", "W"]:
            raise ValueError("End quadrant must be E or W")
        if degrees < 0 or degrees > 90:
            raise ValueError("Bearing degrees must be between 0 and 90")

        if start == "N" and end == "E":
            azimuth = degrees
        elif start == "S" and end == "E":
            azimuth = 180.0 - degrees
        elif start == "S" and end == "W":
            azimuth = 180.0 + degrees
        else:  # N and W
            azimuth = 360.0 - degrees

        return DecimalDegreesAngle(azimuth)

    @staticmethod
    def reverse_azimuth(azimuth: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """
        Calculate reverse (back) azimuth.

        Args:
            azimuth: Forward azimuth

        Returns:
            Reverse azimuth (forward + 180°, normalized)
        """
        reverse = (azimuth.angle_degrees + 180.0) % 360.0
        return DecimalDegreesAngle(reverse)

    @staticmethod
    def deflection_angle(
        back_azimuth: DecimalDegreesAngle,
        forward_azimuth: DecimalDegreesAngle,
        direction: str = "right"
    ) -> DecimalDegreesAngle:
        """
        Calculate deflection angle.

        Args:
            back_azimuth: Azimuth of back line
            forward_azimuth: Azimuth of forward line
            direction: "right" or "left"

        Returns:
            Deflection angle

        Raises:
            ValueError: If invalid direction
        """
        if direction not in ["right", "left"]:
            raise ValueError("Direction must be 'right' or 'left'")

        diff = forward_azimuth.angle_degrees - back_azimuth.angle_degrees

        if direction == "right":
            if diff < 0:
                diff += 360.0
        else:  # left
            if diff > 0:
                diff -= 360.0
            diff = abs(diff)

        return DecimalDegreesAngle(diff)

    @staticmethod
    def interior_angle(
        back_azimuth: DecimalDegreesAngle,
        forward_azimuth: DecimalDegreesAngle
    ) -> DecimalDegreesAngle:
        """
        Calculate interior angle at a point.

        Args:
            back_azimuth: Azimuth to back point
            forward_azimuth: Azimuth to forward point

        Returns:
            Interior angle (0-180°)
        """
        # Reverse the back azimuth
        reversed_back = DirectionCalculations.reverse_azimuth(back_azimuth)

        # Calculate difference
        diff = abs(forward_azimuth.angle_degrees - reversed_back.angle_degrees)

        # Normalize to 0-180°
        if diff > 180.0:
            diff = 360.0 - diff

        return DecimalDegreesAngle(diff)


class DistanceCalculations:
    """Utilities for distance calculations."""

    @staticmethod
    def horizontal_from_slope(
        slope_distance: float,
        vertical_angle: DecimalDegreesAngle
    ) -> float:
        """
        Calculate horizontal distance from slope distance and vertical angle.

        Args:
            slope_distance: Slope distance
            vertical_angle: Vertical angle from horizontal

        Returns:
            Horizontal distance
        """
        angle_rad = math.radians(vertical_angle.angle_degrees)
        return slope_distance * math.cos(angle_rad)

    @staticmethod
    def vertical_from_slope(
        slope_distance: float,
        vertical_angle: DecimalDegreesAngle
    ) -> float:
        """
        Calculate vertical distance from slope distance and vertical angle.

        Args:
            slope_distance: Slope distance
            vertical_angle: Vertical angle from horizontal

        Returns:
            Vertical distance
        """
        angle_rad = math.radians(vertical_angle.angle_degrees)
        return slope_distance * math.sin(angle_rad)

    @staticmethod
    def slope_from_horizontal_vertical(
        horizontal_distance: float,
        vertical_distance: float
    ) -> float:
        """
        Calculate slope distance from horizontal and vertical distances.

        Args:
            horizontal_distance: Horizontal distance
            vertical_distance: Vertical distance

        Returns:
            Slope distance
        """
        return math.sqrt(horizontal_distance**2 + vertical_distance**2)

    @staticmethod
    def vertical_angle_from_distances(
        horizontal_distance: float,
        vertical_distance: float
    ) -> DecimalDegreesAngle:
        """
        Calculate vertical angle from horizontal and vertical distances.

        Args:
            horizontal_distance: Horizontal distance
            vertical_distance: Vertical distance

        Returns:
            Vertical angle from horizontal

        Raises:
            ValueError: If horizontal distance is zero
        """
        if horizontal_distance == 0:
            raise ValueError("Horizontal distance cannot be zero")

        angle_rad = math.atan2(vertical_distance, horizontal_distance)
        return DecimalDegreesAngle(math.degrees(angle_rad))

    @staticmethod
    def scale_distance(distance: float, scale_factor: float) -> float:
        """
        Apply scale factor to distance.

        Args:
            distance: Original distance
            scale_factor: Scale factor

        Returns:
            Scaled distance
        """
        return distance * scale_factor


class VectorCalculations:
    """Utilities for 3D vector calculations."""

    @staticmethod
    def add_vectors(
        v1: Tuple[float, float, float],
        v2: Tuple[float, float, float]
    ) -> Tuple[float, float, float]:
        """
        Add two 3D vectors.

        Args:
            v1: First vector (N, E, Z)
            v2: Second vector (N, E, Z)

        Returns:
            Sum vector
        """
        return (v1[0] + v2[0], v1[1] + v2[1], v1[2] + v2[2])

    @staticmethod
    def subtract_vectors(
        v1: Tuple[float, float, float],
        v2: Tuple[float, float, float]
    ) -> Tuple[float, float, float]:
        """
        Subtract v2 from v1.

        Args:
            v1: First vector (N, E, Z)
            v2: Second vector to subtract (N, E, Z)

        Returns:
            Difference vector
        """
        return (v1[0] - v2[0], v1[1] - v2[1], v1[2] - v2[2])

    @staticmethod
    def scale_vector(
        v: Tuple[float, float, float],
        scale: float
    ) -> Tuple[float, float, float]:
        """
        Scale a vector by a factor.

        Args:
            v: Vector (N, E, Z)
            scale: Scale factor

        Returns:
            Scaled vector
        """
        return (v[0] * scale, v[1] * scale, v[2] * scale)

    @staticmethod
    def magnitude(v: Tuple[float, float, float]) -> float:
        """
        Calculate magnitude (length) of vector.

        Args:
            v: Vector (N, E, Z)

        Returns:
            Magnitude
        """
        return math.sqrt(v[0]**2 + v[1]**2 + v[2]**2)

    @staticmethod
    def unit_vector(v: Tuple[float, float, float]) -> Tuple[float, float, float]:
        """
        Calculate unit vector (normalized to length 1).

        Args:
            v: Vector (N, E, Z)

        Returns:
            Unit vector

        Raises:
            ValueError: If vector has zero magnitude
        """
        mag = VectorCalculations.magnitude(v)
        if mag == 0:
            raise ValueError("Cannot normalize zero vector")
        return (v[0] / mag, v[1] / mag, v[2] / mag)

    @staticmethod
    def dot_product(
        v1: Tuple[float, float, float],
        v2: Tuple[float, float, float]
    ) -> float:
        """
        Calculate dot product of two vectors.

        Args:
            v1: First vector (N, E, Z)
            v2: Second vector (N, E, Z)

        Returns:
            Dot product
        """
        return v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]

    @staticmethod
    def cross_product(
        v1: Tuple[float, float, float],
        v2: Tuple[float, float, float]
    ) -> Tuple[float, float, float]:
        """
        Calculate cross product of two vectors.

        Args:
            v1: First vector (N, E, Z)
            v2: Second vector (N, E, Z)

        Returns:
            Cross product vector
        """
        return (
            v1[1] * v2[2] - v1[2] * v2[1],
            v1[2] * v2[0] - v1[0] * v2[2],
            v1[0] * v2[1] - v1[1] * v2[0]
        )

    @staticmethod
    def angle_between(
        v1: Tuple[float, float, float],
        v2: Tuple[float, float, float]
    ) -> DecimalDegreesAngle:
        """
        Calculate angle between two vectors.

        Args:
            v1: First vector (N, E, Z)
            v2: Second vector (N, E, Z)

        Returns:
            Angle between vectors

        Raises:
            ValueError: If either vector has zero magnitude
        """
        mag1 = VectorCalculations.magnitude(v1)
        mag2 = VectorCalculations.magnitude(v2)

        if mag1 == 0 or mag2 == 0:
            raise ValueError("Cannot calculate angle with zero vector")

        dot = VectorCalculations.dot_product(v1, v2)
        cos_angle = dot / (mag1 * mag2)

        # Clamp to [-1, 1] to handle floating point errors
        cos_angle = max(-1.0, min(1.0, cos_angle))

        angle_rad = math.acos(cos_angle)
        return DecimalDegreesAngle(math.degrees(angle_rad))

    @staticmethod
    def horizontal_distance(v: Tuple[float, float, float]) -> float:
        """
        Calculate horizontal distance (ignoring Z component).

        Args:
            v: Vector (N, E, Z)

        Returns:
            Horizontal distance
        """
        return math.sqrt(v[0]**2 + v[1]**2)

    @staticmethod
    def azimuth(v: Tuple[float, float, float]) -> DecimalDegreesAngle:
        """
        Calculate azimuth of vector (from north, clockwise).

        Args:
            v: Vector (N, E, Z)

        Returns:
            Azimuth angle

        Raises:
            ValueError: If horizontal component is zero
        """
        horiz_dist = VectorCalculations.horizontal_distance(v)
        if horiz_dist == 0:
            raise ValueError("Cannot calculate azimuth for vertical vector")

        azimuth_rad = math.atan2(v[1], v[0])
        azimuth_deg = math.degrees(azimuth_rad)

        if azimuth_deg < 0:
            azimuth_deg += 360.0

        return DecimalDegreesAngle(azimuth_deg)

    @staticmethod
    def vertical_angle(v: Tuple[float, float, float]) -> DecimalDegreesAngle:
        """
        Calculate vertical angle from horizontal.

        Args:
            v: Vector (N, E, Z)

        Returns:
            Vertical angle from horizontal
        """
        horiz_dist = VectorCalculations.horizontal_distance(v)
        if horiz_dist == 0:
            # Vertical vector
            return DecimalDegreesAngle(90.0 if v[2] > 0 else -90.0)

        angle_rad = math.atan2(v[2], horiz_dist)
        return DecimalDegreesAngle(math.degrees(angle_rad))


class CoordinateCalculations:
    """Utilities for coordinate calculations."""

    @staticmethod
    def forward_calculation(
        start_n: float,
        start_e: float,
        azimuth: DecimalDegreesAngle,
        distance: float
    ) -> Tuple[float, float]:
        """
        Calculate end coordinates from start, azimuth, and distance.

        Args:
            start_n: Starting northing
            start_e: Starting easting
            azimuth: Azimuth angle
            distance: Distance

        Returns:
            Tuple of (end_northing, end_easting)
        """
        azimuth_rad = math.radians(azimuth.angle_degrees)
        delta_n = distance * math.cos(azimuth_rad)
        delta_e = distance * math.sin(azimuth_rad)

        return (start_n + delta_n, start_e + delta_e)

    @staticmethod
    def inverse_calculation(
        start_n: float,
        start_e: float,
        end_n: float,
        end_e: float
    ) -> Tuple[DecimalDegreesAngle, float]:
        """
        Calculate azimuth and distance between two points.

        Args:
            start_n: Starting northing
            start_e: Starting easting
            end_n: Ending northing
            end_e: Ending easting

        Returns:
            Tuple of (azimuth, distance)
        """
        delta_n = end_n - start_n
        delta_e = end_e - start_e

        distance = math.sqrt(delta_n**2 + delta_e**2)

        if distance == 0:
            # Same point
            return (DecimalDegreesAngle(0.0), 0.0)

        azimuth_rad = math.atan2(delta_e, delta_n)
        azimuth_deg = math.degrees(azimuth_rad)

        if azimuth_deg < 0:
            azimuth_deg += 360.0

        return (DecimalDegreesAngle(azimuth_deg), distance)

    @staticmethod
    def traverse_calculation(
        start_n: float,
        start_e: float,
        courses: list[Tuple[DecimalDegreesAngle, float]]
    ) -> list[Tuple[float, float]]:
        """
        Calculate coordinates for a traverse.

        Args:
            start_n: Starting northing
            start_e: Starting easting
            courses: List of (azimuth, distance) tuples

        Returns:
            List of (northing, easting) tuples for each point
        """
        points = [(start_n, start_e)]
        current_n, current_e = start_n, start_e

        for azimuth, distance in courses:
            current_n, current_e = CoordinateCalculations.forward_calculation(
                current_n, current_e, azimuth, distance
            )
            points.append((current_n, current_e))

        return points

    @staticmethod
    def area_from_coordinates(
        coordinates: list[Tuple[float, float]]
    ) -> float:
        """
        Calculate area of polygon from coordinates using shoelace formula.

        Args:
            coordinates: List of (northing, easting) tuples

        Returns:
            Area (positive for counter-clockwise, negative for clockwise)

        Raises:
            ValueError: If less than 3 points provided
        """
        if len(coordinates) < 3:
            raise ValueError("At least 3 points required for area calculation")

        area = 0.0
        n = len(coordinates)

        for i in range(n):
            j = (i + 1) % n
            area += coordinates[i][0] * coordinates[j][1]
            area -= coordinates[j][0] * coordinates[i][1]

        return abs(area) / 2.0

    @staticmethod
    def centroid_from_coordinates(
        coordinates: list[Tuple[float, float]]
    ) -> Tuple[float, float]:
        """
        Calculate centroid of polygon from coordinates.

        Args:
            coordinates: List of (northing, easting) tuples

        Returns:
            Tuple of (centroid_northing, centroid_easting)

        Raises:
            ValueError: If no points provided
        """
        if not coordinates:
            raise ValueError("At least one point required")

        n = len(coordinates)
        sum_n = sum(coord[0] for coord in coordinates)
        sum_e = sum(coord[1] for coord in coordinates)

        return (sum_n / n, sum_e / n)
