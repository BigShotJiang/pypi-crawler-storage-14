"""Workbench-specific exceptions for Plana Figura Workbench."""

from plana_figura.exceptions import PlanaFiguraError


class FileIOError(PlanaFiguraError):
    """File import/export errors."""
    pass


class UIError(PlanaFiguraError):
    """User interface errors."""
    pass


class SystemError(PlanaFiguraError):
    """System-level errors (memory, permissions, etc.)."""
    pass


class CommandError(PlanaFiguraError):
    """Command execution errors."""
    pass


class PluginError(PlanaFiguraError):
    """Plugin-related errors."""
    pass


class DialogError(UIError):
    """Dialog-specific errors."""
    pass


class ValidationError(PlanaFiguraError):
    """Workbench-level validation errors (distinct from core ValidationError)."""
    pass
