"""Mixin class for controllers to implement the Firewall pattern."""

import logging
from typing import Optional, Dict, Any, Callable

from plana_figura.exceptions import PlanaFiguraError, GeometryError, ValidationError as CoreValidationError
from plana_figura_workbench.exceptions import CommandError, UIError
from plana_figura_workbench.error_handling import ErrorDialogManager
from plana_figura_workbench.logging_config import log_error_with_context


class ControllerErrorMixin:
    """
    Mixin class that implements the Firewall pattern for controllers.
    
    This mixin provides methods for controllers to safely execute operations
    that might raise Core exceptions, translating them into UI-appropriate actions.
    """
    
    def __init__(self):
        self.error_dialog_manager = ErrorDialogManager()
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def safe_execute_command(self, command, recovery_options: Optional[list] = None) -> bool:
        """
        Safely execute a command with error handling.
        
        This method implements the Firewall pattern - it catches Core exceptions
        from commands and translates them into user-friendly dialogs.
        
        Args:
            command: Command to execute
            recovery_options: Optional recovery options for error dialog
            
        Returns:
            True if command executed successfully, False otherwise
        """
        try:
            return command.execute()
            
        except CommandError as cmd_error:
            # Command already caught and wrapped the Core error
            self._handle_command_error(cmd_error, recovery_options)
            return False
            
        except (GeometryError, CoreValidationError, PlanaFiguraError) as core_error:
            # This shouldn't happen if commands are properly implemented,
            # but provides a safety net
            self.logger.error(f"Core error leaked through command: {core_error}")
            
            # Wrap and handle as command error
            cmd_error = CommandError(
                f"Operation failed: {core_error}",
                error_code=getattr(core_error, 'error_code', 'CONTROLLER_CORE_ERROR'),
                context={'original_error': str(core_error)}
            )
            self._handle_command_error(cmd_error, recovery_options)
            return False
            
        except Exception as unexpected_error:
            # Handle any other unexpected errors
            self.logger.error(f"Unexpected error in controller: {unexpected_error}")
            
            error = UIError(
                f"Unexpected error: {unexpected_error}",
                error_code='CONTROLLER_UNEXPECTED_ERROR',
                context={'error': str(unexpected_error)}
            )
            self._handle_ui_error(error)
            return False
    
    def safe_execute_operation(self, operation: Callable, *args, **kwargs) -> Any:
        """
        Safely execute a Core operation with error handling.
        
        This method should be used when controllers need to call Core library
        functions directly (not through commands).
        
        Args:
            operation: Core operation to execute
            *args: Arguments for the operation
            **kwargs: Keyword arguments for the operation
            
        Returns:
            Result of the operation, or None if it failed
        """
        try:
            return operation(*args, **kwargs)
            
        except (GeometryError, CoreValidationError, PlanaFiguraError) as core_error:
            # This is the Firewall - catch Core exceptions
            self.logger.error(f"Core error in operation: {core_error}")
            
            # Show user-friendly error dialog
            self.error_dialog_manager.show_error(core_error, parent=getattr(self, 'parent', None))
            return None
            
        except Exception as unexpected_error:
            # Handle unexpected errors
            self.logger.error(f"Unexpected error in operation: {unexpected_error}")
            
            error = UIError(
                f"Operation failed: {unexpected_error}",
                error_code='OPERATION_UNEXPECTED_ERROR',
                context={'operation': operation.__name__, 'error': str(unexpected_error)}
            )
            self.error_dialog_manager.show_error(error, parent=getattr(self, 'parent', None))
            return None
    
    def _handle_command_error(self, error: CommandError, recovery_options: Optional[list] = None):
        """Handle command errors with appropriate UI response."""
        # Log the error with full context
        log_error_with_context(self.logger, error)
        
        # Show error dialog with recovery options if available
        result = self.error_dialog_manager.show_error(
            error, 
            parent=getattr(self, 'parent', None),
            recovery_options=recovery_options
        )
        
        # Handle recovery option selection
        if result and recovery_options:
            self._handle_recovery_option(result)
    
    def _handle_ui_error(self, error: UIError):
        """Handle UI errors."""
        log_error_with_context(self.logger, error)
        self.error_dialog_manager.show_error(error, parent=getattr(self, 'parent', None))
    
    def _handle_recovery_option(self, recovery_option: Dict[str, Any]):
        """
        Handle user selection of recovery option.
        
        This method should be overridden in controllers that provide
        recovery options.
        
        Args:
            recovery_option: Selected recovery option
        """
        if 'callback' in recovery_option:
            try:
                recovery_option['callback']()
            except Exception as e:
                self.logger.error(f"Recovery option callback failed: {e}")
    
    def create_recovery_options(self, error_code: str) -> Optional[list]:
        """
        Create recovery options for specific error codes.
        
        This method should be overridden in controllers to provide
        context-specific recovery options.
        
        Args:
            error_code: The error code to create recovery options for
            
        Returns:
            List of recovery options or None
        """
        # Default recovery options for common errors
        if error_code == "GEOMETRY_INTERSECTION_FAILED":
            return [
                {
                    'text': 'Try Simple Intersection',
                    'callback': lambda: self._try_simple_intersection()
                },
                {
                    'text': 'Create Point at Midpoint',
                    'callback': lambda: self._create_midpoint()
                }
            ]
        
        return None
    
    def _try_simple_intersection(self):
        """Default recovery option - try simple intersection."""
        # This is a placeholder - actual implementation would depend on context
        self.logger.info("Attempting simple intersection recovery")
    
    def _create_midpoint(self):
        """Default recovery option - create midpoint."""
        # This is a placeholder - actual implementation would depend on context
        self.logger.info("Creating midpoint as recovery option")


# Example usage in a controller
class ExampleController(ControllerErrorMixin):
    """Example controller demonstrating error handling patterns."""
    
    def __init__(self, document, parent=None):
        super().__init__()
        self.document = document
        self.parent = parent
    
    def add_geometry_with_error_handling(self, geometry_data):
        """Example method showing how to use the error handling mixin."""
        from plana_figura_workbench.commands.geometry_commands import AddGeometryCommand
        
        # Create command
        command = AddGeometryCommand(self.document, geometry_data)
        
        # Create recovery options for this specific operation
        recovery_options = self.create_recovery_options('GEOMETRY_CREATION_FAILED')
        
        # Execute with error handling
        success = self.safe_execute_command(command, recovery_options)
        
        if success:
            self.logger.info("Geometry added successfully")
        else:
            self.logger.warning("Failed to add geometry")
        
        return success
    
    def validate_input_with_error_handling(self, input_data):
        """Example method showing direct Core operation with error handling."""
        from plana_figura.validation import validate_coordinate
        
        # Use safe_execute_operation for Core library calls
        result = self.safe_execute_operation(validate_coordinate, input_data)
        
        return result is not None
    
    def create_recovery_options(self, error_code: str) -> Optional[list]:
        """Override to provide context-specific recovery options."""
        if error_code == 'GEOMETRY_CREATION_FAILED':
            return [
                {
                    'text': 'Use Default Values',
                    'callback': lambda: self._use_default_geometry_values()
                },
                {
                    'text': 'Open Input Dialog',
                    'callback': lambda: self._open_geometry_input_dialog()
                }
            ]
        
        # Fall back to base class for common recovery options
        return super().create_recovery_options(error_code)
    
    def _use_default_geometry_values(self):
        """Recovery option implementation."""
        self.logger.info("Using default geometry values as recovery")
        # Implementation would create geometry with safe default values
    
    def _open_geometry_input_dialog(self):
        """Recovery option implementation."""
        self.logger.info("Opening geometry input dialog as recovery")
        # Implementation would show input dialog for user to correct values
