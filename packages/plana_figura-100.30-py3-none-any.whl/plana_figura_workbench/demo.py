"""Demo application for Plana Figura Workbench."""

import tkinter as tk
from tkinter import ttk
import logging

from typing import List
from plana_figura import Point, LineSegment, GeometryCollection, Geometry
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.plugins import GeometryOrganizer, MapView

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


class WorkbenchDemo(tk.Tk):
    """Demo application for testing Plana Figura Workbench plugins."""

    def __init__(self):
        """Initialize the demo application."""
        super().__init__()

        self.title("Plana Figura Workbench - Demo")
        self.geometry("1200x800")

        # Create document with sample data
        self.document = self._create_sample_document()

        # Setup UI
        self._setup_ui()

        logger.info("Demo application started")

    def _create_sample_document(self) -> PlanaFiguraDocument:
        """
        Create a sample document with test geometries.

        Returns:
            A document with sample data
        """
        doc = PlanaFiguraDocument("Demo Document")

        # Create some sample points
        points = [
            Point(0, 0, 0),
            Point(10, 0, 0),
            Point(10, 10, 0),
            Point(0, 10, 0),
            Point(5, 5, 5),
        ]

        # Create some line segments
        line_segments = [
            LineSegment(points[0], points[1]),
            LineSegment(points[1], points[2]),
            LineSegment(points[2], points[3]),
            LineSegment(points[3], points[0]),
        ]

        # Create collections (cast to List[Geometry] for type checker)
        points_list: List[Geometry] = [p for p in points]  # type: ignore[misc]
        lines_list: List[Geometry] = [ls for ls in line_segments]  # type: ignore[misc]

        points_collection = GeometryCollection(points_list)
        lines_collection = GeometryCollection(lines_list)

        doc.add_collection(points_collection)
        doc.add_collection(lines_collection, set_active=False)

        logger.info(f"Created sample document with {doc.get_geometry_count()} "
                    f"geometries")

        return doc

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Create main paned window
        paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)

        # Left panel - Geometry Organizer
        left_frame = ttk.Frame(paned, width=300)
        organizer = GeometryOrganizer(left_frame, self.document)
        organizer.pack(fill=tk.BOTH, expand=True)
        paned.add(left_frame, weight=1)

        # Right panel - Map View
        right_frame = ttk.Frame(paned)
        map_view = MapView(right_frame, self.document)
        map_view.pack(fill=tk.BOTH, expand=True)
        paned.add(right_frame, weight=3)

        # Menu bar
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Exit", command=self.quit)

        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self._show_about)

    def _show_about(self) -> None:
        """Show about dialog."""
        from tkinter import messagebox
        messagebox.showinfo(
            "About",
            "Plana Figura Workbench - Demo\n\n"
            "Phase 2: Core Views\n"
            "- Geometry Organizer\n"
            "- Map View\n"
            "- Selection Synchronization"
        )


def main():
    """Run the demo application."""
    app = WorkbenchDemo()
    app.mainloop()


if __name__ == "__main__":
    main()
