"""Line segment creation form."""

import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable
import logging

from plana_figura import Point, LineSegment
from plana_figura_workbench.validators import (
    CoordinateValidator,
    ElevationValidator
)
from plana_figura_workbench.forms.base import (
    GeometryInputForm,
    ValidatedEntry
)

logger = logging.getLogger(__name__)


class LineCreationForm(GeometryInputForm):
    """
    Form for creating LineSegment geometries.

    Provides input fields for:
    - Start point (Northing, Easting, Elevation)
    - End point (Northing, Easting, Elevation)
    """

    def __init__(
        self,
        parent: tk.Widget,
        on_create: Optional[Callable[[LineSegment], None]] = None,
        on_cancel: Optional[Callable[[], None]] = None
    ):
        """
        Initialize line creation form.

        Args:
            parent: Parent widget
            on_create: Callback when line is created
            on_cancel: Callback when form is cancelled
        """
        super().__init__(parent, on_create, on_cancel)

    def _setup_ui(self) -> None:
        """Set up the form UI."""
        # Title
        title_label = ttk.Label(
            self,
            text="Create Line Segment",
            font=("TkDefaultFont", 14, "bold")
        )
        title_label.pack(pady=(0, 15))

        # Input fields frame with grid layout
        fields_frame = ttk.Frame(self)
        fields_frame.pack(fill=tk.BOTH, expand=True, padx=10)
        fields_frame.columnconfigure(0, weight=1)

        # Start point section
        start_label = ttk.Label(
            fields_frame,
            text="Start Point:",
            font=("TkDefaultFont", 11, "bold")
        )
        start_label.grid(row=0, column=0, sticky=tk.W, pady=(0, 5))

        # Start Northing
        self.start_northing_entry = ValidatedEntry(
            fields_frame,
            validator=CoordinateValidator(),
            label="  Northing:",
            width=25
        )
        self.start_northing_entry.grid(row=1, column=0, sticky=tk.EW, pady=3)

        # Start Easting
        self.start_easting_entry = ValidatedEntry(
            fields_frame,
            validator=CoordinateValidator(),
            label="  Easting:",
            width=25
        )
        self.start_easting_entry.grid(row=2, column=0, sticky=tk.EW, pady=3)

        # Start Elevation
        self.start_elevation_entry = ValidatedEntry(
            fields_frame,
            validator=ElevationValidator(allow_empty=True),
            label="  Elevation:",
            width=25
        )
        self.start_elevation_entry.grid(row=3, column=0, sticky=tk.EW, pady=3)
        self.start_elevation_entry.set_value("0")

        # Separator
        separator = ttk.Separator(fields_frame, orient=tk.HORIZONTAL)
        separator.grid(row=4, column=0, sticky=tk.EW, pady=10)

        # End point section
        end_label = ttk.Label(
            fields_frame,
            text="End Point:",
            font=("TkDefaultFont", 11, "bold")
        )
        end_label.grid(row=5, column=0, sticky=tk.W, pady=(0, 5))

        # End Northing
        self.end_northing_entry = ValidatedEntry(
            fields_frame,
            validator=CoordinateValidator(),
            label="  Northing:",
            width=25
        )
        self.end_northing_entry.grid(row=6, column=0, sticky=tk.EW, pady=3)

        # End Easting
        self.end_easting_entry = ValidatedEntry(
            fields_frame,
            validator=CoordinateValidator(),
            label="  Easting:",
            width=25
        )
        self.end_easting_entry.grid(row=7, column=0, sticky=tk.EW, pady=3)

        # End Elevation
        self.end_elevation_entry = ValidatedEntry(
            fields_frame,
            validator=ElevationValidator(allow_empty=True),
            label="  Elevation:",
            width=25
        )
        self.end_elevation_entry.grid(row=8, column=0, sticky=tk.EW, pady=3)
        self.end_elevation_entry.set_value("0")

        # Help text
        help_label = ttk.Label(
            self,
            text="Enter coordinates in meters (elevation defaults to 0)",
            font=("TkDefaultFont", 9),
            foreground="gray"
        )
        help_label.pack(pady=(10, 0))

    def _validate_form(self) -> bool:
        """
        Validate the entire form.

        Returns:
            True if form is valid, False otherwise
        """
        entries = [
            self.start_northing_entry,
            self.start_easting_entry,
            self.start_elevation_entry,
            self.end_northing_entry,
            self.end_easting_entry,
            self.end_elevation_entry
        ]

        for entry in entries:
            if not entry.is_valid():
                logger.warning("Invalid entry value")
                return False

        return True

    def _create_geometry(self) -> LineSegment:
        """
        Create the LineSegment object from form values.

        Returns:
            The created LineSegment

        Raises:
            ValueError: If form is invalid
        """
        # Get start point values
        start_n = self.start_northing_entry.get_value()
        start_e = self.start_easting_entry.get_value()
        start_z = self.start_elevation_entry.get_value()

        # Get end point values
        end_n = self.end_northing_entry.get_value()
        end_e = self.end_easting_entry.get_value()
        end_z = self.end_elevation_entry.get_value()

        # Validate all values
        if not all([
            start_n.is_valid, start_e.is_valid, start_z.is_valid,
            end_n.is_valid, end_e.is_valid, end_z.is_valid
        ]):
            raise ValueError("Form contains invalid values")

        # Create start point
        start_elevation = 0.0
        if start_z.value is not None:
            start_elevation = float(start_z.value)

        start_point = Point(
            northing=float(start_n.value),
            easting=float(start_e.value),
            elevation=start_elevation
        )

        # Create end point
        end_elevation = 0.0
        if end_z.value is not None:
            end_elevation = float(end_z.value)

        end_point = Point(
            northing=float(end_n.value),
            easting=float(end_e.value),
            elevation=end_elevation
        )

        # Create line segment
        line = LineSegment(start_point, end_point)

        logger.info(
            f"Created line segment: "
            f"Start({start_point.northing}, {start_point.easting}), "
            f"End({end_point.northing}, {end_point.easting})"
        )

        return line

    def clear_form(self) -> None:
        """Clear all form fields."""
        self.start_northing_entry.clear()
        self.start_easting_entry.clear()
        self.start_elevation_entry.clear()
        self.end_northing_entry.clear()
        self.end_easting_entry.clear()
        self.end_elevation_entry.clear()

        # Reset default elevations
        self.start_elevation_entry.set_value("0")
        self.end_elevation_entry.set_value("0")

    def set_line(self, line: LineSegment) -> None:
        """
        Populate form with line segment values.

        Args:
            line: The line segment to populate from
        """
        # Set start point
        self.start_northing_entry.set_value(str(line.start_point.northing))
        self.start_easting_entry.set_value(str(line.start_point.easting))
        self.start_elevation_entry.set_value(str(line.start_point.elevation))

        # Set end point
        self.end_northing_entry.set_value(str(line.end_point.northing))
        self.end_easting_entry.set_value(str(line.end_point.easting))
        self.end_elevation_entry.set_value(str(line.end_point.elevation))
