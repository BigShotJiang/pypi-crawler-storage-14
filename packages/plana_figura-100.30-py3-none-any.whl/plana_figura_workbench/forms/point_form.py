"""Point creation form."""

import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable
import logging

from plana_figura import Point
from plana_figura_workbench.validators import (
    CoordinateValidator,
    ElevationValidator
)
from plana_figura_workbench.forms.base import (
    GeometryInputForm,
    ValidatedEntry
)

logger = logging.getLogger(__name__)


class PointCreationForm(GeometryInputForm):
    """
    Form for creating Point geometries.

    Provides input fields for:
    - Northing coordinate
    - Easting coordinate
    - Elevation (optional)
    """

    def __init__(
        self,
        parent: tk.Widget,
        on_create: Optional[Callable[[Point], None]] = None,
        on_cancel: Optional[Callable[[], None]] = None,
        require_elevation: bool = False
    ):
        """
        Initialize point creation form.

        Args:
            parent: Parent widget
            on_create: Callback when point is created
            on_cancel: Callback when form is cancelled
            require_elevation: Whether elevation is required
        """
        self.require_elevation = require_elevation
        super().__init__(parent, on_create, on_cancel)

    def _setup_ui(self) -> None:
        """Set up the form UI."""
        # Title
        title_label = ttk.Label(
            self,
            text="Create Point",
            font=("TkDefaultFont", 14, "bold")
        )
        title_label.pack(pady=(0, 15))

        # Input fields frame with grid layout
        fields_frame = ttk.Frame(self)
        fields_frame.pack(fill=tk.BOTH, expand=True, padx=10)
        fields_frame.columnconfigure(0, weight=1)

        # Northing entry
        self.northing_entry = ValidatedEntry(
            fields_frame,
            validator=CoordinateValidator(),
            label="Northing:",
            width=25
        )
        self.northing_entry.grid(row=0, column=0, sticky=tk.EW, pady=5)

        # Easting entry
        self.easting_entry = ValidatedEntry(
            fields_frame,
            validator=CoordinateValidator(),
            label="Easting:",
            width=25
        )
        self.easting_entry.grid(row=1, column=0, sticky=tk.EW, pady=5)

        # Elevation entry
        elev_label = "Elevation:" if not self.require_elevation else "Elevation:*"
        self.elevation_entry = ValidatedEntry(
            fields_frame,
            validator=ElevationValidator(
                allow_empty=not self.require_elevation
            ),
            label=elev_label,
            width=25
        )
        self.elevation_entry.grid(row=2, column=0, sticky=tk.EW, pady=5)

        # Set default elevation to 0
        if not self.require_elevation:
            self.elevation_entry.set_value("0")

        # Help text
        help_text = "Enter coordinates in meters"
        if not self.require_elevation:
            help_text += " (elevation defaults to 0)"

        help_label = ttk.Label(
            self,
            text=help_text,
            font=("TkDefaultFont", 9),
            foreground="gray"
        )
        help_label.pack(pady=(10, 0))

    def _validate_form(self) -> bool:
        """
        Validate the entire form.

        Returns:
            True if form is valid, False otherwise
        """
        northing_valid = self.northing_entry.is_valid()
        easting_valid = self.easting_entry.is_valid()
        elevation_valid = self.elevation_entry.is_valid()

        if not northing_valid:
            logger.warning("Invalid northing value")
            return False

        if not easting_valid:
            logger.warning("Invalid easting value")
            return False

        if not elevation_valid:
            logger.warning("Invalid elevation value")
            return False

        return True

    def _create_geometry(self) -> Point:
        """
        Create the Point object from form values.

        Returns:
            The created Point

        Raises:
            ValueError: If form is invalid
        """
        northing_result = self.northing_entry.get_value()
        easting_result = self.easting_entry.get_value()
        elevation_result = self.elevation_entry.get_value()

        if not all([
            northing_result.is_valid,
            easting_result.is_valid,
            elevation_result.is_valid
        ]):
            raise ValueError("Form contains invalid values")

        # Get elevation value (default to 0 if None)
        elevation = 0.0
        if elevation_result.value is not None:
            elevation = float(elevation_result.value)

        # Create point
        point = Point(
            northing=float(northing_result.value),
            easting=float(easting_result.value),
            elevation=elevation
        )

        logger.info(
            f"Created point: N={point.northing}, "
            f"E={point.easting}, Z={point.elevation}"
        )

        return point

    def clear_form(self) -> None:
        """Clear all form fields."""
        self.northing_entry.clear()
        self.easting_entry.clear()
        self.elevation_entry.clear()

        # Reset default elevation
        if not self.require_elevation:
            self.elevation_entry.set_value("0")

    def set_point(self, point: Point) -> None:
        """
        Populate form with point values.

        Args:
            point: The point to populate from
        """
        self.northing_entry.set_value(str(point.northing))
        self.easting_entry.set_value(str(point.easting))
        self.elevation_entry.set_value(str(point.elevation))
