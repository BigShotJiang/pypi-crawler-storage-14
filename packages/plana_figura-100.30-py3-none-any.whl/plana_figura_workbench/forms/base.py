"""Base classes for geometry input forms."""

import tkinter as tk
from tkinter import ttk
import ttkbootstrap as ttk_bs
from typing import Optional, Callable, Any
from abc import ABC, abstractmethod
import logging

from plana_figura_workbench.validators import Validator, ValidationResult

logger = logging.getLogger(__name__)


class ValidatedEntry(ttk.Frame):
    """
    An entry widget with real-time validation feedback.

    Attributes:
        validator: The validator to use for this entry
        on_change: Optional callback when value changes
    """

    def __init__(
        self,
        parent: tk.Widget,
        validator: Validator,
        label: str = "",
        on_change: Optional[Callable[[ValidationResult], None]] = None,
        **kwargs
    ):
        """
        Initialize validated entry.

        Args:
            parent: Parent widget
            validator: Validator for this entry
            label: Label text
            on_change: Callback when value changes
            **kwargs: Additional arguments for entry widget
        """
        super().__init__(parent)
        self.validator = validator
        self.on_change = on_change
        self._validation_result: Optional[ValidationResult] = None

        # Configure grid columns
        self.columnconfigure(1, weight=1)

        # Create label if provided
        if label:
            self.label = ttk.Label(self, text=label, width=12, anchor=tk.E)
            self.label.grid(row=0, column=0, sticky=tk.E, padx=(0, 5))

        # Create entry widget
        self.entry_var = tk.StringVar()
        self.entry_var.trace_add('write', self._on_entry_change)

        self.entry = ttk.Entry(self, textvariable=self.entry_var, **kwargs)
        self.entry.grid(row=0, column=1, sticky=tk.EW)

        # Create validation feedback label
        self.feedback_label = ttk.Label(
            self,
            text="",
            foreground="red",
            font=("TkDefaultFont", 8),
            width=2
        )
        self.feedback_label.grid(row=0, column=2, padx=(5, 0))

    def _on_entry_change(self, *args) -> None:
        """Handle entry value change."""
        value = self.entry_var.get()
        self._validation_result = self.validator.validate(value)

        # Update feedback
        if value and not self._validation_result.is_valid:
            self.feedback_label.config(text="✗")
            self.entry.config(foreground="red")
        else:
            self.feedback_label.config(text="")
            self.entry.config(foreground="black")

        # Call callback if provided
        if self.on_change:
            self.on_change(self._validation_result)

    def get_value(self) -> ValidationResult:
        """
        Get the current validated value.

        Returns:
            ValidationResult with parsed value or error
        """
        if self._validation_result is None:
            # No validation yet, validate now
            value = self.entry_var.get()
            self._validation_result = self.validator.validate(value)

        return self._validation_result

    def set_value(self, value: str) -> None:
        """
        Set the entry value.

        Args:
            value: The value to set
        """
        self.entry_var.set(value)

    def clear(self) -> None:
        """Clear the entry."""
        self.entry_var.set("")
        self.feedback_label.config(text="")
        self.entry.config(foreground="black")
        self._validation_result = None

    def is_valid(self) -> bool:
        """
        Check if current value is valid.

        Returns:
            True if valid, False otherwise
        """
        result = self.get_value()
        return result.is_valid


class GeometryInputForm(ttk.Frame, ABC):
    """
    Abstract base class for geometry input forms.

    Provides common functionality for creating geometry objects
    from user input with validation.
    """

    def __init__(
        self,
        parent: tk.Widget,
        on_create: Optional[Callable[[Any], None]] = None,
        on_cancel: Optional[Callable[[], None]] = None
    ):
        """
        Initialize geometry input form.

        Args:
            parent: Parent widget
            on_create: Callback when geometry is created
            on_cancel: Callback when form is cancelled
        """
        super().__init__(parent, padding=10)
        self.on_create = on_create
        self.on_cancel = on_cancel

        self._setup_ui()
        self._create_buttons()

    @abstractmethod
    def _setup_ui(self) -> None:
        """Set up the form UI. Must be implemented by subclasses."""
        pass

    @abstractmethod
    def _validate_form(self) -> bool:
        """
        Validate the entire form.

        Returns:
            True if form is valid, False otherwise
        """
        pass

    @abstractmethod
    def _create_geometry(self) -> Any:
        """
        Create the geometry object from form values.

        Returns:
            The created geometry object

        Raises:
            ValueError: If form is invalid
        """
        pass

    def _create_buttons(self) -> None:
        """Create form buttons (Create, Cancel)."""
        button_frame = ttk.Frame(self)
        button_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(10, 0))

        # Cancel button
        self.cancel_button = ttk_bs.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel_clicked,
            bootstyle="secondary",
            width=10
        )
        self.cancel_button.pack(side=tk.RIGHT, padx=(5, 0))

        # Create button
        self.create_button = ttk_bs.Button(
            button_frame,
            text="Create",
            command=self._on_create_clicked,
            bootstyle="success",
            width=10
        )
        self.create_button.pack(side=tk.RIGHT)

    def _on_create_clicked(self) -> None:
        """Handle Create button click."""
        if not self._validate_form():
            logger.warning("Form validation failed")
            return

        try:
            geometry = self._create_geometry()
            logger.info(f"Created geometry: {type(geometry).__name__}")

            if self.on_create:
                self.on_create(geometry)

            self.clear_form()

        except Exception as e:
            logger.error(f"Error creating geometry: {e}")
            self._show_error(str(e))

    def _on_cancel_clicked(self) -> None:
        """Handle Cancel button click."""
        self.clear_form()

        if self.on_cancel:
            self.on_cancel()

    def _show_error(self, message: str) -> None:
        """
        Show error message to user.

        Args:
            message: Error message to display
        """
        from tkinter import messagebox
        messagebox.showerror("Error", message)

    @abstractmethod
    def clear_form(self) -> None:
        """Clear all form fields."""
        pass

    def enable_form(self, enabled: bool = True) -> None:
        """
        Enable or disable the form.

        Args:
            enabled: Whether to enable the form
        """
        state = tk.NORMAL if enabled else tk.DISABLED
        self.create_button.config(state=state)
