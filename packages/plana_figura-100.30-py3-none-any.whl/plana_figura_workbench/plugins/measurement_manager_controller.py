"""Controller for Measurement Manager plugin - testable business logic."""

from typing import List, Dict, Optional, Any, Tuple
from plana_figura import (
    Measurement,
    MeasurementType,
    DecimalDegreesAngle
)
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.commands import (
    AddMeasurementCommand,
    RemoveMeasurementCommand,
    ModifyMeasurementCommand,
    CreateMeasurementCollectionCommand,
    RemoveMeasurementCollectionCommand
)
from plana_figura_workbench.controller_error_mixin import ControllerErrorMixin
import logging

logger = logging.getLogger(__name__)


class MeasurementManagerController(ControllerErrorMixin):
    """
    Controller for Measurement Manager - handles all business logic.

    This controller is completely independent of the UI framework,
    making it easily testable without tkinter dependencies.
    """

    def __init__(
        self,
        document: PlanaFiguraDocument,
        command_manager: Optional[Any] = None
    ):
        """
        Initialize the controller.

        Args:
            document: The document to manage
            command_manager: Optional command manager for undo/redo
        """
        super().__init__()
        self.document = document
        self.command_manager = command_manager
        self.selected_measurement_ids: List[int] = []

    # ========================================================================
    # Collection Management
    # ========================================================================

    def create_collection(self, name: str) -> bool:
        """
        Create a new measurement collection.

        Args:
            name: Name for the new collection

        Returns:
            True if successful, False otherwise
        """
        try:
            cmd = CreateMeasurementCollectionCommand(self.document, name)
            if self.command_manager:
                return self.command_manager.execute(cmd)
            else:
                return cmd.execute()
        except Exception as e:
            logger.error(f"Failed to create collection: {e}")
            return False

    def delete_collection(self, name: str) -> bool:
        """
        Delete a measurement collection.

        Args:
            name: Name of the collection to delete

        Returns:
            True if successful, False otherwise
        """
        try:
            cmd = RemoveMeasurementCollectionCommand(self.document, name)
            if self.command_manager:
                return self.command_manager.execute(cmd)
            else:
                return cmd.execute()
        except Exception as e:
            logger.error(f"Failed to delete collection: {e}")
            return False

    def set_active_collection(self, name: str) -> bool:
        """
        Set the active measurement collection.

        Args:
            name: Name of the collection to activate

        Returns:
            True if successful, False otherwise
        """
        return self.document.set_active_measurement_collection(name)

    def get_collection_names(self) -> List[str]:
        """
        Get list of all collection names.

        Returns:
            List of collection names
        """
        return list(self.document.measurement_collections.keys())

    def get_active_collection_name(self) -> Optional[str]:
        """
        Get the name of the active collection.

        Returns:
            Active collection name or None
        """
        return self.document.active_measurement_collection

    # ========================================================================
    # Measurement Creation
    # ========================================================================

    def add_horizontal_angle(
        self,
        name: str,
        degrees: float,
        description: str = ""
    ) -> Optional[int]:
        """
        Add a horizontal angle measurement.

        Args:
            name: Measurement name
            degrees: Angle value in decimal degrees
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        return self._add_angle_measurement(
            name,
            degrees,
            MeasurementType.HORIZONTAL_ANGLE,
            description
        )

    def add_vertical_angle(
        self,
        name: str,
        degrees: float,
        description: str = ""
    ) -> Optional[int]:
        """
        Add a vertical angle measurement.

        Args:
            name: Measurement name
            degrees: Angle value in decimal degrees
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        return self._add_angle_measurement(
            name,
            degrees,
            MeasurementType.VERTICAL_ANGLE,
            description
        )

    def add_zenith_angle(
        self,
        name: str,
        degrees: float,
        description: str = ""
    ) -> Optional[int]:
        """
        Add a zenith angle measurement.

        Args:
            name: Measurement name
            degrees: Angle value in decimal degrees
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        return self._add_angle_measurement(
            name,
            degrees,
            MeasurementType.ZENITH_ANGLE,
            description
        )

    def add_azimuth(
        self,
        name: str,
        degrees: float,
        description: str = ""
    ) -> Optional[int]:
        """
        Add an azimuth measurement.

        Args:
            name: Measurement name
            degrees: Azimuth value in decimal degrees
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        return self._add_angle_measurement(
            name,
            degrees,
            MeasurementType.AZIMUTH,
            description
        )

    def add_bearing(
        self,
        name: str,
        degrees: float,
        description: str = ""
    ) -> Optional[int]:
        """
        Add a bearing measurement.

        Args:
            name: Measurement name
            degrees: Bearing value in decimal degrees
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        return self._add_angle_measurement(
            name,
            degrees,
            MeasurementType.BEARING,
            description
        )

    def add_direction(
        self,
        name: str,
        degrees: float,
        description: str = ""
    ) -> Optional[int]:
        """
        Add a direction measurement.

        Args:
            name: Measurement name
            degrees: Direction value in decimal degrees
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        return self._add_angle_measurement(
            name,
            degrees,
            MeasurementType.DIRECTION,
            description
        )

    def add_distance(
        self,
        name: str,
        value: float,
        distance_type: MeasurementType,
        description: str = ""
    ) -> Optional[int]:
        """
        Add a distance measurement.

        Args:
            name: Measurement name
            value: Distance value
            distance_type: Type of distance measurement
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        try:
            collection = self.document.get_active_measurement_collection()
            if collection is None:
                logger.error("No active measurement collection")
                return None

            measurement = Measurement(
                name=name,
                value=value,
                measurement_type=distance_type,
                description=description
            )

            cmd = AddMeasurementCommand(
                self.document,
                measurement,
                self.document.active_measurement_collection
            )

            success = (
                self.command_manager.execute(cmd)
                if self.command_manager
                else cmd.execute()
            )

            return measurement.id if success else None

        except Exception as e:
            logger.error(f"Failed to add distance: {e}")
            return None

    def add_vector_3d(
        self,
        name: str,
        northing: float,
        easting: float,
        elevation: float,
        description: str = ""
    ) -> Optional[int]:
        """
        Add a 3D vector measurement.

        Args:
            name: Measurement name
            northing: Northing component
            easting: Easting component
            elevation: Elevation component
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        try:
            collection = self.document.get_active_measurement_collection()
            if collection is None:
                logger.error("No active measurement collection")
                return None

            measurement = Measurement(
                name=name,
                value=(northing, easting, elevation),
                measurement_type=MeasurementType.VECTOR_3D,
                description=description
            )

            cmd = AddMeasurementCommand(
                self.document,
                measurement,
                self.document.active_measurement_collection
            )

            success = (
                self.command_manager.execute(cmd)
                if self.command_manager
                else cmd.execute()
            )

            return measurement.id if success else None

        except Exception as e:
            logger.error(f"Failed to add vector: {e}")
            return None

    def _add_angle_measurement(
        self,
        name: str,
        degrees: float,
        measurement_type: MeasurementType,
        description: str
    ) -> Optional[int]:
        """
        Internal helper to add angle-based measurements.

        Args:
            name: Measurement name
            degrees: Angle value in decimal degrees
            measurement_type: Type of measurement
            description: Optional description

        Returns:
            Measurement ID if successful, None otherwise
        """
        try:
            collection = self.document.get_active_measurement_collection()
            if collection is None:
                logger.error("No active measurement collection")
                return None

            angle = DecimalDegreesAngle(degrees)
            measurement = Measurement(
                name=name,
                value=angle,
                measurement_type=measurement_type,
                description=description
            )

            cmd = AddMeasurementCommand(
                self.document,
                measurement,
                self.document.active_measurement_collection
            )

            success = (
                self.command_manager.execute(cmd)
                if self.command_manager
                else cmd.execute()
            )

            return measurement.id if success else None

        except Exception as e:
            logger.error(f"Failed to add {measurement_type}: {e}")
            return None

    # ========================================================================
    # Measurement Management
    # ========================================================================

    def remove_measurement(self, measurement_id: int) -> bool:
        """
        Remove a measurement.

        Args:
            measurement_id: ID of measurement to remove

        Returns:
            True if successful, False otherwise
        """
        try:
            collection_name = self.document.active_measurement_collection
            if collection_name is None:
                logger.error("No active measurement collection")
                return False

            cmd = RemoveMeasurementCommand(
                self.document,
                measurement_id,
                collection_name
            )

            return (
                self.command_manager.execute(cmd)
                if self.command_manager
                else cmd.execute()
            )

        except Exception as e:
            logger.error(f"Failed to remove measurement: {e}")
            return False

    def update_measurement(
        self,
        measurement_id: int,
        **kwargs: Any
    ) -> bool:
        """
        Update a measurement's properties.

        Args:
            measurement_id: ID of measurement to update
            **kwargs: Fields to update (name, description, etc.)

        Returns:
            True if successful, False otherwise
        """
        try:
            collection_name = self.document.active_measurement_collection
            if collection_name is None:
                logger.error("No active measurement collection")
                return False

            cmd = ModifyMeasurementCommand(
                self.document,
                measurement_id,
                collection_name,
                **kwargs
            )

            return (
                self.command_manager.execute(cmd)
                if self.command_manager
                else cmd.execute()
            )

        except Exception as e:
            logger.error(f"Failed to update measurement: {e}")
            return False

    # ========================================================================
    # Queries
    # ========================================================================

    def get_all_measurements(self) -> List[Measurement]:
        """
        Get all measurements in the active collection.

        Returns:
            List of measurements
        """
        collection = self.document.get_active_measurement_collection()
        if collection is None:
            return []
        return list(collection)

    def get_filtered_measurements(
        self,
        filter_type: str
    ) -> List[Measurement]:
        """
        Get measurements filtered by type.

        Args:
            filter_type: Filter type ("all", "angles", "directions",
                        "distances", "vectors")

        Returns:
            List of filtered measurements
        """
        collection = self.document.get_active_measurement_collection()
        if collection is None:
            return []

        if filter_type == "all":
            return list(collection)
        elif filter_type == "angles":
            return collection.get_all_angles()
        elif filter_type == "directions":
            return collection.get_all_directions()
        elif filter_type == "distances":
            return collection.get_all_distances()
        elif filter_type == "vectors":
            return collection.get_all_vectors()
        else:
            logger.warning(f"Unknown filter type: {filter_type}")
            return []

    def get_measurement_info(
        self,
        measurement_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        Get detailed information about a measurement.

        Args:
            measurement_id: ID of the measurement

        Returns:
            Dictionary with measurement info or None if not found
        """
        collection = self.document.get_active_measurement_collection()
        if collection is None:
            return None

        measurement = collection.get(measurement_id)
        if measurement is None:
            return None

        info = {
            'id': measurement.id,
            'name': measurement.name,
            'type': measurement.measurement_type.value,
            'description': measurement.description,
            'metadata': measurement.metadata
        }

        # Format value based on type
        if measurement.measurement_type in {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }:
            if isinstance(measurement.value, DecimalDegreesAngle):
                info['value'] = f"{measurement.value.angle_degrees:.6f}°"
                info['value_raw'] = measurement.value.angle_degrees
        elif measurement.measurement_type == MeasurementType.VECTOR_3D:
            if isinstance(measurement.value, tuple) and len(measurement.value) == 3:
                n, e, z = measurement.value
                info['value'] = f"N:{n:.4f}, E:{e:.4f}, Z:{z:.4f}"
                info['value_raw'] = measurement.value
        else:
            # Distance types
            info['value'] = f"{measurement.value:.4f} m"
            info['value_raw'] = measurement.value

        return info

    def get_measurement_display_string(
        self,
        measurement: Measurement
    ) -> Tuple[str, str, str]:
        """
        Get display strings for a measurement (ID, Name, Type, Value).

        Args:
            measurement: The measurement

        Returns:
            Tuple of (id_str, name, type, value)
        """
        id_str = str(measurement.id)
        name = measurement.name
        type_str = measurement.measurement_type.value

        # Format value
        if measurement.measurement_type in {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }:
            if isinstance(measurement.value, DecimalDegreesAngle):
                value_str = f"{measurement.value.angle_degrees:.4f}°"
            else:
                value_str = str(measurement.value)
        elif measurement.measurement_type == MeasurementType.VECTOR_3D:
            if isinstance(measurement.value, tuple) and len(measurement.value) == 3:
                n, e, z = measurement.value
                value_str = f"({n:.2f}, {e:.2f}, {z:.2f})"
            else:
                value_str = str(measurement.value)
        else:
            # Distance types
            value_str = f"{measurement.value:.4f} m"

        return (id_str, name, type_str, value_str)

    # ========================================================================
    # Selection
    # ========================================================================

    def select_measurement(self, measurement_id: int) -> None:
        """
        Select a measurement.

        Args:
            measurement_id: ID of measurement to select
        """
        if measurement_id not in self.selected_measurement_ids:
            self.selected_measurement_ids = [measurement_id]

    def select_measurements(self, measurement_ids: List[int]) -> None:
        """
        Select multiple measurements.

        Args:
            measurement_ids: List of measurement IDs to select
        """
        self.selected_measurement_ids = measurement_ids.copy()

    def clear_selection(self) -> None:
        """Clear the measurement selection."""
        self.selected_measurement_ids.clear()

    def get_selected_measurements(self) -> List[int]:
        """
        Get list of selected measurement IDs.

        Returns:
            List of selected measurement IDs
        """
        return self.selected_measurement_ids.copy()

    def is_selected(self, measurement_id: int) -> bool:
        """
        Check if a measurement is selected.

        Args:
            measurement_id: ID to check

        Returns:
            True if selected, False otherwise
        """
        return measurement_id in self.selected_measurement_ids
