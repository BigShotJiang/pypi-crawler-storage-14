"""Geometry Manipulator plugin - UI for geometry manipulations."""

import tkinter as tk
from tkinter import ttk
import ttkbootstrap as ttk_boot
from typing import Optional
import logging

from plana_figura import Point
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.model.document import Observer
from plana_figura_workbench.plugins.geometry_manipulator_controller import (
    GeometryManipulatorController
)
from plana_figura_workbench.events import GeometrySelectedEvent, SelectionChangedEvent

logger = logging.getLogger(__name__)


class GeometryManipulator(ttk.Frame, Observer):
    """
    Geometry Manipulator plugin.
    
    Provides UI for manipulating geometries (translate, rotate, scale, mirror).
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        document: PlanaFiguraDocument,
        event_bus,
        command_manager=None,
        selection_manager=None,
        data_bucket=None
    ):
        """
        Initialize the Geometry Manipulator.
        
        Args:
            parent: Parent widget
            document: Document model
            event_bus: Event bus for communication
            command_manager: Command manager for undo/redo
            selection_manager: Centralized selection manager
            data_bucket: Optional DataBucket for shared data access
        """
        ttk.Frame.__init__(self, parent)
        
        self.document = document
        self.event_bus = event_bus
        self.command_manager = command_manager
        self.selection_manager = selection_manager
        self.data_bucket = data_bucket
        
        # Controller
        self.controller = GeometryManipulatorController(document)
        
        # Entry variables for manipulation parameters
        self.translate_n_var = tk.StringVar(value="0.0")
        self.translate_e_var = tk.StringVar(value="0.0")
        self.translate_z_var = tk.StringVar(value="0.0")
        
        self.rotate_center_n_var = tk.StringVar(value="0.0")
        self.rotate_center_e_var = tk.StringVar(value="0.0")
        self.rotate_angle_var = tk.StringVar(value="0.0")
        
        self.scale_center_n_var = tk.StringVar(value="0.0")
        self.scale_center_e_var = tk.StringVar(value="0.0")
        self.scale_factor_var = tk.StringVar(value="1.0")
        
        self.mirror_p1_n_var = tk.StringVar(value="0.0")
        self.mirror_p1_e_var = tk.StringVar(value="0.0")
        self.mirror_p2_n_var = tk.StringVar(value="100.0")
        self.mirror_p2_e_var = tk.StringVar(value="100.0")
        
        # Create UI
        self._create_ui()
        
        # Subscribe to events
        self._subscribe_events()
        
        # Initial update
        self._update_selection_info()
        
        logger.info("Geometry Manipulator initialized")
    
    def _create_ui(self) -> None:
        """Create the user interface."""
        # Configure grid
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        
        # Title
        title_frame = ttk.Frame(self)
        title_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        ttk.Label(
            title_frame,
            text="Geometry Manipulator",
            font=("Segoe UI", 16, "bold")
        ).pack(anchor=tk.W)
        
        ttk.Label(
            title_frame,
            text="Manipulate selected geometries",
            font=("Segoe UI", 10)
        ).pack(anchor=tk.W)
        
        # Selection info panel
        self._create_selection_panel()
        
        # Manipulations panel with tabs
        self._create_manipulations_panel()
    
    def _create_selection_panel(self) -> None:
        """Create the selection information panel with treeview."""
        selection_frame = ttk.LabelFrame(
            self,
            text="Selection",
            padding=10
        )
        selection_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))
        
        # Selection summary label
        self.selection_label = ttk.Label(
            selection_frame,
            text="No geometries selected",
            font=("Segoe UI", 11, "bold")
        )
        self.selection_label.pack(anchor=tk.W, pady=(0, 5))
        
        # Treeview for selection breakdown
        tree_frame = ttk.Frame(selection_frame)
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=(5, 0))
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Treeview
        self.selection_tree = ttk.Treeview(
            tree_frame,
            columns=("Count",),
            show="tree headings",
            height=4,
            yscrollcommand=scrollbar.set
        )
        self.selection_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.selection_tree.yview)
        
        # Configure columns
        self.selection_tree.heading("#0", text="Type")
        self.selection_tree.heading("Count", text="Count")
        self.selection_tree.column("#0", width=200)
        self.selection_tree.column("Count", width=80, anchor=tk.CENTER)
        
        # Help text
        help_text = ttk.Label(
            selection_frame,
            text="Select geometries in the Geometry Organizer or Map View.",
            font=("Segoe UI", 9),
            foreground="gray"
        )
        help_text.pack(anchor=tk.W, pady=(5, 0))
    
    def _create_manipulations_panel(self) -> None:
        """Create the manipulations panel with tabs."""
        manip_frame = ttk.LabelFrame(
            self,
            text="Manipulations",
            padding=10
        )
        manip_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 10))
        
        # Create notebook for tabs
        self.manip_notebook = ttk.Notebook(manip_frame)
        self.manip_notebook.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create tabs
        self._create_translate_tab()
        self._create_rotate_tab()
        self._create_scale_tab()
        self._create_mirror_tab()
        
        # Buttons at bottom
        button_frame = ttk.Frame(manip_frame)
        button_frame.pack(fill=tk.X)
        
        self.perform_edits_button = ttk_boot.Button(
            button_frame,
            text="Perform As Edits",
            command=lambda: self._perform_manipulation(copy_mode=False),
            bootstyle="success",
            width=20
        )
        self.perform_edits_button.pack(side=tk.LEFT, padx=(0, 5))
        
        self.perform_copies_button = ttk_boot.Button(
            button_frame,
            text="Perform With Copies",
            command=lambda: self._perform_manipulation(copy_mode=True),
            bootstyle="primary",
            width=20
        )
        self.perform_copies_button.pack(side=tk.LEFT)
    
    def _create_translate_tab(self) -> None:
        """Create the Translate tab."""
        tab = ttk.Frame(self.manip_notebook, padding=10)
        self.manip_notebook.add(tab, text="Translate")
        
        # Delta Northing
        row = 0
        ttk.Label(tab, text="Delta Northing:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.translate_n_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Delta Easting
        row += 1
        ttk.Label(tab, text="Delta Easting:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.translate_e_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Delta Elevation
        row += 1
        ttk.Label(tab, text="Delta Elevation:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.translate_z_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Description
        row += 1
        desc = ttk.Label(
            tab,
            text="Move geometries by specified distances in N/E/Z directions.",
            font=("Segoe UI", 9),
            foreground="gray",
            wraplength=300
        )
        desc.grid(row=row, column=0, columnspan=2, sticky=tk.W, pady=(10, 0))
        
        tab.columnconfigure(1, weight=1)
    
    def _create_rotate_tab(self) -> None:
        """Create the Rotate tab."""
        tab = ttk.Frame(self.manip_notebook, padding=10)
        self.manip_notebook.add(tab, text="Rotate")
        
        # Center Northing
        row = 0
        ttk.Label(tab, text="Center Northing:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.rotate_center_n_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Center Easting
        row += 1
        ttk.Label(tab, text="Center Easting:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.rotate_center_e_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Angle
        row += 1
        ttk.Label(tab, text="Angle (degrees):").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.rotate_angle_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Description
        row += 1
        desc = ttk.Label(
            tab,
            text="Rotate geometries around a center point. Positive = counterclockwise.",
            font=("Segoe UI", 9),
            foreground="gray",
            wraplength=300
        )
        desc.grid(row=row, column=0, columnspan=2, sticky=tk.W, pady=(10, 0))
        
        tab.columnconfigure(1, weight=1)
    
    def _create_scale_tab(self) -> None:
        """Create the Scale tab."""
        tab = ttk.Frame(self.manip_notebook, padding=10)
        self.manip_notebook.add(tab, text="Scale")
        
        # Center Northing
        row = 0
        ttk.Label(tab, text="Center Northing:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.scale_center_n_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Center Easting
        row += 1
        ttk.Label(tab, text="Center Easting:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.scale_center_e_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Scale Factor
        row += 1
        ttk.Label(tab, text="Scale Factor:").grid(row=row, column=0, sticky=tk.W, pady=8)
        ttk.Entry(tab, textvariable=self.scale_factor_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Description
        row += 1
        desc = ttk.Label(
            tab,
            text="Scale geometries relative to center. Factor > 1 enlarges, < 1 shrinks.",
            font=("Segoe UI", 9),
            foreground="gray",
            wraplength=300
        )
        desc.grid(row=row, column=0, columnspan=2, sticky=tk.W, pady=(10, 0))
        
        tab.columnconfigure(1, weight=1)
    
    def _create_mirror_tab(self) -> None:
        """Create the Mirror tab."""
        tab = ttk.Frame(self.manip_notebook, padding=10)
        self.manip_notebook.add(tab, text="Mirror")
        
        # Point 1
        ttk.Label(tab, text="Axis Point 1:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 5))
        
        row = 1
        ttk.Label(tab, text="Northing:").grid(row=row, column=0, sticky=tk.W, pady=8, padx=(10, 0))
        ttk.Entry(tab, textvariable=self.mirror_p1_n_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        row += 1
        ttk.Label(tab, text="Easting:").grid(row=row, column=0, sticky=tk.W, pady=8, padx=(10, 0))
        ttk.Entry(tab, textvariable=self.mirror_p1_e_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Point 2
        row += 1
        ttk.Label(tab, text="Axis Point 2:", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, columnspan=2, sticky=tk.W, pady=(10, 5))
        
        row += 1
        ttk.Label(tab, text="Northing:").grid(row=row, column=0, sticky=tk.W, pady=8, padx=(10, 0))
        ttk.Entry(tab, textvariable=self.mirror_p2_n_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        row += 1
        ttk.Label(tab, text="Easting:").grid(row=row, column=0, sticky=tk.W, pady=8, padx=(10, 0))
        ttk.Entry(tab, textvariable=self.mirror_p2_e_var, width=15).grid(row=row, column=1, sticky=tk.EW, padx=5)
        
        # Description
        row += 1
        desc = ttk.Label(
            tab,
            text="Mirror geometries across an axis line defined by two points.",
            font=("Segoe UI", 9),
            foreground="gray",
            wraplength=300
        )
        desc.grid(row=row, column=0, columnspan=2, sticky=tk.W, pady=(10, 0))
        
        tab.columnconfigure(1, weight=1)
    
    def _subscribe_events(self) -> None:
        """Subscribe to selection changes."""
        if self.selection_manager:
            # Use SelectionManager observer pattern
            self.selection_manager.add_observer(self._on_selection_manager_changed)
        elif self.event_bus:
            # Fallback to event bus
            self.event_bus.subscribe(
                GeometrySelectedEvent,
                self._on_single_selection_changed
            )
            self.event_bus.subscribe(
                SelectionChangedEvent,
                self._on_selection_changed
            )
    
    def _update_selection_info(self) -> None:
        """Update the selection information display."""
        # Use SelectionManager if available, otherwise use controller
        if self.selection_manager:
            summary = self.selection_manager.get_summary()
            type_counts = self.selection_manager.get_type_counts()
            collections_count = self.selection_manager.get_collections_count()
            has_selection = self.selection_manager.has_selection()
        else:
            summary = self.controller.get_selection_summary()
            type_counts = self.controller.get_selection_type_counts()
            collections_count = self.controller.get_selected_collections_count()
            has_selection = self.controller.has_selection()
        
        self.selection_label.config(text=summary)
        
        # Update treeview
        self.selection_tree.delete(*self.selection_tree.get_children())
        
        # Add geometry type counts
        for type_name in sorted(type_counts.keys()):
            count = type_counts[type_name]
            self.selection_tree.insert("", tk.END, text=type_name, values=(count,))
        
        # Add collections count
        if collections_count > 0:
            self.selection_tree.insert("", tk.END, text="Collections", values=(collections_count,))
        
        # Update button state
        button_state = "normal" if has_selection else "disabled"
        self.perform_edits_button.config(state=button_state)
        self.perform_copies_button.config(state=button_state)
    
    def _on_selection_manager_changed(self, selection_manager, source: str) -> None:
        """
        Handle selection change from SelectionManager.
        
        Args:
            selection_manager: The SelectionManager instance
            source: Name of plugin that changed selection
        """
        # Don't update if we're the source (avoid circular updates)
        if source != "geometry_manipulator":
            self._update_selection_info()
    
    def _on_single_selection_changed(self, event: GeometrySelectedEvent) -> None:
        """
        Handle single geometry selection event (fallback).
        
        Args:
            event: Single selection event
        """
        self._update_selection_info()
    
    def _on_selection_changed(self, event: SelectionChangedEvent) -> None:
        """
        Handle multi-selection change event (fallback).
        
        Args:
            event: Selection change event
        """
        self._update_selection_info()
    
    def _perform_manipulation(self, copy_mode: bool) -> None:
        """
        Perform the selected manipulation.
        
        Args:
            copy_mode: If True, create copies; if False, edit originals
        """
        if not self.controller.can_transform():
            return
        
        # Get current tab
        current_tab = self.manip_notebook.index(self.manip_notebook.select())
        tab_names = ["Translate", "Rotate", "Scale", "Mirror"]
        manip_type = tab_names[current_tab]
        
        logger.info(f"Performing {manip_type} (copy_mode={copy_mode})")
        
        try:
            # Create transformation based on type
            transformation = None
            if manip_type == "Translate":
                transformation = self._create_translation()
            elif manip_type == "Rotate":
                transformation = self._create_rotation()
            elif manip_type == "Scale":
                transformation = self._create_scale()
            elif manip_type == "Mirror":
                transformation = self._create_mirror()
            
            if transformation:
                self._execute_manipulation(manip_type, transformation, copy_mode)
        
        except ValueError as e:
            from tkinter import messagebox
            messagebox.showerror("Invalid Input", str(e))
    
    def _create_translation(self):
        """Create Translation object from form values."""
        from plana_figura import Translation
        
        delta_n = float(self.translate_n_var.get())
        delta_e = float(self.translate_e_var.get())
        delta_z = float(self.translate_z_var.get())
        
        return Translation(delta_n, delta_e, delta_z)
    
    def _create_rotation(self):
        """Create Rotation object from form values."""
        from plana_figura import Rotation
        
        center_n = float(self.rotate_center_n_var.get())
        center_e = float(self.rotate_center_e_var.get())
        angle = float(self.rotate_angle_var.get())
        
        center = Point(center_n, center_e, 0.0)
        return Rotation(center, angle)
    
    def _create_scale(self):
        """Create Scale object from form values."""
        from plana_figura import Scale
        
        center_n = float(self.scale_center_n_var.get())
        center_e = float(self.scale_center_e_var.get())
        factor = float(self.scale_factor_var.get())
        
        center = Point(center_n, center_e, 0.0)
        return Scale(center, factor)
    
    def _create_mirror(self):
        """Create Mirror object from form values."""
        from plana_figura import Mirror, LineSegment
        
        p1_n = float(self.mirror_p1_n_var.get())
        p1_e = float(self.mirror_p1_e_var.get())
        p2_n = float(self.mirror_p2_n_var.get())
        p2_e = float(self.mirror_p2_e_var.get())
        
        p1 = Point(p1_n, p1_e, 0.0)
        p2 = Point(p2_n, p2_e, 0.0)
        axis = LineSegment(p1, p2)
        
        return Mirror(axis)
    
    def _execute_manipulation(self, manip_type: str, transformation, copy_mode: bool) -> None:
        """
        Execute a manipulation command.
        
        Args:
            manip_type: Type of manipulation
            transformation: Transformation object
            copy_mode: Whether to copy or edit
        """
        from plana_figura_workbench.commands import (
            TranslateCommand,
            RotateCommand,
            ScaleCommand,
            MirrorCommand
        )
        
        # Get selected geometries
        geometries = self.controller.get_selected_geometries()
        
        if not geometries:
            return
        
        # If copy mode, create copies first
        if copy_mode:
            # Create copies and add to active collection
            copies = []
            for geom in geometries:
                # Transform creates a new geometry
                copy = geom.transform(transformation)
                copies.append(copy)
                
                # Add to active collection
                if self.document.active_collection:
                    self.document.active_collection.add(copy)
            
            self.document.modified = True
            logger.info(f"Created {len(copies)} copies with {manip_type}")
            
            # Publish event to trigger UI refresh
            if hasattr(self, 'event_bus') and self.event_bus:
                from vultus_serpentis.events import Event
                self.event_bus.publish(Event('document_modified', {'source': 'geometry_manipulator'}))
            
            # Show success message
            from tkinter import messagebox
            messagebox.showinfo(
                "Success",
                f"Created {len(copies)} {manip_type.lower()}d cop{'y' if len(copies) == 1 else 'ies'}",
                parent=self
            )
            return
        
        # Edit mode: create appropriate command
        cmd = None
        if manip_type == "Translate":
            cmd = TranslateCommand(self.document, geometries, transformation)
        elif manip_type == "Rotate":
            cmd = RotateCommand(self.document, geometries, transformation)
        elif manip_type == "Scale":
            cmd = ScaleCommand(self.document, geometries, transformation)
        elif manip_type == "Mirror":
            cmd = MirrorCommand(self.document, geometries, transformation)
        
        # Execute via command manager
        if cmd and self.command_manager:
            self.command_manager.execute(cmd)
            logger.info(f"Executed {manip_type} on {len(geometries)} geometries")
            
            # Show success message
            from tkinter import messagebox
            messagebox.showinfo(
                "Success",
                f"{manip_type}d {len(geometries)} geometr{'y' if len(geometries) == 1 else 'ies'}",
                parent=self
            )
    
    def update(self) -> None:
        """Update the view (Observer pattern)."""
        self._update_selection_info()
