"""Controller for Geometry Organizer plugin - testable business logic."""

from typing import List, Dict, Optional, Tuple
from plana_figura import Geometry, GeometryCollection, Point
import logging

from plana_figura_workbench.controller_error_mixin import ControllerErrorMixin

logger = logging.getLogger(__name__)


class GeometryOrganizerController(ControllerErrorMixin):
    """
    Controller for Geometry Organizer - handles all business logic.

    This controller is completely independent of the UI framework,
    making it easily testable without tkinter dependencies.
    """

    def __init__(self):
        """Initialize the controller."""
        super().__init__()
        self.selected_geometries: List[Geometry] = []
        self.selected_collection: Optional[GeometryCollection] = None

    def get_collection_display_name(
        self,
        collection: GeometryCollection,
        index: int,
        is_active: bool
    ) -> str:
        """
        Get display name for a collection.

        Args:
            collection: The collection
            index: Collection index (0-based)
            is_active: Whether this is the active collection

        Returns:
            Display name string
        """
        # Use collection name if it has one, otherwise use index
        if hasattr(collection, 'name') and collection.name:
            name = collection.name
        else:
            name = f"Collection {index + 1}"
        
        if is_active:
            name += " (Active)"
        return name

    def get_geometry_display_name(
        self,
        geometry: Geometry,
        index: int
    ) -> str:
        """
        Get display name for a geometry.

        Args:
            geometry: The geometry
            index: Geometry index in collection (0-based)

        Returns:
            Display name string showing name/identifier and DXF handle
        """
        # Start with name or default identifier
        if hasattr(geometry, 'name') and geometry.name:
            display_name = geometry.name
        else:
            geom_type = type(geometry).__name__
            display_name = f"{geom_type} {index + 1}"
        
        # Add DXF handle if available
        if hasattr(geometry, 'dxf_handle') and geometry.dxf_handle:
            display_name += f" [DXF: {geometry.dxf_handle}]"
        
        return display_name

    def get_geometry_info_string(self, geometry: Geometry) -> str:
        """
        Get info string for geometry showing UUID, Name, and DXF Handle.

        Args:
            geometry: The geometry

        Returns:
            Info string for display in tree column
        """
        parts = []
        
        # Add UUID (first 8 characters)
        if hasattr(geometry, 'uuid') and geometry.uuid:
            parts.append(f"UUID:{geometry.uuid[:8]}")
        
        # Add Name if available
        if hasattr(geometry, 'name') and geometry.name:
            parts.append(f"Name:{geometry.name}")
        
        # Add DXF Handle if available
        if hasattr(geometry, 'dxf_handle') and geometry.dxf_handle:
            parts.append(f"DXF:{geometry.dxf_handle}")
        
        # If no info available, return empty string
        return " | ".join(parts) if parts else ""

    def get_geometry_properties(self, geometry: Geometry) -> str:
        """
        Get detailed properties text for a geometry with two sections:
        coordinates and computed properties.

        Args:
            geometry: The geometry

        Returns:
            Multi-line properties string with coordinates and computed properties sections
        """
        lines = []
        
        # Basic info
        lines.append(f"Type: {type(geometry).__name__}")
        if hasattr(geometry, 'name') and geometry.name:
            lines.append(f"Name: {geometry.name}")
        if hasattr(geometry, 'uuid') and geometry.uuid:
            lines.append(f"UUID: {geometry.uuid}")
        if hasattr(geometry, 'dxf_handle') and geometry.dxf_handle:
            lines.append(f"DXF Handle: {geometry.dxf_handle}")
        
        lines.append("")
        lines.append("=== COORDINATES ===")

        # Point coordinates
        if isinstance(geometry, Point):
            lines.append(f"Northing: {geometry.northing:.6f}")
            lines.append(f"Easting: {geometry.easting:.6f}")
            lines.append(f"Elevation: {geometry.elevation:.6f}")

        # LineSegment coordinates
        elif hasattr(geometry, 'start_point') and hasattr(geometry, 'end_point'):
            lines.append("Start Point:")
            lines.append(f"  N: {geometry.start_point.northing:.6f}")
            lines.append(f"  E: {geometry.start_point.easting:.6f}")
            lines.append(f"  Z: {geometry.start_point.elevation:.6f}")
            lines.append("")
            lines.append("End Point:")
            lines.append(f"  N: {geometry.end_point.northing:.6f}")
            lines.append(f"  E: {geometry.end_point.easting:.6f}")
            lines.append(f"  Z: {geometry.end_point.elevation:.6f}")

        # Add computed properties section
        lines.append("")
        lines.append("=== COMPUTED PROPERTIES ===")
        
        if isinstance(geometry, Point):
            # For points, show grid info if available
            if hasattr(geometry, 'grid') and geometry.grid:
                lines.append(f"Grid: {geometry.grid}")
        
        elif hasattr(geometry, 'start_point') and hasattr(geometry, 'end_point'):
            # For line segments, compute length and bearing
            try:
                # Calculate 2D and 3D distances
                dx = geometry.end_point.easting - geometry.start_point.easting
                dy = geometry.end_point.northing - geometry.start_point.northing
                dz = geometry.end_point.elevation - geometry.start_point.elevation
                
                length_2d = (dx**2 + dy**2)**0.5
                length_3d = (dx**2 + dy**2 + dz**2)**0.5
                
                lines.append(f"2D Length: {length_2d:.6f}")
                lines.append(f"3D Length: {length_3d:.6f}")
                
                # Calculate bearing/azimuth
                import math
                if length_2d > 0:
                    bearing_rad = math.atan2(dx, dy)
                    bearing_deg = math.degrees(bearing_rad)
                    if bearing_deg < 0:
                        bearing_deg += 360
                    lines.append(f"Azimuth: {bearing_deg:.6f}°")
                
                # Calculate slope
                if length_2d > 0:
                    slope_rad = math.atan2(dz, length_2d)
                    slope_deg = math.degrees(slope_rad)
                    lines.append(f"Slope: {slope_deg:.6f}°")
                    
            except Exception:
                lines.append("Unable to compute properties")

        # Polyline/Polygon properties
        elif hasattr(geometry, 'points'):
            lines.append(f"Vertices: {len(geometry.points)}")
            if len(geometry.points) > 0:
                lines.append("")
                lines.append("Points:")
                for i, pt in enumerate(geometry.points[:5]):  # Show first 5
                    lines.append(
                        f"  {i+1}. N={pt.northing}, E={pt.easting}, "
                        f"Z={pt.elevation}"
                    )
                if len(geometry.points) > 5:
                    lines.append(f"  ... and {len(geometry.points) - 5} more")

        # Common computed properties
        lines.append("")
        if hasattr(geometry, 'length'):
            try:
                length = geometry.length
                if callable(length):
                    length = length()
                lines.append(f"Length: {length:.4f}")
            except Exception as e:
                logger.debug(f"Could not get length: {e}")

        if hasattr(geometry, 'area'):
            try:
                area = geometry.area
                if callable(area):
                    area = area()
                lines.append(f"Area: {area:.4f}")
            except Exception as e:
                logger.debug(f"Could not get area: {e}")

        if hasattr(geometry, 'radius'):
            lines.append(f"Radius: {geometry.radius:.4f}")

        if hasattr(geometry, 'azimuth'):
            try:
                azimuth = geometry.azimuth
                if callable(azimuth):
                    azimuth = azimuth()
                lines.append(f"Azimuth: {azimuth.degrees:.4f}°")
            except Exception as e:
                logger.debug(f"Could not get azimuth: {e}")

        # Envelope
        if hasattr(geometry, 'envelope_2d'):
            try:
                env = geometry.envelope_2d
                if env:
                    lines.append("")
                    lines.append("Envelope:")
                    lines.append(
                        f"  N: {env.min_northing:.2f} to "
                        f"{env.max_northing:.2f}"
                    )
                    lines.append(
                        f"  E: {env.min_easting:.2f} to "
                        f"{env.max_easting:.2f}"
                    )
            except Exception as e:
                logger.debug(f"Could not get envelope: {e}")

        return "\n".join(lines)

    def get_multi_selection_properties(
        self,
        geometries: List[Geometry]
    ) -> str:
        """
        Get properties text for multiple selected geometries.

        Args:
            geometries: List of selected geometries

        Returns:
            Multi-line properties string
        """
        lines = []
        lines.append(f"Multiple Selection ({len(geometries)} items)")
        lines.append("")

        # Count by type
        type_counts: Dict[str, int] = {}
        for geom in geometries:
            type_name = type(geom).__name__
            type_counts[type_name] = type_counts.get(type_name, 0) + 1

        lines.append("Types:")
        for type_name, count in sorted(type_counts.items()):
            lines.append(f"  {type_name}: {count}")

        return "\n".join(lines)

    def get_collection_properties(
        self,
        collection: GeometryCollection
    ) -> str:
        """
        Get properties text for a collection.

        Args:
            collection: The collection

        Returns:
            Multi-line properties string
        """
        lines = []
        lines.append("Geometry Collection")
        lines.append("")
        lines.append(f"Total Geometries: {collection.count}")

        # Type counts
        type_counts = collection.get_type_counts()
        if type_counts:
            lines.append("")
            lines.append("Types:")
            for type_name, count in sorted(type_counts.items()):
                lines.append(f"  {type_name}: {count}")

        # Envelope
        try:
            if collection.envelope_2d:
                env = collection.envelope_2d
                lines.append("")
                lines.append("Envelope:")
                lines.append(
                    f"  N: {env.min_northing:.2f} to "
                    f"{env.max_northing:.2f}"
                )
                lines.append(
                    f"  E: {env.min_easting:.2f} to "
                    f"{env.max_easting:.2f}"
                )
        except Exception as e:
            logger.debug(f"Could not get collection envelope: {e}")

        return "\n".join(lines)

    def update_selection(
        self,
        geometries: List[Geometry],
        collection: Optional[GeometryCollection] = None
    ) -> None:
        """
        Update the current selection.

        Args:
            geometries: Selected geometries
            collection: Selected collection (if any)
        """
        self.selected_geometries = geometries
        self.selected_collection = collection

    def get_selection_properties(self) -> str:
        """
        Get properties text for current selection.

        Returns:
            Multi-line properties string
        """
        if len(self.selected_geometries) == 1:
            return self.get_geometry_properties(self.selected_geometries[0])
        elif len(self.selected_geometries) > 1:
            return self.get_multi_selection_properties(self.selected_geometries)
        elif self.selected_collection:
            return self.get_collection_properties(self.selected_collection)
        else:
            return ""

    def get_tree_data(
        self,
        collections: List[GeometryCollection],
        active_collection: Optional[GeometryCollection]
    ) -> List[Tuple[str, str, str, List[Tuple[str, str, str]]]]:
        """
        Get tree data structure for display.

        Args:
            collections: List of collections
            active_collection: The active collection

        Returns:
            List of tuples: (name, type, info, children)
            where children is a list of (name, type, info) tuples
        """
        tree_data = []

        for idx, collection in enumerate(collections):
            is_active = collection == active_collection
            coll_name = self.get_collection_display_name(
                collection, idx, is_active
            )
            coll_type = "GeometryCollection"
            coll_info = str(collection.count)

            # Get children (geometries)
            children = []
            for geom_idx, geometry in enumerate(collection.geometries):
                geom_name = self.get_geometry_display_name(geometry, geom_idx)
                geom_type = type(geometry).__name__
                geom_info = self.get_geometry_info_string(geometry)
                children.append((geom_name, geom_type, geom_info))

            tree_data.append((coll_name, coll_type, coll_info, children))

        return tree_data

    def can_move_geometries(self, geometries: List[Geometry], source_collection: GeometryCollection) -> bool:
        """
        Check if geometries can be moved from source collection.
        
        Args:
            geometries: List of geometries to move
            source_collection: Source collection
            
        Returns:
            True if geometries can be moved (not from default/import collections)
        """
        # Only allow move from user-created collections
        # Default and import collections should only allow copy
        if hasattr(source_collection, 'name'):
            collection_name = source_collection.name.lower()
            if 'default' in collection_name or 'import' in collection_name:
                return False
        return True

    def can_copy_geometries(self, geometries: List[Geometry]) -> bool:
        """
        Check if geometries can be copied.
        
        Args:
            geometries: List of geometries to copy
            
        Returns:
            True if geometries can be copied (always allowed)
        """
        return len(geometries) > 0

    def move_geometries(self, geometries: List[Geometry], 
                       source_collection: GeometryCollection,
                       destination_collection: GeometryCollection) -> bool:
        """
        Move geometries from source to destination collection.
        
        Args:
            geometries: List of geometries to move
            source_collection: Source collection
            destination_collection: Destination collection
            
        Returns:
            True if successful
        """
        if not self.can_move_geometries(geometries, source_collection):
            return False
            
        try:
            # Remove from source
            for geometry in geometries:
                if geometry in source_collection.geometries:
                    source_collection.remove(geometry)
            
            # Add to destination
            for geometry in geometries:
                destination_collection.add(geometry)
                
            return True
        except Exception as e:
            logger.error(f"Failed to move geometries: {e}")
            return False

    def copy_geometries(self, geometries: List[Geometry],
                       destination_collection: GeometryCollection) -> bool:
        """
        Copy geometries to destination collection.
        
        Args:
            geometries: List of geometries to copy
            destination_collection: Destination collection
            
        Returns:
            True if successful
        """
        if not self.can_copy_geometries(geometries):
            return False
            
        try:
            # Create copies and add to destination
            for geometry in geometries:
                # Create a copy with new UUID but same properties
                if isinstance(geometry, Point):
                    copy_geom = Point(
                        geometry.northing, 
                        geometry.easting, 
                        geometry.elevation,
                        grid=geometry.grid,
                        name=f"{geometry.name} (Copy)" if geometry.name else None,
                        dxf_handle=geometry.dxf_handle
                    )
                else:
                    # For other geometry types, try to create a basic copy
                    # This would need to be expanded for specific geometry types
                    copy_geom = geometry  # Fallback - would need proper copying logic
                
                destination_collection.add(copy_geom)
                
            return True
        except Exception as e:
            logger.error(f"Failed to copy geometries: {e}")
            return False

    def get_available_collections(self, collections: List[GeometryCollection], 
                                 exclude_collection: Optional[GeometryCollection] = None) -> List[GeometryCollection]:
        """
        Get list of collections available as destinations.
        
        Args:
            collections: All collections
            exclude_collection: Collection to exclude from list
            
        Returns:
            List of available destination collections
        """
        available = []
        for collection in collections:
            if collection != exclude_collection:
                available.append(collection)
        return available
