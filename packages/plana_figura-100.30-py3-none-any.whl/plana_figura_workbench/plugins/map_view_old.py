"""Map View plugin - visual canvas for geometry display."""

import tkinter as tk
from tkinter import ttk
from typing import Optional, Dict, Tuple, cast
import logging
import sys
from pathlib import Path

# Add Local Packages to path for vultus_serpentis
_local_packages = (
    Path(__file__).parent.parent.parent / "Local Packages" / "vultus_serpentis"
)
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

from vultus_serpentis.events import EventBus  # type: ignore

from plana_figura import Geometry, Point
from plana_figura.spatial import TwoDimensionalEnvelope
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.model.document import Observer
from plana_figura_workbench.events import (
    GeometrySelectedEvent,
    GeometryModifiedEvent,
    GeometryAddedEvent,
    GeometryDeletedEvent,
)

logger = logging.getLogger(__name__)


class MapView(ttk.Frame, Observer):
    """
    Map View plugin.

    Displays geometries on a canvas with zoom and pan capabilities.

    Features:
    - Visual rendering of all geometries
    - Zoom in/out with mouse wheel
    - Pan with middle mouse button
    - Selection with left click
    - Coordinate display
    """

    def __init__(
        self,
        parent: tk.Widget,
        document: PlanaFiguraDocument,
        event_bus: Optional[EventBus] = None,
        data_bucket=None
    ):
        """
        Initialize the Map View.

        Args:
            parent: Parent widget
            document: The document to display
            event_bus: Optional EventBus for plugin communication
            data_bucket: Optional DataBucket for shared data access
        """
        super().__init__(parent)
        self.document = document
        self.document.add_observer(self)
        self.event_bus = event_bus or EventBus.default()
        self.data_bucket = data_bucket

        # Viewport state
        self.viewport: Optional[TwoDimensionalEnvelope] = None
        self.zoom_level: float = 1.0
        self.pan_start: Optional[Tuple[int, int]] = None

        # Canvas item tracking
        # id(geometry) -> canvas_item_id
        self._geometry_to_canvas_item: Dict[int, int] = {}
        self._canvas_item_to_geometry: Dict[int, Geometry] = {}

        self._setup_ui()
        self._bind_events()
        self._subscribe_to_events()
        self._setup_data_bucket_sync()
        self._fit_to_contents()

        logger.info("Map View initialized")

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        # Canvas
        self.canvas = tk.Canvas(
            self,
            bg="white",
            cursor="crosshair"
        )
        self.canvas.grid(row=0, column=0, sticky="nsew")

        # Status bar
        status_frame = ttk.Frame(self)
        status_frame.grid(row=1, column=0, sticky="ew")

        self.status_label = ttk.Label(
            status_frame,
            text="Ready",
            relief=tk.SUNKEN,
            anchor=tk.W
        )
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2, pady=2)

        self.coord_label = ttk.Label(
            status_frame,
            text="N: 0.00, E: 0.00",
            relief=tk.SUNKEN,
            width=25
        )
        self.coord_label.pack(side=tk.RIGHT, padx=2, pady=2)

    def _bind_events(self) -> None:
        """Bind mouse and keyboard events."""
        # Mouse motion for coordinate display
        self.canvas.bind("<Motion>", self._on_mouse_move)

        # Left click for selection
        self.canvas.bind("<Button-1>", self._on_left_click)

        # Middle mouse button for panning
        self.canvas.bind("<Button-2>", self._on_pan_start)
        self.canvas.bind("<B2-Motion>", self._on_pan_drag)
        self.canvas.bind("<ButtonRelease-2>", self._on_pan_end)

        # Mouse wheel for zooming
        self.canvas.bind("<MouseWheel>", self._on_mouse_wheel)

        # Canvas resize
        self.canvas.bind("<Configure>", self._on_canvas_resize)

    def _subscribe_to_events(self) -> None:
        """Subscribe to EventBus events."""
        self.event_bus.subscribe(
            GeometrySelectedEvent, self._on_geometry_selected_event
        )
        self.event_bus.subscribe(
            GeometryModifiedEvent, self._on_geometry_modified_event
        )
        self.event_bus.subscribe(
            GeometryAddedEvent, self._on_geometry_added_event
        )
        self.event_bus.subscribe(
            GeometryDeletedEvent, self._on_geometry_deleted_event
        )
        logger.debug("Map View subscribed to EventBus events")

    def _fit_to_contents(self) -> None:
        """Fit the viewport to show all geometries."""
        all_geometries = self.document.get_all_geometries()

        if not all_geometries:
            # Default viewport
            self.viewport = TwoDimensionalEnvelope(
                min_northing=0,
                max_northing=100,
                min_easting=0,
                max_easting=100
            )
            self.zoom_level = 1.0
            self._render()
            return

        # Calculate envelope of all geometries
        min_n = min_e = float('inf')
        max_n = max_e = float('-inf')

        for geom in all_geometries:
            if isinstance(geom, Point):
                min_n = min(min_n, geom.northing)
                max_n = max(max_n, geom.northing)
                min_e = min(min_e, geom.easting)
                max_e = max(max_e, geom.easting)
            elif hasattr(geom, 'envelope_2d') and geom.envelope_2d:
                env = geom.envelope_2d
                min_n = min(min_n, env.min_northing)
                max_n = max(max_n, env.max_northing)
                min_e = min(min_e, env.min_easting)
                max_e = max(max_e, env.max_easting)

        # Add 10% margin
        n_range = max_n - min_n
        e_range = max_e - min_e

        if n_range == 0:
            n_range = 10
        if e_range == 0:
            e_range = 10

        margin = 0.1
        self.viewport = TwoDimensionalEnvelope(
            min_northing=min_n - n_range * margin,
            max_northing=max_n + n_range * margin,
            min_easting=min_e - e_range * margin,
            max_easting=max_e + e_range * margin
        )

        self.zoom_level = 1.0
        self._render()

    def _world_to_screen(
        self,
        northing: float,
        easting: float
    ) -> Tuple[int, int]:
        """
        Convert world coordinates to screen pixels.

        Args:
            northing: World northing coordinate
            easting: World easting coordinate

        Returns:
            (x, y) screen coordinates
        """
        if not self.viewport:
            return (0, 0)

        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()

        if canvas_width <= 1 or canvas_height <= 1:
            return (0, 0)

        # Normalize to 0-1
        x_norm = (easting - self.viewport.min_easting) / self.viewport.width
        y_norm = (northing - self.viewport.min_northing) / self.viewport.height

        # Convert to screen (flip Y axis - screen Y increases downward)
        screen_x = int(x_norm * canvas_width)
        screen_y = int((1 - y_norm) * canvas_height)

        return (screen_x, screen_y)

    def _screen_to_world(self, screen_x: int, screen_y: int) -> Tuple[float, float]:
        """
        Convert screen pixels to world coordinates.

        Args:
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate

        Returns:
            (northing, easting) world coordinates
        """
        if not self.viewport:
            return (0.0, 0.0)

        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()

        if canvas_width <= 1 or canvas_height <= 1:
            return (0.0, 0.0)

        # Normalize to 0-1
        x_norm = screen_x / canvas_width
        y_norm = 1 - (screen_y / canvas_height)  # Flip Y

        # Convert to world
        easting = self.viewport.min_easting + (x_norm * self.viewport.width)
        northing = self.viewport.min_northing + (y_norm * self.viewport.height)

        return (northing, easting)

    def _render(self) -> None:
        """Render all geometries on the canvas."""
        # Clear canvas
        self.canvas.delete("all")
        self._geometry_to_canvas_item.clear()
        self._canvas_item_to_geometry.clear()

        # Draw grid
        self._draw_grid()

        # Draw all geometries
        for collection in self.document.collections:
            for geometry in collection.geometries:
                self._draw_geometry(geometry)

        # Highlight selection
        self._update_selection_display()

        logger.debug(f"Rendered {self.document.get_geometry_count()} geometries")

    def _draw_grid(self) -> None:
        """Draw grid lines on the canvas."""
        if not self.viewport:
            return

        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()

        if canvas_width <= 1 or canvas_height <= 1:
            return

        # Calculate grid interval (aim for ~10 lines)
        grid_interval = self.document.grid.grid_interval

        # Draw vertical grid lines
        e_start = (int(self.viewport.min_easting / grid_interval)
                   * grid_interval)
        e = e_start
        while e <= self.viewport.max_easting:
            x1, y1 = self._world_to_screen(self.viewport.min_northing, e)
            x2, y2 = self._world_to_screen(self.viewport.max_northing, e)
            self.canvas.create_line(
                x1, y1, x2, y2,
                fill="lightgray",
                tags="grid"
            )
            e += grid_interval

        # Draw horizontal grid lines
        n_start = (int(self.viewport.min_northing / grid_interval)
                   * grid_interval)
        n = n_start
        while n <= self.viewport.max_northing:
            x1, y1 = self._world_to_screen(n, self.viewport.min_easting)
            x2, y2 = self._world_to_screen(n, self.viewport.max_easting)
            self.canvas.create_line(
                x1, y1, x2, y2,
                fill="lightgray",
                tags="grid"
            )
            n += grid_interval

    def _draw_geometry(self, geometry: Geometry) -> None:
        """
        Draw a geometry on the canvas.

        Args:
            geometry: The geometry to draw
        """
        if isinstance(geometry, Point):
            self._draw_point(geometry)
        elif hasattr(geometry, 'start_point') and hasattr(geometry, 'end_point'):
            # Line segment
            self._draw_line_segment(geometry)
        # Add more geometry types as needed

    def _draw_point(self, point: Point) -> None:
        """
        Draw a point on the canvas.

        Args:
            point: The point to draw
        """
        x, y = self._world_to_screen(point.northing, point.easting)

        # Draw as small circle
        radius = 3
        item_id = self.canvas.create_oval(
            x - radius, y - radius,
            x + radius, y + radius,
            fill="blue",
            outline="darkblue",
            tags="geometry"
        )

        self._geometry_to_canvas_item[id(point)] = item_id
        self._canvas_item_to_geometry[item_id] = cast(Geometry, point)

    def _draw_line_segment(self, line_segment: Geometry) -> None:
        """
        Draw a line segment on the canvas.

        Args:
            line_segment: The line segment to draw
        """
        # Type narrowing - we know this has start_point and end_point
        start_pt = getattr(line_segment, 'start_point')
        end_pt = getattr(line_segment, 'end_point')

        x1, y1 = self._world_to_screen(
            start_pt.northing,
            start_pt.easting
        )
        x2, y2 = self._world_to_screen(
            end_pt.northing,
            end_pt.easting
        )

        item_id = self.canvas.create_line(
            x1, y1, x2, y2,
            fill="black",
            width=2,
            tags="geometry"
        )

        self._geometry_to_canvas_item[id(line_segment)] = item_id
        self._canvas_item_to_geometry[item_id] = line_segment

    def _update_selection_display(self) -> None:
        """Update the visual display of selected geometries."""
        # Reset all geometries to normal appearance
        for item_id in self._canvas_item_to_geometry.keys():
            self.canvas.itemconfig(item_id, width=2)

        # Highlight selected geometries
        for geometry in self.document.selection:
            if id(geometry) in self._geometry_to_canvas_item:
                item_id = self._geometry_to_canvas_item[id(geometry)]
                self.canvas.itemconfig(item_id, width=3, outline="red")

    def _on_mouse_move(self, event: tk.Event) -> None:
        """
        Handle mouse motion for coordinate display.

        Args:
            event: The mouse event
        """
        northing, easting = self._screen_to_world(event.x, event.y)
        self.coord_label.config(text=f"N: {northing:.2f}, E: {easting:.2f}")

    def _on_left_click(self, event: tk.Event) -> None:
        """
        Handle left click for selection.

        Args:
            event: The mouse event
        """
        # Find item at click location
        item_id = self.canvas.find_closest(event.x, event.y)[0]

        if item_id in self._canvas_item_to_geometry:
            geometry = self._canvas_item_to_geometry[item_id]

            # Check if Ctrl is pressed for multi-select
            state_int = event.state if isinstance(event.state, int) else 0
            if state_int & 0x0004:  # Ctrl key
                self.document.select_geometries([geometry], mode="toggle")
            else:
                self.document.select_geometries([geometry], mode="replace")

            # Publish selection event
            self.event_bus.publish(GeometrySelectedEvent(
                geometry=geometry,
                source="map_view"
            ))

            self.status_label.config(
                text=f"Selected: {type(geometry).__name__}"
            )
        else:
            # Clicked on empty space - clear selection
            self.document.clear_selection()

            # Publish deselection event
            self.event_bus.publish(GeometrySelectedEvent(
                geometry=None,
                source="map_view"
            ))

            self.status_label.config(text="Ready")

    def _on_pan_start(self, event: tk.Event) -> None:
        """
        Handle pan start.

        Args:
            event: The mouse event
        """
        self.pan_start = (event.x, event.y)
        self.canvas.config(cursor="fleur")

    def _on_pan_drag(self, event: tk.Event) -> None:
        """
        Handle pan drag.

        Args:
            event: The mouse event
        """
        if not self.pan_start or not self.viewport:
            return

        # Calculate delta in screen coordinates
        dx = event.x - self.pan_start[0]
        dy = event.y - self.pan_start[1]

        # Convert to world coordinates
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()

        if canvas_width <= 1 or canvas_height <= 1:
            return

        world_dx = -dx * self.viewport.width / canvas_width
        world_dy = dy * self.viewport.height / canvas_height

        # Update viewport
        self.viewport = TwoDimensionalEnvelope(
            min_northing=self.viewport.min_northing + world_dy,
            max_northing=self.viewport.max_northing + world_dy,
            min_easting=self.viewport.min_easting + world_dx,
            max_easting=self.viewport.max_easting + world_dx
        )

        self.pan_start = (event.x, event.y)
        self._render()

    def _on_pan_end(self, event: tk.Event) -> None:
        """
        Handle pan end.

        Args:
            event: The mouse event
        """
        self.pan_start = None
        self.canvas.config(cursor="crosshair")

    def _on_mouse_wheel(self, event: tk.Event) -> None:
        """
        Handle mouse wheel for zooming.

        Args:
            event: The mouse event
        """
        if not self.viewport:
            return

        # Get mouse position in world coordinates
        mouse_n, mouse_e = self._screen_to_world(event.x, event.y)

        # Zoom factor
        if event.delta > 0:
            factor = 0.9  # Zoom in
        else:
            factor = 1.1  # Zoom out

        # Calculate new viewport size
        new_width = self.viewport.width * factor
        new_height = self.viewport.height * factor

        # Keep mouse position fixed
        x_ratio = ((mouse_e - self.viewport.min_easting)
                   / self.viewport.width)
        y_ratio = ((mouse_n - self.viewport.min_northing)
                   / self.viewport.height)

        new_min_e = mouse_e - new_width * x_ratio
        new_max_e = new_min_e + new_width
        new_min_n = mouse_n - new_height * y_ratio
        new_max_n = new_min_n + new_height

        self.viewport = TwoDimensionalEnvelope(
            min_northing=new_min_n,
            max_northing=new_max_n,
            min_easting=new_min_e,
            max_easting=new_max_e
        )

        self.zoom_level *= factor
        self._render()

        self.status_label.config(text=f"Zoom: {self.zoom_level:.2f}x")
        
        # Publish viewport state to DataBucket
        self._publish_viewport_state()

    def _setup_data_bucket_sync(self) -> None:
        """Set up DataBucket synchronization for viewport state."""
        if self.data_bucket:
            from plana_figura_workbench.model import DataBucketKeys
            
            # Observe viewport changes from other sources
            self.data_bucket.observe(DataBucketKeys.VIEWPORT_CENTER, self._on_viewport_changed)
            self.data_bucket.observe(DataBucketKeys.VIEWPORT_ZOOM, self._on_viewport_changed)
    
    def _publish_viewport_state(self) -> None:
        """Publish current viewport state to DataBucket."""
        if self.data_bucket and self.viewport:
            from plana_figura_workbench.model import DataBucketKeys
            
            center = (
                (self.viewport.min_northing + self.viewport.max_northing) / 2,
                (self.viewport.min_easting + self.viewport.max_easting) / 2
            )
            
            self.data_bucket.set(DataBucketKeys.VIEWPORT_CENTER, center, source='map_view')
            self.data_bucket.set(DataBucketKeys.VIEWPORT_ZOOM, self.zoom_level, source='map_view')
    
    def _on_viewport_changed(self, key: str, new_value, old_value, source: str) -> None:
        """Handle viewport changes from other plugins."""
        # Don't respond to our own changes
        if source == 'map_view':
            return
        
        # Could implement viewport sync from other sources here if needed
        logger.debug(f"Viewport changed by {source}: {key} = {new_value}")

    def _on_canvas_resize(self, event: tk.Event) -> None:
        """
        Handle canvas resize events.

        Args:
            event: The resize event
        """
        self._render()

    def on_document_update(self, observable: PlanaFiguraDocument) -> None:
        """
        Called when the document changes.

        Args:
            observable: The document that changed
        """
        self._render()

    # EventBus event handlers

    def _on_geometry_selected_event(self, event: GeometrySelectedEvent) -> None:
        """
        Handle geometry selection event from EventBus.

        Args:
            event: The selection event
        """
        # Don't respond to our own events
        if event.source == "map_view":
            return

        # Update selection display
        self._update_selection_display()
        logger.debug(f"Map View received selection event from {event.source}")

    def _on_geometry_modified_event(self, event: GeometryModifiedEvent) -> None:
        """
        Handle geometry modification event from EventBus.

        Args:
            event: The modification event
        """
        # Re-render to show changes
        self._render()
        logger.debug("Map View received geometry modified event")

    def _on_geometry_added_event(self, event: GeometryAddedEvent) -> None:
        """
        Handle geometry added event from EventBus.

        Args:
            event: The added event
        """
        # Re-render to show new geometry
        self._render()
        logger.debug("Map View received geometry added event")

    def _on_geometry_deleted_event(self, event: GeometryDeletedEvent) -> None:
        """
        Handle geometry deleted event from EventBus.

        Args:
            event: The deleted event
        """
        # Re-render to remove geometry
        self._render()
        logger.debug("Map View received geometry deleted event")

    # Observer protocol method
    def update(self, observable) -> None:  # type: ignore[override]
        """Observer protocol method."""
        self.on_document_update(observable)
