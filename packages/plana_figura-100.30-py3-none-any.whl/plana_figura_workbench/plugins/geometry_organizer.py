"""Geometry Organizer plugin - tree view for geometry management."""

import tkinter as tk
from tkinter import ttk
from typing import Dict, List, Optional
import logging
import sys
import math
from pathlib import Path

# Add Local Packages to path for vultus_serpentis
_local_packages = (
    Path(__file__).parent.parent.parent / "Local Packages" / "vultus_serpentis"
)
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

from vultus_serpentis.events import EventBus  # type: ignore

from plana_figura import Geometry, GeometryCollection
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.model.document import Observer
from plana_figura_workbench.plugins.geometry_organizer_controller import (
    GeometryOrganizerController
)
from plana_figura_workbench.events import GeometrySelectedEvent, SelectionChangedEvent
from plana_figura_workbench.dialogs.properties_dialog import GeometryPropertiesDialog

logger = logging.getLogger(__name__)


class GeometryOrganizer(ttk.Frame, Observer):
    """
    Geometry Organizer plugin.

    Displays a tree view of all geometry collections and their contents.
    Allows selection, renaming, and basic organization of geometries.

    Features:
    - Tree view with collections and geometries
    - Properties panel showing geometry details
    - Selection synchronization with other plugins
    - Context menu for common operations
    """

    def __init__(
        self,
        parent: tk.Widget,
        document: PlanaFiguraDocument,
        event_bus: Optional[EventBus] = None,
        selection_manager=None,
        data_bucket=None
    ):
        """
        Initialize the Geometry Organizer.

        Args:
            parent: Parent widget
            document: The document to display
            event_bus: Optional EventBus for plugin communication
            selection_manager: Optional SelectionManager for centralized selection
            data_bucket: Optional DataBucket for shared data access
        """
        super().__init__(parent)
        self.document = document
        self.document.add_observer(self)
        self.event_bus = event_bus or EventBus.default()
        self.selection_manager = selection_manager
        self.data_bucket = data_bucket

        # Controller for business logic
        self.controller = GeometryOrganizerController()

        # Map tree item IDs to geometry objects
        self._item_to_geometry: Dict[str, Geometry] = {}
        self._geometry_to_item: Dict[int, str] = {}  # Use id(geometry) as key

        # Map tree item IDs to collections
        self._item_to_collection: Dict[str, GeometryCollection] = {}
        self._collection_to_item: Dict[int, str] = {}  # Use id(collection) as key

        # Flag to prevent recursive updates
        self._updating = False

        self._setup_ui()
        self._populate_tree()

        # Subscribe to SelectionManager changes
        logger.info("=== GeometryOrganizer: Initializing ===")
        logger.info(f"Selection manager available: {self.selection_manager is not None}")
        if self.selection_manager is not None:
            self.selection_manager.add_observer(self._on_selection_changed)
            logger.info(f"Subscribed to SelectionManager, observer count: {len(self.selection_manager._observers)}")
        else:
            logger.warning("No selection_manager available")

        logger.info("=== Geometry Organizer initialized ===")

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Configure grid
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=0)  # Toolbar
        self.rowconfigure(1, weight=0)  # Filter/Collection bar
        self.rowconfigure(2, weight=3)  # Tree
        self.rowconfigure(3, weight=1)  # Properties

        # Toolbar
        self._create_toolbar()

        # Filter and collection bar
        self._create_filter_bar()

        # Tree view
        self._create_tree_view()

        # Properties panel
        self._create_properties_panel()

    def _create_toolbar(self) -> None:
        """Create the toolbar with action buttons."""
        toolbar = ttk.Frame(self)
        toolbar.grid(row=0, column=0, sticky="ew", padx=5, pady=5)

        # Geometry type selector
        ttk.Label(toolbar, text="Type:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.geometry_type_var = tk.StringVar(value="Point")
        self.geometry_type_combo = ttk.Combobox(
            toolbar,
            textvariable=self.geometry_type_var,
            values=["Point", "Line", "Circular Arc", "Polyline", "Polygon"],
            state="readonly",
            width=15
        )
        self.geometry_type_combo.pack(side=tk.LEFT, padx=(0, 5))

        # Add button
        self.add_button = ttk.Button(
            toolbar,
            text="Add",
            command=self._on_add_geometry
        )
        self.add_button.pack(side=tk.LEFT, padx=2)

        # Edit button
        self.edit_button = ttk.Button(
            toolbar,
            text="Edit",
            command=self._on_edit_geometry,
            state=tk.DISABLED
        )
        self.edit_button.pack(side=tk.LEFT, padx=2)

        # Delete button
        self.delete_button = ttk.Button(
            toolbar,
            text="Delete",
            command=self._on_delete_geometry,
            state=tk.DISABLED
        )
        self.delete_button.pack(side=tk.LEFT, padx=2)

        # Transform with Measurement button
        self.transform_button = ttk.Button(
            toolbar,
            text="Transform",
            command=self._on_transform_with_measurement,
            state=tk.DISABLED
        )
        self.transform_button.pack(side=tk.LEFT, padx=2)

        # Separator
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(
            side=tk.LEFT, fill=tk.Y, padx=5
        )

        # Collection management
        ttk.Button(
            toolbar,
            text="New Collection",
            command=self._on_new_collection
        ).pack(side=tk.LEFT, padx=2)

        ttk.Button(
            toolbar,
            text="Delete Collection",
            command=self._on_delete_collection
        ).pack(side=tk.LEFT, padx=2)

        # Separator
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(
            side=tk.LEFT, fill=tk.Y, padx=5
        )

        # Refresh button
        ttk.Button(
            toolbar,
            text="Refresh",
            command=self._populate_tree
        ).pack(side=tk.LEFT, padx=2)

    def _create_filter_bar(self) -> None:
        """Create the filter and collection selection bar."""
        filter_frame = ttk.Frame(self)
        filter_frame.grid(row=1, column=0, sticky="ew", padx=5, pady=5)

        # Filter label and dropdown
        ttk.Label(filter_frame, text="Filter:").pack(side=tk.LEFT, padx=(0, 5))

        self.filter_var = tk.StringVar(value="all")
        self.filter_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.filter_var,
            values=["all", "points", "lines", "polylines", "polygons"],
            state="readonly",
            width=15
        )
        self.filter_combo.pack(side=tk.LEFT, padx=(0, 15))
        self.filter_combo.bind("<<ComboboxSelected>>", self._on_filter_changed)

        # Collection label and dropdown
        ttk.Label(filter_frame, text="Collection:").pack(side=tk.LEFT, padx=(0, 5))

        self.collection_var = tk.StringVar()
        self.collection_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.collection_var,
            state="readonly",
            width=20
        )
        self.collection_combo.pack(side=tk.LEFT, padx=(0, 15))
        self.collection_combo.bind(
            "<<ComboboxSelected>>",
            self._on_collection_changed
        )

        # Search box
        ttk.Label(filter_frame, text="Search:").pack(side=tk.LEFT, padx=(0, 5))
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(
            filter_frame,
            textvariable=self.search_var,
            width=20
        )
        self.search_entry.pack(side=tk.LEFT)
        self.search_var.trace_add("write", self._on_search_changed)

        # Update collection list
        self._update_collection_list()

    def _create_tree_view(self) -> None:
        """Create the tree view for geometries."""
        tree_frame = ttk.Frame(self)
        tree_frame.grid(row=2, column=0, sticky="nsew", padx=5, pady=5)
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)

        # Tree view with scrollbar
        self.tree = ttk.Treeview(
            tree_frame,
            columns=("type", "count"),
            selectmode="extended"
        )
        self.tree.grid(row=0, column=0, sticky="nsew")

        # Scrollbar
        scrollbar = ttk.Scrollbar(
            tree_frame,
            orient="vertical",
            command=self.tree.yview
        )
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=scrollbar.set)

        # Configure columns
        self.tree.heading("#0", text="Name")
        self.tree.heading("type", text="Type")
        self.tree.heading("count", text="Count/Info")

        self.tree.column("#0", width=200)
        self.tree.column("type", width=100)
        self.tree.column("count", width=100)

        # Bind selection event
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        
        # Bind right-click for context menu
        self.tree.bind("<Button-3>", self._on_tree_right_click)

    def _create_properties_panel(self) -> None:
        """Create the properties panel."""
        props_frame = ttk.LabelFrame(self, text="Properties")
        props_frame.grid(row=3, column=0, sticky="nsew", padx=5, pady=5)
        props_frame.columnconfigure(0, weight=1)
        props_frame.rowconfigure(0, weight=1)

        # Properties text widget
        self.properties_text = tk.Text(
            props_frame,
            height=8,
            wrap=tk.WORD,
            state=tk.DISABLED
        )
        self.properties_text.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

        # Properties scrollbar
        props_scrollbar = ttk.Scrollbar(
            props_frame,
            orient="vertical",
            command=self.properties_text.yview
        )
        props_scrollbar.grid(row=0, column=1, sticky="ns")
        self.properties_text.configure(yscrollcommand=props_scrollbar.set)

    def _populate_tree(self) -> None:
        """Populate the tree view with current document data."""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)

        self._item_to_geometry.clear()
        self._geometry_to_item.clear()
        self._item_to_collection.clear()
        self._collection_to_item.clear()

        # Add folders and their collections
        folder_manager = self.document.geometry_folder_manager
        
        # First, add root folders (Imports, Exports)
        for folder in folder_manager.root_folders:
            self._add_folder_to_tree("", folder)
        
        # Then add collections that aren't in any folder
        collections_in_folders = []
        for folder in folder_manager.get_all_folders():
            collections_in_folders.extend(folder.collections)
        
        # Add remaining collections at root level
        for idx, collection in enumerate(self.document.collections):
            if collection not in collections_in_folders:
                is_active = collection == self.document.active_collection
                collection_name = self.controller.get_collection_display_name(
                    collection, idx, is_active
                )

                item_id = self.tree.insert(
                    "",
                    "end",
                    text=collection_name,
                    values=("GeometryCollection", collection.count),
                    open=True
                )

                self._item_to_collection[item_id] = collection
                self._collection_to_item[id(collection)] = item_id

                # Add geometries in this collection
                for geom_idx, geometry in enumerate(collection.geometries):
                    self._add_geometry_to_tree(item_id, geometry, geom_idx)

        logger.debug(f"Tree populated with {len(self.document.collections)} "
                     f"collections and {len(folder_manager.root_folders)} folders")

    def _add_geometry_to_tree(
        self,
        parent_id: str,
        geometry: Geometry,
        index: int
    ) -> str:
        """
        Add a geometry to the tree.

        Args:
            parent_id: Parent tree item ID
            geometry: The geometry to add
            index: Index in the collection

        Returns:
            The tree item ID
        """
        # Use controller to get display name (includes name if available)
        geom_display_name = self.controller.get_geometry_display_name(geometry, index)
        geom_type = type(geometry).__name__
        geom_info = self._get_geometry_info(geometry)

        item_id = self.tree.insert(
            parent_id,
            "end",
            text=geom_display_name,
            values=(geom_type, geom_info)
        )

        self._item_to_geometry[item_id] = geometry
        self._geometry_to_item[id(geometry)] = item_id

        return item_id

    def _add_folder_to_tree(self, parent_id: str, folder) -> str:
        """
        Add a folder to the tree (recursive).
        
        Args:
            parent_id: Parent tree item ID
            folder: The folder to add
            
        Returns:
            The tree item ID
        """
        # Add folder node
        folder_icon = "📁" if folder.is_virtual else "📂"
        folder_name = f"{folder_icon} {folder.name}"
        
        item_id = self.tree.insert(
            parent_id,
            "end",
            text=folder_name,
            values=("Folder", f"{folder.get_collection_count()} collections"),
            open=folder.expanded
        )
        
        # Add collections in this folder
        for idx, collection in enumerate(folder.collections):
            is_active = collection == self.document.active_collection
            collection_name = self.controller.get_collection_display_name(
                collection, idx, is_active
            )
            
            coll_item_id = self.tree.insert(
                item_id,
                "end",
                text=collection_name,
                values=("GeometryCollection", collection.count),
                open=True
            )
            
            self._item_to_collection[coll_item_id] = collection
            self._collection_to_item[id(collection)] = coll_item_id
            
            # Add geometries in this collection
            for geom_idx, geometry in enumerate(collection.geometries):
                self._add_geometry_to_tree(coll_item_id, geometry, geom_idx)
        
        # Add child folders (recursive)
        for child_folder in folder.children:
            self._add_folder_to_tree(item_id, child_folder)
        
        return item_id

    def _get_geometry_info(self, geometry: Geometry) -> str:
        """
        Get summary information for a geometry.

        Args:
            geometry: The geometry

        Returns:
            Summary string
        """
        # Use controller to get geometry info string
        return self.controller.get_geometry_info_string(geometry)

    def _on_tree_select(self, event: tk.Event) -> None:
        """
        Handle tree selection changes.

        Args:
            event: The selection event
        """
        # Prevent recursive updates
        if self._updating:
            return
            
        selected_items = self.tree.selection()

        if not selected_items:
            self._clear_properties()
            return

        # Get selected geometries
        selected_geometries: List[Geometry] = []

        for item_id in selected_items:
            if item_id in self._item_to_geometry:
                selected_geometries.append(self._item_to_geometry[item_id])

        # Update properties panel
        if len(selected_geometries) == 1:
            self._show_properties(selected_geometries[0])
        elif len(selected_geometries) > 1:
            self._show_multi_selection_properties(selected_geometries)
        else:
            # Collection selected
            if selected_items[0] in self._item_to_collection:
                collection = self._item_to_collection[selected_items[0]]
                self._show_collection_properties(collection)

        # Update button states based on selection
        if selected_geometries:
            # Enable edit and delete buttons
            self.edit_button.config(state=tk.NORMAL)
            self.delete_button.config(state=tk.NORMAL)
            # Enable transform button for single selection
            if len(selected_geometries) == 1:
                self.transform_button.config(state=tk.NORMAL)
            else:
                self.transform_button.config(state=tk.DISABLED)
        else:
            # Disable all action buttons
            self.edit_button.config(state=tk.DISABLED)
            self.delete_button.config(state=tk.DISABLED)
            self.transform_button.config(state=tk.DISABLED)

        # Update selection (don't trigger if we're responding to a document change)
        self._updating = True
        try:
            if self.selection_manager:
                # Use centralized selection manager
                logger.info(f"=== GeometryOrganizer: Updating selection ===")
                logger.info(f"Selected geometries count: {len(selected_geometries)}")
                self.selection_manager.select(selected_geometries, source="geometry_organizer")
                logger.info(f"Selection manager count after update: {self.selection_manager.get_count()}")
            else:
                # Fallback to old method
                logger.warning("No selection manager, using fallback")
                if selected_geometries:
                    self.document.select_geometries(selected_geometries)

                    # Publish selection event via EventBus
                    self.event_bus.publish(SelectionChangedEvent(
                        selected_geometries=selected_geometries,
                        source="geometry_organizer"
                    ))
                    
                    if len(selected_geometries) == 1:
                        self.event_bus.publish(GeometrySelectedEvent(
                            geometry=selected_geometries[0],
                            source="geometry_organizer"
                        ))
                else:
                    # Publish deselection events
                    self.event_bus.publish(SelectionChangedEvent(
                        selected_geometries=[],
                        source="geometry_organizer"
                    ))
                    self.event_bus.publish(GeometrySelectedEvent(
                        geometry=None,
                        source="geometry_organizer"
                    ))
        finally:
            self._updating = False

    def _show_properties(self, geometry: Geometry) -> None:
        """
        Show properties for a single geometry.

        Args:
            geometry: The geometry to display
        """
        # Use controller to get properties text
        props_text = self.controller.get_geometry_properties(geometry)

        self.properties_text.configure(state=tk.NORMAL)
        self.properties_text.delete(1.0, tk.END)
        self.properties_text.insert(tk.END, props_text)
        self.properties_text.configure(state=tk.DISABLED)

    def _show_multi_selection_properties(
        self,
        geometries: List[Geometry]
    ) -> None:
        """
        Show properties for multiple selected geometries.

        Args:
            geometries: List of selected geometries
        """
        # Use controller to get properties text
        props_text = self.controller.get_multi_selection_properties(geometries)

        self.properties_text.configure(state=tk.NORMAL)
        self.properties_text.delete(1.0, tk.END)
        self.properties_text.insert(tk.END, props_text)
        self.properties_text.configure(state=tk.DISABLED)

    def _show_collection_properties(
        self,
        collection: GeometryCollection
    ) -> None:
        """
        Show properties for a collection.

        Args:
            collection: The collection to display
        """
        # Use controller to get properties text
        props_text = self.controller.get_collection_properties(collection)

        self.properties_text.configure(state=tk.NORMAL)
        self.properties_text.delete(1.0, tk.END)
        self.properties_text.insert(tk.END, props_text)
        self.properties_text.configure(state=tk.DISABLED)

    def _clear_properties(self) -> None:
        """Clear the properties panel."""
        self.properties_text.configure(state=tk.NORMAL)
        self.properties_text.delete(1.0, tk.END)
        self.properties_text.configure(state=tk.DISABLED)

    def on_document_update(self, observable: PlanaFiguraDocument) -> None:
        """
        Called when the document changes.

        Args:
            observable: The document that changed
        """
        # Skip updates if we're currently updating to prevent recursion
        if self._updating:
            return
            
        # Repopulate the tree
        self._populate_tree()

        # Update selection display
        self._update_selection_display()

    # Observer protocol method
    def update(self, observable) -> None:  # type: ignore[override]
        """Observer protocol method."""
        self.on_document_update(observable)

    def _update_selection_display(self) -> None:
        """Update the tree to reflect the current document selection."""
        # Clear current tree selection
        self.tree.selection_remove(*self.tree.selection())

        # Select items corresponding to document selection
        for geometry in self.document.selection:
            if id(geometry) in self._geometry_to_item:
                item_id = self._geometry_to_item[id(geometry)]
                self.tree.selection_add(item_id)

    def _on_selection_changed(self, selection_manager, source: str) -> None:
        """
        Called when selection changes in SelectionManager.

        Args:
            selection_manager: The SelectionManager that changed
            source: Source of the selection change
        """
        logger.info(f"=== GeometryOrganizer: _on_selection_changed called ===")
        logger.info(f"Source: {source}")
        logger.info(f"Selection count: {selection_manager.get_count()}")

        # Don't update if we caused the change (to avoid recursion)
        if source == "geometry_organizer":
            logger.info("Ignoring own selection change (avoiding loop)")
            return

        # Update the tree display to reflect the new selection
        logger.info("Updating tree selection display")
        self._update_selection_display()
        logger.info(f"=== GeometryOrganizer: Selection changed by {source}, updated display ===")

    # Toolbar button handlers
    def _on_add_geometry(self) -> None:
        """Handle Add button click."""
        geometry_type = self.geometry_type_var.get()
        logger.info(f"Add {geometry_type} requested")
        
        from plana_figura_workbench.dialogs import PointDialog, LineDialog, PolylineDialog
        from plana_figura_workbench.dialogs.geometry_dialogs import PolygonDialog, CircularArcDialog
        
        dialog = None
        if geometry_type == "Point":
            dialog = PointDialog(self, title="Create Point")
        elif geometry_type == "Line":
            dialog = LineDialog(self, title="Create Line")
        elif geometry_type == "Circular Arc":
            dialog = CircularArcDialog(self, title="Create Circular Arc")
        elif geometry_type == "Polyline":
            dialog = PolylineDialog(self, title="Create Polyline")
        elif geometry_type == "Polygon":
            dialog = PolygonDialog(self, title="Create Polygon")
        
        if dialog:
            self.wait_window(dialog)
            if dialog.result:
                # Add to active collection
                if self.document.active_collection:
                    self.document.active_collection.add(dialog.result)
                    self.document.modified = True
                    # Notify observers so MapView and other plugins update
                    self.document._notify_observers()
                    logger.info(f"Added {type(dialog.result).__name__} to active collection")
                    # Refresh the tree view
                    self._populate_tree()
                    # Publish event for other plugins
                    if hasattr(self, 'event_bus') and self.event_bus:
                        from vultus_serpentis.events import Event
                        self.event_bus.publish(Event('geometry_added', {'geometry': dialog.result}))
                else:
                    from tkinter import messagebox
                    messagebox.showwarning(
                        "No Active Collection",
                        "Please create or select a collection first.",
                        parent=self
                    )

    def _on_edit_geometry(self) -> None:
        """Handle Edit button click."""
        logger.info("Edit geometry requested")
        # TODO: Implement edit geometry dialog

    def _on_delete_geometry(self) -> None:
        """Handle Delete button click."""
        logger.info("Delete geometry requested")
        # TODO: Implement delete geometry

    def _on_transform_with_measurement(self) -> None:
        """Handle Transform with Measurement button click."""
        logger.info("Transform with measurement requested")
        
        # Get selected geometry
        selected_items = self.tree.selection()
        if len(selected_items) != 1:
            from tkinter import messagebox
            messagebox.showwarning(
                "Select One Geometry",
                "Please select exactly one geometry to transform.",
                parent=self
            )
            return
        
        item_id = selected_items[0]
        geometry = self._item_to_geometry.get(item_id)
        
        if not geometry:
            return
        
        # Get measurements from the document
        all_measurements = []
        for collection in self.document.collections:
            if hasattr(collection, 'get_measurements'):
                all_measurements.extend(collection.get_measurements())
        
        if not all_measurements:
            from tkinter import messagebox
            messagebox.showwarning(
                "No Measurements",
                "There are no measurements available in the document.",
                parent=self
            )
            return
        
        # Show transformation dialog
        from plana_figura_workbench.dialogs import TransformGeometryWithMeasurementsDialog
        dialog = TransformGeometryWithMeasurementsDialog(self, geometry, all_measurements)
        self.wait_window(dialog)
        
        if dialog.result_geometry:
            # Apply transformation
            trans_type, *params = dialog.result_geometry
            
            try:
                if trans_type == "move":
                    vector = params[0]
                    self._apply_move_transformation(geometry, vector)
                elif trans_type == "rotate":
                    angle, center = params
                    self._apply_rotate_transformation(geometry, angle, center)
                elif trans_type == "scale":
                    scale_factor, center = params
                    self._apply_scale_transformation(geometry, scale_factor, center)
                elif trans_type == "offset":
                    distance, direction = params
                    self._apply_offset_transformation(geometry, distance, direction)
                
                # Notify observers and refresh
                self.document._notify_observers()
                self._populate_tree()
                
                logger.info(f"Applied {trans_type} transformation to {type(geometry).__name__}")
                
            except Exception as e:
                from tkinter import messagebox
                messagebox.showerror(
                    "Transformation Error",
                    f"Failed to apply transformation: {str(e)}",
                    parent=self
                )
                logger.error(f"Transformation failed: {e}")
    
    def _apply_move_transformation(self, geometry, vector):
        """Apply move transformation to geometry."""
        if hasattr(geometry, 'points'):
            # For polyline, polygon, etc.
            for point in geometry.points:
                point.northing += vector.northing
                point.easting += vector.easting
                if hasattr(point, 'elevation'):
                    point.elevation += vector.elevation
        elif hasattr(geometry, 'start') and hasattr(geometry, 'end'):
            # For line segment
            geometry.start.northing += vector.northing
            geometry.start.easting += vector.easting
            if hasattr(geometry.start, 'elevation'):
                geometry.start.elevation += vector.elevation
            
            geometry.end.northing += vector.northing
            geometry.end.easting += vector.easting
            if hasattr(geometry.end, 'elevation'):
                geometry.end.elevation += vector.elevation
        elif hasattr(geometry, 'northing'):
            # For single point
            geometry.northing += vector.northing
            geometry.easting += vector.easting
            if hasattr(geometry, 'elevation'):
                geometry.elevation += vector.elevation
    
    def _apply_rotate_transformation(self, geometry, angle, center):
        """Apply rotation transformation to geometry."""
        import math
        
        # Convert angle to radians for trig functions
        angle_rad = math.radians(angle.decimal_degrees)
        cos_angle = math.cos(angle_rad)
        sin_angle = math.sin(angle_rad)
        
        def rotate_point(point):
            # Translate to origin
            x = point.easting - center.easting
            y = point.northing - center.northing
            
            # Rotate
            new_x = x * cos_angle - y * sin_angle
            new_y = x * sin_angle + y * cos_angle
            
            # Translate back
            point.easting = new_x + center.easting
            point.northing = new_y + center.northing
            
            return point
        
        if hasattr(geometry, 'points'):
            # For polyline, polygon, etc.
            for point in geometry.points:
                rotate_point(point)
        elif hasattr(geometry, 'start') and hasattr(geometry, 'end'):
            # For line segment
            rotate_point(geometry.start)
            rotate_point(geometry.end)
        elif hasattr(geometry, 'northing'):
            # For single point
            rotate_point(geometry)
    
    def _apply_scale_transformation(self, geometry, scale_factor, center):
        """Apply scale transformation to geometry."""
        def scale_point(point):
            # Translate to origin
            x = point.easting - center.easting
            y = point.northing - center.northing
            
            # Scale
            new_x = x * scale_factor
            new_y = y * scale_factor
            
            # Translate back
            point.easting = new_x + center.easting
            point.northing = new_y + center.northing
            
            return point
        
        if hasattr(geometry, 'points'):
            # For polyline, polygon, etc.
            for point in geometry.points:
                scale_point(point)
        elif hasattr(geometry, 'start') and hasattr(geometry, 'end'):
            # For line segment
            scale_point(geometry.start)
            scale_point(geometry.end)
        elif hasattr(geometry, 'northing'):
            # For single point
            scale_point(geometry)
    
    def _apply_offset_transformation(self, geometry, distance, direction):
        """Apply offset transformation to geometry (for lines and polylines)."""
        # Only applicable to lines and polylines
        if not (hasattr(geometry, 'start') and hasattr(geometry, 'end')) and not hasattr(geometry, 'points'):
            raise ValueError("Offset only applies to lines and polylines")
        
        # Calculate perpendicular offset
        def offset_line_segment(line):
            # Calculate direction vector
            dx = line.end.easting - line.start.easting
            dy = line.end.northing - line.start.northing
            length = math.sqrt(dx*dx + dy*dy)
            
            if length == 0:
                return line
            
            # Normalize direction
            dx /= length
            dy /= length
            
            # Perpendicular vector (rotate 90 degrees)
            perp_x = -dy
            perp_y = dx
            
            # Apply offset based on direction
            if direction == "left":
                offset_x = perp_x * distance
                offset_y = perp_y * distance
            else:  # right
                offset_x = -perp_x * distance
                offset_y = -perp_y * distance
            
            # Create offset points
            new_start = Point(
                line.start.northing + offset_y,
                line.start.easting + offset_x,
                getattr(line.start, 'elevation', 0)
            )
            new_end = Point(
                line.end.northing + offset_y,
                line.end.easting + offset_x,
                getattr(line.end, 'elevation', 0)
            )
            
            line.start = new_start
            line.end = new_end
            return line
        
        if hasattr(geometry, 'start') and hasattr(geometry, 'end'):
            # Single line segment
            offset_line_segment(geometry)
        elif hasattr(geometry, 'points'):
            # Polyline - offset each segment
            for i in range(len(geometry.points) - 1):
                segment = type(geometry)(
                    geometry.points[i],
                    geometry.points[i + 1]
                )
                offset_line_segment(segment)
                geometry.points[i] = segment.start
                geometry.points[i + 1] = segment.end

    def _on_new_collection(self) -> None:
        """Handle New Collection button click."""
        logger.info("New collection requested")
        
        from tkinter import simpledialog, messagebox
        name = simpledialog.askstring(
            "New Collection",
            "Enter collection name:",
            parent=self
        )
        
        if name:
            from plana_figura import GeometryCollection
            new_collection = GeometryCollection()
            new_collection.name = name
            self.document.add_collection(new_collection)
            self.document.set_active_collection(new_collection)
            logger.info(f"Created new collection: {name}")
            
            # Refresh UI
            self._update_collection_list()
            self._populate_tree()
            
            messagebox.showinfo(
                "Collection Created",
                f"Created new collection '{name}'",
                parent=self
            )

    def _on_delete_collection(self) -> None:
        """Handle Delete Collection button click."""
        logger.info("Delete collection requested")
        # TODO: Implement delete collection

    # Filter and collection handlers
    def _on_filter_changed(self, event=None) -> None:
        """Handle filter dropdown change."""
        logger.info(f"Filter changed to: {self.filter_var.get()}")
        self._populate_tree()

    def _on_collection_changed(self, event=None) -> None:
        """Handle collection dropdown change."""
        collection_name = self.collection_var.get()
        logger.info(f"Collection changed to: {collection_name}")
        # TODO: Set active collection

    def _on_search_changed(self, *args) -> None:
        """Handle search box text change."""
        search_text = self.search_var.get()
        logger.debug(f"Search text: {search_text}")
        # TODO: Implement search filtering

    def _update_collection_list(self) -> None:
        """Update the collection dropdown list."""
        collection_names = []
        for idx, collection in enumerate(self.document.collections):
            is_active = collection == self.document.active_collection
            name = self.controller.get_collection_display_name(
                collection, idx, is_active
            )
            collection_names.append(name)
        
        self.collection_combo['values'] = collection_names
        
        # Set current active collection
        if self.document.active_collection:
            for idx, collection in enumerate(self.document.collections):
                if collection == self.document.active_collection:
                    is_active = True
                    name = self.controller.get_collection_display_name(
                        collection, idx, is_active
                    )
                    self.collection_var.set(name)
                    break
    
    def _on_tree_right_click(self, event) -> None:
        """Handle right-click on tree item - show context menu."""
        # Select the item under cursor
        item_id = self.tree.identify_row(event.y)
        if not item_id:
            return
        
        # Update selection: if the item is already selected, preserve the
        # existing (possibly multi-) selection. Otherwise, select only this
        # item. This allows context menu actions (Move/Copy) to operate on
        # all currently selected geometries.
        current_selection = self.tree.selection()
        if item_id not in current_selection:
            self.tree.selection_set(item_id)
        
        # Check if it's a geometry (not a collection or folder)
        if item_id in self._item_to_geometry:
            geometry = self._item_to_geometry[item_id]
            
            # Create context menu
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(
                label="Properties...",
                command=lambda: self._show_properties_dialog(geometry)
            )
            menu.add_separator()
            menu.add_command(label="Move to Collection...", command=self._on_move_geometry)
            menu.add_command(label="Copy to Collection...", command=self._on_copy_geometry)
            menu.add_separator()
            menu.add_command(label="Delete", command=self._on_delete_geometry)
            
            # Show menu at cursor position
            menu.tk_popup(event.x_root, event.y_root)
    
    def _show_properties_dialog(self, geometry: Geometry) -> None:
        """
        Show the properties dialog for a geometry.
        
        Args:
            geometry: The geometry to edit
        """
        dialog = GeometryPropertiesDialog(self, geometry)
        self.wait_window(dialog)
        
        if dialog.result:
            # Properties were changed, refresh the tree and notify observers
            self._populate_tree()
            self.document._notify_observers()
            logger.info(f"Updated properties for {type(geometry).__name__}")
    
    def _on_delete_geometry(self) -> None:
        """Handle delete geometry from context menu."""
        # Get selected items
        selected_items = self.tree.selection()
        if not selected_items:
            return
        
        # Get geometries to delete
        geometries_to_delete = []
        for item_id in selected_items:
            if item_id in self._item_to_geometry:
                geometries_to_delete.append(self._item_to_geometry[item_id])
        
        if not geometries_to_delete:
            return
        
        # Confirm deletion
        from tkinter import messagebox
        if len(geometries_to_delete) == 1:
            msg = f"Delete {type(geometries_to_delete[0]).__name__}?"
        else:
            msg = f"Delete {len(geometries_to_delete)} geometries?"
        
        if not messagebox.askyesno("Confirm Delete", msg):
            return
        
        # Delete using command system for proper undo/redo support
        if self.document.active_collection:
            from plana_figura_workbench.commands import RemoveGeometryCommand
            
            for geometry in geometries_to_delete:
                try:
                    # Use command system
                    command = RemoveGeometryCommand(self.document, geometry)
                    if hasattr(self, 'command_manager') and self.command_manager:
                        self.command_manager.execute(command)
                    else:
                        # Fallback to direct removal
                        command.execute()
                    logger.info(f"Deleted {type(geometry).__name__}")
                except Exception as e:
                    logger.error(f"Failed to delete geometry: {e}")
            
            # Refresh UI - the command system should handle document notification
            self._populate_tree()
    
    def _on_move_geometry(self) -> None:
        """Move selected geometries to another collection."""
        selected_items = self.tree.selection()
        if not selected_items:
            logger.info("No items selected, returning")
            return
        
        # Get geometries to move
        geometries_to_move = []
        source_collections = []  # Use list instead of set since GeometryCollection is not hashable
        
        for item_id in selected_items:
            if item_id in self._item_to_geometry:
                geometry = self._item_to_geometry[item_id]
                geometries_to_move.append(geometry)
                
                # Find source collection
                for collection in self.document.collections:
                    if geometry in collection.geometries:
                        if collection not in source_collections:
                            source_collections.append(collection)
                        break
        
        if not geometries_to_move:
            return
        
        # Show collection selection dialog
        target_collection = self._select_target_collection("Move to Collection")
        if target_collection is None:
            return
        
        # Move geometries
        try:
            for geometry in geometries_to_move:
                for source_collection in source_collections:
                    if geometry in source_collection.geometries:
                        source_collection.remove(geometry)
                target_collection.add(geometry)
            
            self.document.modified = True
            self.document._notify_observers()
            self._populate_tree()
            logger.info(f"Moved {len(geometries_to_move)} geometries to {target_collection.name or 'collection'}")
        except Exception as e:
            logger.error(f"Error during move: {e}", exc_info=True)
    
    def _on_copy_geometry(self) -> None:
        """Copy selected geometries to another collection."""
        selected_items = self.tree.selection()
        if not selected_items:
            return
        
        # Get geometries to copy
        geometries_to_copy = []
        
        for item_id in selected_items:
            if item_id in self._item_to_geometry:
                geometries_to_copy.append(self._item_to_geometry[item_id])
        
        if not geometries_to_copy:
            return
        
        # Show collection selection dialog
        target_collection = self._select_target_collection("Copy to Collection")
        if target_collection is None:
            return
        
        # Copy geometries (create deep copies)
        import copy
        for geometry in geometries_to_copy:
            geometry_copy = copy.deepcopy(geometry)
            target_collection.add(geometry_copy)
        
        self.document.modified = True
        self.document._notify_observers()
        self._populate_tree()
        logger.info(f"Copied {len(geometries_to_copy)} geometries to {target_collection.name or 'collection'}")
    
    def _select_target_collection(self, title: str) -> Optional[GeometryCollection]:
        """
        Show dialog to select a target collection.
        
        Args:
            title: Dialog title
            
        Returns:
            Selected collection or None if cancelled
        """
        from tkinter import simpledialog
        
        # Build list of collection names
        collection_names = []
        for idx, collection in enumerate(self.document.collections):
            if hasattr(collection, 'name') and collection.name:
                collection_names.append(collection.name)
            else:
                collection_names.append(f"Collection {idx + 1}")
        
        if not collection_names:
            from tkinter import messagebox
            messagebox.showwarning(
                "No Collections",
                "There are no collections to move/copy to.",
                parent=self
            )
            return None
        
        # Show selection dialog
        from tkinter import Toplevel, Listbox, Button, SINGLE
        
        dialog = Toplevel(self)
        dialog.title(title)
        dialog.geometry("300x400")
        dialog.transient(self)
        dialog.grab_set()
        
        # Listbox for collections
        listbox = Listbox(dialog, selectmode=SINGLE)
        listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        for name in collection_names:
            listbox.insert(tk.END, name)
        
        # Result variable
        result = [None]
        
        def on_ok():
            selection = listbox.curselection()
            if selection:
                result[0] = self.document.collections[selection[0]]
            dialog.destroy()
        
        def on_cancel():
            dialog.destroy()
        
        # Buttons
        button_frame = ttk.Frame(dialog)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        Button(button_frame, text="OK", command=on_ok).pack(side=tk.LEFT, padx=5)
        Button(button_frame, text="Cancel", command=on_cancel).pack(side=tk.LEFT, padx=5)
        
        # Wait for dialog
        self.wait_window(dialog)
        
        return result[0]
