"""Measurement Manager plugin - tree view for measurement management."""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Optional
import logging
import sys
from pathlib import Path

# Add Local Packages to path for vultus_serpentis
_local_packages = (
    Path(__file__).parent.parent.parent / "Local Packages" / "vultus_serpentis"
)
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

from vultus_serpentis.events import EventBus  # type: ignore

from plana_figura import Measurement
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.model.document import Observer
from plana_figura_workbench.plugins.measurement_manager_controller import (
    MeasurementManagerController
)
from plana_figura_workbench.events import (
    MeasurementAddedEvent,
    MeasurementRemovedEvent,
    MeasurementModifiedEvent,
    MeasurementCollectionCreatedEvent,
    MeasurementCollectionRemovedEvent,
    MeasurementSelectionChangedEvent
)

logger = logging.getLogger(__name__)


class MeasurementManager(ttk.Frame, Observer):
    """
    Measurement Manager plugin.

    Displays a tree view of all measurements in the active collection.
    Allows filtering by type, selection, and basic management operations.

    Features:
    - Tree view with measurements (ID, Name, Type, Value)
    - Filter dropdown (All, Angles, Directions, Distances, Vectors)
    - Collection dropdown
    - Toolbar with Add, Edit, Delete buttons
    - Properties panel showing measurement details
    - Event-driven updates
    """

    def __init__(
        self,
        parent: tk.Widget,
        document: PlanaFiguraDocument,
        event_bus: Optional[EventBus] = None,
        command_manager: Optional[object] = None
    ):
        """
        Initialize the Measurement Manager.

        Args:
            parent: Parent widget
            document: The document to display
            event_bus: Optional EventBus for plugin communication
            command_manager: Optional command manager for undo/redo
        """
        super().__init__(parent)
        self.document = document
        self.document.add_observer(self)
        self.event_bus = event_bus or EventBus.default()
        self.command_manager = command_manager

        # Controller for business logic
        self.controller = MeasurementManagerController(
            document,
            command_manager
        )

        # Map tree item IDs to measurement IDs
        self._item_to_measurement_id: Dict[str, int] = {}
        self._measurement_id_to_item: Dict[int, str] = {}

        # Current filter
        self._current_filter = "all"

        self._setup_ui()
        self._subscribe_to_events()
        self._populate_tree()

        logger.info("Measurement Manager initialized")

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Configure grid
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=0)  # Toolbar
        self.rowconfigure(1, weight=0)  # Filter/Collection bar
        self.rowconfigure(2, weight=3)  # Tree
        self.rowconfigure(3, weight=1)  # Properties

        # Toolbar
        self._create_toolbar()

        # Filter and collection bar
        self._create_filter_bar()

        # Tree view
        self._create_tree_view()

        # Properties panel
        self._create_properties_panel()

    def _create_toolbar(self) -> None:
        """Create the toolbar with action buttons."""
        toolbar = ttk.Frame(self)
        toolbar.grid(row=0, column=0, sticky="ew", padx=5, pady=5)

        # Add button (will have dropdown menu in future)
        self.add_button = ttk.Button(
            toolbar,
            text="Add",
            command=self._on_add_measurement
        )
        self.add_button.pack(side=tk.LEFT, padx=2)

        # Edit button
        self.edit_button = ttk.Button(
            toolbar,
            text="Edit",
            command=self._on_edit_measurement,
            state=tk.DISABLED
        )
        self.edit_button.pack(side=tk.LEFT, padx=2)

        # Delete button
        self.delete_button = ttk.Button(
            toolbar,
            text="Delete",
            command=self._on_delete_measurement,
            state=tk.DISABLED
        )
        self.delete_button.pack(side=tk.LEFT, padx=2)

        # Geometry Creation button
        self.create_geometry_button = ttk.Button(
            toolbar,
            text="Create Geometry",
            command=self._on_create_geometry
        )
        self.create_geometry_button.pack(side=tk.LEFT, padx=2)

        # Separator
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(
            side=tk.LEFT, fill=tk.Y, padx=5
        )

        # Collection management
        ttk.Button(
            toolbar,
            text="New Collection",
            command=self._on_new_collection
        ).pack(side=tk.LEFT, padx=2)

        ttk.Button(
            toolbar,
            text="Delete Collection",
            command=self._on_delete_collection
        ).pack(side=tk.LEFT, padx=2)

    def _create_filter_bar(self) -> None:
        """Create the filter and collection selection bar."""
        filter_frame = ttk.Frame(self)
        filter_frame.grid(row=1, column=0, sticky="ew", padx=5, pady=5)

        # Filter label and dropdown
        ttk.Label(filter_frame, text="Filter:").pack(side=tk.LEFT, padx=(0, 5))

        self.filter_var = tk.StringVar(value="all")
        self.filter_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.filter_var,
            values=["all", "angles", "directions", "distances", "vectors"],
            state="readonly",
            width=15
        )
        self.filter_combo.pack(side=tk.LEFT, padx=(0, 15))
        self.filter_combo.bind("<<ComboboxSelected>>", self._on_filter_changed)

        # Collection label and dropdown
        ttk.Label(filter_frame, text="Collection:").pack(side=tk.LEFT, padx=(0, 5))

        self.collection_var = tk.StringVar()
        self.collection_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.collection_var,
            state="readonly",
            width=20
        )
        self.collection_combo.pack(side=tk.LEFT)
        self.collection_combo.bind(
            "<<ComboboxSelected>>",
            self._on_collection_changed
        )

        # Update collection list
        self._update_collection_list()

    def _create_tree_view(self) -> None:
        """Create the tree view for measurements."""
        tree_frame = ttk.Frame(self)
        tree_frame.grid(row=2, column=0, sticky="nsew", padx=5, pady=5)
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)

        # Tree view with columns
        self.tree = ttk.Treeview(
            tree_frame,
            columns=("id", "name", "type", "value"),
            show="headings",
            selectmode="extended"
        )
        self.tree.grid(row=0, column=0, sticky="nsew")

        # Scrollbar
        scrollbar = ttk.Scrollbar(
            tree_frame,
            orient="vertical",
            command=self.tree.yview
        )
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=scrollbar.set)

        # Configure columns
        self.tree.heading("id", text="ID")
        self.tree.heading("name", text="Name")
        self.tree.heading("type", text="Type")
        self.tree.heading("value", text="Value")

        self.tree.column("id", width=50, anchor=tk.CENTER)
        self.tree.column("name", width=150)
        self.tree.column("type", width=150)
        self.tree.column("value", width=150, anchor=tk.E)

        # Bind selection event
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # Bind double-click for edit
        self.tree.bind("<Double-Button-1>", lambda e: self._on_edit_measurement())

    def _create_properties_panel(self) -> None:
        """Create the properties panel."""
        props_frame = ttk.LabelFrame(self, text="Properties")
        props_frame.grid(row=3, column=0, sticky="nsew", padx=5, pady=5)
        props_frame.columnconfigure(0, weight=1)
        props_frame.rowconfigure(0, weight=1)

        # Properties text widget
        self.properties_text = tk.Text(
            props_frame,
            height=8,
            wrap=tk.WORD,
            state=tk.DISABLED
        )
        self.properties_text.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

        # Properties scrollbar
        props_scrollbar = ttk.Scrollbar(
            props_frame,
            orient="vertical",
            command=self.properties_text.yview
        )
        props_scrollbar.grid(row=0, column=1, sticky="ns")
        self.properties_text.configure(yscrollcommand=props_scrollbar.set)

    def _subscribe_to_events(self) -> None:
        """Subscribe to measurement events."""
        self.event_bus.subscribe(
            MeasurementAddedEvent,
            self._on_measurement_added
        )
        self.event_bus.subscribe(
            MeasurementRemovedEvent,
            self._on_measurement_removed
        )
        self.event_bus.subscribe(
            MeasurementModifiedEvent,
            self._on_measurement_modified
        )
        self.event_bus.subscribe(
            MeasurementCollectionCreatedEvent,
            self._on_collection_created
        )
        self.event_bus.subscribe(
            MeasurementCollectionRemovedEvent,
            self._on_collection_removed
        )

    def _populate_tree(self) -> None:
        """Populate the tree view with current measurements."""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)

        self._item_to_measurement_id.clear()
        self._measurement_id_to_item.clear()

        # Get filtered measurements
        measurements = self.controller.get_filtered_measurements(
            self._current_filter
        )

        # Add measurements to tree
        for measurement in measurements:
            self._add_measurement_to_tree(measurement)

    def _add_measurement_to_tree(self, measurement: Measurement) -> None:
        """
        Add a measurement to the tree.

        Args:
            measurement: The measurement to add
        """
        id_str, name, type_str, value_str = (
            self.controller.get_measurement_display_string(measurement)
        )

        item_id = self.tree.insert(
            "",
            tk.END,
            values=(id_str, name, type_str, value_str)
        )

        self._item_to_measurement_id[item_id] = measurement.id
        self._measurement_id_to_item[measurement.id] = item_id

    def _update_collection_list(self) -> None:
        """Update the collection dropdown list."""
        collections = self.controller.get_collection_names()
        self.collection_combo['values'] = collections

        # Set current active collection
        active = self.controller.get_active_collection_name()
        if active:
            self.collection_var.set(active)

    def _update_properties_panel(self) -> None:
        """Update the properties panel with selected measurement info."""
        selected_items = self.tree.selection()

        self.properties_text.configure(state=tk.NORMAL)
        self.properties_text.delete(1.0, tk.END)

        if len(selected_items) == 0:
            self.properties_text.insert(tk.END, "No measurement selected")
        elif len(selected_items) == 1:
            # Show detailed info for single selection
            item_id = selected_items[0]
            measurement_id = self._item_to_measurement_id.get(item_id)

            if measurement_id is not None:
                info = self.controller.get_measurement_info(measurement_id)
                if info:
                    self.properties_text.insert(tk.END, f"ID: {info['id']}\n")
                    self.properties_text.insert(tk.END, f"Name: {info['name']}\n")
                    self.properties_text.insert(tk.END, f"Type: {info['type']}\n")
                    self.properties_text.insert(tk.END, f"Value: {info['value']}\n")
                    if info.get('description'):
                        self.properties_text.insert(
                            tk.END,
                            f"\nDescription:\n{info['description']}\n"
                        )
                    if info.get('metadata'):
                        self.properties_text.insert(
                            tk.END,
                            f"\nMetadata:\n{info['metadata']}\n"
                        )
        else:
            # Multiple selection
            self.properties_text.insert(
                tk.END,
                f"{len(selected_items)} measurements selected"
            )

        self.properties_text.configure(state=tk.DISABLED)

    def _update_button_states(self) -> None:
        """Update toolbar button states based on selection."""
        selected_items = self.tree.selection()
        has_selection = len(selected_items) > 0

        self.edit_button.configure(
            state=tk.NORMAL if len(selected_items) == 1 else tk.DISABLED
        )
        self.delete_button.configure(
            state=tk.NORMAL if has_selection else tk.DISABLED
        )

    # ========================================================================
    # Event Handlers - UI Events
    # ========================================================================

    def _on_tree_select(self, event: tk.Event) -> None:
        """Handle tree selection change."""
        selected_items = self.tree.selection()
        measurement_ids = [
            self._item_to_measurement_id[item]
            for item in selected_items
            if item in self._item_to_measurement_id
        ]

        # Update controller selection
        self.controller.select_measurements(measurement_ids)

        # Update UI
        self._update_properties_panel()
        self._update_button_states()

        # Publish selection event
        if self.event_bus:
            collection_name = self.controller.get_active_collection_name()
            if collection_name:
                self.event_bus.publish(
                    MeasurementSelectionChangedEvent(
                        selected_ids=measurement_ids,
                        collection_name=collection_name
                    )
                )

    def _on_filter_changed(self, event: tk.Event) -> None:
        """Handle filter selection change."""
        self._current_filter = self.filter_var.get()
        self._populate_tree()

    def _on_collection_changed(self, event: tk.Event) -> None:
        """Handle collection selection change."""
        collection_name = self.collection_var.get()
        if collection_name:
            self.controller.set_active_collection(collection_name)
            self._populate_tree()

    def _on_add_measurement(self) -> None:
        """Handle Add button click."""
        # Show menu to choose measurement type
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Angle (Horizontal/Vertical/Zenith)", command=self._add_angle)
        menu.add_command(label="Direction (Azimuth/Bearing)", command=self._add_direction)
        menu.add_command(label="Distance", command=self._add_distance)
        menu.add_command(label="3D Vector", command=self._add_vector)
        
        # Show menu at button location
        try:
            x = self.add_button.winfo_rootx()
            y = self.add_button.winfo_rooty() + self.add_button.winfo_height()
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()
    
    def _add_angle(self) -> None:
        """Add an angle measurement."""
        from plana_figura_workbench.dialogs import AddAngleDialog
        dialog = AddAngleDialog(self)
        self.wait_window(dialog)
        if dialog.result:
            collection_name = self.controller.get_active_collection_name()
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                if self.command_manager:
                    self.command_manager.execute(cmd)
                else:
                    cmd.execute()
    
    def _add_direction(self) -> None:
        """Add a direction measurement."""
        from plana_figura_workbench.dialogs import AddDirectionDialog
        dialog = AddDirectionDialog(self)
        self.wait_window(dialog)
        if dialog.result:
            collection_name = self.controller.get_active_collection_name()
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                if self.command_manager:
                    self.command_manager.execute(cmd)
                else:
                    cmd.execute()
    
    def _add_distance(self) -> None:
        """Add a distance measurement."""
        from plana_figura_workbench.dialogs import AddDistanceDialog
        dialog = AddDistanceDialog(self)
        self.wait_window(dialog)
        if dialog.result:
            collection_name = self.controller.get_active_collection_name()
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                if self.command_manager:
                    self.command_manager.execute(cmd)
                else:
                    cmd.execute()
    
    def _add_vector(self) -> None:
        """Add a 3D vector measurement."""
        from plana_figura_workbench.dialogs import AddVectorDialog
        dialog = AddVectorDialog(self)
        self.wait_window(dialog)
        if dialog.result:
            collection_name = self.controller.get_active_collection_name()
            if collection_name:
                from plana_figura_workbench.commands import AddMeasurementCommand
                cmd = AddMeasurementCommand(
                    self.document,
                    dialog.result,
                    collection_name
                )
                if self.command_manager:
                    self.command_manager.execute(cmd)
                else:
                    cmd.execute()

    def _on_create_geometry(self) -> None:
        """Handle Create Geometry button click."""
        # Show menu to choose geometry type
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Point from Direction+Distance", command=self._create_point_from_measurements)
        menu.add_command(label="Line from Vector", command=self._create_line_from_measurements)
        menu.add_command(label="Polyline from Traverse", command=self._create_polyline_from_measurements)
        menu.add_command(label="Rectangle from Dimensions", command=self._create_rectangle_from_measurements)
        
        # Show menu at button location
        try:
            x = self.create_geometry_button.winfo_rootx()
            y = self.create_geometry_button.winfo_rooty() + self.create_geometry_button.winfo_height()
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()
    
    def _create_point_from_measurements(self) -> None:
        """Create a point from direction and distance measurements."""
        from plana_figura_workbench.dialogs import CreatePointFromMeasurementsDialog
        
        # Get measurements from active collection
        collection_name = self.controller.get_active_collection_name()
        if collection_name:
            collection = self.document.get_measurement_collection(collection_name)
            measurements = collection.get_measurements()
            
            if len(measurements) < 2:
                messagebox.showwarning(
                    "Not Enough Measurements",
                    "You need at least one direction and one distance measurement to create a point."
                )
                return
            
            dialog = CreatePointFromMeasurementsDialog(self, measurements, event_bus=self.event_bus)
            self.wait_window(dialog)
            if dialog.result_point:
                # Add point to document
                point = dialog.result_point
                from plana_figura_workbench.model import Point as ModelPoint
                model_point = ModelPoint(point.northing, point.easting, point.elevation)
                self.document.add_point(model_point)
                
                # Publish event
                from plana_figura_workbench.events import PointAddedEvent
                event = PointAddedEvent(model_point)
                self.event_bus.publish(event)
    
    def _create_line_from_measurements(self) -> None:
        """Create a line from a vector measurement."""
        from plana_figura_workbench.dialogs import CreateLineFromMeasurementsDialog
        
        # Get measurements from active collection
        collection_name = self.controller.get_active_collection_name()
        if collection_name:
            collection = self.document.get_measurement_collection(collection_name)
            measurements = collection.get_measurements()
            
            # Check for vector measurements
            vector_measurements = [m for m in measurements if m.measurement_type.name == "VECTOR_3D"]
            if not vector_measurements:
                messagebox.showwarning(
                    "No Vector Measurements",
                    "You need at least one 3D vector measurement to create a line."
                )
                return
            
            dialog = CreateLineFromMeasurementsDialog(self, measurements)
            self.wait_window(dialog)
            if dialog.result_line:
                # Add line to document
                line = dialog.result_line
                from plana_figura_workbench.model import LineSegment as ModelLine
                from plana_figura_workbench.model import Point as ModelPoint
                start_point = ModelPoint(line.start.northing, line.start.easting, line.start.elevation)
                end_point = ModelPoint(line.end.northing, line.end.easting, line.end.elevation)
                model_line = ModelLine(start_point, end_point)
                self.document.add_line(model_line)
                
                # Publish event
                from plana_figura_workbench.events import LineAddedEvent
                event = LineAddedEvent(model_line)
                self.event_bus.publish(event)
    
    def _create_polyline_from_measurements(self) -> None:
        """Create a polyline from direction/distance measurement pairs."""
        from plana_figura_workbench.dialogs import CreatePolylineFromMeasurementsDialog
        
        # Get measurements from active collection
        collection_name = self.controller.get_active_collection_name()
        if collection_name:
            collection = self.document.get_measurement_collection(collection_name)
            measurements = collection.get_measurements()
            
            # Check for required measurements
            direction_measurements = [m for m in measurements if m.measurement_type.name in ["DIRECTION", "AZIMUTH", "BEARING"]]
            distance_measurements = [m for m in measurements if m.measurement_type.name in ["DISTANCE", "HORIZONTAL_DISTANCE", "SLOPE_DISTANCE", "VERTICAL_DISTANCE"]]
            
            if not direction_measurements or not distance_measurements:
                messagebox.showwarning(
                    "Insufficient Measurements",
                    "You need at least one direction and one distance measurement to create a polyline."
                )
                return
            
            dialog = CreatePolylineFromMeasurementsDialog(self, measurements)
            self.wait_window(dialog)
            if dialog.result_polyline:
                # Add polyline to document
                polyline = dialog.result_polyline
                from plana_figura_workbench.model import Polyline as ModelPolyline
                from plana_figura_workbench.model import Point as ModelPoint
                
                model_points = []
                for point in polyline.points:
                    model_point = ModelPoint(point.northing, point.easting, point.elevation)
                    model_points.append(model_point)
                
                model_polyline = ModelPolyline(model_points)
                self.document.add_polyline(model_polyline)
                
                # Publish event
                from plana_figura_workbench.events import PolylineAddedEvent
                event = PolylineAddedEvent(model_polyline)
                self.event_bus.publish(event)
    
    def _create_rectangle_from_measurements(self) -> None:
        """Create a rectangle from width and height measurements."""
        from plana_figura_workbench.dialogs import CreateRectangleFromMeasurementsDialog
        
        # Get measurements from active collection
        collection_name = self.controller.get_active_collection_name()
        if collection_name:
            collection = self.document.get_measurement_collection(collection_name)
            measurements = collection.get_measurements()
            
            # Check for distance measurements
            distance_measurements = [m for m in measurements if m.measurement_type.name in ["DISTANCE", "HORIZONTAL_DISTANCE"]]
            if len(distance_measurements) < 2:
                messagebox.showwarning(
                    "Insufficient Measurements",
                    "You need at least two distance measurements (width and height) to create a rectangle."
                )
                return
            
            dialog = CreateRectangleFromMeasurementsDialog(self, measurements)
            self.wait_window(dialog)
            if dialog.result_rectangle:
                # Add polygon (rectangle) to document
                rectangle = dialog.result_rectangle
                from plana_figura_workbench.model import Polygon as ModelPolygon
                from plana_figura_workbench.model import Point as ModelPoint
                
                model_points = []
                for point in rectangle.points:
                    model_point = ModelPoint(point.northing, point.easting, point.elevation)
                    model_points.append(model_point)
                
                model_polygon = ModelPolygon(model_points)
                self.document.add_polygon(model_polygon)
                
                # Publish event
                from plana_figura_workbench.events import PolygonAddedEvent
                event = PolygonAddedEvent(model_polygon)
                self.event_bus.publish(event)

    def _on_edit_measurement(self) -> None:
        """Handle Edit button click."""
        selected_items = self.tree.selection()
        if len(selected_items) != 1:
            return

        item_id = selected_items[0]
        measurement_id = self._item_to_measurement_id.get(item_id)

        if measurement_id is not None:
            # Get the measurement
            collection = self.document.get_active_measurement_collection()
            if collection is None:
                return
            
            measurement = collection.get(measurement_id)
            if measurement is None:
                return
            
            # Open appropriate dialog based on type
            from plana_figura import MeasurementType
            dialog = None
            
            if measurement.measurement_type in {
                MeasurementType.HORIZONTAL_ANGLE,
                MeasurementType.VERTICAL_ANGLE,
                MeasurementType.ZENITH_ANGLE
            }:
                from plana_figura_workbench.dialogs import AddAngleDialog
                dialog = AddAngleDialog(self, measurement, "Edit Angle Measurement")
            elif measurement.measurement_type in {
                MeasurementType.DIRECTION,
                MeasurementType.AZIMUTH,
                MeasurementType.BEARING
            }:
                from plana_figura_workbench.dialogs import AddDirectionDialog
                dialog = AddDirectionDialog(self, measurement, "Edit Direction Measurement")
            elif measurement.measurement_type in {
                MeasurementType.DISTANCE,
                MeasurementType.HORIZONTAL_DISTANCE,
                MeasurementType.SLOPE_DISTANCE,
                MeasurementType.VERTICAL_DISTANCE
            }:
                from plana_figura_workbench.dialogs import AddDistanceDialog
                dialog = AddDistanceDialog(self, measurement, "Edit Distance Measurement")
            elif measurement.measurement_type == MeasurementType.VECTOR_3D:
                from plana_figura_workbench.dialogs import AddVectorDialog
                dialog = AddVectorDialog(self, measurement, "Edit 3D Vector Measurement")
            
            if dialog:
                self.wait_window(dialog)
                if dialog.result:
                    # Update the measurement
                    collection_name = self.controller.get_active_collection_name()
                    if collection_name:
                        from plana_figura_workbench.commands import ModifyMeasurementCommand
                        cmd = ModifyMeasurementCommand(
                            self.document,
                            measurement_id,
                            collection_name,
                            name=dialog.result.name,
                            value=dialog.result.value,
                            description=dialog.result.description
                        )
                        if self.command_manager:
                            self.command_manager.execute(cmd)
                        else:
                            cmd.execute()

    def _on_delete_measurement(self) -> None:
        """Handle Delete button click."""
        selected_items = self.tree.selection()
        if not selected_items:
            return

        measurement_ids = [
            self._item_to_measurement_id[item]
            for item in selected_items
            if item in self._item_to_measurement_id
        ]

        if not measurement_ids:
            return

        # Confirm deletion
        count = len(measurement_ids)
        message = (
            f"Delete {count} measurement{'s' if count > 1 else ''}?"
        )
        if not messagebox.askyesno("Confirm Delete", message):
            return

        # Delete measurements
        for measurement_id in measurement_ids:
            self.controller.remove_measurement(measurement_id)

        # Tree will be updated via event

    def _on_new_collection(self) -> None:
        """Handle New Collection button click."""
        # Simple input dialog
        from tkinter import simpledialog
        name = simpledialog.askstring(
            "New Collection",
            "Enter collection name:"
        )

        if name:
            if self.controller.create_collection(name):
                self._update_collection_list()
                self.collection_var.set(name)
            else:
                messagebox.showerror(
                    "Error",
                    f"Failed to create collection '{name}'"
                )

    def _on_delete_collection(self) -> None:
        """Handle Delete Collection button click."""
        collection_name = self.collection_var.get()
        if not collection_name:
            return

        # Don't allow deleting the last collection
        if len(self.controller.get_collection_names()) <= 1:
            messagebox.showwarning(
                "Cannot Delete",
                "Cannot delete the last collection."
            )
            return

        # Confirm deletion
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Delete collection '{collection_name}'?\n\n"
            "All measurements in this collection will be removed."
        ):
            return

        if self.controller.delete_collection(collection_name):
            self._update_collection_list()
        else:
            messagebox.showerror(
                "Error",
                f"Failed to delete collection '{collection_name}'"
            )

    # ========================================================================
    # Event Handlers - Document Events
    # ========================================================================

    def _on_measurement_added(self, event: MeasurementAddedEvent) -> None:
        """Handle measurement added event."""
        # Check if it's in the active collection
        if event.collection_name == self.controller.get_active_collection_name():
            # Refresh tree
            self._populate_tree()

    def _on_measurement_removed(self, event: MeasurementRemovedEvent) -> None:
        """Handle measurement removed event."""
        # Check if it's in the active collection
        if event.collection_name == self.controller.get_active_collection_name():
            # Remove from tree
            item_id = self._measurement_id_to_item.get(event.measurement_id)
            if item_id:
                self.tree.delete(item_id)
                del self._item_to_measurement_id[item_id]
                del self._measurement_id_to_item[event.measurement_id]

    def _on_measurement_modified(
        self,
        event: MeasurementModifiedEvent
    ) -> None:
        """Handle measurement modified event."""
        # Check if it's in the active collection
        if event.collection_name == self.controller.get_active_collection_name():
            # Refresh tree (simple approach)
            self._populate_tree()

    def _on_collection_created(
        self,
        event: MeasurementCollectionCreatedEvent
    ) -> None:
        """Handle collection created event."""
        self._update_collection_list()

    def _on_collection_removed(
        self,
        event: MeasurementCollectionRemovedEvent
    ) -> None:
        """Handle collection removed event."""
        self._update_collection_list()
        self._populate_tree()

    # ========================================================================
    # Observer Interface
    # ========================================================================

    def update(self, observable: object) -> None:
        """
        Handle document updates.

        Args:
            observable: The observable object (document)
        """
        # Refresh the entire view
        self._update_collection_list()
        self._populate_tree()

    def cleanup(self) -> None:
        """Clean up resources and unsubscribe from events."""
        self.document.remove_observer(self)

        # Unsubscribe from events
        self.event_bus.unsubscribe(
            MeasurementAddedEvent,
            self._on_measurement_added
        )
        self.event_bus.unsubscribe(
            MeasurementRemovedEvent,
            self._on_measurement_removed
        )
        self.event_bus.unsubscribe(
            MeasurementModifiedEvent,
            self._on_measurement_modified
        )
        self.event_bus.unsubscribe(
            MeasurementCollectionCreatedEvent,
            self._on_collection_created
        )
        self.event_bus.unsubscribe(
            MeasurementCollectionRemovedEvent,
            self._on_collection_removed
        )

        logger.info("Measurement Manager cleaned up")
