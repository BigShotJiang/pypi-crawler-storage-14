"""Grid Editor Plugin for Plana Figura Workbench.

Provides UI for configuring grid settings including:
- Grid interval
- Coordinate tolerance
- Distance tolerance
- Angle settings
- Grid visibility
"""

import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import logging
from typing import Optional

from plana_figura.grid import Grid, CardinalDirection, AngleDirection
from plana_figura_workbench.model import DataBucketKeys, PlanaFiguraDocument
from plana_figura_workbench.widgets import DMSEntry

logger = logging.getLogger(__name__)


class GridEditor(ttk.Frame):
    """
    Grid Editor plugin for configuring grid settings.
    
    Features:
    - Edit grid interval
    - Edit coordinate/distance/angle tolerances
    - Configure angle measurement settings
    - Toggle grid visibility
    - Preview grid settings
    - Publish to DataBucket for other plugins
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        document: Optional[PlanaFiguraDocument] = None,
        data_bucket=None,
        event_bus=None
    ):
        """
        Initialize the Grid Editor.
        
        Args:
            parent: Parent widget
            data_bucket: Optional DataBucket for data sharing
            event_bus: Optional EventBus for plugin communication
        """
        super().__init__(parent)
        
        self.document = document
        self.data_bucket = data_bucket
        self.event_bus = event_bus
        
        # Current grid instance
        self.current_grid: Optional[Grid] = None
        self.grid_visible: bool = True
        
        # Variables for grid settings
        self.grid_interval_var = tk.StringVar(value="0.01")
        self.coord_tolerance_var = tk.StringVar(value="0.02")
        self.dist_tolerance_var = tk.StringVar(value="0.02")
        # Angle tolerance will use DMS widget
        self.angle_tolerance_dms = None  # Created in _setup_ui
        self.angle_interval_var = tk.StringVar(value="1.0")
        self.zero_direction_var = tk.StringVar(value="NORTH")
        self.angle_measurement_var = tk.StringVar(value="CLOCKWISE")
        self.grid_visible_var = tk.BooleanVar(value=True)
        
        self._setup_ui()
        self._create_default_grid()
        self._setup_data_bucket_sync()
        
        logger.info("Grid Editor initialized")
    
    def _safe_bootstyle(self, widget, style: str) -> None:
        """Safely apply bootstyle, falling back to default if not available."""
        try:
            widget.configure(bootstyle=style)
        except (tk.TclError, Exception):
            pass  # Use default style
    
    def _setup_ui(self) -> None:
        """Set up the user interface."""
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        
        # Title
        title_frame = ttk.Frame(self)
        title_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        ttk.Label(
            title_frame,
            text="Grid Settings",
            font=("Segoe UI", 16, "bold")
        ).pack(side=LEFT)
        
        # Visibility toggle
        self.visibility_check = ttk.Checkbutton(
            title_frame,
            text="Grid Visible",
            variable=self.grid_visible_var,
            command=self._on_visibility_changed
        )
        self._safe_bootstyle(self.visibility_check, "success-round-toggle")
        self.visibility_check.pack(side=RIGHT)
        
        # Main content in scrollable frame
        canvas = tk.Canvas(self, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        scrollbar.grid(row=1, column=1, sticky="ns", pady=5)
        
        # Grid Spacing Section
        self._create_spacing_section(scrollable_frame)
        
        # Tolerance Section
        self._create_tolerance_section(scrollable_frame)
        
        # Angle Settings Section
        self._create_angle_section(scrollable_frame)
        
        # Action Buttons
        self._create_action_buttons(scrollable_frame)
        
        # Status Section
        self._create_status_section(scrollable_frame)
    
    def _create_spacing_section(self, parent: ttk.Frame) -> None:
        """Create the grid spacing section."""
        section = ttk.LabelFrame(
            parent,
            text="Grid Spacing",
            padding=15
        )
        self._safe_bootstyle(section, "primary")
        section.pack(fill=X, padx=5, pady=5)
        
        # Grid Interval
        interval_frame = ttk.Frame(section)
        interval_frame.pack(fill=X, pady=5)
        
        ttk.Label(
            interval_frame,
            text="Grid Interval:",
            width=20
        ).pack(side=LEFT)
        
        ttk.Entry(
            interval_frame,
            textvariable=self.grid_interval_var,
            width=15
        ).pack(side=LEFT, padx=5)
        
        ttk.Label(
            interval_frame,
            text="(spacing between grid lines)",
            font=("Segoe UI", 8),
            foreground="gray"
        ).pack(side=LEFT)
    
    def _create_tolerance_section(self, parent: ttk.Frame) -> None:
        """Create the tolerance settings section."""
        section = ttk.LabelFrame(
            parent,
            text="Snap Tolerances",
            padding=15
        )
        self._safe_bootstyle(section, "info")
        section.pack(fill=X, padx=5, pady=5)
        
        # Coordinate Tolerance
        coord_frame = ttk.Frame(section)
        coord_frame.pack(fill=X, pady=5)
        
        ttk.Label(
            coord_frame,
            text="Coordinate Tolerance:",
            width=20
        ).pack(side=LEFT)
        
        ttk.Entry(
            coord_frame,
            textvariable=self.coord_tolerance_var,
            width=15
        ).pack(side=LEFT, padx=5)
        
        ttk.Label(
            coord_frame,
            text="(snap distance for coordinates)",
            font=("Segoe UI", 8),
            foreground="gray"
        ).pack(side=LEFT)
        
        # Distance Tolerance
        dist_frame = ttk.Frame(section)
        dist_frame.pack(fill=X, pady=5)
        
        ttk.Label(
            dist_frame,
            text="Distance Tolerance:",
            width=20
        ).pack(side=LEFT)
        
        ttk.Entry(
            dist_frame,
            textvariable=self.dist_tolerance_var,
            width=15
        ).pack(side=LEFT, padx=5)
        
        ttk.Label(
            dist_frame,
            text="(snap distance for measurements)",
            font=("Segoe UI", 8),
            foreground="gray"
        ).pack(side=LEFT)
    
    def _create_angle_section(self, parent: ttk.Frame) -> None:
        """Create the angle settings section."""
        section = ttk.LabelFrame(
            parent,
            text="Angle Settings",
            padding=15
        )
        self._safe_bootstyle(section, "warning")
        section.pack(fill=X, padx=5, pady=5)
        
        # Angle Tolerance (DMS format)
        angle_tol_frame = ttk.Frame(section)
        angle_tol_frame.pack(fill=X, pady=5)
        
        ttk.Label(
            angle_tol_frame,
            text="Angle Tolerance:",
            width=20
        ).pack(side=LEFT)
        
        # Create DMS entry widget
        self.angle_tolerance_dms = DMSEntry(angle_tol_frame)
        self.angle_tolerance_dms.pack(side=LEFT, padx=5)
        
        # Set default value (5e-7 degrees = 0° 0' 0.0018")
        self.angle_tolerance_dms.set_decimal_degrees(5e-7)
        
        # Angle Interval
        angle_int_frame = ttk.Frame(section)
        angle_int_frame.pack(fill=X, pady=5)
        
        ttk.Label(
            angle_int_frame,
            text="Angle Interval:",
            width=20
        ).pack(side=LEFT)
        
        ttk.Entry(
            angle_int_frame,
            textvariable=self.angle_interval_var,
            width=15
        ).pack(side=LEFT, padx=5)
        
        ttk.Label(
            angle_int_frame,
            text="degrees (snap increment)",
            font=("Segoe UI", 8),
            foreground="gray"
        ).pack(side=LEFT)
        
        # Zero Angle Direction
        zero_dir_frame = ttk.Frame(section)
        zero_dir_frame.pack(fill=X, pady=5)
        
        ttk.Label(
            zero_dir_frame,
            text="Zero Angle Direction:",
            width=20
        ).pack(side=LEFT)
        
        ttk.Combobox(
            zero_dir_frame,
            textvariable=self.zero_direction_var,
            values=["NORTH", "EAST", "SOUTH", "WEST"],
            state="readonly",
            width=12
        ).pack(side=LEFT, padx=5)
        
        # Angle Measurement
        angle_meas_frame = ttk.Frame(section)
        angle_meas_frame.pack(fill=X, pady=5)
        
        ttk.Label(
            angle_meas_frame,
            text="Angle Measurement:",
            width=20
        ).pack(side=LEFT)
        
        ttk.Combobox(
            angle_meas_frame,
            textvariable=self.angle_measurement_var,
            values=["CLOCKWISE", "COUNTERCLOCKWISE"],
            state="readonly",
            width=12
        ).pack(side=LEFT, padx=5)
    
    def _create_action_buttons(self, parent: ttk.Frame) -> None:
        """Create action buttons."""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=X, padx=5, pady=15)
        
        apply_btn = ttk.Button(
            button_frame,
            text="Apply Settings",
            command=self._on_apply,
            width=20
        )
        self._safe_bootstyle(apply_btn, "success")
        apply_btn.pack(side=LEFT, padx=5)
        
        reset_btn = ttk.Button(
            button_frame,
            text="Reset to Defaults",
            command=self._on_reset,
            width=20
        )
        self._safe_bootstyle(reset_btn, "secondary")
        reset_btn.pack(side=LEFT, padx=5)
        
        preset_btn = ttk.Button(
            button_frame,
            text="Load Preset",
            command=self._on_load_preset,
            width=20
        )
        self._safe_bootstyle(preset_btn, "info")
        preset_btn.pack(side=LEFT, padx=5)
    
    def _create_status_section(self, parent: ttk.Frame) -> None:
        """Create status display section."""
        section = ttk.LabelFrame(
            parent,
            text="Current Grid Status",
            padding=15
        )
        self._safe_bootstyle(section, "secondary")
        section.pack(fill=X, padx=5, pady=5)
        
        self.status_label = ttk.Label(
            section,
            text="Grid: Default settings loaded",
            font=("Segoe UI", 9)
        )
        self.status_label.pack(fill=X)
    
    def _create_default_grid(self) -> None:
        """Create and apply default grid settings."""
        self.current_grid = Grid()
        self._publish_to_data_bucket()
        logger.debug("Default grid created")
    
    def _on_apply(self) -> None:
        """Apply current settings to create new grid."""
        # Show warning dialog
        if self.document:
            # Count geometries that will be affected
            geom_count = len(self.document.get_all_geometries())
            
            if geom_count > 0:
                response = messagebox.askyesno(
                    "Apply Grid Settings",
                    f"This will replace the grid in all {geom_count} geometries.\n\n"
                    f"All existing geometries will use the new grid settings.\n\n"
                    f"Do you want to continue?",
                    icon='warning'
                )
                
                if not response:
                    self.status_label.config(text="Grid application cancelled")
                    return
        
        try:
            # Parse values
            grid_interval = float(self.grid_interval_var.get())
            coord_tolerance = float(self.coord_tolerance_var.get())
            dist_tolerance = float(self.dist_tolerance_var.get())
            
            # Get angle tolerance from DMS widget
            angle_tolerance = self.angle_tolerance_dms.get_decimal_degrees()
            angle_interval = float(self.angle_interval_var.get())
            
            # Parse enums
            zero_direction = CardinalDirection[self.zero_direction_var.get()]
            angle_measurement = AngleDirection[self.angle_measurement_var.get()]
            
            # Create new grid
            new_grid = Grid(
                grid_interval=grid_interval,
                coordinate_tolerance=coord_tolerance,
                distance_tolerance=dist_tolerance,
                angle_tolerance_degrees=angle_tolerance,
                angle_interval_degrees=angle_interval,
                zero_angle_direction=zero_direction,
                angle_measurement=angle_measurement
            )
            
            # Update all geometries with new grid
            if self.document:
                updated_count = self._update_geometries_grid(new_grid)
                logger.info(f"Updated grid in {updated_count} geometries")
            
            # Set as current grid
            self.current_grid = new_grid
            
            # Publish to DataBucket
            self._publish_to_data_bucket()
            
            # Update status
            if self.document:
                self.status_label.config(
                    text=f"Grid applied to {updated_count} geometries: Interval={grid_interval}"
                )
            else:
                self.status_label.config(
                    text=f"Grid applied: Interval={grid_interval}, Visible={self.grid_visible}"
                )
            
            logger.info(f"Grid settings applied: {self.current_grid}")
            
        except ValueError as e:
            self.status_label.config(text=f"Error: Invalid value - {e}")
            logger.error(f"Error applying grid settings: {e}")
        except Exception as e:
            self.status_label.config(text=f"Error: {e}")
            logger.error(f"Error applying grid settings: {e}", exc_info=True)
    
    def _update_geometries_grid(self, new_grid: Grid) -> int:
        """
        Update all geometries in the document with the new grid.
        
        Args:
            new_grid: The new Grid to apply
            
        Returns:
            Number of geometries updated
        """
        if not self.document:
            return 0
        
        updated_count = 0
        
        # Update all geometries
        for geometry in self.document.get_all_geometries():
            if hasattr(geometry, '_grid'):
                geometry._grid = new_grid
                updated_count += 1
        
        return updated_count
    
    def _on_reset(self) -> None:
        """Reset to default grid settings."""
        self.grid_interval_var.set("0.01")
        self.coord_tolerance_var.set("0.02")
        self.dist_tolerance_var.set("0.02")
        self.angle_tolerance_dms.set_decimal_degrees(5e-7)
        self.angle_interval_var.set("1.0")
        self.zero_direction_var.set("NORTH")
        self.angle_measurement_var.set("CLOCKWISE")
        self.grid_visible_var.set(True)
        
        self._on_apply()
        self.status_label.config(text="Grid reset to default settings")
        logger.info("Grid reset to defaults")
    
    def _on_load_preset(self) -> None:
        """Load a preset grid configuration."""
        # Create preset selection dialog
        dialog = tk.Toplevel(self)
        dialog.title("Load Grid Preset")
        dialog.geometry("400x300")
        dialog.transient(self)
        dialog.grab_set()
        
        ttk.Label(
            dialog,
            text="Select a Grid Preset:",
            font=("Segoe UI", 12, "bold")
        ).pack(pady=10)
        
        presets = {
            "Fine (0.001)": {
                "interval": "0.001",
                "coord_tol": "0.002",
                "dist_tol": "0.002"
            },
            "Standard (0.01)": {
                "interval": "0.01",
                "coord_tol": "0.02",
                "dist_tol": "0.02"
            },
            "Coarse (0.1)": {
                "interval": "0.1",
                "coord_tol": "0.2",
                "dist_tol": "0.2"
            },
            "Metric (1.0)": {
                "interval": "1.0",
                "coord_tol": "2.0",
                "dist_tol": "2.0"
            }
        }
        
        def apply_preset(preset_name):
            preset = presets[preset_name]
            self.grid_interval_var.set(preset["interval"])
            self.coord_tolerance_var.set(preset["coord_tol"])
            self.dist_tolerance_var.set(preset["dist_tol"])
            dialog.destroy()
            self._on_apply()
        
        for preset_name in presets:
            btn = ttk.Button(
                dialog,
                text=preset_name,
                command=lambda p=preset_name: apply_preset(p),
                width=30
            )
            self._safe_bootstyle(btn, "info-outline")
            btn.pack(pady=5)
        
        cancel_btn = ttk.Button(
            dialog,
            text="Cancel",
            command=dialog.destroy,
            width=30
        )
        self._safe_bootstyle(cancel_btn, "secondary")
        cancel_btn.pack(pady=10)
    
    def _on_visibility_changed(self) -> None:
        """Handle grid visibility toggle."""
        self.grid_visible = self.grid_visible_var.get()
        self._publish_to_data_bucket()
        
        status = "visible" if self.grid_visible else "hidden"
        self.status_label.config(text=f"Grid {status}")
        logger.debug(f"Grid visibility: {self.grid_visible}")
    
    def _setup_data_bucket_sync(self) -> None:
        """Set up DataBucket synchronization."""
        if self.data_bucket is not None:
            # Observe grid changes from other sources
            self.data_bucket.observe(DataBucketKeys.GRID, self._on_grid_changed)
            self.data_bucket.observe(DataBucketKeys.GRID_VISIBLE, self._on_grid_visibility_changed)
    
    def _publish_to_data_bucket(self) -> None:
        """Publish current grid to DataBucket."""
        if self.data_bucket is not None:
            self.data_bucket.set(
                DataBucketKeys.GRID,
                self.current_grid,
                source='grid_editor'
            )
            
            self.data_bucket.set(
                DataBucketKeys.GRID_VISIBLE,
                self.grid_visible,
                source='grid_editor'
            )
            
            logger.debug("Published grid to DataBucket")
    
    def _on_grid_changed(self, key: str, new_value, old_value, source: str) -> None:
        """Handle grid changes from other plugins."""
        if source == 'grid_editor':
            return  # Don't respond to our own changes
        
        if new_value is not None:
            self.current_grid = new_value
            # Update UI to reflect new grid
            self._update_ui_from_grid()
            logger.debug(f"Grid changed by {source}")
    
    def _on_grid_visibility_changed(self, key: str, new_value, old_value, source: str) -> None:
        """Handle grid visibility changes from other plugins."""
        if source == 'grid_editor':
            return
        
        if new_value is not None:
            self.grid_visible = new_value
            self.grid_visible_var.set(new_value)
            logger.debug(f"Grid visibility changed by {source}: {new_value}")
    
    def _update_ui_from_grid(self) -> None:
        """Update UI controls from current grid."""
        if self.current_grid:
            self.grid_interval_var.set(str(self.current_grid.grid_interval))
            self.coord_tolerance_var.set(str(self.current_grid.coordinate_tolerance))
            self.dist_tolerance_var.set(str(self.current_grid.distance_tolerance))
            self.angle_tolerance_dms.set_decimal_degrees(self.current_grid.angle_tolerance_degrees)
            self.angle_interval_var.set(str(self.current_grid.angle_interval_degrees))
            self.zero_direction_var.set(self.current_grid.zero_angle_direction.name)
            self.angle_measurement_var.set(self.current_grid.angle_measurement.name)
    
    def get_current_grid(self) -> Optional[Grid]:
        """
        Get the current grid instance.
        
        Returns:
            Current Grid or None
        """
        return self.current_grid
    
    def set_grid(self, grid: Grid) -> None:
        """
        Set the current grid.
        
        Args:
            grid: Grid instance to set
        """
        self.current_grid = grid
        self._update_ui_from_grid()
        self._publish_to_data_bucket()
