"""Controller for Geometry Manipulator plugin."""

from typing import List, Optional, Dict
import logging

from plana_figura import Geometry, GeometryCollection
from plana_figura_workbench.model import PlanaFiguraDocument

logger = logging.getLogger(__name__)


class GeometryManipulatorController:
    """
    Controller for Geometry Manipulator plugin.
    
    Handles business logic for geometry transformations without
    any tkinter dependencies (testable).
    """
    
    def __init__(self, document: PlanaFiguraDocument):
        """
        Initialize the controller.
        
        Args:
            document: The document model
        """
        self.document = document
    
    def get_selected_geometries(self) -> List[Geometry]:
        """
        Get currently selected geometries.
        
        Returns:
            List of selected geometries
        """
        return self.document.selection.copy() if self.document.selection else []
    
    def get_selection_count(self) -> int:
        """
        Get count of selected geometries.
        
        Returns:
            Number of selected geometries
        """
        return len(self.document.selection) if self.document.selection else 0
    
    def get_selection_summary(self) -> str:
        """
        Get a summary of the current selection.
        
        Returns:
            Summary string (e.g., "3 geometries selected")
        """
        count = self.get_selection_count()
        
        if count == 0:
            return "No geometries selected"
        elif count == 1:
            geometry = self.document.selection[0]
            type_name = type(geometry).__name__
            return f"1 {type_name} selected"
        else:
            # Count by type
            type_counts = {}
            for geometry in self.document.selection:
                type_name = type(geometry).__name__
                type_counts[type_name] = type_counts.get(type_name, 0) + 1
            
            # Format summary
            parts = []
            for type_name, count in sorted(type_counts.items()):
                parts.append(f"{count} {type_name}{'s' if count > 1 else ''}")
            
            return f"{count} geometries selected: " + ", ".join(parts)
    
    def has_selection(self) -> bool:
        """
        Check if any geometries are selected.
        
        Returns:
            True if selection is not empty
        """
        return self.get_selection_count() > 0
    
    def get_available_transformations(self) -> List[str]:
        """
        Get list of available transformation types.
        
        Returns:
            List of transformation names
        """
        return ["Translate", "Rotate", "Scale", "Mirror"]
    
    def can_transform(self) -> bool:
        """
        Check if transformation can be performed.
        
        Returns:
            True if geometries are selected
        """
        return self.has_selection()
    
    def get_transform_button_state(self) -> str:
        """
        Get the state for the transform button.
        
        Returns:
            "normal" or "disabled"
        """
        return "normal" if self.can_transform() else "disabled"
    
    def get_selection_type_counts(self) -> Dict[str, int]:
        """
        Get count of selected geometries by type.
        
        Returns:
            Dictionary mapping type names to counts
        """
        type_counts = {}
        
        if self.document.selection:
            for geometry in self.document.selection:
                type_name = type(geometry).__name__
                type_counts[type_name] = type_counts.get(type_name, 0) + 1
        
        return type_counts
    
    def get_selected_collections_count(self) -> int:
        """
        Get count of collections that contain selected geometries.
        
        Returns:
            Number of collections with selected geometries
        """
        if not self.document.selection:
            return 0
        
        # Find which collections contain selected geometries
        # Use list since GeometryCollection is not hashable
        collections_with_selection = []
        for collection in self.document.collections:
            for geometry in self.document.selection:
                if geometry in collection.geometries:
                    if collection not in collections_with_selection:
                        collections_with_selection.append(collection)
                    break
        
        return len(collections_with_selection)
