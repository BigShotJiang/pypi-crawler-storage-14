"""Base class for map interaction tools.

This module provides the abstract MapTool base class that all map tools
must inherit from. Tools handle user interaction with the map canvas.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any
import logging

if TYPE_CHECKING:
    from plana_figura_workbench.plugins.map_view.map_view_controller import MapViewController

logger = logging.getLogger(__name__)


class MapTool(ABC):
    """
    Abstract base class for all map interaction tools.

    Tools implement the Strategy pattern for handling different types of
    user interaction with the map (pan, zoom, select, draw, etc.).

    Each tool has a lifecycle:
    1. Created and registered with controller
    2. Activated when user selects it
    3. Handles events while active
    4. Deactivated when user selects another tool

    Subclasses must implement the event handling methods.

    Example:
        >>> class PanTool(MapTool):
        ...     def on_mouse_press(self, event):
        ...         self.start_x = event.x
        ...         self.start_y = event.y
        ...
        ...     def on_mouse_move(self, event):
        ...         if self.is_dragging:
        ...             dx = event.x - self.start_x
        ...             dy = event.y - self.start_y
        ...             self.controller.pan(dx, dy)
    """

    def __init__(self, controller: 'MapViewController'):
        """
        Initialize the tool.

        Args:
            controller: The MapViewController that owns this tool
        """
        self.controller = controller
        self.is_active = False
        self._cursor = "arrow"
        logger.debug(f"{self.__class__.__name__} created")

    @property
    def cursor(self) -> str:
        """
        Get the cursor to display when this tool is active.

        Returns:
            Cursor name (e.g., "arrow", "crosshair", "hand2")
        """
        return self._cursor

    def activate(self) -> None:
        """
        Called when the tool becomes active.

        Override this to perform setup when the tool is activated.
        The base implementation sets is_active and updates the cursor.
        """
        self.is_active = True
        self.controller.set_cursor(self._cursor)
        logger.debug(f"{self.__class__.__name__} activated")

    def deactivate(self) -> None:
        """
        Called when the tool is deactivated.

        Override this to perform cleanup when the tool is deactivated.
        The base implementation just sets is_active to False.
        """
        self.is_active = False
        logger.debug(f"{self.__class__.__name__} deactivated")

    @abstractmethod
    def on_mouse_press(self, event: Any) -> None:
        """
        Handle mouse button press event.

        Args:
            event: Mouse event with x, y, and button attributes
        """
        pass

    @abstractmethod
    def on_mouse_move(self, event: Any) -> None:
        """
        Handle mouse move event.

        Args:
            event: Mouse event with x, y attributes
        """
        pass

    @abstractmethod
    def on_mouse_release(self, event: Any) -> None:
        """
        Handle mouse button release event.

        Args:
            event: Mouse event with x, y, and button attributes
        """
        pass

    def on_mouse_wheel(self, event: Any) -> None:
        """
        Handle mouse wheel event.

        Override this to handle mouse wheel events (zoom, etc.).
        The base implementation does nothing.

        Args:
            event: Mouse wheel event with delta attribute
        """
        pass

    def on_key_press(self, event: Any) -> None:
        """
        Handle key press event.

        Override this to handle keyboard shortcuts.
        The base implementation does nothing.

        Args:
            event: Key event with keysym attribute
        """
        pass

    def on_key_release(self, event: Any) -> None:
        """
        Handle key release event.

        Override this to handle keyboard shortcuts.
        The base implementation does nothing.

        Args:
            event: Key event with keysym attribute
        """
        pass

    def __repr__(self) -> str:
        """String representation."""
        status = "active" if self.is_active else "inactive"
        return f"{self.__class__.__name__}({status})"
