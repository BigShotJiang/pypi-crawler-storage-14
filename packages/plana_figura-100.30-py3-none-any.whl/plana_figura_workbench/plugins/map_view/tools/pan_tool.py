"""Pan tool for dragging the map view.

This module provides the PanTool which allows users to pan the map
by clicking and dragging.
"""

from typing import Any, Optional
import logging
from .map_tool import MapTool

logger = logging.getLogger(__name__)


class PanTool(MapTool):
    """
    Tool for panning the map view by dragging.

    The user clicks and drags to pan the viewport. The tool tracks
    the drag start position and calculates the offset as the mouse moves.

    Example:
        >>> pan_tool = PanTool(controller)
        >>> pan_tool.activate()
        >>> # User clicks and drags
        >>> pan_tool.on_mouse_press(event)
        >>> pan_tool.on_mouse_move(event)
        >>> pan_tool.on_mouse_release(event)
    """

    def __init__(self, controller: Any):
        """
        Initialize the pan tool.

        Args:
            controller: The MapViewController
        """
        super().__init__(controller)
        self._cursor = "hand2"
        self._is_dragging = False
        self._drag_start_x: Optional[int] = None
        self._drag_start_y: Optional[int] = None
        logger.debug("PanTool initialized")

    def activate(self) -> None:
        """Activate the pan tool."""
        super().activate()
        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None

    def deactivate(self) -> None:
        """Deactivate the pan tool."""
        super().deactivate()
        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None

    def on_mouse_press(self, event: Any) -> None:
        """
        Start dragging when mouse button is pressed.

        Args:
            event: Mouse event with x, y attributes
        """
        self._is_dragging = True
        self._drag_start_x = event.x
        self._drag_start_y = event.y
        logger.debug(f"Pan started at ({event.x}, {event.y})")

    def on_mouse_move(self, event: Any) -> None:
        """
        Pan the view as mouse moves while dragging.

        Args:
            event: Mouse event with x, y attributes
        """
        if self._is_dragging and self._drag_start_x is not None and self._drag_start_y is not None:
            # Calculate offset from drag start
            dx = event.x - self._drag_start_x
            dy = event.y - self._drag_start_y

            # Pan the view
            if hasattr(self.controller, 'pan'):
                self.controller.pan(dx, dy)

            # Update drag start for next move
            self._drag_start_x = event.x
            self._drag_start_y = event.y

    def on_mouse_release(self, event: Any) -> None:
        """
        Stop dragging when mouse button is released.

        Args:
            event: Mouse event with x, y attributes
        """
        if self._is_dragging:
            logger.debug(f"Pan ended at ({event.x}, {event.y})")
        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None
