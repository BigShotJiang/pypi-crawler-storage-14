"""Zoom tool for zooming the map view.

This module provides the ZoomTool which allows users to zoom in/out
using the mouse wheel or by dragging a zoom box.
"""

from typing import Any, Optional
import logging
from .map_tool import MapTool

logger = logging.getLogger(__name__)


class ZoomTool(MapTool):
    """
    Tool for zooming the map view.

    Supports two zoom modes:
    1. Mouse wheel: Zoom in/out centered on mouse position
    2. Drag box: Zoom to fit a dragged rectangle

    Example:
        >>> zoom_tool = ZoomTool(controller)
        >>> zoom_tool.activate()
        >>> # User scrolls mouse wheel
        >>> zoom_tool.on_mouse_wheel(event)
    """

    def __init__(self, controller: Any):
        """
        Initialize the zoom tool.

        Args:
            controller: The MapViewController
        """
        super().__init__(controller)
        self._cursor = "crosshair"
        self._is_dragging = False
        self._drag_start_x: Optional[int] = None
        self._drag_start_y: Optional[int] = None
        self._zoom_factor = 1.2  # 20% zoom per wheel click
        logger.debug("ZoomTool initialized")

    def activate(self) -> None:
        """Activate the zoom tool."""
        super().activate()
        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None

    def deactivate(self) -> None:
        """Deactivate the zoom tool."""
        super().deactivate()
        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None

    def on_mouse_press(self, event: Any) -> None:
        """
        Start dragging a zoom box.

        Args:
            event: Mouse event with x, y attributes
        """
        self._is_dragging = True
        self._drag_start_x = event.x
        self._drag_start_y = event.y
        logger.debug(f"Zoom box started at ({event.x}, {event.y})")

    def on_mouse_move(self, event: Any) -> None:
        """
        Update the zoom box as mouse moves.

        Args:
            event: Mouse event with x, y attributes
        """
        if self._is_dragging and self._drag_start_x is not None and self._drag_start_y is not None:
            # Draw zoom box (controller should handle visualization)
            if hasattr(self.controller, 'draw_zoom_box'):
                self.controller.draw_zoom_box(
                    self._drag_start_x,
                    self._drag_start_y,
                    event.x,
                    event.y
                )

    def on_mouse_release(self, event: Any) -> None:
        """
        Zoom to the dragged box.

        Args:
            event: Mouse event with x, y attributes
        """
        if self._is_dragging and self._drag_start_x is not None and self._drag_start_y is not None:
            # Only zoom if box is large enough (avoid accidental clicks)
            dx = abs(event.x - self._drag_start_x)
            dy = abs(event.y - self._drag_start_y)

            if dx > 5 and dy > 5:
                # Zoom to box
                if hasattr(self.controller, 'zoom_to_box'):
                    self.controller.zoom_to_box(
                        self._drag_start_x,
                        self._drag_start_y,
                        event.x,
                        event.y
                    )
                logger.debug(
                    f"Zoomed to box: ({self._drag_start_x}, {self._drag_start_y}) "
                    f"to ({event.x}, {event.y})"
                )
            else:
                # Single click - zoom in at point
                if hasattr(self.controller, 'zoom_at_point'):
                    self.controller.zoom_at_point(event.x, event.y, self._zoom_factor)
                logger.debug(f"Zoomed in at ({event.x}, {event.y})")

        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None

    def on_mouse_wheel(self, event: Any) -> None:
        """
        Zoom in/out with mouse wheel.

        Args:
            event: Mouse wheel event with delta and x, y attributes
        """
        # Determine zoom direction from wheel delta
        if hasattr(event, 'delta'):
            if event.delta > 0:
                # Zoom in
                factor = self._zoom_factor
            else:
                # Zoom out
                factor = 1.0 / self._zoom_factor

            # Zoom centered on mouse position
            if hasattr(self.controller, 'zoom_at_point'):
                self.controller.zoom_at_point(event.x, event.y, factor)
                logger.debug(f"Wheel zoom {factor:.2f}x at ({event.x}, {event.y})")
