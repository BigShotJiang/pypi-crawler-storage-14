"""Select tool for selecting geometries on the map.

This module provides the SelectTool which allows users to select
geometries by clicking on them or dragging a selection box.
"""

from typing import Any, Optional
import logging
from .map_tool import MapTool

logger = logging.getLogger(__name__)


class SelectTool(MapTool):
    """
    Tool for selecting geometries on the map.

    Supports two selection modes:
    1. Click: Select single geometry at click point
    2. Drag box: Select all geometries within dragged rectangle

    Modifiers:
    - Ctrl: Add to selection
    - Shift: Toggle selection
    - No modifier: Replace selection

    Example:
        >>> select_tool = SelectTool(controller)
        >>> select_tool.activate()
        >>> # User clicks on geometry
        >>> select_tool.on_mouse_press(event)
        >>> select_tool.on_mouse_release(event)
    """

    def __init__(self, controller: Any):
        """
        Initialize the select tool.

        Args:
            controller: The MapViewController
        """
        super().__init__(controller)
        self._cursor = "arrow"
        self._is_dragging = False
        self._drag_start_x: Optional[int] = None
        self._drag_start_y: Optional[int] = None
        logger.debug("SelectTool initialized")

    def activate(self) -> None:
        """Activate the select tool."""
        super().activate()
        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None
        logger.info("SELECT_TOOL: Activated successfully")

    def deactivate(self) -> None:
        """Deactivate the select tool."""
        super().deactivate()
        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None

    def on_mouse_press(self, event: Any) -> None:
        """
        Start selection operation.

        Args:
            event: Mouse event with x, y attributes
        """
        logger.info(f"SELECT_TOOL: ===== MOUSE PRESS RECEIVED =====")
        logger.info(f"SELECT_TOOL: Event coordinates: ({event.x}, {event.y})")
        logger.info(f"SELECT_TOOL: Event type: {type(event)}")
        logger.info(f"SELECT_TOOL: Event attributes: {dir(event)}")
        
        self._is_dragging = True
        self._drag_start_x = event.x
        self._drag_start_y = event.y
        logger.info(f"SELECT_TOOL: Drag started at ({event.x}, {event.y})")

    def on_mouse_move(self, event: Any) -> None:
        """
        Update selection box as mouse moves.

        Args:
            event: Mouse event with x, y attributes
        """
        if self._is_dragging and self._drag_start_x is not None and self._drag_start_y is not None:
            # Draw selection box (controller should handle visualization)
            if hasattr(self.controller, 'draw_selection_box'):
                self.controller.draw_selection_box(
                    self._drag_start_x,
                    self._drag_start_y,
                    event.x,
                    event.y
                )

    def on_mouse_release(self, event: Any) -> None:
        """
        Complete selection operation.

        Args:
            event: Mouse event with x, y attributes and state (for modifiers)
        """
        logger.info(f"SELECT_TOOL: ===== MOUSE RELEASE RECEIVED =====")
        logger.info(f"SELECT_TOOL: Event coordinates: ({event.x}, {event.y})")
        logger.info(f"SELECT_TOOL: Drag state: is_dragging={self._is_dragging}, start=({self._drag_start_x}, {self._drag_start_y})")
        
        if self._is_dragging and self._drag_start_x is not None and self._drag_start_y is not None:
            # Check if this was a drag or a click
            dx = abs(event.x - self._drag_start_x)
            dy = abs(event.y - self._drag_start_y)

            # Determine selection mode from modifiers
            add_to_selection = hasattr(event, 'state') and bool(event.state & 0x4)  # Ctrl key
            toggle_selection = hasattr(event, 'state') and bool(event.state & 0x1)  # Shift key

            if dx > 5 and dy > 5:
                # Box selection
                # Determine selection mode based on drag direction:
                # - Drag left-to-right => "window" (fully inside)
                # - Drag right-to-left => "crossing" (touching or inside)
                mode = "window"
                if event.x < self._drag_start_x:
                    mode = "crossing"

                logger.info(
                    f"SELECT_TOOL: Performing {mode} box selection from "
                    f"({self._drag_start_x}, {self._drag_start_y}) to ({event.x}, {event.y})"
                )

                if hasattr(self.controller, 'select_in_box'):
                    self.controller.select_in_box(
                        self._drag_start_x,
                        self._drag_start_y,
                        event.x,
                        event.y,
                        mode=mode,
                        add=add_to_selection,
                        toggle=toggle_selection
                    )
                    logger.info("SELECT_TOOL: Box selection completed")
                else:
                    logger.error("SELECT_TOOL: Controller missing select_in_box method")
            else:
                # Point selection
                logger.info(f"SELECT_TOOL: Performing point selection at ({event.x}, {event.y})")
                if hasattr(self.controller, 'select_at_point'):
                    self.controller.select_at_point(
                        event.x,
                        event.y,
                        add=add_to_selection,
                        toggle=toggle_selection
                    )
                    logger.info(f"SELECT_TOOL: Point selection completed")
                else:
                    logger.error(f"SELECT_TOOL: Controller missing select_at_point method")

        self._is_dragging = False
        self._drag_start_x = None
        self._drag_start_y = None

    def on_key_press(self, event: Any) -> None:
        """
        Handle keyboard shortcuts.

        Args:
            event: Key event with keysym attribute
        """
        if hasattr(event, 'keysym'):
            if event.keysym == 'Escape':
                # Clear selection
                if hasattr(self.controller, 'clear_selection'):
                    self.controller.clear_selection()
                logger.debug("Selection cleared (Escape)")
            elif event.keysym == 'a' and hasattr(event, 'state') and (event.state & 0x4):
                # Ctrl+A: Select all
                if hasattr(self.controller, 'select_all'):
                    self.controller.select_all()
                logger.debug("Select all (Ctrl+A)")
