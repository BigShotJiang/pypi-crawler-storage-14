"""Map View Settings Persistence.

This module handles saving and loading map view settings and layer properties
to/from XML files stored alongside the document.
"""

import xml.etree.ElementTree as ET
import logging
from pathlib import Path
from typing import Dict, Any, Optional

from plana_figura_workbench.plugins.map_view.map_view_model import (
    LayerStyle
)

logger = logging.getLogger(__name__)


class MapViewSettings:
    """Manages persistence of map view settings."""

    def __init__(self, document_path: Optional[Path] = None):
        """
        Initialize settings manager.

        Args:
            document_path: Path to the document file (optional)
        """
        self.document_path = document_path
        self._settings: Dict[str, Any] = {}

    def get_settings_path(self) -> Optional[Path]:
        """
        Get the path to the settings file.

        Returns:
            Path to settings file, or None if no document path
        """
        if self.document_path is None:
            return None

        # Store settings alongside document with .mapview.xml extension
        return self.document_path.with_suffix('.mapview.xml')

    def save_settings(
        self,
        background_color: str,
        selection_color: str,
        grid_visible: bool,
        grid_interval: float,
        grid_color: str,
        layer_styles: Dict[str, LayerStyle]
    ) -> bool:
        """
        Save map view settings to file.

        Args:
            background_color: Canvas background color
            selection_color: Selection highlight color
            grid_visible: Whether grid is visible
            grid_interval: Grid line interval
            grid_color: Grid line color
            layer_styles: Dictionary of layer name -> LayerStyle

        Returns:
            True if saved successfully, False otherwise
        """
        settings_path = self.get_settings_path()
        if settings_path is None:
            logger.warning("No document path set, cannot save settings")
            return False

        try:
            # Create root element
            root = ET.Element('MapViewSettings')
            root.set('version', '1.0')

            # Add appearance section
            appearance = ET.SubElement(root, 'Appearance')
            ET.SubElement(appearance, 'BackgroundColor').text = background_color
            ET.SubElement(appearance, 'SelectionColor').text = selection_color

            # Add grid section
            grid = ET.SubElement(root, 'Grid')
            ET.SubElement(grid, 'Visible').text = str(grid_visible).lower()
            ET.SubElement(grid, 'Interval').text = str(grid_interval)
            ET.SubElement(grid, 'Color').text = grid_color

            # Add layer styles section
            layers = ET.SubElement(root, 'LayerStyles')
            for name, style in layer_styles.items():
                layer = ET.SubElement(layers, 'Layer')
                layer.set('name', name)
                ET.SubElement(layer, 'StrokeColor').text = style.stroke_color
                ET.SubElement(layer, 'StrokeWidth').text = str(style.stroke_width)
                ET.SubElement(layer, 'FillColor').text = style.fill_color
                ET.SubElement(layer, 'LineJoin').text = getattr(style, 'line_join', 'miter')
                ET.SubElement(layer, 'LineCap').text = getattr(style, 'line_cap', 'butt')
                ET.SubElement(layer, 'PointSize').text = str(style.point_size)
                ET.SubElement(layer, 'PointColor').text = style.point_color
                ET.SubElement(layer, 'PointShape').text = style.point_shape

            # Create tree and write to file
            tree = ET.ElementTree(root)
            ET.indent(tree, space='  ')  # Pretty print

            with open(settings_path, 'wb') as f:
                tree.write(
                    f,
                    encoding='utf-8',
                    xml_declaration=True
                )

            logger.info(f"Saved map view settings to {settings_path}")
            return True

        except Exception as e:
            logger.error(f"Failed to save map view settings: {e}")
            return False

    def load_settings(self) -> Optional[Dict[str, Any]]:
        """
        Load map view settings from file.

        Returns:
            Dictionary of settings, or None if file doesn't exist or error
        """
        settings_path = self.get_settings_path()
        if settings_path is None or not settings_path.exists():
            logger.debug("No settings file found")
            return None

        try:
            tree = ET.parse(settings_path)
            root = tree.getroot()

            # Parse settings into dictionary
            settings = {'version': root.get('version', '1.0')}

            # Parse appearance
            appearance = root.find('Appearance')
            if appearance is not None:
                bg_color = appearance.find('BackgroundColor')
                if bg_color is not None:
                    settings['background_color'] = bg_color.text
                sel_color = appearance.find('SelectionColor')
                if sel_color is not None:
                    settings['selection_color'] = sel_color.text

            # Parse grid
            grid = root.find('Grid')
            if grid is not None:
                settings['grid'] = {}
                visible = grid.find('Visible')
                if visible is not None:
                    settings['grid']['visible'] = visible.text.lower() == 'true'
                interval = grid.find('Interval')
                if interval is not None:
                    settings['grid']['interval'] = float(interval.text)
                color = grid.find('Color')
                if color is not None:
                    settings['grid']['color'] = color.text

            # Parse layer styles
            layers = root.find('LayerStyles')
            if layers is not None:
                settings['layer_styles'] = {}
                for layer in layers.findall('Layer'):
                    name = layer.get('name')
                    if name:
                        style_dict = {}
                        for elem in layer:
                            if elem.tag == 'StrokeColor':
                                style_dict['stroke_color'] = elem.text
                            elif elem.tag == 'StrokeWidth':
                                style_dict['stroke_width'] = int(elem.text)
                            elif elem.tag == 'FillColor':
                                style_dict['fill_color'] = elem.text or ''
                            elif elem.tag == 'LineJoin':
                                style_dict['line_join'] = elem.text
                            elif elem.tag == 'LineCap':
                                style_dict['line_cap'] = elem.text
                            elif elem.tag == 'PointSize':
                                style_dict['point_size'] = int(elem.text)
                            elif elem.tag == 'PointColor':
                                style_dict['point_color'] = elem.text
                            elif elem.tag == 'PointShape':
                                style_dict['point_shape'] = elem.text
                        settings['layer_styles'][name] = style_dict

            logger.info(f"Loaded map view settings from {settings_path}")
            return settings

        except Exception as e:
            logger.error(f"Failed to load map view settings: {e}")
            return None

    def get_layer_style(self, layer_name: str) -> Optional[LayerStyle]:
        """
        Get saved style for a specific layer.

        Args:
            layer_name: Name of the layer

        Returns:
            LayerStyle if found, None otherwise
        """
        settings = self.load_settings()
        if settings is None:
            return None

        layer_styles = settings.get('layer_styles', {})
        style_dict = layer_styles.get(layer_name)

        if style_dict is None:
            return None

        # Create LayerStyle from dictionary
        return LayerStyle(
            stroke_color=style_dict.get('stroke_color', 'black'),
            stroke_width=style_dict.get('stroke_width', 1),
            fill_color=style_dict.get('fill_color', ''),
            point_size=style_dict.get('point_size', 5),
            point_color=style_dict.get('point_color', 'yellow'),
            point_shape=style_dict.get('point_shape', 'circle')
        )

    def get_background_color(self) -> str:
        """Get saved background color."""
        settings = self.load_settings()
        if settings:
            return settings.get('background_color', 'white')
        return 'white'

    def get_selection_color(self) -> str:
        """Get saved selection color."""
        settings = self.load_settings()
        if settings:
            return settings.get('selection_color', 'red')
        return 'red'

    def get_grid_settings(self) -> Dict[str, Any]:
        """Get saved grid settings."""
        settings = self.load_settings()
        if settings and 'grid' in settings:
            return settings['grid']
        return {
            'visible': False,
            'interval': 10.0,
            'color': '#CCCCCC'
        }
