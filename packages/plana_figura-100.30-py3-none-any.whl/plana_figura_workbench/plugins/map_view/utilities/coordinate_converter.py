"""Coordinate conversion between world and screen coordinates.

This module provides utilities for converting between world coordinates
(northing/easting) and screen coordinates (pixels) for map rendering.
"""

from typing import Tuple, Optional
from plana_figura.spatial import TwoDimensionalEnvelope
from plana_figura.grid import Grid


class CoordinateConverter:
    """
    Converts between world coordinates and screen coordinates.

    This class handles the transformation between the world coordinate system
    (northing/easting in meters) and screen coordinates (pixels). It accounts
    for the current viewport and canvas size, and optionally applies grid
    snapping.

    Example:
        >>> viewport = TwoDimensionalEnvelope(0, 100, 0, 100)
        >>> converter = CoordinateConverter(viewport, 800, 600)
        >>> screen_x, screen_y = converter.world_to_screen(50, 50)
        >>> northing, easting = converter.screen_to_world(400, 300)
    """

    def __init__(
        self,
        viewport: TwoDimensionalEnvelope,
        canvas_width: int,
        canvas_height: int,
        grid: Optional[Grid] = None
    ):
        """
        Initialize the coordinate converter.

        Args:
            viewport: The current viewport in world coordinates
            canvas_width: Canvas width in pixels
            canvas_height: Canvas height in pixels
            grid: Optional grid for snapping coordinates
        """
        self._viewport = viewport
        self._canvas_width = canvas_width
        self._canvas_height = canvas_height
        self._grid = grid

        # Cache scale factors for performance
        self._update_scale_factors()

    def _update_scale_factors(self) -> None:
        """Update cached scale factors when viewport or canvas changes."""
        # Calculate uniform scale factor to preserve aspect ratio
        # Use the smaller scale to ensure viewport fits entirely in canvas
        scale_x = self._canvas_width / self._viewport.width
        scale_y = self._canvas_height / self._viewport.height
        self._uniform_scale = min(scale_x, scale_y)
        
        # Calculate centering offsets
        scaled_viewport_width = self._viewport.width * self._uniform_scale
        scaled_viewport_height = self._viewport.height * self._uniform_scale
        self._x_offset = (self._canvas_width - scaled_viewport_width) / 2
        self._y_offset = (self._canvas_height - scaled_viewport_height) / 2
        
        # Keep old scale factors for backward compatibility (but they should not be used)
        self._x_scale = self._uniform_scale
        self._y_scale = self._uniform_scale

    @property
    def viewport(self) -> TwoDimensionalEnvelope:
        """Get the current viewport."""
        return self._viewport

    @viewport.setter
    def viewport(self, value: TwoDimensionalEnvelope) -> None:
        """Set the viewport and update scale factors."""
        self._viewport = value
        self._update_scale_factors()

    @property
    def canvas_width(self) -> int:
        """Get the canvas width."""
        return self._canvas_width

    @canvas_width.setter
    def canvas_width(self, value: int) -> None:
        """Set the canvas width and update scale factors."""
        self._canvas_width = value
        self._update_scale_factors()

    @property
    def canvas_height(self) -> int:
        """Get the canvas height."""
        return self._canvas_height

    @canvas_height.setter
    def canvas_height(self, value: int) -> None:
        """Set the canvas height and update scale factors."""
        self._canvas_height = value
        self._update_scale_factors()

    @property
    def grid(self) -> Optional[Grid]:
        """Get the grid for snapping."""
        return self._grid

    @grid.setter
    def grid(self, value: Optional[Grid]) -> None:
        """Set the grid for snapping."""
        self._grid = value

    def world_to_screen(self, northing: float, easting: float) -> Tuple[int, int]:
        """
        Convert world coordinates to screen coordinates.

        Args:
            northing: Northing coordinate in world units
            easting: Easting coordinate in world units

        Returns:
            Tuple of (screen_x, screen_y) in pixels

        Example:
            >>> converter.world_to_screen(1000.0, 2000.0)
            (400, 300)
        """
        # Convert to viewport-relative coordinates
        x_rel = easting - self._viewport.min_easting
        y_rel = northing - self._viewport.min_northing

        # Apply uniform scaling and centering
        screen_x = int(x_rel * self._uniform_scale + self._x_offset)
        screen_y = int((self._viewport.height - y_rel) * self._uniform_scale + self._y_offset)  # Flip Y axis

        return (screen_x, screen_y)

    def screen_to_world(
        self,
        screen_x: int,
        screen_y: int,
        snap: bool = False
    ) -> Tuple[float, float]:
        """
        Convert screen coordinates to world coordinates.

        Args:
            screen_x: X coordinate in pixels
            screen_y: Y coordinate in pixels
            snap: If True and grid is set, snap to grid

        Returns:
            Tuple of (northing, easting) in world units

        Example:
            >>> converter.screen_to_world(400, 300)
            (1000.0, 2000.0)
            >>> converter.screen_to_world(400, 300, snap=True)
            (1000.0, 2000.0)  # Snapped to grid
        """
        # Remove centering offset and apply inverse uniform scaling
        x_rel = (screen_x - self._x_offset) / self._uniform_scale
        y_rel = self._viewport.height - (screen_y - self._y_offset) / self._uniform_scale  # Flip Y axis

        # Convert to world coordinates
        easting = self._viewport.min_easting + x_rel
        northing = self._viewport.min_northing + y_rel

        # Apply grid snapping if requested
        if snap and self._grid is not None:
            northing = self._grid.snap_coordinate(northing)
            easting = self._grid.snap_coordinate(easting)

        return (northing, easting)

    def update_canvas_size(self, width: int, height: int) -> None:
        """
        Update the canvas size.

        Args:
            width: New canvas width in pixels
            height: New canvas height in pixels
        """
        self._canvas_width = width
        self._canvas_height = height
        self._update_scale_factors()

    def get_scale_factor(self) -> float:
        """
        Get the current scale factor (pixels per world unit).

        Returns:
            Average scale factor in pixels per world unit

        Example:
            >>> converter.get_scale_factor()
            8.0  # 8 pixels per meter
        """
        return (self._x_scale + self._y_scale) / 2

    def get_world_distance_per_pixel(self) -> float:
        """
        Get the world distance represented by one pixel.

        Returns:
            World distance per pixel (average of X and Y)

        Example:
            >>> converter.get_world_distance_per_pixel()
            0.125  # 0.125 meters per pixel
        """
        return 1.0 / self.get_scale_factor()

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"CoordinateConverter("
            f"viewport={self._viewport}, "
            f"canvas={self._canvas_width}x{self._canvas_height}, "
            f"scale={self.get_scale_factor():.2f}px/unit)"
        )
