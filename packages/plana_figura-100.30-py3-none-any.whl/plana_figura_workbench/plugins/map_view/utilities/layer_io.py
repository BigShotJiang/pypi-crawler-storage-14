"""Layer properties import/export to standalone XML files."""

import xml.etree.ElementTree as ET
from typing import List
from pathlib import Path
import logging

from plana_figura_workbench.plugins.map_view.map_view_model import Layer, LayerStyle

logger = logging.getLogger(__name__)


def save_layers_to_xml(layers: List[Layer], filename: str) -> None:
    """
    Save layer properties to an XML file.
    
    Args:
        layers: List of Layer objects to save
        filename: Path to XML file
    """
    # Create root element
    root = ET.Element('LayerProperties')
    root.set('version', '1.0')
    
    # Add each layer
    for layer in layers:
        layer_elem = ET.SubElement(root, 'Layer')
        layer_elem.set('name', layer.name)
        
        # Visibility
        ET.SubElement(layer_elem, 'Visible').text = str(layer.visible).lower()
        
        # Z-order
        ET.SubElement(layer_elem, 'ZOrder').text = str(layer.z_order)
        
        # Style
        if layer.style:
            style_elem = ET.SubElement(layer_elem, 'Style')
            ET.SubElement(style_elem, 'StrokeColor').text = layer.style.stroke_color
            ET.SubElement(style_elem, 'StrokeWidth').text = str(layer.style.stroke_width)
            ET.SubElement(style_elem, 'FillColor').text = layer.style.fill_color
            ET.SubElement(style_elem, 'LineJoin').text = getattr(layer.style, 'line_join', 'miter')
            ET.SubElement(style_elem, 'LineCap').text = getattr(layer.style, 'line_cap', 'butt')
            ET.SubElement(style_elem, 'PointSize').text = str(layer.style.point_size)
            ET.SubElement(style_elem, 'PointColor').text = layer.style.point_color
            ET.SubElement(style_elem, 'PointShape').text = layer.style.point_shape
    
    # Create tree and write to file
    tree = ET.ElementTree(root)
    ET.indent(tree, space='  ')  # Pretty print
    
    with open(filename, 'wb') as f:
        tree.write(
            f,
            encoding='utf-8',
            xml_declaration=True
        )
    
    logger.info(f"Saved {len(layers)} layer(s) to {filename}")


def load_layers_from_xml(filename: str) -> List[Layer]:
    """
    Load layer properties from an XML file.
    
    Args:
        filename: Path to XML file
        
    Returns:
        List of Layer objects
    """
    tree = ET.parse(filename)
    root = tree.getroot()
    
    layers = []
    
    for layer_elem in root.findall('Layer'):
        name = layer_elem.get('name', 'Unnamed Layer')
        
        # Visibility
        visible_text = layer_elem.findtext('Visible', 'true')
        visible = visible_text.lower() == 'true'
        
        # Z-order
        z_order = int(layer_elem.findtext('ZOrder', '0'))
        
        # Style
        style = None
        style_elem = layer_elem.find('Style')
        if style_elem is not None:
            style = LayerStyle(
                stroke_color=style_elem.findtext('StrokeColor', 'black'),
                stroke_width=int(style_elem.findtext('StrokeWidth', '1')),
                fill_color=style_elem.findtext('FillColor', 'white'),
                line_join=style_elem.findtext('LineJoin', 'miter'),
                line_cap=style_elem.findtext('LineCap', 'butt'),
                point_size=int(style_elem.findtext('PointSize', '5')),
                point_color=style_elem.findtext('PointColor', 'black'),
                point_shape=style_elem.findtext('PointShape', 'circle')
            )
        
        layer = Layer(
            name=name,
            visible=visible,
            z_order=z_order,
            style=style
        )
        layers.append(layer)
    
    logger.info(f"Loaded {len(layers)} layer(s) from {filename}")
    return layers
