"""Map view dialogs."""

from plana_figura_workbench.plugins.map_view.dialogs.layer_manager_dialog import LayerManagerDialog
from plana_figura_workbench.plugins.map_view.dialogs.layer_properties_dialog import LayerPropertiesDialog
from plana_figura_workbench.plugins.map_view.dialogs.map_settings_dialog import MapSettingsDialog

__all__ = [
    'LayerManagerDialog',
    'LayerPropertiesDialog',
    'MapSettingsDialog',
]
