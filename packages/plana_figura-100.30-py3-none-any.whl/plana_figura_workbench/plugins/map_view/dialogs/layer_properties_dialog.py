"""Dialog for editing layer properties."""

import tkinter as tk
from tkinter import ttk, colorchooser
from typing import Optional
import logging

from plana_figura_workbench.plugins.map_view.map_view_model import LayerStyle

logger = logging.getLogger(__name__)


class LayerPropertiesDialog(tk.Toplevel):
    """Dialog for editing layer style properties."""

    def __init__(self, parent: tk.Widget, layer_name: str, style: LayerStyle):
        """
        Initialize the layer properties dialog.

        Args:
            parent: Parent window
            layer_name: Name of the layer
            style: Current layer style
        """
        super().__init__(parent)

        self.title(f"Layer Properties - {layer_name}")
        self.geometry("450x400")
        self.resizable(False, False)

        # Make dialog modal
        self.transient(parent)
        self.grab_set()

        # Store style
        self.style = style
        self.result: Optional[LayerStyle] = None

        self._setup_ui()

        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_y() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        main_frame = ttk.Frame(self, padding=15)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Stroke properties
        stroke_frame = ttk.LabelFrame(main_frame, text="Stroke Properties", padding=10)
        stroke_frame.pack(fill=tk.X, pady=(0, 10))

        # Stroke color
        color_frame = ttk.Frame(stroke_frame)
        color_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(color_frame, text="Stroke Color:", width=15).pack(side=tk.LEFT)

        self.stroke_color_var = tk.StringVar(value=self.style.stroke_color)
        self.stroke_color_btn = ttk.Button(
            color_frame,
            text="Choose Color",
            command=self._choose_stroke_color,
            bootstyle="secondary"
        )
        self.stroke_color_btn.pack(side=tk.LEFT, padx=(0, 10))

        self.stroke_color_preview = tk.Canvas(
            color_frame, width=50, height=25, bg=self.style.stroke_color
        )
        self.stroke_color_preview.pack(side=tk.LEFT)

        # Stroke width
        width_frame = ttk.Frame(stroke_frame)
        width_frame.pack(fill=tk.X)

        ttk.Label(width_frame, text="Stroke Width:", width=15).pack(side=tk.LEFT)

        self.stroke_width_var = tk.IntVar(value=self.style.stroke_width)
        ttk.Spinbox(
            width_frame,
            from_=1,
            to=10,
            textvariable=self.stroke_width_var,
            width=10
        ).pack(side=tk.LEFT)

        # Fill properties
        fill_frame = ttk.LabelFrame(main_frame, text="Fill Properties", padding=10)
        fill_frame.pack(fill=tk.X, pady=(0, 10))

        # Fill color
        fill_color_frame = ttk.Frame(fill_frame)
        fill_color_frame.pack(fill=tk.X)

        ttk.Label(fill_color_frame, text="Fill Color:", width=15).pack(side=tk.LEFT)

        self.fill_color_var = tk.StringVar(value=self.style.fill_color)
        self.fill_color_btn = ttk.Button(
            fill_color_frame,
            text="Choose Color",
            command=self._choose_fill_color,
            bootstyle="secondary"
        )
        self.fill_color_btn.pack(side=tk.LEFT, padx=(0, 10))

        self.fill_color_preview = tk.Canvas(
            fill_color_frame, width=50, height=25, bg=self.style.fill_color
        )
        self.fill_color_preview.pack(side=tk.LEFT)

        # Point properties
        point_frame = ttk.LabelFrame(main_frame, text="Point Properties", padding=10)
        point_frame.pack(fill=tk.X, pady=(0, 10))

        # Point size
        size_frame = ttk.Frame(point_frame)
        size_frame.pack(fill=tk.X)

        ttk.Label(size_frame, text="Point Size:", width=15).pack(side=tk.LEFT)

        self.point_size_var = tk.IntVar(value=self.style.point_size)
        ttk.Spinbox(
            size_frame,
            from_=1,
            to=20,
            textvariable=self.point_size_var,
            width=10
        ).pack(side=tk.LEFT)

        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))

        ttk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=12
        ).pack(side=tk.RIGHT, padx=(5, 0))

        ttk.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle="primary",
            width=12
        ).pack(side=tk.RIGHT)

    def _choose_stroke_color(self) -> None:
        """Choose stroke color."""
        color = colorchooser.askcolor(
            color=self.stroke_color_var.get(),
            title="Choose Stroke Color",
            parent=self
        )
        if color[1]:  # color[1] is the hex string
            self.stroke_color_var.set(color[1])
            self.stroke_color_preview.config(bg=color[1])

    def _choose_fill_color(self) -> None:
        """Choose fill color."""
        color = colorchooser.askcolor(
            color=self.fill_color_var.get(),
            title="Choose Fill Color",
            parent=self
        )
        if color[1]:  # color[1] is the hex string
            self.fill_color_var.set(color[1])
            self.fill_color_preview.config(bg=color[1])

    def _on_ok(self) -> None:
        """Handle OK button click."""
        self.result = LayerStyle(
            stroke_color=self.stroke_color_var.get(),
            stroke_width=self.stroke_width_var.get(),
            fill_color=self.fill_color_var.get(),
            point_size=self.point_size_var.get()
        )
        self.destroy()

    def _on_cancel(self) -> None:
        """Handle Cancel button click."""
        self.result = None
        self.destroy()

    def show(self) -> Optional[LayerStyle]:
        """Show the dialog and wait for result."""
        self.wait_window()
        return self.result
