"""Map Settings Dialog for MapView plugin.

This dialog allows users to configure map canvas settings including:
- Background color
- Grid visibility
- Grid line interval
"""

import tkinter as tk
from tkinter import ttk, colorchooser, filedialog, messagebox
from typing import TYPE_CHECKING
import logging
from pathlib import Path

if TYPE_CHECKING:
    from plana_figura_workbench.plugins.map_view.map_view_controller import (
        MapViewController
    )

logger = logging.getLogger(__name__)


class MapSettingsDialog(tk.Toplevel):
    """Dialog for configuring map canvas settings."""

    def __init__(self, parent, controller: 'MapViewController', canvas: tk.Canvas):
        """
        Initialize the map settings dialog.

        Args:
            parent: Parent widget
            controller: MapViewController instance
            canvas: Canvas widget
        """
        super().__init__(parent)
        self.controller = controller
        self.canvas = canvas
        self.title("Map Settings")
        self.geometry("450x450")
        self.minsize(450, 450)
        self.resizable(True, True)

        # Make dialog modal
        self.transient(parent)
        self.grab_set()

        # Current settings
        self.current_bg_color = self.canvas.cget("bg")
        self.grid_visible = False
        self.grid_interval = 10.0

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Main frame
        main_frame = ttk.Frame(self, padding=10)
        main_frame.pack(fill="both", expand=True)

        # Background color section
        bg_frame = ttk.LabelFrame(main_frame, text="Background", padding=10)
        bg_frame.pack(fill="x", pady=(0, 10))

        # Configure grid columns
        bg_frame.columnconfigure(0, weight=0, minsize=120)
        bg_frame.columnconfigure(1, weight=1, minsize=150)
        bg_frame.columnconfigure(2, weight=0, minsize=80)

        ttk.Label(bg_frame, text="Background Color:").grid(
            row=0, column=0, sticky="w", padx=5, pady=5
        )

        self.bg_color_frame = tk.Frame(
            bg_frame,
            width=100,
            height=25,
            relief="solid",
            borderwidth=1,
            bg=self.current_bg_color
        )
        self.bg_color_frame.grid(row=0, column=1, sticky="ew", padx=5, pady=5)

        ttk.Button(
            bg_frame,
            text="Choose...",
            command=self._choose_bg_color,
            width=10
        ).grid(row=0, column=2, sticky="ew", padx=5, pady=5)

        # Selection color
        ttk.Label(bg_frame, text="Selection Color:").grid(
            row=1, column=0, sticky="w", padx=5, pady=5
        )

        self.selection_color = self.controller.model.selection_color
        self.selection_color_frame = tk.Frame(
            bg_frame,
            width=100,
            height=25,
            relief="solid",
            borderwidth=1,
            bg=self.selection_color
        )
        self.selection_color_frame.grid(row=1, column=1, sticky="ew", padx=5, pady=5)

        ttk.Button(
            bg_frame,
            text="Choose...",
            command=self._choose_selection_color,
            width=10
        ).grid(row=1, column=2, sticky="ew", padx=5, pady=5)

        # Hover color
        ttk.Label(bg_frame, text="Hover Color:").grid(
            row=2, column=0, sticky="w", padx=5, pady=5
        )

        self.hover_color = getattr(self.controller.model, 'hover_color', 'orange')
        self.hover_color_frame = tk.Frame(
            bg_frame,
            width=100,
            height=25,
            relief="solid",
            borderwidth=1,
            bg=self.hover_color
        )
        self.hover_color_frame.grid(row=2, column=1, sticky="ew", padx=5, pady=5)

        ttk.Button(
            bg_frame,
            text="Choose...",
            command=self._choose_hover_color,
            width=10
        ).grid(row=2, column=2, sticky="ew", padx=5, pady=5)

        # Grid section
        grid_frame = ttk.LabelFrame(main_frame, text="Grid", padding=10)
        grid_frame.pack(fill="x", pady=(0, 10))

        # Configure grid columns
        grid_frame.columnconfigure(0, weight=0, minsize=120)
        grid_frame.columnconfigure(1, weight=1, minsize=150)
        grid_frame.columnconfigure(2, weight=0, minsize=80)

        # Grid visibility
        self.grid_visible_var = tk.BooleanVar(value=self.grid_visible)
        ttk.Checkbutton(
            grid_frame,
            text="Show Grid Lines",
            variable=self.grid_visible_var,
            command=self._toggle_grid
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=5, pady=5)

        # Grid interval
        ttk.Label(grid_frame, text="Grid Interval:").grid(
            row=1, column=0, sticky="w", padx=5, pady=5
        )

        self.grid_interval_var = tk.DoubleVar(value=self.grid_interval)
        interval_spinbox = ttk.Spinbox(
            grid_frame,
            from_=1.0,
            to=100.0,
            increment=1.0,
            textvariable=self.grid_interval_var
        )
        interval_spinbox.grid(row=1, column=1, sticky="ew", padx=5, pady=5)

        ttk.Label(grid_frame, text="units").grid(
            row=1, column=2, sticky="w", padx=5, pady=5
        )

        # Grid color
        ttk.Label(grid_frame, text="Grid Color:").grid(
            row=2, column=0, sticky="w", padx=5, pady=5
        )

        self.grid_color = "#CCCCCC"
        self.grid_color_frame = tk.Frame(
            grid_frame,
            width=100,
            height=25,
            relief="solid",
            borderwidth=1,
            bg=self.grid_color
        )
        self.grid_color_frame.grid(row=2, column=1, sticky="ew", padx=5, pady=5)

        ttk.Button(
            grid_frame,
            text="Choose...",
            command=self._choose_grid_color,
            width=10
        ).grid(row=2, column=2, sticky="ew", padx=5, pady=5)

        # Save as default checkbox
        default_frame = ttk.Frame(main_frame)
        default_frame.pack(fill="x", pady=(10, 0))

        self.save_as_default_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            default_frame,
            text="Save as default (will be loaded on startup)",
            variable=self.save_as_default_var
        ).pack(side="left", padx=5)

        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill="x", pady=(10, 0))

        # Left side - Load/Save buttons
        ttk.Button(
            button_frame,
            text="Load from TOML...",
            command=self._load_from_toml,
            width=15
        ).pack(side="left", padx=5)

        ttk.Button(
            button_frame,
            text="Save to TOML...",
            command=self._save_to_toml,
            width=15
        ).pack(side="left", padx=5)

        # Right side - Apply/Close buttons
        ttk.Button(
            button_frame,
            text="Apply",
            command=self._apply_settings,
            width=10
        ).pack(side="right", padx=5)

        ttk.Button(
            button_frame,
            text="Close",
            command=self.destroy,
            width=10
        ).pack(side="right", padx=5)

    def _choose_bg_color(self) -> None:
        """Choose background color."""
        color = colorchooser.askcolor(
            initialcolor=self.current_bg_color,
            title="Choose Background Color"
        )
        if color[1]:
            self.current_bg_color = color[1]
            self.bg_color_frame.config(bg=self.current_bg_color)

    def _choose_selection_color(self) -> None:
        """Choose selection color."""
        color = colorchooser.askcolor(
            initialcolor=self.selection_color,
            title="Choose Selection Color"
        )
        if color[1]:
            self.selection_color = color[1]
            self.selection_color_frame.config(bg=self.selection_color)

    def _choose_grid_color(self) -> None:
        """Choose grid color."""
        color = colorchooser.askcolor(
            initialcolor=self.grid_color,
            title="Choose Grid Color"
        )
        if color[1]:
            self.grid_color = color[1]
            self.grid_color_frame.config(bg=self.grid_color)

    def _toggle_grid(self) -> None:
        """Toggle grid visibility."""
        self.grid_visible = self.grid_visible_var.get()

    def _apply_settings(self) -> None:
        """Apply settings to the map."""
        # Apply background color
        self.canvas.config(bg=self.current_bg_color)

        # Apply selection color
        self.controller.model.selection_color = self.selection_color

        # Apply hover color
        self.controller.model.hover_color = self.hover_color

        # Apply grid settings
        if self.grid_visible:
            self._draw_grid()
        else:
            self._clear_grid()

        # Save settings
        self.controller.save_settings(self.current_bg_color)

        # Save as default if checkbox is checked
        if self.save_as_default_var.get():
            self._save_as_default()

        logger.info("Applied map settings")

    def _draw_grid(self) -> None:
        """Draw grid lines on the canvas."""
        # Clear existing grid
        self._clear_grid()

        # Get viewport bounds
        viewport = self.controller.model.viewport
        converter = self.controller.renderer.converter

        # Calculate grid interval in screen coordinates
        interval = self.grid_interval_var.get()

        # Draw vertical lines
        min_easting = viewport.min_easting
        max_easting = viewport.max_easting

        easting = min_easting - (min_easting % interval)
        while easting <= max_easting:
            x1, y1 = converter.world_to_screen(viewport.min_northing, easting)
            x2, y2 = converter.world_to_screen(viewport.max_northing, easting)

            self.canvas.create_line(
                x1, y1, x2, y2,
                fill=self.grid_color,
                tags="grid"
            )
            easting += interval

        # Draw horizontal lines
        min_northing = viewport.min_northing
        max_northing = viewport.max_northing

        northing = min_northing - (min_northing % interval)
        while northing <= max_northing:
            x1, y1 = converter.world_to_screen(northing, viewport.min_easting)
            x2, y2 = converter.world_to_screen(northing, viewport.max_easting)

            self.canvas.create_line(
                x1, y1, x2, y2,
                fill=self.grid_color,
                tags="grid"
            )
            northing += interval

        # Lower grid lines below geometry
        self.canvas.tag_lower("grid")

        logger.debug(f"Drew grid with interval {interval}")

    def _clear_grid(self) -> None:
        """Clear grid lines from the canvas."""
        self.canvas.delete("grid")
        logger.debug("Cleared grid")

    def _choose_hover_color(self) -> None:
        """Choose hover color."""
        color = colorchooser.askcolor(
            initialcolor=self.hover_color,
            title="Choose Hover Color"
        )
        if color[1]:
            self.hover_color = color[1]
            self.hover_color_frame.config(bg=self.hover_color)

    def _load_from_toml(self) -> None:
        """Load settings from a TOML file."""
        filename = filedialog.askopenfilename(
            title="Load Map Settings",
            filetypes=[("TOML files", "*.toml"), ("All files", "*.*")]
        )
        if not filename:
            return

        try:
            import tomllib
            with open(filename, 'rb') as f:
                settings = tomllib.load(f)

            # Apply loaded settings
            if 'background_color' in settings:
                self.current_bg_color = settings['background_color']
                self.bg_color_frame.config(bg=self.current_bg_color)

            if 'selection_color' in settings:
                self.selection_color = settings['selection_color']
                self.selection_color_frame.config(bg=self.selection_color)

            if 'hover_color' in settings:
                self.hover_color = settings['hover_color']
                self.hover_color_frame.config(bg=self.hover_color)

            if 'grid' in settings:
                grid = settings['grid']
                self.grid_visible_var.set(grid.get('visible', False))
                self.grid_interval_var.set(grid.get('interval', 10.0))
                if 'color' in grid:
                    self.grid_color = grid['color']
                    self.grid_color_frame.config(bg=self.grid_color)

            messagebox.showinfo("Success", f"Settings loaded from {Path(filename).name}")
            logger.info(f"Loaded settings from {filename}")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load settings: {e}")
            logger.error(f"Failed to load settings from {filename}: {e}")

    def _save_to_toml(self) -> None:
        """Save settings to a TOML file."""
        filename = filedialog.asksaveasfilename(
            title="Save Map Settings",
            defaultextension=".toml",
            filetypes=[("TOML files", "*.toml"), ("All files", "*.*")]
        )
        if not filename:
            return

        try:
            settings = {
                'background_color': self.current_bg_color,
                'selection_color': self.selection_color,
                'hover_color': self.hover_color,
                'grid': {
                    'visible': self.grid_visible_var.get(),
                    'interval': self.grid_interval_var.get(),
                    'color': self.grid_color
                }
            }

            # Write TOML file
            with open(filename, 'w') as f:
                f.write("# Map View Settings\n\n")
                f.write(f'background_color = "{settings["background_color"]}"\n')
                f.write(f'selection_color = "{settings["selection_color"]}"\n')
                f.write(f'hover_color = "{settings["hover_color"]}"\n')
                f.write('\n[grid]\n')
                f.write(f'visible = {str(settings["grid"]["visible"]).lower()}\n')
                f.write(f'interval = {settings["grid"]["interval"]}\n')
                f.write(f'color = "{settings["grid"]["color"]}"\n')

            messagebox.showinfo("Success", f"Settings saved to {Path(filename).name}")
            logger.info(f"Saved settings to {filename}")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to save settings: {e}")
            logger.error(f"Failed to save settings to {filename}: {e}")

    def _save_as_default(self) -> None:
        """Save current settings as default."""
        try:
            default_path = self._get_default_settings_path()
            default_path.parent.mkdir(parents=True, exist_ok=True)

            settings = {
                'background_color': self.current_bg_color,
                'selection_color': self.selection_color,
                'hover_color': self.hover_color,
                'grid': {
                    'visible': self.grid_visible_var.get(),
                    'interval': self.grid_interval_var.get(),
                    'color': self.grid_color
                }
            }

            # Write TOML file
            with open(default_path, 'w') as f:
                f.write("# Map View Default Settings\n\n")
                f.write(f'background_color = "{settings["background_color"]}"\n')
                f.write(f'selection_color = "{settings["selection_color"]}"\n')
                f.write(f'hover_color = "{settings["hover_color"]}"\n')
                f.write('\n[grid]\n')
                f.write(f'visible = {str(settings["grid"]["visible"]).lower()}\n')
                f.write(f'interval = {settings["grid"]["interval"]}\n')
                f.write(f'color = "{settings["grid"]["color"]}"\n')

            logger.info(f"Saved default settings to {default_path}")
            messagebox.showinfo(
                "Success",
                "Settings saved as default.\nThey will be loaded when the application starts."
            )

        except Exception as e:
            messagebox.showerror("Error", f"Failed to save default settings: {e}")
            logger.error(f"Failed to save default settings: {e}")

    @staticmethod
    def _get_default_settings_path() -> Path:
        """Get the path to the default settings file."""
        from pathlib import Path
        import os

        # Use user's home directory
        if os.name == 'nt':  # Windows
            config_dir = Path.home() / 'AppData' / 'Local' / 'PlanaFigura'
        else:  # Unix-like
            config_dir = Path.home() / '.config' / 'plana_figura'

        return config_dir / 'map_view_defaults.toml'

    @staticmethod
    def load_default_settings() -> dict:
        """Load default settings if they exist."""
        try:
            default_path = MapSettingsDialog._get_default_settings_path()
            if not default_path.exists():
                return {}

            settings = {}
            with open(default_path, 'r') as f:
                content = f.read()

                # Simple TOML parsing for our specific format
                for line in content.split('\n'):
                    line = line.strip()
                    if not line or line.startswith('#') or line.startswith('['):
                        continue

                    if '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip().strip('"')

                        # Handle boolean values
                        if value.lower() == 'true':
                            value = True
                        elif value.lower() == 'false':
                            value = False
                        # Handle numeric values
                        elif value.replace('.', '', 1).isdigit():
                            value = float(value) if '.' in value else int(value)

                        settings[key] = value

            logger.info(f"Loaded default settings from {default_path}")
            return settings

        except Exception as e:
            logger.warning(f"Failed to load default settings: {e}")
            return {}
