"""Layer Manager Dialog for MapView plugin.

This dialog allows users to configure layer properties including:
- Fill color
- Stroke color
- Stroke width
- Line join type
- Line end type
"""

import tkinter as tk
from tkinter import ttk, colorchooser
from typing import TYPE_CHECKING
import logging

if TYPE_CHECKING:
    from plana_figura_workbench.plugins.map_view.map_view_controller import (
        MapViewController
    )

logger = logging.getLogger(__name__)


class LayerManagerDialog(tk.Toplevel):
    """Dialog for managing layer properties."""

    def __init__(self, parent, controller: 'MapViewController'):
        """
        Initialize the layer manager dialog.

        Args:
            parent: Parent widget
            controller: MapViewController instance
        """
        super().__init__(parent)
        self.controller = controller
        self.title("Layer Manager")
        self.geometry("500x700")
        self.minsize(500, 700)
        self.resizable(True, True)

        # Make dialog modal
        self.transient(parent)
        self.grab_set()

        self._setup_ui()
        self._load_layers()

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Main frame
        main_frame = ttk.Frame(self, padding=10)
        main_frame.pack(fill="both", expand=True)

        # Layer list
        list_frame = ttk.LabelFrame(main_frame, text="Layers", padding=5)
        list_frame.pack(fill="both", expand=True, pady=(0, 10))

        # Scrollbar and listbox
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side="right", fill="y")

        self.layer_listbox = tk.Listbox(
            list_frame,
            yscrollcommand=scrollbar.set,
            selectmode="single"
        )
        self.layer_listbox.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.layer_listbox.yview)

        self.layer_listbox.bind("<<ListboxSelect>>", self._on_layer_select)

        # Selected layer indicator
        indicator_frame = ttk.Frame(main_frame)
        indicator_frame.pack(fill="x", pady=(0, 10))
        ttk.Label(indicator_frame, text="Editing:", font=("TkDefaultFont", 9, "bold")).pack(side="left", padx=(0, 5))
        self.selected_layer_label = ttk.Label(indicator_frame, text="(No layer selected)", foreground="blue")
        self.selected_layer_label.pack(side="left")

        # Properties frame
        props_frame = ttk.LabelFrame(main_frame, text="Layer Properties", padding=10)
        props_frame.pack(fill="x", pady=(0, 10))

        # Configure grid columns for consistent sizing
        props_frame.columnconfigure(0, weight=0, minsize=120)  # Labels
        props_frame.columnconfigure(1, weight=1, minsize=150)  # Controls
        props_frame.columnconfigure(2, weight=0, minsize=80)   # Buttons

        # Fill color
        ttk.Label(props_frame, text="Fill Color:").grid(
            row=0, column=0, sticky="w", padx=5, pady=5
        )
        self.fill_color_frame = tk.Frame(
            props_frame, width=100, height=25, relief="solid", borderwidth=1
        )
        self.fill_color_frame.grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        ttk.Button(
            props_frame, text="Choose...", command=self._choose_fill_color, width=10
        ).grid(row=0, column=2, sticky="ew", padx=5, pady=5)

        # Stroke color
        ttk.Label(props_frame, text="Stroke Color:").grid(
            row=1, column=0, sticky="w", padx=5, pady=5
        )
        self.stroke_color_frame = tk.Frame(
            props_frame, width=100, height=25, relief="solid", borderwidth=1
        )
        self.stroke_color_frame.grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        ttk.Button(
            props_frame, text="Choose...", command=self._choose_stroke_color, width=10
        ).grid(row=1, column=2, sticky="ew", padx=5, pady=5)

        # Stroke width
        ttk.Label(props_frame, text="Stroke Width:").grid(
            row=2, column=0, sticky="w", padx=5, pady=5
        )
        self.stroke_width_var = tk.IntVar(value=1)
        stroke_width_spinbox = ttk.Spinbox(
            props_frame,
            from_=1,
            to=10,
            textvariable=self.stroke_width_var
        )
        stroke_width_spinbox.grid(row=2, column=1, sticky="ew", padx=5, pady=5, columnspan=2)

        # Line join type
        ttk.Label(props_frame, text="Line Join:").grid(
            row=3, column=0, sticky="w", padx=5, pady=5
        )
        self.line_join_var = tk.StringVar(value="miter")
        line_join_combo = ttk.Combobox(
            props_frame,
            textvariable=self.line_join_var,
            values=["miter", "round", "bevel"],
            state="readonly"
        )
        line_join_combo.grid(row=3, column=1, sticky="ew", padx=5, pady=5, columnspan=2)

        # Line cap type
        ttk.Label(props_frame, text="Line Cap:").grid(
            row=4, column=0, sticky="w", padx=5, pady=5
        )
        self.line_cap_var = tk.StringVar(value="butt")
        line_cap_combo = ttk.Combobox(
            props_frame,
            textvariable=self.line_cap_var,
            values=["butt", "round", "projecting"],
            state="readonly"
        )
        line_cap_combo.grid(row=4, column=1, sticky="ew", padx=5, pady=5, columnspan=2)

        # Point color
        ttk.Label(props_frame, text="Point Color:").grid(
            row=5, column=0, sticky="w", padx=5, pady=5
        )
        self.point_color_frame = tk.Frame(
            props_frame, width=100, height=25, relief="solid", borderwidth=1
        )
        self.point_color_frame.grid(row=5, column=1, sticky="ew", padx=5, pady=5)
        ttk.Button(
            props_frame, text="Choose...", command=self._choose_point_color, width=10
        ).grid(row=5, column=2, sticky="ew", padx=5, pady=5)

        # Point size (radius)
        ttk.Label(props_frame, text="Point Radius:").grid(
            row=6, column=0, sticky="w", padx=5, pady=5
        )
        self.point_size_var = tk.IntVar(value=5)
        point_size_spinbox = ttk.Spinbox(
            props_frame,
            from_=1,
            to=20,
            textvariable=self.point_size_var
        )
        point_size_spinbox.grid(row=6, column=1, sticky="ew", padx=5, pady=5, columnspan=2)

        # Apply button
        ttk.Button(
            props_frame, text="Apply", command=self._apply_properties, width=15
        ).grid(row=7, column=1, columnspan=2, sticky="e", padx=5, pady=10)

        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill="x")

        ttk.Button(button_frame, text="Close", command=self.destroy).pack(
            side="right", padx=5
        )

        # Store current colors and selected layer
        self.current_fill_color = "#FFFFFF"
        self.current_stroke_color = "#000000"
        self.current_point_color = "yellow"
        self.selected_layer_index = None  # Track selected layer

    def _load_layers(self) -> None:
        """Load layers into the listbox."""
        self.layer_listbox.delete(0, tk.END)
        for layer in self.controller.model.layers:
            self.layer_listbox.insert(tk.END, layer.name)
        
        # Select first layer by default if available
        if len(self.controller.model.layers) > 0:
            self.layer_listbox.selection_set(0)
            self.selected_layer_index = 0
            # Trigger selection event to load properties
            self._on_layer_select(None)

    def _on_layer_select(self, event) -> None:
        """Handle layer selection."""
        selection = self.layer_listbox.curselection()
        if not selection:
            return

        index = selection[0]
        self.selected_layer_index = index  # Store the selected index
        layer = self.controller.model.layers[index]

        # Update selected layer indicator
        self.selected_layer_label.config(text=layer.name, foreground="blue")

        # Update UI with layer properties
        self.current_fill_color = layer.style.fill_color or "#FFFFFF"
        self.current_stroke_color = layer.style.stroke_color or "#000000"
        self.current_point_color = layer.style.point_color or "yellow"

        self.fill_color_frame.config(bg=self.current_fill_color)
        self.stroke_color_frame.config(bg=self.current_stroke_color)
        self.point_color_frame.config(bg=self.current_point_color)
        self.stroke_width_var.set(layer.style.stroke_width)
        self.line_join_var.set(getattr(layer.style, 'line_join', 'miter'))
        self.line_cap_var.set(getattr(layer.style, 'line_cap', 'butt'))
        self.point_size_var.set(layer.style.point_size)

    def _choose_fill_color(self) -> None:
        """Choose fill color."""
        color = colorchooser.askcolor(
            initialcolor=self.current_fill_color,
            title="Choose Fill Color"
        )
        if color[1]:
            self.current_fill_color = color[1]
            self.fill_color_frame.config(bg=self.current_fill_color)

    def _choose_stroke_color(self) -> None:
        """Choose stroke color."""
        color = colorchooser.askcolor(
            initialcolor=self.current_stroke_color,
            title="Choose Stroke Color"
        )
        if color[1]:
            self.current_stroke_color = color[1]
            self.stroke_color_frame.config(bg=self.current_stroke_color)

    def _choose_point_color(self) -> None:
        """Choose point color."""
        color = colorchooser.askcolor(
            initialcolor=self.current_point_color,
            title="Choose Point Color"
        )
        if color[1]:
            self.current_point_color = color[1]
            self.point_color_frame.config(bg=self.current_point_color)

    def _apply_properties(self) -> None:
        """Apply properties to selected layer."""
        # Use stored index instead of curselection (which clears when focus lost)
        if self.selected_layer_index is None:
            logger.warning("No layer selected")
            return

        if self.selected_layer_index >= len(self.controller.model.layers):
            logger.warning("Selected layer index out of range")
            return

        layer = self.controller.model.layers[self.selected_layer_index]

        # Get values
        line_join = self.line_join_var.get()
        line_cap = self.line_cap_var.get()
        logger.info(f"Dialog sending: line_join='{line_join}', line_cap='{line_cap}'")

        # Update layer style
        self.controller.update_layer_style(
            layer.name,
            fill_color=self.current_fill_color,
            stroke_color=self.current_stroke_color,
            stroke_width=self.stroke_width_var.get(),
            line_join=line_join,
            line_cap=line_cap,
            point_color=self.current_point_color,
            point_size=self.point_size_var.get()
        )

        # Save settings
        canvas = self.controller._canvas
        if canvas:
            bg_color = canvas.cget("bg")
            self.controller.save_settings(bg_color)

        logger.info(f"Applied properties to layer '{layer.name}'")
