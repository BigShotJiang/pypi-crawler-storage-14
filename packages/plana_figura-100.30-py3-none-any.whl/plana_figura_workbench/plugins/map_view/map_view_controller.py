"""MapView controller - business logic and coordination.

This module provides the MapViewController class which mediates between
the model, view (renderer), and tools. It handles document observation,
tool management, and command execution.
"""

from typing import Optional, Dict, Any, Tuple, TYPE_CHECKING
import logging
import math

from plana_figura import Geometry
from plana_figura.spatial import TwoDimensionalEnvelope
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.model.document import Observer
from plana_figura_workbench.plugins.map_view.map_view_model import (
    MapViewModel,
    Layer,
    LayerStyle
)
from plana_figura_workbench.plugins.map_view.map_view_renderer import (
    MapViewRenderer
)
from plana_figura_workbench.plugins.map_view.map_view_settings import (
    MapViewSettings
)

if TYPE_CHECKING:
    from plana_figura_workbench.plugins.map_view.tools.map_tool import MapTool
    from vultus_serpentis.events import EventBus

logger = logging.getLogger(__name__)


class MapViewController(Observer):
    """
    Controller for the MapView plugin.

    Mediates between the document, model, renderer, and tools. Handles:
    - Document observation and synchronization
    - Tool lifecycle management
    - Event delegation to active tool
    - Command execution
    - Viewport management

    Example:
        >>> controller = MapViewController(document, model, renderer, event_bus)
        >>> controller.set_active_tool(pan_tool)
        >>> controller.zoom_in()
        >>> controller.fit_to_contents()
    """

    def __init__(
        self,
        document: PlanaFiguraDocument,
        model: MapViewModel,
        renderer: MapViewRenderer,
        event_bus: Optional['EventBus'] = None
    ):
        """
        Initialize the controller.

        Args:
            document: The document to observe
            model: The view model
            renderer: The renderer
            event_bus: Optional event bus for plugin communication
        """
        self.document = document
        self.model = model
        self.renderer = renderer
        self.event_bus = event_bus

        # Register as document observer
        self.document.add_observer(self)

        # Tool management
        self._tools: Dict[str, 'MapTool'] = {}
        self._active_tool: Optional['MapTool'] = None

        # Canvas reference (set by view)
        self._canvas: Optional[Any] = None

        # Settings persistence
        self.settings = MapViewSettings()

        # Selection manager access (through data_bucket)
        self._selection_manager = None
        logger.info(f"=== MapViewController: Initializing ===")
        logger.info(f"Model: {type(self.model).__name__}")
        logger.info(f"Model data bucket available: {self.model.data_bucket is not None}")
        
        # Try to get SelectionManager from model's data_bucket
        data_bucket = self.model.data_bucket
        if data_bucket is not None:
            logger.info(f"DataBucket type: {type(data_bucket).__name__}")
            logger.info(f"DataBucket contents: {list(data_bucket._data.keys()) if hasattr(data_bucket, '_data') else 'unknown'}")
            
            from plana_figura_workbench.model import DataBucketKeys
            logger.info(f"Looking for key: {DataBucketKeys.SELECTION_MANAGER}")
            
            self._selection_manager = data_bucket.get(DataBucketKeys.SELECTION_MANAGER, None)
            logger.info(f"Selection manager found in model data_bucket: {self._selection_manager is not None}")
            
            if self._selection_manager is not None:
                logger.info(f"SelectionManager type: {type(self._selection_manager).__name__}")
                logger.info(f"SelectionManager current count: {self._selection_manager.get_count()}")
                
                # Subscribe to selection changes
                self._selection_manager.add_observer(self._on_selection_changed)
                logger.info(f"Subscribed to SelectionManager, observer count: {len(self._selection_manager._observers)}")
            else:
                logger.warning("No selection_manager in data_bucket")
                logger.warning(f"Available keys: {list(data_bucket._data.keys()) if hasattr(data_bucket, '_data') else 'unknown'}")
        else:
            logger.warning("No data_bucket available in model")

        # Initialize layers from document
        self._sync_layers_from_document()

        logger.info("=== MapViewController initialized ===")

    def set_canvas(self, canvas: Any) -> None:
        """
        Set the canvas reference.

        Args:
            canvas: The canvas widget
        """
        self._canvas = canvas

    def set_cursor(self, cursor: str) -> None:
        """
        Set the canvas cursor.

        Args:
            cursor: Cursor name (e.g., "arrow", "crosshair", "hand2")
        """
        if self._canvas:
            self._canvas.config(cursor=cursor)

    def register_tool(self, name: str, tool: 'MapTool') -> None:
        """
        Register a tool with the controller.

        Args:
            name: Tool name (e.g., "pan", "zoom", "select")
            tool: The tool instance
        """
        self._tools[name] = tool
        logger.debug(f"Registered tool: {name}")

    def set_active_tool(self, name: str) -> None:
        """
        Activate a tool by name.

        Args:
            name: Tool name to activate
        """
        print(f"=" * 80)
        print(f"SET_ACTIVE_TOOL: Requested tool: {name}")
        print(f"SET_ACTIVE_TOOL: Available tools: {list(self._tools.keys())}")
        print(f"=" * 80)
        
        if name not in self._tools:
            logger.warning(f"Tool not found: {name}")
            print(f"ERROR: Tool '{name}' not found!")
            return

        # Deactivate current tool
        if self._active_tool:
            old_tool_name = type(self._active_tool).__name__
            print(f"SET_ACTIVE_TOOL: Deactivating old tool: {old_tool_name}")
            self._active_tool.deactivate()

        # Activate new tool
        self._active_tool = self._tools[name]
        new_tool_name = type(self._active_tool).__name__
        print(f"SET_ACTIVE_TOOL: Activating new tool: {new_tool_name}")
        self._active_tool.activate()
        self.model.active_tool = self._active_tool

        logger.info(f"Activated tool: {name}")
        print(f"SET_ACTIVE_TOOL: Tool activation complete")

    def get_active_tool(self) -> Optional['MapTool']:
        """
        Get the currently active tool.

        Returns:
            The active tool, or None if no tool is active
        """
        return self._active_tool

    # Event delegation to active tool

    def on_mouse_press(self, event: Any) -> None:
        """Delegate mouse press to active tool."""
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"CONTROLLER: Mouse press received, active tool: {type(self._active_tool).__name__ if self._active_tool else 'None'}")
        
        if self._active_tool:
            logger.info(f"CONTROLLER: Delegating to {type(self._active_tool).__name__}")
            self._active_tool.on_mouse_press(event)
        else:
            logger.warning(f"CONTROLLER: No active tool to handle mouse press")

    def on_mouse_move(self, event: Any) -> None:
        """Delegate mouse move to active tool."""
        if self._active_tool:
            self._active_tool.on_mouse_move(event)

    def on_mouse_release(self, event: Any) -> None:
        """Delegate mouse release to active tool."""
        if self._active_tool:
            self._active_tool.on_mouse_release(event)

    def on_mouse_wheel(self, event: Any) -> None:
        """Delegate mouse wheel to active tool."""
        if self._active_tool:
            self._active_tool.on_mouse_wheel(event)

    def on_key_press(self, event: Any) -> None:
        """Delegate key press to active tool."""
        if self._active_tool:
            self._active_tool.on_key_press(event)

    # Viewport management

    def pan(self, dx: int, dy: int) -> None:
        """
        Pan the viewport by screen pixels.

        Args:
            dx: Horizontal pan in pixels (positive = pan right)
            dy: Vertical pan in pixels (positive = pan down)
        """
        viewport = self.model.viewport

        # Convert pixel delta to world delta
        world_dx = dx * (viewport.width / self.renderer.converter.canvas_width)
        world_dy = dy * (viewport.height / self.renderer.converter.canvas_height)

        # Pan viewport in same direction as drag (intuitive behavior)
        # When user drags right (+dx), viewport moves left (-world_dx) to show content to the right
        # When user drags down (+dy), viewport moves up (+world_dy) to show content below
        new_viewport = TwoDimensionalEnvelope(
            viewport.min_northing + world_dy,
            viewport.max_northing + world_dy,
            viewport.min_easting - world_dx,
            viewport.max_easting - world_dx
        )

        self.model.viewport = new_viewport
        self.renderer.update_viewport(new_viewport)
        self.refresh()

    def zoom(
        self,
        factor: float,
        center_x: Optional[int] = None,
        center_y: Optional[int] = None
    ) -> None:
        """
        Zoom the viewport by a factor.

        Args:
            factor: Zoom factor (> 1 = zoom in, < 1 = zoom out)
            center_x: Optional screen X coordinate to zoom around
            center_y: Optional screen Y coordinate to zoom around
        """
        viewport = self.model.viewport

        # If no center provided, zoom around viewport center
        if center_x is None or center_y is None:
            center_x = self.renderer.converter.canvas_width // 2
            center_y = self.renderer.converter.canvas_height // 2

        # Convert center to world coordinates
        center_northing, center_easting = self.renderer.converter.screen_to_world(
            center_x, center_y
        )

        # Calculate new viewport dimensions
        new_width = viewport.width / factor
        new_height = viewport.height / factor

        # Calculate new viewport bounds (centered on zoom point)
        new_min_easting = center_easting - (new_width / 2)
        new_max_easting = center_easting + (new_width / 2)
        new_min_northing = center_northing - (new_height / 2)
        new_max_northing = center_northing + (new_height / 2)

        new_viewport = TwoDimensionalEnvelope(
            new_min_northing,
            new_max_northing,
            new_min_easting,
            new_max_easting
        )

        self.model.viewport = new_viewport
        self.model.zoom_level *= factor
        self.renderer.update_viewport(new_viewport)
        self.refresh()

    def zoom_in(self, center_x: Optional[int] = None, center_y: Optional[int] = None) -> None:
        """Zoom in by a fixed factor."""
        self.zoom(1.2, center_x, center_y)

    def zoom_out(self, center_x: Optional[int] = None, center_y: Optional[int] = None) -> None:
        """Zoom out by a fixed factor."""
        self.zoom(0.8, center_x, center_y)

    def zoom_at_point(self, screen_x: int, screen_y: int, factor: float) -> None:
        """
        Zoom at a specific screen point.

        Args:
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate
            factor: Zoom factor (> 1 = zoom in, < 1 = zoom out)
        """
        self.zoom(factor, screen_x, screen_y)

    def zoom_to_box(
        self,
        start_x: int,
        start_y: int,
        end_x: int,
        end_y: int
    ) -> None:
        """
        Zoom to fit a screen box.

        Args:
            start_x: Start screen X coordinate
            start_y: Start screen Y coordinate
            end_x: End screen X coordinate
            end_y: End screen Y coordinate
        """
        import logging
        logger = logging.getLogger(__name__)
        
        # Convert screen coordinates to world coordinates
        logger.debug(f"Screen box: ({start_x}, {start_y}) to ({end_x}, {end_y})")
        
        start_n, start_e = self.renderer.converter.screen_to_world(start_x, start_y)
        end_n, end_e = self.renderer.converter.screen_to_world(end_x, end_y)
        
        logger.debug(f"World box: N=[{start_n:.3f}, {end_n:.3f}], E=[{start_e:.3f}, {end_e:.3f}]")
        logger.debug(f"Current viewport: {self.model.viewport}")

        # Create new viewport from box
        min_northing = min(start_n, end_n)
        max_northing = max(start_n, end_n)
        min_easting = min(start_e, end_e)
        max_easting = max(start_e, end_e)
        
        # Ensure minimum box size to avoid zero-width/height viewports
        width = max_easting - min_easting
        height = max_northing - min_northing
        
        if width < 1e-6:  # Very small width
            center_e = (min_easting + max_easting) / 2
            min_easting = center_e - 0.5
            max_easting = center_e + 0.5
            width = 1.0
            
        if height < 1e-6:  # Very small height
            center_n = (min_northing + max_northing) / 2
            min_northing = center_n - 0.5
            max_northing = center_n + 0.5
            height = 1.0
        
        # Maintain aspect ratio to prevent skewing
        canvas_width = self.renderer.converter.canvas_width
        canvas_height = self.renderer.converter.canvas_height
        
        if canvas_width > 0 and canvas_height > 0:
            canvas_aspect = canvas_width / canvas_height
            data_aspect = width / height
            
            logger.debug(f"Canvas aspect: {canvas_aspect:.3f}, Data aspect: {data_aspect:.3f}")
            
            if data_aspect > canvas_aspect:
                # Data is wider - expand height to match canvas aspect
                new_height = width / canvas_aspect
                height_diff = new_height - height
                min_northing -= height_diff / 2
                max_northing += height_diff / 2
                logger.debug(f"Expanded height by {height_diff:.3f}")
            else:
                # Data is taller - expand width to match canvas aspect
                new_width = height * canvas_aspect
                width_diff = new_width - width
                min_easting -= width_diff / 2
                max_easting += width_diff / 2
                logger.debug(f"Expanded width by {width_diff:.3f}")
        
        logger.debug(f"Final zoom box: N=[{min_northing:.3f}, {max_northing:.3f}], E=[{min_easting:.3f}, {max_easting:.3f}]")

        new_viewport = TwoDimensionalEnvelope(
            min_northing,
            max_northing,
            min_easting,
            max_easting
        )

        self.model.viewport = new_viewport
        self.renderer.update_viewport(new_viewport)
        self.refresh()

    def draw_zoom_box(
        self,
        start_x: int,
        start_y: int,
        end_x: int,
        end_y: int
    ) -> None:
        """
        Draw a zoom box on the canvas.

        Args:
            start_x: Start screen X coordinate
            start_y: Start screen Y coordinate
            end_x: End screen X coordinate
            end_y: End screen Y coordinate
        """
        # Clear previous zoom box
        if hasattr(self, 'canvas'):
            self.canvas.delete("zoom_box")

            # Draw new zoom box
            self.canvas.create_rectangle(
                start_x, start_y, end_x, end_y,
                outline="red",
                width=2,
                dash=(5, 5),
                tags="zoom_box"
            )

    def fit_to_contents(self) -> None:
        """Fit the viewport to show all geometries."""
        import logging
        logger = logging.getLogger(__name__)
        
        # Calculate bounding box of all geometries
        min_northing = float('inf')
        max_northing = float('-inf')
        min_easting = float('inf')
        max_easting = float('-inf')

        has_geometries = False
        geometry_count = 0

        logger.info(f"Starting fit_to_contents with {len(self.document.collections)} collections")
        
        for collection in self.document.collections:
            logger.info(f"Processing collection '{collection.name}' with {len(collection.geometries)} geometries")
            for geometry in collection.geometries:
                has_geometries = True
                geometry_count += 1
                logger.debug(f"Processing geometry {geometry_count}: {type(geometry).__name__}")
                
                # Get geometry bounds with error handling
                try:
                    if hasattr(geometry, 'northing') and hasattr(geometry, 'easting'):
                        # Point
                        min_northing = min(min_northing, geometry.northing)
                        max_northing = max(max_northing, geometry.northing)
                        min_easting = min(min_easting, geometry.easting)
                        max_easting = max(max_easting, geometry.easting)
                        logger.debug(f"Point: N={geometry.northing}, E={geometry.easting}")
                    elif hasattr(geometry, 'points'):
                        # SimplePolyline or SimplePolygon
                        for point in geometry.points:
                            min_northing = min(min_northing, point.northing)
                            max_northing = max(max_northing, point.northing)
                            min_easting = min(min_easting, point.easting)
                            max_easting = max(max_easting, point.easting)
                        logger.debug(f"Polyline/Polygon with {len(geometry.points)} points")
                    elif hasattr(geometry, 'start_point') and hasattr(geometry, 'end_point'):
                        # LineSegment
                        for point in [geometry.start_point, geometry.end_point]:
                            min_northing = min(min_northing, point.northing)
                            max_northing = max(max_northing, point.northing)
                            min_easting = min(min_easting, point.easting)
                            max_easting = max(max_easting, point.easting)
                        logger.debug(f"LineSegment: start=({geometry.start_point.northing}, {geometry.start_point.easting}), end=({geometry.end_point.northing}, {geometry.end_point.easting})")
                    elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
                        # CircularArc
                        for point in [geometry.radius_point, geometry.start_point, geometry.end_point]:
                            min_northing = min(min_northing, point.northing)
                            max_northing = max(max_northing, point.northing)
                            min_easting = min(min_easting, point.easting)
                            max_easting = max(max_easting, point.easting)
                        logger.debug(f"CircularArc with center=({geometry.radius_point.northing}, {geometry.radius_point.easting})")
                    else:
                        logger.warning(f"Unknown geometry type: {type(geometry).__name__}")
                except Exception as e:
                    logger.error(f"Error processing geometry {type(geometry).__name__}: {e}")
                    continue

        logger.info(f"Fit to contents: Found {geometry_count} geometries")
        logger.info(f"Bounds: N=[{min_northing}, {max_northing}], E=[{min_easting}, {max_easting}]")

        # Check if we have valid bounds (not inf)
        if not has_geometries or not (math.isfinite(min_northing) and math.isfinite(max_northing) and 
                                       math.isfinite(min_easting) and math.isfinite(max_easting)):
            # Default viewport
            logger.info("No geometries found, using default viewport")
            new_viewport = TwoDimensionalEnvelope(0, 100, 0, 100)
        else:
            # Calculate data bounds
            width = max_easting - min_easting
            height = max_northing - min_northing
            
            # Handle zero width/height (single point or line)
            if width == 0:
                width = 20  # Default width for single points
            if height == 0:
                height = 20  # Default height for single points
            
            # Get canvas dimensions for aspect ratio calculation
            canvas_width = self.renderer.converter.canvas_width
            canvas_height = self.renderer.converter.canvas_height
            
            # Ensure canvas dimensions are valid
            if canvas_width <= 0 or canvas_height <= 0:
                logger.warning(f"Invalid canvas dimensions: {canvas_width}x{canvas_height}, using defaults")
                canvas_width = 800
                canvas_height = 600
            
            canvas_aspect = canvas_width / canvas_height if canvas_height > 0 else 1.0
            data_aspect = width / height if height > 0 else 1.0
            
            logger.info(f"Canvas: {canvas_width}x{canvas_height}, aspect={canvas_aspect:.3f}")
            logger.info(f"Data: {width:.3f}x{height:.3f}, aspect={data_aspect:.3f}")
            
            # Adjust viewport to match canvas aspect ratio
            if data_aspect > canvas_aspect:
                # Data is wider than canvas - expand height
                new_height = width / canvas_aspect
                height_diff = new_height - height
                height = new_height
                min_northing -= height_diff / 2
                max_northing += height_diff / 2
            else:
                # Data is taller than canvas - expand width  
                new_width = height * canvas_aspect
                width_diff = new_width - width
                width = new_width
                min_easting -= width_diff / 2
                max_easting += width_diff / 2
            
            # Add 10% margin after aspect ratio correction
            margin_x = width * 0.1
            margin_y = height * 0.1
            
            viewport_min_northing = min_northing - margin_y
            viewport_max_northing = max_northing + margin_y
            viewport_min_easting = min_easting - margin_x
            viewport_max_easting = max_easting + margin_x

            logger.info(f"Final Viewport: N=[{viewport_min_northing:.3f}, {viewport_max_northing:.3f}], E=[{viewport_min_easting:.3f}, {viewport_max_easting:.3f}]")

            new_viewport = TwoDimensionalEnvelope(
                viewport_min_northing,
                viewport_max_northing,
                viewport_min_easting,
                viewport_max_easting
            )

        # Apply the new viewport with comprehensive logging
        logger.info(f"Setting viewport: {new_viewport}")
        logger.info(f"Old viewport was: {self.model.viewport}")
        
        # Store old viewport for comparison
        old_viewport = self.model.viewport
        
        self.model.viewport = new_viewport
        self.model.zoom_level = 1.0
        
        # Verify viewport was set
        logger.info(f"Viewport after setting: {self.model.viewport}")
        
        # Update renderer and refresh
        logger.info("Updating renderer viewport...")
        self.renderer.update_viewport(new_viewport)
        
        # Verify converter viewport
        logger.info(f"Converter viewport: {self.renderer.converter.viewport}")
        
        logger.info("Refreshing display...")
        self.refresh()
        
        # Final verification
        if self.model.viewport != old_viewport:
            logger.info(f"SUCCESS: Viewport changed from {old_viewport} to {self.model.viewport}")
        else:
            logger.warning(f"WARNING: Viewport did not change! Still: {self.model.viewport}")
        
        logger.info("Fit to contents completed")

    def refresh(self) -> None:
        """Refresh the canvas display."""
        # Render all layers
        geometry_collections = {
            collection.name: collection
            for collection in self.document.collections
        }

        self.renderer.render_layers(self.model.layers, geometry_collections)

        logger.debug("Canvas refreshed")

    # Document observation

    def update(self, observable: PlanaFiguraDocument) -> None:
        """
        Observer pattern update method - called when document changes.

        Args:
            observable: The document that changed
        """
        self.on_document_changed(observable)

    def on_document_changed(self, document: PlanaFiguraDocument) -> None:
        """
        Called when the document changes.

        Args:
            document: The changed document
        """
        self._sync_layers_from_document()
        self.refresh()

    def _sync_layers_from_document(self) -> None:
        """Synchronize layers with document collections."""
        # Create layers for each collection
        layers = []
        for i, collection in enumerate(self.document.collections):
            name = collection.name
            # Check if layer already exists
            existing_layer = next(
                (layer for layer in self.model.layers if layer.name == name),
                None
            )

            if existing_layer:
                layers.append(existing_layer)
            else:
                # Create new layer with default style
                layer = Layer(
                    name=name,
                    visible=True,
                    z_order=i,
                    style=LayerStyle()
                )
                layers.append(layer)

        self.model.layers = layers
        logger.debug(f"Synced {len(layers)} layers from document")

    def set_layer_visibility(self, layer_name: str, visible: bool) -> None:
        """
        Set the visibility of a layer.

        Args:
            layer_name: Name of the layer
            visible: Whether the layer should be visible
        """
        for layer in self.model.layers:
            if layer.name == layer_name:
                layer.visible = visible
                self.refresh()
                logger.debug(f"Set layer '{layer_name}' visibility to {visible}")
                break

    def update_layer_style(
        self,
        layer_name: str,
        fill_color: Optional[str] = None,
        stroke_color: Optional[str] = None,
        stroke_width: Optional[int] = None,
        line_join: Optional[str] = None,
        line_cap: Optional[str] = None,
        point_color: Optional[str] = None,
        point_size: Optional[int] = None
    ) -> None:
        """
        Update the style of a layer.

        Args:
            layer_name: Name of the layer
            fill_color: Fill color (optional)
            stroke_color: Stroke color (optional)
            stroke_width: Stroke width (optional)
            line_join: Line join style (optional)
            line_cap: Line cap style (optional)
            point_color: Point color (optional)
            point_size: Point radius (optional)
        """
        for layer in self.model.layers:
            if layer.name == layer_name:
                if fill_color is not None:
                    layer.style.fill_color = fill_color
                if stroke_color is not None:
                    layer.style.stroke_color = stroke_color
                if stroke_width is not None:
                    layer.style.stroke_width = stroke_width
                if line_join is not None:
                    layer.style.line_join = line_join
                    logger.info(f"Set layer '{layer_name}' line_join to '{line_join}'")
                if line_cap is not None:
                    layer.style.line_cap = line_cap
                    logger.info(f"Set layer '{layer_name}' line_cap to '{line_cap}'")
                if point_color is not None:
                    layer.style.point_color = point_color
                if point_size is not None:
                    layer.style.point_size = point_size
                self.refresh()
                logger.debug(f"Updated style for layer '{layer_name}'")
                break

    # Hit detection

    def get_geometry_at_screen_point(self, screen_x: int, screen_y: int, tolerance: int = 30) -> Optional[Geometry]:
        """
        Get the geometry at a screen point using distance-based hit detection.

        Args:
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate
            tolerance: Hit detection tolerance in pixels (default 30)

        Returns:
            The geometry at the point, or None
        """
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"HIT_DETECT: Looking for geometry at ({screen_x}, {screen_y}) with tolerance={tolerance}")
        
        # Use the same distance-based detection as hover
        # Check all geometries and find the closest one within tolerance
        closest_geometry = None
        closest_distance = float('inf')
        
        for layer in self.model.layers:
            if not layer.visible:
                continue
                
            # Find collection for this layer
            collection = None
            for coll in self.document.collections:
                if coll.name == layer.name:
                    collection = coll
                    break
            
            if collection is None:
                continue
            
            for geometry in collection.geometries:
                if self._is_geometry_near_point(geometry, screen_x, screen_y, tolerance):
                    # Calculate actual distance to prioritize closest geometry
                    # For now, just return the first match
                    logger.info(f"HIT_DETECT: Found {type(geometry).__name__} within tolerance")
                    return geometry
        
        logger.info(f"HIT_DETECT: No geometry found within tolerance")
        return None

    def highlight_geometry(self, geometry: Geometry) -> None:
        """
        Highlight a geometry.

        Args:
            geometry: The geometry to highlight
        """
        self.renderer.highlight_geometry(geometry, self.model.selection_color)

    def unhighlight_geometry(self, geometry: Geometry) -> None:
        """
        Unhighlight a geometry.

        Args:
            geometry: The geometry to unhighlight
        """
        # Find the layer for this geometry
        layer_style = None
        for layer in self.model.layers:
            layer_style = layer.style
            break  # Use first layer's style for now

        self.renderer.unhighlight_geometry(geometry, layer_style)

    def on_canvas_resize(self, width: int, height: int) -> None:
        """
        Handle canvas resize.

        Args:
            width: New canvas width
            height: New canvas height
        """
        self.renderer.update_canvas_size(width, height)
        self.refresh()

    # Selection methods

    def select_at_point(
        self,
        screen_x: int,
        screen_y: int,
        add: bool = False,
        toggle: bool = False
    ) -> None:
        """
        Select geometry at a screen point.

        Args:
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate
            add: If True, add to selection; if False, replace selection
            toggle: If True, toggle selection state
        """
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"SELECT: Attempting selection at ({screen_x}, {screen_y}), add={add}, toggle={toggle}")
        
        geometry = self.get_geometry_at_screen_point(screen_x, screen_y)
        logger.info(f"SELECT: Found geometry: {type(geometry).__name__ if geometry else 'None'}")

        if geometry:
            # Actually update the SelectionManager
            if self._selection_manager is not None:
                logger.info(f"SELECT: Adding geometry to SelectionManager")
                
                if not add and not toggle:
                    # Replace selection - clear first
                    logger.info(f"SELECT: Clearing existing selection (replace mode)")
                    self._selection_manager.clear(source="map_view")
                
                if toggle:
                    # Toggle selection state
                    if self._selection_manager.is_selected(geometry):
                        logger.info(f"SELECT: Removing geometry from selection (toggle mode)")
                        self._selection_manager.remove_from_selection(geometry, source="map_view")
                    else:
                        logger.info(f"SELECT: Adding geometry to selection (toggle mode)")
                        self._selection_manager.add_to_selection(geometry, source="map_view")
                else:
                    # Add to selection
                    logger.info(f"SELECT: Adding geometry to selection")
                    self._selection_manager.add_to_selection(geometry, source="map_view")
                
                logger.info(f"SELECT: Selection count after update: {self._selection_manager.get_count()}")
            else:
                logger.warning(f"SELECT: No SelectionManager available - cannot update selection")
            
            # Publish selection event for other components
            if self.event_bus:
                logger.info(f"SELECT: Publishing GeometrySelectedEvent via event bus")
                from plana_figura_workbench.events import GeometrySelectedEvent
                event = GeometrySelectedEvent(
                    geometry=geometry,
                    source="map_view"
                )
                self.event_bus.publish(event)
                logger.info(f"SELECT: Event published successfully")
            
            # Refresh to show the selection visually
            if self.renderer is not None:
                logger.info(f"SELECT: Refreshing MapView to show selection")
                if self._selection_manager:
                    logger.info(f"SELECT: Before refresh - SelectionManager count: {self._selection_manager.get_count()}")
                    logger.info(f"SELECT: Before refresh - is_geometry_selected: {self.is_geometry_selected(geometry)}")
                self.refresh()
                logger.info(f"SELECT: After refresh - completed")
            else:
                logger.warning(f"SELECT: No renderer available - cannot refresh")
            
            logger.info(f"SELECT: Successfully selected {type(geometry).__name__} at ({screen_x}, {screen_y})")
        else:
            logger.info(f"SELECT: No geometry found at ({screen_x}, {screen_y}) - selection failed")

    def select_in_box(
        self,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
        mode: str = "window",
        add: bool = False,
        toggle: bool = False
    ) -> None:
        """
        Select geometries within a box.

        Args:
            x1: Box start X
            y1: Box start Y
            x2: Box end X
            y2: Box end Y
            mode: Selection mode:
                - "window": only geometries fully inside the box
                - "crossing": geometries that intersect or are inside the box
            add: If True, add to selection
            toggle: If True, toggle selection
        """
        # Normalize box coordinates
        min_x = min(x1, x2)
        max_x = max(x1, x2)
        min_y = min(y1, y2)
        max_y = max(y1, y2)

        # Backwards compatibility: treat unknown modes as original behavior
        if mode not in ("window", "crossing"):
            mode = "window"

        # Find geometries in box
        selected_geometries = []

        for collection in self.document.collections:
            for geometry in collection.geometries:
                # Check if geometry is in box
                if self._is_geometry_in_screen_box(geometry, min_x, min_y, max_x, max_y, mode):
                    selected_geometries.append(geometry)

        # Publish selection events
        if self.event_bus:
            from plana_figura_workbench.events import GeometrySelectedEvent
            for geometry in selected_geometries:
                event = GeometrySelectedEvent(
                    geometry=geometry,
                    add_to_selection=add,
                    toggle_selection=toggle
                )
                self.event_bus.publish(event)
                self.highlight_geometry(geometry)

        logger.info(f"Selected {len(selected_geometries)} geometries in box")

    def _is_geometry_in_screen_box(
        self,
        geometry: Geometry,
        min_x: int,
        min_y: int,
        max_x: int,
        max_y: int,
        mode: str = "window"
    ) -> bool:
        """
        Check if a geometry is within or crossing a screen box.

        Args:
            geometry: The geometry to check
            min_x: Box minimum X
            min_y: Box minimum Y
            max_x: Box maximum X
            max_y: Box maximum Y
            mode: "window" or "crossing" (see select_in_box)

        Returns:
            True if geometry matches the selection predicate for the mode
        """
        # Helper to check if a point is inside the box
        def _point_inside(x: float, y: float) -> bool:
            return min_x <= x <= max_x and min_y <= y <= max_y

        # Helper to check if a segment intersects the box
        def _segment_crosses_box(x1: float, y1: float, x2: float, y2: float) -> bool:
            # Trivial accept if either endpoint is inside
            if _point_inside(x1, y1) or _point_inside(x2, y2):
                return True

            # Trivial reject if segment bbox is completely outside
            seg_min_x = min(x1, x2)
            seg_max_x = max(x1, x2)
            seg_min_y = min(y1, y2)
            seg_max_y = max(y1, y2)
            if seg_max_x < min_x or seg_min_x > max_x or seg_max_y < min_y or seg_min_y > max_y:
                return False

            # Check intersection with each box edge (coarse but sufficient here)
            # We reuse point-to-line distance as an approximation near edges.
            if self._point_to_line_distance(min_x, min_y, x1, y1, x2, y2) == 0:
                return True
            if self._point_to_line_distance(max_x, min_y, x1, y1, x2, y2) == 0:
                return True
            if self._point_to_line_distance(max_x, max_y, x1, y1, x2, y2) == 0:
                return True
            if self._point_to_line_distance(min_x, max_y, x1, y1, x2, y2) == 0:
                return True

            return False

        # Normalize mode
        if mode not in ("window", "crossing"):
            mode = "window"

        if hasattr(geometry, 'northing') and hasattr(geometry, 'easting'):
            # Point
            screen_x, screen_y = self.renderer.converter.world_to_screen(
                geometry.northing,
                geometry.easting
            )
            # For points, window and crossing behave the same
            return _point_inside(screen_x, screen_y)

        elif hasattr(geometry, 'points'):
            # SimplePolyline or SimplePolygon
            points = geometry.points
            if not points:
                return False

            # Convert all points to screen coordinates
            screen_points = [
                self.renderer.converter.world_to_screen(p.northing, p.easting)
                for p in points
            ]

            if mode == "window":
                # All vertices must be inside the box
                return all(_point_inside(x, y) for x, y in screen_points)

            # crossing mode: any vertex inside OR any segment crossing box
            if any(_point_inside(x, y) for x, y in screen_points):
                return True

            # Check segments
            for i in range(len(screen_points) - 1):
                x1_s, y1_s = screen_points[i]
                x2_s, y2_s = screen_points[i + 1]
                if _segment_crosses_box(x1_s, y1_s, x2_s, y2_s):
                    return True

            # For polygons, also test closing segment
            from plana_figura.composite import SimplePolygon
            if isinstance(geometry, SimplePolygon) and len(screen_points) > 2:
                x1_s, y1_s = screen_points[-1]
                x2_s, y2_s = screen_points[0]
                if _segment_crosses_box(x1_s, y1_s, x2_s, y2_s):
                    return True

            return False

        elif hasattr(geometry, 'start_point') and hasattr(geometry, 'end_point'):
            # LineSegment
            start = geometry.start_point
            end = geometry.end_point
            start_x, start_y = self.renderer.converter.world_to_screen(
                start.northing,
                start.easting
            )
            end_x, end_y = self.renderer.converter.world_to_screen(
                end.northing,
                end.easting
            )

            if mode == "window":
                # Both endpoints must be inside the box
                return _point_inside(start_x, start_y) and _point_inside(end_x, end_y)

            # crossing mode: endpoint inside or segment crosses box
            return _segment_crosses_box(start_x, start_y, end_x, end_y)

        return False

    def select_all(self) -> None:
        """Select all geometries."""
        if self.event_bus:
            from plana_figura_workbench.events import GeometrySelectedEvent
            for collection in self.document.collections:
                for geometry in collection.geometries:
                    event = GeometrySelectedEvent(
                        geometry=geometry,
                        add_to_selection=True,
                        toggle_selection=False
                    )
                    self.event_bus.publish(event)
                    self.highlight_geometry(geometry)

        logger.info("Selected all geometries")

    # Settings persistence

    def save_settings(self, canvas_bg_color: str) -> None:
        """
        Save current map view settings.

        Args:
            canvas_bg_color: Current canvas background color
        """
        # Collect layer styles
        layer_styles = {}
        for layer in self.model.layers:
            layer_styles[layer.name] = layer.style

        # Save settings
        self.settings.save_settings(
            background_color=canvas_bg_color,
            selection_color=self.model.selection_color,
            grid_visible=False,  # TODO: Track grid state
            grid_interval=10.0,  # TODO: Track grid interval
            grid_color="#CCCCCC",  # TODO: Track grid color
            layer_styles=layer_styles
        )

    def load_settings(self, canvas) -> None:
        """
        Load saved map view settings.

        Args:
            canvas: Canvas widget to apply background color
        """
        settings = self.settings.load_settings()
        if settings is None:
            logger.debug("No saved settings found")
            return

        # Apply background color
        bg_color = settings.get('background_color', 'white')
        if canvas:
            canvas.config(bg=bg_color)

        # Apply selection color
        selection_color = settings.get('selection_color', 'red')
        self.model.selection_color = selection_color

        # Apply layer styles
        layer_styles = settings.get('layer_styles', {})
        for layer in self.model.layers:
            if layer.name in layer_styles:
                style_dict = layer_styles[layer.name]
                layer.style = LayerStyle(
                    stroke_color=style_dict.get('stroke_color', 'black'),
                    stroke_width=style_dict.get('stroke_width', 1),
                    fill_color=style_dict.get('fill_color', ''),
                    line_join=style_dict.get('line_join', 'miter'),
                    line_cap=style_dict.get('line_cap', 'butt'),
                    point_size=style_dict.get('point_size', 5),
                    point_color=style_dict.get('point_color', 'yellow'),
                    point_shape=style_dict.get('point_shape', 'circle')
                )

        logger.info("Loaded map view settings")
        self.refresh()

    # Hover detection

    def handle_hover(self, screen_x: int, screen_y: int, tolerance: int = 30, node_tolerance: int = 30) -> None:
        """
        Handle hover detection - highlight geometries and nodes near the cursor.

        Args:
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate
            tolerance: Pixel tolerance for geometry hit detection (default 30px)
            node_tolerance: Pixel tolerance for node hit detection (default 30px)
        """
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"HOVER: Checking hover at ({screen_x}, {screen_y}) with tolerance={tolerance}")
        
        # Debug: Count total geometries available
        total_geometries = 0
        geometry_types = {}
        for coll in self.document.collections:
            for geom in coll.geometries:
                total_geometries += 1
                geom_type = type(geom).__name__
                geometry_types[geom_type] = geometry_types.get(geom_type, 0) + 1
        
        logger.info(f"HOVER: Total geometries available: {total_geometries}")
        if geometry_types:
            logger.info(f"HOVER: Geometry types: {geometry_types}")
        
        # Clear previous hover highlights
        self.renderer.clear_hover_highlights()

        # Find geometries within tolerance
        nearby_geometries = []
        hovered_geoms = []
        for layer in self.model.layers:
            if not layer.visible:
                continue

            collection_name = layer.name
            collection = None
            for coll in self.document.collections:
                if coll.name == collection_name:
                    collection = coll
                    break

            if collection is None:
                continue

            for geometry in collection.geometries:
                geom_type = type(geometry).__name__
                is_near = self._is_geometry_near_point(geometry, screen_x, screen_y, tolerance)
                logger.info(f"HOVER: Testing {geom_type} - near_point={is_near}")
                
                if is_near:
                    logger.info(f"HOVER: Found hoverable {geom_type}")
                    nearby_geometries.append((geometry, layer.style))
                    hovered_geoms.append(geometry)

        # Store hovered geometries in model
        self.model.hovered_geometries = hovered_geoms

        # Highlight ALL nodes in hovered geometries
        self.model.hovered_node = None
        import logging
        logger = logging.getLogger(__name__)
        
        for geometry, style in nearby_geometries:
            # Highlight all nodes in this geometry with hover color
            self.renderer.highlight_all_nodes(geometry, self.model.hover_color, style)
            
            # Also check if we're specifically near a node for properties display
            node_info = self._find_nearest_node(geometry, screen_x, screen_y, node_tolerance)
            if node_info and self.model.hovered_node is None:
                logger.debug(f"Found hovered node: geometry={type(geometry).__name__}, node_index={node_info[1]}")
                self.model.hovered_node = node_info

        # Highlight nearby geometries with hover color and 2x stroke width
        for geometry, style in nearby_geometries:
            self.renderer.highlight_hover(geometry, self.model.hover_color, style)
        
        # Summary
        logger.info(f"HOVER: Final result - {len(nearby_geometries)} geometries hovered")

    def _is_geometry_near_point(
        self, geometry: Geometry, screen_x: int, screen_y: int, tolerance: int
    ) -> bool:
        """
        Check if a geometry is near a screen point.

        Args:
            geometry: Geometry to check
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate
            tolerance: Pixel tolerance

        Returns:
            True if geometry is within tolerance of the point
        """
        from plana_figura.geometry import Point
        from plana_figura.linear import LineSegment

        if isinstance(geometry, Point):
            # Check if point is within tolerance
            px, py = self.renderer.converter.world_to_screen(
                geometry.northing,
                geometry.easting
            )
            distance = ((px - screen_x) ** 2 + (py - screen_y) ** 2) ** 0.5
            return distance <= tolerance

        elif isinstance(geometry, LineSegment):
            # Check if line segment is within tolerance
            start_x, start_y = self.renderer.converter.world_to_screen(
                geometry.start_point.northing,
                geometry.start_point.easting
            )
            end_x, end_y = self.renderer.converter.world_to_screen(
                geometry.end_point.northing,
                geometry.end_point.easting
            )

            # Calculate distance from point to line segment
            distance = self._point_to_line_distance(
                screen_x, screen_y,
                start_x, start_y,
                end_x, end_y
            )
            
            import logging
            logger = logging.getLogger(__name__)
            logger.info(f"LINESEG_HOVER: Mouse at ({screen_x}, {screen_y}), Line from ({start_x:.1f}, {start_y:.1f}) to ({end_x:.1f}, {end_y:.1f}), distance={distance:.1f}, tolerance={tolerance}")
            
            return distance <= tolerance

        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            # Check if point is near the circular arc
            import logging
            logger = logging.getLogger(__name__)
            logger.debug(f"Checking CircularArc hover at screen ({screen_x}, {screen_y}) with tolerance {tolerance}")
            
            center = geometry.radius_point
            start_point = geometry.start_point
            end_point = geometry.end_point
            
            # Convert to screen coordinates
            center_x, center_y = self.renderer.converter.world_to_screen(
                center.northing, center.easting
            )
            start_x, start_y = self.renderer.converter.world_to_screen(
                start_point.northing, start_point.easting
            )
            end_x, end_y = self.renderer.converter.world_to_screen(
                end_point.northing, end_point.easting
            )
            
            logger.debug(f"  Arc center: world=({center.northing}, {center.easting}), screen=({center_x}, {center_y})")
            logger.debug(f"  Arc start: world=({start_point.northing}, {start_point.easting}), screen=({start_x}, {start_y})")
            logger.debug(f"  Arc end: world=({end_point.northing}, {end_point.easting}), screen=({end_x}, {end_y})")
            
            # Calculate radius in screen coordinates
            radius_screen = ((start_x - center_x) ** 2 + (start_y - center_y) ** 2) ** 0.5
            logger.debug(f"  Screen radius: {radius_screen:.1f}")
            
            # Check if point is near the arc path
            # First check if point is approximately on the circle
            point_distance_from_center = ((screen_x - center_x) ** 2 + (screen_y - center_y) ** 2) ** 0.5
            distance_from_arc = abs(point_distance_from_center - radius_screen)
            logger.debug(f"  Point distance from center: {point_distance_from_center:.1f}")
            logger.debug(f"  Distance from arc path: {distance_from_arc:.1f}")
            
            if distance_from_arc > tolerance:
                logger.debug(f"  -> Point too far from arc path ({distance_from_arc:.1f} > {tolerance})")
                return False
                
            # Check if point is within the arc's angular range
            import math
            point_angle = math.degrees(math.atan2(screen_y - center_y, screen_x - center_x))
            start_angle = math.degrees(math.atan2(start_y - center_y, start_x - center_x))
            end_angle = math.degrees(math.atan2(end_y - center_y, end_x - center_x))
            
            # Normalize angles to 0-360
            if point_angle < 0:
                point_angle += 360
            if start_angle < 0:
                start_angle += 360
            if end_angle < 0:
                end_angle += 360
                
            logger.debug(f"  Angles: point={point_angle:.1f}°, start={start_angle:.1f}°, end={end_angle:.1f}°")
            
            # Check if point angle is between start and end angles
            in_range = False
            if start_angle <= end_angle:
                in_range = start_angle <= point_angle <= end_angle
                logger.debug(f"  -> Normal arc: {start_angle:.1f}° <= {point_angle:.1f}° <= {end_angle:.1f}° = {in_range}")
            else:
                # Arc crosses 0 degrees
                in_range = point_angle >= start_angle or point_angle <= end_angle
                logger.debug(f"  -> Arc crosses 0°: {point_angle:.1f}° >= {start_angle:.1f}° or {point_angle:.1f}° <= {end_angle:.1f}° = {in_range}")
            
            logger.debug(f"  -> CircularArc hover result: {in_range}")
            return in_range

        elif hasattr(geometry, 'points'):
            # SimplePolyline or SimplePolygon - check distance to each line segment
            from plana_figura.composite import SimplePolyline, SimplePolygon
            
            if isinstance(geometry, (SimplePolyline, SimplePolygon)):
                import logging
                logger = logging.getLogger(__name__)
                points = geometry.points
                if len(points) < 2:
                    logger.debug(f"SimplePolyline has insufficient points: {len(points)}")
                    return False
                
                logger.info(f"POLYLINE_HOVER: Checking SimplePolyline with {len(points)} points, tolerance={tolerance}")
                
                # Use larger tolerance for polylines (tessellated arcs need more tolerance)
                polyline_tolerance = max(tolerance, 15)  # Minimum 15 pixels for polylines
                logger.info(f"POLYLINE_HOVER: Using polyline tolerance: {polyline_tolerance}")
                
                min_distance = float('inf')
                
                # Check distance to each line segment in the polyline
                for i in range(len(points) - 1):
                    start_point = points[i]
                    end_point = points[i + 1]
                    
                    start_x, start_y = self.renderer.converter.world_to_screen(
                        start_point.northing, start_point.easting
                    )
                    end_x, end_y = self.renderer.converter.world_to_screen(
                        end_point.northing, end_point.easting
                    )
                    
                    distance = self._point_to_line_distance(
                        screen_x, screen_y, start_x, start_y, end_x, end_y
                    )
                    
                    min_distance = min(min_distance, distance)
                    
                    if distance <= polyline_tolerance:
                        logger.info(f"POLYLINE_HOVER: SimplePolyline segment {i} hit: distance={distance:.1f} <= {polyline_tolerance}")
                        return True
                
                # For SimplePolygon, also check the closing segment
                if isinstance(geometry, SimplePolygon) and len(points) > 2:
                    start_point = points[-1]
                    end_point = points[0]
                    
                    start_x, start_y = self.renderer.converter.world_to_screen(
                        start_point.northing, start_point.easting
                    )
                    end_x, end_y = self.renderer.converter.world_to_screen(
                        end_point.northing, end_point.easting
                    )
                    
                    distance = self._point_to_line_distance(
                        screen_x, screen_y, start_x, start_y, end_x, end_y
                    )
                    
                    min_distance = min(min_distance, distance)
                    
                    if distance <= polyline_tolerance:
                        logger.info(f"POLYLINE_HOVER: SimplePolygon closing segment hit: distance={distance:.1f} <= {polyline_tolerance}")
                        return True
                
                logger.info(f"POLYLINE_HOVER: SimplePolyline miss: min_distance={min_distance:.1f} > {polyline_tolerance}")
                return False

        # For other geometry types, use bounding box check
        return False

    def _point_to_line_distance(
        self, px: float, py: float,
        x1: float, y1: float,
        x2: float, y2: float
    ) -> float:
        """
        Calculate distance from point to line segment.

        Args:
            px, py: Point coordinates
            x1, y1: Line start coordinates
            x2, y2: Line end coordinates

        Returns:
            Distance from point to line segment
        """
        # Vector from line start to point
        dx = x2 - x1
        dy = y2 - y1

        if dx == 0 and dy == 0:
            # Line segment is a point
            return ((px - x1) ** 2 + (py - y1) ** 2) ** 0.5

        # Parameter t of closest point on line
        t = max(0, min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)))

        # Closest point on line segment
        closest_x = x1 + t * dx
        closest_y = y1 + t * dy

        # Distance from point to closest point
        return ((px - closest_x) ** 2 + (py - closest_y) ** 2) ** 0.5

    def _find_nearest_node(
        self, geometry: Geometry, screen_x: int, screen_y: int, tolerance: int
    ) -> Optional[Tuple[Geometry, int]]:
        """
        Find the nearest node in a geometry within tolerance.

        Args:
            geometry: Geometry to check
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate
            tolerance: Pixel tolerance

        Returns:
            Tuple of (geometry, node_index) if found, None otherwise
        """
        from plana_figura.geometry import Point
        from plana_figura.linear import LineSegment
        from plana_figura.composite import SimplePolyline, SimplePolygon

        nodes = []
        if isinstance(geometry, Point):
            nodes = [geometry]
        elif isinstance(geometry, LineSegment):
            nodes = [geometry.start_point, geometry.end_point]
        elif isinstance(geometry, SimplePolyline):
            nodes = geometry.points
        elif isinstance(geometry, SimplePolygon):
            nodes = geometry.points
        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            # CircularArc has 3 nodes: center, start, end
            nodes = [geometry.radius_point, geometry.start_point, geometry.end_point]

        # Find closest node
        min_distance = float('inf')
        closest_index = None
        import logging
        logger = logging.getLogger(__name__)
        
        logger.debug(f"Checking {len(nodes)} nodes for {type(geometry).__name__} at screen ({screen_x}, {screen_y}) with tolerance {tolerance}")

        for i, node in enumerate(nodes):
            node_screen_x, node_screen_y = self.renderer.converter.world_to_screen(
                node.northing, node.easting
            )
            distance = ((screen_x - node_screen_x) ** 2 + (screen_y - node_screen_y) ** 2) ** 0.5
            
            logger.debug(f"  Node {i}: world=({node.northing:.3f}, {node.easting:.3f}), screen=({node_screen_x}, {node_screen_y}), distance={distance:.1f}")

            if distance < min_distance and distance <= tolerance:
                min_distance = distance
                closest_index = i
                logger.debug(f"    -> New closest node: {i} at distance {distance:.1f}")

        if closest_index is not None:
            logger.debug(f"Found closest node {closest_index} at distance {min_distance:.1f}")
            return (geometry, closest_index)
        
        logger.debug(f"No node found within tolerance {tolerance}")
        return None

    # Geometry and Node Properties

    def get_geometry_properties(self, geometry: Geometry) -> dict:
        """
        Get properties of a geometry for display.

        Args:
            geometry: Geometry to get properties for

        Returns:
            Dictionary of properties
        """
        from plana_figura.geometry import Point
        from plana_figura.linear import LineSegment
        from plana_figura.composite import SimplePolyline, SimplePolygon

        props = {
            'identifier': str(id(geometry)),
            'type': type(geometry).__name__,
            'node_count': 0
        }

        if isinstance(geometry, Point):
            props['node_count'] = 1
        elif isinstance(geometry, LineSegment):
            props['node_count'] = 2
            # length is a method in LineSegment
            props['length'] = geometry.length()
        elif isinstance(geometry, SimplePolyline):
            props['node_count'] = len(geometry.points)
            # length is a method in SimplePolyline
            length_val = geometry.length()
            props['length'] = length_val if not callable(length_val) else length_val()
        elif isinstance(geometry, SimplePolygon):
            props['node_count'] = len(geometry.points)
            # perimeter and area are methods in SimplePolygon
            props['perimeter'] = geometry.perimeter()
            props['area'] = geometry.area()
        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            props['node_count'] = 3  # center, start, end
            # length is a method in CircularArc
            props['length'] = geometry.length()

        return props

    def get_node_properties(self, geometry: Geometry, node_index: int) -> Optional[dict]:
        """
        Get properties of a specific node in a geometry.

        Args:
            geometry: Geometry containing the node
            node_index: Index of the node

        Returns:
            Dictionary of node properties or None
        """
        from plana_figura.geometry import Point
        from plana_figura.linear import LineSegment
        from plana_figura.composite import SimplePolyline, SimplePolygon

        node = None
        if isinstance(geometry, Point):
            if node_index == 0:
                node = geometry
        elif isinstance(geometry, LineSegment):
            if node_index == 0:
                node = geometry.start_point
            elif node_index == 1:
                node = geometry.end_point
        elif isinstance(geometry, SimplePolyline):
            if 0 <= node_index < len(geometry.points):
                node = geometry.points[node_index]
        elif isinstance(geometry, SimplePolygon):
            if 0 <= node_index < len(geometry.points):
                node = geometry.points[node_index]
        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            # CircularArc has 3 nodes: center, start, end
            if node_index == 0:
                node = geometry.radius_point  # center
            elif node_index == 1:
                node = geometry.start_point
            elif node_index == 2:
                node = geometry.end_point

        if node:
            return {
                'sequence': node_index + 1,  # 1-indexed for display
                'northing': node.northing,
                'easting': node.easting,
                'elevation': node.elevation
            }
        return None

    # Selection management

    def add_hovered_to_selection(self) -> None:
        """Add currently hovered geometries to selection."""
        logger.info(f"=== MapView: add_hovered_to_selection called ===")
        logger.info(f"Selection manager available: {self._selection_manager is not None}")
        logger.info(f"Hovered geometries count: {len(self.model.hovered_geometries)}")
        
        if self._selection_manager is None:
            logger.warning("No selection manager available")
            return

        for geometry in self.model.hovered_geometries:
            logger.info(f"Adding geometry to selection: {type(geometry).__name__} at {id(geometry)}")
            self._selection_manager.add_to_selection(geometry, source="map_view")

        logger.info(f"Selection count after add: {self._selection_manager.get_count()}")
        
        if self.renderer is not None:
            logger.info("Refreshing MapView after selection change")
            self.refresh()
        logger.info(f"=== MapView: Added {len(self.model.hovered_geometries)} geometries to selection ===")

    def remove_hovered_from_selection(self) -> None:
        """Remove currently hovered geometries from selection."""
        logger.info(f"=== MapView: remove_hovered_from_selection called ===")
        
        if self._selection_manager is None:
            logger.warning("No selection manager available")
            return

        for geometry in self.model.hovered_geometries:
            logger.info(f"Removing geometry from selection: {type(geometry).__name__} at {id(geometry)}")
            self._selection_manager.remove_from_selection(geometry, source="map_view")

        logger.info(f"Selection count after remove: {self._selection_manager.get_count()}")
        
        if self.renderer is not None:
            self.refresh()
        logger.info(f"=== MapView: Removed {len(self.model.hovered_geometries)} geometries from selection ===")

    def clear_selection(self) -> None:
        """Clear all selected geometries."""
        logger.info(f"=== MapView: clear_selection called ===")
        
        if self._selection_manager is None:
            logger.warning("No selection manager available")
            return

        logger.info(f"Selection count before clear: {self._selection_manager.get_count()}")
        self._selection_manager.clear(source="map_view")
        logger.info(f"Selection count after clear: {self._selection_manager.get_count()}")
        
        if self.renderer is not None:
            logger.info("Refreshing MapView after clear")
            self.refresh()
        logger.info("=== MapView: Cleared selection ===")

    def is_geometry_selected(self, geometry: Geometry) -> bool:
        """
        Check if a geometry is selected.

        Args:
            geometry: Geometry to check

        Returns:
            True if geometry is selected
        """
        if self._selection_manager is None:
            logger.debug(f"SELECTION_CHECK: No selection manager available")
            return False
        
        is_selected = self._selection_manager.is_selected(geometry)
        logger.debug(f"SELECTION_CHECK: Geometry {type(geometry).__name__} is_selected={is_selected}")
        return is_selected

    def _on_selection_changed(self, selection_manager: 'SelectionManager', source: str) -> None:
        """
        Called when selection changes in SelectionManager.

        Args:
            selection_manager: The SelectionManager that changed
            source: Source of the selection change
        """
        logger.info(f"=== MapView: _on_selection_changed called ===")
        logger.info(f"Source: {source}")
        logger.info(f"Selection count: {selection_manager.get_count()}")
        
        # Don't refresh if we caused the change
        if source == "map_view":
            logger.info("Ignoring own selection change (avoiding loop)")
            return

        # Refresh to show updated selection
        if self.renderer is not None:
            logger.info("Refreshing MapView due to external selection change")
            self.refresh()
        else:
            logger.warning("Cannot refresh - no renderer available")
        logger.info(f"=== MapView: Selection changed by {source}, refreshed ===")
