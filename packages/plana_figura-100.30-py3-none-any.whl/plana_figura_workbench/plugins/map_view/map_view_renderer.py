"""MapView renderer - handles canvas rendering logic.

This module provides the MapViewRenderer class which is responsible for
rendering geometries to the canvas. It is a "dumb" presentation component
that does not handle events or contain business logic.
"""

from typing import Dict, List, Optional, Any
import logging

from plana_figura import (
    Geometry,
    Point,
    LineSegment,
    SimplePolyline,
    SimplePolygon
)
from plana_figura.spatial import TwoDimensionalEnvelope
from plana_figura_workbench.plugins.map_view.map_view_model import (
    Layer,
    LayerStyle
)
from plana_figura_workbench.plugins.map_view.utilities.coordinate_converter import (
    CoordinateConverter
)

logger = logging.getLogger(__name__)


class MapViewRenderer:
    """
    Handles rendering of geometries to a canvas.

    This is a "dumb" presentation component that:
    - Renders geometries to canvas
    - Applies layer styles
    - Manages canvas items
    - Provides rendering utilities

    It does NOT:
    - Handle events
    - Contain business logic
    - Manage state

    Example:
        >>> renderer = MapViewRenderer(canvas, converter)
        >>> renderer.render_geometry(point, layer_style)
        >>> renderer.clear()
    """

    def __init__(
        self,
        canvas: Any,  # tk.Canvas or MockCanvas
        converter: CoordinateConverter,
        selection_checker: Optional[callable] = None,
        selection_color_getter: Optional[callable] = None
    ):
        """
        Initialize the renderer.

        Args:
            canvas: The canvas to render to (tk.Canvas or test double)
            converter: Coordinate converter for world-to-screen transformations
            selection_checker: Optional callback to check if geometry is selected
            selection_color_getter: Optional callback to get selection color
        """
        self.canvas = canvas
        self.converter = converter
        self.selection_checker = selection_checker
        self.selection_color_getter = selection_color_getter

        # Track canvas items for each geometry
        # id(geometry) -> list of canvas item IDs
        self._geometry_items: Dict[int, List[int]] = {}

        # Track geometry for each canvas item (for hit detection)
        # canvas_item_id -> geometry
        self._item_to_geometry: Dict[int, Geometry] = {}

        # Track preview items separately
        # list of canvas item IDs for preview geometries
        self._preview_items: List[int] = []

        logger.debug("MapViewRenderer initialized")

    def clear(self) -> None:
        """Clear all items from the canvas."""
        self.canvas.delete("all")
        self._geometry_items.clear()
        self._item_to_geometry.clear()
        self._preview_items.clear()
        logger.debug("Canvas cleared")

    def render_layers(
        self,
        layers: List[Layer],
        geometry_collections: Dict[str, Any]
    ) -> None:
        """
        Render all visible layers.

        Args:
            layers: List of layers to render
            geometry_collections: Dict mapping collection names to GeometryCollection objects
        """
        self.clear()

        # Sort layers by z_order
        sorted_layers = sorted(layers, key=lambda l: l.z_order)

        for layer in sorted_layers:
            if not layer.visible:
                logger.debug(f"Skipping invisible layer: {layer.name}")
                continue

            collection = geometry_collections.get(layer.name)
            if collection is None:
                logger.warning(f"No collection found for layer: {layer.name}")
                continue

            logger.info(
                f"Rendering layer '{layer.name}' with {len(collection.geometries)} "
                f"geometries, style cap={getattr(layer.style, 'line_cap', 'N/A')}"
            )

            # Render all geometries in the collection
            for geometry in collection.geometries:
                # Check if geometry is selected
                is_selected = (self.selection_checker is not None and
                               self.selection_checker(geometry))
                self.render_geometry(geometry, layer.style, is_selected=is_selected)

        logger.debug(f"Rendered {len(sorted_layers)} layers")

    def render_preview_geometry(
        self,
        geometry: Optional[Geometry]
    ) -> None:
        """
        Render a preview geometry with special styling.

        Args:
            geometry: The geometry to preview (None to clear preview)
        """
        # Clear existing preview
        for item_id in self._preview_items:
            self.canvas.delete(item_id)
        self._preview_items.clear()

        if geometry is None:
            logger.debug("Preview cleared")
            return

        # Create preview style (semi-transparent, distinct color)
        preview_style = LayerStyle(
            stroke_color="blue",
            stroke_width=2,
            fill_color="lightblue",
            line_join="miter",
            line_cap="butt",
            point_size=6,
            point_color="blue",
            point_shape="circle"
        )

        # Set items to be dashed for preview
        original_dash_state = None

        # Render the geometry
        item_ids: List[int] = []

        if isinstance(geometry, Point):
            item_ids = self._render_point(geometry, preview_style)
        elif isinstance(geometry, LineSegment):
            item_ids = self._render_line_segment(geometry, preview_style)
        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            item_ids = self._render_circular_arc(geometry, preview_style)
        elif isinstance(geometry, SimplePolyline):
            item_ids = self._render_polyline(geometry, preview_style)
        elif isinstance(geometry, SimplePolygon):
            item_ids = self._render_polygon(geometry, preview_style)
        else:
            logger.warning(f"Unknown geometry type for preview: {type(geometry)}")
            return

        # Apply preview styling (dashed lines, semi-transparent fill)
        for item_id in item_ids:
            self.canvas.itemconfig(item_id, dash=(5, 3))
            self.canvas.itemconfig(item_id, stipple="gray50")

        # Track preview items
        self._preview_items.extend(item_ids)

        logger.debug(f"Preview rendered for {type(geometry).__name__}")

    def render_geometry(
        self,
        geometry: Geometry,
        style: Optional[LayerStyle] = None,
        is_selected: bool = False
    ) -> List[int]:
        """
        Render a single geometry to the canvas.

        Args:
            geometry: The geometry to render
            style: Optional style to apply (uses defaults if None)
            is_selected: Whether the geometry is selected

        Returns:
            List of canvas item IDs created for this geometry
        """
        logger.info(
            f"render_geometry called: type={type(geometry).__name__}, "
            f"class_name={geometry.__class__.__name__}, "
            f"style cap={getattr(style, 'line_cap', 'N/A') if style else 'None'}, "
            f"selected={is_selected}"
        )
        if style is None:
            style = LayerStyle()

        # If selected, modify style to use selection color
        if is_selected:
            # Get selection color from callback or use default
            selection_color = "red"  # Default
            if self.selection_color_getter is not None:
                selection_color = self.selection_color_getter()

            # Create a copy of the style with selection color
            style = LayerStyle(
                stroke_color=selection_color,
                stroke_width=style.stroke_width + 1,  # Slightly thicker
                fill_color=style.fill_color,
                line_join=getattr(style, 'line_join', 'miter'),
                line_cap=getattr(style, 'line_cap', 'butt'),
                point_size=style.point_size + 2,  # Slightly larger
                point_color=selection_color,
                point_shape=style.point_shape
            )

        item_ids: List[int] = []

        if isinstance(geometry, Point):
            item_ids = self._render_point(geometry, style)
        elif isinstance(geometry, LineSegment):
            item_ids = self._render_line_segment(geometry, style)
        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            item_ids = self._render_circular_arc(geometry, style)
        elif isinstance(geometry, SimplePolyline):
            item_ids = self._render_polyline(geometry, style)
        elif isinstance(geometry, SimplePolygon):
            item_ids = self._render_polygon(geometry, style)
        else:
            logger.warning(f"Unknown geometry type: {type(geometry)}")

        # Track the items for this geometry
        geom_id = id(geometry)
        self._geometry_items[geom_id] = item_ids

        # Track geometry for each item (for hit detection)
        for item_id in item_ids:
            self._item_to_geometry[item_id] = geometry

        return item_ids

    def _render_point(self, point: Point, style: LayerStyle) -> List[int]:
        """Render a point geometry."""
        screen_x, screen_y = self.converter.world_to_screen(
            point.northing,
            point.easting
        )

        # Render point based on shape
        radius = style.point_size

        item_ids = []

        if style.point_shape == "circle":
            item_id = self.canvas.create_oval(
                screen_x - radius,
                screen_y - radius,
                screen_x + radius,
                screen_y + radius,
                fill=style.point_color,
                outline=style.stroke_color,
                width=1,
                tags=("geometry", "point")
            )
            item_ids.append(item_id)

        elif style.point_shape == "square":
            item_id = self.canvas.create_rectangle(
                screen_x - radius,
                screen_y - radius,
                screen_x + radius,
                screen_y + radius,
                fill=style.point_color,
                outline=style.stroke_color,
                width=1,
                tags=("geometry", "point")
            )
            item_ids.append(item_id)

        elif style.point_shape == "cross":
            # Vertical line
            item_id1 = self.canvas.create_line(
                screen_x,
                screen_y - radius,
                screen_x,
                screen_y + radius,
                fill=style.point_color,
                width=style.stroke_width,
                tags=("geometry", "point")
            )
            # Horizontal line
            item_id2 = self.canvas.create_line(
                screen_x - radius,
                screen_y,
                screen_x + radius,
                screen_y,
                fill=style.point_color,
                width=style.stroke_width,
                tags=("geometry", "point")
            )
            item_ids.extend([item_id1, item_id2])

        return item_ids

    def _render_line_segment(self, line_segment: LineSegment, style: LayerStyle) -> List[int]:
        """Render a line segment geometry."""
        start = line_segment.start_point
        end = line_segment.end_point

        start_x, start_y = self.converter.world_to_screen(
            start.northing,
            start.easting
        )
        end_x, end_y = self.converter.world_to_screen(
            end.northing,
            end.easting
        )

        cap = getattr(style, 'line_cap', 'butt')
        join = getattr(style, 'line_join', 'miter')
        logger.info(
            f"DUPLICATE _render_line_segment: cap={cap}, join={join}, "
            f"width={style.stroke_width}"
        )

        item_id = self.canvas.create_line(
            start_x, start_y, end_x, end_y,
            fill=style.stroke_color,
            width=style.stroke_width,
            capstyle=cap,
            joinstyle=join,
            tags=("geometry", "line")
        )

        return [item_id]

    def _render_circular_arc(self, arc, style: LayerStyle) -> List[int]:
        """Render a circular arc geometry."""
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"RENDER_ARC: Rendering CircularArc")
        
        # Get arc properties
        center = arc.radius_point
        start_point = arc.start_point
        end_point = arc.end_point
        
        # Convert center to screen coordinates
        center_x, center_y = self.converter.world_to_screen(
            center.northing, center.easting
        )
        
        # Convert start and end points to screen coordinates
        start_x, start_y = self.converter.world_to_screen(
            start_point.northing, start_point.easting
        )
        end_x, end_y = self.converter.world_to_screen(
            end_point.northing, end_point.easting
        )
        
        # Calculate radius in screen coordinates
        radius_screen = ((start_x - center_x) ** 2 + (start_y - center_y) ** 2) ** 0.5
        
        # Calculate angles in screen coordinates
        # tkinter: 0° = East (3 o'clock), but Y increases downward so angles go CLOCKWISE
        # We need to negate Y for atan2 to get correct counterclockwise angles
        import math
        start_angle = math.degrees(math.atan2(-(start_y - center_y), start_x - center_x))
        end_angle = math.degrees(math.atan2(-(end_y - center_y), end_x - center_x))
        
        # Calculate extent (sweep angle) from screen coordinates
        # Go counterclockwise from start to end
        extent = end_angle - start_angle
        if extent < 0:
            extent += 360
        
        logger.info(f"RENDER_ARC: World coords - center=({center.northing:.2f}, {center.easting:.2f})")
        logger.info(f"RENDER_ARC: World coords - start=({start_point.northing:.2f}, {start_point.easting:.2f})")
        logger.info(f"RENDER_ARC: World coords - end=({end_point.northing:.2f}, {end_point.easting:.2f})")
        logger.info(f"RENDER_ARC: Screen coords - center=({center_x:.1f}, {center_y:.1f})")
        logger.info(f"RENDER_ARC: Screen coords - start=({start_x:.1f}, {start_y:.1f})")
        logger.info(f"RENDER_ARC: Screen coords - end=({end_x:.1f}, {end_y:.1f})")
        logger.info(f"RENDER_ARC: Calculated - start_angle={start_angle:.1f}°, end_angle={end_angle:.1f}°, extent={extent:.1f}°")
        logger.info(f"RENDER_ARC: Arc.sweep_angle={math.degrees(arc.sweep_angle):.1f}° (not used for rendering)")
            
        # Create bounding box for the arc
        bbox_x1 = center_x - radius_screen
        bbox_y1 = center_y - radius_screen
        bbox_x2 = center_x + radius_screen
        bbox_y2 = center_y + radius_screen
        
        # Render the arc
        item_id = self.canvas.create_arc(
            bbox_x1, bbox_y1, bbox_x2, bbox_y2,
            start=start_angle,
            extent=extent,
            outline=style.stroke_color,
            width=style.stroke_width,
            style="arc",
            tags=("geometry", "arc")
        )
        
        return [item_id]

    def _render_polyline(self, polyline: SimplePolyline, style: LayerStyle) -> List[int]:
        """Render a polyline geometry."""
        coords = []
        for point in polyline.points:
            screen_x, screen_y = self.converter.world_to_screen(
                point.northing,
                point.easting
            )
            coords.extend([screen_x, screen_y])

        item_id = self.canvas.create_line(
            *coords,
            fill=style.stroke_color,
            width=style.stroke_width,
            capstyle=getattr(style, 'line_cap', 'butt'),
            joinstyle=getattr(style, 'line_join', 'miter'),
            tags=("geometry", "polyline")
        )

        return [item_id]

    def _render_polygon(self, polygon: SimplePolygon, style: LayerStyle) -> List[int]:
        """Render a polygon geometry."""
        coords = []
        for point in polygon.points:
            screen_x, screen_y = self.converter.world_to_screen(
                point.northing,
                point.easting
            )
            coords.extend([screen_x, screen_y])

        item_id = self.canvas.create_polygon(
            *coords,
            fill=style.fill_color if style.fill_color else "",
            outline=style.stroke_color,
            width=style.stroke_width,
            joinstyle=getattr(style, 'line_join', 'miter'),
            tags=("geometry", "polygon")
        )

        return [item_id]

    def highlight_geometry(self, geometry: Geometry, color: str = "red") -> None:
        """
        Highlight a geometry (for selection).

        Args:
            geometry: The geometry to highlight
            color: Highlight color (default: red)
        """
        import logging
        logger = logging.getLogger(__name__)
        
        geom_id = id(geometry)
        item_ids = self._geometry_items.get(geom_id, [])
        
        logger.info(f"HIGHLIGHT: Highlighting {type(geometry).__name__} with {len(item_ids)} canvas items")

        for item_id in item_ids:
            item_type = "unknown"  # Initialize to avoid UnboundLocalError
            try:
                # Get the item type to determine what options are available
                item_type = self.canvas.type(item_id)
                logger.debug(f"HIGHLIGHT: Item {item_id} type: {item_type}")
                
                # Apply highlighting based on item type
                if item_type in ['line', 'arc']:
                    # Lines and arcs support outline and width
                    self.canvas.itemconfigure(item_id, outline=color, width=3)
                elif item_type in ['oval', 'rectangle']:
                    # Shapes support outline
                    self.canvas.itemconfigure(item_id, outline=color)
                elif item_type == 'polygon':
                    # Polygons can have outline or fill
                    self.canvas.itemconfigure(item_id, outline=color, width=2)
                else:
                    # For other types, try outline only
                    self.canvas.itemconfigure(item_id, outline=color)
                    
                logger.debug(f"HIGHLIGHT: Successfully highlighted item {item_id}")
                
            except Exception as e:
                logger.warning(f"HIGHLIGHT: Failed to highlight item {item_id} ({item_type}): {e}")
                # Try alternative highlighting
                try:
                    self.canvas.itemconfigure(item_id, fill=color)
                    logger.debug(f"HIGHLIGHT: Used fill color for item {item_id}")
                except Exception as e2:
                    logger.error(f"HIGHLIGHT: Complete failure for item {item_id}: {e2}")

    def unhighlight_geometry(self, geometry: Geometry, style: Optional[LayerStyle] = None) -> None:
        """
        Remove highlight from a geometry.

        Args:
            geometry: The geometry to unhighlight
            style: Optional style to restore (uses defaults if None)
        """
        if style is None:
            style = LayerStyle()

        geom_id = id(geometry)
        item_ids = self._geometry_items.get(geom_id, [])

        for item_id in item_ids:
            self.canvas.itemconfigure(
                item_id,
                outline=style.stroke_color,
                width=style.stroke_width
            )

    def get_geometry_at_point(
        self,
        screen_x: int,
        screen_y: int,
        halo: int = 30
    ) -> Optional[Geometry]:
        """
        Find the geometry at a screen point (for hit detection).

        Args:
            screen_x: Screen X coordinate
            screen_y: Screen Y coordinate
            halo: Search radius in pixels (default 30 for reliable selection)

        Returns:
            The geometry at the point, or None if no geometry found
        """
        import logging
        logger = logging.getLogger(__name__)
        logger.debug(f"HIT_TEST: Looking for geometry at ({screen_x}, {screen_y}) with halo={halo}")
        
        # Find the closest canvas item
        try:
            item_id = self.canvas.find_closest(screen_x, screen_y, halo=halo)
            logger.info(f"HIT_TEST: Canvas find_closest returned: {item_id}")
        except Exception as e:
            logger.error(f"HIT_TEST: Canvas find_closest failed: {e}")
            return None

        if item_id:
            # find_closest returns a tuple, get the first element
            if isinstance(item_id, tuple):
                item_id = item_id[0]
            
            logger.debug(f"HIT_TEST: Canvas item ID: {item_id}")
            logger.debug(f"HIT_TEST: Available item mappings: {len(self._item_to_geometry)} items")
            if self._item_to_geometry:
                geometry_types = [type(geom).__name__ for geom in self._item_to_geometry.values()]
                logger.debug(f"HIT_TEST: Geometry types in mapping: {set(geometry_types)}")
            
            # Look up the geometry for this item
            geometry = self._item_to_geometry.get(item_id)
            if geometry:
                logger.debug(f"HIT_TEST: Found geometry: {type(geometry).__name__}")
            else:
                logger.debug(f"HIT_TEST: No geometry mapping found for item {item_id}")
                # Debug: show some available mappings
                if self._item_to_geometry:
                    sample_items = list(self._item_to_geometry.keys())[:5]
                    logger.debug(f"HIT_TEST: Sample item IDs in mapping: {sample_items}")
            
            return geometry
        else:
            logger.info(f"HIT_TEST: No canvas item found at ({screen_x}, {screen_y}) with halo={halo}")
            # Debug: try with larger halo
            try:
                larger_item_id = self.canvas.find_closest(screen_x, screen_y, halo=50)
                logger.info(f"HIT_TEST: With halo=50: {larger_item_id}")
            except:
                pass

        logger.info(f"HIT_TEST: Final result: None (no geometry found)")
        return None

    def render_grid(self, viewport: TwoDimensionalEnvelope, grid_interval: float) -> None:
        """
        Render a grid on the canvas.

        Args:
            viewport: The current viewport
            grid_interval: Grid spacing in world units
        """
        # Calculate grid lines
        min_easting = (viewport.min_easting // grid_interval) * grid_interval
        max_easting = viewport.max_easting
        min_northing = (viewport.min_northing // grid_interval) * grid_interval
        max_northing = viewport.max_northing

        # Vertical lines
        easting = min_easting
        while easting <= max_easting:
            x1, y1 = self.converter.world_to_screen(min_northing, easting)
            x2, y2 = self.converter.world_to_screen(max_northing, easting)
            self.canvas.create_line(
                x1, y1, x2, y2,
                fill="lightgray",
                tags=("grid",)
            )
            easting += grid_interval

        # Horizontal lines
        northing = min_northing
        while northing <= max_northing:
            x1, y1 = self.converter.world_to_screen(northing, min_easting)
            x2, y2 = self.converter.world_to_screen(northing, max_easting)
            self.canvas.create_line(
                x1, y1, x2, y2,
                fill="lightgray",
                tags=("grid",)
            )
            northing += grid_interval

        # Lower grid items below geometry
        self.canvas.tag_lower("grid")

    def update_viewport(self, viewport: TwoDimensionalEnvelope) -> None:
        """
        Update the viewport for coordinate conversion.

        Args:
            viewport: The new viewport
        """
        self.converter.viewport = viewport

    def update_canvas_size(self, width: int, height: int) -> None:
        """
        Update the canvas size for coordinate conversion.

        Args:
            width: New canvas width in pixels
            height: New canvas height in pixels
        """
        self.converter.canvas_width = width
        self.converter.canvas_height = height

    def clear_hover_highlights(self) -> None:
        """Clear all hover highlights from the canvas."""
        self.canvas.delete("hover")
        self.canvas.delete("node_highlight")

    def highlight_hover(self, geometry: Geometry, color: str, style: LayerStyle) -> None:
        """
        Highlight a geometry with hover color and 2x stroke width.

        Args:
            geometry: Geometry to highlight
            color: Hover color
            style: Original layer style
        """
        from plana_figura.geometry import Point
        from plana_figura.linear import LineSegment

        # Create a temporary style with hover color and 2x stroke width
        hover_width = style.stroke_width * 2

        if isinstance(geometry, Point):
            # Highlight point with hover color
            screen_x, screen_y = self.converter.world_to_screen(
                geometry.northing,
                geometry.easting
            )
            radius = style.point_size
            self.canvas.create_oval(
                screen_x - radius,
                screen_y - radius,
                screen_x + radius,
                screen_y + radius,
                fill=color,
                outline=color,
                width=2,
                tags=("hover",)
            )

        elif isinstance(geometry, LineSegment):
            # Highlight line segment with hover color and 2x width
            start_x, start_y = self.converter.world_to_screen(
                geometry.start_point.northing,
                geometry.start_point.easting
            )
            end_x, end_y = self.converter.world_to_screen(
                geometry.end_point.northing,
                geometry.end_point.easting
            )
            self.canvas.create_line(
                start_x, start_y, end_x, end_y,
                fill=color,
                width=hover_width,
                capstyle=getattr(style, 'line_cap', 'butt'),
                joinstyle=getattr(style, 'line_join', 'miter'),
                tags=("hover",)
            )

        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            # Highlight circular arc with hover color and 2x width
            # Use the same rendering logic as _render_circular_arc but with hover styling
            center = geometry.radius_point
            start_point = geometry.start_point
            end_point = geometry.end_point
            
            center_x, center_y = self.converter.world_to_screen(
                center.northing, center.easting
            )
            start_x, start_y = self.converter.world_to_screen(
                start_point.northing, start_point.easting
            )
            end_x, end_y = self.converter.world_to_screen(
                end_point.northing, end_point.easting
            )
            
            radius_screen = ((start_x - center_x) ** 2 + (start_y - center_y) ** 2) ** 0.5
            
            import math
            # Negate Y for tkinter's inverted Y-axis
            start_angle = math.degrees(math.atan2(-(start_y - center_y), start_x - center_x))
            end_angle = math.degrees(math.atan2(-(end_y - center_y), end_x - center_x))
            
            # Calculate extent from screen coordinates
            extent = end_angle - start_angle
            if extent < 0:
                extent += 360
                
            bbox_x1 = center_x - radius_screen
            bbox_y1 = center_y - radius_screen
            bbox_x2 = center_x + radius_screen
            bbox_y2 = center_y + radius_screen
            
            self.canvas.create_arc(
                bbox_x1, bbox_y1, bbox_x2, bbox_y2,
                start=start_angle,
                extent=extent,
                outline=color,
                width=hover_width,
                style="arc",
                tags=("hover",)
            )

        elif isinstance(geometry, SimplePolyline):
            # Highlight polyline with hover color and 2x width
            coords: List[float] = []
            for point in geometry.points:
                screen_x, screen_y = self.converter.world_to_screen(
                    point.northing,
                    point.easting
                )
                coords.extend([screen_x, screen_y])

            if len(coords) >= 4:  # At least 2 points
                self.canvas.create_line(
                    *coords,
                    fill=color,
                    width=hover_width,
                    capstyle=getattr(style, 'line_cap', 'butt'),
                    joinstyle=getattr(style, 'line_join', 'miter'),
                    tags=("hover",)
                )

        elif isinstance(geometry, SimplePolygon):
            # Highlight polygon with hover color and 2x width
            coords: List[float] = []
            for point in geometry.points:
                screen_x, screen_y = self.converter.world_to_screen(
                    point.northing,
                    point.easting
                )
                coords.extend([screen_x, screen_y])

            if len(coords) >= 6:  # At least 3 points
                self.canvas.create_polygon(
                    *coords,
                    outline=color,
                    width=hover_width,
                    fill='',
                    joinstyle=getattr(style, 'line_join', 'miter'),
                    tags=("hover",)
                )

    def highlight_node(self, geometry: Geometry, node_index: int, style: LayerStyle) -> None:
        """
        Highlight a specific node with a circle (radius = 2x stroke width).

        Args:
            geometry: Geometry containing the node
            node_index: Index of the node to highlight
            style: Original layer style
        """
        from plana_figura.geometry import Point
        from plana_figura.linear import LineSegment
        from plana_figura.composite import SimplePolyline, SimplePolygon

        # Get the node
        node = None
        if isinstance(geometry, Point):
            if node_index == 0:
                node = geometry
        elif isinstance(geometry, LineSegment):
            if node_index == 0:
                node = geometry.start_point
            elif node_index == 1:
                node = geometry.end_point
        elif isinstance(geometry, SimplePolyline):
            if 0 <= node_index < len(geometry.points):
                node = geometry.points[node_index]
        elif isinstance(geometry, SimplePolygon):
            if 0 <= node_index < len(geometry.points):
                node = geometry.points[node_index]
        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            # CircularArc has 3 nodes: center, start, end
            if node_index == 0:
                node = geometry.radius_point  # center
            elif node_index == 1:
                node = geometry.start_point
            elif node_index == 2:
                node = geometry.end_point

        if node:
            # Convert to screen coordinates
            screen_x, screen_y = self.converter.world_to_screen(
                node.northing,
                node.easting
            )

            # Make node circles more visible - larger radius and thicker outline
            radius = max(style.stroke_width * 3, 8)  # Minimum 8 pixels, 3x stroke width
            
            import logging
            logger = logging.getLogger(__name__)
            logger.debug(f"Highlighting node at screen ({screen_x}, {screen_y}) with radius {radius}")

            # Draw prominent circle with thick outline and fill
            self.canvas.create_oval(
                screen_x - radius,
                screen_y - radius,
                screen_x + radius,
                screen_y + radius,
                outline="blue",
                fill="lightblue",
                width=4,  # Thick outline
                tags=("node_highlight",)
            )
        else:
            import logging
            logger = logging.getLogger(__name__)
            logger.debug(f"No node found for geometry {type(geometry).__name__} at index {node_index}")

    def highlight_all_nodes(self, geometry: Geometry, hover_color: str, style: LayerStyle) -> None:
        """
        Highlight all nodes in a geometry with solid circles using hover color.
        
        For CircularArcs, only highlights the endpoints (start and end), not the center.
        
        Args:
            geometry: Geometry containing the nodes
            hover_color: Color to use for highlighting
            style: Original layer style for calculating radius
        """
        from plana_figura.geometry import Point
        from plana_figura.linear import LineSegment
        from plana_figura.composite import SimplePolyline, SimplePolygon

        # Get all nodes in the geometry
        nodes = []
        if isinstance(geometry, Point):
            nodes = [geometry]
        elif isinstance(geometry, LineSegment):
            nodes = [geometry.start_point, geometry.end_point]
        elif isinstance(geometry, SimplePolyline):
            nodes = geometry.points
        elif isinstance(geometry, SimplePolygon):
            nodes = geometry.points
        elif hasattr(geometry, '__class__') and geometry.__class__.__name__ == 'CircularArc':
            # CircularArc: Only highlight endpoints (start, end), NOT the center
            nodes = [geometry.start_point, geometry.end_point]

        # Highlight each node
        for node in nodes:
            # Convert to screen coordinates
            screen_x, screen_y = self.converter.world_to_screen(
                node.northing,
                node.easting
            )

            # Radius is 1.5x the hover stroke width (2x original stroke width)
            hover_stroke_width = style.stroke_width * 2
            radius = max(int(hover_stroke_width * 1.5), 6)  # Minimum 6 pixels

            # Draw solid circle with hover color
            self.canvas.create_oval(
                screen_x - radius,
                screen_y - radius,
                screen_x + radius,
                screen_y + radius,
                outline=hover_color,
                fill=hover_color,
                width=2,
                tags=("node_highlight",)
            )
