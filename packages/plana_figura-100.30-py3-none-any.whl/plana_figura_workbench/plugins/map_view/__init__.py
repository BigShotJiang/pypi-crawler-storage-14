"""MapView plugin package."""

from plana_figura_workbench.plugins.map_view.map_view import MapView

__all__ = ['MapView']
