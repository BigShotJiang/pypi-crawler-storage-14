"""MapView model - manages view state for the map canvas.

This module provides the MapViewModel class which manages the state of the
map view including viewport, zoom level, layers, and active tool.
"""

from typing import Optional, List, Tuple, TYPE_CHECKING
import logging
from dataclasses import dataclass

from plana_figura import Geometry
from plana_figura.spatial import TwoDimensionalEnvelope
from plana_figura_workbench.model.document import Observable

if TYPE_CHECKING:
    from plana_figura_workbench.model import DataBucket

logger = logging.getLogger(__name__)


@dataclass
class Layer:
    """
    Represents a map layer with styling and visibility.

    Attributes:
        name: Layer name
        visible: Whether the layer is visible
        z_order: Drawing order (higher = on top)
        style: Layer styling options
    """
    name: str
    visible: bool = True
    z_order: int = 0
    style: Optional['LayerStyle'] = None


@dataclass
class LayerStyle:
    """
    Styling information for a layer.

    Attributes:
        stroke_color: Line/outline color
        stroke_width: Line/outline width in pixels
        fill_color: Fill color (empty string for no fill)
        line_join: Line join style ('miter', 'round', 'bevel')
        line_cap: Line cap style ('butt', 'round', 'projecting')
        point_size: Point marker radius in pixels
        point_color: Point fill color
        point_shape: Point marker shape ('circle', 'square', 'cross')
    """
    stroke_color: str = "black"
    stroke_width: int = 2  # Minimum 2 for visible line caps
    fill_color: str = ""
    line_join: str = "miter"
    line_cap: str = "butt"
    point_size: int = 5
    point_color: str = "yellow"
    point_shape: str = "circle"


class MapViewModel(Observable):
    """
    Manages the state of the MapView plugin.

    This model represents the view state (not the geospatial data). It manages
    the current viewport, zoom level, layers, active tool, and snapping settings.
    Changes to these properties notify observers via the Observable pattern.

    The model also integrates with DataBucket to publish viewport and zoom state
    for use by other plugins.

    Example:
        >>> model = MapViewModel()
        >>> model.viewport = TwoDimensionalEnvelope(0, 100, 0, 100)
        >>> model.zoom_level = 1.5
        >>> model.is_snapping_enabled = True
    """

    def __init__(self, data_bucket: Optional['DataBucket'] = None):
        """
        Initialize the MapViewModel.

        Args:
            data_bucket: Optional DataBucket for publishing state
        """
        super().__init__()
        self.data_bucket = data_bucket

        # View state
        self._viewport = TwoDimensionalEnvelope(0, 100, 0, 100)
        self._zoom_level = 1.0
        self._layers: List[Layer] = []
        self._active_tool: Optional[object] = None  # MapTool type
        self._is_snapping_enabled = False
        self._selection_color = "red"  # Color for selected items
        self._hover_color = "orange"  # Color for hover highlighting
        self._hovered_geometries: List[Geometry] = []  # Currently hovered geometries
        self._hovered_node: Optional[Tuple[Geometry, int]] = None  # (geometry, node_index)

        logger.debug("MapViewModel initialized")

    @property
    def viewport(self) -> TwoDimensionalEnvelope:
        """Get the current viewport."""
        return self._viewport

    @viewport.setter
    def viewport(self, value: TwoDimensionalEnvelope) -> None:
        """
        Set the viewport and notify observers.

        Args:
            value: New viewport
        """
        if self._viewport != value:
            self._viewport = value
            self._notify_observers()

            # Publish to DataBucket
            if self.data_bucket is not None:
                try:
                    from plana_figura_workbench.model import DataBucketKeys
                    center = self._get_viewport_center()
                    self.data_bucket.set(
                        DataBucketKeys.VIEWPORT_CENTER,
                        center,
                        source='map_view_model'
                    )
                except Exception as e:
                    logger.error(f"Error publishing viewport to DataBucket: {e}")

            logger.debug(f"Viewport changed: {value}")

    @property
    def zoom_level(self) -> float:
        """Get the current zoom level."""
        return self._zoom_level

    @zoom_level.setter
    def zoom_level(self, value: float) -> None:
        """
        Set the zoom level and notify observers.

        Args:
            value: New zoom level (must be positive)

        Raises:
            ValueError: If zoom level is not positive
        """
        if value <= 0:
            raise ValueError("Zoom level must be positive")

        if self._zoom_level != value:
            self._zoom_level = value
            self._notify_observers()

            # Publish to DataBucket
            if self.data_bucket is not None:
                try:
                    from plana_figura_workbench.model import DataBucketKeys
                    self.data_bucket.set(
                        DataBucketKeys.VIEWPORT_ZOOM,
                        value,
                        source='map_view_model'
                    )
                except Exception as e:
                    logger.error(f"Error publishing zoom to DataBucket: {e}")

            logger.debug(f"Zoom level changed: {value}")

    @property
    def layers(self) -> List[Layer]:
        """Get all layers."""
        return self._layers.copy()

    @layers.setter
    def layers(self, value: List[Layer]) -> None:
        """Set layers and notify observers."""
        self._layers = value
        self._notify_observers()

    @property
    def active_tool(self) -> Optional[object]:
        """Get the currently active tool."""
        return self._active_tool

    @active_tool.setter
    def active_tool(self, tool: Optional[object]) -> None:
        """
        Set the active tool and notify observers.

        This will deactivate the previous tool and activate the new one.

        Args:
            tool: New active tool (or None)
        """
        if self._active_tool != tool:
            old_tool = self._active_tool

            # Deactivate old tool
            if old_tool is not None and hasattr(old_tool, 'deactivate'):
                try:
                    old_tool.deactivate()  # type: ignore
                except Exception as e:
                    logger.error(f"Error deactivating tool: {e}")

            self._active_tool = tool

            # Activate new tool
            if tool is not None and hasattr(tool, 'activate'):
                try:
                    tool.activate()  # type: ignore
                except Exception as e:
                    logger.error(f"Error activating tool: {e}")

            self._notify_observers()

            logger.debug(f"Active tool changed: {tool}")

    @property
    def is_snapping_enabled(self) -> bool:
        """Get whether snapping is enabled."""
        return self._is_snapping_enabled

    @is_snapping_enabled.setter
    def is_snapping_enabled(self, value: bool) -> None:
        """
        Set whether snapping is enabled and notify observers.

        Args:
            value: True to enable snapping, False to disable
        """
        if self._is_snapping_enabled != value:
            self._is_snapping_enabled = value
            self._notify_observers()

            logger.debug(f"Snapping enabled changed: {value}")

    @property
    def selection_color(self) -> str:
        """Get the selection color."""
        return self._selection_color

    @selection_color.setter
    def selection_color(self, value: str) -> None:
        """
        Set the selection color and notify observers.

        Args:
            value: Color string (e.g., 'red', '#FF0000')
        """
        if self._selection_color != value:
            self._selection_color = value
            self._notify_observers()
            logger.debug(f"Selection color changed: {value}")

    @property
    def hover_color(self) -> str:
        """Get the hover color."""
        return self._hover_color

    @hover_color.setter
    def hover_color(self, value: str) -> None:
        """
        Set the hover color and notify observers.

        Args:
            value: Color string (e.g., 'orange', '#FFA500')
        """
        if self._hover_color != value:
            self._hover_color = value
            self._notify_observers()
            logger.debug(f"Hover color changed: {value}")

    @property
    def hovered_geometries(self) -> List[Geometry]:
        """Get the currently hovered geometries."""
        return self._hovered_geometries

    @hovered_geometries.setter
    def hovered_geometries(self, value: List[Geometry]) -> None:
        """
        Set the hovered geometries.

        Args:
            value: List of geometries currently under the cursor
        """
        self._hovered_geometries = value

    @property
    def hovered_node(self) -> Optional[Tuple[Geometry, int]]:
        """Get the currently hovered node (geometry, node_index)."""
        return self._hovered_node

    @hovered_node.setter
    def hovered_node(self, value: Optional[Tuple[Geometry, int]]) -> None:
        """
        Set the hovered node.

        Args:
            value: Tuple of (geometry, node_index) or None
        """
        self._hovered_node = value

    def add_layer(self, layer: Layer) -> None:
        """
        Add a layer to the map.

        Args:
            layer: Layer to add
        """
        self._layers.append(layer)
        self._notify_observers()

        logger.debug(f"Layer added: {layer.name}")

    def remove_layer(self, layer_name: str) -> bool:
        """
        Remove a layer from the map.

        Args:
            layer_name: Name of the layer to remove

        Returns:
            True if layer was removed, False if not found
        """
        for i, layer in enumerate(self._layers):
            if layer.name == layer_name:
                self._layers.pop(i)
                self._notify_observers()
                logger.debug(f"Layer removed: {layer_name}")
                return True

        logger.warning(f"Layer not found: {layer_name}")
        return False

    def get_layer(self, layer_name: str) -> Optional[Layer]:
        """
        Get a layer by name.

        Args:
            layer_name: Name of the layer

        Returns:
            Layer if found, None otherwise
        """
        for layer in self._layers:
            if layer.name == layer_name:
                return layer
        return None

    def set_layer_visibility(self, layer_name: str, visible: bool) -> bool:
        """
        Set the visibility of a layer.

        Args:
            layer_name: Name of the layer
            visible: True to show, False to hide

        Returns:
            True if layer was found and updated, False otherwise
        """
        layer = self.get_layer(layer_name)
        if layer is not None:
            layer.visible = visible
            self._notify_observers()
            logger.debug(f"Layer visibility changed: {layer_name} = {visible}")
            return True

        logger.warning(f"Layer not found: {layer_name}")
        return False

    def clear_layers(self) -> None:
        """Remove all layers."""
        self._layers.clear()
        self._notify_observers()
        logger.debug("All layers cleared")

    def _get_viewport_center(self) -> tuple[float, float]:
        """
        Get the center point of the current viewport.

        Returns:
            Tuple of (northing, easting) at viewport center
        """
        center_n = (self._viewport.min_northing + self._viewport.max_northing) / 2
        center_e = (self._viewport.min_easting + self._viewport.max_easting) / 2
        return (center_n, center_e)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"MapViewModel("
            f"viewport={self._viewport}, "
            f"zoom={self._zoom_level:.2f}, "
            f"layers={len(self._layers)}, "
            f"snapping={self._is_snapping_enabled})"
        )
