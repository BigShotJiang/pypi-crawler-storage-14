"""MapView plugin - main integration wrapper.

This module provides the MapView plugin class which integrates all MVC
components and provides the main plugin interface.
"""

import tkinter as tk
from tkinter import ttk
from typing import Optional, TYPE_CHECKING, Dict, Any
import logging
import sys
from pathlib import Path

# Add Local Packages to path for vultus_serpentis
_local_packages = (
    Path(__file__).parent.parent.parent.parent / "Local Packages" / "vultus_serpentis"
)
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

from vultus_serpentis.events import EventBus  # type: ignore  # noqa: E402

from plana_figura import Geometry  # noqa: E402
from plana_figura_workbench.model import PlanaFiguraDocument  # noqa: E402
from plana_figura_workbench.plugins.map_view.map_view_model import (  # noqa: E402
    MapViewModel
)
from plana_figura_workbench.plugins.map_view.map_view_controller import (  # noqa: E402
    MapViewController
)
from plana_figura_workbench.plugins.map_view.map_view_renderer import (  # noqa: E402
    MapViewRenderer
)
from plana_figura_workbench.plugins.map_view.utilities.coordinate_converter import (  # noqa: E402
    CoordinateConverter
)
from plana_figura_workbench.plugins.map_view.tools.pan_tool import PanTool  # noqa: E402
from plana_figura_workbench.plugins.map_view.tools.zoom_tool import ZoomTool  # noqa: E402
from plana_figura_workbench.plugins.map_view.tools.select_tool import SelectTool  # noqa: E402
from plana_figura_workbench.events import (  # noqa: E402
    GeometryModifiedEvent,
    GeometryAddedEvent,
    GeometryDeletedEvent,
    GeometryPreviewEvent,
)

if TYPE_CHECKING:
    from plana_figura_workbench.model import DataBucket

logger = logging.getLogger(__name__)


class MapView(ttk.Frame):
    """
    MapView plugin - visual canvas for geometry display.

    This is the main plugin class that integrates the MVC components:
    - MapViewModel: Manages view state
    - MapViewController: Handles business logic and tool management
    - MapViewRenderer: Renders geometries to canvas

    Features:
    - Layer-based rendering with styling
    - Tool-based interaction (pan, zoom, select)
    - Hit detection for geometry selection
    - Coordinate conversion
    - Event bus integration
    - DataBucket integration

    Example:
        >>> map_view = MapView(parent, document, event_bus, data_bucket)
        >>> map_view.pack(fill="both", expand=True)
    """

    def __init__(
        self,
        parent: tk.Widget,
        document: PlanaFiguraDocument,
        event_bus: Optional[EventBus] = None,
        data_bucket: Optional['DataBucket'] = None
    ):
        """
        Initialize the MapView plugin.

        Args:
            parent: Parent widget
            document: The document to display
            event_bus: Optional EventBus for plugin communication
            data_bucket: Optional DataBucket for shared data access
        """
        super().__init__(parent)
        self.document = document
        self.event_bus = event_bus or EventBus.default()
        self.data_bucket = data_bucket

        # Create MVC components
        self.model = MapViewModel(data_bucket)

        # Create canvas first (needed by other components)
        self.canvas = None  # Will be created in _setup_ui

        # Setup UI to create canvas
        self._create_canvas()

        # Create coordinate converter
        self.converter = CoordinateConverter(
            viewport=self.model.viewport,
            canvas_width=800,  # Will be updated on resize
            canvas_height=600,
            grid=document.grid if hasattr(document, 'grid') else None
        )

        # Create controller first (needed for selection_checker)
        self.controller = MapViewController(
            document,
            self.model,
            None,  # Renderer will be set after creation
            self.event_bus
        )

        # Create renderer with selection_checker and selection_color_getter callbacks
        self.renderer = MapViewRenderer(
            self.canvas,
            self.converter,
            selection_checker=self.controller.is_geometry_selected,
            selection_color_getter=lambda: self.model.selection_color
        )

        # Set renderer in controller
        self.controller.renderer = self.renderer
        self.controller.set_canvas(self.canvas)

        # Now setup rest of UI (toolbar, status bar)
        self._setup_ui()

        # Register tools
        self._register_tools()

        # Set default tool
        self.controller.set_active_tool("pan")

        # Bind events
        self._bind_events()

        # Subscribe to event bus
        self._subscribe_to_events()
        
        # Subscribe to document changes
        self.document.add_observer(self)

        # Load saved settings
        self.controller.load_settings(self.canvas)

        # Initial render
        self.controller.fit_to_contents()

        logger.info("MapView initialized")

    def _create_canvas(self) -> None:
        """Create the canvas widget."""
        self.columnconfigure(0, weight=1)  # Main content (PanedWindow)
        self.columnconfigure(1, weight=0)  # Toolbar
        self.columnconfigure(2, weight=0)  # Information pane
        self.rowconfigure(0, weight=1)

        # Create PanedWindow for resizable layer panel
        self.main_paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        self.main_paned.grid(row=0, column=0, sticky="nsew")

        # Canvas will be added to PanedWindow later
        self.canvas = tk.Canvas(
            self.main_paned,
            bg="white",
            cursor="crosshair"
        )

    def _setup_ui(self) -> None:
        """Set up the user interface (layer panel, toolbar and status bar)."""

        # Layer panel (left side)
        self._setup_layer_panel()

        # Information pane (right side)
        self._setup_information_pane()

        # Status bar
        self.status_bar = ttk.Frame(self)
        self.status_bar.grid(row=1, column=0, columnspan=4, sticky="ew")

        self.status_label = ttk.Label(
            self.status_bar,
            text="Ready",
            anchor="w"
        )
        self.status_label.pack(side="left", fill="x", expand=True, padx=5, pady=2)

        # Coordinate display
        self.coord_label = ttk.Label(
            self.status_bar,
            text="N: 0.00, E: 0.00",
            anchor="e"
        )
        self.coord_label.pack(side="right", padx=5, pady=2)

        # Toolbar (right side)
        self.toolbar = ttk.Frame(self, padding=5)
        self.toolbar.grid(row=0, column=1, sticky="ns")

        # Configure grid for consistent button sizing
        self.toolbar.columnconfigure(0, weight=1, minsize=100)

        # Tool buttons
        row = 0
        self.pan_button = ttk.Button(
            self.toolbar,
            text="Pan",
            command=lambda: self.controller.set_active_tool("pan"),
            width=12
        )
        self.pan_button.grid(row=row, column=0, sticky="ew", pady=2)

        row += 1
        self.zoom_button = ttk.Button(
            self.toolbar,
            text="Zoom Window",
            command=lambda: self.controller.set_active_tool("zoom"),
            width=12
        )
        self.zoom_button.grid(row=row, column=0, sticky="ew", pady=2)

        row += 1
        self.select_button = ttk.Button(
            self.toolbar,
            text="Select",
            command=lambda: self.controller.set_active_tool("select"),
            width=12
        )
        self.select_button.grid(row=row, column=0, sticky="ew", pady=2)

        row += 1
        ttk.Separator(self.toolbar, orient="horizontal").grid(
            row=row, column=0, sticky="ew", pady=5
        )

        row += 1
        self.zoom_in_button = ttk.Button(
            self.toolbar,
            text="Zoom In",
            command=lambda: self.controller.zoom_in(),
            width=12
        )
        self.zoom_in_button.grid(row=row, column=0, sticky="ew", pady=2)

        row += 1
        self.zoom_out_button = ttk.Button(
            self.toolbar,
            text="Zoom Out",
            command=lambda: self.controller.zoom_out(),
            width=12
        )
        self.zoom_out_button.grid(row=row, column=0, sticky="ew", pady=2)

        row += 1
        self.fit_button = ttk.Button(
            self.toolbar,
            text="Fit All",
            command=lambda: self.controller.fit_to_contents(),
            width=12
        )
        self.fit_button.grid(row=row, column=0, sticky="ew", pady=2)

        row += 1
        ttk.Separator(self.toolbar, orient="horizontal").grid(
            row=row, column=0, sticky="ew", pady=5
        )

        # Layer manager button
        row += 1
        self.layer_manager_button = ttk.Button(
            self.toolbar,
            text="Layers...",
            command=self._show_layer_manager,
            width=12
        )
        self.layer_manager_button.grid(row=row, column=0, sticky="ew", pady=2)

        # Map settings button
        row += 1
        self.settings_button = ttk.Button(
            self.toolbar,
            text="Settings...",
            command=self._show_map_settings,
            width=12
        )
        self.settings_button.grid(row=row, column=0, sticky="ew", pady=2)

        # Separator
        row += 1
        ttk.Separator(self.toolbar, orient="horizontal").grid(
            row=row, column=0, sticky="ew", pady=5
        )

        # Clear Selection button
        row += 1
        self.clear_selection_button = ttk.Button(
            self.toolbar,
            text="Clear Selection",
            command=self._clear_selection,
            width=15
        )
        self.clear_selection_button.grid(row=row, column=0, sticky="ew", pady=2)

    def _register_tools(self) -> None:
        """Register all tools with the controller."""
        pan_tool = PanTool(self.controller)
        zoom_tool = ZoomTool(self.controller)
        select_tool = SelectTool(self.controller)

        self.controller.register_tool("pan", pan_tool)
        self.controller.register_tool("zoom", zoom_tool)
        self.controller.register_tool("select", select_tool)

        logger.debug("Tools registered")

    def _bind_events(self) -> None:
        """Bind canvas events."""
        print("=" * 80)
        print("BINDING CANVAS EVENTS - THIS MESSAGE CONFIRMS CODE IS LOADED")
        print("=" * 80)
        
        # Set canvas to accept focus so it can receive mouse and keyboard events
        self.canvas.config(takefocus=True)
        self.canvas.focus_set()
        
        print(f"Canvas takefocus: {self.canvas.cget('takefocus')}")
        print(f"Canvas has focus: {self.canvas.focus_get() == self.canvas}")
        
        # Mouse events
        self.canvas.bind("<ButtonPress-1>", self._on_mouse_press)
        self.canvas.bind("<B1-Motion>", self._on_mouse_move)
        self.canvas.bind("<ButtonRelease-1>", self._on_mouse_release)
        self.canvas.bind("<ButtonPress-2>", self._on_mouse_press)
        self.canvas.bind("<B2-Motion>", self._on_mouse_move)
        self.canvas.bind("<ButtonRelease-2>", self._on_mouse_release)
        self.canvas.bind("<ButtonPress-3>", self._on_mouse_press)
        self.canvas.bind("<B3-Motion>", self._on_mouse_move)
        self.canvas.bind("<ButtonRelease-3>", self._on_mouse_release)

        # Mouse wheel
        self.canvas.bind("<MouseWheel>", self._on_mouse_wheel)
        self.canvas.bind("<Button-4>", self._on_mouse_wheel)  # Linux scroll up
        self.canvas.bind("<Button-5>", self._on_mouse_wheel)  # Linux scroll down

        # Mouse motion (for coordinate display)
        self.canvas.bind("<Motion>", self._on_mouse_motion)

        # Keyboard
        self.canvas.bind("<Key>", self._on_key_press)

        # Canvas resize
        self.canvas.bind("<Configure>", self._on_canvas_resize)

        logger.info("Events bound - canvas has focus and is ready for mouse clicks")

    def _on_mouse_press(self, event: tk.Event) -> None:
        """Handle mouse press."""
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"MAP_VIEW: Mouse press at ({event.x}, {event.y}), button={event.num}")
        
        # Log active tool
        active_tool = self.controller.get_active_tool()
        tool_name = type(active_tool).__name__ if active_tool else "None"
        logger.info(f"MAP_VIEW: Active tool: {tool_name}")
        
        # Right click shows context menu
        if event.num == 3:
            logger.info(f"MAP_VIEW: Right click - showing context menu")
            self._show_context_menu(event)
        else:
            logger.info(f"MAP_VIEW: Left/Middle click - delegating to controller")
            try:
                self.controller.on_mouse_press(event)
                logger.info(f"MAP_VIEW: Controller handled mouse press successfully")
            except Exception as e:
                logger.error(f"MAP_VIEW: Controller mouse press failed: {e}")
                import traceback
                traceback.print_exc()

    def _on_mouse_move(self, event: tk.Event) -> None:
        """Handle mouse move."""
        self.controller.on_mouse_move(event)

    def _on_mouse_release(self, event: tk.Event) -> None:
        """Handle mouse release."""
        self.controller.on_mouse_release(event)

    def _on_mouse_wheel(self, event: tk.Event) -> None:
        """Handle mouse wheel."""
        self.controller.on_mouse_wheel(event)

    def _on_key_press(self, event: tk.Event) -> None:
        """Handle key press."""
        self.controller.on_key_press(event)

    def _on_mouse_motion(self, event: tk.Event) -> None:
        """Handle mouse motion (for coordinate display and hover detection)."""
        # Convert screen to world coordinates
        northing, easting = self.converter.screen_to_world(event.x, event.y)
        self.coord_label.config(text=f"N: {northing:.2f}, E: {easting:.2f}")

        # Hover detection - use default tolerances from controller
        self.controller.handle_hover(event.x, event.y)
        
        # Update information pane
        self._update_information_pane()

    def _on_canvas_resize(self, event: tk.Event) -> None:
        """Handle canvas resize."""
        if event.width > 1 and event.height > 1:
            self.controller.on_canvas_resize(event.width, event.height)

    def _subscribe_to_events(self) -> None:
        """Subscribe to event bus events."""
        self.event_bus.subscribe(GeometryAddedEvent, self._on_geometry_added)
        self.event_bus.subscribe(GeometryModifiedEvent, self._on_geometry_modified)
        self.event_bus.subscribe(GeometryDeletedEvent, self._on_geometry_deleted)
        self.event_bus.subscribe(GeometryPreviewEvent, self._on_geometry_preview)

        logger.debug("Subscribed to events")

    def _on_geometry_added(self, event: GeometryAddedEvent) -> None:
        """Handle geometry added event."""
        self.controller.refresh()

    def _on_geometry_modified(self, event: GeometryModifiedEvent) -> None:
        """Handle geometry modified event."""
        self.controller.refresh()

    def _on_geometry_deleted(self, event: GeometryDeletedEvent) -> None:
        """Handle geometry deleted event."""
        self.controller.refresh()

    def _on_geometry_preview(self, event: GeometryPreviewEvent) -> None:
        """Handle geometry preview event."""
        logger.debug(f"Received preview event from {event.source}: {event.operation_type}")
        
        # Render preview geometry
        self.renderer.render_preview_geometry(event.geometry)

    def _setup_layer_panel(self) -> None:
        """Set up the layer visibility panel."""
        # Layer panel frame
        self.layer_panel = ttk.LabelFrame(self.main_paned, text="Layers", padding=5)
        
        # Add layer panel to PanedWindow first
        self.main_paned.add(self.layer_panel, weight=0)
        
        # Add canvas to PanedWindow
        self.main_paned.add(self.canvas, weight=1)

        # Scrollable frame for layer checkboxes
        self.layer_canvas = tk.Canvas(self.layer_panel, width=150)
        self.layer_scrollbar = ttk.Scrollbar(
            self.layer_panel,
            orient="vertical",
            command=self.layer_canvas.yview
        )
        self.layer_frame = ttk.Frame(self.layer_canvas)

        self.layer_frame.bind(
            "<Configure>",
            lambda e: self.layer_canvas.configure(
                scrollregion=self.layer_canvas.bbox("all")
            )
        )

        self.layer_canvas.create_window((0, 0), window=self.layer_frame, anchor="nw")
        self.layer_canvas.configure(yscrollcommand=self.layer_scrollbar.set)

        self.layer_canvas.pack(side="left", fill="both", expand=True)
        self.layer_scrollbar.pack(side="right", fill="y")

        # Dictionary to store layer checkbutton variables and tooltips
        self.layer_vars: Dict[str, tk.BooleanVar] = {}
        self.layer_tooltips: Dict[str, Any] = {}

        # Populate layers
        self._refresh_layer_panel()

    def _refresh_layer_panel(self) -> None:
        """Refresh the layer panel with current layers."""
        # Clear existing widgets
        for widget in self.layer_frame.winfo_children():
            widget.destroy()

        self.layer_vars.clear()
        self.layer_tooltips.clear()

        # Add checkbox for each layer
        for layer in self.model.layers:
            var = tk.BooleanVar(value=layer.visible)
            self.layer_vars[layer.name] = var

            layer_name = layer.name
            cb = ttk.Checkbutton(
                self.layer_frame,
                text=layer_name,
                variable=var,
                command=lambda n=layer_name: self._toggle_layer_visibility(n)
            )
            cb.pack(anchor="w", pady=2)

            # Add tooltip showing full layer name
            self._create_tooltip(cb, layer_name)

    def _toggle_layer_visibility(self, layer_name: str) -> None:
        """Toggle visibility of a layer."""
        visible = self.layer_vars[layer_name].get()
        self.controller.set_layer_visibility(layer_name, visible)

    def _create_tooltip(self, widget: tk.Widget, text: str) -> None:
        """Create a tooltip for a widget.

        Args:
            widget: Widget to attach tooltip to
            text: Tooltip text to display
        """
        def on_enter(event: tk.Event) -> None:
            # Create tooltip window
            tooltip = tk.Toplevel()
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")

            label = tk.Label(
                tooltip,
                text=text,
                background="#ffffe0",
                relief="solid",
                borderwidth=1,
                font=("TkDefaultFont", 9)
            )
            label.pack()

            # Store tooltip reference
            setattr(widget, '_tooltip', tooltip)  # type: ignore[attr-defined]

        def on_leave(event: tk.Event) -> None:
            # Destroy tooltip window
            if hasattr(widget, '_tooltip'):
                tooltip_win = getattr(widget, '_tooltip')
                tooltip_win.destroy()
                delattr(widget, '_tooltip')

        widget.bind("<Enter>", on_enter)
        widget.bind("<Leave>", on_leave)

    def _setup_information_pane(self) -> None:
        """Set up the information pane for displaying geometry and node properties."""
        # Information pane frame
        self.info_panel = ttk.LabelFrame(self, text="Information", padding=5)
        self.info_panel.grid(row=0, column=2, sticky="nsew", padx=2, pady=2)

        # Configure grid
        self.info_panel.rowconfigure(0, weight=1)  # Geometry properties
        self.info_panel.rowconfigure(1, weight=1)  # Node properties
        self.info_panel.columnconfigure(0, weight=1)

        # Top section: Geometry Properties
        geom_frame = ttk.LabelFrame(self.info_panel, text="Geometry Properties", padding=5)
        geom_frame.grid(row=0, column=0, sticky="nsew", pady=(0, 5))

        # Geometry properties text widget
        self.geom_info_text = tk.Text(
            geom_frame,
            width=30,
            height=10,
            wrap=tk.WORD,
            state=tk.DISABLED,
            font=("Courier", 9)
        )
        self.geom_info_text.pack(fill=tk.BOTH, expand=True)

        # Bottom section: Node Properties
        node_frame = ttk.LabelFrame(self.info_panel, text="Node Properties", padding=5)
        node_frame.grid(row=1, column=0, sticky="nsew")

        # Node properties text widget
        self.node_info_text = tk.Text(
            node_frame,
            width=30,
            height=6,
            wrap=tk.WORD,
            state=tk.DISABLED,
            font=("Courier", 9)
        )
        self.node_info_text.pack(fill=tk.BOTH, expand=True)

        # Initially clear
        self._clear_information_pane()

    def _clear_information_pane(self) -> None:
        """Clear the information pane."""
        self.geom_info_text.configure(state=tk.NORMAL)
        self.geom_info_text.delete("1.0", tk.END)
        self.geom_info_text.insert("1.0", "Hover over a geometry to see its properties.")
        self.geom_info_text.configure(state=tk.DISABLED)

        self.node_info_text.configure(state=tk.NORMAL)
        self.node_info_text.delete("1.0", tk.END)
        self.node_info_text.insert("1.0", "Hover near a node to see its properties.")
        self.node_info_text.configure(state=tk.DISABLED)

    def _update_information_pane(self) -> None:
        """Update the information pane with current hover information."""
        # Update geometry properties
        if self.model.hovered_geometries:
            geometry = self.model.hovered_geometries[0]  # Show first hovered geometry
            self._update_geometry_info(geometry)
        else:
            self.geom_info_text.configure(state=tk.NORMAL)
            self.geom_info_text.delete("1.0", tk.END)
            self.geom_info_text.insert("1.0", "Hover over a geometry to see its properties.")
            self.geom_info_text.configure(state=tk.DISABLED)

        # Update node properties
        if self.model.hovered_node:
            geometry, node_index = self.model.hovered_node
            self._update_node_info(geometry, node_index)
        else:
            self.node_info_text.configure(state=tk.NORMAL)
            self.node_info_text.delete("1.0", tk.END)
            self.node_info_text.insert("1.0", "Hover near a node to see its properties.")
            self.node_info_text.configure(state=tk.DISABLED)

    def _update_geometry_info(self, geometry: Geometry) -> None:
        """Update geometry properties display."""
        self.geom_info_text.configure(state=tk.NORMAL)
        self.geom_info_text.delete("1.0", tk.END)

        # Get geometry properties from controller
        props = self.controller.get_geometry_properties(geometry)

        # Format and display
        text = f"Identifier: {props['identifier']}\n"
        text += f"Type: {props['type']}\n"
        text += f"\n"

        if 'length' in props:
            text += f"Length: {props['length']:.3f}\n"
        if 'area' in props:
            text += f"Area: {props['area']:.3f}\n"
        if 'perimeter' in props:
            text += f"Perimeter: {props['perimeter']:.3f}\n"

        text += f"\nNodes: {props['node_count']}"

        self.geom_info_text.insert("1.0", text)
        self.geom_info_text.configure(state=tk.DISABLED)

    def _update_node_info(self, geometry: Geometry, node_index: int) -> None:
        """Update node properties display."""
        self.node_info_text.configure(state=tk.NORMAL)
        self.node_info_text.delete("1.0", tk.END)

        # Get node properties from controller
        node_props = self.controller.get_node_properties(geometry, node_index)

        if node_props:
            text = f"Sequence: {node_props['sequence']}\n"
            text += f"Northing: {node_props['northing']:.3f}\n"
            text += f"Easting: {node_props['easting']:.3f}\n"
            text += f"Elevation: {node_props['elevation']:.3f}"
            self.node_info_text.insert("1.0", text)

        self.node_info_text.configure(state=tk.DISABLED)

    def _show_layer_manager(self) -> None:
        """Show the layer manager dialog."""
        from plana_figura_workbench.plugins.map_view.dialogs.layer_manager_dialog import (
            LayerManagerDialog
        )

        dialog = LayerManagerDialog(self, self.controller)
        self.wait_window(dialog)
        self._refresh_layer_panel()

    def _show_map_settings(self) -> None:
        """Show the map settings dialog."""
        from plana_figura_workbench.plugins.map_view.dialogs.map_settings_dialog import (
            MapSettingsDialog
        )

        dialog = MapSettingsDialog(self, self.controller, self.canvas)
        self.wait_window(dialog)

    def _clear_selection(self) -> None:
        """Clear all selected geometries."""
        self.controller.clear_selection()

    def _show_context_menu(self, event: tk.Event) -> None:
        """
        Show context menu for hovered geometries.

        Args:
            event: Mouse event with x, y coordinates
        """
        # Create context menu
        menu = tk.Menu(self, tearoff=0)
        
        # Add menu items
        menu.add_command(
            label="Add To Selected Items",
            command=self.controller.add_hovered_to_selection
        )
        menu.add_command(
            label="Remove From Selected Items",
            command=self.controller.remove_hovered_from_selection
        )

        # Show menu at mouse position
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    # Public API

    def zoom_in(self) -> None:
        """Zoom in."""
        self.controller.zoom_in()

    def zoom_out(self) -> None:
        """Zoom out."""
        self.controller.zoom_out()

    def fit_to_contents(self) -> None:
        """Fit viewport to show all geometries."""
        self.controller.fit_to_contents()

    def refresh(self) -> None:
        """Refresh the display."""
        self.controller.refresh()

    def set_tool(self, tool_name: str) -> None:
        """
        Set the active tool.

        Args:
            tool_name: Name of the tool to activate ("pan", "zoom", "select")
        """
        self.controller.set_active_tool(tool_name)
    
    def update(self, observable) -> None:
        """Observer pattern update method - called when document changes."""
        self.on_document_update(observable)
    
    def on_document_update(self, observable) -> None:
        """Handle document updates by refreshing the map view."""
        logger.info("Document updated - refreshing MapView")
        self.refresh()
        self._refresh_layer_panel()
