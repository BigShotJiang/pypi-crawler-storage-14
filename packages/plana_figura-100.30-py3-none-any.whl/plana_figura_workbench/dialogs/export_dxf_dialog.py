"""Dialog for exporting to DXF files."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import ttkbootstrap as ttkb
from pathlib import Path
from typing import Optional, Dict
import logging

from plana_figura import GeometryCollection
from plana_figura_workbench.io.dxf import DXFWriter, DXFConfig
from plana_figura_workbench.io.dxf.dxf_config import DXFVersion

logger = logging.getLogger(__name__)


class ExportDXFDialog(tk.Toplevel):
    """
    Dialog for exporting geometries to DXF files.
    
    Allows user to:
    - Select output file
    - Choose DXF version
    - Configure export options
    - Select which collections to export
    """
    
    def __init__(self, parent, document):
        """
        Initialize the export dialog.
        
        Args:
            parent: Parent window
            document: PlanaFiguraDocument to export from
        """
        super().__init__(parent)
        
        self.title("Export to DXF File")
        self.geometry("550x450")
        self.resizable(True, True)
        
        # Make dialog modal
        self.transient(parent)
        self.grab_set()
        
        # Data
        self.document = document
        self.result = None
        self.selected_file: Optional[Path] = None
        self.config = DXFConfig.default_export()
        
        self._setup_ui()
        
        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_y() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")
    
    def _setup_ui(self):
        """Set up the user interface."""
        # Main container
        main_frame = ttk.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # File selection
        self._create_file_section(main_frame)
        
        # Collection selection
        self._create_collection_section(main_frame)
        
        # Options
        self._create_options_section(main_frame)
        
        # Buttons
        self._create_buttons(main_frame)
    
    def _create_file_section(self, parent):
        """Create file selection section."""
        file_frame = ttk.LabelFrame(parent, text="Output File", padding=10)
        file_frame.pack(fill=tk.X, pady=(0, 10))
        
        # File path
        path_frame = ttk.Frame(file_frame)
        path_frame.pack(fill=tk.X)
        
        ttk.Label(path_frame, text="File:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.file_var = tk.StringVar()
        self.file_entry = ttk.Entry(path_frame, textvariable=self.file_var, state="readonly")
        self.file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        browse_btn = ttk.Button(
            path_frame,
            text="Browse...",
            command=self._on_browse,
            bootstyle="secondary"
        )
        browse_btn.pack(side=tk.LEFT)
    
    def _create_collection_section(self, parent):
        """Create collection selection section."""
        collection_frame = ttk.LabelFrame(parent, text="Collections to Export", padding=10)
        collection_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Toolbar
        toolbar = ttk.Frame(collection_frame)
        toolbar.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(
            toolbar,
            text="Select All",
            command=self._on_select_all_collections,
            bootstyle="secondary-outline",
            width=12
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        ttk.Button(
            toolbar,
            text="Deselect All",
            command=self._on_deselect_all_collections,
            bootstyle="secondary-outline",
            width=12
        ).pack(side=tk.LEFT)
        
        # Collection list
        list_frame = ttk.Frame(collection_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Listbox
        self.collection_listbox = tk.Listbox(
            list_frame,
            selectmode=tk.MULTIPLE,
            yscrollcommand=scrollbar.set
        )
        self.collection_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.collection_listbox.yview)
        
        # Populate collections
        self._populate_collections()
        
        # Info label
        self.collection_info_label = ttk.Label(
            collection_frame,
            text=f"{len(self.document.collections)} collection(s) available",
            foreground="gray"
        )
        self.collection_info_label.pack(fill=tk.X, pady=(5, 0))
    
    def _create_options_section(self, parent):
        """Create export options section."""
        options_frame = ttk.LabelFrame(parent, text="Export Options", padding=10)
        options_frame.pack(fill=tk.X, pady=(0, 10))
        
        # DXF Version
        version_frame = ttk.Frame(options_frame)
        version_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(version_frame, text="DXF Version:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.version_var = tk.StringVar(value="R2018")
        version_combo = ttk.Combobox(
            version_frame,
            textvariable=self.version_var,
            values=["R12", "R2000", "R2004", "R2007", "R2010", "R2013", "R2018"],
            state="readonly",
            width=15
        )
        version_combo.pack(side=tk.LEFT)
        version_combo.current(6)  # R2018
        
        # Coordinate precision
        precision_frame = ttk.Frame(options_frame)
        precision_frame.pack(fill=tk.X, pady=(5, 0))
        
        ttk.Label(precision_frame, text="Coordinate precision:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.precision_var = tk.IntVar(value=6)
        precision_spinbox = ttk.Spinbox(
            precision_frame,
            from_=0,
            to=15,
            textvariable=self.precision_var,
            width=10
        )
        precision_spinbox.pack(side=tk.LEFT)
        
        ttk.Label(precision_frame, text="decimal places").pack(side=tk.LEFT, padx=(5, 0))
        
        # Export as layers
        self.export_as_layers_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            options_frame,
            text="Export each collection as a separate layer",
            variable=self.export_as_layers_var,
            bootstyle="round-toggle"
        ).pack(anchor=tk.W, pady=(10, 0))
    
    def _create_buttons(self, parent):
        """Create dialog buttons."""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X)
        
        ttk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=12
        ).pack(side=tk.RIGHT, padx=(5, 0))
        
        self.export_btn = ttk.Button(
            button_frame,
            text="Export",
            command=self._on_export,
            bootstyle="primary",
            width=12
        )
        self.export_btn.pack(side=tk.RIGHT)
    
    def _populate_collections(self):
        """Populate the collection listbox."""
        self.collection_listbox.delete(0, tk.END)
        
        for idx, collection in enumerate(self.document.collections):
            # Get collection name
            if hasattr(collection, 'name') and collection.name:
                name = collection.name
            else:
                name = f"Collection {idx + 1}"
            
            # Add geometry count
            display_name = f"{name} ({collection.count} geometries)"
            self.collection_listbox.insert(tk.END, display_name)
        
        # Select active collection by default
        if self.document.active_collection:
            try:
                active_idx = self.document.collections.index(self.document.active_collection)
                self.collection_listbox.selection_set(active_idx)
            except ValueError:
                pass
    
    def _on_browse(self):
        """Handle Browse button click."""
        filename = filedialog.asksaveasfilename(
            parent=self,
            title="Export to DXF File",
            defaultextension=".dxf",
            filetypes=[
                ("DXF Files", "*.dxf"),
                ("All Files", "*.*")
            ]
        )
        
        if filename:
            self.selected_file = Path(filename)
            self.file_var.set(str(self.selected_file))
    
    def _on_select_all_collections(self):
        """Select all collections."""
        self.collection_listbox.selection_set(0, tk.END)
    
    def _on_deselect_all_collections(self):
        """Deselect all collections."""
        self.collection_listbox.selection_clear(0, tk.END)
    
    def _on_export(self):
        """Handle Export button click."""
        if not self.selected_file:
            messagebox.showwarning(
                "No File Selected",
                "Please select an output file.",
                parent=self
            )
            return
        
        # Get selected collections
        selected_indices = self.collection_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning(
                "No Collections Selected",
                "Please select at least one collection to export.",
                parent=self
            )
            return
        
        selected_collections = [
            self.document.collections[i] for i in selected_indices
        ]
        
        # Update config
        version_map = {
            "R12": DXFVersion.R12,
            "R2000": DXFVersion.R2000,
            "R2004": DXFVersion.R2004,
            "R2007": DXFVersion.R2007,
            "R2010": DXFVersion.R2010,
            "R2013": DXFVersion.R2013,
            "R2018": DXFVersion.R2018,
        }
        self.config.dxf_version = version_map[self.version_var.get()]
        self.config.coordinate_precision = self.precision_var.get()
        
        self.result = {
            'file': self.selected_file,
            'collections': selected_collections,
            'config': self.config,
            'export_as_layers': self.export_as_layers_var.get()
        }
        
        self.destroy()
    
    def _on_cancel(self):
        """Handle Cancel button click."""
        self.result = None
        self.destroy()
    
    def show(self):
        """Show the dialog and wait for result."""
        self.wait_window()
        return self.result
