"""
Controllers for geometry creation/editing dialogs.

These controllers contain all business logic for geometry dialogs,
making them fully testable without GUI dependencies.
"""

from typing import Optional, List, Tuple, Dict
from plana_figura import Point, LineSegment
from plana_figura.composite import SimplePolyline
from plana_figura.linear import CircularArc
from plana_figura_workbench.validators import (
    CoordinateValidator,
    ElevationValidator,
    ValidationResult,
)
import logging

logger = logging.getLogger(__name__)


class PointDialogController:
    """
    Controller for Point creation/editing dialog.
    
    Handles validation and Point object creation/modification.
    """
    
    def __init__(self):
        """Initialize the controller with validators."""
        self.northing_validator = CoordinateValidator()
        self.easting_validator = CoordinateValidator()
        self.elevation_validator = ElevationValidator()
        
        # Current values
        self.northing: Optional[float] = None
        self.easting: Optional[float] = None
        self.elevation: float = 0.0
        self.name: Optional[str] = None
        
        # For editing mode
        self.original_point: Optional[Point] = None
    
    def load_point(self, point: Point) -> None:
        """
        Load an existing point for editing.
        
        Args:
            point: The point to edit
        """
        self.original_point = point
        self.northing = point.northing
        self.easting = point.easting
        self.elevation = point.elevation
        self.name = point.name
    
    def validate_northing(self, value: str) -> ValidationResult:
        """Validate northing input."""
        return self.northing_validator.validate(value)
    
    def validate_easting(self, value: str) -> ValidationResult:
        """Validate easting input."""
        return self.easting_validator.validate(value)
    
    def validate_elevation(self, value: str) -> ValidationResult:
        """Validate elevation input."""
        return self.elevation_validator.validate(value)
    
    def set_northing(self, value: str) -> bool:
        """
        Set northing value after validation.
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_northing(value)
        if result.is_valid:
            self.northing = result.value
            return True
        return False
    
    def set_easting(self, value: str) -> bool:
        """
        Set easting value after validation.
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_easting(value)
        if result.is_valid:
            self.easting = result.value
            return True
        return False
    
    def set_elevation(self, value: str) -> bool:
        """
        Set elevation value after validation.
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_elevation(value)
        if result.is_valid:
            self.elevation = result.value
            return True
        return False
    
    def set_name(self, value: str) -> bool:
        """
        Set name value (optional).
        
        Returns:
            Always True (name is optional)
        """
        self.name = value.strip() if value.strip() else None
        return True
    
    def is_valid(self) -> Tuple[bool, str]:
        """
        Check if all required fields are valid.
        
        Returns:
            (is_valid, error_message)
        """
        if self.northing is None:
            return (False, "Northing is required")
        if self.easting is None:
            return (False, "Easting is required")
        return (True, "")
    
    def create_point(self) -> Optional[Point]:
        """
        Create a Point object from current values.
        
        Returns:
            Point object if valid, None otherwise
        """
        is_valid, error = self.is_valid()
        if not is_valid:
            logger.warning(f"Cannot create point: {error}")
            return None
        
        return Point(
            northing=self.northing,  # type: ignore
            easting=self.easting,  # type: ignore
            elevation=self.elevation,
            name=self.name
        )
    
    def get_initial_values(self) -> Dict[str, str]:
        """
        Get initial values for form fields.
        
        Returns:
            Dictionary of field values as strings
        """
        return {
            'northing': str(self.northing) if self.northing is not None else "",
            'easting': str(self.easting) if self.easting is not None else "",
            'elevation': str(self.elevation),
            'name': self.name if self.name else ""
        }


class LineDialogController:
    """
    Controller for LineSegment creation/editing dialog.
    
    Handles validation and LineSegment object creation/modification.
    """
    
    def __init__(self):
        """Initialize the controller with validators."""
        self.coord_validator = CoordinateValidator()
        self.elev_validator = ElevationValidator()
        
        # Start point
        self.start_n: Optional[float] = None
        self.start_e: Optional[float] = None
        self.start_z: float = 0.0
        
        # End point
        self.end_n: Optional[float] = None
        self.end_e: Optional[float] = None
        self.end_z: float = 0.0
        
        # Optional name
        self.name: Optional[str] = None
        
        # For editing mode
        self.original_line: Optional[LineSegment] = None
    
    def load_line(self, line: LineSegment) -> None:
        """
        Load an existing line for editing.
        
        Args:
            line: The line segment to edit
        """
        self.original_line = line
        self.start_n = line.start_point.northing
        self.start_e = line.start_point.easting
        self.start_z = line.start_point.elevation
        self.end_n = line.end_point.northing
        self.end_e = line.end_point.easting
        self.end_z = line.end_point.elevation
        self.name = line.name
    
    def validate_coordinate(self, value: str) -> ValidationResult:
        """Validate coordinate input."""
        return self.coord_validator.validate(value)
    
    def validate_elevation(self, value: str) -> ValidationResult:
        """Validate elevation input."""
        return self.elev_validator.validate(value)
    
    def set_start_northing(self, value: str) -> bool:
        """Set start northing."""
        result = self.validate_coordinate(value)
        if result.is_valid:
            self.start_n = result.value
            return True
        return False
    
    def set_start_easting(self, value: str) -> bool:
        """Set start easting."""
        result = self.validate_coordinate(value)
        if result.is_valid:
            self.start_e = result.value
            return True
        return False
    
    def set_start_elevation(self, value: str) -> bool:
        """Set start elevation."""
        result = self.validate_elevation(value)
        if result.is_valid:
            self.start_z = result.value
            return True
        return False
    
    def set_end_northing(self, value: str) -> bool:
        """Set end northing."""
        result = self.validate_coordinate(value)
        if result.is_valid:
            self.end_n = result.value
            return True
        return False
    
    def set_end_easting(self, value: str) -> bool:
        """Set end easting."""
        result = self.validate_coordinate(value)
        if result.is_valid:
            self.end_e = result.value
            return True
        return False
    
    def set_end_elevation(self, value: str) -> bool:
        """Set end elevation."""
        result = self.validate_elevation(value)
        if result.is_valid:
            self.end_z = result.value
            return True
        return False
    
    def set_name(self, value: str) -> bool:
        """Set name value (optional)."""
        self.name = value.strip() if value.strip() else None
        return True
    
    def is_valid(self) -> Tuple[bool, str]:
        """
        Check if all required fields are valid.
        
        Returns:
            (is_valid, error_message)
        """
        if self.start_n is None or self.start_e is None:
            return (False, "Start point coordinates are required")
        if self.end_n is None or self.end_e is None:
            return (False, "End point coordinates are required")
        
        # Check if points are coincident
        if (self.start_n == self.end_n and
                self.start_e == self.end_e and
                self.start_z == self.end_z):
            return (False, "Start and end points cannot be the same")
        
        return (True, "")
    
    def create_line(self) -> Optional[LineSegment]:
        """
        Create a LineSegment object from current values.
        
        Returns:
            LineSegment object if valid, None otherwise
        """
        is_valid, error = self.is_valid()
        if not is_valid:
            logger.warning(f"Cannot create line: {error}")
            return None
        
        start_point = Point(
            northing=self.start_n,  # type: ignore
            easting=self.start_e,  # type: ignore
            elevation=self.start_z
        )
        end_point = Point(
            northing=self.end_n,  # type: ignore
            easting=self.end_e,  # type: ignore
            elevation=self.end_z
        )
        
        return LineSegment(start_point, end_point, name=self.name)
    
    def get_initial_values(self) -> Dict[str, str]:
        """
        Get initial values for form fields.
        
        Returns:
            Dictionary of field values as strings
        """
        return {
            'start_n': str(self.start_n) if self.start_n is not None else "",
            'start_e': str(self.start_e) if self.start_e is not None else "",
            'start_z': str(self.start_z),
            'end_n': str(self.end_n) if self.end_n is not None else "",
            'end_e': str(self.end_e) if self.end_e is not None else "",
            'end_z': str(self.end_z),
            'name': self.name if self.name else ""
        }


class PolylineDialogController:
    """
    Controller for SimplePolyline creation/editing dialog.
    
    Handles validation and SimplePolyline object creation/modification.
    """
    
    def __init__(self):
        """Initialize the controller with validators."""
        self.coord_validator = CoordinateValidator()
        self.elev_validator = ElevationValidator()
        
        # List of points (as tuples of (N, E, Z))
        self.points: List[Tuple[float, float, float]] = []
        
        # Optional name
        self.name: Optional[str] = None
        
        # For editing mode
        self.original_polyline: Optional[SimplePolyline] = None
    
    def load_polyline(self, polyline: SimplePolyline) -> None:
        """
        Load an existing polyline for editing.
        
        Args:
            polyline: The polyline to edit
        """
        self.original_polyline = polyline
        self.points = [
            (pt.northing, pt.easting, pt.elevation)
            for pt in polyline.points
        ]
        self.name = polyline.name
    
    def validate_coordinate(self, value: str) -> ValidationResult:
        """Validate coordinate input."""
        return self.coord_validator.validate(value)
    
    def validate_elevation(self, value: str) -> ValidationResult:
        """Validate elevation input."""
        return self.elev_validator.validate(value)
    
    def add_point(
        self,
        northing: str,
        easting: str,
        elevation: str = "0.0"
    ) -> Tuple[bool, str]:
        """
        Add a point to the polyline.
        
        Args:
            northing: Northing coordinate as string
            easting: Easting coordinate as string
            elevation: Elevation as string
        
        Returns:
            (success, error_message)
        """
        # Validate inputs
        n_result = self.validate_coordinate(northing)
        if not n_result.is_valid:
            return (False, f"Invalid northing: {n_result.error_message}")
        
        e_result = self.validate_coordinate(easting)
        if not e_result.is_valid:
            return (False, f"Invalid easting: {e_result.error_message}")
        
        z_result = self.validate_elevation(elevation)
        if not z_result.is_valid:
            return (False, f"Invalid elevation: {z_result.error_message}")
        
        # Add point
        self.points.append((n_result.value, e_result.value, z_result.value))
        return (True, "")
    
    def remove_point(self, index: int) -> bool:
        """
        Remove a point at the given index.
        
        Args:
            index: Index of point to remove
        
        Returns:
            True if removed, False if invalid index
        """
        if 0 <= index < len(self.points):
            self.points.pop(index)
            return True
        return False
    
    def update_point(
        self,
        index: int,
        northing: str,
        easting: str,
        elevation: str
    ) -> Tuple[bool, str]:
        """
        Update a point at the given index.
        
        Args:
            index: Index of point to update
            northing: New northing value
            easting: New easting value
            elevation: New elevation value
        
        Returns:
            (success, error_message)
        """
        if not (0 <= index < len(self.points)):
            return (False, "Invalid point index")
        
        # Validate inputs
        n_result = self.validate_coordinate(northing)
        if not n_result.is_valid:
            return (False, f"Invalid northing: {n_result.error_message}")
        
        e_result = self.validate_coordinate(easting)
        if not e_result.is_valid:
            return (False, f"Invalid easting: {e_result.error_message}")
        
        z_result = self.validate_elevation(elevation)
        if not z_result.is_valid:
            return (False, f"Invalid elevation: {z_result.error_message}")
        
        # Update point
        self.points[index] = (n_result.value, e_result.value, z_result.value)
        return (True, "")
    
    def clear_points(self) -> None:
        """Clear all points."""
        self.points.clear()
    
    def get_point_count(self) -> int:
        """Get the number of points."""
        return len(self.points)
    
    def add_point_object(self, point: Point) -> None:
        """
        Add a Point object directly.
        
        Args:
            point: Point object to add
        """
        self.points.append((point.northing, point.easting, point.elevation))
    
    def get_points(self) -> List[Point]:
        """
        Get all points as Point objects.
        
        Returns:
            List of Point objects
        """
        return [
            Point(northing=n, easting=e, elevation=z)
            for n, e, z in self.points
        ]
    
    def move_point_up(self, index: int) -> bool:
        """
        Move a point up in the list (towards index 0).
        
        Args:
            index: Index of point to move
            
        Returns:
            True if moved, False if invalid index or already at top
        """
        if 0 < index < len(self.points):
            self.points[index], self.points[index - 1] = self.points[index - 1], self.points[index]
            return True
        return False
    
    def move_point_down(self, index: int) -> bool:
        """
        Move a point down in the list (towards end).
        
        Args:
            index: Index of point to move
            
        Returns:
            True if moved, False if invalid index or already at bottom
        """
        if 0 <= index < len(self.points) - 1:
            self.points[index], self.points[index + 1] = self.points[index + 1], self.points[index]
            return True
        return False
    
    def get_points_as_strings(self) -> List[Dict[str, str]]:
        """
        Get all points as string dictionaries for display.
        
        Returns:
            List of point dictionaries with string values
        """
        return [
            {
                'northing': str(n),
                'easting': str(e),
                'elevation': str(z)
            }
            for n, e, z in self.points
        ]
    
    def set_name(self, value: str) -> bool:
        """Set name value (optional)."""
        self.name = value.strip() if value.strip() else None
        return True
    
    def is_valid(self) -> Tuple[bool, str]:
        """
        Check if polyline is valid.
        
        Returns:
            (is_valid, error_message)
        """
        if len(self.points) < 2:
            return (False, "Polyline must have at least 2 points")
        return (True, "")
    
    def create_polyline(self) -> Optional[SimplePolyline]:
        """
        Create a SimplePolyline object from current points.
        
        Returns:
            SimplePolyline object if valid, None otherwise
        """
        is_valid, error = self.is_valid()
        if not is_valid:
            logger.warning(f"Cannot create polyline: {error}")
            return None
        
        # Create Point objects
        point_objects = [
            Point(northing=n, easting=e, elevation=z)
            for n, e, z in self.points
        ]
        
        try:
            return SimplePolyline(point_objects, name=self.name)
        except Exception as e:
            logger.error(f"Failed to create polyline: {e}")
            return None


class CircularArcDialogController:
    """
    Controller for CircularArc creation/editing dialog.
    
    Handles validation and CircularArc object creation/modification.
    A circular arc is defined by three points: center (radius point), start, and end.
    """
    
    def __init__(self):
        """Initialize the controller with validators."""
        self.coord_validator = CoordinateValidator()
        self.elevation_validator = ElevationValidator()
        
        # Center point (radius point)
        self.center_n: Optional[float] = None
        self.center_e: Optional[float] = None
        self.center_z: float = 0.0
        
        # Start point
        self.start_n: Optional[float] = None
        self.start_e: Optional[float] = None
        self.start_z: float = 0.0
        
        # End point
        self.end_n: Optional[float] = None
        self.end_e: Optional[float] = None
        self.end_z: float = 0.0
        
        # Optional name
        self.name: Optional[str] = None
        
        # For editing mode
        self.original_arc: Optional[CircularArc] = None
    
    def load_arc(self, arc: CircularArc) -> None:
        """
        Load an existing arc for editing.
        
        Args:
            arc: The arc to edit
        """
        self.original_arc = arc
        self.center_n = arc.radius_point.northing
        self.center_e = arc.radius_point.easting
        self.center_z = arc.radius_point.elevation
        self.start_n = arc.start_point.northing
        self.start_e = arc.start_point.easting
        self.start_z = arc.start_point.elevation
        self.end_n = arc.end_point.northing
        self.end_e = arc.end_point.easting
        self.end_z = arc.end_point.elevation
        self.name = arc.name
    
    def set_center_northing(self, value: str) -> bool:
        """Set center northing after validation."""
        result = self.coord_validator.validate(value)
        if result.is_valid:
            self.center_n = result.value
            return True
        return False
    
    def set_center_easting(self, value: str) -> bool:
        """Set center easting after validation."""
        result = self.coord_validator.validate(value)
        if result.is_valid:
            self.center_e = result.value
            return True
        return False
    
    def set_center_elevation(self, value: str) -> bool:
        """Set center elevation after validation."""
        result = self.elevation_validator.validate(value)
        if result.is_valid:
            self.center_z = result.value
            return True
        return False
    
    def set_start_northing(self, value: str) -> bool:
        """Set start northing after validation."""
        result = self.coord_validator.validate(value)
        if result.is_valid:
            self.start_n = result.value
            return True
        return False
    
    def set_start_easting(self, value: str) -> bool:
        """Set start easting after validation."""
        result = self.coord_validator.validate(value)
        if result.is_valid:
            self.start_e = result.value
            return True
        return False
    
    def set_start_elevation(self, value: str) -> bool:
        """Set start elevation after validation."""
        result = self.elevation_validator.validate(value)
        if result.is_valid:
            self.start_z = result.value
            return True
        return False
    
    def set_end_northing(self, value: str) -> bool:
        """Set end northing after validation."""
        result = self.coord_validator.validate(value)
        if result.is_valid:
            self.end_n = result.value
            return True
        return False
    
    def set_end_easting(self, value: str) -> bool:
        """Set end easting after validation."""
        result = self.coord_validator.validate(value)
        if result.is_valid:
            self.end_e = result.value
            return True
        return False
    
    def set_end_elevation(self, value: str) -> bool:
        """Set end elevation after validation."""
        result = self.elevation_validator.validate(value)
        if result.is_valid:
            self.end_z = result.value
            return True
        return False
    
    def get_center_values(self) -> Tuple[str, str, str]:
        """Get current center point values as strings for display."""
        return (
            str(self.center_n) if self.center_n is not None else "",
            str(self.center_e) if self.center_e is not None else "",
            str(self.center_z)
        )
    
    def get_start_values(self) -> Tuple[str, str, str]:
        """Get current start point values as strings for display."""
        return (
            str(self.start_n) if self.start_n is not None else "",
            str(self.start_e) if self.start_e is not None else "",
            str(self.start_z)
        )
    
    def get_end_values(self) -> Tuple[str, str, str]:
        """Get current end point values as strings for display."""
        return (
            str(self.end_n) if self.end_n is not None else "",
            str(self.end_e) if self.end_e is not None else "",
            str(self.end_z)
        )
    
    def set_name(self, value: str) -> bool:
        """Set name value (optional)."""
        self.name = value.strip() if value.strip() else None
        return True
    
    def create_arc(self) -> Optional[CircularArc]:
        """
        Create a CircularArc from current values.
        
        Returns:
            CircularArc object if successful, None otherwise
        """
        # Validate all required fields are set
        if any(v is None for v in [
            self.center_n, self.center_e,
            self.start_n, self.start_e,
            self.end_n, self.end_e
        ]):
            logger.error("Cannot create arc: missing required coordinates")
            return None
        
        try:
            from plana_figura.grid import Grid
            grid = Grid()
            
            # Create points
            center = Point(self.center_n, self.center_e, self.center_z, grid)
            start = Point(self.start_n, self.start_e, self.start_z, grid)
            end = Point(self.end_n, self.end_e, self.end_z, grid)
            
            # Create arc
            return CircularArc(center, start, end, grid, name=self.name)
        except Exception as e:
            logger.error(f"Failed to create circular arc: {e}")
            return None
