"""Measurement dialogs for adding/editing measurements."""

import tkinter as tk
import ttkbootstrap as ttk_boot
from typing import Optional
from plana_figura import Measurement, MeasurementType, DecimalDegreesAngle
from plana_figura_workbench.dialogs.measurement_dialog_controller import (
    AngleDialogController,
    DirectionDialogController,
    DistanceDialogController
)


class AddAngleDialog(tk.Toplevel):
    """Dialog for adding/editing angle measurements."""

    def __init__(self, parent, measurement: Optional[Measurement] = None, 
                 title: str = "Add Angle Measurement", 
                 measurement_type: MeasurementType = MeasurementType.HORIZONTAL_ANGLE, **kwargs):
        super().__init__(parent, **kwargs)
        self.result: Optional[Measurement] = None
        
        # Create controller
        self.controller = AngleDialogController()
        if measurement is not None:
            self.controller.load_measurement(measurement)
        elif measurement_type:
            self.controller.set_angle_type(measurement_type)
        
        self.title(title)
        self.geometry("450x400")
        self.resizable(False, False)
        
        self._create_widgets()
        
        # Load existing measurement if editing
        if measurement:
            self._load_measurement()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        row = 0
        
        # Type
        ttk_boot.Label(main_frame, text="Type:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.type_var = tk.StringVar()
        type_combo = ttk_boot.Combobox(
            main_frame,
            textvariable=self.type_var,
            values=["Horizontal Angle", "Vertical Angle", "Zenith Angle"],
            state="readonly",
            width=28
        )
        type_combo.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        type_combo.current(0)
        row += 1
        
        # Name
        ttk_boot.Label(main_frame, text="Name:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.name_entry = ttk_boot.Entry(main_frame, width=30)
        self.name_entry.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        # Decimal degrees
        ttk_boot.Label(main_frame, text="Decimal Degrees:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.decimal_entry = ttk_boot.Entry(main_frame, width=30)
        self.decimal_entry.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        self.decimal_entry.bind("<KeyRelease>", self._on_decimal_changed)
        row += 1
        
        # DMS
        dms_frame = ttk_boot.LabelFrame(main_frame, text="DMS (Degrees Minutes Seconds)", padding=10)
        dms_frame.grid(row=row, column=0, columnspan=2, sticky=tk.EW, pady=10)
        
        ttk_boot.Label(dms_frame, text="Degrees:").grid(row=0, column=0, sticky=tk.W, padx=5)
        self.deg_entry = ttk_boot.Entry(dms_frame, width=10)
        self.deg_entry.grid(row=0, column=1, padx=5)
        self.deg_entry.bind("<KeyRelease>", self._on_dms_changed)
        
        ttk_boot.Label(dms_frame, text="Minutes:").grid(row=0, column=2, sticky=tk.W, padx=5)
        self.min_entry = ttk_boot.Entry(dms_frame, width=10)
        self.min_entry.grid(row=0, column=3, padx=5)
        self.min_entry.bind("<KeyRelease>", self._on_dms_changed)
        
        ttk_boot.Label(dms_frame, text="Seconds:").grid(row=0, column=4, sticky=tk.W, padx=5)
        self.sec_entry = ttk_boot.Entry(dms_frame, width=10)
        self.sec_entry.grid(row=0, column=5, padx=5)
        self.sec_entry.bind("<KeyRelease>", self._on_dms_changed)
        row += 1
        
        # Description
        ttk_boot.Label(main_frame, text="Description:").grid(row=row, column=0, sticky=tk.NW, pady=5)
        self.description_text = tk.Text(main_frame, height=3, width=30)
        self.description_text.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        # Buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=row, column=0, columnspan=2, pady=20)
        ttk_boot.Button(button_frame, text="OK", command=self._on_ok, bootstyle="success", width=10).pack(side=tk.LEFT, padx=5)
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel, bootstyle="secondary", width=10).pack(side=tk.LEFT, padx=5)
        
        main_frame.columnconfigure(1, weight=1)
        
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _load_measurement(self) -> None:
        """Load existing measurement into dialog."""
        self.name_entry.insert(0, self.controller.get_name())
        self.type_var.set(self.controller.get_measurement_type().value)
        
        decimal = self.controller.get_decimal_degrees()
        if decimal is not None:
            self.decimal_entry.insert(0, str(decimal))
        
        desc = self.controller.get_description()
        if desc:
            self.description_text.insert("1.0", desc)
    
    def _on_decimal_changed(self, event=None) -> None:
        """Handle decimal degrees input change."""
        try:
            decimal_str = self.decimal_entry.get().strip()
            if decimal_str:
                result = self.controller.set_decimal_degrees(decimal_str)
                if result.is_valid:
                    # Update DMS
                    deg, min, sec = self.controller.get_dms()
                    self.deg_entry.delete(0, tk.END)
                    self.deg_entry.insert(0, str(deg))
                    self.min_entry.delete(0, tk.END)
                    self.min_entry.insert(0, str(min))
                    self.sec_entry.delete(0, tk.END)
                    self.sec_entry.insert(0, f"{sec:.2f}")
        except:
            pass
    
    def _on_dms_changed(self, event=None) -> None:
        """Handle DMS input change."""
        try:
            deg_str = self.deg_entry.get().strip()
            min_str = self.min_entry.get().strip()
            sec_str = self.sec_entry.get().strip()
            
            if deg_str or min_str or sec_str:
                result = self.controller.set_dms(deg_str, min_str, sec_str)
                if result.is_valid:
                    # Update decimal
                    decimal = self.controller.get_decimal_degrees()
                    if decimal is not None:
                        self.decimal_entry.delete(0, tk.END)
                        self.decimal_entry.insert(0, f"{decimal:.6f}")
        except:
            pass
    
    def _on_ok(self) -> None:
        """Handle OK button."""
        # Set values in controller
        self.controller.set_name(self.name_entry.get())
        self.controller.set_description(self.description_text.get("1.0", tk.END).strip())
        
        # Set type
        type_str = self.type_var.get()
        for mt in MeasurementType:
            if mt.value == type_str:
                self.controller.set_measurement_type(mt)
                break
        
        # Create measurement
        result = self.controller.create_measurement()
        if result.is_valid:
            self.result = result.value
            self.destroy()
        else:
            tk.messagebox.showerror("Error", result.error_message)
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()


class AddDirectionDialog(tk.Toplevel):
    """Dialog for adding/editing direction measurements."""

    def __init__(self, parent, measurement: Optional[Measurement] = None,
                 title: str = "Add Direction Measurement",
                 measurement_type: MeasurementType = MeasurementType.AZIMUTH, **kwargs):
        super().__init__(parent, **kwargs)
        self.result: Optional[Measurement] = None
        
        # Create controller
        self.controller = DirectionDialogController()
        if measurement is not None:
            self.controller.load_measurement(measurement)
        elif measurement_type:
            self.controller.set_direction_type(measurement_type)
        
        self.title(title)
        self.geometry("450x350")
        self.resizable(False, False)
        
        self._create_widgets()
        
        # Load existing measurement if editing
        if measurement:
            self._load_measurement()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        row = 0
        
        # Type
        ttk_boot.Label(main_frame, text="Type:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.type_var = tk.StringVar()
        type_combo = ttk_boot.Combobox(
            main_frame,
            textvariable=self.type_var,
            values=["Azimuth", "Bearing"],
            state="readonly",
            width=28
        )
        type_combo.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        type_combo.current(0)  # Default to Azimuth
        row += 1
        
        # Name
        ttk_boot.Label(main_frame, text="Name:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.name_entry = ttk_boot.Entry(main_frame, width=30)
        self.name_entry.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        # Decimal degrees
        ttk_boot.Label(main_frame, text="Decimal Degrees:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.decimal_entry = ttk_boot.Entry(main_frame, width=30)
        self.decimal_entry.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1

        # DMS input (optional)
        dms_frame = ttk_boot.LabelFrame(
            main_frame,
            text="DMS (Degrees Minutes Seconds)",
            padding=10
        )
        dms_frame.grid(row=row, column=0, columnspan=2, sticky=tk.EW, pady=10)

        ttk_boot.Label(dms_frame, text="Degrees:").grid(row=0, column=0, sticky=tk.W, padx=5)
        self.deg_entry = ttk_boot.Entry(dms_frame, width=8)
        self.deg_entry.grid(row=0, column=1, padx=5)

        ttk_boot.Label(dms_frame, text="Minutes:").grid(row=0, column=2, sticky=tk.W, padx=5)
        self.min_entry = ttk_boot.Entry(dms_frame, width=8)
        self.min_entry.grid(row=0, column=3, padx=5)

        ttk_boot.Label(dms_frame, text="Seconds:").grid(row=0, column=4, sticky=tk.W, padx=5)
        self.sec_entry = ttk_boot.Entry(dms_frame, width=8)
        self.sec_entry.grid(row=0, column=5, padx=5)
        row += 1
        
        # Bearing notation
        bearing_frame = ttk_boot.LabelFrame(main_frame, text="Bearing Notation (e.g., N 45 30 15 E)", padding=10)
        bearing_frame.grid(row=row, column=0, columnspan=2, sticky=tk.EW, pady=10)
        
        self.bearing_entry = ttk_boot.Entry(bearing_frame, width=40)
        self.bearing_entry.pack(fill=tk.X, padx=5, pady=5)
        
        ttk_boot.Button(
            bearing_frame,
            text="Convert to Azimuth",
            command=self._on_convert_bearing,
            bootstyle="info"
        ).pack(pady=5)
        row += 1
        
        # Description
        ttk_boot.Label(main_frame, text="Description:").grid(row=row, column=0, sticky=tk.NW, pady=5)
        self.description_text = tk.Text(main_frame, height=3, width=30)
        self.description_text.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        # Buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=row, column=0, columnspan=2, pady=20)
        ttk_boot.Button(button_frame, text="OK", command=self._on_ok, bootstyle="success", width=10).pack(side=tk.LEFT, padx=5)
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel, bootstyle="secondary", width=10).pack(side=tk.LEFT, padx=5)
        
        main_frame.columnconfigure(1, weight=1)
        
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _load_measurement(self) -> None:
        """Load existing measurement into dialog."""
        self.name_entry.insert(0, self.controller.get_name())
        self.type_var.set(self.controller.get_measurement_type().value)
        
        decimal = self.controller.get_decimal_degrees()
        if decimal is not None:
            self.decimal_entry.insert(0, str(decimal))
        
        desc = self.controller.get_description()
        if desc:
            self.description_text.insert("1.0", desc)
    
    def _on_convert_bearing(self) -> None:
        """Convert bearing notation to azimuth."""
        bearing_str = self.bearing_entry.get().strip()
        if not bearing_str:
            tk.messagebox.showwarning("Warning", "Please enter a bearing notation")
            return
        
        result = self.controller.convert_bearing_to_azimuth(bearing_str)
        if result.is_valid:
            azimuth = result.value
            self.decimal_entry.delete(0, tk.END)
            self.decimal_entry.insert(0, f"{azimuth:.6f}")
            tk.messagebox.showinfo("Success", f"Bearing converted to azimuth: {azimuth:.6f}°")
        else:
            tk.messagebox.showerror("Error", result.error_message)
    
    def _on_ok(self) -> None:
        """Handle OK button."""
        # Set values in controller
        self.controller.set_name(self.name_entry.get())

        # If DMS values are provided, use them to compute decimal degrees
        deg_str = self.deg_entry.get().strip() if hasattr(self, 'deg_entry') else ""
        min_str = self.min_entry.get().strip() if hasattr(self, 'min_entry') else ""
        sec_str = self.sec_entry.get().strip() if hasattr(self, 'sec_entry') else ""

        decimal_value = None
        if deg_str or min_str or sec_str:
            try:
                deg = float(deg_str) if deg_str else 0.0
                minutes = float(min_str) if min_str else 0.0
                seconds = float(sec_str) if sec_str else 0.0
                decimal_value = deg + (minutes / 60.0) + (seconds / 3600.0)
            except ValueError:
                decimal_value = None

        if decimal_value is not None:
            self.controller.set_decimal_degrees(str(decimal_value))
        else:
            self.controller.set_decimal_degrees(self.decimal_entry.get())

        self.controller.set_description(self.description_text.get("1.0", tk.END).strip())
        
        # Set type
        type_str = self.type_var.get()
        for mt in MeasurementType:
            if mt.value == type_str:
                self.controller.set_measurement_type(mt)
                break
        
        # Create measurement
        result = self.controller.create_measurement()
        if result.is_valid:
            self.result = result.value
            self.destroy()
        else:
            tk.messagebox.showerror("Error", result.error_message)
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()


class AddDistanceDialog(tk.Toplevel):
    """Dialog for adding/editing distance measurements."""

    def __init__(self, parent, measurement: Optional[Measurement] = None,
                 title: str = "Add Distance Measurement", **kwargs):
        super().__init__(parent, **kwargs)
        self.result: Optional[Measurement] = None
        
        # Create controller
        self.controller = DistanceDialogController()
        if measurement is not None:
            self.controller.load_measurement(measurement)
        
        self.title(title)
        self.geometry("400x300")
        self.resizable(False, False)
        
        self._create_widgets()
        
        # Load existing measurement if editing
        if measurement:
            self._load_measurement()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        row = 0
        
        # Name
        ttk_boot.Label(main_frame, text="Name:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.name_entry = ttk_boot.Entry(main_frame, width=30)
        self.name_entry.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        # Type
        ttk_boot.Label(main_frame, text="Type:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.type_var = tk.StringVar()
        type_combo = ttk_boot.Combobox(
            main_frame,
            textvariable=self.type_var,
            values=["Horizontal Distance", "Slope Distance", "Vertical Distance"],
            state="readonly",
            width=28
        )
        type_combo.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        type_combo.current(0)
        row += 1
        
        # Distance value
        ttk_boot.Label(main_frame, text="Distance:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.distance_entry = ttk_boot.Entry(main_frame, width=30)
        self.distance_entry.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        # Description
        ttk_boot.Label(main_frame, text="Description:").grid(row=row, column=0, sticky=tk.NW, pady=5)
        self.description_text = tk.Text(main_frame, height=3, width=30)
        self.description_text.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        # Buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=row, column=0, columnspan=2, pady=20)
        ttk_boot.Button(button_frame, text="OK", command=self._on_ok, bootstyle="success", width=10).pack(side=tk.LEFT, padx=5)
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel, bootstyle="secondary", width=10).pack(side=tk.LEFT, padx=5)
        
        main_frame.columnconfigure(1, weight=1)
        
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _load_measurement(self) -> None:
        """Load existing measurement into dialog."""
        self.name_entry.insert(0, self.controller.get_name())
        self.type_var.set(self.controller.get_measurement_type().value)
        
        distance = self.controller.get_distance()
        if distance is not None:
            self.distance_entry.insert(0, str(distance))
        
        desc = self.controller.get_description()
        if desc:
            self.description_text.insert("1.0", desc)
    
    def _on_ok(self) -> None:
        """Handle OK button."""
        # Set values in controller
        self.controller.set_name(self.name_entry.get())
        self.controller.set_value(self.distance_entry.get())
        self.controller.set_description(self.description_text.get("1.0", tk.END).strip())
        
        # Set type
        type_str = self.type_var.get()
        for mt in MeasurementType:
            if mt.value == type_str:
                self.controller.set_measurement_type(mt)
                break
        
        # Create measurement
        result = self.controller.create_measurement()
        if result.is_valid:
            self.result = result.value
            self.destroy()
        else:
            tk.messagebox.showerror("Error", result.error_message)
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()
