"""
Transformation dialogs for geometry manipulation.

Modal dialogs for translate, rotate, scale, and mirror operations.
Uses surveying conventions (Northing/Easting/Elevation, DMS angles).
"""

import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from typing import Optional, Tuple

from plana_figura_workbench.dialogs.transform_dialog_controller import (
    TranslateDialogController,
    RotateDialogController,
    ScaleDialogController,
    MirrorDialogController,
)


class TranslateDialog(ttk.Toplevel):
    """
    Modal dialog for translating (moving) geometry.
    
    Uses surveying conventions:
    - Delta Northing (change in Y/North direction)
    - Delta Easting (change in X/East direction)
    - Delta Elevation (change in Z/height)
    """
    
    def __init__(self, parent, title="Translate Geometry"):
        """
        Initialize the translate dialog.
        
        Args:
            parent: Parent window
            title: Dialog title
        """
        super().__init__(parent, title=title)
        
        self.controller = TranslateDialogController()
        self.result: Optional[Tuple[float, float, float]] = None
        
        self._setup_ui()
        self._center_dialog()
        
        # Make modal
        self.transient(parent)
        self.grab_set()
        
        # Focus first entry
        self.delta_northing_entry.focus()
    
    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Main frame with padding
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=BOTH, expand=YES)
        
        # Title label
        title_label = ttk.Label(
            main_frame,
            text="Enter translation deltas:",
            font=("Segoe UI", 10, "bold")
        )
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 15), sticky=W)
        
        # Delta Northing
        ttk.Label(main_frame, text="Δ Northing:").grid(
            row=1, column=0, sticky=W, pady=5
        )
        self.delta_northing_entry = ttk.Entry(main_frame, width=20)
        self.delta_northing_entry.grid(row=1, column=1, sticky=EW, pady=5, padx=5)
        self.delta_northing_entry.insert(0, "0.0")
        ttk.Label(main_frame, text="(units)").grid(
            row=1, column=2, sticky=W, pady=5
        )
        
        # Delta Easting
        ttk.Label(main_frame, text="Δ Easting:").grid(
            row=2, column=0, sticky=W, pady=5
        )
        self.delta_easting_entry = ttk.Entry(main_frame, width=20)
        self.delta_easting_entry.grid(row=2, column=1, sticky=EW, pady=5, padx=5)
        self.delta_easting_entry.insert(0, "0.0")
        ttk.Label(main_frame, text="(units)").grid(
            row=2, column=2, sticky=W, pady=5
        )
        
        # Delta Elevation
        ttk.Label(main_frame, text="Δ Elevation:").grid(
            row=3, column=0, sticky=W, pady=5
        )
        self.delta_elevation_entry = ttk.Entry(main_frame, width=20)
        self.delta_elevation_entry.grid(row=3, column=1, sticky=EW, pady=5, padx=5)
        self.delta_elevation_entry.insert(0, "0.0")
        ttk.Label(main_frame, text="(units)").grid(
            row=3, column=2, sticky=W, pady=5
        )
        
        # Validation labels
        self.validation_label = ttk.Label(
            main_frame,
            text="",
            foreground="red",
            font=("Segoe UI", 9)
        )
        self.validation_label.grid(
            row=4, column=0, columnspan=3, pady=(10, 0), sticky=W
        )
        
        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=5, column=0, columnspan=3, pady=(20, 0))
        
        # OK button
        self.ok_button = ttk.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle=SUCCESS,
            width=10
        )
        self.ok_button.pack(side=LEFT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            width=10
        )
        cancel_button.pack(side=LEFT, padx=5)
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        
        # Bind Enter and Escape keys
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _center_dialog(self) -> None:
        """Center the dialog on the parent window."""
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
    
    def _on_ok(self) -> None:
        """Handle OK button click."""
        # Get values
        dn = self.delta_northing_entry.get()
        de = self.delta_easting_entry.get()
        dz = self.delta_elevation_entry.get()
        
        # Validate and set
        if not self.controller.set_delta_northing(dn):
            self.validation_label.config(
                text="Invalid Delta Northing"
            )
            return
        
        if not self.controller.set_delta_easting(de):
            self.validation_label.config(
                text="Invalid Delta Easting"
            )
            return
        
        if not self.controller.set_delta_elevation(dz):
            self.validation_label.config(
                text="Invalid Delta Elevation"
            )
            return
        
        # Check if valid (at least one non-zero)
        if not self.controller.is_valid():
            self.validation_label.config(
                text="At least one delta must be non-zero"
            )
            return
        
        # Get result
        self.result = self.controller.get_deltas()
        self.destroy()
    
    def _on_cancel(self) -> None:
        """Handle Cancel button click."""
        self.result = None
        self.destroy()


class RotateDialog(ttk.Toplevel):
    """
    Modal dialog for rotating geometry.
    
    Uses surveying conventions:
    - Center point in Northing/Easting
    - Angle in Degrees-Minutes-Seconds (DMS) format
    - Clockwise/Counter-clockwise direction
    """
    
    def __init__(self, parent, title="Rotate Geometry"):
        """
        Initialize the rotate dialog.
        
        Args:
            parent: Parent window
            title: Dialog title
        """
        super().__init__(parent, title=title)
        
        self.controller = RotateDialogController()
        self.result: Optional[Tuple[Tuple[float, float], float]] = None
        
        self._setup_ui()
        self._center_dialog()
        
        # Make modal
        self.transient(parent)
        self.grab_set()
        
        # Focus first entry
        self.center_northing_entry.focus()
    
    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Main frame with padding
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=BOTH, expand=YES)
        
        # Title label
        title_label = ttk.Label(
            main_frame,
            text="Enter rotation parameters:",
            font=("Segoe UI", 10, "bold")
        )
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 15), sticky=W)
        
        # Center Point section
        center_label = ttk.Label(
            main_frame,
            text="Center Point:",
            font=("Segoe UI", 9, "bold")
        )
        center_label.grid(row=1, column=0, columnspan=3, sticky=W, pady=(10, 5))
        
        # Center Northing
        ttk.Label(main_frame, text="Northing:").grid(
            row=2, column=0, sticky=W, pady=5
        )
        self.center_northing_entry = ttk.Entry(main_frame, width=20)
        self.center_northing_entry.grid(row=2, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=2, column=2, sticky=W, pady=5
        )
        
        # Center Easting
        ttk.Label(main_frame, text="Easting:").grid(
            row=3, column=0, sticky=W, pady=5
        )
        self.center_easting_entry = ttk.Entry(main_frame, width=20)
        self.center_easting_entry.grid(row=3, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=3, column=2, sticky=W, pady=5
        )
        
        # Angle section
        angle_label = ttk.Label(
            main_frame,
            text="Rotation Angle (DMS):",
            font=("Segoe UI", 9, "bold")
        )
        angle_label.grid(row=4, column=0, columnspan=3, sticky=W, pady=(15, 5))
        
        # Degrees
        ttk.Label(main_frame, text="Degrees:").grid(
            row=5, column=0, sticky=W, pady=5
        )
        self.degrees_entry = ttk.Entry(main_frame, width=20)
        self.degrees_entry.grid(row=5, column=1, sticky=EW, pady=5, padx=5)
        self.degrees_entry.insert(0, "0")
        ttk.Label(main_frame, text="°").grid(
            row=5, column=2, sticky=W, pady=5
        )
        
        # Minutes
        ttk.Label(main_frame, text="Minutes:").grid(
            row=6, column=0, sticky=W, pady=5
        )
        self.minutes_entry = ttk.Entry(main_frame, width=20)
        self.minutes_entry.grid(row=6, column=1, sticky=EW, pady=5, padx=5)
        self.minutes_entry.insert(0, "0")
        ttk.Label(main_frame, text="'").grid(
            row=6, column=2, sticky=W, pady=5
        )
        
        # Seconds
        ttk.Label(main_frame, text="Seconds:").grid(
            row=7, column=0, sticky=W, pady=5
        )
        self.seconds_entry = ttk.Entry(main_frame, width=20)
        self.seconds_entry.grid(row=7, column=1, sticky=EW, pady=5, padx=5)
        self.seconds_entry.insert(0, "0.0")
        ttk.Label(main_frame, text="\"").grid(
            row=7, column=2, sticky=W, pady=5
        )
        
        # Direction
        direction_frame = ttk.Frame(main_frame)
        direction_frame.grid(row=8, column=0, columnspan=3, pady=(10, 0), sticky=W)
        
        ttk.Label(direction_frame, text="Direction:").pack(side=LEFT, padx=(0, 10))
        
        self.direction_var = tk.StringVar(value="CW")
        ttk.Radiobutton(
            direction_frame,
            text="Clockwise",
            variable=self.direction_var,
            value="CW"
        ).pack(side=LEFT, padx=5)
        ttk.Radiobutton(
            direction_frame,
            text="Counter-Clockwise",
            variable=self.direction_var,
            value="CCW"
        ).pack(side=LEFT, padx=5)
        
        # Validation labels
        self.validation_label = ttk.Label(
            main_frame,
            text="",
            foreground="red",
            font=("Segoe UI", 9)
        )
        self.validation_label.grid(
            row=9, column=0, columnspan=3, pady=(10, 0), sticky=W
        )
        
        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=10, column=0, columnspan=3, pady=(20, 0))
        
        # OK button
        self.ok_button = ttk.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle=SUCCESS,
            width=10
        )
        self.ok_button.pack(side=LEFT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            width=10
        )
        cancel_button.pack(side=LEFT, padx=5)
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        
        # Bind Enter and Escape keys
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _center_dialog(self) -> None:
        """Center the dialog on the parent window."""
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
    
    def _on_ok(self) -> None:
        """Handle OK button click."""
        # Get values
        cn = self.center_northing_entry.get()
        ce = self.center_easting_entry.get()
        deg = self.degrees_entry.get()
        mins = self.minutes_entry.get()
        secs = self.seconds_entry.get()
        direction = self.direction_var.get()
        
        # Validate and set center
        if not self.controller.set_center_northing(cn):
            self.validation_label.config(
                text="Invalid Center Northing"
            )
            return
        
        if not self.controller.set_center_easting(ce):
            self.validation_label.config(
                text="Invalid Center Easting"
            )
            return
        
        # Validate and set angle
        if not self.controller.set_degrees(deg):
            self.validation_label.config(
                text="Invalid Degrees (must be -360 to 360)"
            )
            return
        
        if not self.controller.set_minutes(mins):
            self.validation_label.config(
                text="Invalid Minutes (must be 0-59)"
            )
            return
        
        if not self.controller.set_seconds(secs):
            self.validation_label.config(
                text="Invalid Seconds (must be 0-59.999)"
            )
            return
        
        # Set direction
        self.controller.set_clockwise(direction == "CW")
        
        # Check if valid
        if not self.controller.is_valid():
            self.validation_label.config(
                text="Angle must be non-zero"
            )
            return
        
        # Get result (center point, angle in decimal degrees)
        center = self.controller.get_center()
        angle = self.controller.get_angle_decimal()
        self.result = (center, angle)
        self.destroy()
    
    def _on_cancel(self) -> None:
        """Handle Cancel button click."""
        self.result = None
        self.destroy()


class ScaleDialog(ttk.Toplevel):
    """
    Modal dialog for scaling geometry.
    
    Uses surveying conventions:
    - Center point in Northing/Easting
    - Scale factor (multiplier)
    """
    
    def __init__(self, parent, title="Scale Geometry"):
        """
        Initialize the scale dialog.
        
        Args:
            parent: Parent window
            title: Dialog title
        """
        super().__init__(parent, title=title)
        
        self.controller = ScaleDialogController()
        self.result: Optional[Tuple[Tuple[float, float], float]] = None
        
        self._setup_ui()
        self._center_dialog()
        
        # Make modal
        self.transient(parent)
        self.grab_set()
        
        # Focus first entry
        self.center_northing_entry.focus()
    
    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Main frame with padding
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=BOTH, expand=YES)
        
        # Title label
        title_label = ttk.Label(
            main_frame,
            text="Enter scale parameters:",
            font=("Segoe UI", 10, "bold")
        )
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 15), sticky=W)
        
        # Center Point section
        center_label = ttk.Label(
            main_frame,
            text="Center Point:",
            font=("Segoe UI", 9, "bold")
        )
        center_label.grid(row=1, column=0, columnspan=3, sticky=W, pady=(10, 5))
        
        # Center Northing
        ttk.Label(main_frame, text="Northing:").grid(
            row=2, column=0, sticky=W, pady=5
        )
        self.center_northing_entry = ttk.Entry(main_frame, width=20)
        self.center_northing_entry.grid(row=2, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=2, column=2, sticky=W, pady=5
        )
        
        # Center Easting
        ttk.Label(main_frame, text="Easting:").grid(
            row=3, column=0, sticky=W, pady=5
        )
        self.center_easting_entry = ttk.Entry(main_frame, width=20)
        self.center_easting_entry.grid(row=3, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=3, column=2, sticky=W, pady=5
        )
        
        # Scale Factor section
        scale_label = ttk.Label(
            main_frame,
            text="Scale Factor:",
            font=("Segoe UI", 9, "bold")
        )
        scale_label.grid(row=4, column=0, columnspan=3, sticky=W, pady=(15, 5))
        
        # Scale Factor
        ttk.Label(main_frame, text="Factor:").grid(
            row=5, column=0, sticky=W, pady=5
        )
        self.scale_factor_entry = ttk.Entry(main_frame, width=20)
        self.scale_factor_entry.grid(row=5, column=1, sticky=EW, pady=5, padx=5)
        self.scale_factor_entry.insert(0, "1.0")
        ttk.Label(main_frame, text="(>0, ≠1)").grid(
            row=5, column=2, sticky=W, pady=5
        )
        
        # Help text
        help_label = ttk.Label(
            main_frame,
            text="Examples: 2.0 = double size, 0.5 = half size",
            font=("Segoe UI", 8),
            foreground="gray"
        )
        help_label.grid(row=6, column=0, columnspan=3, sticky=W, pady=(5, 0))
        
        # Validation labels
        self.validation_label = ttk.Label(
            main_frame,
            text="",
            foreground="red",
            font=("Segoe UI", 9)
        )
        self.validation_label.grid(
            row=7, column=0, columnspan=3, pady=(10, 0), sticky=W
        )
        
        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=8, column=0, columnspan=3, pady=(20, 0))
        
        # OK button
        self.ok_button = ttk.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle=SUCCESS,
            width=10
        )
        self.ok_button.pack(side=LEFT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            width=10
        )
        cancel_button.pack(side=LEFT, padx=5)
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        
        # Bind Enter and Escape keys
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _center_dialog(self) -> None:
        """Center the dialog on the parent window."""
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
    
    def _on_ok(self) -> None:
        """Handle OK button click."""
        # Get values
        cn = self.center_northing_entry.get()
        ce = self.center_easting_entry.get()
        sf = self.scale_factor_entry.get()
        
        # Validate and set center
        if not self.controller.set_center_northing(cn):
            self.validation_label.config(
                text="Invalid Center Northing"
            )
            return
        
        if not self.controller.set_center_easting(ce):
            self.validation_label.config(
                text="Invalid Center Easting"
            )
            return
        
        # Validate and set scale factor
        if not self.controller.set_scale_factor(sf):
            result = self.controller.validate_scale_factor(sf)
            self.validation_label.config(
                text=result.error_message or "Invalid Scale Factor"
            )
            return
        
        # Check if valid
        if not self.controller.is_valid():
            self.validation_label.config(
                text="Invalid parameters"
            )
            return
        
        # Get result (center point, scale factor)
        center = self.controller.get_center()
        factor = self.controller.get_scale_factor()
        self.result = (center, factor)
        self.destroy()
    
    def _on_cancel(self) -> None:
        """Handle Scale dialog Cancel button click."""
        self.result = None
        self.destroy()


class MirrorDialog(ttk.Toplevel):
    """
    Modal dialog for mirroring geometry.
    
    Uses surveying conventions:
    - Mirror line defined by two points (Northing/Easting)
    """
    
    def __init__(self, parent, title="Mirror Geometry"):
        """
        Initialize the mirror dialog.
        
        Args:
            parent: Parent window
            title: Dialog title
        """
        super().__init__(parent, title=title)
        
        self.controller = MirrorDialogController()
        self.result: Optional[Tuple[Tuple[float, float], Tuple[float, float]]] = None
        
        self._setup_ui()
        self._center_dialog()
        
        # Make modal
        self.transient(parent)
        self.grab_set()
        
        # Focus first entry
        self.point1_northing_entry.focus()
    
    def _setup_ui(self) -> None:
        """Set up the user interface."""
        # Main frame with padding
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=BOTH, expand=YES)
        
        # Title label
        title_label = ttk.Label(
            main_frame,
            text="Define mirror line with two points:",
            font=("Segoe UI", 10, "bold")
        )
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 15), sticky=W)
        
        # Point 1 section
        point1_label = ttk.Label(
            main_frame,
            text="Point 1:",
            font=("Segoe UI", 9, "bold")
        )
        point1_label.grid(row=1, column=0, columnspan=3, sticky=W, pady=(10, 5))
        
        # Point 1 Northing
        ttk.Label(main_frame, text="Northing:").grid(
            row=2, column=0, sticky=W, pady=5
        )
        self.point1_northing_entry = ttk.Entry(main_frame, width=20)
        self.point1_northing_entry.grid(row=2, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=2, column=2, sticky=W, pady=5
        )
        
        # Point 1 Easting
        ttk.Label(main_frame, text="Easting:").grid(
            row=3, column=0, sticky=W, pady=5
        )
        self.point1_easting_entry = ttk.Entry(main_frame, width=20)
        self.point1_easting_entry.grid(row=3, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=3, column=2, sticky=W, pady=5
        )
        
        # Point 2 section
        point2_label = ttk.Label(
            main_frame,
            text="Point 2:",
            font=("Segoe UI", 9, "bold")
        )
        point2_label.grid(row=4, column=0, columnspan=3, sticky=W, pady=(15, 5))
        
        # Point 2 Northing
        ttk.Label(main_frame, text="Northing:").grid(
            row=5, column=0, sticky=W, pady=5
        )
        self.point2_northing_entry = ttk.Entry(main_frame, width=20)
        self.point2_northing_entry.grid(row=5, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=5, column=2, sticky=W, pady=5
        )
        
        # Point 2 Easting
        ttk.Label(main_frame, text="Easting:").grid(
            row=6, column=0, sticky=W, pady=5
        )
        self.point2_easting_entry = ttk.Entry(main_frame, width=20)
        self.point2_easting_entry.grid(row=6, column=1, sticky=EW, pady=5, padx=5)
        ttk.Label(main_frame, text="(units)").grid(
            row=6, column=2, sticky=W, pady=5
        )
        
        # Help text
        help_label = ttk.Label(
            main_frame,
            text="Geometry will be reflected across the line between these points",
            font=("Segoe UI", 8),
            foreground="gray"
        )
        help_label.grid(row=7, column=0, columnspan=3, sticky=W, pady=(10, 0))
        
        # Validation labels
        self.validation_label = ttk.Label(
            main_frame,
            text="",
            foreground="red",
            font=("Segoe UI", 9)
        )
        self.validation_label.grid(
            row=8, column=0, columnspan=3, pady=(10, 0), sticky=W
        )
        
        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=9, column=0, columnspan=3, pady=(20, 0))
        
        # OK button
        self.ok_button = ttk.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle=SUCCESS,
            width=10
        )
        self.ok_button.pack(side=LEFT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            width=10
        )
        cancel_button.pack(side=LEFT, padx=5)
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        
        # Bind Enter and Escape keys
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _center_dialog(self) -> None:
        """Center the dialog on the parent window."""
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
    
    def _on_ok(self) -> None:
        """Handle OK button click."""
        # Get values
        p1n = self.point1_northing_entry.get()
        p1e = self.point1_easting_entry.get()
        p2n = self.point2_northing_entry.get()
        p2e = self.point2_easting_entry.get()
        
        # Validate and set point 1
        if not self.controller.set_point1_northing(p1n):
            self.validation_label.config(
                text="Invalid Point 1 Northing"
            )
            return
        
        if not self.controller.set_point1_easting(p1e):
            self.validation_label.config(
                text="Invalid Point 1 Easting"
            )
            return
        
        # Validate and set point 2
        if not self.controller.set_point2_northing(p2n):
            self.validation_label.config(
                text="Invalid Point 2 Northing"
            )
            return
        
        if not self.controller.set_point2_easting(p2e):
            self.validation_label.config(
                text="Invalid Point 2 Easting"
            )
            return
        
        # Check if valid
        if not self.controller.is_valid():
            self.validation_label.config(
                text="Points must be different (not coincident)"
            )
            return
        
        # Get result (two points defining the mirror line)
        self.result = self.controller.get_mirror_line()
        self.destroy()
    
    def _on_cancel(self) -> None:
        """Handle Mirror dialog Cancel button click."""
        self.result = None
        self.destroy()
