"""
Geometry transformation dialogs using measurement objects.

These dialogs allow users to transform geometries using measurement values,
providing UI access to transformation functions with measurements.
"""

import tkinter as tk
import ttkbootstrap as ttk_boot
from typing import Optional, List, Tuple, Any
import logging
import math

from plana_figura import (
    Point, LineSegment, SimplePolyline, SimplePolygon,
    Measurement, MeasurementType, DecimalDegreesAngle, SurveyorsDirection,
    Vector2D, Vector3D
)
from plana_figura.geometry_builders import (
    extend_line_segment,
    rotate_line_segment,
    offset_line_segment
)

logger = logging.getLogger(__name__)


def extract_direction_from_measurement(measurement: Measurement) -> SurveyorsDirection:
    """Extract a SurveyorsDirection from a direction/azimuth/bearing measurement."""
    if measurement.measurement_type not in [
        MeasurementType.DIRECTION,
        MeasurementType.AZIMUTH,
        MeasurementType.BEARING
    ]:
        raise ValueError(f"Measurement {measurement.name} is not a direction type")
    
    return SurveyorsDirection(measurement.value)


def extract_distance_from_measurement(measurement: Measurement) -> float:
    """Extract a distance value from a distance measurement."""
    if measurement.measurement_type not in [
        MeasurementType.DISTANCE,
        MeasurementType.HORIZONTAL_DISTANCE,
        MeasurementType.SLOPE_DISTANCE,
        MeasurementType.VERTICAL_DISTANCE
    ]:
        raise ValueError(f"Measurement {measurement.name} is not a distance type")
    
    return float(measurement.value)


def extract_vector_from_measurement(measurement: Measurement) -> Vector3D:
    """Extract a Vector3D from a 3D vector measurement."""
    if measurement.measurement_type != MeasurementType.VECTOR_3D:
        raise ValueError(f"Measurement {measurement.name} is not a 3D vector type")
    
    northing, easting, elevation = measurement.value
    return Vector3D(northing, easting, elevation)


def extract_angle_from_measurement(measurement: Measurement) -> DecimalDegreesAngle:
    """Extract a DecimalDegreesAngle from an angle measurement."""
    if measurement.measurement_type not in [
        MeasurementType.HORIZONTAL_ANGLE,
        MeasurementType.VERTICAL_ANGLE,
        MeasurementType.ZENITH_ANGLE
    ]:
        raise ValueError(f"Measurement {measurement.name} is not an angle type")
    
    return measurement.value


class TransformGeometryWithMeasurementsDialog(ttk_boot.Toplevel):
    """
    Dialog for transforming geometry using measurements.
    
    Supports:
    - Move by vector measurement
    - Rotate by angle measurement (around a point)
    - Scale by distance measurement
    - Offset by distance measurement
    """
    
    def __init__(self, parent, geometry: Any, measurements: List[Measurement]):
        super().__init__(parent)
        self.title("Transform Geometry with Measurements")
        self.geometry("550x600")
        self.resizable(False, False)
        
        self.geometry = geometry
        self.measurements = measurements
        self.result_geometry: Optional[Any] = None
        self.transformation_type = tk.StringVar(value="move")
        
        self._create_widgets()
        self._setup_bindings()
        self._update_preview()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self):
        """Create the dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk_boot.Label(
            main_frame,
            text="Transform Geometry Using Measurements",
            font=("TkDefaultFont", 12, "bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Transformation type selection
        type_frame = ttk_boot.LabelFrame(main_frame, text="Transformation Type", padding=5)
        type_frame.pack(fill=tk.X, pady=5)
        
        ttk_boot.Radiobutton(
            type_frame, text="Move by Vector", 
            variable=self.transformation_type, value="move",
            command=self._on_type_change
        ).pack(anchor=tk.W, pady=2)
        
        ttk_boot.Radiobutton(
            type_frame, text="Rotate by Angle", 
            variable=self.transformation_type, value="rotate",
            command=self._on_type_change
        ).pack(anchor=tk.W, pady=2)
        
        ttk_boot.Radiobutton(
            type_frame, text="Scale by Distance", 
            variable=self.transformation_type, value="scale",
            command=self._on_type_change
        ).pack(anchor=tk.W, pady=2)
        
        ttk_boot.Radiobutton(
            type_frame, text="Offset by Distance", 
            variable=self.transformation_type, value="offset",
            command=self._on_type_change
        ).pack(anchor=tk.W, pady=2)
        
        # Measurement selection frame (dynamic content)
        self.measurement_frame = ttk_boot.LabelFrame(main_frame, text="Measurement", padding=5)
        self.measurement_frame.pack(fill=tk.X, pady=5)
        
        # Options frame (dynamic content)
        self.options_frame = ttk_boot.LabelFrame(main_frame, text="Options", padding=5)
        self.options_frame.pack(fill=tk.X, pady=5)
        
        # Result preview
        preview_frame = ttk_boot.LabelFrame(main_frame, text="Result Preview", padding=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.result_text = tk.Text(preview_frame, height=8, width=60, state=tk.DISABLED)
        self.result_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)
        
        # Error label
        self.error_label = ttk_boot.Label(main_frame, text="", foreground="red")
        self.error_label.pack(pady=5)
        
        # Button frame
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.ok_button = ttk_boot.Button(button_frame, text="OK", command=self._on_ok, style="success.TButton")
        self.ok_button.pack(side=tk.RIGHT, padx=5)
        
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT, padx=5)
        
        # Initialize dynamic content
        self._on_type_change()
        
    def _setup_bindings(self):
        """Setup event bindings."""
        # Keyboard shortcuts
        self.bind('<Return>', lambda e: self._on_ok())
        self.bind('<Escape>', lambda e: self._on_cancel())
    
    def _on_type_change(self):
        """Handle transformation type change."""
        # Clear existing widgets
        for widget in self.measurement_frame.winfo_children():
            widget.destroy()
        for widget in self.options_frame.winfo_children():
            widget.destroy()
        
        trans_type = self.transformation_type.get()
        
        if trans_type == "move":
            self._create_move_widgets()
        elif trans_type == "rotate":
            self._create_rotate_widgets()
        elif trans_type == "scale":
            self._create_scale_widgets()
        elif trans_type == "offset":
            self._create_offset_widgets()
        
        self._update_preview()
    
    def _create_move_widgets(self):
        """Create widgets for move transformation."""
        ttk_boot.Label(self.measurement_frame, text="Vector Measurement:").pack(anchor=tk.W, pady=2)
        
        self.move_vector_var = tk.StringVar()
        self.move_vector_combo = ttk_boot.Combobox(
            self.measurement_frame,
            textvariable=self.move_vector_var,
            state="readonly"
        )
        self.move_vector_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Populate vector measurements
        vector_measurements = [
            m.name for m in self.measurements
            if m.measurement_type == MeasurementType.VECTOR_3D
        ]
        self.move_vector_combo['values'] = vector_measurements
        self._vector_measurements = {
            m.name: m for m in self.measurements
            if m.measurement_type == MeasurementType.VECTOR_3D
        }
        
        if vector_measurements:
            self.move_vector_combo.current(0)
        
        self.move_vector_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
    
    def _create_rotate_widgets(self):
        """Create widgets for rotate transformation."""
        # Angle measurement
        ttk_boot.Label(self.measurement_frame, text="Angle Measurement:").pack(anchor=tk.W, pady=2)
        
        self.rotate_angle_var = tk.StringVar()
        self.rotate_angle_combo = ttk_boot.Combobox(
            self.measurement_frame,
            textvariable=self.rotate_angle_var,
            state="readonly"
        )
        self.rotate_angle_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Rotation center
        ttk_boot.Label(self.options_frame, text="Rotation Center:").pack(anchor=tk.W, pady=2)
        center_frame = ttk_boot.Frame(self.options_frame)
        center_frame.pack(fill=tk.X, padx=5, pady=2)
        
        ttk_boot.Label(center_frame, text="Use:").pack(side=tk.LEFT)
        
        self.rotate_center_var = tk.StringVar(value="origin")
        ttk_boot.Radiobutton(
            center_frame, text="Origin (0,0,0)",
            variable=self.rotate_center_var, value="origin",
            command=self._update_preview
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Radiobutton(
            center_frame, text="Geometry Centroid",
            variable=self.rotate_center_var, value="centroid",
            command=self._update_preview
        ).pack(side=tk.LEFT, padx=5)
        
        # Populate angle measurements
        angle_measurements = [
            m.name for m in self.measurements
            if m.measurement_type in [
                MeasurementType.HORIZONTAL_ANGLE,
                MeasurementType.VERTICAL_ANGLE,
                MeasurementType.ZENITH_ANGLE
            ]
        ]
        self.rotate_angle_combo['values'] = angle_measurements
        self._angle_measurements = {
            m.name: m for m in self.measurements
            if m.measurement_type in [
                MeasurementType.HORIZONTAL_ANGLE,
                MeasurementType.VERTICAL_ANGLE,
                MeasurementType.ZENITH_ANGLE
            ]
        }
        
        if angle_measurements:
            self.rotate_angle_combo.current(0)
        
        self.rotate_angle_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
    
    def _create_scale_widgets(self):
        """Create widgets for scale transformation."""
        # Scale factor measurement
        ttk_boot.Label(self.measurement_frame, text="Scale Factor:").pack(anchor=tk.W, pady=2)
        
        self.scale_factor_var = tk.StringVar()
        self.scale_factor_combo = ttk_boot.Combobox(
            self.measurement_frame,
            textvariable=self.scale_factor_var,
            state="readonly"
        )
        self.scale_factor_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Scale center
        ttk_boot.Label(self.options_frame, text="Scale Center:").pack(anchor=tk.W, pady=2)
        center_frame = ttk_boot.Frame(self.options_frame)
        center_frame.pack(fill=tk.X, padx=5, pady=2)
        
        ttk_boot.Label(center_frame, text="Use:").pack(side=tk.LEFT)
        
        self.scale_center_var = tk.StringVar(value="origin")
        ttk_boot.Radiobutton(
            center_frame, text="Origin (0,0,0)",
            variable=self.scale_center_var, value="origin",
            command=self._update_preview
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Radiobutton(
            center_frame, text="Geometry Centroid",
            variable=self.scale_center_var, value="centroid",
            command=self._update_preview
        ).pack(side=tk.LEFT, padx=5)
        
        # Populate distance measurements (use as scale factor)
        distance_measurements = [
            m.name for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DISTANCE,
                MeasurementType.HORIZONTAL_DISTANCE
            ]
        ]
        self.scale_factor_combo['values'] = distance_measurements
        self._distance_measurements = {
            m.name: m for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DISTANCE,
                MeasurementType.HORIZONTAL_DISTANCE
            ]
        }
        
        if distance_measurements:
            self.scale_factor_combo.current(0)
        
        self.scale_factor_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
    
    def _create_offset_widgets(self):
        """Create widgets for offset transformation."""
        # Offset distance measurement
        ttk_boot.Label(self.measurement_frame, text="Offset Distance:").pack(anchor=tk.W, pady=2)
        
        self.offset_distance_var = tk.StringVar()
        self.offset_distance_combo = ttk_boot.Combobox(
            self.measurement_frame,
            textvariable=self.offset_distance_var,
            state="readonly"
        )
        self.offset_distance_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Offset direction
        ttk_boot.Label(self.options_frame, text="Offset Direction:").pack(anchor=tk.W, pady=2)
        direction_frame = ttk_boot.Frame(self.options_frame)
        direction_frame.pack(fill=tk.X, padx=5, pady=2)
        
        ttk_boot.Label(direction_frame, text="Use:").pack(side=tk.LEFT)
        
        self.offset_direction_var = tk.StringVar(value="left")
        ttk_boot.Radiobutton(
            direction_frame, text="Left",
            variable=self.offset_direction_var, value="left",
            command=self._update_preview
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Radiobutton(
            direction_frame, text="Right",
            variable=self.offset_direction_var, value="right",
            command=self._update_preview
        ).pack(side=tk.LEFT, padx=5)
        
        # Populate distance measurements
        distance_measurements = [
            m.name for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DISTANCE,
                MeasurementType.HORIZONTAL_DISTANCE
            ]
        ]
        self.offset_distance_combo['values'] = distance_measurements
        
        if distance_measurements:
            self.offset_distance_combo.current(0)
    
    def _get_geometry_centroid(self) -> Point:
        """Calculate the centroid of the geometry."""
        if isinstance(self.geometry, Point):
            return Point(self.geometry.northing, self.geometry.easting, getattr(self.geometry, 'elevation', 0))
        elif isinstance(self.geometry, LineSegment):
            return Point(
                (self.geometry.start.northing + self.geometry.end.northing) / 2,
                (self.geometry.start.easting + self.geometry.end.easting) / 2,
                (getattr(self.geometry.start, 'elevation', 0) + getattr(self.geometry.end, 'elevation', 0)) / 2
            )
        elif isinstance(self.geometry, SimplePolyline):
            points = self.geometry.points
            return Point(
                sum(p.northing for p in points) / len(points),
                sum(p.easting for p in points) / len(points),
                sum(getattr(p, 'elevation', 0) for p in points) / len(points)
            )
        elif isinstance(self.geometry, SimplePolygon):
            # Use polygon centroid formula
            points = self.geometry.points
            area = 0.0
            cx = 0.0
            cy = 0.0
            for i in range(len(points)):
                j = (i + 1) % len(points)
                a = points[i].easting * points[j].northing - points[j].easting * points[i].northing
                area += a
                cx += (points[i].easting + points[j].easting) * a
                cy += (points[i].northing + points[j].northing) * a
            
            if area != 0:
                area /= 2
                cx /= (6 * area)
                cy /= (6 * area)
            
            return Point(cy, cx, 0)  # cx is easting, cy is northing
    
    def _update_preview(self):
        """Update the preview based on selected transformation."""
        try:
            trans_type = self.transformation_type.get()
            
            if trans_type == "move":
                self._preview_move()
            elif trans_type == "rotate":
                self._preview_rotate()
            elif trans_type == "scale":
                self._preview_scale()
            elif trans_type == "offset":
                self._preview_offset()
                
        except Exception as e:
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"Error: {str(e)}")
            self.result_text.config(state=tk.DISABLED)
            self.error_label.config(text=str(e))
            self.result_geometry = None
            self.ok_button.config(state=tk.DISABLED)
    
    def _preview_move(self):
        """Preview move transformation."""
        vector_name = self.move_vector_var.get()
        
        if not vector_name:
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "Select a vector measurement")
            self.result_text.config(state=tk.DISABLED)
            self.error_label.config(text="")
            return
        
        vector = self._vector_measurements.get(vector_name)
        if not vector:
            return
        
        vector_obj = extract_vector_from_measurement(vector)
        
        self.result_text.config(state=tk.NORMAL)
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"Transformation: Move by Vector\n")
        self.result_text.insert(tk.END, f"Vector: N={vector_obj.northing:.3f}, E={vector_obj.easting:.3f}\n")
        self.result_text.insert(tk.END, f"Geometry Type: {type(self.geometry).__name__}\n")
        self.result_text.insert(tk.END, f"\nNote: Move transformation will be applied\n")
        self.result_text.insert(tk.END, f"when OK is clicked.")
        self.result_text.config(state=tk.DISABLED)
        
        self.error_label.config(text="")
        self.result_geometry = (trans_type, vector_obj)
        self.ok_button.config(state=tk.NORMAL)
    
    def _preview_rotate(self):
        """Preview rotate transformation."""
        angle_name = self.rotate_angle_var.get()
        center_type = self.rotate_center_var.get()
        
        if not angle_name:
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "Select an angle measurement")
            self.result_text.config(state=tk.DISABLED)
            self.error_label.config(text="")
            return
        
        angle = self._angle_measurements.get(angle_name)
        if not angle:
            return
        
        angle_obj = extract_angle_from_measurement(angle)
        
        center = Point(0, 0, 0) if center_type == "origin" else self._get_geometry_centroid()
        
        self.result_text.config(state=tk.NORMAL)
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"Transformation: Rotate by Angle\n")
        self.result_text.insert(tk.END, f"Angle: {angle_obj.angle_degrees:.3f}°\n")
        self.result_text.insert(tk.END, f"Center: {center_type}\n")
        if center_type == "origin":
            self.result_text.insert(tk.END, f"Center Point: N={center.northing:.3f}, E={center.easting:.3f}\n")
        self.result_text.insert(tk.END, f"\nNote: Rotation will be applied when OK is clicked.")
        self.result_text.config(state=tk.DISABLED)
        
        self.error_label.config(text="")
        self.result_geometry = (trans_type, angle_obj, center)
        self.ok_button.config(state=tk.NORMAL)
    
    def _preview_scale(self):
        """Preview scale transformation."""
        distance_name = self.scale_factor_var.get()
        center_type = self.scale_center_var.get()
        
        if not distance_name:
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "Select a distance measurement for scale factor")
            self.result_text.config(state=tk.DISABLED)
            self.error_label.config(text="")
            return
        
        distance = self._distance_measurements.get(distance_name)
        if not distance:
            return
        
        scale_factor = extract_distance_from_measurement(distance)
        
        center = Point(0, 0, 0) if center_type == "origin" else self._get_geometry_centroid()
        
        self.result_text.config(state=tk.NORMAL)
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"Transformation: Scale by Distance\n")
        self.result_text.insert(tk.END, f"Scale Factor: {scale_factor:.3f}\n")
        self.result_text.insert(tk.END, f"Center: {center_type}\n")
        if center_type == "origin":
            self.result_text.insert(tk.END, f"Center Point: N={center.northing:.3f}, E={center.easting:.3f}\n")
        self.result_text.insert(tk.END, f"\nNote: Scale transformation will be applied\n")
        self.result_text.insert(tk.END, f"when OK is clicked.")
        self.result_text.config(state=tk.DISABLED)
        
        self.error_label.config(text="")
        self.result_geometry = (trans_type, scale_factor, center)
        self.ok_button.config(state=tk.NORMAL)
    
    def _preview_offset(self):
        """Preview offset transformation."""
        distance_name = self.offset_distance_var.get()
        direction = self.offset_direction_var.get()
        
        if not distance_name:
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "Select a distance measurement for offset")
            self.result_text.config(state=tk.DISABLED)
            self.error_label.config(text="")
            return
        
        distance = self._distance_measurements.get(distance_name)
        if not distance:
            return
        
        offset_distance = extract_distance_from_measurement(distance)
        
        self.result_text.config(state=tk.NORMAL)
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"Transformation: Offset by Distance\n")
        self.result_text.insert(tk.END, f"Offset Distance: {offset_distance:.3f}\n")
        self.result_text.insert(tk.END, f"Direction: {direction}\n")
        self.result_text.insert(tk.END, f"\nNote: Offset applies to lines/polylines only.\n")
        self.result_text.insert(tk.END, f"Applied when OK is clicked.")
        self.result_text.config(state=tk.DISABLED)
        
        # Check if geometry supports offset
        if isinstance(self.geometry, (LineSegment, SimplePolyline)):
            self.error_label.config(text="")
            self.result_geometry = (trans_type, offset_distance, direction)
            self.ok_button.config(state=tk.NORMAL)
        else:
            self.error_label.config(text="Offset only applies to lines and polylines")
            self.result_geometry = None
            self.ok_button.config(state=tk.DISABLED)
    
    def _on_ok(self):
        """Handle OK button click."""
        if self.result_geometry:
            self.destroy()
    
    def _on_cancel(self):
        """Handle Cancel button click."""
        self.result_geometry = None
        self.destroy()
