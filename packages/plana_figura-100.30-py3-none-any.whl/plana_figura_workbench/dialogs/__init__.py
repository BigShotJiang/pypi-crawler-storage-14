"""Dialog modules for Plana Figura Workbench."""

from plana_figura_workbench.dialogs.geometry_dialogs import (
    PointDialog,
    LineDialog,
    PolylineDialog,
)
from plana_figura_workbench.dialogs.transform_dialogs import (
    TranslateDialog,
    RotateDialog,
    ScaleDialog,
    MirrorDialog,
)
from plana_figura_workbench.dialogs.measurement_dialogs import (
    AddAngleDialog,
    AddDirectionDialog,
    AddDistanceDialog,
)
from plana_figura_workbench.dialogs.add_vector_dialog import AddVectorDialog
from plana_figura_workbench.dialogs.import_dxf_dialog import ImportDXFDialog
from plana_figura_workbench.dialogs.export_dxf_dialog import ExportDXFDialog
from plana_figura_workbench.dialogs.geometry_creation_dialogs import (
    CreatePointFromMeasurementsDialog,
    CreateLineFromMeasurementsDialog,
    CreatePolylineFromMeasurementsDialog,
    CreateRectangleFromMeasurementsDialog,
)
from plana_figura_workbench.dialogs.geometry_transformation_dialogs import (
    TransformGeometryWithMeasurementsDialog,
)

__all__ = [
    "PointDialog",
    "LineDialog",
    "PolylineDialog",
    "TranslateDialog",
    "RotateDialog",
    "ScaleDialog",
    "MirrorDialog",
    "AddAngleDialog",
    "AddDirectionDialog",
    "AddDistanceDialog",
    "AddVectorDialog",
    "ImportDXFDialog",
    "ExportDXFDialog",
    "CreatePointFromMeasurementsDialog",
    "CreateLineFromMeasurementsDialog",
    "CreatePolylineFromMeasurementsDialog",
    "CreateRectangleFromMeasurementsDialog",
    "TransformGeometryWithMeasurementsDialog",
]
