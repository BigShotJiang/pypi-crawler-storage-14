"""
Controllers for transformation dialogs (Translate, Rotate, Scale, Mirror).

These controllers contain all business logic for transformation dialogs,
making them fully testable without GUI dependencies.

Uses surveying conventions:
- Northing/Easting/Elevation (not X/Y/Z)
- Degrees-Minutes-Seconds (DMS) format for angles
"""

from typing import Optional, Tuple
import logging

from plana_figura_workbench.validators import (
    CoordinateValidator,
    ElevationValidator,
    ValidationResult,
)

logger = logging.getLogger(__name__)


class TranslateDialogController:
    """
    Controller for translate (move) dialog.
    
    Handles validation and state for translating geometry by
    delta northing, delta easting, and delta elevation.
    """
    
    def __init__(self):
        """Initialize the translate dialog controller."""
        self.delta_northing: Optional[float] = None
        self.delta_easting: Optional[float] = None
        self.delta_elevation: Optional[float] = None
        
        self.coord_validator = CoordinateValidator()
        self.elev_validator = ElevationValidator()
    
    def validate_delta_northing(self, value: str) -> ValidationResult:
        """
        Validate delta northing input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        # Empty is valid for deltas (defaults to 0)
        if not value.strip():
            return ValidationResult(True, "Valid")
        return self.coord_validator.validate(value)
    
    def validate_delta_easting(self, value: str) -> ValidationResult:
        """
        Validate delta easting input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        # Empty is valid for deltas (defaults to 0)
        if not value.strip():
            return ValidationResult(True, "Valid")
        return self.coord_validator.validate(value)
    
    def validate_delta_elevation(self, value: str) -> ValidationResult:
        """
        Validate delta elevation input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        return self.elev_validator.validate(value)
    
    def set_delta_northing(self, value: str) -> bool:
        """
        Set delta northing value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_delta_northing(value)
        if result.is_valid:
            self.delta_northing = float(value) if value.strip() else 0.0
            return True
        return False
    
    def set_delta_easting(self, value: str) -> bool:
        """
        Set delta easting value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_delta_easting(value)
        if result.is_valid:
            self.delta_easting = float(value) if value.strip() else 0.0
            return True
        return False
    
    def set_delta_elevation(self, value: str) -> bool:
        """
        Set delta elevation value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_delta_elevation(value)
        if result.is_valid:
            self.delta_elevation = float(value) if value.strip() else 0.0
            return True
        return False
    
    def is_valid(self) -> bool:
        """
        Check if current state is valid for translation.
        
        At least one delta must be non-zero.
        
        Returns:
            True if valid, False otherwise
        """
        if self.delta_northing is None or self.delta_easting is None:
            return False
        
        # At least one delta must be non-zero
        if (self.delta_northing == 0.0 and
            self.delta_easting == 0.0 and
            (self.delta_elevation is None or self.delta_elevation == 0.0)):
            return False
        
        return True
    
    def get_deltas(self) -> Tuple[float, float, float]:
        """
        Get the translation deltas.
        
        Returns:
            Tuple of (delta_northing, delta_easting, delta_elevation)
        """
        return (
            self.delta_northing or 0.0,
            self.delta_easting or 0.0,
            self.delta_elevation or 0.0
        )


class RotateDialogController:
    """
    Controller for rotate dialog.
    
    Handles validation and state for rotating geometry around a point
    by an angle in degrees-minutes-seconds format.
    """
    
    def __init__(self):
        """Initialize the rotate dialog controller."""
        self.center_northing: Optional[float] = None
        self.center_easting: Optional[float] = None
        self.degrees: Optional[int] = None
        self.minutes: Optional[int] = None
        self.seconds: Optional[float] = None
        self.clockwise: bool = True  # Surveying convention: clockwise from north
        
        self.coord_validator = CoordinateValidator()
    
    def validate_center_northing(self, value: str) -> ValidationResult:
        """
        Validate center northing input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        return self.coord_validator.validate(value)
    
    def validate_center_easting(self, value: str) -> ValidationResult:
        """
        Validate center easting input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        return self.coord_validator.validate(value)
    
    def validate_degrees(self, value: str) -> ValidationResult:
        """
        Validate degrees input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        if not value.strip():
            return ValidationResult(False, "Degrees required")
        
        try:
            deg = int(value)
            if deg < -360 or deg > 360:
                return ValidationResult(False, "Degrees must be between -360 and 360")
            return ValidationResult(True, "Valid")
        except ValueError:
            return ValidationResult(False, "Must be an integer")
    
    def validate_minutes(self, value: str) -> ValidationResult:
        """
        Validate minutes input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        if not value.strip():
            return ValidationResult(True, "Valid")  # Minutes optional
        
        try:
            mins = int(value)
            if mins < 0 or mins >= 60:
                return ValidationResult(False, "Minutes must be 0-59")
            return ValidationResult(True, "Valid")
        except ValueError:
            return ValidationResult(False, "Must be an integer")
    
    def validate_seconds(self, value: str) -> ValidationResult:
        """
        Validate seconds input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        if not value.strip():
            return ValidationResult(True, "Valid")  # Seconds optional
        
        try:
            secs = float(value)
            if secs < 0.0 or secs >= 60.0:
                return ValidationResult(False, "Seconds must be 0-59.999...")
            return ValidationResult(True, "Valid")
        except ValueError:
            return ValidationResult(False, "Must be a number")
    
    def set_center_northing(self, value: str) -> bool:
        """
        Set center northing value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_center_northing(value)
        if result.is_valid:
            self.center_northing = float(value)
            return True
        return False
    
    def set_center_easting(self, value: str) -> bool:
        """
        Set center easting value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_center_easting(value)
        if result.is_valid:
            self.center_easting = float(value)
            return True
        return False
    
    def set_degrees(self, value: str) -> bool:
        """
        Set degrees value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_degrees(value)
        if result.is_valid:
            self.degrees = int(value)
            return True
        return False
    
    def set_minutes(self, value: str) -> bool:
        """
        Set minutes value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_minutes(value)
        if result.is_valid:
            self.minutes = int(value) if value.strip() else 0
            return True
        return False
    
    def set_seconds(self, value: str) -> bool:
        """
        Set seconds value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_seconds(value)
        if result.is_valid:
            self.seconds = float(value) if value.strip() else 0.0
            return True
        return False
    
    def set_clockwise(self, clockwise: bool) -> None:
        """
        Set rotation direction.
        
        Args:
            clockwise: True for clockwise, False for counter-clockwise
        """
        self.clockwise = clockwise
    
    def is_valid(self) -> bool:
        """
        Check if current state is valid for rotation.
        
        Returns:
            True if valid, False otherwise
        """
        if self.center_northing is None or self.center_easting is None:
            return False
        
        if self.degrees is None:
            return False
        
        # Check if angle is non-zero
        angle_decimal = self.get_angle_decimal()
        if angle_decimal == 0.0:
            return False
        
        return True
    
    def get_angle_decimal(self) -> float:
        """
        Convert DMS to decimal degrees.
        
        Returns:
            Angle in decimal degrees
        """
        deg = self.degrees or 0
        mins = self.minutes or 0
        secs = self.seconds or 0.0
        
        # Convert to decimal
        decimal = abs(deg) + mins / 60.0 + secs / 3600.0
        
        # Apply sign
        if deg < 0:
            decimal = -decimal
        
        # Apply direction (clockwise is negative in standard math)
        if self.clockwise:
            decimal = -decimal
        
        return decimal
    
    def get_center(self) -> Tuple[float, float]:
        """
        Get the rotation center point.
        
        Returns:
            Tuple of (northing, easting)
        """
        return (self.center_northing or 0.0, self.center_easting or 0.0)
    
    def get_angle_dms_string(self) -> str:
        """
        Get formatted DMS string.
        
        Returns:
            String like "45° 30' 15.5\""
        """
        deg = self.degrees or 0
        mins = self.minutes or 0
        secs = self.seconds or 0.0
        
        direction = "CW" if self.clockwise else "CCW"
        
        if secs == 0.0:
            if mins == 0:
                return f"{deg}° {direction}"
            return f"{deg}° {mins}' {direction}"
        
        return f"{deg}° {mins}' {secs:.2f}\" {direction}"


class ScaleDialogController:
    """
    Controller for scale dialog.
    
    Handles validation and state for scaling geometry from a center point
    by a scale factor.
    """
    
    def __init__(self):
        """Initialize the scale dialog controller."""
        self.center_northing: Optional[float] = None
        self.center_easting: Optional[float] = None
        self.scale_factor: Optional[float] = None
        
        self.coord_validator = CoordinateValidator()
    
    def validate_center_northing(self, value: str) -> ValidationResult:
        """
        Validate center northing input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        return self.coord_validator.validate(value)
    
    def validate_center_easting(self, value: str) -> ValidationResult:
        """
        Validate center easting input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        return self.coord_validator.validate(value)
    
    def validate_scale_factor(self, value: str) -> ValidationResult:
        """
        Validate scale factor input.
        
        Args:
            value: String value to validate
        
        Returns:
            ValidationResult with success status and message
        """
        if not value.strip():
            return ValidationResult(False, "Scale factor required")
        
        try:
            factor = float(value)
            if factor <= 0:
                return ValidationResult(False, "Scale factor must be positive")
            if factor == 1.0:
                return ValidationResult(False, "Scale factor cannot be 1.0 (no change)")
            return ValidationResult(True, "Valid")
        except ValueError:
            return ValidationResult(False, "Must be a number")
    
    def set_center_northing(self, value: str) -> bool:
        """
        Set center northing value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_center_northing(value)
        if result.is_valid:
            self.center_northing = float(value)
            return True
        return False
    
    def set_center_easting(self, value: str) -> bool:
        """
        Set center easting value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_center_easting(value)
        if result.is_valid:
            self.center_easting = float(value)
            return True
        return False
    
    def set_scale_factor(self, value: str) -> bool:
        """
        Set scale factor value.
        
        Args:
            value: String value to set
        
        Returns:
            True if valid and set, False otherwise
        """
        result = self.validate_scale_factor(value)
        if result.is_valid:
            self.scale_factor = float(value)
            return True
        return False
    
    def is_valid(self) -> bool:
        """
        Check if current state is valid for scaling.
        
        Returns:
            True if valid, False otherwise
        """
        if self.center_northing is None or self.center_easting is None:
            return False
        
        if self.scale_factor is None or self.scale_factor == 1.0:
            return False
        
        return True
    
    def get_center(self) -> Tuple[float, float]:
        """
        Get the scale center point.
        
        Returns:
            Tuple of (northing, easting)
        """
        return (self.center_northing or 0.0, self.center_easting or 0.0)
    
    def get_scale_factor(self) -> float:
        """
        Get the scale factor.
        
        Returns:
            Scale factor
        """
        return self.scale_factor or 1.0


class MirrorDialogController:
    """
    Controller for mirror dialog.
    
    Handles validation and state for mirroring geometry across a line
    defined by two points.
    """
    
    def __init__(self):
        """Initialize the mirror dialog controller."""
        self.point1_northing: Optional[float] = None
        self.point1_easting: Optional[float] = None
        self.point2_northing: Optional[float] = None
        self.point2_easting: Optional[float] = None
        
        self.coord_validator = CoordinateValidator()
    
    def validate_point1_northing(self, value: str) -> ValidationResult:
        """Validate point 1 northing input."""
        return self.coord_validator.validate(value)
    
    def validate_point1_easting(self, value: str) -> ValidationResult:
        """Validate point 1 easting input."""
        return self.coord_validator.validate(value)
    
    def validate_point2_northing(self, value: str) -> ValidationResult:
        """Validate point 2 northing input."""
        return self.coord_validator.validate(value)
    
    def validate_point2_easting(self, value: str) -> ValidationResult:
        """Validate point 2 easting input."""
        return self.coord_validator.validate(value)
    
    def set_point1_northing(self, value: str) -> bool:
        """Set point 1 northing value."""
        result = self.validate_point1_northing(value)
        if result.is_valid:
            self.point1_northing = float(value)
            return True
        return False
    
    def set_point1_easting(self, value: str) -> bool:
        """Set point 1 easting value."""
        result = self.validate_point1_easting(value)
        if result.is_valid:
            self.point1_easting = float(value)
            return True
        return False
    
    def set_point2_northing(self, value: str) -> bool:
        """Set point 2 northing value."""
        result = self.validate_point2_northing(value)
        if result.is_valid:
            self.point2_northing = float(value)
            return True
        return False
    
    def set_point2_easting(self, value: str) -> bool:
        """Set point 2 easting value."""
        result = self.validate_point2_easting(value)
        if result.is_valid:
            self.point2_easting = float(value)
            return True
        return False
    
    def is_valid(self) -> bool:
        """
        Check if current state is valid for mirroring.
        
        Points must be different (not coincident).
        
        Returns:
            True if valid, False otherwise
        """
        if (self.point1_northing is None or self.point1_easting is None or
            self.point2_northing is None or self.point2_easting is None):
            return False
        
        # Check if points are coincident
        if (self.point1_northing == self.point2_northing and
            self.point1_easting == self.point2_easting):
            return False
        
        return True
    
    def get_mirror_line(self) -> Tuple[Tuple[float, float], Tuple[float, float]]:
        """
        Get the mirror line as two points.
        
        Returns:
            Tuple of ((n1, e1), (n2, e2))
        """
        return (
            (self.point1_northing or 0.0, self.point1_easting or 0.0),
            (self.point2_northing or 0.0, self.point2_easting or 0.0)
        )
