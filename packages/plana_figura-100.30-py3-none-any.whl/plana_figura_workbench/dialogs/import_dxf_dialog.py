"""Dialog for importing DXF files."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from typing import Optional, Set
import logging

from plana_figura_workbench.io.dxf import DXFReader, DXFConfig

logger = logging.getLogger(__name__)


class ImportDXFDialog(tk.Toplevel):
    """
    Dialog for importing DXF files.

    Allows user to:
    - Select DXF file
    - Choose which layers to import
    - Configure import options
    - Preview file metadata
    """

    def __init__(self, parent):
        """
        Initialize the import dialog.

        Args:
            parent: Parent window
        """
        super().__init__(parent)

        self.title("Import DXF File")
        self.geometry("600x650")
        self.resizable(True, True)

        # Make dialog modal
        self.transient(parent)
        self.grab_set()

        # Result
        self.result = None
        self.selected_file: Optional[Path] = None
        self.selected_layers: Set[str] = set()
        self.config = DXFConfig.default_import()

        self._setup_ui()

        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_y() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")

    def _setup_ui(self):
        """Set up the user interface."""
        # Main container
        main_frame = ttk.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # File selection
        self._create_file_section(main_frame)

        # Layer selection
        self._create_layer_section(main_frame)

        # Naming section
        self._create_naming_section(main_frame)

        # Options
        self._create_options_section(main_frame)

        # Buttons
        self._create_buttons(main_frame)

    def _create_file_section(self, parent):
        """Create file selection section."""
        file_frame = ttk.LabelFrame(parent, text="File Selection", padding=10)
        file_frame.pack(fill=tk.X, pady=(0, 10))

        # File path
        path_frame = ttk.Frame(file_frame)
        path_frame.pack(fill=tk.X)

        ttk.Label(path_frame, text="File:").pack(side=tk.LEFT, padx=(0, 5))

        self.file_var = tk.StringVar()
        self.file_entry = ttk.Entry(path_frame, textvariable=self.file_var, state="readonly")
        self.file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        browse_btn = ttk.Button(
            path_frame,
            text="Browse...",
            command=self._on_browse,
            bootstyle="secondary"
        )
        browse_btn.pack(side=tk.LEFT)

        # File info
        self.info_label = ttk.Label(
            file_frame,
            text="No file selected",
            foreground="gray"
        )
        self.info_label.pack(fill=tk.X, pady=(5, 0))

    def _create_layer_section(self, parent):
        """Create layer selection section."""
        layer_frame = ttk.LabelFrame(parent, text="Layers", padding=10)
        layer_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        # Toolbar
        toolbar = ttk.Frame(layer_frame)
        toolbar.pack(fill=tk.X, pady=(0, 5))

        ttk.Button(
            toolbar,
            text="Select All",
            command=self._on_select_all_layers,
            bootstyle="secondary-outline",
            width=12
        ).pack(side=tk.LEFT, padx=(0, 5))

        ttk.Button(
            toolbar,
            text="Deselect All",
            command=self._on_deselect_all_layers,
            bootstyle="secondary-outline",
            width=12
        ).pack(side=tk.LEFT)

        # Layer list
        list_frame = ttk.Frame(layer_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)

        # Scrollbar
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Listbox
        self.layer_listbox = tk.Listbox(
            list_frame,
            selectmode=tk.MULTIPLE,
            yscrollcommand=scrollbar.set
        )
        self.layer_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.layer_listbox.yview)

        # Info label
        self.layer_info_label = ttk.Label(
            layer_frame,
            text="Select a file to view layers",
            foreground="gray"
        )
        self.layer_info_label.pack(fill=tk.X, pady=(5, 0))

    def _create_naming_section(self, parent):
        """Create naming and layer properties section."""
        naming_frame = ttk.LabelFrame(parent, text="Collection and Layer Names", padding=10)
        naming_frame.pack(fill=tk.X, pady=(0, 10))

        # Collection name
        coll_frame = ttk.Frame(naming_frame)
        coll_frame.pack(fill=tk.X, pady=(0, 5))

        ttk.Label(coll_frame, text="Collection Name:", width=18).pack(side=tk.LEFT, padx=(0, 5))

        self.collection_name_var = tk.StringVar(value="")
        self.collection_entry = ttk.Entry(coll_frame, textvariable=self.collection_name_var)
        self.collection_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Layer name
        layer_frame = ttk.Frame(naming_frame)
        layer_frame.pack(fill=tk.X, pady=(0, 5))

        ttk.Label(layer_frame, text="Map View Layer:", width=18).pack(side=tk.LEFT, padx=(0, 5))

        self.layer_name_var = tk.StringVar(value="")
        self.layer_entry = ttk.Entry(layer_frame, textvariable=self.layer_name_var)
        self.layer_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Layer properties button
        props_frame = ttk.Frame(naming_frame)
        props_frame.pack(fill=tk.X, pady=(5, 0))

        self.layer_props_btn = ttk.Button(
            props_frame,
            text="Set Layer Properties...",
            command=self._on_layer_properties,
            bootstyle="info",
            state=tk.DISABLED
        )
        self.layer_props_btn.pack(side=tk.LEFT)

        ttk.Label(
            props_frame,
            text="(Configure color, width, etc. for the imported layer)",
            foreground="gray",
            font=("TkDefaultFont", 8)
        ).pack(side=tk.LEFT, padx=(10, 0))

    def _create_options_section(self, parent):
        """Create import options section."""
        options_frame = ttk.LabelFrame(parent, text="Import Options", padding=10)
        options_frame.pack(fill=tk.X, pady=(0, 10))

        # Ignore elevation
        self.ignore_elevation_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            options_frame,
            text="Ignore elevation (set all Z coordinates to 0)",
            variable=self.ignore_elevation_var,
            bootstyle="round-toggle"
        ).pack(anchor=tk.W)

        # Approximate curves
        self.approximate_curves_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            options_frame,
            text="Approximate curves (circles, arcs, splines)",
            variable=self.approximate_curves_var,
            bootstyle="round-toggle"
        ).pack(anchor=tk.W, pady=(5, 0))

        # Curve segments
        segments_frame = ttk.Frame(options_frame)
        segments_frame.pack(fill=tk.X, pady=(5, 0))

        ttk.Label(segments_frame, text="Curve segments:").pack(side=tk.LEFT, padx=(20, 5))

        self.curve_segments_var = tk.IntVar(value=32)
        segments_spinbox = ttk.Spinbox(
            segments_frame,
            from_=8,
            to=128,
            textvariable=self.curve_segments_var,
            width=10
        )
        segments_spinbox.pack(side=tk.LEFT)

    def _create_buttons(self, parent):
        """Create dialog buttons."""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X)

        ttk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=12
        ).pack(side=tk.RIGHT, padx=(5, 0))

        self.import_btn = ttk.Button(
            button_frame,
            text="Import",
            command=self._on_import,
            bootstyle="primary",
            width=12,
            state=tk.DISABLED
        )
        self.import_btn.pack(side=tk.RIGHT)

    def _on_browse(self):
        """Handle Browse button click."""
        filename = filedialog.askopenfilename(
            parent=self,
            title="Select DXF File",
            filetypes=[
                ("DXF Files", "*.dxf"),
                ("All Files", "*.*")
            ]
        )

        if filename:
            self.selected_file = Path(filename)
            self.file_var.set(str(self.selected_file))
            self._load_file_info()

    def _load_file_info(self):
        """Load and display file information."""
        if not self.selected_file:
            return

        try:
            # Read file metadata
            reader = DXFReader(self.config)
            metadata = reader.get_metadata(self.selected_file)

            # Update info label
            info_text = (
                f"DXF Version: {metadata.get('dxf_version', 'Unknown')} | "
                f"Layers: {metadata.get('layer_count', 0)} | "
                f"Entities: {metadata.get('total_entities', 0)}"
            )
            self.info_label.config(text=info_text, foreground="black")

            # Populate layer list
            self.layer_listbox.delete(0, tk.END)
            layers = metadata.get('layers', [])

            for layer in layers:
                self.layer_listbox.insert(tk.END, layer)

            # Select all layers by default
            self._on_select_all_layers()

            # Update layer info
            self.layer_info_label.config(
                text=f"{len(layers)} layer(s) available",
                foreground="black"
            )

            # Set default collection and layer names
            default_name = self.selected_file.stem
            self.collection_name_var.set(f"Import - {default_name}")
            self.layer_name_var.set(default_name)

            # Enable import button and layer properties
            self.import_btn.config(state=tk.NORMAL)
            self.layer_props_btn.config(state=tk.NORMAL)

        except Exception as e:
            logger.error(f"Error loading DXF file: {e}")
            messagebox.showerror(
                "Error",
                f"Failed to load DXF file:\n{str(e)}",
                parent=self
            )
            self.info_label.config(text="Error loading file", foreground="red")

    def _on_select_all_layers(self):
        """Select all layers."""
        self.layer_listbox.selection_set(0, tk.END)

    def _on_deselect_all_layers(self):
        """Deselect all layers."""
        self.layer_listbox.selection_clear(0, tk.END)

    def _on_layer_properties(self):
        """Handle Set Layer Properties button click."""
        from plana_figura_workbench.plugins.map_view.dialogs.layer_properties_dialog import (
            LayerPropertiesDialog
        )
        from plana_figura_workbench.plugins.map_view.map_view_model import LayerStyle

        # Create default layer style if not exists
        if not hasattr(self, 'layer_properties'):
            self.layer_properties = LayerStyle(
                stroke_color='#000000',
                stroke_width=2,
                fill_color='#FFFFFF',
                point_size=3
            )

        # Show layer properties dialog
        dialog = LayerPropertiesDialog(
            self,
            layer_name=self.layer_name_var.get() or "Imported Layer",
            style=self.layer_properties
        )

        result = dialog.show()
        if result:
            self.layer_properties = result

    def _on_import(self):
        """Handle Import button click."""
        if not self.selected_file:
            messagebox.showwarning(
                "No File Selected",
                "Please select a DXF file to import.",
                parent=self
            )
            return

        # Get selected layers
        selected_indices = self.layer_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning(
                "No Layers Selected",
                "Please select at least one layer to import.",
                parent=self
            )
            return

        self.selected_layers = {
            self.layer_listbox.get(i) for i in selected_indices
        }

        # Update config
        if len(self.selected_layers) < self.layer_listbox.size():
            self.config.import_layers = self.selected_layers
        else:
            self.config.import_layers = None
        self.config.ignore_elevation = self.ignore_elevation_var.get()
        self.config.approximate_curves = self.approximate_curves_var.get()
        self.config.curve_segments = self.curve_segments_var.get()

        self.result = {
            'file': self.selected_file,
            'layers': self.selected_layers,
            'config': self.config,
            'collection_name': (
                self.collection_name_var.get().strip() or
                f"Import - {self.selected_file.stem}"
            ),
            'layer_name': self.layer_name_var.get().strip() or self.selected_file.stem,
            'layer_properties': getattr(self, 'layer_properties', None)
        }

        self.destroy()

    def _on_cancel(self):
        """Handle Cancel button click."""
        self.result = None
        self.destroy()

    def show(self):
        """Show the dialog and wait for result."""
        self.wait_window()
        return self.result
