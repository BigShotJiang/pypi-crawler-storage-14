"""
Geometry creation dialogs using measurement objects.

These dialogs allow users to create geometries from existing measurements,
providing UI access to the Phase 1-3 measurement-geometry integration functions.
"""

import tkinter as tk
import ttkbootstrap as ttk_boot
from typing import Optional, List, Tuple, Any
import logging
import math

from plana_figura import (
    Point, LineSegment, SimplePolyline, SimplePolygon,
    Measurement, MeasurementType, DecimalDegreesAngle, SurveyorsDirection,
    Vector2D, Vector3D
)
from plana_figura.geometry_builders import (
    create_point_from_direction_distance,
    create_line_from_vector,
    create_polyline_from_direction_distance_pairs,
    create_rectangle
)
from plana_figura_workbench.events import (
    GeometryPreviewEvent,
)
logger = logging.getLogger(__name__)


def extract_direction_from_measurement(measurement: Measurement) -> SurveyorsDirection:
    """Extract a SurveyorsDirection from a direction/azimuth/bearing measurement."""
    if measurement.measurement_type not in [
        MeasurementType.DIRECTION,
        MeasurementType.AZIMUTH,
        MeasurementType.BEARING
    ]:
        raise ValueError(f"Measurement '{measurement.name}' is not a direction type")
    
    # Convert angle to radians if it's in degrees
    if hasattr(measurement.value, 'radians'):
        angle_radians = measurement.value.radians
    elif hasattr(measurement.value, 'decimal_degrees'):
        angle_radians = math.radians(measurement.value.decimal_degrees)
    elif hasattr(measurement.value, 'angle_degrees'):
        angle_radians = math.radians(measurement.value.angle_degrees)
    elif hasattr(measurement.value, 'degrees'):
        angle_radians = math.radians(measurement.value.degrees)
    else:
        # Assume it's already in radians
        angle_radians = float(measurement.value)
    
    return SurveyorsDirection(angle_radians)


def extract_distance_from_measurement(measurement: Measurement) -> float:
    """Extract a distance value from a distance measurement."""
    if measurement.measurement_type not in [
        MeasurementType.DISTANCE,
        MeasurementType.HORIZONTAL_DISTANCE,
        MeasurementType.SLOPE_DISTANCE,
        MeasurementType.VERTICAL_DISTANCE
    ]:
        raise ValueError(f"Measurement {measurement.name} is not a distance type")
    
    return float(measurement.value)


def extract_vector_from_measurement(measurement: Measurement) -> Vector3D:
    """Extract a Vector3D from a 3D vector measurement."""
    if measurement.measurement_type != MeasurementType.VECTOR_3D:
        raise ValueError(f"Measurement '{measurement.name}' is not a 3D vector type")
    
    vector_value = measurement.value
    if len(vector_value) != 3:
        raise ValueError(f"Vector measurement '{measurement.name}' must have 3 components")
    
    northing, easting, elevation = vector_value
    return Vector3D(
        delta_northing=northing,
        delta_easting=easting,
        delta_elevation=elevation
    )


class CreatePointFromMeasurementsDialog(ttk_boot.Toplevel):
    """
    Dialog for creating a point from direction and distance measurements.
    
    Uses the create_point_from_direction_distance() function from Phase 2.
    """
    
    def __init__(self, parent, measurements: List[Measurement], base_point: Optional[Point] = None, event_bus=None):
        super().__init__(parent)
        self.title("Create Point from Measurements")
        self.geometry("550x450")
        self.resizable(False, False)
        
        self.measurements = measurements
        self.base_point = base_point or Point(0, 0, 0)
        self.result_point: Optional[Point] = None
        self.event_bus = event_bus
        
        self._create_widgets()
        self._setup_bindings()
        self._update_preview()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self):
        """Create the dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk_boot.Label(
            main_frame,
            text="Create Point from Direction + Distance",
            font=("TkDefaultFont", 12, "bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Direction measurement section
        direction_frame = ttk_boot.LabelFrame(main_frame, text="Direction Measurement", padding=5)
        direction_frame.pack(fill=tk.X, pady=5)
        
        self.direction_var = tk.StringVar()
        self.direction_combo = ttk_boot.Combobox(
            direction_frame,
            textvariable=self.direction_var,
            state="readonly"
        )
        self.direction_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Distance measurement section
        distance_frame = ttk_boot.LabelFrame(main_frame, text="Distance Measurement", padding=5)
        distance_frame.pack(fill=tk.X, pady=5)
        
        self.distance_var = tk.StringVar()
        self.distance_combo = ttk_boot.Combobox(
            distance_frame,
            textvariable=self.distance_var,
            state="readonly"
        )
        self.distance_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Base point section
        base_frame = ttk_boot.LabelFrame(main_frame, text="Base Point", padding=5)
        base_frame.pack(fill=tk.X, pady=5)
        
        base_info_frame = ttk_boot.Frame(base_frame)
        base_info_frame.pack(fill=tk.X)
        
        ttk_boot.Label(base_info_frame, text="N:").grid(row=0, column=0, sticky=tk.W, padx=2)
        self.base_n_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.northing:.3f}")
        self.base_n_label.grid(row=0, column=1, sticky=tk.W, padx=2)
        
        ttk_boot.Label(base_info_frame, text="E:").grid(row=0, column=2, sticky=tk.W, padx=2)
        self.base_e_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.easting:.3f}")
        self.base_e_label.grid(row=0, column=3, sticky=tk.W, padx=2)
        
        ttk_boot.Label(base_info_frame, text="Z:").grid(row=0, column=4, sticky=tk.W, padx=2)
        self.base_z_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.elevation:.3f}")
        self.base_z_label.grid(row=0, column=5, sticky=tk.W, padx=2)
        
        # Result preview
        preview_frame = ttk_boot.LabelFrame(main_frame, text="Result Point", padding=5)
        preview_frame.pack(fill=tk.X, pady=5)
        
        preview_info_frame = ttk_boot.Frame(preview_frame)
        preview_info_frame.pack(fill=tk.X)
        
        ttk_boot.Label(preview_info_frame, text="N:").grid(row=0, column=0, sticky=tk.W, padx=2)
        self.result_n_label = ttk_boot.Label(preview_info_frame, text="---")
        self.result_n_label.grid(row=0, column=1, sticky=tk.W, padx=2)
        
        ttk_boot.Label(preview_info_frame, text="E:").grid(row=0, column=2, sticky=tk.W, padx=2)
        self.result_e_label = ttk_boot.Label(preview_info_frame, text="---")
        self.result_e_label.grid(row=0, column=3, sticky=tk.W, padx=2)
        
        ttk_boot.Label(preview_info_frame, text="Z:").grid(row=0, column=4, sticky=tk.W, padx=2)
        self.result_z_label = ttk_boot.Label(preview_info_frame, text="---")
        self.result_z_label.grid(row=0, column=5, sticky=tk.W, padx=2)
        
        # Error label
        self.error_label = ttk_boot.Label(main_frame, text="", foreground="red")
        self.error_label.pack(pady=5)
        
        # Button frame
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.ok_button = ttk_boot.Button(button_frame, text="OK", command=self._on_ok, style="success.TButton")
        self.ok_button.pack(side=tk.RIGHT, padx=5)
        
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT, padx=5)
        
        # Populate measurement combos
        self._populate_measurements()
        
    def _populate_measurements(self):
        """Populate the measurement dropdowns with appropriate measurements."""
        # Get direction measurements
        direction_measurements = [
            (m.name, m) for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DIRECTION,
                MeasurementType.AZIMUTH,
                MeasurementType.BEARING
            ]
        ]
        
        # Get distance measurements
        distance_measurements = [
            (m.name, m) for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DISTANCE,
                MeasurementType.HORIZONTAL_DISTANCE,
                MeasurementType.SLOPE_DISTANCE,
                MeasurementType.VERTICAL_DISTANCE
            ]
        ]
        
        # Set dropdown values
        direction_names = [name for name, _ in direction_measurements]
        distance_names = [name for name, _ in distance_measurements]
        
        self.direction_combo['values'] = direction_names
        self.distance_combo['values'] = distance_names
        
        # Store measurement mappings
        self._direction_measurements = dict(direction_measurements)
        self._distance_measurements = dict(distance_measurements)
        
        # Select first values if available
        if direction_names:
            self.direction_combo.current(0)
        if distance_names:
            self.distance_combo.current(0)
    
    def _setup_bindings(self):
        """Setup event bindings."""
        self.direction_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
        self.distance_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
        
        # Keyboard shortcuts
        self.bind('<Return>', lambda e: self._on_ok())
        self.bind('<Escape>', lambda e: self._on_cancel())
    
    def _update_preview(self):
        """Update the preview based on selected measurements."""
        try:
            direction_name = self.direction_var.get()
            distance_name = self.distance_var.get()
            
            if not direction_name or not distance_name:
                self.result_n_label.config(text="---")
                self.result_e_label.config(text="---")
                self.result_z_label.config(text="---")
                self.error_label.config(text="")
                return
            
            direction = self._direction_measurements.get(direction_name)
            distance = self._distance_measurements.get(distance_name)
            
            if not direction or not distance:
                raise ValueError("Invalid measurements selected")
            
            # Extract direction and distance values
            direction_obj = extract_direction_from_measurement(direction)
            distance_obj = extract_distance_from_measurement(distance)
            
            # Create point using Phase 2 function
            poline = create_line_from_vector(
                start_point=self.base_point,
                vector=direction_obj
            )
            distance=distance_obj
            
            # Update preview
            self.result_n_label.config(text=f"{poline.end_point.northing:.3f}")
            self.result_e_label.config(text=f"{poline.end_point.easting:.3f}")
            self.result_z_label.config(text=f"{poline.end_point.elevation:.3f}")
            self.result_z_label.config(text=f"{point.elevation:.3f}")
            self.error_label.config(text="")
            
            # Store result for OK
            self.result_point = point
            self.ok_button.config(state=tk.NORMAL)
            
            # Publish preview event
            if self.event_bus:
                preview_event = GeometryPreviewEvent(
                    geometry=point,
                    source="point_creation_dialog",
                    operation_type="create"
                )
                self.event_bus.publish(preview_event)
            
        except Exception as e:
            self.result_n_label.config(text="---")
            self.result_e_label.config(text="---")
            self.result_z_label.config(text="---")
            self.error_label.config(text=str(e))
            self.result_point = None
            self.ok_button.config(state=tk.DISABLED)
            
            # Clear preview
            if self.event_bus:
                preview_event = GeometryPreviewEvent(
                    geometry=None,
                    source="point_creation_dialog",
                    operation_type="create"
                )
                self.event_bus.publish(preview_event)
    
    def _on_ok(self):
        """Handle OK button click."""
        if self.result_point:
            self.destroy()
    
    def _on_cancel(self):
        """Handle Cancel button click."""
        self.result_point = None
        
        # Clear preview
        if self.event_bus:
            preview_event = GeometryPreviewEvent(
                geometry=None,
                source="point_creation_dialog",
                operation_type="create"
            )
            self.event_bus.publish(preview_event)
        
        self.destroy()


class CreateLineFromMeasurementsDialog(ttk_boot.Toplevel):
    """
    Dialog for creating a line from a start point and vector measurement.
    
    Uses the create_line_from_vector() function from Phase 2.
    """
    
    def __init__(self, parent, measurements: List[Measurement], start_point: Optional[Point] = None):
        super().__init__(parent)
        self.title("Create Line from Measurements")
        self.geometry("500x450")
        self.resizable(False, False)
        
        self.measurements = measurements
        self.result_line: Optional[LineSegment] = None
        self.start_point = start_point or Point(0, 0, 0)
        
        self._create_widgets()
        self._setup_bindings()
        self._update_preview()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self):
        """Create the dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk_boot.Label(
            main_frame,
            text="Create Line from Start Point + Vector",
            font=("TkDefaultFont", 12, "bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Vector measurement section
        vector_frame = ttk_boot.LabelFrame(main_frame, text="Vector Measurement", padding=5)
        vector_frame.pack(fill=tk.X, pady=5)
        
        self.vector_var = tk.StringVar()
        self.vector_combo = ttk_boot.Combobox(
            vector_frame,
            textvariable=self.vector_var,
            state="readonly"
        )
        self.vector_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Start point section
        start_frame = ttk_boot.LabelFrame(main_frame, text="Start Point", padding=5)
        start_frame.pack(fill=tk.X, pady=5)
        
        start_info_frame = ttk_boot.Frame(start_frame)
        start_info_frame.pack(fill=tk.X)
        
        ttk_boot.Label(start_info_frame, text="N:").grid(row=0, column=0, sticky=tk.W, padx=2)
        self.start_n_label = ttk_boot.Label(start_info_frame, text=f"{self.start_point.northing:.3f}")
        self.start_n_label.grid(row=0, column=1, sticky=tk.W, padx=2)
        
        ttk_boot.Label(start_info_frame, text="E:").grid(row=0, column=2, sticky=tk.W, padx=2)
        self.start_e_label = ttk_boot.Label(start_info_frame, text=f"{self.start_point.easting:.3f}")
        self.start_e_label.grid(row=0, column=3, sticky=tk.W, padx=2)
        
        ttk_boot.Label(start_info_frame, text="Z:").grid(row=0, column=4, sticky=tk.W, padx=2)
        self.start_z_label = ttk_boot.Label(start_info_frame, text=f"{self.start_point.elevation:.3f}")
        self.start_z_label.grid(row=0, column=5, sticky=tk.W, padx=2)
        
        # Result preview
        preview_frame = ttk_boot.LabelFrame(main_frame, text="Result Line", padding=5)
        preview_frame.pack(fill=tk.X, pady=5)
        
        # Start point (same as input)
        start_info_frame = ttk_boot.Frame(preview_frame)
        start_info_frame.pack(fill=tk.X)
        
        ttk_boot.Label(start_info_frame, text="Start:", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=0, sticky=tk.W, padx=2)
        ttk_boot.Label(start_info_frame, text=f"N={self.start_point.northing:.3f}").grid(row=0, column=1, sticky=tk.W, padx=2)
        ttk_boot.Label(start_info_frame, text=f"E={self.start_point.easting:.3f}").grid(row=0, column=2, sticky=tk.W, padx=2)
        ttk_boot.Label(start_info_frame, text=f"Z={self.start_point.elevation:.3f}").grid(row=0, column=3, sticky=tk.W, padx=2)
        
        # End point (calculated)
        end_info_frame = ttk_boot.Frame(preview_frame)
        end_info_frame.pack(fill=tk.X)
        
        ttk_boot.Label(end_info_frame, text="End:", font=("TkDefaultFont", 9, "bold")).grid(row=1, column=0, sticky=tk.W, padx=2)
        self.end_n_label = ttk_boot.Label(end_info_frame, text="---")
        self.end_n_label.grid(row=1, column=1, sticky=tk.W, padx=2)
        
        self.end_e_label = ttk_boot.Label(end_info_frame, text="---")
        self.end_e_label.grid(row=1, column=2, sticky=tk.W, padx=2)
        
        self.end_z_label = ttk_boot.Label(end_info_frame, text="---")
        self.end_z_label.grid(row=1, column=3, sticky=tk.W, padx=2)
        
        # Line properties
        props_info_frame = ttk_boot.Frame(preview_frame)
        props_info_frame.pack(fill=tk.X, pady=(5, 0))
        
        ttk_boot.Label(props_info_frame, text="Length:", font=("TkDefaultFont", 9, "bold")).grid(row=2, column=0, sticky=tk.W, padx=2)
        self.length_label = ttk_boot.Label(props_info_frame, text="---")
        self.length_label.grid(row=2, column=1, sticky=tk.W, padx=2)
        
        ttk_boot.Label(props_info_frame, text="Direction:", font=("TkDefaultFont", 9, "bold")).grid(row=2, column=2, sticky=tk.W, padx=2)
        self.direction_label = ttk_boot.Label(props_info_frame, text="---")
        self.direction_label.grid(row=2, column=3, sticky=tk.W, padx=2)
        
        # Error label
        self.error_label = ttk_boot.Label(main_frame, text="", foreground="red")
        self.error_label.pack(pady=5)
        
        # Button frame
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.ok_button = ttk_boot.Button(button_frame, text="OK", command=self._on_ok, style="success.TButton")
        self.ok_button.pack(side=tk.RIGHT, padx=5)
        
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT, padx=5)
        
        # Populate measurement combo
        self._populate_measurements()
        
    def _populate_measurements(self):
        """Populate the vector measurement dropdown."""
        # Get vector measurements
        vector_measurements = [
            (m.name, m) for m in self.measurements
            if m.measurement_type == MeasurementType.VECTOR_3D
        ]
        
        # Set dropdown values
        vector_names = [name for name, _ in vector_measurements]
        self.vector_combo['values'] = vector_names
        
        # Store measurement mapping
        self._vector_measurements = dict(vector_measurements)
        
        # Select first value if available
        if vector_names:
            self.vector_combo.current(0)
    
    def _setup_bindings(self):
        """Setup event bindings."""
        self.vector_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
        
        # Keyboard shortcuts
        self.bind('<Return>', lambda e: self._on_ok())
        self.bind('<Escape>', lambda e: self._on_cancel())
    
    def _update_preview(self):
        """Update the preview based on selected vector."""
        try:
            vector_name = self.vector_var.get()
            
            if not vector_name:
                self.end_n_label.config(text="---")
                self.end_e_label.config(text="---")
                self.end_z_label.config(text="---")
                self.length_label.config(text="---")
                self.direction_label.config(text="---")
                self.error_label.config(text="")
                return
            
            vector = self._vector_measurements.get(vector_name)
            
            if not vector:
                raise ValueError("Invalid vector measurement selected")
            
            # Extract vector from measurement
            vector_obj = extract_vector_from_measurement(vector)
            
            # Create line using Phase 2 function
            line = create_line_from_vector(self.start_point, vector_obj)
            
            # Calculate direction from the vector
            direction_radians = math.atan2(vector_obj.delta_easting, vector_obj.delta_northing)
            if direction_radians < 0:
                direction_radians += 2 * math.pi
            direction_obj = SurveyorsDirection(direction_radians)
            
            # Update preview
            self.end_n_label.config(text=f"{line.end_point.northing:.3f}")
            self.end_e_label.config(text=f"{line.end_point.easting:.3f}")
            self.end_z_label.config(text=f"{line.end_point.elevation:.3f}")
            self.length_label.config(text=f"{line.length():.3f}")
            self.direction_label.config(text=f"{direction_obj.decimal_degrees:.2f}°")
            self.error_label.config(text="")
            
            # Store result for OK
            self.result_line = line
            self.ok_button.config(state=tk.NORMAL)
            
        except Exception as e:
            self.end_n_label.config(text="---")
            self.end_e_label.config(text="---")
            self.end_z_label.config(text="---")
            self.length_label.config(text="---")
            self.direction_label.config(text="---")
            self.error_label.config(text=str(e))
            self.result_line = None
            self.ok_button.config(state=tk.DISABLED)
    
    def _on_ok(self):
        """Handle OK button click."""
        if self.result_line:
            self.destroy()
    
    def _on_cancel(self):
        """Handle Cancel button click."""
        self.result_line = None
        self.destroy()


class CreatePolylineFromMeasurementsDialog(ttk_boot.Toplevel):
    """
    Dialog for creating a polyline from direction/distance measurement pairs.
    
    Uses the create_polyline_from_direction_distance_pairs() function from Phase 2.
    """
    
    def __init__(self, parent, measurements: List[Measurement], base_point: Optional[Point] = None):
        super().__init__(parent)
        self.title("Create Polyline from Measurements")
        self.geometry("600x500")
        self.resizable(False, False)
        
        self.measurements = measurements
        self.result_polyline: Optional[SimplePolyline] = None
        self.base_point = base_point or Point(0, 0, 0)
        
        self._create_widgets()
        self._setup_bindings()
        self._update_preview()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self):
        """Create the dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk_boot.Label(
            main_frame,
            text="Create Polyline from Direction/Distance Pairs",
            font=("TkDefaultFont", 12, "bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Measurement pairs frame with scrollbar
        pairs_frame = ttk_boot.LabelFrame(main_frame, text="Direction/Distance Pairs", padding=5)
        pairs_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Create scrollable frame
        canvas = tk.Canvas(pairs_frame, height=200)
        scrollbar = ttk_boot.Scrollbar(pairs_frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk_boot.Frame(canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Headers
        ttk_boot.Label(self.scrollable_frame, text="Leg #", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=0, padx=5, pady=2)
        ttk_boot.Label(self.scrollable_frame, text="Direction", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=1, padx=5, pady=2)
        ttk_boot.Label(self.scrollable_frame, text="Distance", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=2, padx=5, pady=2)
        
        # Initialize empty lists for widgets
        self.direction_combos = []
        self.distance_combos = []
        self.direction_vars = []
        self.distance_vars = []
        
        # Base point section
        base_frame = ttk_boot.LabelFrame(main_frame, text="Base Point", padding=5)
        base_frame.pack(fill=tk.X, pady=5)
        
        base_info_frame = ttk_boot.Frame(base_frame)
        base_info_frame.pack(fill=tk.X)
        
        ttk_boot.Label(base_info_frame, text="N:").grid(row=0, column=0, sticky=tk.W, padx=2)
        self.base_n_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.northing:.3f}")
        self.base_n_label.grid(row=0, column=1, sticky=tk.W, padx=2)
        
        ttk_boot.Label(base_info_frame, text="E:").grid(row=0, column=2, sticky=tk.W, padx=2)
        self.base_e_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.easting:.3f}")
        self.base_e_label.grid(row=0, column=3, sticky=tk.W, padx=2)
        
        ttk_boot.Label(base_info_frame, text="Z:").grid(row=0, column=4, sticky=tk.W, padx=2)
        self.base_z_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.elevation:.3f}")
        self.base_z_label.grid(row=0, column=5, sticky=tk.W, padx=2)
        
        # Control buttons
        control_frame = ttk_boot.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=5)
        
        ttk_boot.Button(control_frame, text="Add Leg", command=self._add_leg).pack(side=tk.LEFT, padx=5)
        ttk_boot.Button(control_frame, text="Remove Last", command=self._remove_last_leg).pack(side=tk.LEFT, padx=5)
        ttk_boot.Button(control_frame, text="Clear All", command=self._clear_all).pack(side=tk.LEFT, padx=5)
        
        # Result preview
        preview_frame = ttk_boot.LabelFrame(main_frame, text="Result", padding=5)
        preview_frame.pack(fill=tk.X, pady=5)
        
        self.result_text = tk.Text(preview_frame, height=4, width=50, state=tk.DISABLED)
        self.result_text.pack(fill=tk.X, padx=5, pady=2)
        
        # Error label
        self.error_label = ttk_boot.Label(main_frame, text="", foreground="red")
        self.error_label.pack(pady=5)
        
        # Button frame
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.ok_button = ttk_boot.Button(button_frame, text="OK", command=self._on_ok, style="success.TButton")
        self.ok_button.pack(side=tk.RIGHT, padx=5)
        
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT, padx=5)
        
        # Populate measurement options
        self._populate_measurements()
        
        # Add initial leg
        self._add_leg()
        
    def _populate_measurements(self):
        """Populate measurement options."""
        # Get direction measurements
        self._direction_measurements = {
            m.name: m for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DIRECTION,
                MeasurementType.AZIMUTH,
                MeasurementType.BEARING
            ]
        }
        
        # Get distance measurements
        self._distance_measurements = {
            m.name: m for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DISTANCE,
                MeasurementType.HORIZONTAL_DISTANCE,
                MeasurementType.SLOPE_DISTANCE,
                MeasurementType.VERTICAL_DISTANCE
            ]
        }
        
        self.direction_names = list(self._direction_measurements.keys())
        self.distance_names = list(self._distance_measurements.keys())
    
    def _add_leg(self):
        """Add a new leg row."""
        row = len(self.direction_combos) + 1  # +1 for header
        
        # Leg number
        ttk_boot.Label(self.scrollable_frame, text=f"{row}").grid(row=row, column=0, padx=5, pady=2)
        
        # Direction combo
        direction_var = tk.StringVar()
        direction_combo = ttk_boot.Combobox(
            self.scrollable_frame,
            textvariable=direction_var,
            values=self.direction_names,
            state="readonly",
            width=25
        )
        direction_combo.grid(row=row, column=1, padx=5, pady=2)
        
        # Distance combo
        distance_var = tk.StringVar()
        distance_combo = ttk_boot.Combobox(
            self.scrollable_frame,
            textvariable=distance_var,
            values=self.distance_names,
            state="readonly",
            width=25
        )
        distance_combo.grid(row=row, column=2, padx=5, pady=2)
        
        # Store widgets
        self.direction_vars.append(direction_var)
        self.distance_vars.append(distance_var)
        self.direction_combos.append(direction_combo)
        self.distance_combos.append(distance_combo)
        
        # Bind events
        direction_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
        distance_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
    
    def _remove_last_leg(self):
        """Remove the last leg row."""
        if self.direction_combos:
            # Destroy widgets
            row = len(self.direction_combos)
            self.direction_combos[-1].destroy()
            self.distance_combos[-1].destroy()
            
            # Remove from lists
            self.direction_combos.pop()
            self.distance_combos.pop()
            self.direction_vars.pop()
            self.distance_vars.pop()
            
            # Remove leg number label
            for widget in self.scrollable_frame.grid_slaves(row=row):
                widget.destroy()
            
            self._update_preview()
    
    def _clear_all(self):
        """Clear all legs."""
        while self.direction_combos:
            self._remove_last_leg()
        self._add_leg()
    
    def _setup_bindings(self):
        """Setup event bindings."""
        # Keyboard shortcuts
        self.bind('<Return>', lambda e: self._on_ok())
        self.bind('<Escape>', lambda e: self._on_cancel())
    
    def _update_preview(self):
        """Update the preview based on selected measurements."""
        try:
            # Collect direction/distance pairs
            direction_distance_pairs = []
            
            for dir_var, dist_var in zip(self.direction_vars, self.distance_vars):
                dir_name = dir_var.get()
                dist_name = dist_var.get()
                
                if not dir_name or not dist_name:
                    continue
                
                direction = self._direction_measurements.get(dir_name)
                distance = self._distance_measurements.get(dist_name)
                
                if not direction or not distance:
                    continue
                
                direction_obj = extract_direction_from_measurement(direction)
                distance_obj = extract_distance_from_measurement(distance)
                
                direction_distance_pairs.append((direction_obj, distance_obj))
            
            if not direction_distance_pairs:
                self.result_text.config(state=tk.NORMAL)
                self.result_text.delete(1.0, tk.END)
                self.result_text.insert(tk.END, "Select at least one complete direction/distance pair")
                self.result_text.config(state=tk.DISABLED)
                self.error_label.config(text="")
                self.result_polyline = None
                self.ok_button.config(state=tk.DISABLED)
                return
            
            # Create polyline using Phase 2 function
            polyline = create_polyline_from_direction_distance_pairs(
                self.base_point, direction_distance_pairs
            )
            
            # Calculate closure info
            start_point = polyline.points[0]
            end_point = polyline.points[-1]
            closure_distance = start_point.distance_to(end_point)
            
            # Update result text
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"Points: {len(polyline.points)}\n")
            self.result_text.insert(tk.END, f"Total Length: {polyline.length():.3f}\n")
            self.result_text.insert(tk.END, f"Start: N={start_point.northing:.3f}, E={start_point.easting:.3f}\n")
            self.result_text.insert(tk.END, f"End: N={end_point.northing:.3f}, E={end_point.easting:.3f}\n")
            self.result_text.insert(tk.END, f"Closure: {closure_distance:.6f}")
            self.result_text.config(state=tk.DISABLED)
            
            self.error_label.config(text="")
            self.result_polyline = polyline
            self.ok_button.config(state=tk.NORMAL)
            
        except Exception as e:
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "Error creating polyline")
            self.result_text.config(state=tk.DISABLED)
            self.error_label.config(text=str(e))
            self.result_polyline = None
            self.ok_button.config(state=tk.DISABLED)
    
    def _on_ok(self):
        """Handle OK button click."""
        if self.result_polyline:
            self.destroy()
    
    def _on_cancel(self):
        """Handle Cancel button click."""
        self.result_polyline = None
        self.destroy()


class CreateRectangleFromMeasurementsDialog(ttk_boot.Toplevel):
    """
    Dialog for creating a rectangle from a base point and dimension measurements.
    
    Uses the create_rectangle() function from Phase 2.
    """
    
    def __init__(self, parent, measurements: List[Measurement], base_point: Optional[Point] = None):
        super().__init__(parent)
        self.title("Create Rectangle from Measurements")
        self.geometry("500x550")
        self.resizable(False, False)
        
        self.measurements = measurements
        self.result_rectangle: Optional[SimplePolygon] = None
        self.base_point = base_point or Point(0, 0, 0)
        
        self._create_widgets()
        self._setup_bindings()
        self._update_preview()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
        
    def _create_widgets(self):
        """Create the dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk_boot.Label(
            main_frame,
            text="Create Rectangle from Dimensions",
            font=("TkDefaultFont", 12, "bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Width measurement section
        width_frame = ttk_boot.LabelFrame(main_frame, text="Width Measurement", padding=5)
        width_frame.pack(fill=tk.X, pady=5)
        
        self.width_var = tk.StringVar()
        self.width_combo = ttk_boot.Combobox(
            width_frame,
            textvariable=self.width_var,
            state="readonly"
        )
        self.width_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Height measurement section
        height_frame = ttk_boot.LabelFrame(main_frame, text="Height Measurement", padding=5)
        height_frame.pack(fill=tk.X, pady=5)
        
        self.height_var = tk.StringVar()
        self.height_combo = ttk_boot.Combobox(
            height_frame,
            textvariable=self.height_var,
            state="readonly"
        )
        self.height_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Direction section (optional - for rotated rectangle)
        direction_frame = ttk_boot.LabelFrame(main_frame, text="Direction (Optional)", padding=5)
        direction_frame.pack(fill=tk.X, pady=5)
        
        self.use_direction_var = tk.BooleanVar(value=False)
        self.use_direction_check = ttk_boot.Checkbutton(
            direction_frame,
            text="Rotate rectangle using direction measurement",
            variable=self.use_direction_var,
            command=self._on_direction_toggle
        )
        self.use_direction_check.pack(fill=tk.X, padx=5, pady=2)
        
        self.direction_var = tk.StringVar()
        self.direction_combo = ttk_boot.Combobox(
            direction_frame,
            textvariable=self.direction_var,
            state="readonly"
        )
        self.direction_combo.pack(fill=tk.X, padx=5, pady=2)
        
        # Initially disable direction
        self.direction_combo.config(state=tk.DISABLED)
        
        # Base point section
        base_frame = ttk_boot.LabelFrame(main_frame, text="Base Point (Lower-left corner)", padding=5)
        base_frame.pack(fill=tk.X, pady=5)
        
        base_info_frame = ttk_boot.Frame(base_frame)
        base_info_frame.pack(fill=tk.X)
        
        ttk_boot.Label(base_info_frame, text="N:").grid(row=0, column=0, sticky=tk.W, padx=2)
        self.base_n_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.northing:.3f}")
        self.base_n_label.grid(row=0, column=1, sticky=tk.W, padx=2)
        
        ttk_boot.Label(base_info_frame, text="E:").grid(row=0, column=2, sticky=tk.W, padx=2)
        self.base_e_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.easting:.3f}")
        self.base_e_label.grid(row=0, column=3, sticky=tk.W, padx=2)
        
        ttk_boot.Label(base_info_frame, text="Z:").grid(row=0, column=4, sticky=tk.W, padx=2)
        self.base_z_label = ttk_boot.Label(base_info_frame, text=f"{self.base_point.elevation:.3f}")
        self.base_z_label.grid(row=0, column=5, sticky=tk.W, padx=2)
        
        # Result preview
        preview_frame = ttk_boot.LabelFrame(main_frame, text="Result", padding=5)
        preview_frame.pack(fill=tk.X, pady=5)
        
        self.result_text = tk.Text(preview_frame, height=5, width=50, state=tk.DISABLED)
        self.result_text.pack(fill=tk.X, padx=5, pady=2)
        
        # Error label
        self.error_label = ttk_boot.Label(main_frame, text="", foreground="red")
        self.error_label.pack(pady=5)
        
        # Button frame
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.ok_button = ttk_boot.Button(button_frame, text="OK", command=self._on_ok, style="success.TButton")
        self.ok_button.pack(side=tk.RIGHT, padx=5)
        
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT, padx=5)
        
        # Populate measurement combos
        self._populate_measurements()
        
    def _populate_measurements(self):
        """Populate the measurement dropdowns."""
        # Get distance measurements for width/height
        distance_measurements = [
            (m.name, m) for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DISTANCE,
                MeasurementType.HORIZONTAL_DISTANCE
            ]
        ]
        
        # Get direction measurements for rotation
        direction_measurements = [
            (m.name, m) for m in self.measurements
            if m.measurement_type in [
                MeasurementType.DIRECTION,
                MeasurementType.AZIMUTH,
                MeasurementType.BEARING
            ]
        ]
        
        # Set dropdown values
        distance_names = [name for name, _ in distance_measurements]
        direction_names = [name for name, _ in direction_measurements]
        
        self.width_combo['values'] = distance_names
        self.height_combo['values'] = distance_names
        self.direction_combo['values'] = direction_names
        
        # Store measurement mappings
        self._distance_measurements = dict(distance_measurements)
        self._direction_measurements = dict(direction_measurements)
        
        # Select first values if available
        if distance_names:
            self.width_combo.current(0)
            self.height_combo.current(min(1, len(distance_names) - 1))
        if direction_names:
            self.direction_combo.current(0)
    
    def _setup_bindings(self):
        """Setup event bindings."""
        self.width_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
        self.height_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
        self.direction_combo.bind('<<ComboboxSelected>>', lambda e: self._update_preview())
        
        # Keyboard shortcuts
        self.bind('<Return>', lambda e: self._on_ok())
        self.bind('<Escape>', lambda e: self._on_cancel())
    
    def _on_direction_toggle(self):
        """Handle direction checkbox toggle."""
        if self.use_direction_var.get():
            self.direction_combo.config(state="readonly")
        else:
            self.direction_combo.config(state=tk.DISABLED)
            self.direction_var.set("")
        self._update_preview()
    
    def _update_preview(self):
        """Update the preview based on selected measurements."""
        try:
            width_name = self.width_var.get()
            height_name = self.height_var.get()
            
            if not width_name or not height_name:
                self.result_text.config(state=tk.NORMAL)
                self.result_text.delete(1.0, tk.END)
                self.result_text.insert(tk.END, "Select width and height measurements")
                self.result_text.config(state=tk.DISABLED)
                self.error_label.config(text="")
                self.result_rectangle = None
                self.ok_button.config(state=tk.DISABLED)
                return
            
            width = self._distance_measurements.get(width_name)
            height = self._distance_measurements.get(height_name)
            
            if not width or not height:
                raise ValueError("Invalid measurements selected")
            
            # Extract distance values
            width_obj = extract_distance_from_measurement(width)
            height_obj = extract_distance_from_measurement(height)
            
            # Check for direction (rotation)
            if self.use_direction_var.get():
                direction_name = self.direction_var.get()
                if direction_name:
                    direction = self._direction_measurements.get(direction_name)
                    if direction:
                        direction_obj = extract_direction_from_measurement(direction)
                        # Create rotated rectangle using vector approach
                        # First create basic rectangle, then rotate
                        rect = create_rectangle(self.base_point, width_obj, height_obj)
                        # TODO: Implement rotation using direction
                        self.result_text.config(state=tk.NORMAL)
                        self.result_text.delete(1.0, tk.END)
                        self.result_text.insert(tk.END, "Rotation not yet implemented\n")
                        self.result_text.insert(tk.END, f"Width: {width_obj:.3f}, Height: {height_obj:.3f}\n")
                        self.result_text.insert(tk.END, f"Direction: {direction_obj.decimal_degrees:.2f}°\n")
                        self.result_text.insert(tk.END, "Creating axis-aligned rectangle")
                        self.result_text.config(state=tk.DISABLED)
                    else:
                        self.result_text.config(state=tk.NORMAL)
                        self.result_text.delete(1.0, tk.END)
                        self.result_text.insert(tk.END, "Invalid direction measurement")
                        self.result_text.config(state=tk.DISABLED)
                else:
                    self.result_text.config(state=tk.NORMAL)
                    self.result_text.delete(1.0, tk.END)
                    self.result_text.insert(tk.END, "Direction enabled but not selected")
                    self.result_text.config(state=tk.DISABLED)
            else:
                # Create rectangle using Phase 2 function
                rect = create_rectangle(self.base_point, width_obj, height_obj)
                self.result_rectangle = rect
                
                # Update result text
                self.result_text.config(state=tk.NORMAL)
                self.result_text.delete(1.0, tk.END)
                self.result_text.insert(tk.END, f"Area: {rect.area:.3f}\n")
                self.result_text.insert(tk.END, f"Perimeter: {rect.length():.3f}\n")
                self.result_text.insert(tk.END, f"Width: {width_obj:.3f}, Height: {height_obj:.3f}\n")
                self.result_text.insert(tk.END, f"Points: {len(rect.points)}\n")
                self.result_text.insert(tk.END, f"Base: N={self.base_point.northing:.3f}, E={self.base_point.easting:.3f}")
                self.result_text.config(state=tk.DISABLED)
            
            self.error_label.config(text="")
            self.ok_button.config(state=tk.NORMAL)
            
        except Exception as e:
            self.result_text.config(state=tk.NORMAL)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "Error creating rectangle")
            self.result_text.config(state=tk.DISABLED)
            self.error_label.config(text=str(e))
            self.result_rectangle = None
            self.ok_button.config(state=tk.DISABLED)
    
    def _on_ok(self):
        """Handle OK button click."""
        if self.result_rectangle:
            self.destroy()
    
    def _on_cancel(self):
        """Handle Cancel button click."""
        self.result_rectangle = None
        self.destroy()
