"""Properties dialog for viewing and editing geometry metadata."""

import tkinter as tk
from tkinter import messagebox
from typing import Optional
import ttkbootstrap as ttk_boot

from plana_figura import Geometry
from plana_figura.exceptions import ValidationError


class GeometryPropertiesDialog(tk.Toplevel):
    """
    Modal dialog for viewing and editing geometry properties.
    
    Displays:
    - Type (read-only)
    - UUID (read-only, with copy button)
    - Name (editable)
    - DXF Handle (read-only)
    
    The dialog allows editing the name property while keeping
    other metadata read-only for data integrity.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        geometry: Geometry,
        title: str = "Geometry Properties"
    ):
        """
        Initialize the properties dialog.
        
        Args:
            parent: Parent widget
            geometry: The geometry to display/edit
            title: Dialog title
        """
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        
        self.geometry_obj = geometry
        self.result: bool = False  # True if OK clicked, False if cancelled
        
        self._create_widgets()
        self._populate_fields()
        
        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_y() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
        
        # Focus name field
        self.name_entry.focus_set()
        
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        ttk_boot.Label(
            main_frame,
            text="Geometry Properties",
            font=("Segoe UI", 12, "bold")
        ).grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # Type (read-only)
        ttk_boot.Label(main_frame, text="Type:").grid(
            row=1, column=0, sticky=tk.W, pady=5
        )
        self.type_label = ttk_boot.Label(
            main_frame,
            text="",
            font=("Segoe UI", 9, "bold")
        )
        self.type_label.grid(row=1, column=1, columnspan=2, sticky=tk.W, pady=5, padx=5)
        
        # UUID (read-only with copy button)
        ttk_boot.Label(main_frame, text="UUID:").grid(
            row=2, column=0, sticky=tk.W, pady=5
        )
        self.uuid_entry = ttk_boot.Entry(main_frame, width=25, state="readonly")
        self.uuid_entry.grid(row=2, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Button(
            main_frame,
            text="Copy",
            command=self._copy_uuid,
            bootstyle="info-outline",
            width=8
        ).grid(row=2, column=2, pady=5, padx=5)
        
        # Name (editable)
        ttk_boot.Label(main_frame, text="Name:").grid(
            row=3, column=0, sticky=tk.W, pady=5
        )
        self.name_entry = ttk_boot.Entry(main_frame, width=30)
        self.name_entry.grid(row=3, column=1, columnspan=2, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(
            main_frame,
            text="(Optional - leave blank for default)",
            font=("Segoe UI", 8),
            foreground="gray"
        ).grid(row=4, column=1, columnspan=2, sticky=tk.W, padx=5)
        
        # DXF Handle (read-only)
        ttk_boot.Label(main_frame, text="DXF Handle:").grid(
            row=5, column=0, sticky=tk.W, pady=5
        )
        self.dxf_handle_entry = ttk_boot.Entry(main_frame, width=25, state="readonly")
        self.dxf_handle_entry.grid(row=5, column=1, columnspan=2, sticky=tk.EW, pady=5, padx=5)
        
        # Separator
        ttk_boot.Separator(main_frame, orient=tk.HORIZONTAL).grid(
            row=6, column=0, columnspan=3, sticky=tk.EW, pady=20
        )
        
        # Buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=7, column=0, columnspan=3, pady=10)
        
        ttk_boot.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle="success",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        # Configure grid
        main_frame.columnconfigure(1, weight=1)
        
        # Bind keys
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _populate_fields(self) -> None:
        """Populate fields with current geometry values."""
        # Type
        self.type_label.config(text=type(self.geometry_obj).__name__)
        
        # UUID
        if hasattr(self.geometry_obj, 'uuid') and self.geometry_obj.uuid:
            self.uuid_entry.config(state="normal")
            self.uuid_entry.delete(0, tk.END)
            self.uuid_entry.insert(0, self.geometry_obj.uuid)
            self.uuid_entry.config(state="readonly")
        else:
            self.uuid_entry.config(state="normal")
            self.uuid_entry.delete(0, tk.END)
            self.uuid_entry.insert(0, "(Not assigned)")
            self.uuid_entry.config(state="readonly")
        
        # Name
        if hasattr(self.geometry_obj, 'name') and self.geometry_obj.name:
            self.name_entry.insert(0, self.geometry_obj.name)
        
        # DXF Handle
        if hasattr(self.geometry_obj, 'dxf_handle') and self.geometry_obj.dxf_handle:
            self.dxf_handle_entry.config(state="normal")
            self.dxf_handle_entry.delete(0, tk.END)
            self.dxf_handle_entry.insert(0, self.geometry_obj.dxf_handle)
            self.dxf_handle_entry.config(state="readonly")
        else:
            self.dxf_handle_entry.config(state="normal")
            self.dxf_handle_entry.delete(0, tk.END)
            self.dxf_handle_entry.insert(0, "(None)")
            self.dxf_handle_entry.config(state="readonly")
    
    def _copy_uuid(self) -> None:
        """Copy UUID to clipboard."""
        if hasattr(self.geometry_obj, 'uuid') and self.geometry_obj.uuid:
            self.clipboard_clear()
            self.clipboard_append(self.geometry_obj.uuid)
            messagebox.showinfo(
                "Copied",
                f"UUID copied to clipboard:\n{self.geometry_obj.uuid}"
            )
        else:
            messagebox.showwarning("No UUID", "This geometry does not have a UUID.")
    
    def _on_ok(self) -> None:
        """Handle OK button - save changes."""
        # Update name
        new_name = self.name_entry.get().strip()
        
        # Set name (empty string becomes None)
        if hasattr(self.geometry_obj, 'name'):
            try:
                self.geometry_obj.name = new_name if new_name else None
                self.result = True
                self.destroy()
            except (ValidationError, ValueError) as e:
                messagebox.showerror("Invalid Input", str(e))
        else:
            messagebox.showerror(
                "Error",
                "This geometry does not support the name property."
            )
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = False
        self.destroy()
