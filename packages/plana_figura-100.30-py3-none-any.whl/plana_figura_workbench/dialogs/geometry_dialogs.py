"""
Modal dialogs for geometry creation/editing.

These are the View components that use the testable controllers.
"""

import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk_boot
from typing import Optional
import logging

from plana_figura import Point, LineSegment
from plana_figura.composite import SimplePolyline, SimplePolygon
from plana_figura.linear import CircularArc
from plana_figura_workbench.dialogs.geometry_dialog_controller import (
    PointDialogController,
    LineDialogController,
    PolylineDialogController,
    CircularArcDialogController,
)

logger = logging.getLogger(__name__)


class PointDialog(tk.Toplevel):
    """
    Modal dialog for creating/editing a Point.
    
    Uses PointDialogController for business logic.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        point: Optional[Point] = None,
        title: str = "Create Point"
    ):
        """
        Initialize the dialog.
        
        Args:
            parent: Parent widget
            point: Existing point to edit (None for create mode)
            title: Dialog title
        """
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        
        # Controller
        self.controller = PointDialogController()
        if point:
            self.controller.load_point(point)
        
        # Result
        self.result: Optional[Point] = None
        
        self._create_widgets()
        self._populate_fields()
        
        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_y() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
        
        # Focus first field
        self.northing_entry.focus_set()
    
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Northing
        ttk_boot.Label(main_frame, text="Northing:").grid(
            row=0, column=0, sticky=tk.W, pady=5
        )
        self.northing_entry = ttk_boot.Entry(main_frame, width=20)
        self.northing_entry.grid(row=0, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Easting
        ttk_boot.Label(main_frame, text="Easting:").grid(
            row=1, column=0, sticky=tk.W, pady=5
        )
        self.easting_entry = ttk_boot.Entry(main_frame, width=20)
        self.easting_entry.grid(row=1, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Elevation
        ttk_boot.Label(main_frame, text="Elevation:").grid(
            row=2, column=0, sticky=tk.W, pady=5
        )
        self.elevation_entry = ttk_boot.Entry(main_frame, width=20)
        self.elevation_entry.grid(row=2, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Name (optional)
        ttk_boot.Label(main_frame, text="Name (optional):").grid(
            row=3, column=0, sticky=tk.W, pady=5
        )
        self.name_entry = ttk_boot.Entry(main_frame, width=20)
        self.name_entry.grid(row=3, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=20)
        
        ttk_boot.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle="success",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        # Configure grid
        main_frame.columnconfigure(1, weight=1)
        
        # Bind Enter key
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _populate_fields(self) -> None:
        """Populate fields with initial values."""
        values = self.controller.get_initial_values()
        self.northing_entry.insert(0, values['northing'])
        self.easting_entry.insert(0, values['easting'])
        self.elevation_entry.insert(0, values['elevation'])
        if values.get('name'):
            self.name_entry.insert(0, values['name'])
    
    def _on_ok(self) -> None:
        """Handle OK button."""
        # Set values in controller
        if not self.controller.set_northing(self.northing_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid northing value")
            self.northing_entry.focus_set()
            return
        
        if not self.controller.set_easting(self.easting_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid easting value")
            self.easting_entry.focus_set()
            return
        
        if not self.controller.set_elevation(self.elevation_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid elevation value")
            self.elevation_entry.focus_set()
            return
        
        # Set name (optional)
        self.controller.set_name(self.name_entry.get())
        
        # Create point
        self.result = self.controller.create_point()
        if self.result:
            self.destroy()
        else:
            messagebox.showerror("Error", "Failed to create point")
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()


class LineDialog(tk.Toplevel):
    """
    Modal dialog for creating/editing a LineSegment.
    
    Uses LineDialogController for business logic.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        line: Optional[LineSegment] = None,
        title: str = "Create Line"
    ):
        """
        Initialize the dialog.
        
        Args:
            parent: Parent widget
            line: Existing line to edit (None for create mode)
            title: Dialog title
        """
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        
        # Controller
        self.controller = LineDialogController()
        if line:
            self.controller.load_line(line)
        
        # Result
        self.result: Optional[LineSegment] = None
        
        self._create_widgets()
        self._populate_fields()
        
        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_y() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
        
        # Focus first field
        self.start_n_entry.focus_set()
    
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Start Point section
        ttk_boot.Label(
            main_frame,
            text="Start Point",
            font=("Segoe UI", 10, "bold")
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 10))
        
        ttk_boot.Label(main_frame, text="Northing:").grid(
            row=1, column=0, sticky=tk.W, pady=5
        )
        self.start_n_entry = ttk_boot.Entry(main_frame, width=20)
        self.start_n_entry.grid(row=1, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Easting:").grid(
            row=2, column=0, sticky=tk.W, pady=5
        )
        self.start_e_entry = ttk_boot.Entry(main_frame, width=20)
        self.start_e_entry.grid(row=2, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Elevation:").grid(
            row=3, column=0, sticky=tk.W, pady=5
        )
        self.start_z_entry = ttk_boot.Entry(main_frame, width=20)
        self.start_z_entry.grid(row=3, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # End Point section
        ttk_boot.Label(
            main_frame,
            text="End Point",
            font=("Segoe UI", 10, "bold")
        ).grid(row=4, column=0, columnspan=2, sticky=tk.W, pady=(20, 10))
        
        ttk_boot.Label(main_frame, text="Northing:").grid(
            row=5, column=0, sticky=tk.W, pady=5
        )
        self.end_n_entry = ttk_boot.Entry(main_frame, width=20)
        self.end_n_entry.grid(row=5, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Easting:").grid(
            row=6, column=0, sticky=tk.W, pady=5
        )
        self.end_e_entry = ttk_boot.Entry(main_frame, width=20)
        self.end_e_entry.grid(row=6, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Elevation:").grid(
            row=7, column=0, sticky=tk.W, pady=5
        )
        self.end_z_entry = ttk_boot.Entry(main_frame, width=20)
        self.end_z_entry.grid(row=7, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Name (optional)
        ttk_boot.Label(main_frame, text="Name (optional):").grid(
            row=8, column=0, sticky=tk.W, pady=5
        )
        self.name_entry = ttk_boot.Entry(main_frame, width=20)
        self.name_entry.grid(row=8, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=9, column=0, columnspan=2, pady=20)
        
        ttk_boot.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle="success",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        # Configure grid
        main_frame.columnconfigure(1, weight=1)
        
        # Bind keys
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _populate_fields(self) -> None:
        """Populate fields with initial values."""
        values = self.controller.get_initial_values()
        self.start_n_entry.insert(0, values['start_n'])
        self.start_e_entry.insert(0, values['start_e'])
        self.start_z_entry.insert(0, values['start_z'])
        self.end_n_entry.insert(0, values['end_n'])
        self.end_e_entry.insert(0, values['end_e'])
        self.end_z_entry.insert(0, values['end_z'])
        if values.get('name'):
            self.name_entry.insert(0, values['name'])
    
    def _on_ok(self) -> None:
        """Handle OK button."""
        # Set start point
        if not self.controller.set_start_northing(self.start_n_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid start northing")
            self.start_n_entry.focus_set()
            return
        
        if not self.controller.set_start_easting(self.start_e_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid start easting")
            self.start_e_entry.focus_set()
            return
        
        if not self.controller.set_start_elevation(self.start_z_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid start elevation")
            self.start_z_entry.focus_set()
            return
        
        # Set end point
        if not self.controller.set_end_northing(self.end_n_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid end northing")
            self.end_n_entry.focus_set()
            return
        
        if not self.controller.set_end_easting(self.end_e_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid end easting")
            self.end_e_entry.focus_set()
            return
        
        if not self.controller.set_end_elevation(self.end_z_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid end elevation")
            self.end_z_entry.focus_set()
            return
        
        # Set name (optional)
        self.controller.set_name(self.name_entry.get())
        
        # Validate and create
        is_valid, error = self.controller.is_valid()
        if not is_valid:
            messagebox.showerror("Invalid Input", error)
            return
        
        self.result = self.controller.create_line()
        if self.result:
            self.destroy()
        else:
            messagebox.showerror("Error", "Failed to create line")
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()


class PolylineDialog(tk.Toplevel):
    """
    Modal dialog for creating/editing a SimplePolyline.
    
    Uses PolylineDialogController for business logic.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        polyline: Optional[SimplePolyline] = None,
        title: str = "Create Polyline"
    ):
        """
        Initialize the dialog.
        
        Args:
            parent: Parent widget
            polyline: Existing polyline to edit (None for create mode)
            title: Dialog title
        """
        super().__init__(parent)
        self.title(title)
        self.geometry("500x600")
        self.transient(parent)
        self.grab_set()
        
        # Controller
        self.controller = PolylineDialogController()
        if polyline:
            self.controller.load_polyline(polyline)
        
        # Result
        self.result: Optional[SimplePolyline] = None
        
        self._create_widgets()
        
        # Load name if editing
        if polyline and polyline.name:
            self.name_entry.insert(0, polyline.name)
        
        self._populate_list()
        
        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_y() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
        
        # Focus first field
        self.n_entry.focus_set()
    
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Name field
        name_frame = ttk_boot.Frame(main_frame)
        name_frame.grid(row=0, column=0, sticky=tk.EW, pady=(0, 10))
        ttk_boot.Label(name_frame, text="Name (optional):").pack(side=tk.LEFT, padx=5)
        self.name_entry = ttk_boot.Entry(name_frame, width=30)
        self.name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # Input section
        input_frame = ttk_boot.LabelFrame(
            main_frame,
            text="Add Point",
            padding=10
        )
        input_frame.grid(row=1, column=0, sticky=tk.EW, pady=(0, 10))
        
        ttk_boot.Label(input_frame, text="N:").grid(row=0, column=0, sticky=tk.W)
        self.n_entry = ttk_boot.Entry(input_frame, width=12)
        self.n_entry.grid(row=0, column=1, padx=5)
        
        ttk_boot.Label(input_frame, text="E:").grid(row=0, column=2, sticky=tk.W)
        self.e_entry = ttk_boot.Entry(input_frame, width=12)
        self.e_entry.grid(row=0, column=3, padx=5)
        
        ttk_boot.Label(input_frame, text="Z:").grid(row=0, column=4, sticky=tk.W)
        self.z_entry = ttk_boot.Entry(input_frame, width=12)
        self.z_entry.insert(0, "0.0")
        self.z_entry.grid(row=0, column=5, padx=5)
        
        ttk_boot.Button(
            input_frame,
            text="Add",
            command=self._on_add_point,
            bootstyle="primary",
            width=8
        ).grid(row=0, column=6, padx=5)
        
        # Points list
        list_frame = ttk_boot.LabelFrame(
            main_frame,
            text="Points",
            padding=10
        )
        list_frame.grid(row=2, column=0, sticky=tk.NSEW, pady=(0, 10))
        
        # Listbox with scrollbar
        scrollbar = ttk_boot.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.points_listbox = tk.Listbox(
            list_frame,
            height=10,
            yscrollcommand=scrollbar.set
        )
        self.points_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.points_listbox.yview)
        
        # List buttons
        list_button_frame = ttk_boot.Frame(main_frame)
        list_button_frame.grid(row=3, column=0, pady=(0, 10))
        
        ttk_boot.Button(
            list_button_frame,
            text="Move Up",
            command=self._on_move_up,
            bootstyle="info",
            width=12
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            list_button_frame,
            text="Move Down",
            command=self._on_move_down,
            bootstyle="info",
            width=12
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            list_button_frame,
            text="Remove Selected",
            command=self._on_remove_point,
            bootstyle="danger",
            width=15
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            list_button_frame,
            text="Clear All",
            command=self._on_clear_points,
            bootstyle="warning",
            width=12
        ).pack(side=tk.LEFT, padx=5)
        
        # Dialog buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=3, column=0, pady=10)
        
        ttk_boot.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle="success",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        # Configure grid
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Bind keys
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _populate_list(self) -> None:
        """Populate listbox with current points."""
        self.points_listbox.delete(0, tk.END)
        for i, point_dict in enumerate(self.controller.get_points_as_strings()):
            text = (f"{i+1}. N={point_dict['northing']}, "
                    f"E={point_dict['easting']}, Z={point_dict['elevation']}")
            self.points_listbox.insert(tk.END, text)
    
    def _on_add_point(self) -> None:
        """Handle Add Point button."""
        success, error = self.controller.add_point(
            self.n_entry.get(),
            self.e_entry.get(),
            self.z_entry.get()
        )
        
        if success:
            self._populate_list()
            # Clear entries
            self.n_entry.delete(0, tk.END)
            self.e_entry.delete(0, tk.END)
            self.z_entry.delete(0, tk.END)
            self.z_entry.insert(0, "0.0")
            self.n_entry.focus_set()
        else:
            messagebox.showerror("Invalid Input", error)
    
    def _on_move_up(self) -> None:
        """Handle Move Up button."""
        selection = self.points_listbox.curselection()
        if selection and selection[0] > 0:
            index = selection[0]
            self.controller.move_point_up(index)
            self._populate_list()
            self.points_listbox.selection_set(index - 1)
    
    def _on_move_down(self) -> None:
        """Handle Move Down button."""
        selection = self.points_listbox.curselection()
        if selection and selection[0] < self.points_listbox.size() - 1:
            index = selection[0]
            self.controller.move_point_down(index)
            self._populate_list()
            self.points_listbox.selection_set(index + 1)
    
    def _on_remove_point(self) -> None:
        """Handle Remove Point button."""
        selection = self.points_listbox.curselection()
        if selection:
            index = selection[0]
            self.controller.remove_point(index)
            self._populate_list()
    
    def _on_clear_points(self) -> None:
        """Handle Clear All button."""
        if messagebox.askyesno("Confirm", "Clear all points?"):
            self.controller.clear_points()
            self._populate_list()
    
    def _on_ok(self) -> None:
        """Handle OK button."""
        is_valid, error = self.controller.is_valid()
        if not is_valid:
            messagebox.showerror("Invalid Input", error)
            return
        
        # Set name (optional)
        self.controller.set_name(self.name_entry.get())
        
        self.result = self.controller.create_polyline()
        if self.result:
            self.destroy()
        else:
            messagebox.showerror("Error", "Failed to create polyline")
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()


class PolygonDialog(tk.Toplevel):
    """
    Modal dialog for creating/editing a SimplePolygon.
    
    Similar to PolylineDialog but creates closed polygons.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        polygon: Optional[SimplePolygon] = None,
        title: str = "Create Polygon"
    ):
        """
        Initialize the dialog.
        
        Args:
            parent: Parent widget
            polygon: Existing polygon to edit (None for create mode)
            title: Dialog title
        """
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        
        # Controller (reuse PolylineDialogController)
        self.controller = PolylineDialogController()
        if polygon:
            # Load polygon points (excluding duplicate closing point)
            points = polygon.points[:-1] if len(polygon.points) > 0 and polygon.points[0].is_coincident(polygon.points[-1]) else polygon.points
            for pt in points:
                self.controller.add_point_object(pt)
            # Load name
            self.controller.name = polygon.name
        
        # Result
        self.result: Optional[SimplePolygon] = None
        
        self._create_widgets()
        
        # Load name if editing
        if polygon and polygon.name:
            self.name_entry.insert(0, polygon.name)
        
        self._populate_list()
        
        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_y() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
        
        # Focus first field
        self.n_entry.focus_set()
    
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Name field
        name_frame = ttk_boot.Frame(main_frame)
        name_frame.grid(row=0, column=0, sticky=tk.EW, pady=(0, 10))
        ttk_boot.Label(name_frame, text="Name (optional):").pack(side=tk.LEFT, padx=5)
        self.name_entry = ttk_boot.Entry(name_frame, width=30)
        self.name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # Input section
        input_frame = ttk_boot.LabelFrame(
            main_frame,
            text="Add Point",
            padding=10
        )
        input_frame.grid(row=1, column=0, sticky=tk.EW, pady=(0, 10))
        
        ttk_boot.Label(input_frame, text="N:").grid(row=0, column=0, sticky=tk.W)
        self.n_entry = ttk_boot.Entry(input_frame, width=12)
        self.n_entry.grid(row=0, column=1, padx=5)
        
        ttk_boot.Label(input_frame, text="E:").grid(row=0, column=2, sticky=tk.W)
        self.e_entry = ttk_boot.Entry(input_frame, width=12)
        self.e_entry.grid(row=0, column=3, padx=5)
        
        ttk_boot.Label(input_frame, text="Z:").grid(row=0, column=4, sticky=tk.W)
        self.z_entry = ttk_boot.Entry(input_frame, width=12)
        self.z_entry.insert(0, "0.0")
        self.z_entry.grid(row=0, column=5, padx=5)
        
        ttk_boot.Button(
            input_frame,
            text="Add",
            command=self._on_add_point,
            bootstyle="primary",
            width=8
        ).grid(row=0, column=6, padx=5)
        
        # Points list
        list_frame = ttk_boot.LabelFrame(
            main_frame,
            text="Points (Polygon will be closed automatically)",
            padding=10
        )
        list_frame.grid(row=2, column=0, sticky=tk.NSEW, pady=(0, 10))
        
        # Listbox with scrollbar
        scrollbar = ttk_boot.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.points_listbox = tk.Listbox(
            list_frame,
            height=10,
            yscrollcommand=scrollbar.set
        )
        self.points_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.points_listbox.yview)
        
        # List buttons
        list_button_frame = ttk_boot.Frame(main_frame)
        list_button_frame.grid(row=3, column=0, pady=(0, 10))
        
        ttk_boot.Button(
            list_button_frame,
            text="Move Up",
            command=self._on_move_up,
            bootstyle="info",
            width=12
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            list_button_frame,
            text="Move Down",
            command=self._on_move_down,
            bootstyle="info",
            width=12
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            list_button_frame,
            text="Remove Selected",
            command=self._on_remove_point,
            bootstyle="danger",
            width=15
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            list_button_frame,
            text="Clear All",
            command=self._on_clear_points,
            bootstyle="warning",
            width=12
        ).pack(side=tk.LEFT, padx=5)
        
        # Dialog buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=3, column=0, pady=10)
        
        ttk_boot.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle="success",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        # Configure grid
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Bind keys
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _populate_list(self) -> None:
        """Populate listbox with current points."""
        self.points_listbox.delete(0, tk.END)
        for i, point_dict in enumerate(self.controller.get_points_as_strings()):
            text = (f"{i+1}. N={point_dict['northing']}, "
                    f"E={point_dict['easting']}, Z={point_dict['elevation']}")
            self.points_listbox.insert(tk.END, text)
    
    def _on_add_point(self) -> None:
        """Handle Add Point button."""
        success, error = self.controller.add_point(
            self.n_entry.get(),
            self.e_entry.get(),
            self.z_entry.get()
        )
        
        if success:
            self._populate_list()
            # Clear entries
            self.n_entry.delete(0, tk.END)
            self.e_entry.delete(0, tk.END)
            self.z_entry.delete(0, tk.END)
            self.z_entry.insert(0, "0.0")
            self.n_entry.focus_set()
        else:
            messagebox.showerror("Invalid Input", error)
    
    def _on_move_up(self) -> None:
        """Handle Move Up button."""
        selection = self.points_listbox.curselection()
        if selection and selection[0] > 0:
            index = selection[0]
            self.controller.move_point_up(index)
            self._populate_list()
            self.points_listbox.selection_set(index - 1)
    
    def _on_move_down(self) -> None:
        """Handle Move Down button."""
        selection = self.points_listbox.curselection()
        if selection and selection[0] < self.points_listbox.size() - 1:
            index = selection[0]
            self.controller.move_point_down(index)
            self._populate_list()
            self.points_listbox.selection_set(index + 1)
    
    def _on_remove_point(self) -> None:
        """Handle Remove Point button."""
        selection = self.points_listbox.curselection()
        if selection:
            index = selection[0]
            self.controller.remove_point(index)
            self._populate_list()
    
    def _on_clear_points(self) -> None:
        """Handle Clear All button."""
        if messagebox.askyesno("Confirm", "Clear all points?"):
            self.controller.clear_points()
            self._populate_list()
    
    def _on_ok(self) -> None:
        """Handle OK button."""
        # Need at least 3 points for a polygon
        if self.controller.get_point_count() < 3:
            messagebox.showerror("Invalid Input", "A polygon requires at least 3 points")
            return
        
        # Set name (optional)
        self.controller.set_name(self.name_entry.get())
        
        # Create polygon from points (add closing point)
        points = self.controller.get_points()
        if len(points) >= 3:
            # Add closing point
            points.append(points[0])
            try:
                self.result = SimplePolygon(points, name=self.controller.name)
                self.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create polygon: {str(e)}")
        else:
            messagebox.showerror("Invalid Input", "A polygon requires at least 3 points")
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()


class CircularArcDialog(tk.Toplevel):
    """
    Modal dialog for creating/editing a CircularArc.
    
    Uses CircularArcDialogController for business logic.
    A circular arc is defined by three points: center, start, and end.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        arc: Optional[CircularArc] = None,
        title: str = "Create Circular Arc"
    ):
        """
        Initialize the dialog.
        
        Args:
            parent: Parent widget
            arc: Existing arc to edit (None for create mode)
            title: Dialog title
        """
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        
        # Controller
        self.controller = CircularArcDialogController()
        if arc:
            self.controller.load_arc(arc)
        
        # Result
        self.result: Optional[CircularArc] = None
        
        self._create_widgets()
        self._populate_fields()
        
        # Center on parent
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_y() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
        
        # Focus first field
        self.center_n_entry.focus_set()
    
    def _create_widgets(self) -> None:
        """Create dialog widgets."""
        # Main frame
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Center Point section
        ttk_boot.Label(
            main_frame,
            text="Center Point (Radius Point)",
            font=("Segoe UI", 10, "bold")
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 10))
        
        ttk_boot.Label(main_frame, text="Northing:").grid(
            row=1, column=0, sticky=tk.W, pady=5
        )
        self.center_n_entry = ttk_boot.Entry(main_frame, width=20)
        self.center_n_entry.grid(row=1, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Easting:").grid(
            row=2, column=0, sticky=tk.W, pady=5
        )
        self.center_e_entry = ttk_boot.Entry(main_frame, width=20)
        self.center_e_entry.grid(row=2, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Elevation:").grid(
            row=3, column=0, sticky=tk.W, pady=5
        )
        self.center_z_entry = ttk_boot.Entry(main_frame, width=20)
        self.center_z_entry.grid(row=3, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Start Point section
        ttk_boot.Label(
            main_frame,
            text="Start Point",
            font=("Segoe UI", 10, "bold")
        ).grid(row=4, column=0, columnspan=2, sticky=tk.W, pady=(20, 10))
        
        ttk_boot.Label(main_frame, text="Northing:").grid(
            row=5, column=0, sticky=tk.W, pady=5
        )
        self.start_n_entry = ttk_boot.Entry(main_frame, width=20)
        self.start_n_entry.grid(row=5, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Easting:").grid(
            row=6, column=0, sticky=tk.W, pady=5
        )
        self.start_e_entry = ttk_boot.Entry(main_frame, width=20)
        self.start_e_entry.grid(row=6, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Elevation:").grid(
            row=7, column=0, sticky=tk.W, pady=5
        )
        self.start_z_entry = ttk_boot.Entry(main_frame, width=20)
        self.start_z_entry.grid(row=7, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # End Point section
        ttk_boot.Label(
            main_frame,
            text="End Point",
            font=("Segoe UI", 10, "bold")
        ).grid(row=8, column=0, columnspan=2, sticky=tk.W, pady=(20, 10))
        
        ttk_boot.Label(main_frame, text="Northing:").grid(
            row=9, column=0, sticky=tk.W, pady=5
        )
        self.end_n_entry = ttk_boot.Entry(main_frame, width=20)
        self.end_n_entry.grid(row=9, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Easting:").grid(
            row=10, column=0, sticky=tk.W, pady=5
        )
        self.end_e_entry = ttk_boot.Entry(main_frame, width=20)
        self.end_e_entry.grid(row=10, column=1, sticky=tk.EW, pady=5, padx=5)
        
        ttk_boot.Label(main_frame, text="Elevation:").grid(
            row=11, column=0, sticky=tk.W, pady=5
        )
        self.end_z_entry = ttk_boot.Entry(main_frame, width=20)
        self.end_z_entry.grid(row=11, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Name (optional)
        ttk_boot.Label(main_frame, text="Name (optional):").grid(
            row=12, column=0, sticky=tk.W, pady=5
        )
        self.name_entry = ttk_boot.Entry(main_frame, width=20)
        self.name_entry.grid(row=12, column=1, sticky=tk.EW, pady=5, padx=5)
        
        # Buttons
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=13, column=0, columnspan=2, pady=20)
        
        ttk_boot.Button(
            button_frame,
            text="OK",
            command=self._on_ok,
            bootstyle="success",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        ttk_boot.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            bootstyle="secondary",
            width=10
        ).pack(side=tk.LEFT, padx=5)
        
        # Configure grid
        main_frame.columnconfigure(1, weight=1)
        
        # Bind keys
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())
    
    def _populate_fields(self) -> None:
        """Populate fields with current values from controller."""
        center_n, center_e, center_z = self.controller.get_center_values()
        self.center_n_entry.insert(0, center_n)
        self.center_e_entry.insert(0, center_e)
        self.center_z_entry.insert(0, center_z)
        
        start_n, start_e, start_z = self.controller.get_start_values()
        self.start_n_entry.insert(0, start_n)
        self.start_e_entry.insert(0, start_e)
        self.start_z_entry.insert(0, start_z)
        
        end_n, end_e, end_z = self.controller.get_end_values()
        self.end_n_entry.insert(0, end_n)
        self.end_e_entry.insert(0, end_e)
        self.end_z_entry.insert(0, end_z)
        
        # Load name if editing
        if self.controller.name:
            self.name_entry.insert(0, self.controller.name)
    
    def _on_ok(self) -> None:
        """Handle OK button - validate and create arc."""
        # Validate center point
        if not self.controller.set_center_northing(self.center_n_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid center northing value")
            self.center_n_entry.focus_set()
            return
        
        if not self.controller.set_center_easting(self.center_e_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid center easting value")
            self.center_e_entry.focus_set()
            return
        
        if not self.controller.set_center_elevation(self.center_z_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid center elevation value")
            self.center_z_entry.focus_set()
            return
        
        # Validate start point
        if not self.controller.set_start_northing(self.start_n_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid start northing value")
            self.start_n_entry.focus_set()
            return
        
        if not self.controller.set_start_easting(self.start_e_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid start easting value")
            self.start_e_entry.focus_set()
            return
        
        if not self.controller.set_start_elevation(self.start_z_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid start elevation value")
            self.start_z_entry.focus_set()
            return
        
        # Validate end point
        if not self.controller.set_end_northing(self.end_n_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid end northing value")
            self.end_n_entry.focus_set()
            return
        
        if not self.controller.set_end_easting(self.end_e_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid end easting value")
            self.end_e_entry.focus_set()
            return
        
        if not self.controller.set_end_elevation(self.end_z_entry.get()):
            messagebox.showerror("Invalid Input", "Invalid end elevation value")
            self.end_z_entry.focus_set()
            return
        
        # Set name (optional)
        self.controller.set_name(self.name_entry.get())
        
        # Create arc
        self.result = self.controller.create_arc()
        if self.result:
            self.destroy()
        else:
            messagebox.showerror("Error", "Failed to create circular arc")
    
    def _on_cancel(self) -> None:
        """Handle Cancel button."""
        self.result = None
        self.destroy()
