"""
Controllers for measurement creation/editing dialogs.

These controllers contain all business logic for measurement dialogs,
making them fully testable without GUI dependencies.
"""

from typing import Optional, Tuple
from plana_figura import (
    Measurement,
    MeasurementType,
    DecimalDegreesAngle
)
from plana_figura_workbench.validators import ValidationResult
import logging

logger = logging.getLogger(__name__)


class AngleDialogController:
    """
    Controller for Angle measurement creation/editing dialog.

    Handles validation and Measurement object creation for all angle types
    (horizontal, vertical, zenith).
    """

    def __init__(self):
        """Initialize the controller."""
        self.name: str = ""
        self.angle_type: MeasurementType = MeasurementType.HORIZONTAL_ANGLE
        self.decimal_degrees: Optional[float] = None
        self.degrees: Optional[int] = None
        self.minutes: Optional[int] = None
        self.seconds: Optional[float] = None
        self.description: str = ""

        # For editing mode
        self.original_measurement: Optional[Measurement] = None
        self.is_edit_mode: bool = False

    def load_measurement(self, measurement: Measurement) -> None:
        """
        Load an existing measurement for editing.

        Args:
            measurement: The measurement to edit
        """
        self.original_measurement = measurement
        self.is_edit_mode = True
        self.name = measurement.name
        self.angle_type = measurement.measurement_type
        self.description = measurement.description

        # Extract angle value
        if isinstance(measurement.value, DecimalDegreesAngle):
            self.decimal_degrees = measurement.value.angle_degrees
            # Convert to DMS
            self.degrees, self.minutes, self.seconds = (
                self._decimal_to_dms(self.decimal_degrees)
            )

    def set_angle_type(self, angle_type: MeasurementType) -> bool:
        """
        Set the angle type.

        Args:
            angle_type: The measurement type

        Returns:
            True if valid angle type
        """
        if angle_type in {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE
        }:
            self.angle_type = angle_type
            return True
        return False

    def validate_name(self, name: str) -> ValidationResult:
        """Validate measurement name."""
        if not name or not name.strip():
            return ValidationResult(False, error_message="Name cannot be empty")
        return ValidationResult(True, value=name.strip())

    def validate_decimal_degrees(self, value: str) -> ValidationResult:
        """Validate decimal degrees input."""
        if not value or not value.strip():
            return ValidationResult(False, error_message="Value cannot be empty")

        try:
            degrees = float(value)
            # Allow any angle value (will be normalized)
            return ValidationResult(True, value=degrees)
        except ValueError:
            return ValidationResult(False, error_message="Invalid number format")

    def validate_dms_component(
        self,
        value: str,
        component: str,
        min_val: float,
        max_val: float
    ) -> ValidationResult:
        """
        Validate DMS component (degrees, minutes, or seconds).

        Args:
            value: The input value
            component: Component name for error messages
            min_val: Minimum allowed value
            max_val: Maximum allowed value

        Returns:
            ValidationResult
        """
        if not value or not value.strip():
            return ValidationResult(False, error_message=f"{component} cannot be empty")

        try:
            num = float(value)
            if num < min_val or num > max_val:
                return ValidationResult(
                    False,
                    error_message=f"{component} must be between {min_val} and {max_val}"
                )
            return ValidationResult(True, value=num)
        except ValueError:
            return ValidationResult(False, error_message="Invalid number format")

    def set_decimal_degrees(self, value: str) -> bool:
        """
        Set angle from decimal degrees.

        Returns:
            True if valid and set
        """
        result = self.validate_decimal_degrees(value)
        if result.is_valid:
            self.decimal_degrees = result.value
            # Update DMS
            self.degrees, self.minutes, self.seconds = (
                self._decimal_to_dms(result.value)
            )
            return True
        return False

    def set_dms(
        self,
        degrees: str,
        minutes: str,
        seconds: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Set angle from DMS values.

        Returns:
            Tuple of (success, error_message)
        """
        # Validate degrees
        deg_result = self.validate_dms_component(degrees, "Degrees", 0, 360)
        if not deg_result.is_valid:
            return False, deg_result.error_message

        # Validate minutes
        min_result = self.validate_dms_component(minutes, "Minutes", 0, 59)
        if not min_result.is_valid:
            return False, min_result.error_message

        # Validate seconds
        sec_result = self.validate_dms_component(seconds, "Seconds", 0, 59.999999)
        if not sec_result.is_valid:
            return False, sec_result.error_message

        # All valid - store and convert to decimal
        self.degrees = int(deg_result.value)
        self.minutes = int(min_result.value)
        self.seconds = sec_result.value
        self.decimal_degrees = self._dms_to_decimal(
            self.degrees,
            self.minutes,
            self.seconds
        )
        return True, None

    def set_name(self, name: str) -> bool:
        """Set measurement name."""
        result = self.validate_name(name)
        if result.is_valid:
            self.name = result.value
            return True
        return False

    def set_description(self, description: str) -> None:
        """Set measurement description."""
        self.description = description

    def get_name(self) -> str:
        """Get measurement name."""
        return self.name

    def get_description(self) -> str:
        """Get measurement description."""
        return self.description

    def get_measurement_type(self) -> MeasurementType:
        """Get measurement type."""
        return self.angle_type

    def set_measurement_type(self, measurement_type: MeasurementType) -> bool:
        """Set measurement type."""
        return self.set_angle_type(measurement_type)

    def get_decimal_degrees(self) -> Optional[float]:
        """Get decimal degrees value."""
        return self.decimal_degrees

    def get_dms(self) -> Tuple[int, int, float]:
        """Get degrees, minutes, seconds."""
        return (self.degrees or 0, self.minutes or 0, self.seconds or 0.0)

    def can_create(self) -> Tuple[bool, Optional[str]]:
        """
        Check if measurement can be created with current values.

        Returns:
            Tuple of (can_create, error_message)
        """
        # Validate name
        name_result = self.validate_name(self.name)
        if not name_result.is_valid:
            return False, name_result.error_message

        # Check if we have an angle value
        if self.decimal_degrees is None:
            return False, "Angle value is required"

        return True, None

    def create_measurement(self) -> ValidationResult:
        """
        Create a Measurement object from current values.

        Returns:
            ValidationResult with Measurement object or error message
        """
        can_create, error = self.can_create()
        if not can_create:
            logger.error(f"Cannot create measurement: {error}")
            return ValidationResult(False, error_message=error)

        try:
            angle = DecimalDegreesAngle(self.decimal_degrees)
            measurement = Measurement(
                name=self.name,
                value=angle,
                measurement_type=self.angle_type,
                description=self.description
            )
            return ValidationResult(True, value=measurement)
        except Exception as e:
            logger.error(f"Failed to create measurement: {e}")
            return ValidationResult(False, error_message=str(e))

    def _decimal_to_dms(self, decimal: float) -> Tuple[int, int, float]:
        """
        Convert decimal degrees to DMS.

        Args:
            decimal: Decimal degrees

        Returns:
            Tuple of (degrees, minutes, seconds)
        """
        # Normalize to [0, 360)
        decimal = decimal % 360.0

        degrees = int(decimal)
        remainder = (decimal - degrees) * 60
        minutes = int(remainder)
        seconds = (remainder - minutes) * 60

        return degrees, minutes, seconds

    def _dms_to_decimal(self, degrees: int, minutes: int, seconds: float) -> float:
        """
        Convert DMS to decimal degrees.

        Args:
            degrees: Degrees
            minutes: Minutes
            seconds: Seconds

        Returns:
            Decimal degrees
        """
        return degrees + (minutes / 60.0) + (seconds / 3600.0)


class DirectionDialogController:
    """
    Controller for Direction measurement creation/editing dialog.

    Handles validation and Measurement object creation for direction types
    (azimuth, bearing, direction).
    """

    def __init__(self):
        """Initialize the controller."""
        self.name: str = ""
        self.direction_type: MeasurementType = MeasurementType.AZIMUTH
        self.decimal_degrees: Optional[float] = None
        self.description: str = ""

        # For bearing notation
        self.bearing_quadrant_start: str = "N"  # N or S
        self.bearing_degrees: Optional[int] = None
        self.bearing_minutes: Optional[int] = None
        self.bearing_seconds: Optional[float] = None
        self.bearing_quadrant_end: str = "E"  # E or W

        # For editing mode
        self.original_measurement: Optional[Measurement] = None
        self.is_edit_mode: bool = False

    def load_measurement(self, measurement: Measurement) -> None:
        """
        Load an existing measurement for editing.

        Args:
            measurement: The measurement to edit
        """
        self.original_measurement = measurement
        self.is_edit_mode = True
        self.name = measurement.name
        self.direction_type = measurement.measurement_type
        self.description = measurement.description

        # Extract angle value
        if isinstance(measurement.value, DecimalDegreesAngle):
            self.decimal_degrees = measurement.value.angle_degrees

    def set_direction_type(self, direction_type: MeasurementType) -> bool:
        """
        Set the direction type.

        Args:
            direction_type: The measurement type

        Returns:
            True if valid direction type
        """
        if direction_type in {
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }:
            self.direction_type = direction_type
            return True
        return False

    def validate_name(self, name: str) -> ValidationResult:
        """Validate measurement name."""
        if not name or not name.strip():
            return ValidationResult(False, error_message="Name cannot be empty")
        return ValidationResult(True, value=name.strip())

    def validate_decimal_degrees(self, value: str) -> ValidationResult:
        """Validate decimal degrees input."""
        if not value or not value.strip():
            return ValidationResult(False, error_message="Value cannot be empty")

        try:
            degrees = float(value)
            return ValidationResult(True, value=degrees)
        except ValueError:
            return ValidationResult(False, error_message="Invalid number format")

    def set_decimal_degrees(self, value: str) -> bool:
        """
        Set direction from decimal degrees.

        Returns:
            True if valid and set
        """
        result = self.validate_decimal_degrees(value)
        if result.is_valid:
            self.decimal_degrees = result.value
            return True
        return False

    def set_bearing_notation(
        self,
        quadrant_start: str,
        degrees: str,
        minutes: str,
        seconds: str,
        quadrant_end: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Set direction from bearing notation (e.g., N 45° 30' 0" E).

        Args:
            quadrant_start: "N" or "S"
            degrees: Degrees (0-90)
            minutes: Minutes (0-59)
            seconds: Seconds (0-59.999)
            quadrant_end: "E" or "W"

        Returns:
            Tuple of (success, error_message)
        """
        # Validate quadrants
        if quadrant_start not in ["N", "S"]:
            return False, "Start quadrant must be N or S"
        if quadrant_end not in ["E", "W"]:
            return False, "End quadrant must be E or W"

        # Validate degrees (0-90 for bearings)
        try:
            deg = float(degrees)
            if deg < 0 or deg > 90:
                return False, "Bearing degrees must be between 0 and 90"
        except ValueError:
            return False, "Invalid degrees format"

        # Validate minutes
        try:
            min_val = float(minutes)
            if min_val < 0 or min_val > 59:
                return False, "Minutes must be between 0 and 59"
        except ValueError:
            return False, "Invalid minutes format"

        # Validate seconds
        try:
            sec = float(seconds)
            if sec < 0 or sec >= 60:
                return False, "Seconds must be between 0 and 59.999"
        except ValueError:
            return False, "Invalid seconds format"

        # Store bearing components
        self.bearing_quadrant_start = quadrant_start
        self.bearing_degrees = int(deg)
        self.bearing_minutes = int(min_val)
        self.bearing_seconds = sec
        self.bearing_quadrant_end = quadrant_end

        # Convert to azimuth (decimal degrees from north, clockwise)
        bearing_decimal = deg + (min_val / 60.0) + (sec / 3600.0)

        if quadrant_start == "N" and quadrant_end == "E":
            # NE quadrant: 0-90°
            azimuth = bearing_decimal
        elif quadrant_start == "S" and quadrant_end == "E":
            # SE quadrant: 90-180°
            azimuth = 180.0 - bearing_decimal
        elif quadrant_start == "S" and quadrant_end == "W":
            # SW quadrant: 180-270°
            azimuth = 180.0 + bearing_decimal
        else:  # N and W
            # NW quadrant: 270-360°
            azimuth = 360.0 - bearing_decimal

        self.decimal_degrees = azimuth
        return True, None

    def can_create(self) -> Tuple[bool, Optional[str]]:
        """
        Check if measurement can be created with current values.

        Returns:
            Tuple of (can_create, error_message)
        """
        # Validate name
        name_result = self.validate_name(self.name)
        if not name_result.is_valid:
            return False, name_result.error_message

        # Check if we have a direction value
        if self.decimal_degrees is None:
            return False, "Direction value is required"

        return True, None

    def create_measurement(self) -> ValidationResult:
        """
        Create a Measurement object from current values.

        Returns:
            ValidationResult with Measurement object or error message
        """
        can_create, error = self.can_create()
        if not can_create:
            logger.error(f"Cannot create measurement: {error}")
            return ValidationResult(False, error_message=error)

        try:
            angle = DecimalDegreesAngle(self.decimal_degrees)
            measurement = Measurement(
                name=self.name,
                value=angle,
                measurement_type=self.direction_type,
                description=self.description
            )
            return ValidationResult(True, value=measurement)
        except Exception as e:
            logger.error(f"Failed to create measurement: {e}")
            return ValidationResult(False, error_message=str(e))


class DistanceDialogController:
    """
    Controller for Distance measurement creation/editing dialog.

    Handles validation and Measurement object creation for all distance types.
    """

    def __init__(self):
        """Initialize the controller."""
        self.name: str = ""
        self.distance_type: MeasurementType = MeasurementType.HORIZONTAL_DISTANCE
        self.value: Optional[float] = None
        self.description: str = ""

        # For editing mode
        self.original_measurement: Optional[Measurement] = None
        self.is_edit_mode: bool = False

    def load_measurement(self, measurement: Measurement) -> None:
        """
        Load an existing measurement for editing.

        Args:
            measurement: The measurement to edit
        """
        self.original_measurement = measurement
        self.is_edit_mode = True
        self.name = measurement.name
        self.distance_type = measurement.measurement_type
        self.description = measurement.description
        self.value = float(measurement.value)

    def set_distance_type(self, distance_type: MeasurementType) -> bool:
        """
        Set the distance type.

        Args:
            distance_type: The measurement type

        Returns:
            True if valid distance type
        """
        if distance_type in {
            MeasurementType.DISTANCE,
            MeasurementType.HORIZONTAL_DISTANCE,
            MeasurementType.SLOPE_DISTANCE,
            MeasurementType.VERTICAL_DISTANCE
        }:
            self.distance_type = distance_type
            return True
        return False

    def validate_name(self, name: str) -> ValidationResult:
        """Validate measurement name."""
        if not name or not name.strip():
            return ValidationResult(False, error_message="Name cannot be empty")
        return ValidationResult(True, value=name.strip())

    def validate_value(self, value: str) -> ValidationResult:
        """Validate distance value."""
        if not value or not value.strip():
            return ValidationResult(False, error_message="Value cannot be empty")

        try:
            distance = float(value)
            if distance < 0:
                return ValidationResult(
                    False,
                    error_message="Distance cannot be negative"
                )
            return ValidationResult(True, value=distance)
        except ValueError:
            return ValidationResult(False, error_message="Invalid number format")

    def set_value(self, value: str) -> bool:
        """
        Set distance value.

        Returns:
            True if valid and set
        """
        result = self.validate_value(value)
        if result.is_valid:
            self.value = result.value
            return True
        return False

    def set_name(self, name: str) -> bool:
        """Set measurement name."""
        result = self.validate_name(name)
        if result.is_valid:
            self.name = result.value
            return True
        return False

    def set_description(self, description: str) -> None:
        """Set measurement description."""
        self.description = description

    def get_name(self) -> str:
        """Get measurement name."""
        return self.name

    def get_distance(self) -> Optional[float]:
        """Get distance value."""
        return self.value

    def get_description(self) -> str:
        """Get measurement description."""
        return self.description

    def get_measurement_type(self) -> MeasurementType:
        """Get measurement type."""
        return self.distance_type

    def set_measurement_type(self, measurement_type: MeasurementType) -> bool:
        """Set measurement type."""
        return self.set_distance_type(measurement_type)

    def can_create(self) -> Tuple[bool, Optional[str]]:
        """
        Check if measurement can be created with current values.

        Returns:
            Tuple of (can_create, error_message)
        """
        # Validate name
        name_result = self.validate_name(self.name)
        if not name_result.is_valid:
            return False, name_result.error_message

        # Check if we have a value
        if self.value is None:
            return False, "Distance value is required"

        return True, None

    def create_measurement(self) -> ValidationResult:
        """
        Create a Measurement object from current values.

        Returns:
            ValidationResult with Measurement object or error message
        """
        can_create, error = self.can_create()
        if not can_create:
            logger.error(f"Cannot create measurement: {error}")
            return ValidationResult(False, error_message=error)

        try:
            measurement = Measurement(
                name=self.name,
                value=self.value,
                measurement_type=self.distance_type,
                description=self.description
            )
            return ValidationResult(True, value=measurement)
        except Exception as e:
            logger.error(f"Failed to create measurement: {e}")
            return ValidationResult(False, error_message=str(e))


class VectorDialogController:
    """
    Controller for 3D Vector measurement creation/editing dialog.

    Handles validation and Measurement object creation for 3D vectors.
    """

    def __init__(self):
        """Initialize the controller."""
        self.name: str = ""
        self.northing: Optional[float] = None
        self.easting: Optional[float] = None
        self.elevation: Optional[float] = None
        self.description: str = ""

        # For editing mode
        self.original_measurement: Optional[Measurement] = None
        self.is_edit_mode: bool = False

    def load_measurement(self, measurement: Measurement) -> None:
        """
        Load an existing measurement for editing.

        Args:
            measurement: The measurement to edit
        """
        self.original_measurement = measurement
        self.is_edit_mode = True
        self.name = measurement.name
        self.description = measurement.description

        # Extract vector components
        if isinstance(measurement.value, tuple) and len(measurement.value) == 3:
            self.northing, self.easting, self.elevation = measurement.value

    def validate_name(self, name: str) -> ValidationResult:
        """Validate measurement name."""
        if not name or not name.strip():
            return ValidationResult(False, error_message="Name cannot be empty")
        return ValidationResult(True, value=name.strip())

    def validate_component(self, value: str, component_name: str) -> ValidationResult:
        """Validate vector component."""
        if not value or not value.strip():
            return ValidationResult(
                False,
                error_message=f"{component_name} cannot be empty"
            )

        try:
            component = float(value)
            return ValidationResult(True, value=component)
        except ValueError:
            return ValidationResult(False, error_message="Invalid number format")

    def set_northing(self, value: str) -> bool:
        """Set northing component."""
        result = self.validate_component(value, "Northing")
        if result.is_valid:
            self.northing = result.value
            return True
        return False

    def set_easting(self, value: str) -> bool:
        """Set easting component."""
        result = self.validate_component(value, "Easting")
        if result.is_valid:
            self.easting = result.value
            return True
        return False

    def set_elevation(self, value: str) -> bool:
        """Set elevation component."""
        result = self.validate_component(value, "Elevation")
        if result.is_valid:
            self.elevation = result.value
            return True
        return False

    def can_create(self) -> Tuple[bool, Optional[str]]:
        """
        Check if measurement can be created with current values.

        Returns:
            Tuple of (can_create, error_message)
        """
        # Validate name
        name_result = self.validate_name(self.name)
        if not name_result.is_valid:
            return False, name_result.error_message

        # Check if we have all components
        if self.northing is None:
            return False, "Northing is required"
        if self.easting is None:
            return False, "Easting is required"
        if self.elevation is None:
            return False, "Elevation is required"

        return True, None

    def create_measurement(self) -> ValidationResult:
        """
        Create a Measurement object from current values.

        Returns:
            ValidationResult with Measurement object or error message
        """
        can_create, error = self.can_create()
        if not can_create:
            logger.error(f"Cannot create measurement: {error}")
            return ValidationResult(False, error_message=error)

        try:
            measurement = Measurement(
                name=self.name,
                value=(self.northing, self.easting, self.elevation),
                measurement_type=MeasurementType.VECTOR_3D,
                description=self.description
            )
            return ValidationResult(True, value=measurement)
        except Exception as e:
            logger.error(f"Failed to create measurement: {e}")
            return ValidationResult(False, error_message=str(e))

    def get_computed_properties(self) -> Optional[dict]:
        """
        Get computed properties (magnitude, azimuth, slope).

        Returns:
            Dictionary with computed properties or None if incomplete
        """
        if self.northing is None or self.easting is None or self.elevation is None:
            return None

        import math

        # Magnitude
        magnitude = math.sqrt(
            self.northing**2 + self.easting**2 + self.elevation**2
        )

        # Horizontal distance
        horiz_dist = math.sqrt(self.northing**2 + self.easting**2)

        # Azimuth (from north, clockwise)
        if horiz_dist > 0:
            azimuth_rad = math.atan2(self.easting, self.northing)
            azimuth = math.degrees(azimuth_rad)
            if azimuth < 0:
                azimuth += 360
        else:
            azimuth = 0.0

        # Slope angle (from horizontal)
        if horiz_dist > 0:
            slope_rad = math.atan2(self.elevation, horiz_dist)
            slope = math.degrees(slope_rad)
        else:
            slope = 90.0 if self.elevation > 0 else -90.0

        return {
            'magnitude': magnitude,
            'azimuth': azimuth,
            'slope': slope,
            'horizontal_distance': horiz_dist
        }
