"""Dialog for adding 3D vector measurements."""

import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk_boot
from typing import Optional

from plana_figura import Measurement
from plana_figura_workbench.dialogs.measurement_dialog_controller import VectorDialogController


class AddVectorDialog(tk.Toplevel):
    """Modal dialog for creating/editing 3D vector measurements."""

    def __init__(self, parent: tk.Widget, measurement: Optional[Measurement] = None, title: str = "Add 3D Vector"):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        
        self.controller = VectorDialogController()
        if measurement:
            self.controller.load_measurement(measurement)
        
        self.result: Optional[Measurement] = None
        self._create_widgets()
        self._populate_fields()
        
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_y() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")
        self.name_entry.focus_set()

    def _create_widgets(self) -> None:
        main_frame = ttk_boot.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        row = 0
        
        ttk_boot.Label(main_frame, text="Name:").grid(row=row, column=0, sticky=tk.W, pady=5)
        self.name_entry = ttk_boot.Entry(main_frame, width=20)
        self.name_entry.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        ttk_boot.Separator(main_frame, orient=tk.HORIZONTAL).grid(row=row, column=0, columnspan=2, sticky=tk.EW, pady=10)
        row += 1
        
        comp_frame = ttk_boot.LabelFrame(main_frame, text="Components", padding=10)
        comp_frame.grid(row=row, column=0, columnspan=2, sticky=tk.EW, pady=5)
        
        ttk_boot.Label(comp_frame, text="Northing:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.northing_entry = ttk_boot.Entry(comp_frame, width=15)
        self.northing_entry.grid(row=0, column=1, sticky=tk.EW, pady=5, padx=5)
        self.northing_entry.bind("<KeyRelease>", self._on_component_changed)
        
        ttk_boot.Label(comp_frame, text="Easting:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.easting_entry = ttk_boot.Entry(comp_frame, width=15)
        self.easting_entry.grid(row=1, column=1, sticky=tk.EW, pady=5, padx=5)
        self.easting_entry.bind("<KeyRelease>", self._on_component_changed)
        
        ttk_boot.Label(comp_frame, text="Elevation:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.elevation_entry = ttk_boot.Entry(comp_frame, width=15)
        self.elevation_entry.grid(row=2, column=1, sticky=tk.EW, pady=5, padx=5)
        self.elevation_entry.bind("<KeyRelease>", self._on_component_changed)
        
        comp_frame.columnconfigure(1, weight=1)
        row += 1
        
        self.props_frame = ttk_boot.LabelFrame(main_frame, text="Computed Properties", padding=10)
        self.props_frame.grid(row=row, column=0, columnspan=2, sticky=tk.EW, pady=5)
        self.props_text = tk.Text(self.props_frame, height=4, width=30, state=tk.DISABLED)
        self.props_text.pack(fill=tk.BOTH, expand=True)
        row += 1
        
        ttk_boot.Separator(main_frame, orient=tk.HORIZONTAL).grid(row=row, column=0, columnspan=2, sticky=tk.EW, pady=10)
        row += 1
        
        ttk_boot.Label(main_frame, text="Description:").grid(row=row, column=0, sticky=tk.NW, pady=5)
        self.description_text = tk.Text(main_frame, height=3, width=20)
        self.description_text.grid(row=row, column=1, sticky=tk.EW, pady=5, padx=5)
        row += 1
        
        button_frame = ttk_boot.Frame(main_frame)
        button_frame.grid(row=row, column=0, columnspan=2, pady=20)
        ttk_boot.Button(button_frame, text="OK", command=self._on_ok, bootstyle="success", width=10).pack(side=tk.LEFT, padx=5)
        ttk_boot.Button(button_frame, text="Cancel", command=self._on_cancel, bootstyle="secondary", width=10).pack(side=tk.LEFT, padx=5)
        
        main_frame.columnconfigure(1, weight=1)
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self._on_cancel())

    def _populate_fields(self) -> None:
        if self.controller.is_edit_mode:
            self.name_entry.insert(0, self.controller.name)
            if self.controller.northing is not None:
                self.northing_entry.insert(0, str(self.controller.northing))
            if self.controller.easting is not None:
                self.easting_entry.insert(0, str(self.controller.easting))
            if self.controller.elevation is not None:
                self.elevation_entry.insert(0, str(self.controller.elevation))
            if self.controller.description:
                self.description_text.insert("1.0", self.controller.description)
            self._update_computed_properties()

    def _on_component_changed(self, event=None) -> None:
        n = self.northing_entry.get()
        e = self.easting_entry.get()
        z = self.elevation_entry.get()
        if n:
            self.controller.set_northing(n)
        if e:
            self.controller.set_easting(e)
        if z:
            self.controller.set_elevation(z)
        self._update_computed_properties()

    def _update_computed_properties(self) -> None:
        props = self.controller.get_computed_properties()
        self.props_text.configure(state=tk.NORMAL)
        self.props_text.delete("1.0", tk.END)
        if props:
            self.props_text.insert(tk.END, f"Magnitude: {props['magnitude']:.4f}\n")
            self.props_text.insert(tk.END, f"Azimuth: {props['azimuth']:.4f}°\n")
            self.props_text.insert(tk.END, f"Slope: {props['slope']:.4f}°\n")
            self.props_text.insert(tk.END, f"Horiz. Dist: {props['horizontal_distance']:.4f}")
        self.props_text.configure(state=tk.DISABLED)

    def _on_ok(self) -> None:
        self.controller.name = self.name_entry.get().strip()
        self.controller.description = self.description_text.get("1.0", tk.END).strip()
        can_create, error = self.controller.can_create()
        if not can_create:
            messagebox.showerror("Invalid Input", error)
            return
        result = self.controller.create_measurement()
        if result.is_valid:
            self.result = result.value
            self.destroy()
        else:
            messagebox.showerror("Error", result.error_message)

    def _on_cancel(self) -> None:
        self.result = None
        self.destroy()
