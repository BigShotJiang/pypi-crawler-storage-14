"""Error handling components for the Plana Figura Workbench."""

import tkinter as tk
from tkinter import messagebox, ttk
import logging
from typing import Optional, Dict, Any, List, Callable
from pathlib import Path
import threading
import time

from plana_figura.exceptions import PlanaFiguraError, ValidationError as CoreValidationError, GeometryError
from plana_figura_workbench.exceptions import UIError, FileIOError, SystemError

logger = logging.getLogger(__name__)


class ErrorDialogManager:
    """Manages user-friendly error dialogs."""
    
    def __init__(self):
        self.error_messages = self._load_error_messages()
    
    def show_error(self, error: PlanaFiguraError, parent=None, recovery_options=None):
        """
        Show appropriate error dialog based on error type.
        This is the "translator" component of the Firewall.
        """
        # 1. Log the full error with context for debugging
        logger.error(f"Caught Error: {error.error_code}", exc_info=error)
        
        # 2. Get user-friendly message from the error_code
        message = self._get_user_message_from_code(error.error_code, error.context)
        
        # 3. Check for specific recovery options
        if recovery_options:
            # Show a dialog with custom buttons (e.g., "Create Intersection")
            return self._show_recovery_dialog(message, recovery_options, parent)
        
        # 4. Show a standard error dialog
        if isinstance(error, CoreValidationError):
            return self._show_validation_error(message, error, parent)
        else:
            return self._show_generic_error(message, error, parent)
    
    def _get_user_message_from_code(self, error_code: str, context: Dict[str, Any]) -> str:
        """Retrieves a user-friendly string based on the error code."""
        if not error_code:
            return "An unexpected error occurred."
        
        # Get base message from error code
        base_message = self.error_messages.get(error_code, "An unexpected error occurred.")
        
        # Format with context if available
        try:
            return base_message.format(**context)
        except (KeyError, ValueError):
            return base_message
    
    def _show_validation_error(self, message: str, error: PlanaFiguraError, parent=None):
        """Show validation error dialog with specific styling."""
        return messagebox.showwarning(
            "Input Validation Error",
            f"{message}\n\nPlease check your input and try again.",
            parent=parent
        )
    
    def _show_generic_error(self, message: str, error: PlanaFiguraError, parent=None):
        """Show generic error dialog."""
        return messagebox.showerror(
            "Error",
            message,
            parent=parent
        )
    
    def _show_recovery_dialog(self, message: str, recovery_options: List[Dict], parent=None):
        """Show error dialog with recovery options."""
        dialog = RecoveryDialog(parent, message, recovery_options)
        return dialog.show()
    
    def _load_error_messages(self) -> Dict[str, str]:
        """Load user-friendly error messages."""
        return {
            "COORD_INVALID_FORMAT": "Invalid coordinate: '{input}' is not a valid number for {field}.",
            "GEOMETRY_INVALID_POINTS": "Cannot create {geometry_type}: requires at least {min_points} points.",
            "FILE_NOT_FOUND": "File not found: {filepath}",
            "FILE_PERMISSION_DENIED": "Permission denied accessing file: {filepath}",
            "MEASUREMENT_TYPE_MISMATCH": "Measurement '{measurement_name}' is type {actual_type}, expected {expected_type}.",
            "GEOMETRY_INTERSECTION_FAILED": "Could not find intersection between {geometry1} and {geometry2}.",
            "MEMORY_INSUFFICIENT": "Insufficient memory to complete operation. Try closing other applications.",
            "PLUGIN_LOAD_FAILED": "Failed to load plugin '{plugin_name}': {reason}",
        }


class RecoveryDialog(tk.Toplevel):
    """Dialog for showing error recovery options."""
    
    def __init__(self, parent, message: str, recovery_options: List[Dict]):
        super().__init__(parent)
        self.parent = parent
        self.message = message
        self.recovery_options = recovery_options
        self.result = None
        
        self.title("Error - Recovery Options")
        self.transient(parent)
        self.grab_set()
        
        self._create_widgets()
        self._center_on_parent()
    
    def _create_widgets(self):
        """Create dialog widgets."""
        main_frame = ttk.Frame(self)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Error message
        message_label = ttk.Label(main_frame, text=self.message, wraplength=400)
        message_label.pack(pady=(0, 20))
        
        # Recovery options
        options_frame = ttk.LabelFrame(main_frame, text="Recovery Options")
        options_frame.pack(fill=tk.X, pady=(0, 20))
        
        for i, option in enumerate(self.recovery_options):
            btn = ttk.Button(
                options_frame,
                text=option['text'],
                command=lambda opt=option: self._on_recovery_option(opt)
            )
            btn.pack(fill=tk.X, pady=2)
        
        # Cancel button
        cancel_btn = ttk.Button(main_frame, text="Cancel", command=self._on_cancel)
        cancel_btn.pack(pady=(10, 0))
    
    def _center_on_parent(self):
        """Center dialog on parent window."""
        self.update_idletasks()
        
        if self.parent:
            parent_x = self.parent.winfo_rootx()
            parent_y = self.parent.winfo_rooty()
            parent_width = self.parent.winfo_width()
            parent_height = self.parent.winfo_height()
            
            dialog_width = self.winfo_reqwidth()
            dialog_height = self.winfo_reqheight()
            
            x = parent_x + (parent_width - dialog_width) // 2
            y = parent_y + (parent_height - dialog_height) // 2
            
            self.geometry(f"{dialog_width}x{dialog_height}+{x}+{y}")
    
    def _on_recovery_option(self, option: Dict):
        """Handle recovery option selection."""
        self.result = option
        self.destroy()
    
    def _on_cancel(self):
        """Handle cancel."""
        self.result = None
        self.destroy()
    
    def show(self):
        """Show dialog and return result."""
        self.wait_window()
        return self.result


class AutoSaveManager:
    """Handles automatic saving and crash recovery."""
    
    def __init__(self, save_interval: int = 300):  # 5 minutes
        self.save_interval = save_interval
        self.recovery_file = Path.home() / ".plana_figura" / "recovery.pfd"
        self.recovery_file.parent.mkdir(exist_ok=True)
        self._timer = None
        self._document = None
    
    def start_auto_save(self, document):
        """Start automatic saving timer."""
        self._document = document
        self._schedule_next_save()
    
    def stop_auto_save(self):
        """Stop automatic saving."""
        if self._timer:
            self._timer.cancel()
            self._timer = None
    
    def _schedule_next_save(self):
        """Schedule the next auto-save."""
        if self._timer:
            self._timer.cancel()
        
        self._timer = threading.Timer(self.save_interval, self._perform_auto_save)
        self._timer.daemon = True
        self._timer.start()
    
    def _perform_auto_save(self):
        """Perform automatic save."""
        try:
            if self._document and self._document.is_modified():
                # Save to recovery file
                self._document.save_to_file(self.recovery_file)
                logger.info("Auto-save completed")
        except Exception as e:
            logger.error(f"Auto-save failed: {e}")
        finally:
            # Schedule next save
            self._schedule_next_save()
    
    def check_for_recovery(self) -> bool:
        """Check if recovery file exists from previous crash."""
        return self.recovery_file.exists()
    
    def load_recovery_file(self):
        """Load the recovery file."""
        if self.recovery_file.exists():
            # Implementation depends on document loading mechanism
            return self.recovery_file
        return None
    
    def clear_recovery_file(self):
        """Clear the recovery file after successful save."""
        if self.recovery_file.exists():
            self.recovery_file.unlink()


class SafeFileManager:
    """Handles safe file operations with comprehensive error handling."""
    
    @staticmethod
    def safe_read_file(filepath: Path, encoding: str = 'utf-8') -> str:
        """Safely read a file with proper error handling."""
        try:
            return filepath.read_text(encoding=encoding)
        except FileNotFoundError:
            raise FileIOError(
                f"File not found: {filepath}",
                error_code="FILE_NOT_FOUND",
                context={"filepath": str(filepath)}
            )
        except PermissionError:
            raise FileIOError(
                f"Permission denied: {filepath}",
                error_code="FILE_PERMISSION_DENIED",
                context={"filepath": str(filepath)}
            )
        except UnicodeDecodeError as e:
            raise FileIOError(
                f"File encoding error: {filepath}",
                error_code="FILE_ENCODING_ERROR",
                context={"filepath": str(filepath), "encoding": encoding, "error": str(e)}
            )
        except OSError as e:
            raise FileIOError(
                f"File system error: {filepath}",
                error_code="FILE_SYSTEM_ERROR",
                context={"filepath": str(filepath), "error": str(e)}
            )
    
    @staticmethod
    def safe_write_file(filepath: Path, content: str, encoding: str = 'utf-8', backup: bool = True):
        """Safely write a file with backup and error handling."""
        backup_path = None
        
        try:
            # Create backup if file exists and backup is requested
            if backup and filepath.exists():
                backup_path = filepath.with_suffix(filepath.suffix + '.backup')
                filepath.rename(backup_path)
            
            # Write the file
            filepath.write_text(content, encoding=encoding)
            
            # Remove backup on success
            if backup_path and backup_path.exists():
                backup_path.unlink()
                
        except PermissionError:
            # Restore backup if write failed
            if backup_path and backup_path.exists():
                backup_path.rename(filepath)
            
            raise FileIOError(
                f"Permission denied writing to: {filepath}",
                error_code="FILE_WRITE_PERMISSION_DENIED",
                context={"filepath": str(filepath)}
            )
        except OSError as e:
            # Restore backup if write failed
            if backup_path and backup_path.exists():
                backup_path.rename(filepath)
            
            raise FileIOError(
                f"File system error writing to: {filepath}",
                error_code="FILE_WRITE_SYSTEM_ERROR",
                context={"filepath": str(filepath), "error": str(e)}
            )


class ProgressIndicatorWithErrorHandling:
    """Progress indicator that handles errors gracefully."""
    
    def __init__(self, parent, title: str = "Processing..."):
        self.parent = parent
        self.title = title
        self.dialog = None
        self.progress_var = None
        self.status_var = None
        self.cancelled = False
    
    def __enter__(self):
        """Enter context manager."""
        self._create_dialog()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager."""
        if self.dialog:
            self.dialog.destroy()
        
        # Handle exceptions
        if exc_type and issubclass(exc_type, PlanaFiguraError):
            error_manager = ErrorDialogManager()
            error_manager.show_error(exc_val, self.parent)
            return True  # Suppress the exception
        
        return False
    
    def _create_dialog(self):
        """Create progress dialog."""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title(self.title)
        self.dialog.transient(self.parent)
        self.dialog.grab_set()
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        progress_bar = ttk.Progressbar(
            self.dialog, 
            variable=self.progress_var, 
            maximum=100
        )
        progress_bar.pack(padx=20, pady=10, fill=tk.X)
        
        # Status label
        self.status_var = tk.StringVar(value="Starting...")
        status_label = ttk.Label(self.dialog, textvariable=self.status_var)
        status_label.pack(padx=20, pady=(0, 10))
        
        # Cancel button
        cancel_btn = ttk.Button(self.dialog, text="Cancel", command=self._cancel)
        cancel_btn.pack(pady=(0, 20))
    
    def update_progress(self, percentage: float, status: str = ""):
        """Update progress and status."""
        if self.progress_var:
            self.progress_var.set(percentage)
        if self.status_var and status:
            self.status_var.set(status)
        
        if self.dialog:
            self.dialog.update()
    
    def _cancel(self):
        """Handle cancel button."""
        self.cancelled = True
    
    def is_cancelled(self) -> bool:
        """Check if operation was cancelled."""
        return self.cancelled
