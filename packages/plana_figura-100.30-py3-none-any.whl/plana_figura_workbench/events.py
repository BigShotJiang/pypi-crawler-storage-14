"""Event type definitions for Plana Figura Workbench.

This module defines all event types used for decoupled communication
between plugins via the Vultus Serpentis EventBus.
"""

from dataclasses import dataclass
from typing import Optional, List

# Import from local vultus_serpentis module
import sys
from pathlib import Path
_local_packages = Path(__file__).parent.parent.parent / "Local Packages" / "vultus_serpentis"
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

from vultus_serpentis.events import Event  # type: ignore
from plana_figura import Geometry, GeometryCollection, MeasurementType
from plana_figura.grid import Grid


@dataclass
class GeometrySelectedEvent(Event):
    """
    Published when geometry is selected in any view.

    Attributes:
        geometry: The selected geometry (None if deselected)
        source: Name of the plugin that published the event
    """

    geometry: Optional[Geometry]
    source: str


@dataclass
class GeometryAddedEvent(Event):
    """
    Published when geometry is added to the document.

    Attributes:
        geometry: The added geometry
        collection: The collection containing the geometry
    """

    geometry: Geometry
    collection: GeometryCollection


@dataclass
class GeometryModifiedEvent(Event):
    """
    Published when geometry is modified.

    Attributes:
        old_geometry: The original geometry
        new_geometry: The modified geometry
        collection: The collection containing the geometry
    """

    old_geometry: Geometry
    new_geometry: Geometry
    collection: GeometryCollection


@dataclass
class GeometryDeletedEvent(Event):
    """
    Published when geometry is deleted from the document.

    Attributes:
        geometry: The deleted geometry
        collection: The collection that contained the geometry
    """

    geometry: Geometry
    collection: GeometryCollection


@dataclass
class CollectionAddedEvent(Event):
    """
    Published when a geometry collection is added to the document.

    Attributes:
        collection: The added collection
    """

    collection: GeometryCollection


@dataclass
class CollectionRemovedEvent(Event):
    """
    Published when a geometry collection is removed from the document.

    Attributes:
        collection: The removed collection
    """

    collection: GeometryCollection


@dataclass
class DocumentClearedEvent(Event):
    """
    Published when the document is cleared (new document).

    Attributes:
        document_name: Name of the new document
    """

    document_name: str


@dataclass
class GridSettingsChangedEvent(Event):
    """
    Published when grid settings are modified.

    Attributes:
        grid: The updated grid configuration
    """

    grid: Grid


@dataclass
class ViewportChangedEvent(Event):
    """
    Published when the map view viewport changes (zoom/pan).

    Attributes:
        zoom_level: Current zoom level
        center_northing: Center northing coordinate
        center_easting: Center easting coordinate
    """

    zoom_level: float
    center_northing: float
    center_easting: float


@dataclass
class SelectionChangedEvent(Event):
    """
    Published when the selection set changes.

    Attributes:
        selected_geometries: List of currently selected geometries
        source: Name of the plugin that published the event
    """

    selected_geometries: List[Geometry]
    source: str


@dataclass
class GridChangedEvent(Event):
    """
    Published when the grid system changes.

    Attributes:
        grid: The new grid
        source: Name of the plugin that published the event
    """

    grid: Grid
    source: str


@dataclass
class GeometryPreviewEvent(Event):
    """
    Published when geometry preview should be shown/updated.

    Attributes:
        geometry: The preview geometry (None to clear preview)
        source: Name of the plugin that published the event
        operation_type: Type of operation (create, transform)
    """

    geometry: Optional[Geometry]
    source: str
    operation_type: str


@dataclass
class MeasurementSelectionEvent(Event):
    """
    Published when measurements are selected in a dialog.

    Attributes:
        measurements: List of selected measurements
        source: Name of the dialog/plugin
        dialog_type: Type of dialog (point_creation, line_creation, etc.)
    """

    measurements: List
    source: str
    dialog_type: str


# ============================================================================
# Measurement Events
# ============================================================================


@dataclass
class MeasurementAddedEvent(Event):
    """
    Published when a measurement is added to a collection.

    Attributes:
        measurement_id: ID of the added measurement
        collection_name: Name of the collection containing the measurement
        measurement_type: Type of the measurement
    """

    measurement_id: int
    collection_name: str
    measurement_type: MeasurementType


@dataclass
class MeasurementRemovedEvent(Event):
    """
    Published when a measurement is removed from a collection.

    Attributes:
        measurement_id: ID of the removed measurement
        collection_name: Name of the collection that contained the measurement
    """

    measurement_id: int
    collection_name: str


@dataclass
class MeasurementModifiedEvent(Event):
    """
    Published when a measurement is modified.

    Attributes:
        measurement_id: ID of the modified measurement
        collection_name: Name of the collection containing the measurement
        field_changed: Name of the field that was changed
    """

    measurement_id: int
    collection_name: str
    field_changed: str


@dataclass
class MeasurementCollectionCreatedEvent(Event):
    """
    Published when a measurement collection is created.

    Attributes:
        collection_name: Name of the created collection
    """

    collection_name: str


@dataclass
class MeasurementCollectionRemovedEvent(Event):
    """
    Published when a measurement collection is removed.

    Attributes:
        collection_name: Name of the removed collection
    """

    collection_name: str


@dataclass
class MeasurementSelectionChangedEvent(Event):
    """
    Published when the measurement selection changes.

    Attributes:
        selected_ids: List of selected measurement IDs
        collection_name: Name of the collection containing the measurements
    """

    selected_ids: List[int]
    collection_name: str
