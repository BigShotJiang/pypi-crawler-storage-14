"""
Plana Figura Workbench - GUI application for geometry manipulation.
"""

__version__ = "0.1.0"

# Import key modules for public API
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.events import (
    GeometrySelectedEvent,
    GeometryAddedEvent,
    GeometryModifiedEvent,
    GeometryDeletedEvent,
    CollectionAddedEvent,
    CollectionRemovedEvent,
    DocumentClearedEvent,
    GridSettingsChangedEvent,
    ViewportChangedEvent,
    SelectionChangedEvent,
)
from plana_figura_workbench.actions import WorkbenchActions

__all__ = [
    "__version__",
    "PlanaFiguraDocument",
    "WorkbenchActions",
    "GeometrySelectedEvent",
    "GeometryAddedEvent",
    "GeometryModifiedEvent",
    "GeometryDeletedEvent",
    "CollectionAddedEvent",
    "CollectionRemovedEvent",
    "DocumentClearedEvent",
    "GridSettingsChangedEvent",
    "ViewportChangedEvent",
    "SelectionChangedEvent",
]
