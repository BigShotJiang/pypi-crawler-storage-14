"""Action definitions for Plana Figura Workbench.

This module defines all Action objects used for centralizing UI logic
and state management across menus and buttons.
"""

from typing import Callable, Optional

# Import from local vultus_serpentis module
import sys
from pathlib import Path
_local_packages = Path(__file__).parent.parent / "Local Packages" / "vultus_serpentis"
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

from vultus_serpentis.actions import Action  # type: ignore
from vultus_serpentis.events import EventBus  # type: ignore


class WorkbenchActions:
    """
    Container for all application actions.

    This class creates and manages all Action objects used throughout
    the application. Actions centralize command logic and automatically
    update bound widgets when their state changes.
    """

    def __init__(self, event_bus: Optional[EventBus] = None):
        """
        Initialize all workbench actions.

        Args:
            event_bus: Optional EventBus for action events
        """
        self.event_bus = event_bus

        # File Actions
        self.new_action = Action(
            "New",
            lambda: None,  # Will be set by main app
            event_bus=event_bus,
            tooltip_text="Create a new document",
            accelerator="Ctrl+N"
        )

        self.open_action = Action(
            "Open...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Open an existing document",
            accelerator="Ctrl+O",
            enabled=False  # Not implemented yet
        )

        self.save_action = Action(
            "Save",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Save the current document",
            accelerator="Ctrl+S",
            enabled=False  # Not implemented yet
        )

        self.save_as_action = Action(
            "Save As...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Save the document with a new name",
            accelerator="Ctrl+Shift+S",
            enabled=False  # Not implemented yet
        )

        # Edit Actions
        self.undo_action = Action(
            "Undo",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Undo the last action",
            accelerator="Ctrl+Z",
            enabled=False
        )

        self.redo_action = Action(
            "Redo",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Redo the last undone action",
            accelerator="Ctrl+Y",
            enabled=False
        )

        self.select_all_action = Action(
            "Select All",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Select all geometries",
            accelerator="Ctrl+A"
        )

        self.deselect_all_action = Action(
            "Deselect All",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Clear selection",
            accelerator="Escape"
        )

        # Geometry Actions
        self.create_point_action = Action(
            "Create Point...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Create a new point"
        )

        self.create_line_action = Action(
            "Create Line...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Create a new line segment"
        )

        self.create_polyline_action = Action(
            "Create Polyline...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Create a new polyline"
        )

        self.delete_action = Action(
            "Delete",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Delete selected geometry",
            accelerator="Delete",
            enabled=False
        )

        self.duplicate_action = Action(
            "Duplicate",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Duplicate selected geometry",
            accelerator="Ctrl+D",
            enabled=False
        )

        self.edit_properties_action = Action(
            "Properties...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Edit geometry properties",
            accelerator="Alt+Enter",
            enabled=False
        )

        # Transform Actions
        self.translate_action = Action(
            "Translate...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Move selected geometry",
            enabled=False
        )

        self.rotate_action = Action(
            "Rotate...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Rotate selected geometry",
            enabled=False
        )

        self.scale_action = Action(
            "Scale...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Scale selected geometry",
            enabled=False
        )

        self.mirror_action = Action(
            "Mirror...",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Mirror selected geometry",
            enabled=False
        )

        # View Actions
        self.zoom_in_action = Action(
            "Zoom In",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Zoom in",
            accelerator="Ctrl++"
        )

        self.zoom_out_action = Action(
            "Zoom Out",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Zoom out",
            accelerator="Ctrl+-"
        )

        self.zoom_fit_action = Action(
            "Zoom Fit",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Fit all geometry in view",
            accelerator="Ctrl+0"
        )

        self.show_grid_action = Action(
            "Show Grid",
            lambda: None,
            event_bus=event_bus,
            tooltip_text="Toggle grid display"
        )

    def set_command(self, action_name: str, command: Callable[[], None]) -> None:
        """
        Set the command for a specific action.

        Args:
            action_name: Name of the action attribute (e.g., 'new_action')
            command: Callable to execute when action is triggered
        """
        action = getattr(self, action_name, None)
        if action and isinstance(action, Action):
            action._command = command

    def update_selection_actions(self, has_selection: bool) -> None:
        """
        Update action states based on selection.

        Args:
            has_selection: True if any geometry is selected
        """
        self.delete_action.enabled = has_selection
        self.duplicate_action.enabled = has_selection
        self.edit_properties_action.enabled = has_selection
        self.translate_action.enabled = has_selection
        self.rotate_action.enabled = has_selection
        self.scale_action.enabled = has_selection
        self.mirror_action.enabled = has_selection

    def update_undo_redo_actions(
        self,
        can_undo: bool,
        can_redo: bool
    ) -> None:
        """
        Update undo/redo action states.

        Args:
            can_undo: True if undo is available
            can_redo: True if redo is available
        """
        self.undo_action.enabled = can_undo
        self.redo_action.enabled = can_redo
