"""Comprehensive logging configuration for Plana Figura Workbench."""

import logging
import logging.handlers
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional
import json


class PlanaFiguraLogger:
    """Centralized logging configuration for Plana Figura."""
    
    def __init__(self, log_dir: Optional[Path] = None):
        """
        Initialize the logging system.
        
        Args:
            log_dir: Directory for log files. Defaults to user's home/.plana_figura/logs
        """
        if log_dir is None:
            log_dir = Path.home() / ".plana_figura" / "logs"
        
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Configure root logger
        self.root_logger = logging.getLogger()
        self.root_logger.setLevel(logging.DEBUG)
        
        # Clear any existing handlers
        self.root_logger.handlers.clear()
        
        # Setup handlers
        self._setup_console_handler()
        self._setup_file_handler()
        self._setup_error_handler()
        self._setup_performance_handler()
    
    def _setup_console_handler(self):
        """Setup console logging handler."""
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        
        # Console formatter - simpler format
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S'
        )
        console_handler.setFormatter(console_formatter)
        
        self.root_logger.addHandler(console_handler)
    
    def _setup_file_handler(self):
        """Setup rotating file handler for general logging."""
        log_file = self.log_dir / "plana_figura.log"
        
        # Rotating file handler - 10MB max, keep 5 backups
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        
        # Detailed formatter for file logging
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(funcName)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        
        self.root_logger.addHandler(file_handler)
    
    def _setup_error_handler(self):
        """Setup dedicated error logging handler."""
        error_file = self.log_dir / "errors.log"
        
        error_handler = logging.handlers.RotatingFileHandler(
            error_file,
            maxBytes=5 * 1024 * 1024,  # 5MB
            backupCount=10,
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        
        # JSON formatter for structured error logging
        error_handler.setFormatter(ErrorJSONFormatter())
        
        self.root_logger.addHandler(error_handler)
    
    def _setup_performance_handler(self):
        """Setup performance logging handler."""
        perf_file = self.log_dir / "performance.log"
        
        perf_handler = logging.handlers.RotatingFileHandler(
            perf_file,
            maxBytes=5 * 1024 * 1024,  # 5MB
            backupCount=3,
            encoding='utf-8'
        )
        perf_handler.setLevel(logging.INFO)
        
        # Filter for performance-related logs
        perf_handler.addFilter(PerformanceFilter())
        
        perf_formatter = logging.Formatter(
            '%(asctime)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        perf_handler.setFormatter(perf_formatter)
        
        self.root_logger.addHandler(perf_handler)
    
    def get_logger(self, name: str) -> logging.Logger:
        """Get a logger with the specified name."""
        return logging.getLogger(name)
    
    def log_system_info(self):
        """Log system information at startup."""
        import platform
        import psutil
        
        logger = self.get_logger("system")
        
        logger.info("=== Plana Figura Workbench Starting ===")
        logger.info(f"Platform: {platform.platform()}")
        logger.info(f"Python: {platform.python_version()}")
        logger.info(f"CPU Count: {psutil.cpu_count()}")
        logger.info(f"Memory: {psutil.virtual_memory().total / (1024**3):.1f} GB")
        logger.info(f"Log Directory: {self.log_dir}")


class ErrorJSONFormatter(logging.Formatter):
    """JSON formatter for structured error logging."""
    
    def format(self, record):
        """Format log record as JSON."""
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
        }
        
        # Add exception info if present
        if record.exc_info:
            log_entry['exception'] = {
                'type': record.exc_info[0].__name__,
                'message': str(record.exc_info[1]),
                'traceback': self.formatException(record.exc_info)
            }
        
        # Add extra fields if present
        if hasattr(record, 'error_code'):
            log_entry['error_code'] = record.error_code
        
        if hasattr(record, 'context'):
            log_entry['context'] = record.context
        
        return json.dumps(log_entry, ensure_ascii=False)


class PerformanceFilter(logging.Filter):
    """Filter for performance-related log messages."""
    
    def filter(self, record):
        """Filter performance-related messages."""
        performance_keywords = [
            'performance', 'timing', 'duration', 'memory', 'cpu',
            'slow', 'fast', 'optimization', 'benchmark'
        ]
        
        message = record.getMessage().lower()
        return any(keyword in message for keyword in performance_keywords)


class ErrorContextCollector:
    """Collects context information for error reporting."""
    
    @staticmethod
    def collect_context() -> dict:
        """Collect system and application context."""
        import platform
        import psutil
        import gc
        
        try:
            context = {
                'system': {
                    'platform': platform.platform(),
                    'python_version': platform.python_version(),
                    'cpu_count': psutil.cpu_count(),
                    'memory_total': psutil.virtual_memory().total,
                    'memory_available': psutil.virtual_memory().available,
                    'memory_percent': psutil.virtual_memory().percent,
                    'disk_usage': psutil.disk_usage('/').percent if platform.system() != 'Windows' else psutil.disk_usage('C:').percent,
                },
                'application': {
                    'timestamp': datetime.now().isoformat(),
                    'gc_objects': len(gc.get_objects()),
                    'gc_stats': gc.get_stats() if hasattr(gc, 'get_stats') else None,
                }
            }
            
            # Add process-specific info
            process = psutil.Process()
            context['process'] = {
                'memory_info': process.memory_info()._asdict(),
                'cpu_percent': process.cpu_percent(),
                'num_threads': process.num_threads(),
                'open_files': len(process.open_files()) if hasattr(process, 'open_files') else 0,
            }
            
            return context
            
        except Exception as e:
            # Fallback context if collection fails
            return {
                'error': f"Failed to collect context: {e}",
                'timestamp': datetime.now().isoformat()
            }


class ResourceMonitor:
    """Monitors system resources and logs warnings."""
    
    def __init__(self, memory_threshold: float = 80.0, disk_threshold: float = 90.0):
        """
        Initialize resource monitor.
        
        Args:
            memory_threshold: Memory usage percentage to trigger warning
            disk_threshold: Disk usage percentage to trigger warning
        """
        self.memory_threshold = memory_threshold
        self.disk_threshold = disk_threshold
        self.logger = logging.getLogger("resource_monitor")
    
    def check_resources(self):
        """Check system resources and log warnings if thresholds exceeded."""
        import psutil
        import platform
        
        try:
            # Check memory
            memory = psutil.virtual_memory()
            if memory.percent > self.memory_threshold:
                self.logger.warning(
                    f"High memory usage: {memory.percent:.1f}% "
                    f"({memory.used / (1024**3):.1f}GB / {memory.total / (1024**3):.1f}GB)"
                )
            
            # Check disk space
            disk_path = 'C:' if platform.system() == 'Windows' else '/'
            disk = psutil.disk_usage(disk_path)
            disk_percent = (disk.used / disk.total) * 100
            
            if disk_percent > self.disk_threshold:
                self.logger.warning(
                    f"Low disk space: {disk_percent:.1f}% used "
                    f"({disk.free / (1024**3):.1f}GB free)"
                )
            
            # Check for memory leaks (simplified)
            import gc
            gc_objects = len(gc.get_objects())
            if gc_objects > 100000:  # Arbitrary threshold
                self.logger.info(f"High object count: {gc_objects} objects in memory")
                
        except Exception as e:
            self.logger.error(f"Failed to check resources: {e}")


# Global logger instance
_logger_instance: Optional[PlanaFiguraLogger] = None


def setup_logging(log_dir: Optional[Path] = None) -> PlanaFiguraLogger:
    """Setup global logging configuration."""
    global _logger_instance
    
    if _logger_instance is None:
        _logger_instance = PlanaFiguraLogger(log_dir)
        _logger_instance.log_system_info()
    
    return _logger_instance


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance."""
    if _logger_instance is None:
        setup_logging()
    
    return _logger_instance.get_logger(name)


def log_error_with_context(logger: logging.Logger, error: Exception, context: dict = None):
    """Log an error with full context information."""
    # Collect system context
    full_context = ErrorContextCollector.collect_context()
    
    # Add provided context
    if context:
        full_context['error_context'] = context
    
    # Create log record with extra fields
    logger.error(
        f"Error occurred: {error}",
        exc_info=error,
        extra={
            'error_code': getattr(error, 'error_code', None),
            'context': full_context
        }
    )
