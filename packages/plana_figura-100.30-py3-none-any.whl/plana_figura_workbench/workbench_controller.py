"""
Workbench Controller - Business logic for the main application.

This controller is completely independent of the GUI framework,
making it fully testable without tkinter/ttkbootstrap dependencies.
"""

from typing import Optional
import logging
import sys
from pathlib import Path

# Add Local Packages to path for vultus_serpentis
_local_packages = Path(__file__).parent.parent / "Local Packages" / "vultus_serpentis"
if str(_local_packages) not in sys.path:
    sys.path.insert(0, str(_local_packages))

from vultus_serpentis.commands import CommandManager  # type: ignore
from vultus_serpentis.events import EventBus  # type: ignore

from plana_figura import Point, LineSegment, GeometryCollection, Geometry
from plana_figura_workbench.model import PlanaFiguraDocument
from plana_figura_workbench.events import (
    GeometrySelectedEvent,
    GeometryAddedEvent,
    GeometryDeletedEvent,
)
from plana_figura_workbench.commands import (
    AddGeometryCommand,
    RemoveGeometryCommand,
)
from plana_figura_workbench.controller_error_mixin import ControllerErrorMixin


logger = logging.getLogger(__name__)


class WorkbenchController(ControllerErrorMixin):
    """
    Controller for Plana Figura Workbench.

    Handles all business logic independent of UI framework.
    """

    def __init__(
        self,
        event_bus: Optional[EventBus] = None,
        command_manager: Optional[CommandManager] = None
    ):
        """
        Initialize the controller.

        Args:
            event_bus: Optional EventBus instance
            command_manager: Optional CommandManager instance
        """
        super().__init__()
        self.event_bus = event_bus or EventBus.default()
        self.command_manager = command_manager or CommandManager()

        # Document state
        self.document: Optional[PlanaFiguraDocument] = None
        self.selected_geometry: Optional[Geometry] = None

    def create_sample_document(self) -> PlanaFiguraDocument:
        """
        Create a sample document with default collections.

        Returns:
            PlanaFiguraDocument with default geometry and measurement collections
        """
        doc = PlanaFiguraDocument("Sample Document")

        # Create default geometry collections
        # 1. All Geometries (system collection - contains all geometries)
        all_geometries = GeometryCollection()
        all_geometries.name = "All Geometries"
        doc.add_collection(all_geometries, set_active=False)
        
        # 2. Unclaimed Geometries (system collection - geometries not in user collections)
        unclaimed_geometries = GeometryCollection()
        unclaimed_geometries.name = "Unclaimed Geometries"
        doc.add_collection(unclaimed_geometries, set_active=True)
        
        # 3. Imports folder (virtual folder for imported geometry collections)
        # Note: Individual import collections will be added when files are imported
        
        # 4. Exports folder (virtual folder for exported geometry collections)
        # Note: Individual export collections will be added when files are exported
        
        # Add some sample geometries to Unclaimed Geometries
        unclaimed_geometries.add(Point(100, 100, 0))
        unclaimed_geometries.add(Point(200, 100, 0))
        unclaimed_geometries.add(Point(200, 200, 0))
        unclaimed_geometries.add(LineSegment(Point(100, 100, 0), Point(200, 200, 0)))

        # Create default measurement collections
        from plana_figura import MeasurementCollection
        
        # 1. All Measurements (system collection - contains all measurements)
        all_measurements = MeasurementCollection("All Measurements")
        doc.add_measurement_collection(all_measurements, set_active=False)
        
        # 2. Unclaimed Measurements (system collection - measurements not in user collections)
        unclaimed_measurements = MeasurementCollection("Unclaimed Measurements")
        doc.add_measurement_collection(unclaimed_measurements, set_active=True)
        
        # 3. Imports folder (virtual folder for imported measurement collections)
        # Note: Individual import collections will be added when files are imported
        
        # 4. Exports folder (virtual folder for exported measurement collections)
        # Note: Individual export collections will be added when files are exported

        logger.info(
            f"Created sample document with {len(doc.collections)} geometry collections "
            f"and {len(doc.measurement_collections)} measurement collections"
        )
        return doc

    def set_document(self, document: PlanaFiguraDocument) -> None:
        """
        Set the active document.

        Args:
            document: The document to set as active
        """
        self.document = document
        logger.info(f"Document set: {document.name}")

    def create_point(self, point: Point) -> bool:
        """
        Create a new point in the active collection.

        Args:
            point: The point to create

        Returns:
            True if successful, False otherwise
        """
        if not self.document or not self.document.active_collection:
            logger.error("No active document or collection")
            return False

        command = AddGeometryCommand(self.document, point)
        if self.command_manager.execute(command):
            # Publish event
            self.event_bus.publish(GeometryAddedEvent(
                geometry=point,
                collection=self.document.active_collection
            ))
            logger.info("Point created successfully")
            return True

        logger.error("Failed to create point")
        return False

    def create_line(self, line: LineSegment) -> bool:
        """
        Create a new line segment in the active collection.

        Args:
            line: The line segment to create

        Returns:
            True if successful, False otherwise
        """
        if not self.document or not self.document.active_collection:
            logger.error("No active document or collection")
            return False

        command = AddGeometryCommand(self.document, line)
        if self.command_manager.execute(command):
            # Publish event
            self.event_bus.publish(GeometryAddedEvent(
                geometry=line,
                collection=self.document.active_collection
            ))
            logger.info("Line created successfully")
            return True

        logger.error("Failed to create line")
        return False

    def create_polyline(self, polyline: Geometry) -> bool:
        """
        Create a new polyline in the active collection.

        Args:
            polyline: The polyline to create

        Returns:
            True if successful, False otherwise
        """
        if not self.document or not self.document.active_collection:
            logger.error("No active document or collection")
            return False

        command = AddGeometryCommand(self.document, polyline)
        if self.command_manager.execute(command):
            # Publish event
            self.event_bus.publish(GeometryAddedEvent(
                geometry=polyline,
                collection=self.document.active_collection
            ))
            logger.info("Polyline created successfully")
            return True

        logger.error("Failed to create polyline")
        return False

    def create_geometry(self, geometry: Geometry) -> bool:
        """
        Create a new geometry in the active collection.

        Generic method that works for any geometry type.

        Args:
            geometry: The geometry to create

        Returns:
            True if successful, False otherwise
        """
        if not self.document or not self.document.active_collection:
            logger.error("No active document or collection")
            return False

        command = AddGeometryCommand(self.document, geometry)
        if self.command_manager.execute(command):
            # Publish event
            self.event_bus.publish(GeometryAddedEvent(
                geometry=geometry,
                collection=self.document.active_collection
            ))
            logger.info(f"{type(geometry).__name__} created successfully")
            return True

        logger.error("Failed to create geometry")
        return False

    def delete_geometry(self, geometry: Geometry) -> bool:
        """
        Delete a geometry from the document.

        Args:
            geometry: The geometry to delete

        Returns:
            True if successful, False otherwise
        """
        if not self.document:
            logger.error("No active document")
            return False

        command = RemoveGeometryCommand(self.document, geometry)
        if self.command_manager.execute(command):
            # Clear selection if deleted geometry was selected
            if self.selected_geometry == geometry:
                self.selected_geometry = None

            # Publish event
            self.event_bus.publish(GeometryDeletedEvent(
                geometry=geometry,
                collection=None  # Command will find the collection
            ))
            logger.info(f"{type(geometry).__name__} deleted successfully")
            return True

        logger.error("Failed to delete geometry")
        return False

    def select_geometry(self, geometry: Optional[Geometry], source: str = "controller") -> None:
        """
        Select a geometry.

        Args:
            geometry: The geometry to select (None to deselect)
            source: Source identifier for event
        """
        self.selected_geometry = geometry

        # Publish event
        self.event_bus.publish(GeometrySelectedEvent(
            geometry=geometry,
            source=source
        ))

        if geometry:
            logger.info(f"Selected {type(geometry).__name__}")
        else:
            logger.info("Selection cleared")

    def undo(self) -> bool:
        """
        Undo the last command.

        Returns:
            True if successful, False otherwise
        """
        if self.command_manager.can_undo():
            self.command_manager.undo()
            logger.info("Undo executed")
            return True

        logger.warning("Cannot undo - no commands in history")
        return False

    def redo(self) -> bool:
        """
        Redo the last undone command.

        Returns:
            True if successful, False otherwise
        """
        if self.command_manager.can_redo():
            self.command_manager.redo()
            logger.info("Redo executed")
            return True

        logger.warning("Cannot redo - no commands to redo")
        return False

    def can_undo(self) -> bool:
        """Check if undo is available."""
        return self.command_manager.can_undo()

    def can_redo(self) -> bool:
        """Check if redo is available."""
        return self.command_manager.can_redo()

    def has_selection(self) -> bool:
        """Check if there is a selected geometry."""
        return self.selected_geometry is not None

    def get_geometry_count(self) -> int:
        """
        Get total geometry count in document.

        Returns:
            Number of geometries
        """
        if not self.document:
            return 0
        return self.document.get_geometry_count()

    def get_status_message(self) -> str:
        """
        Get current status message.

        Returns:
            Status message string
        """
        if self.selected_geometry:
            return f"Selected: {type(self.selected_geometry).__name__}"
        return "Ready"

    def get_geometry_count_message(self) -> str:
        """
        Get geometry count message.

        Returns:
            Count message string
        """
        count = self.get_geometry_count()
        return f"{count} {'geometry' if count == 1 else 'geometries'}"

    def get_undo_redo_state(self) -> tuple[bool, bool]:
        """
        Get current undo/redo state.

        Returns:
            Tuple of (can_undo, can_redo)
        """
        return (self.can_undo(), self.can_redo())
