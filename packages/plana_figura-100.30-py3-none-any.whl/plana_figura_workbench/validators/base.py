"""Base validator classes for input validation."""

from abc import ABC, abstractmethod
from typing import Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """
    Result of a validation operation.

    Attributes:
        is_valid: Whether the input is valid
        value: The validated/parsed value (if valid)
        error_message: Error message (if invalid)
    """

    is_valid: bool
    value: Optional[object] = None
    error_message: Optional[str] = None

    @staticmethod
    def success(value: object) -> 'ValidationResult':
        """
        Create a successful validation result.

        Args:
            value: The validated value

        Returns:
            ValidationResult with is_valid=True
        """
        return ValidationResult(is_valid=True, value=value)

    @staticmethod
    def failure(error_message: str) -> 'ValidationResult':
        """
        Create a failed validation result.

        Args:
            error_message: Description of the validation error

        Returns:
            ValidationResult with is_valid=False
        """
        return ValidationResult(is_valid=False, error_message=error_message)


class Validator(ABC):
    """
    Abstract base class for input validators.

    Validators parse and validate user input, converting strings
    to appropriate types and checking constraints.
    """

    @abstractmethod
    def validate(self, input_str: str) -> ValidationResult:
        """
        Validate and parse input string.

        Args:
            input_str: The input string to validate

        Returns:
            ValidationResult with parsed value or error message
        """
        pass

    def is_valid(self, input_str: str) -> bool:
        """
        Check if input is valid without parsing.

        Args:
            input_str: The input string to check

        Returns:
            True if valid, False otherwise
        """
        return self.validate(input_str).is_valid


class NumericValidator(Validator):
    """
    Validator for numeric input with optional range constraints.

    Attributes:
        min_value: Minimum allowed value (inclusive)
        max_value: Maximum allowed value (inclusive)
        allow_empty: Whether empty string is valid
        decimal_places: Number of decimal places to round to (None = no rounding)
    """

    def __init__(
        self,
        min_value: Optional[float] = None,
        max_value: Optional[float] = None,
        allow_empty: bool = False,
        decimal_places: Optional[int] = None
    ):
        """
        Initialize numeric validator.

        Args:
            min_value: Minimum allowed value
            max_value: Maximum allowed value
            allow_empty: Whether empty input is valid
            decimal_places: Number of decimal places for rounding
        """
        self.min_value = min_value
        self.max_value = max_value
        self.allow_empty = allow_empty
        self.decimal_places = decimal_places

    def validate(self, input_str: str) -> ValidationResult:
        """
        Validate numeric input.

        Args:
            input_str: The input string

        Returns:
            ValidationResult with float value or error
        """
        # Handle empty input
        if not input_str.strip():
            if self.allow_empty:
                return ValidationResult.success(None)
            return ValidationResult.failure("Value is required")

        # Try to parse as float
        try:
            value = float(input_str)
        except ValueError:
            return ValidationResult.failure(
                f"'{input_str}' is not a valid number"
            )

        # Check for NaN or infinity
        if not (-float('inf') < value < float('inf')):
            return ValidationResult.failure("Value must be finite")

        # Check range constraints
        if self.min_value is not None and value < self.min_value:
            return ValidationResult.failure(
                f"Value must be >= {self.min_value}"
            )

        if self.max_value is not None and value > self.max_value:
            return ValidationResult.failure(
                f"Value must be <= {self.max_value}"
            )

        # Round if requested
        if self.decimal_places is not None:
            value = round(value, self.decimal_places)

        return ValidationResult.success(value)


class CoordinatePairValidator(Validator):
    """
    Validator for coordinate pairs (e.g., "100.5, 200.3").

    Accepts formats:
    - "100.5, 200.3" (comma-separated)
    - "100.5 200.3" (space-separated)
    - "100.5,200.3" (no spaces)

    Attributes:
        separator: Expected separator character(s)
        min_value: Minimum allowed value for each coordinate
        max_value: Maximum allowed value for each coordinate
    """

    def __init__(
        self,
        separator: str = ",",
        min_value: Optional[float] = None,
        max_value: Optional[float] = None
    ):
        """
        Initialize coordinate pair validator.

        Args:
            separator: Separator character (comma or space)
            min_value: Minimum value for coordinates
            max_value: Maximum value for coordinates
        """
        self.separator = separator
        self.numeric_validator = NumericValidator(
            min_value=min_value,
            max_value=max_value
        )

    def validate(self, input_str: str) -> ValidationResult:
        """
        Validate coordinate pair input.

        Args:
            input_str: The input string (e.g., "100, 200")

        Returns:
            ValidationResult with tuple (x, y) or error
        """
        if not input_str.strip():
            return ValidationResult.failure("Coordinates are required")

        # Try to split by separator
        if self.separator in input_str:
            parts = input_str.split(self.separator)
        else:
            # Try space-separated
            parts = input_str.split()

        if len(parts) != 2:
            return ValidationResult.failure(
                f"Expected 2 coordinates, got {len(parts)}"
            )

        # Validate each coordinate
        results = []
        for i, part in enumerate(parts):
            result = self.numeric_validator.validate(part.strip())
            if not result.is_valid:
                return ValidationResult.failure(
                    f"Coordinate {i+1}: {result.error_message}"
                )
            results.append(result.value)

        return ValidationResult.success(tuple(results))


class IntegerValidator(Validator):
    """
    Validator for integer input with optional range constraints.

    Attributes:
        min_value: Minimum allowed value (inclusive)
        max_value: Maximum allowed value (inclusive)
        allow_empty: Whether empty string is valid
    """

    def __init__(
        self,
        min_value: Optional[int] = None,
        max_value: Optional[int] = None,
        allow_empty: bool = False
    ):
        """
        Initialize integer validator.

        Args:
            min_value: Minimum allowed value
            max_value: Maximum allowed value
            allow_empty: Whether empty input is valid
        """
        self.min_value = min_value
        self.max_value = max_value
        self.allow_empty = allow_empty

    def validate(self, input_str: str) -> ValidationResult:
        """
        Validate integer input.

        Args:
            input_str: The input string

        Returns:
            ValidationResult with int value or error
        """
        # Handle empty input
        if not input_str.strip():
            if self.allow_empty:
                return ValidationResult.success(None)
            return ValidationResult.failure("Value is required")

        # Try to parse as integer
        try:
            value = int(input_str)
        except ValueError:
            return ValidationResult.failure(
                f"'{input_str}' is not a valid integer"
            )

        # Check range constraints
        if self.min_value is not None and value < self.min_value:
            return ValidationResult.failure(
                f"Value must be >= {self.min_value}"
            )

        if self.max_value is not None and value > self.max_value:
            return ValidationResult.failure(
                f"Value must be <= {self.max_value}"
            )

        return ValidationResult.success(value)
