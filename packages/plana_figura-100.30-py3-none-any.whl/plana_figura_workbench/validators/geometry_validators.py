"""Validators for geometry-specific inputs."""

from typing import Optional
import logging

from plana_figura import Point
from plana_figura.angles import DecimalDegreesAngle
from plana_figura_workbench.validators.base import (
    Validator,
    ValidationResult,
    NumericValidator
)

logger = logging.getLogger(__name__)


class CoordinateValidator(NumericValidator):
    """
    Validator for coordinate values (Northing or Easting).

    Uses reasonable defaults for survey coordinates.
    """

    def __init__(
        self,
        min_value: Optional[float] = -1000000.0,
        max_value: Optional[float] = 10000000.0,
        decimal_places: int = 3
    ):
        """
        Initialize coordinate validator.

        Args:
            min_value: Minimum coordinate value
            max_value: Maximum coordinate value
            decimal_places: Number of decimal places
        """
        super().__init__(
            min_value=min_value,
            max_value=max_value,
            decimal_places=decimal_places
        )


class ElevationValidator(NumericValidator):
    """
    Validator for elevation values.

    Allows negative elevations (below sea level).
    """

    def __init__(
        self,
        min_value: Optional[float] = -1000.0,
        max_value: Optional[float] = 10000.0,
        decimal_places: int = 3,
        allow_empty: bool = True
    ):
        """
        Initialize elevation validator.

        Args:
            min_value: Minimum elevation
            max_value: Maximum elevation
            decimal_places: Number of decimal places
            allow_empty: Whether empty (default 0) is allowed
        """
        super().__init__(
            min_value=min_value,
            max_value=max_value,
            decimal_places=decimal_places,
            allow_empty=allow_empty
        )


class AngleValidator(Validator):
    """
    Validator for angle values in decimal degrees.

    Accepts various formats:
    - Decimal degrees: "45.5"
    - With degree symbol: "45.5°"
    - Negative angles: "-45.5"

    Attributes:
        min_degrees: Minimum angle in degrees
        max_degrees: Maximum angle in degrees
        normalize: Whether to normalize to 0-360 range
    """

    def __init__(
        self,
        min_degrees: float = 0.0,
        max_degrees: float = 360.0,
        normalize: bool = True
    ):
        """
        Initialize angle validator.

        Args:
            min_degrees: Minimum angle value
            max_degrees: Maximum angle value
            normalize: Whether to normalize to 0-360
        """
        self.min_degrees = min_degrees
        self.max_degrees = max_degrees
        self.normalize = normalize

    def validate(self, input_str: str) -> ValidationResult:
        """
        Validate angle input.

        Args:
            input_str: The input string

        Returns:
            ValidationResult with DecimalDegreesAngle or error
        """
        if not input_str.strip():
            return ValidationResult.failure("Angle is required")

        # Remove degree symbol if present
        clean_str = input_str.strip().replace('°', '').replace('deg', '')

        # Try to parse as float
        try:
            degrees = float(clean_str)
        except ValueError:
            return ValidationResult.failure(
                f"'{input_str}' is not a valid angle"
            )

        # Create angle object
        try:
            angle = DecimalDegreesAngle(degrees)
        except Exception as e:
            return ValidationResult.failure(f"Invalid angle: {e}")

        # Normalize if requested
        if self.normalize:
            # Normalize to 0-360 range
            normalized_degrees = degrees % 360
            angle = DecimalDegreesAngle(normalized_degrees)
            degrees = normalized_degrees

        # Check range
        if degrees < self.min_degrees or degrees > self.max_degrees:
            return ValidationResult.failure(
                f"Angle must be between {self.min_degrees}° "
                f"and {self.max_degrees}°"
            )

        return ValidationResult.success(angle)


class DistanceValidator(NumericValidator):
    """
    Validator for distance values.

    Distances must be positive (or zero).
    """

    def __init__(
        self,
        min_value: float = 0.0,
        max_value: Optional[float] = 100000.0,
        decimal_places: int = 3,
        allow_zero: bool = False
    ):
        """
        Initialize distance validator.

        Args:
            min_value: Minimum distance (usually 0)
            max_value: Maximum distance
            decimal_places: Number of decimal places
            allow_zero: Whether zero distance is allowed
        """
        if not allow_zero and min_value == 0.0:
            min_value = 0.001  # Minimum positive distance

        super().__init__(
            min_value=min_value,
            max_value=max_value,
            decimal_places=decimal_places
        )


class PointValidator(Validator):
    """
    Validator for complete Point input.

    Accepts formats:
    - "N, E" (2D point, elevation = 0)
    - "N, E, Z" (3D point)

    Attributes:
        require_elevation: Whether elevation is required
    """

    def __init__(self, require_elevation: bool = False):
        """
        Initialize point validator.

        Args:
            require_elevation: Whether elevation must be provided
        """
        self.require_elevation = require_elevation
        self.coord_validator = CoordinateValidator()
        self.elev_validator = ElevationValidator()

    def validate(self, input_str: str) -> ValidationResult:
        """
        Validate point input.

        Args:
            input_str: The input string (e.g., "100, 200" or "100, 200, 50")

        Returns:
            ValidationResult with Point object or error
        """
        if not input_str.strip():
            return ValidationResult.failure("Point coordinates are required")

        # Split by comma
        parts = [p.strip() for p in input_str.split(',')]

        if len(parts) < 2:
            return ValidationResult.failure(
                "Point requires at least Northing and Easting"
            )

        if len(parts) > 3:
            return ValidationResult.failure(
                f"Too many values: expected 2 or 3, got {len(parts)}"
            )

        # Validate northing
        north_result = self.coord_validator.validate(parts[0])
        if not north_result.is_valid:
            return ValidationResult.failure(
                f"Northing: {north_result.error_message}"
            )

        # Validate easting
        east_result = self.coord_validator.validate(parts[1])
        if not east_result.is_valid:
            return ValidationResult.failure(
                f"Easting: {east_result.error_message}"
            )

        # Validate elevation if provided
        elevation = 0.0
        if len(parts) == 3:
            elev_result = self.elev_validator.validate(parts[2])
            if not elev_result.is_valid:
                return ValidationResult.failure(
                    f"Elevation: {elev_result.error_message}"
                )
            elev_value = elev_result.value
            elevation = float(elev_value) if elev_value is not None else 0.0
        elif self.require_elevation:
            return ValidationResult.failure("Elevation is required")

        # Create Point object
        try:
            point = Point(
                northing=float(north_result.value),  # type: ignore[arg-type]
                easting=float(east_result.value),  # type: ignore[arg-type]
                elevation=elevation
            )
            return ValidationResult.success(point)
        except Exception as e:
            return ValidationResult.failure(f"Invalid point: {e}")


class AzimuthValidator(AngleValidator):
    """
    Validator for azimuth angles (0-360 degrees from North).

    Azimuth is always normalized to 0-360 range.
    """

    def __init__(self):
        """Initialize azimuth validator."""
        super().__init__(
            min_degrees=0.0,
            max_degrees=360.0,
            normalize=True
        )


class BearingValidator(Validator):
    """
    Validator for bearing input in surveying notation.

    Accepts formats:
    - "N 45 E" (45 degrees from North towards East)
    - "S 30 W" (30 degrees from South towards West)
    - "N 45° 30' E" (with degrees and minutes)

    Note: This is a simplified version. Full DMS parsing
    would be more complex.
    """

    def __init__(self):
        """Initialize bearing validator."""
        self.angle_validator = AngleValidator(
            min_degrees=0.0,
            max_degrees=90.0,
            normalize=False
        )

    def validate(self, input_str: str) -> ValidationResult:
        """
        Validate bearing input.

        Args:
            input_str: The input string (e.g., "N 45 E")

        Returns:
            ValidationResult with azimuth angle or error
        """
        if not input_str.strip():
            return ValidationResult.failure("Bearing is required")

        # Parse simple bearing format: "N 45 E"
        parts = input_str.upper().split()

        if len(parts) != 3:
            return ValidationResult.failure(
                "Bearing format: 'N/S angle E/W' (e.g., 'N 45 E')"
            )

        direction1, angle_str, direction2 = parts

        # Validate directions
        if direction1 not in ['N', 'S']:
            return ValidationResult.failure(
                "First direction must be N or S"
            )

        if direction2 not in ['E', 'W']:
            return ValidationResult.failure(
                "Second direction must be E or W"
            )

        # Validate angle
        angle_result = self.angle_validator.validate(angle_str)
        if not angle_result.is_valid:
            return ValidationResult.failure(
                f"Angle: {angle_result.error_message}"
            )

        angle_value = angle_result.value.angle_degrees

        # Convert to azimuth (0-360 from North)
        if direction1 == 'N' and direction2 == 'E':
            azimuth = angle_value
        elif direction1 == 'N' and direction2 == 'W':
            azimuth = 360 - angle_value
        elif direction1 == 'S' and direction2 == 'E':
            azimuth = 180 - angle_value
        else:  # S and W
            azimuth = 180 + angle_value

        try:
            azimuth_angle = DecimalDegreesAngle(azimuth)
            return ValidationResult.success(azimuth_angle)
        except Exception as e:
            return ValidationResult.failure(f"Invalid bearing: {e}")
