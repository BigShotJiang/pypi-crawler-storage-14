"""
Geometry builders for creating geometry from measurements.

This module provides functions for creating and transforming geometry using
surveying measurements (directions, distances, angles, vectors). It enables
surveying-style construction workflows.

Key functions:
- Point creation from vectors and direction/distance
- Line creation from vectors and direction/distance
- Line transformations (extend, offset, rotate)
- Polyline creation from vectors and direction/distance pairs
- Polygon creation (rectangles, regular polygons)
"""

import math
from typing import Optional, List, Tuple

from plana_figura.geometry import Point, SurveyorsDirection, Vector2D, Vector3D
from plana_figura.linear import LineSegment
from plana_figura.composite import SimplePolyline, SimplePolygon
from plana_figura.angles import DecimalDegreesAngle
from plana_figura.grid import Grid as TheGrid


# ============================================================================
# Point Creation
# ============================================================================

def create_point_from_vector(
    start_point: Point,
    vector: Vector3D,
    grid: Optional[TheGrid] = None
) -> Point:
    """
    Create point by applying 3D vector to start point.

    Args:
        start_point: Starting point
        vector: 3D vector to apply
        grid: Optional grid for the new point

    Returns:
        New point at start_point + vector

    Example:
        >>> from plana_figura import Point, Vector3D
        >>> start = Point(1000, 2000, 100)
        >>> vec = Vector3D(100.0, 50.0, 25.0)
        >>> end = create_point_from_vector(start, vec)
        >>> end.northing
        1100.0
        >>> end.easting
        2050.0
        >>> end.elevation
        125.0
    """
    new_northing = start_point.northing + vector.delta_northing
    new_easting = start_point.easting + vector.delta_easting
    new_elevation = start_point.elevation + vector.delta_elevation

    return Point(new_northing, new_easting, new_elevation, grid=grid)


def create_point_from_direction_distance(
    start_point: Point,
    direction: SurveyorsDirection,
    distance: float,
    elevation_change: float = 0.0,
    grid: Optional[TheGrid] = None
) -> Point:
    """
    Create point from start point, direction, and distance.

    Args:
        start_point: Starting point
        direction: Direction to travel
        distance: Horizontal distance
        elevation_change: Change in elevation (default: 0.0)
        grid: Optional grid for the new point

    Returns:
        New point

    Example:
        >>> from plana_figura import Point, SurveyorsDirection
        >>> import math
        >>> start = Point(1000, 2000, 100)
        >>> north = SurveyorsDirection(math.radians(0))
        >>> end = create_point_from_direction_distance(start, north, 100.0, 10.0)
        >>> end.northing
        1100.0
        >>> end.elevation
        110.0
    """
    # Create 2D vector from direction and distance
    vector_2d = Vector2D.from_direction_distance(direction, distance, grid)

    # Apply to start point
    new_northing = start_point.northing + vector_2d.delta_northing
    new_easting = start_point.easting + vector_2d.delta_easting
    new_elevation = start_point.elevation + elevation_change

    return Point(new_northing, new_easting, new_elevation, grid=grid)


# ============================================================================
# Line Segment Creation
# ============================================================================

def create_line_from_vector(
    start_point: Point,
    vector: Vector3D,
    grid: Optional[TheGrid] = None
) -> LineSegment:
    """
    Create line segment from start point and 3D vector.

    Args:
        start_point: Starting point
        vector: 3D vector defining direction and distance
        grid: Optional grid for the line segment

    Returns:
        New line segment

    Example:
        >>> from plana_figura import Point, Vector3D
        >>> start = Point(1000, 2000, 100)
        >>> vec = Vector3D(100.0, 50.0, 25.0)
        >>> line = create_line_from_vector(start, vec)
        >>> line.end_point.northing
        1100.0
        >>> line.end_point.easting
        2050.0
        >>> line.end_point.elevation
        125.0
    """
    end_point = create_point_from_vector(start_point, vector, grid)
    return LineSegment(start_point, end_point, grid=grid)


def create_line_from_direction_distance(
    start_point: Point,
    direction: SurveyorsDirection,
    distance: float,
    elevation_change: float = 0.0,
    grid: Optional[TheGrid] = None
) -> LineSegment:
    """
    Create line segment from start point, direction, and distance.

    Args:
        start_point: Starting point
        direction: Direction of the line
        distance: Horizontal distance
        elevation_change: Change in elevation (default: 0.0)
        grid: Optional grid for the line segment

    Returns:
        New line segment

    Example:
        >>> from plana_figura import Point, SurveyorsDirection
        >>> import math
        >>> start = Point(1000, 2000, 100)
        >>> north = SurveyorsDirection(math.radians(0))
        >>> line = create_line_from_direction_distance(start, north, 100.0, 10.0)
        >>> line.end_point.northing
        1100.0
        >>> line.end_point.elevation
        110.0
    """
    end_point = create_point_from_direction_distance(
        start_point, direction, distance, elevation_change, grid
    )
    return LineSegment(start_point, end_point, grid=grid)


# ============================================================================
# Line Segment Transformations
# ============================================================================

def extend_line_segment(
    line: LineSegment,
    distance: float,
    from_start: bool = False,
    grid: Optional[TheGrid] = None
) -> LineSegment:
    """
    Extend line segment by a distance in the same direction.

    Args:
        line: Original line segment
        distance: Distance to extend (can be negative to shorten)
        from_start: Extend from start (True) or end (False)
        grid: Optional grid for the new line segment

    Returns:
        New extended line segment

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> line = LineSegment(Point(0, 0, 0), Point(100, 0, 0))
        >>> extended = extend_line_segment(line, 50.0)
        >>> extended.end_point.northing
        150.0
    """
    # Get the direction of the line
    direction = line.azimuth

    if from_start:
        # Extend from start (reverse direction)
        reverse_direction = line.reverse_azimuth
        new_start = create_point_from_direction_distance(
            line.start_point, reverse_direction, distance, 0.0, grid
        )
        return LineSegment(new_start, line.end_point, grid=grid)
    else:
        # Extend from end (forward direction)
        new_end = create_point_from_direction_distance(
            line.end_point, direction, distance, 0.0, grid
        )
        return LineSegment(line.start_point, new_end, grid=grid)


def offset_line_segment(
    line: LineSegment,
    distance: float,
    side: str = 'right',
    grid: Optional[TheGrid] = None
) -> LineSegment:
    """
    Create parallel line offset from original.

    Args:
        line: Original line segment
        distance: Offset distance (perpendicular to line)
        side: 'right' or 'left' (relative to direction of travel)
        grid: Optional grid for the new line segment

    Returns:
        New offset line segment

    Raises:
        ValueError: If side is not 'right' or 'left'

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> line = LineSegment(Point(0, 0, 0), Point(100, 0, 0))  # North
        >>> offset = offset_line_segment(line, 10.0, 'right')
        >>> # New line 10m to the East
    """
    if side not in ('right', 'left'):
        raise ValueError(f"side must be 'right' or 'left', got '{side}'")

    # Get perpendicular direction
    line_direction = line.azimuth

    # Right = +90°, Left = -90°
    angle_offset = 90.0 if side == 'right' else -90.0
    perp_angle = DecimalDegreesAngle(angle_offset)

    # Calculate perpendicular direction
    from plana_figura.measurement_operations import apply_angle_to_direction
    perp_direction = apply_angle_to_direction(line_direction, perp_angle, grid)

    # Offset both points
    new_start = create_point_from_direction_distance(
        line.start_point, perp_direction, distance, 0.0, grid
    )
    new_end = create_point_from_direction_distance(
        line.end_point, perp_direction, distance, 0.0, grid
    )

    return LineSegment(new_start, new_end, grid=grid)


def rotate_line_segment(
    line: LineSegment,
    angle: DecimalDegreesAngle,
    pivot_point: Optional[Point] = None,
    grid: Optional[TheGrid] = None
) -> LineSegment:
    """
    Create new line by rotating existing line around a pivot point.

    Args:
        line: Original line segment
        angle: Rotation angle (+ = clockwise from North)
        pivot_point: Point to rotate around (default: start point)
        grid: Optional grid for the new line segment

    Returns:
        New rotated line segment

    Example:
        >>> from plana_figura import Point, LineSegment, DecimalDegreesAngle
        >>> line = LineSegment(Point(0, 0, 0), Point(100, 0, 0))
        >>> angle = DecimalDegreesAngle(90.0)
        >>> rotated = rotate_line_segment(line, angle)
        >>> # Line now points East instead of North
    """
    if pivot_point is None:
        pivot_point = line.start_point

    # Rotate start point (if not the pivot)
    if pivot_point == line.start_point:
        new_start = line.start_point
    else:
        # Calculate vector from pivot to start
        dx_start = line.start_point.easting - pivot_point.easting
        dy_start = line.start_point.northing - pivot_point.northing

        # Rotate the vector (clockwise from North in surveying convention)
        # Standard rotation is counterclockwise, so we negate the angle
        angle_rad = math.radians(angle.angle_degrees)
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)

        # For surveying: rotate clockwise from North
        # North=+Y, East=+X, so rotation matrix is:
        # [cos  sin] for clockwise
        # [-sin cos]
        new_dx_start = dx_start * cos_a + dy_start * sin_a
        new_dy_start = -dx_start * sin_a + dy_start * cos_a

        new_start = Point(
            pivot_point.northing + new_dy_start,
            pivot_point.easting + new_dx_start,
            line.start_point.elevation,
            grid=grid
        )

    # Rotate end point
    dx_end = line.end_point.easting - pivot_point.easting
    dy_end = line.end_point.northing - pivot_point.northing

    angle_rad = math.radians(angle.angle_degrees)
    cos_a = math.cos(angle_rad)
    sin_a = math.sin(angle_rad)

    # For surveying: rotate clockwise from North
    new_dx_end = dx_end * cos_a + dy_end * sin_a
    new_dy_end = -dx_end * sin_a + dy_end * cos_a

    new_end = Point(
        pivot_point.northing + new_dy_end,
        pivot_point.easting + new_dx_end,
        line.end_point.elevation,
        grid=grid
    )

    return LineSegment(new_start, new_end, grid=grid)


# ============================================================================
# Polyline Creation
# ============================================================================

def create_polyline_from_vectors(
    start_point: Point,
    vectors: List[Vector3D],
    grid: Optional[TheGrid] = None
) -> SimplePolyline:
    """
    Create polyline from start point and list of 3D vectors.

    Args:
        start_point: Starting point
        vectors: List of 3D vectors (one per segment)
        grid: Optional grid for the polyline

    Returns:
        New polyline

    Example:
        >>> from plana_figura import Point, Vector3D
        >>> start = Point(1000, 2000, 100)
        >>> vectors = [
        ...     Vector3D(100.0, 0.0, 0.0),   # 100m North
        ...     Vector3D(0.0, 50.0, 0.0),    # 50m East
        ...     Vector3D(-100.0, 0.0, 0.0)   # 100m South
        ... ]
        >>> polyline = create_polyline_from_vectors(start, vectors)
        >>> len(polyline.points)
        4
    """
    points = [start_point]
    current_point = start_point

    for vector in vectors:
        current_point = create_point_from_vector(current_point, vector, grid)
        points.append(current_point)

    return SimplePolyline(points)


def create_polyline_from_direction_distance_pairs(
    start_point: Point,
    pairs: List[Tuple[SurveyorsDirection, float]],
    elevation_changes: Optional[List[float]] = None,
    grid: Optional[TheGrid] = None
) -> SimplePolyline:
    """
    Create polyline from direction/distance pairs (traverse style).

    Args:
        start_point: Starting point
        pairs: List of (direction, distance) tuples
        elevation_changes: Optional elevation change for each segment
        grid: Optional grid for the polyline

    Returns:
        New polyline

    Example:
        >>> from plana_figura import Point, SurveyorsDirection
        >>> import math
        >>> start = Point(1000, 2000, 100)
        >>> north = SurveyorsDirection(math.radians(0))
        >>> east = SurveyorsDirection(math.radians(90))
        >>> pairs = [(north, 100.0), (east, 50.0)]
        >>> polyline = create_polyline_from_direction_distance_pairs(start, pairs)
        >>> len(polyline.points)
        3
    """
    if elevation_changes is None:
        elevation_changes = [0.0] * len(pairs)
    elif len(elevation_changes) != len(pairs):
        raise ValueError(
            f"elevation_changes length ({len(elevation_changes)}) "
            f"must match pairs length ({len(pairs)})"
        )

    points = [start_point]
    current_point = start_point

    for (direction, distance), elev_change in zip(pairs, elevation_changes):
        current_point = create_point_from_direction_distance(
            current_point, direction, distance, elev_change, grid
        )
        points.append(current_point)

    return SimplePolyline(points)


def extend_polyline(
    polyline: SimplePolyline,
    distance: float,
    from_start: bool = False,
    grid: Optional[TheGrid] = None
) -> SimplePolyline:
    """
    Extend polyline by distance in direction of first/last segment.

    Args:
        polyline: Original polyline
        distance: Distance to extend
        from_start: Extend from start (True) or end (False)
        grid: Optional grid for the new polyline

    Returns:
        New extended polyline

    Example:
        >>> # Polyline with 3 points
        >>> extended = extend_polyline(polyline, 25.0)
        >>> # New polyline with 4 points (extended at end)
    """
    if len(polyline.points) < 2:
        raise ValueError("Polyline must have at least 2 points to extend")

    points = list(polyline.points)

    if from_start:
        # Extend from start
        first_segment = LineSegment(points[1], points[0])
        direction = first_segment.azimuth
        new_point = create_point_from_direction_distance(
            points[0], direction, distance, 0.0, grid
        )
        points.insert(0, new_point)
    else:
        # Extend from end
        last_segment = LineSegment(points[-2], points[-1])
        direction = last_segment.azimuth
        new_point = create_point_from_direction_distance(
            points[-1], direction, distance, 0.0, grid
        )
        points.append(new_point)

    return SimplePolyline(points)


# ============================================================================
# Polygon Creation
# ============================================================================

def create_rectangle(
    corner_point: Point,
    width: float,
    height: float,
    rotation: Optional[DecimalDegreesAngle] = None,
    grid: Optional[TheGrid] = None
) -> SimplePolygon:
    """
    Create rectangle from corner point and dimensions.

    Args:
        corner_point: Lower-left corner (before rotation)
        width: Width (East-West dimension before rotation)
        height: Height (North-South dimension before rotation)
        rotation: Optional rotation angle (+ = clockwise from North)
        grid: Optional grid for the polygon

    Returns:
        New rectangular polygon

    Example:
        >>> from plana_figura import Point
        >>> corner = Point(1000, 2000, 100)
        >>> rect = create_rectangle(corner, 50.0, 100.0)
        >>> len(rect.points)
        5
    """
    # Create rectangle aligned with N-E axes
    p1 = corner_point
    p2 = Point(corner_point.northing + height, corner_point.easting, corner_point.elevation, grid)
    p3 = Point(corner_point.northing + height, corner_point.easting +
               width, corner_point.elevation, grid)
    p4 = Point(corner_point.northing, corner_point.easting + width, corner_point.elevation, grid)

    points = [p1, p2, p3, p4, p1]  # Close the polygon

    # Apply rotation if specified
    if rotation is not None and rotation.angle_degrees != 0.0:
        # Rotate around corner point
        rotated_points = []
        for point in points:
            if point == corner_point:
                rotated_points.append(point)
            else:
                # Calculate vector from corner to point
                dx = point.easting - corner_point.easting
                dy = point.northing - corner_point.northing

                # Rotate the vector (clockwise from North in surveying convention)
                angle_rad = math.radians(rotation.angle_degrees)
                cos_a = math.cos(angle_rad)
                sin_a = math.sin(angle_rad)

                new_dx = dx * cos_a + dy * sin_a
                new_dy = -dx * sin_a + dy * cos_a

                rotated_point = Point(
                    corner_point.northing + new_dy,
                    corner_point.easting + new_dx,
                    point.elevation,
                    grid=grid
                )
                rotated_points.append(rotated_point)

        points = rotated_points

    return SimplePolygon(points)


def create_regular_polygon(
    center: Point,
    radius: float,
    num_sides: int,
    rotation: Optional[DecimalDegreesAngle] = None,
    grid: Optional[TheGrid] = None
) -> SimplePolygon:
    """
    Create regular polygon (equal sides and angles).

    Args:
        center: Center point
        radius: Distance from center to vertices
        num_sides: Number of sides (must be >= 3)
        rotation: Optional rotation angle (+ = clockwise from North)
        grid: Optional grid for the polygon

    Returns:
        New regular polygon

    Raises:
        ValueError: If num_sides < 3

    Example:
        >>> from plana_figura import Point
        >>> center = Point(1000, 2000, 100)
        >>> hexagon = create_regular_polygon(center, 50.0, 6)
        >>> len(hexagon.points)
        7
    """
    if num_sides < 3:
        raise ValueError(f"num_sides must be >= 3, got {num_sides}")

    # Calculate angle between vertices
    angle_step = 360.0 / num_sides

    # Start angle (pointing North by default)
    start_angle = rotation.angle_degrees if rotation is not None else 0.0

    # Create vertices
    points = []
    for i in range(num_sides):
        angle_deg = start_angle + (i * angle_step)
        angle_rad = math.radians(angle_deg)

        # Calculate point position
        # In surveying: 0° = North, 90° = East
        dx = radius * math.sin(angle_rad)
        dy = radius * math.cos(angle_rad)

        point = Point(
            center.northing + dy,
            center.easting + dx,
            center.elevation,
            grid=grid
        )
        points.append(point)

    # Close the polygon
    points.append(points[0])

    return SimplePolygon(points)
