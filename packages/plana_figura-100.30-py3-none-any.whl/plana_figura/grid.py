"""Grid system for geometric calculations."""

import math
from enum import Enum, auto
from dataclasses import dataclass
from typing import Any, TYPE_CHECKING

from .exceptions import ValidationError
from .angles import DecimalDegreesAngle

if TYPE_CHECKING:
    from .geometry import Coordinate

class CardinalDirection(Enum):
    """Cardinal directions for angle reference."""
    NORTH = auto()
    EAST = auto()
    SOUTH = auto()
    WEST = auto()

class AngleDirection(Enum):
    """Direction for measuring angles."""
    CLOCKWISE = auto()
    COUNTERCLOCKWISE = auto()

@dataclass(frozen=True)
class Grid:
    """A grid system for snapping coordinates and angles.
    
    Args:
        grid_interval: The interval between grid lines
        coordinate_tolerance: The tolerance for snapping coordinates to grid lines
        distance_tolerance: The tolerance for snapping distances to grid lines
        angle_tolerance_degrees: The tolerance for snapping angles to grid lines (in degrees)
        angle_interval_degrees: The interval for rounding angles in degrees
        zero_angle_direction: The direction of zero angle
        angle_measurement: The direction of angle measurement (clockwise or counterclockwise)
    """
    
    grid_interval: float = 0.01
    coordinate_tolerance: float = 0.02
    distance_tolerance: float = 0.02
    angle_tolerance_degrees: float = 5e-7
    angle_interval_degrees: float = 1.0
    zero_angle_direction: CardinalDirection = CardinalDirection.NORTH
    angle_measurement: AngleDirection = AngleDirection.CLOCKWISE
    
    def __post_init__(self) -> None:
        """Validate grid parameters."""
        if self.grid_interval <= 0:
            raise ValidationError(f"grid_interval must be positive, got {self.grid_interval}")
        if self.coordinate_tolerance <= 0:
            raise ValidationError(
                f"coordinate_tolerance must be positive, "
                f"got {self.coordinate_tolerance}"
            )
        if self.distance_tolerance <= 0:
            raise ValidationError(
                f"distance_tolerance must be positive, "
                f"got {self.distance_tolerance}"
            )
        if self.angle_tolerance_degrees <= 0:
            raise ValidationError(
                f"angle_tolerance_degrees must be positive, "
                f"got {self.angle_tolerance_degrees}"
            )
        if self.angle_interval_degrees <= 0:
            raise ValidationError(
                f"angle_interval_degrees must be positive, "
                f"got {self.angle_interval_degrees}"
            )
            
    def snap_coordinate(self, value: float) -> float:
        """Snap a coordinate value to the nearest grid line.
        
        Args:
            value: The coordinate value to snap
            
        Returns:
            float: The snapped coordinate value
        """
        # Find the nearest grid line
        grid_value = round(value / self.grid_interval) * self.grid_interval
        
        # Only snap if we're within tolerance
        if abs(value - grid_value) <= self.coordinate_tolerance:
            return grid_value
        return value
    
    def snap_angle(self, angle: DecimalDegreesAngle) -> DecimalDegreesAngle:
        """Snap an angle to the nearest grid angle.
        
        Args:
            angle: The angle to snap
            
        Returns:
            The snapped angle
        """
        # Handle special case where angle is very close to 0
        if abs(angle.angle_degrees) < self.angle_tolerance_degrees:
            return DecimalDegreesAngle(0.0)
        
        # Normalize angle to [0, 360)
        # (DecimalDegreesAngle already does this in __post_init__)
        
        # Snap to nearest grid angle based on angle_interval_degrees
        grid_index = round(angle.angle_degrees / self.angle_interval_degrees)
        snapped = grid_index * self.angle_interval_degrees
        
        # Only snap if we're within tolerance
        if abs(angle.angle_degrees - snapped) <= self.angle_tolerance_degrees:
            return DecimalDegreesAngle(snapped)
        return angle
    
    def is_coordinate_on_grid(self, value: float) -> bool:
        """Check if a coordinate value lies on a grid line.
        
        Args:
            value: The coordinate value to check
            
        Returns:
            True if the value is on a grid line, False otherwise
        """
        # Find distance to nearest grid line
        grid_line = round(value / self.grid_interval) * self.grid_interval
        # Use 10% of grid interval as tolerance
        return abs(value - grid_line) < self.grid_interval * 0.1
    
    def is_angle_on_grid(self, angle: DecimalDegreesAngle) -> bool:
        """Check if an angle aligns with the grid.
        
        Args:
            angle: The angle to check
            
        Returns:
            True if the angle is on a grid line, False otherwise
        """
        # Find nearest grid angle
        grid_index = round(angle.angle_degrees / self.angle_interval_degrees)
        grid_angle = grid_index * self.angle_interval_degrees
        
        # Check if within tolerance
        return abs(angle.angle_degrees - grid_angle) <= self.angle_tolerance_degrees
    
    def are_equal_within_tolerance(self, coord1: 'Coordinate', coord2: 'Coordinate') -> bool:
        """Check if two coordinates are equal within the grid's tolerance.
        
        Args:
            coord1: First coordinate
            coord2: Second coordinate
            
        Returns:
            bool: True if the coordinates are equal within tolerance
        """
        return coord1.equals_within_tolerance(coord2, self.coordinate_tolerance)
    
    def round_distance(self, distance: float) -> float:
        """Round a distance value to the nearest grid interval.
        
        Args:
            distance: The distance value to round
            
        Returns:
            float: The rounded distance value
        """
        if abs(distance) < self.distance_tolerance:
            return 0.0
        return round(distance / self.grid_interval) * self.grid_interval
    
    def round_angle(self, angle_degrees: float) -> float:
        """Round an angle value to the nearest grid angle interval.
        
        Args:
            angle_degrees: The angle value in degrees to round
            
        Returns:
            float: The rounded angle value in degrees
        """
        if abs(angle_degrees) < self.angle_tolerance_degrees:
            return 0.0
        interval = self.angle_interval_degrees
        return round(angle_degrees / interval) * interval
    
    def __eq__(self, other: Any) -> bool:
        """Compare two grid instances for equality."""
        if not isinstance(other, Grid):
            return NotImplemented
        return (
            self.grid_interval == other.grid_interval and
            self.coordinate_tolerance == other.coordinate_tolerance and
            self.distance_tolerance == other.distance_tolerance and
            self.angle_tolerance_degrees == other.angle_tolerance_degrees and
            self.angle_interval_degrees == other.angle_interval_degrees and
            self.zero_angle_direction == other.zero_angle_direction and
            self.angle_measurement == other.angle_measurement
        )
    
    def __hash__(self) -> int:
        """Compute hash value for grid instance."""
        return hash((
            round(self.grid_interval / self.coordinate_tolerance),
            round(self.coordinate_tolerance / self.coordinate_tolerance),
            round(self.distance_tolerance / self.distance_tolerance),
            round(self.angle_tolerance_degrees / self.angle_tolerance_degrees),
            round(self.angle_interval_degrees / self.angle_interval_degrees),
            self.zero_angle_direction,
            self.angle_measurement
        ))
    
    def __str__(self) -> str:
        """Return string representation of grid."""
        return (
            f"Grid(grid_interval={self.grid_interval}, "
            f"coordinate_tolerance={self.coordinate_tolerance}, "
            f"distance_tolerance={self.distance_tolerance}, "
            f"angle_tolerance_degrees={self.angle_tolerance_degrees}, "
            f"angle_interval_degrees={self.angle_interval_degrees}, "
            f"zero_angle_direction={self.zero_angle_direction}, "
            f"angle_measurement={self.angle_measurement})"
        )
    
    def __repr__(self) -> str:
        """Return detailed string representation of grid."""
        return str(self)
