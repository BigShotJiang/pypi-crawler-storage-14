from dataclasses import dataclass
from abc import ABC, abstractmethod
from typing import Optional, TYPE_CHECKING, Tuple, List, Iterator
from plana_figura.exceptions import ValidationError
from nanoid import generate
import re

if TYPE_CHECKING:
    from typing_extensions import Self

import itertools
import math
import logging

# Create logger
logger = logging.getLogger('plana_figura')

class GeometryError(Exception):
    """Base exception class for geometry-related errors."""
    pass

class TopologyError(GeometryError):
    """Exception raised for topology-related errors (e.g., disconnected elements)."""
    pass

@dataclass(frozen=True)
class Coordinate:
    """An immutable class representing a 3D coordinate using northing, easting, and elevation."""
    northing: float
    easting: float
    elevation: float

    def __post_init__(self) -> None:
        """Validate and convert values to float after initialization."""
        for field in ['northing', 'easting', 'elevation']:
            value = getattr(self, field)
            if not isinstance(value, (int, float)):
                raise ValidationError(f"{field} must be a number, got {type(value)}")
            if math.isnan(value) or math.isinf(value):
                raise ValidationError(f"{field} must be a finite number, got {value}")
            object.__setattr__(self, field, float(value))

    def equals_within_tolerance(self, other: 'Coordinate', tolerance: float = 1e-10) -> bool:
        """Check if two coordinates are equal within a specified tolerance."""
        if not isinstance(other, Coordinate):
            return False
        if tolerance < 0:
            raise ValidationError(f"Tolerance must be non-negative, got {tolerance}")
        return (abs(self.northing - other.northing) <= tolerance and
                abs(self.easting - other.easting) <= tolerance and
                abs(self.elevation - other.elevation) <= tolerance)

    def distance_to(self, other: 'Coordinate') -> float:
        """Calculate the 3D distance to another coordinate."""
        if not isinstance(other, Coordinate):
            raise ValidationError(f"Expected Coordinate, got {type(other)}")
        return math.sqrt(
            (self.northing - other.northing) ** 2 +
            (self.easting - other.easting) ** 2 +
            (self.elevation - other.elevation) ** 2
        )

@dataclass(frozen=True)
class TwoDimensionalEnvelope:
    """An immutable class representing a 2D bounding box defined by min/max northing and easting."""
    min_northing: float
    max_northing: float
    min_easting: float
    max_easting: float
    
    def __post_init__(self) -> None:
        """Validate and convert values to float after initialization."""
        for field in ['min_northing', 'max_northing', 'min_easting', 'max_easting']:
            value = getattr(self, field)
            if not isinstance(value, (int, float)):
                raise ValidationError(f"{field} must be a number, got {type(value)}")
            if math.isnan(value) or math.isinf(value):
                raise ValidationError(f"{field} must be a finite number, got {value}")
            object.__setattr__(self, field, float(value))
        
        if self.min_northing > self.max_northing:
            raise ValidationError("min_northing must be less than or equal to max_northing")
        if self.min_easting > self.max_easting:
            raise ValidationError("min_easting must be less than or equal to max_easting")
    
    @property
    def width(self) -> float:
        """Get the width (east-west extent) of the envelope."""
        return self.max_easting - self.min_easting
    
    @property
    def height(self) -> float:
        """Get the height (north-south extent) of the envelope."""
        return self.max_northing - self.min_northing

    def intersects(self, other: 'TwoDimensionalEnvelope') -> bool:
        """
        Check if this envelope intersects with another envelope.
        
        Args:
            other (TwoDimensionalEnvelope): The other envelope to check
            
        Returns:
            bool: True if the envelopes intersect, False otherwise
        """
        return not (self.max_northing < other.min_northing or
                   self.min_northing > other.max_northing or
                   self.max_easting < other.min_easting or
                   self.min_easting > other.max_easting)

    def contains(self, other: 'TwoDimensionalEnvelope') -> bool:
        """
        Check if this envelope fully contains another envelope.
        
        Args:
            other (TwoDimensionalEnvelope): The other envelope to check
            
        Returns:
            bool: True if this envelope contains the other envelope, False otherwise
        """
        return (self.min_northing <= other.min_northing and
                self.max_northing >= other.max_northing and
                self.min_easting <= other.min_easting and
                self.max_easting >= other.max_easting)

    def contains_point(self, point: 'Point', tolerance: float = 1e-10) -> bool:
        """
        Check if this envelope contains a point, with optional tolerance.
        
        Args:
            point (Point): The point to check
            tolerance (float, optional): Tolerance for floating point comparisons
            
        Returns:
            bool: True if the envelope contains the point, False otherwise
        """
        return (self.min_northing - tolerance <= point.northing <= self.max_northing + tolerance and
                self.min_easting - tolerance <= point.easting <= self.max_easting + tolerance)

class Geometry(ABC):
    """Base class for all geometry objects."""
    
    _next_id: int = 0  # Class variable for tracking IDs
    
    def __init__(
        self,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> None:
        """
        Initialize a geometry object.
        
        Args:
            uuid: Optional 16-character unique identifier (auto-generated if None)
                  Format: XXXX-XXXX-XXXX-XXXX (4 groups of 4 alphanumeric chars)
            name: Optional user-provided name for the geometry
            dxf_handle: Optional DXF handle for import/export persistence
        """
        self._id = self._get_next_id()
        
        # Generate UUID if not provided (format: XXXX-XXXX-XXXX-XXXX)
        if uuid is None:
            # Generate 16 characters, format as 4 groups of 4
            raw_id = generate(size=16)
            self._uuid = f"{raw_id[0:4]}-{raw_id[4:8]}-{raw_id[8:12]}-{raw_id[12:16]}"
        else:
            self._validate_uuid(uuid)
            self._uuid = uuid
        
        self._name = name
        self._dxf_handle = dxf_handle
    
    @staticmethod
    def _validate_uuid(uuid: str) -> None:
        """
        Validate UUID format (XXXX-XXXX-XXXX-XXXX).
        
        Args:
            uuid: The UUID string to validate
            
        Raises:
            ValidationError: If UUID format is invalid
        """
        pattern = r'^[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}$'
        if not re.match(pattern, uuid):
            raise ValidationError(
                f"Invalid UUID format: {uuid}. "
                "Expected format: XXXX-XXXX-XXXX-XXXX (16 alphanumeric characters)"
            )
    
    @property
    def id(self) -> int:
        """Get the unique ID of this geometry object."""
        return self._id
    
    @property
    def uuid(self) -> str:
        """Get the unique identifier."""
        return self._uuid
    
    @property
    def name(self) -> Optional[str]:
        """Get the user-provided name."""
        return self._name
    
    @name.setter
    def name(self, value: Optional[str]) -> None:
        """Set the user-provided name."""
        self._name = value
    
    @property
    def dxf_handle(self) -> Optional[str]:
        """Get the DXF handle."""
        return self._dxf_handle
    
    @dxf_handle.setter
    def dxf_handle(self, value: Optional[str]) -> None:
        """Set the DXF handle."""
        self._dxf_handle = value
    
    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope that contains this geometry.
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing this geometry
        """
        raise NotImplementedError("Subclasses must implement envelope_2d")
    
    @classmethod
    def _get_next_id(cls) -> int:
        """Get the next available geometry ID."""
        cls._next_id += 1
        return cls._next_id

class LinearGeometry(Geometry, ABC):
    """Base class for all linear geometry objects."""
    
    @abstractmethod
    def length(self) -> float:
        """
        Calculate the length of the linear geometry.
        
        Returns:
            float: The length of the geometry
        """
        pass
    
    @property
    @abstractmethod
    def start_point(self) -> 'Point':
        """
        Get the starting point of the linear geometry.
        
        Returns:
            Point: The start point
        """
        pass
    
    @property
    @abstractmethod
    def end_point(self) -> 'Point':
        """
        Get the ending point of the linear geometry.
        
        Returns:
            Point: The end point
        """
        pass
    
    @property
    @abstractmethod
    def azimuth(self) -> 'SurveyorsDirection':
        """
        Calculate the azimuth (bearing) from start to end point.
        For curved geometries, this is the chord azimuth.
        
        Returns:
            SurveyorsDirection: The azimuth of the geometry
        """
        pass

class Point(Geometry):
    """A class representing a 3D point using a Coordinate."""
    
    def __init__(
        self,
        northing: float,
        easting: float,
        elevation: float,
        grid=None,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """
        Initialize a 3D point.
        
        Args:
            northing (float): The northing coordinate (equivalent to y)
            easting (float): The easting coordinate (equivalent to x)
            elevation (float): The elevation coordinate (equivalent to z)
            grid (Grid, optional): The grid this point is in. Defaults to None.
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name for the point
            dxf_handle: Optional DXF handle for import/export persistence
            
        Raises:
            ValidationError: If any coordinate is not convertible to float or is not finite
        """
        from .exceptions import ValidationError
        import math
        
        # Convert and validate coordinates (from core.py Point)
        def convert_to_float(name: str, value) -> float:
            """Convert a value to float, with helpful error messages."""
            try:
                result = float(value)
                if math.isnan(result) or math.isinf(result):
                    raise ValidationError(f"{name} must be a finite number, got {value}")
                return result
            except (TypeError, ValueError) as e:
                raise ValidationError(
                    f"{name} must be convertible to float, "
                    f"got {value} ({type(value)})"
                )
        
        # Check if we have mixed types (some strings, some numbers)
        values = [northing, easting, elevation]
        str_count = sum(isinstance(v, str) for v in values)
        if 0 < str_count < len(values):
            raise ValidationError("Cannot mix string and numeric coordinate types")
        
        # Convert all values to float
        northing = convert_to_float("northing", northing)
        easting = convert_to_float("easting", easting)
        elevation = convert_to_float("elevation", elevation)
        
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        self._coordinate = Coordinate(northing, easting, elevation)
        
        # Set up grid (use default if none provided, like core.py)
        if grid is None:
            from .grid import Grid
            self._grid = Grid()
        else:
            self._grid = grid
    
    @classmethod
    def from_coordinate(cls, coordinate: Coordinate, grid=None, uuid: Optional[str] = None, 
                       name: Optional[str] = None, dxf_handle: Optional[str] = None) -> 'Point':
        """Create a point from a coordinate.
        
        Args:
            coordinate: The coordinate to create the point from
            grid: Optional grid system for the point
            uuid: Optional unique identifier
            name: Optional name for the point
            dxf_handle: Optional DXF handle
            
        Returns:
            A new point with the given coordinate
        """
        return cls(coordinate.northing, coordinate.easting, coordinate.elevation, 
                  grid=grid, uuid=uuid, name=name, dxf_handle=dxf_handle)
    
    @classmethod
    def from_point(cls, point: 'Point', grid=None, uuid: Optional[str] = None,
                  name: Optional[str] = None, dxf_handle: Optional[str] = None) -> 'Point':
        """Create a point from another point.
        
        Args:
            point: The point to copy coordinates from
            grid: Optional grid system for the point. If None, uses the source point's grid.
            uuid: Optional unique identifier
            name: Optional name for the point
            dxf_handle: Optional DXF handle
            
        Returns:
            A new point with the same coordinates
        """
        return cls(point.northing, point.easting, point.elevation, 
                  grid=grid or point.grid, uuid=uuid, name=name, dxf_handle=dxf_handle)
    
    @property
    def grid(self):
        """Get the grid system for this point."""
        return self._grid
    
    @property
    def northing(self) -> float:
        """Get the northing coordinate."""
        return self._coordinate.northing
    
    @property
    def easting(self) -> float:
        """Get the easting coordinate."""
        return self._coordinate.easting
    
    @property
    def elevation(self) -> float:
        """Get the elevation coordinate."""
        return self._coordinate.elevation
    
    def __str__(self) -> str:
        """Return a string representation of the point."""
        return f"Point(N={self.northing}, E={self.easting}, EL={self.elevation})"
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the point."""
        return self.__str__()
    
    def __eq__(self, other) -> bool:
        """Check if two points are equal."""
        if not isinstance(other, Point):
            return False
        return self.equals(other)
    
    def __hash__(self) -> int:
        """Make Point hashable so it can be used as dictionary keys."""
        return hash((self.northing, self.easting, self.elevation, self.uuid))
    
    def equals_within_tolerance(self, other: 'Point', tolerance: float) -> bool:
        """
        Check if two points are equal within a specified tolerance.
        
        Args:
            other (Point): Another point to compare with
            tolerance (float): The maximum allowed difference between coordinates
            
        Returns:
            bool: True if the points are equal within the specified tolerance
        """
        if not isinstance(other, Point):
            return False
        return self._coordinate.equals_within_tolerance(other._coordinate, tolerance)

    def distance_to(self, other: 'Point') -> float:
        """
        Calculate the 3D distance to another point.
        
        Args:
            other (Point): Another point to calculate distance to
            
        Returns:
            float: The 3D distance between the points
            
        Raises:
            ValidationError: If other is not a Point
        """
        from .exceptions import ValidationError
        if not isinstance(other, Point):
            raise ValidationError(f"Expected Point, got {type(other)}")
        return self._coordinate.distance_to(other._coordinate)
    
    def distance_2d_to(self, other: 'Point') -> float:
        """Calculate the 2D distance (ignoring elevation) to another point.
        
        Args:
            other (Point): Another point to calculate distance to
            
        Returns:
            float: The 2D distance between the points
            
        Raises:
            ValidationError: If other is not a Point
        """
        from .exceptions import ValidationError
        import math
        if not isinstance(other, Point):
            raise ValidationError(f"Expected Point, got {type(other)}")
        dx = self.easting - other.easting
        dy = self.northing - other.northing
        return math.sqrt(dx * dx + dy * dy)
    
    def distance_3d_to(self, other: 'Point') -> float:
        """Calculate the 3D distance to another point.
        
        This is an alias for distance_to() for API consistency.
        
        Args:
            other (Point): Another point to calculate distance to
            
        Returns:
            float: The 3D distance between the points
        """
        return self.distance_to(other)

    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope that contains this point.
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing the point
        """
        return TwoDimensionalEnvelope(
            min_northing=self.northing,
            max_northing=self.northing,
            min_easting=self.easting,
            max_easting=self.easting
        )

    def is_coincident(self, other: 'Point') -> bool:
        """Check if two points are coincident within the grid's tolerance.
        
        Args:
            other (Point): The other point to compare with
        
        Returns:
            bool: True if the points are coincident within the grid tolerance, False otherwise
        """
        if not isinstance(other, Point):
            return False
        return self._grid.are_equal_within_tolerance(self._coordinate, other._coordinate)
    
    def equals(self, other: 'Point') -> bool:
        """Check if two points are equal.
        
        Args:
            other (Point): The other point to compare with
        
        Returns:
            bool: True if the points are equal, False otherwise
        """
        if not isinstance(other, Point):
            return False
        return self.is_coincident(other)

class SurveyorsDirection:
    """A direction in surveyors notation (clockwise from north)."""
    
    def __init__(self, angle_radians: float):
        """Initialize a surveyors direction.
        
        Args:
            angle_radians (float): The angle in radians, measured clockwise from north
        """
        self._angle_radians = angle_radians % (2 * math.pi)
    
    @property
    def decimal_degrees(self) -> float:
        """Get the angle in decimal degrees."""
        return math.degrees(self._angle_radians)
    
    @property
    def angle_degrees(self) -> float:
        """Get the angle in decimal degrees."""
        return math.degrees(self._angle_radians)
    
    @property
    def angle_radians(self) -> float:
        """Get the angle in radians."""
        return self._angle_radians
    
    def __str__(self) -> str:
        """Return a string representation of the direction."""
        return f"{math.degrees(self._angle_radians):.2f}°"
    
    @staticmethod
    def from_points(start: Point, end: Point) -> 'SurveyorsDirection':
        """
        Create a direction from two points.
        
        Args:
            start (Point): The starting point
            end (Point): The ending point
        
        Returns:
            SurveyorsDirection: The direction from start to end
        """
        dx = end.easting - start.easting
        dy = end.northing - start.northing
        
        # atan2(y, x) gives angle from positive x-axis counterclockwise
        # For surveying: North=0°, East=90°, South=180°, West=270° (clockwise from North)
        # atan2(dx, dy) gives angle from North axis, but counterclockwise
        # So we need to negate and normalize to get clockwise from North
        angle = math.atan2(dx, dy)
        if angle < 0:
            angle += 2 * math.pi
        
        return SurveyorsDirection(angle)
    
    def equals_within_tolerance(self, other: 'SurveyorsDirection', tolerance: float) -> bool:
        """
        Check if this direction equals another within a tolerance.
        
        Args:
            other (SurveyorsDirection): The other direction
            tolerance (float): The tolerance in radians
        
        Returns:
            bool: True if the directions are equal within tolerance
        """
        # Handle wrap-around at 2π
        diff = abs(self._angle_radians - other._angle_radians)
        if diff > math.pi:
            diff = 2 * math.pi - diff
        return diff <= tolerance

class LineSegment(LinearGeometry):
    """A line segment defined by two points.
    
    A line segment is a finite line defined by a start point and an end point.
    It has properties like length, slope, and azimuth.
    """
    
    def __init__(self, start: Point, end: Point):
        """
        Initialize a line segment.
        
        Args:
            start (Point): The starting point of the line segment
            end (Point): The ending point of the line segment
        """
        super().__init__()
        self._start = start
        self._end = end
    
    @property
    def start_point(self) -> Point:
        """Get the starting point of the line segment."""
        return self._start
    
    @property
    def end_point(self) -> Point:
        """Get the ending point of the line segment."""
        return self._end
    
    def length(self) -> float:
        """
        Calculate the length of the line segment.
        
        Returns:
            float: The length of the line segment
        """
        return self._start.distance_to(self._end)
    
    def calculate_change_in_northing(self) -> float:
        """
        Calculate the change in northing from start to end point.
        
        Returns:
            float: The change in northing
        """
        return self._end.northing - self._start.northing
    
    def calculate_change_in_easting(self) -> float:
        """
        Calculate the change in easting from start to end point.
        
        Returns:
            float: The change in easting
        """
        return self._end.easting - self._start.easting
    
    def calculate_change_in_elevation(self) -> float:
        """
        Calculate the change in elevation from start to end point.
        
        Returns:
            float: The change in elevation
        """
        return self._end.elevation - self._start.elevation
    
    @property
    def slope(self) -> float:
        """
        Calculate the slope of the line segment.
        
        The slope is calculated as the ratio of change in elevation to
        the horizontal distance (sqrt(change_in_northing^2 + change_in_easting^2)).
        
        Returns:
            float: The slope of the line segment (infinity for vertical lines)
        """
        change_in_northing = self.calculate_change_in_northing()
        change_in_easting = self.calculate_change_in_easting()
        
        horizontal_distance = math.sqrt(change_in_northing**2 + change_in_easting**2)
        
        if horizontal_distance < 1e-10:  # Vertical line
            return float('inf')
            
        return self.calculate_change_in_elevation() / horizontal_distance
        
    @property
    def azimuth(self) -> SurveyorsDirection:
        """
        Calculate the azimuth (bearing) from start to end point.
        
        Returns:
            SurveyorsDirection: The azimuth of the line segment
        """
        change_in_northing = self.calculate_change_in_northing()
        change_in_easting = self.calculate_change_in_easting()
        
        # For points that are too close, return 0
        if abs(change_in_northing) < 1e-10 and abs(change_in_easting) < 1e-10:
            return SurveyorsDirection(0.0)
            
        # Calculate the angle in radians and convert to azimuth (clockwise from north)
        return SurveyorsDirection.from_points(self._start, self._end)
    
    @property
    def reverse_azimuth(self) -> SurveyorsDirection:
        """
        Calculate the reverse azimuth (bearing from end to start point).
        
        This is the azimuth you would measure if traveling from the end point
        back to the start point.
        
        Returns:
            SurveyorsDirection: The reverse azimuth of the line segment
        """
        return SurveyorsDirection.from_points(self._end, self._start)
    
    @property
    def horizontal_length(self) -> float:
        """
        Calculate the horizontal (2D) length of the line segment.
        
        This is the distance ignoring elevation differences, calculated as
        the Euclidean distance in the horizontal plane (N-E plane).
        
        Returns:
            float: The horizontal length in the same units as coordinates
        """
        delta_n = self.calculate_change_in_northing()
        delta_e = self.calculate_change_in_easting()
        return math.sqrt(delta_n**2 + delta_e**2)
        
    def point_at_parameter(self, t: float) -> Point:
        """
        Calculate the point at parameter t along the line segment.
        
        Args:
            t (float): Parameter value between 0 and 1, where:
                      0 = start point
                      1 = end point
                      0.5 = midpoint
                      
        Returns:
            Point: The point at parameter t
            
        Raises:
            ValidationError: If t is not between 0 and 1
        """
        if not 0 <= t <= 1:
            raise ValidationError("Parameter t must be between 0 and 1")
            
        # Linear interpolation
        northing = self._start.northing + t * self.calculate_change_in_northing()
        easting = self._start.easting + t * self.calculate_change_in_easting()
        elevation = self._start.elevation + t * self.calculate_change_in_elevation()
        
        return Point(northing, easting, elevation, grid=self._start._grid)

    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope that contains this line segment.
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing all points in the line segment
        """
        min_n = min(self._start.northing, self._end.northing)
        max_n = max(self._start.northing, self._end.northing)
        min_e = min(self._start.easting, self._end.easting)
        max_e = max(self._start.easting, self._end.easting)
        
        return TwoDimensionalEnvelope(min_n, max_n, min_e, max_e)
    
    def __str__(self) -> str:
        """Return a string representation of the line segment."""
        return f"LineSegment(start={str(self._start)}, end={str(self._end)})"
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the line segment."""
        return f"LineSegment(start={str(self._start)}, end={str(self._end)})"

class SimplePolyline(LinearGeometry):
    """A class representing a simple polyline made up of connected line segments."""
    
    def __init__(self, points: List[Point]):
        """
        Initialize a polyline with a list of points.
        
        Args:
            points (list[Point]): The ordered list of points defining the polyline.
                                Must contain at least 2 points.
            
        Raises:
            ValueError: If fewer than 2 points are provided
        """
        super().__init__()
        if len(points) < 2:
            raise ValueError("A polyline must have at least 2 points")
        
        self.points = points
        self._segments: Optional[List[LineSegment]] = None  # Lazy initialization of segments
    
    @property
    def start_point(self) -> Point:
        """Get the starting point of the polyline."""
        return self.points[0]
    
    @property
    def end_point(self) -> Point:
        """Get the ending point of the polyline."""
        return self.points[-1]
    
    def length(self) -> float:
        """
        Calculate the total length of the polyline.
        
        Returns:
            float: The sum of all segment lengths
        """
        return sum(segment.length() for segment in self.segments())
    
    @property
    def azimuth(self) -> SurveyorsDirection:
        """
        Get the azimuth from the start point to the end point.
        
        Returns:
            SurveyorsDirection: The azimuth of the chord from start to end
        """
        return LineSegment(self.start_point, self.end_point).azimuth
    
    def _create_segments(self) -> None:
        """Create line segments from the points if not already created."""
        if self._segments is None:
            self._segments = []
            for i in range(len(self.points) - 1):
                self._segments.append(LineSegment(self.points[i], self.points[i + 1]))
    
    def number_of_segments(self) -> int:
        """
        Get the number of line segments in the polyline.
        
        Returns:
            int: The number of line segments
        """
        return len(self.points) - 1
    
    def total_length(self) -> float:
        """
        Calculate the total length of the polyline.
        
        Returns:
            float: The sum of all segment lengths
        """
        self._create_segments()
        assert self._segments is not None  # For type checker
        return sum(segment.length() for segment in self._segments)
    
    def segments(self) -> List[LineSegment]:
        """
        Get a list of the line segments in the polyline.
        
        Returns:
            List[LineSegment]: The line segments in the polyline, in order
            
        Example:
            >>> for segment in polyline.segments():
            ...     print(f"Segment length: {segment.length()}")
        """
        self._create_segments()
        assert self._segments is not None  # For type checker
        return self._segments
    
    def points_iter(self):
        """
        Get an iterator over all points in the polyline.
        
        Yields:
            Point: Each point in the polyline, in order
            
        Example:
            >>> for point in polyline.points_iter():
            ...     print(f"Point: N={point.northing}, E={point.easting}")
        """
        return iter(self.points)

    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope that contains this polyline.
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing all points in the polyline
        """
        # Extract northing and easting coordinates
        northings = [p.northing for p in self.points]
        eastings = [p.easting for p in self.points]
        
        return TwoDimensionalEnvelope(
            min(northings),
            max(northings),
            min(eastings),
            max(eastings)
        )

class SimplePolygon(Geometry):
    """
    A class representing a simple (non-self-intersecting) polygon in 3D space.
    The polygon is defined by a sequence of points that form a closed figure.
    The last point is automatically connected to the first point to close the polygon.
    """
    
    def __init__(self, points: list[Point]):
        """
        Initialize a simple polygon with a list of points.
        
        Args:
            points (list[Point]): The vertices of the polygon in order.
                Must have at least 3 points to form a valid polygon.
                
        Raises:
            ValueError: If fewer than 3 points are provided
        """
        super().__init__()
        
        # Validate minimum number of points
        if len(points) < 3:
            raise ValueError("A polygon must have at least 3 points")
            
        # Store points as a tuple to make it immutable
        self._points = tuple(points)
        logger.debug(f"Created polygon with {len(self._points)} points")
    
    def __str__(self) -> str:
        """Return a string representation of the polygon."""
        points_str = ", ".join(str(p) for p in self._points)
        return f"SimplePolygon([{points_str}])"
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the polygon."""
        return self.__str__()
    
    @property
    def points(self) -> tuple[Point, ...]:
        """
        Get the points that define the polygon.
        
        Returns:
            tuple[Point, ...]: A tuple of points in order
        """
        return self._points
    
    @property
    def segments(self) -> list[LineSegment]:
        """
        Get the line segments that make up the polygon's boundary.
        
        Returns:
            list[LineSegment]: The line segments forming the polygon's boundary
        """
        segments = []
        
        # Create segments between consecutive points
        for i in range(len(self._points)):
            start = self._points[i]
            # Connect last point back to first point
            end = self._points[(i + 1) % len(self._points)]
            segments.append(LineSegment(start, end))
            
        return segments
    
    @property
    def perimeter(self) -> float:
        """
        Calculate the perimeter of the polygon.
        
        Returns:
            float: The sum of all segment lengths
        """
        return sum(segment.length() for segment in self.segments)
    
    @property
    def area(self) -> float:
        """
        Calculate the area of the polygon using the Shoelace formula.
        This assumes the polygon lies in a plane parallel to the N-E plane.
        
        Returns:
            float: The area of the polygon
            
        Note:
            The Shoelace formula calculates the area by taking half the sum of the
            cross products of consecutive vertices:
            Area = 0.5 * |∑(x[i]*y[i+1] - x[i+1]*y[i])|
            where x and y are easting and northing coordinates.
        """
        # Initialize sum
        sum_area = 0.0
        
        # Apply Shoelace formula
        for i in range(len(self._points)):
            j = (i + 1) % len(self._points)  # Next point (wraps around)
            
            # Get coordinates
            x1, y1 = self._points[i].easting, self._points[i].northing
            x2, y2 = self._points[j].easting, self._points[j].northing
            
            # Add cross product
            sum_area += x1 * y2 - x2 * y1
            
        # Take absolute value and divide by 2
        return abs(sum_area) / 2.0
    
    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope that contains this polygon.
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing the polygon
        """
        # Extract northing and easting coordinates
        northings = [p.northing for p in self._points]
        eastings = [p.easting for p in self._points]
        
        # Create envelope from min/max coordinates
        return TwoDimensionalEnvelope(
            min(northings),
            max(northings),
            min(eastings),
            max(eastings)
        )

class ComplexPolygon(Geometry):
    """
    A class representing a polygon with a boundary that can include both
    line segments and circular arcs. The polygon is defined by a sequence
    of connected linear geometry elements that form a closed figure.
    The last element's end point must connect to the first element's
    start point.
    """
    
    def __init__(self, elements: list[LinearGeometry]):
        """
        Initialize a complex polygon with a list of connected linear geometry elements.
        
        Args:
            elements (list[LinearGeometry]): The ordered list of connected linear geometry elements.
                                         Must contain at least 1 element.
                                         Each element must be either a LineSegment or CircularArc.
                                         Elements must be connected (end point of one element
                                         must be the start point of the next element).
                                         The last element's end point must
                                         connect to the first element's start point.
        
        Raises:
            ValueError: If no elements are provided
            ValueError: If elements are not connected
            ValueError: If an element is not a LineSegment or CircularArc
            ValueError: If the polygon is not closed (last element doesn't connect to first)
        """
        super().__init__()
        
        if not elements:
            raise ValueError("Complex polygon must have at least 1 element")
        
        # Validate element types
        for element in elements:
            if not isinstance(element, (LineSegment, CircularArc)):
                raise ValueError("Complex polygon elements must be LineSegment or CircularArc")
        
        # Validate elements are connected
        for i in range(len(elements) - 1):
            current = elements[i]
            next_element = elements[i + 1]
            if not current.end_point.is_coincident(next_element.start_point):
                raise ValueError(f"Elements at index {i} and {i+1} are not connected")
        
        # Validate polygon is closed
        if not elements[-1].end_point.is_coincident(elements[0].start_point):
            raise ValueError("Complex polygon must be closed (last element must connect to first)")
        
        self._elements = tuple(elements)
        logger.debug(f"Created complex polygon with {len(self._elements)} elements")
    
    def __str__(self) -> str:
        """Return a string representation of the polygon."""
        return f"ComplexPolygon with {len(self._elements)} elements"
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the polygon."""
        elements_str = ",\n  ".join(repr(e) for e in self._elements)
        return f"ComplexPolygon([\n  {elements_str}\n])"
    
    @property
    def elements(self) -> tuple[LinearGeometry, ...]:
        """
        Get the elements that define the polygon's boundary.
        
        Returns:
            tuple[LinearGeometry, ...]: A tuple of linear geometry elements in order
        """
        return self._elements
    
    @property
    def perimeter(self) -> float:
        """
        Calculate the perimeter of the polygon.
        
        Returns:
            float: The sum of all element lengths
        """
        return sum(element.length() for element in self._elements)
    
    @property
    def area(self) -> float:
        """
        Calculate the area of the polygon.
        
        For polygons with circular arcs, this splits each arc into small line segments
        and uses the Shoelace formula on the resulting simple polygon approximation.
        
        The approximation error is controlled by the number of segments used per arc.
        More segments = more accurate but slower calculation.
        
        Returns:
            float: The area of the polygon
        """
        # Get points from elements
        points = []
        for element in self._elements:
            if isinstance(element, LineSegment):
                points.append(element.start_point)
            elif isinstance(element, CircularArc):
                # For arcs, add multiple points to approximate the curve
                # Number of segments could be based on arc length or sweep angle
                num_segments = 32  # Fixed number for now, could be made configurable
                
                # Get arc parameters
                start_angle = element._start_angle
                sweep_angle = element._sweep_angle
                radius = element.radius
                center = element.radius_point
                
                # Add points along the arc
                for i in range(num_segments):
                    t = i / num_segments
                    angle = start_angle + sweep_angle * t
                    northing = center.northing + radius * math.cos(angle)
                    easting = center.easting + radius * math.sin(angle)
                    points.append(Point(northing, easting, center.elevation))
        
        # Add first point again to close the polygon
        points.append(points[0])
        
        # Calculate area using Shoelace formula
        area = 0.0
        for i in range(len(points) - 1):
            j = i + 1
            area += points[i].easting * points[j].northing
            area -= points[j].easting * points[i].northing
        return abs(area) / 2.0
    
    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope that contains this polygon.
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing the polygon
        """
        # Extract northing and easting coordinates from all points
        northings = []
        eastings = []
        
        for element in self._elements:
            if isinstance(element, LineSegment):
                # For line segments, just add endpoints
                northings.extend([element.start_point.northing, element.end_point.northing])
                eastings.extend([element.start_point.easting, element.end_point.easting])
            elif isinstance(element, CircularArc):
                # For arcs, need to check points along the arc for extrema
                # Add endpoints
                northings.extend([element.start_point.northing, element.end_point.northing])
                eastings.extend([element.start_point.easting, element.end_point.easting])
                
                # Add center point +/- radius in each direction
                # This covers the extreme points of the arc
                center = element.radius_point
                radius = element.radius
                northings.extend([center.northing - radius, center.northing + radius])
                eastings.extend([center.easting - radius, center.easting + radius])
        
        # Create envelope from min/max coordinates
        return TwoDimensionalEnvelope(
            min(northings),
            max(northings),
            min(eastings),
            max(eastings)
        )

class ComplexPolyline(LinearGeometry):
    """
    A complex polyline that can contain both line segments and circular arcs.
    """
    
    def __init__(self, elements: List[LinearGeometry]):
        """
        Initialize a complex polyline.
        
        Args:
            elements (list[LinearGeometry]): The ordered list of connected linear geometry elements.
                                         Must contain at least 1 element.
                                         Each element must be either a LineSegment or CircularArc.
                                         Elements must be connected (end point of one element
                                         must be the start point of the next element).
        
        Raises:
            ValueError: If no elements are provided
            ValueError: If elements are not connected
            ValueError: If an element is not a LineSegment or CircularArc
        """
        super().__init__()
        
        if not elements:
            raise ValueError("Complex polyline must have at least 1 element")
        
        # Validate element types
        for element in elements:
            if not isinstance(element, (LineSegment, CircularArc)):
                raise ValueError("Complex polyline elements must be LineSegment or CircularArc")
        
        # Validate connectivity
        for i in range(len(elements) - 1):
            if not elements[i].end_point.equals_within_tolerance(
                elements[i + 1].start_point, 1e-10
            ):
                raise ValueError(f"Elements at indices {i} and {i+1} are not connected")
        
        self.elements = elements
    
    @property
    def start_point(self) -> Point:
        """
        Get the start point of the complex polyline.
        
        Returns:
            Point: The start point
        """
        return self.elements[0].start_point
    
    @property
    def end_point(self) -> Point:
        """
        Get the end point of the complex polyline.
        
        Returns:
            Point: The end point
        """
        return self.elements[-1].end_point
    
    def length(self) -> float:
        """
        Get the total length of the complex polyline.
        
        Returns:
            float: The length
        """
        return sum(element.length() for element in self.elements)
    
    def elements_iter(self):
        """
        Get an iterator over the elements in this complex polyline.
        
        Yields:
            LinearGeometry: The next element in the polyline
        """
        yield from self.elements
    
    @property
    def azimuth(self) -> SurveyorsDirection:
        """
        Get the azimuth from the start point to the end point.
        
        Returns:
            SurveyorsDirection: The azimuth
        """
        return SurveyorsDirection.from_points(self.start_point, self.end_point)
    
    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope that contains this complex polyline.
        
        The envelope must contain not just the start and end points, but also any extreme points
        along the arc's curve. For example, if the arc curves upward, the envelope's max_northing
        must account for the highest point on the curve.
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing all points in the polyline
        """
        if not self.elements:
            return TwoDimensionalEnvelope(0, 0, 0, 0)
        
        # Start with the envelope of the first element
        result = self.elements[0].envelope_2d
        
        # Merge with envelopes of remaining elements
        for element in self.elements[1:]:
            element_env = element.envelope_2d
            result = TwoDimensionalEnvelope(
                min(result.min_northing, element_env.min_northing),
                max(result.max_northing, element_env.max_northing),
                min(result.min_easting, element_env.min_easting),
                max(result.max_easting, element_env.max_easting)
            )
        
        return result
    
    def __str__(self) -> str:
        """
        Get a string representation of this complex polyline.
        
        Returns:
            str: A string representation
        """
        return f"ComplexPolyline with {len(self.elements)} elements"
    
    def __repr__(self) -> str:
        """
        Get a detailed string representation of this complex polyline.
        
        Returns:
            str: A detailed string representation
        """
        elements_str = "\n  ".join(f"{i}: {element}" for i, element in enumerate(self.elements))
        return f"ComplexPolyline [\n  {elements_str}\n]"

class Vector2D:
    """
    A 2D vector in the horizontal plane (northing-easting).
    
    Represents a displacement in the horizontal plane with delta_northing
    and delta_easting components. Can be created from a direction and distance,
    or directly from components.
    """
    
    def __init__(
        self,
        delta_northing: float,
        delta_easting: float,
        grid: Optional['Grid'] = None
    ):
        """
        Initialize a 2D vector.
        
        Args:
            delta_northing: Change in northing coordinate
            delta_easting: Change in easting coordinate
            grid: Optional grid for coordinate system reference
        """
        self.delta_northing = float(delta_northing)
        self.delta_easting = float(delta_easting)
        self.grid = grid
    
    @classmethod
    def from_direction_distance(
        cls,
        direction: SurveyorsDirection,
        distance: float,
        grid: Optional['Grid'] = None
    ) -> 'Vector2D':
        """
        Create a 2D vector from a direction and distance.
        
        Args:
            direction: The azimuth direction
            distance: The horizontal distance
            grid: Optional grid reference
        
        Returns:
            Vector2D: A new 2D vector
        
        Example:
            >>> from plana_figura import SurveyorsDirection, Vector2D
            >>> import math
            >>> north = SurveyorsDirection(0.0)  # 0 radians = North
            >>> vec = Vector2D.from_direction_distance(north, 100.0)
            >>> vec.delta_northing
            100.0
        """
        # Use radians for trig functions
        angle_rad = direction.angle_radians
        delta_n = distance * math.cos(angle_rad)
        delta_e = distance * math.sin(angle_rad)
        return cls(delta_n, delta_e, grid)
    
    @property
    def magnitude(self) -> float:
        """
        Calculate the magnitude (length) of the vector.
        
        Returns:
            float: The Euclidean length of the vector
        """
        return math.sqrt(self.delta_northing**2 + self.delta_easting**2)
    
    @property
    def direction(self) -> SurveyorsDirection:
        """
        Calculate the direction (azimuth) of the vector.
        
        Returns:
            SurveyorsDirection: The azimuth of the vector
        """
        angle_rad = math.atan2(self.delta_easting, self.delta_northing)
        if angle_rad < 0:
            angle_rad += 2 * math.pi
        return SurveyorsDirection(angle_rad)
    
    def calculate_change_in_northing(self) -> float:
        """
        Calculate the change in northing (N) component.
        
        This is an alias for delta_northing for compatibility with old Vector class.
        
        Returns:
            float: The change in northing coordinate
        """
        return self.delta_northing
    
    def calculate_change_in_easting(self) -> float:
        """
        Calculate the change in easting (E) component.
        
        This is an alias for delta_easting for compatibility with old Vector class.
        
        Returns:
            float: The change in easting coordinate
        """
        return self.delta_easting
    
    @property
    def distance(self) -> float:
        """
        Get the distance (magnitude) of the vector.
        
        This is an alias for magnitude for compatibility with old Vector class.
        
        Returns:
            float: The magnitude of the vector
        """
        return self.magnitude
    
    def create_line_segment(self, start: Point) -> LineSegment:
        """
        Create a line segment from a start point using this vector.
        
        Args:
            start: The starting point of the line segment
            
        Returns:
            LineSegment: A new line segment
        
        Example:
            >>> from plana_figura import Point, Vector2D
            >>> start = Point(1000, 2000, 100)
            >>> vec = Vector2D(100.0, 50.0)
            >>> line = vec.create_line_segment(start)
            >>> line.end_point.northing
            1100.0
            >>> line.end_point.easting
            2050.0
        """
        # Create end point
        end = Point(
            northing=start.northing + self.delta_northing,
            easting=start.easting + self.delta_easting,
            elevation=start.elevation,  # Keep same elevation
            grid=start.grid
        )
        
        return LineSegment(start, end)
    
    def to_3d(
        self,
        delta_elevation: Optional[float] = None,
        vertical_angle: Optional['DecimalDegreesAngle'] = None,
        zenith_angle: Optional['DecimalDegreesAngle'] = None
    ) -> 'Vector3D':
        """
        Convert to a 3D vector by adding a vertical component.
        
        Provide exactly ONE of: delta_elevation, vertical_angle, or zenith_angle.
        
        Args:
            delta_elevation: Direct elevation change (+ = up, - = down)
            vertical_angle: Angle from horizontal plane (+ = up, - = down)
            zenith_angle: Angle from vertical plumb line (0° = straight up, 90° = horizontal, 180° = straight down)
            
        Returns:
            Vector3D: A new 3D vector
        
        Raises:
            ValueError: If more than one parameter is provided or none are provided
        
        Example:
            >>> vec2d = Vector2D(100.0, 0.0)
            >>> # Using elevation change
            >>> vec3d = vec2d.to_3d(delta_elevation=50.0)
            >>> vec3d.delta_elevation
            50.0
            
            >>> # Using vertical angle (45° up)
            >>> from plana_figura.angles import DecimalDegreesAngle
            >>> vec3d = vec2d.to_3d(vertical_angle=DecimalDegreesAngle(45.0))
            >>> abs(vec3d.delta_elevation - 100.0) < 0.01  # tan(45°) * 100
            True
        """
        # Check that exactly one parameter is provided
        params_provided = sum([
            delta_elevation is not None,
            vertical_angle is not None,
            zenith_angle is not None
        ])
        
        if params_provided == 0:
            raise ValueError(
                "Must provide one of: delta_elevation, vertical_angle, or zenith_angle"
            )
        if params_provided > 1:
            raise ValueError(
                "Provide only ONE of: delta_elevation, vertical_angle, or zenith_angle"
            )
        
        # Calculate delta_elevation based on which parameter was provided
        if delta_elevation is not None:
            dz = delta_elevation
        elif vertical_angle is not None:
            # Vertical angle: measured from horizontal plane
            # Positive = up, negative = down
            # delta_z = horizontal_distance * tan(vertical_angle)
            horizontal_distance = self.magnitude
            angle_rad = math.radians(vertical_angle.angle_degrees)
            dz = horizontal_distance * math.tan(angle_rad)
        else:  # zenith_angle is not None
            # Zenith angle: measured from vertical plumb line
            # 0° = straight up, 90° = horizontal, 180° = straight down
            # Convert to vertical angle: vertical_angle = 90° - zenith_angle
            # Then: delta_z = horizontal_distance * tan(vertical_angle)
            horizontal_distance = self.magnitude
            zenith_deg = zenith_angle.angle_degrees
            vertical_deg = 90.0 - zenith_deg
            angle_rad = math.radians(vertical_deg)
            dz = horizontal_distance * math.tan(angle_rad)
        
        return Vector3D(
            self.delta_northing,
            self.delta_easting,
            dz,
            self.grid
        )
    
    def __str__(self) -> str:
        """Return string representation."""
        return f"Vector2D(ΔN={self.delta_northing:.4f}, ΔE={self.delta_easting:.4f})"
    
    def __repr__(self) -> str:
        """Return detailed string representation."""
        return self.__str__()


class Vector3D:
    """
    A 3D vector in space (northing-easting-elevation).
    
    Represents a displacement in 3D space with delta_northing, delta_easting,
    and delta_elevation components.
    """
    
    def __init__(
        self,
        delta_northing: float,
        delta_easting: float,
        delta_elevation: float,
        grid: Optional['Grid'] = None
    ):
        """
        Initialize a 3D vector.
        
        Args:
            delta_northing: Change in northing coordinate
            delta_easting: Change in easting coordinate
            delta_elevation: Change in elevation coordinate
            grid: Optional grid for coordinate system reference
        """
        self.delta_northing = float(delta_northing)
        self.delta_easting = float(delta_easting)
        self.delta_elevation = float(delta_elevation)
        self.grid = grid
    
    @property
    def magnitude(self) -> float:
        """
        Calculate the magnitude (length) of the vector in 3D space.
        
        Returns:
            float: The Euclidean length of the vector
        """
        return math.sqrt(
            self.delta_northing**2 +
            self.delta_easting**2 +
            self.delta_elevation**2
        )
    
    @property
    def horizontal_magnitude(self) -> float:
        """
        Calculate the horizontal (2D) magnitude of the vector.
        
        Returns:
            float: The horizontal distance (ignoring elevation)
        """
        return math.sqrt(self.delta_northing**2 + self.delta_easting**2)
    
    @property
    def horizontal_direction(self) -> SurveyorsDirection:
        """
        Calculate the horizontal direction (azimuth) of the vector.
        
        Returns:
            SurveyorsDirection: The azimuth in the horizontal plane
        """
        angle_rad = math.atan2(self.delta_easting, self.delta_northing)
        if angle_rad < 0:
            angle_rad += 2 * math.pi
        return SurveyorsDirection(angle_rad)
    
    def to_2d(self) -> Vector2D:
        """
        Project to a 2D vector (discard elevation component).
        
        Returns:
            Vector2D: The horizontal projection of this vector
        """
        return Vector2D(self.delta_northing, self.delta_easting, self.grid)
    
    def __str__(self) -> str:
        """Return string representation."""
        return (
            f"Vector3D(ΔN={self.delta_northing:.4f}, "
            f"ΔE={self.delta_easting:.4f}, ΔZ={self.delta_elevation:.4f})"
        )
    
    def __repr__(self) -> str:
        """Return detailed string representation."""
        return self.__str__()


class CircularArc(LinearGeometry):
    """A circular arc defined by its radius point (center), start point, and end point.
    
    The arc is defined by its radius point (center) and two points that lie on the arc.
    The arc is drawn from start_point to end_point in a clockwise direction.
    Angles are measured clockwise from north (0°).
    Points are specified in northing/easting order.
    """
    
    def __init__(self, radius_point: Point, start_point: Point, end_point: Point):
        """Initialize a circular arc.
        
        Args:
            radius_point: The center point of the arc (northing, easting)
            start_point: The start point of the arc (northing, easting)
            end_point: The end point of the arc (northing, easting)
            
        Raises:
            ValidationError: If start and end points are not equidistant from radius point
            ValidationError: If any points are coincident
        """
        super().__init__()
        
        logger.debug("Initializing CircularArc:")
        logger.debug(f"  radius_point: ({radius_point.northing}, {radius_point.easting})")
        logger.debug(f"  start_point: ({start_point.northing}, {start_point.easting})")
        logger.debug(f"  end_point: ({end_point.northing}, {end_point.easting})")
        
        # Validate points are not coincident
        if start_point.is_coincident(end_point):
            raise ValidationError("Start and end points cannot be coincident")
        if start_point.is_coincident(radius_point) or end_point.is_coincident(radius_point):
            raise ValidationError("Start and end points cannot be coincident with radius point")
        
        # Store points
        self._radius_point = radius_point
        self._start = start_point
        self._end = end_point
        
        # Calculate and validate radii
        start_radius = self._calculate_radius(start_point)
        end_radius = self._calculate_radius(end_point)
        
        if not math.isclose(start_radius, end_radius, rel_tol=1e-10):
            raise ValidationError(
                f"Start and end points must be equidistant from radius point. "
                f"Got start radius={start_radius:.6f}, end radius={end_radius:.6f}"
            )
        
        self._radius = start_radius
        self._start_angle = self._calculate_angle_from_north(start_point)
        self._end_angle = self._calculate_angle_from_north(end_point)
        self._sweep_angle = self._calculate_sweep_angle()
        
        logger.debug("Created CircularArc:")
        logger.debug(f"  radius: {self._radius:.6f}")
        logger.debug(f"  start angle: {math.degrees(self._start_angle):.2f}°")
        logger.debug(f"  end angle: {math.degrees(self._end_angle):.2f}°")
        logger.debug(f"  sweep angle: {math.degrees(self._sweep_angle):.2f}°")
    
    def _calculate_radius(self, point: Point) -> float:
        """Calculate the radius from the center to a point."""
        return math.sqrt(
            (point.northing - self._radius_point.northing) ** 2 +
            (point.easting - self._radius_point.easting) ** 2
        )
    
    def _calculate_vector_components(self, point: Point) -> tuple[float, float]:
        """Calculate the vector components from center to point."""
        dn = point.northing - self._radius_point.northing
        de = point.easting - self._radius_point.easting
        return dn, de
    
    def _calculate_angle_from_north(self, point: Point) -> float:
        """Calculate the angle clockwise from north to the given point."""
        dn, de = self._calculate_vector_components(point)
        angle = math.atan2(de, dn)  # Angle from north
        return self._normalize_angle(angle)
    
    def _normalize_angle(self, angle: float) -> float:
        """Normalize angle to be between 0 and 2π."""
        return angle % (2 * math.pi)
    
    def _calculate_sweep_angle(self) -> float:
        """Calculate the sweep angle from start to end in clockwise direction."""
        sweep = self._end_angle - self._start_angle
        if sweep <= 0:
            sweep += 2 * math.pi
        return sweep
    
    @property
    def radius_point(self) -> Point:
        """Get the center point of the arc."""
        return self._radius_point
    
    @property
    def radius(self) -> float:
        """Get the radius of the arc."""
        return self._radius
    
    @property
    def start_point(self) -> Point:
        """Get the starting point of the arc."""
        return self._start
    
    @property
    def end_point(self) -> Point:
        """Get the ending point of the arc."""
        return self._end
    
    @property
    def start_angle(self) -> float:
        """Get the start angle in radians clockwise from north."""
        return self._start_angle
    
    @property
    def end_angle(self) -> float:
        """Get the end angle in radians clockwise from north."""
        return self._end_angle
    
    @property
    def sweep_angle(self) -> float:
        """Get the sweep angle in radians."""
        return self._sweep_angle
    
    def length(self) -> float:
        """Calculate the arc length."""
        return self._radius * self._sweep_angle
    
    def calculate_change_in_northing(self) -> float:
        """
        Calculate the change in northing from start to end point.
        
        Returns:
            float: The change in northing (end - start)
        """
        return self._end.northing - self._start.northing
    
    def calculate_change_in_easting(self) -> float:
        """
        Calculate the change in easting from start to end point.
        
        Returns:
            float: The change in easting (end - start)
        """
        return self._end.easting - self._start.easting
    
    @property
    def azimuth(self) -> SurveyorsDirection:
        """
        Calculate the azimuth at the start point.
        
        Returns:
            SurveyorsDirection: The azimuth, measured clockwise from north
        """
        change_in_northing = self.calculate_change_in_northing()
        change_in_easting = self.calculate_change_in_easting()
        
        # For points that are too close, return north
        if abs(change_in_northing) < 1e-10 and abs(change_in_easting) < 1e-10:
            return SurveyorsDirection(0.0)
            
        # Calculate the angle in radians
        angle_rad = math.atan2(change_in_easting, change_in_northing)
        
        # Convert to azimuth (clockwise from north)
        if angle_rad < 0:
            angle_rad += 2 * math.pi
            
        return SurveyorsDirection(angle_rad)
    
    def __str__(self) -> str:
        """Return a string representation of the arc."""
        return (
            f"CircularArc("
            f"center=({self._radius_point.northing}, {self._radius_point.easting}), "
            f"radius={self._radius:.3f}, "
            f"start=({self._start.northing}, {self._start.easting}), "
            f"end=({self._end.northing}, {self._end.easting}), "
                f"sweep={math.degrees(self._sweep_angle):.1f}°)")
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the arc."""
        return (f"CircularArc(radius_point=Point(N={self._radius_point.northing}, "
                f"E={self._radius_point.easting}, EL={self._radius_point.elevation}), "
                f"start_point=Point(N={self._start.northing}, E={self._start.easting}, "
                f"EL={self._start.elevation}), "
                f"end_point=Point(N={self._end.northing}, E={self._end.easting}, "
                f"EL={self._end.elevation}))")

class QuadTreeNode:
    """A node in the quad tree index."""
    
    def __init__(
        self,
        envelope: TwoDimensionalEnvelope,
        max_objects: int = 10,
        max_depth: int = 6,
        depth: int = 0
    ):
        """
        Initialize a quad tree node.
        
        Args:
            envelope (TwoDimensionalEnvelope): The 2D envelope that this node covers
            max_objects (int, optional): Maximum number of objects before splitting. Defaults to 10.
            max_depth (int, optional): Maximum depth of the tree. Defaults to 6.
            depth (int, optional): Current depth of the node. Defaults to 0.
        """
        self.envelope = envelope
        self.max_objects = max_objects
        self.max_depth = max_depth
        self.depth = depth
        self.objects: list[Geometry] = []
        self.children: list[Optional[QuadTreeNode]] = [None] * 4  # NW, NE, SW, SE
        self._should_subdivide = True  # Flag to control subdivision
        
    def insert(self, geometry: Geometry) -> bool:
        """Insert a geometry object into this node or its children.
        
        Args:
            geometry (Geometry): The geometry object to insert
            
        Returns:
            bool: True if the object was inserted, False if it was outside the root's envelope
        """
        # First check if the geometry's envelope intersects this node
        if geometry.envelope_2d is None or not self.envelope.intersects(geometry.envelope_2d):
            logger.debug(f"Geometry outside node envelope, skipping insert")
            return False
            
        # If we have children and the geometry fits entirely in one quadrant,
        # insert it into that child
        if self.children[0] is not None:  # Check if we have children
            quadrant = self._get_geometry_quadrant(geometry)
            if quadrant is not None:
                child = self.children[quadrant]
                assert child is not None  # For type checker
                logger.debug(f"Inserting geometry into child quadrant {quadrant}")
                return child.insert(geometry)
                
        # If we don't have children or the geometry spans multiple quadrants,
        # store it at this level and try to subdivide
        logger.debug(f"Storing geometry at current level (depth={self.depth})")
        self.objects.append(geometry)
        self._try_subdivide()
        return True
        
    def _try_subdivide(self) -> None:
        """Try to subdivide this node if conditions are met."""
        # Check if we should subdivide
        if (self.depth >= self.max_depth or len(self.objects) <= self.max_objects):
            logger.debug(
                f"Skipping subdivision: depth={self.depth}, "
                f"objects={len(self.objects)}, max_depth={self.max_depth}, "
                f"max_objects={self.max_objects}"
            )
            return
            
        logger.debug(
            f"Starting subdivision at depth {self.depth} "
            f"with {len(self.objects)} objects"
        )
        
        # Create child nodes
        mid_n = (self.envelope.min_northing + self.envelope.max_northing) / 2
        mid_e = (self.envelope.min_easting + self.envelope.max_easting) / 2
        logger.debug(f"Subdivision midpoints: N={mid_n}, E={mid_e}")
        
        # Create child nodes in order: NW, NE, SW, SE
        self.children = [None] * 4
        for i in range(4):
            bounds = self._get_quadrant_bounds(i, mid_n, mid_e)
            self.children[i] = QuadTreeNode(
                bounds, self.max_objects, self.max_depth, self.depth + 1
            )
            logger.debug(
                f"Created child {i} with bounds: "
                f"N({bounds.min_northing}, {bounds.max_northing}), "
                f"E({bounds.min_easting}, {bounds.max_easting})"
            )
            
        # Distribute objects to children
        remaining_objects = []
        for obj in self.objects:
            logger.debug(
                f"Attempting to distribute object {obj.__class__.__name__} "
                f"to a child node"
            )
            quadrant = self._get_geometry_quadrant(obj)
            if quadrant is not None:
                child = self.children[quadrant]
                assert child is not None  # For type checker
                logger.debug(f"Distributing object to child quadrant {quadrant}")
                success = child.insert(obj)
                logger.debug(f"Insert into child {quadrant} {'succeeded' if success else 'failed'}")
            else:
                logger.debug(f"Keeping object at current level (spans quadrants)")
                remaining_objects.append(obj)
                
        # Update objects list to only contain those that span multiple quadrants
        logger.debug(
            f"Subdivision complete. {len(remaining_objects)} objects "
            f"remain at current level"
        )
        self.objects = remaining_objects
        
    def query(self, search_env: TwoDimensionalEnvelope) -> list[Geometry]:
        """Find all geometry objects that intersect with the search envelope.
        
        Args:
            search_env (TwoDimensionalEnvelope): The envelope to search within
            
        Returns:
            list[Geometry]: List of geometry objects that intersect the search envelope
        """
        results: List[Geometry] = []
        
        # First check if this node's envelope intersects the search envelope
        if not self.envelope.intersects(search_env):
            return results
            
        # If the search envelope completely contains this node's envelope,
        # we can add all objects without further checks
        if search_env.contains(self.envelope):
            results.extend(self.objects)
            if self.children[0] is not None:
                for child in self.children:
                    if child:
                        results.extend(child.query(search_env))
            return results
            
        # Otherwise, check each object in this node
        for obj in self.objects:
            obj_env = obj.envelope_2d
            if obj_env and obj_env.intersects(search_env):
                results.append(obj)
                
        # Recursively search children
        if self.children[0] is not None:
            for child in self.children:
                if child:
                    results.extend(child.query(search_env))
                    
        return results

    def _get_geometry_quadrant(self, geometry: Geometry) -> Optional[int]:
        """Determine which quadrant a geometry belongs in.
        
        Args:
            geometry (Geometry): The geometry to check
            
        Returns:
            Optional[int]: The quadrant index (0=NW, 1=NE, 2=SW, 3=SE)
                          or None if spans multiple quadrants
        """
        logger.debug(f"Determining quadrant for {geometry.__class__.__name__}")
        
        if isinstance(geometry, Point):
            mid_n = (self.envelope.min_northing + self.envelope.max_northing) / 2
            mid_e = (self.envelope.min_easting + self.envelope.max_easting) / 2
            quadrant = self._get_point_quadrant(geometry, mid_n, mid_e)
            logger.debug(f"Point quadrant determination: {quadrant}")
            return quadrant
            
        # For non-point geometries, check if they fit entirely within a quadrant
        if geometry.envelope_2d is None:
            logger.debug("Geometry has no envelope, cannot determine quadrant")
            return None
            
        mid_n = (self.envelope.min_northing + self.envelope.max_northing) / 2
        mid_e = (self.envelope.min_easting + self.envelope.max_easting) / 2
        
        # Check if geometry spans multiple quadrants
        spans_n = (
            geometry.envelope_2d.min_northing < mid_n and
            geometry.envelope_2d.max_northing > mid_n
        )
        spans_e = (
            geometry.envelope_2d.min_easting < mid_e and
            geometry.envelope_2d.max_easting > mid_e
        )
        
        if spans_n or spans_e:
            logger.debug(f"Geometry spans quadrants: spans_n={spans_n}, spans_e={spans_e}")
            return None
            
        # Determine quadrant based on envelope position
        in_north = geometry.envelope_2d.min_northing >= mid_n
        in_east = geometry.envelope_2d.min_easting >= mid_e
        
        quadrant = None
        if in_north:
            quadrant = 1 if in_east else 0  # NE or NW
        else:
            quadrant = 3 if in_east else 2  # SE or SW
            
        logger.debug(
            f"Geometry quadrant determination: in_north={in_north}, "
            f"in_east={in_east}, quadrant={quadrant}"
        )
        return quadrant
        
    def _get_quadrant_bounds(
        self, quadrant: int, mid_n: float, mid_e: float
    ) -> TwoDimensionalEnvelope:
        """Get the envelope bounds for a specific quadrant.
        
        The quadrants are arranged as follows:
            NW (0) | NE (1)
            ---------------
            SW (2) | SE (3)
            
        Note: northing is like y-coordinate (up/down)
              easting is like x-coordinate (left/right)
        
        Args:
            quadrant (int): The quadrant index (0=NW, 1=NE, 2=SW, 3=SE)
            mid_n (float): The northing midpoint
            mid_e (float): The easting midpoint
            
        Returns:
            TwoDimensionalEnvelope: The envelope for the specified quadrant
        """
        logger.debug(
            f"Getting bounds for quadrant {quadrant} "
            f"with mid_n={mid_n}, mid_e={mid_e}"
        )
        logger.debug(
            f"Parent envelope: "
            f"N({self.envelope.min_northing}, {self.envelope.max_northing}), "
            f"E({self.envelope.min_easting}, {self.envelope.max_easting})"
        )
        
        # Calculate bounds based on quadrant
        min_n = self.envelope.min_northing
        max_n = self.envelope.max_northing
        min_e = self.envelope.min_easting
        max_e = self.envelope.max_easting
        
        # For north quadrants (0,1), take upper half of northing range
        # For south quadrants (2,3), take lower half of northing range
        if quadrant in (0, 1):  # North quadrants
            min_n = mid_n
        else:  # South quadrants
            max_n = mid_n
            
        # For east quadrants (1,3), take right half of easting range
        # For west quadrants (0,2), take left half of easting range
        if quadrant in (1, 3):  # East quadrants
            min_e = mid_e
        else:  # West quadrants
            max_e = mid_e
            
        bounds = TwoDimensionalEnvelope(min_n, max_n, min_e, max_e)
        logger.debug(
            f"Quadrant {quadrant} bounds: "
            f"N({bounds.min_northing}, {bounds.max_northing}), "
            f"E({bounds.min_easting}, {bounds.max_easting})"
        )
        return bounds
        
    def _get_point_quadrant(self, point: Point, mid_n: float, mid_e: float) -> Optional[int]:
        """Get the quadrant index for a point.
        
        The quadrants are arranged as follows:
            NW (0) | NE (1)
            ---------------
            SW (2) | SE (3)
            
        For a point (n,e) to be in a quadrant:
        - NW (0): n > mid_n and e < mid_e
        - NE (1): n > mid_n and e > mid_e
        - SW (2): n < mid_n and e < mid_e
        - SE (3): n < mid_n and e > mid_e
        
        Note: northing is like y-coordinate (up/down)
              easting is like x-coordinate (left/right)
        
        Args:
            point (Point): The point to check
            mid_n (float): The northing midpoint of this node's envelope
            mid_e (float): The easting midpoint of this node's envelope
            
        Returns:
            Optional[int]: The quadrant index (0=NW, 1=NE, 2=SW, 3=SE) or None if on boundary
        """
        logger.debug(
            f"Checking quadrant for point ({point.northing}, {point.easting}) "
            f"with mid_n={mid_n}, mid_e={mid_e}"
        )
        
        # Check if point is on any boundary
        if abs(point.northing - mid_n) < 1e-10 or abs(point.easting - mid_e) < 1e-10:
            logger.debug("Point is on boundary, cannot determine unique quadrant")
            return None
            
        # Determine quadrant based on midpoint comparison
        # Note: northing is like y-coordinate, easting is like x-coordinate
        in_north = point.northing > mid_n
        in_east = point.easting > mid_e
        
        # Map the combination of north/east flags to quadrants:
        # in_north | in_east | quadrant
        #   True   |  False  |    0 (NW)
        #   True   |  True   |    1 (NE)
        #   False  |  False  |    2 (SW)
        #   False  |  True   |    3 (SE)
        quadrant = None
        if in_north:
            quadrant = 0 if not in_east else 1  # NW or NE
        else:
            quadrant = 2 if not in_east else 3  # SW or SE
            
        logger.debug(
            f"Point quadrant determination: in_north={in_north}, "
            f"in_east={in_east}, quadrant={quadrant}"
        )
        return quadrant
        
class QuadTreeIndex:
    """A quad tree spatial index for geometry objects."""
    
    def __init__(self, envelope: TwoDimensionalEnvelope, max_objects: int = 10, max_depth: int = 6):
        """
        Initialize a quad tree index.
        
        Args:
            envelope (TwoDimensionalEnvelope): The 2D envelope that covers all objects
            max_objects (int, optional): Maximum number of objects in a node
                                      before splitting. Defaults to 10.
            max_depth (int, optional): Maximum depth of the tree. Defaults to 6.
        """
        self.root = QuadTreeNode(envelope, max_objects, max_depth)
        self._object_count = 0
        
    def insert(self, geometry: Geometry) -> bool:
        """
        Insert a geometry object into the quad tree.
        
        Args:
            geometry (Geometry): The geometry object to insert
            
        Returns:
            bool: True if the object was inserted, False if it was outside the root's envelope
        """
        if self.root.insert(geometry):
            self._object_count += 1
            return True
        return False
        
    def query(self, search_envelope: TwoDimensionalEnvelope) -> list[Geometry]:
        """
        Find all geometry objects that intersect with the search envelope.
        
        Args:
            search_envelope (TwoDimensionalEnvelope): The envelope to search within
            
        Returns:
            list[Geometry]: List of geometry objects that intersect the search envelope
        """
        return self.root.query(search_envelope)
        
    def clear(self) -> None:
        """Remove all objects from the index."""
        self.root = QuadTreeNode(self.root.envelope, self.root.max_objects, self.root.max_depth)
        self._object_count = 0
        
    @property
    def object_count(self) -> int:
        """Get the total number of objects in the index."""
        return self._object_count

class GeometryManipulator:
    """
    A class for manipulating geometric objects such as LineSegments.
    Provides methods for scaling and other transformations.
    """
    
    @staticmethod
    def translate_point(point: Point, vector: Vector2D) -> Point:
        """
        Translate a point by a vector.
        
        Args:
            point (Point): The point to translate
            vector (Vector): The vector to translate by
            
        Returns:
            Point: A new point translated by the vector
        """
        # Calculate new coordinates
        new_northing = point.northing + vector.calculate_change_in_northing()
        new_easting = point.easting + vector.calculate_change_in_easting()
        
        # Return new point at same elevation
        return Point(new_northing, new_easting, point.elevation)
    
    @classmethod
    def translate_line_segment(cls, line_segment: LineSegment, vector: Vector2D) -> LineSegment:
        """
        Translate a line segment by a vector.
        
        Args:
            line_segment (LineSegment): The line segment to translate
            vector (Vector): The vector to translate by
            
        Returns:
            LineSegment: A new line segment translated by the vector
        """
        # Translate start and end points
        new_start = cls.translate_point(line_segment.start_point, vector)
        new_end = cls.translate_point(line_segment.end_point, vector)
        
        # Return new line segment
        return LineSegment(new_start, new_end)
    
    @classmethod
    def translate_polyline(cls, polyline: SimplePolyline, vector: Vector2D) -> SimplePolyline:
        """
        Translate a polyline by a vector.
        
        Args:
            polyline (SimplePolyline): The polyline to translate
            vector (Vector): The vector to translate by
            
        Returns:
            SimplePolyline: A new polyline translated by the vector
        """
        # Translate all points
        new_points = [cls.translate_point(point, vector) for point in polyline.points]
        
        # Return new polyline
        return SimplePolyline(new_points)
    
    @classmethod
    def translate_polygon(cls, polygon: SimplePolygon, vector: Vector2D) -> SimplePolygon:
        """
        Translate a polygon by a vector.
        
        Args:
            polygon (SimplePolygon): The polygon to translate
            vector (Vector): The vector to translate by
            
        Returns:
            SimplePolygon: A new polygon translated by the vector
        """
        # Translate all points
        new_points = [cls.translate_point(point, vector) for point in polygon.points]
        
        # Return new polygon
        return SimplePolygon(new_points)
    
    @staticmethod
    def scale_point(point: Point, scale_factor: float, origin: Point) -> Point:
        """
        Scale a point relative to an origin point.
        
        Args:
            point (Point): The point to scale
            scale_factor (float): The scale factor (> 0)
            origin (Point): The point to scale relative to
            
        Returns:
            Point: A new point scaled relative to the origin
            
        Raises:
            ValueError: If scale_factor <= 0
        """
        # Validate scale factor
        if scale_factor <= 0:
            raise ValueError("Scale factor must be greater than 0")
        
        # Calculate scaled coordinates relative to origin
        new_northing = origin.northing + (point.northing - origin.northing) * scale_factor
        new_easting = origin.easting + (point.easting - origin.easting) * scale_factor
        
        # Return new point at same elevation
        return Point(new_northing, new_easting, point.elevation)
    
    @classmethod
    def scale_line_segment(
        cls, line_segment: LineSegment, scale_factor: float, origin: Point
    ) -> LineSegment:
        """
        Scale a line segment relative to an origin point.
        
        Args:
            line_segment (LineSegment): The line segment to scale
            scale_factor (float): The scale factor (> 0)
            origin (Point): The point to scale relative to
            
        Returns:
            LineSegment: A new line segment scaled relative to the origin
            
        Raises:
            ValueError: If scale_factor <= 0
        """
        # Scale start and end points
        new_start = cls.scale_point(line_segment.start_point, scale_factor, origin)
        new_end = cls.scale_point(line_segment.end_point, scale_factor, origin)
        
        # Return new line segment
        return LineSegment(new_start, new_end)
    
    @classmethod
    def scale_polyline(
        cls, polyline: SimplePolyline, scale_factor: float, origin: Point
    ) -> SimplePolyline:
        """
        Scale a polyline relative to an origin point.
        
        Args:
            polyline (SimplePolyline): The polyline to scale
            scale_factor (float): The scale factor (> 0)
            origin (Point): The point to scale relative to
            
        Returns:
            SimplePolyline: A new polyline scaled relative to the origin
            
        Raises:
            ValueError: If scale_factor <= 0
        """
        # Scale all points
        new_points = [cls.scale_point(point, scale_factor, origin) for point in polyline.points]
        
        # Return new polyline
        return SimplePolyline(new_points)
    
    @classmethod
    def scale_polygon(cls, polygon: SimplePolygon, scale_factor: float, origin: Point) -> SimplePolygon:
        """
        Scale a polygon relative to an origin point.
        
        Args:
            polygon (SimplePolygon): The polygon to scale
            scale_factor (float): The scale factor (> 0)
            origin (Point): The point to scale relative to
            
        Returns:
            SimplePolygon: A new polygon scaled relative to the origin
            
        Raises:
            ValueError: If scale_factor <= 0
        """
        # Scale all points
        new_points = [cls.scale_point(point, scale_factor, origin) for point in polygon.points]
        
        # Return new polygon
        return SimplePolygon(new_points)
    
    @staticmethod
    def rotate_point(point: Point, angle: SurveyorsDirection, origin: Point) -> Point:
        """
        Rotate a point around an origin point by a given angle.
        
        Args:
            point (Point): The point to rotate
            angle (SurveyorsDirection): The angle to rotate by (clockwise for positive angles)
            origin (Point): The point to rotate around
            
        Returns:
            Point: A new point rotated around the origin
        """
        # Convert angle to radians
        angle_rad = angle.angle_radians
        
        # Calculate relative coordinates
        dx = point.easting - origin.easting
        dy = point.northing - origin.northing
        
        # Apply rotation matrix for clockwise rotation in northing-easting system
        # 1. Rotate clockwise by angle
        # 2. Translate back by origin
        cos_angle = math.cos(angle_rad)
        sin_angle = math.sin(angle_rad)
        new_dx = dx * cos_angle - dy * sin_angle
        new_dy = dx * sin_angle + dy * cos_angle
        
        # Calculate new absolute coordinates
        new_easting = origin.easting + new_dx
        new_northing = origin.northing + new_dy
        
        # Return new point at same elevation
        return Point(new_northing, new_easting, point.elevation)
    
    @classmethod
    def rotate_line_segment(cls, line_segment: LineSegment, angle: SurveyorsDirection, origin: Point) -> LineSegment:
        """
        Rotate a line segment around an origin point by a given angle.
        
        Args:
            line_segment (LineSegment): The line segment to rotate
            angle (SurveyorsDirection): The angle to rotate by
            origin (Point): The point to rotate around
            
        Returns:
            LineSegment: A new line segment rotated around the origin
        """
        # Rotate start and end points
        new_start = cls.rotate_point(line_segment.start_point, angle, origin)
        new_end = cls.rotate_point(line_segment.end_point, angle, origin)
        
        # Return new line segment
        return LineSegment(new_start, new_end)
    
    @classmethod
    def rotate_polyline(cls, polyline: SimplePolyline, angle: SurveyorsDirection, origin: Point) -> SimplePolyline:
        """
        Rotate a polyline around an origin point by a given angle.
        
        Args:
            polyline (SimplePolyline): The polyline to rotate
            angle (SurveyorsDirection): The angle to rotate by
            origin (Point): The point to rotate around
            
        Returns:
            SimplePolyline: A new polyline rotated around the origin
        """
        # Rotate all points
        new_points = [cls.rotate_point(point, angle, origin) for point in polyline.points]
        
        # Return new polyline
        return SimplePolyline(new_points)
    
    @classmethod
    def rotate_polygon(cls, polygon: SimplePolygon, angle: SurveyorsDirection, origin: Point) -> SimplePolygon:
        """
        Rotate a polygon around an origin point by a given angle.
        
        Args:
            polygon (SimplePolygon): The polygon to rotate
            angle (SurveyorsDirection): The angle to rotate by
            origin (Point): The point to rotate around
            
        Returns:
            SimplePolygon: A new polygon rotated around the origin
        """
        # Rotate all points
        new_points = [cls.rotate_point(point, angle, origin) for point in polygon.points]
        
        # Return new polygon
        return SimplePolygon(new_points)
    
    @staticmethod
    def translate_arc(arc: CircularArc, vector: Vector2D) -> CircularArc:
        """
        Translate a circular arc by a vector.
        
        Args:
            arc (CircularArc): The arc to translate
            vector (Vector): The vector to translate by
            
        Returns:
            CircularArc: A new arc translated by the vector
        """
        # Translate all points
        new_radius_point = GeometryManipulator.translate_point(arc.radius_point, vector)
        new_start = GeometryManipulator.translate_point(arc.start_point, vector)
        new_end = GeometryManipulator.translate_point(arc.end_point, vector)
        
        return CircularArc(new_radius_point, new_start, new_end)
    
    @staticmethod
    def rotate_arc(arc: CircularArc, angle: SurveyorsDirection, origin: Point) -> CircularArc:
        """
        Rotate a circular arc around an origin point by a given angle.
        
        Args:
            arc (CircularArc): The arc to rotate
            angle (SurveyorsDirection): The angle to rotate by
            origin (Point): The point to rotate around
            
        Returns:
            CircularArc: A new arc rotated around the origin
        """
        # Rotate all points
        new_radius_point = GeometryManipulator.rotate_point(arc.radius_point, angle, origin)
        new_start = GeometryManipulator.rotate_point(arc.start_point, angle, origin)
        new_end = GeometryManipulator.rotate_point(arc.end_point, angle, origin)
        
        return CircularArc(new_radius_point, new_start, new_end)

    @staticmethod
    def translate(geometry: Geometry, vector: Vector2D) -> Geometry:
        """
        Translate a geometry object by a vector.
        
        Args:
            geometry (Geometry): The geometry to translate
            vector (Vector): The translation vector
        
        Returns:
            Geometry: The translated geometry
        """
        if isinstance(geometry, Point):
            return GeometryManipulator.translate_point(geometry, vector)
        elif isinstance(geometry, LineSegment):
            return GeometryManipulator.translate_line_segment(geometry, vector)
        elif isinstance(geometry, CircularArc):
            return GeometryManipulator.translate_arc(geometry, vector)
        elif isinstance(geometry, ComplexPolyline):
            return GeometryManipulator._translate_complex_polyline(geometry, vector)
        else:
            raise ValueError(f"Unsupported geometry type: {type(geometry)}")

    @staticmethod
    def _translate_complex_polyline(polyline: ComplexPolyline, vector: Vector2D) -> ComplexPolyline:
        """Translate a complex polyline by a vector."""
        new_elements: List[LinearGeometry] = []
        for element in polyline.elements_iter():
            if isinstance(element, LineSegment):
                new_elements.append(GeometryManipulator.translate_line_segment(element, vector))
            else:  # CircularArc
                new_elements.append(GeometryManipulator.translate_arc(element, vector))
        return GeometryFactory.create_complex_polyline(new_elements)

    # ==================== Elevation Operations ====================
    
    @staticmethod
    def shift_elevation_point(point: Point, delta_elevation: float) -> Point:
        """
        Shift a point's elevation by a delta value.
        
        Args:
            point: The point to shift
            delta_elevation: The amount to add to the elevation (can be negative)
            
        Returns:
            A new point with shifted elevation
            
        Example:
            >>> p = Point(100, 200, 50)
            >>> shifted = GeometryManipulator.shift_elevation_point(p, 10)
            >>> shifted.elevation  # 60
        """
        return Point(point.northing, point.easting, point.elevation + delta_elevation)
    
    @staticmethod
    def set_elevation_point(point: Point, new_elevation: float) -> Point:
        """
        Set a point's elevation to an absolute value.
        
        Args:
            point: The point to modify
            new_elevation: The new elevation value
            
        Returns:
            A new point with the specified elevation
            
        Example:
            >>> p = Point(100, 200, 50)
            >>> adjusted = GeometryManipulator.set_elevation_point(p, 100)
            >>> adjusted.elevation  # 100
        """
        return Point(point.northing, point.easting, new_elevation)
    
    @classmethod
    def shift_elevation_line_segment(cls, segment: LineSegment, delta: float) -> LineSegment:
        """
        Shift both endpoints of a line segment by the same elevation delta.
        
        Args:
            segment: The line segment to shift
            delta: The amount to add to the elevation
            
        Returns:
            A new line segment with shifted elevation
            
        Example:
            >>> seg = LineSegment(Point(0, 0, 10), Point(10, 10, 20))
            >>> shifted = GeometryManipulator.shift_elevation_line_segment(seg, 5)
            >>> shifted.start_point.elevation  # 15
            >>> shifted.end_point.elevation  # 25
        """
        new_start = cls.shift_elevation_point(segment.start_point, delta)
        new_end = cls.shift_elevation_point(segment.end_point, delta)
        return LineSegment(new_start, new_end)
    
    @classmethod
    def shift_elevation_polyline(cls, polyline: SimplePolyline, delta: float) -> SimplePolyline:
        """
        Shift all points in a polyline by the same elevation delta.
        
        Args:
            polyline: The polyline to shift
            delta: The amount to add to the elevation
            
        Returns:
            A new polyline with shifted elevation
        """
        new_points = [cls.shift_elevation_point(p, delta) for p in polyline.points]
        return SimplePolyline(new_points)
    
    @classmethod
    def shift_elevation_polygon(cls, polygon: SimplePolygon, delta: float) -> SimplePolygon:
        """
        Shift all points in a polygon by the same elevation delta.
        
        Args:
            polygon: The polygon to shift
            delta: The amount to add to the elevation
            
        Returns:
            A new polygon with shifted elevation
        """
        new_points = [cls.shift_elevation_point(p, delta) for p in polygon.points]
        return SimplePolygon(new_points)
    
    @classmethod
    def shift_elevation_arc(cls, arc: CircularArc, delta: float) -> CircularArc:
        """
        Shift all points in a circular arc by the same elevation delta.
        
        Args:
            arc: The arc to shift
            delta: The amount to add to the elevation
            
        Returns:
            A new arc with shifted elevation
        """
        new_center = cls.shift_elevation_point(arc.radius_point, delta)
        new_start = cls.shift_elevation_point(arc.start_point, delta)
        new_end = cls.shift_elevation_point(arc.end_point, delta)
        return CircularArc(new_center, new_start, new_end)

    # ==================== Mirror/Reflect Operations ====================
    
    @staticmethod
    def mirror_point_across_vertical_line(point: Point, easting: float) -> Point:
        """
        Mirror a point across a vertical line at the given easting.
        
        Args:
            point: The point to mirror
            easting: The easting coordinate of the vertical mirror line
            
        Returns:
            A new point mirrored across the vertical line
            
        Example:
            >>> p = Point(100, 50, 10)
            >>> mirrored = GeometryManipulator.mirror_point_across_vertical_line(p, 100)
            >>> mirrored.easting  # 150 (2*100 - 50)
        """
        new_easting = 2 * easting - point.easting
        return Point(point.northing, new_easting, point.elevation)
    
    @staticmethod
    def mirror_point_across_horizontal_line(point: Point, northing: float) -> Point:
        """
        Mirror a point across a horizontal line at the given northing.
        
        Args:
            point: The point to mirror
            northing: The northing coordinate of the horizontal mirror line
            
        Returns:
            A new point mirrored across the horizontal line
            
        Example:
            >>> p = Point(50, 100, 10)
            >>> mirrored = GeometryManipulator.mirror_point_across_horizontal_line(p, 100)
            >>> mirrored.northing  # 150 (2*100 - 50)
        """
        new_northing = 2 * northing - point.northing
        return Point(new_northing, point.easting, point.elevation)
    
    @staticmethod
    def mirror_point_across_line(point: Point, line: LineSegment) -> Point:
        """
        Mirror a point across an arbitrary line.
        
        Algorithm:
        1. Find perpendicular from point to line
        2. Calculate intersection point (foot of perpendicular)
        3. Reflect point across intersection
        
        Args:
            point: The point to mirror
            line: The line to mirror across
            
        Returns:
            A new point mirrored across the line
            
        Example:
            >>> p = Point(5, 5, 0)
            >>> mirror_line = LineSegment(Point(0, 0, 0), Point(10, 0, 0))
            >>> mirrored = GeometryManipulator.mirror_point_across_line(p, mirror_line)
            >>> mirrored.northing  # -5 (mirrored across horizontal line at y=0)
        """
        # Get line direction vector
        dx = line.end_point.easting - line.start_point.easting
        dy = line.end_point.northing - line.start_point.northing
        
        # Normalize
        length = math.sqrt(dx*dx + dy*dy)
        if length < 1e-10:
            raise ValidationError("Mirror line has zero length")
        dx /= length
        dy /= length
        
        # Vector from line start to point
        px = point.easting - line.start_point.easting
        py = point.northing - line.start_point.northing
        
        # Project onto line
        dot = px * dx + py * dy
        
        # Foot of perpendicular
        foot_e = line.start_point.easting + dot * dx
        foot_n = line.start_point.northing + dot * dy
        
        # Mirror across foot
        new_easting = 2 * foot_e - point.easting
        new_northing = 2 * foot_n - point.northing
        
        return Point(new_northing, new_easting, point.elevation)
    
    @staticmethod
    def mirror_point_across_point(point: Point, center: Point) -> Point:
        """
        Mirror a point across another point (180° rotation).
        
        Args:
            point: The point to mirror
            center: The center point to mirror across
            
        Returns:
            A new point mirrored across the center point
            
        Example:
            >>> p = Point(5, 5, 10)
            >>> center = Point(0, 0, 0)
            >>> mirrored = GeometryManipulator.mirror_point_across_point(p, center)
            >>> mirrored.northing  # -5
            >>> mirrored.easting  # -5
        """
        new_northing = 2 * center.northing - point.northing
        new_easting = 2 * center.easting - point.easting
        return Point(new_northing, new_easting, point.elevation)
    
    @classmethod
    def mirror_line_segment_across_line(cls, segment: LineSegment, mirror_line: LineSegment) -> LineSegment:
        """
        Mirror a line segment across a line.
        
        Args:
            segment: The line segment to mirror
            mirror_line: The line to mirror across
            
        Returns:
            A new line segment mirrored across the line
        """
        new_start = cls.mirror_point_across_line(segment.start_point, mirror_line)
        new_end = cls.mirror_point_across_line(segment.end_point, mirror_line)
        return LineSegment(new_start, new_end)
    
    @classmethod
    def mirror_polyline_across_line(cls, polyline: SimplePolyline, mirror_line: LineSegment) -> SimplePolyline:
        """
        Mirror a polyline across a line.
        
        Args:
            polyline: The polyline to mirror
            mirror_line: The line to mirror across
            
        Returns:
            A new polyline mirrored across the line
        """
        new_points = [cls.mirror_point_across_line(p, mirror_line) for p in polyline.points]
        return SimplePolyline(new_points)
    
    @classmethod
    def mirror_polygon_across_line(cls, polygon: SimplePolygon, mirror_line: LineSegment) -> SimplePolygon:
        """
        Mirror a polygon across a line.
        
        Args:
            polygon: The polygon to mirror
            mirror_line: The line to mirror across
            
        Returns:
            A new polygon mirrored across the line
        """
        new_points = [cls.mirror_point_across_line(p, mirror_line) for p in polygon.points]
        return SimplePolygon(new_points)
    
    @classmethod
    def mirror_arc_across_line(cls, arc: CircularArc, mirror_line: LineSegment) -> CircularArc:
        """
        Mirror a circular arc across a line.
        
        Note: Arc direction (CW/CCW) is reversed after mirroring.
        
        Args:
            arc: The arc to mirror
            mirror_line: The line to mirror across
            
        Returns:
            A new arc mirrored across the line with reversed direction
        """
        new_center = cls.mirror_point_across_line(arc.radius_point, mirror_line)
        new_start = cls.mirror_point_across_line(arc.start_point, mirror_line)
        new_end = cls.mirror_point_across_line(arc.end_point, mirror_line)
        
        # Swap start and end to reverse arc direction
        return CircularArc(new_center, new_end, new_start)

    # ==================== Trim Operations ====================
    
    @staticmethod
    def trim_line_segment_at_point(
        segment: LineSegment,
        trim_point: Point,
        keep_start: bool = True,
        tolerance: float = 1e-6
    ) -> LineSegment:
        """
        Trim a line segment at a point.
        
        Args:
            segment: The line segment to trim
            trim_point: The point to trim at (must be on or near the segment)
            keep_start: If True, keep the portion from start to trim_point.
                       If False, keep the portion from trim_point to end.
            tolerance: Maximum distance from point to line to be considered
                      "on" the line
                       
        Returns:
            The trimmed line segment
            
        Raises:
            ValidationError: If trim_point is not on the segment
            
        Example:
            >>> seg = LineSegment(Point(0, 0, 0), Point(10, 0, 0))
            >>> trim_pt = Point(7, 0, 0)
            >>> trimmed = GeometryManipulator.trim_line_segment_at_point(
            ...     seg, trim_pt, keep_start=True
            ... )
            >>> trimmed.length()  # 7.0
        """
        # Calculate line direction vector
        dx = segment.end_point.easting - segment.start_point.easting
        dy = segment.end_point.northing - segment.start_point.northing
        line_length = math.sqrt(dx*dx + dy*dy)
        
        if line_length < 1e-10:
            raise ValidationError("Cannot trim a zero-length line segment")
        
        # Normalize direction
        dx /= line_length
        dy /= line_length
        
        # Vector from start to trim point
        px = trim_point.easting - segment.start_point.easting
        py = trim_point.northing - segment.start_point.northing
        
        # Project onto line to get parameter t (0 to 1)
        t = (px * dx + py * dy) / line_length
        
        # Calculate perpendicular distance
        perp_dist = abs(px * (-dy) + py * dx)
        
        if perp_dist > tolerance:
            raise ValidationError(
                f"Trim point is not on the line segment (distance: {perp_dist})"
            )
        
        if t < -tolerance or t > 1 + tolerance:
            raise ValidationError(
                f"Trim point is not within the line segment bounds (t: {t})"
            )
        
        # Clamp t to [0, 1]
        t = max(0.0, min(1.0, t))
        
        # Create trimmed segment
        if keep_start:
            return LineSegment(segment.start_point, trim_point)
        else:
            return LineSegment(trim_point, segment.end_point)
    
    @staticmethod
    def trim_line_segment_to_line(
        segment: LineSegment,
        trim_line: LineSegment,
        keep_start: bool = True,
        extend_trim_line: bool = True
    ) -> LineSegment:
        """
        Trim a line segment to its intersection with another line.
        
        Args:
            segment: The line segment to trim
            trim_line: The line to trim to
            keep_start: If True, keep start→intersection; if False,
                       keep intersection→end
            extend_trim_line: If True, treat trim_line as infinite;
                             if False, must intersect within trim_line bounds
            
        Returns:
            The trimmed line segment
            
        Raises:
            ValidationError: If lines don't intersect or are parallel
            
        Example:
            >>> seg = LineSegment(Point(0, 0, 0), Point(10, 0, 0))
            >>> trim = LineSegment(Point(7, -5, 0), Point(7, 5, 0))
            >>> trimmed = GeometryManipulator.trim_line_segment_to_line(seg, trim, keep_start=True)
            >>> trimmed.end_point.easting  # 7.0
        """
        # Get direction vectors
        dx1 = segment.end_point.easting - segment.start_point.easting
        dy1 = segment.end_point.northing - segment.start_point.northing
        dx2 = trim_line.end_point.easting - trim_line.start_point.easting
        dy2 = trim_line.end_point.northing - trim_line.start_point.northing
        
        # Calculate determinant (cross product)
        det = dx1 * dy2 - dy1 * dx2
        
        if abs(det) < 1e-10:
            raise ValidationError("Lines are parallel, cannot trim")
        
        # Calculate intersection parameters
        dpx = trim_line.start_point.easting - segment.start_point.easting
        dpy = trim_line.start_point.northing - segment.start_point.northing
        
        t = (dpx * dy2 - dpy * dx2) / det
        s = (dpx * dy1 - dpy * dx1) / det
        
        # Check if intersection is within bounds
        if t < 0 or t > 1:
            raise ValidationError("Intersection is not on the segment being trimmed")
        
        if not extend_trim_line and (s < 0 or s > 1):
            raise ValidationError("Intersection is not on the trim line")
        
        # Calculate intersection point
        intersection_e = segment.start_point.easting + t * dx1
        intersection_n = segment.start_point.northing + t * dy1
        # Interpolate elevation
        intersection_el = segment.start_point.elevation + t * (segment.end_point.elevation - segment.start_point.elevation)
        intersection = Point(intersection_n, intersection_e, intersection_el)
        
        # Create trimmed segment
        if keep_start:
            return LineSegment(segment.start_point, intersection)
        else:
            return LineSegment(intersection, segment.end_point)
    
    @staticmethod
    def trim_arc_at_point(
        arc: CircularArc,
        trim_point: Point,
        keep_start: bool = True,
        tolerance: float = 1e-6
    ) -> CircularArc:
        """
        Trim a circular arc at a point.
        
        Args:
            arc: The arc to trim
            trim_point: The point to trim at (must be on the arc)
            keep_start: If True, keep start→trim_point; if False, keep trim_point→end
            tolerance: Maximum distance from point to arc
            
        Returns:
            The trimmed arc
            
        Raises:
            ValidationError: If trim_point is not on the arc
        """
        # Calculate distance from trim point to arc center
        dist_to_center = math.sqrt(
            (trim_point.easting - arc.radius_point.easting)**2 +
            (trim_point.northing - arc.radius_point.northing)**2
        )
        
        # Verify point is on the circle
        if abs(dist_to_center - arc.radius) > tolerance:
            raise ValidationError(
                f"Trim point is not on the arc "
                f"(distance from center: {dist_to_center}, radius: {arc.radius})"
            )
        
        # Calculate angle of trim point from center
        trim_angle = math.atan2(
            trim_point.northing - arc.radius_point.northing,
            trim_point.easting - arc.radius_point.easting
        )
        
        # Get arc's start and end angles
        start_angle = math.atan2(
            arc.start_point.northing - arc.radius_point.northing,
            arc.start_point.easting - arc.radius_point.easting
        )
        end_angle = math.atan2(
            arc.end_point.northing - arc.radius_point.northing,
            arc.end_point.easting - arc.radius_point.easting
        )
        
        # Normalize angles to check if trim_point is on the arc
        # This is simplified - a full implementation would need to handle arc direction
        
        # Create trimmed arc
        if keep_start:
            return CircularArc(arc.radius_point, arc.start_point, trim_point)
        else:
            return CircularArc(arc.radius_point, trim_point, arc.end_point)
    
    @staticmethod
    def trim_arc_to_line(
        arc: CircularArc,
        trim_line: LineSegment,
        keep_start: bool = True,
        extend_trim_line: bool = True
    ) -> CircularArc:
        """
        Trim a circular arc to its intersection with a line.
        
        Args:
            arc: The arc to trim
            trim_line: The line to trim to
            keep_start: If True, keep start→intersection; if False, keep intersection→end
            extend_trim_line: If True, treat trim_line as infinite
            
        Returns:
            The trimmed arc
            
        Raises:
            ValidationError: If line doesn't intersect the arc
        """
        # Calculate circle-line intersections
        # Line equation: P = P0 + t*d
        # Circle equation: |P - C|² = r²
        
        dx = trim_line.end_point.easting - trim_line.start_point.easting
        dy = trim_line.end_point.northing - trim_line.start_point.northing
        
        # Vector from line start to circle center
        fx = trim_line.start_point.easting - arc.radius_point.easting
        fy = trim_line.start_point.northing - arc.radius_point.northing
        
        # Quadratic equation coefficients: a*t² + b*t + c = 0
        a = dx*dx + dy*dy
        b = 2*(fx*dx + fy*dy)
        c = fx*fx + fy*fy - arc.radius*arc.radius
        
        discriminant = b*b - 4*a*c
        
        if discriminant < 0:
            raise ValidationError("Line does not intersect the circle")
        
        # Calculate intersection parameters
        sqrt_disc = math.sqrt(discriminant)
        t1 = (-b - sqrt_disc) / (2*a)
        t2 = (-b + sqrt_disc) / (2*a)
        
        # Calculate intersection points
        intersections = []
        for t in [t1, t2]:
            if extend_trim_line or (0 <= t <= 1):
                int_e = trim_line.start_point.easting + t * dx
                int_n = trim_line.start_point.northing + t * dy
                int_el = arc.start_point.elevation  # Use arc elevation
                intersections.append(Point(int_n, int_e, int_el))
        
        if not intersections:
            raise ValidationError("Line does not intersect the arc within bounds")
        
        # Choose the appropriate intersection based on keep_start
        # For simplicity, use the first intersection
        # A full implementation would filter to points actually on the arc
        intersection = intersections[0]
        
        # Create trimmed arc
        if keep_start:
            return CircularArc(arc.radius_point, arc.start_point, intersection)
        else:
            return CircularArc(arc.radius_point, intersection, arc.end_point)

    # ==================== Extend Operations ====================
    
    @staticmethod
    def extend_line_segment_to_point(
        segment: LineSegment,
        target_point: Point,
        extend_start: bool = False,
        tolerance: float = 1e-6
    ) -> LineSegment:
        """
        Extend a line segment to reach a target point.
        
        Args:
            segment: The line segment to extend
            target_point: The point to extend to (must be on the line's
                         projection)
            extend_start: If True, extend from start; if False, extend from end
            tolerance: Maximum distance from point to line projection
            
        Returns:
            The extended line segment
            
        Raises:
            ValidationError: If target point is not on the line's projection
                            or extension is in wrong direction
            
        Example:
            >>> seg = LineSegment(Point(2, 0, 0), Point(5, 0, 0))
            >>> target = Point(8, 0, 0)
            >>> extended = GeometryManipulator.extend_line_segment_to_point(
            ...     seg, target, extend_start=False
            ... )
            >>> extended.length()  # 6.0
        """
        # Calculate line direction vector
        dx = segment.end_point.easting - segment.start_point.easting
        dy = segment.end_point.northing - segment.start_point.northing
        line_length = math.sqrt(dx*dx + dy*dy)
        
        if line_length < 1e-10:
            raise ValidationError("Cannot extend a zero-length line segment")
        
        # Normalize direction
        dx /= line_length
        dy /= line_length
        
        # Vector from start to target point
        px = target_point.easting - segment.start_point.easting
        py = target_point.northing - segment.start_point.northing
        
        # Calculate perpendicular distance
        perp_dist = abs(px * (-dy) + py * dx)
        
        if perp_dist > tolerance:
            raise ValidationError(
                f"Target point is not on the line's projection "
                f"(distance: {perp_dist})"
            )
        
        # Project onto line to get parameter t
        t = (px * dx + py * dy) / line_length
        
        # Verify extension is in correct direction
        if extend_start:
            if t >= 0:
                raise ValidationError(
                    "Target point is not before the start of the segment"
                )
            return LineSegment(target_point, segment.end_point)
        else:
            if t <= 1:
                raise ValidationError(
                    "Target point is not beyond the end of the segment"
                )
            return LineSegment(segment.start_point, target_point)
    
    @staticmethod
    def extend_line_segment_to_line(
        segment: LineSegment,
        target_line: LineSegment,
        extend_start: bool = False,
        extend_target_line: bool = True
    ) -> LineSegment:
        """
        Extend a line segment to intersect with another line.
        
        Args:
            segment: The line segment to extend
            target_line: The line to extend to
            extend_start: If True, extend from start; if False, extend from end
            extend_target_line: If True, treat target_line as infinite
            
        Returns:
            The extended line segment
            
        Raises:
            ValidationError: If lines are parallel or extension is in wrong direction
            
        Example:
            >>> seg = LineSegment(Point(0, 0, 0), Point(5, 0, 0))
            >>> target = LineSegment(Point(10, -5, 0), Point(10, 5, 0))
            >>> extended = GeometryManipulator.extend_line_segment_to_line(seg, target, extend_start=False)
            >>> extended.end_point.easting  # 10.0
        """
        # Get direction vectors
        dx1 = segment.end_point.easting - segment.start_point.easting
        dy1 = segment.end_point.northing - segment.start_point.northing
        dx2 = target_line.end_point.easting - target_line.start_point.easting
        dy2 = target_line.end_point.northing - target_line.start_point.northing
        
        # Calculate determinant (cross product)
        det = dx1 * dy2 - dy1 * dx2
        
        if abs(det) < 1e-10:
            raise ValidationError("Lines are parallel, cannot extend to intersection")
        
        # Calculate intersection parameters
        dpx = target_line.start_point.easting - segment.start_point.easting
        dpy = target_line.start_point.northing - segment.start_point.northing
        
        t = (dpx * dy2 - dpy * dx2) / det
        s = (dpx * dy1 - dpy * dx1) / det
        
        # Verify extension is in correct direction
        if extend_start:
            if t >= 0:
                raise ValidationError("Intersection is not before the start of the segment")
        else:
            if t <= 1:
                raise ValidationError("Intersection is not beyond the end of the segment")
        
        if not extend_target_line and (s < 0 or s > 1):
            raise ValidationError("Intersection is not on the target line")
        
        # Calculate intersection point
        intersection_e = segment.start_point.easting + t * dx1
        intersection_n = segment.start_point.northing + t * dy1
        # Interpolate elevation
        intersection_el = segment.start_point.elevation + t * (segment.end_point.elevation - segment.start_point.elevation)
        intersection = Point(intersection_n, intersection_e, intersection_el)
        
        # Create extended segment
        if extend_start:
            return LineSegment(intersection, segment.end_point)
        else:
            return LineSegment(segment.start_point, intersection)
    
    @staticmethod
    def extend_line_segment_by_distance(
        segment: LineSegment,
        distance: float,
        extend_start: bool = False
    ) -> LineSegment:
        """
        Extend a line segment by a specified distance.
        
        Args:
            segment: The line segment to extend
            distance: The distance to extend (can be negative to shorten,
                     but use trim for clarity)
            extend_start: If True, extend from start; if False, extend from end
            
        Returns:
            The extended line segment
            
        Example:
            >>> seg = LineSegment(Point(0, 0, 0), Point(3, 4, 0))  # Length = 5
            >>> extended = GeometryManipulator.extend_line_segment_by_distance(
            ...     seg, 5.0, extend_start=False
            ... )
            >>> extended.length()  # 10.0
        """
        # Calculate direction vector
        dx = segment.end_point.easting - segment.start_point.easting
        dy = segment.end_point.northing - segment.start_point.northing
        dz = segment.end_point.elevation - segment.start_point.elevation
        
        length = math.sqrt(dx*dx + dy*dy)
        
        if length < 1e-10:
            raise ValidationError("Cannot extend a zero-length line segment")
        
        # Normalize direction (2D)
        dx_norm = dx / length
        dy_norm = dy / length
        
        # Calculate extension vector
        ext_e = dx_norm * distance
        ext_n = dy_norm * distance
        # Elevation change proportional to distance
        ext_z = (dz / length) * distance
        
        if extend_start:
            # Extend backward from start
            new_start_e = segment.start_point.easting - ext_e
            new_start_n = segment.start_point.northing - ext_n
            new_start_z = segment.start_point.elevation - ext_z
            new_start = Point(new_start_n, new_start_e, new_start_z)
            return LineSegment(new_start, segment.end_point)
        else:
            # Extend forward from end
            new_end_e = segment.end_point.easting + ext_e
            new_end_n = segment.end_point.northing + ext_n
            new_end_z = segment.end_point.elevation + ext_z
            new_end = Point(new_end_n, new_end_e, new_end_z)
            return LineSegment(segment.start_point, new_end)
    
    @staticmethod
    def extend_arc_by_angle(
        arc: CircularArc,
        angle: float,
        extend_start: bool = False
    ) -> CircularArc:
        """
        Extend a circular arc by a specified angle.
        
        Args:
            arc: The arc to extend
            angle: The angle to extend by (in radians, can be negative)
            extend_start: If True, extend from start; if False, extend from end
            
        Returns:
            The extended arc
            
        Raises:
            ValidationError: If extension would create an arc > 360°
            
        Example:
            >>> center = Point(0, 0, 0)
            >>> start = Point(5, 0, 0)  # 0°
            >>> end = Point(0, 5, 0)    # 90°
            >>> arc = CircularArc(center, start, end)
            >>> extended = GeometryManipulator.extend_arc_by_angle(arc, math.pi/4, extend_start=False)
            >>> # Arc now goes from 0° to 135°
        """
        # Get current start and end angles
        start_angle = math.atan2(
            arc.start_point.northing - arc.radius_point.northing,
            arc.start_point.easting - arc.radius_point.easting
        )
        end_angle = math.atan2(
            arc.end_point.northing - arc.radius_point.northing,
            arc.end_point.easting - arc.radius_point.easting
        )
        
        # Calculate new angles
        if extend_start:
            new_start_angle = start_angle - angle
            new_end_angle = end_angle
        else:
            new_start_angle = start_angle
            new_end_angle = end_angle + angle
        
        # Check for full circle (simplified check)
        sweep = abs(new_end_angle - new_start_angle)
        if sweep >= 2 * math.pi:
            raise ValidationError("Extension would create an arc >= 360°")
        
        # Calculate new start/end points
        if extend_start:
            new_start_e = arc.radius_point.easting + arc.radius * math.cos(new_start_angle)
            new_start_n = arc.radius_point.northing + arc.radius * math.sin(new_start_angle)
            new_start = Point(new_start_n, new_start_e, arc.start_point.elevation)
            return CircularArc(arc.radius_point, new_start, arc.end_point)
        else:
            new_end_e = arc.radius_point.easting + arc.radius * math.cos(new_end_angle)
            new_end_n = arc.radius_point.northing + arc.radius * math.sin(new_end_angle)
            new_end = Point(new_end_n, new_end_e, arc.end_point.elevation)
            return CircularArc(arc.radius_point, arc.start_point, new_end)

class GeometryFactory:
    """
    A factory class for creating geometric objects such as polylines.
    This class provides static methods to create geometric objects from various inputs.
    """
    
    @staticmethod
    def create_polyline_from_points(points: list[Point]) -> SimplePolyline:
        """
        Create a SimplePolyline from a list of points.
        
        Args:
            points (list[Point]): The ordered list of points defining the polyline.
                                Must contain at least 2 points.
            
        Returns:
            SimplePolyline: A new polyline defined by the points
            
        Raises:
            ValueError: If fewer than 2 points are provided
            
        Example:
            >>> points = [Point(0,0,0), Point(1,1,0), Point(2,0,0)]
            >>> polyline = GeometryFactory.create_polyline_from_points(points)
        """
        return SimplePolyline(points)
    
    @staticmethod
    def create_polyline_from_segments(segments: list[LineSegment]) -> SimplePolyline:
        """
        Create a SimplePolyline from a list of line segments.
        
        Args:
            segments (list[LineSegment]): The ordered list of connected line segments.
                                      Must contain at least 1 segment.
                                      Segments must be connected (end point of one segment
                                      must be the start point of the next segment).
            
        Returns:
            SimplePolyline: A new polyline defined by the segments
            
        Raises:
            ValueError: If no segments are provided or if segments are not connected
            
        Example:
            >>> segment1 = LineSegment(Point(0,0,0), Point(1,1,0))
            >>> segment2 = LineSegment(Point(1,1,0), Point(2,0,0))
            >>> polyline = GeometryFactory.create_polyline_from_segments([segment1, segment2])
        """
        if not segments:
            raise ValueError("At least one segment is required")
            
        # Validate connectivity
        for i in range(len(segments) - 1):
            if not segments[i].end_point.equals_within_tolerance(segments[i + 1].start_point, 1e-10):
                raise ValueError(f"Segments at indices {i} and {i+1} are not connected")
                
        # Extract points from segments
        points = [segments[0].start_point]
        points.extend(segment.end_point for segment in segments)
        
        return SimplePolyline(points)
    
    @staticmethod
    def create_complex_polyline(elements: List[LinearGeometry]) -> ComplexPolyline:
        """
        Create a ComplexPolyline from a list of linear geometry elements.
        
        Args:
            elements (list[LinearGeometry]): The ordered list of connected linear geometry elements.
                                         Must contain at least 1 element.
                                         Each element must be either a LineSegment or CircularArc.
                                         Elements must be connected (end point of one element
                                         must be the start point of the next element).
            
        Returns:
            ComplexPolyline: A new complex polyline defined by the elements
            
        Raises:
            ValueError: If no elements are provided
            ValueError: If elements are not connected
            ValueError: If an element is not a LineSegment or CircularArc
            
        Example:
            >>> segment = LineSegment(Point(0,0,0), Point(1,1,0))
            >>> arc = CircularArc(Point(1,0,0), Point(1,1,0), Point(2,1,0))
            >>> polyline = GeometryFactory.create_complex_polyline([segment, arc])
        """
        return ComplexPolyline(elements)
