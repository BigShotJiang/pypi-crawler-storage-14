"""Core geometric types and base classes."""

import math
from typing import Optional, Any, TYPE_CHECKING
import logging

from .constants import DISTANCE_TOLERANCE
from .exceptions import ValidationError
from .geometry import Coordinate

if TYPE_CHECKING:
    from .grid import Grid
    from .geometry import TwoDimensionalEnvelope

logger = logging.getLogger(__name__)

# Note: Coordinate is imported from geometry to avoid duplication

# Point class moved to geometry.py to consolidate duplicate classes

class Geometry:
    """Abstract base class for all geometric objects.
    
    This class defines the common interface that all geometric objects must implement.
    It includes methods for spatial relationships, measurements, and transformations.
    """
    
    def __init__(self):
        """Initialize a geometry object."""
        self._envelope: Optional[TwoDimensionalEnvelope] = None

    @property
    def envelope_2d(self) -> 'TwoDimensionalEnvelope':
        """Get the 2D envelope that contains this geometry.
        
        The envelope is cached after first calculation for performance.
        Subclasses must implement _calculate_envelope_2d().
        
        Returns:
            TwoDimensionalEnvelope: The 2D envelope containing this geometry
        """
        if self._envelope is None:
            self._envelope = self._calculate_envelope_2d()
        return self._envelope

    def _calculate_envelope_2d(self) -> 'TwoDimensionalEnvelope':
        """Calculate the 2D envelope that contains this geometry.
        
        This method must be implemented by subclasses.
        
        Returns:
            TwoDimensionalEnvelope: The calculated 2D envelope
            
        Raises:
            NotImplementedError: If the subclass does not implement this method
        """
        raise NotImplementedError("Subclasses must implement _calculate_envelope_2d()")
