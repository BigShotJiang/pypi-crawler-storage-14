"""
XML format reader and writer for Plana Figura.

XML Format Specification:
- Root element: <PlanaFiguraDocument>
- Metadata section for document information
- Grid section for coordinate system configuration
- Geometries section for all geometry objects
- Human-readable and schema-validatable
"""

import xml.etree.ElementTree as ET
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

from plana_figura.geometry import Point, Geometry
from plana_figura.linear import LineSegment, CircularArc
from plana_figura.composite import (
    SimplePolyline,
    SimplePolygon,
    ComplexPolyline,
    ComplexPolygon,
)
from plana_figura.grid import Grid, CardinalDirection, AngleDirection
from plana_figura.exceptions import ValidationError

logger = logging.getLogger(__name__)


class XMLWriter:
    """
    Writer for XML format.

    Writes geometry objects and metadata to an XML file with proper
    structure and Grid configuration.
    """

    def __init__(self, file_path: str):
        """
        Initialize the XML writer.

        Args:
            file_path: Path to the output file
        """
        self.file_path = file_path
        logger.info(f"Initialized XML writer for: {file_path}")

    def write_document(
        self,
        geometries: List[Geometry],
        grid: Optional[Grid] = None,
        metadata: Optional[Dict[str, str]] = None
    ) -> None:
        """
        Write a complete document with geometries, grid, and metadata.

        Args:
            geometries: List of geometry objects to write
            grid: Grid configuration (uses default if None)
            metadata: Optional metadata dictionary with keys:
                     name, author, description, project_number
        """
        # Create root element
        root = ET.Element('PlanaFiguraDocument')
        root.set('version', '1.0')

        # Add metadata section
        if metadata:
            self._add_metadata(root, metadata)

        # Add grid configuration
        if grid is None:
            grid = Grid()
        self._add_grid(root, grid)

        # Add geometries section
        geometries_elem = ET.SubElement(root, 'Geometries')
        geometries_elem.set('count', str(len(geometries)))

        for geom in geometries:
            self._add_geometry(geometries_elem, geom)

        # Create tree and write to file
        tree = ET.ElementTree(root)
        ET.indent(tree, space='  ')  # Pretty print with 2-space indent

        with open(self.file_path, 'wb') as f:
            tree.write(
                f,
                encoding='utf-8',
                xml_declaration=True
            )

        logger.info(
            f"Wrote {len(geometries)} geometries to {self.file_path}"
        )

    def _add_metadata(
        self,
        root: ET.Element,
        metadata: Dict[str, str]
    ) -> None:
        """Add metadata section to XML."""
        meta_elem = ET.SubElement(root, 'Metadata')

        # Add standard metadata fields
        for key in ['name', 'author', 'description', 'project_number']:
            if key in metadata:
                elem = ET.SubElement(meta_elem, key.title().replace('_', ''))
                elem.text = metadata[key]

        # Add timestamps
        created = ET.SubElement(meta_elem, 'Created')
        created.text = metadata.get(
            'created',
            datetime.now().isoformat()
        )

        modified = ET.SubElement(meta_elem, 'Modified')
        modified.text = metadata.get(
            'modified',
            datetime.now().isoformat()
        )

    def _add_grid(self, root: ET.Element, grid: Grid) -> None:
        """Add Grid configuration to XML."""
        grid_elem = ET.SubElement(root, 'Grid')

        # Grid interval
        interval = ET.SubElement(grid_elem, 'GridInterval')
        interval.text = str(grid.grid_interval)

        # Coordinate tolerance
        coord_tol = ET.SubElement(grid_elem, 'CoordinateTolerance')
        coord_tol.text = str(grid.coordinate_tolerance)

        # Distance tolerance
        dist_tol = ET.SubElement(grid_elem, 'DistanceTolerance')
        dist_tol.text = str(grid.distance_tolerance)

        # Angle tolerance (degrees)
        angle_tol = ET.SubElement(grid_elem, 'AngleToleranceDegrees')
        angle_tol.text = str(grid.angle_tolerance_degrees)

        # Angle interval (degrees)
        angle_int = ET.SubElement(grid_elem, 'AngleIntervalDegrees')
        angle_int.text = str(grid.angle_interval_degrees)

        # Zero angle direction
        zero_dir = ET.SubElement(grid_elem, 'ZeroAngleDirection')
        zero_dir.text = grid.zero_angle_direction.name

        # Angle measurement direction
        angle_meas = ET.SubElement(grid_elem, 'AngleMeasurement')
        angle_meas.text = grid.angle_measurement.name

    def _add_geometry(
        self,
        parent: ET.Element,
        geometry: Geometry
    ) -> None:
        """Add a geometry element to XML."""
        if isinstance(geometry, Point):
            self._add_point(parent, geometry)
        elif isinstance(geometry, LineSegment):
            self._add_line_segment(parent, geometry)
        elif isinstance(geometry, CircularArc):
            self._add_circular_arc(parent, geometry)
        elif isinstance(geometry, SimplePolygon):
            self._add_simple_polygon(parent, geometry)
        elif isinstance(geometry, SimplePolyline):
            self._add_simple_polyline(parent, geometry)
        elif isinstance(geometry, ComplexPolygon):
            self._add_complex_polygon(parent, geometry)
        elif isinstance(geometry, ComplexPolyline):
            self._add_complex_polyline(parent, geometry)
        else:
            raise ValidationError(
                f"Unsupported geometry type: {type(geometry).__name__}"
            )

    def _add_point_element(
        self,
        parent: ET.Element,
        point: Point,
        tag_name: str = 'Point'
    ) -> ET.Element:
        """Add a point element with coordinates."""
        point_elem = ET.SubElement(parent, tag_name)
        point_elem.set('northing', f"{point.northing:.6f}")
        point_elem.set('easting', f"{point.easting:.6f}")
        point_elem.set('elevation', f"{point.elevation:.6f}")
        return point_elem

    def _add_point(self, parent: ET.Element, point: Point) -> None:
        """Add a Point geometry."""
        self._add_point_element(parent, point, 'Point')

    def _add_line_segment(
        self,
        parent: ET.Element,
        segment: LineSegment
    ) -> None:
        """Add a LineSegment geometry."""
        seg_elem = ET.SubElement(parent, 'LineSegment')
        self._add_point_element(seg_elem, segment.start_point, 'StartPoint')
        self._add_point_element(seg_elem, segment.end_point, 'EndPoint')

    def _add_circular_arc(
        self,
        parent: ET.Element,
        arc: CircularArc
    ) -> None:
        """Add a CircularArc geometry."""
        arc_elem = ET.SubElement(parent, 'CircularArc')
        self._add_point_element(arc_elem, arc.radius_point, 'RadiusPoint')
        self._add_point_element(arc_elem, arc.start_point, 'StartPoint')
        self._add_point_element(arc_elem, arc.end_point, 'EndPoint')

    def _add_simple_polyline(
        self,
        parent: ET.Element,
        polyline: SimplePolyline
    ) -> None:
        """Add a SimplePolyline geometry."""
        poly_elem = ET.SubElement(parent, 'SimplePolyline')
        vertices = ET.SubElement(poly_elem, 'Vertices')
        vertices.set('count', str(len(polyline.points)))

        for point in polyline.points:
            self._add_point_element(vertices, point, 'Vertex')

    def _add_simple_polygon(
        self,
        parent: ET.Element,
        polygon: SimplePolygon
    ) -> None:
        """Add a SimplePolygon geometry."""
        poly_elem = ET.SubElement(parent, 'SimplePolygon')
        vertices = ET.SubElement(poly_elem, 'Vertices')
        vertices.set('count', str(len(polygon.points)))

        for point in polygon.points:
            self._add_point_element(vertices, point, 'Vertex')

    def _add_complex_polyline(
        self,
        parent: ET.Element,
        polyline: ComplexPolyline
    ) -> None:
        """Add a ComplexPolyline geometry."""
        poly_elem = ET.SubElement(parent, 'ComplexPolyline')
        elements = ET.SubElement(poly_elem, 'Elements')
        elements.set('count', str(len(polyline.elements)))

        for element in polyline.elements:
            if isinstance(element, LineSegment):
                self._add_line_segment(elements, element)
            elif isinstance(element, CircularArc):
                self._add_circular_arc(elements, element)

    def _add_complex_polygon(
        self,
        parent: ET.Element,
        polygon: ComplexPolygon
    ) -> None:
        """Add a ComplexPolygon geometry."""
        poly_elem = ET.SubElement(parent, 'ComplexPolygon')
        elements = ET.SubElement(poly_elem, 'Elements')
        elements.set('count', str(len(polygon.elements)))

        for element in polygon.elements:
            if isinstance(element, LineSegment):
                self._add_line_segment(elements, element)
            elif isinstance(element, CircularArc):
                self._add_circular_arc(elements, element)


class XMLReader:
    """
    Reader for XML format.

    Reads geometry objects, metadata, and Grid configuration from XML files.
    """

    def __init__(self, file_path: str):
        """
        Initialize the XML reader.

        Args:
            file_path: Path to the input file
        """
        self.file_path = file_path
        logger.info(f"Initialized XML reader for: {file_path}")

    def read_document(
        self
    ) -> tuple[List[Geometry], Grid, Dict[str, str]]:
        """
        Read complete document from XML file.

        Returns:
            Tuple of (geometries, grid, metadata)
        """
        tree = ET.parse(self.file_path)
        root = tree.getroot()

        if root.tag != 'PlanaFiguraDocument':
            raise ValidationError(
                f"Invalid root element: {root.tag}, "
                f"expected PlanaFiguraDocument"
            )

        # Read metadata
        metadata = self._read_metadata(root)

        # Read grid configuration
        grid = self._read_grid(root)

        # Read geometries
        geometries = self._read_geometries(root)

        logger.info(
            f"Read {len(geometries)} geometries from {self.file_path}"
        )

        return geometries, grid, metadata

    def _read_metadata(self, root: ET.Element) -> Dict[str, str]:
        """Read metadata section from XML."""
        metadata: Dict[str, str] = {}

        meta_elem = root.find('Metadata')
        if meta_elem is not None:
            for child in meta_elem:
                if child.text:
                    # Convert tag name to lowercase with underscores
                    key = child.tag.lower()
                    if key == 'projectnumber':
                        key = 'project_number'
                    metadata[key] = child.text

        return metadata

    def _read_grid(self, root: ET.Element) -> Grid:
        """Read Grid configuration from XML."""
        grid_elem = root.find('Grid')
        if grid_elem is None:
            return Grid()  # Return default grid

        # Read grid parameters
        grid_interval = float(
            grid_elem.findtext('GridInterval', '0.01')
        )
        coord_tol = float(
            grid_elem.findtext('CoordinateTolerance', '0.02')
        )
        dist_tol = float(
            grid_elem.findtext('DistanceTolerance', '0.02')
        )
        angle_tol = float(
            grid_elem.findtext('AngleToleranceDegrees', '5e-7')
        )
        angle_int = float(
            grid_elem.findtext('AngleIntervalDegrees', '1.0')
        )

        # Read zero angle direction
        zero_dir_text = grid_elem.findtext(
            'ZeroAngleDirection',
            'NORTH'
        )
        zero_dir = CardinalDirection[zero_dir_text]

        # Read angle measurement direction
        angle_meas_text = grid_elem.findtext(
            'AngleMeasurement',
            'CLOCKWISE'
        )
        angle_meas = AngleDirection[angle_meas_text]

        return Grid(
            grid_interval=grid_interval,
            coordinate_tolerance=coord_tol,
            distance_tolerance=dist_tol,
            angle_tolerance_degrees=angle_tol,
            angle_interval_degrees=angle_int,
            zero_angle_direction=zero_dir,
            angle_measurement=angle_meas
        )

    def _read_geometries(self, root: ET.Element) -> List[Geometry]:
        """Read all geometries from XML."""
        geometries: List[Geometry] = []

        geom_elem = root.find('Geometries')
        if geom_elem is None:
            return geometries

        for child in geom_elem:
            geom = self._read_geometry(child)
            if geom is not None:
                geometries.append(geom)

        return geometries

    def _read_geometry(self, elem: ET.Element) -> Optional[Geometry]:
        """Read a single geometry element."""
        if elem.tag == 'Point':
            return self._read_point(elem)
        elif elem.tag == 'LineSegment':
            return self._read_line_segment(elem)
        elif elem.tag == 'CircularArc':
            return self._read_circular_arc(elem)
        elif elem.tag == 'SimplePolyline':
            return self._read_simple_polyline(elem)
        elif elem.tag == 'SimplePolygon':
            return self._read_simple_polygon(elem)
        elif elem.tag == 'ComplexPolyline':
            return self._read_complex_polyline(elem)
        elif elem.tag == 'ComplexPolygon':
            return self._read_complex_polygon(elem)
        else:
            logger.warning(f"Unknown geometry type: {elem.tag}")
            return None

    def _read_point_element(self, elem: ET.Element) -> Point:
        """Read a point element with coordinates."""
        northing = float(elem.get('northing', '0.0'))
        easting = float(elem.get('easting', '0.0'))
        elevation = float(elem.get('elevation', '0.0'))
        return Point(northing, easting, elevation)

    def _read_point(self, elem: ET.Element) -> Point:
        """Read a Point geometry."""
        return self._read_point_element(elem)

    def _read_line_segment(self, elem: ET.Element) -> LineSegment:
        """Read a LineSegment geometry."""
        start_elem = elem.find('StartPoint')
        end_elem = elem.find('EndPoint')

        if start_elem is None or end_elem is None:
            raise ValidationError(
                "LineSegment missing StartPoint or EndPoint"
            )

        start = self._read_point_element(start_elem)
        end = self._read_point_element(end_elem)

        return LineSegment(start, end)

    def _read_circular_arc(self, elem: ET.Element) -> CircularArc:
        """Read a CircularArc geometry."""
        radius_elem = elem.find('RadiusPoint')
        start_elem = elem.find('StartPoint')
        end_elem = elem.find('EndPoint')

        if (radius_elem is None or
                start_elem is None or
                end_elem is None):
            raise ValidationError(
                "CircularArc missing required points"
            )

        radius_point = self._read_point_element(radius_elem)
        start_point = self._read_point_element(start_elem)
        end_point = self._read_point_element(end_elem)

        return CircularArc(radius_point, start_point, end_point)

    def _read_simple_polyline(self, elem: ET.Element) -> SimplePolyline:
        """Read a SimplePolyline geometry."""
        vertices_elem = elem.find('Vertices')
        if vertices_elem is None:
            raise ValidationError("SimplePolyline missing Vertices")

        points = []
        for vertex in vertices_elem.findall('Vertex'):
            points.append(self._read_point_element(vertex))

        return SimplePolyline(points)

    def _read_simple_polygon(self, elem: ET.Element) -> SimplePolygon:
        """Read a SimplePolygon geometry."""
        vertices_elem = elem.find('Vertices')
        if vertices_elem is None:
            raise ValidationError("SimplePolygon missing Vertices")

        points = []
        for vertex in vertices_elem.findall('Vertex'):
            points.append(self._read_point_element(vertex))

        return SimplePolygon(points)

    def _read_complex_polyline(
        self,
        elem: ET.Element
    ) -> ComplexPolyline:
        """Read a ComplexPolyline geometry."""
        elements_elem = elem.find('Elements')
        if elements_elem is None:
            raise ValidationError("ComplexPolyline missing Elements")

        elements: List[Any] = []
        for child in elements_elem:
            if child.tag == 'LineSegment':
                elements.append(self._read_line_segment(child))
            elif child.tag == 'CircularArc':
                elements.append(self._read_circular_arc(child))

        return ComplexPolyline(elements)

    def _read_complex_polygon(self, elem: ET.Element) -> ComplexPolygon:
        """Read a ComplexPolygon geometry."""
        elements_elem = elem.find('Elements')
        if elements_elem is None:
            raise ValidationError("ComplexPolygon missing Elements")

        elements: List[Any] = []
        for child in elements_elem:
            if child.tag == 'LineSegment':
                elements.append(self._read_line_segment(child))
            elif child.tag == 'CircularArc':
                elements.append(self._read_circular_arc(child))

        return ComplexPolygon(elements)
