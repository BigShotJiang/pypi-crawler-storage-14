"""
Single Line Plain Text File (SLPTF) format reader and writer.

SLPTF Format Specification:
- One geometry or measurement object per line
- Coordinate sequences in square brackets []
- Double colon :: separators
- Format: GeometryType [Coordinate :: Key=Value :: ...]
- Coordinate types: Start, End, Angle Point, Begin Curve, End Curve,
  Radius Point
- Calculated properties (length, slope, direction) NOT stored
- Sequence numbers for coordinate ordering

Measurement Format:
- Format: Measurement [ID = X :: Type = Y :: Name = Z :: Value = W :: Description = D]
- Vector values: [ID = X :: Type = 3D Vector :: Name = Z :: Northing = N :: Easting = E :: Elevation = Z :: Description = D]

Example Geometry:
Line Segment [Coordinate :: Sequence Number = 1 :: Type = Start ::
Northing = 5000.00 :: Easting = 10000.00] [Coordinate ::
Sequence Number = 2 :: Type = End :: Northing = 6000.00 ::
Easting = 11000.00]

Example Measurements:
Measurement [ID = 1 :: Type = Horizontal Angle :: Name = Angle ABC :: Value = 45.500000 :: Description = Test angle]
Measurement [ID = 2 :: Type = 3D Vector :: Name = Vector AB :: Northing = 100.0 :: Easting = 200.0 :: Elevation = 50.0 :: Description = Test vector]
"""

import re
from typing import List, Dict, Any, Union, Optional
import logging

from plana_figura.geometry import Point, Geometry
from plana_figura.linear import LineSegment, CircularArc
from plana_figura.composite import (
    SimplePolyline,
    SimplePolygon,
    ComplexPolyline,
    ComplexPolygon,
)
from plana_figura.measurements import Measurement, MeasurementType, DecimalDegreesAngle
from plana_figura.exceptions import ValidationError

logger = logging.getLogger(__name__)


class SLPTFWriter:
    """
    Writer for Single Line Plain Text File (SLPTF) format.

    Writes geometry and measurement objects to a text file, one object per line.
    """

    def __init__(self, file_path: str):
        """
        Initialize the SLPTF writer.

        Args:
            file_path: Path to the output file
        """
        self.file_path = file_path
        logger.info(f"Initialized SLPTF writer for: {file_path}")

    def write_geometries(self, geometries: List[Geometry]) -> None:
        """
        Write a list of geometries to the file.

        Args:
            geometries: List of geometry objects to write
        """
        with open(self.file_path, 'w', encoding='utf-8') as f:
            for geom in geometries:
                line = self._geometry_to_line(geom)
                f.write(line + '\n')

        logger.info(f"Wrote {len(geometries)} geometries to {self.file_path}")

    def write_measurements(self, measurements: List[Measurement]) -> None:
        """
        Write a list of measurements to the file.

        Args:
            measurements: List of measurement objects to write
        """
        with open(self.file_path, 'w', encoding='utf-8') as f:
            for meas in measurements:
                line = self._measurement_to_line(meas)
                f.write(line + '\n')

        logger.info(f"Wrote {len(measurements)} measurements to {self.file_path}")

    def write_all(self, geometries: List[Geometry], measurements: List[Measurement]) -> None:
        """
        Write both geometries and measurements to the file.

        Args:
            geometries: List of geometry objects to write
            measurements: List of measurement objects to write
        """
        with open(self.file_path, 'w', encoding='utf-8') as f:
            for geom in geometries:
                line = self._geometry_to_line(geom)
                f.write(line + '\n')
            for meas in measurements:
                line = self._measurement_to_line(meas)
                f.write(line + '\n')

        logger.info(f"Wrote {len(geometries)} geometries and {len(measurements)} measurements to {self.file_path}")

    def _geometry_to_line(self, geometry: Geometry) -> str:
        """
        Convert a geometry object to a SLPTF line.

        Args:
            geometry: Geometry object to convert

        Returns:
            SLPTF formatted string

        Raises:
            ValidationError: If geometry type is not supported
        """
        if isinstance(geometry, Point):
            return self._point_to_line(geometry)
        elif isinstance(geometry, LineSegment):
            return self._line_segment_to_line(geometry)
        elif isinstance(geometry, CircularArc):
            return self._circular_arc_to_line(geometry)
        elif isinstance(geometry, SimplePolygon):
            return self._simple_polygon_to_line(geometry)
        elif isinstance(geometry, SimplePolyline):
            return self._simple_polyline_to_line(geometry)
        elif isinstance(geometry, ComplexPolygon):
            return self._complex_polygon_to_line(geometry)
        elif isinstance(geometry, ComplexPolyline):
            return self._complex_polyline_to_line(geometry)
        else:
            raise ValidationError(
                f"Unsupported geometry type: {type(geometry).__name__}"
            )

    def _format_metadata(self, obj: Union[Geometry, 'Measurement']) -> str:
        """
        Format metadata section for geometry or measurement.

        Args:
            obj: Geometry or Measurement object

        Returns:
            Formatted metadata string in <<key=value, key=value>> format
        """
        metadata_parts = []
        
        # UUID is always present
        metadata_parts.append(f'uuid={obj.uuid}')
        
        # Add name if present
        if hasattr(obj, 'name') and obj.name:
            # Escape quotes in name
            escaped_name = obj.name.replace('"', '\\"')
            metadata_parts.append(f'name="{escaped_name}"')
        
        # Add DXF handle if present (geometries only)
        if hasattr(obj, 'dxf_handle') and obj.dxf_handle:
            metadata_parts.append(f'dxf_handle={obj.dxf_handle}')
        
        if metadata_parts:
            return f" <<{', '.join(metadata_parts)}>>"
        return ""

    def _format_coordinate(
        self,
        point: Point,
        seq_num: int,
        coord_type: str
    ) -> str:
        """
        Format a coordinate in SLPTF format.

        Args:
            point: Point to format
            seq_num: Sequence number
            coord_type: Coordinate type (Start, End, etc.)

        Returns:
            Formatted coordinate string
        """
        return (
            f"[Coordinate :: Sequence Number = {seq_num} :: "
            f"Type = {coord_type} :: "
            f"Northing = {point.northing:.2f} :: "
            f"Easting = {point.easting:.2f} :: "
            f"Elevation = {point.elevation:.2f}]"
        )

    def _point_to_line(self, point: Point) -> str:
        """Convert Point to SLPTF line."""
        coord = self._format_coordinate(point, 1, "Point")
        metadata = self._format_metadata(point)
        return f"Point {coord}{metadata}"

    def _line_segment_to_line(self, segment: LineSegment) -> str:
        """Convert LineSegment to SLPTF line."""
        start = self._format_coordinate(segment.start_point, 1, "Start")
        end = self._format_coordinate(segment.end_point, 2, "End")
        metadata = self._format_metadata(segment)
        return f"Line Segment {start} {end}{metadata}"

    def _circular_arc_to_line(self, arc: CircularArc) -> str:
        """Convert CircularArc to SLPTF line."""
        radius_pt = self._format_coordinate(arc.radius_point, 1, "Radius Point")
        start = self._format_coordinate(arc.start_point, 2, "Begin Curve")
        end = self._format_coordinate(arc.end_point, 3, "End Curve")
        metadata = self._format_metadata(arc)
        return f"Circular Arc {radius_pt} {start} {end}{metadata}"

    def _simple_polyline_to_line(self, polyline: SimplePolyline) -> str:
        """Convert SimplePolyline to SLPTF line."""
        coords = []
        for i, point in enumerate(polyline.points, start=1):
            coord_type = "Start" if i == 1 else "Vertex"
            coords.append(self._format_coordinate(point, i, coord_type))
        metadata = self._format_metadata(polyline)
        return f"Simple Polyline {' '.join(coords)}{metadata}"

    def _simple_polygon_to_line(self, polygon: SimplePolygon) -> str:
        """Convert SimplePolygon to SLPTF line."""
        coords = []
        for i, point in enumerate(polygon.points, start=1):
            coord_type = "Start" if i == 1 else "Vertex"
            coords.append(self._format_coordinate(point, i, coord_type))
        metadata = self._format_metadata(polygon)
        return f"Simple Polygon {' '.join(coords)}{metadata}"

    def _complex_polyline_to_line(self, polyline: ComplexPolyline) -> str:
        """Convert ComplexPolyline to SLPTF line."""
        coords = []
        seq_num = 1

        for element in polyline.elements:
            if isinstance(element, LineSegment):
                coords.append(
                    self._format_coordinate(element.start_point, seq_num, "Start")
                )
                seq_num += 1
                coords.append(
                    self._format_coordinate(element.end_point, seq_num, "End")
                )
                seq_num += 1
            elif isinstance(element, CircularArc):
                coords.append(
                    self._format_coordinate(
                        element.radius_point, seq_num, "Radius Point"
                    )
                )
                seq_num += 1
                coords.append(
                    self._format_coordinate(
                        element.start_point, seq_num, "Begin Curve"
                    )
                )
                seq_num += 1
                coords.append(
                    self._format_coordinate(
                        element.end_point, seq_num, "End Curve"
                    )
                )
                seq_num += 1

        metadata = self._format_metadata(polyline)
        return f"Complex Polyline {' '.join(coords)}{metadata}"

    def _complex_polygon_to_line(self, polygon: ComplexPolygon) -> str:
        """Convert ComplexPolygon to SLPTF line."""
        coords = []
        seq_num = 1

        for element in polygon.elements:
            if isinstance(element, LineSegment):
                coords.append(
                    self._format_coordinate(element.start_point, seq_num, "Start")
                )
                seq_num += 1
                coords.append(
                    self._format_coordinate(element.end_point, seq_num, "End")
                )
                seq_num += 1
            elif isinstance(element, CircularArc):
                coords.append(
                    self._format_coordinate(
                        element.radius_point, seq_num, "Radius Point"
                    )
                )
                seq_num += 1
                coords.append(
                    self._format_coordinate(
                        element.start_point, seq_num, "Begin Curve"
                    )
                )
                seq_num += 1
                coords.append(
                    self._format_coordinate(
                        element.end_point, seq_num, "End Curve"
                    )
                )
                seq_num += 1

        metadata = self._format_metadata(polygon)
        return f"Complex Polygon {' '.join(coords)}{metadata}"

    def _measurement_to_line(self, measurement: Measurement) -> str:
        """
        Convert a measurement object to a SLPTF line.

        Args:
            measurement: Measurement object to convert

        Returns:
            SLPTF formatted string
        """
        # Escape special characters in name and description
        name = measurement.name.replace("::", ";;")
        desc = measurement.description.replace("::", ";;") if measurement.description else ""
        
        # Handle 3D vectors specially
        if measurement.measurement_type == MeasurementType.VECTOR_3D:
            if isinstance(measurement.value, tuple) and len(measurement.value) == 3:
                n, e, z = measurement.value
                parts = [
                    f"ID = {measurement.id}",
                    f"Type = {measurement.measurement_type.value}",
                    f"Name = {name}",
                    f"Northing = {n:.4f}",
                    f"Easting = {e:.4f}",
                    f"Elevation = {z:.4f}"
                ]
                if desc:
                    parts.append(f"Description = {desc}")
                metadata = self._format_metadata(measurement)
                return f"Measurement [{' :: '.join(parts)}]{metadata}"
        
        # Handle angles and directions (DecimalDegreesAngle)
        if isinstance(measurement.value, DecimalDegreesAngle):
            value_str = f"{measurement.value.angle_degrees:.6f}"
        # Handle distances (float)
        elif isinstance(measurement.value, (int, float)):
            value_str = f"{measurement.value:.4f}"
        else:
            value_str = str(measurement.value)
        
        parts = [
            f"ID = {measurement.id}",
            f"Type = {measurement.measurement_type.value}",
            f"Name = {name}",
            f"Value = {value_str}"
        ]
        if desc:
            parts.append(f"Description = {desc}")
        
        metadata = self._format_metadata(measurement)
        return f"Measurement [{' :: '.join(parts)}]{metadata}"


class SLPTFReader:
    """
    Reader for Single Line Plain Text File (SLPTF) format.

    Reads geometry and measurement objects from a text file, one object per line.
    """

    # Regex pattern for parsing coordinates
    COORD_PATTERN = re.compile(
        r'\[Coordinate\s*::\s*'
        r'Sequence Number\s*=\s*(\d+)\s*::\s*'
        r'Type\s*=\s*([^:]+?)\s*::\s*'
        r'Northing\s*=\s*([-+]?\d+\.?\d*)\s*::\s*'
        r'Easting\s*=\s*([-+]?\d+\.?\d*)\s*::\s*'
        r'Elevation\s*=\s*([-+]?\d+\.?\d*)\s*\]'
    )
    
    # Regex pattern for parsing measurement key-value pairs
    MEASUREMENT_KV_PATTERN = re.compile(
        r'([^=]+?)\s*=\s*([^:]+?)(?:\s*::\s*|$)'
    )

    def __init__(self, file_path: str):
        """
        Initialize the SLPTF reader.

        Args:
            file_path: Path to the input file
        """
        self.file_path = file_path
        logger.info(f"Initialized SLPTF reader for: {file_path}")

    def _parse_metadata(self, line: str) -> tuple:
        """
        Extract metadata from end of line.
        
        Args:
            line: SLPTF line potentially containing metadata
            
        Returns:
            Tuple of (line_without_metadata, metadata_dict)
        """
        # Check for metadata section <<...>>
        metadata_pattern = r'<<(.+?)>>$'
        match = re.search(metadata_pattern, line)
        
        if not match:
            return line, {}
        
        # Extract metadata string
        metadata_str = match.group(1)
        clean_line = line[:match.start()].strip()
        
        # Parse key=value pairs
        metadata = {}
        
        # Handle quoted values: key="value" or key=value
        pairs = re.findall(r'(\w+)=(?:"([^"]*)"|([^,\s]+))', metadata_str)
        
        for key, quoted_val, unquoted_val in pairs:
            value = quoted_val if quoted_val else unquoted_val
            # Unescape quotes
            if quoted_val:
                value = value.replace('\\"', '"')
            metadata[key] = value
        
        return clean_line, metadata

    def read_geometries(self) -> List[Geometry]:
        """
        Read all geometries from the file.

        Returns:
            List of geometry objects

        Raises:
            ValidationError: If file format is invalid
        """
        geometries: List[Geometry] = []

        with open(self.file_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue  # Skip empty lines and comments

                try:
                    geom = self._line_to_geometry(line)
                    geometries.append(geom)
                except Exception as e:
                    logger.error(f"Error parsing line {line_num}: {e}")
                    raise ValidationError(
                        f"Invalid SLPTF format at line {line_num}: {e}"
                    )

        logger.info(f"Read {len(geometries)} geometries from {self.file_path}")
        return geometries

    def read_measurements(self) -> List[Measurement]:
        """
        Read all measurements from the file.

        Returns:
            List of measurement objects

        Raises:
            ValidationError: If file format is invalid
        """
        measurements: List[Measurement] = []

        with open(self.file_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue  # Skip empty lines and comments

                # Check if this is a measurement line
                if line.startswith('Measurement '):
                    try:
                        meas = self._line_to_measurement(line)
                        measurements.append(meas)
                    except Exception as e:
                        logger.error(f"Error parsing measurement at line {line_num}: {e}")
                        raise ValidationError(
                            f"Invalid measurement format at line {line_num}: {e}"
                        )

        logger.info(f"Read {len(measurements)} measurements from {self.file_path}")
        return measurements

    def read_all(self) -> tuple[List[Geometry], List[Measurement]]:
        """
        Read all geometries and measurements from the file.

        Returns:
            Tuple of (geometries, measurements)

        Raises:
            ValidationError: If file format is invalid
        """
        geometries: List[Geometry] = []
        measurements: List[Measurement] = []

        with open(self.file_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue  # Skip empty lines and comments

                try:
                    if line.startswith('Measurement '):
                        meas = self._line_to_measurement(line)
                        measurements.append(meas)
                    else:
                        geom = self._line_to_geometry(line)
                        geometries.append(geom)
                except Exception as e:
                    logger.error(f"Error parsing line {line_num}: {e}")
                    raise ValidationError(
                        f"Invalid SLPTF format at line {line_num}: {e}"
                    )

        logger.info(f"Read {len(geometries)} geometries and {len(measurements)} measurements from {self.file_path}")
        return geometries, measurements

    def _line_to_geometry(self, line: str) -> Geometry:
        """
        Convert a SLPTF line to a geometry object.

        Args:
            line: SLPTF formatted string

        Returns:
            Geometry object

        Raises:
            ValidationError: If line format is invalid
        """
        # Extract metadata first
        clean_line, metadata = self._parse_metadata(line)
        
        # Extract optional properties from metadata
        uuid = metadata.get('uuid')
        name = metadata.get('name')
        dxf_handle = metadata.get('dxf_handle')
        
        # Extract geometry type (first word(s) before first bracket)
        match = re.match(r'^([^\[]+)\s*\[', clean_line)
        if not match:
            raise ValidationError(f"Cannot parse geometry type from: {clean_line}")

        geom_type = match.group(1).strip()

        # Parse all coordinates
        coordinates = self._parse_coordinates(clean_line)

        # Create geometry based on type, passing metadata
        if geom_type == "Point":
            return self._create_point(coordinates, uuid, name, dxf_handle)
        elif geom_type == "Line Segment":
            return self._create_line_segment(coordinates, uuid, name, dxf_handle)
        elif geom_type == "Circular Arc":
            return self._create_circular_arc(coordinates, uuid, name, dxf_handle)
        elif geom_type == "Simple Polyline":
            return self._create_simple_polyline(coordinates, uuid, name, dxf_handle)
        elif geom_type == "Simple Polygon":
            return self._create_simple_polygon(coordinates, uuid, name, dxf_handle)
        elif geom_type == "Complex Polyline":
            return self._create_complex_polyline(coordinates, uuid, name, dxf_handle)
        elif geom_type == "Complex Polygon":
            return self._create_complex_polygon(coordinates, uuid, name, dxf_handle)
        else:
            raise ValidationError(f"Unknown geometry type: {geom_type}")

    def _parse_coordinates(self, line: str) -> List[Dict[str, Any]]:
        """
        Parse all coordinates from a line.

        Args:
            line: SLPTF formatted string

        Returns:
            List of coordinate dictionaries
        """
        coordinates = []

        for match in self.COORD_PATTERN.finditer(line):
            seq_num = int(match.group(1))
            coord_type = match.group(2).strip()
            northing = float(match.group(3))
            easting = float(match.group(4))
            elevation = float(match.group(5))

            coordinates.append({
                'seq_num': seq_num,
                'type': coord_type,
                'northing': northing,
                'easting': easting,
                'elevation': elevation,
                'point': Point(northing, easting, elevation)
            })

        # Sort by sequence number
        coordinates.sort(key=lambda c: int(c['seq_num']))  # type: ignore

        return coordinates

    def _create_point(
        self,
        coordinates: List[Dict[str, Any]],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> Point:
        """Create Point from coordinates."""
        if len(coordinates) != 1:
            raise ValidationError(
                f"Point must have exactly 1 coordinate, got {len(coordinates)}"
            )
        point = coordinates[0]['point']
        # Create new point with metadata
        return Point(
            point.northing, point.easting, point.elevation,
            grid=point.grid,
            uuid=uuid, name=name, dxf_handle=dxf_handle
        )

    def _create_line_segment(
        self,
        coordinates: List[Dict[str, Any]],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> LineSegment:
        """Create LineSegment from coordinates."""
        if len(coordinates) != 2:
            raise ValidationError(
                f"Line Segment must have exactly 2 coordinates, got {len(coordinates)}"
            )
        start = coordinates[0]['point']
        end = coordinates[1]['point']
        return LineSegment(start, end, uuid=uuid, name=name, dxf_handle=dxf_handle)

    def _create_circular_arc(
        self,
        coordinates: List[Dict[str, Any]],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> CircularArc:
        """Create CircularArc from coordinates."""
        if len(coordinates) != 3:
            raise ValidationError(
                f"Circular Arc must have exactly 3 coordinates, got {len(coordinates)}"
            )
        radius_point = coordinates[0]['point']
        start_point = coordinates[1]['point']
        end_point = coordinates[2]['point']

        return CircularArc(radius_point, start_point, end_point, uuid=uuid, name=name, dxf_handle=dxf_handle)

    def _create_simple_polyline(
        self,
        coordinates: List[Dict[str, Any]],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> SimplePolyline:
        """Create SimplePolyline from coordinates."""
        if len(coordinates) < 2:
            raise ValidationError(
                f"Simple Polyline must have at least 2 coordinates, got {len(coordinates)}"
            )
        points = [coord['point'] for coord in coordinates]
        return SimplePolyline(points, uuid=uuid, name=name, dxf_handle=dxf_handle)

    def _create_simple_polygon(
        self,
        coordinates: List[Dict[str, Any]],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> SimplePolygon:
        """Create SimplePolygon from coordinates."""
        if len(coordinates) < 4:
            raise ValidationError(
                f"Simple Polygon must have at least 4 coordinates, got {len(coordinates)}"
            )
        points = [coord['point'] for coord in coordinates]
        return SimplePolygon(points, uuid=uuid, name=name, dxf_handle=dxf_handle)

    def _create_complex_polyline(
        self,
        coordinates: List[Dict[str, Any]],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> ComplexPolyline:
        """Create ComplexPolyline from coordinates."""
        elements: List[Any] = []
        i = 0

        while i < len(coordinates):
            coord_type = coordinates[i]['type']

            if coord_type == "Radius Point":
                # This is an arc - need 3 coordinates
                if i + 2 >= len(coordinates):
                    raise ValidationError(
                        "Incomplete arc definition in Complex Polyline"
                    )

                radius_point = coordinates[i]['point']
                start_point = coordinates[i + 1]['point']
                end_point = coordinates[i + 2]['point']

                arc = CircularArc(radius_point, start_point, end_point)
                elements.append(arc)
                i += 3

            elif coord_type in ("Start", "End"):
                # This is a line segment - need 2 coordinates
                if i + 1 >= len(coordinates):
                    raise ValidationError(
                        "Incomplete line definition in Complex Polyline"
                    )

                start = coordinates[i]['point']
                end = coordinates[i + 1]['point']

                segment = LineSegment(start, end)
                elements.append(segment)
                i += 2

            else:
                raise ValidationError(
                    f"Unexpected coordinate type in Complex Polyline: {coord_type}"
                )

        return ComplexPolyline(elements, uuid=uuid, name=name, dxf_handle=dxf_handle)

    def _create_complex_polygon(
        self,
        coordinates: List[Dict[str, Any]],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ) -> ComplexPolygon:
        """Create ComplexPolygon from coordinates."""
        elements: List[Any] = []
        i = 0

        while i < len(coordinates):
            coord_type = coordinates[i]['type']

            if coord_type == "Radius Point":
                # This is an arc - need 3 coordinates
                if i + 2 >= len(coordinates):
                    raise ValidationError(
                        "Incomplete arc definition in Complex Polygon"
                    )

                radius_point = coordinates[i]['point']
                start_point = coordinates[i + 1]['point']
                end_point = coordinates[i + 2]['point']

                arc = CircularArc(radius_point, start_point, end_point)
                elements.append(arc)
                i += 3

            elif coord_type in ("Start", "End"):
                # This is a line segment - need 2 coordinates
                if i + 1 >= len(coordinates):
                    raise ValidationError(
                        "Incomplete line definition in Complex Polygon"
                    )

                start = coordinates[i]['point']
                end = coordinates[i + 1]['point']

                segment = LineSegment(start, end)
                elements.append(segment)
                i += 2

            else:
                raise ValidationError(
                    f"Unexpected coordinate type in Complex Polygon: {coord_type}"
                )

        return ComplexPolygon(elements, uuid=uuid, name=name, dxf_handle=dxf_handle)

    def _line_to_measurement(self, line: str) -> Measurement:
        """
        Convert a SLPTF line to a measurement object.

        Args:
            line: SLPTF formatted string

        Returns:
            Measurement object

        Raises:
            ValidationError: If line format is invalid
        """
        # Extract metadata first
        clean_line, metadata = self._parse_metadata(line)
        uuid = metadata.get('uuid')
        
        # Extract content within brackets
        match = re.search(r'Measurement\s*\[(.*)\]', clean_line)
        if not match:
            raise ValidationError(f"Cannot parse measurement from: {clean_line}")

        content = match.group(1)
        
        # Parse key-value pairs
        data: Dict[str, str] = {}
        for kv_match in self.MEASUREMENT_KV_PATTERN.finditer(content):
            key = kv_match.group(1).strip()
            value = kv_match.group(2).strip()
            data[key] = value

        # Extract required fields
        if 'ID' not in data:
            raise ValidationError("Measurement missing ID field")
        if 'Type' not in data:
            raise ValidationError("Measurement missing Type field")
        if 'Name' not in data:
            raise ValidationError("Measurement missing Name field")

        measurement_id = int(data['ID'])
        type_str = data['Type']
        name = data['Name'].replace(";;", "::")  # Unescape
        description = data.get('Description', '').replace(";;", "::") if data.get('Description') else ""

        # Find matching MeasurementType
        measurement_type = None
        for mt in MeasurementType:
            if mt.value == type_str:
                measurement_type = mt
                break
        
        if measurement_type is None:
            raise ValidationError(f"Unknown measurement type: {type_str}")

        # Parse value based on type
        if measurement_type == MeasurementType.VECTOR_3D:
            # Vector requires Northing, Easting, Elevation
            if 'Northing' not in data or 'Easting' not in data or 'Elevation' not in data:
                raise ValidationError("3D Vector requires Northing, Easting, and Elevation")
            northing = float(data['Northing'])
            easting = float(data['Easting'])
            elevation = float(data['Elevation'])
            value = (northing, easting, elevation)
        elif measurement_type in {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }:
            # Angle/Direction types use DecimalDegreesAngle
            if 'Value' not in data:
                raise ValidationError(f"{type_str} requires Value field")
            degrees = float(data['Value'])
            value = DecimalDegreesAngle(degrees)
        else:
            # Distance types use float
            if 'Value' not in data:
                raise ValidationError(f"{type_str} requires Value field")
            value = float(data['Value'])

        return Measurement(
            name=name,
            value=value,
            measurement_type=measurement_type,
            measurement_id=measurement_id,
            description=description,
            uuid=uuid
        )
