"""
Geometry extractors for extracting measurements and coordinates from geometry.

This module provides functions for extracting measurements (directions, distances,
angles, vectors) and coordinates (points) from geometric objects.
"""

from typing import Optional, List
import math

from plana_figura.geometry import (
    Point,
    LineSegment,
    SurveyorsDirection,
    Vector2D,
    Vector3D
)
from plana_figura.linear import CircularArc
from plana_figura.composite import SimplePolyline, SimplePolygon
from plana_figura.angles import DecimalDegreesAngle
from plana_figura.grid import Grid as TheGrid


# ============================================================================
# Measurement Extraction from Line Segments
# ============================================================================

def extract_direction_from_line_segment(
    line: LineSegment,
    reverse: bool = False,
    grid: Optional[TheGrid] = None
) -> SurveyorsDirection:
    """
    Extract direction from line segment.

    Args:
        line: The line segment
        reverse: If True, extract direction from end to start
        grid: Optional grid for direction calculation

    Returns:
        Direction from start to end (or end to start if reversed)

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> start = Point(1000, 2000, 100)
        >>> end = Point(1100, 2000, 100)  # 100m North
        >>> line = LineSegment(start, end)
        >>> direction = extract_direction_from_line_segment(line)
        >>> direction.azimuth.degrees
        0.0

        >>> # Reversed direction
        >>> direction_rev = extract_direction_from_line_segment(line, reverse=True)
        >>> direction_rev.azimuth.degrees
        180.0
    """
    if reverse:
        # Use the line's reverse azimuth
        return line.reverse_azimuth
    else:
        # Use the line's forward azimuth
        return line.azimuth


def extract_distance_from_line_segment(
    line: LineSegment,
    grid: Optional[TheGrid] = None
) -> float:
    """
    Extract horizontal distance from line segment.

    Args:
        line: The line segment
        grid: Optional grid for distance calculation

    Returns:
        Horizontal distance of the line segment (float)

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> start = Point(1000, 2000, 100)
        >>> end = Point(1000, 2100, 100)  # 100m East
        >>> line = LineSegment(start, end)
        >>> distance = extract_distance_from_line_segment(line)
        >>> distance
        100.0
    """
    # Get horizontal length
    return line.horizontal_length


def extract_3d_vector_from_line_segment(
    line: LineSegment,
    reverse: bool = False,
    grid: Optional[TheGrid] = None
) -> Vector3D:
    """
    Extract 3D vector from line segment.

    Args:
        line: The line segment
        reverse: If True, extract vector from end to start
        grid: Optional grid for vector calculation

    Returns:
        Vector3D representing the line segment

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> start = Point(1000, 2000, 100)
        >>> end = Point(1100, 2050, 150)
        >>> line = LineSegment(start, end)
        >>> vector = extract_3d_vector_from_line_segment(line)
        >>> vector.delta_northing
        100.0
        >>> vector.delta_easting
        50.0
        >>> vector.delta_elevation
        50.0
    """
    if reverse:
        delta_n = line.start_point.northing - line.end_point.northing
        delta_e = line.start_point.easting - line.end_point.easting
        delta_z = line.start_point.elevation - line.end_point.elevation
    else:
        delta_n = line.end_point.northing - line.start_point.northing
        delta_e = line.end_point.easting - line.start_point.easting
        delta_z = line.end_point.elevation - line.start_point.elevation

    return Vector3D(delta_n, delta_e, delta_z, grid=grid)


def extract_horizontal_vector_from_line_segment(
    line: LineSegment,
    reverse: bool = False,
    grid: Optional[TheGrid] = None
) -> Vector2D:
    """
    Extract horizontal vector from line segment (ignoring elevation).

    Args:
        line: The line segment
        reverse: If True, extract vector from end to start
        grid: Optional grid for vector calculation

    Returns:
        Vector2D representing the horizontal component of the line segment

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> start = Point(1000, 2000, 100)
        >>> end = Point(1100, 2050, 150)  # Elevation change ignored
        >>> line = LineSegment(start, end)
        >>> vector = extract_horizontal_vector_from_line_segment(line)
        >>> vector.delta_northing
        100.0
        >>> vector.delta_easting
        50.0
    """
    if reverse:
        delta_n = line.start_point.northing - line.end_point.northing
        delta_e = line.start_point.easting - line.end_point.easting
    else:
        delta_n = line.end_point.northing - line.start_point.northing
        delta_e = line.end_point.easting - line.start_point.easting

    return Vector2D(delta_n, delta_e, grid=grid)


# ============================================================================
# Angle Extraction from Polylines and Polygons
# ============================================================================

def extract_angle_from_polyline_vertices(
    polyline: SimplePolyline,
    vertex_index: int,
    grid: Optional[TheGrid] = None
) -> DecimalDegreesAngle:
    """
    Extract angle at a polyline vertex (angle between adjacent segments).

    Calculates the interior angle at the specified vertex, measured from
    the incoming segment to the outgoing segment.

    Args:
        polyline: The polyline
        vertex_index: Index of vertex (must be > 0 and < len(points)-1)
        grid: Optional grid for angle calculation

    Returns:
        Interior angle at the vertex (0-360°)

    Raises:
        ValueError: If vertex_index is invalid

    Example:
        >>> from plana_figura import Point, SimplePolyline
        >>> points = [
        ...     Point(1000, 2000, 100),
        ...     Point(1100, 2000, 100),  # Vertex at index 1
        ...     Point(1100, 2100, 100)
        ... ]
        >>> polyline = SimplePolyline(points)
        >>> angle = extract_angle_from_polyline_vertices(polyline, 1)
        >>> angle.degrees
        90.0
    """
    if vertex_index <= 0 or vertex_index >= len(polyline.points) - 1:
        raise ValueError(
            f"Vertex index {vertex_index} is invalid. "
            f"Must be between 1 and {len(polyline.points) - 2} inclusive."
        )

    # Get the three points
    prev_point = polyline.points[vertex_index - 1]
    vertex_point = polyline.points[vertex_index]
    next_point = polyline.points[vertex_index + 1]

    # Create line segments
    incoming = LineSegment(prev_point, vertex_point)
    outgoing = LineSegment(vertex_point, next_point)

    # Get azimuths
    azimuth_in = incoming.azimuth.decimal_degrees
    azimuth_out = outgoing.azimuth.decimal_degrees

    # Calculate angle difference (clockwise from incoming to outgoing)
    angle_diff = azimuth_out - azimuth_in

    # Normalize to 0-360
    if angle_diff < 0:
        angle_diff += 360.0

    if grid is not None:
        return DecimalDegreesAngle(angle_diff, grid=grid)
    else:
        return DecimalDegreesAngle(angle_diff)


def extract_angle_from_polygon_vertices(
    polygon: SimplePolygon,
    vertex_index: int,
    grid: Optional[TheGrid] = None
) -> DecimalDegreesAngle:
    """
    Extract interior angle at polygon vertex.

    Calculates the interior angle at the specified vertex. For closed
    polygons, the first and last points are the same, so valid indices
    are 0 to len(points)-2.

    Args:
        polygon: The polygon
        vertex_index: Index of vertex (0 to len(points)-2)
        grid: Optional grid for angle calculation

    Returns:
        Interior angle at the vertex (0-360°)

    Raises:
        ValueError: If vertex_index is invalid

    Example:
        >>> from plana_figura import Point, SimplePolygon
        >>> # Square polygon
        >>> points = [
        ...     Point(1000, 2000, 100),
        ...     Point(1100, 2000, 100),
        ...     Point(1100, 2100, 100),
        ...     Point(1000, 2100, 100),
        ...     Point(1000, 2000, 100)  # Closing point
        ... ]
        >>> polygon = SimplePolygon(points)
        >>> angle = extract_angle_from_polygon_vertices(polygon, 1)
        >>> angle.degrees
        90.0
    """
    # Polygon points include closing point, so max index is len-2
    if vertex_index < 0 or vertex_index >= len(polygon.points) - 1:
        raise ValueError(
            f"Vertex index {vertex_index} is invalid. "
            f"Must be between 0 and {len(polygon.points) - 2} inclusive."
        )

    # Get the three points (handling wrap-around for first vertex)
    if vertex_index == 0:
        prev_point = polygon.points[-2]  # Second to last (before closing point)
    else:
        prev_point = polygon.points[vertex_index - 1]

    vertex_point = polygon.points[vertex_index]
    next_point = polygon.points[vertex_index + 1]

    # Create line segments
    incoming = LineSegment(prev_point, vertex_point)
    outgoing = LineSegment(vertex_point, next_point)

    # Get azimuths
    azimuth_in = incoming.azimuth.decimal_degrees
    azimuth_out = outgoing.azimuth.decimal_degrees

    # Calculate angle difference
    angle_diff = azimuth_out - azimuth_in

    # Normalize to 0-360
    if angle_diff < 0:
        angle_diff += 360.0

    if grid is not None:
        return DecimalDegreesAngle(angle_diff, grid=grid)
    else:
        return DecimalDegreesAngle(angle_diff)


# ============================================================================
# Point Extraction from Geometry
# ============================================================================

def extract_points_from_line_segment(
    line: LineSegment,
    include_start: bool = True,
    include_end: bool = True
) -> List[Point]:
    """
    Extract start and/or end points from line segment.

    Args:
        line: The line segment
        include_start: Include start point
        include_end: Include end point

    Returns:
        List of extracted points

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> start = Point(1000, 2000, 100)
        >>> end = Point(1100, 2100, 150)
        >>> line = LineSegment(start, end)
        >>> points = extract_points_from_line_segment(line)
        >>> len(points)
        2
        >>> points = extract_points_from_line_segment(line, include_start=False)
        >>> len(points)
        1
    """
    points = []
    if include_start:
        points.append(line.start_point)
    if include_end:
        points.append(line.end_point)
    return points


def extract_points_from_polyline(
    polyline: SimplePolyline,
    include_vertices: bool = True,
    num_intermediate_per_segment: int = 0
) -> List[Point]:
    """
    Extract vertices and/or intermediate points from polyline.

    Args:
        polyline: The polyline
        include_vertices: Include vertex points
        num_intermediate_per_segment: Number of evenly-spaced intermediate
            points to add along each segment

    Returns:
        List of extracted points

    Example:
        >>> from plana_figura import Point, SimplePolyline
        >>> points = [
        ...     Point(1000, 2000, 100),
        ...     Point(1100, 2000, 100),
        ...     Point(1100, 2100, 100)
        ... ]
        >>> polyline = SimplePolyline(points)
        >>> extracted = extract_points_from_polyline(polyline)
        >>> len(extracted)
        3
        >>> # With intermediate points
        >>> extracted = extract_points_from_polyline(
        ...     polyline, num_intermediate_per_segment=1
        ... )
        >>> len(extracted)
        5
    """
    result = []

    for i in range(len(polyline.points) - 1):
        # Add vertex if requested
        if include_vertices:
            result.append(polyline.points[i])

        # Add intermediate points if requested
        if num_intermediate_per_segment > 0:
            start = polyline.points[i]
            end = polyline.points[i + 1]

            for j in range(1, num_intermediate_per_segment + 1):
                # Calculate interpolation factor
                t = j / (num_intermediate_per_segment + 1)

                # Interpolate coordinates
                n = start.northing + t * (end.northing - start.northing)
                e = start.easting + t * (end.easting - start.easting)
                z = start.elevation + t * (end.elevation - start.elevation)

                result.append(Point(n, e, z, grid=start.grid))

    # Add last vertex if requested
    if include_vertices:
        result.append(polyline.points[-1])

    return result


def extract_points_from_polygon(
    polygon: SimplePolygon,
    include_vertices: bool = True,
    num_intermediate_per_segment: int = 0
) -> List[Point]:
    """
    Extract vertices and/or intermediate points from polygon.

    Note: The closing point (duplicate of first point) is not included
    in the vertex list.

    Args:
        polygon: The polygon
        include_vertices: Include vertex points
        num_intermediate_per_segment: Number of evenly-spaced intermediate
            points to add along each segment

    Returns:
        List of extracted points (excluding closing point)

    Example:
        >>> from plana_figura import Point, SimplePolygon
        >>> points = [
        ...     Point(1000, 2000, 100),
        ...     Point(1100, 2000, 100),
        ...     Point(1100, 2100, 100),
        ...     Point(1000, 2000, 100)  # Closing point
        ... ]
        >>> polygon = SimplePolygon(points)
        >>> extracted = extract_points_from_polygon(polygon)
        >>> len(extracted)  # Excludes closing point
        3
    """
    result = []

    # Process all segments (including the closing segment)
    for i in range(len(polygon.points) - 1):
        # Add vertex if requested (skip closing point)
        if include_vertices:
            result.append(polygon.points[i])

        # Add intermediate points if requested
        if num_intermediate_per_segment > 0:
            start = polygon.points[i]
            end = polygon.points[i + 1]

            for j in range(1, num_intermediate_per_segment + 1):
                # Calculate interpolation factor
                t = j / (num_intermediate_per_segment + 1)

                # Interpolate coordinates
                n = start.northing + t * (end.northing - start.northing)
                e = start.easting + t * (end.easting - start.easting)
                z = start.elevation + t * (end.elevation - start.elevation)

                result.append(Point(n, e, z, grid=start.grid))

    return result


def extract_points_from_circular_arc(
    arc: CircularArc,
    include_center: bool = False,
    include_start: bool = True,
    include_end: bool = True,
    num_intermediate: int = 0,
    grid: Optional[TheGrid] = None
) -> List[Point]:
    """
    Extract points from circular arc.

    Args:
        arc: The circular arc
        include_center: Include center point
        include_start: Include start point
        include_end: Include end point
        num_intermediate: Number of intermediate points along arc
        grid: Optional grid for the points

    Returns:
        List of extracted points

    Example:
        >>> from plana_figura import CircularArc, Point
        >>> arc = CircularArc(...)
        >>> points = extract_points_from_circular_arc(arc, num_intermediate=4)
        >>> # Returns start, 4 intermediate points, and end (6 total)
    """
    result = []

    # Add center point if requested
    if include_center:
        result.append(arc.center_point)

    # Add start point if requested
    if include_start:
        result.append(arc.start_point)

    # Add intermediate points if requested
    if num_intermediate > 0:
        # Get arc parameters
        center = arc.center_point
        radius = arc.radius
        start_angle = arc.start_angle
        end_angle = arc.end_angle

        # Calculate angle step
        total_angle = end_angle - start_angle
        angle_step = total_angle / (num_intermediate + 1)

        # Generate intermediate points
        for i in range(1, num_intermediate + 1):
            angle = start_angle + (i * angle_step)

            # Calculate point coordinates
            # In surveying: 0° = North, 90° = East
            dx = radius * math.sin(angle)
            dy = radius * math.cos(angle)

            point = Point(
                center.northing + dy,
                center.easting + dx,
                arc.start_point.elevation,  # Use start elevation for all points
                grid=grid or arc.start_point.grid
            )
            result.append(point)

    # Add end point if requested
    if include_end:
        result.append(arc.end_point)

    return result
