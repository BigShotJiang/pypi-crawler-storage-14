"""
Measurement classes for storing survey measurements.

This module provides classes for representing and managing survey measurements
including angles and distances. Measurements are first-class objects that can
be named, stored, and manipulated independently of geometry.
"""

from typing import Optional, Union, List, Dict, Any, Tuple
from enum import Enum
import logging
import re

from plana_figura.angles import DecimalDegreesAngle
from plana_figura.exceptions import ValidationError
from nanoid import generate

logger = logging.getLogger(__name__)


class MeasurementType(Enum):
    """Enumeration of measurement types."""
    # Angle types
    HORIZONTAL_ANGLE = "Horizontal Angle"
    VERTICAL_ANGLE = "Vertical Angle"
    ZENITH_ANGLE = "Zenith Angle"

    # Distance types
    DISTANCE = "Distance"
    HORIZONTAL_DISTANCE = "Horizontal Distance"
    SLOPE_DISTANCE = "Slope Distance"
    VERTICAL_DISTANCE = "Vertical Distance"

    # Direction types
    DIRECTION = "Direction"
    AZIMUTH = "Azimuth"
    BEARING = "Bearing"

    # 3D Vector
    VECTOR_3D = "3D Vector"


class Measurement:
    """
    Base class for survey measurements.

    A measurement represents a named, identifiable quantity that can be
    an angle or a distance. Each measurement has:
    - A unique identifier (integer)
    - A name (string)
    - A value (angle or distance)
    - A measurement type
    - Optional description and metadata
    """

    _next_id: int = 1  # Class variable for auto-incrementing IDs

    @staticmethod
    def _validate_uuid(uuid: str) -> None:
        """
        Validate UUID format (XXXX-XXXX-XXXX-XXXX).
        
        Args:
            uuid: The UUID string to validate
            
        Raises:
            ValidationError: If UUID format is invalid
        """
        pattern = r'^[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}$'
        if not re.match(pattern, uuid):
            raise ValidationError(
                f"Invalid UUID format: {uuid}. "
                "Expected format: XXXX-XXXX-XXXX-XXXX (16 alphanumeric characters)"
            )

    def __init__(
        self,
        name: str,
        value: Union[DecimalDegreesAngle, float, Tuple[float, float, float]],
        measurement_type: MeasurementType,
        measurement_id: Optional[int] = None,
        description: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        uuid: Optional[str] = None
    ):
        """
        Initialize a measurement.

        Args:
            name: Name of the measurement (e.g., "Angle ABC", "Distance AB")
            value: The measurement value:
                - DecimalDegreesAngle for angle/direction types
                - float for distance types
                - tuple (N, E, Z) for 3D vectors
            measurement_type: Type of measurement
            measurement_id: Unique identifier (auto-assigned if None)
            description: Optional description
            metadata: Optional metadata dictionary
            uuid: Optional 16-character unique identifier (auto-generated if None)
                  Format: XXXX-XXXX-XXXX-XXXX (4 groups of 4 alphanumeric chars)

        Raises:
            ValidationError: If inputs are invalid
        """
        if not name or not isinstance(name, str):
            raise ValidationError("Measurement name must be a non-empty string")

        if measurement_type not in MeasurementType:
            raise ValidationError(
                f"Invalid measurement type: {measurement_type}"
            )

        # Validate value based on type
        angle_types = {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }

        distance_types = {
            MeasurementType.DISTANCE,
            MeasurementType.HORIZONTAL_DISTANCE,
            MeasurementType.SLOPE_DISTANCE,
            MeasurementType.VERTICAL_DISTANCE
        }

        if measurement_type in angle_types:
            if not isinstance(value, DecimalDegreesAngle):
                raise ValidationError(
                    f"{measurement_type.value} measurements must use "
                    "DecimalDegreesAngle"
                )
        elif measurement_type in distance_types:
            if not isinstance(value, (int, float)):
                raise ValidationError(
                    f"{measurement_type.value} measurements must be numeric"
                )
            if value < 0:
                raise ValidationError(
                    f"{measurement_type.value} measurements must be "
                    "non-negative"
                )
        elif measurement_type == MeasurementType.VECTOR_3D:
            if not isinstance(value, tuple) or len(value) != 3:
                raise ValidationError(
                    "3D Vector measurements must be a tuple (N, E, Z)"
                )
            if not all(isinstance(v, (int, float)) for v in value):
                raise ValidationError(
                    "3D Vector components must be numeric"
                )

        self._name = name
        self._value = value
        self._type = measurement_type
        self._description = description
        self._metadata = metadata or {}

        # Assign ID
        if measurement_id is None:
            self._id = Measurement._next_id
            Measurement._next_id += 1
        else:
            if not isinstance(measurement_id, int) or measurement_id < 1:
                raise ValidationError(
                    "Measurement ID must be a positive integer"
                )
            self._id = measurement_id
            # Update next_id if necessary
            if measurement_id >= Measurement._next_id:
                Measurement._next_id = measurement_id + 1

        # Generate UUID if not provided (format: XXXX-XXXX-XXXX-XXXX)
        if uuid is None:
            # Generate 16 characters, format as 4 groups of 4
            raw_id = generate(size=16)
            self._uuid = f"{raw_id[0:4]}-{raw_id[4:8]}-{raw_id[8:12]}-{raw_id[12:16]}"
        else:
            self._validate_uuid(uuid)
            self._uuid = uuid

        logger.debug(
            f"Created {self._type.value} measurement: "
            f"ID={self._id}, UUID={self._uuid}, Name='{self._name}'"
        )

    @property
    def id(self) -> int:
        """Get the unique identifier."""
        return self._id

    @property
    def uuid(self) -> str:
        """Get the UUID."""
        return self._uuid

    @property
    def name(self) -> str:
        """Get the measurement name."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """Set the measurement name."""
        if not value or not isinstance(value, str):
            raise ValidationError("Measurement name must be a non-empty string")
        self._name = value

    @property
    def value(self) -> Union[DecimalDegreesAngle, float, Tuple[float, float, float]]:
        """Get the measurement value."""
        return self._value

    @value.setter
    def value(self, new_value: Union[DecimalDegreesAngle, float, Tuple[float, float, float]]) -> None:
        """Set the measurement value."""
        # Validate based on type
        angle_types = {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }

        distance_types = {
            MeasurementType.DISTANCE,
            MeasurementType.HORIZONTAL_DISTANCE,
            MeasurementType.SLOPE_DISTANCE,
            MeasurementType.VERTICAL_DISTANCE
        }

        if self._type in angle_types:
            if not isinstance(new_value, DecimalDegreesAngle):
                raise ValidationError(
                    f"{self._type.value} measurements must use "
                    "DecimalDegreesAngle"
                )
        elif self._type in distance_types:
            if not isinstance(new_value, (int, float)):
                raise ValidationError(
                    f"{self._type.value} measurements must be numeric"
                )
            if new_value < 0:
                raise ValidationError(
                    f"{self._type.value} measurements must be non-negative"
                )
        elif self._type == MeasurementType.VECTOR_3D:
            if not isinstance(new_value, tuple) or len(new_value) != 3:
                raise ValidationError(
                    "3D Vector measurements must be a tuple (N, E, Z)"
                )
            if not all(isinstance(v, (int, float)) for v in new_value):
                raise ValidationError(
                    "3D Vector components must be numeric"
                )
        self._value = new_value

    @property
    def measurement_type(self) -> MeasurementType:
        """Get the measurement type."""
        return self._type

    @property
    def description(self) -> str:
        """Get the measurement description."""
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        """Set the measurement description."""
        self._description = value

    @property
    def metadata(self) -> Dict[str, Any]:
        """Get the metadata dictionary."""
        return self._metadata

    def get_formatted_value(self) -> str:
        """
        Get a formatted string representation of the value.

        Returns:
            Formatted value string
        """
        angle_types = {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }

        if self._type in angle_types:
            # DecimalDegreesAngle has angle_degrees property
            assert isinstance(self._value, DecimalDegreesAngle)
            return f"{self._value.angle_degrees:.6f}°"
        elif self._type == MeasurementType.VECTOR_3D:
            assert isinstance(self._value, tuple)
            n, e, z = self._value
            return f"N:{n:.4f}, E:{e:.4f}, Z:{z:.4f}"
        else:
            assert isinstance(self._value, (int, float))
            return f"{self._value:.4f}"

    def __str__(self) -> str:
        """String representation."""
        return (
            f"{self._type.value} '{self._name}': "
            f"{self.get_formatted_value()}"
        )

    def __repr__(self) -> str:
        """Detailed representation."""
        return (
            f"Measurement(id={self._id}, name='{self._name}', "
            f"type={self._type.value}, value={self.get_formatted_value()})"
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert measurement to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        angle_types = {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }

        result = {
            'id': self._id,
            'name': self._name,
            'type': self._type.value,
            'description': self._description,
            'metadata': self._metadata.copy()
        }

        if self._type in angle_types:
            assert isinstance(self._value, DecimalDegreesAngle)
            result['value'] = self._value.angle_degrees
        elif self._type == MeasurementType.VECTOR_3D:
            assert isinstance(self._value, tuple)
            result['value'] = list(self._value)  # Convert tuple to list
        else:
            assert isinstance(self._value, (int, float))
            result['value'] = self._value

        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Measurement':
        """
        Create measurement from dictionary.

        Args:
            data: Dictionary with measurement data

        Returns:
            Measurement instance
        """
        measurement_type = MeasurementType(data['type'])

        angle_types = {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE,
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }

        # Convert value based on type
        value: Union[DecimalDegreesAngle, float, Tuple[float, float, float]]
        if measurement_type in angle_types:
            value = DecimalDegreesAngle(data['value'])
        elif measurement_type == MeasurementType.VECTOR_3D:
            vec_data = data['value']
            value = (float(vec_data[0]), float(vec_data[1]), float(vec_data[2]))  # Convert to typed tuple
        else:
            value = float(data['value'])

        return cls(
            name=data['name'],
            value=value,
            measurement_type=measurement_type,
            measurement_id=data.get('id'),
            description=data.get('description', ''),
            metadata=data.get('metadata', {})
        )


class MeasurementCollection:
    """
    Collection for managing multiple measurements.

    Provides storage, retrieval, filtering, and management of measurements
    with support for both angles and distances.
    """

    def __init__(self, name: str = "Measurements"):
        """
        Initialize a measurement collection.

        Args:
            name: Name of the collection
        """
        self._name = name
        self._measurements: Dict[int, Measurement] = {}
        logger.debug(f"Created MeasurementCollection: '{name}'")

    @property
    def name(self) -> str:
        """Get the collection name."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """Set the collection name."""
        if not value or not isinstance(value, str):
            raise ValidationError("Collection name must be a non-empty string")
        self._name = value

    def add(self, measurement: Measurement) -> None:
        """
        Add a measurement to the collection.

        Args:
            measurement: Measurement to add

        Raises:
            ValidationError: If measurement ID already exists
        """
        if not isinstance(measurement, Measurement):
            raise ValidationError(
                f"Expected Measurement, got {type(measurement)}"
            )

        if measurement.id in self._measurements:
            raise ValidationError(
                f"Measurement with ID {measurement.id} already exists"
            )

        self._measurements[measurement.id] = measurement
        logger.debug(
            f"Added measurement ID {measurement.id} to collection '{self._name}'"
        )

    def remove(self, measurement_id: int) -> None:
        """
        Remove a measurement by ID.

        Args:
            measurement_id: ID of measurement to remove

        Raises:
            ValidationError: If measurement ID not found
        """
        if measurement_id not in self._measurements:
            raise ValidationError(
                f"Measurement with ID {measurement_id} not found"
            )

        del self._measurements[measurement_id]
        logger.debug(
            f"Removed measurement ID {measurement_id} from "
            f"collection '{self._name}'"
        )

    def get(self, measurement_id: int) -> Optional[Measurement]:
        """
        Get a measurement by ID.

        Args:
            measurement_id: ID of measurement to retrieve

        Returns:
            Measurement if found, None otherwise
        """
        return self._measurements.get(measurement_id)

    def get_by_name(self, name: str) -> List[Measurement]:
        """
        Get all measurements with a given name.

        Args:
            name: Name to search for

        Returns:
            List of measurements with matching name
        """
        return [
            m for m in self._measurements.values()
            if m.name == name
        ]

    def get_by_type(
        self,
        measurement_type: MeasurementType
    ) -> List[Measurement]:
        """
        Get all measurements of a given type.

        Args:
            measurement_type: Type to filter by

        Returns:
            List of measurements of the specified type
        """
        return [
            m for m in self._measurements.values()
            if m.measurement_type == measurement_type
        ]

    def get_all_angles(self) -> List[Measurement]:
        """Get all angle measurements (all angle types)."""
        angle_types = {
            MeasurementType.HORIZONTAL_ANGLE,
            MeasurementType.VERTICAL_ANGLE,
            MeasurementType.ZENITH_ANGLE
        }
        return [
            m for m in self._measurements.values()
            if m.measurement_type in angle_types
        ]

    def get_all_directions(self) -> List[Measurement]:
        """Get all direction measurements (azimuth, bearing, direction)."""
        direction_types = {
            MeasurementType.DIRECTION,
            MeasurementType.AZIMUTH,
            MeasurementType.BEARING
        }
        return [
            m for m in self._measurements.values()
            if m.measurement_type in direction_types
        ]

    def get_all_distances(self) -> List[Measurement]:
        """Get all distance measurements (all distance types)."""
        distance_types = {
            MeasurementType.DISTANCE,
            MeasurementType.HORIZONTAL_DISTANCE,
            MeasurementType.SLOPE_DISTANCE,
            MeasurementType.VERTICAL_DISTANCE
        }
        return [
            m for m in self._measurements.values()
            if m.measurement_type in distance_types
        ]

    def get_all_vectors(self) -> List[Measurement]:
        """Get all 3D vector measurements."""
        return self.get_by_type(MeasurementType.VECTOR_3D)

    def clear(self) -> None:
        """Remove all measurements from the collection."""
        self._measurements.clear()
        logger.debug(f"Cleared all measurements from collection '{self._name}'")

    def __len__(self) -> int:
        """Get the number of measurements in the collection."""
        return len(self._measurements)

    def __iter__(self):
        """Iterate over measurements."""
        return iter(self._measurements.values())

    def __contains__(self, measurement_id: int) -> bool:
        """Check if a measurement ID exists in the collection."""
        return measurement_id in self._measurements

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert collection to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        return {
            'name': self._name,
            'measurements': [
                m.to_dict() for m in self._measurements.values()
            ]
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MeasurementCollection':
        """
        Create collection from dictionary.

        Args:
            data: Dictionary with collection data

        Returns:
            MeasurementCollection instance
        """
        collection = cls(name=data['name'])
        for m_data in data['measurements']:
            measurement = Measurement.from_dict(m_data)
            collection.add(measurement)
        return collection

    def __str__(self) -> str:
        """String representation."""
        angle_count = len(self.get_all_angles())
        direction_count = len(self.get_all_directions())
        distance_count = len(self.get_all_distances())
        vector_count = len(self.get_all_vectors())

        parts = []
        if angle_count > 0:
            parts.append(f"{angle_count} angles")
        if direction_count > 0:
            parts.append(f"{direction_count} directions")
        if distance_count > 0:
            parts.append(f"{distance_count} distances")
        if vector_count > 0:
            parts.append(f"{vector_count} vectors")

        content = ", ".join(parts) if parts else "empty"
        return f"MeasurementCollection '{self._name}': {content}"

    def __repr__(self) -> str:
        """Detailed representation."""
        return (
            f"MeasurementCollection(name='{self._name}', "
            f"count={len(self)})"
        )
