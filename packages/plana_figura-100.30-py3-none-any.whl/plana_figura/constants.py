"""Constants used throughout the Plana Figura package."""

from math import pi

# Tolerance values for floating point comparisons
DISTANCE_TOLERANCE = 1e-10  # meters
ANGLE_TOLERANCE = 1e-10  # radians
AREA_TOLERANCE = 1e-10  # square meters

# Mathematical constants
TWO_PI = 2 * pi
HALF_PI = pi / 2

# Default values
DEFAULT_MAX_QUAD_TREE_DEPTH = 6
DEFAULT_MAX_QUAD_TREE_OBJECTS = 10

# Unit conversion factors
DEGREES_TO_RADIANS = pi / 180
RADIANS_TO_DEGREES = 180 / pi
