"""Exceptions used throughout the Plana Figura package."""

from datetime import datetime
from typing import Optional, Dict, Any


class PlanaFiguraError(Exception):
    """Base exception for all Plana Figura errors."""
    
    def __init__(self, message: str, error_code: str = None, context: dict = None):
        super().__init__(message)
        self.error_code = error_code
        self.context = context or {}
        self.timestamp = datetime.now()


class GeometryError(PlanaFiguraError):
    """Base exception class for geometry-related errors."""
    pass


class MeasurementError(PlanaFiguraError):
    """Measurement processing errors."""
    pass

class ValidationError(GeometryError):
    """Exception raised for geometry validation errors.
    
    Examples:
        - Invalid coordinate values (NaN, infinity)
        - Invalid polygon with fewer than 3 points
        - Invalid envelope with min > max
    """
    pass

class TopologyError(GeometryError):
    """Exception raised for topology-related errors.
    
    Examples:
        - Disconnected elements in a complex polygon
        - Unclosed polygon
        - Self-intersecting geometry
    """
    pass

class GeometryTypeError(GeometryError):
    """Exception raised when an operation is attempted with an incompatible geometry type.
    
    Examples:
        - Trying to calculate area of a line
        - Adding a non-geometry object to a spatial index
    """
    pass
