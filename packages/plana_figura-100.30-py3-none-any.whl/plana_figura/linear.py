"""Linear geometry classes and utilities."""

import math
import logging
from dataclasses import dataclass
from typing import Optional, Union, List, Tuple

from .exceptions import ValidationError
from .constants import TWO_PI, HALF_PI, DEGREES_TO_RADIANS, RADIANS_TO_DEGREES
from .grid import CardinalDirection, AngleDirection, Grid
from .angles import DecimalDegreesAngle
from .geometry import TwoDimensionalEnvelope, LinearGeometry, SurveyorsDirection, Point
# core.Point merged into geometry.Point

logger = logging.getLogger(__name__)

# Note: LinearGeometry is imported from geometry.py to use the canonical base class

class LineSegment(LinearGeometry):
    """A line segment defined by start and end points.
    
    Attributes:
        start_point: The start point
        end_point: The end point
        grid: Optional grid system for the line segment
    """
    
    __slots__ = ['_start', '_end', '_length', '_azimuth', '_grid']
    
    def __init__(
        self,
        start_point: Point,
        end_point: Point,
        grid: Optional['Grid'] = None,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """Initialize a line segment.
        
        Args:
            start_point: The start point
            end_point: The end point
            grid: Optional grid system for the line segment
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name for the line segment
            dxf_handle: Optional DXF handle for import/export persistence
            
        Raises:
            ValidationError: If start and end points are coincident or have incompatible grids
        """
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        
        # Validate input types
        if not isinstance(start_point, Point):
            raise ValidationError("start_point must be a Point object")
        if not isinstance(end_point, Point):
            raise ValidationError("end_point must be a Point object")
        
        from .grid import Grid
        self._grid = grid or Grid()
        
        # Ensure points have compatible grids
        if grid is not None:
            if start_point.grid != grid:
                raise ValidationError("Start point grid does not match line segment grid")
            if end_point.grid != grid:
                raise ValidationError("End point grid does not match line segment grid")
        
        if start_point.is_coincident(end_point):
            raise ValidationError("Start and end points cannot be coincident")
        
        self._start = start_point
        self._end = end_point
        self._length: Optional[float] = None
        self._azimuth_cached: Optional[SurveyorsDirection] = None
    
    @property
    def grid(self) -> 'Grid':
        """Get the grid system for this line segment."""
        return self._grid
    
    @property
    def start_point(self) -> Point:
        """Get the starting point of the line segment."""
        return self._start
    
    @property
    def end_point(self) -> Point:
        """Get the ending point of the line segment."""
        return self._end
    
    def length(self) -> float:
        """Calculate the length of the line segment."""
        if self._length is None:
            dx = self._end.easting - self._start.easting
            dy = self._end.northing - self._start.northing
            dz = self._end.elevation - self._start.elevation
            self._length = math.sqrt(dx * dx + dy * dy + dz * dz)
        return self._length
    
    @property
    def azimuth(self) -> SurveyorsDirection:
        """Calculate the azimuth (bearing) from start to end point.
        
        Returns:
            SurveyorsDirection: The azimuth of the line segment
        """
        if self._azimuth_cached is None:
            self._azimuth_cached = SurveyorsDirection.from_points(self._start, self._end)
        return self._azimuth_cached
    
    @property
    def direction(self) -> SurveyorsDirection:
        """
        Get the direction of the line segment as a SurveyorsDirection.
        
        Returns:
            SurveyorsDirection: The direction from start to end point
        """
        return SurveyorsDirection.from_points(self._start, self._end)
    
    @property
    def reverse_azimuth(self) -> SurveyorsDirection:
        """
        Calculate the reverse azimuth (bearing from end to start point).
        
        This is the azimuth you would measure if traveling from the end point
        back to the start point.
        
        Returns:
            SurveyorsDirection: The reverse azimuth of the line segment
        """
        return SurveyorsDirection.from_points(self._end, self._start)
    
    @property
    def horizontal_length(self) -> float:
        """
        Calculate the horizontal (2D) length of the line segment.
        
        This is the distance ignoring elevation differences, calculated as
        the Euclidean distance in the horizontal plane (N-E plane).
        
        Returns:
            float: The horizontal length in the same units as coordinates
        """
        delta_n = self._end.northing - self._start.northing
        delta_e = self._end.easting - self._start.easting
        return math.sqrt(delta_n**2 + delta_e**2)
    
    @property
    def is_flat(self) -> bool:
        """Check if the line segment is flat (no elevation change).
        
        Returns:
            bool: True if there is no change in elevation between start and end points
        """
        dz = self._end.elevation - self._start.elevation
        return abs(dz) <= self._grid.distance_tolerance
    
    @property
    def is_vertical(self) -> bool:
        """Check if the line segment is vertical in the northing-easting plane.
        
        Returns:
            bool: True if there is no change in easting between start and end points
        """
        dx = self._end.easting - self._start.easting
        return abs(dx) <= self._grid.distance_tolerance
    
    @property
    def slope(self) -> float:
        """
        Calculate the slope of the line segment.
        
        The slope is calculated as the ratio of change in elevation to
        the horizontal distance (sqrt(change_in_northing^2 + change_in_easting^2)).
        
        Returns:
            float: The slope of the line segment (infinity for vertical lines, 0 for flat lines)
        """
        if self.is_vertical:
            return float('inf')
        if self.is_flat:
            return 0.0
        
        horizontal_distance = math.sqrt(
            self.calculate_change_in_northing()**2 + 
            self.calculate_change_in_easting()**2
        )
        return self.calculate_change_in_elevation() / horizontal_distance
    
    def calculate_change_in_northing(self) -> float:
        """Calculate the change in northing."""
        return self._end.northing - self._start.northing
    
    def calculate_change_in_easting(self) -> float:
        """Calculate the change in easting."""
        return self._end.easting - self._start.easting
    
    def calculate_change_in_elevation(self) -> float:
        """Calculate the change in elevation."""
        return self._end.elevation - self._start.elevation
    
    def is_parallel_to(self, other: 'LineSegment') -> bool:
        """Check if this line segment is parallel to another within the grid's tolerance.
        
        Args:
            other: Another line segment to compare with
            
        Returns:
            bool: True if the line segments are parallel within the grid's angle tolerance
        """
        # Get azimuths
        azimuth1 = self.azimuth
        azimuth2 = other.azimuth
        
        # Calculate difference
        diff = abs(azimuth1.angle_degrees - azimuth2.angle_degrees)
        if diff > 180:
            diff = 360 - diff
        
        # Check if difference is within tolerance
        return diff <= self._grid.angle_tolerance_degrees
    
    def is_perpendicular_to(self, other: 'LineSegment') -> bool:
        """Check if this line segment is perpendicular to another within the grid's tolerance.
        
        Args:
            other: Another line segment to compare with
            
        Returns:
            bool: True if the line segments are perpendicular within the grid's angle tolerance
        """
        # Get azimuths
        azimuth1 = self.azimuth
        azimuth2 = other.azimuth
        
        # Calculate difference
        diff = abs(azimuth1.angle_degrees - azimuth2.angle_degrees)
        if diff > 180:
            diff = 360 - diff
        
        # Check if difference is within tolerance of 90 degrees
        return abs(diff - 90) <= self._grid.angle_tolerance_degrees
    
    def point_at_parameter(self, t: float) -> Point:
        """Get the point at the given parameter value.
        
        Args:
            t: Parameter value in [0,1] where 0 is start point and 1 is end point
            
        Returns:
            Point: The point at the given parameter value
            
        Raises:
            ValidationError: If t is not in [0,1]
        """
        if not 0 <= t <= 1:
            raise ValidationError("Parameter t must be in [0,1]")
        
        # Interpolate coordinates
        northing = self._start.northing + t * (self._end.northing - self._start.northing)
        easting = self._start.easting + t * (self._end.easting - self._start.easting)
        elevation = self._start.elevation + t * (self._end.elevation - self._start.elevation)
        
        return Point(northing, easting, elevation, grid=self._grid)
    
    def parameter_at_point(self, point: Point) -> float:
        """Get the parameter value at the given point.
        
        Args:
            point: The point to find the parameter value for
            
        Returns:
            float: Parameter value in [0,1] where 0 is start point and 1 is end point
        """
        # Project point onto line
        dx = self._end.easting - self._start.easting
        dy = self._end.northing - self._start.northing
        dz = self._end.elevation - self._start.elevation
        
        # Calculate parameter value
        if dx != 0:
            t = (point.easting - self._start.easting) / dx
        elif dy != 0:
            t = (point.northing - self._start.northing) / dy
        else:
            t = (point.elevation - self._start.elevation) / dz
        
        # Clamp to [0,1]
        return max(0, min(1, t))
    
    def _calculate_envelope_2d(self) -> TwoDimensionalEnvelope:
        """Calculate the 2D envelope containing this line segment."""
        return TwoDimensionalEnvelope(
            min_northing=min(self._start.northing, self._end.northing),
            max_northing=max(self._start.northing, self._end.northing),
            min_easting=min(self._start.easting, self._end.easting),
            max_easting=max(self._start.easting, self._end.easting)
        )
    
    def __str__(self) -> str:
        """Return a string representation of the line segment."""
        return f"LineSegment(start={self._start}, end={self._end})"
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the line segment."""
        return (
            f"LineSegment(start={self._start!r}, end={self._end!r}, "
            f"length={self.length}, azimuth={self.azimuth})"
        )

class CircularArc(LinearGeometry):
    """A circular arc defined by radius point, start point, and end point.
    
    Attributes:
        radius_point: Center point of the circle
        start_point: Start point of the arc
        end_point: End point of the arc
        grid: Optional grid system for the arc
    """
    
    __slots__ = [
        '_radius_point', '_start_point', '_end_point', '_grid',
        '_radius', '_length', '_azimuth', '_start_angle',
        '_end_angle', '_sweep_angle'
    ]
    
    def __init__(
        self,
        radius_point: Point,
        start_point: Point,
        end_point: Point,
        grid: Optional['Grid'] = None,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """Initialize a circular arc.
        
        Args:
            radius_point: Center point of the circle
            start_point: Start point of the arc
            end_point: End point of the arc
            grid: Optional grid system for the arc
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name for the circular arc
            dxf_handle: Optional DXF handle for import/export persistence
            
        Raises:
            ValidationError: If points are coincident or have incompatible grids
        """
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        
        # Validate input types
        if not isinstance(radius_point, Point):
            raise ValidationError("radius_point must be a Point object")
        if not isinstance(start_point, Point):
            raise ValidationError("start_point must be a Point object")
        if not isinstance(end_point, Point):
            raise ValidationError("end_point must be a Point object")
        
        from .grid import Grid
        self._grid = grid or Grid()  # Use default grid if none provided
        
        logger.debug("Initializing CircularArc:")
        logger.debug(f"  radius_point: ({radius_point.northing}, {radius_point.easting})")
        logger.debug(f"  start_point: ({start_point.northing}, {start_point.easting})")
        logger.debug(f"  end_point: ({end_point.northing}, {end_point.easting})")
        
        # Validate points are not coincident
        if start_point.is_coincident(end_point):
            raise ValidationError("Start and end points cannot be coincident")
        if start_point.is_coincident(radius_point) or end_point.is_coincident(radius_point):
            raise ValidationError("Start and end points cannot be coincident with radius point")
        
        # Store points
        self._radius_point = radius_point
        self._start_point = start_point
        self._end_point = end_point
        
        # Calculate and validate radii
        self._radius = radius_point.distance_to(start_point)
        end_radius = radius_point.distance_to(end_point)
        if abs(self._radius - end_radius) > self._grid.distance_tolerance:
            raise ValidationError(
                f"Start and end points must be equidistant from radius point. "
                f"Got {self._radius} and {end_radius}"
            )
        
        # Calculate angles in radians
        self._start_angle = math.atan2(
            start_point.easting - radius_point.easting,
            start_point.northing - radius_point.northing
        )
        self._end_angle = math.atan2(
            end_point.easting - radius_point.easting,
            end_point.northing - radius_point.northing
        )
        
        # Calculate sweep angle
        sweep = self._end_angle - self._start_angle
        if sweep < 0:
            sweep += TWO_PI
        self._sweep_angle = sweep
        
        # Cache for computed properties
        self._length: Optional[float] = None
        self._azimuth_cached: Optional[SurveyorsDirection] = None
    
    @property
    def radius_point(self) -> Point:
        """Get the center point of the arc."""
        return self._radius_point
    
    @property
    def radius(self) -> float:
        """Get the radius of the arc."""
        return self._radius
    
    @property
    def start_point(self) -> Point:
        """Get the starting point of the arc."""
        return self._start_point
    
    @property
    def end_point(self) -> Point:
        """Get the ending point of the arc."""
        return self._end_point
    
    @property
    def start_angle(self) -> float:
        """Get the start angle."""
        return self._start_angle
    
    @property
    def end_angle(self) -> float:
        """Get the end angle."""
        return self._end_angle
    
    @property
    def sweep_angle(self) -> float:
        """Get the sweep angle."""
        return self._sweep_angle
    
    def length(self) -> float:
        """Calculate the arc length."""
        if self._length is None:
            self._length = self._radius * self._sweep_angle
        return self._length
    
    @property
    def azimuth(self) -> SurveyorsDirection:
        """Calculate the azimuth (bearing) at the start point.
        
        For a circular arc, this is the chord azimuth from start to end.
        
        Returns:
            SurveyorsDirection: The azimuth of the arc
        """
        if self._azimuth_cached is None:
            self._azimuth_cached = SurveyorsDirection.from_points(self._start_point, self._end_point)
        return self._azimuth_cached
    
    def _calculate_envelope_2d(self) -> TwoDimensionalEnvelope:
        """Calculate the 2D envelope containing this circular arc.
        
        The envelope must contain not just the start and end points,
        but also any extreme points along the arc's curve.
        """
        # Get extreme points
        min_northing = min(self._start_point.northing, self._end_point.northing)
        max_northing = max(self._start_point.northing, self._end_point.northing)
        min_easting = min(self._start_point.easting, self._end_point.easting)
        max_easting = max(self._start_point.easting, self._end_point.easting)
        
        # Check if arc crosses cardinal directions
        start_angle = self._start_angle
        end_angle = self._end_angle
        sweep = self._sweep_angle
        
        # Normalize angles to [0, 2π]
        while start_angle < 0:
            start_angle += TWO_PI
        while end_angle < 0:
            end_angle += TWO_PI
        
        # Check if arc crosses each cardinal direction
        for angle in [0, HALF_PI, math.pi, 3*HALF_PI]:  # E, N, W, S
            # Normalize test angle to be after start_angle
            test_angle = angle
            while test_angle < start_angle:
                test_angle += TWO_PI
            
            # Check if angle is within sweep
            if test_angle <= start_angle + sweep:
                # Update bounds based on cardinal direction
                if angle == 0:  # East
                    max_easting = max(max_easting, self._radius_point.easting + self._radius)
                elif angle == HALF_PI:  # North
                    max_northing = max(max_northing, self._radius_point.northing + self._radius)
                elif angle == math.pi:  # West
                    min_easting = min(min_easting, self._radius_point.easting - self._radius)
                else:  # South
                    min_northing = min(min_northing, self._radius_point.northing - self._radius)
        
        return TwoDimensionalEnvelope(
            min_northing=min_northing,
            max_northing=max_northing,
            min_easting=min_easting,
            max_easting=max_easting
        )
    
    def __str__(self) -> str:
        """Return a string representation of the arc."""
        return (
            f"CircularArc(radius_point={self._radius_point}, "
            f"start_point={self._start_point}, end_point={self._end_point})"
        )
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the arc."""
        return (
            f"CircularArc(radius_point={self._radius_point!r}, "
            f"start_point={self._start_point!r}, end_point={self._end_point!r}, "
            f"radius={self._radius}, length={self.length}, "
            f"start_angle={self.start_angle}, end_angle={self.end_angle}, "
            f"sweep_angle={self.sweep_angle})"
        )
