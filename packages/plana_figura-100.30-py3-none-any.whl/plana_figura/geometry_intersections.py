"""
Geometry intersection calculations.

This module provides functions for calculating intersections between
geometric elements (lines, circles, arcs).
"""

import math
from typing import Optional, List

from plana_figura.geometry import Point, LineSegment
from plana_figura.grid import Grid as TheGrid


# ============================================================================
# Line-Line Intersections
# ============================================================================

def intersect_line_line(
    line1: LineSegment,
    line2: LineSegment,
    extend_lines: bool = False,
    grid: Optional[TheGrid] = None
) -> Optional[Point]:
    """
    Calculate intersection point of two line segments.

    Args:
        line1: First line segment
        line2: Second line segment
        extend_lines: If True, treat as infinite lines; if False, only
                     intersect if within segments
        grid: Optional grid for the intersection point

    Returns:
        Intersection point, or None if lines don't intersect

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> line1 = LineSegment(Point(0, 0, 0), Point(100, 0, 0))  # North
        >>> line2 = LineSegment(Point(50, -50, 0), Point(50, 50, 0))  # East
        >>> point = intersect_line_line(line1, line2)
        >>> # Returns Point(50, 0, 0)
    """
    # Get line endpoints
    x1, y1 = line1.start_point.easting, line1.start_point.northing
    x2, y2 = line1.end_point.easting, line1.end_point.northing
    x3, y3 = line2.start_point.easting, line2.start_point.northing
    x4, y4 = line2.end_point.easting, line2.end_point.northing

    # Calculate denominators
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)

    # Check if lines are parallel
    if abs(denom) < 1e-10:
        return None

    # Calculate intersection parameters
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
    u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom

    # Check if intersection is within line segments (if not extending)
    if not extend_lines:
        if t < 0 or t > 1 or u < 0 or u > 1:
            return None

    # Calculate intersection point
    x = x1 + t * (x2 - x1)
    y = y1 + t * (y2 - y1)

    # Interpolate elevation
    z = line1.start_point.elevation + t * (
        line1.end_point.elevation - line1.start_point.elevation
    )

    return Point(y, x, z, grid=grid)


def intersect_line_circle(
    line: LineSegment,
    center: Point,
    radius: float,
    extend_line: bool = False,
    grid: Optional[TheGrid] = None
) -> List[Point]:
    """
    Calculate intersection points of line and circle.

    Args:
        line: Line segment
        center: Circle center point
        radius: Circle radius
        extend_line: If True, treat as infinite line
        grid: Optional grid for intersection points

    Returns:
        List of intersection points (0, 1, or 2 points)

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> line = LineSegment(Point(0, 0, 0), Point(100, 0, 0))
        >>> center = Point(50, 0, 0)
        >>> points = intersect_line_circle(line, center, 25.0)
        >>> # Returns 2 points where line crosses circle
    """
    # Get line direction vector
    dx = line.end_point.easting - line.start_point.easting
    dy = line.end_point.northing - line.start_point.northing

    # Get vector from line start to circle center
    fx = line.start_point.easting - center.easting
    fy = line.start_point.northing - center.northing

    # Solve quadratic equation: at² + bt + c = 0
    a = dx * dx + dy * dy
    b = 2 * (fx * dx + fy * dy)
    c = (fx * fx + fy * fy) - radius * radius

    discriminant = b * b - 4 * a * c

    # No intersection
    if discriminant < 0:
        return []

    # Calculate t values
    discriminant = math.sqrt(discriminant)
    t1 = (-b - discriminant) / (2 * a)
    t2 = (-b + discriminant) / (2 * a)

    result = []

    # Check first intersection
    if extend_line or (0 <= t1 <= 1):
        x = line.start_point.easting + t1 * dx
        y = line.start_point.northing + t1 * dy
        z = line.start_point.elevation + t1 * (
            line.end_point.elevation - line.start_point.elevation
        )
        result.append(Point(y, x, z, grid=grid))

    # Check second intersection (if different from first)
    if abs(t2 - t1) > 1e-10:
        if extend_line or (0 <= t2 <= 1):
            x = line.start_point.easting + t2 * dx
            y = line.start_point.northing + t2 * dy
            z = line.start_point.elevation + t2 * (
                line.end_point.elevation - line.start_point.elevation
            )
            result.append(Point(y, x, z, grid=grid))

    return result


def intersect_circle_circle(
    center1: Point,
    radius1: float,
    center2: Point,
    radius2: float,
    grid: Optional[TheGrid] = None
) -> List[Point]:
    """
    Calculate intersection points of two circles.

    Args:
        center1: First circle center
        radius1: First circle radius
        center2: Second circle center
        radius2: Second circle radius
        grid: Optional grid for intersection points

    Returns:
        List of intersection points (0, 1, or 2 points)

    Example:
        >>> from plana_figura import Point
        >>> c1 = Point(0, 0, 0)
        >>> c2 = Point(50, 0, 0)
        >>> points = intersect_circle_circle(c1, 30.0, c2, 30.0)
        >>> # Returns 2 intersection points
    """
    # Calculate distance between centers
    dx = center2.easting - center1.easting
    dy = center2.northing - center1.northing
    d = math.sqrt(dx * dx + dy * dy)

    # Check if circles are too far apart or one contains the other
    if d > radius1 + radius2 or d < abs(radius1 - radius2) or d < 1e-10:
        return []

    # Calculate distance from center1 to intersection chord
    a = (radius1 * radius1 - radius2 * radius2 + d * d) / (2 * d)

    # Calculate height of intersection chord
    h_squared = radius1 * radius1 - a * a
    if h_squared < 0:
        return []
    h = math.sqrt(h_squared)

    # Calculate point on line between centers
    px = center1.easting + a * dx / d
    py = center1.northing + a * dy / d

    # Calculate intersection points
    result = []

    # First intersection point
    x1 = px + h * dy / d
    y1 = py - h * dx / d
    result.append(Point(y1, x1, center1.elevation, grid=grid))

    # Second intersection point (if not tangent)
    if h > 1e-10:
        x2 = px - h * dy / d
        y2 = py + h * dx / d
        result.append(Point(y2, x2, center1.elevation, grid=grid))

    return result
