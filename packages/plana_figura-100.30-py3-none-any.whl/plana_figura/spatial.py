"""Spatial indexing and envelope classes."""

from typing import List
import logging

from .geometry import Geometry, TwoDimensionalEnvelope, QuadTreeNode
from .constants import DEFAULT_MAX_QUAD_TREE_DEPTH, DEFAULT_MAX_QUAD_TREE_OBJECTS

logger = logging.getLogger(__name__)

# Note: TwoDimensionalEnvelope and QuadTreeNode are imported from geometry to avoid duplication

class QuadTreeIndex:
    """A quad tree spatial index for geometry objects.
    
    This class provides efficient spatial querying of geometry objects
    by organizing them in a hierarchical structure based on their location.
    """
    
    def __init__(self, envelope: TwoDimensionalEnvelope,
                 max_objects: int = DEFAULT_MAX_QUAD_TREE_OBJECTS,
                 max_depth: int = DEFAULT_MAX_QUAD_TREE_DEPTH):
        """Initialize a quad tree index.
        
        Args:
            envelope: The 2D envelope that covers all objects
            max_objects: Maximum number of objects in a node before splitting
            max_depth: Maximum depth of the tree
        """
        self.root = QuadTreeNode(envelope, max_objects, max_depth)
        self._object_count = 0

    def insert(self, geometry: Geometry) -> bool:
        """Insert a geometry object into the quad tree.
        
        Args:
            geometry: The geometry object to insert
            
        Returns:
            bool: True if the object was inserted, False if outside root's envelope
        """
        if self.root.insert(geometry):
            self._object_count += 1
            return True
        return False

    @property
    def object_count(self) -> int:
        """Get the total number of objects in the index."""
        return self._object_count

    def query(self, search_envelope: TwoDimensionalEnvelope) -> List[Geometry]:
        """Find all geometry objects that intersect with the search envelope.
        
        Args:
            search_envelope: The envelope to search within
            
        Returns:
            List of geometry objects that intersect the search envelope
        """
        return self.root.query(search_envelope)
