"""
Measurement operations for creating, converting, and combining measurements.

This module provides functions for working with surveying measurements:
- Rotating directions by angles
- Calculating angles between directions
- Creating vectors from directions and distances
- Combining horizontal and vertical components

All operations support optional Grid integration for consistent calculations.
"""

from typing import Optional
import math

from plana_figura.angles import DecimalDegreesAngle
from plana_figura.geometry import SurveyorsDirection, Vector2D, Vector3D
from plana_figura.grid import Grid as TheGrid


def apply_angle_to_direction(
    direction: SurveyorsDirection,
    angle: DecimalDegreesAngle,
    grid: Optional[TheGrid] = None
) -> SurveyorsDirection:
    """
    Apply an angle rotation to a direction to create a new direction.
    
    Rotates the direction by the specified angle. Positive angles rotate
    clockwise (in surveying convention), negative angles rotate counterclockwise.
    
    Args:
        direction: Base direction to rotate
        angle: Angle to rotate (positive = clockwise from direction)
        grid: Optional grid for angle normalization and zero direction
    
    Returns:
        New rotated direction
    
    Example:
        >>> from plana_figura import DecimalDegreesAngle, SurveyorsDirection
        >>> north = SurveyorsDirection(DecimalDegreesAngle(0))
        >>> angle_90 = DecimalDegreesAngle(90)
        >>> east = apply_angle_to_direction(north, angle_90)
        >>> east.azimuth.degrees
        90.0
        
        >>> # Rotate 45° from East
        >>> east = SurveyorsDirection(DecimalDegreesAngle(90))
        >>> angle_45 = DecimalDegreesAngle(45)
        >>> southeast = apply_angle_to_direction(east, angle_45)
        >>> southeast.azimuth.degrees
        135.0
    """
    # Get the current azimuth in degrees
    current_azimuth = direction.decimal_degrees
    
    # Add the rotation angle
    new_azimuth = current_azimuth + angle.angle_degrees
    
    # Normalize to 0-360 range
    new_azimuth = new_azimuth % 360.0
    
    # Convert to radians and create new SurveyorsDirection
    new_azimuth_rad = math.radians(new_azimuth)
    return SurveyorsDirection(new_azimuth_rad)


def angle_between_directions(
    from_direction: SurveyorsDirection,
    to_direction: SurveyorsDirection,
    grid: Optional[TheGrid] = None
) -> DecimalDegreesAngle:
    """
    Calculate the clockwise angle from one direction to another.
    
    Returns the angle you would need to rotate clockwise from the first
    direction to reach the second direction. Always returns a positive
    angle between 0 and 360 degrees.
    
    Args:
        from_direction: Starting direction
        to_direction: Ending direction
        grid: Optional grid for angle calculation
    
    Returns:
        Clockwise angle from first direction to second (0-360°)
    
    Example:
        >>> from plana_figura import DecimalDegreesAngle, SurveyorsDirection
        >>> north = SurveyorsDirection(DecimalDegreesAngle(0))
        >>> east = SurveyorsDirection(DecimalDegreesAngle(90))
        >>> angle = angle_between_directions(north, east)
        >>> angle.degrees
        90.0
        
        >>> # From East to North (270° clockwise)
        >>> angle = angle_between_directions(east, north)
        >>> angle.degrees
        270.0
    """
    # Get azimuths in degrees
    from_azimuth = from_direction.decimal_degrees
    to_azimuth = to_direction.decimal_degrees
    
    # Calculate difference
    diff = to_azimuth - from_azimuth
    
    # Normalize to 0-360 range
    if diff < 0:
        diff += 360.0
    
    if grid is not None:
        return DecimalDegreesAngle(diff, grid=grid)
    else:
        return DecimalDegreesAngle(diff)


def create_horizontal_vector(
    direction: SurveyorsDirection,
    distance: float,
    grid: Optional[TheGrid] = None
) -> Vector2D:
    """
    Combine a direction and distance to create a horizontal vector.
    
    Creates a 2D vector with the specified direction and magnitude.
    The vector components (delta_northing, delta_easting) are calculated
    using trigonometry.
    
    Args:
        direction: Direction of the vector (azimuth)
        distance: Magnitude of the vector (horizontal distance)
        grid: Optional grid for calculations
    
    Returns:
        Vector2D with specified direction and distance
    
    Example:
        >>> from plana_figura import SurveyorsDirection, Vector2D
        >>> import math
        >>> # 100m North
        >>> north = SurveyorsDirection(0.0)  # 0 radians = North
        >>> vector = create_horizontal_vector(north, 100.0)
        >>> vector.delta_northing
        100.0
        >>> vector.delta_easting
        0.0
        
        >>> # 100m at 45° (Northeast)
        >>> ne = SurveyorsDirection(math.radians(45))
        >>> vector = create_horizontal_vector(ne, 100.0)
        >>> abs(vector.delta_northing - 70.71) < 0.01
        True
        >>> abs(vector.delta_easting - 70.71) < 0.01
        True
    """
    return Vector2D.from_direction_distance(direction, distance, grid)


def create_3d_vector_from_vertical_angle(
    horizontal_vector: Vector2D,
    vertical_angle: DecimalDegreesAngle,
    grid: Optional[TheGrid] = None
) -> Vector3D:
    """
    Combine horizontal vector and vertical angle to create 3D vector.
    
    The vertical angle is measured from the horizontal plane:
    - Positive angles = upward slope
    - Negative angles = downward slope
    - 0° = horizontal
    
    The horizontal distance is preserved, and the elevation change is
    calculated based on the vertical angle.
    
    Args:
        horizontal_vector: Horizontal component (Vector2D)
        vertical_angle: Vertical angle (+ = up, - = down from horizontal)
        grid: Optional grid for calculations
    
    Returns:
        Vector3D with horizontal and vertical components
    
    Example:
        >>> from plana_figura import Vector2D, DecimalDegreesAngle
        >>> # 100m North, 45° up
        >>> h_vec = Vector2D(100.0, 0.0)
        >>> v_angle = DecimalDegreesAngle(45.0)
        >>> vector_3d = create_3d_vector_from_vertical_angle(h_vec, v_angle)
        >>> abs(vector_3d.delta_elevation - 100.0) < 0.01  # tan(45°) * 100
        True
        
        >>> # 100m East, 30° down
        >>> h_vec = Vector2D(0.0, 100.0)
        >>> v_angle = DecimalDegreesAngle(-30.0)
        >>> vector_3d = create_3d_vector_from_vertical_angle(h_vec, v_angle)
        >>> abs(vector_3d.delta_elevation - (-57.74)) < 0.01  # tan(-30°) * 100
        True
    """
    return horizontal_vector.to_3d(vertical_angle=vertical_angle)


def create_3d_vector_from_elevation_change(
    horizontal_vector: Vector2D,
    elevation_change: float,
    grid: Optional[TheGrid] = None
) -> Vector3D:
    """
    Combine horizontal vector and elevation change to create 3D vector.
    
    Simply combines the horizontal components with a specified elevation
    change to create a 3D vector.
    
    Args:
        horizontal_vector: Horizontal component (Vector2D)
        elevation_change: Change in elevation (+ = up, - = down)
        grid: Optional grid for calculations
    
    Returns:
        Vector3D with specified components
    
    Example:
        >>> from plana_figura import Vector2D
        >>> # 100m North, 50m up
        >>> h_vec = Vector2D(100.0, 0.0)
        >>> vector_3d = create_3d_vector_from_elevation_change(h_vec, 50.0)
        >>> vector_3d.delta_northing
        100.0
        >>> vector_3d.delta_easting
        0.0
        >>> vector_3d.delta_elevation
        50.0
    """
    return horizontal_vector.to_3d(delta_elevation=elevation_change)
