"""
Plana Figura - A 2D geometry library.

This package provides classes and utilities for working with geometric objects
such as points, lines, arcs, polygons, and spatial indexing.
"""

from .exceptions import ValidationError
from .core import Geometry
from .geometry import Point
from .angles import DecimalDegreesAngle
from .linear import LineSegment, CircularArc
from .grid import Grid as TheGrid, CardinalDirection, AngleDirection
from .geometry import GeometryManipulator
from .composite import (
    SimplePolyline,
    SimplePolygon,
    ComplexPolyline,
    ComplexPolygon,
    GeometryCollection
)
from .io import SLPTFReader, SLPTFWriter, XMLReader, XMLWriter
from .measurements import (
    Measurement,
    MeasurementCollection,
    MeasurementType
)
from .angles import DecimalDegreesAngle as Angle
from .geometry import (
    SurveyorsDirection,
    Vector2D,
    Vector3D
)
from .measurement_operations import (
    apply_angle_to_direction,
    angle_between_directions,
    create_horizontal_vector,
    create_3d_vector_from_vertical_angle,
    create_3d_vector_from_elevation_change
)
from .geometry_extractors import (
    extract_direction_from_line_segment,
    extract_distance_from_line_segment,
    extract_3d_vector_from_line_segment,
    extract_horizontal_vector_from_line_segment,
    extract_angle_from_polyline_vertices,
    extract_angle_from_polygon_vertices,
    extract_points_from_line_segment,
    extract_points_from_polyline,
    extract_points_from_polygon
)
from .geometry_builders import (
    create_point_from_vector,
    create_point_from_direction_distance,
    create_line_from_vector,
    create_line_from_direction_distance,
    extend_line_segment,
    offset_line_segment,
    rotate_line_segment,
    create_polyline_from_vectors,
    create_polyline_from_direction_distance_pairs,
    extend_polyline,
    create_rectangle,
    create_regular_polygon
)
from .geometry_intersections import (
    intersect_line_line,
    intersect_line_circle,
    intersect_circle_circle
)
from .geometry_analysis import (
    closest_point_on_line,
    distance_point_to_line,
    distance_point_to_point,
    point_in_polygon,
    point_on_polygon_boundary
)
from .geometry_extractors import extract_points_from_circular_arc

__all__ = [
    'ValidationError',
    'Point',
    'Geometry',
    'DecimalDegreesAngle',
    'LineSegment',
    'CircularArc',
    'TheGrid',
    'CardinalDirection',
    'AngleDirection',
    'GeometryManipulator',
    'SimplePolyline',
    'SimplePolygon',
    'ComplexPolyline',
    'ComplexPolygon',
    'GeometryCollection',
    'SLPTFReader',
    'SLPTFWriter',
    'XMLReader',
    'XMLWriter',
    'Measurement',
    'MeasurementCollection',
    'MeasurementType',
    'Angle',
    'SurveyorsDirection',
    'Vector2D',
    'Vector3D',
    # Measurement operations
    'apply_angle_to_direction',
    'angle_between_directions',
    'create_horizontal_vector',
    'create_3d_vector_from_vertical_angle',
    'create_3d_vector_from_elevation_change',
    # Geometry extractors
    'extract_direction_from_line_segment',
    'extract_distance_from_line_segment',
    'extract_3d_vector_from_line_segment',
    'extract_horizontal_vector_from_line_segment',
    'extract_angle_from_polyline_vertices',
    'extract_angle_from_polygon_vertices',
    'extract_points_from_line_segment',
    'extract_points_from_polyline',
    'extract_points_from_polygon',
    'extract_points_from_circular_arc',
    # Geometry builders
    'create_point_from_vector',
    'create_point_from_direction_distance',
    'create_line_from_vector',
    'create_line_from_direction_distance',
    'extend_line_segment',
    'offset_line_segment',
    'rotate_line_segment',
    'create_polyline_from_vectors',
    'create_polyline_from_direction_distance_pairs',
    'extend_polyline',
    'create_rectangle',
    'create_regular_polygon',
    # Geometry intersections
    'intersect_line_line',
    'intersect_line_circle',
    'intersect_circle_circle',
    # Geometry analysis
    'closest_point_on_line',
    'distance_point_to_line',
    'distance_point_to_point',
    'point_in_polygon',
    'point_on_polygon_boundary'
]

__version__ = '100.30'
