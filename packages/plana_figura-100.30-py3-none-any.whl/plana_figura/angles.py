"""Angle-related classes and utilities."""

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING
from .exceptions import ValidationError
from .constants import DEGREES_TO_RADIANS, RADIANS_TO_DEGREES

if TYPE_CHECKING:
    from .grid import Grid
    from typing import Optional

# Default grid for angle operations
_default_grid: 'Optional[Grid]' = None  # Will be set after Grid is imported

def _get_default_grid() -> 'Grid':
    """Get or create the default grid for angle operations."""
    global _default_grid
    if _default_grid is None:
        from .grid import Grid
        _default_grid = Grid()
    return _default_grid

@dataclass(frozen=True)
class DecimalDegreesAngle:
    """An angle measured in decimal degrees.
    
    This class encapsulates angle measurements and provides conversion between
    degrees and radians. It ensures consistent angle handling throughout the
    codebase, particularly for:
    - Azimuth angles (measured clockwise from reference direction)
    - Sweep angles (measured in specified direction)
    - Grid angle snapping and comparison
    
    The angle can be created in several ways:
    >>> # From decimal degrees
    >>> angle1 = DecimalDegreesAngle(52.19064)
    >>> 
    >>> # From degrees, minutes, seconds
    >>> angle2 = DecimalDegreesAngle.from_dms(52, 11, 26.3)
    >>> 
    >>> # From DMS string
    >>> angle3 = DecimalDegreesAngle.from_dms_str("52-11-26.3")
    
    Attributes:
        angle_degrees: The angle in decimal degrees
        grid: Optional grid for angle tolerance
        _original_degrees: Original angle before normalization (set in __post_init__)
    """
    angle_degrees: float
    grid: 'Grid' = None  # type: ignore
    _original_degrees: float = 0.0  # Will be set in __post_init__
    
    def __post_init__(self):
        """Normalize angle to [0, 360) range."""
        if self.grid is None:
            object.__setattr__(self, 'grid', _get_default_grid())
            
        # Store original angle for use in abs() and to_dms()
        object.__setattr__(self, '_original_degrees', self.angle_degrees)
        # Handle floating point precision issues
        if math.isclose(self.angle_degrees, 360.0, abs_tol=self.grid.angle_tolerance_degrees):
            normalized = 0.0
        elif math.isclose(self.angle_degrees, 0.0, abs_tol=self.grid.angle_tolerance_degrees):
            normalized = 0.0
        else:
            # Normalize to [0, 360)
            normalized = self.angle_degrees % 360.0
            # Handle edge cases near 0 and 360
            if math.isclose(normalized, 360.0, abs_tol=self.grid.angle_tolerance_degrees):
                normalized = 0.0
            elif math.isclose(normalized, 0.0, abs_tol=self.grid.angle_tolerance_degrees):
                normalized = 0.0
        object.__setattr__(self, 'angle_degrees', normalized)
    
    @property
    def angle_radians(self) -> float:
        """Get the angle in radians."""
        return self.angle_degrees * DEGREES_TO_RADIANS
    
    @classmethod
    def from_radians(cls, radians: float) -> 'DecimalDegreesAngle':
        """Create an angle from a radian value."""
        return cls(radians * RADIANS_TO_DEGREES)
    
    @classmethod
    def from_dms(cls, degrees: int, minutes: int, seconds: float) -> 'DecimalDegreesAngle':
        """Create an angle from degrees, minutes, and seconds.
        
        Args:
            degrees: Whole number of degrees
            minutes: Whole number of minutes (0-59)
            seconds: Decimal seconds (0-60)
            
        Returns:
            DecimalDegreesAngle: The angle in decimal degrees
            
        Raises:
            ValidationError: If minutes not in [0,59] or seconds not in [0,60)
        """
        if not (0 <= minutes < 60):
            raise ValidationError(f"Minutes must be in range [0,59], got {minutes}")
        if not (0 <= seconds < 60):
            raise ValidationError(f"Seconds must be in range [0,60), got {seconds}")
            
        # Handle negative angles correctly
        sign = -1 if degrees < 0 else 1
        abs_degrees = abs(degrees)
        
        # Handle very small values
        default_grid = _get_default_grid()
        if math.isclose(seconds, 0.0, abs_tol=default_grid.angle_tolerance_degrees):
            seconds = 0.0
        
        decimal_degrees = (
            sign * (
                abs_degrees +
                minutes / 60.0 +
                seconds / 3600.0
            )
        )
        return cls(decimal_degrees)
    
    @classmethod
    def from_dms_str(cls, dms_str: str) -> 'DecimalDegreesAngle':
        """Create an angle from a degrees-minutes-seconds string.
        
        The string should be in the format "DD-MM-SS.ss" where:
        - DD is whole degrees (can be negative)
        - MM is whole minutes (00-59)
        - SS.ss is decimal seconds (00.00-59.99)
        
        Args:
            dms_str: The angle string in DD-MM-SS.ss format
            
        Returns:
            DecimalDegreesAngle: The angle in decimal degrees
            
        Raises:
            ValidationError: If string format is invalid or values out of range
        """
        try:
            # Handle negative sign separately
            is_negative = dms_str.startswith('-')
            dms_str = dms_str.lstrip('-')
            
            parts = dms_str.split("-")
            if len(parts) != 3:
                raise ValidationError(
                    f"DMS string must have format 'DD-MM-SS.ss', got '{dms_str}'"
                )
            
            degrees = int(parts[0])
            minutes = int(parts[1])
            seconds = float(parts[2])
            
            if is_negative:
                degrees = -degrees
            
            return cls.from_dms(degrees, minutes, seconds)
            
        except (ValueError, IndexError) as e:
            raise ValidationError(
                f"Invalid DMS string '{dms_str}'. Must be in format 'DD-MM-SS.ss'"
            ) from e
    
    def to_dms(self) -> tuple[int, int, float]:
        """Convert the angle to degrees, minutes, and seconds.
        
        Returns:
            tuple[int, int, float]: (degrees, minutes, seconds)
        """
        # Use original angle to preserve sign
        angle = self._original_degrees
        
        # Handle negative angles
        sign = -1 if angle < 0 else 1
        abs_degrees = abs(angle)
        
        # Extract components
        degrees = int(abs_degrees)
        minutes_float = (abs_degrees - degrees) * 60
        minutes = int(minutes_float)
        seconds = (minutes_float - minutes) * 60
        
        # Handle floating point precision issues
        default_grid = _get_default_grid()
        if math.isclose(seconds, 60.0, abs_tol=default_grid.angle_tolerance_degrees):
            seconds = 0.0
            minutes += 1
        if minutes == 60:
            minutes = 0
            degrees += 1
        if math.isclose(seconds, 0.0, abs_tol=default_grid.angle_tolerance_degrees):
            seconds = 0.0
        
        # Apply sign to degrees only
        return (sign * degrees, minutes, seconds)
    
    def __str__(self) -> str:
        """Return string representation in both decimal and DMS format."""
        deg, min, sec = self.to_dms()
        return f"{self._original_degrees}° ({deg}-{min:02d}-{sec:05.2f})"
    
    def __repr__(self) -> str:
        """Return detailed string representation."""
        return f"DecimalDegreesAngle(angle_degrees={self._original_degrees})"
    
    def __add__(self, other: 'DecimalDegreesAngle') -> 'DecimalDegreesAngle':
        """Add two angles."""
        return DecimalDegreesAngle(self._original_degrees + other._original_degrees)
    
    def __sub__(self, other: 'DecimalDegreesAngle') -> 'DecimalDegreesAngle':
        """Subtract two angles."""
        return DecimalDegreesAngle(self._original_degrees - other._original_degrees)
    
    def __neg__(self) -> 'DecimalDegreesAngle':
        """Negate an angle."""
        return DecimalDegreesAngle(-self._original_degrees)
    
    def __abs__(self) -> 'DecimalDegreesAngle':
        """Get absolute value of angle."""
        return DecimalDegreesAngle(abs(self._original_degrees))
    
    def __eq__(self, other: object) -> bool:
        """Check if two angles are equal."""
        if not isinstance(other, DecimalDegreesAngle):
            return NotImplemented
        return math.isclose(
            self.angle_degrees,
            other.angle_degrees,
            abs_tol=self.grid.angle_tolerance_degrees
        )
    
    def normalize_to_180(self) -> 'DecimalDegreesAngle':
        """Normalize angle difference to [-180, 180) range.
        
        This is useful for comparing angles where the direction of rotation
        doesn't matter, such as in parallel/perpendicular tests.
        
        Returns:
            DecimalDegreesAngle: A new angle in [-180, 180) range
        """
        # Use original angle to preserve negative values
        angle = self._original_degrees
        # Normalize to [-180, 180) range
        while angle >= 180.0:
            angle -= 360.0
        while angle < -180.0:
            angle += 360.0
        # Handle edge cases near -180 and 180
        if math.isclose(angle, 180.0, abs_tol=self.grid.angle_tolerance_degrees):
            angle = -180.0
        elif math.isclose(angle, -180.0, abs_tol=self.grid.angle_tolerance_degrees):
            angle = -180.0
        # Create new angle with normalized value as both original and normalized
        result = DecimalDegreesAngle(angle)
        # Override both values to preserve the normalized angle
        object.__setattr__(result, '_original_degrees', angle)
        object.__setattr__(result, 'angle_degrees', angle)
        return result
        
    def equals_within_tolerance(self, other: 'DecimalDegreesAngle', tolerance: float) -> bool:
        """Check if this angle equals another within a tolerance.
        
        Args:
            other (DecimalDegreesAngle): The other angle to compare with
            tolerance (float): The tolerance in degrees
            
        Returns:
            bool: True if the angles are equal within tolerance
        """
        if not isinstance(other, DecimalDegreesAngle):
            return False
            
        # Handle wrap-around at 360°
        diff = abs(self.angle_degrees - other.angle_degrees)
        if diff > 180.0:
            diff = 360.0 - diff
        return diff <= tolerance
