"""Composite geometry classes including polylines and polygons."""

from typing import List, Optional, Iterator, Tuple, Union, Callable, Dict, TYPE_CHECKING
import logging

from .geometry import Point, Geometry, TwoDimensionalEnvelope
from .linear import LinearGeometry, LineSegment, CircularArc
from .spatial import QuadTreeIndex
from .exceptions import ValidationError, TopologyError
from .constants import DISTANCE_TOLERANCE
# core.Point merged into geometry.Point

if TYPE_CHECKING:
    from .grid import Grid

logger = logging.getLogger(__name__)

class SimplePolyline(Geometry):
    """A polyline defined by a sequence of points connected by straight line segments."""
    
    __slots__ = ['_points', '_segments', '_length', '_grid']
    
    def __init__(
        self,
        points: List[Point],
        grid: Optional['Grid'] = None,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """Initialize a simple polyline.
        
        Args:
            points: List of points defining the polyline
            grid: Optional grid system for the polyline
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name
            dxf_handle: Optional DXF handle for import/export persistence
        """
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        
        from .grid import Grid
        self._grid = grid or Grid()
        
        if len(points) < 2:
            raise ValidationError("SimplePolyline must have at least 2 points")
            
        # Validate points are not coincident
        for i in range(len(points) - 1):
            if points[i].is_coincident(points[i + 1]):
                raise ValidationError(
                    f"Consecutive points cannot be coincident at index {i}"
                )
        
        self._points = points
        self._segments = [
            LineSegment(points[i], points[i + 1])
            for i in range(len(points) - 1)
        ]
        self._length: Optional[float] = None
    
    @property
    def points(self) -> List[Point]:
        """Get the list of points defining the polyline."""
        return self._points
    
    @property
    def segments(self) -> List[LineSegment]:
        """Get the list of line segments composing the polyline."""
        return self._segments
    
    @property
    def grid(self) -> 'Grid':
        """Get the grid system for this polyline."""
        return self._grid
    
    def length(self) -> float:
        """Calculate the total length of the polyline."""
        if self._length is None:
            total_length = 0.0
            for i in range(len(self._points) - 1):
                total_length += self._points[i].distance_to(self._points[i + 1])
            self._length = self._grid.round_distance(total_length)
        return self._length
    
    def _calculate_envelope_2d(self) -> TwoDimensionalEnvelope:
        """Calculate the 2D envelope containing this polyline."""
        min_n = min(p.northing for p in self._points)
        max_n = max(p.northing for p in self._points)
        min_e = min(p.easting for p in self._points)
        max_e = max(p.easting for p in self._points)
        return TwoDimensionalEnvelope(min_n, max_n, min_e, max_e)

class ComplexPolyline(Geometry):
    """A polyline composed of connected linear elements (line segments and circular arcs).
    
    A complex polyline is a sequence of linear elements that are connected
    end-to-end. It can contain both line segments and circular arcs.
    """
    
    __slots__ = ['_elements', '_length']
    
    def __init__(
        self,
        elements: List[LinearGeometry],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """Initialize a complex polyline.
        
        Args:
            elements: List of linear elements (LineSegment or CircularArc)
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name
            dxf_handle: Optional DXF handle for import/export persistence
            
        Raises:
            ValidationError: If fewer than 1 element is provided
            TopologyError: If elements are not connected end-to-end
        """
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        
        if not elements:
            raise ValidationError("ComplexPolyline must have at least 1 element")
            
        # Validate elements are connected
        for i in range(len(elements) - 1):
            if not elements[i].end_point.is_coincident(elements[i + 1].start_point):
                raise TopologyError(
                    f"Elements must be connected end-to-end. "
                    f"Discontinuity between elements {i} and {i+1}"
                )
        
        self._elements = elements
        self._length: Optional[float] = None
    
    @property
    def elements(self) -> List[LinearGeometry]:
        """Get the list of linear elements composing the polyline."""
        return self._elements
    
    def length(self) -> float:
        """Calculate the total length of the polyline."""
        if self._length is None:
            self._length = sum(element.length() for element in self._elements)
        return self._length
    
    def _calculate_envelope_2d(self) -> TwoDimensionalEnvelope:
        """Calculate the 2D envelope containing this polyline."""
        # Start with the envelope of the first element
        envelope = self._elements[0].envelope_2d
        
        # Expand to include all other elements
        for element in self._elements[1:]:
            elem_env = element.envelope_2d
            envelope = TwoDimensionalEnvelope(
                min(envelope.min_northing, elem_env.min_northing),
                max(envelope.max_northing, elem_env.max_northing),
                min(envelope.min_easting, elem_env.min_easting),
                max(envelope.max_easting, elem_env.max_easting)
            )
        
        return envelope

class SimplePolygon(Geometry):
    """A polygon composed of connected line segments forming a closed ring.
    
    A simple polygon is a closed sequence of points connected by straight
    line segments. It cannot contain circular arcs or other curve types.
    The polygon must be closed (first point equals last point) and must
    not be self-intersecting.
    """
    
    __slots__ = ['_points', '_segments', '_area']
    
    def __init__(
        self,
        points: List[Point],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """Initialize a simple polygon.
        
        Args:
            points: List of points defining the polygon vertices
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name
            dxf_handle: Optional DXF handle for import/export persistence
            
        Raises:
            ValidationError: If fewer than 4 points are provided
            ValidationError: If consecutive points are coincident
            ValidationError: If polygon is not closed
            TopologyError: If polygon is self-intersecting
        """
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        
        if len(points) < 4:
            raise ValidationError(
                "SimplePolygon must have at least 4 points "
                "(3 unique points plus closing point)"
            )
            
        # Validate points are not coincident and polygon is closed
        if not points[0].is_coincident(points[-1]):
            raise ValidationError("Polygon must be closed (first point = last point)")
            
        for i in range(len(points) - 1):
            if points[i].is_coincident(points[i + 1]):
                raise ValidationError(
                    f"Consecutive points cannot be coincident at index {i}"
                )
        
        self._points = points
        self._segments = [
            LineSegment(points[i], points[i + 1])
            for i in range(len(points) - 1)
        ]
        self._area: Optional[float] = None
        
        # TODO: Add self-intersection check
    
    @property
    def points(self) -> List[Point]:
        """Get the list of points defining the polygon."""
        return self._points
    
    @property
    def segments(self) -> List[LineSegment]:
        """Get the list of line segments composing the polygon."""
        return self._segments
    
    def perimeter(self) -> float:
        """Calculate the perimeter length of the polygon."""
        return sum(segment.length() for segment in self._segments)
    
    def area(self) -> float:
        """Calculate the area of the polygon using the shoelace formula."""
        if self._area is None:
            # Shoelace formula (also known as surveyor's formula)
            area = 0.0
            for i in range(len(self._points) - 1):
                p1 = self._points[i]
                p2 = self._points[i + 1]
                area += (p1.northing * p2.easting - p2.northing * p1.easting)
            self._area = abs(area) / 2.0
        return self._area
    
    def _calculate_envelope_2d(self) -> TwoDimensionalEnvelope:
        """Calculate the 2D envelope containing this polygon."""
        min_n = min(p.northing for p in self._points)
        max_n = max(p.northing for p in self._points)
        min_e = min(p.easting for p in self._points)
        max_e = max(p.easting for p in self._points)
        return TwoDimensionalEnvelope(min_n, max_n, min_e, max_e)

class ComplexPolygon(Geometry):
    """A polygon composed of connected linear elements forming a closed ring.
    
    A complex polygon is a closed sequence of linear elements that can include
    both line segments and circular arcs. The polygon must be closed
    (end point of last element equals start point of first element)
    and must not be self-intersecting.
    """
    
    __slots__ = ['_elements', '_area']
    
    def __init__(
        self,
        elements: List[LinearGeometry],
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """Initialize a complex polygon.
        
        Args:
            elements: List of linear elements (LineSegment or CircularArc)
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name
            dxf_handle: Optional DXF handle for import/export persistence
            
        Raises:
            ValidationError: If fewer than 3 elements are provided
            TopologyError: If elements are not connected or polygon is not closed
            TopologyError: If polygon is self-intersecting
        """
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        
        if len(elements) < 3:
            raise ValidationError("ComplexPolygon must have at least 3 elements")
            
        # Validate elements are connected and polygon is closed
        for i in range(len(elements)):
            next_i = (i + 1) % len(elements)
            if not elements[i].end_point.is_coincident(elements[next_i].start_point):
                raise TopologyError(
                    f"Elements must be connected end-to-end. "
                    f"Discontinuity between elements {i} and {next_i}"
                )
        
        self._elements = elements
        self._area: Optional[float] = None
        
        # TODO: Add self-intersection check
    
    @property
    def elements(self) -> List[LinearGeometry]:
        """Get the list of linear elements composing the polygon."""
        return self._elements
    
    def perimeter(self) -> float:
        """Calculate the perimeter length of the polygon."""
        return sum(element.length() for element in self._elements)
    
    def area(self) -> float:
        """Calculate the area of the polygon.
        
        For polygons with circular arcs, the area is calculated by:
        1. Computing the area as if all segments were straight lines
        2. Adding/subtracting the area of circular segments based on orientation
        """
        if self._area is None:
            # TODO: Implement area calculation for complex polygons
            # This requires careful handling of circular segments
            raise NotImplementedError(
                "Area calculation for complex polygons is not yet implemented"
            )
        return self._area
    
    def _calculate_envelope_2d(self) -> TwoDimensionalEnvelope:
        """Calculate the 2D envelope containing this polygon."""
        # Start with the envelope of the first element
        envelope = self._elements[0].envelope_2d
        
        # Expand to include all other elements
        for element in self._elements[1:]:
            elem_env = element.envelope_2d
            envelope = TwoDimensionalEnvelope(
                min(envelope.min_northing, elem_env.min_northing),
                max(envelope.max_northing, elem_env.max_northing),
                min(envelope.min_easting, elem_env.min_easting),
                max(envelope.max_easting, elem_env.max_easting)
            )
        
        return envelope


class GeometryCollection(Geometry):
    """
    A collection of related geometries.
    
    This class provides a container for managing multiple geometry objects
    of potentially different types. It supports iteration, filtering,
    spatial queries, and aggregate operations.
    
    Duplicates are allowed - the same geometry object can be added
    multiple times.
    
    Attributes:
        geometries: List of geometry objects in the collection
        envelope_2d: The 2D envelope encompassing all geometries
        count: Number of geometries in the collection
        is_empty: Whether the collection is empty
    
    Example:
        >>> collection = GeometryCollection()
        >>> collection.add(Point(100, 200, 50))
        >>> collection.add(LineSegment(Point(0, 0, 0), Point(10, 0, 0)))
        >>> print(collection.count)
        2
        >>> envelope = collection.envelope_2d
    """
    
    __slots__ = ['_geometries', '_envelope', '_spatial_index']
    
    def __init__(
        self,
        geometries: Optional[List[Geometry]] = None,
        use_spatial_index: bool = False,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        dxf_handle: Optional[str] = None
    ):
        """
        Initialize a geometry collection.
        
        Args:
            geometries: Optional list of geometry objects to initialize with
            use_spatial_index: If True, build a QuadTree spatial index for
            uuid: Optional 16-character unique identifier (auto-generated if None)
            name: Optional user-provided name
            dxf_handle: Optional DXF handle for import/export persistence
                             efficient spatial queries (useful for large
                             collections)
        
        Raises:
            ValidationError: If any item in geometries is not a Geometry
        """
        super().__init__(uuid=uuid, name=name, dxf_handle=dxf_handle)
        
        self._geometries: List[Geometry] = []
        self._envelope: Optional[TwoDimensionalEnvelope] = None
        self._spatial_index: Optional[QuadTreeIndex] = None
        
        if geometries:
            for geom in geometries:
                # Accept both Geometry and Point objects
                if not isinstance(geom, (Geometry, Point)):
                    raise ValidationError(
                        f"All items must be Geometry or Point instances, "
                        f"got {type(geom)}"
                    )
                self._geometries.append(geom)
        
        if use_spatial_index and self._geometries:
            self._build_spatial_index()
    
    @property
    def geometries(self) -> List[Geometry]:
        """Get a copy of the list of geometries."""
        return self._geometries.copy()
    
    @property
    def count(self) -> int:
        """Get the number of geometries in the collection."""
        return len(self._geometries)
    
    @property
    def is_empty(self) -> bool:
        """Check if the collection is empty."""
        return len(self._geometries) == 0
    
    @property
    def envelope_2d(self) -> TwoDimensionalEnvelope:
        """
        Get the 2D envelope encompassing all geometries.
        
        Returns:
            The envelope containing all geometries, or empty envelope if no geometries
        """
        if self._envelope is None:
            if self.is_empty:
                # Return an empty envelope for empty collections
                self._envelope = TwoDimensionalEnvelope(0, 0, 0, 0)
            else:
                self._envelope = self._calculate_envelope()
        return self._envelope
    
    def add(self, geometry: Geometry) -> 'GeometryCollection':
        """
        Add a geometry to the collection.
        
        Args:
            geometry: The geometry to add
        
        Returns:
            Self (for method chaining)
        
        Raises:
            ValidationError: If geometry is not a Geometry instance
        """
        # Accept Geometry and Point instances
        if not isinstance(geometry, (Geometry, Point)):
            raise ValidationError(
                f"Can only add Geometry or Point instances, "
                f"got {type(geometry)}"
            )
        
        self._geometries.append(geometry)
        self._envelope = None  # Invalidate cached envelope
        
        if self._spatial_index:
            self._spatial_index.insert(geometry)
        
        return self
    
    def add_all(self, geometries: List[Geometry]) -> 'GeometryCollection':
        """
        Add multiple geometries to the collection.
        
        Args:
            geometries: List of geometries to add
        
        Returns:
            Self (for method chaining)
        """
        for geom in geometries:
            self.add(geom)
        return self
    
    def remove(self, geometry: Geometry) -> bool:
        """
        Remove the first occurrence of a geometry from the collection.
        
        Args:
            geometry: The geometry to remove
        
        Returns:
            True if geometry was found and removed, False otherwise
        """
        try:
            self._geometries.remove(geometry)
            self._envelope = None
            self._spatial_index = None  # Invalidate spatial index
            return True
        except ValueError:
            return False
    
    def remove_at(self, index: int) -> Geometry:
        """
        Remove and return the geometry at the specified index.
        
        Args:
            index: The index of the geometry to remove
        
        Returns:
            The removed geometry
        
        Raises:
            IndexError: If index is out of range
        """
        geometry = self._geometries.pop(index)
        self._envelope = None
        self._spatial_index = None
        return geometry
    
    def clear(self) -> None:
        """Remove all geometries from the collection."""
        self._geometries.clear()
        self._envelope = None
        self._spatial_index = None
    
    def __iter__(self) -> Iterator[Geometry]:
        """Iterate over geometries in the collection."""
        return iter(self._geometries)
    
    def __len__(self) -> int:
        """Get the number of geometries in the collection."""
        return len(self._geometries)
    
    def __getitem__(self, index: int) -> Geometry:
        """
        Get geometry at the specified index.
        
        Args:
            index: The index of the geometry to retrieve
        
        Returns:
            The geometry at the specified index
        
        Raises:
            IndexError: If index is out of range
        """
        return self._geometries[index]
    
    def __contains__(self, geometry: Geometry) -> bool:
        """Check if a geometry is in the collection."""
        return geometry in self._geometries
    
    def filter_by_type(self, geometry_type: type) -> 'GeometryCollection':
        """
        Create a new collection with only geometries of the specified type.
        
        Args:
            geometry_type: The type to filter by (e.g., Point, LineSegment)
        
        Returns:
            A new GeometryCollection with filtered geometries
        
        Example:
            >>> points = collection.filter_by_type(Point)
            >>> lines = collection.filter_by_type(LineSegment)
        """
        filtered = [g for g in self._geometries if isinstance(g, geometry_type)]
        return GeometryCollection(filtered)
    
    def filter(
        self, predicate: Callable[[Geometry], bool]
    ) -> 'GeometryCollection':
        """
        Create a new collection with geometries matching the predicate.
        
        Args:
            predicate: A function that takes a geometry and returns True/False
        
        Returns:
            A new GeometryCollection with filtered geometries
        
        Example:
            >>> # Get all geometries with elevation > 100
            >>> high = collection.filter(
            ...     lambda g: hasattr(g, 'elevation') and g.elevation > 100
            ... )
        """
        filtered = [g for g in self._geometries if predicate(g)]
        return GeometryCollection(filtered)
    
    def query_envelope(
        self,
        envelope: TwoDimensionalEnvelope
    ) -> 'GeometryCollection':
        """
        Query geometries that intersect with the given envelope.
        
        Args:
            envelope: The envelope to query
        
        Returns:
            A new GeometryCollection with geometries intersecting the envelope
        
        Note:
            If spatial index is enabled, this uses the QuadTree for efficiency.
            Otherwise, it checks all geometries.
        """
        if self._spatial_index:
            results = self._spatial_index.query(envelope)
            return GeometryCollection(results)
        else:
            # Fallback: check all geometries
            results = [
                g for g in self._geometries
                if g.envelope_2d and g.envelope_2d.intersects(envelope)
            ]
            return GeometryCollection(results)
    
    def get_by_types(self, *geometry_types: type) -> 'GeometryCollection':
        """
        Get geometries matching any of the specified types.
        
        Args:
            *geometry_types: Variable number of geometry types
        
        Returns:
            A new GeometryCollection with matching geometries
        
        Example:
            >>> linear = collection.get_by_types(LineSegment, CircularArc)
        """
        filtered = [
            g for g in self._geometries
            if isinstance(g, geometry_types)
        ]
        return GeometryCollection(filtered)
    
    def _calculate_envelope(self) -> TwoDimensionalEnvelope:
        """Calculate the envelope encompassing all geometries."""
        if self.is_empty:
            return TwoDimensionalEnvelope(0, 0, 0, 0)
        
        # Collect all envelopes
        envelopes = [g.envelope_2d for g in self._geometries]
        
        if not envelopes:
            return TwoDimensionalEnvelope(0, 0, 0, 0)
        
        # Find min/max across all envelopes
        min_northing = min(e.min_northing for e in envelopes)
        max_northing = max(e.max_northing for e in envelopes)
        min_easting = min(e.min_easting for e in envelopes)
        max_easting = max(e.max_easting for e in envelopes)
        
        return TwoDimensionalEnvelope(
            min_northing, max_northing, min_easting, max_easting
        )
    
    def get_type_counts(self) -> Dict[str, int]:
        """
        Get a count of geometries by type.
        
        Returns:
            Dictionary mapping type names to counts
        
        Example:
            >>> counts = collection.get_type_counts()
            >>> # {'Point': 10, 'LineSegment': 5, 'CircularArc': 3}
        """
        counts: Dict[str, int] = {}
        for geom in self._geometries:
            type_name = type(geom).__name__
            counts[type_name] = counts.get(type_name, 0) + 1
        return counts
    
    def total_length(self) -> float:
        """
        Calculate the total length of all linear geometries.
        
        Returns:
            Sum of lengths of all geometries that have a length() method
        
        Note:
            Points and polygons are excluded (no length concept)
        """
        total = 0.0
        for geom in self._geometries:
            if hasattr(geom, 'length') and callable(geom.length):
                total += geom.length()
        return total
    
    def total_area(self) -> float:
        """
        Calculate the total area of all polygon geometries.
        
        Returns:
            Sum of areas of all geometries that have an area() method
        
        Note:
            Points, lines, and arcs are excluded (no area concept)
        """
        total = 0.0
        for geom in self._geometries:
            if hasattr(geom, 'area') and callable(geom.area):
                total += geom.area()
        return total
    
    def _build_spatial_index(self) -> None:
        """Build a QuadTree spatial index for the collection."""
        if self.is_empty:
            return
        
        envelope = self.envelope_2d
        if envelope:
            self._spatial_index = QuadTreeIndex(envelope)
            for geom in self._geometries:
                self._spatial_index.insert(geom)
    
    def enable_spatial_index(self) -> None:
        """Enable spatial indexing for efficient spatial queries."""
        if not self._spatial_index:
            self._build_spatial_index()
    
    def disable_spatial_index(self) -> None:
        """Disable spatial indexing."""
        self._spatial_index = None
    
    @property
    def has_spatial_index(self) -> bool:
        """Check if spatial indexing is enabled."""
        return self._spatial_index is not None
    
    def transform(
        self,
        operation: Callable[[Geometry], Geometry]
    ) -> 'GeometryCollection':
        """
        Apply a transformation to all geometries in the collection.
        
        Args:
            operation: A function that takes a geometry and returns a
                      transformed geometry
        
        Returns:
            A new GeometryCollection with transformed geometries
        
        Example:
            >>> from plana_figura import GeometryManipulator
            >>> # Shift all points up by 10 units
            >>> shifted = collection.transform(
            ...     lambda g: GeometryManipulator.shift_elevation_point(g, 10)
            ...     if isinstance(g, Point) else g
            ... )
        """
        transformed = [operation(g) for g in self._geometries]
        return GeometryCollection(transformed)
    
    def transform_in_place(
        self,
        operation: Callable[[Geometry], Geometry]
    ) -> 'GeometryCollection':
        """
        Apply a transformation to all geometries, replacing them in place.
        
        Args:
            operation: A function that takes a geometry and returns a
                      transformed geometry
        
        Returns:
            Self (for method chaining)
        
        Example:
            >>> from plana_figura import GeometryManipulator
            >>> collection.transform_in_place(
            ...     lambda g: GeometryManipulator.shift_elevation_point(g, 10)
            ...     if isinstance(g, Point) else g
            ... )
        """
        self._geometries = [operation(g) for g in self._geometries]
        self._envelope = None
        self._spatial_index = None
        return self
    
    def copy(self) -> 'GeometryCollection':
        """
        Create a shallow copy of the collection.
        
        Returns:
            A new GeometryCollection with the same geometries
        
        Note:
            The geometries themselves are not copied (shallow copy)
        """
        return GeometryCollection(self._geometries.copy())
    
    def __repr__(self) -> str:
        """Return a string representation of the collection."""
        type_counts = self.get_type_counts()
        counts_str = ", ".join(f"{k}: {v}" for k, v in type_counts.items())
        return f"GeometryCollection(count={self.count}, types=[{counts_str}])"
    
    def __str__(self) -> str:
        """Return a user-friendly string representation."""
        return f"GeometryCollection with {self.count} geometries"
    
    def __eq__(self, other: object) -> bool:
        """Check equality with another GeometryCollection."""
        if not isinstance(other, GeometryCollection):
            return NotImplemented
        return self._geometries == other._geometries
    
    def _calculate_envelope_2d(self) -> TwoDimensionalEnvelope:
        """Calculate the 2D envelope (required by Geometry base class)."""
        return self._calculate_envelope()
