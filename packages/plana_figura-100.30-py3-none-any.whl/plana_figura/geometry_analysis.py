"""
Geometric analysis functions.

This module provides functions for analyzing geometric relationships
and properties (distances, containment, closest points).
"""

import math
from typing import Optional

from plana_figura.geometry import Point, LineSegment
from plana_figura.composite import SimplePolygon
from plana_figura.grid import Grid as TheGrid


# ============================================================================
# Point-Line Analysis
# ============================================================================

def closest_point_on_line(
    point: Point,
    line: LineSegment,
    extend_line: bool = False,
    grid: Optional[TheGrid] = None
) -> Point:
    """
    Find closest point on line to given point.

    Args:
        point: Point to measure from
        line: Line segment
        extend_line: If True, treat as infinite line
        grid: Optional grid for the result point

    Returns:
        Closest point on line

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> point = Point(50, 25, 0)
        >>> line = LineSegment(Point(0, 0, 0), Point(100, 0, 0))
        >>> closest = closest_point_on_line(point, line)
        >>> # Returns Point(50, 0, 0)
    """
    # Get line direction vector
    dx = line.end_point.easting - line.start_point.easting
    dy = line.end_point.northing - line.start_point.northing

    # Get vector from line start to point
    px = point.easting - line.start_point.easting
    py = point.northing - line.start_point.northing

    # Calculate parameter t (projection of point onto line)
    line_length_squared = dx * dx + dy * dy

    if line_length_squared < 1e-10:
        # Line is essentially a point
        return Point(
            line.start_point.northing,
            line.start_point.easting,
            line.start_point.elevation,
            grid=grid
        )

    t = (px * dx + py * dy) / line_length_squared

    # Clamp t to [0, 1] if not extending line
    if not extend_line:
        t = max(0.0, min(1.0, t))

    # Calculate closest point
    x = line.start_point.easting + t * dx
    y = line.start_point.northing + t * dy
    z = line.start_point.elevation + t * (
        line.end_point.elevation - line.start_point.elevation
    )

    return Point(y, x, z, grid=grid)


def distance_point_to_line(
    point: Point,
    line: LineSegment,
    extend_line: bool = False,
    grid: Optional[TheGrid] = None
) -> float:
    """
    Calculate perpendicular distance from point to line.

    Args:
        point: Point to measure from
        line: Line segment
        extend_line: If True, treat as infinite line
        grid: Optional grid for calculations

    Returns:
        Perpendicular distance

    Example:
        >>> from plana_figura import Point, LineSegment
        >>> point = Point(50, 25, 0)
        >>> line = LineSegment(Point(0, 0, 0), Point(100, 0, 0))
        >>> dist = distance_point_to_line(point, line)
        >>> # Returns 25.0
    """
    # Get closest point on line
    closest = closest_point_on_line(point, line, extend_line, grid)

    # Calculate distance
    dx = point.easting - closest.easting
    dy = point.northing - closest.northing

    return math.sqrt(dx * dx + dy * dy)


def distance_point_to_point(
    point1: Point,
    point2: Point,
    horizontal_only: bool = False
) -> float:
    """
    Calculate distance between two points.

    Args:
        point1: First point
        point2: Second point
        horizontal_only: If True, ignore elevation (2D distance)

    Returns:
        Distance between points

    Example:
        >>> from plana_figura import Point
        >>> p1 = Point(0, 0, 0)
        >>> p2 = Point(100, 0, 10)
        >>> dist_3d = distance_point_to_point(p1, p2)
        >>> dist_2d = distance_point_to_point(p1, p2, horizontal_only=True)
    """
    dx = point2.easting - point1.easting
    dy = point2.northing - point1.northing

    if horizontal_only:
        return math.sqrt(dx * dx + dy * dy)
    else:
        dz = point2.elevation - point1.elevation
        return math.sqrt(dx * dx + dy * dy + dz * dz)


# ============================================================================
# Point-Polygon Analysis
# ============================================================================

def point_in_polygon(
    point: Point,
    polygon: SimplePolygon,
    grid: Optional[TheGrid] = None
) -> bool:
    """
    Test if point is inside polygon (2D test, ignores elevation).

    Uses the ray casting algorithm: cast a ray from the point to infinity
    and count how many times it crosses the polygon boundary. If odd, the
    point is inside; if even, it's outside.

    Args:
        point: Point to test
        polygon: Polygon to test against
        grid: Optional grid for calculations

    Returns:
        True if point is inside polygon

    Example:
        >>> from plana_figura import Point
        >>> from plana_figura.geometry_builders import create_rectangle
        >>> point = Point(50, 50, 0)
        >>> square = create_rectangle(Point(0, 0, 0), 100.0, 100.0)
        >>> inside = point_in_polygon(point, square)
        >>> # Returns True
    """
    # Get polygon vertices
    vertices = polygon.points
    n = len(vertices) - 1  # Exclude closing point

    # Ray casting algorithm
    inside = False
    px, py = point.easting, point.northing

    for i in range(n):
        # Get edge vertices
        x1, y1 = vertices[i].easting, vertices[i].northing
        x2, y2 = vertices[i + 1].easting, vertices[i + 1].northing

        # Check if ray crosses edge
        if ((y1 > py) != (y2 > py)) and (
            px < (x2 - x1) * (py - y1) / (y2 - y1) + x1
        ):
            inside = not inside

    return inside


def point_on_polygon_boundary(
    point: Point,
    polygon: SimplePolygon,
    tolerance: float = 1e-6,
    grid: Optional[TheGrid] = None
) -> bool:
    """
    Test if point is on the boundary of a polygon.

    Args:
        point: Point to test
        polygon: Polygon to test against
        tolerance: Distance tolerance for "on boundary"
        grid: Optional grid for calculations

    Returns:
        True if point is on polygon boundary

    Example:
        >>> from plana_figura import Point
        >>> from plana_figura.geometry_builders import create_rectangle
        >>> point = Point(0, 50, 0)  # On left edge
        >>> square = create_rectangle(Point(0, 0, 0), 100.0, 100.0)
        >>> on_boundary = point_on_polygon_boundary(point, square)
        >>> # Returns True
    """
    # Check each edge
    vertices = polygon.points
    n = len(vertices) - 1  # Exclude closing point

    for i in range(n):
        # Create line segment for this edge
        edge = LineSegment(vertices[i], vertices[i + 1])

        # Check distance to edge
        dist = distance_point_to_line(point, edge, extend_line=False, grid=grid)

        if dist < tolerance:
            return True

    return False
