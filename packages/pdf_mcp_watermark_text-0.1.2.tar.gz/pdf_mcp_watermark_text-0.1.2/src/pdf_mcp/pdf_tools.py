from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import fitz  # type: ignore

from .utils import add_pdf_extension, contains_chinese, ensure_parent_dir, resolve_output_path


@dataclass
class TextWatermarkResult:
    output_path: Path
    page_count: int
    watermark_text: str
    watermark_type: str


def _to_path(path_like: str) -> Path:
    return Path(path_like).expanduser().resolve()


 


def add_text_watermark(
    input_path: str,
    output_path: str,
    watermark_text: str,
    opacity: float = 0.3,
    font_size: int = 24,
    position: str = "center",
    rotation: float = 0.0,
    color: tuple[float, float, float] = (0.5, 0.5, 0.5),
    layout: str = "single",
) -> TextWatermarkResult:
    """直接在PDF上添加文字水印（文字可选择、可复制）。

    Args:
        input_path: 输入PDF文件路径
        output_path: 输出PDF文件路径
        watermark_text: 水印文字内容
        opacity: 不透明度 (0.0-1.0)，通过调整颜色亮度实现
        font_size: 字体大小
        position: 位置："center", "top-left", "top-right", "bottom-left", "bottom-right"
        rotation: 旋转角度
        color: RGB颜色元组 (0.0-1.0)
        layout: 布局模式："single"(单个), "corners"(四角), "tile"(平铺)

    Returns:
        TextWatermarkResult: 添加水印的结果
    """
    source_path = _to_path(input_path)
    if not source_path.exists():
        raise FileNotFoundError(f"文件不存在: {source_path}")
    if source_path.suffix.lower() != ".pdf":
        raise ValueError("输入文件必须为PDF")

    if not watermark_text.strip():
        raise ValueError("水印文字不能为空")

    doc = fitz.open(source_path)
    page_count = doc.page_count
    if page_count == 0:
        raise ValueError("输入PDF为空")

    # 检测是否包含中文，如果包含则使用中文字体
    font_name = None
    if contains_chinese(watermark_text):
        # PyMuPDF 内置的中文字体名称
        # china-s: 简体中文 (Simplified Chinese)
        # china-t: 繁体中文 (Traditional Chinese)
        # china-ss: 简体中文宋体
        # china-ts: 繁体中文宋体
        font_name = "china-s"

    # 限制透明度和颜色值范围，通过提高颜色亮度来模拟透明度
    opacity = max(0.0, min(opacity, 1.0))
    # 将颜色调亮以模拟透明效果：越透明，颜色越接近白色
    # 修复：使用正确的透明度计算，让水印更淡
    adjusted_color = tuple(
        c + (1.0 - c) * (1.0 - opacity)
        for c in color
    )
    
    # PyMuPDF 的 insert_text 只支持 0, 90, 180, 270 度旋转
    # 对于其他角度，需要使用 TextWriter
    use_textwriter = rotation not in [0, 90, 180, 270]
    
    for page in doc:
        rect = page.rect
        text_width = fitz.get_text_length(watermark_text, fontsize=font_size)
        text_height = font_size
        
        if use_textwriter:
            # 使用 TextWriter 支持任意角度旋转
            tw = fitz.TextWriter(rect)
            
        if layout == "corners":
            # 四角模式
            positions = [
                (50, rect.height - 50),  # 左上
                (rect.width - text_width - 50, rect.height - 50),  # 右上
                (50, 50 + text_height),  # 左下
                (rect.width - text_width - 50, 50 + text_height),  # 右下
            ]
            for x, y in positions:
                if use_textwriter:
                    if font_name:
                        tw.append(
                            fitz.Point(x, y),
                            watermark_text,
                            fontsize=font_size,
                            fontname=font_name,
                        )
                    else:
                        tw.append(
                            fitz.Point(x, y),
                            watermark_text,
                            fontsize=font_size,
                        )
                else:
                    if font_name:
                        page.insert_text(
                            fitz.Point(x, y),
                            watermark_text,
                            fontsize=font_size,
                            fontname=font_name,
                            color=adjusted_color,
                            rotate=int(rotation),
                            overlay=True,
                        )
                    else:
                        page.insert_text(
                            fitz.Point(x, y),
                            watermark_text,
                            fontsize=font_size,
                            color=adjusted_color,
                            rotate=int(rotation),
                            overlay=True,
                        )
        
        elif layout == "tile":
            # 平铺模式 - 增加间距，避免水印过于密集
            # 使用固定的最小间距，确保中文水印不会太密集
            min_spacing_x = 200  # 最小水平间距（像素）
            min_spacing_y = 100  # 最小垂直间距（像素）
            spacing_x = max(text_width * 3.0, min_spacing_x)
            spacing_y = max(text_height * 6.0, min_spacing_y)

            # 计算需要多少行和列
            cols = int(rect.width / spacing_x) + 1
            rows = int(rect.height / spacing_y) + 1
            
            for row in range(rows):
                for col in range(cols):
                    x = col * spacing_x
                    y = row * spacing_y + text_height
                    
                    # 确保在页面范围内
                    if x < rect.width and y < rect.height:
                        if use_textwriter:
                            if font_name:
                                tw.append(
                                    fitz.Point(x, y),
                                    watermark_text,
                                    fontsize=font_size,
                                    fontname=font_name,
                                )
                            else:
                                tw.append(
                                    fitz.Point(x, y),
                                    watermark_text,
                                    fontsize=font_size,
                                )
                        else:
                            if font_name:
                                page.insert_text(
                                    fitz.Point(x, y),
                                    watermark_text,
                                    fontsize=font_size,
                                    fontname=font_name,
                                    color=adjusted_color,
                                    rotate=int(rotation),
                                    overlay=True,
                                )
                            else:
                                page.insert_text(
                                    fitz.Point(x, y),
                                    watermark_text,
                                    fontsize=font_size,
                                    color=adjusted_color,
                                    rotate=int(rotation),
                                    overlay=True,
                                )
        
        else:
            # 单个位置模式
            pos_map = {
                "center": (rect.width / 2 - text_width / 2, rect.height / 2),
                "top-left": (50, rect.height - 50),
                "top-right": (rect.width - text_width - 50, rect.height - 50),
                "bottom-left": (50, 50 + text_height),
                "bottom-right": (rect.width - text_width - 50, 50 + text_height),
            }
            
            x, y = pos_map.get(position, pos_map["center"])
            if use_textwriter:
                if font_name:
                    tw.append(
                        fitz.Point(x, y),
                        watermark_text,
                        fontsize=font_size,
                        fontname=font_name,
                    )
                else:
                    tw.append(
                        fitz.Point(x, y),
                        watermark_text,
                        fontsize=font_size,
                    )
            else:
                if font_name:
                    page.insert_text(
                        fitz.Point(x, y),
                        watermark_text,
                        fontsize=font_size,
                        fontname=font_name,
                        color=adjusted_color,
                        rotate=int(rotation),
                        overlay=True,
                    )
                else:
                    page.insert_text(
                        fitz.Point(x, y),
                        watermark_text,
                        fontsize=font_size,
                        color=adjusted_color,
                        rotate=int(rotation),
                        overlay=True,
                    )
        
        # 如果使用 TextWriter，应用颜色、旋转并写入页面
        if use_textwriter:
            tw.write_text(page, color=adjusted_color, overlay=True, rotate=rotation)
    
    resolved_output_path = add_pdf_extension(resolve_output_path(source_path, output_path))
    ensure_parent_dir(resolved_output_path)
    doc.save(resolved_output_path)
    doc.close()
    
    layout_desc = {
        "single": "单个位置",
        "corners": "四角",
        "tile": "平铺"
    }.get(layout, "单个位置")
    
    watermark_type = f"{'中文' if contains_chinese(watermark_text) else ''}文字水印({layout_desc})"
    
    return TextWatermarkResult(
        output_path=resolved_output_path,
        page_count=page_count,
        watermark_text=watermark_text,
        watermark_type=watermark_type,
    )
