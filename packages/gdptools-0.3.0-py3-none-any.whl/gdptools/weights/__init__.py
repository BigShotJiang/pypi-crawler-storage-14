"""Placeholder __init__.py for weights package."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())
