"""Placeholder __init__.py for agg package."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())
