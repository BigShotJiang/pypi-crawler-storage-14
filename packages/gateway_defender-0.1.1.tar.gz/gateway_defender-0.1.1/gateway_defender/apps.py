from django.apps import AppConfig


class AccountsConfig(AppConfig):
    name = 'gateway_defender'
    label = 'accounts'
