##############################################################################
#
# Copyright (c) 2002 Zope Foundation and Contributors.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################

from .DT_Util import name_param
from .DT_Util import parse_params


class ReturnTag:

    name = 'return'
    expr = None

    def __init__(self, args, encoding=None):
        args = parse_params(args, name='', expr='')
        name, expr = name_param(args, 'var', 1)
        self.__name__ = name
        self.expr = expr
        self.encoding = encoding

    def render(self, md):
        if self.expr is None:
            val = md[self.__name__]
        else:
            val = self.expr.eval(md)

        raise DTReturn(val)

    __call__ = render


class DTReturn(Exception):

    def __init__(self, v):
        self.v = v
