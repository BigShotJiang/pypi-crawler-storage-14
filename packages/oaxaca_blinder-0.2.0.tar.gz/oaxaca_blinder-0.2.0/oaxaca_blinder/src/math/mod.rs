pub mod ols;
pub mod normalization;
pub mod quantile_regression;
pub mod rif;
pub mod diagnostics;
pub mod kde;
pub mod logit;
pub mod probit;
