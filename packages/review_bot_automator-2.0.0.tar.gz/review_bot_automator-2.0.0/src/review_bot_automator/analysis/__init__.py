"""Conflict analysis and detection."""
