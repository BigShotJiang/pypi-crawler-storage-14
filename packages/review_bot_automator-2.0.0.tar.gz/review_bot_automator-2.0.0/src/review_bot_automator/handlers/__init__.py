"""File-type specific handlers for conflict resolution."""
