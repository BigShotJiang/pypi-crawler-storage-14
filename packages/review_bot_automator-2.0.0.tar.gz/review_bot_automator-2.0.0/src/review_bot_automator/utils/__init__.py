"""Utility modules for the conflict resolver.

This package contains utility functions and helpers used across
the conflict resolver components.
"""
