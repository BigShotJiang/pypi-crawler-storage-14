"""GitHub, CodeRabbit, and other integrations."""
