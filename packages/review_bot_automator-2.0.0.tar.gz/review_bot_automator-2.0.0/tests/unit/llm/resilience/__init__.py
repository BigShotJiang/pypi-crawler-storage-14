"""Tests for LLM resilience patterns."""
