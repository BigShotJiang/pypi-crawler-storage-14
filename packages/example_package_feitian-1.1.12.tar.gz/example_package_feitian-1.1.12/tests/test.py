

import numpy as np

#这里就是引入包了
from example_package_fetian import *

print(add(1,2))
hello()
