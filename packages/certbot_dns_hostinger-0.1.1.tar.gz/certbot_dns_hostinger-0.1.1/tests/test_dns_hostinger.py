#!/usr/bin/env python3
"""Basic tests for certbot-dns-hostinger plugin."""

import os
import tempfile
import unittest
from unittest.mock import patch, MagicMock

# Mock certbot imports for testing
with patch.dict(
    "sys.modules",
    {
        "certbot": MagicMock(),
        "certbot.errors": MagicMock(),
        "certbot.plugins": MagicMock(),
        "certbot.plugins.dns_common": MagicMock(),
        "certbot.compat": MagicMock(),
    },
):
    # Create a mock Authenticator class
    class MockAuthenticator:
        description = "Mock DNS Authenticator for Hostinger"
        ttl = 60

    # Mock the module
    import sys

    sys.modules["src.certbot_dns_hostinger._internal.dns_hostinger"] = MagicMock()
    sys.modules[
        "src.certbot_dns_hostinger._internal.dns_hostinger"
    ].Authenticator = MockAuthenticator

    try:
        from src.certbot_dns_hostinger._internal.dns_hostinger import Authenticator

        IMPORT_SUCCESS = True
    except ImportError:
        IMPORT_SUCCESS = False


class TestDNSHostinger(unittest.TestCase):
    """Test cases for DNS Hostinger plugin."""

    def test_plugin_structure(self):
        """Test that the plugin directory structure is correct."""
        # Check if src directory exists
        self.assertTrue(os.path.exists("src"))
        self.assertTrue(os.path.exists("src/certbot_dns_hostinger"))
        self.assertTrue(os.path.exists("src/certbot_dns_hostinger/_internal"))

        # Check if main plugin file exists
        self.assertTrue(os.path.exists("src/certbot_dns_hostinger/_internal/dns_hostinger.py"))

        # Check if __init__.py files exist
        self.assertTrue(os.path.exists("src/certbot_dns_hostinger/__init__.py"))
        self.assertTrue(os.path.exists("src/certbot_dns_hostinger/_internal/__init__.py"))

    def test_setup_files(self):
        """Test that setup files exist and are valid."""
        # Check if setup.py exists
        self.assertTrue(os.path.exists("setup.py"))

        # Check if pyproject.toml exists
        self.assertTrue(os.path.exists("pyproject.toml"))

        # Check if MANIFEST.in exists
        self.assertTrue(os.path.exists("MANIFEST.in"))

        # Check if README.rst exists
        self.assertTrue(os.path.exists("README.rst"))

    def test_credentials_file_creation(self):
        """Test creating a credentials file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("dns_hostinger_api_token = test_token_123\n")
            temp_file = f.name

        try:
            # Check if file was created
            self.assertTrue(os.path.exists(temp_file))

            # Check content
            with open(temp_file, "r") as f:
                content = f.read()
                self.assertIn("dns_hostinger_api_token = test_token_123", content)
        finally:
            # Cleanup
            os.unlink(temp_file)

    def test_setup_py_version(self):
        """Test that setup.py exists and is valid."""
        with open("setup.py", "r") as f:
            content = f.read()
            # Check if setup.py is not empty
            self.assertNotEqual(content.strip(), "")
            # Check if it imports setuptools
            self.assertIn("from setuptools import setup", content)

    @unittest.skipUnless(IMPORT_SUCCESS, "Plugin import failed")
    def test_authenticator_class(self):
        """Test that Authenticator class can be imported."""
        self.assertTrue(hasattr(Authenticator, "description"))
        self.assertTrue(hasattr(Authenticator, "ttl"))


if __name__ == "__main__":
    unittest.main()
