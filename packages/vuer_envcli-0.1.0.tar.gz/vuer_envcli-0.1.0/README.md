# Vuer Hub Environment CLI

`vuer.env` is a lightweight CLI for uploading and downloading environment
packages to/from a Vuer Hub backend. It is built on top
of [`params-proto`](https://github.com/episodeyang/params_proto) and works
great for CI/CD pipelines as well as local development workflows.

## Features

- `push` – upload a packaged environment file with metadata (name, version,
  visibility, etc.)
- `pull` – download an environment by `environmentId`
- Automatic JWT handling via env variable (`VUER_AUTH_TOKEN`)
- Configurable API base URL (`VUER_API_BASE_URL`)
- Friendly error messages and helpful command-level `--help` output

## Installation

```bash
pip install vuer-envcli
```

> During local development you can install the project in editable mode:
> ```bash
> cd /envcli
> pip install -e .
> ```

## Environment Variables

| Variable            | Required | Description                                   |
|---------------------|----------|-----------------------------------------------|
| `VUER_AUTH_TOKEN`   | ✅        | JWT token used for all authenticated requests |
| `VUER_API_BASE_URL` | ✅        | Base URL of the Vuer Hub API                  |

```bash
export VUER_AUTH_TOKEN="your-jwt-token"
export VUER_API_BASE_URL="https://api.xxxx.com"
```

## Usage Overview

```bash
vuer.env push --file <path> --name <name> --version <semver> [options...]
vuer.env pull --id <environmentId> [--output <dir>] [--filename <name>]
```

Run `vuer.env --help`, `vuer.env push --help`, or `vuer.env pull --help` to get
detailed descriptions of every option.

## Push Command

Upload a packaged environment:

```bash
vuer.env push \
  --file ./build/my-env.zip \
  --name demo-env \
  --version v1.2.3 \
  --description "Demo package" \
  --env-type isaac \
  --visibility PUBLIC
```

### Push Flags

| Flag                 | Required | Description                                                  |
|----------------------|----------|--------------------------------------------------------------|
| `--file PATH`        | ✅        | Path to the package file (zip/tar/etc.)                      |
| `--name NAME`        | ✅        | Environment name without spaces                              |
| `--version SEMVER`   | ✅        | Semver-compliant version string (`v1.2.3`, `v2.0.0-beta`, …) |
| `--description TEXT` | ❌        | Optional text                                                |
| `--env-type TYPE`    | ❌        | Optional Example: `isaac`, `mujoco`                          |
| `--visibility VIS`   | ❌        | Optional `PUBLIC` (default), `PRIVATE`                       |

## Pull Command

Download an environment by ID:

```bash
vuer.env pull \
  --id 252454509945688064 \
  --output ./downloads \
  --filename demo-env.zip
```

If `--filename` is omitted, the tool will try to derive the original filename
from the server’s `Content-Disposition` header. Files are stored under
the `downloads/` directory by default.

### Pull Flags

| Flag                  | Required | Description                                 |
|-----------------------|----------|---------------------------------------------|
| `--id ENVIRONMENT_ID` | ✅        | Target environment’s `environmentId`        |
| `--output DIR`        | ❌        | Destination directory (default `downloads`) |
| `--filename NAME`     | ❌        | Override for the saved filename             |

## Error Handling

All network and file-system errors are surfaced as readable messages (prefixed
with `[ERROR]`). Typical causes:

- Invalid JWT → ensure `VUER_AUTH_TOKEN` is set and not expired.
- Duplicate name/version on `push` → server enforces `(name, versionId)`
  uniqueness.
- Missing file path on `push` or invalid target directory on `pull`.

## Development

1. Clone the main repository and navigate into the CLI folder.
2. Install dependencies: `pip install -e .`
3. Run the CLI locally using `vuer.env ...`.


