import os
import sys
from pathlib import Path
from typing import Dict, Optional

import requests
from params_proto import ParamsProto, Proto


def _normalize_cli_args() -> None:
    """Allow users to use underscores in flag names by converting to
    hyphens."""
    normalized = [sys.argv[0]]
    for token in sys.argv[1:]:
        if not token.startswith("--"):
            normalized.append(token)
            continue

        if "=" in token:
            key, value = token.split("=", 1)
            key = key.replace("_", "-")
            normalized.append(f"{key}={value}")
        else:
            normalized.append(token.replace("_", "-"))

    sys.argv = normalized


HELP_FLAGS = {"-h", "--help"}
_normalize_cli_args()


def print_root_help() -> None:
    print(
        """
    Vuer Hub Environment CLI
    
    Usage:
      vuer.env push --file <path> --name <name> --version <semver> [options...]
      vuer.env pull --id <environmentId> [--output <dir>] [--filename <name>]
    
    Commands:
      push    Upload a packaged environment (requires JWT auth)
      pull    Download an environment by environmentId
    
    Global Options:
      -h, --help        Show this help message
    
    Run `vuer.env push --help` or `vuer.env pull --help` for command-specific options.
    """
    )


def print_push_help() -> None:
    print_root_help()
    print(
        """
    Push Options:
      --file PATH            Path to environment package (required)
      --name NAME            Environment name, no spaces (required)
      --version SEMVER       Version string (semver) (required)
      --description TEXT     Optional description
      --env-type TYPE        Optional environment type (e.g. isaac, mujoco)
      --visibility VIS       PUBLIC | PRIVATE | ORG_MEMBERS (default PUBLIC)
    """
    )


def print_pull_help() -> None:
    print_root_help()
    print(
        """
    Pull Options:
      --id ENVIRONMENT_ID    Target environmentId (required)
      --output DIR           Directory to save download (default downloads/)
      --filename NAME        Optional override for saved file name
    """
    )


def _maybe_print_root_help() -> None:
    if len(sys.argv) == 1:
        print_root_help()
        sys.exit(0)
    first = sys.argv[1]
    if first in HELP_FLAGS:
        print_root_help()
        sys.exit(0)


_maybe_print_root_help()

API_BASE_ENV = "VUER_API_BASE_URL"
AUTH_TOKEN_ENV = "VUER_AUTH_TOKEN"
DEFAULT_API_BASE = "https://api.vuer.ai"
DOWNLOAD_DIR_DEFAULT = "downloads"


class PushConfig(ParamsProto, prefix=""):
    file = Proto(help="Path to the environment package (zip/tar/etc.)")
    name = Proto(help="Environment name (no spaces)")
    version = Proto(help="Environment version (semver, e.g., 1.2.3)")
    description = Proto("", help="Optional description")
    env_type = Proto("", help="Environment type, e.g., isaac, mujoco")
    visibility = Proto("PUBLIC",
                       help="Visibility: PUBLIC | PRIVATE | ORG_MEMBERS")


class PullConfig(ParamsProto, prefix=""):
    id = Proto(help="Environment ID (environmentId field)")
    output = Proto(DOWNLOAD_DIR_DEFAULT,
                   help="Directory to place downloaded file")
    filename = Proto("",
                     help="Optional custom filename (defaults to "
                          "server-provided)")


def get_api_base() -> str:
    vuer_back_endpoint = os.getenv("VUER_BACKEND_ENDPOINT")
    if not vuer_back_endpoint:
        raise RuntimeError(
            "Missing VUER_BACKEND_ENDPOINT environment variable."
        )
    return vuer_back_endpoint.rstrip("/")


def get_auth_headers() -> Dict[str, str]:
    token = os.getenv(AUTH_TOKEN_ENV)
    if not token:
        raise RuntimeError(
            f"Missing JWT token. Please set "
            f"environment variable {AUTH_TOKEN_ENV}."
        )
    return {"Authorization": f"Bearer {token}"}


def resolve_file(path_str: str) -> Path:
    if not path_str:
        raise RuntimeError("File path is required (--file)")
    candidate = Path(path_str).expanduser()
    if candidate.is_file():
        return candidate
    candidate = Path.cwd() / path_str
    if candidate.is_file():
        return candidate
    raise RuntimeError(f"File '{path_str}' does not exist")


def cmd_push() -> None:
    file_path = resolve_file(str(PushConfig.file))
    if not PushConfig.name:
        raise RuntimeError("Environment name is required (--name)")
    if " " in PushConfig.name:
        raise RuntimeError("Environment name cannot contain spaces")
    if not PushConfig.version:
        raise RuntimeError("Environment version is required (--version)")

    url = f"{get_api_base()}/environments/upload"
    headers = get_auth_headers()

    data = {
        "name": PushConfig.name,
        "versionId": PushConfig.version,
    }
    if PushConfig.description:
        data["description"] = PushConfig.description
    if PushConfig.env_type:
        data["type"] = PushConfig.env_type
    if PushConfig.visibility:
        data["visibility"] = PushConfig.visibility

    try:
        with file_path.open("rb") as f:
            files = {
                "package": (file_path.name, f, "application/octet-stream")}
            response = requests.post(
                url, headers=headers, data=data, files=files, timeout=60
            )
    except requests.RequestException as exc:
        raise RuntimeError(f"Push request failed: {exc}") from exc

    if response.status_code >= 300:
        raise RuntimeError(
            f"Push failed ({response.status_code}): {response.text.strip()}"
        )

    payload = response.json()
    env = payload.get("environment", payload)
    print("=== Push Success ===")
    print(f"ID        : {env.get('environmentId')}")
    print(f"Name      : {env.get('name')}")
    print(f"Version   : {env.get('versionId')}")
    print(f"Visibility: {env.get('visibility')}")


def ensure_output_dir(path_str: Optional[str]) -> Path:
    directory = Path(path_str or DOWNLOAD_DIR_DEFAULT).expanduser()
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def extract_filename(resp: requests.Response, default_name: str) -> str:
    content_disposition = resp.headers.get("Content-Disposition", "")
    if not content_disposition:
        return default_name

    # RFC 5987 style: filename*=UTF-8''encoded-name
    if "filename*=" in content_disposition:
        part = content_disposition.split("filename*=")[-1].strip()
        if part.lower().startswith("utf-8''"):
            encoded = part[7:]
        else:
            encoded = part
        encoded = encoded.split(";")[0].strip().strip('"')
        from urllib.parse import unquote

        candidate = unquote(encoded)
        if candidate:
            return candidate

    if "filename=" in content_disposition:
        candidate = content_disposition.split("filename=")[-1].strip().strip(
            '"')
        candidate = candidate.split(";")[0].strip()
        if candidate:
            return candidate

    return default_name


def cmd_pull() -> None:
    if not PullConfig.id:
        raise RuntimeError("Environment ID is required (--id)")

    url = f"{get_api_base()}/environments/{PullConfig.id}/download"
    headers = get_auth_headers()

    try:
        response = requests.get(url, headers=headers, stream=True, timeout=60)
    except requests.RequestException as exc:
        raise RuntimeError(f"Pull request failed: {exc}") from exc

    if response.status_code >= 300:
        raise RuntimeError(
            f"Pull failed ({response.status_code}): {response.text.strip()}"
        )

    downloads_dir = ensure_output_dir(str(PullConfig.output))
    filename = (
            PullConfig.filename
            or extract_filename(response, f"{PullConfig.id}.bin")
    )
    destination = downloads_dir / filename

    try:
        with destination.open("wb") as f:
            for chunk in response.iter_content(chunk_size=1024 * 512):
                if chunk:
                    f.write(chunk)
    except OSError as exc:
        raise RuntimeError(f"Failed to write file: {exc}") from exc

    print("=== Pull Success ===")
    print(f"Saved to: {destination.resolve()}")


def main() -> None:
    cmd = sys.argv[1]
    sys.argv = [sys.argv[0]] + sys.argv[2:]

    try:
        if cmd == "push":
            if any(arg in HELP_FLAGS for arg in sys.argv[1:]):
                print_push_help()
                return
            cmd_push()
        elif cmd == "pull":
            if any(arg in HELP_FLAGS for arg in sys.argv[1:]):
                print_pull_help()
                return
            cmd_pull()
        else:
            print(f"Unknown command '{cmd}'\n")
            print_root_help()
    except Exception as exc:  # noqa: BLE001
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
