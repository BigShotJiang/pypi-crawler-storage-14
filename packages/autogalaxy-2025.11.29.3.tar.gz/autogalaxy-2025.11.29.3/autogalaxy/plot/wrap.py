import autoarray.plot as aplt


class HalfLightRadiusAXVLine(aplt.AXVLine):
    pass


class EinsteinRadiusAXVLine(aplt.AXVLine):
    pass


class ModelFluxesYXScatter(aplt.YXScatter):
    pass


class LightProfileCentresScatter(aplt.GridScatter):
    pass


class MassProfileCentresScatter(aplt.GridScatter):
    pass


class MultipleImagesScatter(aplt.GridScatter):
    pass


class TangentialCriticalCurvesPlot(aplt.GridPlot):
    pass


class RadialCriticalCurvesPlot(aplt.GridPlot):
    pass


class TangentialCausticsPlot(aplt.GridPlot):
    pass


class RadialCausticsPlot(aplt.GridPlot):
    pass
