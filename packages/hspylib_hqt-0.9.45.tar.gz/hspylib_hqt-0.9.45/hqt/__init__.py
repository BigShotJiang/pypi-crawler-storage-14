# _*_ coding: utf-8 _*_
#
# hspylib-hqt v0.9.45
#
# Package: main.hqt
"""Package initialization."""

__all__ = [
    'promotions', 
    'qt_application', 
    'stream_capturer', 
    'views'
]
__version__ = '0.9.45'
