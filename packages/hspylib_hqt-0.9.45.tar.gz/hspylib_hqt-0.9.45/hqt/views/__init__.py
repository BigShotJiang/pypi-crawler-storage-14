# _*_ coding: utf-8 _*_
#
# hspylib-hqt v0.9.45
#
# Package: main.hqt.views
"""Package initialization."""

__all__ = [
    'main_view', 
    'qt_view'
]
__version__ = '0.9.45'
