import re

# Optimized Cambodia phone prefixes
KH_PREFIXES = [
    {"operator": "Cellcard", "prefixes": ["010","011","012","014","017","018","061","076","077","078","085","086","087","089"], "digits": 8},
    {"operator": "Smart",   "prefixes": ["015","016","069","070","071","076","081","087","088","093","096","098"], "digits": 9},
    {"operator": "Metfone", "prefixes": ["031","032","033","034","035","036","037","038","060","066","067","068","071","090","091","097","088"], "digits": 9},
    {"operator": "Cootel",  "prefixes": ["038","068","071"], "digits": 9},
    {"operator": "Yes/Seatel", "prefixes": ["067","068"], "digits": 9},
]

# Build flat prefix -> (operator, digits) mapping for fast lookup
PREFIX_MAP = {}
for item in KH_PREFIXES:
    for p in item["prefixes"]:
        PREFIX_MAP[p] = {"operator": item["operator"], "digits": item["digits"]}


def clean_number(phone: str) -> str:
    """Auto convert any Cambodia phone input to digits (without +855)."""
    if not isinstance(phone, str):
        raise ValueError("Phone number must be a string")

    phone = re.sub(r"[ \-]", "", phone)

    if phone.startswith("+855"):
        phone = phone[4:]
    elif phone.startswith("855"):
        phone = phone[3:]
    elif phone.startswith("0"):
        phone = phone[1:]

    if not phone.isdigit():
        raise ValueError("Phone number must contain digits only")
    return phone


def is_valid_cambodia(phone: str, strict_prefix: bool = False) -> bool:
    phone_digits = clean_number(phone)

    if len(phone_digits) not in (8, 9):
        return False

    if strict_prefix:
        prefix = phone_digits[:3]
        info = PREFIX_MAP.get(prefix)
        if not info:
            return False
        if len(phone_digits) != info["digits"]:
            return False

    return bool(re.fullmatch(r"\d{8,9}", phone_digits))


def format_to_international(phone: str, strict_prefix: bool = False) -> str:
    phone_digits = clean_number(phone)
    if not is_valid_cambodia(phone_digits, strict_prefix=strict_prefix):
        raise ValueError("Invalid Cambodia phone number")
    return "+855" + phone_digits


def get_operator(phone: str) -> str:
    phone_digits = clean_number(phone)
    prefix = phone_digits[:3]
    info = PREFIX_MAP.get(prefix)
    return info["operator"] if info else "Unknown"
