from setuptools import setup, find_packages

setup(
    name="orbitaim_ai",
    version="0.0.2",
    description="Single place for all AI usecases across OrbitAim Products",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=["requests"],
    python_requires=">=3.9",
)

# Remove-Item -Recurse -Force .\build, .\dist, .\*.egg-info
# python -m build
# python setup.py sdist bdist_wheel
# pip install dist/{package_name}-{version}-py3-none-any.whl
# pip install 'C:\Users\AI TEAM\Desktop\orbit_ai\dist\orbit_ai-0.0.1-py3-none-any.whl'
# twine upload dist/*
# #07OrbitAim 
# pypi-AgEIcHlwaS5vcmcCJGViZmExMGU1LTM5YTUtNGMzOS1iMzJiLWQwOWY2YmJjOTU4OAACKlszLCIzZGRmMWExMS05YTM5LTQ4ZGEtOWRlYy01OWJlYjJiNDYyNjMiXQAABiA3vQM_1zXMmfTAsjz6g3HxfkuvG5gQML-JXcliJJQbMw
