import numpy as np


def hello_avneesh_function(name:str):
    if name:
        return (f"hello from {name}!")
    return ("hello from avneesh!")
