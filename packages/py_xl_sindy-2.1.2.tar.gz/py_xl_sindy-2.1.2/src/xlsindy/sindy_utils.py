"""
This file implement the base SINDy algorithm and also utilitaries that came from past SINDy studies like :
- Ensemble SINDy
- Hard treshold optimisation

TODO
"""
