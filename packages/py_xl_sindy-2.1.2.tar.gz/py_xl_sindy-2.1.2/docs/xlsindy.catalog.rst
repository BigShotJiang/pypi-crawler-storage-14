xlsindy.catalog module
======================

.. automodule:: xlsindy.catalog
   :members:
   :undoc-members:
   :show-inheritance:
