xlsindy.dynamics\_modeling module
=================================

.. automodule:: xlsindy.dynamics_modeling
   :members:
   :undoc-members:
   :show-inheritance:
