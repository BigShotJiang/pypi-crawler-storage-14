xlsindy.euler\_lagrange module
==============================

.. automodule:: xlsindy.euler_lagrange
   :members:
   :undoc-members:
   :show-inheritance:
