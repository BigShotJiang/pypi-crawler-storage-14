xlsindy.render module
=====================

.. automodule:: xlsindy.render
   :members:
   :undoc-members:
   :show-inheritance:
