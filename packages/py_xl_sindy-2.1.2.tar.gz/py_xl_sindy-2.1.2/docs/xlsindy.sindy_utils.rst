xlsindy.sindy_utils module
==========================

.. automodule:: xlsindy.sindy_utils
   :members:
   :undoc-members:
   :show-inheritance:
