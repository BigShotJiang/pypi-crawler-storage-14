xlsindy.optimization module
===========================

.. automodule:: xlsindy.optimization
   :members:
   :undoc-members:
   :show-inheritance:
