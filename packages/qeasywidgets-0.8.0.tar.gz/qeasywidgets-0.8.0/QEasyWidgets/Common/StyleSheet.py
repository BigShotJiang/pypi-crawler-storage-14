from enum import Enum
from pathlib import Path
from typing import Union, Optional
from PySide6.QtCore import QFile, QObject, QEvent
from PySide6.QtWidgets import QApplication, QWidget

from .Signals import componentsSignals
from .Theme import EasyTheme, currentTheme, isDarkTheme

##############################################################################################################################

registratedWidgets = {}


class StyleSheetBase(Enum):
    '''
    '''
    Label = 'Label'
    ToolTip = 'ToolTip'
    Button = 'Button'
    CheckBox = 'CheckBox'
    ScrollArea = 'ScrollArea'
    Tree = 'Tree'
    List = 'List'
    ToolBox = 'ToolBox'
    GroupBox = 'GroupBox'
    Slider = 'Slider'
    SpinBox = 'SpinBox'
    ComboBox = 'ComboBox'
    Edit = 'Edit'
    Browser = 'Browser'
    ProgressBar = 'ProgressBar'
    Player = 'Player'
    Tab = 'Tab'
    Table = 'Table'
    ChatWidget = 'ChatWidget'
    Bar = 'Bar'
    DockWidget = 'DockWidget'
    Menu = 'Menu'

    def registrate(self, widget, value):
        registratedWidgets[widget] = value

    def deregistrate(self, widget):
        registratedWidgets.pop(widget)

    def apply(self, widget: QWidget, theme: Optional[str] = None, registrate: bool = True):
        EasyTheme.update(theme) if theme is not None else None

        Prefix = 'QSS'
        FilePath = f'qss/{currentTheme()}/{self.value}.qss'
        File = QFile(Path(f':/{Prefix}').joinpath(FilePath))
        File.open(QFile.ReadOnly | QFile.Text)
        QSS = str(File.readAll(), encoding = 'utf-8')
        File.close()

        widget.setStyleSheet(QSS)

        self.registrate(widget, self.value) if registrate else None


def Function_UpdateStyleSheet(
    theme: Optional[str] = None
):
    '''
    '''
    for widget, value in list(registratedWidgets.items()):
        for Value in StyleSheetBase:
            if Value.value != value:
                continue
            try:
                Value.apply(widget, theme)
            except RuntimeError:
                Value.deregistrate(widget)
            finally:
                #QApplication.instance().processEvents()
                continue


componentsSignals.setTheme.connect(Function_UpdateStyleSheet)

##############################################################################################################################

class CustomStyleSheet:
    """
    Custom style sheet that supports different styles for light and dark themes
    """
    LIGHT_QSS_KEY = 'lightCustomQss'
    DARK_QSS_KEY = 'darkCustomQss'

    def __init__(self, widget: QWidget):
        self.widget = widget

    def setCustomStyleSheet(self, lightQss: str, darkQss: str):
        """
        Set custom style sheet for light and dark themes
        
        Parameters
        ----------
        lightQss: str
            Style sheet for light theme
        darkQss: str
            Style sheet for dark theme
        """
        self.setLightStyleSheet(lightQss)
        self.setDarkStyleSheet(darkQss)
        self._applyStyleSheet()

    def setLightStyleSheet(self, qss: str):
        """Set light theme stylesheet"""
        self.widget.setProperty(self.LIGHT_QSS_KEY, qss)
        return self

    def setDarkStyleSheet(self, qss: str):
        """Set dark theme stylesheet"""
        self.widget.setProperty(self.DARK_QSS_KEY, qss)
        return self

    def lightStyleSheet(self) -> str:
        """Get light theme stylesheet"""
        return self.widget.property(self.LIGHT_QSS_KEY) or ''

    def darkStyleSheet(self) -> str:
        """Get dark theme stylesheet"""
        return self.widget.property(self.DARK_QSS_KEY) or ''

    def _applyStyleSheet(self):
        """Apply the appropriate stylesheet based on current theme"""
        qss = self.darkStyleSheet() if isDarkTheme() else self.lightStyleSheet()
        self.widget.setStyleSheet(qss)


class CustomStyleSheetWatcher(QObject):
    """
    Watcher for custom style sheet changes
    """
    def __init__(self):
        super().__init__()
        componentsSignals.setTheme.connect(self._onThemeChanged)
        self.widgets = set()

    def register(self, widget: QWidget):
        """Register a widget to watch for theme changes"""
        if widget not in self.widgets:
            self.widgets.add(widget)

    def deregister(self, widget: QWidget):
        """Deregister a widget"""
        self.widgets.discard(widget)

    def _onThemeChanged(self):
        """Update all registered widgets when theme changes"""
        removes = []
        for widget in list(self.widgets):
            try:
                if widget.property(CustomStyleSheet.LIGHT_QSS_KEY) or widget.property(CustomStyleSheet.DARK_QSS_KEY):
                    CustomStyleSheet(widget)._applyStyleSheet()
            except RuntimeError:
                removes.append(widget)
        
        for widget in removes:
            self.deregister(widget)


# Global custom stylesheet watcher
customStyleSheetWatcher = CustomStyleSheetWatcher()


def setCustomStyleSheet(widget: QWidget, lightQss: str, darkQss: str):
    """
    Set custom style sheet for light and dark themes with automatic theme switching support
    
    Parameters
    ----------
    widget: QWidget
        The widget to apply custom stylesheet
    lightQss: str
        Style sheet for light theme
    darkQss: str
        Style sheet for dark theme
    """
    CustomStyleSheet(widget).setCustomStyleSheet(lightQss, darkQss)
    customStyleSheetWatcher.register(widget)

##############################################################################################################################