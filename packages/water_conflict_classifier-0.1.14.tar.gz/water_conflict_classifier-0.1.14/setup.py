"""Setup script for water-conflict-classifier package."""
from setuptools import setup

# Configuration is in pyproject.toml
setup()

