# PSyclone LFRic Scripts

This directory contains example PSyclone scripts for the LFRic API
that might be useful either in themselves, or as a starting point for
creating a new script.
