# Getting Started with multi-join

__version__: `0.1.2`

The multi-join package is a toolkit to join any number of iterables together using specified join conditions. It is mainly geared towards joining delimited flat files together though, similar to unix `join` command but in a pure python API. It is built on top of `heapq.merge`.

There is [online](https://cfinan.gitlab.io/multi-join/index.html) documentation for multi-join.

## Installation instructions

Install using pip
```
pip install multi-join
```

Or a conda install
```
conda install -c cfin multi-join
```

## Basic usage
There are some examples in `./resources/examples` where `.` is the root of the multi-join repository.

## Run tests
If you have cloned the repository, you can also run the tests using `pytest ./tests`, if any fail please contact us (see the contribution page for contact info).
