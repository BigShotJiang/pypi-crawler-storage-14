__version__ = '0.1.2'

# Import examples into the main package
# from . import join
