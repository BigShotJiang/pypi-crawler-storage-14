from __future__ import annotations

import typing

Bool = typing.Literal['true', 'false']
