# This is actually used
from . import authifier as a  # noqa: F401
from .authorized_bots import *
from .basic import *
from .bots import *
from .channel_invites import *
from .channel_unreads import *
from .channel_webhooks import *
from .channels import *
from .discovery import *
from .embeds import *
from .emojis import *
from .files import *
from .gateway import *
from .localization import *
from .messages import *
from .misc import *
from .oauth2 import *
from .permissions import *
from .safety_reports import *
from .server_bans import *
from .server_members import *
from .servers import *
from .user_settings import *
from .users import *
