module.exports = async (page, scenario, vp) => {
    await require(__dirname + "/helpers")(page, scenario);
};
