cadnaPromise
==============

.. image:: https://img.shields.io/badge/License-GPLv3-yellowgreen.svg
    :target: LICENSE
    :alt: License


.. image:: https://gitlab.lip6.fr/hilaire/promise2/badges/master/pipeline.svg
    :target: pipeline
    :alt: Pipeline
