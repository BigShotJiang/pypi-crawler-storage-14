# Auto-generated values for animal
puppy
kitten
fox
panda
octopus
flamingo
kangaroo
sloth
hamster
chihuahua
bunny
meerkat
axolotl
flying squirrel
narwhal
tiger
lemur
dolphin
penguin
glowworm