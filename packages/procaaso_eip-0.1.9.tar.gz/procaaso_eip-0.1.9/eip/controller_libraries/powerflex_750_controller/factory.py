from typing import Union, overload, Literal
from .PowerFlex753 import PowerFlex753


@overload
def create_controller(
    model: str,
    *,
    deviceIpAddress: str,
    port: int,
) -> PowerFlex753: ...


def create_controller(model: str, deviceIpAddress: str, port: int, **kwargs) -> Union[PowerFlex753]:
    if model.lower() == "753":
        return PowerFlex753(deviceIpAddress=deviceIpAddress, port=port)
    else:
        raise ValueError(f"Unsupported model: {model}")
