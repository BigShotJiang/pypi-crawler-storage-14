import time
from abc import ABC, abstractmethod
from eip.client import EIPBaseClient


class PowerFlex750Base(ABC):
    def __init__(self, deviceIpAddress: str, port: int = 44818):
        try:
            self.deviceIpAddress = deviceIpAddress
            self.port = port
            self.eeipClient = EIPBaseClient()
            self.sessionHandle = self.eeipClient.register_session(self.deviceIpAddress, port=port)
        except Exception as e:
            raise Exception(f"TCP session registration failed: {e}")

    ##########################
    ## Public Class Methods ##
    ##########################

    ####################
    ## Public Getters ##
    ####################

    ####################
    ## Public Setters ##
    ####################

    ###########################
    ## Private Class Methods ##
    ###########################

    #####################
    ## Private Getters ##
    #####################

    #####################s
    ## Private Setters ##
    #####################

    #####################
    ## Private Helpers ##
    #####################
