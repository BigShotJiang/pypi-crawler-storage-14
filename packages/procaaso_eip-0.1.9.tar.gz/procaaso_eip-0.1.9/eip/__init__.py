"""
procaaso-eip: EtherNet/IP (EIP) communication driver for industrial automation controllers.
"""

__version__ = "0.1.9"

from .client import EIPBaseClient
from .cip import CIPClient
from .models import (
    CommonPacketFormat,
    ListIdentityReply,
    EncapsulationHeader,
)

__all__ = [
    "EIPBaseClient",
    "CIPClient",
    "CommonPacketFormat",
    "ListIdentityReply",
    "EncapsulationHeader",
    "__version__",
]
