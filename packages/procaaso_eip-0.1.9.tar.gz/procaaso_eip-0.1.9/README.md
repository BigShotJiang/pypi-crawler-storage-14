# procaaso-eip

A Python library for EtherNet/IP (EIP) communication with industrial automation controllers.

## Overview

`procaaso-eip` provides a comprehensive communication driver for EtherNet/IP protocol, enabling Python applications to interface with industrial controllers including VFDs (Variable Frequency Drives), motor controllers, and I/O modules.

## Features

- **EtherNet/IP Protocol**: Full CIP (Common Industrial Protocol) implementation
- **Multiple Controller Support**: Pre-built drivers for various industrial hardware
- **EDS File Parser**: Parse and utilize Electronic Data Sheet files
- **Type-Safe**: Built with Pydantic for robust data validation

## Supported Hardware

This library includes hardware interfaces for:

- PowerFlex 750/753 Variable Frequency Drives
- Nanotec motor controllers (C5-E-1-11, C5-E-2-11)
- Moxa I/O modules (E1212, E1242)
- Kollmorgen servo drives (AKD series)
- Mettler Toledo devices (ACT350)

## Installation

```bash
pip install procaaso-eip
```

Or with Poetry:

```bash
poetry add procaaso-eip
```

## Quick Start

```python
from eip.controller_libraries.powerflex_750_controller.factory import PowerFlexFactory

# Connect to a PowerFlex VFD
controller = PowerFlexFactory.create_controller(
    address="192.168.1.10",
    port=44818,
    model="753"
)

# Control the drive
controller.set_speed_units("RPM")
controller.set_motor_np_rpm(1750)
controller.set_run(True)
```

## Command-Line Tools

The package includes an EDS file parser:

```bash
eds-parser --help
```

## Controllers

This library has a number of hardware interfaces that will use ethernet/IP to communicate

### Running Tests

For testing changes to this library, install the required modules, then do the following:

For general tests, navigate to the tests folder and eneter the following style, referencing your specific hardware:

``` bash
python -m tests.test_motor_controller
```

#### How to touch a PowerFlex device remotely

1. Ensure that the firewall is open
    sudo ufw allow 2244/tcp
2. Open up the wire gaurd connection
    Make sure you can ping
3. Bring up the ssh tunnel
    ssh -p 2244 -N -L 3301:195.168.1.11:44818 consynsys@< IP Address of the edge device > -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 -o ServerAliveCountMax=3
4. Activate your VM
5. Run the tester

    ``` bash
    python -m eip.controller_libraries.tests.powerflex_tests.UnifiedControllerTester
    ```
