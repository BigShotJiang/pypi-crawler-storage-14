"""
EDS (Electronic Data Sheet) parser for EtherNet/IP devices.
"""

__version__ = "0.1.9"

from .parser import main

__all__ = [
    "main",
    "__version__",
]
