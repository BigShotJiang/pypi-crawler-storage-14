#####################################################
colorLib.builder: Build COLR/CPAL tables from scratch
#####################################################

.. automodule:: fontTools.colorLib.builder
   :no-inherited-members:
