####################################
merge: Merge multiple fonts into one
####################################

.. rubric:: Overview:
   :heading-level: 2

:mod:`fontTools.merge` provides both a library and a command line interface
(``fonttools merge``) for merging multiple fonts together.

.. autoclass:: fontTools.merge.Merger
   :members:
   :undoc-members:
