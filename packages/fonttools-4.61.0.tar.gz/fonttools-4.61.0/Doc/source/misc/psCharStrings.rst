#####################################################
psCharStrings: Tools for working with CharString data
#####################################################

.. currentmodule:: fontTools.misc.psCharStrings

.. automodule:: fontTools.misc.psCharStrings
   :members:
   :undoc-members:
