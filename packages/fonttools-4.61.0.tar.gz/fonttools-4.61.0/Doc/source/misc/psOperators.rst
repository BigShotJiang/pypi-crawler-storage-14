########################################################
psOperators: Tools for working with PostScript operators
########################################################

.. currentmodule:: fontTools.misc.psOperators

.. automodule:: fontTools.misc.psOperators
   :members:
   :undoc-members:
