###############################################
intTools: Tools for working with integer values
###############################################

.. currentmodule:: fontTools.misc.intTools

.. automodule:: fontTools.misc.intTools
   :members:
   :undoc-members:
