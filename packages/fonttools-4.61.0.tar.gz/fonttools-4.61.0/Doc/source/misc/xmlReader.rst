#####################################
xmlReader: Tools for reading XML data
#####################################

.. currentmodule:: fontTools.misc.xmlReader

.. automodule:: fontTools.misc.xmlReader
   :members:
   :undoc-members:
