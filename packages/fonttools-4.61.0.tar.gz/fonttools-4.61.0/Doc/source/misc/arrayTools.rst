#############################################
arrayTools: Various array and rectangle tools
#############################################

.. currentmodule:: fontTools.misc.arrayTools

.. automodule:: fontTools.misc.arrayTools
   :members:
   :undoc-members:
   :member-order: bysource
