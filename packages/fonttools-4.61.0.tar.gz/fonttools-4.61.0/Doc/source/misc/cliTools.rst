###################################################################
cliTools: Utilities for command-line interfaces and console scripts
###################################################################

.. currentmodule:: fontTools.misc.cliTools

.. automodule:: fontTools.misc.cliTools
   :members:
   :undoc-members:
