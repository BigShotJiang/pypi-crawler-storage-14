################
ScriptExtensions
################

.. currentmodule:: fontTools.unicodedata.ScriptExtensions

.. automodule:: fontTools.unicodedata.ScriptExtensions
   :members:
   :undoc-members:

.. data:: fontTools.unicodedata.ScriptExtensions.RANGES

.. data:: fontTools.unicodedata.ScriptExtensions.VALUES
