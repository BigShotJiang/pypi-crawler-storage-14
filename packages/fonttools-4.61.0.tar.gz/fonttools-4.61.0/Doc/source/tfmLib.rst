###########################################
tfmLib: Read TeX Font Metrics files
###########################################

.. rubric:: Overview
   :heading-level: 2


.. automodule:: fontTools.tfmLib
   :members: TFM
   :undoc-members:
   :exclude-members: TFMException

          
    .. rubric:: Module contents:
       :heading-level: 2

		       
.. autoexception:: fontTools.tfmLib.TFMException
