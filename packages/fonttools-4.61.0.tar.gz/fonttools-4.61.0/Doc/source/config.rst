###########################
config: Configure fontTools
###########################

.. automodule:: fontTools.config
   :members:
   :undoc-members:
