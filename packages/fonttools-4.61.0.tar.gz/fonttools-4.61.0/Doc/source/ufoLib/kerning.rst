###########################################
kerning: Support for accessing kerning data
###########################################

.. automodule:: fontTools.ufoLib.kerning
   :members:
   :undoc-members:
