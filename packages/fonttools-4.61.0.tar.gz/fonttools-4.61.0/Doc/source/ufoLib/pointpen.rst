######################################################################
pointPen: A pen for accessing points in a glyph contour *[deprecated]*
######################################################################

.. important::
   
    .. automodule:: fontTools.ufoLib.pointPen
       :members:
       :undoc-members:
