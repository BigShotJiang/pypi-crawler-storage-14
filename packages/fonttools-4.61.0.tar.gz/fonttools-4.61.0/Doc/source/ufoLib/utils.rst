#########################################
utils: Miscellaneous UFO helper functions
#########################################

.. automodule:: fontTools.ufoLib.utils
   :members:
   :undoc-members:
