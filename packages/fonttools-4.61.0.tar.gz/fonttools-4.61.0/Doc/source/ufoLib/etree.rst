#############################################################
etree: Shim module for the ElementTree XML API *[deprecated]*
#############################################################

.. important::
   
    .. automodule:: fontTools.ufoLib.etree
       :members:
       :undoc-members:
