#############################################
t1Lib: Read and write PostScript Type 1 fonts
#############################################

.. rubric:: Overview:
   :heading-level: 2

Note also that :mod:`t1Lib` supports some :doc:`optional </optional>`
external libraries.

.. automodule:: fontTools.t1Lib
   :members:
   :undoc-members:

    
    .. rubric:: Module members:
       :heading-level: 2
 
