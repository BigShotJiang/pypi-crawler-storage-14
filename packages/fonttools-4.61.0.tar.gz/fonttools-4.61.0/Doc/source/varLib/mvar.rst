####
mvar
####

.. automodule:: fontTools.varLib.mvar
   :members:
   :undoc-members:

.. data:: fontTools.varLib.mvar.MVAR_ENTRIES
