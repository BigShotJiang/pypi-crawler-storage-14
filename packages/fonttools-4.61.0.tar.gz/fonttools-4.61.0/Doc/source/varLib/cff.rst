###
cff
###

.. automodule:: fontTools.varLib.cff
   :members:
   :undoc-members:
