##############################
CFFToCFF2: convert CFF to CFF2
##############################

.. automodule:: fontTools.cffLib.CFFToCFF2
   :inherited-members:
   :members:
   :undoc-members:
