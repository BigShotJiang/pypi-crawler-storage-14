################################################
woff2: Read and write the WOFF2 font file format
################################################

Note also that :mod:`woff2` supports some :doc:`optional </optional>`
external libraries.


.. automodule:: fontTools.ttLib.woff2
   :members:
   :undoc-members:
