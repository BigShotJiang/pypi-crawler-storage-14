``hdmx``: Horizontal Device Metrics table
-----------------------------------------

The ``hdmx`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._h_d_m_x
   :members:
   :undoc-members:

