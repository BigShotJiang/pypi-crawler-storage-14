``SING``: SING Glyphlet Basic Information table
-----------------------------------------------

The ``SING`` table is an Adobe Glyphlets table.

.. automodule:: fontTools.ttLib.tables.S_I_N_G_
   :members:
   :undoc-members:
