``avar``: Axis Variations table
-------------------------------

The ``avar`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._a_v_a_r
   :members:
   :undoc-members:

