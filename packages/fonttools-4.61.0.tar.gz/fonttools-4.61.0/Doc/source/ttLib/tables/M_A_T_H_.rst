``MATH``: Mathematical Typesetting table
----------------------------------------

The ``MATH`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.M_A_T_H_
   :members:
   :undoc-members:
