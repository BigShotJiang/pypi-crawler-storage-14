``JSTF``: Justification table
-----------------------------

The ``JSTF`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.J_S_T_F_
   :members:
   :undoc-members:
