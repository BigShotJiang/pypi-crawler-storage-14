``OS/2``: OS/2 and Windows Metrics table
----------------------------------------

The ``OS/2`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.O_S_2f_2
   :members:
   :undoc-members:
