``cvar``: CVT Variations table
------------------------------

The ``cvar`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._c_v_a_r
   :members:
   :undoc-members:


TupleVariation
^^^^^^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.TupleVariation
   :noindex:
   :members:
   :undoc-members:
