``post``: PostScript table
--------------------------

The ``post`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._p_o_s_t
   :members:
   :undoc-members:

