``cvt``:  Control Value Table
-----------------------------

The ``cvt`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._c_v_t
   :members:
   :undoc-members:

