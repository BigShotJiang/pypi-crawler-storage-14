``maxp``: Maximum Profile table
-------------------------------

The ``maxp`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._m_a_x_p
   :members:
   :undoc-members:

