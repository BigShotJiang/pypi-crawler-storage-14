``COLR``: Color table
---------------------

The ``COLR`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.C_O_L_R_
   :members:
   :undoc-members:
