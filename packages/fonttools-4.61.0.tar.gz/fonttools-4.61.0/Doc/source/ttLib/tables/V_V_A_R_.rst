``VVAR``: Vertical Metrics Variations table
-------------------------------------------

The ``VVAR`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.V_V_A_R_
   :members:
   :undoc-members:

