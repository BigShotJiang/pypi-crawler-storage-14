``FFTM``: FontForge Time Stamp table
------------------------------------

The ``FFTM`` table is used by the FontForge font editor.

.. automodule:: fontTools.ttLib.tables.F_F_T_M_
   :members:
   :undoc-members:


