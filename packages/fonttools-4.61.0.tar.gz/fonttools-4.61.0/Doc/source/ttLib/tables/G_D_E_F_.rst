``GDEF``: Glyph Definition table
--------------------------------

The ``GDEF`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.G_D_E_F_
   :members:
   :undoc-members:

