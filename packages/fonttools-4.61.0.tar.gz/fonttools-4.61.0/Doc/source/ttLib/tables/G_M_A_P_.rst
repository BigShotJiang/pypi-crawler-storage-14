``GMAP``: SING Glyphlet Summary table
-------------------------------------

The ``GMAP`` table is an Adobe Glyphlets table.

.. automodule:: fontTools.ttLib.tables.G_M_A_P_
   :members:
   :undoc-members:

