``prop``: Glyph Properties Table
--------------------------------

The ``prop`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._p_r_o_p
   :members:
   :undoc-members:

