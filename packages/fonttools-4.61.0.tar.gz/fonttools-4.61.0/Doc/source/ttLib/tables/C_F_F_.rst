``CFF``: Compact Font Format table
----------------------------------

The ``CFF`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.C_F_F_
   :members:
   :undoc-members:

