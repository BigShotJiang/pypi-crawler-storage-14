``Glat``: Graphite Glyph Attributes table
-----------------------------------------

The ``Glat`` table is a Graphite table.

.. automodule:: fontTools.ttLib.tables.G__l_a_t
   :members:
   :undoc-members:

