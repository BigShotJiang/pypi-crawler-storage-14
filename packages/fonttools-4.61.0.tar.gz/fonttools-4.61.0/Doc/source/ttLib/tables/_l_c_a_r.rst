``lcar``: Ligature Caret Table
------------------------------

The ``lcar`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._l_c_a_r
   :members:
   :undoc-members:

