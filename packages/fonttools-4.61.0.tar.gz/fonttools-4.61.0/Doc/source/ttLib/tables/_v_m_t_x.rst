``vmtx``: Vertical Metrics table
--------------------------------

The ``vmtx`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._v_m_t_x
   :members:
   :undoc-members:

