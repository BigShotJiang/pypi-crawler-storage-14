``GPOS``: Glyph Positioning table
---------------------------------

The ``GPOS`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.G_P_O_S_
   :members:
   :undoc-members:

