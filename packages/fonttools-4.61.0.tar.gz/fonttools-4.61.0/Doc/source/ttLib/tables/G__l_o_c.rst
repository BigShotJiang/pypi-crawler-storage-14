``Gloc``: Graphite index to glyph attributes table
--------------------------------------------------

The ``Gloc`` table is a Graphite table.

.. automodule:: fontTools.ttLib.tables.G__l_o_c
   :members:
   :undoc-members:

