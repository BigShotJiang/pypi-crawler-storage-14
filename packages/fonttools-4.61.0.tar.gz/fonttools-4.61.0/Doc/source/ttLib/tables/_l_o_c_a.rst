``loca``: Index to Location table
---------------------------------

The ``loca`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._l_o_c_a
   :members:
   :undoc-members:

