###############################################
basePen: Base classes for segment-oriented pens
###############################################

.. automodule:: fontTools.pens.basePen
   :members:
   :undoc-members:
