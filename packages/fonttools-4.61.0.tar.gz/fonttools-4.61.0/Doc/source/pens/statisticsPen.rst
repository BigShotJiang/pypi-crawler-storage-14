#############
statisticsPen
#############

.. automodule:: fontTools.pens.statisticsPen
   :members:
   :undoc-members:
