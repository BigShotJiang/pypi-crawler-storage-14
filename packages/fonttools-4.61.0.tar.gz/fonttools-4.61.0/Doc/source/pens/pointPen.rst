####################################
pointPen: Point-oriented pen classes
####################################

.. currentmodule:: fontTools.pens.pointPen

This module contains base classes for point-oriented :doc:`pens
</pens/index>`. 

.. automodule:: fontTools.pens.pointPen
   :members:
   :undoc-members:
