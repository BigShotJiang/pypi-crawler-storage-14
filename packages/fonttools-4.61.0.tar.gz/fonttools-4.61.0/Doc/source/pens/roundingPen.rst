###########
roundingPen
###########

.. automodule:: fontTools.pens.roundingPen
   :members:
   :undoc-members:
