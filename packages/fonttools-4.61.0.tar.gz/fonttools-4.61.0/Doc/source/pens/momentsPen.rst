##########
momentsPen
##########

.. automodule:: fontTools.pens.momentsPen
   :members:
   :undoc-members:
