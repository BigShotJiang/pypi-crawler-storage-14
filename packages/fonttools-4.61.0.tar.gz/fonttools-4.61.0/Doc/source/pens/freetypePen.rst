###########
freetypePen
###########

.. automodule:: fontTools.pens.freetypePen
   :members:
   :undoc-members:
