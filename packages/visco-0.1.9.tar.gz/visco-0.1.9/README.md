VISCO (VISibility COmpression)

A tool for compressing radio interferometric data using Singular Value Decomposition (SVD) techniques.


## Documentation

For detailed documentation, visit: [https://visco.readthedocs.io](https://visco.readthedocs.io)

## Installation

```bash
pip install visco