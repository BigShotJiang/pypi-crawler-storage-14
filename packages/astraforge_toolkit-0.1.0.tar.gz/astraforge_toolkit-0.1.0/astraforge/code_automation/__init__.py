"""
Entry points for code automation clients (Codex & MR author helpers).

These utilities are lightweight shims intended for use outside the Django
runtime. They delegate HTTP calls to the `AstraForgeClient`.
"""

from .automation import CodeAutomationClient

__all__ = ["CodeAutomationClient"]
