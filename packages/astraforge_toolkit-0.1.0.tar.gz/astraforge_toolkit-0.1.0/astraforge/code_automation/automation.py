from __future__ import annotations

from typing import Any, Mapping, Optional

from astraforge.sdk import AstraForgeClient, AstraForgeResponse


class CodeAutomationClient:
    """
    High-level helper for Codex-style automation flows.

    This wrapper intentionally stays minimal and dependency-free so it can be
    imported in automation scripts without pulling the full backend stack.
    """

    def __init__(self, base_url: str, api_key: Optional[str] = None, timeout: int = 30):
        self.client = AstraForgeClient(base_url=base_url, api_key=api_key, timeout=timeout)

    def submit_plan(self, spec: Mapping[str, Any]) -> AstraForgeResponse:
        """
        Submit a plan for execution (POST /api/requests/).
        """
        return self.client.submit_request(spec)

    def execute(self, request_id: str, spec_override: Optional[Mapping[str, Any]] = None) -> AstraForgeResponse:
        """
        Trigger execution of an existing request (POST /api/requests/{id}/execute).
        """
        path = f"/api/requests/{request_id}/execute"
        payload = spec_override or {}
        return self.client._execute(self.client._build_request(path, method="POST", payload=payload))

    def deepagent_message(self, conversation_id: str, message: str) -> AstraForgeResponse:
        """
        Send a single non-streaming message to the deep agent for automation flows.
        """
        return self.client.chat(conversation_id, message)
