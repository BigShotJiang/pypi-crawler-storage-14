"""
Lightweight, dependency-free SDK helpers for calling AstraForge APIs.

This module is designed to be published alongside the backend package so
external clients can import `AstraForgeClient` without pulling in the Django
runtime.
"""

from .client import AstraForgeClient

__all__ = ["AstraForgeClient"]
