from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional


@dataclass
class AstraForgeResponse:
    status: int
    headers: Mapping[str, str]
    body: Optional[Mapping[str, Any]]


class AstraForgeClient:
    """
    Minimal, dependency-free SDK for calling AstraForge APIs.

    This client uses the Python standard library (`urllib`) so it can be
    consumed without installing the full backend runtime or any third-party
    HTTP libraries.
    """

    def __init__(self, base_url: str, api_key: Optional[str] = None, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

    def _build_request(
        self,
        path: str,
        *,
        method: str = "GET",
        payload: Optional[Mapping[str, Any]] = None,
    ) -> urllib.request.Request:
        url = f"{self.base_url}/{path.lstrip('/')}"
        data: Optional[bytes] = None
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
        return urllib.request.Request(url, data=data, headers=headers, method=method)

    def _execute(self, request: urllib.request.Request) -> AstraForgeResponse:
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as resp:
                raw = resp.read()
                body = json.loads(raw.decode("utf-8")) if raw else None
                return AstraForgeResponse(
                    status=resp.status,
                    headers=dict(resp.headers.items()),
                    body=body if isinstance(body, Mapping) else None,
                )
        except urllib.error.HTTPError as exc:  # pragma: no cover - passthrough
            raw = exc.read()
            body = json.loads(raw.decode("utf-8")) if raw else None
            return AstraForgeResponse(
                status=exc.code,
                headers=dict(exc.headers.items()),
                body=body if isinstance(body, Mapping) else None,
            )

    # --- Public helpers -------------------------------------------------

    def health(self) -> AstraForgeResponse:
        """Simple health check."""
        return self._execute(self._build_request("/api/health", method="GET"))

    def submit_request(self, payload: Mapping[str, Any]) -> AstraForgeResponse:
        """Submit a new code request (minimal wrapper around POST /api/requests)."""
        return self._execute(self._build_request("/api/requests/", method="POST", payload=payload))

    def chat(self, conversation_id: str, message: str) -> AstraForgeResponse:
        """Send a chat message to a deep agent conversation."""
        body = {"messages": [{"role": "user", "content": message}], "stream": False}
        path = f"/api/deepagent/conversations/{urllib.parse.quote(conversation_id)}/messages/"
        return self._execute(self._build_request(path, method="POST", payload=body))
