"""
Public exports for using the sandbox-bound deep agent outside the AstraForge app.

These re-export the sandbox backend and tool wrappers so external users can
instantiate the same deep agent runtime in their own processes.
"""

from astraforge.sandbox.deepagent_backend import SandboxBackend
from astraforge.infrastructure.ai.shell_tools import sandbox_shell
from astraforge.infrastructure.ai.python_repl_tools import sandbox_python_repl
from astraforge.infrastructure.ai.playwright_tools import sandbox_open_url_with_playwright
from astraforge.infrastructure.ai.image_tools import sandbox_view_image

__all__ = [
    "SandboxBackend",
    "sandbox_shell",
    "sandbox_python_repl",
    "sandbox_open_url_with_playwright",
    "sandbox_view_image",
]
