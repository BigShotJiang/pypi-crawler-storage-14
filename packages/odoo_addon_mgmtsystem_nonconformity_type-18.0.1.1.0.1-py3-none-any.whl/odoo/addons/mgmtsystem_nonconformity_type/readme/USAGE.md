NC Type

- Go to Management System → Management System → Nonconformities
- Create new Nonconformity
- Select a Nonconformity Type: default is Internal

NC Partner Quality E-mail

- Go to Contacts
- Open a Partner
- On tab Contacts & Adresses create/select a contact of type Quality
  Address
- Go to Management System → Management System → Nonconformity
- Create a new Nonconformity
- Click «Send by Email»
