"""Internal logging utilities for CyMeta."""

from __future__ import annotations

import logging
from typing import Optional

LOGGER_NAME = "cymeta"


def _configure_root_logger() -> logging.Logger:
    """Ensure the root CyMeta logger has at least one handler."""
    logger = logging.getLogger(LOGGER_NAME)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter("[CyMeta][%(levelname)s] %(message)s")
        )
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logger


def get_logger(component: Optional[str] = None) -> logging.Logger:
    """
    Get a namespaced CyMeta logger.

    Args:
        component: Optional component name (e.g., "compressor", "converter").
    """
    root = _configure_root_logger()
    if component:
        return root.getChild(component)
    return root


def set_log_level(level: int) -> None:
    """Set logging level for all CyMeta loggers."""
    logger = _configure_root_logger()
    logger.setLevel(level)
    for handler in logger.handlers:
        handler.setLevel(level)


__all__ = ["get_logger", "set_log_level"]

