#!/usr/bin/env python3
"""
Sistema de registro de datasets con CIDs IPFS reales.
Gestiona el registro, verificación y recuperación de datasets distribuidos.
"""

import asyncio
import hashlib
import json
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import ipfshttpclient
from pathlib import Path

from ..core.logging import get_logger
from ..core.config import get_config

logger = get_logger(__name__)


@dataclass
class DatasetMetadata:
    """Metadatos de un dataset registrado."""
    dataset_id: str
    name: str
    description: str
    owner_id: str
    cid: str  # CID IPFS real
    size_bytes: int
    num_samples: int
    data_format: str
    schema: Dict[str, Any]
    tags: List[str] = field(default_factory=list)
    quality_score: float = 0.0
    privacy_level: str = "public"  # public, private, sensitive
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    access_count: int = 0
    last_accessed: Optional[str] = None
    checksum: str = ""  # SHA256 del contenido


@dataclass
class DatasetRegistry:
    """Registro de datasets con IPFS real."""

    ipfs_client: Optional[ipfshttpclient.Client] = None
    registry: Dict[str, DatasetMetadata] = field(default_factory=dict)
    config: Any = None

    def __post_init__(self):
        if self.config is None:
            self.config = get_config()

        # Inicializar cliente IPFS
        self._init_ipfs_client()

        logger.info("🗂️ Dataset Registry initialized with real IPFS")

    def _init_ipfs_client(self):
        """Inicializar cliente IPFS real."""
        try:
            self.ipfs_client = ipfshttpclient.connect(
                f"/ip4/{self.config.ipfs.api_host}/tcp/{self.config.ipfs.api_port}/http"
            )
            logger.info("✅ Connected to IPFS daemon")
        except Exception as e:
            logger.error(f"❌ Failed to connect to IPFS: {e}")
            self.ipfs_client = None

    async def register_dataset(
        self,
        dataset_path: str,
        name: str,
        description: str,
        owner_id: str,
        data_format: str,
        schema: Dict[str, Any],
        tags: List[str] = None,
        privacy_level: str = "public"
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Registrar dataset real en IPFS.

        Args:
            dataset_path: Ruta al archivo/dataset local
            name: Nombre del dataset
            description: Descripción
            owner_id: ID del propietario
            data_format: Formato de datos (json, csv, parquet, etc.)
            schema: Esquema de datos
            tags: Etiquetas
            privacy_level: Nivel de privacidad

        Returns:
            (success, message, dataset_id)
        """
        if tags is None:
            tags = []

        try:
            # Verificar que el archivo existe
            path = Path(dataset_path)
            if not path.exists():
                return False, f"Dataset file not found: {dataset_path}", None

            # Calcular checksum y tamaño
            checksum = self._calculate_checksum(path)
            size_bytes = path.stat().st_size

            # Subir a IPFS real
            cid = self._upload_to_ipfs(path)
            if not cid:
                return False, "Failed to upload to IPFS", None

            # Crear metadatos
            dataset_id = f"ds_{owner_id}_{int(datetime.now().timestamp())}"

            metadata = DatasetMetadata(
                dataset_id=dataset_id,
                name=name,
                description=description,
                owner_id=owner_id,
                cid=cid,
                size_bytes=size_bytes,
                num_samples=self._estimate_sample_count(path, data_format),
                data_format=data_format,
                schema=schema,
                tags=tags,
                privacy_level=privacy_level,
                checksum=checksum
            )

            # Registrar en memoria
            self.registry[dataset_id] = metadata

            logger.info(f"✅ Registered dataset {dataset_id} with CID {cid}")
            return True, f"Dataset registered successfully with CID {cid}", dataset_id

        except Exception as e:
            logger.error(f"❌ Failed to register dataset: {e}")
            return False, f"Registration failed: {str(e)}", None

    def _upload_to_ipfs(self, file_path: Path) -> Optional[str]:
        """Subir archivo a IPFS real."""
        if not self.ipfs_client:
            logger.error("IPFS client not available")
            return None

        try:
            # Subir archivo a IPFS
            result = self.ipfs_client.add(str(file_path))
            cid = result['Hash']
            logger.info(f"📦 Uploaded to IPFS: {cid}")
            return cid
        except Exception as e:
            logger.error(f"Failed to upload to IPFS: {e}")
            return None

    def _calculate_checksum(self, file_path: Path) -> str:
        """Calcular checksum SHA256 del archivo."""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    def _estimate_sample_count(self, file_path: Path, data_format: str) -> int:
        """Estimar número de muestras basado en el formato."""
        try:
            if data_format.lower() == 'json':
                with open(file_path, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return len(data)
                    elif isinstance(data, dict) and 'data' in data:
                        return len(data['data'])
            elif data_format.lower() == 'csv':
                with open(file_path, 'r') as f:
                    return sum(1 for _ in f) - 1  # Restar header
        except Exception as e:
            logger.warning(f"Could not estimate sample count: {e}")

        return 0

    def get_dataset(self, dataset_id: str) -> Optional[DatasetMetadata]:
        """Obtener metadatos de dataset."""
        return self.registry.get(dataset_id)

    def list_datasets(self, owner_id: Optional[str] = None,
                     tags: List[str] = None) -> List[DatasetMetadata]:
        """Listar datasets con filtros opcionales."""
        datasets = list(self.registry.values())

        if owner_id:
            datasets = [d for d in datasets if d.owner_id == owner_id]

        if tags:
            datasets = [d for d in datasets if any(tag in d.tags for tag in tags)]

        return datasets

    async def download_dataset(self, dataset_id: str, output_path: str) -> Tuple[bool, str]:
        """
        Descargar dataset desde IPFS real.

        Args:
            dataset_id: ID del dataset
            output_path: Ruta donde guardar

        Returns:
            (success, message)
        """
        metadata = self.get_dataset(dataset_id)
        if not metadata:
            return False, f"Dataset {dataset_id} not found"

        try:
            # Descargar desde IPFS
            if not self.ipfs_client:
                return False, "IPFS client not available"

            # Obtener contenido desde IPFS
            content = self.ipfs_client.cat(metadata.cid)

            # Verificar checksum
            content_checksum = hashlib.sha256(content).hexdigest()
            if content_checksum != metadata.checksum:
                return False, "Checksum verification failed"

            # Guardar archivo
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)

            with open(output_file, 'wb') as f:
                f.write(content)

            # Actualizar estadísticas de acceso
            metadata.access_count += 1
            metadata.last_accessed = datetime.now().isoformat()

            logger.info(f"📥 Downloaded dataset {dataset_id} from IPFS")
            return True, f"Dataset downloaded to {output_path}"

        except Exception as e:
            logger.error(f"Failed to download dataset: {e}")
            return False, f"Download failed: {str(e)}"

    def verify_dataset_integrity(self, dataset_id: str) -> Tuple[bool, str]:
        """Verificar integridad del dataset en IPFS."""
        metadata = self.get_dataset(dataset_id)
        if not metadata:
            return False, f"Dataset {dataset_id} not found"

        try:
            if not self.ipfs_client:
                return False, "IPFS client not available"

            # Obtener contenido desde IPFS
            content = self.ipfs_client.cat(metadata.cid)

            # Verificar checksum
            content_checksum = hashlib.sha256(content).hexdigest()
            if content_checksum != metadata.checksum:
                return False, "Checksum mismatch - dataset corrupted"

            # Verificar tamaño
            if len(content) != metadata.size_bytes:
                return False, "Size mismatch - dataset corrupted"

            return True, "Dataset integrity verified"

        except Exception as e:
            return False, f"Integrity check failed: {str(e)}"

    def update_dataset_metadata(self, dataset_id: str, updates: Dict[str, Any]) -> bool:
        """Actualizar metadatos del dataset."""
        metadata = self.get_dataset(dataset_id)
        if not metadata:
            return False

        # Campos actualizables
        updatable_fields = ['name', 'description', 'tags', 'quality_score', 'privacy_level']

        for field, value in updates.items():
            if field in updatable_fields:
                setattr(metadata, field, value)

        metadata.updated_at = datetime.now().isoformat()
        logger.info(f"📝 Updated metadata for dataset {dataset_id}")
        return True

    def delete_dataset(self, dataset_id: str, owner_id: str) -> Tuple[bool, str]:
        """Eliminar dataset (solo propietario)."""
        metadata = self.get_dataset(dataset_id)
        if not metadata:
            return False, f"Dataset {dataset_id} not found"

        if metadata.owner_id != owner_id:
            return False, "Only owner can delete dataset"

        # Nota: En IPFS real, el contenido permanece disponible
        # Solo eliminamos del registro local
        del self.registry[dataset_id]

        logger.info(f"🗑️ Removed dataset {dataset_id} from registry")
        return True, "Dataset removed from registry"

    def get_registry_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del registro."""
        total_datasets = len(self.registry)
        total_size = sum(d.size_bytes for d in self.registry.values())
        total_accesses = sum(d.access_count for d in self.registry.values())

        return {
            "total_datasets": total_datasets,
            "total_size_bytes": total_size,
            "total_accesses": total_accesses,
            "ipfs_connected": self.ipfs_client is not None,
            "timestamp": datetime.now().isoformat()
        }

    def search_datasets(self, query: str, limit: int = 50) -> List[DatasetMetadata]:
        """Buscar datasets por nombre, descripción o tags."""
        query_lower = query.lower()
        results = []

        for dataset in self.registry.values():
            if (query_lower in dataset.name.lower() or
                query_lower in dataset.description.lower() or
                any(query_lower in tag.lower() for tag in dataset.tags)):
                results.append(dataset)

        # Ordenar por relevancia (simplificado)
        results.sort(key=lambda d: d.access_count, reverse=True)

        return results[:limit]


# Instancia global
_registry_instance: Optional[DatasetRegistry] = None


def get_dataset_registry() -> DatasetRegistry:
    """Obtener instancia global del registro de datasets."""
    global _registry_instance

    if _registry_instance is None:
        _registry_instance = DatasetRegistry()

    return _registry_instance