"""
IPFS Connector - Conexión real con IPFS para almacenamiento distribuido
Soporta nodos locales y gateways públicos como fallback.
"""

import ipfshttpclient
import requests
import logging
import json
from typing import Optional, Dict, Any
from ..core.logging import get_logger

logger = get_logger(__name__)


class IPFSConnector:
    """
    Conector robusto para IPFS con soporte para nodos locales y gateways públicos.
    Maneja automáticamente la conexión y proporciona métodos para subir/descargar datos.
    """

    def __init__(self, host: str = '/ip4/127.0.0.1/tcp/5001/http',
                 gateway_url: str = 'https://ipfs.io/ipfs/',
                 timeout: int = 30):
        """
        Inicializa el conector IPFS.

        Args:
            host: URL del nodo IPFS local
            gateway_url: URL del gateway público como fallback
            timeout: Timeout para operaciones en segundos
        """
        self.host = host
        self.gateway_url = gateway_url.rstrip('/')
        self.timeout = timeout
        self.client: Optional[ipfshttpclient.Client] = None
        self.connected = False
        self._connect()

    def _connect(self) -> None:
        """Intenta conectar con el nodo IPFS local."""
        try:
            self.client = ipfshttpclient.connect(self.host, timeout=self.timeout)
            # Verificar conexión con un ping simple
            self.client.id()
            self.connected = True
            logger.info(f"✅ Conectado a nodo IPFS local en {self.host}")
        except Exception as e:
            logger.warning(f"⚠️ No se pudo conectar a IPFS local: {e}. Usando modo solo-lectura (Gateway público).")
            self.connected = False
            self.client = None

    def add_bytes(self, data: bytes, **kwargs) -> str:
        """
        Sube bytes a IPFS.

        Args:
            data: Datos en bytes a subir
            **kwargs: Parámetros adicionales para ipfs.add

        Returns:
            CID (Content Identifier) del contenido subido

        Raises:
            ConnectionError: Si no hay conexión local disponible
        """
        if not self.connected or not self.client:
            raise ConnectionError("Se requiere un nodo IPFS local para subir contenido.")

        try:
            result = self.client.add_bytes(data, **kwargs)
            cid = result['Hash'] if isinstance(result, dict) else str(result)
            logger.info(f"📤 Datos subidos a IPFS: {cid}")
            return cid
        except Exception as e:
            logger.error(f"❌ Error subiendo datos a IPFS: {e}")
            raise

    def add_json(self, data: Dict[str, Any], **kwargs) -> str:
        """
        Sube un objeto JSON a IPFS.

        Args:
            data: Diccionario Python a serializar como JSON
            **kwargs: Parámetros adicionales

        Returns:
            CID del JSON subido
        """
        json_bytes = json.dumps(data, ensure_ascii=False).encode('utf-8')
        return self.add_bytes(json_bytes, **kwargs)

    def add_file(self, file_path: str, **kwargs) -> str:
        """
        Sube un archivo a IPFS.

        Args:
            file_path: Ruta al archivo a subir
            **kwargs: Parámetros adicionales

        Returns:
            CID del archivo subido
        """
        if not self.connected or not self.client:
            raise ConnectionError("Se requiere un nodo IPFS local para subir archivos.")

        try:
            result = self.client.add(file_path, **kwargs)
            cid = result['Hash'] if isinstance(result, dict) else str(result)
            logger.info(f"📤 Archivo subido a IPFS: {cid}")
            return cid
        except Exception as e:
            logger.error(f"❌ Error subiendo archivo a IPFS: {e}")
            raise

    def get_bytes(self, cid: str) -> bytes:
        """
        Descarga bytes desde IPFS.

        Args:
            cid: Content Identifier del contenido

        Returns:
            Datos en bytes
        """
        try:
            if self.connected and self.client:
                # Usar nodo local si está disponible
                return self.client.cat(cid)
            else:
                # Fallback a gateway público
                url = f"{self.gateway_url}/{cid}"
                logger.info(f"🌐 Descargando desde Gateway público: {url}")
                response = requests.get(url, timeout=self.timeout)
                response.raise_for_status()
                return response.content
        except Exception as e:
            logger.error(f"❌ Error descargando {cid} desde IPFS: {e}")
            raise

    def get_json(self, cid: str) -> Dict[str, Any]:
        """
        Descarga y parsea JSON desde IPFS.

        Args:
            cid: Content Identifier del JSON

        Returns:
            Diccionario Python parseado
        """
        data_bytes = self.get_bytes(cid)
        return json.loads(data_bytes.decode('utf-8'))

    def pin(self, cid: str) -> bool:
        """
        Fija un CID para evitar que sea eliminado por garbage collection.

        Args:
            cid: Content Identifier a fijar

        Returns:
            True si se fijó correctamente
        """
        if not self.connected or not self.client:
            logger.warning("⚠️ No se puede fijar CID sin nodo IPFS local")
            return False

        try:
            self.client.pin.add(cid)
            logger.info(f"📌 CID {cid} fijado en nodo local")
            return True
        except Exception as e:
            logger.error(f"❌ Error fijando CID {cid}: {e}")
            return False

    def unpin(self, cid: str) -> bool:
        """
        Libera un CID fijado.

        Args:
            cid: Content Identifier a liberar

        Returns:
            True si se liberó correctamente
        """
        if not self.connected or not self.client:
            logger.warning("⚠️ No se puede liberar CID sin nodo IPFS local")
            return False

        try:
            self.client.pin.rm(cid)
            logger.info(f"🔓 CID {cid} liberado")
            return True
        except Exception as e:
            logger.error(f"❌ Error liberando CID {cid}: {e}")
            return False

    def get_stats(self) -> Dict[str, Any]:
        """
        Obtiene estadísticas del nodo IPFS.

        Returns:
            Diccionario con estadísticas
        """
        stats = {
            'connected': self.connected,
            'host': self.host,
            'gateway_url': self.gateway_url,
            'can_upload': self.connected,
            'can_download': True  # Siempre puede descargar via gateway
        }

        if self.connected and self.client:
            try:
                # Obtener información del repositorio
                repo_stats = self.client.repo.stat()
                stats.update({
                    'repo_size': repo_stats.get('RepoSize'),
                    'num_objects': repo_stats.get('NumObjects'),
                    'storage_max': repo_stats.get('StorageMax')
                })

                # Obtener peers conectados
                peers = self.client.swarm.peers()
                stats['connected_peers'] = len(peers) if peers else 0

            except Exception as e:
                logger.debug(f"No se pudieron obtener estadísticas detalladas: {e}")

        return stats


# Instancia global del conector
ipfs_connector = IPFSConnector()