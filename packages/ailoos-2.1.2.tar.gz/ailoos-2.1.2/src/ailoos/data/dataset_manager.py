"""
Dataset Manager - Orquestador completo para procesamiento de datasets
Maneja descarga, sanitización, fragmentación (sharding) y distribución IPFS.
"""

import os
import json
import math
import hashlib
import tempfile
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
from datetime import datetime

from .ipfs_connector import ipfs_connector
from ..privacy.pii_scrubber import pii_scrubber
from ..core.logging import get_logger

logger = get_logger(__name__)


class DatasetShard:
    """
    Representa un fragmento (shard) de dataset.
    """

    def __init__(self, index: int, total_shards: int, data: Any,
                 source_dataset: str, metadata: Optional[Dict[str, Any]] = None):
        self.index = index
        self.total_shards = total_shards
        self.data = data
        self.source_dataset = source_dataset
        self.metadata = metadata or {}
        self.created_at = datetime.now().isoformat()
        self.data_hash = self._calculate_hash()

    def _calculate_hash(self) -> str:
        """Calcula hash del contenido del shard."""
        if isinstance(self.data, (dict, list)):
            content_str = json.dumps(self.data, sort_keys=True)
        else:
            content_str = str(self.data)

        return hashlib.sha256(content_str.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        """Convierte el shard a diccionario para serialización."""
        return {
            'index': self.index,
            'total_shards': self.total_shards,
            'data': self.data,
            'source_dataset': self.source_dataset,
            'metadata': self.metadata,
            'created_at': self.created_at,
            'data_hash': self.data_hash
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DatasetShard':
        """Crea un shard desde un diccionario."""
        shard = cls(
            index=data['index'],
            total_shards=data['total_shards'],
            data=data['data'],
            source_dataset=data['source_dataset'],
            metadata=data.get('metadata', {})
        )
        shard.created_at = data.get('created_at', datetime.now().isoformat())
        return shard


class DatasetManager:
    """
    Gestor completo de datasets con capacidades de:
    - Descarga desde fuentes externas
    - Sanitización PII automática
    - Fragmentación (sharding) inteligente
    - Distribución IPFS
    - Registro y seguimiento
    """

    def __init__(self, storage_path: str = "./data_cache",
                 default_shard_size_mb: int = 50,
                 enable_pii_scrubbing: bool = True):
        """
        Inicializa el dataset manager.

        Args:
            storage_path: Directorio para almacenar datasets locales
            default_shard_size_mb: Tamaño por defecto de shards en MB
            enable_pii_scrubbing: Si habilitar sanitización PII automática
        """
        self.storage_path = Path(storage_path)
        self.default_shard_size_mb = default_shard_size_mb
        self.enable_pii_scrubbing = enable_pii_scrubbing

        # Crear directorios necesarios
        self.storage_path.mkdir(parents=True, exist_ok=True)
        (self.storage_path / "datasets").mkdir(exist_ok=True)
        (self.storage_path / "shards").mkdir(exist_ok=True)
        (self.storage_path / "registry").mkdir(exist_ok=True)

        # Estadísticas
        self.stats = {
            'datasets_processed': 0,
            'shards_created': 0,
            'total_data_size_mb': 0.0,
            'pii_instances_removed': 0
        }

        logger.info(f"📦 DatasetManager inicializado en {self.storage_path}")

    def process_text_file(self, file_path: str, dataset_name: str,
                         shard_size_mb: Optional[int] = None,
                         metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Procesa un archivo de texto completo: sanitiza, fragmenta y sube a IPFS.

        Args:
            file_path: Ruta al archivo de texto
            dataset_name: Nombre del dataset
            shard_size_mb: Tamaño de shards en MB (opcional)
            metadata: Metadatos adicionales

        Returns:
            Diccionario con información del dataset procesado
        """
        logger.info(f"🚀 Procesando archivo de texto: {file_path}")

        # 1. Leer y validar archivo
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Archivo no encontrado: {file_path}")

        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            raw_content = f.read()

        file_size_mb = len(raw_content.encode('utf-8')) / (1024 * 1024)
        logger.info(f"📄 Archivo cargado: {file_size_mb:.2f} MB")

        # 2. Sanitización PII
        if self.enable_pii_scrubbing:
            logger.info("🧹 Aplicando sanitización PII...")
            clean_content = pii_scrubber.scrub_text(raw_content)
            pii_stats = pii_scrubber.get_stats()
            self.stats['pii_instances_removed'] += pii_stats['pii_found']
            logger.info(f"✅ Sanitización completada. PII removida: {pii_stats['pii_found']}")
        else:
            clean_content = raw_content

        # 3. Fragmentación inteligente
        shard_size = shard_size_mb or self.default_shard_size_mb
        shards = self._create_text_shards(clean_content, shard_size, dataset_name, metadata)

        # 4. Subida a IPFS
        shard_cids = []
        for shard in shards:
            try:
                cid = ipfs_connector.add_json(shard.to_dict())
                shard_cids.append(cid)
                logger.info(f"📤 Shard {shard.index + 1}/{shard.total_shards} subido: {cid}")
            except Exception as e:
                logger.error(f"❌ Error subiendo shard {shard.index}: {e}")
                # En producción, aquí iría lógica de retry o fallback

        # 5. Crear registro del dataset
        dataset_info = self._create_dataset_registry(
            dataset_name=dataset_name,
            source_file=file_path,
            shard_cids=shard_cids,
            total_size_mb=file_size_mb,
            metadata=metadata or {},
            shard_info=[{
                'index': shard.index,
                'size_chars': len(str(shard.data)),
                'hash': shard.data_hash
            } for shard in shards]
        )

        # 6. Actualizar estadísticas
        self.stats['datasets_processed'] += 1
        self.stats['shards_created'] += len(shards)
        self.stats['total_data_size_mb'] += file_size_mb

        logger.info(f"✅ Dataset '{dataset_name}' procesado exitosamente con {len(shards)} shards")
        return dataset_info

    def process_json_dataset(self, data: List[Dict[str, Any]], dataset_name: str,
                           shard_size_mb: Optional[int] = None,
                           metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Procesa un dataset JSON (lista de registros).

        Args:
            data: Lista de diccionarios JSON
            dataset_name: Nombre del dataset
            shard_size_mb: Tamaño de shards en MB
            metadata: Metadatos adicionales

        Returns:
            Información del dataset procesado
        """
        logger.info(f"🚀 Procesando dataset JSON: {dataset_name} ({len(data)} registros)")

        # 1. Sanitización PII
        if self.enable_pii_scrubbing:
            logger.info("🧹 Aplicando sanitización PII a registros JSON...")
            clean_data = pii_scrubber.scrub_dataset(data)
            pii_stats = pii_scrubber.get_stats()
            self.stats['pii_instances_removed'] += pii_stats['pii_found']
        else:
            clean_data = data

        # 2. Fragmentación por registros
        shard_size = shard_size_mb or self.default_shard_size_mb
        shards = self._create_json_shards(clean_data, shard_size, dataset_name, metadata)

        # 3. Subida a IPFS
        shard_cids = []
        for shard in shards:
            try:
                cid = ipfs_connector.add_json(shard.to_dict())
                shard_cids.append(cid)
                logger.info(f"📤 Shard {shard.index + 1}/{shard.total_shards} subido: {cid}")
            except Exception as e:
                logger.error(f"❌ Error subiendo shard {shard.index}: {e}")

        # 4. Crear registro
        dataset_size_mb = len(json.dumps(clean_data).encode()) / (1024 * 1024)
        dataset_info = self._create_dataset_registry(
            dataset_name=dataset_name,
            source_file="json_dataset",
            shard_cids=shard_cids,
            total_size_mb=dataset_size_mb,
            metadata=metadata or {},
            shard_info=[{
                'index': shard.index,
                'records': len(shard.data) if isinstance(shard.data, list) else 1,
                'hash': shard.data_hash
            } for shard in shards]
        )

        # 5. Actualizar estadísticas
        self.stats['datasets_processed'] += 1
        self.stats['shards_created'] += len(shards)
        self.stats['total_data_size_mb'] += dataset_size_mb

        logger.info(f"✅ Dataset JSON '{dataset_name}' procesado exitosamente")
        return dataset_info

    def download_shard(self, cid: str, local_path: Optional[str] = None) -> DatasetShard:
        """
        Descarga un shard desde IPFS.

        Args:
            cid: Content Identifier del shard
            local_path: Ruta local para guardar (opcional)

        Returns:
            Objeto DatasetShard descargado
        """
        logger.info(f"⬇️ Descargando shard: {cid}")

        try:
            shard_data = ipfs_connector.get_json(cid)
            shard = DatasetShard.from_dict(shard_data)

            if local_path:
                with open(local_path, 'w', encoding='utf-8') as f:
                    json.dump(shard_data, f, indent=2, ensure_ascii=False)
                logger.info(f"💾 Shard guardado localmente: {local_path}")

            logger.info(f"✅ Shard descargado: {shard.source_dataset} (#{shard.index + 1})")
            return shard

        except Exception as e:
            logger.error(f"❌ Error descargando shard {cid}: {e}")
            raise

    def get_dataset_info(self, dataset_name: str) -> Optional[Dict[str, Any]]:
        """
        Obtiene información de un dataset registrado.

        Args:
            dataset_name: Nombre del dataset

        Returns:
            Información del dataset o None si no existe
        """
        registry_path = self.storage_path / "registry" / f"{dataset_name}.json"
        if registry_path.exists():
            with open(registry_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None

    def list_datasets(self) -> List[Dict[str, Any]]:
        """
        Lista todos los datasets registrados.

        Returns:
            Lista de información de datasets
        """
        datasets = []
        registry_dir = self.storage_path / "registry"

        for registry_file in registry_dir.glob("*.json"):
            try:
                with open(registry_file, 'r', encoding='utf-8') as f:
                    dataset_info = json.load(f)
                    datasets.append(dataset_info)
            except Exception as e:
                logger.warning(f"Error leyendo registro {registry_file}: {e}")

        return datasets

    def _create_text_shards(self, content: str, shard_size_mb: int,
                           dataset_name: str, metadata: Optional[Dict[str, Any]] = None) -> List[DatasetShard]:
        """
        Crea shards de texto dividiendo por tamaño aproximado.
        """
        if metadata is None:
            metadata = {}

        # Calcular tamaño aproximado en caracteres por shard
        chars_per_mb = 500000  # Aproximación
        chars_per_shard = int(shard_size_mb * chars_per_mb)

        total_chars = len(content)
        num_shards = max(1, math.ceil(total_chars / chars_per_shard))  # Al menos 1 shard

        shards = []
        for i in range(num_shards):
            start = i * chars_per_shard
            end = min((i + 1) * chars_per_shard, total_chars)

            shard_content = content[start:end]
            shard_metadata = {
                **metadata,
                'shard_type': 'text',
                'char_start': start,
                'char_end': end,
                'content_length': len(shard_content)
            }

            shard = DatasetShard(
                index=i,
                total_shards=num_shards,
                data=shard_content,
                source_dataset=dataset_name,
                metadata=shard_metadata
            )
            shards.append(shard)

        logger.info(f"📦 Creados {num_shards} shards de texto (~{shard_size_mb}MB cada uno)")
        return shards

    def _create_json_shards(self, data: List[Dict], shard_size_mb: int,
                           dataset_name: str, metadata: Dict[str, Any]) -> List[DatasetShard]:
        """
        Crea shards de datos JSON dividiendo por número de registros.
        """
        # Estimar tamaño por registro
        if data:
            avg_record_size = len(json.dumps(data[0]).encode()) / 1024 / 1024  # MB
            records_per_shard = max(1, int(shard_size_mb / avg_record_size))
        else:
            records_per_shard = 1000  # Default

        num_shards = math.ceil(len(data) / records_per_shard)

        shards = []
        for i in range(num_shards):
            start = i * records_per_shard
            end = min((i + 1) * records_per_shard, len(data))

            shard_data = data[start:end]
            shard_metadata = {
                **metadata,
                'shard_type': 'json_records',
                'record_start': start,
                'record_end': end,
                'num_records': len(shard_data)
            }

            shard = DatasetShard(
                index=i,
                total_shards=num_shards,
                data=shard_data,
                source_dataset=dataset_name,
                metadata=shard_metadata
            )
            shards.append(shard)

        logger.info(f"📦 Creados {num_shards} shards JSON ({records_per_shard} registros cada uno)")
        return shards

    def _create_dataset_registry(self, dataset_name: str, source_file: str,
                               shard_cids: List[str], total_size_mb: float,
                               metadata: Dict[str, Any], shard_info: List[Dict]) -> Dict[str, Any]:
        """
        Crea el registro completo del dataset.
        """
        registry = {
            'dataset_name': dataset_name,
            'source_file': source_file,
            'created_at': datetime.now().isoformat(),
            'total_size_mb': total_size_mb,
            'num_shards': len(shard_cids),
            'shard_cids': shard_cids,
            'shard_info': shard_info,
            'metadata': metadata,
            'pii_scrubbed': self.enable_pii_scrubbing,
            'ipfs_stats': ipfs_connector.get_stats()
        }

        # Guardar registro local
        registry_path = self.storage_path / "registry" / f"{dataset_name}.json"
        with open(registry_path, 'w', encoding='utf-8') as f:
            json.dump(registry, f, indent=2, ensure_ascii=False)

        logger.info(f"📋 Registro creado: {registry_path}")
        return registry

    def get_stats(self) -> Dict[str, Any]:
        """
        Obtiene estadísticas del dataset manager.

        Returns:
            Diccionario con estadísticas
        """
        return {
            **self.stats,
            'storage_path': str(self.storage_path),
            'ipfs_connected': ipfs_connector.connected,
            'pii_scrubbing_enabled': self.enable_pii_scrubbing
        }


# Instancia global del dataset manager
dataset_manager = DatasetManager()