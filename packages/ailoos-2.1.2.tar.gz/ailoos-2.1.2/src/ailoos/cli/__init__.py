"""
CLI tools for Ailoos - Command Line Interface for easy node management.
"""

from .main import main

__all__ = ["main"]