import numpy as np
from typing import List, Any
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics.pairwise import euclidean_distances
import logging

logger = logging.getLogger(__name__)

class DensityWeightedSampling:
    """
    Estrategia de muestreo ponderado por densidad para aprendizaje activo.
    Combina incertidumbre con densidad de datos para seleccionar muestras representativas.
    """

    def __init__(self, uncertainty_strategy: Any, density_weight: float = 0.5, k_neighbors: int = 5):
        """
        Inicializa DensityWeightedSampling.

        Args:
            uncertainty_strategy: Estrategia de incertidumbre (e.g., UncertaintySampling)
            density_weight: Peso de la densidad en la combinación (0-1)
            k_neighbors: Número de vecinos para calcular densidad
        """
        self.uncertainty_strategy = uncertainty_strategy
        self.density_weight = density_weight
        self.k_neighbors = k_neighbors

        if not (0 <= density_weight <= 1):
            raise ValueError("density_weight debe estar entre 0 y 1")

    def select_samples(self, model: Any, labeled_data: np.ndarray, unlabeled_data: np.ndarray,
                      n_samples: int) -> List[int]:
        """
        Selecciona muestras combinando incertidumbre y densidad.

        Args:
            model: Modelo entrenado
            labeled_data: Datos etiquetados para calcular densidad
            unlabeled_data: Datos no etiquetados
            n_samples: Número de muestras a seleccionar

        Returns:
            Lista de índices de las muestras seleccionadas
        """
        try:
            # Calcular scores de incertidumbre
            uncertainty_scores = self._get_uncertainty_scores(model, unlabeled_data)

            # Calcular scores de densidad
            density_scores = self._calculate_density_scores(labeled_data, unlabeled_data)

            # Combinar scores: incertidumbre * (1 - densidad) + densidad * peso
            combined_scores = (
                (1 - self.density_weight) * uncertainty_scores +
                self.density_weight * density_scores
            )

            # Seleccionar índices con mayor score combinado
            indices = np.argsort(combined_scores)[-n_samples:][::-1]
            return indices.tolist()

        except Exception as e:
            logger.error(f"Error en select_samples: {e}")
            raise

    def _get_uncertainty_scores(self, model: Any, unlabeled_data: np.ndarray) -> np.ndarray:
        """Obtiene scores de incertidumbre de la estrategia subyacente"""
        if hasattr(self.uncertainty_strategy, 'select_samples'):
            # Si es una clase de estrategia, crear scores temporales
            all_indices = list(range(len(unlabeled_data)))
            selected = self.uncertainty_strategy.select_samples(model, unlabeled_data, len(unlabeled_data))
            scores = np.zeros(len(unlabeled_data))
            for rank, idx in enumerate(selected):
                scores[idx] = len(unlabeled_data) - rank  # Score basado en ranking
            return scores
        else:
            # Asumir que es un método directo
            return self.uncertainty_strategy(model, unlabeled_data)

    def _calculate_density_scores(self, labeled_data: np.ndarray, unlabeled_data: np.ndarray) -> np.ndarray:
        """
        Calcula scores de densidad basados en distancia a datos etiquetados.
        Mayor densidad = menor distancia promedio a k vecinos más cercanos.
        """
        # Combinar datos etiquetados y no etiquetados para calcular densidad
        all_data = np.vstack([labeled_data, unlabeled_data])

        # Calcular distancias
        distances = euclidean_distances(unlabeled_data, all_data)

        # Para cada punto no etiquetado, calcular densidad como 1 / distancia promedio a k vecinos
        density_scores = np.zeros(len(unlabeled_data))

        for i in range(len(unlabeled_data)):
            # Distancia a los k vecinos más cercanos (excluyendo el punto mismo si está en all_data)
            neighbor_distances = np.sort(distances[i, :])[:self.k_neighbors + 1]
            # Excluir distancia 0 si el punto está en labeled_data
            if neighbor_distances[0] == 0:
                neighbor_distances = neighbor_distances[1:]
            else:
                neighbor_distances = neighbor_distances[:self.k_neighbors]

            avg_distance = np.mean(neighbor_distances)
            density_scores[i] = 1 / (avg_distance + 1e-10)  # Evitar división por cero

        # Normalizar scores de densidad
        if np.max(density_scores) > 0:
            density_scores = density_scores / np.max(density_scores)

        return density_scores