import numpy as np
from typing import List, Any
from sklearn.base import BaseEstimator
import logging

logger = logging.getLogger(__name__)

class QueryByCommittee:
    """
    Estrategia de consulta por comité para aprendizaje activo.
    Usa un comité de modelos y selecciona muestras con mayor desacuerdo.
    """

    def __init__(self, committee: List[BaseEstimator], disagreement_measure: str = 'vote_entropy'):
        """
        Inicializa QueryByCommittee.

        Args:
            committee: Lista de modelos entrenados
            disagreement_measure: Medida de desacuerdo ('vote_entropy', 'kl_divergence', 'consensus')
        """
        self.committee = committee
        self.disagreement_measure = disagreement_measure
        self.valid_measures = ['vote_entropy', 'kl_divergence', 'consensus']

        if disagreement_measure not in self.valid_measures:
            raise ValueError(f"Medida {disagreement_measure} no válida. Opciones: {self.valid_measures}")

        if len(committee) < 2:
            raise ValueError("El comité debe tener al menos 2 modelos")

    def select_samples(self, unlabeled_data: np.ndarray, n_samples: int) -> List[int]:
        """
        Selecciona muestras con mayor desacuerdo entre el comité.

        Args:
            unlabeled_data: Datos no etiquetados
            n_samples: Número de muestras a seleccionar

        Returns:
            Lista de índices de las muestras seleccionadas
        """
        try:
            # Obtener predicciones de todos los modelos del comité
            predictions = []
            probabilities = []

            for model in self.committee:
                pred = model.predict(unlabeled_data)
                prob = model.predict_proba(unlabeled_data)
                predictions.append(pred)
                probabilities.append(prob)

            predictions = np.array(predictions)  # (n_models, n_samples)
            probabilities = np.array(probabilities)  # (n_models, n_samples, n_classes)

            if self.disagreement_measure == 'vote_entropy':
                scores = self._vote_entropy(predictions)
            elif self.disagreement_measure == 'kl_divergence':
                scores = self._kl_divergence(probabilities)
            elif self.disagreement_measure == 'consensus':
                scores = self._consensus(predictions)

            # Seleccionar índices con mayor desacuerdo
            indices = np.argsort(scores)[-n_samples:][::-1]
            return indices.tolist()

        except Exception as e:
            logger.error(f"Error en select_samples: {e}")
            raise

    def _vote_entropy(self, predictions: np.ndarray) -> np.ndarray:
        """Calcula la entropía de votos"""
        n_models, n_samples = predictions.shape
        scores = np.zeros(n_samples)

        for i in range(n_samples):
            votes = predictions[:, i]
            unique, counts = np.unique(votes, return_counts=True)
            probs = counts / n_models
            scores[i] = -np.sum(probs * np.log(probs + 1e-10))

        return scores

    def _kl_divergence(self, probabilities: np.ndarray) -> np.ndarray:
        """Calcula la divergencia KL promedio entre modelos"""
        n_models, n_samples, n_classes = probabilities.shape
        scores = np.zeros(n_samples)

        for i in range(n_samples):
            sample_probs = probabilities[:, i, :]  # (n_models, n_classes)
            avg_prob = np.mean(sample_probs, axis=0)

            kl_sum = 0
            for j in range(n_models):
                kl_sum += np.sum(sample_probs[j] * np.log((sample_probs[j] + 1e-10) / (avg_prob + 1e-10)))

            scores[i] = kl_sum / n_models

        return scores

    def _consensus(self, predictions: np.ndarray) -> np.ndarray:
        """Calcula el desacuerdo como 1 - proporción de votos mayoritarios"""
        n_models, n_samples = predictions.shape
        scores = np.zeros(n_samples)

        for i in range(n_samples):
            votes = predictions[:, i]
            unique, counts = np.unique(votes, return_counts=True)
            max_count = np.max(counts)
            scores[i] = 1 - (max_count / n_models)

        return scores