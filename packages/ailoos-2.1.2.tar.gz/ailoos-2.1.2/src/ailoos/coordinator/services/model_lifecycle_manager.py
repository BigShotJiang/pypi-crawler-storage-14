"""
Model Lifecycle Manager - Gestión del ciclo de vida de modelos
Maneja transiciones entre desarrollo→validación→producción→deprecación.
"""

import asyncio
import time
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from ...core.logging import get_logger
from ...federated.federated_version_manager import FederatedVersionManager, ModelVersion, VersionStatus
from ...federated.version_validator import VersionValidator
from ...federated.ipfs_version_distributor import IPFSVersionDistributor, DistributionStrategy
from .model_registry import ModelRegistry

logger = get_logger(__name__)


class LifecycleStage(Enum):
    """Etapas del ciclo de vida del modelo."""
    DEVELOPMENT = "development"
    VALIDATION = "validation"
    PRODUCTION = "production"
    DEPRECATION = "deprecation"
    ARCHIVED = "archived"


class LifecycleTransition(Enum):
    """Transiciones permitidas en el ciclo de vida."""
    START_VALIDATION = "start_validation"
    APPROVE_VALIDATION = "approve_validation"
    REJECT_VALIDATION = "reject_validation"
    PROMOTE_TO_PRODUCTION = "promote_to_production"
    START_DEPRECATION = "start_deprecation"
    ARCHIVE_MODEL = "archive_model"
    ROLLBACK = "rollback"


@dataclass
class LifecycleEvent:
    """Evento en el ciclo de vida."""
    model_name: str
    version_id: str
    from_stage: LifecycleStage
    to_stage: LifecycleStage
    transition: LifecycleTransition
    triggered_by: str
    reason: str
    timestamp: int = field(default_factory=lambda: int(time.time()))
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario."""
        return {
            'model_name': self.model_name,
            'version_id': self.version_id,
            'from_stage': self.from_stage.value,
            'to_stage': self.to_stage.value,
            'transition': self.transition.value,
            'triggered_by': self.triggered_by,
            'reason': self.reason,
            'timestamp': self.timestamp,
            'metadata': self.metadata
        }


class ModelLifecycleManager:
    """
    Gestor del ciclo de vida completo de modelos.
    Coordina transiciones entre etapas con validaciones y approvals.
    """

    def __init__(self, version_manager: FederatedVersionManager,
                 validator: VersionValidator,
                 distributor: IPFSVersionDistributor,
                 registry: ModelRegistry):
        """
        Inicializar el gestor de ciclo de vida.

        Args:
            version_manager: Gestor de versiones federadas
            validator: Validador de versiones
            distributor: Distribuidor de versiones
            registry: Registro de modelos
        """
        self.version_manager = version_manager
        self.validator = validator
        self.distributor = distributor
        self.registry = registry

        # Estado del ciclo de vida
        self.lifecycle_history: Dict[str, List[LifecycleEvent]] = {}  # model_name -> events
        self.stage_requirements: Dict[LifecycleStage, Dict[str, Any]] = self._init_stage_requirements()

        # Callbacks para eventos
        self.lifecycle_callbacks: List[Callable] = []

        # Locks
        self.lifecycle_lock = asyncio.Lock()

        logger.info("🚀 ModelLifecycleManager initialized")

    def _init_stage_requirements(self) -> Dict[LifecycleStage, Dict[str, Any]]:
        """Inicializar requisitos para cada etapa."""
        return {
            LifecycleStage.DEVELOPMENT: {
                'min_versions': 1,
                'requires_validation': False,
                'auto_transition': False
            },
            LifecycleStage.VALIDATION: {
                'min_validations': 3,
                'min_score': 0.7,
                'timeout_hours': 24,
                'requires_validation': True,
                'auto_transition': False
            },
            LifecycleStage.PRODUCTION: {
                'min_uptime_hours': 24,
                'performance_threshold': 0.8,
                'requires_validation': True,
                'auto_transition': False
            },
            LifecycleStage.DEPRECATION: {
                'deprecation_period_days': 30,
                'requires_validation': False,
                'auto_transition': True
            },
            LifecycleStage.ARCHIVED: {
                'retention_days': 365,
                'requires_validation': False,
                'auto_transition': False
            }
        }

    async def get_current_stage(self, model_name: str) -> LifecycleStage:
        """Obtener etapa actual de un modelo."""
        # Obtener versión activa
        active_version = await self.registry.get_active_version(model_name)
        if not active_version:
            return LifecycleStage.DEVELOPMENT

        # Mapear estado de versión a etapa del ciclo de vida
        status_mapping = {
            VersionStatus.DRAFT: LifecycleStage.DEVELOPMENT,
            VersionStatus.VALIDATING: LifecycleStage.VALIDATION,
            VersionStatus.VALIDATED: LifecycleStage.VALIDATION,
            VersionStatus.ACTIVE: LifecycleStage.PRODUCTION,
            VersionStatus.DEPRECATED: LifecycleStage.DEPRECATION,
            VersionStatus.ROLLED_BACK: LifecycleStage.DEPRECATION
        }

        return status_mapping.get(active_version.status, LifecycleStage.DEVELOPMENT)

    async def transition_model(self, model_name: str, transition: LifecycleTransition,
                             triggered_by: str, reason: str = "",
                             metadata: Dict[str, Any] = None) -> bool:
        """
        Ejecutar transición en el ciclo de vida del modelo.

        Args:
            model_name: Nombre del modelo
            transition: Transición a ejecutar
            triggered_by: Usuario/nodo que ejecuta la transición
            reason: Razón de la transición
            metadata: Metadatos adicionales

        Returns:
            True si la transición fue exitosa
        """
        async with self.lifecycle_lock:
            try:
                current_stage = await self.get_current_stage(model_name)
                target_stage = self._get_target_stage(transition)

                # Validar transición
                if not self._is_valid_transition(current_stage, transition):
                    raise ValueError(f"Invalid transition {transition.value} from {current_stage.value}")

                # Verificar requisitos previos
                if not await self._check_transition_requirements(model_name, transition):
                    raise ValueError(f"Transition requirements not met for {transition.value}")

                # Ejecutar transición
                success = await self._execute_transition(model_name, transition, triggered_by, reason, metadata or {})

                if success:
                    # Registrar evento
                    await self._record_lifecycle_event(
                        model_name, "", current_stage, target_stage, transition, triggered_by, reason, metadata or {}
                    )

                    # Notificar callbacks
                    await self._notify_lifecycle_event(model_name, transition, target_stage)

                    logger.info(f"✅ Model {model_name} transitioned: {current_stage.value} -> {target_stage.value} ({transition.value})")
                    return True

                return False

            except Exception as e:
                logger.error(f"❌ Failed to transition model {model_name}: {e}")
                raise

    def _get_target_stage(self, transition: LifecycleTransition) -> LifecycleStage:
        """Obtener etapa objetivo de una transición."""
        transition_mapping = {
            LifecycleTransition.START_VALIDATION: LifecycleStage.VALIDATION,
            LifecycleTransition.APPROVE_VALIDATION: LifecycleStage.VALIDATION,
            LifecycleTransition.REJECT_VALIDATION: LifecycleStage.DEVELOPMENT,
            LifecycleTransition.PROMOTE_TO_PRODUCTION: LifecycleStage.PRODUCTION,
            LifecycleTransition.START_DEPRECATION: LifecycleStage.DEPRECATION,
            LifecycleTransition.ARCHIVE_MODEL: LifecycleStage.ARCHIVED,
            LifecycleTransition.ROLLBACK: LifecycleStage.PRODUCTION  # Rollback vuelve a producción con versión anterior
        }
        return transition_mapping[transition]

    def _is_valid_transition(self, current_stage: LifecycleStage, transition: LifecycleTransition) -> bool:
        """Verificar si una transición es válida desde la etapa actual."""
        valid_transitions = {
            LifecycleStage.DEVELOPMENT: [LifecycleTransition.START_VALIDATION],
            LifecycleStage.VALIDATION: [
                LifecycleTransition.APPROVE_VALIDATION,
                LifecycleTransition.REJECT_VALIDATION,
                LifecycleTransition.ROLLBACK
            ],
            LifecycleStage.PRODUCTION: [
                LifecycleTransition.START_DEPRECATION,
                LifecycleTransition.ROLLBACK
            ],
            LifecycleStage.DEPRECATION: [LifecycleTransition.ARCHIVE_MODEL],
            LifecycleStage.ARCHIVED: []  # No transitions from archived
        }

        return transition in valid_transitions.get(current_stage, [])

    async def _check_transition_requirements(self, model_name: str, transition: LifecycleTransition) -> bool:
        """Verificar requisitos para una transición."""
        if transition == LifecycleTransition.START_VALIDATION:
            # Verificar que existe al menos una versión
            versions = await self.registry.get_model_versions(model_name)
            return len(versions) > 0

        elif transition == LifecycleTransition.APPROVE_VALIDATION:
            # Verificar validaciones completadas
            active_version = await self.registry.get_active_version(model_name)
            if not active_version:
                return False

            validation_status = await self.version_manager.get_validation_status(active_version.version_id)
            requirements = self.stage_requirements[LifecycleStage.VALIDATION]

            approved_votes = sum(1 for v in validation_status['votes'].values()
                               if v == 'approved')
            return approved_votes >= requirements['min_validations']

        elif transition == LifecycleTransition.PROMOTE_TO_PRODUCTION:
            # Verificar que la validación fue exitosa
            active_version = await self.registry.get_active_version(model_name)
            return active_version and active_version.status == VersionStatus.VALIDATED

        elif transition == LifecycleTransition.START_DEPRECATION:
            # Siempre permitido desde producción
            return True

        elif transition == LifecycleTransition.ARCHIVE_MODEL:
            # Verificar período de deprecación
            # En producción, esto sería más complejo
            return True

        return True

    async def _execute_transition(self, model_name: str, transition: LifecycleTransition,
                                triggered_by: str, reason: str, metadata: Dict[str, Any]) -> bool:
        """Ejecutar la lógica específica de la transición."""
        try:
            if transition == LifecycleTransition.START_VALIDATION:
                return await self._start_validation(model_name, triggered_by)

            elif transition == LifecycleTransition.APPROVE_VALIDATION:
                return await self._approve_validation(model_name, triggered_by)

            elif transition == LifecycleTransition.REJECT_VALIDATION:
                return await self._reject_validation(model_name, triggered_by, reason)

            elif transition == LifecycleTransition.PROMOTE_TO_PRODUCTION:
                return await self._promote_to_production(model_name, triggered_by)

            elif transition == LifecycleTransition.START_DEPRECATION:
                return await self._start_deprecation(model_name, triggered_by, reason)

            elif transition == LifecycleTransition.ARCHIVE_MODEL:
                return await self._archive_model(model_name, triggered_by)

            elif transition == LifecycleTransition.ROLLBACK:
                return await self._rollback_model(model_name, triggered_by, reason, metadata)

            return False

        except Exception as e:
            logger.error(f"❌ Transition execution failed: {e}")
            return False

    async def _start_validation(self, model_name: str, triggered_by: str) -> bool:
        """Iniciar proceso de validación."""
        active_version = await self.registry.get_active_version(model_name)
        if not active_version:
            return False

        # Cambiar estado a VALIDATING
        active_version.status = VersionStatus.VALIDATING

        # Iniciar validación colectiva
        # En producción, obtendríamos nodos participantes
        node_ids = ["node_1", "node_2", "node_3"]  # Placeholder
        await self.validator.start_validation(active_version.version_id, node_ids)

        return True

    async def _approve_validation(self, model_name: str, triggered_by: str) -> bool:
        """Aprobar validación y promover a VALIDATED."""
        active_version = await self.registry.get_active_version(model_name)
        if not active_version:
            return False

        # El version manager ya maneja la aprobación automática
        # Aquí solo verificamos que esté validado
        return active_version.status == VersionStatus.VALIDATED

    async def _reject_validation(self, model_name: str, triggered_by: str, reason: str) -> bool:
        """Rechazar validación y volver a desarrollo."""
        active_version = await self.registry.get_active_version(model_name)
        if not active_version:
            return False

        # Deprecar versión rechazada
        await self.version_manager.deprecate_version(
            active_version.version_id,
            reason=f"Validation rejected: {reason}"
        )

        return True

    async def _promote_to_production(self, model_name: str, triggered_by: str) -> bool:
        """Promover modelo validado a producción."""
        active_version = await self.registry.get_active_version(model_name)
        if not active_version or active_version.status != VersionStatus.VALIDATED:
            return False

        # Activar versión (esto la pone en ACTIVE)
        await self.version_manager.force_activate_version(active_version.version_id, "Promoted to production")

        # Distribuir a todos los nodos
        await self.distributor.distribute_version(
            version_id=active_version.version_id,
            target_nodes=["all_nodes"],  # Placeholder
            strategy=DistributionStrategy.BROADCAST,
            priority=5
        )

        return True

    async def _start_deprecation(self, model_name: str, triggered_by: str, reason: str) -> bool:
        """Iniciar proceso de deprecación."""
        active_version = await self.registry.get_active_version(model_name)
        if not active_version:
            return False

        # Deprecar versión
        await self.version_manager.deprecate_version(
            active_version.version_id,
            reason=f"Model deprecated: {reason}"
        )

        return True

    async def _archive_model(self, model_name: str, triggered_by: str) -> bool:
        """Archivar modelo."""
        return await self.registry.archive_model(model_name)

    async def _rollback_model(self, model_name: str, triggered_by: str, reason: str,
                            metadata: Dict[str, Any]) -> bool:
        """Ejecutar rollback del modelo."""
        target_version = metadata.get('target_version')
        if not target_version:
            raise ValueError("Target version required for rollback")

        # Usar rollback coordinator para rollback automático
        # Por ahora, implementación simplificada
        await self.version_manager.force_activate_version(target_version, f"Rolled back: {reason}")

        return True

    async def _record_lifecycle_event(self, model_name: str, version_id: str,
                                    from_stage: LifecycleStage, to_stage: LifecycleStage,
                                    transition: LifecycleTransition, triggered_by: str,
                                    reason: str, metadata: Dict[str, Any]):
        """Registrar evento del ciclo de vida."""
        event = LifecycleEvent(
            model_name=model_name,
            version_id=version_id,
            from_stage=from_stage,
            to_stage=to_stage,
            transition=transition,
            triggered_by=triggered_by,
            reason=reason,
            metadata=metadata
        )

        if model_name not in self.lifecycle_history:
            self.lifecycle_history[model_name] = []

        self.lifecycle_history[model_name].append(event)

    async def _notify_lifecycle_event(self, model_name: str, transition: LifecycleTransition,
                                    new_stage: LifecycleStage):
        """Notificar eventos del ciclo de vida."""
        for callback in self.lifecycle_callbacks:
            try:
                await callback(model_name, transition, new_stage)
            except Exception as e:
                logger.warning(f"Lifecycle callback failed: {e}")

    def add_lifecycle_callback(self, callback: Callable):
        """Agregar callback para eventos del ciclo de vida."""
        self.lifecycle_callbacks.append(callback)

    async def get_lifecycle_history(self, model_name: str) -> List[LifecycleEvent]:
        """Obtener historial del ciclo de vida de un modelo."""
        return self.lifecycle_history.get(model_name, [])

    async def get_stage_requirements(self, stage: LifecycleStage) -> Dict[str, Any]:
        """Obtener requisitos para una etapa."""
        return self.stage_requirements.get(stage, {})

    def update_stage_requirements(self, stage: LifecycleStage, requirements: Dict[str, Any]):
        """Actualizar requisitos para una etapa."""
        if stage in self.stage_requirements:
            self.stage_requirements[stage].update(requirements)
            logger.info(f"⚙️ Updated requirements for stage {stage.value}")

    def get_lifecycle_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del ciclo de vida."""
        total_events = sum(len(events) for events in self.lifecycle_history.values())

        transition_counts = {}
        for events in self.lifecycle_history.values():
            for event in events:
                transition = event.transition.value
                transition_counts[transition] = transition_counts.get(transition, 0) + 1

        return {
            'total_models': len(self.lifecycle_history),
            'total_events': total_events,
            'transition_counts': transition_counts,
            'most_common_transition': max(transition_counts.items(), key=lambda x: x[1]) if transition_counts else None
        }


# Instancia global del servicio
model_lifecycle_manager = ModelLifecycleManager(None, None, None, None)