"""
gRPC services for AILOOS Coordinator API.
"""