"""
API routes for the coordinator service.
"""

from fastapi import APIRouter

from .endpoints import (
    admin,
    analytics,
    contributions,
    coordinator_endpoints,
    datahub,
    empoorio_lm,
    federated,
    inference,
    # integrations,  # Commented out - has import issues
    ipfs,
    marketplace,
    memory,
    metrics,
    models,
    nodes,
    notifications,
    # parental,  # Commented out - has import issues
    # personalization,  # Commented out - has import issues
    privacy,
    rag,
    rewards,
    rounds,
    security,
    sessions,
    settings,
    system_tools,
    users,
    wallet,
    websocket
)
from .websocket import (
    websocket_api_router,
    session_websocket_router,
    metrics_websocket_router,
    alerts_websocket_router,
    federated_websocket_router
)
from ..auth.node_auth import router as auth_router


# Create main API router
api_router = APIRouter()

# Include endpoint routers
api_router.include_router(
    admin.router,
    prefix="/admin",
    tags=["admin"]
)

api_router.include_router(
    contributions.router,
    prefix="/contributions",
    tags=["contributions"]
)

api_router.include_router(
    coordinator_endpoints.router,
    prefix="/coordinator",
    tags=["coordinator"]
)

api_router.include_router(
    empoorio_lm.router,
    tags=["empoorio-lm"]
)


api_router.include_router(
    inference.router,
    prefix="/inference",
    tags=["inference"]
)

api_router.include_router(
    ipfs.router,
    prefix="/ipfs",
    tags=["ipfs"]
)

# api_router.include_router(  # Commented out - has import issues
#     integrations.router,
#     prefix="/integrations",
#     tags=["integrations"]
# )

api_router.include_router(
    marketplace.router,
    prefix="/marketplace",
    tags=["marketplace"]
)

api_router.include_router(
    memory.router,
    prefix="/memory",
    tags=["memory"]
)

api_router.include_router(
    metrics.router,
    prefix="/metrics",
    tags=["metrics"]
)


api_router.include_router(
    models.router,
    prefix="/models",
    tags=["models"]
)

api_router.include_router(
    nodes.router,
    prefix="/nodes",
    tags=["nodes"]
)

api_router.include_router(
    notifications.router,
    prefix="/notifications",
    tags=["notifications"]
)

# api_router.include_router(  # Commented out - has import issues
#     parental.router,
#     prefix="/parental",
#     tags=["parental"]
# )

# api_router.include_router(  # Commented out - has import issues
#     personalization.router,
#     prefix="/personalization",
#     tags=["personalization"]
# )

api_router.include_router(
    rewards.router,
    prefix="/rewards",
    tags=["rewards"]
)

api_router.include_router(
    rounds.router,
    prefix="/rounds",
    tags=["rounds"]
)


api_router.include_router(
    security.router,
    prefix="/security",
    tags=["security"]
)

api_router.include_router(
    sessions.router,
    prefix="/sessions",
    tags=["sessions"]
)

api_router.include_router(
    settings.router,
    prefix="/settings",
    tags=["settings"]
)

# Add UI settings endpoint at /settings/ui
from .endpoints.settings import get_ui_settings
api_router.add_api_route(
    "/settings/ui",
    get_ui_settings,
    methods=["GET"],
    summary="Obtener preferencias de interfaz de usuario",
    description="Obtiene todas las preferencias de interfaz de usuario del usuario actual.",
    tags=["settings-ui"]
)

api_router.include_router(
    users.router,
    prefix="/users",
    tags=["users"]
)

api_router.include_router(
    wallet.router,
    prefix="/wallet",
    tags=["wallet"]
)

# api_router.include_router(  # Commented out - modules not found
#     verification.router,
#     prefix="/verification",
#     tags=["verification"]
# )

# api_router.include_router(  # Commented out - modules not found
#     auditing.router,
#     prefix="/auditing",
#     tags=["auditing"]
# )

api_router.include_router(
    websocket.router,
    prefix="/websocket",
    tags=["websocket"]
)

api_router.include_router(
    analytics.router,
    prefix="/analytics",
    tags=["analytics"]
)

api_router.include_router(
    system_tools.router,
    prefix="/system-tools",
    tags=["system-tools"]
)

api_router.include_router(
    datahub.router,
    tags=["datahub"]
)

api_router.include_router(
    federated.router,
    prefix="/federated",
    tags=["federated"]
)

api_router.include_router(
    rag.router,
    tags=["rag"]
)

api_router.include_router(
    privacy.router,
    prefix="/privacy",
    tags=["privacy"]
)

# Include WebSocket API routers
api_router.include_router(
    websocket_api_router,
    prefix="/ws-api",
    tags=["websocket-api"]
)

api_router.include_router(
    session_websocket_router,
    tags=["websocket-sessions"]
)

api_router.include_router(
    metrics_websocket_router,
    tags=["websocket-metrics"]
)

api_router.include_router(
    alerts_websocket_router,
    tags=["websocket-alerts"]
)

api_router.include_router(
    federated_websocket_router,
    tags=["websocket-federated"]
)

api_router.include_router(
    auth_router,
    prefix="/auth",
    tags=["authentication"]
)