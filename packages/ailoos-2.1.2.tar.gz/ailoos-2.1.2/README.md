# AILOOS - Decentralized AI Learning Orchestration System

AILOOS is a comprehensive SDK for federated learning and decentralized AI training, featuring privacy-preserving machine learning, secure data infrastructure, and complete economic system with DRACMA tokens.

## 🚀 Installation

```bash
pip install ailoos
```

## 📋 Requirements

- Python 3.8+
- Internet connection for IPFS operations

## 🛠️ Quick Start

### Basic Usage

```python
from ailoos import quick_setup

# Setup AILOOS automatically
success = quick_setup(verbose=True)
if success:
    print("AILOOS is ready!")
```

### Configuration

```bash
# Initialize configuration
ailoos config init

# Show current configuration
ailoos config show

# Set configuration values
ailoos config set node.coordinator_url "http://localhost:5001"
```

### Start Federated Node

```python
import asyncio
from ailoos import start_federated_node

# Start a federated learning node
await start_federated_node()
```

## 📚 Key Features

- **Federated Learning**: Privacy-preserving distributed training
- **Secure Data Infrastructure**: PII scrubbing and IPFS integration
- **Economic System**: DRACMA token management and staking
- **Zero Configuration**: Automatic setup and discovery
- **GDPR Compliance**: Built-in privacy protection

## 🔧 Advanced Usage

### Data Processing

```python
from ailoos.data.dataset_manager import dataset_manager

# Process a dataset with automatic PII scrubbing
result = dataset_manager.process_text_file(
    file_path="data.txt",
    dataset_name="my_dataset",
    shard_size_mb=10
)
```

### Wallet Operations

```python
from ailoos.blockchain.wallet_manager import get_wallet_manager

wm = get_wallet_manager()
wallet_id = wm.create_wallet("user123", "secure_password")
balance = wm.get_balance(wallet_id)
```

## 📖 Documentation

For complete documentation, visit:
- [GitHub Repository](https://github.com/empoorio/ailoos)
- [Official Documentation](https://docs.ailoos.dev)

## 📝 License

Copyright © 2024 AILOOS Technologies & Empoorio Ecosystem. All rights reserved.

## 📞 Support

- **Email**: dev@empoorio.com
- **GitHub Issues**: [github.com/empoorio/ailoos/issues](https://github.com/empoorio/ailoos/issues)

---

**AILOOS** - *Sovereign Decentralized AI Library with complete economic system.*
