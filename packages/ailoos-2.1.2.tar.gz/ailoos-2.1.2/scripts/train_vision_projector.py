#!/usr/bin/env python3
"""
Train Vision Projector for Empoorio-Vision
Entrena el proyector multimodal que alinea CLIP embeddings con EmpoorioLM.
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
import argparse
import logging
import sys
import json
from PIL import Image
import requests
from io import BytesIO

# Add directories to path
sys.path.insert(0, str(Path(__file__).parent.parent / "models"))
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    from empoorio_lm.model import EmpoorioLM
    from empoorio_lm.config import EmpoorioLMConfig
    from vision.projector import MultiModalProjector
    from vision.encoder import SigLIPEncoder
except ImportError:
    # Fallback to src/ailoos/models
    from ailoos.models.empoorio_lm.model import EmpoorioLM
    from ailoos.models.empoorio_lm.config import EmpoorioLMConfig
    from ailoos.models.vision.projector import MultiModalProjector
    from ailoos.models.vision.encoder import SigLIPEncoder

logger = logging.getLogger(__name__)


class VisionTextDataset(Dataset):
    """
    Dataset for vision-text alignment training.
    Uses simple image-text pairs for projector training.
    """

    def __init__(self, size: int = 1000):
        self.size = size

        # Simple text prompts that correspond to visual concepts
        self.text_prompts = [
            "a photo of a cat",
            "a photo of a dog",
            "a photo of a car",
            "a photo of a house",
            "a photo of a tree",
            "a photo of a person",
            "a photo of food",
            "a photo of water",
            "a photo of a mountain",
            "a photo of the sky"
        ] * (size // 10 + 1)

        # Generate synthetic vision features (simulating CLIP embeddings)
        self.vision_features = []
        for i in range(size):
            # Create synthetic vision features with some structure
            base_features = torch.randn(256, 768)  # 256 patches, 768 dim (CLIP-like)
            # Add some correlation based on text category
            category_idx = i % len(self.text_prompts)
            category_signal = torch.randn(768) * 0.1
            base_features += category_signal.unsqueeze(0)
            self.vision_features.append(base_features)

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        return {
            'vision_features': self.vision_features[idx],
            'text_prompt': self.text_prompts[idx % len(self.text_prompts)]
        }


class VisionProjectorTrainer:
    """
    Trainer for the multimodal projector.
    """

    def __init__(
        self,
        projector: MultiModalProjector,
        llm_model: EmpoorioLM,
        vision_encoder: Optional[SigLIPEncoder] = None,
        device: str = "auto"
    ):
        self.projector = projector
        self.llm_model = llm_model
        self.vision_encoder = vision_encoder
        self.device = torch.device(device if device != "auto" else ("cuda" if torch.cuda.is_available() else "cpu"))

        # Move models to device
        self.projector.to(self.device)
        self.llm_model.to(self.device)
        if self.vision_encoder:
            self.vision_encoder.to(self.device)

        # Freeze LLM parameters - only train projector
        for param in self.llm_model.parameters():
            param.requires_grad = False

        # Optimizer and loss
        self.optimizer = optim.AdamW(self.projector.parameters(), lr=1e-4, weight_decay=0.01)
        self.criterion = nn.MSELoss()  # Simple alignment loss

        logger.info(f"VisionProjectorTrainer initialized on {self.device}")

    def compute_alignment_loss(
        self,
        vision_features: torch.Tensor,
        text_prompt: str
    ) -> torch.Tensor:
        """
        Compute alignment loss between projected vision features and text embeddings.

        For simplicity, we'll use a contrastive-like loss where vision and text
        features from the same pair should be similar.
        """
        # Project vision features
        projected_vision = self.projector(vision_features.unsqueeze(0))  # [1, num_patches, llm_hidden_size]

        # Get text embeddings from LLM
        text_tokens = self.llm_model.tokenizer.encode(text_prompt, return_tensors="pt").to(self.device)
        with torch.no_grad():
            text_outputs = self.llm_model(text_tokens)
            text_embeddings = text_outputs["hidden_states"][-1]  # Last layer hidden states

        # Simple alignment: average vision features should be close to average text features
        vision_avg = projected_vision.mean(dim=1)  # [1, llm_hidden_size]
        text_avg = text_embeddings.mean(dim=1)  # [1, llm_hidden_size]

        # MSE loss between averaged features
        loss = self.criterion(vision_avg, text_avg)

        return loss

    def train_epoch(self, dataloader: DataLoader) -> Dict[str, float]:
        """Train for one epoch."""
        self.projector.train()
        total_loss = 0.0
        num_batches = 0

        for batch in dataloader:
            vision_features = batch['vision_features'].to(self.device)
            text_prompts = batch['text_prompt']

            batch_loss = 0.0
            for i in range(len(text_prompts)):
                loss = self.compute_alignment_loss(vision_features[i], text_prompts[i])
                batch_loss += loss

            batch_loss /= len(text_prompts)

            # Backward pass
            self.optimizer.zero_grad()
            batch_loss.backward()
            self.optimizer.step()

            total_loss += batch_loss.item()
            num_batches += 1

        avg_loss = total_loss / num_batches
        return {"loss": avg_loss}

    def validate(self, dataloader: DataLoader) -> Dict[str, float]:
        """Validate projector alignment."""
        self.projector.eval()
        total_loss = 0.0
        num_batches = 0

        with torch.no_grad():
            for batch in dataloader:
                vision_features = batch['vision_features'].to(self.device)
                text_prompts = batch['text_prompt']

                batch_loss = 0.0
                for i in range(len(text_prompts)):
                    loss = self.compute_alignment_loss(vision_features[i], text_prompts[i])
                    batch_loss += loss

                batch_loss /= len(text_prompts)
                total_loss += batch_loss.item()
                num_batches += 1

        avg_loss = total_loss / num_batches
        return {"val_loss": avg_loss}

    def save_checkpoint(self, path: str, epoch: int, metrics: Dict[str, float]):
        """Save training checkpoint."""
        checkpoint = {
            'epoch': epoch,
            'projector_state_dict': self.projector.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'metrics': metrics,
            'projector_config': {
                'vision_dim': self.projector.vision_dim,
                'llm_hidden_size': self.projector.llm_hidden_size
            }
        }

        torch.save(checkpoint, path)
        logger.info(f"Checkpoint saved to {path}")

    def load_checkpoint(self, path: str) -> int:
        """Load training checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)
        self.projector.load_state_dict(checkpoint['projector_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

        logger.info(f"Checkpoint loaded from {path}")
        return checkpoint['epoch']


def main():
    """Main training function."""
    parser = argparse.ArgumentParser(description="Train Empoorio-Vision Projector")
    parser.add_argument("--llm_model_path", required=True, help="Path to EmpoorioLM model")
    parser.add_argument("--output_path", required=True, help="Output path for trained projector")
    parser.add_argument("--num_epochs", type=int, default=10, help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=4, help="Batch size")
    parser.add_argument("--learning_rate", type=float, default=1e-4, help="Learning rate")
    parser.add_argument("--dataset_size", type=int, default=1000, help="Dataset size")
    parser.add_argument("--device", choices=["auto", "cpu", "cuda", "mps"], default="auto", help="Compute device")

    args = parser.parse_args()

    # Setup logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    try:
        # Load EmpoorioLM model
        logger.info(f"Loading EmpoorioLM from {args.llm_model_path}")
        llm_config = EmpoorioLMConfig.load_config(str(Path(args.llm_model_path) / "config.json"))
        llm_model = EmpoorioLM.from_pretrained(args.llm_model_path, llm_config)

        # Create projector
        projector = MultiModalProjector(
            vision_dim=768,  # CLIP dimension
            llm_hidden_size=llm_config.hidden_size
        )

        # Create trainer
        trainer = VisionProjectorTrainer(
            projector=projector,
            llm_model=llm_model,
            device=args.device
        )

        # Create dataset and dataloader
        dataset = VisionTextDataset(size=args.dataset_size)
        dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True)

        # Training loop
        logger.info("🚀 Starting projector training...")
        best_loss = float('inf')

        for epoch in range(args.num_epochs):
            # Train
            train_metrics = trainer.train_epoch(dataloader)
            logger.info(f"Epoch {epoch+1}/{args.num_epochs} - Loss: {train_metrics['loss']:.4f}")

            # Validate
            val_metrics = trainer.validate(dataloader)
            logger.info(f"Validation Loss: {val_metrics['val_loss']:.4f}")

            # Save checkpoint
            checkpoint_path = Path(args.output_path) / f"projector_epoch_{epoch+1}.pt"
            checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
            trainer.save_checkpoint(str(checkpoint_path), epoch+1, {**train_metrics, **val_metrics})

            # Save best model
            if val_metrics['val_loss'] < best_loss:
                best_loss = val_metrics['val_loss']
                best_path = Path(args.output_path) / "projector_best.pt"
                trainer.save_checkpoint(str(best_path), epoch+1, {**train_metrics, **val_metrics})

        logger.info("✅ Projector training completed!")
        logger.info(f"Best validation loss: {best_loss:.4f}")

    except Exception as e:
        logger.error(f"❌ Training failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()