#!/usr/bin/env python3
"""
Script de pruebas exhaustivas para todas las APIs de AILOOS.
Prueba todas las APIs identificadas en el sistema incluyendo:
- APIs del coordinator (puerto 8000)
- APIs federadas (puerto 8001)
- APIs del wallet (puerto 8002)
- APIs de health checks
- APIs de métricas
- APIs de configuración
- APIs de marketplace
- APIs de privacidad

Incluye pruebas con y sin autenticación para verificar errores 401/403 apropiados.
"""

import asyncio
import json
import logging
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
import aiohttp
import websockets
import ssl
from concurrent.futures import ThreadPoolExecutor
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('api_test_results.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class APIComprehensiveTester:
    """Clase para pruebas exhaustivas de todas las APIs de AILOOS."""

    def __init__(self):
        self.base_urls = {
            'coordinator': 'http://localhost:8000',
            'federated': 'http://localhost:8001',
            'wallet': 'http://localhost:8002'
        }

        self.ws_urls = {
            'federated_session': 'ws://localhost:8001/api/v1/ws-api/session/',
            'metrics': 'ws://localhost:8001/api/v1/ws-api/metrics',
            'alerts': 'ws://localhost:8001/api/v1/ws-api/alerts',
            'federated_events': 'ws://localhost:8001/api/v1/ws-api/federated'
        }

        self.test_results = {
            'health_checks': [],
            'federated_apis': [],
            'marketplace_apis': [],
            'wallet_apis': [],
            'websocket_tests': [],
            'error_scenarios': [],
            'performance_tests': [],
            'summary': {}
        }

        self.auth_tokens = {
            'admin_token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInR5cGUiOiJhZG1pbiIsImV4cCI6MjAwMDAwMDAwMH0.test_admin_token',
            'node_token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJub2RlXzEiLCJ0eXBlIjoibm9kZSIsImV4cCI6MjAwMDAwMDAwMH0.test_node_token',
            'user_token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyXzEiLCJ0eXBlIjoidXNlciIsImV4cCI6MjAwMDAwMDAwMH0.test_user_token'
        }

        self.session = None
        self.executor = ThreadPoolExecutor(max_workers=10)

    async def init_session(self):
        """Initialize aiohttp session."""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30)
        )

    async def close_session(self):
        """Close aiohttp session."""
        if self.session:
            await self.session.close()

    async def make_request(self, method: str, url: str, headers: Dict = None,
                          data: Dict = None, expected_status: int = None,
                          description: str = "") -> Dict:
        """Make HTTP request and return result."""
        result = {
            'url': url,
            'method': method,
            'description': description,
            'success': False,
            'status_code': None,
            'response_time': None,
            'error': None,
            'response_data': None
        }

        try:
            start_time = time.time()

            async with self.session.request(
                method=method,
                url=url,
                headers=headers,
                json=data
            ) as response:
                result['status_code'] = response.status
                result['response_time'] = time.time() - start_time

                if response.content_type == 'application/json':
                    result['response_data'] = await response.json()
                else:
                    result['response_data'] = await response.text()

                if expected_status:
                    result['success'] = response.status == expected_status
                else:
                    result['success'] = response.status < 400

        except Exception as e:
            result['error'] = str(e)
            result['success'] = False

        return result

    async def test_health_checks(self):
        """Test all health check endpoints."""
        logger.info("🩺 Probando health checks...")

        health_endpoints = [
            {
                'url': f"{self.base_urls['federated']}/health",
                'description': 'Federated API Health Check',
                'expected_fields': ['status', 'active_sessions', 'registered_nodes']
            },
            {
                'url': f"{self.base_urls['coordinator']}/health",
                'description': 'Coordinator API Health Check',
                'expected_fields': ['status', 'service', 'version']
            },
            {
                'url': f"{self.base_urls['wallet']}/health",
                'description': 'Wallet API Health Check',
                'expected_fields': ['wallet_system_health']
            }
        ]

        for endpoint in health_endpoints:
            result = await self.make_request(
                'GET', endpoint['url'],
                description=endpoint['description'],
                expected_status=200
            )

            # Validate response structure
            if result['success'] and result['response_data']:
                missing_fields = []
                for field in endpoint['expected_fields']:
                    if field not in result['response_data']:
                        missing_fields.append(field)

                if missing_fields:
                    result['validation_error'] = f"Missing fields: {missing_fields}"
                    result['success'] = False

            self.test_results['health_checks'].append(result)
            logger.info(f"✅ {endpoint['description']}: {'PASS' if result['success'] else 'FAIL'}")

    async def test_federated_apis(self):
        """Test federated learning APIs."""
        logger.info("🔄 Probando APIs federadas...")

        # Test data
        session_id = "test-session-api-001"
        node_id = "test-node-api-001"

        federated_tests = [
            # Public endpoints (no auth required)
            {
                'method': 'GET',
                'url': f"{self.base_urls['federated']}/api/federated/sessions",
                'description': 'List Active Sessions (Public)',
                'expected_status': 200
            },
            {
                'method': 'GET',
                'url': f"{self.base_urls['federated']}/api/federated/stats",
                'description': 'Get Federated Stats (Public)',
                'expected_status': 200
            },

            # Auth-required endpoints
            {
                'method': 'POST',
                'url': f"{self.base_urls['federated']}/api/federated/session/create",
                'headers': {'Authorization': f'Bearer {self.auth_tokens["admin_token"]}'},
                'data': {
                    'session_id': session_id,
                    'model_name': 'EmpoorioLM-v1',
                    'rounds': 3,
                    'min_nodes': 2,
                    'max_nodes': 5,
                    'dataset_name': 'test-dataset',
                    'privacy_budget': 1.0
                },
                'description': 'Create Federated Session (Auth Required)',
                'expected_status': 200
            },
            {
                'method': 'GET',
                'url': f"{self.base_urls['federated']}/api/federated/session/{session_id}",
                'headers': {'Authorization': f'Bearer {self.auth_tokens["node_token"]}'},
                'description': 'Get Session Details (Auth Required)',
                'expected_status': 200
            },
            {
                'method': 'POST',
                'url': f"{self.base_urls['federated']}/api/federated/node/join",
                'headers': {'Authorization': f'Bearer {self.auth_tokens["node_token"]}'},
                'data': {
                    'session_id': session_id,
                    'node_id': node_id,
                    'hardware_info': {'cpu_cores': 8, 'memory_gb': 16},
                    'local_data_info': {'dataset_size': 1000, 'data_quality_score': 0.8}
                },
                'description': 'Join Federated Session (Auth Required)',
                'expected_status': 200
            }
        ]

        for test in federated_tests:
            result = await self.make_request(
                test['method'], test['url'],
                headers=test.get('headers'),
                data=test.get('data'),
                expected_status=test.get('expected_status'),
                description=test['description']
            )

            self.test_results['federated_apis'].append(result)
            logger.info(f"✅ {test['description']}: {'PASS' if result['success'] else 'FAIL'}")

    async def test_marketplace_apis(self):
        """Test marketplace APIs."""
        logger.info("🛒 Probando APIs de marketplace...")

        user_id = "test-user-marketplace-001"

        marketplace_tests = [
            # Wallet operations
            {
                'method': 'POST',
                'url': f"{self.base_urls['coordinator']}/api/v1/wallet/create",
                'data': {'user_id': user_id, 'label': 'test-wallet'},
                'description': 'Create User Wallet',
                'expected_status': 200
            },
            {
                'method': 'GET',
                'url': f"{self.base_urls['coordinator']}/api/v1/wallet/{user_id}/balance",
                'description': 'Get Wallet Balance',
                'expected_status': 200
            },

            # Marketplace listings
            {
                'method': 'GET',
                'url': f"{self.base_urls['coordinator']}/api/v1/marketplace/listings?limit=10",
                'description': 'Search Marketplace Listings',
                'expected_status': 200
            },
            {
                'method': 'GET',
                'url': f"{self.base_urls['coordinator']}/api/v1/marketplace/stats",
                'description': 'Get Marketplace Stats',
                'expected_status': 200
            }
        ]

        for test in marketplace_tests:
            result = await self.make_request(
                test['method'], test['url'],
                data=test.get('data'),
                expected_status=test.get('expected_status'),
                description=test['description']
            )

            self.test_results['marketplace_apis'].append(result)
            logger.info(f"✅ {test['description']}: {'PASS' if result['success'] else 'FAIL'}")

    async def test_wallet_apis(self):
        """Test wallet APIs."""
        logger.info("💰 Probando APIs de wallet...")

        wallet_tests = [
            {
                'method': 'POST',
                'url': f"{self.base_urls['wallet']}/api/wallet/connect",
                'data': {'wallet_type': 'metamask', 'user_id': 'test-user-wallet'},
                'description': 'Connect Wallet',
                'expected_status': 200
            },
            {
                'method': 'GET',
                'url': f"{self.base_urls['wallet']}/api/wallet/balance/0x123456789",
                'description': 'Get Wallet Balance',
                'expected_status': 200
            }
        ]

        for test in wallet_tests:
            result = await self.make_request(
                test['method'], test['url'],
                data=test.get('data'),
                expected_status=test.get('expected_status'),
                description=test['description']
            )

            self.test_results['wallet_apis'].append(result)
            logger.info(f"✅ {test['description']}: {'PASS' if result['success'] else 'FAIL'}")

    async def test_error_scenarios(self):
        """Test error scenarios (401/403 responses)."""
        logger.info("❌ Probando escenarios de error...")

        error_tests = [
            # Test without authentication where required
            {
                'method': 'POST',
                'url': f"{self.base_urls['federated']}/api/federated/session/create",
                'description': 'Create Session Without Auth (Should Fail)',
                'expected_status': 401
            },
            {
                'method': 'GET',
                'url': f"{self.base_urls['federated']}/api/federated/session/invalid-session-id",
                'description': 'Get Invalid Session (Should Fail)',
                'expected_status': 404
            },
            {
                'method': 'GET',
                'url': f"{self.base_urls['wallet']}/api/wallet/balance/invalid-address",
                'description': 'Get Invalid Wallet Balance (Should Fail)',
                'expected_status': 400
            }
        ]

        for test in error_tests:
            result = await self.make_request(
                test['method'], test['url'],
                expected_status=test.get('expected_status'),
                description=test['description']
            )

            self.test_results['error_scenarios'].append(result)
            logger.info(f"✅ {test['description']}: {'PASS' if result['success'] else 'FAIL'}")

    async def test_websocket_connections(self):
        """Test WebSocket connections."""
        logger.info("🔌 Probando conexiones WebSocket...")

        websocket_tests = []

        # Test WebSocket endpoints
        ws_test_cases = [
            {
                'url': f"{self.ws_urls['metrics']}?token={self.auth_tokens['admin_token']}",
                'description': 'Metrics WebSocket Connection',
                'expected_messages': ['metrics_update']
            },
            {
                'url': f"{self.ws_urls['alerts']}?token={self.auth_tokens['admin_token']}",
                'description': 'Alerts WebSocket Connection',
                'expected_messages': ['alert']
            },
            {
                'url': f"{self.ws_urls['federated_events']}?token={self.auth_tokens['node_token']}",
                'description': 'Federated Events WebSocket Connection',
                'expected_messages': ['federated_event']
            }
        ]

        for test_case in ws_test_cases:
            result = {
                'url': test_case['url'],
                'description': test_case['description'],
                'success': False,
                'error': None,
                'connection_time': None
            }

            try:
                start_time = time.time()

                # Create SSL context for WebSocket (only if using wss://)
                ssl_context = None
                if test_case['url'].startswith('wss://'):
                    ssl_context = ssl.create_default_context()
                    ssl_context.check_hostname = False
                    ssl_context.verify_mode = ssl.CERT_NONE

                async with websockets.connect(
                    test_case['url'],
                    ssl=ssl_context,
                    extra_headers={'User-Agent': 'AILOOS-API-Tester/1.0'}
                ) as websocket:
                    result['connection_time'] = time.time() - start_time
                    result['success'] = True

                    # Try to receive a message (timeout after 2 seconds)
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=2.0)
                        result['received_message'] = message
                    except asyncio.TimeoutError:
                        result['received_message'] = 'No message received within timeout'

            except Exception as e:
                result['error'] = str(e)

            websocket_tests.append(result)
            logger.info(f"✅ {test_case['description']}: {'PASS' if result['success'] else 'FAIL'}")

        self.test_results['websocket_tests'] = websocket_tests

    async def test_performance(self):
        """Test performance and load."""
        logger.info("⚡ Probando rendimiento...")

        performance_tests = []

        # Test concurrent requests to health endpoints
        concurrent_test = {
            'description': 'Concurrent Health Check Requests',
            'endpoint': f"{self.base_urls['coordinator']}/health",
            'concurrent_requests': 10,
            'results': []
        }

        async def single_request():
            return await self.make_request('GET', concurrent_test['endpoint'])

        # Run concurrent requests
        start_time = time.time()
        tasks = [single_request() for _ in range(concurrent_test['concurrent_requests'])]
        results = await asyncio.gather(*tasks)
        total_time = time.time() - start_time

        concurrent_test['total_time'] = total_time
        concurrent_test['avg_response_time'] = sum(r['response_time'] for r in results) / len(results)
        concurrent_test['success_rate'] = sum(1 for r in results if r['success']) / len(results)
        concurrent_test['results'] = results

        performance_tests.append(concurrent_test)
        logger.info(f"✅ Concurrent Health Checks: {concurrent_test['success_rate']:.1%} success rate, {concurrent_test['avg_response_time']:.2f}s avg")

        self.test_results['performance_tests'] = performance_tests

    def generate_report(self):
        """Generate comprehensive test report."""
        logger.info("📊 Generando reporte de resultados...")

        total_tests = 0
        passed_tests = 0

        # Calculate summary
        for category, tests in self.test_results.items():
            if category == 'summary':
                continue

            if isinstance(tests, list):
                total_tests += len(tests)
                passed_tests += sum(1 for test in tests if test.get('success', False))

        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0

        self.test_results['summary'] = {
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'failed_tests': total_tests - passed_tests,
            'success_rate': success_rate,
            'timestamp': datetime.now().isoformat(),
            'duration': time.time() - self.start_time if hasattr(self, 'start_time') else 0
        }

        # Save detailed report
        report_file = 'api_comprehensive_test_report.json'
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(self.test_results, f, indent=2, ensure_ascii=False)

        # Print summary
        print("\n" + "="*80)
        print("📊 REPORTE DE PRUEBAS COMPREHENSIVAS DE APIs AILOOS")
        print("="*80)
        print(f"Total de pruebas: {total_tests}")
        print(f"Pruebas exitosas: {passed_tests}")
        print(f"Pruebas fallidas: {total_tests - passed_tests}")
        print(".1f")
        print(f"Timestamp: {self.test_results['summary']['timestamp']}")
        print(f"Reporte guardado en: {report_file}")
        print("="*80)

        # Detailed results by category
        print("\n📈 RESULTADOS POR CATEGORÍA:")
        for category, tests in self.test_results.items():
            if category == 'summary':
                continue

            if isinstance(tests, list) and tests:
                category_passed = sum(1 for test in tests if test.get('success', False))
                category_total = len(tests)
                category_rate = (category_passed / category_total * 100) if category_total > 0 else 0
                print("30")

        return self.test_results

    async def run_all_tests(self):
        """Run all comprehensive API tests."""
        self.start_time = time.time()
        logger.info("🚀 Iniciando pruebas exhaustivas de APIs AILOOS...")

        try:
            await self.init_session()

            # Run all test categories
            await self.test_health_checks()
            await self.test_federated_apis()
            await self.test_marketplace_apis()
            await self.test_wallet_apis()
            await self.test_error_scenarios()
            await self.test_websocket_connections()
            await self.test_performance()

        finally:
            await self.close_session()

        # Generate report
        return self.generate_report()


async def main():
    """Main function to run comprehensive API tests."""
    tester = APIComprehensiveTester()
    results = await tester.run_all_tests()

    # Exit with appropriate code
    success_rate = results['summary']['success_rate']
    if success_rate >= 90:
        logger.info("🎉 Todas las pruebas pasaron exitosamente!")
        sys.exit(0)
    elif success_rate >= 75:
        logger.warning("⚠️ La mayoría de las pruebas pasaron, pero hay algunos fallos.")
        sys.exit(1)
    else:
        logger.error("❌ Muchas pruebas fallaron. Revisar el reporte detallado.")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())