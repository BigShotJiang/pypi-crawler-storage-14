#!/usr/bin/env python3
"""
Auditoría de Hot-Swap para Expertos Pluggables
===============================================

Esta auditoría verifica que el sistema de expertos permite cambios rápidos
y eficientes entre dominios sin fugas de memoria o degradación de rendimiento.
"""

import torch
import logging
import time
import psutil
import os
from pathlib import Path

# Añadir el directorio raíz al path
script_dir = Path(__file__).parent
root_dir = script_dir.parent
import sys
sys.path.insert(0, str(root_dir))

from src.ailoos.models.empoorio_lm.expert_system import (
    ExpertManager, PluggableEmpoorioLM, Domain,
    create_expert_manager, create_pluggable_empoorio_lm
)
from src.ailoos.models.empoorio_lm import EmpoorioLMConfig

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("HotSwap_Audit")


class HotSwapAuditor:
    """Auditor que verifica el funcionamiento del sistema de expertos."""

    def __init__(self):
        self.expert_manager = None
        self.model = None
        self.memory_baseline = None
        self.results = {}

    def setup_system(self):
        """Configurar el sistema para auditoría."""
        logger.info("🔧 Configurando sistema para auditoría...")

        # Crear gestor de expertos
        self.expert_manager = create_expert_manager("models/experts")

        # Crear expertos mock si no existen
        self._create_mock_experts()

        # Crear modelo pluggable
        config = EmpoorioLMConfig(
            vocab_size=30000,
            hidden_size=768,
            num_layers=12,
            num_heads=12,
            use_moe=True,
            num_experts=8,
            moe_layers=[4, 7, 10]
        )
        self.model = create_pluggable_empoorio_lm(config, self.expert_manager)

        # Medir memoria baseline
        self.memory_baseline = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024  # MB
        logger.info(".1f"
    def _create_mock_experts(self):
        """Crear expertos mock para testing."""
        logger.info("🎭 Creando expertos mock para auditoría...")

        domains_to_create = [Domain.LEGAL, Domain.MEDICAL, Domain.CODING]

        for domain in domains_to_create:
            expert_name = f"{domain.value}_audit_expert"

            # Configuración del experto
            from src.ailoos.models.empoorio_lm.expert_system import ExpertConfig
            config = ExpertConfig(
                domain=domain,
                name=expert_name,
                description=f"Experto mock para auditoría {domain.value}",
                target_layers=[4, 7],
                expert_indices=[6, 7] if domain == Domain.LEGAL else
                              [8, 9] if domain == Domain.MEDICAL else [10, 11],
                dataset_info={"type": "mock", "samples": 100},
                version="1.0.0-audit"
            )

            # Crear pesos mock
            expert_weights = self._generate_mock_weights(domain)

            # Guardar experto
            self.expert_manager.save_expert(config, expert_weights, domain, expert_name)
            logger.info(f"✅ Experto mock creado: {domain.value}/{expert_name}")

    def _generate_mock_weights(self, domain: Domain) -> dict:
        """Generar pesos mock para un experto."""
        # Dimensiones basadas en config del modelo
        hidden_size = 768

        # Generar pesos realistas (pero no funcionales) para testing
        weights = {}

        # Para cada experto en el dominio
        expert_indices = [6, 7] if domain == Domain.LEGAL else \
                        [8, 9] if domain == Domain.MEDICAL else [10, 11]

        for expert_idx in expert_indices:
            # Capas del experto (MLP típico)
            weights[f"expert_{expert_idx}"] = {
                "0.weight": torch.randn(4 * hidden_size, hidden_size),
                "0.bias": torch.randn(4 * hidden_size),
                "2.weight": torch.randn(hidden_size, 4 * hidden_size),
                "2.bias": torch.randn(hidden_size)
            }

        return weights

    def test_expert_switching(self):
        """Probar switching rápido entre expertos."""
        logger.info("🔄 Probando switching entre expertos...")

        test_sequence = [
            ("Redacta un contrato de compraventa", Domain.LEGAL),
            ("Diagnostica estos síntomas: fiebre, tos", Domain.MEDICAL),
            ("Implementa una función de ordenamiento", Domain.CODING),
            ("Analiza este balance financiero", Domain.FINANCIAL),  # No existe, debería fallback
            ("Redacta un acuerdo de confidencialidad", Domain.LEGAL),  # Vuelta al primero
        ]

        switch_times = []
        memory_usage = []

        for prompt, domain in test_sequence:
            logger.info(f"🎯 Cambiando a dominio: {domain.value}")
            logger.info(f"   Prompt: '{prompt[:50]}...'")

            # Medir tiempo de switch
            start_time = time.time()

            # Cargar experto del dominio
            loaded_count = self.model.load_domain_experts(domain)
            switch_time = time.time() - start_time

            switch_times.append(switch_time * 1000)  # ms

            # Medir memoria
            current_memory = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024  # MB
            memory_delta = current_memory - self.memory_baseline
            memory_usage.append(memory_delta)

            logger.info(f"   ⏱️ Tiempo de switch: {switch_time:.2f} ms")
            logger.info(f"   Expertos cargados: {loaded_count}")
            logger.info(f"   📈 Delta memoria: {memory_delta:.1f} MB")

            # Verificar que el switch fue eficiente
            if switch_time > 0.5:  # Más de 500ms es demasiado lento
                logger.warning(f"   ⚠️ Switch lento: {switch_time:.2f} ms")
            else:
                logger.info("   ✅ Switch eficiente")

            # Simular inferencia breve para verificar funcionamiento
            mock_tokens = torch.tensor([[1, 2, 3, 4, 5]], dtype=torch.long)
            try:
                with torch.no_grad():
                    outputs = self.model(mock_tokens, domain=domain)
                logits_shape = outputs["logits"].shape
                logger.info(f"   ✅ Inferencia exitosa - Shape: {logits_shape}")
            except Exception as e:
                logger.error(f"   ❌ Error en inferencia: {e}")

        # Estadísticas finales
        avg_switch_time = sum(switch_times) / len(switch_times)
        max_memory_delta = max(memory_usage)
        memory_leak = memory_usage[-1] - memory_usage[0]  # Comparar inicio vs fin

        self.results["switching"] = {
            "average_switch_time_ms": avg_switch_time,
            "max_memory_delta_mb": max_memory_delta,
            "memory_leak_mb": memory_leak,
            "switches_tested": len(test_sequence),
            "efficient_switches": sum(1 for t in switch_times if t <= 500)
        }

        logger.info("📊 Estadísticas de switching:")
        logger.info(f"   Tiempo promedio: {avg_switch_time:.2f} ms")
        logger.info(f"   Pico memoria: {max_memory_delta:.1f} MB")
        logger.info(f"   Fuga memoria: {memory_leak:.1f} MB")
        logger.info(f"   Switches eficientes: {self.results['switching']['efficient_switches']}/{len(test_sequence)}")

    def test_memory_integrity(self):
        """Probar integridad de memoria durante operaciones."""
        logger.info("🧠 Probando integridad de memoria...")

        initial_memory = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024

        # Ciclo de carga/descarga para verificar fugas
        domains = [Domain.LEGAL, Domain.MEDICAL, Domain.CODING]

        for cycle in range(3):  # 3 ciclos
            logger.info(f"   Ciclo {cycle + 1}/3...")

            for domain in domains:
                # Cargar
                self.model.load_domain_experts(domain)

                # Operación dummy
                mock_tokens = torch.tensor([[1, 2, 3]], dtype=torch.long)
                with torch.no_grad():
                    self.model(mock_tokens, domain=domain)

                # Descargar (simulado - en implementación real tendríamos unplug)
                # Por ahora verificamos que no hay crecimiento continuo

        final_memory = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024
        memory_growth = final_memory - initial_memory

        self.results["memory"] = {
            "initial_memory_mb": initial_memory,
            "final_memory_mb": final_memory,
            "memory_growth_mb": memory_growth,
            "acceptable_growth": memory_growth < 50  # Menos de 50MB es aceptable
        }

        logger.info("📊 Resultados de memoria:")
        logger.info(".1f"        logger.info(".1f"        logger.info(".1f"        if self.results["memory"]["acceptable_growth"]:
            logger.info("   ✅ Crecimiento de memoria aceptable")
        else:
            logger.warning("   ⚠️ Crecimiento de memoria excesivo")

    def run_full_audit(self):
        """Ejecutar auditoría completa."""
        logger.info("🔍 INICIANDO AUDITORÍA COMPLETA DE EXPERTOS PLUGGABLES")
        logger.info("=" * 60)

        try:
            self.setup_system()
            self.test_expert_switching()
            self.test_memory_integrity()

            # Resumen final
            self._print_audit_summary()

            return True

        except Exception as e:
            logger.error(f"❌ Error en auditoría: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _print_audit_summary(self):
        """Imprimir resumen de la auditoría."""
        logger.info("\n" + "=" * 60)
        logger.info("📋 RESUMEN DE AUDITORÍA - FASE 8")
        logger.info("=" * 60)

        # Resultados de switching
        switch_results = self.results.get("switching", {})
        logger.info("🔄 SWITCHING PERFORMANCE:")
        logger.info(".2f"        logger.info(f"   Switches eficientes: {switch_results.get('efficient_switches', 0)}/{switch_results.get('switches_tested', 0)}")

        # Resultados de memoria
        memory_results = self.results.get("memory", {})
        logger.info("🧠 MEMORY INTEGRITY:")
        logger.info(".1f"        logger.info(".1f"        if memory_results.get("acceptable_growth", False):
            logger.info("   ✅ Sin fugas de memoria significativas")
        else:
            logger.info("   ⚠️ Posible fuga de memoria")

        # Veredicto final
        all_passed = (
            switch_results.get("average_switch_time_ms", 1000) < 500 and
            memory_results.get("acceptable_growth", False)
        )

        logger.info("\n🏆 VEREDICTO FINAL:")
        if all_passed:
            logger.info("   ✅ AUDITORÍA SUPERADA - FASE 8 LISTA PARA PRODUCCIÓN")
            logger.info("   🎉 El 'Enjambre de Especialistas' está operativo")
        else:
            logger.info("   ⚠️ AUDITORÍA CON OBSERVACIONES - REVISAR ANTES DE PRODUCCIÓN")

        logger.info("=" * 60)


def main():
    """Función principal."""
    auditor = HotSwapAuditor()
    success = auditor.run_full_audit()

    if success:
        print("\n🎯 Auditoría completada exitosamente")
    else:
        print("\n❌ Error en auditoría")
        sys.exit(1)


if __name__ == "__main__":
    main()