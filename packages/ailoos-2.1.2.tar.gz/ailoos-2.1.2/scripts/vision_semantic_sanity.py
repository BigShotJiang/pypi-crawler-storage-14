#!/usr/bin/env python3
"""
Vision Semantic Sanity Check
Validación semántica zero-shot para verificar que Empoorio-Vision funciona correctamente.

Esta prueba verifica que el pipeline CLIP + Projector puede distinguir
semánticamente entre imágenes similares y diferentes sin entrenamiento.
"""

import sys
import os
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw
import numpy as np

# Añadir src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

def create_semantic_test_images():
    """
    Create pairs of images for semantic testing.

    Returns:
        Dictionary with test image pairs and their descriptions
    """
    images = {}

    # Test 1: Color recognition
    # Red circle vs Blue square
    img1 = Image.new('RGB', (224, 224), 'white')
    draw1 = ImageDraw.Draw(img1)
    draw1.ellipse([50, 50, 174, 174], fill='red')

    img2 = Image.new('RGB', (224, 224), 'white')
    draw2 = ImageDraw.Draw(img2)
    draw2.rectangle([50, 50, 174, 174], fill='blue')

    images['color_test'] = {
        'image1': img1,
        'image2': img2,
        'desc1': 'red circle',
        'desc2': 'blue square',
        'expected_similarity': 'low'  # Different colors and shapes
    }

    # Test 2: Shape recognition
    # Two red circles (should be similar)
    img3 = Image.new('RGB', (224, 224), 'white')
    draw3 = ImageDraw.Draw(img3)
    draw3.ellipse([60, 60, 164, 164], fill='red')

    img4 = Image.new('RGB', (224, 224), 'white')
    draw4 = ImageDraw.Draw(img4)
    draw4.ellipse([70, 70, 154, 154], fill='red')

    images['shape_test'] = {
        'image1': img3,
        'image2': img4,
        'desc1': 'red circle',
        'desc2': 'red circle slightly different size',
        'expected_similarity': 'high'  # Same color and shape
    }

    # Test 3: Document-like content
    # Text-like patterns
    img5 = Image.new('RGB', (224, 224), 'white')
    draw5 = ImageDraw.Draw(img5)
    # Draw some "text" lines
    for y in range(40, 200, 20):
        draw5.line([20, y, 200, y], fill='black', width=2)

    img6 = Image.new('RGB', (224, 224), 'white')
    draw6 = ImageDraw.Draw(img6)
    # Draw different pattern
    for x in range(40, 200, 20):
        draw6.line([x, 20, x, 200], fill='black', width=2)

    images['document_test'] = {
        'image1': img5,
        'image2': img6,
        'desc1': 'horizontal lines like text',
        'desc2': 'vertical lines like table',
        'expected_similarity': 'medium'  # Both are line patterns but different orientation
    }

    return images

def test_semantic_understanding():
    """
    Test semantic understanding using CLIP's zero-shot capabilities.

    This validates that our vision pipeline can distinguish semantic content.
    """
    print("🧪 Testing Semantic Understanding (Zero-Shot)...")

    try:
        from transformers import CLIPProcessor, CLIPModel

        # Load CLIP model (same as our vision encoder)
        model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
        processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

        # Create test images
        test_images = create_semantic_test_images()

        results = {}

        for test_name, test_data in test_images.items():
            print(f"\n📋 Testing {test_name}...")

            # Process images
            inputs1 = processor(text=[test_data['desc1']], images=test_data['image1'], return_tensors="pt", padding=True)
            inputs2 = processor(text=[test_data['desc2']], images=test_data['image2'], return_tensors="pt", padding=True)

            # Get embeddings
            with torch.no_grad():
                outputs1 = model(**inputs1)
                outputs2 = model(**inputs2)

                # Compute similarities
                # Image-to-text similarity
                img1_text1_sim = F.cosine_similarity(
                    outputs1.image_embeds, outputs1.text_embeds, dim=1
                ).item()

                img2_text2_sim = F.cosine_similarity(
                    outputs2.image_embeds, outputs2.text_embeds, dim=1
                ).item()

                # Cross similarities (should be lower)
                img1_text2_sim = F.cosine_similarity(
                    outputs1.image_embeds, outputs2.text_embeds, dim=1
                ).item()

                img2_text1_sim = F.cosine_similarity(
                    outputs2.image_embeds, outputs1.text_embeds, dim=1
                ).item()

            # Calculate contrast ratio
            correct_sim = (img1_text1_sim + img2_text2_sim) / 2
            incorrect_sim = (img1_text2_sim + img2_text1_sim) / 2
            contrast_ratio = correct_sim / max(incorrect_sim, 0.001)

            results[test_name] = {
                'img1_text1_sim': img1_text1_sim,
                'img2_text2_sim': img2_text2_sim,
                'img1_text2_sim': img1_text2_sim,
                'img2_text1_sim': img2_text1_sim,
                'contrast_ratio': contrast_ratio,
                'expected': test_data['expected_similarity']
            }

            print(f"   Correct similarity: {correct_sim:.3f}")
            print(f"   Incorrect similarity: {incorrect_sim:.3f}")
            print(f"   Contrast ratio: {contrast_ratio:.3f}")

            # Validate based on expected similarity
            if test_data['expected_similarity'] == 'high':
                success = contrast_ratio > 1.2  # Should be significantly higher
            elif test_data['expected_similarity'] == 'low':
                success = contrast_ratio > 1.5  # Should be much higher
            else:  # medium
                success = contrast_ratio > 1.1  # Should be moderately higher

            results[test_name]['validation_passed'] = success
            status = "✅ PASSED" if success else "❌ FAILED"
            print(f"   Validation: {status}")

        # Overall assessment
        all_passed = all(r['validation_passed'] for r in results.values())

        print("\n🎯 SEMANTIC SANITY CHECK RESULTS")
        print("=" * 50)

        for test_name, result in results.items():
            status = "✅" if result['validation_passed'] else "❌"
            print(f"   {test_name}: {status} (ratio: {result['contrast_ratio']:.2f})")

        overall_status = "✅ ALL TESTS PASSED" if all_passed else "❌ SOME TESTS FAILED"
        print(f"\n🎯 Overall: {overall_status}")

        if all_passed:
            print("🎉 CLIP semantic understanding is working correctly!")
            print("🚀 Ready for multimodal training.")
        else:
            print("⚠️ Semantic understanding needs investigation.")
            print("💡 Check if CLIP model is loaded correctly.")

        return all_passed

    except Exception as e:
        print(f"❌ Semantic sanity test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_projector_gradient_flow():
    """
    Test that the multimodal projector allows gradient flow correctly.
    """
    print("🧪 Testing Projector Gradient Flow...")

    try:
        from ailoos.models.vision.projector import MultiModalProjector

        # Create projector
        projector = MultiModalProjector(vision_dim=768, llm_hidden_size=768)

        # Create test input
        batch_size, num_patches = 2, 10
        vision_features = torch.randn(batch_size, num_patches, 768, requires_grad=True)

        # Forward pass
        output = projector(vision_features)

        # Create dummy loss
        loss = output.sum()

        # Backward pass
        loss.backward()

        # Check gradients
        has_gradients = vision_features.grad is not None
        grad_norm = torch.norm(vision_features.grad).item()

        print("✅ Forward pass successful")
        print(f"✅ Gradients present: {has_gradients}")
        print(f"✅ Gradient norm: {grad_norm:.4f}")

        # Validate
        if has_gradients and grad_norm > 0.1 and grad_norm < 10.0:
            print("✅ Projector gradient flow is healthy!")
            return True
        else:
            print("❌ Projector gradient flow issue detected")
            return False

    except Exception as e:
        print(f"❌ Projector gradient test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_anyres_integration():
    """
    Test AnyRes integration with semantic understanding.
    """
    print("🧪 Testing AnyRes Integration...")

    try:
        from ailoos.models.vision import AnyResImageProcessor, ImageTokenizer, VisionEncoder

        # Create components
        processor = AnyResImageProcessor()
        tokenizer = ImageTokenizer()

        # Create mock vision encoder
        class MockVisionEncoder:
            def get_image_features(self, img):
                # Simulate CLIP-like features
                h_patches = max(1, img.height // 32)
                w_patches = max(1, img.width // 32)
                num_patches = h_patches * w_patches
                return torch.randn(num_patches, 768)

        encoder = MockVisionEncoder()

        # Test with high-res image
        test_image = create_semantic_test_images()['document_test']['image1']

        # Process with AnyRes
        processed = processor.process_image(test_image)
        tokens = tokenizer.tokenize_image(processed, encoder)

        print(f"✅ AnyRes processed image: {processed['strategy']} strategy")
        print(f"✅ Generated {tokens['num_tokens']} visual tokens")
        print(f"✅ Grid layout: {processed['patches_info']['grid_cols']}x{processed['patches_info']['grid_rows']}")

        # Validate reasonable token count
        if 10 <= tokens['num_tokens'] <= 256:  # Reasonable range
            print("✅ AnyRes tokenization is working correctly!")
            return True
        else:
            print(f"❌ Unexpected token count: {tokens['num_tokens']}")
            return False

    except Exception as e:
        print(f"❌ AnyRes integration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all semantic sanity checks."""
    print("🚀 Empoorio-Vision Semantic Sanity Checks")
    print("=" * 60)

    tests = [
        test_semantic_understanding,
        test_projector_gradient_flow,
        test_anyres_integration
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} crashed: {e}")
            results.append(False)
        print()

    print("=" * 60)
    print("📊 SANITY CHECK RESULTS SUMMARY")
    print("=" * 60)

    passed = sum(results)
    total = len(results)

    test_names = [
        "Semantic Understanding",
        "Projector Gradient Flow",
        "AnyRes Integration"
    ]

    for i, (name, result) in enumerate(zip(test_names, results)):
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{i+1}. {name}: {status}")

    print(f"\n🎯 Overall: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 ALL SANITY CHECKS PASSED!")
        print("🚀 Empoorio-Vision is semantically sound and ready for training!")
        print("💡 Next step: Federated training of the multimodal projector.")
        return 0
    else:
        print("⚠️ Some sanity checks failed.")
        print("🔧 Investigate the failed tests before proceeding with training.")
        return 1

if __name__ == "__main__":
    sys.exit(main())