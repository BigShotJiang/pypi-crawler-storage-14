#!/usr/bin/env python3
"""
Script de Bootstrap DPO para resolver el Cold Start Problem.

Este script descarga datasets DPO públicos de alta calidad, los filtra y limpia,
los convierte al formato AILOOS, realiza pre-entrenamiento DPO inicial,
guarda el modelo con alignment básico y ejecuta tests de validación.

Datasets utilizados:
- Intel/orca_dpo_pairs: Dataset de alta calidad con pares de preferencias
- Anthropic/hh-rlhf: Dataset de Helpful-Harmless RLHF

Beneficio clave: Modelo con alignment básico antes de feedback humano
"""

import os
import sys
import json
import logging
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import time

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import numpy as np
from tqdm import tqdm
import pandas as pd

# Imports de AILOOS
sys.path.append(str(Path(__file__).parent.parent))

from models.empoorio_lm.config import EmpoorioLMConfig, get_config_for_model_size
from models.empoorio_lm.model import EmpoorioLM
from models.empoorio_lm.dpo_wrapper import DualModelWrapper, get_dpo_config
from models.empoorio_lm.dpo_loss import DPOLoss
from data.dpo_collator import DataCollatorForDPO, create_dpo_collator
from transformers import AutoTokenizer

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bootstrap_dpo.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@dataclass
class BootstrapConfig:
    """Configuración para el bootstrap DPO."""
    # Datasets
    datasets: List[str] = None
    max_samples_per_dataset: int = 10000
    min_prompt_length: int = 10
    max_prompt_length: int = 512
    min_response_length: int = 5
    max_response_length: int = 256

    # Modelo
    model_size: str = "small"
    dpo_beta: float = 0.1
    learning_rate: float = 5e-5
    batch_size: int = 4
    num_epochs: int = 3
    max_grad_norm: float = 1.0

    # Paths
    output_dir: str = "models/bootstrap_dpo"
    data_dir: str = "data/bootstrap_dpo"
    cache_dir: str = "cache/bootstrap_dpo"

    # Device
    device: str = "auto"

    def __post_init__(self):
        if self.datasets is None:
            self.datasets = ["Intel/orca_dpo_pairs", "Anthropic/hh-rlhf"]
        # No convertir device aquí, se hace en el trainer


class DPODataset(Dataset):
    """Dataset personalizado para DPO training."""

    def __init__(self, data: List[Dict[str, str]]):
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class BootstrapDPOTrainer:
    """Trainer para bootstrap DPO."""

    def __init__(self, config: BootstrapConfig):
        self.config = config
        # Set up device with auto-detection
        if config.device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(config.device)

        # Crear directorios
        for dir_path in [config.output_dir, config.data_dir, config.cache_dir]:
            Path(dir_path).mkdir(parents=True, exist_ok=True)

        # Inicializar componentes
        self.tokenizer = None
        self.model = None
        self.collator = None
        self.optimizer = None
        self.scheduler = None

        logger.info("🚀 BootstrapDPOTrainer inicializado")
        logger.info(f"📊 Config: {config}")

    def download_and_prepare_datasets(self) -> List[Dict[str, str]]:
        """Descargar y preparar datasets DPO."""
        logger.info("📥 Descargando datasets DPO...")

        all_data = []

        try:
            from datasets import load_dataset
        except ImportError:
            raise ImportError("Se requiere instalar datasets: pip install datasets")

        for dataset_name in self.config.datasets:
            logger.info(f"📦 Procesando dataset: {dataset_name}")

            try:
                if dataset_name == "Intel/orca_dpo_pairs":
                    dataset = load_dataset("Intel/orca_dpo_pairs", split="train")
                    data = self._process_orca_dataset(dataset)
                elif dataset_name == "Anthropic/hh-rlhf":
                    dataset = load_dataset("Anthropic/hh-rlhf", split="train")
                    data = self._process_hh_dataset(dataset)
                else:
                    logger.warning(f"Dataset no soportado: {dataset_name}")
                    continue

                # Limitar muestras
                if len(data) > self.config.max_samples_per_dataset:
                    data = data[:self.config.max_samples_per_dataset]

                all_data.extend(data)
                logger.info(f"✅ {dataset_name}: {len(data)} muestras procesadas")

            except Exception as e:
                logger.error(f"❌ Error procesando {dataset_name}: {e}")
                continue

        # Filtrar y limpiar datos
        logger.info("🧹 Filtrando y limpiando datos...")
        filtered_data = self._filter_and_clean_data(all_data)

        logger.info(f"📊 Datos finales: {len(filtered_data)} muestras")
        return filtered_data

    def _process_orca_dataset(self, dataset) -> List[Dict[str, str]]:
        """Procesar dataset Intel/orca_dpo_pairs."""
        data = []
        for item in dataset:
            # El formato ya es prompt/chosen/rejected
            if all(key in item for key in ["prompt", "chosen", "rejected"]):
                data.append({
                    "prompt": item["prompt"],
                    "chosen": item["chosen"],
                    "rejected": item["rejected"]
                })
        return data

    def _process_hh_dataset(self, dataset) -> List[Dict[str, str]]:
        """Procesar dataset Anthropic/hh-rlhf."""
        data = []

        for item in dataset:
            # HH-RLHF tiene formato diferente, necesitamos extraer pares
            if "chosen" in item and "rejected" in item:
                # Extraer prompt del chosen (todo antes de la respuesta del assistant)
                chosen_text = item["chosen"]
                rejected_text = item["rejected"]

                # Encontrar el prompt (texto antes de "\n\nAssistant:")
                if "\n\nAssistant:" in chosen_text:
                    prompt = chosen_text.split("\n\nAssistant:")[0] + "\n\nAssistant:"
                    chosen_response = chosen_text.split("\n\nAssistant:")[1]
                    rejected_response = rejected_text.split("\n\nAssistant:")[1] if "\n\nAssistant:" in rejected_text else rejected_text

                    data.append({
                        "prompt": prompt,
                        "chosen": chosen_response.strip(),
                        "rejected": rejected_response.strip()
                    })

        return data

    def _filter_and_clean_data(self, data: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Filtrar y limpiar datos."""
        filtered = []

        for item in data:
            try:
                prompt = item["prompt"].strip()
                chosen = item["chosen"].strip()
                rejected = item["rejected"].strip()

                # Verificar longitudes mínimas
                if len(prompt) < self.config.min_prompt_length:
                    continue
                if len(chosen) < self.config.min_response_length:
                    continue
                if len(rejected) < self.config.min_response_length:
                    continue

                # Verificar longitudes máximas
                if len(prompt) > self.config.max_prompt_length:
                    continue
                if len(chosen) > self.config.max_response_length:
                    continue
                if len(rejected) > self.config.max_response_length:
                    continue

                # Verificar que chosen y rejected sean diferentes
                if chosen == rejected:
                    continue

                # Verificar que no estén vacíos
                if not all([prompt, chosen, rejected]):
                    continue

                filtered.append({
                    "prompt": prompt,
                    "chosen": chosen,
                    "rejected": rejected
                })

            except Exception as e:
                logger.warning(f"Error procesando item: {e}")
                continue

        return filtered

    def initialize_model_and_tokenizer(self):
        """Inicializar modelo y tokenizer."""
        logger.info("🤖 Inicializando modelo y tokenizer...")

        # Cargar tokenizer compatible con EmpoorioLM
        # Usar GPT-2 tokenizer pero limitar vocabulario al tamaño del modelo
        self.tokenizer = AutoTokenizer.from_pretrained("gpt2")
        self.tokenizer.pad_token = self.tokenizer.eos_token

        # Crear configuración del modelo compatible con GPT-2 tokenizer
        base_config = get_config_for_model_size(self.config.model_size, use_moe=False)
        dpo_config_dict = get_dpo_config(base_config, self.config.dpo_beta)
        # Remover dpo_beta ya que no es parte de EmpoorioLMConfig
        dpo_config_dict.pop('dpo_beta', None)
        # Ajustar vocab_size para que coincida con GPT-2 tokenizer
        dpo_config_dict['vocab_size'] = self.tokenizer.vocab_size
        model_config = EmpoorioLMConfig(**dpo_config_dict)

        # Nota: El modelo se configura con vocab_size del tokenizer para compatibilidad

        # Crear modelo DPO
        self.model = DualModelWrapper(model_config, self.config.dpo_beta)
        self.model.to(self.device)

        # Crear collator
        self.collator = create_dpo_collator(
            tokenizer=self.tokenizer,
            max_length=1024,
            enable_stats=True
        )

        # Inicializar optimizer
        self.optimizer = torch.optim.AdamW(
            self.model.get_trainable_parameters(),
            lr=self.config.learning_rate,
            weight_decay=0.01
        )

        # Scheduler (se inicializará después de preparar datos)
        self.scheduler = None

        logger.info("✅ Modelo y tokenizer inicializados")
        logger.info(f"📊 Modelo: {self.model}")
        logger.info(f"🔧 Optimizer: {type(self.optimizer).__name__}")
        logger.info(f"📈 Scheduler: {type(self.scheduler).__name__}")

    def train_dpo(self, train_data: List[Dict[str, str]]):
        """Entrenar modelo con DPO."""
        logger.info("🎯 Iniciando entrenamiento DPO...")

        # Preparar dataset
        self.train_dataset = DPODataset(train_data)
        train_loader = DataLoader(
            self.train_dataset,
            batch_size=self.config.batch_size,
            shuffle=True,
            collate_fn=self.collator,
            num_workers=0  # Para evitar issues con multiprocessing
        )

        # Inicializar scheduler si no está inicializado
        if self.scheduler is None:
            num_training_steps = len(self.train_dataset) * self.config.num_epochs // self.config.batch_size
            self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=num_training_steps
            )

        # Estadísticas de entrenamiento
        training_stats = {
            "epoch": [],
            "step": [],
            "loss": [],
            "learning_rate": [],
            "time_per_step": []
        }

        global_step = 0
        best_loss = float('inf')

        for epoch in range(self.config.num_epochs):
            logger.info(f"📚 Epoch {epoch + 1}/{self.config.num_epochs}")

            epoch_start_time = time.time()
            epoch_losses = []

            progress_bar = tqdm(train_loader, desc=f"Epoch {epoch + 1}")

            for batch in progress_bar:
                step_start_time = time.time()

                # Mover batch a device
                batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                        for k, v in batch.items()}

                # Forward pass
                loss, metrics = self.model.compute_dpo_loss(
                    chosen_input_ids=batch["chosen_input_ids"],
                    chosen_attention_mask=batch["chosen_attention_mask"],
                    rejected_input_ids=batch["rejected_input_ids"],
                    rejected_attention_mask=batch["rejected_attention_mask"],
                    chosen_labels=batch["chosen_labels"],
                    rejected_labels=batch["rejected_labels"]
                )

                # Backward pass
                self.optimizer.zero_grad()
                loss.backward()

                # Gradient clipping
                torch.nn.utils.clip_grad_norm_(
                    self.model.get_trainable_parameters(),
                    self.config.max_grad_norm
                )

                self.optimizer.step()
                self.scheduler.step()

                # Estadísticas
                step_time = time.time() - step_start_time
                loss_value = loss.item()

                epoch_losses.append(loss_value)
                global_step += 1

                # Actualizar progress bar
                progress_bar.set_postfix({
                    "loss": f"{loss_value:.4f}",
                    "lr": f"{self.scheduler.get_last_lr()[0]:.2e}"
                })

                # Guardar estadísticas
                training_stats["epoch"].append(epoch + 1)
                training_stats["step"].append(global_step)
                training_stats["loss"].append(loss_value)
                training_stats["learning_rate"].append(self.scheduler.get_last_lr()[0])
                training_stats["time_per_step"].append(step_time)

                # Log cada 100 steps
                if global_step % 100 == 0:
                    logger.info(f"Step {global_step}: loss={loss_value:.4f}, lr={self.scheduler.get_last_lr()[0]:.2e}")

            # Fin de epoch
            epoch_time = time.time() - epoch_start_time
            avg_epoch_loss = np.mean(epoch_losses)

            logger.info(f"Epoch {epoch + 1} completado: avg_loss={avg_epoch_loss:.4f}, time={epoch_time:.2f}s")

            # Guardar mejor modelo
            if avg_epoch_loss < best_loss:
                best_loss = avg_epoch_loss
                self.save_model(f"best_model_epoch_{epoch + 1}")

        # Guardar estadísticas finales
        self.save_training_stats(training_stats)

        logger.info("✅ Entrenamiento DPO completado")
        logger.info(f"🏆 Mejor loss: {best_loss:.4f}")

    def save_model(self, suffix: str = ""):
        """Guardar modelo entrenado."""
        save_path = Path(self.config.output_dir) / f"bootstrap_dpo_model_{suffix}"

        # Crear directorio
        save_path.mkdir(parents=True, exist_ok=True)

        # Guardar modelo
        model_path = save_path / "pytorch_model.bin"
        torch.save(self.model.policy_model.state_dict(), model_path)

        # Guardar tokenizer
        tokenizer_path = save_path / "tokenizer.json"
        self.tokenizer.save_pretrained(str(save_path))

        # Guardar configuración
        config_path = save_path / "config.json"
        with open(config_path, 'w') as f:
            json.dump({
                "bootstrap_config": self.config.__dict__,
                "model_config": self.model.config.to_dict(),
                "training_info": {
                    "device": str(self.device),
                    "final_lr": self.scheduler.get_last_lr()[0] if self.scheduler else None
                }
            }, f, indent=2)

        logger.info(f"💾 Modelo guardado en: {save_path}")

    def save_training_stats(self, stats: Dict[str, List]):
        """Guardar estadísticas de entrenamiento."""
        stats_path = Path(self.config.output_dir) / "training_stats.json"

        # Convertir a formato serializable
        serializable_stats = {}
        for key, values in stats.items():
            if key == "time_per_step":
                serializable_stats[key] = [float(v) for v in values]
            else:
                serializable_stats[key] = values

        with open(stats_path, 'w') as f:
            json.dump(serializable_stats, f, indent=2)

        logger.info(f"📊 Estadísticas guardadas en: {stats_path}")

    def run_validation_tests(self, test_data: List[Dict[str, str]]):
        """Ejecutar tests de validación."""
        logger.info("🧪 Ejecutando tests de validación...")

        # Crear dataset de test pequeño
        test_dataset = DPODataset(test_data[:100])  # Usar 100 muestras para test
        test_loader = DataLoader(
            test_dataset,
            batch_size=self.config.batch_size,
            shuffle=False,
            collate_fn=self.collator
        )

        self.model.eval()
        test_losses = []

        with torch.no_grad():
            for batch in tqdm(test_loader, desc="Validating"):
                batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                        for k, v in batch.items()}

                loss, metrics = self.model.compute_dpo_loss(
                    chosen_input_ids=batch["chosen_input_ids"],
                    chosen_attention_mask=batch["chosen_attention_mask"],
                    rejected_input_ids=batch["rejected_input_ids"],
                    rejected_attention_mask=batch["rejected_attention_mask"],
                    chosen_labels=batch["chosen_labels"],
                    rejected_labels=batch["rejected_labels"]
                )

                test_losses.append(loss.item())

        avg_test_loss = np.mean(test_losses)
        logger.info(f"✅ Test completado: avg_loss={avg_test_loss:.4f}")

        # Guardar resultados de test
        test_results = {
            "avg_test_loss": avg_test_loss,
            "num_test_samples": len(test_dataset),
            "test_timestamp": time.time()
        }

        test_path = Path(self.config.output_dir) / "validation_results.json"
        with open(test_path, 'w') as f:
            json.dump(test_results, f, indent=2)

        return test_results

    def run(self):
        """Ejecutar el proceso completo de bootstrap."""
        logger.info("🚀 Iniciando Bootstrap DPO completo")

        start_time = time.time()

        try:
            # 1. Descargar y preparar datasets
            logger.info("📥 Paso 1: Descargando datasets...")
            train_data = self.download_and_prepare_datasets()

            if len(train_data) == 0:
                raise ValueError("No se pudieron cargar datos de entrenamiento")

            # Guardar datos procesados
            data_path = Path(self.config.data_dir) / "processed_data.json"
            with open(data_path, 'w') as f:
                json.dump(train_data, f, indent=2)
            logger.info(f"💾 Datos guardados en: {data_path}")

            # 2. Inicializar modelo y tokenizer
            logger.info("🤖 Paso 2: Inicializando modelo...")
            self.initialize_model_and_tokenizer()

            # 3. Entrenar DPO
            logger.info("🎯 Paso 3: Entrenando DPO...")
            self.train_dpo(train_data)

            # 4. Guardar modelo final
            logger.info("💾 Paso 4: Guardando modelo final...")
            self.save_model("final")

            # 5. Ejecutar tests
            logger.info("🧪 Paso 5: Ejecutando validación...")
            test_results = self.run_validation_tests(train_data)

            # 6. Resumen final
            total_time = time.time() - start_time
            logger.info("🎉 ¡Bootstrap DPO completado exitosamente!")
            logger.info(f"⏱️ Tiempo total: {total_time:.2f} segundos")
            logger.info(f"📊 Datos procesados: {len(train_data)}")
            logger.info(f"🏆 Mejor loss: {test_results.get('avg_test_loss', 'N/A')}")
            logger.info(f"📁 Modelo guardado en: {self.config.output_dir}")

            return True

        except Exception as e:
            logger.error(f"❌ Error en bootstrap DPO: {e}")
            import traceback
            traceback.print_exc()
            return False


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description="Bootstrap DPO Dataset Script")
    parser.add_argument("--config", type=str, help="Archivo de configuración JSON")
    parser.add_argument("--model-size", type=str, default="small", choices=["small", "medium", "large"])
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--num-epochs", type=int, default=3)
    parser.add_argument("--output-dir", type=str, default="models/bootstrap_dpo")
    parser.add_argument("--device", type=str, default="auto")

    args = parser.parse_args()

    # Cargar configuración
    if args.config and Path(args.config).exists():
        with open(args.config, 'r') as f:
            config_dict = json.load(f)
        config = BootstrapConfig(**config_dict)
    else:
        config = BootstrapConfig()

    # Override con argumentos de línea de comandos
    config.model_size = args.model_size
    config.batch_size = args.batch_size
    config.num_epochs = args.num_epochs
    config.output_dir = args.output_dir
    config.device = args.device

    # Ejecutar bootstrap
    trainer = BootstrapDPOTrainer(config)
    success = trainer.run()

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()