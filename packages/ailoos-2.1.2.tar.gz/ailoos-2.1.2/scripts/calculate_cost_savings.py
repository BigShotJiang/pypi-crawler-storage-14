#!/usr/bin/env python3
"""
Script para calcular costos ahorrados con RAG + CAG vs RAG estándar en EmpoorioLM.

Este script analiza los resultados de benchmarks y calcula ahorros en:
- Costos de inferencia (basados en tokens procesados)
- Costos de latencia (tiempo de respuesta)
- Costos operativos (recursos de infraestructura)
- ROI del sistema de cache

Uso:
    python scripts/calculate_cost_savings.py --benchmark_results benchmark_results/ --cost_model standard
"""

import argparse
import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class CostSavingsCalculator:
    """Calculador de ahorros de costos para RAG + CAG."""

    def __init__(self, config: Dict[str, Any]):
        """
        Inicializar el calculador.

        Args:
            config: Configuración del cálculo
        """
        self.config = config
        self.results = {
            'calculation_config': config,
            'cost_models': {},
            'savings_analysis': {},
            'roi_analysis': {},
            'timestamp': json.dumps({}, default=str)
        }

    def load_benchmark_results(self, results_dir: str) -> Dict[str, Any]:
        """Cargar resultados de benchmarks."""
        results_dir = Path(results_dir)
        benchmark_data = {}

        # Buscar archivos de resultados
        result_files = {
            'cache_hit_rate': results_dir / 'cache_hit_rate_results.json',
            'inference_latency': results_dir / 'inference_latency_results.json',
            'performance_comparison': results_dir / 'rag_performance_comparison.json'
        }

        for test_name, file_path in result_files.items():
            if file_path.exists():
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        benchmark_data[test_name] = json.load(f)
                    logger.info(f"Cargado {test_name} desde {file_path}")
                except Exception as e:
                    logger.warning(f"Error cargando {file_path}: {e}")
            else:
                logger.warning(f"Archivo no encontrado: {file_path}")

        return benchmark_data

    def define_cost_models(self) -> Dict[str, Dict[str, Any]]:
        """Definir diferentes modelos de costo."""
        cost_models = {
            'standard': {
                'name': 'Modelo Estándar',
                'inference_cost_per_token': 0.0001,  # $ por token
                'latency_cost_per_second': 0.01,     # $ por segundo de latencia
                'infrastructure_cost_per_hour': 2.0,  # $ por hora de servidor
                'cache_storage_cost_per_gb': 0.10,   # $ por GB/mes
                'description': 'Modelo estándar basado en proveedores cloud típicos'
            },
            'premium': {
                'name': 'Modelo Premium',
                'inference_cost_per_token': 0.0005,  # $ por token (modelos más caros)
                'latency_cost_per_second': 0.05,     # $ por segundo (SLA estrictos)
                'infrastructure_cost_per_hour': 5.0,  # $ por hora (GPUs premium)
                'cache_storage_cost_per_gb': 0.25,   # $ por GB/mes
                'description': 'Modelo premium para aplicaciones críticas'
            },
            'enterprise': {
                'name': 'Modelo Empresarial',
                'inference_cost_per_token': 0.001,   # $ por token (modelos propietarios)
                'latency_cost_per_second': 0.10,     # $ por segundo (baja latencia requerida)
                'infrastructure_cost_per_hour': 10.0, # $ por hora (infra dedicada)
                'cache_storage_cost_per_gb': 0.50,   # $ por GB/mes
                'description': 'Modelo empresarial con SLA garantizados'
            },
            'custom': {
                'name': 'Modelo Personalizado',
                'inference_cost_per_token': self.config.get('custom_inference_cost', 0.0002),
                'latency_cost_per_second': self.config.get('custom_latency_cost', 0.02),
                'infrastructure_cost_per_hour': self.config.get('custom_infra_cost', 3.0),
                'cache_storage_cost_per_gb': self.config.get('custom_storage_cost', 0.15),
                'description': 'Modelo personalizado basado en configuración'
            }
        }

        return cost_models

    def calculate_inference_cost_savings(self, benchmark_data: Dict[str, Any],
                                       cost_model: Dict[str, Any]) -> Dict[str, Any]:
        """Calcular ahorros en costos de inferencia."""
        savings = {
            'cost_model': cost_model['name'],
            'inference_tokens_saved': 0,
            'latency_time_saved_hours': 0,
            'inference_cost_savings_monthly': 0,
            'latency_cost_savings_monthly': 0,
            'total_savings_monthly': 0
        }

        # Obtener métricas de benchmarks
        monthly_queries = self.config.get('monthly_queries', 100000)  # Asumir 100k queries/mes

        # Calcular desde cache hit rate
        if 'cache_hit_rate' in benchmark_data:
            hit_rate_data = benchmark_data['cache_hit_rate']
            metrics = hit_rate_data.get('metrics', {})
            hit_rate = metrics.get('cache_hit_rate', 0)

            # Estimar tokens por query (promedio)
            avg_tokens_per_query = self.config.get('avg_tokens_per_query', 200)

            # Queries cacheadas no requieren inferencia completa
            cacheable_queries = monthly_queries * hit_rate
            tokens_saved = cacheable_queries * avg_tokens_per_query * 0.8  # 80% reducción

            savings['inference_tokens_saved'] = tokens_saved
            savings['inference_cost_savings_monthly'] = tokens_saved * cost_model['inference_cost_per_token']

        # Calcular desde latencia
        if 'inference_latency' in benchmark_data:
            latency_data = benchmark_data['inference_latency']
            with_cache = latency_data.get('with_cache', {})
            without_cache = latency_data.get('without_cache', {})

            avg_latency_with = with_cache.get('avg_latency', 0)
            avg_latency_without = without_cache.get('avg_latency', 0)

            if avg_latency_without > 0:
                latency_improvement = avg_latency_without - avg_latency_with
                time_saved_per_query = latency_improvement

                # Tiempo total ahorrado por mes
                total_time_saved_seconds = monthly_queries * time_saved_per_query
                total_time_saved_hours = total_time_saved_seconds / 3600

                savings['latency_time_saved_hours'] = total_time_saved_hours
                savings['latency_cost_savings_monthly'] = total_time_saved_hours * cost_model['latency_cost_per_second']

        # Total de ahorros
        savings['total_savings_monthly'] = (
            savings['inference_cost_savings_monthly'] + savings['latency_cost_savings_monthly']
        )

        return savings

    def calculate_infrastructure_cost_savings(self, benchmark_data: Dict[str, Any],
                                            cost_model: Dict[str, Any]) -> Dict[str, Any]:
        """Calcular ahorros en costos de infraestructura."""
        savings = {
            'cost_model': cost_model['name'],
            'server_hours_saved_monthly': 0,
            'infrastructure_cost_savings_monthly': 0,
            'cache_storage_cost_monthly': 0,
            'net_infrastructure_savings_monthly': 0
        }

        monthly_queries = self.config.get('monthly_queries', 100000)

        # Calcular reducción en uso de servidores
        if 'inference_latency' in benchmark_data:
            latency_data = benchmark_data['inference_latency']
            throughput_with = latency_data.get('with_cache', {}).get('throughput_qps', 0)
            throughput_without = latency_data.get('without_cache', {}).get('throughput_qps', 0)

            if throughput_without > 0:
                throughput_improvement = (throughput_with - throughput_without) / throughput_without

                # Estimar reducción en servidores necesarios
                # Asumiendo que throughput mejora permite reducir capacidad de servidores
                server_reduction_factor = min(throughput_improvement * 0.5, 0.3)  # Máximo 30% reducción

                hours_per_month = 24 * 30  # 720 horas
                server_hours_saved = hours_per_month * server_reduction_factor

                savings['server_hours_saved_monthly'] = server_hours_saved
                savings['infrastructure_cost_savings_monthly'] = server_hours_saved * cost_model['infrastructure_cost_per_hour']

        # Costo de almacenamiento del cache
        cache_size_gb = self.config.get('cache_size_gb', 1.0)  # 1GB por defecto
        savings['cache_storage_cost_monthly'] = cache_size_gb * cost_model['cache_storage_cost_per_gb']

        # Ahorro neto (restar costo de cache)
        gross_savings = savings['infrastructure_cost_savings_monthly']
        cache_cost = savings['cache_storage_cost_monthly']
        savings['net_infrastructure_savings_monthly'] = gross_savings - cache_cost

        return savings

    def calculate_roi_analysis(self, inference_savings: Dict[str, Any],
                             infra_savings: Dict[str, Any]) -> Dict[str, Any]:
        """Calcular análisis de ROI."""
        # Costos de implementación del cache
        implementation_costs = {
            'development_hours': self.config.get('development_hours', 40),
            'hourly_rate': self.config.get('hourly_developer_rate', 75),
            'infrastructure_setup_cost': self.config.get('infrastructure_setup_cost', 1000),
            'monthly_maintenance_cost': self.config.get('monthly_maintenance_cost', 200)
        }

        # Calcular costo total de implementación
        development_cost = implementation_costs['development_hours'] * implementation_costs['hourly_rate']
        total_implementation_cost = development_cost + implementation_costs['infrastructure_setup_cost']

        # Ahorros mensuales totales
        monthly_savings = (
            inference_savings['total_savings_monthly'] +
            infra_savings['net_infrastructure_savings_monthly']
        )

        # Calcular período de recuperación
        if monthly_savings > 0:
            payback_months = total_implementation_cost / monthly_savings
            payback_years = payback_months / 12
        else:
            payback_months = float('inf')
            payback_years = float('inf')

        # ROI anual (primer año)
        annual_savings = monthly_savings * 12
        roi_percentage = (annual_savings / total_implementation_cost) * 100 if total_implementation_cost > 0 else 0

        return {
            'implementation_costs': implementation_costs,
            'total_implementation_cost': total_implementation_cost,
            'monthly_savings': monthly_savings,
            'annual_savings': annual_savings,
            'payback_period_months': payback_months,
            'payback_period_years': payback_years,
            'roi_percentage': roi_percentage,
            'monthly_maintenance_cost': implementation_costs['monthly_maintenance_cost'],
            'net_monthly_savings': monthly_savings - implementation_costs['monthly_maintenance_cost']
        }

    def run_calculations(self) -> Dict[str, Any]:
        """Ejecutar todos los cálculos de costos."""
        logger.info("Iniciando cálculos de costos ahorrados...")

        # Cargar datos de benchmarks
        benchmark_data = self.load_benchmark_results(self.config.get('benchmark_results_dir', 'benchmark_results'))

        # Definir modelos de costo
        cost_models = self.define_cost_models()

        # Calcular ahorros para cada modelo de costo
        for model_key, cost_model in cost_models.items():
            logger.info(f"Calculando ahorros para modelo: {cost_model['name']}")

            # Ahorros en inferencia
            inference_savings = self.calculate_inference_cost_savings(benchmark_data, cost_model)

            # Ahorros en infraestructura
            infra_savings = self.calculate_infrastructure_cost_savings(benchmark_data, cost_model)

            # Análisis de ROI
            roi_analysis = self.calculate_roi_analysis(inference_savings, infra_savings)

            self.results['cost_models'][model_key] = {
                'cost_model': cost_model,
                'inference_savings': inference_savings,
                'infrastructure_savings': infra_savings,
                'roi_analysis': roi_analysis
            }

        # Generar análisis general
        self.generate_overall_analysis()

        logger.info("Cálculos completados")
        return self.results

    def generate_overall_analysis(self):
        """Generar análisis general de ahorros."""
        analysis = {
            'best_cost_model': None,
            'highest_savings_model': None,
            'fastest_payback_model': None,
            'average_roi': 0,
            'total_potential_savings': 0
        }

        best_savings = 0
        fastest_payback = float('inf')
        total_roi = 0
        model_count = 0

        for model_key, model_data in self.results['cost_models'].items():
            roi_data = model_data['roi_analysis']
            monthly_savings = roi_data['monthly_savings']

            if monthly_savings > best_savings:
                best_savings = monthly_savings
                analysis['highest_savings_model'] = model_key

            payback_months = roi_data['payback_period_months']
            if payback_months < fastest_payback and payback_months != float('inf'):
                fastest_payback = payback_months
                analysis['fastest_payback_model'] = model_key

            if roi_data['roi_percentage'] > 0:
                total_roi += roi_data['roi_percentage']
                model_count += 1

        analysis['average_roi'] = total_roi / model_count if model_count > 0 else 0
        analysis['total_potential_savings'] = best_savings

        # Modelo recomendado (balance entre ahorros y payback)
        recommended_model = None
        best_score = 0

        for model_key, model_data in self.results['cost_models'].items():
            roi_data = model_data['roi_analysis']
            savings_score = roi_data['monthly_savings'] / 1000  # Normalizar
            payback_score = 12 / max(roi_data['payback_period_months'], 1)  # Menor payback = mejor
            combined_score = savings_score + payback_score

            if combined_score > best_score:
                best_score = combined_score
                recommended_model = model_key

        analysis['recommended_model'] = recommended_model

        self.results['savings_analysis'] = analysis

    def save_results(self, output_file: str):
        """Guardar resultados en archivo JSON."""
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)

        logger.info(f"Resultados guardados en {output_path}")

    def print_summary(self):
        """Imprimir resumen de costos ahorrados."""
        analysis = self.results.get('savings_analysis', {})

        print("\n" + "="*80)
        print("RESUMEN DE COSTOS AHORRADOS - RAG + CAG vs RAG")
        print("="*80)

        print(f"\nModelo con mayores ahorros: {analysis.get('highest_savings_model', 'N/A')}")
        print(f"Modelo con payback más rápido: {analysis.get('fastest_payback_model', 'N/A')}")
        print(f"Modelo recomendado: {analysis.get('recommended_model', 'N/A')}")
        print(".1f")
        print(".0f")

        print("\nDETALLE POR MODELO DE COSTO:")
        for model_key, model_data in self.results.get('cost_models', {}).items():
            print(f"\n{model_data['cost_model']['name'].upper()}:")
            print(f"  Descripción: {model_data['cost_model']['description']}")

            inference = model_data['inference_savings']
            infra = model_data['infrastructure_savings']
            roi = model_data['roi_analysis']

            print(".0f")
            print(".0f")
            print(".0f")
            print(".0f")
            print(".1f")
            print(".1f")
            print(".1f")

        print("\n" + "="*80)


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Calcular costos ahorrados con RAG + CAG')
    parser.add_argument('--benchmark_results_dir', type=str, default='benchmark_results',
                       help='Directorio con resultados de benchmarks')
    parser.add_argument('--cost_model', type=str, default='all',
                       help='Modelo de costo a usar (standard, premium, enterprise, custom, all)')
    parser.add_argument('--monthly_queries', type=int, default=100000,
                       help='Número estimado de queries mensuales')
    parser.add_argument('--avg_tokens_per_query', type=int, default=200,
                       help='Número promedio de tokens por query')
    parser.add_argument('--cache_size_gb', type=float, default=1.0,
                       help='Tamaño del cache en GB')
    parser.add_argument('--development_hours', type=int, default=40,
                       help='Horas de desarrollo para implementar CAG')
    parser.add_argument('--hourly_developer_rate', type=float, default=75.0,
                       help='Costo por hora del desarrollador')
    parser.add_argument('--infrastructure_setup_cost', type=float, default=1000.0,
                       help='Costo de setup de infraestructura')
    parser.add_argument('--monthly_maintenance_cost', type=float, default=200.0,
                       help='Costo mensual de mantenimiento')
    parser.add_argument('--custom_inference_cost', type=float, default=0.0002,
                       help='Costo personalizado por token de inferencia')
    parser.add_argument('--custom_latency_cost', type=float, default=0.02,
                       help='Costo personalizado por segundo de latencia')
    parser.add_argument('--custom_infra_cost', type=float, default=3.0,
                       help='Costo personalizado por hora de infraestructura')
    parser.add_argument('--custom_storage_cost', type=float, default=0.15,
                       help='Costo personalizado por GB de almacenamiento')
    parser.add_argument('--output_file', type=str, default='benchmark_results/cost_savings_report.json',
                       help='Archivo de salida para resultados')

    args = parser.parse_args()

    # Configuración del cálculo
    config = {
        'benchmark_results_dir': args.benchmark_results_dir,
        'cost_model': args.cost_model,
        'monthly_queries': args.monthly_queries,
        'avg_tokens_per_query': args.avg_tokens_per_query,
        'cache_size_gb': args.cache_size_gb,
        'development_hours': args.development_hours,
        'hourly_developer_rate': args.hourly_developer_rate,
        'infrastructure_setup_cost': args.infrastructure_setup_cost,
        'monthly_maintenance_cost': args.monthly_maintenance_cost,
        'custom_inference_cost': args.custom_inference_cost,
        'custom_latency_cost': args.custom_latency_cost,
        'custom_infra_cost': args.custom_infra_cost,
        'custom_storage_cost': args.custom_storage_cost
    }

    # Crear calculador
    calculator = CostSavingsCalculator(config)

    try:
        # Ejecutar cálculos
        results = calculator.run_calculations()

        # Guardar resultados
        calculator.save_results(args.output_file)

        # Imprimir resumen
        calculator.print_summary()

        logger.info(f"Análisis de costos completado. Resultados guardados en {args.output_file}")

    except Exception as e:
        logger.error(f"Error en el cálculo de costos: {e}")
        raise


if __name__ == "__main__":
    main()