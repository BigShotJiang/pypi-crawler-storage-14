#!/usr/bin/env python3
"""
HardwareDetector - Comprehensive hardware detection and auto-configuration for Ailoos nodes.

This script detects system hardware capabilities and assigns performance tiers (NANO to ULTRA)
with automatic configuration generation for optimal performance. Supports detailed classification
including weak/apt/hyper categories and comprehensive node tiering.
"""

import json
import logging
import os
import platform
import sys
import hashlib
import subprocess
import time
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional, List

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Optional dependencies
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    logger.warning("psutil not available. Some hardware detection features will be limited.")

try:
    import cpuinfo
    CPUINFO_AVAILABLE = True
except ImportError:
    CPUINFO_AVAILABLE = False
    logger.warning("cpuinfo not available. CPU details will be basic.")

try:
    import GPUtil
    GPUTIL_AVAILABLE = True
except ImportError:
    GPUTIL_AVAILABLE = False
    logger.warning("GPUtil not available. GPU detection will be limited.")

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    logger.warning("torch not available. GPU detection via torch will be unavailable.")


@dataclass
class HardwareCapabilities:
    """Hardware capabilities of the system."""
    # CPU
    cpu_cores: int = 0
    cpu_frequency_mhz: float = 0.0
    cpu_name: str = ""
    cpu_architecture_type: str = ""
    cpu_instruction_sets: List[str] = None
    cpu_cache_sizes: Dict[str, float] = None
    cpu_benchmark_ops_per_sec: float = 0.0

    # Memory
    total_memory_gb: float = 0.0
    available_memory_gb: float = 0.0
    memory_bandwidth_gb_per_sec: float = 0.0

    # Storage
    total_storage_gb: float = 0.0
    available_storage_gb: float = 0.0
    storage_read_speed_mb_per_sec: float = 0.0
    storage_write_speed_mb_per_sec: float = 0.0
    storage_iops: int = 0

    # GPU
    gpu_available: bool = False
    gpu_count: int = 0
    gpu_name: str = ""
    gpu_memory_gb: float = 0.0
    cuda_available: bool = False
    cuda_version: str = ""

    # Network
    network_interfaces: List[Dict[str, Any]] = None
    network_speed_mbps: float = 0.0
    network_latency_ms: float = 0.0

    # Performance score
    performance_score: float = 0.0

    # Node fingerprint
    node_fingerprint: str = ""

    # System info
    os: str = ""
    architecture: str = ""
    python_version: str = ""

    def __post_init__(self):
        if self.cpu_instruction_sets is None:
            self.cpu_instruction_sets = []
        if self.cpu_cache_sizes is None:
            self.cpu_cache_sizes = {}
        if self.network_interfaces is None:
            self.network_interfaces = []


class HardwareDetector:
    """Main hardware detection class."""

    def __init__(self):
        self.capabilities = HardwareCapabilities()

    def detect_hardware(self) -> HardwareCapabilities:
        """Detect all hardware capabilities."""
        logger.info("🔍 Starting hardware detection...")

        # System info
        self.capabilities.os = platform.system()
        self.capabilities.architecture = platform.machine()
        self.capabilities.python_version = platform.python_version()

        # CPU detection
        self._detect_cpu()

        # Memory detection
        self._detect_memory()

        # Storage detection
        self._detect_storage()

        # GPU detection
        self._detect_gpu()

        # Calculate performance score
        self._calculate_performance_score()

        logger.info(f"✅ Hardware detection completed. Performance score: {self.capabilities.performance_score:.1f}")
        return self.capabilities

    def _detect_cpu(self):
        """Detect CPU capabilities."""
        if not PSUTIL_AVAILABLE:
            self.capabilities.cpu_cores = os.cpu_count() or 1
            self.capabilities.cpu_name = "Unknown CPU"
            return

        self.capabilities.cpu_cores = psutil.cpu_count(logical=True)

        if CPUINFO_AVAILABLE:
            try:
                cpu_info = cpuinfo.get_cpu_info()
                self.capabilities.cpu_name = cpu_info.get('brand_raw', 'Unknown CPU')
                self.capabilities.cpu_frequency_mhz = cpu_info.get('hz_actual', [0])[0] / 1e6 if cpu_info.get('hz_actual') else 0
                self.capabilities.cpu_architecture_type = cpu_info.get('arch', platform.machine())
                self.capabilities.cpu_instruction_sets = cpu_info.get('flags', [])
                cache_size = cpu_info.get('cache_size', '0 KB')
                # Parse cache size, e.g., "6144 KB" to float
                try:
                    cache_mb = float(cache_size.split()[0]) / 1024 if 'KB' in cache_size else float(cache_size.split()[0])
                    self.capabilities.cpu_cache_sizes = {'L3': cache_mb}  # Assuming L3
                except:
                    self.capabilities.cpu_cache_sizes = {}
            except Exception as e:
                logger.warning(f"Failed to get detailed CPU info: {e}")
                self.capabilities.cpu_name = "Unknown CPU"
        else:
            self.capabilities.cpu_name = f"CPU with {self.capabilities.cpu_cores} cores"
            self.capabilities.cpu_architecture_type = platform.machine()

        # Fallback frequency
        if self.capabilities.cpu_frequency_mhz == 0 and psutil.cpu_freq():
            self.capabilities.cpu_frequency_mhz = psutil.cpu_freq().max

        # Benchmark CPU performance
        self._benchmark_cpu()

    def _benchmark_cpu(self):
        """Benchmark CPU performance with a simple computation."""
        try:
            import math
            start_time = time.time()
            # Simple benchmark: compute square roots
            result = 0.0
            for i in range(100000):
                result += math.sqrt(i)
            end_time = time.time()
            elapsed = end_time - start_time
            self.capabilities.cpu_benchmark_ops_per_sec = 100000 / elapsed  # ops per second
        except Exception as e:
            logger.warning(f"Failed to benchmark CPU: {e}")
            self.capabilities.cpu_benchmark_ops_per_sec = 0.0

    def _detect_memory(self):
        """Detect memory capabilities."""
        if not PSUTIL_AVAILABLE:
            return

        mem = psutil.virtual_memory()
        self.capabilities.total_memory_gb = mem.total / (1024**3)
        self.capabilities.available_memory_gb = mem.available / (1024**3)

        # Estimate memory bandwidth
        self._detect_memory_bandwidth()

    def _detect_memory_bandwidth(self):
        """Estimate memory bandwidth using a simple benchmark."""
        try:
            # Simple memory bandwidth test: copy large array
            size = 100 * 1024 * 1024  # 100 MB
            src = bytearray(size)
            dst = bytearray(size)

            start_time = time.time()
            for i in range(10):  # Multiple iterations
                dst[:] = src
            end_time = time.time()

            elapsed = end_time - start_time
            data_transferred_gb = (size * 10) / (1024**3)
            bandwidth = data_transferred_gb / elapsed
            self.capabilities.memory_bandwidth_gb_per_sec = bandwidth
        except Exception as e:
            logger.warning(f"Failed to measure memory bandwidth: {e}")
            self.capabilities.memory_bandwidth_gb_per_sec = 0.0

    def _detect_storage(self):
        """Detect storage capabilities."""
        if not PSUTIL_AVAILABLE:
            return

        # Get root partition
        try:
            usage = psutil.disk_usage('/')
            self.capabilities.total_storage_gb = usage.total / (1024**3)
            self.capabilities.available_storage_gb = usage.free / (1024**3)
        except Exception as e:
            logger.warning(f"Failed to detect storage: {e}")

        # Measure storage I/O
        self._detect_storage_io()

    def _detect_storage_io(self):
        """Measure storage I/O performance."""
        try:
            # Measure read speed using dd
            result = subprocess.run(
                ['dd', 'if=/dev/zero', 'of=/tmp/testfile', 'bs=1M', 'count=100', 'conv=fdatasync'],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                # Parse output like "100+0 records in\n100+0 records out\n104857600 bytes (105 MB, 100 MiB) copied, 0.123456 s, 852 MB/s"
                lines = result.stderr.split('\n')
                for line in lines:
                    if 'MB/s' in line or 'MB/sec' in line:
                        speed_str = line.split(',')[-1].strip()
                        speed = float(speed_str.split()[0])
                        self.capabilities.storage_write_speed_mb_per_sec = speed
                        break

            # Measure read speed
            result = subprocess.run(
                ['dd', 'if=/tmp/testfile', 'of=/dev/null', 'bs=1M'],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                lines = result.stderr.split('\n')
                for line in lines:
                    if 'MB/s' in line or 'MB/sec' in line:
                        speed_str = line.split(',')[-1].strip()
                        speed = float(speed_str.split()[0])
                        self.capabilities.storage_read_speed_mb_per_sec = speed
                        break

            # Clean up
            subprocess.run(['rm', '-f', '/tmp/testfile'], capture_output=True)

            # Estimate IOPS (rough estimate for SSD/HDD)
            if self.capabilities.storage_read_speed_mb_per_sec > 500:
                self.capabilities.storage_iops = 100000  # SSD estimate
            elif self.capabilities.storage_read_speed_mb_per_sec > 100:
                self.capabilities.storage_iops = 10000  # Fast HDD
            else:
                self.capabilities.storage_iops = 1000  # Slow HDD

        except (subprocess.TimeoutExpired, subprocess.SubprocessError, ValueError) as e:
            logger.warning(f"Failed to measure storage I/O: {e}")
            self.capabilities.storage_read_speed_mb_per_sec = 0.0
            self.capabilities.storage_write_speed_mb_per_sec = 0.0
            self.capabilities.storage_iops = 0

    def _detect_gpu(self):
        """Detect GPU capabilities."""
        # Try torch first
        if TORCH_AVAILABLE:
            if torch.cuda.is_available():
                self.capabilities.cuda_available = True
                self.capabilities.gpu_available = True
                self.capabilities.gpu_count = torch.cuda.device_count()
                self.capabilities.gpu_name = torch.cuda.get_device_name(0)
                self.capabilities.gpu_memory_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
                self.capabilities.cuda_version = torch.version.cuda or "Unknown"
                return

        # Try GPUtil
        if GPUTIL_AVAILABLE:
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    self.capabilities.gpu_available = True
                    self.capabilities.gpu_count = len(gpus)
                    gpu = gpus[0]  # Use first GPU
                    self.capabilities.gpu_name = gpu.name
                    self.capabilities.gpu_memory_gb = gpu.memoryTotal / 1024  # Convert MB to GB
            except Exception as e:
                logger.warning(f"Failed to detect GPU via GPUtil: {e}")

        # Check for MPS (Apple Silicon)
        if TORCH_AVAILABLE and torch.backends.mps.is_available():
            self.capabilities.gpu_available = True
            self.capabilities.gpu_name = "Apple Silicon GPU"
            self.capabilities.gpu_memory_gb = 0  # MPS doesn't report memory directly

    def _detect_network_capabilities(self):
        """Detect network capabilities."""
        if not PSUTIL_AVAILABLE:
            return

        try:
            interfaces = psutil.net_if_addrs()
            self.capabilities.network_interfaces = []
            max_speed = 0.0

            for name, addrs in interfaces.items():
                if name == 'lo':  # Skip loopback
                    continue
                interface_info = {'name': name, 'addresses': []}
                for addr in addrs:
                    if addr.family.name == 'AF_INET':
                        interface_info['addresses'].append(addr.address)
                        # Try to get speed (not always available)
                        try:
                            stats = psutil.net_if_stats()
                            if name in stats:
                                speed = stats[name].speed
                                if speed > 0:
                                    max_speed = max(max_speed, speed)
                                    interface_info['speed_mbps'] = speed
                        except:
                            pass
                if interface_info['addresses']:
                    self.capabilities.network_interfaces.append(interface_info)

            self.capabilities.network_speed_mbps = max_speed

            # Measure latency to google DNS
            try:
                result = subprocess.run(
                    ['ping', '-c', '3', '-q', '8.8.8.8'],
                    capture_output=True, text=True, timeout=10
                )
                if result.returncode == 0:
                    # Parse avg latency from "rtt min/avg/max/mdev = 10.123/15.456/20.789/2.345 ms"
                    lines = result.stdout.split('\n')
                    for line in lines:
                        if 'rtt' in line:
                            parts = line.split('=')[1].split('/')
                            avg_rtt = float(parts[1])
                            self.capabilities.network_latency_ms = avg_rtt
                            break
            except (subprocess.TimeoutExpired, subprocess.SubprocessError, ValueError):
                self.capabilities.network_latency_ms = 0.0

        except Exception as e:
            logger.warning(f"Failed to detect network capabilities: {e}")

    def _generate_fingerprint(self):
        """Generate a unique fingerprint for the node based on capabilities."""
        # Create a string representation of key capabilities
        fingerprint_data = {
            'cpu_name': self.capabilities.cpu_name,
            'cpu_cores': self.capabilities.cpu_cores,
            'total_memory_gb': round(self.capabilities.total_memory_gb, 1),
            'gpu_name': self.capabilities.gpu_name if self.capabilities.gpu_available else 'No GPU',
            'os': self.capabilities.os,
            'architecture': self.capabilities.architecture
        }
        fingerprint_str = json.dumps(fingerprint_data, sort_keys=True)
        self.capabilities.node_fingerprint = hashlib.sha256(fingerprint_str.encode()).hexdigest()[:16]

    def _calculate_performance_score(self):
        """Calculate performance score based on hardware."""
        score = 0.0

        # CPU score (max 1.0)
        cpu_score = min(self.capabilities.cpu_cores / 16.0, 1.0)  # Normalize to 16 cores
        score += cpu_score

        # Memory score (max 1.0)
        mem_score = min(self.capabilities.total_memory_gb / 32.0, 1.0)  # Normalize to 32GB
        score += mem_score

        # GPU score (max 2.0)
        if self.capabilities.gpu_available:
            gpu_score = 0.0
            if self.capabilities.gpu_memory_gb >= 8.0:
                gpu_score = 2.0  # High-end GPU
            elif self.capabilities.gpu_memory_gb >= 4.0:
                gpu_score = 1.5  # Mid-range GPU
            else:
                gpu_score = 1.0  # Low-end GPU

            # Bonus for multiple GPUs
            gpu_score *= min(self.capabilities.gpu_count, 4) / 4.0
            score += gpu_score

        # Detect network capabilities
        self._detect_network_capabilities()

        # Generate node fingerprint
        self._generate_fingerprint()

        self.capabilities.performance_score = score

    def assign_role(self, capabilities: HardwareCapabilities) -> str:
        """Assign node tier based on capabilities with comprehensive classification."""
        score = capabilities.performance_score

        # Incorporate CPU benchmark into score
        benchmark_bonus = min(capabilities.cpu_benchmark_ops_per_sec / 50000.0, 0.5)  # Max 0.5 bonus
        score += benchmark_bonus

        # Define tiers based on enhanced score
        if score < 0.5:
            tier = "NANO"
        elif score < 1.0:
            tier = "MICRO"
        elif score < 1.5:
            tier = "WEAK"
        elif score < 2.5:
            tier = "APT"
        elif score < 3.5:
            tier = "STANDARD"
        elif score < 4.5:
            tier = "PREMIUM"
        elif score < 5.5:
            tier = "HYPER"
        else:
            tier = "ULTRA"

        # Additional adjustments
        if capabilities.gpu_available and capabilities.gpu_memory_gb >= 16.0:
            if tier in ["WEAK", "APT", "STANDARD"]:
                tier = "HYPER"
        elif capabilities.gpu_available and capabilities.gpu_memory_gb >= 8.0:
            if tier in ["WEAK", "APT"]:
                tier = "PREMIUM"
        elif not capabilities.gpu_available and capabilities.cpu_cores < 4:
            if tier in ["STANDARD", "PREMIUM", "HYPER", "ULTRA"]:
                tier = "APT"

        logger.info(f"🎯 Assigned tier: {tier} (score: {score:.1f}, benchmark: {capabilities.cpu_benchmark_ops_per_sec:.0f} ops/s)")
        return tier

    def generate_config(self, tier: str, capabilities: HardwareCapabilities) -> Dict[str, Any]:
        """Generate auto-configuration based on tier and capabilities."""
        config = {
            "node_role": tier,
            "hardware_capabilities": asdict(capabilities),
            "inference_config": {},
            "training_config": {},
            "resource_limits": {},
            "optimization_settings": {}
        }

        if tier in ["NANO", "MICRO", "WEAK"]:
            # Ultra-lightweight configuration
            config["inference_config"] = {
                "device": "cpu",
                "max_batch_size": 1,
                "memory_limit_gb": min(1.0, capabilities.total_memory_gb * 0.3),
                "precision": "fp32",
                "enable_quantization": True,
                "max_concurrent_requests": 1
            }
            config["training_config"] = {
                "device": "cpu",
                "batch_size": 1,
                "gradient_accumulation_steps": 8,
                "enable_mixed_precision": False
            }
            config["resource_limits"] = {
                "cpu_limit": "1",
                "memory_limit": "1Gi",
                "gpu_limit": 0
            }
            config["optimization_settings"] = {
                "enable_caching": True,
                "cache_size_mb": 256,
                "enable_compression": True
            }

        elif tier == "APT":
            # Balanced configuration
            config["inference_config"] = {
                "device": "cpu",
                "max_batch_size": min(8, capabilities.cpu_cores),
                "memory_limit_gb": min(8.0, capabilities.total_memory_gb * 0.6),
                "precision": "fp32",
                "enable_quantization": False,
                "max_concurrent_requests": 4
            }
            config["training_config"] = {
                "device": "cpu",
                "batch_size": 2,
                "gradient_accumulation_steps": 2,
                "enable_mixed_precision": False
            }
            config["resource_limits"] = {
                "cpu_limit": f"{min(capabilities.cpu_cores, 4)}",
                "memory_limit": "4Gi",
                "gpu_limit": 0
            }
            config["optimization_settings"] = {
                "enable_caching": True,
                "cache_size_mb": 1024,
                "enable_compression": False
            }

        elif tier == "STANDARD":
            # Standard configuration with optional GPU
            device = "cuda" if capabilities.cuda_available else "cpu"
            config["inference_config"] = {
                "device": device,
                "max_batch_size": 8 if device == "cuda" else 4,
                "memory_limit_gb": capabilities.gpu_memory_gb * 0.7 if device == "cuda" else capabilities.total_memory_gb * 0.6,
                "precision": "fp16" if device == "cuda" else "fp32",
                "enable_quantization": device == "cpu",
                "max_concurrent_requests": 6
            }
            config["training_config"] = {
                "device": device,
                "batch_size": 4,
                "gradient_accumulation_steps": 1,
                "enable_mixed_precision": device == "cuda"
            }
            config["resource_limits"] = {
                "cpu_limit": f"{capabilities.cpu_cores}",
                "memory_limit": f"{int(capabilities.total_memory_gb)}Gi",
                "gpu_limit": capabilities.gpu_count if capabilities.gpu_available else 0
            }
            config["optimization_settings"] = {
                "enable_caching": True,
                "cache_size_mb": 1536,
                "enable_compression": False
            }

        elif tier in ["PREMIUM", "HYPER"]:
            # High-performance configuration
            device = "cuda" if capabilities.cuda_available else "cpu"
            max_batch = 16
            if capabilities.gpu_memory_gb >= 16.0:
                max_batch = 32
            elif capabilities.gpu_memory_gb >= 8.0:
                max_batch = 16

            config["inference_config"] = {
                "device": device,
                "max_batch_size": max_batch,
                "memory_limit_gb": capabilities.gpu_memory_gb * 0.8 if device == "cuda" else capabilities.total_memory_gb * 0.7,
                "precision": "fp16" if device == "cuda" else "fp32",
                "enable_quantization": True,
                "max_concurrent_requests": 12
            }
            config["training_config"] = {
                "device": device,
                "batch_size": max_batch // 2,
                "gradient_accumulation_steps": 1,
                "enable_mixed_precision": device == "cuda"
            }
            config["resource_limits"] = {
                "cpu_limit": f"{capabilities.cpu_cores}",
                "memory_limit": f"{int(capabilities.total_memory_gb)}Gi",
                "gpu_limit": capabilities.gpu_count if capabilities.gpu_available else 0
            }
            config["optimization_settings"] = {
                "enable_caching": True,
                "cache_size_mb": 2048,
                "enable_compression": False,
                "tensor_parallel_size": min(capabilities.gpu_count, 4) if capabilities.gpu_available else 1
            }

        elif tier == "ULTRA":
            # Ultra-high-performance configuration
            device = "cuda" if capabilities.cuda_available else "cpu"
            max_batch = 64 if capabilities.gpu_memory_gb >= 24.0 else 32

            config["inference_config"] = {
                "device": device,
                "max_batch_size": max_batch,
                "memory_limit_gb": capabilities.gpu_memory_gb * 0.9 if device == "cuda" else capabilities.total_memory_gb * 0.8,
                "precision": "fp16" if device == "cuda" else "fp32",
                "enable_quantization": False,
                "max_concurrent_requests": 20
            }
            config["training_config"] = {
                "device": device,
                "batch_size": max_batch,
                "gradient_accumulation_steps": 1,
                "enable_mixed_precision": device == "cuda"
            }
            config["resource_limits"] = {
                "cpu_limit": f"{capabilities.cpu_cores}",
                "memory_limit": f"{int(capabilities.total_memory_gb)}Gi",
                "gpu_limit": capabilities.gpu_count if capabilities.gpu_available else 0
            }
            config["optimization_settings"] = {
                "enable_caching": True,
                "cache_size_mb": 4096,
                "enable_compression": False,
                "tensor_parallel_size": min(capabilities.gpu_count, 8) if capabilities.gpu_available else 1
            }

        else:
            # Fallback for unknown tier
            config["inference_config"] = {
                "device": "cpu",
                "max_batch_size": 1,
                "memory_limit_gb": 1.0,
                "precision": "fp32",
                "enable_quantization": True,
                "max_concurrent_requests": 1
            }
            config["training_config"] = {
                "device": "cpu",
                "batch_size": 1,
                "gradient_accumulation_steps": 1,
                "enable_mixed_precision": False
            }
            config["resource_limits"] = {
                "cpu_limit": "1",
                "memory_limit": "1Gi",
                "gpu_limit": 0
            }
            config["optimization_settings"] = {
                "enable_caching": True,
                "cache_size_mb": 256,
                "enable_compression": True
            }

        return config

    def run(self) -> Dict[str, Any]:
        """Run complete detection and configuration."""
        capabilities = self.detect_hardware()
        tier = self.assign_role(capabilities)
        config = self.generate_config(tier, capabilities)
        return config


def save_config(config: Dict[str, Any], output_file: str = "hardware_config.json"):
    """Save configuration to file."""
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        logger.info(f"💾 Configuration saved to {output_file}")
    except Exception as e:
        logger.error(f"Failed to save config: {e}")


def main():
    """Main entry point."""
    print("🚀 Ailoos HardwareDetector")
    print("=" * 50)

    detector = HardwareDetector()
    config = detector.run()

    # Print summary
    caps = config["hardware_capabilities"]
    print("\n📊 Hardware Summary:")
    print(f"  CPU: {caps['cpu_name']} ({caps['cpu_cores']} cores @ {caps['cpu_frequency_mhz']:.0f} MHz)")
    print(f"    Architecture: {caps['cpu_architecture_type']}")
    print(f"    Benchmark Score: {caps['cpu_benchmark_ops_per_sec']:.0f} ops/s")
    if caps['cpu_instruction_sets']:
        print(f"    Instruction Sets: {', '.join(caps['cpu_instruction_sets'][:5])}...")  # Show first 5
    if caps['cpu_cache_sizes']:
        print(f"    Cache: {caps['cpu_cache_sizes']}")
    print(f"  Memory: {caps['total_memory_gb']:.1f} GB total, {caps['available_memory_gb']:.1f} GB available")
    print(f"    Bandwidth: {caps['memory_bandwidth_gb_per_sec']:.2f} GB/s")
    print(f"  Storage: {caps['total_storage_gb']:.1f} GB total, {caps['available_storage_gb']:.1f} GB available")
    print(f"    Read Speed: {caps['storage_read_speed_mb_per_sec']:.1f} MB/s, Write Speed: {caps['storage_write_speed_mb_per_sec']:.1f} MB/s")
    print(f"    IOPS: {caps['storage_iops']}")
    if caps['gpu_available']:
        print(f"  GPU: {caps['gpu_name']} ({caps['gpu_memory_gb']:.1f} GB)")
    else:
        print("  GPU: Not available")
    print(f"  Network: {caps['network_speed_mbps']:.1f} Mbps, Latency: {caps['network_latency_ms']:.1f} ms")
    if caps['network_interfaces']:
        print(f"    Interfaces: {len(caps['network_interfaces'])} active")
    print(f"  Node Fingerprint: {caps['node_fingerprint']}")
    print(f"  Performance Score: {caps['performance_score']:.1f}")

    print(f"\n🎯 Assigned Tier: {config['node_tier']}")
    print(f"  Device: {config['inference_config']['device']}")
    print(f"  Max Batch Size: {config['inference_config']['max_batch_size']}")
    print(f"  Precision: {config['inference_config']['precision']}")

    # Save config
    save_config(config)

    print("\n✅ Hardware detection and configuration completed!")


if __name__ == "__main__":
    main()