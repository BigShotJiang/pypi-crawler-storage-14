#!/usr/bin/env python3
"""
SCRIPT DE TEST: Probar el EmpoorioLM Provider directamente
Verificar que el provider modificado funciona correctamente.
"""

import asyncio
import sys
import os

# Añadir src al path para importar módulos de AILOOS
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

async def test_empoorio_provider():
    """Probar el EmpoorioLM provider directamente."""
    print("🧪 TESTING EMPOORIOLM PROVIDER DIRECTLY")
    print("=" * 50)

    try:
        # Importar el provider modificado
        from frontend.lib.ai.providers import getLanguageModel

        print("✅ Provider importado correctamente")

        # Obtener el modelo EmpoorioLM
        model = getLanguageModel("ailoos/empoorio-lm")
        print("✅ Modelo EmpoorioLM obtenido del provider")

        # Verificar que es una función de ai-sdk
        if hasattr(model, 'doGenerate'):
            print("✅ Modelo tiene interfaz LanguageModelV2 (ai-sdk)")
        else:
            print("❌ Modelo NO tiene interfaz correcta")
            return

        # Probar generación (esto debería llamar al API local)
        print("\n🔄 Probando generación de texto...")

        result = await model.doGenerate({
            "prompt": [{ "type": "text", "text": "Hola EmpoorioLM, ¿cómo estás?" }],
            "maxTokens": 100,
            "temperature": 0.7,
        })

        print("📨 Respuesta generada:")
        print(f"   Texto: {result.content[0].text[:100]}...")
        print(f"   Tokens: {result.usage}")

        if "Hola" in result.content[0].text or "EmpoorioLM" in result.content[0].text:
            print("✅ Provider conectado al API route correctamente")
        else:
            print("⚠️  Respuesta no parece venir del API esperado")

    except Exception as e:
        print(f"❌ Error probando provider: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_empoorio_provider())