#!/usr/bin/env python3
"""
Script to build and publish AILOOS SDK to PyPI
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, cwd=None):
    """Run a shell command and return the result."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"❌ Command failed: {command}")
        print(f"Error: {e.stderr}")
        return None

def main():
    """Main publishing function."""
    print("🚀 Publishing AILOOS SDK to PyPI")
    print("=" * 50)

    # Check if we're in the right directory
    if not Path("setup.py").exists():
        print("❌ setup.py not found. Run from project root.")
        sys.exit(1)

    # Clean previous builds
    print("🧹 Cleaning previous builds...")
    run_command("rm -rf dist/ build/ *.egg-info/")

    # Build the package
    print("📦 Building package...")
    if not run_command("python setup.py sdist bdist_wheel"):
        print("❌ Build failed")
        sys.exit(1)

    # Check the built files
    print("📋 Checking built files...")
    result = run_command("ls -la dist/")
    if result:
        print(result)

    # Test upload to TestPyPI first
    print("🧪 Testing upload to TestPyPI...")
    print("⚠️  Make sure you have ~/.pypirc configured with testpypi credentials")
    print("   Or set TWINE_USERNAME and TWINE_PASSWORD environment variables")

    test_upload = input("Upload to TestPyPI first? (y/N): ").lower().strip()
    if test_upload == 'y':
        if not run_command("twine upload --repository testpypi dist/*"):
            print("❌ TestPyPI upload failed")
            sys.exit(1)
        print("✅ TestPyPI upload successful")
        print("   Test at: https://test.pypi.org/project/ailoos/")

    # Confirm production upload
    confirm = input("Upload to production PyPI? (y/N): ").lower().strip()
    if confirm != 'y':
        print("📦 Package built successfully. Upload cancelled.")
        print(f"Files in: {Path('dist').absolute()}")
        return

    # Upload to production PyPI
    print("📤 Uploading to production PyPI...")
    if not run_command("twine upload dist/*"):
        print("❌ Production PyPI upload failed")
        sys.exit(1)

    print("🎉 Successfully published to PyPI!")
    print("   View at: https://pypi.org/project/ailoos/")

if __name__ == "__main__":
    main()