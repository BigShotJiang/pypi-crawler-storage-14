from typing import Iterable


def ensure_list(x: Iterable):
    return list(x)
