# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowSimCardResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'sim_card_id': 'int',
        'account_id': 'str',
        'cid': 'str',
        'sim_pool_id': 'int',
        'imei': 'str',
        'sim_status': 'int',
        'device_status': 'int',
        'device_model': 'str',
        'act_date': 'datetime',
        'device_status_date': 'datetime',
        'node_id': 'str',
        'iccid': 'str',
        'network_type': 'str',
        'dbm': 'str',
        'signal_level': 'str',
        'sim_type': 'int',
        'tag_names': 'str',
        'order_id': 'int',
        'expire_time': 'datetime',
        'price_plan_name': 'str',
        'sim_price_plan_id': 'int',
        'flow_left': 'float',
        'flow_used': 'float',
        'operator_status': 'int',
        'msisdn': 'str',
        'imsi': 'str',
        'customer_attribute1': 'str',
        'customer_attribute2': 'str',
        'customer_attribute3': 'str',
        'customer_attribute4': 'str',
        'customer_attribute5': 'str',
        'customer_attribute6': 'str',
        'real_named': 'bool',
        'cut_net_flag': 'bool',
        'exceed_cut_net_flag': 'bool',
        'exceed_cut_net_quota': 'int',
        'imei_bind_remain_times': 'int',
        'speed_value': 'int'
    }

    attribute_map = {
        'sim_card_id': 'sim_card_id',
        'account_id': 'account_id',
        'cid': 'cid',
        'sim_pool_id': 'sim_pool_id',
        'imei': 'imei',
        'sim_status': 'sim_status',
        'device_status': 'device_status',
        'device_model': 'device_model',
        'act_date': 'act_date',
        'device_status_date': 'device_status_date',
        'node_id': 'node_id',
        'iccid': 'iccid',
        'network_type': 'network_type',
        'dbm': 'dbm',
        'signal_level': 'signal_level',
        'sim_type': 'sim_type',
        'tag_names': 'tag_names',
        'order_id': 'order_id',
        'expire_time': 'expire_time',
        'price_plan_name': 'price_plan_name',
        'sim_price_plan_id': 'sim_price_plan_id',
        'flow_left': 'flow_left',
        'flow_used': 'flow_used',
        'operator_status': 'operator_status',
        'msisdn': 'msisdn',
        'imsi': 'imsi',
        'customer_attribute1': 'customer_attribute1',
        'customer_attribute2': 'customer_attribute2',
        'customer_attribute3': 'customer_attribute3',
        'customer_attribute4': 'customer_attribute4',
        'customer_attribute5': 'customer_attribute5',
        'customer_attribute6': 'customer_attribute6',
        'real_named': 'real_named',
        'cut_net_flag': 'cut_net_flag',
        'exceed_cut_net_flag': 'exceed_cut_net_flag',
        'exceed_cut_net_quota': 'exceed_cut_net_quota',
        'imei_bind_remain_times': 'imei_bind_remain_times',
        'speed_value': 'speed_value'
    }

    def __init__(self, sim_card_id=None, account_id=None, cid=None, sim_pool_id=None, imei=None, sim_status=None, device_status=None, device_model=None, act_date=None, device_status_date=None, node_id=None, iccid=None, network_type=None, dbm=None, signal_level=None, sim_type=None, tag_names=None, order_id=None, expire_time=None, price_plan_name=None, sim_price_plan_id=None, flow_left=None, flow_used=None, operator_status=None, msisdn=None, imsi=None, customer_attribute1=None, customer_attribute2=None, customer_attribute3=None, customer_attribute4=None, customer_attribute5=None, customer_attribute6=None, real_named=None, cut_net_flag=None, exceed_cut_net_flag=None, exceed_cut_net_quota=None, imei_bind_remain_times=None, speed_value=None):
        r"""ShowSimCardResponse

        The model defined in huaweicloud sdk

        :param sim_card_id: sim卡id
        :type sim_card_id: int
        :param account_id: 账户id
        :type account_id: str
        :param cid: 容器ID:不同类型卡含义如下 iccid(实体卡)，eid（eSIM）cid（vSIM)
        :type cid: str
        :param sim_pool_id: 流量池ID
        :type sim_pool_id: int
        :param imei: 设备IMEI
        :type imei: str
        :param sim_status: sim卡状态：  10.可测试  11.未激活  13.可激活  14.已停用  20.在用  30.已拆机
        :type sim_status: int
        :param device_status: 设备状态：1.注册 2.重启 3.在线 4.离线 (该参数只有ESIM、VSIM返回, 实体卡返回null)
        :type device_status: int
        :param device_model: 设备模组 (该参数只有ESIM、VSIM返回, 实体卡返回null)
        :type device_model: str
        :param act_date: 激活日期 例如2020-01-31T16:00:00.000Z
        :type act_date: datetime
        :param device_status_date: 设备状态变更时间 例如2020-01-31T16:00:00.000Z (该参数只有ESIM、VSIM返回, 实体卡返回null)
        :type device_status_date: datetime
        :param node_id: 设备标识
        :type node_id: str
        :param iccid: 码号iccid
        :type iccid: str
        :param network_type: 网络类型
        :type network_type: str
        :param dbm: 信号强度 (该参数只有ESIM、VSIM返回, 实体卡返回null)
        :type dbm: str
        :param signal_level: 信号等级:1.差  2.良  3.良  4.优 (该参数只有ESIM、VSIM返回, 实体卡返回null)
        :type signal_level: str
        :param sim_type: sim卡类型 1.vSIM  2.eSIM  3.实体卡
        :type sim_type: int
        :param tag_names: 标签名
        :type tag_names: str
        :param order_id: 批次号
        :type order_id: int
        :param expire_time: 到期时间 例如2021-06-30T00:00:00.000Z
        :type expire_time: datetime
        :param price_plan_name: 在用套餐名
        :type price_plan_name: str
        :param sim_price_plan_id: 套餐订购实例ID
        :type sim_price_plan_id: int
        :param flow_left: 剩余流量(单位M)，数据默认截止到昨日24点。
        :type flow_left: float
        :param flow_used: 已用流量(单位M)，数据默认截止到昨日24点。
        :type flow_used: float
        :param operator_status: 运营商状态 -1.正常（非停机状态） 1.停机（超流量停机） 2.停机（超流量阈值停机） 3.停机（流量池停机） 4.停机（套餐到期停机） 5.停机（主动停机） 6.停机（违规停机） 7.停机（机卡分离停机）
        :type operator_status: int
        :param msisdn: MSISDN
        :type msisdn: str
        :param imsi: IMSI
        :type imsi: str
        :param customer_attribute1: 自定义属性一
        :type customer_attribute1: str
        :param customer_attribute2: 自定义属性二
        :type customer_attribute2: str
        :param customer_attribute3: 自定义属性三
        :type customer_attribute3: str
        :param customer_attribute4: 自定义属性四
        :type customer_attribute4: str
        :param customer_attribute5: 自定义属性五
        :type customer_attribute5: str
        :param customer_attribute6: 自定义属性六
        :type customer_attribute6: str
        :param real_named: 是否已实名认证: true表示是，false表示否，系统SIM卡实名认证状态非实时。
        :type real_named: bool
        :param cut_net_flag: 是否单独断网 true:断网，false:未断网 （当前只支持联通、移动的组池卡，电信卡不限制）
        :type cut_net_flag: bool
        :param exceed_cut_net_flag: 是否达量断网 true:达量断网，false:未达量断网 （当前只支持联通、移动的组池卡，电信卡不限制）
        :type exceed_cut_net_flag: bool
        :param exceed_cut_net_quota: 达量断网阈值（单位MB 当前仅电信卡支持）
        :type exceed_cut_net_quota: int
        :param imei_bind_remain_times: 本月机卡绑定剩余次数（当前仅电信卡支持）
        :type imei_bind_remain_times: int
        :param speed_value: 网络限制速率（单位Kbps,当前电信联通卡支持）
        :type speed_value: int
        """
        
        super().__init__()

        self._sim_card_id = None
        self._account_id = None
        self._cid = None
        self._sim_pool_id = None
        self._imei = None
        self._sim_status = None
        self._device_status = None
        self._device_model = None
        self._act_date = None
        self._device_status_date = None
        self._node_id = None
        self._iccid = None
        self._network_type = None
        self._dbm = None
        self._signal_level = None
        self._sim_type = None
        self._tag_names = None
        self._order_id = None
        self._expire_time = None
        self._price_plan_name = None
        self._sim_price_plan_id = None
        self._flow_left = None
        self._flow_used = None
        self._operator_status = None
        self._msisdn = None
        self._imsi = None
        self._customer_attribute1 = None
        self._customer_attribute2 = None
        self._customer_attribute3 = None
        self._customer_attribute4 = None
        self._customer_attribute5 = None
        self._customer_attribute6 = None
        self._real_named = None
        self._cut_net_flag = None
        self._exceed_cut_net_flag = None
        self._exceed_cut_net_quota = None
        self._imei_bind_remain_times = None
        self._speed_value = None
        self.discriminator = None

        if sim_card_id is not None:
            self.sim_card_id = sim_card_id
        if account_id is not None:
            self.account_id = account_id
        if cid is not None:
            self.cid = cid
        if sim_pool_id is not None:
            self.sim_pool_id = sim_pool_id
        if imei is not None:
            self.imei = imei
        if sim_status is not None:
            self.sim_status = sim_status
        if device_status is not None:
            self.device_status = device_status
        if device_model is not None:
            self.device_model = device_model
        if act_date is not None:
            self.act_date = act_date
        if device_status_date is not None:
            self.device_status_date = device_status_date
        if node_id is not None:
            self.node_id = node_id
        if iccid is not None:
            self.iccid = iccid
        if network_type is not None:
            self.network_type = network_type
        if dbm is not None:
            self.dbm = dbm
        if signal_level is not None:
            self.signal_level = signal_level
        if sim_type is not None:
            self.sim_type = sim_type
        if tag_names is not None:
            self.tag_names = tag_names
        if order_id is not None:
            self.order_id = order_id
        if expire_time is not None:
            self.expire_time = expire_time
        if price_plan_name is not None:
            self.price_plan_name = price_plan_name
        if sim_price_plan_id is not None:
            self.sim_price_plan_id = sim_price_plan_id
        if flow_left is not None:
            self.flow_left = flow_left
        if flow_used is not None:
            self.flow_used = flow_used
        if operator_status is not None:
            self.operator_status = operator_status
        if msisdn is not None:
            self.msisdn = msisdn
        if imsi is not None:
            self.imsi = imsi
        if customer_attribute1 is not None:
            self.customer_attribute1 = customer_attribute1
        if customer_attribute2 is not None:
            self.customer_attribute2 = customer_attribute2
        if customer_attribute3 is not None:
            self.customer_attribute3 = customer_attribute3
        if customer_attribute4 is not None:
            self.customer_attribute4 = customer_attribute4
        if customer_attribute5 is not None:
            self.customer_attribute5 = customer_attribute5
        if customer_attribute6 is not None:
            self.customer_attribute6 = customer_attribute6
        if real_named is not None:
            self.real_named = real_named
        if cut_net_flag is not None:
            self.cut_net_flag = cut_net_flag
        if exceed_cut_net_flag is not None:
            self.exceed_cut_net_flag = exceed_cut_net_flag
        if exceed_cut_net_quota is not None:
            self.exceed_cut_net_quota = exceed_cut_net_quota
        if imei_bind_remain_times is not None:
            self.imei_bind_remain_times = imei_bind_remain_times
        if speed_value is not None:
            self.speed_value = speed_value

    @property
    def sim_card_id(self):
        r"""Gets the sim_card_id of this ShowSimCardResponse.

        sim卡id

        :return: The sim_card_id of this ShowSimCardResponse.
        :rtype: int
        """
        return self._sim_card_id

    @sim_card_id.setter
    def sim_card_id(self, sim_card_id):
        r"""Sets the sim_card_id of this ShowSimCardResponse.

        sim卡id

        :param sim_card_id: The sim_card_id of this ShowSimCardResponse.
        :type sim_card_id: int
        """
        self._sim_card_id = sim_card_id

    @property
    def account_id(self):
        r"""Gets the account_id of this ShowSimCardResponse.

        账户id

        :return: The account_id of this ShowSimCardResponse.
        :rtype: str
        """
        return self._account_id

    @account_id.setter
    def account_id(self, account_id):
        r"""Sets the account_id of this ShowSimCardResponse.

        账户id

        :param account_id: The account_id of this ShowSimCardResponse.
        :type account_id: str
        """
        self._account_id = account_id

    @property
    def cid(self):
        r"""Gets the cid of this ShowSimCardResponse.

        容器ID:不同类型卡含义如下 iccid(实体卡)，eid（eSIM）cid（vSIM)

        :return: The cid of this ShowSimCardResponse.
        :rtype: str
        """
        return self._cid

    @cid.setter
    def cid(self, cid):
        r"""Sets the cid of this ShowSimCardResponse.

        容器ID:不同类型卡含义如下 iccid(实体卡)，eid（eSIM）cid（vSIM)

        :param cid: The cid of this ShowSimCardResponse.
        :type cid: str
        """
        self._cid = cid

    @property
    def sim_pool_id(self):
        r"""Gets the sim_pool_id of this ShowSimCardResponse.

        流量池ID

        :return: The sim_pool_id of this ShowSimCardResponse.
        :rtype: int
        """
        return self._sim_pool_id

    @sim_pool_id.setter
    def sim_pool_id(self, sim_pool_id):
        r"""Sets the sim_pool_id of this ShowSimCardResponse.

        流量池ID

        :param sim_pool_id: The sim_pool_id of this ShowSimCardResponse.
        :type sim_pool_id: int
        """
        self._sim_pool_id = sim_pool_id

    @property
    def imei(self):
        r"""Gets the imei of this ShowSimCardResponse.

        设备IMEI

        :return: The imei of this ShowSimCardResponse.
        :rtype: str
        """
        return self._imei

    @imei.setter
    def imei(self, imei):
        r"""Sets the imei of this ShowSimCardResponse.

        设备IMEI

        :param imei: The imei of this ShowSimCardResponse.
        :type imei: str
        """
        self._imei = imei

    @property
    def sim_status(self):
        r"""Gets the sim_status of this ShowSimCardResponse.

        sim卡状态：  10.可测试  11.未激活  13.可激活  14.已停用  20.在用  30.已拆机

        :return: The sim_status of this ShowSimCardResponse.
        :rtype: int
        """
        return self._sim_status

    @sim_status.setter
    def sim_status(self, sim_status):
        r"""Sets the sim_status of this ShowSimCardResponse.

        sim卡状态：  10.可测试  11.未激活  13.可激活  14.已停用  20.在用  30.已拆机

        :param sim_status: The sim_status of this ShowSimCardResponse.
        :type sim_status: int
        """
        self._sim_status = sim_status

    @property
    def device_status(self):
        r"""Gets the device_status of this ShowSimCardResponse.

        设备状态：1.注册 2.重启 3.在线 4.离线 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :return: The device_status of this ShowSimCardResponse.
        :rtype: int
        """
        return self._device_status

    @device_status.setter
    def device_status(self, device_status):
        r"""Sets the device_status of this ShowSimCardResponse.

        设备状态：1.注册 2.重启 3.在线 4.离线 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :param device_status: The device_status of this ShowSimCardResponse.
        :type device_status: int
        """
        self._device_status = device_status

    @property
    def device_model(self):
        r"""Gets the device_model of this ShowSimCardResponse.

        设备模组 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :return: The device_model of this ShowSimCardResponse.
        :rtype: str
        """
        return self._device_model

    @device_model.setter
    def device_model(self, device_model):
        r"""Sets the device_model of this ShowSimCardResponse.

        设备模组 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :param device_model: The device_model of this ShowSimCardResponse.
        :type device_model: str
        """
        self._device_model = device_model

    @property
    def act_date(self):
        r"""Gets the act_date of this ShowSimCardResponse.

        激活日期 例如2020-01-31T16:00:00.000Z

        :return: The act_date of this ShowSimCardResponse.
        :rtype: datetime
        """
        return self._act_date

    @act_date.setter
    def act_date(self, act_date):
        r"""Sets the act_date of this ShowSimCardResponse.

        激活日期 例如2020-01-31T16:00:00.000Z

        :param act_date: The act_date of this ShowSimCardResponse.
        :type act_date: datetime
        """
        self._act_date = act_date

    @property
    def device_status_date(self):
        r"""Gets the device_status_date of this ShowSimCardResponse.

        设备状态变更时间 例如2020-01-31T16:00:00.000Z (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :return: The device_status_date of this ShowSimCardResponse.
        :rtype: datetime
        """
        return self._device_status_date

    @device_status_date.setter
    def device_status_date(self, device_status_date):
        r"""Sets the device_status_date of this ShowSimCardResponse.

        设备状态变更时间 例如2020-01-31T16:00:00.000Z (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :param device_status_date: The device_status_date of this ShowSimCardResponse.
        :type device_status_date: datetime
        """
        self._device_status_date = device_status_date

    @property
    def node_id(self):
        r"""Gets the node_id of this ShowSimCardResponse.

        设备标识

        :return: The node_id of this ShowSimCardResponse.
        :rtype: str
        """
        return self._node_id

    @node_id.setter
    def node_id(self, node_id):
        r"""Sets the node_id of this ShowSimCardResponse.

        设备标识

        :param node_id: The node_id of this ShowSimCardResponse.
        :type node_id: str
        """
        self._node_id = node_id

    @property
    def iccid(self):
        r"""Gets the iccid of this ShowSimCardResponse.

        码号iccid

        :return: The iccid of this ShowSimCardResponse.
        :rtype: str
        """
        return self._iccid

    @iccid.setter
    def iccid(self, iccid):
        r"""Sets the iccid of this ShowSimCardResponse.

        码号iccid

        :param iccid: The iccid of this ShowSimCardResponse.
        :type iccid: str
        """
        self._iccid = iccid

    @property
    def network_type(self):
        r"""Gets the network_type of this ShowSimCardResponse.

        网络类型

        :return: The network_type of this ShowSimCardResponse.
        :rtype: str
        """
        return self._network_type

    @network_type.setter
    def network_type(self, network_type):
        r"""Sets the network_type of this ShowSimCardResponse.

        网络类型

        :param network_type: The network_type of this ShowSimCardResponse.
        :type network_type: str
        """
        self._network_type = network_type

    @property
    def dbm(self):
        r"""Gets the dbm of this ShowSimCardResponse.

        信号强度 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :return: The dbm of this ShowSimCardResponse.
        :rtype: str
        """
        return self._dbm

    @dbm.setter
    def dbm(self, dbm):
        r"""Sets the dbm of this ShowSimCardResponse.

        信号强度 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :param dbm: The dbm of this ShowSimCardResponse.
        :type dbm: str
        """
        self._dbm = dbm

    @property
    def signal_level(self):
        r"""Gets the signal_level of this ShowSimCardResponse.

        信号等级:1.差  2.良  3.良  4.优 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :return: The signal_level of this ShowSimCardResponse.
        :rtype: str
        """
        return self._signal_level

    @signal_level.setter
    def signal_level(self, signal_level):
        r"""Sets the signal_level of this ShowSimCardResponse.

        信号等级:1.差  2.良  3.良  4.优 (该参数只有ESIM、VSIM返回, 实体卡返回null)

        :param signal_level: The signal_level of this ShowSimCardResponse.
        :type signal_level: str
        """
        self._signal_level = signal_level

    @property
    def sim_type(self):
        r"""Gets the sim_type of this ShowSimCardResponse.

        sim卡类型 1.vSIM  2.eSIM  3.实体卡

        :return: The sim_type of this ShowSimCardResponse.
        :rtype: int
        """
        return self._sim_type

    @sim_type.setter
    def sim_type(self, sim_type):
        r"""Sets the sim_type of this ShowSimCardResponse.

        sim卡类型 1.vSIM  2.eSIM  3.实体卡

        :param sim_type: The sim_type of this ShowSimCardResponse.
        :type sim_type: int
        """
        self._sim_type = sim_type

    @property
    def tag_names(self):
        r"""Gets the tag_names of this ShowSimCardResponse.

        标签名

        :return: The tag_names of this ShowSimCardResponse.
        :rtype: str
        """
        return self._tag_names

    @tag_names.setter
    def tag_names(self, tag_names):
        r"""Sets the tag_names of this ShowSimCardResponse.

        标签名

        :param tag_names: The tag_names of this ShowSimCardResponse.
        :type tag_names: str
        """
        self._tag_names = tag_names

    @property
    def order_id(self):
        r"""Gets the order_id of this ShowSimCardResponse.

        批次号

        :return: The order_id of this ShowSimCardResponse.
        :rtype: int
        """
        return self._order_id

    @order_id.setter
    def order_id(self, order_id):
        r"""Sets the order_id of this ShowSimCardResponse.

        批次号

        :param order_id: The order_id of this ShowSimCardResponse.
        :type order_id: int
        """
        self._order_id = order_id

    @property
    def expire_time(self):
        r"""Gets the expire_time of this ShowSimCardResponse.

        到期时间 例如2021-06-30T00:00:00.000Z

        :return: The expire_time of this ShowSimCardResponse.
        :rtype: datetime
        """
        return self._expire_time

    @expire_time.setter
    def expire_time(self, expire_time):
        r"""Sets the expire_time of this ShowSimCardResponse.

        到期时间 例如2021-06-30T00:00:00.000Z

        :param expire_time: The expire_time of this ShowSimCardResponse.
        :type expire_time: datetime
        """
        self._expire_time = expire_time

    @property
    def price_plan_name(self):
        r"""Gets the price_plan_name of this ShowSimCardResponse.

        在用套餐名

        :return: The price_plan_name of this ShowSimCardResponse.
        :rtype: str
        """
        return self._price_plan_name

    @price_plan_name.setter
    def price_plan_name(self, price_plan_name):
        r"""Sets the price_plan_name of this ShowSimCardResponse.

        在用套餐名

        :param price_plan_name: The price_plan_name of this ShowSimCardResponse.
        :type price_plan_name: str
        """
        self._price_plan_name = price_plan_name

    @property
    def sim_price_plan_id(self):
        r"""Gets the sim_price_plan_id of this ShowSimCardResponse.

        套餐订购实例ID

        :return: The sim_price_plan_id of this ShowSimCardResponse.
        :rtype: int
        """
        return self._sim_price_plan_id

    @sim_price_plan_id.setter
    def sim_price_plan_id(self, sim_price_plan_id):
        r"""Sets the sim_price_plan_id of this ShowSimCardResponse.

        套餐订购实例ID

        :param sim_price_plan_id: The sim_price_plan_id of this ShowSimCardResponse.
        :type sim_price_plan_id: int
        """
        self._sim_price_plan_id = sim_price_plan_id

    @property
    def flow_left(self):
        r"""Gets the flow_left of this ShowSimCardResponse.

        剩余流量(单位M)，数据默认截止到昨日24点。

        :return: The flow_left of this ShowSimCardResponse.
        :rtype: float
        """
        return self._flow_left

    @flow_left.setter
    def flow_left(self, flow_left):
        r"""Sets the flow_left of this ShowSimCardResponse.

        剩余流量(单位M)，数据默认截止到昨日24点。

        :param flow_left: The flow_left of this ShowSimCardResponse.
        :type flow_left: float
        """
        self._flow_left = flow_left

    @property
    def flow_used(self):
        r"""Gets the flow_used of this ShowSimCardResponse.

        已用流量(单位M)，数据默认截止到昨日24点。

        :return: The flow_used of this ShowSimCardResponse.
        :rtype: float
        """
        return self._flow_used

    @flow_used.setter
    def flow_used(self, flow_used):
        r"""Sets the flow_used of this ShowSimCardResponse.

        已用流量(单位M)，数据默认截止到昨日24点。

        :param flow_used: The flow_used of this ShowSimCardResponse.
        :type flow_used: float
        """
        self._flow_used = flow_used

    @property
    def operator_status(self):
        r"""Gets the operator_status of this ShowSimCardResponse.

        运营商状态 -1.正常（非停机状态） 1.停机（超流量停机） 2.停机（超流量阈值停机） 3.停机（流量池停机） 4.停机（套餐到期停机） 5.停机（主动停机） 6.停机（违规停机） 7.停机（机卡分离停机）

        :return: The operator_status of this ShowSimCardResponse.
        :rtype: int
        """
        return self._operator_status

    @operator_status.setter
    def operator_status(self, operator_status):
        r"""Sets the operator_status of this ShowSimCardResponse.

        运营商状态 -1.正常（非停机状态） 1.停机（超流量停机） 2.停机（超流量阈值停机） 3.停机（流量池停机） 4.停机（套餐到期停机） 5.停机（主动停机） 6.停机（违规停机） 7.停机（机卡分离停机）

        :param operator_status: The operator_status of this ShowSimCardResponse.
        :type operator_status: int
        """
        self._operator_status = operator_status

    @property
    def msisdn(self):
        r"""Gets the msisdn of this ShowSimCardResponse.

        MSISDN

        :return: The msisdn of this ShowSimCardResponse.
        :rtype: str
        """
        return self._msisdn

    @msisdn.setter
    def msisdn(self, msisdn):
        r"""Sets the msisdn of this ShowSimCardResponse.

        MSISDN

        :param msisdn: The msisdn of this ShowSimCardResponse.
        :type msisdn: str
        """
        self._msisdn = msisdn

    @property
    def imsi(self):
        r"""Gets the imsi of this ShowSimCardResponse.

        IMSI

        :return: The imsi of this ShowSimCardResponse.
        :rtype: str
        """
        return self._imsi

    @imsi.setter
    def imsi(self, imsi):
        r"""Sets the imsi of this ShowSimCardResponse.

        IMSI

        :param imsi: The imsi of this ShowSimCardResponse.
        :type imsi: str
        """
        self._imsi = imsi

    @property
    def customer_attribute1(self):
        r"""Gets the customer_attribute1 of this ShowSimCardResponse.

        自定义属性一

        :return: The customer_attribute1 of this ShowSimCardResponse.
        :rtype: str
        """
        return self._customer_attribute1

    @customer_attribute1.setter
    def customer_attribute1(self, customer_attribute1):
        r"""Sets the customer_attribute1 of this ShowSimCardResponse.

        自定义属性一

        :param customer_attribute1: The customer_attribute1 of this ShowSimCardResponse.
        :type customer_attribute1: str
        """
        self._customer_attribute1 = customer_attribute1

    @property
    def customer_attribute2(self):
        r"""Gets the customer_attribute2 of this ShowSimCardResponse.

        自定义属性二

        :return: The customer_attribute2 of this ShowSimCardResponse.
        :rtype: str
        """
        return self._customer_attribute2

    @customer_attribute2.setter
    def customer_attribute2(self, customer_attribute2):
        r"""Sets the customer_attribute2 of this ShowSimCardResponse.

        自定义属性二

        :param customer_attribute2: The customer_attribute2 of this ShowSimCardResponse.
        :type customer_attribute2: str
        """
        self._customer_attribute2 = customer_attribute2

    @property
    def customer_attribute3(self):
        r"""Gets the customer_attribute3 of this ShowSimCardResponse.

        自定义属性三

        :return: The customer_attribute3 of this ShowSimCardResponse.
        :rtype: str
        """
        return self._customer_attribute3

    @customer_attribute3.setter
    def customer_attribute3(self, customer_attribute3):
        r"""Sets the customer_attribute3 of this ShowSimCardResponse.

        自定义属性三

        :param customer_attribute3: The customer_attribute3 of this ShowSimCardResponse.
        :type customer_attribute3: str
        """
        self._customer_attribute3 = customer_attribute3

    @property
    def customer_attribute4(self):
        r"""Gets the customer_attribute4 of this ShowSimCardResponse.

        自定义属性四

        :return: The customer_attribute4 of this ShowSimCardResponse.
        :rtype: str
        """
        return self._customer_attribute4

    @customer_attribute4.setter
    def customer_attribute4(self, customer_attribute4):
        r"""Sets the customer_attribute4 of this ShowSimCardResponse.

        自定义属性四

        :param customer_attribute4: The customer_attribute4 of this ShowSimCardResponse.
        :type customer_attribute4: str
        """
        self._customer_attribute4 = customer_attribute4

    @property
    def customer_attribute5(self):
        r"""Gets the customer_attribute5 of this ShowSimCardResponse.

        自定义属性五

        :return: The customer_attribute5 of this ShowSimCardResponse.
        :rtype: str
        """
        return self._customer_attribute5

    @customer_attribute5.setter
    def customer_attribute5(self, customer_attribute5):
        r"""Sets the customer_attribute5 of this ShowSimCardResponse.

        自定义属性五

        :param customer_attribute5: The customer_attribute5 of this ShowSimCardResponse.
        :type customer_attribute5: str
        """
        self._customer_attribute5 = customer_attribute5

    @property
    def customer_attribute6(self):
        r"""Gets the customer_attribute6 of this ShowSimCardResponse.

        自定义属性六

        :return: The customer_attribute6 of this ShowSimCardResponse.
        :rtype: str
        """
        return self._customer_attribute6

    @customer_attribute6.setter
    def customer_attribute6(self, customer_attribute6):
        r"""Sets the customer_attribute6 of this ShowSimCardResponse.

        自定义属性六

        :param customer_attribute6: The customer_attribute6 of this ShowSimCardResponse.
        :type customer_attribute6: str
        """
        self._customer_attribute6 = customer_attribute6

    @property
    def real_named(self):
        r"""Gets the real_named of this ShowSimCardResponse.

        是否已实名认证: true表示是，false表示否，系统SIM卡实名认证状态非实时。

        :return: The real_named of this ShowSimCardResponse.
        :rtype: bool
        """
        return self._real_named

    @real_named.setter
    def real_named(self, real_named):
        r"""Sets the real_named of this ShowSimCardResponse.

        是否已实名认证: true表示是，false表示否，系统SIM卡实名认证状态非实时。

        :param real_named: The real_named of this ShowSimCardResponse.
        :type real_named: bool
        """
        self._real_named = real_named

    @property
    def cut_net_flag(self):
        r"""Gets the cut_net_flag of this ShowSimCardResponse.

        是否单独断网 true:断网，false:未断网 （当前只支持联通、移动的组池卡，电信卡不限制）

        :return: The cut_net_flag of this ShowSimCardResponse.
        :rtype: bool
        """
        return self._cut_net_flag

    @cut_net_flag.setter
    def cut_net_flag(self, cut_net_flag):
        r"""Sets the cut_net_flag of this ShowSimCardResponse.

        是否单独断网 true:断网，false:未断网 （当前只支持联通、移动的组池卡，电信卡不限制）

        :param cut_net_flag: The cut_net_flag of this ShowSimCardResponse.
        :type cut_net_flag: bool
        """
        self._cut_net_flag = cut_net_flag

    @property
    def exceed_cut_net_flag(self):
        r"""Gets the exceed_cut_net_flag of this ShowSimCardResponse.

        是否达量断网 true:达量断网，false:未达量断网 （当前只支持联通、移动的组池卡，电信卡不限制）

        :return: The exceed_cut_net_flag of this ShowSimCardResponse.
        :rtype: bool
        """
        return self._exceed_cut_net_flag

    @exceed_cut_net_flag.setter
    def exceed_cut_net_flag(self, exceed_cut_net_flag):
        r"""Sets the exceed_cut_net_flag of this ShowSimCardResponse.

        是否达量断网 true:达量断网，false:未达量断网 （当前只支持联通、移动的组池卡，电信卡不限制）

        :param exceed_cut_net_flag: The exceed_cut_net_flag of this ShowSimCardResponse.
        :type exceed_cut_net_flag: bool
        """
        self._exceed_cut_net_flag = exceed_cut_net_flag

    @property
    def exceed_cut_net_quota(self):
        r"""Gets the exceed_cut_net_quota of this ShowSimCardResponse.

        达量断网阈值（单位MB 当前仅电信卡支持）

        :return: The exceed_cut_net_quota of this ShowSimCardResponse.
        :rtype: int
        """
        return self._exceed_cut_net_quota

    @exceed_cut_net_quota.setter
    def exceed_cut_net_quota(self, exceed_cut_net_quota):
        r"""Sets the exceed_cut_net_quota of this ShowSimCardResponse.

        达量断网阈值（单位MB 当前仅电信卡支持）

        :param exceed_cut_net_quota: The exceed_cut_net_quota of this ShowSimCardResponse.
        :type exceed_cut_net_quota: int
        """
        self._exceed_cut_net_quota = exceed_cut_net_quota

    @property
    def imei_bind_remain_times(self):
        r"""Gets the imei_bind_remain_times of this ShowSimCardResponse.

        本月机卡绑定剩余次数（当前仅电信卡支持）

        :return: The imei_bind_remain_times of this ShowSimCardResponse.
        :rtype: int
        """
        return self._imei_bind_remain_times

    @imei_bind_remain_times.setter
    def imei_bind_remain_times(self, imei_bind_remain_times):
        r"""Sets the imei_bind_remain_times of this ShowSimCardResponse.

        本月机卡绑定剩余次数（当前仅电信卡支持）

        :param imei_bind_remain_times: The imei_bind_remain_times of this ShowSimCardResponse.
        :type imei_bind_remain_times: int
        """
        self._imei_bind_remain_times = imei_bind_remain_times

    @property
    def speed_value(self):
        r"""Gets the speed_value of this ShowSimCardResponse.

        网络限制速率（单位Kbps,当前电信联通卡支持）

        :return: The speed_value of this ShowSimCardResponse.
        :rtype: int
        """
        return self._speed_value

    @speed_value.setter
    def speed_value(self, speed_value):
        r"""Sets the speed_value of this ShowSimCardResponse.

        网络限制速率（单位Kbps,当前电信联通卡支持）

        :param speed_value: The speed_value of this ShowSimCardResponse.
        :type speed_value: int
        """
        self._speed_value = speed_value

    def to_dict(self):
        import warnings
        warnings.warn("ShowSimCardResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowSimCardResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
