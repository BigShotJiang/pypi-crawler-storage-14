from .bedrock_sdk import patch_client as patch_client
