DROP TABLE IF EXISTS calls_complete;
DROP TABLE IF EXISTS calls_complete_stats;
DROP VIEW IF EXISTS calls_complete_stats_view;
