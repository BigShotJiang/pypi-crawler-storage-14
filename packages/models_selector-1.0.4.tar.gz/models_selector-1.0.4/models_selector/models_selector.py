# a module for sequential or random selection of models path, useful when multiple models exist simultaneously and must all be used separately
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
class ModelsSelector:
	def __init__(self, show_errors=True, display_error_point=False):
		try:
			self.__show_errors = bool(show_errors) if type(show_errors) in (bool, int, float) else True
			self.__display_error_point = bool(display_error_point) if type(display_error_point) in (bool, int, float) else False
			from traceback import print_exc
			self.__print_exc = print_exc
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in ModelsSelector.__init__: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def randomSelection(self, model_paths=[], id=0):
		try:
			model_path = ''
			if not model_paths: return model_path
			model_paths, id = list(model_paths) if type(model_paths) in (tuple, dict, list) else [str(model_paths).strip()], str(id).strip()
			if model_paths: model_path = str(model_paths[0]).strip()
			try:
				from utilities_nlp import UtilitiesNLP as SapiensUtilities
				from os.path import exists
				sapiens_utilities = SapiensUtilities(show_errors=self.__show_errors, display_error_point=self.__display_error_point)
				temporary_path = sapiens_utilities.getTemporaryFilesDirectory()
				file_path, index, max_index = f'{temporary_path}{id}.txt', 0, max(0, len(model_paths)-1)
				if not exists(file_path):
					with open(file_path, 'w', encoding='utf-8', errors='ignore') as file_handle: file_handle.write(str(index).strip())
				else:
					def _get_limited_index(index=0, default_list=[]): return min(max(0, len(default_list)-1), max(0, index))
					with open(file_path, 'r', encoding='utf-8', errors='ignore') as file_handle: index = _get_limited_index(index=int(float(str(file_handle.read()).strip())), default_list=model_paths)
					index += 1
					if index > max_index: index = 0
					model_path = str(model_paths[index]).strip()
					with open(file_path, 'w', encoding='utf-8', errors='ignore') as file_handle: file_handle.write(str(index).strip())
			except:
				from random import randint
				index = randint(0, max(0, len(model_paths)-1))
				model_path = str(model_paths[index]).strip()
			return model_path
		except Exception as error:
			if self.__show_errors:
				error_message = 'ERROR in ModelsSelector.randomSelection: '+str(error)
				print(error_message)
				try: self.__print_exc() if self.__display_error_point else None
				except: pass
			return ''
# a module for sequential or random selection of models path, useful when multiple models exist simultaneously and must all be used separately
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
