# a module for sequential or random selection of models path, useful when multiple models exist simultaneously and must all be used separately
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages

setup(
    name='models_selector',
    version='1.0.4',
    author='OPENSAPI',
    packages=find_packages(),
    install_requires=['utilities-nlp'],
    url='https://github.com/sapiens-technology/models_selector',
    license='Proprietary Software'
)
# a module for sequential or random selection of models path, useful when multiple models exist simultaneously and must all be used separately
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
