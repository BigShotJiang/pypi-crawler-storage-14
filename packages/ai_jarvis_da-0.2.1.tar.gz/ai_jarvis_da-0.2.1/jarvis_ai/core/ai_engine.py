import os
import requests
import json
import time
import logging
from typing import Optional, Dict, Any

# Импортируем наши модули
try:
    from .privacy_engine import PrivacyEngine
    from .knowledge_base import KnowledgeBase
except ImportError:
    # Fallback для случаев, когда модули ещё не созданы
    PrivacyEngine = type('PrivacyEngine', (), {})
    KnowledgeBase = type('KnowledgeBase', (), {})

logger = logging.getLogger(__name__)

class AIEngine:
    def __init__(self):
        self.huggingface_token = os.getenv("HUGGINGFACE_TOKEN")
        try:
            self.knowledge_base = KnowledgeBase()
            self.privacy_engine = PrivacyEngine()
        except:
            # Заглушки на случай ошибок инициализации
            self.knowledge_base = None
            self.privacy_engine = None
            
        self.rate_limit_delay = 1
        self.available_models = [
            "microsoft/DialoGPT-large",
            "google/flan-t5-large", 
            "facebook/blenderbot-400M-distill",
            "gpt2"
        ]
        self.current_model = self.available_models[0]
        
    def is_huggingface_available(self):
        """Проверка доступности Hugging Face"""
        return bool(self.huggingface_token)
    
    def process_query(self, user_query: str, context: Optional[Dict] = None) -> str:
        """Основная обработка запроса"""
        
        # Если Hugging Face не настроен, используем fallback
        if not self.is_huggingface_available():
            return "❌ Hugging Face не настроен. Установите HUGGINGFACE_TOKEN."
        
        try:
            # Упрощённая версия без приватности для теста
            return self._call_hugging_face_simple(user_query)
        except Exception as e:
            return f"❌ Ошибка обработки запроса: {str(e)}"
    
    def _call_hugging_face_simple(self, query: str) -> str:
        """Упрощённый запрос к Hugging Face"""
        if not self.huggingface_token:
            return "❌ Hugging Face недоступен"
        
        try:
            headers = {
                "Authorization": f"Bearer {self.huggingface_token}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "inputs": query,
                "parameters": {
                    "max_new_tokens": 200,
                    "temperature": 0.7,
                }
            }
            
            response = requests.post(
                f"https://api-inference.huggingface.co/models/{self.current_model}",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return self._extract_answer_simple(result)
            else:
                return f"❌ Ошибка API: {response.status_code}"
                
        except Exception as e:
            return f"❌ Ошибка подключения: {str(e)}"
    
    def _extract_answer_simple(self, hf_response: Any) -> str:
        """Простое извлечение ответа"""
        try:
            if isinstance(hf_response, list) and hf_response:
                if 'generated_text' in hf_response[0]:
                    return hf_response[0]['generated_text']
                elif 'text' in hf_response[0]:
                    return hf_response[0]['text']
            return str(hf_response)[:500]  # Ограничиваем длину
        except:
            return "❌ Не удалось обработать ответ"
    
def test_connection(self) -> Dict[str, Any]:
    """Тестирование подключения к Hugging Face"""
    if not self.huggingface_token:
        return {
            "status": "error",
            "message": "HUGGINGFACE_TOKEN не установлен"
        }
    
    try:
        headers = {"Authorization": f"Bearer {self.huggingface_token}"}
        response = requests.get(
            "https://huggingface.co/api/whoami-v2",
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            user_info = response.json()
            return {
                "status": "success",
                "message": "Hugging Face доступен",
                "user": user_info.get('name', 'Unknown'),
                "can_load_models": user_info.get('canLoadModels', False)
            }
        else:
            # Пробуем другую модель
            self.switch_model("google/flan-t5-large")
            return {
                "status": "warning",
                "message": f"Hugging Face доступен, но некоторые модели могут не работать (код: {response.status_code})"
            }
            
    except Exception as e:
        return {
            "status": "error",
            "message": f"Ошибка подключения: {str(e)}"
        }

# Глобальный экземпляр
ai_engine = AIEngine()