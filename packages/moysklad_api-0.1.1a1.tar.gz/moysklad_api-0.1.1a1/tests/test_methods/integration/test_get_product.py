import pytest

from moysklad_api import MsAPI
from moysklad_api.types import Product
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetProduct:
    """
    Example with options: --product-id=1234-5678 --expand=supplier
    """

    async def test_method(
        self, real_client: MsAPI, product_id: str | None, expand: str | None
    ):
        product = await real_client.get_product(product_id=product_id, expand=expand)
        assert isinstance(product, Product)
        assert product.id == product_id
        assert product.name is not None

        if expand:
            assert_expand(expand, product)
