import pytest

from moysklad_api import MsAPI
from moysklad_api.types import Demand
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetDemand:
    """
    Example with options: --demand-id=1234-5678
    """

    async def test_method(
        self, real_client: MsAPI, demand_id: str | None, expand: str | None
    ):
        print(f"expand: {expand}")
        demand = await real_client.get_demand(demand_id=demand_id, expand=expand)
        assert isinstance(demand, Demand)
        assert demand.id == demand_id
        assert demand.name is not None

        if expand:
            assert_expand(expand, demand)
