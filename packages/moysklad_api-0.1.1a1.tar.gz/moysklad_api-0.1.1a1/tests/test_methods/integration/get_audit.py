import pytest

from moysklad_api import MsAPI
from moysklad_api.types import Audit


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetAudit:
    """
    Example with options: --audit-id=1234-5678
    """

    async def test_method(
        self,
        real_client: MsAPI,
        audit_id: str | None,
    ):
        audit = await real_client.get_audit(audit_id=audit_id)
        assert isinstance(audit, Audit)
