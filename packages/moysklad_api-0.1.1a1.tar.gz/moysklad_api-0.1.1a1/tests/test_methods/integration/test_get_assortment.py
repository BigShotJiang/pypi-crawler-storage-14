import pytest

from moysklad_api import MsAPI
from moysklad_api.types import Assortment, MetaArray
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetAssortment:
    """
    Example with options: --assortment-id=1234-5678-919dj-5252363
    """

    async def test_method(self, real_client: MsAPI, default_params: dict):
        expand = default_params.get("expand", None)
        assortment = await real_client.get_assortment(**default_params)
        assert isinstance(assortment, MetaArray)
        assert all(isinstance(p, Assortment) for p in assortment.rows)

        if expand:
            assert_expand(expand, assortment)
