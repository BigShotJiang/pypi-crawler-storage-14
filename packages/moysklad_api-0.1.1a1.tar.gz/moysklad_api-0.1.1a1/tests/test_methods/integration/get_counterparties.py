import pytest

from moysklad_api import MsAPI
from moysklad_api.types import Counterparty, MetaArray
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetCounterparties:
    async def test_method(
        self, real_client: MsAPI, counterparty_id: str | None, expand: str | None
    ):
        print(expand)
        counterparties = await real_client.get_counterparties(expand=expand, limit=10)
        assert isinstance(counterparties, MetaArray)
        assert all(isinstance(c, Counterparty) for c in counterparties.rows)

        if expand:
            assert_expand(expand, counterparties)
