import pytest

from moysklad_api import MsAPI
from moysklad_api.types import ProductUpdate


@pytest.mark.asyncio
@pytest.mark.integration
class TestUpdateProducts:
    """
    Example with options: --products
        '[
            {"id": "123", "name": "New Name"},
            {"id": "456", "description": "New Desc"}
        ]'
    """

    async def test_method(self, real_client: MsAPI, products: list[ProductUpdate]):
        result = await real_client.update_products(products=products)

        assert isinstance(result, list)
        assert len(result) == len(products)

        for i in range(len(products)):
            original_product = products[i]
            updated_product = result[i]

            expected_fields = original_product.model_dump(
                exclude_none=True, exclude={"id"}
            )

            for field, expected in expected_fields.items():
                actual = getattr(updated_product, field)
                assert actual == expected
