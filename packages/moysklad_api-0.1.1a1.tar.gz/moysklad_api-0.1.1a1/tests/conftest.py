import os

import pytest
import pytest_asyncio
from dotenv import load_dotenv

from moysklad_api import MsAPI
from moysklad_api.types import ProductUpdate
from tests.mocked_client import MockedClient


@pytest_asyncio.fixture
async def client() -> MockedClient:
    c = MockedClient(token="mocked_token")
    yield c
    await c.close()


def pytest_addoption(parser):
    parser.addoption(
        "--expand", action="store", default=None, help="Expand related entities"
    )
    parser.addoption("--filters", action="store", default=None, help="Filters")
    parser.addoption("--limit", action="store", default=None, help="Limit")
    parser.addoption("--offset", action="store", default=None, help="Offset")
    parser.addoption("--search", action="store", default=None, help="Search")
    parser.addoption("--order", action="store", default=None, help="Order")
    parser.addoption("--product-id", action="store", default=None, help="Product Id")
    parser.addoption("--demand-id", action="store", default=None, help="Demand Id")
    parser.addoption(
        "--assortment-id", action="store", default=None, help="Assortment Id"
    )
    parser.addoption("--audit-id", action="store", default=None, help="Audit Id")
    parser.addoption(
        "--counterparty-id", action="store", default=None, help="Counterparty Id"
    )
    parser.addoption("--report-type", action="store", default=None, help="Report type")

    parser.addoption(
        "--products",
        action="store",
        default=None,
        help="JSON string with list of products to update",
    )
    parser.addoption(
        "--update-fields",
        action="store",
        default=None,
        help="JSON string with fields to update",
    )


@pytest.fixture
def product_id(request):
    return request.config.getoption("--product-id")


@pytest.fixture
def audit_id(request):
    return request.config.getoption("--audit-id")


@pytest.fixture
def demand_id(request):
    return request.config.getoption("--demand-id")


@pytest.fixture
def assortment_id(request):
    return request.config.getoption("--assortment-id")


@pytest.fixture
def counterparty_id(request):
    return request.config.getoption("--counterparty-id")


@pytest.fixture
def report_type(request):
    return request.config.getoption("--report-type")


@pytest.fixture
def products(request):
    import json

    products_json = request.config.getoption("--products")
    if products_json:
        products_data = json.loads(products_json)
        return [ProductUpdate(**product_data) for product_data in products_data]
    return []


@pytest.fixture
def expand(request):
    return request.config.getoption("--expand")


@pytest.fixture
def default_params(request):
    kwargs = {}
    if request.config.getoption("--limit"):
        kwargs["limit"] = int(request.config.getoption("--limit"))
    if request.config.getoption("--offset"):
        kwargs["offset"] = int(request.config.getoption("--offset"))
    if request.config.getoption("--expand"):
        kwargs["expand"] = request.config.getoption("--expand")
    if request.config.getoption("--search"):
        kwargs["search"] = request.config.getoption("--search")
    if request.config.getoption("--order"):
        kwargs["order"] = request.config.getoption("--order")
    return kwargs


@pytest.fixture
def update_fields(request):
    import json

    fields = request.config.getoption("--update-fields")
    if fields:
        return json.loads(fields)
    return {}


@pytest.fixture
def real_client() -> MsAPI:
    load_dotenv()
    token = os.getenv("TOKEN")
    return MsAPI(token=token)
