from ._logger import Logger, Level

logger = Logger()

__version__ = "2.0.3"
