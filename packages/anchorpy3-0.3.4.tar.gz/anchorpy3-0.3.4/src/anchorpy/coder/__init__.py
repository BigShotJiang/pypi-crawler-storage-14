"""This subpackage defines the Coder class."""
