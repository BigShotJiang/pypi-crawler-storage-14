from __future__ import annotations

U8Array = list[int]
