# Worlds

> Gymnasium-like environments for web worlds

## Coming Soon

Worlds is a Python library that provides Gymnasium-compatible environments for training AI agents on web-based tasks. Think of it as OpenAI Gym/Gymnasium, but for simulated web applications and APIs.

### Vision

- **Simulated Web Environments**: Interact with web application clones (Gmail, social media, e-commerce, etc.)
- **Dual Interface**: Both visual UI and programmatic API access to environment data
- **Multimodal Observations**: Support for screenshots, DOM/HTML, and accessibility tree representations
- **Flexible Action Spaces**: High-level semantic actions and low-level input simulation
- **Gymnasium Compatible**: Full compatibility with the Gymnasium API for seamless integration with RL frameworks

## Installation

```bash
pip install worlds
```

## Quick Start

```python
import worlds

# More coming soon!
```

## Status

This package is currently in early development. Stay tuned for updates!

## License

MIT
