import webview
webview.create_window("docs", "https://pywebview.flowrl.com")
print("starting")
webview.start()

