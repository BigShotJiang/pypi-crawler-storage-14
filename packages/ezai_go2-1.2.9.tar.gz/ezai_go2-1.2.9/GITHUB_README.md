# EZAI-Go2 - 简单易用的AI机器人控制库

[![PyPI version](https://badge.fury.io/py/ezai-go2.svg)](https://badge.fury.io/py/ezai-go2)
[![Python versions](https://img.shields.io/pypi/pyversions/ezai-go2.svg)](https://pypi.org/project/ezai-go2/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

EZAI-Go2 是一个专为 Go2 机器狗和 AI 应用设计的简化 Python 接口库，让机器人控制和计算机视觉变得简单易用。

## 🚀 快速安装

```bash
pip install ezai-go2
```

## 📖 主要功能

- **🤖 Go2 机器狗控制**: 完整的运动控制、状态查询、视频流支持
- **📷 计算机视觉**: 集成 OpenCV，支持图像处理和显示
- **🧠 AI 工作流**: 支持 ONNX 和 RKNN 模型推理
- **🔧 模块化设计**: 支持按需导入，减少依赖冲突
- **🎓 教育友好**: 适合初学者和 STEM 教育

## 🛠️ 开发者指南

### 项目结构
```
go2dog/
├── ezai/                    # 核心库代码
├── examples/               # 示例代码
├── tests/                  # 测试代码
├── DEVELOPMENT.md          # 详细开发指南
├── setup.py                # 打包配置
├── pyproject.toml          # 项目配置
└── upload.py               # 发布脚本
```

### 快速开始

1. **克隆项目**：
```bash
git clone https://github.com/nmww/go2dog.git
cd go2dog
```

2. **安装开发依赖**：
```bash
pip install -e .
pip install ezai-go2[dev]
```

3. **配置 PyPI 认证**（发布时需要）：
   - 在用户主目录创建 `.pypirc` 文件
   - 添加 PyPI API token（详见 [DEVELOPMENT.md](DEVELOPMENT.md)）
   - ⚠️ **重要**: `.pypirc` 文件绝对不能提交到 Git！

4. **版本发布**：
```bash
# 补丁版本
python quick_update.py patch

# 次版本
python quick_update.py minor

# 主版本
python quick_update.py major
```

### 基本使用示例

```python
from ezai import Go2, Camera, OpenCVUI

# Go2 机器狗控制
dog = Go2()
if dog.connect():
    dog.move(0.5, 0, 0)  # 前进
    time.sleep(2)
    dog.move(0, 0, 0)    # 停止
    dog.disconnect()

# 摄像头和 UI
camera = Camera()
ui = OpenCVUI()
image = camera.capture()
if image:
    ui.show_image("Camera", image)
    ui.waitKey(0)
```

## 📚 文档

- **[DEVELOPMENT.md](DEVELOPMENT.md)** - 详细开发指南
- **[README.md](README.md)** - PyPI 展示文档
- **[examples/](examples/)** - 示例代码

## 🤝 贡献

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 创建 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

## 📞 联系方式

- 邮箱: macnote@qq.com
- PyPI: https://pypi.org/project/ezai-go2/
- GitHub: https://github.com/nmww/go2dog

---

⚠️ **开发者注意**: 
- 请勿将 `.pypirc` 文件提交到版本控制
- 发布前请阅读 [DEVELOPMENT.md](DEVELOPMENT.md) 了解详细流程