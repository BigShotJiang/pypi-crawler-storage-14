# EZAI-Go2 发布检查清单

## 🔍 发布前检查

### 代码质量
- [ ] 代码格式化 (`black ezai/ tests/`)
- [ ] 代码检查 (`flake8 ezai/ tests/`)
- [ ] 单元测试通过 (`python -m pytest tests/`)
- [ ] 示例代码可正常运行

### 版本管理
- [ ] 版本号已更新 (setup.py, pyproject.toml, ezai/__init__.py)
- [ ] CHANGELOG.md 已更新
- [ ] README.md 内容正确
- [ ] DEVELOPMENT.md 内容最新

### 依赖检查
- [ ] requirements.txt 版本约束正确
- [ ] pyproject.toml 依赖配置正确
- [ ] 无依赖冲突（特别是 numpy, typing-extensions）

### 安全检查
- [ ] `.pypirc` 在 .gitignore 中
- [ ] 无硬编码的敏感信息
- [ ] API token 未提交到代码库

## 🚀 发布流程

### 1. 准备工作
```bash
# 确保在主分支
git checkout main
git pull origin main

# 确保工作目录干净
git status
```

### 2. 版本更新
```bash
# 使用自动化工具
python quick_update.py patch  # 或 minor/major

# 或手动更新（不推荐）
# 编辑 setup.py, pyproject.toml, ezai/__init__.py
```

### 3. 构建和测试
```bash
# 清理旧版本
python -m build --clean

# 构建新版本
python -m build

# 检查包
twine check dist/*

# 本地测试安装
pip install dist/ezai_go2-*.whl
python -c "import ezai; print(ezai.__version__)"
```

### 4. 发布到 PyPI
```bash
# 上传到测试 PyPI（可选）
twine upload --repository testpypi --config-file .pypirc dist/*

# 测试安装
pip install --index-url https://test.pypi.org/simple/ ezai-go2

# 上传到正式 PyPI
twine upload --config-file .pypirc dist/*
```

### 5. 验证发布
```bash
# 验证安装
pip install ezai-go2==新版本号
python -c "import ezai; print(ezai.__version__)"

# 测试基本功能
python examples/go2_video_stream.py
```

### 6. Git 操作
```bash
# 添加标签
git tag -a v1.0.8 -m "Release version 1.0.8"

# 推送标签
git push origin v1.0.8

# 推送主分支
git push origin main
```

## 📋 发布后检查

### PyPI 验证
- [ ] PyPI 页面显示正确
- [ ] 版本号正确
- [ ] 文档显示正常
- [ ] 下载链接有效

### GitHub 更新
- [ ] Release 创建
- [ ] 标签推送成功
- [ ] 文档链接正确

### 社区通知
- [ ] 更新 CHANGELOG
- [ ] 发送发布通知（如需要）
- [ ] 更新相关文档

## 🚨 常见问题

### 构建失败
```bash
# 清理缓存
python -m build --clean
pip cache purge

# 检查依赖
pip install --upgrade build setuptools wheel
```

### 上传失败
```bash
# 检查 .pypirc 配置
twine check dist/*

# 检查 API token
twine upload --repository testpypi --config-file .pypirc dist/*
```

### 版本冲突
```bash
# 检查现有版本
pip index versions ezai-go2

# 确保版本号递增
# 语义化版本: MAJOR.MINOR.PATCH
```

## 📞 紧急回滚

如果发布出现问题：

1. **从 PyPI 删除版本**（仅限发布后 72 小时内）
2. **发布修复版本**
3. **通知用户**

```bash
# 紧急修复版本
python quick_update.py patch
# 修复问题后重新发布
```

---

⚠️ **重要提醒**: 
- 发布前务必仔细检查
- 确认 .pypirc 配置正确
- 遵循语义化版本规范
- 保持发布记录完整