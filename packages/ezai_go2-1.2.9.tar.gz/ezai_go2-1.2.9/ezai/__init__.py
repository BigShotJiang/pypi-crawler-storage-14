"""
EZAI - 简单易用的AI机器人控制库

专为Go2机器狗和AI应用设计的简化接口
"""

__version__ = "1.2.9"
__author__ = "EZAI Team"
__email__ = "contact@ezai.com"
__description__ = "Easy AI Robot Control Library for Go2 and Computer Vision"

# 导入核心类
try:
    from .go2 import Go2, error_code
    GO2_AVAILABLE = True
except ImportError:
    Go2 = None
    error_code = {}
    GO2_AVAILABLE = False

from .camera import Camera
from .ui import OpenCVUI

# 导入工作流类
try:
    from .onnxWorkflow import Workflow as ONNXWorkflow
    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False

try:
    from .rknnWorkflow import Workflow as RKNNWorkflow
    RKNN_AVAILABLE = True
except ImportError:
    RKNN_AVAILABLE = False

# 导出主要接口
__all__ = [
    "Camera", 
    "OpenCVUI",
]

# 条件导出
if GO2_AVAILABLE:
    __all__.append("Go2")
    __all__.append("error_code")

if ONNX_AVAILABLE:
    __all__.append("ONNXWorkflow")

if RKNN_AVAILABLE:
    __all__.append("RKNNWorkflow")

# 版本和可用性信息
def get_version():
    """获取版本信息"""
    return __version__

def get_available_modules():
    """获取可用模块信息"""
    return {
        "go2": GO2_AVAILABLE,
        "camera": True,
        "ui": True,
        "onnx": ONNX_AVAILABLE,
        "rknn": RKNN_AVAILABLE
    }

def print_info():
    """打印库信息"""
    print(f"EZAI v{__version__}")
    modules = get_available_modules()
    print("可用模块:")
    for module, available in modules.items():
        status = "✅" if available else "❌"
        print(f"  {status} {module}")