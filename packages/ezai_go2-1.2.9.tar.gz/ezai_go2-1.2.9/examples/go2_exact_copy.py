#!/usr/bin/env python3
"""
完全复制pipstream.py的逻辑，只是用EZAI初始化
"""

import os
import sys
import time
import cv2
import numpy as np

# 设置显示环境（与pipstream.py完全一致）
os.environ["DISPLAY"] = ":0"

def test_exact_copy():
    """完全复制pipstream.py的逻辑"""
    print("=== 完全复制pipstream.py逻辑 ===")
    
    # 使用EZAI初始化（这是唯一的不同）
    try:
        sys.path.insert(0, '..')
        import ezai.go2 as go2
        
        print("使用EZAI初始化Go2...")
        robot = go2.Go2()
        robot.init()
        print(f"检测到接口: {robot.interface}")
        
    except Exception as e:
        print(f"EZAI初始化失败: {e}")
        print("回退到硬编码接口...")
        # 如果EZAI失败，使用硬编码接口
        pass
    
    # 以下完全复制pipstream.py的逻辑
    pipe_path = "/tmp/exact_copy_pipe"
    
    # 清理旧管道
    if os.path.exists(pipe_path):
        os.remove(pipe_path)
    
    # 创建管道
    os.mkfifo(pipe_path)
    print("命名管道已创建")
    
    # 启动GStreamer（完全复制pipstream.py的命令）
    gst_cmd = (
        "exec gst-launch-1.0 udpsrc address=230.1.1.1 port=1720 multicast-iface=enx00e0986113a6 "
        "! application/x-rtp, media=video, encoding-name=H264 ! rtph264depay ! h264parse "
        "! avdec_h264 ! videoconvert ! video/x-raw,format=BGR,width=1280,height=720 "
        "! filesink location=" + pipe_path + " > /dev/null 2>&1 &"
    )
    
    print("启动GStreamer...")
    os.system(gst_cmd)
    
    # 等待启动
    time.sleep(3)
    
    try:
        print("开始读取视频...")
        width, height = 1280, 720
        frame_size = width * height * 3
        
        with open(pipe_path, 'rb') as pipe:
            frame_count = 0
            while True:
                # 读取一帧（完全复制pipstream.py）
                frame_data = pipe.read(frame_size)
                
                if len(frame_data) == frame_size:
                    # 转换为图像并显示（完全复制pipstream.py）
                    frame = np.frombuffer(frame_data, dtype=np.uint8).reshape((height, width, 3))
                    cv2.imshow('Video', frame)  # 窗口名与pipstream.py一致
                    frame_count += 1
                    
                    if frame_count % 30 == 0:
                        print(f"显示第 {frame_count} 帧")
                
                # 检查退出（完全复制pipstream.py）
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                    
    except Exception as e:
        print(f"错误: {e}")
    finally:
        # 清理（完全复制pipstream.py）
        os.system("pkill -f gst-launch")
        if os.path.exists(pipe_path):
            os.remove(pipe_path)
        cv2.destroyAllWindows()
        print("程序结束")

if __name__ == "__main__":
    test_exact_copy()