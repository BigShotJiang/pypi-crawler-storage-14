# Listening Machine
A Machine that listens.
<pre>
  pip install listening-machine
</pre>
Then:
```Python
  # Python
  import listening_machine
```
