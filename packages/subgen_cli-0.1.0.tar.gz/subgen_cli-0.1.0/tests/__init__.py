"""Tests for subgen-cli"""
