# SudoDog Shadow Agent Scanner

Detect unmonitored AI agents running on your machine.

## Installation

```bash
pip install sudodog-scanner
```

Or install from source:

```bash
cd cli
pip install -e .
```

## Usage

### Scan and print results

```bash
sudodog-scan
```

### Report to SudoDog Dashboard

```bash
sudodog-scan --report YOUR_API_KEY
```

## What it detects

- Python processes running LangChain, AutoGen, CrewAI, LlamaIndex
- Node.js processes using LangChain.js, Flowise
- Java processes using Spring AI, LangChain4j
- .NET processes using Semantic Kernel
- Network connections to OpenAI, Anthropic, and other AI APIs
