"""
Real Shadow Agent Scanner

Scans running processes on the local machine to detect AI agents
that are not being monitored by SudoDog.
"""

import os
import sys
import json
import subprocess
import re
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class DetectedAgent:
    """Represents a detected shadow agent."""
    pid: int
    process_name: str
    command_line: str
    suspected_framework: str
    confidence: float
    indicators: List[str]
    working_directory: Optional[str] = None
    user: Optional[str] = None
    cpu_percent: Optional[float] = None
    memory_mb: Optional[float] = None
    start_time: Optional[str] = None


# Detection patterns for various AI agent frameworks
FRAMEWORK_PATTERNS = {
    "langchain": {
        "imports": [
            r"langchain",
            r"from langchain",
            r"import langchain",
            r"LangChain",
        ],
        "env_vars": ["LANGCHAIN_API_KEY", "LANGCHAIN_TRACING"],
        "packages": ["langchain", "langchain-core", "langchain-community"],
    },
    "autogen": {
        "imports": [
            r"autogen",
            r"from autogen",
            r"import autogen",
            r"autogen_studio",
        ],
        "env_vars": ["AUTOGEN_"],
        "packages": ["pyautogen", "autogen"],
    },
    "crewai": {
        "imports": [
            r"crewai",
            r"from crewai",
            r"CrewAI",
        ],
        "env_vars": [],
        "packages": ["crewai"],
    },
    "openai-agents": {
        "imports": [
            r"openai\.beta\.assistants",
            r"client\.beta\.assistants",
            r"AssistantEventHandler",
        ],
        "env_vars": ["OPENAI_API_KEY"],
        "packages": ["openai"],
    },
    "anthropic-agents": {
        "imports": [
            r"anthropic",
            r"from anthropic",
            r"Claude",
        ],
        "env_vars": ["ANTHROPIC_API_KEY"],
        "packages": ["anthropic"],
    },
    "semantic-kernel": {
        "imports": [
            r"semantic_kernel",
            r"from semantic_kernel",
        ],
        "env_vars": [],
        "packages": ["semantic-kernel"],
    },
    "llama-index": {
        "imports": [
            r"llama_index",
            r"from llama_index",
            r"LlamaIndex",
        ],
        "env_vars": [],
        "packages": ["llama-index"],
    },
    "haystack": {
        "imports": [
            r"haystack",
            r"from haystack",
        ],
        "env_vars": [],
        "packages": ["farm-haystack", "haystack-ai"],
    },
    "flowise": {
        "imports": [
            r"flowise",
        ],
        "env_vars": ["FLOWISE_"],
        "packages": [],
    },
}

# Command line patterns that suggest AI agent activity
AGENT_CMD_PATTERNS = [
    (r"agent", 0.3),
    (r"assistant", 0.3),
    (r"bot", 0.2),
    (r"llm", 0.3),
    (r"gpt", 0.3),
    (r"chat", 0.2),
    (r"langchain", 0.5),
    (r"autogen", 0.5),
    (r"crewai", 0.5),
    (r"openai", 0.4),
    (r"anthropic", 0.4),
    (r"claude", 0.4),
    (r"embedding", 0.3),
    (r"vector", 0.2),
    (r"rag", 0.3),
    (r"retrieval", 0.2),
]


def get_running_processes() -> List[Dict[str, Any]]:
    """Get list of running processes with their details."""
    processes = []

    if sys.platform == "darwin":  # macOS
        try:
            # Use ps command on macOS
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True,
                text=True
            )
            lines = result.stdout.strip().split('\n')[1:]  # Skip header

            for line in lines:
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    processes.append({
                        "user": parts[0],
                        "pid": int(parts[1]),
                        "cpu": float(parts[2]),
                        "mem": float(parts[3]),
                        "command": parts[10],
                    })
        except Exception as e:
            print(f"Error getting processes on macOS: {e}")

    elif sys.platform == "linux":
        try:
            # Read from /proc on Linux
            for pid_dir in os.listdir('/proc'):
                if pid_dir.isdigit():
                    try:
                        pid = int(pid_dir)

                        # Read command line
                        with open(f'/proc/{pid}/cmdline', 'r') as f:
                            cmdline = f.read().replace('\x00', ' ').strip()

                        if not cmdline:
                            continue

                        # Read process name
                        with open(f'/proc/{pid}/comm', 'r') as f:
                            comm = f.read().strip()

                        # Read status for user info
                        user = "unknown"
                        try:
                            import pwd
                            stat = os.stat(f'/proc/{pid}')
                            user = pwd.getpwuid(stat.st_uid).pw_name
                        except:
                            pass

                        processes.append({
                            "user": user,
                            "pid": pid,
                            "cpu": 0.0,
                            "mem": 0.0,
                            "command": cmdline,
                            "name": comm,
                        })
                    except (FileNotFoundError, PermissionError):
                        continue
        except Exception as e:
            print(f"Error getting processes on Linux: {e}")

    elif sys.platform == "win32":
        try:
            # Try PowerShell first (more reliable on modern Windows)
            result = subprocess.run(
                ["powershell", "-Command",
                 "Get-Process | Select-Object Id,ProcessName,Path,CommandLine | ConvertTo-Json"],
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode == 0 and result.stdout.strip():
                import json
                try:
                    proc_list = json.loads(result.stdout)
                    if isinstance(proc_list, dict):
                        proc_list = [proc_list]

                    for p in proc_list:
                        pid = p.get("Id", 0)
                        name = p.get("ProcessName", "")
                        cmdline = p.get("CommandLine") or p.get("Path") or name

                        if pid and name:
                            processes.append({
                                "user": "unknown",
                                "pid": pid,
                                "cpu": 0.0,
                                "mem": 0.0,
                                "command": cmdline,
                                "name": name.lower(),
                            })
                except json.JSONDecodeError:
                    pass

            # Fallback to WMIC if PowerShell didn't work
            if not processes:
                result = subprocess.run(
                    ["wmic", "process", "get", "ProcessId,Name,CommandLine", "/format:csv"],
                    capture_output=True,
                    text=True
                )
                lines = result.stdout.strip().split('\n')[2:]  # Skip headers

                for line in lines:
                    parts = line.strip().split(',')
                    if len(parts) >= 4:
                        processes.append({
                            "user": "unknown",
                            "pid": int(parts[2]) if parts[2].isdigit() else 0,
                            "cpu": 0.0,
                            "mem": 0.0,
                            "command": parts[1],
                            "name": parts[3].lower() if parts[3] else "",
                        })
        except Exception as e:
            print(f"Error getting processes on Windows: {e}")

    return processes


def check_network_connections(pid: int) -> List[str]:
    """Check network connections for a process to detect API calls."""
    connections = []

    # Known AI API endpoints to look for
    ai_endpoints = [
        "api.openai.com",
        "api.anthropic.com",
        "api.cohere.com",
        "generativelanguage.googleapis.com",
        "api.together.xyz",
        "api.replicate.com",
        "api.mistral.ai",
    ]

    try:
        if sys.platform in ["darwin", "linux"]:
            result = subprocess.run(
                ["lsof", "-i", "-n", "-P", "-p", str(pid)],
                capture_output=True,
                text=True
            )

            for line in result.stdout.split('\n'):
                if any(api in line.lower() for api in ai_endpoints):
                    connections.append(line.strip())

        elif sys.platform == "win32":
            # Use netstat on Windows and correlate with process
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True,
                text=True
            )

            # Find connections belonging to this PID
            for line in result.stdout.split('\n'):
                if str(pid) in line:
                    connections.append(line.strip())

            # Also try PowerShell for more detailed info
            try:
                ps_result = subprocess.run(
                    ["powershell", "-Command",
                     f"Get-NetTCPConnection -OwningProcess {pid} -ErrorAction SilentlyContinue | "
                     "Select-Object RemoteAddress,RemotePort | ConvertTo-Json"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if ps_result.stdout:
                    import json
                    try:
                        conn_data = json.loads(ps_result.stdout)
                        if isinstance(conn_data, dict):
                            conn_data = [conn_data]
                        for conn in conn_data:
                            addr = conn.get("RemoteAddress", "")
                            if any(api in addr for api in ai_endpoints):
                                connections.append(f"{addr}:{conn.get('RemotePort', '')}")
                    except json.JSONDecodeError:
                        pass
            except Exception:
                pass

    except Exception:
        pass

    return connections


def analyze_process(proc: Dict[str, Any]) -> Optional[DetectedAgent]:
    """Analyze a process to determine if it's an AI agent."""
    command = proc.get("command", "").lower()
    name = proc.get("name", proc.get("command", "").split()[0] if proc.get("command") else "").lower()

    # Skip system processes and common non-agent processes
    skip_patterns = [
        "kernel", "systemd", "init", "kworker", "ksoftirq",
        "chrome", "firefox", "safari", "code", "vscode",
        "terminal", "bash", "zsh", "fish", "sh",
        "finder", "dock", "windowserver",
        "launchd", "cfprefsd", "distnoted",
    ]

    if any(skip in name for skip in skip_patterns):
        return None

    # Only look at Python, Node, Java, and .NET processes
    is_runtime = any(runtime in name for runtime in [
        "python", "node", "java", "dotnet", "ruby", "go"
    ])

    if not is_runtime:
        return None

    indicators = []
    confidence = 0.0
    detected_framework = "unknown"

    # Check command line patterns
    for pattern, weight in AGENT_CMD_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            indicators.append(f"Command contains '{pattern}'")
            confidence += weight

    # Check for framework-specific patterns
    for framework, patterns in FRAMEWORK_PATTERNS.items():
        for import_pattern in patterns["imports"]:
            if re.search(import_pattern, command, re.IGNORECASE):
                indicators.append(f"{framework} import detected")
                confidence += 0.4
                detected_framework = framework
                break

    # Check environment variables (if accessible)
    try:
        environ = ""
        if sys.platform == "linux":
            with open(f'/proc/{proc["pid"]}/environ', 'r') as f:
                environ = f.read()
        elif sys.platform == "win32":
            # Use WMI to get environment variables on Windows
            try:
                result = subprocess.run(
                    ["powershell", "-Command",
                     f"(Get-Process -Id {proc['pid']} -ErrorAction SilentlyContinue).StartInfo.EnvironmentVariables | "
                     "ForEach-Object {{ $_.Key + '=' + $_.Value }}"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                environ = result.stdout
            except Exception:
                # Fallback: check common AI env vars in current process (less accurate but useful)
                for framework, patterns in FRAMEWORK_PATTERNS.items():
                    for env_var in patterns["env_vars"]:
                        if env_var in os.environ or any(env_var in k for k in os.environ.keys()):
                            # Can't confirm it's for this specific process, so lower confidence
                            indicators.append(f"AI environment variable {env_var} found in system")
                            confidence += 0.1

        if environ:
            for framework, patterns in FRAMEWORK_PATTERNS.items():
                for env_var in patterns["env_vars"]:
                    if env_var in environ:
                        indicators.append(f"Environment variable {env_var} found")
                        confidence += 0.3
                        if detected_framework == "unknown":
                            detected_framework = framework
    except:
        pass

    # Check network connections for API calls
    connections = check_network_connections(proc["pid"])
    if connections:
        indicators.append(f"Active AI API connections detected ({len(connections)})")
        confidence += 0.4

    # Only report if we have reasonable confidence
    if confidence < 0.3 or not indicators:
        return None

    # Cap confidence at 0.95
    confidence = min(0.95, confidence)

    # Determine process name
    process_name = name
    if "python" in name:
        process_name = "python"
    elif "node" in name:
        process_name = "node"
    elif "java" in name:
        process_name = "java"
    elif "dotnet" in name:
        process_name = "dotnet"

    return DetectedAgent(
        pid=proc["pid"],
        process_name=process_name,
        command_line=proc.get("command", "")[:500],  # Truncate long commands
        suspected_framework=detected_framework,
        confidence=round(confidence, 2),
        indicators=indicators,
        user=proc.get("user"),
        cpu_percent=proc.get("cpu"),
        memory_mb=proc.get("mem"),
    )


def scan_for_shadow_agents() -> List[DetectedAgent]:
    """Scan the system for shadow (unmonitored) AI agents."""
    print("Scanning running processes...")

    processes = get_running_processes()
    print(f"Found {len(processes)} running processes")

    detected_agents = []

    for proc in processes:
        agent = analyze_process(proc)
        if agent:
            detected_agents.append(agent)

    return detected_agents


def format_report(agents: List[DetectedAgent]) -> str:
    """Format the scan results as a human-readable report."""
    if not agents:
        return "No shadow agents detected."

    report = f"\n{'='*60}\n"
    report += f"SHADOW AGENT SCAN REPORT\n"
    report += f"Scan Time: {datetime.now().isoformat()}\n"
    report += f"Detected Agents: {len(agents)}\n"
    report += f"{'='*60}\n\n"

    for i, agent in enumerate(agents, 1):
        report += f"[{i}] PID: {agent.pid}\n"
        report += f"    Process: {agent.process_name}\n"
        report += f"    Framework: {agent.suspected_framework}\n"
        report += f"    Confidence: {agent.confidence * 100:.0f}%\n"
        report += f"    Command: {agent.command_line[:80]}{'...' if len(agent.command_line) > 80 else ''}\n"
        report += f"    Indicators:\n"
        for indicator in agent.indicators:
            report += f"      - {indicator}\n"
        report += "\n"

    return report


def export_json(agents: List[DetectedAgent]) -> str:
    """Export scan results as JSON."""
    return json.dumps({
        "scan_time": datetime.now().isoformat(),
        "agent_count": len(agents),
        "agents": [asdict(a) for a in agents],
    }, indent=2)


if __name__ == "__main__":
    agents = scan_for_shadow_agents()
    print(format_report(agents))
