"""
SudoDog Shadow Agent Scanner

A real process scanner that detects unmonitored AI agents running on your machine.
"""

__version__ = "0.1.0"
