#!/usr/bin/env python3
"""
SudoDog Shadow Agent Scanner CLI

Usage:
    sudodog-scan                    # Scan and print results
    sudodog-scan --json             # Output as JSON
    sudodog-scan --report API_KEY   # Scan and report to SudoDog API
"""

import argparse
import json
import sys
from typing import Optional
from dataclasses import asdict

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from .scanner import scan_for_shadow_agents, format_report, export_json, DetectedAgent


DEFAULT_API_URL = "https://api.sudodog.com/api/v1"


def report_to_api(agents: list[DetectedAgent], api_key: str, api_url: str) -> bool:
    """Report discovered agents to SudoDog API."""
    if not HAS_REQUESTS:
        print("Error: 'requests' library required for API reporting.")
        print("Install with: pip install requests")
        return False

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    payload = {
        "agents": [asdict(a) for a in agents],
        "scan_source": "cli_scanner",
    }

    try:
        response = requests.post(
            f"{api_url}/microsoft365/shadow-agents/report",
            headers=headers,
            json=payload,
            timeout=30,
        )

        if response.status_code == 200:
            result = response.json()
            print(f"Successfully reported {len(agents)} agents to SudoDog")
            print(f"New agents: {result.get('new_count', 0)}")
            print(f"Updated agents: {result.get('updated_count', 0)}")
            return True
        else:
            print(f"Error reporting to API: {response.status_code}")
            print(response.text)
            return False

    except requests.exceptions.RequestException as e:
        print(f"Error connecting to API: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="SudoDog Shadow Agent Scanner - Detect unmonitored AI agents"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON",
    )
    parser.add_argument(
        "--report",
        metavar="API_KEY",
        help="Report results to SudoDog API using the provided API key",
    )
    parser.add_argument(
        "--api-url",
        default=DEFAULT_API_URL,
        help=f"SudoDog API URL (default: {DEFAULT_API_URL})",
    )
    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Suppress output (only report to API)",
    )

    args = parser.parse_args()

    # Run scan
    agents = scan_for_shadow_agents()

    # Output results
    if not args.quiet:
        if args.json:
            print(export_json(agents))
        else:
            print(format_report(agents))

    # Report to API if requested
    if args.report:
        success = report_to_api(agents, args.report, args.api_url)
        sys.exit(0 if success else 1)

    sys.exit(0)


if __name__ == "__main__":
    main()
