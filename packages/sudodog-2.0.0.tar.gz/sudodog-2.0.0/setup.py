from setuptools import setup, find_packages

setup(
    name="sudodog-scanner",
    version="0.1.0",
    description="SudoDog Shadow Agent Scanner - Detect unmonitored AI agents",
    author="SudoDog",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
    ],
    entry_points={
        "console_scripts": [
            "sudodog-scan=sudodog_scanner.cli:main",
        ],
    },
    python_requires=">=3.8",
)
