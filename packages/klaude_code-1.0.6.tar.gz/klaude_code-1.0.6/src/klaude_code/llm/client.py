from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from typing import cast

from klaude_code.protocol.llm_parameter import LLMCallParameter, LLMConfigParameter
from klaude_code.protocol.model import ConversationItem


class LLMClientABC(ABC):
    def __init__(self, config: LLMConfigParameter) -> None:
        self._config = config

    @classmethod
    @abstractmethod
    def create(cls, config: LLMConfigParameter) -> "LLMClientABC":
        pass

    @abstractmethod
    async def call(self, param: LLMCallParameter) -> AsyncGenerator[ConversationItem, None]:
        raise NotImplementedError
        yield cast(ConversationItem, None)  # pyright: ignore[reportUnreachable]

    def get_llm_config(self) -> LLMConfigParameter:
        return self._config

    @property
    def model_name(self) -> str:
        return self._config.model or ""
