from __future__ import annotations

from collections.abc import Awaitable, Callable
from contextvars import ContextVar

from klaude_code.core.sub_agent import SubAgentResult
from klaude_code.protocol.model import SubAgentState
from klaude_code.session.session import Session

# Holds the current Session for tool execution context.
# Set by Agent/Reminder right before invoking a tool.
current_session_var: ContextVar[Session | None] = ContextVar("current_session", default=None)


# Holds a handle to run a nested subtask (sub-agent) from within a tool call.
# The callable takes a prompt string and a sub-agent type string
# returns the final task_result string and session_id str.
current_run_subtask_callback: ContextVar[Callable[[SubAgentState], Awaitable[SubAgentResult]] | None] = ContextVar(
    "current_run_subtask_callback", default=None
)
