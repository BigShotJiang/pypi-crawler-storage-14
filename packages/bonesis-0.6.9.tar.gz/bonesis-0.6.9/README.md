# BoNesis - Boolean Network synthesis

Synthesis of Most Permissive Boolean Networks from network architecture and dynamical properties

This software is distributed under the [CeCILL v2.1](http://www.cecill.info/index.en.html) free software license (GNU GPL compatible).

For installation instructions and usage, see [documentation](https://bnediction.github.io/bonesis).
