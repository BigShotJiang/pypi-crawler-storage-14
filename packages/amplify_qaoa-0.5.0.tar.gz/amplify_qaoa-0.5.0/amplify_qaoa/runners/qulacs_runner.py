from __future__ import annotations

import dataclasses
import time
from collections import Counter
from datetime import timedelta
from typing import TYPE_CHECKING

from qulacs import Observable, PauliOperator, QuantumCircuit, QuantumState
from typing_extensions import override

from .._utility import SolType, decode_solutions
from ._core import AbstractQAOARunner
from ._timing import TimingBase

if TYPE_CHECKING:
    from collections.abc import Iterable


@dataclasses.dataclass
class QulacsTiming(TimingBase): ...


class QulacsRunner(AbstractQAOARunner[QuantumCircuit, Observable, QulacsTiming]):
    def __init__(self, reps: int = 10, shots: int | None = None) -> None:
        super().__init__(reps, shots)

    @staticmethod
    def construct_quantum_circuit(wires: int) -> QuantumCircuit:
        return QuantumCircuit(wires)

    @staticmethod
    def construct_observable(wires: int) -> Observable:
        return Observable(wires)

    @staticmethod
    def add_pauli_x(op_f: Observable, _wires: int, i: int, value: float) -> Observable:
        pauli_str = f"X {i}"
        op_f.add_operator(PauliOperator(pauli_str, value))
        return op_f

    @staticmethod
    def add_h_gate(circuit: QuantumCircuit, i: int) -> QuantumCircuit:
        circuit.add_H_gate(i)
        return circuit

    @staticmethod
    def add_cnot_gate(circuit: QuantumCircuit, i: int, j: int) -> QuantumCircuit:
        circuit.add_CNOT_gate(i, j)
        return circuit

    @staticmethod
    def add_x_gate(circuit: QuantumCircuit, i: int) -> QuantumCircuit:
        circuit.add_X_gate(i)
        return circuit

    @staticmethod
    def add_z_gates(op_f: Observable, _wires: int, li: Iterable[int], value: float) -> Observable:
        pauli_str = ""
        for i in li:
            if pauli_str != "":
                pauli_str += " "
            pauli_str += f"Z {i}"

        op_f.add_operator(PauliOperator(pauli_str, value))
        return op_f

    @staticmethod
    def add_rx_gate(circuit: QuantumCircuit, i: int, value: float, wires: int) -> QuantumCircuit:
        op_x = Observable(wires)
        pauli_str = f"X {i}"
        op_x.add_operator(PauliOperator(pauli_str, 1.0))
        circuit.add_observable_rotation_gate(op_x, value, 1)
        return circuit

    @staticmethod
    def add_ry_gate(circuit: QuantumCircuit, i: int, value: float) -> QuantumCircuit:
        circuit.add_RY_gate(i, value)
        return circuit

    @staticmethod
    def add_observable_rotation_gate(
        circuit: QuantumCircuit, op_f: Observable, value: float, _wires: int
    ) -> QuantumCircuit:
        circuit.add_observable_rotation_gate(op_f, value, 1)
        return circuit

    @override
    def init_runner(self, wires: int) -> None:
        return super().init_runner(wires)  # type: ignore[safe-super]

    @override
    def observe(self, qc: QuantumCircuit) -> tuple[SolType, QulacsTiming]:
        init_time_cf = time.perf_counter()

        wires = qc.get_qubit_count()
        state = QuantumState(wires)
        qc.update_quantum_state(state)

        tune_qulacs_time = timedelta(seconds=time.perf_counter() - init_time_cf)

        samples = Counter(state.sampling(self.shots if self.shots is not None else 1024))
        z_basis = [format(i, "b").zfill(wires) for i in range(2**wires)]
        counts = {z_basis[i]: samples[i] for i in range(2**wires) if i in samples}

        return decode_solutions(counts), QulacsTiming(total_machine_time=tune_qulacs_time, total_execution_time=None)
