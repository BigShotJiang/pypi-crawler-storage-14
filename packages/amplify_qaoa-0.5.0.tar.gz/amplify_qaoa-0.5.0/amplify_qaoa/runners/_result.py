from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import TYPE_CHECKING, Generic

from amplify_qaoa.runners._timing import TimingType

if TYPE_CHECKING:
    from .._utility import SolType
    from ._timing import MeasureTiming, TuneTiming


@dataclass
class OptimizeHistory(Generic[TimingType]):
    parameters: list[float]
    timestamp: TimingType
    objective: float
    counts: list[tuple[list[int], int]]


@dataclasses.dataclass
class TuneResult(Generic[TimingType]):
    tune_timing: TuneTiming[TimingType]
    evals: int
    opt_val: list[float]
    opt_params: list[float]
    group_list: list[list[int]]
    init_ones: list[int]
    params_history: list[OptimizeHistory[TimingType]]


@dataclasses.dataclass
class MeasureResult(Generic[TimingType]):
    counts: SolType
    measure_timing: MeasureTiming[TimingType]


@dataclasses.dataclass(init=False)
class RunResult(Generic[TimingType]):
    # TuneResult
    tune_timing: TuneTiming[TimingType] | None
    evals: int | None
    opt_val: list[float] | None
    opt_params: list[float] | None
    group_list: list[list[int]] | None
    init_ones: list[int] | None
    params_history: list[OptimizeHistory[TimingType]] | None

    # MeasureResult
    counts: SolType
    measure_timing: MeasureTiming[TimingType]

    def __init__(
        self, measure_result: MeasureResult[TimingType], tune_result: TuneResult[TimingType] | None = None
    ) -> None:
        for key, value in measure_result.__dict__.items():
            setattr(self, key, value)

        if tune_result is not None:
            for key, value in tune_result.__dict__.items():
                setattr(self, key, value)
        else:
            self.tune_timing = None
            self.evals = None
            self.opt_val = None
            self.opt_params = None
            self.group_list = None
            self.init_ones = None
            self.params_history = None
