from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Generic, TypeVar

from typing_extensions import Self

if TYPE_CHECKING:
    from datetime import timedelta


@dataclasses.dataclass
class TimingBase:
    total_execution_time: timedelta | None
    total_machine_time: timedelta

    def __iadd__(self, other: Self) -> Self:
        if type(self) is not type(other):
            raise TypeError(f"Cannot add {type(self)} and {type(other)}")

        for field in dataclasses.fields(self):
            if field.name == "total_execution_time" and getattr(self, field.name) is None:
                setattr(self, field.name, getattr(other, field.name))
                continue

            setattr(self, field.name, getattr(self, field.name) + getattr(other, field.name))

        return self


TimingType = TypeVar("TimingType", bound=TimingBase)


@dataclasses.dataclass
class TuneTiming(Generic[TimingType]):
    total_time: timedelta
    minimize_time: timedelta
    classical_opt_time: timedelta
    runner_timing: TimingType


@dataclasses.dataclass
class MeasureTiming(Generic[TimingType]):
    total_time: timedelta
    runner_timing: TimingType
