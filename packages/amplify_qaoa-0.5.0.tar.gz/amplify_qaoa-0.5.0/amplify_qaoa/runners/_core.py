from __future__ import annotations

import random
import time
from abc import ABC, abstractmethod
from collections.abc import Iterable
from copy import deepcopy
from datetime import timedelta
from typing import Generic, TypeGuard

from scipy.optimize import minimize

from amplify_qaoa.runners._result import OptimizeHistory

from .._qaoa_circuits import QaoaAnsatzType, construct_qaoa_circuit
from .._qaoa_circuits._type_utility import CircType, ObsType, SupportsAnsatz, SupportsCAnsatz
from .._utility import IsingDict, SolType, compute_function_value, count_qubits, reduce_degree
from ._result import MeasureResult, RunResult, TuneResult
from ._timing import MeasureTiming, TimingType, TuneTiming


def _initialize_parameters_randomly(wires: int, group_list: list[list[int]], reps: int) -> list[float]:
    # Prepare parameters
    if group_list == []:
        k = 2 * reps
    else:
        k = 0
        not_grouped = set(range(wires))
        for group in group_list:
            m = len(group)
            k += m // 2 + (m - 1) // 2
            not_grouped -= set(group)
        k *= reps
        k += len(not_grouped)

    return [random.random() for _ in range(k)]  # noqa: S311


def select_qaoa_type(group_list: list[list[int]] | None) -> QaoaAnsatzType:
    if group_list is None:
        return QaoaAnsatzType.Original
    return QaoaAnsatzType.Constrained if len(group_list) > 0 else QaoaAnsatzType.Original


class AbstractQAOARunner(ABC, Generic[CircType, ObsType, TimingType]):
    _shots: int | None
    reps: int

    _f_dict: IsingDict | None
    _qaoa_type: QaoaAnsatzType
    _opt_params: list[float] | None
    _group_list: list[list[int]] | None
    _init_ones: list[int] | None

    _url: str | None
    _proxy: str | None

    @property
    def shots(self) -> int | None:
        return self._shots

    @shots.setter
    def shots(self, value: int | None) -> None:
        self._shots = value

    @property
    def proxy(self) -> str | None:
        return self._proxy

    @proxy.setter
    def proxy(self, value: str | None) -> None:
        self._proxy = value

    @property
    def url(self) -> str | None:
        return self._url

    @url.setter
    def url(self, value: str | None) -> None:
        self._url = value

    @property
    def opt_params(self) -> list[float] | None:
        return self._opt_params

    @property
    def qaoa_type(self) -> QaoaAnsatzType:
        return self._qaoa_type

    def __init__(
        self,
        reps: int = 10,
        shots: int | None = None,
        url: str | None = None,
        proxy: str | None = None,
    ) -> None:
        super().__init__()
        self.reps = reps
        self.shots = shots
        self.url = url
        self.proxy = proxy

        self._f_dict = None
        self._qaoa_type = QaoaAnsatzType.Auto
        self._opt_params = None
        self._group_list = None
        self._init_ones = None

    @abstractmethod
    def init_runner(self, wires: int) -> None:
        pass

    @abstractmethod
    def observe(self, qc: CircType) -> tuple[SolType, TimingType]:
        pass

    @staticmethod
    def _typeguard_self(x: object) -> TypeGuard[SupportsAnsatz[CircType, ObsType] | SupportsCAnsatz[CircType]]:
        return isinstance(x, (SupportsAnsatz, SupportsCAnsatz))

    def tune(
        self,
        f_dict: IsingDict,
        optimizer: str = "COBYLA",
        group_list: list[list[int]] | None = None,
        init_ones: list[int] | None = None,
        initial_parameters: list[float] | None = None,
        qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto,
    ) -> TuneResult[TimingType]:
        self_ = self
        if not self._typeguard_self(self_):
            raise TypeError("Protocol check failed.")

        if group_list is None:
            group_list = []
        if init_ones is None:
            init_ones = []

        init_tune_total_time = time.perf_counter()

        reduced_f_dict = reduce_degree(f_dict)
        wires = count_qubits(reduced_f_dict, group_list)

        self.init_runner(wires)

        # Create init_one list
        if group_list != [] and init_ones == []:
            for group in group_list:
                init_ones += random.sample(group, 1)

        # Create initial parameters
        if initial_parameters is None:
            initial_parameters = _initialize_parameters_randomly(wires, group_list, self.reps)

        parameter_values_history: list[OptimizeHistory[TimingType]] = []

        summed_timing: TimingType | None = None

        if qaoa_type == QaoaAnsatzType.Auto:
            qaoa_type = select_qaoa_type(group_list)

        def _cost_function(params_val: list[float]) -> float:
            qc = construct_qaoa_circuit(
                self_, reduced_f_dict, wires, qaoa_type, params_val, self.reps, group_list, init_ones
            )

            counts, timing = self.observe(qc)

            func_val = compute_function_value(reduced_f_dict, counts)

            # Store the total execution time
            # self.observe(qc) returns timing.total_execution_time = None
            timing.total_execution_time = timedelta(seconds=time.perf_counter() - init_tune_total_time)

            nonlocal summed_timing
            if summed_timing is None:
                summed_timing = deepcopy(timing)
            else:
                summed_timing.total_execution_time = timedelta(0.0)
                summed_timing += timing

            parameter_values_history.append(
                OptimizeHistory(parameters=params_val, timestamp=timing, objective=func_val, counts=counts)
            )

            return func_val

        # Time count for minimize
        init_tune_minimize_time = time.perf_counter()
        res = minimize(_cost_function, initial_parameters, method=optimizer)
        tune_minimize_time = time.perf_counter() - init_tune_minimize_time

        self._f_dict = reduced_f_dict
        self._qaoa_type = qaoa_type
        resx = res["x"]
        self._opt_params = list(resx) if isinstance(resx, Iterable) else [resx]
        self._group_list = group_list
        self._init_ones = init_ones

        assert summed_timing is not None

        timing = TuneTiming(
            total_time=timedelta(seconds=time.perf_counter() - init_tune_total_time),
            minimize_time=timedelta(seconds=tune_minimize_time),
            classical_opt_time=timedelta(seconds=tune_minimize_time) - summed_timing.total_machine_time,
            runner_timing=summed_timing,
        )
        resfun = res["fun"]
        return TuneResult(
            evals=res["nfev"],
            tune_timing=timing,
            opt_val=list(resfun) if isinstance(resfun, Iterable) else [resfun],
            opt_params=self._opt_params,
            group_list=group_list,
            init_ones=init_ones,
            params_history=parameter_values_history,
        )

    def measure(
        self,
        f_dict: IsingDict,
        parameters: list[float],
        group_list: list[list[int]] | None = None,
        init_ones: list[int] | None = None,
        qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto,
    ) -> MeasureResult[TimingType]:
        self_ = self
        if not self._typeguard_self(self_):
            raise TypeError("Protocol check failed.")

        if group_list is None:
            group_list = []
        if init_ones is None:
            init_ones = []

        # Time count for tune function
        init_meas_total_time = time.perf_counter()

        wires = count_qubits(f_dict, group_list)

        self.init_runner(wires)

        if qaoa_type == QaoaAnsatzType.Auto:
            qaoa_type = select_qaoa_type(group_list)

        qc = construct_qaoa_circuit(self_, f_dict, wires, qaoa_type, parameters, self.reps, group_list, init_ones)

        counts, runner_timing = self.observe(qc)

        meas_total_time = timedelta(seconds=time.perf_counter() - init_meas_total_time)

        runner_timing.total_execution_time = meas_total_time

        meas_time_taken = MeasureTiming(total_time=meas_total_time, runner_timing=runner_timing)

        return MeasureResult(counts, meas_time_taken)

    def run(
        self,
        f_dict: IsingDict | None = None,
        parameters: list[float] | None = None,
        group_list: list[list[int]] | None = None,
        init_ones: list[int] | None = None,
        qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto,
    ) -> RunResult[TimingType]:
        tune_result = None

        if f_dict is not None:
            f_dict = reduce_degree(f_dict)
            if group_list is None:
                group_list = []
            if init_ones is None:
                init_ones = []
            if qaoa_type == QaoaAnsatzType.Auto:
                qaoa_type = select_qaoa_type(group_list)
            if parameters is None:
                tune_result = self.tune(
                    f_dict=f_dict, optimizer="COBYLA", group_list=group_list, init_ones=init_ones, qaoa_type=qaoa_type
                )
                parameters = tune_result.opt_params
        elif self._f_dict is not None:
            f_dict = self._f_dict
            qaoa_type = self._qaoa_type
            parameters = self._opt_params
            group_list = self._group_list
            init_ones = self._init_ones
        else:
            raise RuntimeError("Problem was not specified.")

        if parameters is None:
            raise RuntimeError("parameters was not specified.")
        if group_list is None:
            raise RuntimeError("group_list was not specified.")
        if init_ones is None:
            raise RuntimeError("init_ones was not specified.")

        measure_result = self.measure(f_dict, parameters, group_list, init_ones, qaoa_type)

        return RunResult(measure_result, tune_result)
