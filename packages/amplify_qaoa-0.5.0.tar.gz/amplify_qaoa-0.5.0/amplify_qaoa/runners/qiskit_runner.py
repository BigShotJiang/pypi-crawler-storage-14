from __future__ import annotations

import dataclasses
import logging
import time
from collections.abc import Iterable
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, TypeGuard, get_args
from urllib.parse import urlparse

from qiskit import QuantumCircuit
from qiskit.circuit.library import HamiltonianGate
from qiskit.primitives import PrimitiveJob
from qiskit.providers import Backend
from qiskit.quantum_info import Operator, Pauli
from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
from qiskit_aer import AerSimulator
from qiskit_ibm_runtime import IBMBackend, QiskitRuntimeService
from qiskit_ibm_runtime import RuntimeJobV2 as RuntimeJob
from qiskit_ibm_runtime import SamplerV2 as Sampler
from qiskit_ibm_runtime.accounts import ChannelType
from qiskit_ibm_runtime.fake_provider import FakeProviderForBackendV2 as FakeProvider
from typing_extensions import override

from .._utility import SolType, decode_solutions
from ._core import AbstractQAOARunner
from ._timing import TimingBase

if TYPE_CHECKING:
    from collections.abc import Iterable


@dataclasses.dataclass
class QiskitTiming(TimingBase):
    qiskit_running_time: timedelta
    machine_running_time: timedelta


logger = logging.getLogger(__name__)


def _get_time_from_result(result_date: str | datetime) -> datetime:
    if type(result_date) is datetime:
        return result_date
    if isinstance(result_date, str):
        try:
            timestamp = datetime.strptime(result_date, "%Y-%m-%dT%H:%M:%S.%f").astimezone()
        except ValueError:
            timestamp = datetime.strptime(result_date, "%Y-%m-%dT%H:%M:%S").astimezone()

        return timestamp
    raise RuntimeError(f"{result_date} is not supported datetime format")


Channels = get_args(get_args(ChannelType)[0])  # Parse ChannelType = Literal[...] | None
OptimizationType = [0, 1, 2, 3]
DeviceType = ["CPU", "GPU", "QPU"]


class QiskitRunner(AbstractQAOARunner[QuantumCircuit, Operator, QiskitTiming]):
    __token: str | None = None
    __provider: QiskitRuntimeService | None = None
    __channel: str = "ibm_quantum_platform"
    __optimization_level: int = 1
    __device: str = "CPU"
    __backend_name: str | None = None
    __backend: AerSimulator | IBMBackend | None = None
    __verify: bool | None = None

    @property
    def provider(self) -> QiskitRuntimeService | None:
        return self.__provider

    @property
    def channel(self) -> str:
        return self.__channel

    @channel.setter
    def channel(self, value: str) -> None:
        if value not in Channels:
            raise RuntimeError(f"Specified channel type is not supported. Supported channels are: {Channels}")

        if self.__channel != value:
            # Reset backend
            self.__backend = None

        self.__channel = value

    @property
    def optimization_level(self) -> int:
        return self.__optimization_level

    @optimization_level.setter
    def optimization_level(self, value: int) -> None:
        if value not in OptimizationType:
            raise RuntimeError("Specified optimization level is not supported.")

        self.__optimization_level = value

    @property
    def device(self) -> str:
        return self.__device

    @device.setter
    def device(self, value: str) -> None:
        if value not in DeviceType:
            raise RuntimeError("Specified device type is not supported.")

        if self.__device != value:
            # Reset backend
            self.__backend = None

        self.__device = value

    @property
    def token(self) -> str | None:
        return self.__token

    @token.setter
    def token(self, value: str | None) -> None:
        if self.__token == value:
            return

        # Token has changed
        self.__token = value
        self.__backend = None  # Reset backend

        if value is None:
            self.__provider = None
            return

        if self.proxy is not None:
            proxies = {"urls": {urlparse(self.url).scheme: self.proxy}}
            self.__provider = QiskitRuntimeService(
                token=value, channel=self.channel, url=self.url, proxies=proxies, verify=self.__verify
            )
        else:
            self.__provider = QiskitRuntimeService(
                token=value, channel=self.channel, url=self.url, verify=self.__verify
            )

    @AbstractQAOARunner.shots.setter  # type: ignore[attr-defined]
    def shots(self, value: int) -> None:
        if self.__backend is not None and self._shots != value:
            self.__backend.set_options(shots=value)

        self._shots = value

    @property
    def backend_name(self) -> str | None:
        return self.__backend_name

    @backend_name.setter
    def backend_name(self, value: str | None) -> None:
        if self.__backend_name != value:
            # Reset backend
            self.__backend = None

        self.__backend_name = value

    @property
    def backend(self) -> AerSimulator | IBMBackend | None:
        return self.__backend

    def __init__(
        self,
        reps: int = 10,
        shots: int | None = 1024,
        backend_name: str | None = None,
        channel: str = "ibm_quantum_platform",
        optimization_level: int = 1,
        device: str = "CPU",
        token: str | None = None,
        proxy: str | None = None,
        verify: bool | None = None,
    ) -> None:
        super().__init__(reps, shots, proxy=proxy, url="https://cloud.ibm.com")

        if channel not in Channels:
            raise RuntimeError("Specified channel type is not supported.")

        if optimization_level not in OptimizationType:
            raise RuntimeError("Specified optimization level is not supported.")

        if device not in DeviceType:
            raise RuntimeError("Specified device type is not supported.")

        self.backend_name = backend_name
        self.channel = channel
        self.optimization_level = optimization_level
        self.device = device
        self.token = token
        self.__verify = verify

    @staticmethod
    def construct_quantum_circuit(wires: int) -> QuantumCircuit:
        return QuantumCircuit(wires)

    @staticmethod
    def construct_observable(wires: int) -> Operator:
        return 0 * Operator(Pauli("I" * wires))

    @staticmethod
    def add_pauli_x(op_f: Operator, wires: int, i: int, value: float) -> Operator:
        op_f += value * Operator(Pauli("I" * (wires - i - 1) + "X" + "I" * i))
        return op_f

    @staticmethod
    def add_h_gate(circuit: QuantumCircuit, i: int) -> QuantumCircuit:
        circuit.h(i)
        return circuit

    @staticmethod
    def add_cnot_gate(circuit: QuantumCircuit, i: int, j: int) -> QuantumCircuit:
        circuit.cx(i, j)
        return circuit

    @staticmethod
    def add_x_gate(circuit: QuantumCircuit, i: int) -> QuantumCircuit:
        circuit.x(i)
        return circuit

    @staticmethod
    def add_z_gates(op_f: Operator, wires: int, li: Iterable[int], value: float) -> Operator:
        pauli_list = ["I"] * wires
        for i in li:
            pauli_list[i] = "Z"

        op_f += value * Operator(Pauli(str.join("", pauli_list)))
        return op_f

    @staticmethod
    def add_rx_gate(circuit: QuantumCircuit, i: int, value: float, _wires: int) -> QuantumCircuit:
        circuit.rx(value, i)
        return circuit

    @staticmethod
    def add_ry_gate(circuit: QuantumCircuit, i: int, value: float) -> QuantumCircuit:
        circuit.ry(value, i)
        return circuit

    @staticmethod
    def add_observable_rotation_gate(
        circuit: QuantumCircuit, op_f: Operator, value: float, wires: int
    ) -> QuantumCircuit:
        circuit.append(HamiltonianGate(op_f, value), list(reversed(range(wires))))
        return circuit

    @staticmethod
    def _typeguard_backends(x: object) -> TypeGuard[list[Backend]]:
        return isinstance(x, list) and all(isinstance(xi, Backend) for xi in x)

    @override
    def init_runner(self, wires: int) -> None:
        # If backend is None, must load backend.
        # If wires is larger than the number of qubits of the current backend,
        # the backend can't be applied to the problem.
        # If token is available or backend is not specified, must update the least busy backend.
        # Otherwise, the current backend is also available to the Ising model.
        if (
            self.__backend is not None
            and wires <= self.__backend.num_qubits
            and (self.__token is None or self.__backend_name is not None)
        ):
            return

        if self.__device in ["CPU", "GPU"]:
            if self.__backend_name is not None:
                available_methods = AerSimulator().available_methods()
                if available_methods is not None and self.__backend_name in available_methods:
                    # Simulation of ideal machine with specified method
                    self.__backend = AerSimulator(method=self.backend_name)
                elif self.__provider is not None:
                    # Simulation of actual machine with specified backend
                    self.__backend = AerSimulator.from_backend(self.provider.backend(name=self.__backend_name))
                else:
                    # Simulation of ideal machine with specified backend
                    # If the prefix of backend_name is not "fake", replace the name of the machiene by "fake_machine".
                    if self.backend_name[:4] == "fake":
                        fake_name = self.backend_name
                    else:
                        hyphen_index = self.backend_name.rfind("_")
                        if hyphen_index == -1:
                            if self.backend_name == "ibmqx2":
                                fake_name = "fake_yorktown"
                            elif self.backend_name == "ibmqx4":
                                fake_name = "fake_tenerife"
                            else:
                                raise RuntimeError("Specified backend name is not supported.")
                        else:
                            fake_name = "fake" + self.backend_name[hyphen_index:]
                        logger.warning(
                            f"You chose an option to perform simulations with a fake backend. In this case, the backend name must start with 'fake_'. The provided backend name '{self.backend_name}' was automatically changed to '{fake_name}' to comply with this rule."  # noqa: E501, G004
                        )
                    self.__backend = FakeProvider().backend(fake_name)
            elif self.provider is not None:
                # Simulation of actual machine with least busy backend
                least_busy_backend = self.provider.least_busy(min_num_qubits=wires, simulator=False)
                if least_busy_backend is not None:
                    self.__backend = AerSimulator.from_backend(least_busy_backend)
                else:
                    raise RuntimeError("Available backend is not found.")
            else:
                # Simulation of ideal machine with default simulator
                self.__backend = AerSimulator(method="automatic", device=self.device)
        elif self.device == "QPU":
            if self.provider is not None:
                if self.backend_name is not None:
                    # Run an actual machine with specified backend
                    self.__backend = self.__provider.backend(self.__backend_name)
                else:
                    # Run an actual machine with least busy backend
                    least_busy_backend = self.provider.least_busy(min_num_qubits=wires, simulator=False)
                    if least_busy_backend is not None:
                        self.__backend = least_busy_backend
                    else:
                        raise RuntimeError("Available backend is not found.")
            else:
                raise RuntimeError('Specified device is "QPU", but a token is not set.')
        else:
            raise NotImplementedError("Invalid device is specified.")

        if self.__device in ["CPU", "GPU"]:
            self.__backend.set_options(device=self.device)  # type: ignore

    @override
    def observe(self, qc: QuantumCircuit) -> tuple[SolType, QiskitTiming]:
        init_time_cf = time.perf_counter()
        qc.measure_all()
        pm = generate_preset_pass_manager(backend=self.backend, optimization_level=self.optimization_level)
        isa_qc = pm.run(qc)
        sampler = Sampler(self.backend)

        init_tune_total_machine_time = datetime.now().astimezone()
        assert self.backend is not None
        job = sampler.run([isa_qc], shots=self.shots)
        counts_encoded = job.result()[0].data.meas.get_counts()
        assert isinstance(counts_encoded, dict)
        end_tune_total_machine_time = datetime.now().astimezone()
        counts = decode_solutions(counts_encoded)

        tune_total_machine_time = (end_tune_total_machine_time - init_tune_total_machine_time).total_seconds()
        assert isinstance(tune_total_machine_time, float), "tune_total_machine_time must be float"

        if hasattr(job, "metrics") and callable(job.metrics):
            assert isinstance(job, (RuntimeJob, PrimitiveJob))
            metrics = job.metrics()
            timestamps = metrics["timestamps"]
            time_created = timestamps["created"]
            assert isinstance(time_created, (datetime, str))
            time_running = timestamps["running"]
            assert isinstance(time_running, (datetime, str))
            time_finished = timestamps["finished"]
            assert isinstance(time_finished, (datetime, str))
            tune_total_machine_time = (
                _get_time_from_result(time_finished) - _get_time_from_result(time_created)
            ).total_seconds()
            assert isinstance(tune_total_machine_time, float), "tune_total_machine_time must be float"
            machine_running_time = (
                _get_time_from_result(time_finished) - _get_time_from_result(time_running)
            ).total_seconds()
            assert isinstance(machine_running_time, float), "machine_running_time must be float"
        else:
            machine_running_time = tune_total_machine_time

        return counts, QiskitTiming(
            qiskit_running_time=timedelta(seconds=time.perf_counter() - init_time_cf),
            total_machine_time=timedelta(seconds=tune_total_machine_time),
            machine_running_time=timedelta(seconds=machine_running_time),
            total_execution_time=None,
        )
