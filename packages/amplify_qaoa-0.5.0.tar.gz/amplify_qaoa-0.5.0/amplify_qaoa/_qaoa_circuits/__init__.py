from __future__ import annotations

from enum import Enum, auto
from typing import TYPE_CHECKING

from ._type_utility import CircType, ObsType, SupportsAnsatz, SupportsCAnsatz, SupportsHam

if TYPE_CHECKING:
    from amplify_qaoa._utility import IsingDict


def generate_hamiltonian(runner: SupportsHam[ObsType], f_dict: IsingDict, wires: int) -> ObsType:
    # Runner requirements:
    # * construct_observable(wires)
    # * add_z_gates(op_f, wires, li, value)

    op_f = runner.construct_observable(wires)

    for key, value in f_dict.items():
        if len(set(key)) > 0:
            op_f = runner.add_z_gates(op_f, wires, key, value)

    return op_f


def qaoa_ansatz(
    runner: SupportsAnsatz[CircType, ObsType], f_dict: IsingDict, wires: int, parameters: list[float], reps: int
) -> CircType:
    # Runner requirements:
    # * HamiltonianCtor
    # * construct_quantum_circuit(wires)
    # * construct_observable(wires)
    # * add_pauli_x(op_mixer, wires, i, value)
    # * add_h_gate(circuit, i)
    # * add_observable_rotation_gate(circuit, op_f, parameters[idx], wires)

    op_f = generate_hamiltonian(runner, f_dict, wires)

    circuit = runner.construct_quantum_circuit(wires)

    op_mixer = runner.construct_observable(wires)

    for i in range(wires):
        op_mixer = runner.add_pauli_x(op_mixer, wires, i, 1.0)

        circuit = runner.add_h_gate(circuit, i)

    for idx in range(reps):
        circuit = runner.add_observable_rotation_gate(circuit, op_f, parameters[idx], wires)

        circuit = runner.add_observable_rotation_gate(circuit, op_mixer, parameters[reps + idx], wires)

    return circuit


def constrained_ansatz(
    runner: SupportsCAnsatz[CircType],
    wires: int,
    parameters: list[float],
    reps: int,
    group_list: list[list[int]],
    init_ones: list[int],
) -> CircType:
    # Runner requirements:
    # * construct_quantum_circuit(wires)
    # * add_x_gate(circuit, i)
    # * add_cnot_gate(circuit, i, j)
    # * add_rx_gate(circuit, i, value, wires)
    # * add_ry_gate(circuit, i, value)

    not_grouped = set(range(wires))
    for group in group_list:
        not_grouped -= set(group)

    k = 0

    circuit = runner.construct_quantum_circuit(wires)
    for i in init_ones:
        runner.add_x_gate(circuit, i)

    for i in not_grouped:
        runner.add_rx_gate(circuit, i, parameters[k], wires)

        k += 1

    for _ in range(reps):
        for group in group_list:
            m = len(group)
            for i in range(m // 2):
                a = 2 * i
                b = 2 * i + 1

                runner.add_cnot_gate(circuit, group[a], group[b])
                runner.add_ry_gate(circuit, group[a], parameters[k])
                runner.add_cnot_gate(circuit, group[b], group[a])
                runner.add_ry_gate(circuit, group[a], -parameters[k])
                runner.add_cnot_gate(circuit, group[a], group[b])

                k += 1

            for i in range((m - 1) // 2):
                a = 2 * i + 1
                b = 2 * i + 2
                runner.add_cnot_gate(circuit, group[a], group[b])
                runner.add_ry_gate(circuit, group[a], parameters[k])
                runner.add_cnot_gate(circuit, group[b], group[a])
                runner.add_ry_gate(circuit, group[a], -parameters[k])
                runner.add_cnot_gate(circuit, group[a], group[b])
                k += 1

    return circuit


class QaoaAnsatzType(Enum):
    Original = auto()
    Constrained = auto()
    Auto = auto()


def construct_qaoa_circuit(
    runner: SupportsAnsatz[CircType, ObsType] | SupportsCAnsatz[CircType],
    f_dict: IsingDict,
    wires: int,
    qaoa_type: QaoaAnsatzType,
    parameters: list[float],
    reps: int,
    group_list: list[list[int]] | None = None,
    init_ones: list[int] | None = None,
) -> CircType:
    if group_list is None:
        group_list = []
    if init_ones is None:
        init_ones = []

    if qaoa_type == QaoaAnsatzType.Constrained:
        if not isinstance(runner, SupportsCAnsatz):
            raise TypeError("Protocol check failed.")
        return constrained_ansatz(runner, wires, parameters, reps, group_list, init_ones)

    if len(group_list) > 0:
        raise ValueError("Group list is not required for Original QAOA.")
    if len(init_ones) > 0:
        raise ValueError("Init ones is not required for Original QAOA.")

    if qaoa_type == QaoaAnsatzType.Original:
        if not isinstance(runner, SupportsAnsatz):
            raise TypeError("Protocol check failed.")
        return qaoa_ansatz(runner, f_dict, wires, parameters, reps)
    raise ValueError("Invalid QaoaAnsatzType.")
