from __future__ import annotations

import typing
from typing import TYPE_CHECKING, Generic, Protocol, TypeVar

if TYPE_CHECKING:
    from collections.abc import Iterable

CircType = TypeVar("CircType")
ObsType = TypeVar("ObsType")

CircType_co = TypeVar("CircType_co", covariant=True)
ObsType_co = TypeVar("ObsType_co", covariant=True)


@typing.runtime_checkable
class SupportsCirc(Protocol, Generic[CircType_co]):
    @staticmethod
    def construct_quantum_circuit(wires: int) -> CircType_co: ...


@typing.runtime_checkable
class SupportsObs(Protocol, Generic[ObsType_co]):
    @staticmethod
    def construct_observable(wires: int) -> ObsType_co: ...


@typing.runtime_checkable
class SupportsHam(SupportsObs[ObsType], Protocol):
    @staticmethod
    def add_z_gates(op_f: ObsType, wires: int, li: Iterable[int], value: float) -> ObsType: ...


@typing.runtime_checkable
class SupportsAnsatz(SupportsCirc[CircType], SupportsHam[ObsType], Protocol):
    @staticmethod
    def add_pauli_x(op_f: ObsType, wires: int, i: int, value: float) -> ObsType: ...

    @staticmethod
    def add_h_gate(circuit: CircType, i: int) -> CircType: ...

    @staticmethod
    def add_observable_rotation_gate(circuit: CircType, op_f: ObsType, value: float, wires: int) -> CircType: ...


@typing.runtime_checkable
class SupportsCAnsatz(SupportsCirc[CircType], Protocol):
    @staticmethod
    def add_cnot_gate(circuit: CircType, i: int, j: int) -> CircType: ...

    @staticmethod
    def add_x_gate(circuit: CircType, i: int) -> CircType: ...

    @staticmethod
    def add_rx_gate(circuit: CircType, i: int, value: float, wires: int) -> CircType: ...

    @staticmethod
    def add_ry_gate(circuit: CircType, i: int, value: float) -> CircType: ...


@typing.runtime_checkable
class SupportsFullSim(SupportsAnsatz[CircType, ObsType], SupportsCAnsatz[CircType], SupportsHam[ObsType], Protocol): ...
