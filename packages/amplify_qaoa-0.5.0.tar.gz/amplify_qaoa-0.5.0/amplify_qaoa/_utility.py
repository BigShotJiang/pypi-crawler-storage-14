from __future__ import annotations

import itertools
from collections import Counter, defaultdict

CoeffType = tuple[int, ...]
IsingDict = dict[CoeffType, float]
SolType = list[tuple[list[int], int]]


def count_qubits(f_dict: IsingDict, group_list: list[list[int]]) -> int:
    """Get the number of qubits required to solve the problem.

    Args:
        f_dict (IsingDict): Ising model
        group_list (list[list[int]]): constraints

    Returns:
        int: the number of qubits

    Examples:
        >>> f_dict = {(0, 1): 1.0, (1, 2): 1.0, (2, 3): 1.0, (3, 0): 1.0}
        >>> group_list = [[0, 1], [2, 3]]
        >>> count_qubits(f_dict, group_list)
        4
    """
    index_set: set[int] = set()

    for key in f_dict:
        index_set |= set(key)

    index_set |= set(itertools.chain.from_iterable(group_list))
    return max(index_set) + 1


def decode_solutions(raw_solution: dict[str, int]) -> list[tuple[list[int], int]]:
    """Decode the solution from the raw solution as list of pair of spin list and frequency.

    Args:
        raw_solution (Dict[str, int]): the raw solution (bit string and frequency)

    Returns:
        list[Tuple[list[int], int]]: list of pair of spin (+1 or -1) list and frequency

    Examples:
        >>> raw_solution = {"0000": 10, "0001": 20, "0010": 30, "0011": 40}
        >>> decode_solutions(raw_solution)
        [([1, 1, 1, 1], 10), ([1, 1, 1, -1], 20), ([1, 1, -1, 1], 30), ([1, 1, -1, -1], 40)]
    """
    return [
        ([-1 if int(i) > 0 else 1 for i in reversed(assignments)], frequency)
        for assignments, frequency in raw_solution.items()
    ]


def reduce_degree(f_dict: IsingDict) -> IsingDict:
    reduced_f_dict: IsingDict = defaultdict(float)

    for key, value in f_dict.items():
        count = Counter(key)
        reduced_key = tuple(i for i, a in count.items() if a % 2 == 1)
        reduced_f_dict[reduced_key] += value

    return reduced_f_dict


def compute_function_value(f_dict: IsingDict, counts: SolType) -> float:
    f_val = 0.0
    stat_sum = 0.0

    for sol, stat in counts:
        stat_sum += stat

        for key, val in f_dict.items():
            tmp = val
            for i in key:
                tmp *= sol[i]
            f_val += tmp * stat

    return f_val / stat_sum
