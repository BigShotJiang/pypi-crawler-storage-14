from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from utility import ClientType, check_run_result, client_list

from amplify_qaoa import QaoaAnsatzType

if TYPE_CHECKING:
    from _pytest.mark.structures import ParameterSet

    from amplify_qaoa._utility import IsingDict

# 3-city-tsp is generated from
tsp_3_city_distance_table = [
    [0, 0.2, 0.4],
    [0.2, 0, 0.2],
    [0.4, 0.2, 0],
]

tsp_3_city_f_dict = {
    (): 2.4,
    (0, 5): 0.1,
    (2, 3): 0.1,
    (1, 5): 0.05,
    (2, 7): 0.05,
    (2, 6): 0.1,
    (0, 8): 0.1,
    (5,): 0.5,
    (1, 4): 0.2,
    (2,): 0.5,
    (4,): 0.4,
    (4, 7): 0.2,
    (6,): 0.5,
    (5, 6): 0.1,
    (1,): 0.4,
    (0, 7): 0.05,
    (0, 3): 0.2,
    (5, 7): 0.05,
    (3, 6): 0.2,
    (4, 8): 0.05,
    (0, 4): 0.05,
    (5, 8): 0.2,
    (3, 7): 0.05,
    (1, 8): 0.05,
    (1, 3): 0.05,
    (2, 8): 0.2,
    (1, 6): 0.05,
    (3,): 0.5,
    (2, 4): 0.05,
    (0,): 0.5,
    (0, 6): 0.2,
    (2, 5): 0.2,
    (3, 8): 0.1,
    (8,): 0.5,
    (1, 7): 0.2,
    (4, 6): 0.05,
    (7,): 0.4,
}
tsp_3_city_group_list = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]

problem_list: list[ParameterSet] = [
    pytest.param({(0,): 1, (1,): 1, (2,): 1}, [[0, 1, 2]], id="simple-one-hot"),
    pytest.param({(0, 1): -2, (0, 2): 1, (1, 2): 2}, [[0, 1]], id="group-with-ungrouped"),
    pytest.param(tsp_3_city_f_dict, tsp_3_city_group_list, id="3-city-tsp"),
    pytest.param({(0, 1, 2): -1}, [[0, 1, 2]], id="3-order-one-hot"),
    pytest.param({(0, 1, 2, 3): -1}, [[0, 1], [2, 3]], id="4-order-one-hot"),
    pytest.param({(0, 1, 2, 3): -1}, [[0, 1]], id="4-order-group-with-ungrouped"),
    pytest.param(
        {
            (0, 1, 2, 3): -1,
            (0, 1): 1,
            (0, 2): -1,
            (0, 3): -1,
            (1, 2): 1,
            (0,): 5,
            (1,): 5,
        },
        [[0, 1]],
        id="4-order-one-hot-ising-model",
    ),
]


@pytest.mark.heavy()
@pytest.mark.parametrize(("f_dict", "group_list"), problem_list)
@pytest.mark.parametrize("client_type", client_list)
def test_solve(
    f_dict: IsingDict,
    group_list: list[list[int]],
    client_type: type[ClientType],
) -> None:
    client = client_type()
    client.shots = 8192

    wires = max(i for key in f_dict for i in key) + 1
    run_result = client.run(f_dict=f_dict, group_list=group_list, qaoa_type=QaoaAnsatzType.Constrained)

    check_run_result(client, f_dict, wires, group_list, run_result)
