import pytest

from amplify_qaoa.runners._core import AbstractQAOARunner
from amplify_qaoa.runners._timing import TimingBase


class MockCircType:
    pass


class MockObsType:
    pass


class MockTimingType(TimingBase):
    pass


class MockQAOARunner(AbstractQAOARunner[MockCircType, MockObsType, MockTimingType]):
    def init_runner(self, wires: int) -> None:
        return super().init_runner(wires)

    def observe(self, qc: MockCircType) -> tuple[list[tuple[list[int], int]], MockTimingType]:
        return super().observe(qc)


def test_proxy_setter() -> None:
    client = MockQAOARunner(reps=1, shots=1)
    assert client.proxy is None

    client = MockQAOARunner(reps=1, shots=1, proxy="scheme://localhost:8888")
    assert client.proxy == "scheme://localhost:8888"


def test_url_setter() -> None:
    client = MockQAOARunner(reps=1, shots=1)
    assert client.url is None

    client = MockQAOARunner(reps=1, shots=1, url="scheme://localhost:8888")

    assert client.url == "scheme://localhost:8888"
