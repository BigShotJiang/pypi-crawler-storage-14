from __future__ import annotations

from amplify_qaoa import QulacsRunner
from amplify_qaoa._qaoa_circuits._type_utility import SupportsFullSim


def test_constructor() -> None:
    client = QulacsRunner(reps=10, shots=1000)

    assert client.reps == 10
    assert client.shots == 1000


def test_proto() -> None:
    assert isinstance(QulacsRunner, SupportsFullSim)


def test_parameter_set() -> None:
    client = QulacsRunner(reps=10, shots=1000)

    # confirm setting reps
    reps_ = 20
    client.reps = reps_
    assert client.reps == reps_

    # confirm setting shots
    shots_ = 2000
    client.shots = shots_
    assert client.shots == shots_
