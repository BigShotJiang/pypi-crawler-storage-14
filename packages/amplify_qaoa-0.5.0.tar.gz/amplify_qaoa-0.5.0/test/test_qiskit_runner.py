from __future__ import annotations

import os
from typing import TYPE_CHECKING

import pytest
from utility import check_run_result

from amplify_qaoa import QiskitRunner
from amplify_qaoa._qaoa_circuits._type_utility import SupportsFullSim

pytestmark = pytest.mark.qiskit_runner

if TYPE_CHECKING:
    from amplify_qaoa._utility import IsingDict

AMPLIFY_QAOA_QISKIT_TEST_TOKEN = os.getenv("AMPLIFY_QAOA_QISKIT_TEST_TOKEN")
if AMPLIFY_QAOA_QISKIT_TEST_TOKEN is None:
    raise ValueError("Set the environment variable AMPLIFY_QAOA_QISKIT_TEST_TOKEN to run the tests.")

TEST_QISKIT_BACKEND_NAME = "ibm_fez"


def test_constructor() -> None:
    client = QiskitRunner(reps=10, shots=2000)

    assert client.reps == 10
    assert client.shots == 2000
    assert client.backend_name is None
    assert client.device == "CPU"
    assert client.provider is None


def test_proto() -> None:
    assert isinstance(QiskitRunner, SupportsFullSim)


def test_parameter_set() -> None:
    client = QiskitRunner(reps=10, shots=2000)

    # confirm setting reps
    reps_ = 20
    client.reps = reps_
    assert client.reps == reps_

    # confirm setting shots
    shots_ = 4000
    client.shots = shots_
    assert client.shots == shots_

    # confirm setting backend_name
    backend_name_ = "automatic"
    client.backend_name = backend_name_
    assert client.backend_name == backend_name_

    # confirm setting device
    for device_ in ["GPU", "CPU", "QPU"]:
        client.device = device_
        assert client.device == device_

    assert client.channel == "ibm_quantum_platform"

    # confirm setting backend_name
    token_ = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
    client.token = token_
    assert client.token == token_


def test_run_with_token_and_simulator_method() -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    wires = 2
    shots = 4000
    client = QiskitRunner(reps=10, shots=shots)
    client.device = "CPU"
    client.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
    client.backend_name = "statevector"  # simulator method
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)

    assert client.backend is not None
    assert client.backend.name == "aer_simulator_statevector"
    assert client.backend.options is not None
    assert client.backend.options.method == "statevector"


def test_run_with_token_and_backend_name() -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    wires = 2
    shots = 4000

    backend_name = TEST_QISKIT_BACKEND_NAME

    client = QiskitRunner(reps=10, shots=shots)
    client.device = "CPU"
    client.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
    client.backend_name = backend_name
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)

    assert client.backend is not None
    assert client.backend.name == "aer_simulator_from(" + backend_name + ")"


def test_run_without_token_and_backend_name() -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    wires = 2
    shots = 4000

    backend_name = TEST_QISKIT_BACKEND_NAME

    client = QiskitRunner(reps=10, shots=shots)
    client.device = "CPU"
    client.backend_name = backend_name
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)

    assert client.backend is not None
    assert client.backend.name == "fake_" + backend_name[4:]


def test_run_with_different_backend_in_tune_and_run() -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    shots = 4000

    client = QiskitRunner(reps=10, shots=shots)
    client.device = "CPU"
    client.backend_name = "statevector"
    tune_result = client.tune(f_dict, optimizer="COBYLA")

    client.backend_name = "density_matrix"
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, 2, [], run_result)


def test_multiple_clients_with_same_token() -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    shots = 4000

    client_1 = QiskitRunner(reps=10, shots=shots)
    client_1.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
    client_1.device = "CPU"
    client_1.backend_name = TEST_QISKIT_BACKEND_NAME
    tune_result = client_1.tune(f_dict, optimizer="COBYLA")

    client_2 = QiskitRunner(reps=10, shots=shots)
    client_2.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
    client_2.device = "CPU"
    client_2.backend_name = TEST_QISKIT_BACKEND_NAME
    client_2.backend_name = "density_matrix"
    run_result = client_2.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client_2, f_dict, 2, [], run_result)


TEST_PROXY_URL = os.getenv("TEST_PROXY_URL")
if TEST_PROXY_URL is None:
    raise ValueError("Set the environment variable TEST_PROXY_URL to run the tests.")


def test_run_with_proxy() -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    wires = 2
    shots = 4000

    backend_name = TEST_QISKIT_BACKEND_NAME

    client = QiskitRunner(reps=10, shots=shots, proxy=TEST_PROXY_URL, verify=False)
    client.device = "CPU"
    client.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
    client.backend_name = backend_name
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)

    assert client.backend is not None
    assert client.backend.name == "aer_simulator_from(" + backend_name + ")"
