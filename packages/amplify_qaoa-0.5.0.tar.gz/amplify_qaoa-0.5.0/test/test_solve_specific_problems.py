from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from utility import ClientType, check_run_result, client_list

if TYPE_CHECKING:
    from _pytest.mark.structures import ParameterSet

    from amplify_qaoa._utility import IsingDict

simple_problem_list: list[ParameterSet] = [
    pytest.param({(0,): 1, (1,): 1}, id="simple-primary-term"),
    pytest.param({(0, 1): 1, (2,): 2}, id="simple-ising-model-1"),
    pytest.param({(0, 2): 1, (1,): -2}, id="simple-ising-model-2"),
    pytest.param({(0, 1): -2, (0,): -1, (): 1}, id="simple-ising-model-3"),
    pytest.param({(0, 1): -2, (0, 0): -1, (1, 1): 1, (): 1}, id="duplicated-ising-model"),
]
high_order_problem_list: list[ParameterSet] = [
    pytest.param({(0, 1, 2): 1, (1,): 1}, id="3-order-term"),
    pytest.param({(0, 1, 2, 3): 1, (1,): 1}, id="4-order-term"),
    pytest.param(
        {(0, 1, 1, 2, 2, 2): -2, (0, 0, 1, 2): -1, (1, 1, 1): 1, (): 1},
        id="duplicated-high-order-ising-model",
    ),
    pytest.param(
        {
            (0, 1, 2, 3, 4, 5, 6): 1,
            (0, 1, 2, 3): -1,
            (4, 5, 6): -1,
            (0, 1): 1,
            (2, 3): 1,
            (1,): 1,
        },
        id="6-order-ising-model",
    ),
    pytest.param(
        {
            (0, 1, 2, 3): 1,
            (0, 1, 2): -1,
            (0, 1, 3): 1,
            (0, 2, 3): 1,
            (1, 2, 3): 1,
            (0, 1): -1,
            (0, 2): -1,
            (0, 3): 1,
            (1, 2): 1,
            (1, 3): 1,
            (2, 3): 1,
            (1,): 1,
        },
        id="4-order-ising-model",
    ),
]


@pytest.mark.heavy()
@pytest.mark.parametrize("f_dict", simple_problem_list)
@pytest.mark.parametrize("client_type", client_list)
def test_simple_ising_model(f_dict: IsingDict, client_type: type[ClientType]) -> None:
    client = client_type()
    client.shots = 2048

    run_result = client.run(f_dict)

    wires = max(i for key in f_dict for i in key) + 1
    check_run_result(client, f_dict, wires, [], run_result)


@pytest.mark.heavy()
# pytest.mark.flaky overrides the default only_rerun option
@pytest.mark.flaky(reruns=3, reruns_delay=1, only_rerun=["FlakyTestError", "RuntimeError"])
@pytest.mark.parametrize("f_dict", high_order_problem_list)
@pytest.mark.parametrize("client_type", client_list)
def test_high_order_ising_model(f_dict: IsingDict, client_type: type[ClientType]) -> None:
    client = client_type()
    client.shots = 16384
    client.reps = 20

    run_result = client.run(f_dict=f_dict)

    wires = max(i for key in f_dict for i in key) + 1
    check_run_result(client, f_dict, wires, [], run_result)
