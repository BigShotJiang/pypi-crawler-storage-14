from __future__ import annotations

from datetime import timedelta
from typing import TYPE_CHECKING

import numpy as np
import pytest
from utility import ClientType, check_run_result, client_list

from amplify_qaoa import QaoaAnsatzType, runners
from amplify_qaoa.runners import QiskitRunner, QulacsRunner
from amplify_qaoa.runners._result import OptimizeHistory
from amplify_qaoa.runners.qiskit_runner import QiskitTiming
from amplify_qaoa.runners.qulacs_runner import QulacsTiming

if TYPE_CHECKING:
    from amplify_qaoa._utility import IsingDict


@pytest.mark.parametrize("client_type", client_list)
def test_run(client_type: type[ClientType]) -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    wires = 2
    shots = 2000

    client = client_type(reps=10, shots=shots)
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)


@pytest.mark.parametrize("client_type", client_list)
def test_run_with_different_shots_in_tune_and_run(client_type: type[ClientType]) -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}

    client = client_type(reps=10, shots=4000)
    tune_result = client.tune(f_dict, optimizer="COBYLA")

    client.shots = 8000
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, 2, [], run_result)


@pytest.mark.parametrize("client_type", client_list)
def test_run_with_different_problems(client_type: type[ClientType]) -> None:
    f_dict: IsingDict = {(0, 1): -1.0, (): 99.0}
    wires = 2
    shots = 2000

    client = client_type(reps=10, shots=shots)
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)

    f_dict: IsingDict = {(0, 1): 1.0, (2,): 2.0}
    wires = 3

    client = client_type(reps=10, shots=shots)
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)

    f_dict: IsingDict = {(0,): 1.0, (1,): 1.0}
    wires = 2

    client = client_type(reps=10, shots=shots)
    tune_result = client.tune(f_dict, optimizer="COBYLA")
    run_result = client.run(f_dict, parameters=tune_result.opt_params)

    # assert result
    check_run_result(client, f_dict, wires, [], run_result)


@pytest.mark.parametrize("client_type", client_list)
def test_tune_run(client_type: type[ClientType]) -> None:
    # MaxCut without grouping
    f_dict_1: IsingDict = {(0, 1): 1.0, (1, 2): 1.0, (0, 3): 1.0, (2, 3): 1.0}

    client = client_type(reps=10, shots=4000)

    tune_result_1 = client.tune(f_dict_1, optimizer="COBYLA")
    run_result_1 = client.run(f_dict_1, parameters=tune_result_1.opt_params)

    # assert result
    check_run_result(client, f_dict_1, 4, [], run_result_1)

    # TSP with grouping
    f_dict_2: IsingDict = {
        (): 2.4,
        (0, 5): 0.1,
        (2, 3): 0.1,
        (1, 5): 0.05,
        (2, 7): 0.05,
        (2, 6): 0.1,
        (0, 8): 0.1,
        (5,): 0.5,
        (1, 4): 0.2,
        (2,): 0.5,
        (4,): 0.4,
        (4, 7): 0.2,
        (6,): 0.5,
        (5, 6): 0.1,
        (1,): 0.4,
        (0, 7): 0.05,
        (0, 3): 0.2,
        (5, 7): 0.05,
        (3, 6): 0.2,
        (4, 8): 0.05,
        (0, 4): 0.05,
        (5, 8): 0.2,
        (3, 7): 0.05,
        (1, 8): 0.05,
        (1, 3): 0.05,
        (2, 8): 0.2,
        (1, 6): 0.05,
        (3,): 0.5,
        (2, 4): 0.05,
        (0,): 0.5,
        (0, 6): 0.2,
        (2, 5): 0.2,
        (3, 8): 0.1,
        (8,): 0.5,
        (1, 7): 0.2,
        (4, 6): 0.05,
        (7,): 0.4,
    }
    group_list_2 = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]

    tune_result_2 = client.tune(
        f_dict_2,
        group_list=group_list_2,
        optimizer="COBYLA",
        qaoa_type=QaoaAnsatzType.Constrained,
    )
    assert client._f_dict == f_dict_2
    assert client._group_list == group_list_2
    assert client.opt_params is not None
    assert client.opt_params == tune_result_2.opt_params

    # Run MaxCut
    run_result_2 = client.run(f_dict_1, parameters=tune_result_1.opt_params)
    check_run_result(client, f_dict_1, 4, [], run_result_2)

    # Run TSP
    run_result_3 = client.run()
    check_run_result(client, f_dict_2, 9, group_list_2, run_result_3)

    # Artificial problem without grouping
    f_dict_3: IsingDict = {(0, 1): 1.0, (1, 2): -1.0, (0, 2): 1.0}

    # tune and run Example3
    run_result_4 = client.run(f_dict_3)
    assert client._f_dict == f_dict_3
    assert client._group_list == []
    check_run_result(client, f_dict_3, 3, [], run_result_4)

    # Add grouping to Example3
    group_list_3 = [[0, 1, 2]]
    tune_result_3 = client.tune(
        f_dict_3,
        optimizer="COBYLA",
        group_list=group_list_3,
        init_ones=[],
        qaoa_type=QaoaAnsatzType.Constrained,
    )
    run_result_5 = client.run()
    assert client._group_list == group_list_3
    assert client._init_ones == tune_result_3.init_ones
    check_run_result(client, f_dict_3, 3, group_list_3, run_result_5)


@pytest.mark.parametrize("client_type", client_list)
def test_param_val_history(client_type: type[ClientType]):
    # MaxCut without grouping
    f_dict: IsingDict = {(0, 1): 1.0, (1, 2): 1.0, (0, 3): 1.0, (2, 3): 1.0}

    client = client_type(reps=10, shots=4000)

    tune_result = client.tune(f_dict, optimizer="COBYLA")

    assert hasattr(tune_result, "params_history")
    assert isinstance(tune_result, runners._result.TuneResult)
    _HIST_ATTRS = ["counts", "objective", "parameters", "timestamp"]
    for hist in tune_result.params_history:
        assert isinstance(hist, OptimizeHistory)

        # check attributes
        for attr in _HIST_ATTRS:
            assert hasattr(hist, attr)

        # check counts
        assert isinstance(hist.counts, list)
        for count in hist.counts:
            assert isinstance(count, tuple)
            assert isinstance(count[0], list)
            assert set(count[0]) <= set({1, -1})
            assert isinstance(count[1], int)

        # check objective
        assert isinstance(hist.objective, float)

        # check parameters
        assert isinstance(hist.parameters, np.ndarray)

        # check timestamp
        timestamp = hist.timestamp
        if client_type == QulacsRunner:
            assert isinstance(timestamp, QulacsTiming)
            assert set(timestamp.__dict__.keys()) == set(
                {
                    "total_execution_time",
                    "total_machine_time",
                }
            )
            for val in timestamp.__dict__.values():
                assert isinstance(val, timedelta)
        elif client_type == QiskitRunner:
            assert isinstance(timestamp, QiskitTiming)
            assert set(timestamp.__dict__.keys()) == set(
                {
                    "machine_running_time",
                    "qiskit_running_time",
                    "total_execution_time",
                    "total_machine_time",
                }
            )
            for val in timestamp.__dict__.values():
                assert isinstance(val, timedelta)


@pytest.mark.parametrize("client_type", client_list)
def test_qaoa_type(client_type: type[ClientType]) -> None:
    f_dict: IsingDict = {(0, 1): 1.0}

    # Case: no group_list is given
    client = client_type(reps=10, shots=1000)
    assert client.qaoa_type == QaoaAnsatzType.Auto
    tune_res = client.tune(f_dict, optimizer="COBYLA")
    assert client.qaoa_type == QaoaAnsatzType.Original

    opt_params = tune_res.opt_params

    client = client_type(reps=10, shots=1000)
    assert client.qaoa_type == QaoaAnsatzType.Auto
    client.measure(f_dict, parameters=opt_params)
    assert client.qaoa_type == QaoaAnsatzType.Auto

    client = client_type(reps=10, shots=1000)
    assert client.qaoa_type == QaoaAnsatzType.Auto
    client.measure(f_dict, parameters=opt_params, qaoa_type=QaoaAnsatzType.Original)
    assert client.qaoa_type == QaoaAnsatzType.Auto

    # Case: group_list is given
    group_list = [[0, 1]]

    client = client_type(reps=10, shots=1000)
    assert client.qaoa_type == QaoaAnsatzType.Auto
    tune_res = client.tune(f_dict, group_list=group_list, optimizer="COBYLA")
    assert client.qaoa_type == QaoaAnsatzType.Constrained
    opt_params = tune_res.opt_params

    client = client_type(reps=10, shots=1000)
    assert client.qaoa_type == QaoaAnsatzType.Auto
    client.measure(f_dict, group_list=group_list, parameters=opt_params)
    assert client.qaoa_type == QaoaAnsatzType.Auto

    client = client_type(reps=10, shots=1000)
    assert client.qaoa_type == QaoaAnsatzType.Auto
    client.measure(f_dict, group_list=group_list, parameters=opt_params, qaoa_type=QaoaAnsatzType.Constrained)
    assert client.qaoa_type == QaoaAnsatzType.Auto
