import pytest

from ankipan import Reader

@pytest.mark.parametrize(
    "lang,input_text,expected",
    [
        ('de', 'Woher genau\\h', 'Woher genau'),
        ('de', 'Woher\ngenau\n\n', 'Woher\ngenau\n\n'),
        ('de', 'Bäume, überall: auch da.', 'Bäume, überall: auch da.'),
    ]
)
def test_add_deck(lang, input_text, expected):
    r = Reader(lang)
    res = r.clean_string(input_text, [])
    assert res == expected
