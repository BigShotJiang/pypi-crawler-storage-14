# Ankipan

Ankipan is a project to democratize language learning in a decentralized way.

It allows you to choose which domains you want to be more fluent in, and creates a custom learning curriculum that aims to get you to your goal as effectively and efficiently as possible.
It is currently based on anki flashcards, where the user first specifies a source text or folder with textdocuments of interest. Ankipan then uses a NLP library to parse all the words and bring them to their root form, and then generates flashcards sorted by occurrence frequency in the source.
The flashcards can contain any number of fields that the user is interested in, such as dictionary definitions, example sentences from a particular source, or gpt-generated translations and explanations for how the words are used in the specified source:

<p align="center">
  <img src="/docs/anki_screenshot_1.png" width="45%"/>
  <img src="/docs/anki_screenshot_2.png" width="45%"/>
</p>

New fields can easily be added in a modular way by creating a new file in the `ankipan/flashcard_fields` directory.
Ankipan can connect to any number of servers containing a pre-parsed db of different text sources, e.g. to collect example sentences or utilize GPT resources for translations/explanations and other fields. (`ankipan.Config.add_server(name, url)`, for hosting a server see https://gitlab.com/ankipan/ankipan_db)

## Getting started

### 1. Prerequisites

- Download and install anki from https://apps.ankiweb.net/
- Create an account on their website
- Install the ankiconnect plugin (In anki, open Tools -> Add Ons -> Get Add-Ons -> paste code 2055492159, see https://ankiweb.net/shared/info/2055492159)
- Open the app and login, keep anki open when syncing databases

### 2. Installation

- Using pip:

```bash
pip install ankipan
```

- From source:

```bash
git clone git@gitlab.com:ankipan/ankipan.git
cd ankipan
pip install .
```

### 3. (Optional) Install lemmatizers to parse your own texts

- Download pytorch from https://pytorch.org/get-started/locally/ (for stanza lemma parsing)
- install dependencies:

```bash
pip install stanza HanTa
```

## Usage

See notebooks in `/examples`

## Notes

- Current lemmatization is done via the `stanza` library in the reader.py module. While this works mostly fine, the library still just uses a statistical model to estimate the likely word roots (lemmas) of the different pieces of sentences. It sometimes makes mistakes, which requires the users to manually filter them in the `select_new_words` overview, or suspend the card later on in anki.
