from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from .secret_provider import get_secret
import httpx
import os

# -------------------------------
# Global route store
# -------------------------------
REGISTERED_ROUTES = []


def add_central_auth(app: FastAPI):

    AUTH_INTROSPECT_URL = os.getenv("AUTH_INTROSPECT_URL")
    AUTH_LOGIN_URL = os.getenv("AUTH_LOGIN_URL")
    CLIENT_ID = os.getenv("VERGE_CLIENT_ID")
    CLIENT_SECRET = os.getenv("VERGE_CLIENT_SECRET")

    # ---------------------------------
    # 1) Collect routes at startup
    # ---------------------------------
    @app.on_event("startup")
    async def verge_bootstrap():
        REGISTERED_ROUTES.clear()

        for route in app.routes:
            try:
                path = getattr(route, "path", None)
                methods = list(getattr(route, "methods", []))

                if not path:
                    continue

                # Skip framework/internal paths
                if path.startswith("/docs") or path.startswith("/openapi"):
                    continue

                if path.startswith("/__verge__"):
                    continue

                for m in methods:
                    if m in ["GET", "POST", "PUT", "PATCH", "DELETE"]:
                        REGISTERED_ROUTES.append({
                            "path": path,
                            "method": m
                        })
            except Exception:
                pass

    # ---------------------------------
    # 2) Expose routes securely
    # ---------------------------------
    @app.get("/__verge__/routes")
    async def verge_routes(request: Request):

        service_secret = get_secret("VERGE_SERVICE_SECRET")

        if not service_secret:
            raise HTTPException(status_code=500, detail="Service secret missing")

        # Header lookup (case-insensitive safe)
        secret = request.headers.get("x-verge-service-secret") or \
                 request.headers.get("X-Verge-Service-Secret")

        if secret != service_secret:
            raise HTTPException(status_code=403, detail="Forbidden")

        return REGISTERED_ROUTES

    # ---------------------------------
    # 3) AUTH MIDDLEWARE
    # ---------------------------------
    @app.middleware("http")
    async def central_auth(request: Request, call_next):

        # Bypass for internal Verge endpoints
        if request.url.path.startswith("/__verge__"):
            return await call_next(request)

        # Allow public paths
        if request.url.path in {"/health", "/docs", "/openapi.json"}:
            return await call_next(request)

        # -------------------------
        # Extract token
        # -------------------------
        token = None
        auth = request.headers.get("authorization")

        if auth and auth.lower().startswith("bearer "):
            parts = auth.split(" ")
            if len(parts) == 2:
                token = parts[1]

        if not token:
            token = request.cookies.get("access_token")

        # -------------------------
        # No token
        # -------------------------
        if not token:
            if "text/html" in request.headers.get("accept", ""):
                return RedirectResponse(
                    f"{AUTH_LOGIN_URL}?redirect_url={request.url}"
                )
            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

        # -------------------------
        # Ensure auth service URL
        # -------------------------
        if not AUTH_INTROSPECT_URL:
            return JSONResponse(
                {"detail": "Auth introspect URL not configured"},
                status_code=500
            )

        # -------------------------
        # Call auth service
        # -------------------------
        try:
            async with httpx.AsyncClient(timeout=3) as client:
                res = await client.post(
                    AUTH_INTROSPECT_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "X-Client-Id": CLIENT_ID,
                        "X-Client-Secret": CLIENT_SECRET
                    }
                )
                data = res.json()
        except Exception:
            return JSONResponse(
                {"detail": "Auth service unreachable"},
                status_code=503
            )

        # -------------------------
        # Invalid session
        # -------------------------
        if not data.get("active"):
            return JSONResponse({"detail": "Session expired"}, status_code=401)

        # -------------------------
        # Attach context
        # -------------------------
        request.state.user = data.get("user", {})
        request.state.roles = data.get("roles", [])

        return await call_next(request)
