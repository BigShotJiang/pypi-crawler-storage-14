# oelint-data

This package provides data for [oelint-adv](https://github.com/priv-kweihmann/oelint-adv)

For more details see the [constants guide](https://github.com/priv-kweihmann/oelint-adv/blob/master/docs/constants.md)
