"""Project management including initialization, stack generation, and plugin sync."""
