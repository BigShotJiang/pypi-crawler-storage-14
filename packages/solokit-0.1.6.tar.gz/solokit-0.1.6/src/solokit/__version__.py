"""Version information for Solokit package."""

__version__ = "0.1.6"
