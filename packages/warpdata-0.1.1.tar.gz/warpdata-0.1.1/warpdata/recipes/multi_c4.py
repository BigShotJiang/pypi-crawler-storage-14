"""
mC4 (Multilingual C4) dataset recipe.

mC4 is a multilingual variant of the C4 dataset, covering Common Crawl web text
in multiple languages.

Source: https://huggingface.co/datasets/mc4
Paper: https://arxiv.org/abs/2010.11934

Languages included: ar, de, en, es, fi, fr, hi, it, ja, ko, nl, pl, pt, ru, sv, th, tr, uk, vi, zh
"""
from pathlib import Path
from typing import List, Optional
import json
import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def multi_c4(
    ctx: RecipeContext,
    raw_data_dir: str = "recipes_raw_data/multi_c4",
    languages: Optional[List[str]] = None,
) -> RecipeOutput:
    """
    Create mC4 multilingual text dataset.

    Loads mC4 data from local JSONL files. Each file contains web text
    in a specific language from Common Crawl.

    Args:
        ctx: Recipe context
        raw_data_dir: Directory containing language-specific JSONL files
        languages: List of language codes to include (None = all available)

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - text: str - Web text content
        - url: str - Source URL (if available)
        - timestamp: str - Crawl timestamp (if available)
        - language: str - Language code (ar, de, en, es, etc.)

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "multi_c4",
        ...     "warpdata://nlp/mc4",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/mc4", as_format="pandas")
        >>> # Filter by language
        >>> english = df[df['language'] == 'en']
        >>> japanese = df[df['language'] == 'ja']
    """
    raw_dir = Path(raw_data_dir)

    if not raw_dir.exists():
        raise ValueError(f"Raw data directory not found: {raw_dir}")

    print(f"Loading mC4 data from {raw_dir}...")

    # Find all JSONL files
    jsonl_files = sorted(raw_dir.glob("*.jsonl"))

    if not jsonl_files:
        raise ValueError(f"No JSONL files found in {raw_dir}")

    print(f"  Found {len(jsonl_files)} language files")

    # Process each language file
    all_records = []
    language_counts = {}

    for jsonl_file in jsonl_files:
        # Extract language code from filename (e.g., "en.jsonl" -> "en")
        lang_code = jsonl_file.stem

        # Skip if specific languages requested and this isn't one of them
        if languages is not None and lang_code not in languages:
            print(f"  Skipping {lang_code} (not in requested languages)")
            continue

        print(f"  Loading {lang_code}...")

        # Read JSONL file
        with open(jsonl_file, 'r', encoding='utf-8') as f:
            count = 0
            for line in f:
                try:
                    data = json.loads(line.strip())

                    record = {
                        'text': str(data.get('text', '')),
                        'url': str(data.get('url', '')),
                        'timestamp': str(data.get('timestamp', '')),
                        'language': lang_code,
                    }

                    all_records.append(record)
                    count += 1

                except json.JSONDecodeError:
                    # Skip malformed lines
                    continue

        language_counts[lang_code] = count
        print(f"    Loaded {count:,} records")

    print(f"\nTotal records: {len(all_records):,}")
    print(f"Languages: {len(language_counts)}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "multi_c4.parquet"
    df.to_parquet(output_path, index=False)

    print(f"\nSaved to {output_path}")
    print(f"\nLanguage distribution:")
    for lang, count in sorted(language_counts.items()):
        print(f"  {lang}: {count:,}")

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_records': len(df),
            'languages': language_counts,
            'source': 'mC4 (Multilingual C4)',
            'raw_data_dir': str(raw_dir),
        },
        raw_data=raw_data_paths,
    )
