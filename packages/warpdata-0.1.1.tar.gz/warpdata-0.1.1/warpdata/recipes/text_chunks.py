"""
Generic text chunking recipe.

This recipe takes an existing warpdata dataset containing long text
fields and produces a *chunked* dataset with one row per text chunk.

Typical use case:
    - Source: warpdata://text/gutenberg-en-50k  (one row per book)
    - Target: warpdata://text/gutenberg-en-50k-chunks (one row per chunk)
    - Embeddings: run warp embeddings add on the chunked dataset,
      using the 'chunk_text' column.

The chunked dataset schema:
    - source_dataset: str    – original warpdata dataset ID
    - source_id: any         – ID from the source row (e.g., book_id or rid)
    - chunk_idx: int         – 0-based chunk index within the source row
    - chunk_start: int       – start character offset in the original text
    - chunk_end: int         – end character offset (exclusive)
    - chunk_text: str        – chunked text slice
    - <extra_columns>: any   – optional columns carried over from source
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    tqdm = None

from ..core.uris import parse_uri
from ..core.registry import get_registry
from ..core.cache import get_cache
from ..api.recipes import RecipeContext
from .base import RecipeOutput


WRITE_CHUNK_ROWS = 50_000


def text_chunks(
    ctx: RecipeContext,
    source_dataset: str,
    text_column: str = "text",
    id_column: str = "rid",
    max_chars: int = 2048,
    overlap_chars: int = 256,
    extra_columns: Optional[List[str]] = None,
) -> RecipeOutput:
    """
    Create a chunked text dataset from an existing warpdata dataset.

    Args:
        ctx: Recipe context.
        source_dataset: Source warpdata dataset ID
            (e.g., 'warpdata://text/gutenberg-en-50k').
        text_column: Name of the text column in the source dataset.
        id_column: Name of the ID column in the source dataset
            (e.g., 'rid' or 'book_id'), used as 'source_id'.
        max_chars: Maximum number of characters per chunk.
        overlap_chars: Number of overlapping characters between chunks
            (0 for no overlap). Must be < max_chars to have effect.
        extra_columns: Optional list of additional columns to carry over
            from the source dataset into the chunked dataset
            (e.g., ['title', 'authors']).

    Returns:
        RecipeOutput with a single Parquet file (main.parquet) containing
        chunked text rows.
    """
    # Normalize extra_columns when passed as a comma-separated string from CLI.
    if isinstance(extra_columns, str):  # type: ignore[unreachable]
        extra_columns_list: List[str] = [
            c.strip() for c in extra_columns.split(",") if c.strip()
        ]
    else:
        extra_columns_list = extra_columns or []

    if max_chars <= 0:
        raise ValueError("max_chars must be a positive integer")
    if overlap_chars < 0:
        raise ValueError("overlap_chars must be >= 0")

    # Effective stride between chunks.
    stride = max_chars - overlap_chars if overlap_chars < max_chars else max_chars

    print(f"📚 Building chunked text dataset from {source_dataset}")
    print(f"   Text column: {text_column}")
    print(f"   ID column: {id_column}")
    print(f"   Chunk size: {max_chars} chars, overlap: {overlap_chars} chars")
    if extra_columns_list:
        print(f"   Extra columns: {extra_columns_list}")

    uri = parse_uri(source_dataset)
    if not uri.is_warpdata:
        raise ValueError(f"source_dataset must be a warpdata:// URI, got: {source_dataset}")

    registry = get_registry()
    dataset_ver = registry.get_dataset_version(uri.workspace, uri.name, uri.version or "latest")
    if dataset_ver is None:
        raise ValueError(f"Source dataset not found: {source_dataset}")

    manifest = registry.get_manifest(uri.workspace, uri.name, dataset_ver["version_hash"]) or {}
    resources = manifest.get("resources") or []
    if not resources:
        raise ValueError(f"No resources found for source dataset: {source_dataset}")

    cache = get_cache()

    out_path = ctx.work_dir / "main.parquet"
    writer: Optional[pq.ParquetWriter] = None
    buffer: List[Dict[str, Any]] = []

    total_source_rows = 0
    total_chunks = 0

    # Optional progress bar over resources; fine-grained per-row progress
    # would require counting rows ahead of time.
    resource_iter = resources
    if tqdm is not None:
        resource_iter = tqdm(resources, desc="Scanning source resources", unit="file")

    def flush_buffer():
        nonlocal writer, buffer, total_chunks
        if not buffer:
            return
        df = pd.DataFrame(buffer)
        table = pa.Table.from_pandas(df, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(out_path, table.schema)
        writer.write_table(table)
        total_chunks += len(df)
        buffer.clear()

    for res in resource_iter:
        res_uri = res.get("uri")
        if not res_uri:
            continue
        try:
            local_path = cache.get(res_uri)
        except Exception as e:
            print(f"   Warning: failed to access resource {res_uri}: {e}")
            continue

        if not local_path or not Path(local_path).exists():
            print(f"   Warning: local path for {res_uri} not found; skipping.")
            continue

        try:
            pf = pq.ParquetFile(local_path)
        except Exception as e:
            print(f"   Warning: failed to open Parquet {local_path}: {e}")
            continue

        # Ensure we only touch the columns we need.
        cols = [id_column, text_column] + [
            c for c in extra_columns_list if c not in (id_column, text_column)
        ]

        for batch in pf.iter_batches(columns=cols, batch_size=1024):
            table = pa.Table.from_batches([batch])
            data = table.to_pydict()

            ids = data.get(id_column)
            texts = data.get(text_column)
            if ids is None or texts is None:
                raise ValueError(
                    f"Source data missing required columns '{id_column}' or '{text_column}'"
                )

            extras_per_col: Dict[str, List[Any]] = {
                col: data.get(col, []) for col in extra_columns_list
            }

            for row_idx, (src_id, txt) in enumerate(zip(ids, texts)):
                total_source_rows += 1

                if txt is None:
                    continue
                text = str(txt)
                if not text:
                    continue

                length = len(text)
                chunk_idx = 0
                start = 0
                while start < length:
                    end = min(start + max_chars, length)
                    chunk_text = text[start:end]

                    rec: Dict[str, Any] = {
                        "source_dataset": source_dataset,
                        "source_id": src_id,
                        "chunk_idx": chunk_idx,
                        "chunk_start": start,
                        "chunk_end": end,
                        "chunk_text": chunk_text,
                    }
                    for col in extra_columns_list:
                        col_vals = extras_per_col.get(col)
                        if col_vals is not None and row_idx < len(col_vals):
                            rec[col] = col_vals[row_idx]
                        else:
                            rec[col] = None

                    buffer.append(rec)
                    chunk_idx += 1

                    if len(buffer) >= WRITE_CHUNK_ROWS:
                        flush_buffer()

                    if end >= length:
                        break
                    start += stride

    flush_buffer()
    if writer is not None:
        writer.close()
    else:
        # No chunks produced; still create an empty table with the expected schema.
        schema = pa.schema(
            [
                ("source_dataset", pa.string()),
                ("source_id", pa.string()),
                ("chunk_idx", pa.int32()),
                ("chunk_start", pa.int32()),
                ("chunk_end", pa.int32()),
                ("chunk_text", pa.string()),
            ]
            + [(col, pa.string()) for col in extra_columns_list]
        )
        empty_table = pa.table({name: pa.array([], type=field.type) for name, field in zip(schema.names, schema)})
        pq.write_table(empty_table, out_path)

    print(f"\n✅ Created chunked dataset with {total_chunks:,} chunks from {total_source_rows:,} source rows")
    print(f"   Output: {out_path}")

    return RecipeOutput(
        main=[out_path],
        metadata={
            "source_dataset": source_dataset,
            "text_column": text_column,
            "id_column": id_column,
            "max_chars": max_chars,
            "overlap_chars": overlap_chars,
            "extra_columns": extra_columns_list,
            "total_source_rows": total_source_rows,
            "total_chunks": total_chunks,
        },
        raw_data=[],
    )

