"""
DMT Brains EEG Dataset Recipe.

Processes EEG recordings during DMT administration and baseline conditions
with psychological assessments (SCID, Big Five, anxiety, mystical beliefs).

Data structure:
- EEG files: S##-CONDITION.bdf (CONDITION = DMT, EC, EO)
- Scales: scales_results.csv with psychological assessments

Output datasets:
- main: All subjects, all conditions
- dmt-only: DMT condition only
- baseline: EC and EO conditions
- complete: Only subjects with all 3 conditions
"""
import json
from pathlib import Path
from typing import List, Dict, Any, Optional
import numpy as np
import pandas as pd

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset, EmbeddingConfig
from ..recipes.utils import (
    discover_files,
    parse_filename_pattern,
    load_auxiliary_data,
    group_files_by_key,
    compute_file_stats,
)


def dmt_brains(
    ctx: RecipeContext,
    data_dir: str,
    include_scales: bool = True,
    include_signals: bool = True,
    window_sec: float = 2.0,
    step_sec: float = 1.0,
    max_channels: Optional[int] = None,
) -> RecipeOutput:
    """
    Create DMT Brains EEG dataset with sub-datasets and documentation.

    Args:
        ctx: Recipe context
        data_dir: Directory containing EEG files and scales_results.csv
        include_scales: If True, merge psychological scales data

    Returns:
        RecipeOutput with main dataset, sub-datasets, and docs

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "dmt_brains",
        ...     "warpdata://neuro/dmt-brains",
        ...     data_dir="./recipes_raw_data/dmt_brains"
        ... )
        >>> print(result['subdatasets'])
    """
    data_path = Path(data_dir)
    print(f"📊 Processing DMT Brains dataset from {data_path}")

    # 1. Discover EEG files
    eeg_files = discover_files(data_path, ['*.bdf', '*.xdf'])
    print(f"   Found {len(eeg_files)} EEG files")

    # 2. Parse filenames and group by subject
    subjects_data = {}

    def extract_subject(filepath: Path) -> str:
        """Extract subject ID from filename."""
        info = parse_filename_pattern(
            filepath,
            r'[Ss](\d+)',
            {'subject_id': 1},
            transform={'subject_id': lambda x: f'S{x.zfill(2)}'}
        )
        return info.get('subject_id')

    file_groups = group_files_by_key(eeg_files, extract_subject)
    print(f"   Found {len(file_groups)} subjects: {sorted(file_groups.keys())}")

    # 3. Load scales data
    scales_data = {}
    if include_scales:
        scales_data = load_auxiliary_data(
            data_path / 'scales_results.csv',
            file_format='csv',
            index_col=0  # Subject ID as index
        )
        print(f"   Loaded scales data for {len(scales_data)} subjects")

    # 4. Process each subject
    all_records = []

    for subject_id in sorted(file_groups.keys()):
        subject_files = file_groups[subject_id]

        # Parse each file to extract condition
        conditions = {}
        for filepath in subject_files:
            filename = filepath.name.upper()

            # Determine condition
            if 'DMT' in filename:
                condition = 'DMT'
            elif 'EC' in filename:
                condition = 'EC'
            elif 'EO' in filename:
                condition = 'EO'
            else:
                continue

            # Get file stats
            size_mb = filepath.stat().st_size / (1024 * 1024)

            conditions[condition] = {
                'filename': filepath.name,
                'file_format': filepath.suffix.lower().lstrip('.'),
                'file_size_mb': size_mb,
                'relative_path': str(filepath.relative_to(data_path))
            }

        # Compute stats
        stats = compute_file_stats(subject_files)

        # Build record
        record = {
            'subject_id': subject_id,
            'conditions': conditions,
            'file_count': stats['file_count'],
            'total_size_mb': stats['total_size_mb'],
            'file_formats': stats['file_formats'],
            'has_all_conditions': {'DMT', 'EC', 'EO'}.issubset(conditions.keys()),
            'found_conditions': sorted(list(conditions.keys())),
            'missing_conditions': sorted(list({'DMT', 'EC', 'EO'} - conditions.keys())),
        }

        # Add scales data if available
        if include_scales and subject_id in scales_data:
            record['scales_data'] = _organize_scales(scales_data[subject_id])
            record['has_scales_data'] = True
        else:
            record['scales_data'] = {}
            record['has_scales_data'] = False

        # Add dataset metadata
        record.update({
            'dataset_name': 'DMT Brains EEG',
            'modality': 'EEG',
            'paradigm': 'psychedelic_research',
            'drug': 'DMT',
        })

        all_records.append(record)

    print(f"   Processed {len(all_records)} subjects")

    # 5. Convert to DataFrame and write main dataset
    df = pd.DataFrame(all_records)

    # Flatten nested structures for DuckDB
    df_flat = _flatten_records(all_records)
    # Load into DuckDB
    main_relation = ctx.engine.conn.from_df(df_flat)

    # Write main dataset
    main_out = ctx.work_dir / "main.parquet"
    ctx.write_parquet(main_relation, main_out)

    # 6. Create sub-datasets (subject-level summaries)
    subdatasets = {}

    # 6.0 Condition-level table: one row per (subject_id, condition)
    conditions_rows: List[Dict[str, Any]] = []
    for _, row in df_flat.iterrows():
        subject_id = row["subject_id"]
        try:
            conditions = json.loads(row["conditions_json"]) if row["conditions_json"] else {}
        except Exception:
            conditions = {}

        for condition, info in conditions.items():
            if not isinstance(info, dict):
                continue
            rel_path = info.get("relative_path")
            conditions_rows.append(
                {
                    "subject_id": subject_id,
                    "condition": condition,
                    "filename": info.get("filename"),
                    "file_format": info.get("file_format"),
                    "file_size_mb": info.get("file_size_mb"),
                    "relative_path": rel_path,
                    # Subject-level metadata
                    "has_all_conditions": row["has_all_conditions"],
                    "has_scales_data": row["has_scales_data"],
                    "found_conditions_str": row["found_conditions_str"],
                    "missing_conditions_str": row["missing_conditions_str"],
                    "dataset_name": row["dataset_name"],
                    "modality": row["modality"],
                    "paradigm": row["paradigm"],
                    "drug": row["drug"],
                    # Optional placeholders for downstream pipelines
                    "remote_url": None,
                    "hf_path": None,
                }
            )

    if conditions_rows:
        conditions_df = pd.DataFrame(conditions_rows)
        conditions_rel = ctx.engine.conn.from_df(conditions_df)
        conditions_out = ctx.work_dir / "dmt_brains_conditions.parquet"
        ctx.write_parquet(conditions_rel, conditions_out)
        subdatasets["conditions"] = SubDataset(
            name="conditions",
            files=[conditions_out],
            description="One row per (subject_id, condition) with EEG file paths and metadata",
        )

    # DMT-only (subjects with DMT condition)
    dmt_out = ctx.filter_and_write(
        main_relation,
        ctx.work_dir / "dmt_only.parquet",
        filter_sql="found_conditions_str LIKE '%DMT%'"
    )
    subdatasets['dmt-only'] = SubDataset(
        name='dmt-only',
        files=[dmt_out],
        description='DMT condition EEG recordings only',
        filter_sql="found_conditions_str LIKE '%DMT%'"
    )

    # Baseline (EC + EO)
    baseline_out = ctx.filter_and_write(
        main_relation,
        ctx.work_dir / "baseline.parquet",
        filter_sql="found_conditions_str LIKE '%EC%' OR found_conditions_str LIKE '%EO%'"
    )
    subdatasets['baseline'] = SubDataset(
        name='baseline',
        files=[baseline_out],
        description='Baseline conditions (Eyes Closed and Eyes Open)',
        filter_sql="found_conditions_str LIKE '%EC%' OR found_conditions_str LIKE '%EO%'"
    )

    # Complete subjects (all 3 conditions)
    complete_out = ctx.filter_and_write(
        main_relation,
        ctx.work_dir / "complete.parquet",
        filter_sql="has_all_conditions = true"
    )
    subdatasets['complete'] = SubDataset(
        name='complete',
        files=[complete_out],
        description='Subjects with all three conditions (DMT, EC, EO)',
        filter_sql="has_all_conditions = true"
    )

    # 6.1 Optionally create windowed EEG signals as an internal table (row-per-window)
    signals_out: Optional[Path] = None
    if include_signals:
        try:
            import mne  # type: ignore
        except Exception as e:
            raise ImportError(
                "mne is required to build the signals subdataset. Install with: pip install mne"
            ) from e

        # Lazy, chunked writer to avoid OOM: stream windows and write in batches.
        import pyarrow as pa  # type: ignore
        import pyarrow.parquet as pq  # type: ignore

        signals_out = ctx.work_dir / "dmt_brains_signals.parquet"
        writer: Optional[pq.ParquetWriter] = None
        buffer: List[Dict[str, Any]] = []
        chunk_size = 256  # windows per write

        def _flush_buffer():
            nonlocal writer, buffer
            if not buffer:
                return
            df_chunk = pd.DataFrame(buffer)
            table = pa.Table.from_pandas(df_chunk)
            if writer is None:
                writer = pq.ParquetWriter(signals_out, table.schema, compression="snappy")
            writer.write_table(table)
            buffer = []

        # Precompute per-subject conditions from df (flat json strings)
        for _, row in df_flat.iterrows():
            subject_id = row["subject_id"]
            try:
                conditions = json.loads(row["conditions_json"]) if row["conditions_json"] else {}
            except Exception:
                conditions = {}

            for condition, info in conditions.items():
                rel_path = info.get("relative_path")
                if not rel_path:
                    continue
                eeg_path = (data_path / rel_path).resolve()
                if not eeg_path.exists():
                    print(f"   ⚠️  Missing EEG file for {subject_id} {condition}: {eeg_path}")
                    continue

                file_fmt = (info.get("file_format") or eeg_path.suffix.lstrip(".")).lower()

                # Load raw EEG with MNE (no preload to avoid loading entire file into RAM)
                try:
                    if file_fmt in ("bdf",):
                        raw = mne.io.read_raw_bdf(str(eeg_path), preload=False, verbose="ERROR")
                    elif file_fmt in ("xdf",):
                        # mne >=1.5 supports XDF via pyxdf; may not be available
                        raw = mne.io.read_raw_xdf(str(eeg_path), preload=False, verbose="ERROR")  # type: ignore[attr-defined]
                    else:
                        # Try auto-detect based on extension
                        raw = mne.io.read_raw(str(eeg_path), preload=False, verbose="ERROR")
                except Exception as ex:
                    print(f"   ⚠️  Could not read EEG file: {eeg_path} ({ex})")
                    continue

                # Pick EEG channels; optionally limit number of channels
                try:
                    raw.pick_types(eeg=True, meg=False, stim=False, eog=False, ecg=False, emg=False, exclude="bads")
                except Exception:
                    pass

                if max_channels is not None and len(raw.ch_names) > max_channels:
                    keep = raw.ch_names[:max_channels]
                    raw.pick_channels(keep)

                sfreq = float(raw.info.get("sfreq", 0.0))
                if sfreq <= 0:
                    print(f"   ⚠️  Invalid sampling rate for {eeg_path}")
                    continue

                n_samples = int(raw.n_times)
                n_channels = len(raw.ch_names)

                win = max(int(round(window_sec * sfreq)), 1)
                step = max(int(round(step_sec * sfreq)), 1)

                # Iterate windows, loading only the needed segment from disk
                widx = 0
                for start in range(0, max(n_samples - win + 1, 0), step):
                    stop = start + win
                    try:
                        segment = raw.get_data(start=start, stop=stop).astype("float32")  # (C, T)
                    except Exception as ex:
                        print(f"   ⚠️  Failed to read window {widx} for {eeg_path}: {ex}")
                        continue
                    # Flatten as time-major (T*C) for downstream compatibility
                    flat = segment.T.reshape(-1).astype("float32")
                    buffer.append(
                        {
                            "subject_id": subject_id,
                            "condition": condition,
                            "sampling_rate": sfreq,
                            "channels": n_channels,
                            "n_samples": win,
                            "window_index": widx,
                            "frames": flat.tolist(),
                            "file_path": str(eeg_path),
                        }
                    )
                    widx += 1

                    if len(buffer) >= chunk_size:
                        _flush_buffer()

        # Flush remaining windows and close writer
        if buffer:
            _flush_buffer()
        if writer is not None:
            writer.close()
        else:
            print("   ⚠️  No EEG windows extracted; skipping signals subdataset")

    # 7. Generate documentation
    total_subjects = len(all_records)
    complete_subjects = sum(1 for r in all_records if r['has_all_conditions'])
    subjects_with_scales = sum(1 for r in all_records if r.get('has_scales_data', False))

    notes_md = f"""# DMT Brains EEG Dataset

## Overview
EEG recordings during DMT (N,N-Dimethyltryptamine) administration and baseline conditions.

## Statistics
- **Total Subjects**: {total_subjects}
- **Complete Subjects** (all 3 conditions): {complete_subjects}
- **Subjects with Scales Data**: {subjects_with_scales}

## Conditions
- **DMT**: EEG during DMT administration (psychedelic condition)
- **EC**: Eyes Closed baseline (pre-drug resting state)
- **EO**: Eyes Open baseline (pre-drug resting state)

## Psychological Assessments
- SCID Clinical Assessment
- Big Five Personality Inventory (pre/post)
- State-Trait Anxiety Inventory (pre/post)
- Mystical Beliefs Scale (pre/post)
- 5D-ASC Psychedelic Experience Scale
- Near-Death Experience Scale
- Alexithymia (TAS) Scale

## Data Structure
Each record contains:
- Subject ID
- Conditions with EEG file paths
- File statistics
- Completeness indicators
- Psychological scales data (if available)

## Sub-Datasets
- **dmt-only**: DMT condition recordings only
- **baseline**: EC and EO baseline conditions
- **complete**: Only subjects with all 3 conditions
 - **conditions**: One row per (subject_id, condition) with EEG file paths

## Citation
Please cite the original study if using this dataset.
"""

    readme_md = f"""# DMT Brains EEG Dataset

## Quick Start
```python
import warpdata as wd

# Load main dataset
data = wd.load("warpdata://neuro/dmt-brains", as_format="pandas")

# Load DMT-only subset
dmt_data = wd.load("warpdata://neuro/dmt-brains-dmt-only", as_format="pandas")

# Load condition-level table (one row per subject & condition)
conditions = wd.load("warpdata://neuro/dmt-brains-conditions", as_format="pandas")

# Load signals (windowed EEG with 'frames' column)
signals = wd.load("warpdata://neuro/dmt-brains-signals", as_format="pandas")
signals.head()

# Query complete subjects
complete = wd.load("warpdata://neuro/dmt-brains-complete", as_format="pandas")
```

## Statistics
- Total subjects: {total_subjects}
- Complete subjects: {complete_subjects}
- Subjects with psychological scales: {subjects_with_scales}
"""

    # Build docs and metadata
    docs = {
        'notes.md': notes_md,
        'README.md': readme_md,
    }

    # Track raw data for backup/provenance
    raw_data_sources = []
    if data_path.exists():
        raw_data_sources.append(data_path)  # Track the entire DMT brains directory (~1.4GB)

    # 8. Return recipe output
    # Include additional internal tables in metadata if present
    extra_meta = {
        'total_subjects': total_subjects,
        'complete_subjects': complete_subjects,
        'subjects_with_scales': subjects_with_scales,
        'conditions': ['DMT', 'EC', 'EO'],
    }
    if signals_out:
        extra_meta.setdefault('tables', {})
        extra_meta['tables']['signals'] = [f"file://{signals_out}"]

    return RecipeOutput(
        main=[main_out],
        subdatasets=subdatasets,
        docs=docs,
        metadata=extra_meta,
        raw_data=raw_data_sources,
    )


def _organize_scales(scales: Dict[str, Any]) -> Dict[str, Any]:
    """Organize flat scales dictionary into categories."""
    organized = {
        'scid_clinical': {k: v for k, v in scales.items() if k.startswith('SCID-')},
        'big_five_personality': {
            'pre': {k: v for k, v in scales.items() if k.startswith('BFI1-')},
            'post': {k: v for k, v in scales.items() if k.startswith('BFI2-')},
            'change': {k: v for k, v in scales.items() if k.startswith('d_BFI-')}
        },
        'anxiety_state': {
            'pre': {k: v for k, v in scales.items() if k.startswith('STAI1-')},
            'post': {k: v for k, v in scales.items() if k.startswith('STAI2-')},
            'change': {k: v for k, v in scales.items() if k.startswith('d_STAI-')}
        },
        'mystical_beliefs': {
            'pre': {k: v for k, v in scales.items() if k.startswith('MBS1-')},
            'post': {k: v for k, v in scales.items() if k.startswith('MBS2-')},
            'change': {k: v for k, v in scales.items() if k.startswith('d_MBS-')}
        },
    }
    return organized


def _flatten_records(records: List[Dict[str, Any]]) -> pd.DataFrame:
    """Flatten nested record structures for DuckDB."""
    flat_records = []

    for record in records:
        flat = {
            'subject_id': record['subject_id'],
            'file_count': record['file_count'],
            'total_size_mb': record['total_size_mb'],
            'has_all_conditions': record['has_all_conditions'],
            'has_scales_data': record.get('has_scales_data', False),
            'found_conditions_str': ','.join(record['found_conditions']),
            'missing_conditions_str': ','.join(record['missing_conditions']),
            'dataset_name': record['dataset_name'],
            'modality': record['modality'],
            'paradigm': record['paradigm'],
            'drug': record['drug'],
            # Store conditions as JSON string
            'conditions_json': json.dumps(record['conditions']),
            # Store scales as JSON string
            'scales_json': json.dumps(record.get('scales_data', {})),
        }
        flat_records.append(flat)

    return pd.DataFrame(flat_records)
