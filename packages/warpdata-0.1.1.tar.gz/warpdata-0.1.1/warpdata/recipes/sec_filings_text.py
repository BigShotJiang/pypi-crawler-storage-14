"""
SEC EDGAR Filing Text dataset recipe.

Downloads the actual 10-K/10-Q filing documents (full text) from SEC EDGAR.
Requires an existing sec_earnings dataset to know which filings to download.

Source: SEC EDGAR Public Archive
"""
from pathlib import Path
from typing import List, Optional
import pandas as pd
import requests
import time
from bs4 import BeautifulSoup
import re

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def download_filing_text(cik: str, accession_number: str, primary_document: str) -> Optional[str]:
    """Download and extract text from a SEC filing."""
    headers = {
        'User-Agent': 'WarpData Dataset Builder research@example.com'
    }

    # Remove dashes from accession number for URL
    accession_clean = accession_number.replace('-', '')

    # Construct URL
    url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{accession_clean}/{primary_document}"

    try:
        time.sleep(0.1)  # SEC rate limit: 10 requests per second
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            return None

        # Parse HTML
        soup = BeautifulSoup(response.content, 'html.parser')

        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()

        # Get text
        text = soup.get_text()

        # Clean up whitespace
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)

        return text

    except Exception as e:
        return None


def sec_filings_text(
    ctx: RecipeContext,
    *,
    earnings_dataset: str,
    limit: Optional[int] = None,
    filing_types: Optional[List[str]] = None,
) -> RecipeOutput:
    """
    Download full text of SEC filings.

    Takes an existing sec_earnings dataset and downloads the actual filing documents.

    Args:
        ctx: Recipe context
        earnings_dataset: Path to sec_earnings dataset (e.g. 'warpdata://earnings/sec-earnings-options-tickers')
        limit: Limit number of filings to download (for testing)
        filing_types: Filter to specific filing types (default: ['10-K', '10-Q'])

    Returns:
        RecipeOutput with filing text content

    Examples:
        >>> import warpdata as wd
        >>> # Download filings for options tickers
        >>> result = wd.run_recipe(
        ...     "sec_filings_text",
        ...     "warpdata://filings/options-tickers-text",
        ...     earnings_dataset="warpdata://earnings/sec-earnings-options-tickers",
        ...     limit=10,  # Test with 10 filings first
        ...     with_materialize=True
        ... )
    """
    from ..api import load

    if filing_types is None:
        filing_types = ['10-K', '10-Q']

    print(f"📊 Downloading SEC Filing Text")
    print(f"   Source: {earnings_dataset}")
    print(f"   Filing types: {', '.join(filing_types)}")

    # Load earnings dataset
    print(f"\n📂 Loading earnings data...")
    df_earnings = load(earnings_dataset, as_format='pandas')

    print(f"  ✓ Loaded {len(df_earnings):,} filings")

    # Filter by filing types
    df_earnings = df_earnings[df_earnings['form_type'].isin(filing_types)]
    print(f"  ✓ Filtered to {len(df_earnings):,} filings ({', '.join(filing_types)})")

    # Limit if specified
    if limit:
        df_earnings = df_earnings.head(limit)
        print(f"  ✓ Limited to {len(df_earnings):,} filings")

    # Filter out rows missing required fields
    required_fields = ['ticker', 'cik', 'filing_date', 'accession_number', 'primary_document']
    df_earnings = df_earnings.dropna(subset=required_fields)

    print(f"  ✓ {len(df_earnings):,} filings have complete data")

    print(f"\n📥 Downloading {len(df_earnings):,} filing documents...")
    print(f"   (This may take a while - SEC rate limit is 10 req/sec)")

    filings_data = []
    success_count = 0
    failed_count = 0

    for idx, row in df_earnings.iterrows():
        ticker = row['ticker']
        cik = row['cik']
        filing_date = row['filing_date']
        form_type = row['form_type']
        fiscal_period = row.get('fiscal_period', None)
        accession = row['accession_number']
        primary_doc = row['primary_document']

        print(f"  [{success_count + failed_count + 1}/{len(df_earnings)}] {ticker} {form_type} {filing_date}...", end='', flush=True)

        # Download filing text
        filing_text = download_filing_text(cik, accession, primary_doc)

        if filing_text:
            filings_data.append({
                'ticker': ticker,
                'cik': cik,
                'filing_date': filing_date,
                'form_type': form_type,
                'fiscal_period': fiscal_period,
                'accession_number': accession,
                'filing_text': filing_text,
                'text_length': len(filing_text),
            })
            print(f" ✓ {len(filing_text):,} chars")
            success_count += 1
        else:
            print(f" ⚠️  Failed")
            failed_count += 1

    print(f"\n✅ Download complete!")
    print(f"   Success: {success_count}")
    print(f"   Failed: {failed_count}")

    if not filings_data:
        raise ValueError("No filings downloaded. Note: This recipe needs CIK data to be added to the earnings dataset.")

    # Convert to DataFrame
    df = pd.DataFrame(filings_data)

    # Save to parquet
    output_file = ctx.work_dir / "sec_filings_text.parquet"
    df.to_parquet(output_file, index=False)

    print(f"  ✓ Saved to {output_file.name}")

    # Generate documentation
    readme = f"""# SEC Filing Text Dataset

## Overview
Full text content of SEC filings (10-K, 10-Q)

## Configuration
- **Source**: {earnings_dataset}
- **Filing Types**: {', '.join(filing_types)}
- **Total Filings**: {len(df)}

## Schema

| Column | Type | Description |
|--------|------|-------------|
| ticker | string | Stock ticker symbol |
| filing_date | date | Date filed with SEC |
| form_type | string | Filing type (10-K, 10-Q) |
| accession_number | string | SEC accession number |
| filing_text | string | Full text content of filing |
| text_length | int | Character count |

## Usage

```python
import warpdata as wd

# Load filing text
df = wd.load("warpdata://filings/...", as_format="pandas")

# Search for keywords
aapl_filings = df[df['ticker'] == 'AAPL']
for _, row in aapl_filings.iterrows():
    if 'revenue' in row['filing_text'].lower():
        print(f"{row['filing_date']}: Contains 'revenue'")

# Analyze text length
df['text_length'].describe()
```

## Statistics
- Total filings: {len(df):,}
- Unique tickers: {df['ticker'].nunique()}
- Average text length: {df['text_length'].mean():,.0f} characters
"""

    metadata = {
        "total_filings": len(df),
        "source": "SEC EDGAR Archive",
    }

    return RecipeOutput(
        main=[output_file],
        docs={"README.md": readme},
        metadata=metadata,
    )
