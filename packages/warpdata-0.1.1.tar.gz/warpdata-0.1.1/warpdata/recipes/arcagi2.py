"""
ARC-AGI-2 recipe.

Same schema as ARC-AGI-1 recipe, processing ARC-AGI-2 JSON tasks into a
single, filterable Parquet dataset with one row per input/output pair.

Raw data layout expected:
  ./recipes_raw_data/ARCAGI2/
    data/
      training/*.json
      evaluation/*.json
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Any, List
import json
from collections import Counter

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def _grid_shape(grid: List[List[int]]) -> tuple[int, int]:
    h = len(grid)
    w = len(grid[0]) if h > 0 else 0
    return h, w


def _color_hist_json(grid: List[List[int]]) -> tuple[int, str]:
    flat = [v for row in grid for v in row]
    hist = Counter(flat)
    return len(hist), json.dumps({int(k): int(v) for k, v in hist.items()}, ensure_ascii=False)


def arcagi2(
    ctx: RecipeContext,
    data_root: str = "./recipes_raw_data/ARCAGI2",
    data_dir: str | None = None,
    limit: int | None = None,
) -> RecipeOutput:
    """
    Create ARC-AGI-2 dataset from local JSON tasks.
    """
    # Resolve data directory (support either repo root or direct data dir)
    if data_dir:
        data_dir = Path(data_dir).resolve()
        root = data_dir.parent
    else:
        root = Path(data_root).resolve()
        data_dir = root / "data"
    train_dir = data_dir / "training"
    eval_dir = data_dir / "evaluation"

    if not data_dir.exists():
        raise FileNotFoundError(f"ARC-AGI-2 data directory not found: {data_dir}")
    if not train_dir.exists() or not eval_dir.exists():
        raise FileNotFoundError(f"Expected training/evaluation subfolders under: {data_dir}")

    records: List[Dict[str, Any]] = []
    total_tasks = 0

    for split_name, split_path in (("training", train_dir), ("evaluation", eval_dir)):
        json_files = sorted(split_path.glob("*.json"))
        if limit is not None:
            json_files = json_files[: max(0, int(limit))]
        total_tasks += len(json_files)
        print(f"Processing {len(json_files)} tasks from {split_name}...")

        for jf in json_files:
            task_id = jf.stem
            with open(jf, "r", encoding="utf-8") as fh:
                task = json.load(fh)

            for pair_type in ("train", "test"):
                pairs = task.get(pair_type, [])
                for idx, pair in enumerate(pairs):
                    inp = pair.get("input", [])
                    out = pair.get("output", [])

                    ih, iw = _grid_shape(inp)
                    oh, ow = _grid_shape(out)
                    in_colors, in_hist_json = _color_hist_json(inp)
                    out_colors, out_hist_json = _color_hist_json(out)

                    records.append(
                        {
                            "task_id": task_id,
                            "split": split_name,
                            "pair_type": pair_type,
                            "pair_index": idx,
                            "input_json": json.dumps(inp, ensure_ascii=False),
                            "output_json": json.dumps(out, ensure_ascii=False),
                            "input_height": ih,
                            "input_width": iw,
                            "output_height": oh,
                            "output_width": ow,
                            "input_cells": ih * iw,
                            "output_cells": oh * ow,
                            "input_n_colors": in_colors,
                            "output_n_colors": out_colors,
                            "input_color_hist": in_hist_json,
                            "output_color_hist": out_hist_json,
                        }
                    )

    df = pd.DataFrame.from_records(records)

    out_path = ctx.work_dir / "arcagi2.parquet"
    df.to_parquet(out_path, index=False)

    metadata = {
        "total_rows": int(len(df)),
        "total_tasks": int(total_tasks),
        "splits": {k: int(v) for k, v in df["split"].value_counts().to_dict().items()},
        "pair_types": {k: int(v) for k, v in df["pair_type"].value_counts().to_dict().items()},
        "columns": {
            "task_id": {"type": "string"},
            "split": {"type": "string", "enum": ["training", "evaluation"]},
            "pair_type": {"type": "string", "enum": ["train", "test"]},
            "pair_index": {"type": "int"},
            "input_json": {"type": "json"},
            "output_json": {"type": "json"},
            "input_height": {"type": "int"},
            "input_width": {"type": "int"},
            "output_height": {"type": "int"},
            "output_width": {"type": "int"},
            "input_cells": {"type": "int"},
            "output_cells": {"type": "int"},
            "input_n_colors": {"type": "int"},
            "output_n_colors": {"type": "int"},
            "input_color_hist": {"type": "json"},
            "output_color_hist": {"type": "json"},
        },
        "source": str(root),
        "dataset": "ARC-AGI-2",
    }

    readme = f"""# ARC-AGI-2 Dataset

Normalized table of input/output pairs from ARC-AGI-2.
Schema matches ARC-AGI-1 recipe for easy joint analysis.
"""

    raw_data_paths = [data_dir]

    return RecipeOutput(
        main=[out_path],
        metadata=metadata,
        docs={"README.md": readme},
        raw_data=raw_data_paths,
    )
