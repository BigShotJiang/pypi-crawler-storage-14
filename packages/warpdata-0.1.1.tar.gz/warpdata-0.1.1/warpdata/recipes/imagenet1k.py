"""
ImageNet-1k dataset recipe.

ImageNet-1k (ILSVRC2012) is a large-scale image classification dataset
with 1000 object categories.

Source: https://huggingface.co/datasets/ILSVRC/imagenet-1k
Paper: https://www.image-net.org/challenges/LSVRC/2012/

Splits:
- train: 1,281,167 images
- validation: 50,000 images

1000 object categories from WordNet hierarchy.
"""
from pathlib import Path
from typing import Tuple, Optional, Dict, List
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def imagenet1k(
    ctx: RecipeContext,
    repo_id: str = "ILSVRC/imagenet-1k",
    splits: Tuple[str, ...] = ("validation",),
    max_samples: int = None,
    image_root: Optional[str] = None,
) -> RecipeOutput:
    """
    Create ImageNet-1k image classification dataset.

    Downloads ImageNet-1k from HuggingFace. Each example contains an image
    and a label (0-999) for one of 1000 object categories.

    Note: This loads image metadata and references, not the raw image bytes,
    to keep the parquet file manageable.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        splits: Which splits to include ("train", "validation"). Default: ("validation",) only
        max_samples: Maximum samples per split (None = all). Use this to get a smaller slice

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - idx: int - Example index
        - label: int - Class label (0-999)
        - split: str - train/validation

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "imagenet1k",
        ...     "warpdata://vision/imagenet-1k",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://vision/imagenet-1k", as_format="pandas")
        >>> # Check label distribution
        >>> print(df['label'].value_counts())
    """
    # Normalize splits (CLI may pass a comma-delimited string via --param)
    if isinstance(splits, str):
        splits = tuple(s.strip() for s in splits.split(',') if s.strip())  # type: ignore

    # Optional: Directly build from a local image directory, if provided.
    if image_root:
        image_root_path = Path(image_root).expanduser().resolve()
        if not image_root_path.exists():
            raise FileNotFoundError(f"Image root not found: {image_root_path}")

        print(f"Building ImageNet-1k from local images at: {image_root_path}")
        print("Expected layout: <root>/{train|validation|val}/<class_dir>/*.jpg")

        # Map split synonyms
        split_aliases: Dict[str, List[str]] = {
            'train': ['train', 'training'],
            'validation': ['validation', 'val', 'valid']
        }

        # Build list of split directories to scan
        split_dirs: List[Tuple[str, Path]] = []
        for split_name in splits:
            candidates = split_aliases.get(split_name, [split_name])
            found = False
            for cand in candidates:
                p = image_root_path / cand
                if p.exists() and p.is_dir():
                    split_dirs.append((split_name, p))
                    found = True
                    break
            if not found:
                # If root directly contains class folders (no split subdir), accept it once
                if image_root_path.exists() and image_root_path.is_dir() and not split_dirs:
                    split_dirs.append((split_name, image_root_path))
                else:
                    print(f"Warning: split '{split_name}' not found under {image_root_path}")

        records: List[Dict] = []
        # Build deterministic class → label index per split from sorted class_dir names
        for split_name, sdir in split_dirs:
            class_dirs = sorted([d for d in sdir.iterdir() if d.is_dir()])
            if not class_dirs:
                print(f"Warning: No class folders under {sdir}")
                continue
            class_to_idx = {c.name: i for i, c in enumerate(class_dirs)}

            exts = {'.jpg', '.jpeg', '.png', '.JPG', '.JPEG', '.PNG'}
            idx_counter = 0
            for cdir in class_dirs:
                label_idx = class_to_idx[cdir.name]
                for f in cdir.rglob('*'):
                    if f.is_file() and f.suffix in exts:
                        records.append({
                            'idx': idx_counter,
                            'label': int(label_idx),
                            'split': split_name,
                            'class': cdir.name,
                            'image_path': str(f.resolve()),
                        })
                        idx_counter += 1

        if not records:
            raise RuntimeError(f"No images found under {image_root_path}")

        print(f"\nTotal images found: {len(records):,}")
        df = pd.DataFrame.from_records(records)
    else:
        print(f"Loading ImageNet-1k from {repo_id}...")
        if max_samples:
            print(f"Note: Limiting to {max_samples:,} samples per split")
        print("Note: Loading metadata only (not full images) to keep dataset manageable.")

        # Load all requested splits
        all_records = []

        for split_name in splits:
            print(f"\n  Loading {split_name} split...")

            # Use streaming if we have max_samples to avoid downloading everything
            if max_samples:
                ds = load_dataset(repo_id, split=split_name, streaming=True)
                print(f"  Processing up to {max_samples:,} images...")

                for idx, example in enumerate(ds):
                    if idx >= max_samples:
                        break

                    record = {
                        'idx': idx,
                        'label': int(example['label']),
                        'split': split_name,
                    }
                    all_records.append(record)

                    # Progress update every 1k for sampled data
                    if (idx + 1) % 1000 == 0:
                        print(f"    Processed {idx + 1:,} images...")
            else:
                ds = load_dataset(repo_id, split=split_name, streaming=False)
                print(f"  Processing {len(ds):,} images...")

                for idx, example in enumerate(ds):
                    # Store metadata only, not the actual image bytes
                    record = {
                        'idx': idx,
                        'label': int(example['label']),
                        'split': split_name,
                    }

                    all_records.append(record)

                    # Progress update every 100k
                    if (idx + 1) % 100000 == 0:
                        print(f"    Processed {idx + 1:,} images...")

        print(f"\nTotal images: {len(all_records):,}")
        # Create DataFrame
        df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "imagenet1k.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")
    print(f"\nSplit distribution:")
    print(df['split'].value_counts().to_string())
    print(f"\nLabel distribution (first 10 classes):")
    print(df['label'].value_counts().head(10).to_string())

    # Track raw data provenance
    raw_data_paths = []
    if image_root:
        raw_data_paths.append(Path(image_root).expanduser().resolve())
    else:
        hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
        if hf_cache.exists():
            raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_images': len(df),
            'splits': df['split'].value_counts().to_dict() if 'split' in df.columns else {},
            'num_classes': int(df['label'].nunique()) if 'label' in df.columns else None,
            'source': image_root if image_root else repo_id,
            'has_image_paths': bool('image_path' in df.columns),
        },
        raw_data=raw_data_paths,
    )
