"""
CoinGecko OHLCV (Candlestick) dataset recipe.

Downloads OHLCV candlestick data for crypto assets from CoinGecko API:
- Open, High, Low, Close prices
- Volume

Data fields per candle and asset:
- timestamp (YYYY-MM-DD HH:00:00, UTC)
- coin_id (coingecko id)
- symbol
- name
- open
- high
- low
- close
- volume

The recipe appends across runs and deduplicates on (timestamp, coin_id).

API key:
- Reads key from env: COINGECKO_API_KEY
- Pro API key required for /ohlc/range endpoint
- Uses x-cg-pro-api-key header

Notes:
- Uses /coins/{id}/ohlc/range endpoint (Pro API only)
- Daily interval: up to 180 days per request
- Hourly interval: up to 31 days per request
- Automatically chunks large date ranges
- Data available from Feb 9, 2018 onwards

Example:
    >>> import warpdata as wd
    >>> result = wd.run_recipe(
    ...     "coingecko_ohlcv",
    ...     "warpdata://crypto/coingecko/ohlcv",
    ...     start_date="2024-01-01",
    ...     end_date="2024-12-31",
    ...     coin_ids=["bitcoin", "ethereum", "solana"],
    ...     interval="daily",
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PUBLIC_API_BASE = "https://api.coingecko.com/api/v3"
PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"

# Top liquid coins that support OHLC endpoint
DEFAULT_COINS = [
    "bitcoin", "ethereum", "tether", "binancecoin", "solana", "ripple",
    "dogecoin", "cardano", "tron", "avalanche-2", "shiba-inu",
    "polkadot", "chainlink", "bitcoin-cash", "litecoin", "uniswap",
    "ethereum-classic", "stellar", "internet-computer", "dai", "usd-coin"
]


def _api_base(api_key: Optional[str]) -> str:
    return PRO_API_BASE if api_key else PUBLIC_API_BASE


_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""

                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                    raise RuntimeError(f"HTTP {code} for {full} :: {body}")

                if code in (401, 403) and PRO_API_BASE in url:
                    alt = url.replace(PRO_API_BASE, PUBLIC_API_BASE)
                    alt_req = urllib.request.Request(alt, headers=headers, method="GET")
                    try:
                        with urllib.request.urlopen(alt_req, timeout=timeout) as r2:
                            return json.loads(r2.read())
                    except:
                        pass

                raise RuntimeError(f"HTTP {code} for {full} :: {body}")

            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def _fetch_coin_info(coin_id: str, api_key: Optional[str], base: str) -> Optional[Dict[str, str]]:
    """Fetch basic coin info (symbol, name). Returns None if coin doesn't exist."""
    try:
        url = f"{base}/coins/{coin_id}"
        params = {"localization": "false", "tickers": "false", "market_data": "false", "community_data": "false", "developer_data": "false"}
        data = _http_get_json(url, params, api_key=api_key, timeout=10.0)
        return {
            "symbol": data.get("symbol", "").upper(),
            "name": data.get("name", ""),
            "id": coin_id
        }
    except Exception:
        return None


def _build_windows(start_date: str, end_date: str, interval: str) -> List[Tuple[str, str]]:
    """Build date windows based on API limits.

    Daily: max 180 days per request
    Hourly: max 31 days per request
    """
    from datetime import date as date_type

    start = date_type.fromisoformat(start_date)
    end = date_type.fromisoformat(end_date)

    # Determine window size based on interval
    window_days = 180 if interval == "daily" else 31

    windows = []
    current = start

    while current <= end:
        window_end = min(current + timedelta(days=window_days - 1), end)
        windows.append((current.isoformat(), window_end.isoformat()))
        current = window_end + timedelta(days=1)

    return windows


def coingecko_ohlcv(
    ctx: RecipeContext,
    start_date: str,
    end_date: str,
    *,
    coin_ids: Optional[List[str]] = None,
    interval: str = "daily",
    api_key: Optional[str] = None,
    max_workers: int = 5,
) -> RecipeOutput:
    """
    Create CoinGecko OHLCV (candlestick) dataset using /range endpoint.

    Downloads OHLC data for specified coins using the new /ohlc/range endpoint.

    Args:
        ctx: Recipe context
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        coin_ids: List of CoinGecko coin IDs (default: top 20 coins)
        interval: "daily" or "hourly" (default: "daily")
        api_key: CoinGecko Pro API key (or set COINGECKO_API_KEY env var) - REQUIRED
        max_workers: Max parallel workers (default: 5)

    Returns:
        RecipeOutput with OHLCV data

    Examples:
        >>> import warpdata as wd
        >>> # Get daily OHLCV for Bitcoin and Ethereum
        >>> result = wd.run_recipe(
        ...     "coingecko_ohlcv",
        ...     "warpdata://crypto/coingecko/ohlcv",
        ...     start_date="2024-01-01",
        ...     end_date="2024-12-31",
        ...     coin_ids=["bitcoin", "ethereum"],
        ...     interval="daily",
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")

    if not api_key:
        raise ValueError("CoinGecko Pro API key required for /ohlc/range endpoint. Set COINGECKO_API_KEY environment variable.")

    if interval not in ("daily", "hourly"):
        raise ValueError(f"Invalid interval: {interval}. Must be 'daily' or 'hourly'")

    base = _api_base(api_key)
    coin_ids = coin_ids or DEFAULT_COINS[:20]

    print(f"📊 Fetching CoinGecko OHLCV Data (/range endpoint)")
    print(f"  Date range: {start_date} to {end_date}")
    print(f"  Interval: {interval}")
    print(f"  Coins: {len(coin_ids)}")
    print(f"  Max workers: {max_workers}")

    # Parse dates
    start_dt = datetime.strptime(start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end_dt = datetime.strptime(end_date, "%Y-%m-%d").replace(hour=23, minute=59, second=59, tzinfo=timezone.utc)
    days_diff = (end_dt - start_dt).days + 1

    print(f"  Days: {days_diff}")

    # Check existing data for smart duplicate detection
    existing_df = None
    existing_coverage = {}
    out_file = ctx.work_dir / "coingecko_ohlcv.parquet"

    if out_file.exists():
        try:
            from ..api import load
            existing_df = load(ctx.dataset_id, as_format="pandas")
            print(f"\n  📦 Found existing dataset: {len(existing_df):,} records")

            # Track coverage per coin
            for coin_id in existing_df['coin_id'].unique():
                coin_data = existing_df[existing_df['coin_id'] == coin_id]
                min_ts = coin_data['timestamp'].min()
                max_ts = coin_data['timestamp'].max()
                existing_coverage[coin_id] = (str(min_ts)[:10], str(max_ts)[:10])
        except Exception as e:
            print(f"  ℹ️  No existing dataset: {e}")

    # Validate coin IDs and fetch metadata
    print(f"\n  📋 Validating coins and fetching metadata...")
    valid_coins = {}
    invalid_coins = []

    for i, coin_id in enumerate(coin_ids, 1):
        info = _fetch_coin_info(coin_id, api_key, base)
        if info:
            valid_coins[coin_id] = info
            if i % 10 == 0 or i == len(coin_ids):
                print(f"    [{i}/{len(coin_ids)}] ✓ {coin_id}: {info['symbol']} - {info['name']}")
        else:
            invalid_coins.append(coin_id)
            print(f"    [{i}/{len(coin_ids)}] ❌ {coin_id}: Invalid or not found")

    if not valid_coins:
        raise ValueError(f"No valid coins found. All {len(coin_ids)} coins are invalid.")

    print(f"\n  ✓ Validated {len(valid_coins)}/{len(coin_ids)} coins")
    if invalid_coins:
        print(f"  ⚠️  Skipped {len(invalid_coins)} invalid coins: {', '.join(invalid_coins[:10])}")

    coin_ids = list(valid_coins.keys())

    # Filter coins that need downloading with smart gap detection
    from datetime import date as date_type

    coins_to_fetch = []
    coins_skipped = []
    date_ranges_to_fetch = {}  # coin_id -> list of (start, end) tuples

    req_start = date_type.fromisoformat(start_date)
    req_end = date_type.fromisoformat(end_date)

    for coin_id in coin_ids:
        if coin_id in existing_coverage:
            exist_start_str, exist_end_str = existing_coverage[coin_id]
            exist_start = date_type.fromisoformat(exist_start_str)
            exist_end = date_type.fromisoformat(exist_end_str)

            # Check if fully covered
            if exist_start <= req_start and exist_end >= req_end:
                coins_skipped.append(coin_id)
                continue

            # Calculate gaps (partial coverage)
            gaps = []

            # Gap before existing data
            if req_start < exist_start:
                gap_end = min(exist_start - timedelta(days=1), req_end)
                if req_start <= gap_end:
                    gaps.append((req_start.isoformat(), gap_end.isoformat()))

            # Gap after existing data
            if req_end > exist_end:
                gap_start = max(exist_end + timedelta(days=1), req_start)
                if gap_start <= req_end:
                    gaps.append((gap_start.isoformat(), req_end.isoformat()))

            if gaps:
                coins_to_fetch.append(coin_id)
                date_ranges_to_fetch[coin_id] = gaps
        else:
            # New coin - fetch entire range
            coins_to_fetch.append(coin_id)
            date_ranges_to_fetch[coin_id] = [(start_date, end_date)]

    # Calculate total days to download for efficiency info
    total_days_to_download = 0
    for coin_id, ranges in date_ranges_to_fetch.items():
        for r_start, r_end in ranges:
            days = (date_type.fromisoformat(r_end) - date_type.fromisoformat(r_start)).days + 1
            total_days_to_download += days

    if coins_skipped:
        print(f"\n  ⚡ Skipping {len(coins_skipped)} coins (already have requested range)")

    if len(coins_to_fetch) > 0:
        print(f"\n  🔄 Fetching {len(coins_to_fetch)} coins (smart gap detection)")

        # Show efficiency info
        naive_days = len(coins_to_fetch) * ((req_end - req_start).days + 1)
        saved_days = naive_days - total_days_to_download
        if saved_days > 0:
            print(f"  💡 Gap detection saved {saved_days:,} days of downloads ({100 * saved_days / naive_days:.1f}% efficiency)")

        # Show gap info for first few coins
        gap_examples = list(date_ranges_to_fetch.items())[:3]
        for coin_id, gaps in gap_examples:
            if len(gaps) == 1 and gaps[0] == (start_date, end_date):
                print(f"     {coin_id}: full range (new coin)")
            else:
                gap_strs = [f"{s} to {e}" for s, e in gaps]
                print(f"     {coin_id}: {len(gaps)} gap(s) → {', '.join(gap_strs)}")
        if len(date_ranges_to_fetch) > 3:
            print(f"     ... and {len(date_ranges_to_fetch) - 3} more")

    if not coins_to_fetch:
        print(f"\n  ✅ All data already present, no API calls needed")
        if existing_df is not None and not existing_df.empty:
            return RecipeOutput(
                main=[out_file],
                metadata={"message": "All data already present", "existing_records": len(existing_df)}
            )

    # Fetch OHLC data using /range endpoint with per-coin date ranges
    def fetch_coin_ohlcv(coin_id: str) -> Tuple[str, List[Dict]]:
        try:
            all_records = []
            info = valid_coins.get(coin_id, {})

            # Get date ranges for this specific coin (may be gaps only)
            coin_ranges = date_ranges_to_fetch.get(coin_id, [(start_date, end_date)])

            for range_start, range_end in coin_ranges:
                # Build windows for this date range
                windows = _build_windows(range_start, range_end, interval)

                for window_start, window_end in windows:
                    url = f"{base}/coins/{coin_id}/ohlc/range"
                    params = {
                        "vs_currency": "usd",
                        "from": window_start,
                        "to": window_end,
                        "interval": interval
                    }

                    try:
                        data = _http_get_json(url, params, api_key=api_key, timeout=15.0)
                    except Exception as e:
                        # API error - skip this window
                        continue

                    if not data or not isinstance(data, list):
                        continue

                    for candle in data:
                        if len(candle) < 5:
                            continue

                        timestamp_ms, open_price, high_price, low_price, close_price = candle[:5]

                        # Volume is optional (6th element)
                        volume = candle[5] if len(candle) > 5 else 0

                        # Convert to datetime
                        ts = datetime.fromtimestamp(timestamp_ms / 1000, tz=timezone.utc)

                        record = {
                            'timestamp': ts.strftime('%Y-%m-%d %H:%M:%S'),
                            'coin_id': coin_id,
                            'symbol': info.get('symbol', ''),
                            'name': info.get('name', ''),
                            'open': open_price,
                            'high': high_price,
                            'low': low_price,
                            'close': close_price,
                            'volume': volume,
                        }
                        all_records.append(record)

            return coin_id, all_records

        except Exception as e:
            return coin_id, []

    # Parallel fetch
    print(f"\n  🚀 Fetching OHLCV data with {max_workers} workers...")
    all_records = []
    successful_coins = []
    failed_coins = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_coin_ohlcv, coin_id): coin_id for coin_id in coins_to_fetch}

        completed = 0
        for future in as_completed(futures):
            coin_id, records = future.result()
            completed += 1

            if records:
                all_records.extend(records)
                successful_coins.append(coin_id)
                print(f"  [{completed}/{len(coins_to_fetch)}] ✓ {coin_id}: {len(records)} candles")
            else:
                failed_coins.append(coin_id)
                print(f"  [{completed}/{len(coins_to_fetch)}] ⚠️  {coin_id}: No data")

    print(f"\n  📊 Summary:")
    print(f"    Successful: {len(successful_coins)}/{len(coins_to_fetch)} coins")
    print(f"    Failed: {len(failed_coins)}/{len(coins_to_fetch)} coins")
    if failed_coins and len(failed_coins) <= 10:
        print(f"    Failed coins: {', '.join(failed_coins)}")
    elif failed_coins:
        print(f"    Failed coins: {', '.join(failed_coins[:10])} ... and {len(failed_coins) - 10} more")

    if not all_records:
        if existing_df is not None and not existing_df.empty:
            print(f"\n  ⚠️  No new data collected, returning existing data")
            return RecipeOutput(
                main=[out_file],
                metadata={"message": "No new data collected", "existing_records": len(existing_df)}
            )
        else:
            raise ValueError(f"No data collected for any of the {len(coins_to_fetch)} coins.")

    print(f"\n  ✓ Collected {len(all_records):,} candles")

    # Create DataFrame
    df = pd.DataFrame(all_records)
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Merge with existing data
    if existing_df is not None and not existing_df.empty:
        print(f"\n  📦 Merging with existing data...")
        existing_df['timestamp'] = pd.to_datetime(existing_df['timestamp'])
        combined_df = pd.concat([existing_df, df], ignore_index=True)
        print(f"  Combined: {len(combined_df):,} records")

        # Deduplicate
        initial_count = len(combined_df)
        combined_df = combined_df.drop_duplicates(subset=['timestamp', 'coin_id'], keep='last')
        duplicates_removed = initial_count - len(combined_df)

        if duplicates_removed > 0:
            print(f"  🧹 Removed {duplicates_removed:,} duplicate records")

        df = combined_df

    # Sort
    df = df.sort_values(['timestamp', 'coin_id']).reset_index(drop=True)

    # Save
    df.to_parquet(out_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} candles")
    print(f"  📊 Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    print(f"  🪙 Unique coins: {df['coin_id'].nunique()}")

    readme = f"""# CoinGecko OHLCV Candlestick Data

## Overview
{interval.capitalize()} OHLC candlestick data from CoinGecko API (/range endpoint)

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Interval**: {interval}
- **Coins**: {len(coin_ids)}
- **Source**: CoinGecko API (Pro)

## Schema

| Column | Type | Description |
|--------|------|-------------|
| timestamp | datetime | Candle timestamp (UTC) |
| coin_id | string | CoinGecko coin ID |
| symbol | string | Coin ticker symbol |
| name | string | Coin name |
| open | float | Opening price (USD) |
| high | float | Highest price (USD) |
| low | float | Lowest price (USD) |
| close | float | Closing price (USD) |
| volume | float | Trading volume |

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("warpdata://crypto/coingecko/ohlcv", as_format="pandas")

# Calculate daily returns
df['daily_return'] = df.groupby('coin_id')['close'].pct_change()

# Find high volatility days
df['volatility'] = (df['high'] - df['low']) / df['open']
high_vol = df[df['volatility'] > 0.1]

# Doji candles (indecision)
df['is_doji'] = abs(df['open'] - df['close']) / (df['high'] - df['low']) < 0.1

# Bullish engulfing pattern
df['body'] = abs(df['close'] - df['open'])
df['prev_body'] = df.groupby('coin_id')['body'].shift(1)
```

## Statistics
- Total candles: {len(df):,}
- Date range: {df['timestamp'].min()} to {df['timestamp'].max()}
- Unique coins: {df['coin_id'].nunique()}
- Interval: {interval}
"""

    return RecipeOutput(
        main=[out_file],
        docs={"README.md": readme},
        metadata={
            "start_date": start_date,
            "end_date": end_date,
            "interval": interval,
            "records": len(df),
            "unique_coins": df['coin_id'].nunique(),
            "source": "CoinGecko API (Pro)",
        },
    )
