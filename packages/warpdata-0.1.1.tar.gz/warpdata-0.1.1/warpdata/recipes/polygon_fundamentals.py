"""
Polygon Fundamentals dataset recipe.

Fetches financial statements, company details, and fundamental data.
Includes: balance sheets, income statements, cash flow, ratios, ticker details.

Source: Polygon.io Reference & Financials API
"""
from pathlib import Path
from typing import List, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import pandas as pd
import sys
import os
import time
import multiprocessing as mp

from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset


def _etl_worker(result_queue: "mp.Queue", sys_path_entry: Optional[str], api_key: str, data_type: str, ticker: str, out_path: str, date: Optional[str] = None) -> None:
    """
    Subprocess worker that imports the Polygon ETL module and executes a single fetch
    call, writing results to the provided JSON path.

    Results are communicated back via `result_queue` as a dict with keys:
    - ok: bool
    - result: Any (only when ok=True)
    - error: str (only when ok=False)
    """
    try:
        # Ensure the external options_etl package is importable inside the subprocess
        if sys_path_entry:
            if sys_path_entry not in sys.path:
                sys.path.insert(0, sys_path_entry)
        from options_etl.polygon_etl_module import PolygonETLAPI  # type: ignore

        etl = PolygonETLAPI(api_key=api_key)

        method_map = {
            "ticker_details": "fetch_ticker_details",
            "balance_sheets": "fetch_balance_sheets",
            "income_statements": "fetch_income_statements",
            "cash_flow": "fetch_cash_flow_statements",
            "financial_ratios": "fetch_financial_ratios",
            "short_interest": "fetch_short_interest",
            "short_volume": "fetch_short_volume",
            "related_companies": "fetch_related_companies",
        }

        if data_type not in method_map:
            result_queue.put({"ok": False, "error": f"Unknown data type: {data_type}"})
            return

        method_name = method_map[data_type]
        fn = getattr(etl, method_name)

        kwargs: Dict[str, Any] = {"ticker": ticker, "out": out_path}
        if data_type == "ticker_details" and date:
            kwargs["date"] = date

        res = fn(**kwargs)
        result_queue.put({"ok": True, "result": res})
    except Exception as e:  # pragma: no cover - defensive
        result_queue.put({"ok": False, "error": str(e)})


def _run_etl_with_timeout(sys_path_entry: Optional[str], api_key: str, data_type: str, ticker: str, out_path: str, date: Optional[str], timeout_s: float) -> Dict[str, Any]:
    """
    Run a single ETL fetch in a subprocess with a hard timeout.
    Returns the result dict from the worker, or raises TimeoutError on deadline.
    """
    q: "mp.Queue" = mp.Queue()
    p = mp.Process(
        target=_etl_worker,
        args=(q, sys_path_entry, api_key, data_type, ticker, out_path, date),
        daemon=True,
    )
    p.start()
    p.join(timeout_s)
    if p.is_alive():
        try:
            p.terminate()
        finally:
            p.join(5)
        raise TimeoutError(f"{data_type}:{ticker} exceeded {timeout_s:.0f}s")
    if not q.empty():
        return q.get()
    return {"ok": False, "error": "No result returned from worker"}


def polygon_fundamentals(
    ctx: RecipeContext,
    tickers: List[str],
    *,
    data_types: Optional[List[str]] = None,
    date: Optional[str] = None,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_fundamentals",
    max_workers: int = 8,
) -> RecipeOutput:
    """
    Create Polygon Fundamentals dataset.

    Downloads financial statements and company metadata.

    Args:
        ctx: Recipe context
        tickers: List of tickers to fetch (e.g., ["AAPL", "MSFT", "TSLA"])
        data_types: List of data types to fetch:
            - "ticker_details": Company info, description, market cap
            - "balance_sheets": Balance sheet statements
            - "income_statements": Income statements (P&L)
            - "cash_flow": Cash flow statements
            - "financial_ratios": Financial ratios
            - "short_interest": Short interest data
            - "short_volume": Short volume data
            - "related_companies": Related/similar companies
            If None, fetches all available types
        date: Date for point-in-time data (YYYY-MM-DD, optional)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with fundamental data per ticker and data type

    Examples:
        >>> import warpdata as wd
        >>> # Fetch company details and financials
        >>> result = wd.run_recipe(
        ...     "polygon_fundamentals",
        ...     "warpdata://fundamentals/aapl",
        ...     tickers=["AAPL"],
        ...     data_types=["ticker_details", "income_statements"],
        ...     with_materialize=True
        ... )
        >>> # Fetch all fundamental data
        >>> result = wd.run_recipe(
        ...     "polygon_fundamentals",
        ...     "warpdata://fundamentals/tech-stocks",
        ...     tickers=["AAPL", "MSFT", "GOOGL"],
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL (parent directory must be on sys.path for options_etl.*)
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    sys_path_entry: Optional[str] = None
    if polygon_etl_path.exists():
        sys_path_entry = str(polygon_etl_path.parent)
        if sys_path_entry not in sys.path:
            sys.path.insert(0, sys_path_entry)

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    if not tickers:
        raise ValueError("Must specify at least one ticker")

    # Default to all data types if not specified
    # NOTE: Some endpoints are excluded by default as they often timeout
    if data_types is None:
        data_types = [
            "ticker_details",
            "balance_sheets",
            "income_statements",
            "cash_flow",
            "financial_ratios",
            # "related_companies",  # Often hangs/timeouts - enable manually if needed
            # "short_interest",     # Often hangs/timeouts - enable manually if needed
            # "short_volume",       # Often hangs/timeouts - enable manually if needed
        ]

    print(f"📊 Fetching Polygon Fundamentals")
    print(f"   Tickers: {', '.join(tickers)}")
    print(f"   Data Types: {', '.join(data_types)}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Per-type timeouts (seconds) to prevent hangs on slow endpoints
    def _tout(name: str, default: float) -> float:
        env_key = f"POLYGON_FUND_TIMEOUT_{name.upper()}"
        try:
            import os
            v = os.environ.get(env_key)
            return float(v) if v else default
        except Exception:
            return default

    per_type_timeout: Dict[str, float] = {
        # Tighter defaults; configurable via env POLYGON_FUND_TIMEOUT_<TYPE>
        "ticker_details": _tout("ticker_details", 10.0),
        "balance_sheets": _tout("balance_sheets", 60.0),
        "income_statements": _tout("income_statements", 60.0),
        "cash_flow": _tout("cash_flow", 60.0),
        "financial_ratios": _tout("financial_ratios", 60.0),
        "short_interest": _tout("short_interest", 45.0),
        "short_volume": _tout("short_volume", 45.0),
        "related_companies": _tout("related_companies", 30.0),
    }

    subdatasets = {}
    metadata = {
        "tickers": tickers,
        "data_types": data_types,
        "source": "Polygon.io Reference & Financials API",
    }
    if date:
        metadata["date"] = date

    # Helper to pick dedup keys based on data_type and available columns
    def _dedup_keys_for(dtype: str, cols: set[str]) -> list[str]:
        if dtype == "ticker_details":
            return [c for c in ["ticker"] if c in cols]
        if dtype in {"balance_sheets", "income_statements", "cash_flow", "financial_ratios"}:
            # Prefer explicit period keys commonly present in Polygon
            # 1) period_end (+ timeframe if exists)
            for cand in (["ticker", "period_end", "timeframe"], ["ticker", "period_end"]):
                if all(c in cols for c in cand):
                    return list(cand)
            # 2) fiscal_year + fiscal_quarter (+ timeframe if exists)
            for cand in (["ticker", "fiscal_year", "fiscal_quarter", "timeframe"], ["ticker", "fiscal_year", "fiscal_quarter"]):
                if all(c in cols for c in cand):
                    return list(cand)
            # 3) fallback keys
            for cand in (["ticker", "fiscal_date"], ["ticker", "start_date", "end_date"], ["ticker", "date"]):
                if all(c in cols for c in cand):
                    return list(cand)
            # ultimate fallback: ticker only
            return [c for c in ["ticker"] if c in cols]
        if dtype in {"short_interest", "short_volume"}:
            for cand in (["ticker", "date"],):
                if all(c in cols for c in cand):
                    return list(cand)
            return [c for c in ["ticker"] if c in cols]
        if dtype == "related_companies":
            for cand in (["ticker", "related_ticker"],):
                if all(c in cols for c in cand):
                    return list(cand)
            return [c for c in ["ticker"] if c in cols]
        return [c for c in ["ticker"] if c in cols]

    # Process each data type
    for data_type in data_types:
        print(f"\n📈 Processing {data_type}...")

        type_dir = raw_dir / data_type
        type_dir.mkdir(parents=True, exist_ok=True)

        all_records = []

        aborted = False

        # Define per-ticker task
        def fetch_one(ticker: str) -> Dict[str, Any]:
            json_file = type_dir / f"{ticker.lower()}.json"
            timeout_s = per_type_timeout.get(data_type, 120.0)
            start_ts = time.time()
            try:
                res = _run_etl_with_timeout(
                    sys_path_entry=sys_path_entry,
                    api_key=api_key,
                    data_type=data_type,
                    ticker=ticker,
                    out_path=str(json_file),
                    date=date,
                    timeout_s=timeout_s,
                )
                took = time.time() - start_ts
                return {"ticker": ticker, "ok": res.get("ok", False), "error": res.get("error"), "took": took}
            except TimeoutError as te:
                return {"ticker": ticker, "ok": False, "error": str(te), "took": time.time() - start_ts}
            except KeyboardInterrupt:
                raise
            except Exception as e:
                return {"ticker": ticker, "ok": False, "error": str(e), "took": time.time() - start_ts}

        # Run per-ticker fetches in parallel
        print(f"  🚀 Fetching {len(tickers)} tickers with {max_workers} workers...")
        try:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(fetch_one, t): t for t in tickers}
                completed = 0
                for fut in as_completed(futures):
                    r = fut.result()
                    completed += 1
                    if r.get("ok"):
                        print(f"  [{completed}/{len(tickers)}] ✓ {r['ticker']} ({r['took']:.1f}s)")
                    else:
                        print(f"  [{completed}/{len(tickers)}] ⚠️  {r['ticker']}: {r.get('error','unknown error')} ({r['took']:.1f}s)")
        except KeyboardInterrupt:
            print("    ⚠️  Aborted by user")
            aborted = True
        except Exception as e:
            print(f"    ⚠️  Parallel fetch error: {e}")

        # Load and process all fetched JSON files
        for ticker in tickers:
            json_file = type_dir / f"{ticker.lower()}.json"
            if json_file.exists():
                try:
                    with open(json_file) as f:
                        data = json.load(f)

                    # Handle different response structures
                    if data_type == "ticker_details":
                        # Single object
                        if isinstance(data, dict) and 'results' in data:
                            record = data['results']
                            record['ticker'] = ticker
                            all_records.append(record)
                        elif isinstance(data, dict):
                            record = data.copy()
                            record['ticker'] = ticker
                            all_records.append(record)

                    elif data_type in ["balance_sheets", "income_statements", "cash_flow", "financial_ratios"]:
                        # Financial statements - typically array of periods
                        if isinstance(data, dict) and 'results' in data:
                            results = data['results']
                            if isinstance(results, list):
                                for item in results:
                                    item['ticker'] = ticker
                                    all_records.append(item)
                            elif isinstance(results, dict):
                                results['ticker'] = ticker
                                all_records.append(results)
                        elif isinstance(data, list):
                            for item in data:
                                item['ticker'] = ticker
                                all_records.append(item)

                    elif data_type in ["short_interest", "short_volume"]:
                        # Time series data
                        if isinstance(data, dict) and 'results' in data:
                            results = data['results']
                            if isinstance(results, list):
                                for item in results:
                                    item['ticker'] = ticker
                                    all_records.append(item)

                    elif data_type == "related_companies":
                        # List of related tickers
                        if isinstance(data, list):
                            for item in data:
                                all_records.append({
                                    'ticker': ticker,
                                    'related_ticker': item
                                })
                        elif isinstance(data, dict) and 'results' in data:
                            for item in data['results']:
                                all_records.append({
                                    'ticker': ticker,
                                    'related_ticker': item
                                })

                except Exception as e:
                    print(f"    ⚠️  Failed to parse {json_file}: {e}")

        if aborted:
            # If user aborted, still write out any partial results for this data_type
            print("  ⚠️  Aborted during fetch; writing partial results if any...")

        # Save if we have data
        if all_records:
            print(f"\n  Total records for {data_type}: {len(all_records):,}")

            # Convert to DataFrame
            df = pd.DataFrame(all_records)

            # Append to existing dataset for this type if present, with safe dedup
            output_file = ctx.work_dir / f"polygon_fundamentals_{data_type}.parquet"
            if output_file.exists():
                try:
                    existing_df = pd.read_parquet(output_file)
                    print(f"  📎 Existing rows for {data_type}: {len(existing_df):,}")
                    df = pd.concat([existing_df, df], ignore_index=True)
                    # Deduplicate with type-aware keys
                    cols = set(df.columns)
                    keys = _dedup_keys_for(data_type, cols)
                    if keys:
                        before = len(df)
                        df = df.drop_duplicates(subset=keys, keep="last")
                        after = len(df)
                        if after != before:
                            print(f"  🧹 Dedup {data_type}: {before:,} -> {after:,} by {keys}")
                except Exception as e:
                    print(f"  ⚠️  Failed to read existing parquet for {data_type}: {e}")

            # Save to parquet (new or updated)
            df.to_parquet(output_file, index=False)

            print(f"  ✓ Saved to {output_file.name}")

            # Show sample
            if len(df) > 0:
                print(f"\n  📊 Sample columns: {list(df.columns[:10])}")
                if len(df.columns) > 10:
                    print(f"     ({len(df.columns) - 10} more columns...)")

            # Add to subdatasets
            subdatasets[data_type] = SubDataset(
                name=data_type,
                files=[output_file],
                description=f"{data_type.replace('_', ' ').title()} for {', '.join(tickers)}",
                metadata={
                    "data_type": data_type,
                    "records": len(df),
                    "columns": list(df.columns),
                    "tickers": tickers,
                }
            )
        else:
            print(f"  ⚠️  No data found for {data_type}")
        if aborted:
            break

    if not subdatasets:
        raise ValueError("No fundamental data downloaded")

    # Use first subdataset as main
    main_files = [list(subdatasets.values())[0].files[0]]

    # Generate documentation
    readme = f"""# Polygon Fundamentals Dataset

## Overview
Financial statements and company fundamentals from Polygon.io

## Configuration
- **Tickers**: {', '.join(tickers)}
- **Data Types**: {', '.join(data_types)}
{f"- **Date**: {date}" if date else ""}

## Data Types

### ticker_details
Company information including:
- Company name, description
- Market cap, shares outstanding
- Industry, sector
- Homepage URL, logo

### balance_sheets
Balance sheet statements showing:
- Assets (current, non-current, total)
- Liabilities (current, long-term, total)
- Equity
- Date of statement

### income_statements
Income statements (P&L) showing:
- Revenues
- Operating expenses
- Net income
- EPS
- Period covered

### cash_flow
Cash flow statements showing:
- Operating cash flow
- Investing cash flow
- Financing cash flow
- Net cash flow

### financial_ratios
Financial ratios including:
- P/E ratio, P/B ratio
- ROE, ROA
- Debt ratios
- Profit margins

### short_interest
Short interest data:
- Short shares
- Short percentage of float
- Days to cover

### short_volume
Daily short volume:
- Short volume
- Short exempt volume
- Total volume

### related_companies
Similar/related companies based on:
- Industry similarity
- Market correlation

## Usage

```python
import warpdata as wd

# Load ticker details
details = wd.load("warpdata://fundamentals/...-ticker_details", as_format="pandas")

# Load income statements
income = wd.load("warpdata://fundamentals/...-income_statements", as_format="pandas")

# Filter by ticker
aapl_income = income[income['ticker'] == 'AAPL']

# Sort by date
income_sorted = income.sort_values('fiscal_date', ascending=False)

# Calculate year-over-year growth
if 'revenues' in income.columns:
    income['revenue_growth'] = income.groupby('ticker')['revenues'].pct_change()
```

## Statistics
"""

    for name, subdataset in subdatasets.items():
        readme += f"\n### {name.replace('_', ' ').title()}\n"
        readme += f"- Records: {subdataset.metadata.get('records', 0):,}\n"
        readme += f"- Columns: {len(subdataset.metadata.get('columns', []))}\n"

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=main_files,
        subdatasets=subdatasets,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
