"""
CoinGecko Trending Coins dataset recipe.

Downloads trending coins data from CoinGecko API:
- Top trending search queries
- Top gainers/losers
- Most visited coins
- Market cap rank
- Price data

Data fields per timestamp and coin:
- timestamp (YYYY-MM-DD HH:00:00, UTC)
- coin_id
- symbol
- name
- market_cap_rank
- price_btc
- thumb (image URL)
- score (trending score)
- category (trending, top_gainer, top_loser)

The recipe collects snapshots hourly and deduplicates on (timestamp, coin_id, category).

API key:
- Reads key from env: COINGECKO_API_KEY
- Pro API key for x-cg-pro-api-key header

Example:
    >>> import warpdata as wd
    >>> result = wd.run_recipe(
    ...     "coingecko_trending",
    ...     "warpdata://crypto/coingecko/trending",
    ...     start_date="2024-01-01",
    ...     end_date="2024-12-31",
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Optional, List
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PUBLIC_API_BASE = "https://api.coingecko.com/api/v3"
PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"


def _api_base(api_key: Optional[str]) -> str:
    return PRO_API_BASE if api_key else PUBLIC_API_BASE


_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                if code in (401, 403) and PRO_API_BASE in url:
                    alt = url.replace(PRO_API_BASE, PUBLIC_API_BASE)
                    alt_req = urllib.request.Request(alt, headers=headers, method="GET")
                    try:
                        with urllib.request.urlopen(alt_req, timeout=timeout) as r2:
                            return json.loads(r2.read())
                    except:
                        pass
            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def coingecko_trending(
    ctx: RecipeContext,
    start_date: str,
    end_date: str,
    *,
    api_key: Optional[str] = None,
    interval_hours: int = 6,
    max_workers: int = 4,
) -> RecipeOutput:
    """
    Create CoinGecko Trending Coins dataset.

    Downloads snapshots of trending coins.

    Args:
        ctx: Recipe context
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        api_key: CoinGecko API key (or set COINGECKO_API_KEY env var)
        interval_hours: Hours between snapshots (default: 6 = 4 times per day)

    Returns:
        RecipeOutput with trending coins data

    Examples:
        >>> import warpdata as wd
        >>> # Get trending coins for 2024
        >>> result = wd.run_recipe(
        ...     "coingecko_trending",
        ...     "warpdata://crypto/coingecko/trending",
        ...     start_date="2024-01-01",
        ...     end_date="2024-12-31",
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")
    base = _api_base(api_key)

    print(f"🔥 Fetching CoinGecko Trending Coins")
    print(f"  Date range: {start_date} to {end_date}")
    print(f"  Interval: {interval_hours} hour(s)")

    # Parse dates
    start_dt = datetime.strptime(start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end_dt = datetime.strptime(end_date, "%Y-%m-%d").replace(hour=23, tzinfo=timezone.utc)

    # Generate timestamps
    current = start_dt
    timestamps = []
    while current <= end_dt:
        timestamps.append(current)
        current += timedelta(hours=interval_hours)

    print(f"  Total snapshots to collect: {len(timestamps)}")

    # Try to load existing data (prefer local stable file to avoid re-register churn)
    existing_df = None
    output_file = ctx.work_dir / "coingecko_trending.parquet"
    print(f"\n  🔄 Checking for existing data...")
    try:
        if output_file.exists():
            existing_df = pd.read_parquet(output_file)
            print(f"  ✓ Found local file: {len(existing_df):,} records")
        else:
            from ..api import load
            dataset_uri = ctx.dataset_id
            existing_df = load(dataset_uri, as_format="pandas")
            print(f"  ✓ Found registry dataset: {len(existing_df):,} records")
    except Exception as load_err:
        print(f"  ℹ️  No existing dataset to merge: {load_err}")

    if existing_df is not None and not existing_df.empty and 'timestamp' in existing_df.columns:
        existing_df['timestamp'] = pd.to_datetime(existing_df['timestamp'])
        try:
            tz_none = existing_df['timestamp'].dt.tz is None
        except Exception:
            tz_none = True
        existing_timestamps = set(existing_df['timestamp'].dt.tz_localize('UTC' if tz_none else None))
        timestamps = [ts for ts in timestamps if ts not in existing_timestamps]
        print(f"  ℹ️  Filtering out {len(existing_timestamps)} existing timestamps")
        print(f"  ⬇️  New snapshots to fetch: {len(timestamps)}")

    if not timestamps:
        print(f"\n  ✅ All timestamps already collected!")
        if existing_df is not None:
            output_file = ctx.work_dir / "coingecko_trending.parquet"
            existing_df.to_parquet(output_file, index=False)
            return RecipeOutput(
                main=[output_file],
                metadata={"message": "No new data to fetch"}
            )
        else:
            raise ValueError("No timestamps to fetch and no existing data")

    # Collect snapshots (concurrently in batches)
    records: List[Dict[str, Any]] = []
    total = len(timestamps)
    print(f"\n  🚀 Collecting {total} snapshots with up to {max_workers} workers...")

    def fetch_one(ts):
        try:
            url = f"{base}/search/trending"
            data = _http_get_json(url, api_key=api_key)
            if 'coins' not in data:
                return []
            rows = []
            for coin_data in data['coins']:
                item = coin_data.get('item', {})
                rows.append({
                    'timestamp': ts.strftime('%Y-%m-%d %H:%M:%S'),
                    'coin_id': item.get('id', ''),
                    'symbol': item.get('symbol', ''),
                    'name': item.get('name', ''),
                    'market_cap_rank': item.get('market_cap_rank', 0),
                    'price_btc': item.get('price_btc', 0),
                    'thumb': item.get('thumb', ''),
                    'score': item.get('score', 0),
                    'category': 'trending'
                })
            return rows
        except Exception:
            return []

    processed = 0
    batch_size = max(max_workers * 25, 100)
    for start_idx in range(0, total, batch_size):
        batch = timestamps[start_idx:start_idx + batch_size]
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futs = [pool.submit(fetch_one, ts) for ts in batch]
            for fut in as_completed(futs):
                rows = fut.result() or []
                records.extend(rows)
                processed += 1
                if processed % 50 == 0 or processed == total:
                    print(f"  [{processed}/{total}] ✓ Collected {len(records)} records")

    if not records:
        raise ValueError("No data collected")

    print(f"\n  ✓ Collected {len(records):,} records")

    # Create DataFrame
    df = pd.DataFrame(records)
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Merge with existing data
    if existing_df is not None and not existing_df.empty:
        print(f"\n  📦 Merging with existing data...")
        combined_df = pd.concat([existing_df, df], ignore_index=True)
        print(f"  Combined: {len(combined_df):,} records")

        # Deduplicate
        initial_count = len(combined_df)
        combined_df = combined_df.drop_duplicates(subset=['timestamp', 'coin_id', 'category'], keep='last')
        duplicates_removed = initial_count - len(combined_df)

        if duplicates_removed > 0:
            print(f"  🧹 Removed {duplicates_removed:,} duplicate records")

        df = combined_df

    # Sort by timestamp
    df = df.sort_values(['timestamp', 'score'], ascending=[True, False]).reset_index(drop=True)

    # Save
    # Save
    output_file = ctx.work_dir / "coingecko_trending.parquet"
    df.to_parquet(output_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} records")
    print(f"  📊 Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    print(f"  🔥 Unique trending coins: {df['coin_id'].nunique()}")

    # Show most frequent trending coins
    top_trending = df['coin_id'].value_counts().head(5)
    print(f"\n  Most frequently trending:")
    for coin, count in top_trending.items():
        print(f"    {coin}: {count} times")

    readme = f"""# CoinGecko Trending Coins

## Overview
Trending coins data from CoinGecko API (top searches, most visited)

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Interval**: {interval_hours} hour(s)
- **Source**: CoinGecko API

## Schema

| Column | Type | Description |
|--------|------|-------------|
| timestamp | datetime | Snapshot timestamp (UTC) |
| coin_id | string | CoinGecko coin ID |
| symbol | string | Coin ticker symbol |
| name | string | Coin name |
| market_cap_rank | int | Market cap rank |
| price_btc | float | Price in BTC |
| thumb | string | Thumbnail image URL |
| score | int | Trending score (0-7) |
| category | string | Category (trending, top_gainer, top_loser) |

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("warpdata://crypto/coingecko/trending", as_format="pandas")

# Find coins that trend frequently
frequent_trending = df.groupby('coin_id').size().sort_values(ascending=False)

# Get trending coins from last snapshot
latest_trending = df[df['timestamp'] == df['timestamp'].max()]

# Track trending score over time
coin_trends = df[df['coin_id'] == 'bitcoin'].set_index('timestamp')['score']

# Find new trending coins (first time appearing)
first_appearances = df.groupby('coin_id')['timestamp'].min()
```

## Statistics
- Total records: {len(df):,}
- Date range: {df['timestamp'].min()} to {df['timestamp'].max()}
- Unique trending coins: {df['coin_id'].nunique()}
- Snapshots collected: {df['timestamp'].nunique()}
"""

    return RecipeOutput(
        main=[output_file],
        docs={"README.md": readme},
        metadata={
            "start_date": start_date,
            "end_date": end_date,
            "records": len(df),
            "unique_coins": df['coin_id'].nunique(),
            "source": "CoinGecko API",
        },
    )
