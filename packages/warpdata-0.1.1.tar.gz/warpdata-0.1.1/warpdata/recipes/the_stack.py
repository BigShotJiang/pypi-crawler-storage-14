"""
The Stack v1 code dataset recipe.

This recipe builds a code corpus from the HuggingFace dataset
``bigcode/the-stack``. Unlike The Stack v2, this dataset already
contains file contents in a ``content`` column, so we can stream it
directly without going through Software Heritage S3.

Reference dataset card:
    https://huggingface.co/datasets/bigcode/the-stack

Core columns (from dataset card / schema preview):
    - hexsha: str      – file hash
    - size: int        – file size in bytes
    - ext: str         – file extension (e.g., ".py")
    - lang: str        – language name (e.g., "Python")
    - max_stars_repo_path: str
    - max_stars_repo_name: str
    - max_stars_repo_licenses: list[str]
    - content: str     – full file text
    - avg_line_length: float
    - max_line_length: int
    - alphanum_fraction: float

Design goals:
    - Filter by language via the ``lang`` column.
    - Support a global ``limit`` (number of files) and/or ``target_gb``
      (approximate bytes of ``content``) to bound the corpus size.
    - Stream the HF dataset and write Parquet in chunks for bounded
      memory usage.
    - Allow explicit selection of Parquet shards via ``data_files`` so
      callers can avoid HF-flagged unsafe files if desired.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Set
import json
from collections import Counter

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from datasets import load_dataset

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    tqdm = None

from ..api.recipes import RecipeContext
from .base import RecipeOutput


WRITE_CHUNK_SIZE = 50_000


def the_stack(
    ctx: RecipeContext,
    repo_id: str = "bigcode/the-stack",
    split: str = "train",
    languages: Optional[List[str]] = None,
    limit: Optional[int] = None,
    target_gb: Optional[float] = None,
    data_files: Optional[Dict[str, List[str]]] = None,
    chunk_size: int = 100_000,
) -> RecipeOutput:
    """
    Create a filtered The Stack v1 code dataset.

    Args:
        ctx: Recipe context.
        repo_id: HF dataset ID (default: 'bigcode/the-stack').
        split: HF split (default: 'train').
        languages: Optional list of values for the ``lang`` column
            (e.g., ['Python', 'C++']). If provided, keep only rows where
            ``lang`` is in this list. Accepts a comma-separated string
            when called from the CLI.
        limit: Global cap on number of files (documents). Mutually
            exclusive with target_gb.
        target_gb: Approximate cap on total text size (in GB) based on
            UTF-8 bytes of the ``content`` field.
        data_files: Optional dict passed to `load_dataset` to select
            specific Parquet shards (e.g., to exclude HF-flagged unsafe
            files). Example:

                data_files={"train": ["train-00000-of-02000.parquet", ...]}

        chunk_size: Number of records per Parquet chunk when writing
            out. Larger chunks are more efficient but use more memory.

    Returns:
        RecipeOutput with a single Parquet file containing:
            - hexsha: str
            - size: int
            - ext: str
            - lang: str
            - max_stars_repo_path: str
            - max_stars_repo_name: str
            - max_stars_repo_licenses_json: str
            - content: str
            - avg_line_length: float
            - max_line_length: int
            - alphanum_fraction: float
    """
    if limit is not None and target_gb is not None:
        raise ValueError("Specify only one of limit (files) or target_gb (GB), not both.")

    # Normalize languages to a set; accept comma-separated string for CLI convenience.
    if languages is not None:
        if isinstance(languages, str):
            raw_langs = [part.strip() for part in languages.split(",") if part.strip()]
        else:
            raw_langs = list(languages)
        lang_set: Optional[Set[str]] = {str(lang) for lang in raw_langs}
    else:
        lang_set = None

    print(f"📚 Loading The Stack v1 from {repo_id} (split={split})")
    if lang_set:
        print(f"   Restricting to languages: {sorted(lang_set)}")
    if limit is not None:
        print(f"   Global file limit: {limit:,}")
    if target_gb is not None:
        total_bytes_budget = int(target_gb * (1024**3))
        print(f"   Global text byte budget: ~{target_gb:.2f} GB ({total_bytes_budget:,} bytes)")
    else:
        total_bytes_budget = None

    # Streaming dataset from HF; data_files can be used to select/exclude shards.
    ds = load_dataset(
        repo_id,
        split=split,
        streaming=True,
        data_files=data_files,
    )

    out_path = ctx.work_dir / "the_stack.parquet"
    writer: Optional[pq.ParquetWriter] = None
    chunk_records: List[Dict[str, Any]] = []
    total_files = 0
    total_bytes = 0
    lang_counts: Counter[str] = Counter()
    lang_bytes: Counter[str] = Counter()

    def flush_chunk():
        nonlocal writer, chunk_records
        if not chunk_records:
            return
        df = pd.DataFrame(chunk_records)
        table = pa.Table.from_pandas(df, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(out_path, table.schema)
        writer.write_table(table)
        chunk_records.clear()

    if tqdm is not None:
        data_iter = tqdm(ds, desc="Streaming The Stack v1", unit="file")
    else:
        data_iter = ds

    for i, ex in enumerate(data_iter):
        # Language filter
        lang = str(ex.get("lang", "") or "")
        if lang_set is not None and lang not in lang_set:
            continue

        content = str(ex.get("content", ""))
        text_bytes = len(content.encode("utf-8", errors="ignore"))

        # Apply limits before adding to buffer where possible
        if limit is not None and total_files >= limit:
            print(f"   Reached file limit: {total_files:,}")
            break
        if total_bytes_budget is not None and total_bytes + text_bytes > total_bytes_budget:
            print(
                f"   Reached byte budget after adding file {total_files + 1:,}: "
                f"{(total_bytes + text_bytes) / (1024**3):.2f} GB"
            )
            # Optionally still include this last file
            # record will still be added below.

        max_stars_repo_licenses = ex.get("max_stars_repo_licenses", []) or []

        record: Dict[str, Any] = {
            "hexsha": str(ex.get("hexsha", "")),
            "size": int(ex.get("size", 0) or 0),
            "ext": str(ex.get("ext", "")),
            "lang": lang,
            "max_stars_repo_path": str(ex.get("max_stars_repo_path", "")),
            "max_stars_repo_name": str(ex.get("max_stars_repo_name", "")),
            "max_stars_repo_licenses_json": json.dumps(max_stars_repo_licenses, ensure_ascii=False),
            "content": content,
            "avg_line_length": float(ex.get("avg_line_length", 0.0) or 0.0),
            "max_line_length": int(ex.get("max_line_length", 0) or 0),
            "alphanum_fraction": float(ex.get("alphanum_fraction", 0.0) or 0.0),
        }

        chunk_records.append(record)
        total_files += 1
        total_bytes += text_bytes
        lang_counts[lang] += 1
        lang_bytes[lang] += text_bytes

        if chunk_size and len(chunk_records) >= chunk_size:
            flush_chunk()

        if total_files % 50_000 == 0:
            # Update tqdm postfix with GB and a few top languages
            if tqdm is not None and isinstance(data_iter, tqdm):
                top_langs = lang_counts.most_common(3)
                postfix = {
                    "GB": f"{total_bytes / (1024**3):.2f}",
                }
                for lng, cnt in top_langs:
                    gb_l = lang_bytes[lng] / (1024**3)
                    postfix[lng] = f"{cnt} ({gb_l:.2f}GB)"
                data_iter.set_postfix(postfix)

            print(
                f"   Processed {total_files:,} files "
                f"(~{total_bytes / (1024**3):.2f} GB of text)"
            )

        if limit is not None and total_files >= limit:
            print(f"   Reached file limit: {total_files:,}")
            break
        if total_bytes_budget is not None and total_bytes >= total_bytes_budget:
            print(
                f"   Reached text byte budget: "
                f"{total_bytes / (1024**3):.2f} GB after {total_files:,} files"
            )
            break

    flush_chunk()
    if writer is not None:
        writer.close()

    print(
        f"\n✅ Completed The Stack v1 recipe with {total_files:,} files "
        f"and ~{total_bytes / (1024**3):.2f} GB of text"
    )
    print(f"Saved to {out_path}")

    # Provenance: HF cache root
    raw_data_paths: List[Path] = []
    hf_cache_root = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache_root.exists():
        raw_data_paths.append(hf_cache_root)

    return RecipeOutput(
        main=[out_path],
        metadata={
            "total_files": total_files,
            "total_text_bytes": total_bytes,
            "repo_id": repo_id,
            "split": split,
            "languages": sorted(lang_set) if lang_set else None,
            "limit": limit,
            "target_gb": target_gb,
        },
        raw_data=raw_data_paths,
    )
