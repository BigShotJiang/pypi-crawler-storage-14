"""
Polygon Intraday dataset recipe.

Fetches minute/second-level bars for stocks and options.
Useful for intraday analysis, backtesting, and high-frequency strategies.

Source: Polygon.io Aggregates API
"""
from pathlib import Path
from typing import List, Optional
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset


def polygon_intraday(
    ctx: RecipeContext,
    tickers: List[str],
    start_date: str,
    end_date: str,
    *,
    timespan: str = "minute",
    multiplier: int = 1,
    asset_type: str = "stocks",
    adjusted: bool = True,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_intraday",
) -> RecipeOutput:
    """
    Create Polygon Intraday dataset with minute/second bars.

    Downloads intraday bars (OHLCV) for specific tickers.

    Args:
        ctx: Recipe context
        tickers: List of tickers to fetch (e.g., ["SPY", "QQQ", "AAPL"])
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        timespan: Bar timespan - "minute", "second", "hour" (default: "minute")
        multiplier: Timespan multiplier (e.g., 5 for 5-minute bars) (default: 1)
        asset_type: "stocks" or "options" (default: "stocks")
        adjusted: Whether to use adjusted prices (default: True)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with intraday bar data per ticker

    Examples:
        >>> import warpdata as wd
        >>> # Fetch 5-minute bars for SPY
        >>> result = wd.run_recipe(
        ...     "polygon_intraday",
        ...     "warpdata://intraday/spy-5min",
        ...     tickers=["SPY"],
        ...     start_date="2025-01-17",
        ...     end_date="2025-01-17",
        ...     timespan="minute",
        ...     multiplier=5,
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    if not tickers:
        raise ValueError("Must specify at least one ticker")

    print(f"📊 Fetching Polygon Intraday data from {start_date} to {end_date}")
    print(f"   Tickers: {', '.join(tickers)}")
    print(f"   Timespan: {multiplier} {timespan}")
    print(f"   Asset Type: {asset_type}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    subdatasets = {}
    metadata = {
        "start_date": start_date,
        "end_date": end_date,
        "tickers": tickers,
        "timespan": f"{multiplier} {timespan}",
        "asset_type": asset_type,
        "source": "Polygon.io Aggregates API",
        "data_type": "intraday_bars",
    }

    # Process each ticker
    for ticker in tickers:
        print(f"\n📈 Processing {ticker}...")

        ticker_dir = raw_dir / asset_type / ticker.lower()
        ticker_dir.mkdir(parents=True, exist_ok=True)

        json_file = ticker_dir / f"{start_date}_to_{end_date}_{multiplier}{timespan}.json"

        # Fetch if not cached
        if not json_file.exists():
            try:
                if asset_type == "stocks":
                    result = etl.fetch_stock_custom_bars(
                        ticker=ticker,
                        multiplier=multiplier,
                        timespan=timespan,
                        from_date=start_date,
                        to_date=end_date,
                        adjusted=adjusted,
                        out=str(json_file)
                    )
                else:  # options
                    result = etl.fetch_custom_bars(
                        ticker=ticker,
                        multiplier=multiplier,
                        timespan=timespan,
                        from_date=start_date,
                        to_date=end_date,
                        adjusted=adjusted,
                        out=str(json_file)
                    )
                print(f"  ✓ Fetched {result.get('count', 0)} bars")
            except Exception as e:
                print(f"  ⚠️  Error: {e}")
                continue

        # Load and process
        if json_file.exists():
            try:
                with open(json_file) as f:
                    data = json.load(f)

                # Handle both list and dict responses
                if isinstance(data, list):
                    raw_results = data
                elif isinstance(data, dict):
                    raw_results = data.get('results', [])
                else:
                    raw_results = []

                if raw_results:
                    # Convert to DataFrame
                    df = pd.DataFrame(raw_results)

                    # Rename columns from Polygon format
                    column_mapping = {
                        'v': 'volume',
                        'vw': 'vwap',
                        'o': 'open',
                        'c': 'close',
                        'h': 'high',
                        'l': 'low',
                        't': 'timestamp_ms',
                        'n': 'transactions',
                    }

                    df = df.rename(columns=column_mapping)

                    # Add ticker column
                    df['ticker'] = ticker

                    # Convert timestamp to datetime
                    if 'timestamp_ms' in df.columns:
                        df['timestamp'] = pd.to_datetime(df['timestamp_ms'], unit='ms')

                    # Select and order columns
                    final_columns = ['timestamp', 'ticker', 'open', 'high', 'low', 'close',
                                   'volume', 'vwap', 'transactions', 'timestamp_ms']
                    df = df[[col for col in final_columns if col in df.columns]]

                    # Save to parquet
                    output_file = ctx.work_dir / f"polygon_intraday_{ticker.lower()}.parquet"
                    df.to_parquet(output_file, index=False)

                    print(f"  ✓ Saved {len(df):,} bars to {output_file.name}")
                    print(f"\n  📊 Sample data:")
                    print(df.head(3).to_string())

                    # Add to subdatasets
                    subdatasets[ticker.lower()] = SubDataset(
                        name=ticker.lower(),
                        files=[output_file],
                        description=f"Intraday {multiplier}{timespan} bars for {ticker}",
                        metadata={
                            "ticker": ticker,
                            "bars": len(df),
                            "timespan": f"{multiplier} {timespan}",
                            "date_range": f"{df['timestamp'].min()} to {df['timestamp'].max()}",
                        }
                    )
                else:
                    print(f"  ⚠️  No data found")

            except Exception as e:
                print(f"  ⚠️  Failed to process {json_file}: {e}")

    if not subdatasets:
        raise ValueError("No intraday data downloaded")

    # Use first ticker's data as main dataset
    main_files = [list(subdatasets.values())[0].files[0]]

    # Generate documentation
    readme = f"""# Polygon Intraday Dataset

## Overview
Intraday {multiplier} {timespan} bars from Polygon.io

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Tickers**: {', '.join(tickers)}
- **Timespan**: {multiplier} {timespan}
- **Asset Type**: {asset_type}
- **Adjusted**: {adjusted}

## Schema

| Column | Type | Description |
|--------|------|-------------|
| timestamp | datetime | Bar timestamp |
| ticker | string | Ticker symbol |
| open | float | Opening price |
| high | float | Highest price |
| low | float | Lowest price |
| close | float | Closing price |
| volume | int | Trading volume |
| vwap | float | Volume-weighted average price |
| transactions | int | Number of transactions |
| timestamp_ms | int | Unix timestamp in milliseconds |

## Usage

```python
import warpdata as wd

# Load intraday data
df = wd.load("warpdata://intraday/...", as_format="pandas")

# Resample to different timeframe
df_hourly = df.set_index('timestamp').resample('1H').agg({
    'open': 'first',
    'high': 'max',
    'low': 'min',
    'close': 'last',
    'volume': 'sum'
})

# Calculate returns
df['returns'] = df['close'].pct_change()

# Filter market hours
df_market = df[df['timestamp'].dt.hour.between(9, 16)]
```

## Statistics
"""

    for name, subdataset in subdatasets.items():
        readme += f"\n### {name.upper()}\n"
        readme += f"- Bars: {subdataset.metadata.get('bars', 0):,}\n"
        readme += f"- Date Range: {subdataset.metadata.get('date_range', 'N/A')}\n"

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=main_files,
        subdatasets=subdatasets,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
