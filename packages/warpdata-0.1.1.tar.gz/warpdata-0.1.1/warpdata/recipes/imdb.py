"""
IMDB dataset recipe.

IMDB is a binary sentiment classification dataset containing movie reviews.

Source: https://huggingface.co/datasets/imdb
Paper: https://ai.stanford.edu/~amaas/data/sentiment/

Splits:
- train: 25,000 reviews
- test: 25,000 reviews
- unsupervised: 50,000 unlabeled reviews

Sentiment:
- 0: Negative
- 1: Positive
"""
from pathlib import Path
from typing import Tuple
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def imdb(
    ctx: RecipeContext,
    repo_id: str = "imdb",
    splits: Tuple[str, ...] = ("train", "test"),
) -> RecipeOutput:
    """
    Create IMDB sentiment classification dataset.

    Downloads IMDB from HuggingFace. Each review has text and a binary
    sentiment label (positive/negative).

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        splits: Which splits to include ("train", "test", "unsupervised")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - text: str - Review text
        - label: int - Sentiment (0=Negative, 1=Positive, -1=Unlabeled)
        - label_name: str - Sentiment name
        - split: str - train/test/unsupervised

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "imdb",
        ...     "warpdata://nlp/imdb",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/imdb", as_format="pandas")
        >>> # Filter by sentiment
        >>> positive = df[df['label'] == 1]
    """
    print(f"Loading IMDB from {repo_id}...")

    # Label names
    label_names = {0: 'Negative', 1: 'Positive', -1: 'Unlabeled'}

    # Load all requested splits
    all_records = []

    for split_name in splits:
        print(f"  Loading {split_name} split...")
        ds = load_dataset(repo_id, split=split_name)

        print(f"  Processing {len(ds):,} reviews...")

        for example in ds:
            # Unsupervised split has label=-1
            label = int(example['label']) if example['label'] >= 0 else -1

            record = {
                'text': str(example['text']),
                'label': label,
                'label_name': label_names[label],
                'split': split_name,
            }

            all_records.append(record)

    print(f"\nTotal reviews: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "imdb.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")
    print(f"\nSplit distribution:")
    print(df['split'].value_counts().to_string())
    print(f"\nSentiment distribution:")
    print(df['label_name'].value_counts().to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_reviews': len(df),
            'splits': df['split'].value_counts().to_dict(),
            'sentiments': df['label_name'].value_counts().to_dict(),
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
