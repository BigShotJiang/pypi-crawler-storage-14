"""
GloVe word embeddings dataset recipe.

GloVe (Global Vectors for Word Representation) provides pre-trained word embeddings
learned from large text corpora using co-occurrence statistics.

This recipe parses GloVe embeddings from the standard text format where each line is:
word dim1 dim2 dim3 ... dimN

Default source: Custom trained embeddings from Dolma corpus
See also: https://nlp.stanford.edu/projects/glove/

Contains:
- 1.2M vocabulary
- 300-dimensional embeddings
"""
from pathlib import Path
import pandas as pd
import numpy as np

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def glove(
    ctx: RecipeContext,
    embeddings_file: str = "recipes_raw_data/glove/dolma_300_2024_1.2M.100_combined.txt",
    dimension: int = 300,
) -> RecipeOutput:
    """
    Create GloVe word embeddings dataset.

    Parses GloVe embeddings from text format into a structured dataset with
    word-to-embedding mappings. Each word gets a row with its token and embedding vector.

    Args:
        ctx: Recipe context
        embeddings_file: Path to GloVe embeddings file (relative to workspace root)
        dimension: Expected embedding dimension (default: 300)

    Returns:
        RecipeOutput with embeddings dataset

    Dataset columns:
        - word: str - The word/token
        - embedding: list[float] - The embedding vector (dimension=300)

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "glove",
        ...     "warpdata://nlp/glove-dolma-300d",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/glove-dolma-300d", as_format="pandas")
        >>> # Look up embedding for a word
        >>> word_embed = df[df['word'] == 'the']['embedding'].iloc[0]
        >>> # Find most common words
        >>> df.head(100)  # GloVe typically ordered by frequency
    """
    # Resolve embeddings file path
    embeddings_path = Path(embeddings_file)
    if not embeddings_path.is_absolute():
        # Try relative to workspace root
        embeddings_path = Path.cwd() / embeddings_file

    if not embeddings_path.exists():
        raise FileNotFoundError(
            f"GloVe embeddings file not found: {embeddings_path}\n"
            f"Please ensure the file exists at: {embeddings_file}"
        )

    print(f"Loading GloVe embeddings from {embeddings_path}...")
    print(f"  Expected dimension: {dimension}")
    print(f"  File size: {embeddings_path.stat().st_size / (1024**3):.2f} GB")

    # Parse embeddings file
    all_records = []
    errors = 0

    with open(embeddings_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            if line_num % 100000 == 0:
                print(f"  Processed {line_num:,} words...")

            parts = line.strip().split()
            if len(parts) != dimension + 1:
                errors += 1
                if errors <= 5:  # Only show first few errors
                    print(f"  Warning: Line {line_num} has {len(parts)-1} dims (expected {dimension})")
                continue

            word = parts[0]
            embedding = [float(x) for x in parts[1:]]

            all_records.append({
                'word': word,
                'embedding': embedding,
            })

    print(f"\nTotal words: {len(all_records):,}")
    if errors > 0:
        print(f"Skipped {errors:,} malformed lines")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Add statistics
    print(f"\nDataset statistics:")
    print(f"  Vocabulary size: {len(df):,}")
    print(f"  Embedding dimension: {dimension}")
    print(f"  Total parameters: {len(df) * dimension:,}")

    # Show sample words
    print(f"\nSample words (first 10):")
    for word in df['word'].head(10):
        print(f"  - {word}")

    # Write to output
    output_path = ctx.work_dir / "glove.parquet"
    df.to_parquet(output_path, index=False)

    print(f"\nSaved to {output_path}")

    # Track raw data provenance
    raw_data_paths = [embeddings_path]

    return RecipeOutput(
        main=[output_path],
        metadata={
            'vocabulary_size': len(df),
            'embedding_dimension': dimension,
            'total_parameters': len(df) * dimension,
            'source_file': str(embeddings_path),
            'errors_skipped': errors,
        },
        raw_data=raw_data_paths,
    )
