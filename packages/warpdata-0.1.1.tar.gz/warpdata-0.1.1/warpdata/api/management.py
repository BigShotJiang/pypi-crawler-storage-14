"""
Dataset management API for warpdata.

Provides functions for:
- Registering datasets
- Listing datasets
- Getting dataset info
- Materializing datasets
- Removing datasets
"""
import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Union

from ..core.uris import parse_uri, split_dataset_id
from ..core.registry import get_registry
from ..core.cache import get_cache
from ..core.utils import compute_hash
from ..io.fsspec_fs import get_filesystem
from ..engine.duck import get_engine
from ..io.fsspec_fs import get_filesystem
from ..core.storage import compute_content_hash


def register_dataset(
    dataset_id: str,
    resources: List[str],
    schema: Optional[Dict[str, str]] = None,
    file_format: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    raw_data: Optional[List[str]] = None,
    storage_backend: str = "local",
    upload_to_storage: bool = False,
) -> str:
    """
    Register a new dataset version in the registry.

    Args:
        dataset_id: Dataset ID (e.g., 'warpdata://nlp/imdb')
        resources: List of resource URIs (files that make up the dataset)
        schema: Optional schema dictionary (auto-inferred if not provided)
        metadata: Optional metadata dictionary
        raw_data: Optional list of raw data source paths (for provenance tracking)
        storage_backend: Storage backend to use ('local' or 's3')
        upload_to_storage: If True, upload resources and raw_data to storage backend

    Returns:
        Version hash

    Examples:
        >>> import warpdata as wd
        >>> # Basic registration
        >>> version = wd.register_dataset(
        ...     "warpdata://nlp/reviews",
        ...     resources=["s3://bucket/reviews/*.parquet"]
        ... )

        >>> # With raw data tracking
        >>> version = wd.register_dataset(
        ...     "warpdata://arxiv/papers",
        ...     resources=["./processed/papers.parquet"],
        ...     raw_data=["./raw/pdfs/", "./raw/metadata.db"]
        ... )

        >>> # With S3 storage
        >>> version = wd.register_dataset(
        ...     "warpdata://arxiv/papers",
        ...     resources=["./processed/papers.parquet"],
        ...     raw_data=["./raw/pdfs/"],
        ...     storage_backend="s3",
        ...     upload_to_storage=True
        ... )
    """
    # Parse dataset ID
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID. Must be warpdata:// URI: {dataset_id}")

    workspace = uri.workspace
    name = uri.name

    if not workspace or not name:
        raise ValueError(f"Invalid dataset ID format: {dataset_id}")

    # Expand glob patterns in resources
    expanded_resources = []
    for resource in resources:
        if "*" in resource:
            # Expand glob
            fs = get_filesystem(resource)
            matches = fs.glob(resource)
            if not matches:
                raise FileNotFoundError(f"No files found matching pattern: {resource}")
            expanded_resources.extend(matches)
        else:
            expanded_resources.append(resource)

    if not expanded_resources:
        raise ValueError("No resources provided")

    # Fetch metadata for each resource (without downloading)
    resource_metadata = []

    for resource_uri in expanded_resources:
        # Get filesystem and metadata WITHOUT downloading
        fs = get_filesystem(resource_uri)
        try:
            info = fs.info(resource_uri)

            # Skip directories if they appear in glob results
            if info.get("type") == "directory":
                continue

            etag = fs.get_etag(resource_uri)

            resource_metadata.append(
                {
                    "uri": resource_uri,
                    "checksum": etag,
                    "size": info.get("size"),
                    "type": info.get("type", "file"),
                }
            )
        except Exception as e:
            raise FileNotFoundError(f"Failed to access resource metadata for {resource_uri}: {e}")

    if not resource_metadata:
        raise ValueError("No valid resources found after filtering")

    # Infer schema if not provided
    # This is the ONE necessary download if schema is not provided
    if schema is None:
        cache = get_cache()
        engine = get_engine()
        # Download only the first resource to infer schema
        first_resource_local_path = cache.get(expanded_resources[0])
        schema = engine.get_schema(first_resource_local_path)

    # Build manifest
    manifest = {
        "schema": schema,
        "resources": resource_metadata,
        "format": file_format or "parquet",  # Use provided format or default to parquet
        "metadata": metadata or {},
    }

    # Compute version hash from manifest
    # This ensures the same resources always produce the same version
    manifest_str = json.dumps(manifest, sort_keys=True)
    version_hash = compute_hash(manifest_str)

    # Register in database
    registry = get_registry()
    registry.register_dataset(workspace, name, version_hash, manifest)

    # Handle raw data if provided
    if raw_data:
        from ..core.storage import get_global_storage, get_storage_backend, compute_content_hash

        # Use global storage if available, otherwise create new instance
        try:
            storage = get_global_storage()
        except:
            storage_config = {}
            if storage_backend == "s3" and metadata:
                storage_config["bucket"] = metadata.get("storage_bucket")
            storage = get_storage_backend(storage_backend, **storage_config)

        for raw_source in raw_data:
            raw_path = Path(raw_source).resolve()

            if not raw_path.exists():
                print(f"Warning: Raw data source not found: {raw_source}")
                continue

            # Determine source type
            if raw_path.is_dir():
                source_type = "directory"
                size = sum(f.stat().st_size for f in raw_path.rglob("*") if f.is_file())
                content_hash = None  # Don't hash entire directories
            else:
                source_type = raw_path.suffix[1:] if raw_path.suffix else "file"
                size = raw_path.stat().st_size
                content_hash = compute_content_hash(raw_path) if upload_to_storage else None

            # Upload to storage if requested
            if upload_to_storage and raw_path.is_file():
                content_hash = storage.put(
                    raw_path,
                    metadata={
                        "type": "raw_data",
                        "dataset": f"{workspace}/{name}",
                        "source_type": source_type,
                    }
                )

            # Register raw data source
            registry.register_raw_data_source(
                workspace=workspace,
                name=name,
                version_hash=version_hash,
                source_type=source_type,
                source_path=str(raw_path),
                content_hash=content_hash,
                size=size,
            )

    return version_hash


def list_datasets(workspace: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    List all registered datasets.

    Args:
        workspace: Optional workspace filter

    Returns:
        List of dataset info dictionaries

    Examples:
        >>> import warpdata as wd
        >>> datasets = wd.list_datasets()
        >>> for ds in datasets:
        ...     print(f"{ds['workspace']}/{ds['name']}: {ds['latest_version']}")
    """
    registry = get_registry()
    return registry.list_datasets(workspace)


def list_subdatasets(dataset_id: str) -> List[Dict[str, Any]]:
    """
    List all subdatasets of a given dataset.

    Args:
        dataset_id: Parent dataset ID (e.g., 'warpdata://audio/vctk')

    Returns:
        List of subdataset info dictionaries with schema and description

    Examples:
        >>> import warpdata as wd
        >>> subdatasets = wd.list_subdatasets("warpdata://audio/vctk")
        >>> for sub in subdatasets:
        ...     print(f"{sub['name']}: {sub['description']}")
        ...     print(f"  Dataset ID: warpdata://{sub['workspace']}/{sub['name']}")
        ...     print(f"  Schema: {sub['schema'].keys()}")
    """
    # Parse URI
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name

    # Get subdatasets from registry
    registry = get_registry()
    return registry.list_subdatasets(workspace, name)


def verify_dataset(
    dataset_id: str,
    deep: bool = False,
    materialize_check: bool = False,
) -> Dict[str, Any]:
    """
    Verify that a dataset's registered resources and raw data sources are present and consistent.

    Checks:
      - Each resource URI exists (via filesystem info)
      - Size matches manifest (when available)
      - If deep: compares checksum/etag when available; for local files without checksum, computes content hash
      - Raw data sources exist (file/dir); if deep and file, size matches recorded
      - Optional: attempts materialization to ensure queryable parquet

    Returns a report dict with 'ok' boolean and details.
    """
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    registry = get_registry()
    ver = registry.get_dataset_version(uri.workspace, uri.name, uri.version or "latest")
    if not ver:
        raise ValueError(f"Dataset not found: {dataset_id}")
    version_hash = ver["version_hash"]
    manifest = registry.get_manifest(uri.workspace, uri.name, version_hash) or {}

    issues: List[str] = []
    resources_report = []
    for res in manifest.get("resources", []):
        ruri = res.get("uri")
        rsize = res.get("size")
        rchk = res.get("checksum")
        status = {"uri": ruri, "exists": False, "size_ok": None, "checksum_ok": None}
        try:
            fs = get_filesystem(ruri)
            info = fs.info(ruri)
            status["exists"] = True
            # Size check when available
            if rsize is not None and isinstance(info.get("size"), (int, float)):
                status["size_ok"] = (int(info["size"]) == int(rsize))
                if not status["size_ok"]:
                    issues.append(f"Resource size mismatch: {ruri}")
            # Deep checksum/etag check
            if deep:
                etag = fs.get_etag(ruri)
                if rchk:
                    status["checksum_ok"] = (etag == rchk)
                    if status["checksum_ok"] is False:
                        issues.append(f"Resource checksum mismatch: {ruri}")
                else:
                    # For local files without checksum in manifest, compute hash
                    if ruri.startswith("file://"):
                        from pathlib import Path as _Path
                        p = _Path(ruri[7:])
                        if p.exists() and p.is_file():
                            content_hash = compute_content_hash(p)
                            status["checksum_ok"] = True if content_hash else None
        except Exception as e:
            status["error"] = str(e)
            issues.append(f"Resource missing/inaccessible: {ruri}")
        resources_report.append(status)

    # Raw data check
    raw_report = []
    raw_sources = registry.list_raw_data_sources(uri.workspace, uri.name, version_hash)
    for src in raw_sources:
        spath = src.get("source_path")
        stype = src.get("source_type")
        recorded_size = src.get("size")
        from pathlib import Path as _Path
        p = _Path(spath)
        item = {"path": spath, "type": stype, "exists": p.exists(), "size_ok": None}
        if not p.exists():
            issues.append(f"Raw data missing: {spath}")
        else:
            if deep and recorded_size and p.is_file():
                item["size_ok"] = (p.stat().st_size == int(recorded_size))
                if item["size_ok"] is False:
                    issues.append(f"Raw data size mismatch: {spath}")
        raw_report.append(item)

    # Optional materialization check
    materialized = None
    if materialize_check:
        try:
            mat_path = materialize(dataset_id, update_registry=False, force=False)
            from pathlib import Path as _Path
            materialized = str(mat_path)
            if not _Path(mat_path).exists():
                issues.append("Materialization path missing after run")
        except Exception as e:
            issues.append(f"Materialization failed: {e}")

    ok = len(issues) == 0
    return {
        "dataset_id": dataset_id,
        "version": version_hash,
        "ok": ok,
        "issues": issues,
        "resources": resources_report,
        "raw_data": raw_report,
        "materialized": materialized,
    }


def verify_datasets(
    workspace: Optional[str] = None,
    deep: bool = False,
    materialize_check: bool = False,
) -> Dict[str, Any]:
    """
    Verify all datasets in the registry (optionally filter by workspace).

    Returns a summary report with per-dataset results and counts of issues.
    """
    registry = get_registry()
    datasets = registry.list_datasets(workspace)
    results = []
    total_issues = 0
    for ds in datasets:
        ds_id = f"warpdata://{ds['workspace']}/{ds['name']}"
        rep = verify_dataset(ds_id, deep=deep, materialize_check=materialize_check)
        results.append(rep)
        if not rep["ok"]:
            total_issues += 1

    return {
        "workspace": workspace,
        "total": len(results),
        "with_issues": total_issues,
        "ok": (total_issues == 0),
        "results": results,
    }


def dataset_info(dataset_id: str) -> Dict[str, Any]:
    """
    Get detailed information about a dataset.

    Args:
        dataset_id: Dataset ID (e.g., 'warpdata://nlp/imdb' or 'warpdata://nlp/imdb@version')
                    Supports shorthand forms like 'nlp/imdb' or 'imdb'

    Returns:
        Dictionary with dataset info including manifest

    Examples:
        >>> import warpdata as wd
        >>> info = wd.dataset_info("warpdata://nlp/imdb")
        >>> info = wd.dataset_info("nlp/imdb")  # Shorthand also works
        >>> info = wd.dataset_info("imdb")  # Auto-find across workspaces
        >>> print(info['manifest']['schema'])
    """
    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    # Parse URI
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    # Get dataset version info
    registry = get_registry()
    dataset_ver = registry.get_dataset_version(workspace, name, version)

    if dataset_ver is None:
        raise ValueError(f"Dataset not found: {dataset_id}")

    # Get manifest
    manifest = registry.get_manifest(workspace, name, dataset_ver["version_hash"])

    return {
        "workspace": workspace,
        "name": name,
        "version_hash": dataset_ver["version_hash"],
        "manifest": manifest,
        "created_at": dataset_ver.get("created_at"),
    }


def materialize(
    dataset_id: str,
    output_path: Optional[Path] = None,
    force: bool = False,
    update_registry: bool = True
) -> Path:
    """
    Materialize a dataset to a local Parquet file with row IDs.

    This creates a consolidated local copy of the dataset with a monotonically
    increasing 'rid' (row ID) column, which is required for embeddings.

    Args:
        dataset_id: Dataset ID (e.g., 'warpdata://nlp/imdb')
        output_path: Optional output path (auto-generated if not provided)
        force: Force re-materialization even if already exists
        update_registry: If True, re-register dataset to point to materialized file

    Returns:
        Path to materialized Parquet file

    Examples:
        >>> import warpdata as wd
        >>> path = wd.materialize("warpdata://nlp/reviews")
        >>> print(f"Materialized to: {path}")
    """
    # Parse URI
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    # Get dataset version
    registry = get_registry()
    dataset_ver = registry.get_dataset_version(workspace, name, version)

    if dataset_ver is None:
        raise ValueError(f"Dataset not found: {dataset_id}")

    version_hash = dataset_ver["version_hash"]

    # Determine output path
    if output_path is None:
        cache = get_cache()
        dataset_cache_dir = cache.get_dataset_cache_dir(workspace, name, version_hash)
        output_path = dataset_cache_dir / "materialized.parquet"

    output_path = Path(output_path)

    # Check if already exists
    if output_path.exists() and not force:
        return output_path

    # Load the dataset
    from .data import load

    relation = load(dataset_id, as_format="duckdb")

    # Add row ID column
    # Use ROW_NUMBER() window function to add monotonic rid
    engine = get_engine()
    with_rid = engine.conn.sql(
        """
        SELECT ROW_NUMBER() OVER () - 1 AS rid, *
        FROM relation
        """
    )

    # Write to Parquet
    output_path.parent.mkdir(parents=True, exist_ok=True)
    engine.conn.sql(f"COPY (SELECT * FROM with_rid) TO '{output_path}' (FORMAT PARQUET)")

    # Optionally update registry to point to materialized file
    if update_registry:
        # Get original metadata
        manifest = registry.get_manifest(workspace, name, version_hash)
        original_metadata = manifest.get("metadata", {}) if manifest else {}

        # Mark as materialized
        updated_metadata = {**original_metadata, "materialized": True}

        # Re-register with materialized file as resource
        register_dataset(
            dataset_id,
            resources=[f"file://{output_path.resolve()}"],
            metadata=updated_metadata
        )

    return output_path


def remove_dataset(dataset_id: str, version: Optional[str] = None):
    """
    Remove a dataset or specific version from the registry.

    Args:
        dataset_id: Dataset ID (e.g., 'warpdata://nlp/imdb')
        version: Optional version to remove (removes all versions if not specified)

    Examples:
        >>> import warpdata as wd
        >>> wd.remove_dataset("warpdata://nlp/old-dataset")
    """
    # Parse URI
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name

    if not workspace or not name:
        raise ValueError(f"Invalid dataset ID format: {dataset_id}")

    # Get registry and remove
    registry = get_registry()
    registry.remove_dataset(workspace, name, version_hash=version)
