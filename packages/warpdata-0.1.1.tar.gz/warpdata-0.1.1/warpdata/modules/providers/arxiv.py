from __future__ import annotations
from ..base import BaseWarpDatasetModule


class ArxivPapersModule(BaseWarpDatasetModule):
    """Provider for arxiv/papers dataset."""

    id = "warp.dataset.arxiv_papers"
    version = "1.0.0"
    dataset_uri = "warpdata://arxiv/papers"

