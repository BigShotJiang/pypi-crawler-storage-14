from __future__ import annotations
from ..base import BaseWarpDatasetModule


class MathHendrycksModule(BaseWarpDatasetModule):
    id = "warp.dataset.math_hendrycks"
    version = "1.0.0"
    dataset_uri = "warpdata://math/math_hendrycks"


class MathVisionModule(BaseWarpDatasetModule):
    id = "warp.dataset.mathvision"
    version = "1.0.0"
    dataset_uri = "warpdata://math/mathvision"


class MathVistaModule(BaseWarpDatasetModule):
    id = "warp.dataset.mathvista"
    version = "1.0.0"
    dataset_uri = "warpdata://math/mathvista"


class MathX100KModule(BaseWarpDatasetModule):
    id = "warp.dataset.mathx_100k"
    version = "1.0.0"
    dataset_uri = "warpdata://math/mathx-100k"


class NuminaLeanModule(BaseWarpDatasetModule):
    id = "warp.dataset.numina_lean"
    version = "1.0.0"
    dataset_uri = "warpdata://math/numina_lean"

