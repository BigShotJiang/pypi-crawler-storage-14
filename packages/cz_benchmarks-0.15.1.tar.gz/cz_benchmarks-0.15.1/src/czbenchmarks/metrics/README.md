# cz-benchmarks Metrics

For complete details on the metrics, please refer to the links below:

- [How to add a Metric](../../../docs/source/how_to_guides/add_new_metric.md)
- [Developer Guide](../../../docs/source/developer_guides/metrics.md)