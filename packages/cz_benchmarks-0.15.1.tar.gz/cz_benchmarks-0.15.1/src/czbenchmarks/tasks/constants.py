N_FOLDS = 5

MIN_CLASS_SIZE = 10

FLAVOR = "igraph"

KEY_ADDED = "leiden"

OBSM_KEY = "emb"

N_ITERATIONS = 2
