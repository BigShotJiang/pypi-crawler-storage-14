# cz-benchmarks Tasks

For complete details on the tasks, please refer to the links below:

- [How to add a Task](../../../docs/source/how_to_guides/add_new_task.md)
- [Developer Guide](../../../docs/source/developer_guides/tasks.md)