"""Smart WebFetch MCP Server - Context-aware web fetching for LLMs."""

__version__ = "0.1.0"
