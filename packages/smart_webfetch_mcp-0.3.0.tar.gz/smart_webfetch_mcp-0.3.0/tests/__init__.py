"""Tests for smart-webfetch-mcp."""
