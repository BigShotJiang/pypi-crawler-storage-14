"""Get Report of a workflow from the project"""

import datetime
import json
from collections import OrderedDict
from collections.abc import Sequence
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from cmem.cmempy.api import get_json
from cmem.cmempy.config import get_di_api_endpoint
from cmem_plugin_base.dataintegration.context import ExecutionContext
from cmem_plugin_base.dataintegration.description import Icon, Plugin, PluginParameter
from cmem_plugin_base.dataintegration.entity import (
    Entities,
)
from cmem_plugin_base.dataintegration.parameter.choice import ChoiceParameterType
from cmem_plugin_base.dataintegration.plugins import WorkflowPlugin
from cmem_plugin_base.dataintegration.ports import FixedNumberOfInputs, FixedSchemaPort
from cmem_plugin_base.dataintegration.typed_entities.file import FileEntitySchema, LocalFile
from cmem_plugin_base.dataintegration.utils import setup_cmempy_user_access

from cmem_plugin_wfreports.workflow_type import WorkflowParameterType

CHOICE_LIST: OrderedDict[str, str] = OrderedDict(
    [
        ("Latest Report", "Latest Report"),
        ("Latest Report with Errors", "Latest Report with Errors"),
        ("Latest Report with Warning or Errors", "Latest Report with Warning or Errors"),
    ]
)


def get_report(context: ExecutionContext, workflow_id: str, time: str) -> dict[str, Any]:
    """Get Workflow Report"""
    setup_cmempy_user_access(context=context.user)
    api_base = get_di_api_endpoint() + "/api/workspace/reports/report"
    report: dict[str, Any] = get_json(
        api_base,
        params={
            "projectId": context.task.project_id(),
            "taskId": workflow_id,
            "time": time,
        },
    )
    return report


def list_reports(context: ExecutionContext, workflow_id: str) -> list[dict[str, str]]:
    """List the workflow reports."""
    setup_cmempy_user_access(context=context.user)
    # list?projectId=CMEM7071_b0f29341d3fdb8c0&taskId=DemofailedRESTrequests_67dcee4fe1696181
    api_base = get_di_api_endpoint() + "/api/workspace/reports/list"
    response: list[dict[str, str]] = get_json(
        api_base,
        params={
            "projectId": context.task.project_id(),
            "taskId": workflow_id,
        },
    )
    return response


@Plugin(
    label="Get workflow report",
    plugin_id="cmem_plugin_wfreports_get_report",
    description="Output a workflow execution report as a JSON file.",
    documentation="""
This workflow operator retrieves a specific execution report of a workflow and outputs it
as a JSON file.

The plugin queries the backend API to list all available reports for the given workflow and
allows you to select which report to retrieve:

- **Latest Report**: The most recent execution report
- **Latest Report with Errors**: The most recent failed execution report
- **Latest Report with Warning or Errors**: The most recent report with warnings (successful or not)

The report contains detailed information about the workflow execution, including task results,
execution times, and any errors or warnings.

## Output

The plugin outputs a single JSON file entity containing the complete workflow execution report.

## Usage

This operator is useful for:
- Monitoring workflow execution results and failures
- Debugging recent errors or warnings
- Creating audit trails of workflow runs
- Archiving execution reports for compliance purposes
- Feeding execution data into downstream analysis tasks
""",
    icon=Icon(package=__package__, file_name="get_report.svg"),
    parameters=[
        PluginParameter(
            name="workflow_id",
            label="Workflow",
            description="The workflow from which the reports get listed.",
            param_type=WorkflowParameterType(),
        ),
        PluginParameter(
            name="report_selected",
            label="Report",
            description="Selector for reports to be shown.",
            param_type=ChoiceParameterType(CHOICE_LIST),
            default_value=CHOICE_LIST["Latest Report"],
        ),
        PluginParameter(
            name="time_period",
            label="Time Period",
            description="The time period in hours of the workflow execution reports that can be"
            " listed."
            "Allows only full hours. Defaults to 0 for every execution report.",
            default_value=0,
        ),
    ],
)
class GetReport(WorkflowPlugin):
    """Get Report Workflow Plugin"""

    def __init__(self, workflow_id: str, report_selected: str, time_period: int) -> None:
        self.workflow_id = workflow_id
        self.report_selected = report_selected
        if time_period < 0:
            raise ValueError("time_period cannot be negative")
        self.time_period = time_period
        self._temp_dir = TemporaryDirectory()
        self.download_dir = Path(self._temp_dir.name)
        self.output_schema = FileEntitySchema()
        self.input_ports = FixedNumberOfInputs([])
        self.output_port = FixedSchemaPort(schema=self.output_schema)

    def execute(
        self,
        inputs: Sequence[Entities],  # noqa: ARG002
        context: ExecutionContext,
    ) -> Entities:
        """Run the workflow operator."""
        entities = [
            self.output_schema.to_entity(file) for file in self.get_selected_report(context)
        ]
        return Entities(entities=iter(entities), schema=self.output_schema)

    def get_selected_report(self, context: ExecutionContext) -> list[LocalFile]:
        """Get the selected workflow report."""
        setup_cmempy_user_access(context=context.user)
        reports = sorted(
            list_reports(context=context, workflow_id=self.workflow_id),
            key=lambda report: report["time"],
            reverse=True,
        )
        time_filtered_reports = []
        if self.time_period > 0:
            current_timestamp = datetime.datetime.now(datetime.UTC)
            for rep in reports:
                report_timestamp = datetime.datetime.fromisoformat(rep["time"])
                if current_timestamp - report_timestamp < datetime.timedelta(
                    hours=self.time_period
                ):
                    time_filtered_reports.append(rep)
                if current_timestamp - report_timestamp > datetime.timedelta(
                    hours=self.time_period
                ):
                    break

        report: dict[str, Any] = {}

        amount_of_reports = len(reports) if self.time_period == 0 else len(time_filtered_reports)

        if self.report_selected == "Latest Report" and amount_of_reports > 0:
            selected_report = reports[0] if self.time_period == 0 else time_filtered_reports[0]
            report = get_report(
                context=context, workflow_id=self.workflow_id, time=selected_report["time"]
            )

        if self.report_selected == "Latest Report with Warning or Errors" and amount_of_reports > 0:
            report = self.get_last_warning_or_error_report(
                context, report, reports if self.time_period == 0 else time_filtered_reports
            )

        if self.report_selected == "Latest Report with Errors" and amount_of_reports > 0:
            report = self.get_last_error_report(
                context, report, reports if self.time_period == 0 else time_filtered_reports
            )

        self.download_dir.mkdir(parents=True, exist_ok=True)
        report_file = self.download_dir / "report.json"
        with report_file.open("w") as file:
            json.dump(report, file)
        return [LocalFile(str(report_file), "application/json")]

    def get_last_warning_or_error_report(
        self,
        context: ExecutionContext,
        report: dict[str, Any],
        reports: list[dict[str, str]],
    ) -> dict[str, Any]:
        """Get the latest workflow report that had warnings."""
        for rep in reports:
            response: dict[str, Any] = get_report(
                context, workflow_id=self.workflow_id, time=rep["time"]
            )
            value = response["value"]
            warnings = value["warnings"]
            if warnings:
                return response
        return report

    def get_last_error_report(
        self,
        context: ExecutionContext,
        report: dict[str, Any],
        reports: list[dict[str, str]],
    ) -> dict[str, Any]:
        """Get the latest workflow report that had errors."""
        for rep in reports:
            response: dict[str, Any] = get_report(
                context, workflow_id=self.workflow_id, time=rep["time"]
            )
            metadata = response["metaData"]
            finish_status = metadata["finishStatus"]
            concrete_status = finish_status["concreteStatus"]
            if concrete_status == "Failed":
                return response
        return report
