"""Reports subpackage placeholder for future report utilities."""

__all__: list[str] = []
