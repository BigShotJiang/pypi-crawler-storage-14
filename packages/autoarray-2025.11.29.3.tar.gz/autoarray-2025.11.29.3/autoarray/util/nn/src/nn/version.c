/******************************************************************************
 *
 * File:           version.c
 *
 * Created:        05/05/2021
 *
 * Author:         Pavel Sakov
 *                 BoM
 *
 * Purpose:        NN library version.
 *
 * Description:    NN library version.
 *
 * Revisions:      None
 *
 *****************************************************************************/

char* nn_version = "2.0.6";
