from autoarray.structures.mesh.rectangular_2d import Mesh2DRectangular


class Mesh2DRectangularUniform(Mesh2DRectangular):

    pass
