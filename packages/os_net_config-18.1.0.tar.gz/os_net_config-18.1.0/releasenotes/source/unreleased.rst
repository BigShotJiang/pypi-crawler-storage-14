==============================
 Current Series Release Notes
==============================

.. important::

   **As of version 18.1.0, release notes have moved to GitHub Releases:**

   https://github.com/os-net-config/os-net-config/releases

   This page is maintained for historical reference only.

.. toctree::
