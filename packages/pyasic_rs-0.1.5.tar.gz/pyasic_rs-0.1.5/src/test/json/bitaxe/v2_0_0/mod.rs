#![cfg(test)]

pub(crate) const SYSTEM_INFO_COMMAND: &str = include_str!("system_info.json");
