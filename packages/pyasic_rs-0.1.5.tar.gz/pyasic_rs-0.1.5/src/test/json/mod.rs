pub(crate) mod bitaxe;
pub(crate) mod bmminer;
pub(crate) mod btminer;
pub(crate) mod cgminer;
pub(crate) mod epic;
pub(crate) mod luxminer;
