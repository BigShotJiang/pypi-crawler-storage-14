In order to use this module act as follow:

- From a Inventory Adjustment in state 'Pending to Approve' click in the
  button 'Request Verification'. This will create all the Slot
  Verification Request needed.
- Go to 'Inventory / Inventory Control / Slot Verification Request'
- Go to a Slot Verification Request 'Waiting Actions' and confirm it.
- You can now check the involved lines and moves to help you.
- Once you have found the problem and you have fixed it 'Mark as Solved'
  the Verification.

You can also create the SVR manually.
