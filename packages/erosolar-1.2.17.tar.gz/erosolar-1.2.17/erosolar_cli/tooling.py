from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import List

from langchain_core.tools import tool


def build_tools(root: Path) -> list:
  safe_root = root.resolve()

  @tool
  def read_file(path: str, start: int = 1, end: int = 200) -> str:
    """Read a file within the workspace, returning numbered lines."""
    full = (safe_root / path).resolve()
    if safe_root not in full.parents and full != safe_root:
      return f"error: path outside workspace: {path}"
    if not full.exists() or not full.is_file():
      return f"error: file not found: {path}"
    try:
      lines = full.read_text(encoding="utf-8").splitlines()
    except Exception as error:
      return f"error: failed to read {path}: {error}"
    start_idx = max(start - 1, 0)
    end_idx = min(end, len(lines))
    numbered = [f"{idx + 1}: {line}" for idx, line in enumerate(lines[start_idx:end_idx], start=start_idx)]
    return "\n".join(numbered) if numbered else "error: no content in range"

  @tool
  def list_dir(path: str = ".", recursive: bool = False, limit: int = 200) -> str:
    """List files/directories under a path."""
    target = (safe_root / path).resolve()
    if safe_root not in target.parents and target != safe_root:
      return f"error: path outside workspace: {path}"
    if not target.exists():
      return f"error: path not found: {path}"
    entries: List[str] = []
    if recursive:
      for item in target.rglob("*"):
        if len(entries) >= limit:
          break
        rel = item.relative_to(safe_root)
        entries.append(f"{rel}/" if item.is_dir() else str(rel))
    else:
      for item in sorted(target.iterdir()):
        if len(entries) >= limit:
          break
        rel = item.relative_to(safe_root)
        entries.append(f"{rel}/" if item.is_dir() else str(rel))
    return "\n".join(entries)

  @tool
  def search_text(pattern: str, path: str = ".", max_results: int = 50) -> str:
    """Regex search files under a path, returning matched lines."""
    target = (safe_root / path).resolve()
    if safe_root not in target.parents and target != safe_root:
      return f"error: path outside workspace: {path}"
    if not target.exists():
      return f"error: path not found: {path}"
    try:
      regex = re.compile(pattern, flags=re.MULTILINE)
    except re.error as error:
      return f"error: invalid regex: {error}"
    results: List[str] = []
    for file_path in target.rglob("*"):
      if len(results) >= max_results:
        break
      if not file_path.is_file():
        continue
      try:
        content = file_path.read_text(encoding="utf-8")
      except (UnicodeDecodeError, OSError):
        continue
      for match in regex.finditer(content):
        line_no = content.count("\n", 0, match.start()) + 1
        rel = file_path.relative_to(safe_root)
        snippet = content.splitlines()[line_no - 1]
        results.append(f"{rel}:{line_no}: {snippet}")
        if len(results) >= max_results:
          break
    return "\n".join(results) if results else "no matches"

  @tool
  def run_bash(command: str, timeout: int = 20) -> str:
    """Run a bash command inside the workspace (non-interactive)."""
    try:
      result = subprocess.run(
        ["bash", "-lc", command],
        cwd=safe_root,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
        text=True,
        capture_output=True,
        timeout=timeout,
      )
    except subprocess.TimeoutExpired:
      return f"Command timed out after {timeout}s"
    except Exception as error:
      return f"error: failed to run command: {error}"
    output_parts = []
    if result.stdout:
      output_parts.append(result.stdout.strip())
    if result.stderr:
      output_parts.append(f"stderr:\n{result.stderr.strip()}")
    if result.returncode != 0:
      output_parts.append(f"exit code: {result.returncode}")
    return "\n".join(part for part in output_parts if part)

  return [read_file, list_dir, search_text, run_bash]
