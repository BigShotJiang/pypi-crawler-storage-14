from __future__ import annotations

import json
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_RULEBOOK_ROOT = REPO_ROOT


@dataclass(frozen=True)
class RulebookPrompt:
  profile: str
  label: str
  version: str
  contract_version: str
  description: str | None
  file: str
  body: str


def build_rulebook_prompt(profile: str, file_override: str | None = None, root: Path | None = None) -> RulebookPrompt:
  manifest = _load_rulebook_manifest(profile, file_override=file_override, root=root)
  body = _format_rulebook(manifest)
  return RulebookPrompt(
    profile=manifest.get("profile", profile),
    label=manifest.get("label") or manifest.get("profile", profile),
    version=str(manifest.get("version", "unknown")),
    contract_version=str(manifest.get("contractVersion", "unknown")),
    description=manifest.get("description"),
    file=file_override or f"agents/{profile}.rules.json",
    body=body,
  )


@lru_cache(maxsize=8)
def _load_rulebook_manifest(profile: str, file_override: str | None = None, root: Path | None = None) -> dict[str, Any]:
  base = root or DEFAULT_RULEBOOK_ROOT
  target = Path(file_override) if file_override else Path("agents") / f"{profile}.rules.json"
  path = (base / target).resolve()
  raw = json.loads(path.read_text(encoding="utf-8"))
  declared = raw.get("profile")
  if declared and declared != profile:
    raise ValueError(f"Rulebook profile mismatch for {profile}: file declares {declared}")
  return raw


def _format_rulebook(manifest: dict[str, Any]) -> str:
  lines: list[str] = []
  header_label = manifest.get("label") or manifest.get("profile", "rulebook")
  version = manifest.get("version", "unknown")
  contract = manifest.get("contractVersion", "unknown")
  lines.append(f"{header_label} — rulebook version {version} (contract {contract}).")

  description = manifest.get("description")
  if description:
    lines.append(str(description).strip())

  principles = manifest.get("globalPrinciples") or []
  if principles:
    lines.append("\nGLOBAL PRINCIPLES:")
    lines.extend(_format_rule(rule) for rule in principles)

  for phase in manifest.get("phases", []):
    phase_label = phase.get("label") or phase.get("id")
    phase_parts = [part for part in [phase_label, phase.get("description")] if part]
    lines.append(f"\nPHASE {phase.get('id')}: {' – '.join(phase_parts)}")
    if phase.get("trigger"):
      lines.append(f"  Trigger: {phase['trigger']}")
    for step in phase.get("steps", []):
      lines.append(_format_step(step))

  return "\n".join(filter(bool, lines))


def _format_rule(rule: dict[str, Any], indent: str = "  ") -> str:
  severity = str(rule.get("severity") or "INFO").upper()
  summary = rule.get("summary") or ""
  parts: list[str] = [f"[{severity}] ({rule.get('id')}) {summary}"]
  detail = rule.get("detail")
  if detail:
    parts.append(f"— {detail}")
  evidence = rule.get("evidenceRequired")
  if evidence:
    parts.append(f"Evidence: {evidence}")
  return f"{indent}{' '.join(parts)}"


def _format_step(step: dict[str, Any]) -> str:
  details: list[str] = []
  intent = step.get("intent")
  description = step.get("description")
  if intent:
    details.append(intent)
  if description and description != intent:
    details.append(description)

  header_parts = [f"  STEP {step.get('id')}: {step.get('title')}"]
  if details:
    header_parts.append(f"({' — '.join(details)})")
  lines = [" ".join(header_parts)]

  if step.get("entryCriteria"):
    lines.append(f"    Entry: {'; '.join(step['entryCriteria'])}")
  if step.get("exitCriteria"):
    lines.append(f"    Exit: {'; '.join(step['exitCriteria'])}")
  if step.get("allowedTools"):
    lines.append(f"    Allowed tools: {', '.join(step['allowedTools'])}")
  if step.get("blockedTools"):
    lines.append(f"    Blocked tools: {', '.join(step['blockedTools'])}")
  if step.get("notes"):
    lines.append(f"    Notes: {' '.join(step['notes'])}")

  for rule in step.get("rules", []):
    lines.append(_format_rule(rule, indent="    - "))

  if step.get("subSteps"):
    lines.append("    Sub-steps:")
    for sub in step["subSteps"]:
      indented = re.sub(r"^  ", "      ", _format_step(sub), flags=re.MULTILINE)
      lines.append(indented)

  return "\n".join(lines)
