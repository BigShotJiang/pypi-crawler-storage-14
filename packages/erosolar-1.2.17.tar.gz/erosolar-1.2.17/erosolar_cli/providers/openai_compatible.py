"""
OpenAI-Compatible Provider

A unified provider for all OpenAI-compatible APIs including:
- DeepSeek
- xAI (Grok)
- Ollama
- Groq
- Together AI
- Fireworks AI
- Mistral AI

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, AsyncIterator
from dataclasses import dataclass

logger = logging.getLogger(__name__)

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False


def _safe_parse_arguments(arguments: Any, context: str = "") -> dict:
    """
    Safely parse tool call arguments, handling malformed JSON gracefully.

    Args:
        arguments: Raw arguments (str, dict, or other)
        context: Description of where parsing is happening (for logging)

    Returns:
        Parsed dict, or empty dict if parsing fails
    """
    if isinstance(arguments, dict):
        return arguments
    if not isinstance(arguments, str):
        return {}

    if not arguments.strip():
        return {}

    try:
        parsed = json.loads(arguments)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse tool arguments{' in ' + context if context else ''}: {e}")
        # Try to salvage partial JSON by attempting common fixes
        try:
            fixed = arguments.rstrip()
            if not fixed.endswith('}'):
                fixed += '}'
            parsed = json.loads(fixed)
            logger.info(f"Recovered partial JSON by adding closing brace")
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            pass

        # Return empty dict as fallback
        return {}


@dataclass
class OpenAICompatibleOptions:
    """Options for OpenAI-compatible providers."""
    provider_id: str
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    max_tokens: int = 4096
    temperature: float = 0.0
    timeout: int = 120


class OpenAICompatibleProvider:
    """
    A unified provider for OpenAI-compatible APIs.

    Works with any API that follows the OpenAI chat completions format.
    """

    def __init__(self, options: OpenAICompatibleOptions):
        if not HAS_HTTPX:
            raise ImportError("httpx is required for OpenAI-compatible providers. Install with: pip install httpx")

        self.options = options
        self._id = options.provider_id
        self._model = options.model
        self._base_url = options.base_url or "https://api.openai.com/v1"
        self._api_key = options.api_key
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def id(self) -> str:
        """Provider identifier."""
        return self._id

    @property
    def model(self) -> str:
        """Model identifier."""
        return self._model

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None:
            headers = {"Content-Type": "application/json"}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"

            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=headers,
                timeout=self.options.timeout,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _convert_messages(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Convert messages to OpenAI format."""
        converted = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "tool":
                converted.append({
                    "role": "tool",
                    "tool_call_id": msg.get("tool_call_id", ""),
                    "content": content,
                })
            elif role == "assistant" and msg.get("tool_calls"):
                converted.append({
                    "role": "assistant",
                    "content": content or None,
                    "tool_calls": [
                        {
                            "id": tc.get("id", ""),
                            "type": "function",
                            "function": {
                                "name": tc.get("name", ""),
                                "arguments": json.dumps(tc.get("arguments", {})),
                            },
                        }
                        for tc in msg["tool_calls"]
                    ],
                })
            else:
                converted.append({
                    "role": role,
                    "content": content,
                })

        return converted

    def _convert_tools(self, tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Convert tools to OpenAI format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.get("name", ""),
                    "description": tool.get("description", ""),
                    "parameters": tool.get("parameters", {}),
                },
            }
            for tool in tools
        ]

    async def generate(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Generate a response.

        Args:
            messages: Conversation messages
            tools: Optional tool definitions

        Returns:
            Response with content and/or tool calls
        """
        client = self._get_client()

        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": self._convert_messages(messages),
            "max_tokens": self.options.max_tokens,
            "temperature": self.options.temperature,
        }

        if tools:
            payload["tools"] = self._convert_tools(tools)

        response = await client.post("/chat/completions", json=payload)
        response.raise_for_status()
        data = response.json()

        choice = data.get("choices", [{}])[0]
        message = choice.get("message", {})
        usage = data.get("usage", {})

        result: Dict[str, Any] = {
            "usage": {
                "input_tokens": usage.get("prompt_tokens", 0),
                "output_tokens": usage.get("completion_tokens", 0),
            },
        }

        if message.get("tool_calls"):
            result["type"] = "tool_calls"
            result["tool_calls"] = [
                {
                    "id": tc.get("id", ""),
                    "name": tc.get("function", {}).get("name", ""),
                    "arguments": _safe_parse_arguments(tc.get("function", {}).get("arguments", "{}"), "openai_compatible"),
                }
                for tc in message["tool_calls"]
            ]
            if message.get("content"):
                result["content"] = message["content"]
        else:
            result["type"] = "message"
            result["content"] = message.get("content", "")

        return result

    async def generate_stream(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Generate a streaming response.

        Args:
            messages: Conversation messages
            tools: Optional tool definitions

        Yields:
            Stream chunks with content deltas or tool calls
        """
        client = self._get_client()

        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": self._convert_messages(messages),
            "max_tokens": self.options.max_tokens,
            "temperature": self.options.temperature,
            "stream": True,
        }

        if tools:
            payload["tools"] = self._convert_tools(tools)

        async with client.stream("POST", "/chat/completions", json=payload) as response:
            response.raise_for_status()

            async for line in response.aiter_lines():
                if not line or not line.startswith("data: "):
                    continue

                data_str = line[6:]  # Remove "data: " prefix
                if data_str == "[DONE]":
                    break

                try:
                    data = json.loads(data_str)
                    choice = data.get("choices", [{}])[0]
                    delta = choice.get("delta", {})

                    if delta.get("content"):
                        yield {
                            "type": "content",
                            "content": delta["content"],
                        }
                    elif delta.get("tool_calls"):
                        for tc in delta["tool_calls"]:
                            yield {
                                "type": "tool_call",
                                "index": tc.get("index", 0),
                                "id": tc.get("id"),
                                "name": tc.get("function", {}).get("name"),
                                "arguments": tc.get("function", {}).get("arguments"),
                            }

                except json.JSONDecodeError:
                    continue
