"""
Unified Tool Runtime Bridge

Provides backward-compatible unified tool runtime by wrapping
the core unified module.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable

from .unified import (
    ToolRuntime,
    ToolRuntimeConfig,
    ToolDefinition,
    ToolSuite,
    ToolCallRequest,
    ToolCallResult,
    create_tool_runtime,
    create_unified_tool_suite,
)


# Re-export with unified names
UnifiedToolRuntime = ToolRuntime
UnifiedToolRuntimeConfig = ToolRuntimeConfig
UnifiedToolDefinition = ToolDefinition
UnifiedToolSuite = ToolSuite


@dataclass
class ToolExecutionContext:
    """Context for tool execution."""
    working_dir: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


def create_full_tool_runtime(
    working_dir: str = ".",
    config: Optional[ToolRuntimeConfig] = None,
) -> ToolRuntime:
    """Create a fully-configured tool runtime with all tools."""
    runtime = create_tool_runtime(config)
    suite = create_unified_tool_suite(working_dir)
    runtime.register_suite(suite)
    return runtime


__all__ = [
    "UnifiedToolRuntime",
    "UnifiedToolRuntimeConfig",
    "UnifiedToolDefinition",
    "UnifiedToolSuite",
    "ToolExecutionContext",
    "create_full_tool_runtime",
]
