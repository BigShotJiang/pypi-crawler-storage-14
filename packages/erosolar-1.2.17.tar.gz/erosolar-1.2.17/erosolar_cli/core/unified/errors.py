"""
Unified Error Handling

Structured error system with severity levels, auto-fix capabilities,
and recovery strategies.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Literal, Optional, Union

from .types import ErrorCategory, ErrorSeverity, ErrorSuggestion, StructuredErrorData


# ============================================================================
# Base Structured Error
# ============================================================================

class StructuredError(Exception):
    """Base class for all structured errors."""

    def __init__(
        self,
        message: str,
        *,
        code: Optional[str] = None,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        category: Optional[ErrorCategory] = None,
        suggestions: Optional[List[ErrorSuggestion]] = None,
        recoverable: Optional[bool] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.code = code or self._infer_code(message)
        self.severity = severity
        self.category = category or self._infer_category(message)
        self.suggestions = suggestions or []
        self.recoverable = recoverable if recoverable is not None else self._infer_recoverable()
        self.metadata = metadata or {}
        self.timestamp = time.time()

    def _infer_code(self, message: str) -> str:
        """Infer error code from message."""
        msg_lower = message.lower()
        if "permission" in msg_lower or "denied" in msg_lower:
            return "PERMISSION_DENIED"
        if "not found" in msg_lower or "missing" in msg_lower:
            return "NOT_FOUND"
        if "timeout" in msg_lower:
            return "TIMEOUT"
        if "validation" in msg_lower or "invalid" in msg_lower:
            return "VALIDATION_ERROR"
        if "network" in msg_lower or "connection" in msg_lower:
            return "NETWORK_ERROR"
        return "UNKNOWN_ERROR"

    def _infer_category(self, message: str) -> ErrorCategory:
        """Infer category from message."""
        msg_lower = message.lower()
        if "dangerous" in msg_lower or "unsafe" in msg_lower:
            return ErrorCategory.DANGEROUS
        if "blocked" in msg_lower or "not allowed" in msg_lower:
            return ErrorCategory.BLOCKED
        if "validation" in msg_lower or "invalid" in msg_lower:
            return ErrorCategory.VALIDATION
        if "resource" in msg_lower or "limit" in msg_lower:
            return ErrorCategory.RESOURCE
        if "context" in msg_lower or "token" in msg_lower:
            return ErrorCategory.CONTEXT
        if "provider" in msg_lower or "api" in msg_lower:
            return ErrorCategory.PROVIDER
        if "tool" in msg_lower:
            return ErrorCategory.TOOL
        if "permission" in msg_lower:
            return ErrorCategory.PERMISSION
        if "network" in msg_lower:
            return ErrorCategory.NETWORK
        return ErrorCategory.UNKNOWN

    def _infer_recoverable(self) -> bool:
        """Infer if error is recoverable."""
        return self.severity != ErrorSeverity.CRITICAL

    async def try_auto_fix(self) -> Dict[str, Any]:
        """Try to auto-fix the error."""
        for suggestion in self.suggestions:
            if suggestion.auto_fixable and suggestion.fix_fn:
                try:
                    result = suggestion.fix_fn()
                    if asyncio.iscoroutine(result):
                        result = await result
                    if result:
                        return {"fixed": True, "result": result}
                except Exception as e:
                    return {"fixed": False, "error": str(e)}
        return {"fixed": False}

    def to_dict(self) -> StructuredErrorData:
        """Convert to structured error data."""
        return StructuredErrorData(
            code=self.code,
            message=str(self),
            severity=self.severity,
            category=self.category,
            suggestions=[
                ErrorSuggestion(
                    action=s.action,
                    description=s.description,
                    auto_fixable=s.auto_fixable,
                )
                for s in self.suggestions
            ],
            recoverable=self.recoverable,
            metadata=self.metadata,
        )

    def to_display_string(self) -> str:
        """Format for display."""
        lines = [f"[{self.severity.value.upper()}] {self}"]

        if self.suggestions:
            lines.append("\nSuggestions:")
            for suggestion in self.suggestions:
                lines.append(f"  - {suggestion.action}: {suggestion.description}")

        return "\n".join(lines)


# ============================================================================
# Specific Error Types
# ============================================================================

class DangerousOperationError(StructuredError):
    """Error for dangerous operations that could cause harm."""

    def __init__(
        self,
        message: str,
        operation: str,
        safe_alternatives: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        safe_alternatives = safe_alternatives or []
        suggestions = [
            ErrorSuggestion(
                action="Use safe alternative",
                description=alt,
                auto_fixable=False,
            )
            for alt in safe_alternatives
        ]

        super().__init__(
            message,
            code="DANGEROUS_OPERATION",
            severity=ErrorSeverity.CRITICAL,
            category=ErrorCategory.DANGEROUS,
            suggestions=suggestions,
            recoverable=False,
            metadata={**(metadata or {}), "operation": operation, "safe_alternatives": safe_alternatives},
        )

        self.operation = operation
        self.safe_alternatives = safe_alternatives


class BlockedOperationError(StructuredError):
    """Error for blocked operations due to policy."""

    def __init__(
        self,
        message: str,
        operation: str,
        policy: str,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(
            message,
            code="BLOCKED_OPERATION",
            severity=ErrorSeverity.ERROR,
            category=ErrorCategory.BLOCKED,
            suggestions=[
                ErrorSuggestion(
                    action="Review policy",
                    description=f"This operation is blocked by policy: {policy}",
                    auto_fixable=False,
                )
            ],
            recoverable=False,
            metadata={**(metadata or {}), "operation": operation, "policy": policy},
        )

        self.operation = operation
        self.policy = policy


class ValidationError(StructuredError):
    """Error for validation failures."""

    def __init__(
        self,
        message: str,
        field: str,
        *,
        expected_type: Optional[str] = None,
        actual_value: Any = None,
        examples: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        suggestions = []

        if expected_type:
            suggestions.append(ErrorSuggestion(
                action="Fix type",
                description=f"Expected type: {expected_type}",
                auto_fixable=False,
            ))

        if examples:
            suggestions.append(ErrorSuggestion(
                action="See examples",
                description=", ".join(examples),
                auto_fixable=False,
            ))

        super().__init__(
            message,
            code="VALIDATION_ERROR",
            severity=ErrorSeverity.ERROR,
            category=ErrorCategory.VALIDATION,
            suggestions=suggestions,
            recoverable=True,
            metadata={**(metadata or {}), "field": field, "expected_type": expected_type},
        )

        self.field = field
        self.expected_type = expected_type
        self.actual_value = actual_value


class ResourceLimitError(StructuredError):
    """Error for resource limits."""

    def __init__(
        self,
        message: str,
        resource: str,
        limit: int,
        current: int,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(
            message,
            code="RESOURCE_LIMIT",
            severity=ErrorSeverity.ERROR,
            category=ErrorCategory.RESOURCE,
            suggestions=[
                ErrorSuggestion(
                    action="Reduce usage",
                    description=f"Current: {current}, Limit: {limit}",
                    auto_fixable=False,
                )
            ],
            recoverable=True,
            metadata={**(metadata or {}), "resource": resource, "limit": limit, "current": current},
        )

        self.resource = resource
        self.limit = limit
        self.current = current


class ContextOverflowError(StructuredError):
    """Error for context overflow."""

    def __init__(
        self,
        message: str,
        max_tokens: int,
        current_tokens: int,
        truncatable: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        suggestions = []

        if truncatable:
            suggestions.append(ErrorSuggestion(
                action="Truncate context",
                description="Older messages can be removed to free up space",
                auto_fixable=True,
            ))

        suggestions.append(ErrorSuggestion(
            action="Reduce input",
            description=f"Reduce input size by {current_tokens - max_tokens} tokens",
            auto_fixable=False,
        ))

        super().__init__(
            message,
            code="CONTEXT_OVERFLOW",
            severity=ErrorSeverity.WARNING,
            category=ErrorCategory.CONTEXT,
            suggestions=suggestions,
            recoverable=truncatable,
            metadata={**(metadata or {}), "max_tokens": max_tokens, "current_tokens": current_tokens},
        )

        self.max_tokens = max_tokens
        self.current_tokens = current_tokens
        self.truncatable = truncatable


class ProviderError(StructuredError):
    """Error for provider/API issues."""

    def __init__(
        self,
        message: str,
        provider_id: str,
        *,
        status_code: Optional[int] = None,
        retryable: Optional[bool] = None,
        retry_after_ms: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        is_retryable = retryable if retryable is not None else (status_code >= 500 if status_code else False)
        suggestions = []

        if is_retryable:
            desc = f"Retry after {retry_after_ms}ms" if retry_after_ms else "Retry the request"
            suggestions.append(ErrorSuggestion(
                action="Retry",
                description=desc,
                auto_fixable=True,
            ))

        super().__init__(
            message,
            code="PROVIDER_ERROR",
            severity=ErrorSeverity.ERROR if status_code == 500 else ErrorSeverity.WARNING,
            category=ErrorCategory.PROVIDER,
            suggestions=suggestions,
            recoverable=is_retryable,
            metadata={**(metadata or {}), "provider_id": provider_id, "status_code": status_code},
        )

        self.provider_id = provider_id
        self.status_code = status_code
        self.retryable = is_retryable


class ToolExecutionError(StructuredError):
    """Error for tool execution failures."""

    def __init__(
        self,
        message: str,
        tool_name: str,
        phase: Literal["validation", "execution", "timeout"],
        metadata: Optional[Dict[str, Any]] = None,
    ):
        suggestions = []

        if phase == "validation":
            suggestions.append(ErrorSuggestion(
                action="Fix arguments",
                description="Check the tool arguments match the expected schema",
                auto_fixable=False,
            ))
        elif phase == "timeout":
            suggestions.append(ErrorSuggestion(
                action="Increase timeout",
                description="The operation took too long - try increasing the timeout",
                auto_fixable=False,
            ))

        super().__init__(
            message,
            code="TOOL_EXECUTION_ERROR",
            severity=ErrorSeverity.WARNING if phase == "timeout" else ErrorSeverity.ERROR,
            category=ErrorCategory.TOOL,
            suggestions=suggestions,
            recoverable=phase != "validation",
            metadata={**(metadata or {}), "tool_name": tool_name, "phase": phase},
        )

        self.tool_name = tool_name
        self.phase = phase


class NetworkError(StructuredError):
    """Error for network issues."""

    def __init__(
        self,
        message: str,
        *,
        url: Optional[str] = None,
        retryable: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(
            message,
            code="NETWORK_ERROR",
            severity=ErrorSeverity.ERROR,
            category=ErrorCategory.NETWORK,
            suggestions=[
                ErrorSuggestion(
                    action="Check connection",
                    description="Verify network connectivity",
                    auto_fixable=False,
                ),
                ErrorSuggestion(
                    action="Retry",
                    description="The request can be retried",
                    auto_fixable=True,
                ),
            ],
            recoverable=retryable,
            metadata={**(metadata or {}), "url": url},
        )

        self.url = url
        self.retryable = retryable


# ============================================================================
# Error Recovery
# ============================================================================

RecoveryStrategy = Literal["retry", "fallback", "skip", "abort", "prompt_user"]


@dataclass
class RecoveryAttempt:
    """Result of a recovery attempt."""
    strategy: RecoveryStrategy
    success: bool
    result: Any = None
    error: Optional[str] = None


class ErrorRecoveryManager:
    """Error recovery manager."""

    def __init__(
        self,
        max_retries: int = 3,
        retry_delay_ms: int = 1000,
    ):
        self.max_retries = max_retries
        self.retry_delay_ms = retry_delay_ms

    async def attempt_recovery(
        self,
        error: StructuredError,
        strategies: List[RecoveryStrategy],
        *,
        retry_fn: Optional[Callable] = None,
        fallback_fn: Optional[Callable] = None,
    ) -> RecoveryAttempt:
        """Attempt recovery for an error."""
        for strategy in strategies:
            result = await self._try_strategy(error, strategy, retry_fn, fallback_fn)
            if result.success:
                return result

        return RecoveryAttempt(strategy="abort", success=False, error="All recovery strategies failed")

    async def _try_strategy(
        self,
        error: StructuredError,
        strategy: RecoveryStrategy,
        retry_fn: Optional[Callable],
        fallback_fn: Optional[Callable],
    ) -> RecoveryAttempt:
        """Try a specific recovery strategy."""
        if strategy == "retry":
            if not retry_fn:
                return RecoveryAttempt(strategy=strategy, success=False, error="No retry function provided")
            return await self._retry_with_backoff(retry_fn)

        elif strategy == "fallback":
            if not fallback_fn:
                return RecoveryAttempt(strategy=strategy, success=False, error="No fallback function provided")
            try:
                result = fallback_fn()
                if asyncio.iscoroutine(result):
                    result = await result
                return RecoveryAttempt(strategy=strategy, success=True, result=result)
            except Exception as e:
                return RecoveryAttempt(strategy=strategy, success=False, error=str(e))

        elif strategy == "skip":
            return RecoveryAttempt(strategy=strategy, success=True)

        elif strategy == "abort":
            return RecoveryAttempt(strategy=strategy, success=False, error=str(error))

        elif strategy == "prompt_user":
            return RecoveryAttempt(strategy=strategy, success=False, error="User intervention required")

        return RecoveryAttempt(strategy=strategy, success=False, error="Unknown strategy")

    async def _retry_with_backoff(self, fn: Callable) -> RecoveryAttempt:
        """Retry with exponential backoff."""
        last_error = None

        for attempt in range(self.max_retries):
            try:
                result = fn()
                if asyncio.iscoroutine(result):
                    result = await result
                return RecoveryAttempt(strategy="retry", success=True, result=result)
            except Exception as e:
                last_error = e
                delay = (self.retry_delay_ms / 1000) * (2 ** attempt)
                await asyncio.sleep(delay)

        return RecoveryAttempt(
            strategy="retry",
            success=False,
            error=str(last_error) if last_error else "Max retries exceeded"
        )


# ============================================================================
# Utility Functions
# ============================================================================

def is_structured_error(error: Any) -> bool:
    """Check if an error is a structured error."""
    return isinstance(error, StructuredError)


def wrap_error(error: Any, category: Optional[ErrorCategory] = None) -> StructuredError:
    """Wrap any error as a structured error."""
    if is_structured_error(error):
        return error

    if isinstance(error, Exception):
        return StructuredError(str(error), category=category)

    return StructuredError(str(error), category=category)


def create_error_recovery_manager(
    max_retries: int = 3,
    retry_delay_ms: int = 1000,
) -> ErrorRecoveryManager:
    """Create error recovery manager."""
    return ErrorRecoveryManager(max_retries=max_retries, retry_delay_ms=retry_delay_ms)
