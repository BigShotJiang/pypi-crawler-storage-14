"""
Unified Version Manager

Comprehensive semantic versioning system with compatibility checking,
dependency resolution, and self-upgrade capabilities.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple

from .types import SemanticVersion, VersionBump, VersionConstraint


# ============================================================================
# Version Parsing and Formatting
# ============================================================================

def parse_version(version_str: str) -> SemanticVersion:
    """Parse a semantic version string."""
    pattern = r'^(\d+)\.(\d+)\.(\d+)(?:-([a-zA-Z0-9.-]+))?(?:\+([a-zA-Z0-9.-]+))?$'
    match = re.match(pattern, version_str.strip())

    if not match:
        raise ValueError(f"Invalid version string: {version_str}")

    return SemanticVersion(
        major=int(match.group(1)),
        minor=int(match.group(2)),
        patch=int(match.group(3)),
        prerelease=match.group(4),
        build=match.group(5),
    )


def format_version(version: SemanticVersion) -> str:
    """Format a semantic version to string."""
    return str(version)


# ============================================================================
# Version Comparison
# ============================================================================

def compare_versions(a: SemanticVersion, b: SemanticVersion) -> int:
    """
    Compare two semantic versions.
    Returns: -1 if a < b, 0 if a == b, 1 if a > b
    """
    # Compare major, minor, patch
    if a.major != b.major:
        return -1 if a.major < b.major else 1
    if a.minor != b.minor:
        return -1 if a.minor < b.minor else 1
    if a.patch != b.patch:
        return -1 if a.patch < b.patch else 1

    # Compare prerelease
    # A version without prerelease > version with prerelease
    if a.prerelease and not b.prerelease:
        return -1
    if not a.prerelease and b.prerelease:
        return 1

    if a.prerelease and b.prerelease:
        a_parts = a.prerelease.split('.')
        b_parts = b.prerelease.split('.')

        for i in range(max(len(a_parts), len(b_parts))):
            if i >= len(a_parts):
                return -1
            if i >= len(b_parts):
                return 1

            a_part = a_parts[i]
            b_part = b_parts[i]

            # Try numeric comparison
            try:
                a_num = int(a_part)
                b_num = int(b_part)
                if a_num != b_num:
                    return -1 if a_num < b_num else 1
            except ValueError:
                # String comparison
                if a_part != b_part:
                    return -1 if a_part < b_part else 1

    return 0


def version_lt(a: SemanticVersion, b: SemanticVersion) -> bool:
    """Check if version a is less than version b."""
    return compare_versions(a, b) < 0


def version_lte(a: SemanticVersion, b: SemanticVersion) -> bool:
    """Check if version a is less than or equal to version b."""
    return compare_versions(a, b) <= 0


def version_gt(a: SemanticVersion, b: SemanticVersion) -> bool:
    """Check if version a is greater than version b."""
    return compare_versions(a, b) > 0


def version_gte(a: SemanticVersion, b: SemanticVersion) -> bool:
    """Check if version a is greater than or equal to version b."""
    return compare_versions(a, b) >= 0


def version_eq(a: SemanticVersion, b: SemanticVersion) -> bool:
    """Check if two versions are equal."""
    return compare_versions(a, b) == 0


# ============================================================================
# Version Bumping
# ============================================================================

def bump_version(version: SemanticVersion, bump: VersionBump) -> SemanticVersion:
    """Bump a version."""
    major = version.major
    minor = version.minor
    patch = version.patch
    prerelease = version.prerelease

    if bump == "major":
        major += 1
        minor = 0
        patch = 0
        prerelease = None
    elif bump == "minor":
        minor += 1
        patch = 0
        prerelease = None
    elif bump == "patch":
        patch += 1
        prerelease = None
    elif bump == "prerelease":
        if prerelease:
            # Increment prerelease number if it ends with a number
            match = re.match(r'^(.*)\.(\d+)$', prerelease)
            if match:
                prerelease = f"{match.group(1)}.{int(match.group(2)) + 1}"
            else:
                prerelease = f"{prerelease}.1"
        else:
            prerelease = "alpha.1"

    return SemanticVersion(
        major=major,
        minor=minor,
        patch=patch,
        prerelease=prerelease,
        build=version.build,
    )


# ============================================================================
# Version Constraints
# ============================================================================

def parse_constraint(constraint_str: str) -> VersionConstraint:
    """Parse a version constraint string."""
    pattern = r'^([=<>^~]+)?\s*(\d+\.\d+\.\d+.*)$'
    match = re.match(pattern, constraint_str.strip())

    if not match:
        raise ValueError(f"Invalid version constraint: {constraint_str}")

    operator = match.group(1) or "="
    version = parse_version(match.group(2))

    return VersionConstraint(operator=operator, version=version)


def satisfies_constraint(version: SemanticVersion, constraint: VersionConstraint) -> bool:
    """Check if a version satisfies a constraint."""
    op = constraint.operator
    target = constraint.version

    if op == "=":
        return version_eq(version, target)
    elif op == ">":
        return version_gt(version, target)
    elif op == ">=":
        return version_gte(version, target)
    elif op == "<":
        return version_lt(version, target)
    elif op == "<=":
        return version_lte(version, target)
    elif op == "^":
        # Compatible with: same major version, >= given version
        return version.major == target.major and version_gte(version, target)
    elif op == "~":
        # Approximately equivalent: same major.minor, >= given version
        return (
            version.major == target.major and
            version.minor == target.minor and
            version_gte(version, target)
        )

    return False


def satisfies_all_constraints(
    version: SemanticVersion,
    constraints: List[VersionConstraint]
) -> bool:
    """Check if a version satisfies all constraints (AND)."""
    return all(satisfies_constraint(version, c) for c in constraints)


def satisfies(version_str: str, constraint_str: str) -> bool:
    """Parse and check a constraint string."""
    version = parse_version(version_str)
    constraint = parse_constraint(constraint_str)
    return satisfies_constraint(version, constraint)


# ============================================================================
# Version Manager Class
# ============================================================================

@dataclass
class VersionRecord:
    """A version record."""
    id: str
    version: SemanticVersion
    release_date: str
    changelog: Optional[str] = None
    breaking: bool = False


@dataclass
class VersionManagerConfig:
    """Configuration for the version manager."""
    current_version: str
    data_dir: Optional[str] = None
    check_interval: Optional[int] = None


class VersionManager:
    """
    Version Manager.

    Manages version tracking, compatibility checking, and upgrade paths.
    """

    def __init__(self, config: VersionManagerConfig):
        self.config = config
        self.current_version = parse_version(config.current_version)
        self.version_history: List[VersionRecord] = []

    def get_current(self) -> SemanticVersion:
        """Get current version."""
        return SemanticVersion(
            major=self.current_version.major,
            minor=self.current_version.minor,
            patch=self.current_version.patch,
            prerelease=self.current_version.prerelease,
            build=self.current_version.build,
        )

    def get_current_string(self) -> str:
        """Get current version string."""
        return str(self.current_version)

    def is_upgrade_available(self, latest_version: str) -> bool:
        """Check if an upgrade is available."""
        latest = parse_version(latest_version)
        return version_gt(latest, self.current_version)

    def check_compatibility(self, required_version: str) -> Dict[str, Any]:
        """Check compatibility with a required version."""
        required = parse_version(required_version)

        if version_lt(self.current_version, required):
            return {
                "compatible": False,
                "reason": f"Current version {self.current_version} is less than required {required_version}",
            }

        # Check for major version compatibility
        if self.current_version.major != required.major:
            return {
                "compatible": False,
                "reason": f"Major version mismatch: {self.current_version.major} vs {required.major}",
            }

        return {"compatible": True}

    def record_version(self, record: VersionRecord) -> None:
        """Add a version to history."""
        self.version_history.append(record)
        self.version_history.sort(key=lambda r: (r.version.major, r.version.minor, r.version.patch))

    def get_history(self) -> List[VersionRecord]:
        """Get version history."""
        return list(self.version_history)

    def find_matching_versions(self, constraint_str: str) -> List[VersionRecord]:
        """Find versions matching a constraint."""
        constraint = parse_constraint(constraint_str)
        return [r for r in self.version_history if satisfies_constraint(r.version, constraint)]

    def get_upgrade_path(self, target_version: str) -> List[VersionRecord]:
        """Get upgrade path from current to target."""
        target = parse_version(target_version)

        if version_lte(target, self.current_version):
            return []

        return [
            r for r in self.version_history
            if version_gt(r.version, self.current_version) and version_lte(r.version, target)
        ]

    def has_breaking_changes(self, target_version: str) -> bool:
        """Check if upgrade path has breaking changes."""
        path = self.get_upgrade_path(target_version)
        return any(r.breaking for r in path)


# ============================================================================
# Plugin Dependency Resolution
# ============================================================================

@dataclass
class PluginDependency:
    """A plugin dependency."""
    plugin_id: str
    version_constraint: str


@dataclass
class ResolvedDependency:
    """A resolved dependency."""
    plugin_id: str
    resolved_version: SemanticVersion
    constraint: VersionConstraint


@dataclass
class DependencyConflict:
    """A dependency conflict."""
    plugin_id: str
    conflicting_constraints: List[VersionConstraint]
    reason: str


class PluginDependencyResolver:
    """
    Plugin Dependency Resolver.

    Resolves plugin dependencies and detects version conflicts.
    """

    def __init__(self):
        self.available_versions: Dict[str, List[SemanticVersion]] = {}

    def register_versions(self, plugin_id: str, versions: List[str]) -> None:
        """Register available versions for a plugin."""
        parsed = [parse_version(v) for v in versions]
        # Sort descending
        parsed.sort(key=lambda v: (v.major, v.minor, v.patch), reverse=True)
        self.available_versions[plugin_id] = parsed

    def resolve(
        self,
        dependencies: List[PluginDependency]
    ) -> Dict[str, List]:
        """Resolve dependencies."""
        resolved: List[ResolvedDependency] = []
        conflicts: List[DependencyConflict] = []

        # Group constraints by plugin
        constraints_by_plugin: Dict[str, List[VersionConstraint]] = {}

        for dep in dependencies:
            constraint = parse_constraint(dep.version_constraint)
            if dep.plugin_id not in constraints_by_plugin:
                constraints_by_plugin[dep.plugin_id] = []
            constraints_by_plugin[dep.plugin_id].append(constraint)

        # Resolve each plugin
        for plugin_id, constraints in constraints_by_plugin.items():
            versions = self.available_versions.get(plugin_id, [])

            # Find version satisfying all constraints
            matching_version = None
            for v in versions:
                if satisfies_all_constraints(v, constraints):
                    matching_version = v
                    break

            if matching_version:
                resolved.append(ResolvedDependency(
                    plugin_id=plugin_id,
                    resolved_version=matching_version,
                    constraint=constraints[0],
                ))
            else:
                conflicts.append(DependencyConflict(
                    plugin_id=plugin_id,
                    conflicting_constraints=constraints,
                    reason=f"No version of {plugin_id} satisfies all constraints",
                ))

        return {"resolved": resolved, "conflicts": conflicts}


# ============================================================================
# Self-Upgrade Manager
# ============================================================================

@dataclass
class UpgradeResult:
    """Result of an upgrade attempt."""
    success: bool
    from_version: str
    to_version: str
    changelog: Optional[str] = None
    error: Optional[str] = None


@dataclass
class SelfUpgradeConfig:
    """Configuration for self-upgrade."""
    current_version: str
    release_url: Optional[str] = None
    backup_dir: Optional[str] = None


class SelfUpgradeManager:
    """
    Self-Upgrade Manager.

    Handles self-upgrade with backup and rollback support.
    """

    def __init__(self, config: SelfUpgradeConfig):
        self.config = config
        self.current_version = parse_version(config.current_version)
        self.backup_version: Optional[SemanticVersion] = None

    async def check_for_upgrades(self) -> Dict[str, Any]:
        """Check for available upgrades."""
        # In a real implementation, this would check a release server
        return {"available": False}

    async def upgrade(self, target_version: str) -> UpgradeResult:
        """Perform upgrade."""
        target = parse_version(target_version)

        if version_lte(target, self.current_version):
            return UpgradeResult(
                success=False,
                from_version=str(self.current_version),
                to_version=target_version,
                error="Target version is not newer than current version",
            )

        # Create backup
        self.backup_version = SemanticVersion(
            major=self.current_version.major,
            minor=self.current_version.minor,
            patch=self.current_version.patch,
            prerelease=self.current_version.prerelease,
            build=self.current_version.build,
        )

        try:
            # In a real implementation, this would download and install
            old_version = str(self.current_version)
            self.current_version = target

            return UpgradeResult(
                success=True,
                from_version=old_version,
                to_version=target_version,
            )
        except Exception as e:
            return UpgradeResult(
                success=False,
                from_version=str(self.current_version),
                to_version=target_version,
                error=str(e),
            )

    async def rollback(self) -> bool:
        """Rollback to previous version."""
        if not self.backup_version:
            return False

        self.current_version = self.backup_version
        self.backup_version = None
        return True

    def get_current_version(self) -> str:
        """Get current version."""
        return str(self.current_version)


# ============================================================================
# Utility Functions
# ============================================================================

def create_version_manager(current_version: str) -> VersionManager:
    """Create a version manager with default config."""
    return VersionManager(VersionManagerConfig(current_version=current_version))


def is_compatible(current: str, required: str) -> bool:
    """Quick version check."""
    current_v = parse_version(current)
    required_v = parse_version(required)
    return current_v.major == required_v.major and version_gte(current_v, required_v)
