"""
User Preferences Manager

Stores and retrieves user preferences like default model selection.
Preferences are stored in ~/.erosolar/preferences.json

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class ProviderPreferences:
    """Preferences for a specific provider."""
    default_model: Optional[str] = None
    last_used_model: Optional[str] = None
    favorite_models: List[str] = field(default_factory=list)


@dataclass
class UserPreferences:
    """User preferences for erosolar CLI."""
    # Global default provider (None = auto-detect)
    default_provider: Optional[str] = None

    # Per-provider preferences
    provider_preferences: Dict[str, ProviderPreferences] = field(default_factory=dict)

    # Global default model (overrides provider default)
    default_model: Optional[str] = None

    # Display preferences
    show_provider_status: bool = True
    enable_alpha_zero: bool = True

    # Session preferences
    auto_save_sessions: bool = False

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UserPreferences':
        """Create from dictionary."""
        provider_prefs = {}
        for provider_id, prefs in data.get('provider_preferences', {}).items():
            provider_prefs[provider_id] = ProviderPreferences(**prefs)

        return cls(
            default_provider=data.get('default_provider'),
            provider_preferences=provider_prefs,
            default_model=data.get('default_model'),
            show_provider_status=data.get('show_provider_status', True),
            enable_alpha_zero=data.get('enable_alpha_zero', True),
            auto_save_sessions=data.get('auto_save_sessions', False),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            'default_provider': self.default_provider,
            'provider_preferences': {
                k: asdict(v) for k, v in self.provider_preferences.items()
            },
            'default_model': self.default_model,
            'show_provider_status': self.show_provider_status,
            'enable_alpha_zero': self.enable_alpha_zero,
            'auto_save_sessions': self.auto_save_sessions,
        }


class PreferencesManager:
    """Manages user preferences storage and retrieval."""

    _instance: Optional['PreferencesManager'] = None

    def __new__(cls) -> 'PreferencesManager':
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._preferences = None
            cls._instance._preferences_path = None
        return cls._instance

    @property
    def preferences_path(self) -> Path:
        """Get path to preferences file."""
        if self._preferences_path is None:
            config_dir = Path.home() / ".erosolar"
            config_dir.mkdir(exist_ok=True)
            self._preferences_path = config_dir / "preferences.json"
        return self._preferences_path

    def load(self) -> UserPreferences:
        """Load user preferences from disk."""
        if self._preferences is not None:
            return self._preferences

        if self.preferences_path.exists():
            try:
                with open(self.preferences_path, 'r') as f:
                    data = json.load(f)
                self._preferences = UserPreferences.from_dict(data)
            except (json.JSONDecodeError, TypeError, KeyError):
                self._preferences = UserPreferences()
        else:
            self._preferences = UserPreferences()

        return self._preferences

    def save(self) -> None:
        """Save user preferences to disk."""
        if self._preferences is None:
            return

        with open(self.preferences_path, 'w') as f:
            json.dump(self._preferences.to_dict(), f, indent=2)

    def get_default_model(self, provider_id: Optional[str] = None) -> Optional[str]:
        """
        Get the default model for a provider.

        Priority:
        1. Global default_model (if set)
        2. Provider-specific default_model
        3. None (use provider's default)
        """
        prefs = self.load()

        # Global default takes precedence
        if prefs.default_model:
            return prefs.default_model

        # Provider-specific default
        if provider_id and provider_id in prefs.provider_preferences:
            return prefs.provider_preferences[provider_id].default_model

        return None

    def set_default_model(self, model: str, provider_id: Optional[str] = None) -> None:
        """
        Set the default model.

        Args:
            model: Model to set as default
            provider_id: If set, makes this provider-specific. If None, sets global default.
        """
        prefs = self.load()

        if provider_id:
            if provider_id not in prefs.provider_preferences:
                prefs.provider_preferences[provider_id] = ProviderPreferences()
            prefs.provider_preferences[provider_id].default_model = model
        else:
            prefs.default_model = model

        self.save()

    def clear_default_model(self, provider_id: Optional[str] = None) -> None:
        """Clear the default model setting."""
        prefs = self.load()

        if provider_id:
            if provider_id in prefs.provider_preferences:
                prefs.provider_preferences[provider_id].default_model = None
        else:
            prefs.default_model = None

        self.save()

    def get_default_provider(self) -> Optional[str]:
        """Get the default provider (None = auto-detect)."""
        prefs = self.load()
        return prefs.default_provider

    def set_default_provider(self, provider_id: Optional[str]) -> None:
        """Set the default provider."""
        prefs = self.load()
        prefs.default_provider = provider_id
        self.save()

    def record_model_usage(self, provider_id: str, model: str) -> None:
        """Record that a model was used (for "last used" feature)."""
        prefs = self.load()

        if provider_id not in prefs.provider_preferences:
            prefs.provider_preferences[provider_id] = ProviderPreferences()

        prefs.provider_preferences[provider_id].last_used_model = model
        self.save()


# Global instance
preferences = PreferencesManager()


def get_user_default_model(provider_id: Optional[str] = None) -> Optional[str]:
    """Get user's default model preference."""
    return preferences.get_default_model(provider_id)


def set_user_default_model(model: str, provider_id: Optional[str] = None) -> None:
    """Set user's default model preference."""
    preferences.set_default_model(model, provider_id)


def get_user_default_provider() -> Optional[str]:
    """Get user's default provider preference."""
    return preferences.get_default_provider()


def set_user_default_provider(provider_id: Optional[str]) -> None:
    """Set user's default provider preference."""
    preferences.set_default_provider(provider_id)
