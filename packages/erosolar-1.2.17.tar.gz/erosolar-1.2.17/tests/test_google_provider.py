from types import SimpleNamespace
from typing import Any, List

import pytest

from erosolar_cli.core.types import AssistantMessage, SystemMessage, ToolMessage, UserMessage
from erosolar_cli.providers.google_provider import GoogleProvider, GoogleProviderOptions


class _StubModel:
    def __init__(self, responses: List[Any]):
        self._responses = responses
        self.calls: list[dict[str, Any]] = []

    async def generate_content_async(self, *args, **kwargs):
        self.calls.append({"args": args, "kwargs": kwargs})
        return self._responses.pop(0)


def _configure_stub(monkeypatch: pytest.MonkeyPatch, responses: List[Any]) -> _StubModel:
    monkeypatch.setattr("google.generativeai.configure", lambda **_: None)
    stub_model = _StubModel(responses)
    monkeypatch.setattr("google.generativeai.GenerativeModel", lambda *_, **__: stub_model)
    return stub_model


@pytest.mark.asyncio
async def test_google_provider_basic_message(monkeypatch: pytest.MonkeyPatch) -> None:
    stub_response = SimpleNamespace(text="hello world", usage_metadata=SimpleNamespace(prompt_token_count=1))
    model_stub = _configure_stub(monkeypatch, [stub_response])

    provider = GoogleProvider(GoogleProviderOptions(api_key="test", model="gemini-test"))
    result = await provider.generate([], [])

    assert result.type == "message"
    assert result.content == "hello world"
    assert model_stub.calls  # ensure model invoked


@pytest.mark.asyncio
async def test_google_provider_tool_calls(monkeypatch: pytest.MonkeyPatch) -> None:
    tool_call = SimpleNamespace(name="testTool", args={"foo": "bar"}, id="123")
    part = SimpleNamespace(function_call=tool_call)
    content = SimpleNamespace(parts=[part])
    candidate = SimpleNamespace(content=content)
    response = SimpleNamespace(text="using tool", candidates=[candidate], usage_metadata=None)
    _configure_stub(monkeypatch, [response])

    provider = GoogleProvider(GoogleProviderOptions(api_key="test", model="gemini-test"))
    messages = [
        SystemMessage(role="system", content="sys"),
        UserMessage(role="user", content="hi"),
        AssistantMessage(role="assistant", content="", tool_calls=[]),
        ToolMessage(role="tool", name="t", content="{}", tool_call_id="id"),
    ]
    result = await provider.generate(messages, [])

    assert result.type == "tool_calls"
    assert result.tool_calls[0].name == "testTool"
    assert result.tool_calls[0].arguments == {"foo": "bar"}
