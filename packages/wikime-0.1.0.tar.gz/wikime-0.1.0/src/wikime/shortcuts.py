import subprocess
from pathlib import Path


def open(path: Path, cwd: Path = Path.cwd()):
    subprocess.Popen(
        # ["open", path],
        ["code", cwd, "--goto", path],
        close_fds=True,
    )
