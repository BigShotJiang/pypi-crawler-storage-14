from django.conf import settings
from django.http import HttpRequest, HttpResponse
from django.shortcuts import redirect
from django.views.generic import View

from wikime import shortcuts


class OpenMixin(View):
    def post(self, request: HttpRequest, **kwargs) -> HttpResponse:
        shortcuts.open(self.get_object().path, cwd=settings.BASE_DIR)
        return redirect(request.POST.get("next", request.path))
