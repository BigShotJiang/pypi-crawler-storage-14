from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument("path", type=Path)

    def handle(self, path: Path, **options):
        base: Path = settings.CONTENT_DIR
        post = base / path
        if not post.parent.exists():
            print("Unable to find path", post.parent)
            raise SystemExit(1)
        if post.exists():
            print("Post already exists")
        else:
            with post.open("w") as fp:
                fp.write("---\n")
                fp.write(f"title: {post.stem}\n")
                fp.write("---\n")
        print("Created new post ", post)
