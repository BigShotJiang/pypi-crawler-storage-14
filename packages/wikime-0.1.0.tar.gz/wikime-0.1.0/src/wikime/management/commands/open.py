from pathlib import Path

from django.core.management.base import BaseCommand

from wikime import shortcuts


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument("path", type=Path)
        parser.add_argument("--interactive", action="store_false")

    def handle(self, path, **options):
        shortcuts.open(path)
