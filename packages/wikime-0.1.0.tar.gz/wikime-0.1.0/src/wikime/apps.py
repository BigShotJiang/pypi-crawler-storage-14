import logging
from pathlib import Path

from django.apps import AppConfig
from django.conf import settings
from django.utils.autoreload import BaseReloader, autoreload_started, file_changed

logger = logging.getLogger(__name__)


class WikimeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "wikime"

    def ready(self):
        autoreload_started.connect(register_watches)
        file_changed.connect(process_file_changed)


def register_watches(sender: BaseReloader, **kwargs):
    sender.watch_dir(settings.CONTENT_DIR, "**/*.md")
    sender.watch_dir(settings.CONTENT_DIR, "**/*.markdown")


def process_file_changed(file_path: Path, **kwargs):
    if file_path.suffix in [".md", ".markdown"]:
        print(__file__, file_path, kwargs)
        return True
