from .abc_continuum_object import ABCContinuumObject
from .clusters import SuperComputer
from .data_centers import DataCenter
from .network import Network


class Continuum(ABCContinuumObject):
    superComputers: list[SuperComputer]
    dataCenters: list[DataCenter]
    network: Network

    @property
    def summary(self) -> str:
        result = "Continuum made of :\n"
        result += f"    • {len(self.superComputers)} cluster{'' if len(self.superComputers) <= 1 else 's'} :\n"
        for each_hpc in self.superComputers:
            result += f"        • {each_hpc.summary}\n"
            result += "\n"

        result += f"    • {len(self.dataCenters)} dataCenters :\n"
        for each_datacenter in self.dataCenters:
            result += f"        • {each_datacenter.summary}\n"

        result += f"    • with network graph : {self.network.summary}"

        return result
