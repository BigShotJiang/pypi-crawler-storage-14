from .abc_continuum_object import ABCContinuumObject
from .generic_objects import MeasuredValue
from uuid import UUID
from typing import Annotated
from pydantic import Field, BaseModel


class NetworkEdge(BaseModel):  # TODO: add validation of start and end as node labels
    start: str
    end: str
    throughput: MeasuredValue


class NetworkNode(BaseModel):
    id: UUID
    label: str


class Network(ABCContinuumObject):
    nodes: Annotated[
        list[NetworkNode], Field(description="List of nodes on the network graph")
    ]
    edges: Annotated[
        list[NetworkEdge], Field(description="Description of the edges on the network")
    ]
