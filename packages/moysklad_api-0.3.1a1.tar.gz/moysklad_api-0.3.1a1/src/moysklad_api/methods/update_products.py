from pydantic import Field

from moysklad_api.methods.base import MSMethod
from moysklad_api.types import ProductUpdate


class UpdateProducts(MSMethod[ProductUpdate]):
    __return__ = list[ProductUpdate]
    __api_method__ = "entity/product"

    data: list[ProductUpdate] = Field(..., alias="products")
