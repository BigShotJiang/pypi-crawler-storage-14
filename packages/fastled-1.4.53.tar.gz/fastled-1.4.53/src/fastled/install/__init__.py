"""FastLED install module."""
