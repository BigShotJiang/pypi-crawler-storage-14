#!/bin/bash

# Run this when you want to debug the compiler and you are in interactive
# mode at /js

python compile.py --debug --keep