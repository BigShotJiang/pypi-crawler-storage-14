from .decorators import throttle
from .exceptions import ThrottleException


__version__ = '1.0.1'
__copyright__ = 'Copyright © 2025, Konstantin Tolstikhin'
__author__ = 'Konstantin Tolstikhin'
