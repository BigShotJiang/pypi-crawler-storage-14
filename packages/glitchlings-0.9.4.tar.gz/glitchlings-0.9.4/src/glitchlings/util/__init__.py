from glitchlings.zoo.transforms import KeyNeighborMap
from glitchlings.zoo.transforms import (
    compute_string_diffs as string_diffs,
)

from .keyboards import (
    KEYNEIGHBORS,
    SHIFT_MAPS,
    KeyboardLayouts,
    KeyNeighbors,
    ShiftMap,
    ShiftMaps,
)

__all__ = [
    "SAMPLE_TEXT",
    "string_diffs",
    "KeyNeighborMap",
    "KeyboardLayouts",
    "ShiftMap",
    "ShiftMaps",
    "KeyNeighbors",
    "KEYNEIGHBORS",
    "SHIFT_MAPS",
]

SAMPLE_TEXT = (
    "One morning, when Gregor Samsa woke from troubled dreams, he found himself "
    "transformed in his bed into a horrible vermin. He lay on his armour-like back, and "
    "if he lifted his head a little he could see his brown belly, slightly domed and "
    "divided by arches into stiff sections. The bedding was hardly able to cover it and "
    "seemed ready to slide off any moment. His many legs, pitifully thin compared with "
    "the size of the rest of him, waved about helplessly as he looked."
)
