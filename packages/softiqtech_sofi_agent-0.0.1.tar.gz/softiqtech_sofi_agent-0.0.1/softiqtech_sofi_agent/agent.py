import requests
from agents import Runner, Agent
from .connection import model, config
from .data import website_data # import directly, no HTTP


def fetch_data():
    return website_data

# Load personal data once
WEBSITE_DATA = fetch_data()


# Create Gemini assistant agent
sub_agent = Agent(
    name="SoftiqTech_AI_Assistant_Sofi",
    instructions="""
    You are Sofi - SoftiqTech's website AI agent.
    Always answer professionally and clearly.
    """
    )


async def assistant(user_message: str):
    try:
        web_data = WEBSITE_DATA  # directly loaded
        user_input = f"""
        Here is SoftiqTech's complete website data:
        {web_data}

        User question:
        {user_message}
        """

        # 🟢 Correct Gemini call
        result = await Runner.run(
            sub_agent,
            run_config=config,
            input=user_input
        )

        # Extract output
        if hasattr(result, "final_output"):
            return result.final_output

        return "No response from agent."

    except Exception as e:
        print("AGENT ERROR:", e)
        return "Sorry, I am unable to process your request right now."
