"""Generated from Protobuf definitions for Nebius API."""
