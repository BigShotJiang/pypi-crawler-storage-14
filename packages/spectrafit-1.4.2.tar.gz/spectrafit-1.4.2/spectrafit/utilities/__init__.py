"""Utilities of the spectraFit package."""
