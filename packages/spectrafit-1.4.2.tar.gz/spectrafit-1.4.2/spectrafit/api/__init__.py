"""Reference of the APIs of the SpectraFit package."""
