"""SpectraFit App module."""
