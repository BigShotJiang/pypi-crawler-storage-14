"""Modules for fitting spectra."""

from __future__ import annotations
