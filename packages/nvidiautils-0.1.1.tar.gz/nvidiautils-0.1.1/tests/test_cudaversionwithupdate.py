import random
import pytest
from nvidiautils import CudaVersionWithUpdate


def test_parse():
    v = CudaVersionWithUpdate.from_string("12.9.1")
    assert v.major == 12 and v.minor == 9 and v.update == 1
    for s in ("12", "12.", "12.9", "12.9.", "12.9.1.", "a.b.c"):
        with pytest.raises(ValueError):
            CudaVersionWithUpdate.from_string(s)


def test_format():
    v = CudaVersionWithUpdate(12, 9, 1)
    assert str(v) == "12.9.1"
    v = CudaVersionWithUpdate(1, 0, 0)
    assert str(v) == "1.0.0"


def test_order():
    versions_ordered = [
        CudaVersionWithUpdate.from_string(e)
        for e in ("0.0.0", "0.0.1", "0.1.0", "1.0.0", "1.0.1")
    ]
    for _ in range(1000):
        versions_unordered = versions_ordered[:]
        random.shuffle(versions_unordered)
        assert sorted(versions_unordered) == versions_ordered
