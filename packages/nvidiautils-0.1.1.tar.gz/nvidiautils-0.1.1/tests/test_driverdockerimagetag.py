import pytest
from nvidiautils import DriverDockerImageTag, DriverVersion


def test_parse():
    v = DriverDockerImageTag.from_string("580.82.07-rhcos4.18")
    assert v.version == DriverVersion(580, 82, 7)
    assert v.os == "rhcos4.18"
    for s in ("notavalidversion-rhcos4.18", "580.82.07-unknown22.04", "580.82.07"):
        with pytest.raises(ValueError):
            DriverDockerImageTag.from_string(s)


def test_format():
    v = DriverDockerImageTag(DriverVersion(580, 82, 7), "rhcos4.18")
    assert str(v) == "580.82.07-rhcos4.18"
