import random
import pytest
from nvidiautils import MIGDeviceName


def test_instanciate():
    for args in ((-1, 0, 0), (0, -1, 0), (0, 0, -1)):
        with pytest.raises(ValueError):
            MIGDeviceName(*args)


def test_parse():
    mig = MIGDeviceName.from_string("3g.40gb")
    assert mig.sm_slices == 3
    assert mig.memory_size == 40
    assert mig.compute_instances is None
    mig = MIGDeviceName.from_string("1c.3g.40gb")
    assert mig.sm_slices == 3
    assert mig.memory_size == 40
    assert mig.compute_instances == 1
    for s in ("42", "3c.40gb", "1c.3g", "1c.40gb", "Ac.Bg.Cgb"):
        with pytest.raises(ValueError):
            MIGDeviceName.from_string(s)


def test_format():
    mig = MIGDeviceName(3, 40)
    assert str(mig) == "3g.40gb"
    mig = MIGDeviceName(3, 40, 1)
    assert str(mig) == "1c.3g.40gb"


def test_order():
    migs_ordered = [
        MIGDeviceName.from_string(e)
        for e in (
            "1g.20gb",
            "1c.2g.20gb",
            "2g.20gb",
            "2g.40gb",
            "1c.3g.40gb",
            "3g.40gb",
            "7c.3g.40gb",
        )
    ]
    for _ in range(1000):
        migs_unordered = migs_ordered[:]
        random.shuffle(migs_unordered)
        assert sorted(migs_unordered) == migs_ordered


def test_repr():
    mig1 = MIGDeviceName(3, 40)
    mig2 = eval(repr(mig1))
    assert mig1 == mig2
    mig1 = MIGDeviceName(3, 40, 1)
    mig2 = eval(repr(mig1))
    assert mig1 == mig2


def test_lt():
    with pytest.raises(TypeError):
        MIGDeviceName(3, 40) < None


def test_hash_and_eq():
    assert not (MIGDeviceName(3, 40) == None)
    mig1 = MIGDeviceName(3, 40)
    mig2 = MIGDeviceName(3, 40, 3)
    mig3 = MIGDeviceName(3, 40)
    assert mig1 != mig2
    assert mig1 == mig3
    assert hash(mig1) != hash(mig2)
    assert hash(mig1) == hash(mig3)
