import random
import pytest
from nvidiautils import DriverVersion


def test_parse():
    v = DriverVersion.from_string("580.82.07")
    assert v.x == 580 and v.y == 82 and v.z == 7
    for s in ("580", "580.", "580.82", "580.82.", "580.82.07.", "a.b.c"):
        with pytest.raises(ValueError):
            DriverVersion.from_string(s)


def test_format():
    v = DriverVersion(580, 82, 7)
    assert str(v) == "580.82.07"
    v = DriverVersion(1, 0, 0)
    assert str(v) == "1.00.00"


def test_order():
    versions_ordered = [
        DriverVersion.from_string(e)
        for e in ("0.0.0", "0.0.1", "0.1.0", "1.0.0", "1.0.1")
    ]
    for _ in range(1000):
        versions_unordered = versions_ordered[:]
        random.shuffle(versions_unordered)
        assert sorted(versions_unordered) == versions_ordered
