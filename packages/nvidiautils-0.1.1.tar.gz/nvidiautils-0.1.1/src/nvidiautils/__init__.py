from dataclasses import dataclass
from functools import total_ordering
from typing import Optional, Tuple


@dataclass(order=True, frozen=True)
class DriverVersion:
    x: int
    y: int
    z: int

    @classmethod
    def from_string(cls, s: str, /) -> "DriverVersion":
        msg = "Malformed driver version"
        parts = s.split(".")
        if len(parts) != 3:
            raise ValueError(msg)
        args = []
        for e in parts:
            try:
                n = int(e)
            except ValueError:
                raise ValueError(msg) from None
            args.append(n)
        return cls(*args)

    def __str__(self) -> str:
        return f"{self.x:d}.{self.y:02d}.{self.z:02d}"


@dataclass(order=True, frozen=True)
class CudaVersionWithUpdate:
    major: int
    minor: int
    update: int

    @classmethod
    def from_string(cls, s: str, /) -> "CudaVersionWithUpdate":
        msg = "Malformed driver version"
        parts = s.split(".")
        if len(parts) != 3:
            raise ValueError(msg)
        args = []
        for e in parts:
            try:
                n = int(e)
            except ValueError:
                raise ValueError(msg) from None
            args.append(n)
        return cls(*args)

    def __str__(self):
        return f"{self.major:d}.{self.minor:d}.{self.update:d}"


@dataclass(frozen=True)
class DriverDockerImageTag:
    version: DriverVersion
    os: str

    @classmethod
    def from_string(cls, s: str, /) -> "DriverDockerImageTag":
        msg = "Malformed driver Docker image tag"
        parts = s.split("-", 1)
        if len(parts) != 2:
            raise ValueError(msg)
        version, os = parts
        try:
            version = DriverVersion.from_string(version)
        except ValueError:
            raise ValueError(msg)
        if not any(os.startswith(e) for e in ("ubuntu", "centos", "rhcos", "rhel")):
            raise ValueError(msg)
        return cls(version, os)

    def __str__(self):
        return f"{self.version!s:s}-{self.os:s}"


@total_ordering
class MIGDeviceName:
    """
    Represents a MIG device, as defined in
    `NVIDIA's MIG user guide <https://docs.nvidia.com/datacenter/tesla/mig-user-guide/mig-device-names.html>`__.

    This object is ordered with this precedence:

    *   Number of streaming multiprocessor slices
    *   Quantity of memory
    *   Number of compute instances, when specified

    For example, `1c.2g.20gb` < `2g.20gb` < `1c.3g.40gb` < `7c.3g.40gb`.

    Note that `7c.4g.40gb` is invalid in practice, but this class does not check for that.

    :param sm_slices: The number of streaming multiprocessor slices.
    :type sm_slices: int
    :param memory_size: The quantity of memory in gigabytes.
    :type memory_size: int
    :param compute_instances: The number of compute instances.
    :type compute_instances: int or None
    """

    _sm_slices: int
    _memory_size: int
    _compute_instances: Optional[int]
    __slots__ = ["_sm_slices", "_memory_size", "_compute_instances"]

    def __init__(
        self,
        sm_slices: int,
        memory_slices: int,
        compute_instances: Optional[int] = None,
        /,
    ) -> None:
        if (
            sm_slices < 0
            or memory_slices < 0
            or (compute_instances is not None and compute_instances < 0)
        ):
            msg = "All arguments must be greated than zero"
            raise ValueError(msg)
        self._sm_slices = sm_slices
        self._memory_size = memory_slices
        self._compute_instances = compute_instances

    @classmethod
    def from_string(cls, mig: str, /) -> "MIGDeviceName":
        """
        Parses a MIG device name from a string.

        :param mig: The MIG device name to parse.
        :type mig: str
        """
        msg = "Malformed MIG device name"

        def split_mig_device_name(s: str, /) -> Tuple[Optional[str], str, str]:
            parts = s.split(".")
            if len(parts) == 2:
                return (None, parts[0], parts[1])
            elif len(parts) == 3:
                return (parts[0], parts[1], parts[2])
            else:
                raise ValueError(msg)

        def coerce_int_that_ends_with(s: str, tail: str, /) -> int:
            if s[-len(tail) :] != tail:
                raise ValueError(msg)
            try:
                return int(s[: -len(tail)])
            except ValueError:
                raise ValueError(msg) from None

        compute_instances, sm_slices, memory_slices = split_mig_device_name(mig)
        if compute_instances is not None:
            compute_instances = coerce_int_that_ends_with(compute_instances, "c")
        sm_slices = coerce_int_that_ends_with(sm_slices, "g")
        memory_slices = coerce_int_that_ends_with(memory_slices, "gb")
        return cls(sm_slices, memory_slices, compute_instances)

    def __str__(self):
        s = f"{self._sm_slices:d}g.{self._memory_size:d}gb"
        if self._compute_instances is not None:
            s = f"{self._compute_instances}c.{s:s}"
        return s

    def __repr__(self):
        s = f"{self.__class__.__name__:s}({self._sm_slices!r}, {self._memory_size!r}"
        if self._compute_instances is not None:
            s = f"{s:s}, {self._compute_instances!r}"
        s = f"{s:s})"
        return s

    @property
    def sm_slices(self) -> int:
        """
        Number of streaming multiprocessor slices.
        """
        return self._sm_slices

    @property
    def memory_size(self) -> int:
        """
        Quantity of memory in gigabytes.
        """
        return self._memory_size

    @property
    def compute_instances(self) -> Optional[int]:
        """
        Number of compute instances, if specified, ``None`` otherwise.
        """
        return self._compute_instances

    def __lt__(self, other):
        if not isinstance(other, MIGDeviceName):
            return NotImplemented
        if self._sm_slices == other._sm_slices:
            if self._memory_size == other._memory_size:
                if (
                    self._compute_instances is not None
                    and other._compute_instances is not None
                ):
                    return self._compute_instances < other._compute_instances
                elif other._compute_instances is not None:
                    return self._sm_slices < other._compute_instances
                elif self._compute_instances is not None:
                    return self._compute_instances < other._sm_slices
                else:  # pragma: no cover
                    assert False, "DEAD CODE"
            return self._memory_size < other._memory_size
        return self._sm_slices < other._sm_slices

    def __eq__(self, other):
        if not isinstance(other, MIGDeviceName):
            return NotImplemented
        return (
            self._sm_slices == other._sm_slices
            and self._memory_size == other._memory_size
            and self._compute_instances == other._compute_instances
        )

    def __hash__(self):
        return hash((self._sm_slices, self._memory_size, self._compute_instances))
