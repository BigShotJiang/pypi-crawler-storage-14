from cm_colors.core.cm_colors import CMColors
from cm_colors.core.colors import Color,ColorPair

__version__ = "0.4.0"

__all__ = ['CMColors','Color','ColorPair']
