# Greb

Getting started with Greb code search is simple and takes just a few minutes.

## Integration Methods

Integrate Greb into your AI coding assistant using MCP (Model Context Protocol). Select your IDE below for specific setup instructions.

Select your AI coding assistant below.

- **Cheetah AI**
- **Cursor**
- **Windsurf**
- **Claude Code**

## Steps

Follow these steps to integrate Greb MCP server with Cheetah AI:

### 1. Install the Greb package

The MCP server is included in the Greb Python package.

```bash
pip install cheetah-greb
```

**Note:** Requires Python 3.10-3.13. Python 3.14 is not yet supported due to onnxruntime compatibility (not a Greb limitation). We will update the package when onnxruntime adds Python 3.14 support.

**First Run:** The first search will be slower (~30-60 seconds) as Greb is being configured. Subsequent runs will be very fast.

### 2. Configure Cheetah AI

Add the Greb MCP server to your Cheetah AI MCP configuration.

```json
{
  "mcpServers": {
    "greb-mcp": {
      "disabled": false,
      "timeout": 60,
      "type": "stdio",
      "command": "greb-mcp",
      "args": [],
      "env": {
        "GREB_API_KEY": "grb_your_api_key_here",
        "GREB_API_URL": "https://search.grebmcp.com"
      }
    }
  }
}
```

### 3. Start searching

Talk to Cheetah AI and it will automatically use the MCP server to search your code with natural language queries.

```bash
# Example queries:
"Use greb mcp to find authentication middleware in the backend directory"
"Use greb mcp to find all API endpoints"
"Use greb mcp to look for database connection setup in ./src"
```

## That's it!

You now have access to intelligent code search through MCP. Start searching your codebase using natural language queries with your AI coding assistant!