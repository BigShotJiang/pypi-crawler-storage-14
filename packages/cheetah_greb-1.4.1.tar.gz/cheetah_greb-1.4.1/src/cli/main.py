"""Greb CLI - Information and help."""

from __future__ import annotations

import click


@click.command()
def main():
    """Greb - AI-powered intelligent code search through MCP.
    
    Getting started with Greb code search is simple and takes just a few minutes.
    
    INTEGRATION:
    Integrate Greb into your AI coding assistant using MCP (Model Context Protocol).
    
    STEPS:
    
    1. Install the Greb package
       The MCP server is included in the Greb Python package.
       
       pip install cheetah-greb
       
       Note: Requires Python 3.10-3.13. Python 3.14 is not yet supported due to
       onnxruntime compatibility (not a Greb limitation). We will update the
       package when onnxruntime adds Python 3.14 support.
       
       First Run: The first search will be slower (~30-60 seconds) as Greb is
       being configured. Subsequent runs will be very fast.
    
    2. Configure Cheetah AI
       Add the Greb MCP server to your Cheetah AI MCP configuration.
       
       {
         "mcpServers": {
           "greb-mcp": {
             "disabled": false,
             "timeout": 60,
             "type": "stdio",
             "command": "greb-mcp",
             "args": [],
             "env": {
               "GREB_API_KEY": "grb_your_api_key_here",
               "GREB_API_URL": "https://search.grebmcp.com"
             }
           }
         }
       }
    
    3. Start searching
       Talk to Cheetah AI and it will automatically use the MCP server to search
       your code with natural language queries.
       
       Example queries:
       "Use greb mcp to find authentication middleware in the backend directory"
       "Use greb mcp to find all API endpoints"
       "Use greb mcp to look for database connection setup in ./src"
    
    Documentation: https://grebmcp.com/get-started/installation
    """
    pass


if __name__ == '__main__':
    main()