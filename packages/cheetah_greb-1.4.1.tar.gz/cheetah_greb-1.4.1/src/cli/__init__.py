"""Greb CLI - AI-powered intelligent code search through MCP."""


from __future__ import annotations

from .main import main

__all__ = ["main"]