"""
DIRACCommon.ConfigurationSystem tests
"""
