"""
Integration tests for celltypist with numpy 2.x and pandas 2.x.

Tests actual celltypist functionality to ensure compatibility with upgraded dependencies.
"""

import unittest
import numpy as np
import pandas as pd
import tempfile
import os
import sys

# Add parent directory to path to import celltypist
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestCelltypistDataProcessing(unittest.TestCase):
    """Test celltypist data processing with numpy/pandas v2."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temporary files."""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_import_celltypist(self):
        """Test that celltypist can be imported."""
        try:
            import celltypist
            print(f"✓ celltypist imported successfully, version: {celltypist.__version__}")
        except Exception as e:
            self.fail(f"Failed to import celltypist: {e}")

    def test_models_module(self):
        """Test celltypist.models module functions."""
        try:
            from celltypist import models

            # Test internal collapse functions
            from celltypist.models import _collapse_mean, _collapse_random

            # Test 1D array
            arr_1d = np.array([1.0, 2.0, 3.0])
            mean_1d = _collapse_mean(arr_1d)
            self.assertEqual(mean_1d, 2.0)

            # Test 2D array (collapse by row)
            arr_2d = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
            mean_2d = _collapse_mean(arr_2d)
            self.assertTrue(np.array_equal(mean_2d, np.array([2.0, 5.0])))

            # Test random collapse
            np.random.seed(42)
            random_1d = _collapse_random(arr_1d)
            self.assertIn(random_1d, arr_1d)

            print("✓ celltypist.models internal functions work correctly")
        except Exception as e:
            self.fail(f"Failed to test celltypist.models: {e}")

    def test_samples_module(self):
        """Test celltypist.samples module functions."""
        try:
            from celltypist.samples import get_sample_csv, _get_sample_data

            # Test getting sample data path
            sample_csv = get_sample_csv()
            self.assertTrue(os.path.exists(sample_csv))

            # Test getting conversion files
            conversion_file = _get_sample_data("Ensembl105_Human2Mouse_Genes.csv")
            self.assertTrue(os.path.exists(conversion_file))

            print("✓ celltypist.samples functions work correctly")
        except Exception as e:
            self.fail(f"Failed to test celltypist.samples: {e}")

    def test_annotation_result_class(self):
        """Test AnnotationResult class creation and methods."""
        try:
            from celltypist.classifier import AnnotationResult
            from anndata import AnnData

            # Create mock data
            n_cells = 100
            n_genes = 50
            n_types = 5

            # Create mock AnnData
            X = np.random.rand(n_cells, n_genes)
            adata = AnnData(X)
            adata.var_names = [f"Gene{i}" for i in range(n_genes)]
            adata.obs_names = [f"Cell{i}" for i in range(n_cells)]

            # Create mock prediction results
            cell_types = [f"Type{i}" for i in range(n_types)]
            labels = pd.DataFrame({
                'predicted_labels': np.random.choice(cell_types, n_cells)
            })

            decision_mat = pd.DataFrame(
                np.random.rand(n_cells, n_types),
                columns=cell_types,
                index=adata.obs_names
            )

            prob_mat = pd.DataFrame(
                np.random.rand(n_cells, n_types),
                columns=cell_types,
                index=adata.obs_names
            )
            # Normalize probabilities
            prob_mat = prob_mat.div(prob_mat.sum(axis=1), axis=0)

            # Create AnnotationResult
            result = AnnotationResult(labels, decision_mat, prob_mat, adata)

            # Test attributes
            self.assertEqual(result.cell_count, n_cells)
            self.assertIsInstance(result.predicted_labels, pd.DataFrame)
            self.assertIsInstance(result.decision_matrix, pd.DataFrame)
            self.assertIsInstance(result.probability_matrix, pd.DataFrame)

            # Test summary_frequency method
            freq = result.summary_frequency()
            self.assertIsInstance(freq, pd.DataFrame)
            self.assertTrue('celltype' in freq.columns)
            self.assertTrue('counts' in freq.columns)

            # Test to_adata method
            adata_with_labels = result.to_adata()
            self.assertTrue('predicted_labels' in adata_with_labels.obs.columns)
            self.assertTrue('conf_score' in adata_with_labels.obs.columns)

            print("✓ AnnotationResult class works correctly with v2")
        except Exception as e:
            self.fail(f"Failed to test AnnotationResult: {e}")

    def test_dataframe_operations_used_in_celltypist(self):
        """Test specific DataFrame operations used in celltypist code."""
        # Test the sort_values inplace pattern from classifier.py:75
        df = pd.DataFrame({
            'celltype': ['TypeA', 'TypeB', 'TypeC'],
            'counts': [10, 5, 15]
        })
        df.sort_values(['counts'], ascending=False, inplace=True)
        self.assertEqual(df.iloc[0]['counts'], 15)

        # Test the drop pattern from classifier.py:186
        df = pd.DataFrame({
            'A': [1, 2, 3],
            'decision score': [0.8, 0.9, 0.7],
            'probability': [0.6, 0.7, 0.5]
        })
        df.drop(columns=['decision score', 'probability'], inplace=True)
        self.assertEqual(list(df.columns), ['A'])

        # Test the dropna pattern from models.py:247
        df = pd.DataFrame({
            0: [1, 2, np.nan, 4],
            1: ['a', 'b', 'c', 'd']
        })
        df.dropna(axis=0, inplace=True)
        self.assertEqual(len(df), 3)

        # Test the drop_duplicates pattern from models.py:248
        df = pd.DataFrame({
            0: [1, 2, 2, 3],
            1: ['a', 'b', 'b', 'c']
        })
        df.drop_duplicates(inplace=True)
        self.assertEqual(len(df), 3)

        # Test drop_duplicates with subset and keep=False from models.py:272-273
        df = pd.DataFrame({
            0: [1, 2, 2, 3],
            1: ['a', 'b', 'c', 'd']
        })
        df.drop_duplicates([0], inplace=True, keep=False)
        self.assertEqual(len(df), 2)  # Only 1 and 3 remain

        print("✓ DataFrame operations used in celltypist work correctly")

    def test_numpy_operations_used_in_celltypist(self):
        """Test specific numpy operations used in celltypist code."""
        # Test unique with return_counts from classifier.py:73
        arr = np.array(['A', 'B', 'A', 'C', 'B', 'A'])
        unique, counts = np.unique(arr, return_counts=True)
        self.assertTrue(np.array_equal(unique, np.array(['A', 'B', 'C'])))
        self.assertTrue(np.array_equal(counts, np.array([3, 2, 1])))

        # Test mean with axis from models.py:26
        arr = np.array([[1, 2, 3], [4, 5, 6]])
        mean_row = np.mean(arr, axis=-1)
        self.assertTrue(np.array_equal(mean_row, np.array([2., 5.])))

        # Test random.choice from models.py:32
        np.random.seed(42)
        arr = np.array([1, 2, 3, 4, 5])
        choice = np.random.choice(arr, 1)[0]
        self.assertIn(choice, arr)

        # Test column_stack from models.py:307
        a = np.array([1, 2, 3])
        b = np.array([4, 5, 6])
        c = np.array([7, 8, 9])
        stacked = np.column_stack([a, b, c])
        self.assertEqual(stacked.shape, (3, 3))

        print("✓ numpy operations used in celltypist work correctly")

    def test_csv_reading_pattern(self):
        """Test CSV reading pattern used in models.py."""
        # Create test CSV file
        csv_path = os.path.join(self.temp_dir, 'test_mapping.csv')
        df = pd.DataFrame({
            0: ['GENE1', 'GENE2', 'GENE3'],
            1: ['Gene1', 'Gene2', 'Gene3']
        })
        df.to_csv(csv_path, index=False, header=False)

        # Read CSV without header (pattern from models.py:246)
        map_content = pd.read_csv(csv_path, sep=',', header=None)

        self.assertEqual(len(map_content), 3)
        self.assertEqual(len(map_content.columns), 2)

        # Test dropna and drop_duplicates chain
        map_content.dropna(axis=0, inplace=True)
        map_content.drop_duplicates(inplace=True)

        self.assertEqual(len(map_content), 3)

        print("✓ CSV reading pattern works correctly")

    def test_probability_matrix_operations(self):
        """Test operations on probability matrices used in celltypist."""
        # Create mock probability matrix
        n_cells = 50
        n_types = 5
        cell_types = [f"Type{i}" for i in range(n_types)]

        prob_mat = pd.DataFrame(
            np.random.rand(n_cells, n_types),
            columns=cell_types
        )
        # Normalize to make valid probabilities
        prob_mat = prob_mat.div(prob_mat.sum(axis=1), axis=0)

        # Test max operation (used for confidence scores)
        max_probs = prob_mat.max(axis=1)
        self.assertEqual(len(max_probs), n_cells)
        self.assertTrue(all(max_probs <= 1.0))
        self.assertTrue(all(max_probs >= 0.0))

        # Test .values attribute
        max_values = prob_mat.max(axis=1).values
        self.assertIsInstance(max_values, np.ndarray)
        self.assertTrue(np.array_equal(max_probs.values, max_values))

        # Test iterrows pattern (used in classifier.py:117)
        for index, row in prob_mat.iterrows():
            self.assertIsInstance(row, pd.Series)
            self.assertEqual(len(row), n_types)

        print("✓ Probability matrix operations work correctly")

    def test_downsample_functionality(self):
        """Test downsample_adata function compatibility."""
        try:
            from celltypist.samples import downsample_adata
            from anndata import AnnData

            # Create mock AnnData
            n_cells = 100
            n_genes = 50
            X = np.random.rand(n_cells, n_genes)
            adata = AnnData(X)
            adata.obs['celltype'] = np.random.choice(['TypeA', 'TypeB', 'TypeC'], n_cells)

            # Test downsampling
            sampled_indices = downsample_adata(
                adata,
                mode='total',
                n_cells=50,
                random_state=42,
                return_index=True
            )

            self.assertEqual(len(sampled_indices), 50)
            self.assertTrue(all(idx < n_cells for idx in sampled_indices))

            # Test balanced downsampling
            sampled_indices_balanced = downsample_adata(
                adata,
                mode='total',
                n_cells=50,
                by='celltype',
                balance_cell_type=True,
                random_state=42,
                return_index=True
            )

            self.assertEqual(len(sampled_indices_balanced), 50)

            print("✓ downsample_adata works correctly with v2")
        except Exception as e:
            self.fail(f"Failed to test downsample_adata: {e}")


class TestNumpyPandasVersion(unittest.TestCase):
    """Test numpy and pandas versions."""

    def test_numpy_pandas_versions(self):
        """Print numpy and pandas versions."""
        print(f"\n{'='*60}")
        print(f"Dependency Versions:")
        print(f"{'='*60}")
        print(f"numpy version:  {np.__version__}")
        print(f"pandas version: {pd.__version__}")

        try:
            import scanpy as sc
            print(f"scanpy version: {sc.__version__}")
        except ImportError:
            print(f"scanpy: not installed")

        try:
            from sklearn import __version__ as skv
            print(f"scikit-learn version: {skv}")
        except ImportError:
            print(f"scikit-learn: not installed")

        try:
            from anndata import __version__ as av
            print(f"anndata version: {av}")
        except ImportError:
            print(f"anndata: not installed")

        print(f"{'='*60}\n")

        # Verify versions are v2+
        np_version = int(np.__version__.split('.')[0])
        pd_version = int(pd.__version__.split('.')[0])

        self.assertGreaterEqual(np_version, 2, f"numpy version {np.__version__} is not 2.x+")
        self.assertGreaterEqual(pd_version, 2, f"pandas version {pd.__version__} is not 2.x+")


if __name__ == '__main__':
    # Run version test first
    suite = unittest.TestLoader().loadTestsFromTestCase(TestNumpyPandasVersion)
    unittest.TextTestRunner(verbosity=2).run(suite)

    # Run other tests
    suite = unittest.TestLoader().loadTestsFromTestCase(TestCelltypistDataProcessing)
    unittest.TextTestRunner(verbosity=2).run(suite)
