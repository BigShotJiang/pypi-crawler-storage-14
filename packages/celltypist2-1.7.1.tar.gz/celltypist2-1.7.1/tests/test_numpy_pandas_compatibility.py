"""
Test suite for numpy 2.x and pandas 2.x compatibility.

This module tests key operations that may have changed between v1 and v2:
- DataFrame operations (inplace, sorting, indexing)
- numpy array operations and dtypes
- CSV reading/writing
- Data type conversions
"""

import unittest
import numpy as np
import pandas as pd
import tempfile
import os
from pathlib import Path


class TestNumpyPandasCompatibility(unittest.TestCase):
    """Test numpy and pandas v2 compatibility."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temporary files."""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_numpy_version(self):
        """Test that numpy version is 2.x or higher."""
        version = np.__version__
        major_version = int(version.split('.')[0])
        self.assertGreaterEqual(major_version, 2, f"numpy version {version} is not 2.x or higher")
        print(f"✓ numpy version: {version}")

    def test_pandas_version(self):
        """Test that pandas version is 2.x or higher."""
        version = pd.__version__
        major_version = int(version.split('.')[0])
        self.assertGreaterEqual(major_version, 2, f"pandas version {version} is not 2.x or higher")
        print(f"✓ pandas version: {version}")

    def test_numpy_array_creation(self):
        """Test numpy array creation with different dtypes."""
        # Test basic array creation
        arr_float = np.array([1.0, 2.0, 3.0])
        self.assertEqual(arr_float.dtype, np.float64)

        arr_int = np.array([1, 2, 3])
        self.assertTrue(np.issubdtype(arr_int.dtype, np.integer))

        arr_bool = np.array([True, False, True])
        self.assertEqual(arr_bool.dtype, np.bool_)

        print("✓ numpy array creation works correctly")

    def test_numpy_dtype_specifications(self):
        """Test that numpy dtype specifications work in v2."""
        # Using string dtype specifications (v2 compatible)
        arr1 = np.array([1.0, 2.0, 3.0], dtype='float64')
        arr2 = np.array([1, 2, 3], dtype='int64')
        arr3 = np.array([True, False], dtype='bool')

        self.assertEqual(arr1.dtype, np.float64)
        self.assertEqual(arr2.dtype, np.int64)
        self.assertEqual(arr3.dtype, np.bool_)

        print("✓ numpy dtype specifications work correctly")

    def test_numpy_array_indexing(self):
        """Test numpy array indexing and slicing."""
        arr = np.arange(10)

        # Boolean indexing
        mask = arr > 5
        result = arr[mask]
        self.assertTrue(np.array_equal(result, np.array([6, 7, 8, 9])))

        # Fancy indexing
        indices = np.array([0, 2, 4])
        result = arr[indices]
        self.assertTrue(np.array_equal(result, np.array([0, 2, 4])))

        print("✓ numpy array indexing works correctly")

    def test_numpy_matrix_operations(self):
        """Test numpy matrix operations."""
        # 2D array operations
        arr = np.array([[1, 2, 3], [4, 5, 6]])

        # Mean along axis
        mean_axis0 = np.mean(arr, axis=0)
        self.assertTrue(np.array_equal(mean_axis0, np.array([2.5, 3.5, 4.5])))

        mean_axis1 = np.mean(arr, axis=1)
        self.assertTrue(np.array_equal(mean_axis1, np.array([2., 5.])))

        # Random choice
        np.random.seed(42)
        choice = np.random.choice(arr.ravel(), 3, replace=False)
        self.assertEqual(len(choice), 3)

        print("✓ numpy matrix operations work correctly")

    def test_numpy_column_stack(self):
        """Test numpy column_stack operation."""
        a = np.array([1, 2, 3])
        b = np.array([4, 5, 6])
        c = np.array([7, 8, 9])

        result = np.column_stack([a, b, c])
        expected = np.array([[1, 4, 7], [2, 5, 8], [3, 6, 9]])

        self.assertTrue(np.array_equal(result, expected))
        print("✓ numpy column_stack works correctly")

    def test_pandas_dataframe_creation(self):
        """Test pandas DataFrame creation and basic operations."""
        df = pd.DataFrame({
            'A': [1, 2, 3],
            'B': ['a', 'b', 'c'],
            'C': [1.0, 2.0, 3.0]
        })

        self.assertEqual(len(df), 3)
        self.assertEqual(len(df.columns), 3)

        print("✓ pandas DataFrame creation works correctly")

    def test_pandas_sort_values_inplace(self):
        """Test pandas sort_values with inplace parameter."""
        df = pd.DataFrame({
            'counts': [5, 2, 8, 1]
        })

        # Test inplace=True (used in classifier.py line 75)
        df_copy = df.copy()
        df_copy.sort_values(['counts'], ascending=False, inplace=True)

        self.assertTrue(df_copy['counts'].iloc[0] == 8)
        self.assertTrue(df_copy['counts'].iloc[-1] == 1)

        print("✓ pandas sort_values with inplace works correctly")

    def test_pandas_drop_inplace(self):
        """Test pandas drop with inplace parameter."""
        df = pd.DataFrame({
            'A': [1, 2, 3],
            'B': [4, 5, 6],
            'C': [7, 8, 9]
        })

        # Test drop columns inplace (used in classifier.py line 186)
        df_copy = df.copy()
        df_copy.drop(columns=['B', 'C'], inplace=True)

        self.assertEqual(list(df_copy.columns), ['A'])

        print("✓ pandas drop with inplace works correctly")

    def test_pandas_dropna_inplace(self):
        """Test pandas dropna with inplace parameter."""
        df = pd.DataFrame({
            'A': [1, np.nan, 3],
            'B': [4, 5, np.nan]
        })

        # Test dropna inplace (used in models.py line 247)
        df_copy = df.copy()
        df_copy.dropna(axis=0, inplace=True)

        self.assertEqual(len(df_copy), 1)

        print("✓ pandas dropna with inplace works correctly")

    def test_pandas_drop_duplicates_inplace(self):
        """Test pandas drop_duplicates with inplace parameter."""
        df = pd.DataFrame({
            0: [1, 2, 2, 3],
            1: ['a', 'b', 'b', 'c']
        })

        # Test drop_duplicates inplace (used in models.py lines 248, 272, 273)
        df_copy = df.copy()
        df_copy.drop_duplicates(inplace=True)

        self.assertEqual(len(df_copy), 3)

        # Test drop_duplicates with subset and keep=False
        df_copy2 = df.copy()
        df_copy2.drop_duplicates([0], inplace=True, keep=False)

        print("✓ pandas drop_duplicates with inplace works correctly")

    def test_pandas_csv_operations(self):
        """Test pandas CSV reading and writing."""
        # Create test data
        df = pd.DataFrame({
            'gene': ['GENE1', 'GENE2', 'GENE3'],
            'value': [1.5, 2.5, 3.5]
        })

        # Write CSV
        csv_path = os.path.join(self.temp_dir, 'test.csv')
        df.to_csv(csv_path, index=False)

        # Read CSV
        df_read = pd.read_csv(csv_path)

        self.assertTrue(df.equals(df_read))

        # Test reading without header (used in models.py line 246)
        df.to_csv(csv_path, index=False, header=False)
        df_no_header = pd.read_csv(csv_path, header=None)

        self.assertEqual(len(df_no_header), 3)
        self.assertEqual(len(df_no_header.columns), 2)

        print("✓ pandas CSV operations work correctly")

    def test_pandas_values_attribute(self):
        """Test pandas .values attribute (still works but .to_numpy() preferred)."""
        df = pd.DataFrame({
            'A': [1, 2, 3],
            'B': [4, 5, 6]
        })

        # .values should still work
        values = df.values
        self.assertIsInstance(values, np.ndarray)
        self.assertEqual(values.shape, (3, 2))

        # .to_numpy() is preferred in v2
        values_new = df.to_numpy()
        self.assertTrue(np.array_equal(values, values_new))

        print("✓ pandas .values attribute still works")

    def test_pandas_series_values(self):
        """Test pandas Series .values attribute."""
        series = pd.Series([1, 2, 3, 4])

        values = series.values
        self.assertIsInstance(values, np.ndarray)
        self.assertEqual(len(values), 4)

        print("✓ pandas Series .values works correctly")

    def test_pandas_iterrows(self):
        """Test pandas iterrows functionality."""
        df = pd.DataFrame({
            'A': [1, 2, 3],
            'B': [4, 5, 6]
        })

        # Test iterrows (used in classifier.py and plot.py)
        for index, row in df.iterrows():
            self.assertIsInstance(row, pd.Series)
            self.assertTrue('A' in row.index)
            self.assertTrue('B' in row.index)

        print("✓ pandas iterrows works correctly")

    def test_pandas_pivot_table(self):
        """Test pandas pivot_table functionality."""
        df = pd.DataFrame({
            'pred': ['A', 'B', 'A', 'B'],
            'refer': ['X', 'X', 'Y', 'Y'],
            'score': [0.8, 0.6, 0.9, 0.7]
        })

        # Test pivot_table (used in plot.py line 46-47)
        pivot = df.pivot_table(
            values='score',
            index='pred',
            columns='refer',
            aggfunc='mean',
            fill_value=0,
            dropna=False,
            observed=True
        )

        self.assertIsInstance(pivot, pd.DataFrame)
        self.assertEqual(pivot.shape, (2, 2))

        print("✓ pandas pivot_table works correctly")

    def test_pandas_unique_return_counts(self):
        """Test np.unique with return_counts on pandas objects."""
        series = pd.Series(['A', 'B', 'A', 'C', 'B', 'A'])

        # Test np.unique with return_counts (used in classifier.py line 73)
        unique, counts = np.unique(series, return_counts=True)

        self.assertEqual(len(unique), 3)
        self.assertEqual(len(counts), 3)
        self.assertTrue(np.array_equal(unique, np.array(['A', 'B', 'C'])))
        self.assertTrue(np.array_equal(counts, np.array([3, 2, 1])))

        print("✓ np.unique with return_counts works correctly")

    def test_pandas_isin(self):
        """Test pandas .isin() method."""
        series = pd.Series(['gene1', 'gene2', 'gene3'])
        check_list = ['gene1', 'gene3', 'gene4']

        # Test isin (used in models.py)
        mask = series.isin(check_list)

        self.assertTrue(mask[0])
        self.assertFalse(mask[1])
        self.assertTrue(mask[2])

        print("✓ pandas .isin() works correctly")

    def test_pandas_categorical_operations(self):
        """Test pandas categorical operations."""
        # Create categorical series
        cat_series = pd.Series(['A', 'B', 'C', 'A', 'B'], dtype='category')

        # Test cat accessor
        self.assertEqual(len(cat_series.cat.categories), 3)

        # Test reorder_categories (used in plot.py)
        cat_series = cat_series.cat.reorder_categories(['C', 'B', 'A'])
        self.assertEqual(list(cat_series.cat.categories), ['C', 'B', 'A'])

        print("✓ pandas categorical operations work correctly")

    def test_numpy_random_operations(self):
        """Test numpy random operations."""
        np.random.seed(42)

        # Test random.choice with probabilities
        arr = np.arange(10)
        p = np.ones(10) / 10
        choice = np.random.choice(arr, 3, replace=False, p=p)

        self.assertEqual(len(choice), 3)

        # Test random.choice from 2D array column
        arr_2d = np.array([[1, 2, 3], [4, 5, 6]])
        col_choice = np.random.choice(arr_2d.shape[1], 1)[0]

        self.assertIn(col_choice, [0, 1, 2])

        print("✓ numpy random operations work correctly")

    def test_numpy_concatenate(self):
        """Test numpy concatenate."""
        arr1 = np.array([1, 2, 3])
        arr2 = np.array([4, 5, 6])
        arr3 = np.array([7, 8, 9])

        result = np.concatenate([arr1, arr2, arr3])
        expected = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

        self.assertTrue(np.array_equal(result, expected))

        print("✓ numpy concatenate works correctly")

    def test_pandas_dataframe_max_operations(self):
        """Test pandas DataFrame max operations."""
        df = pd.DataFrame({
            'A': [1, 2, 3],
            'B': [4, 5, 6],
            'C': [7, 8, 9]
        })

        # Test max along axis
        max_axis0 = df.max(axis=0)
        self.assertEqual(max_axis0['A'], 3)

        max_axis1 = df.max(axis=1)
        self.assertTrue(isinstance(max_axis1, pd.Series))

        # Test max with .values
        max_values = df.max(axis=1).values
        self.assertTrue(np.array_equal(max_values, np.array([7, 8, 9])))

        print("✓ pandas DataFrame max operations work correctly")

    def test_scipy_sparse_integration(self):
        """Test numpy/pandas integration with scipy sparse matrices."""
        try:
            from scipy.sparse import csr_matrix

            # Create sparse matrix
            data = np.array([1, 2, 3, 4])
            row = np.array([0, 0, 1, 1])
            col = np.array([0, 1, 0, 1])
            sparse = csr_matrix((data, (row, col)), shape=(2, 2))

            # Convert to dense
            dense = sparse.toarray()

            self.assertIsInstance(dense, np.ndarray)
            self.assertEqual(dense.shape, (2, 2))

            print("✓ scipy sparse matrix integration works correctly")
        except ImportError:
            print("⊘ scipy not installed, skipping sparse matrix test")


class TestDataFrameListOperations(unittest.TestCase):
    """Test list operations that may be used with DataFrames."""

    def test_list_append_pattern(self):
        """Test the pattern used in models.py with list append."""
        coef_to = []
        mean_to = []
        var_to = []
        scale_to = []

        # Simulate the append pattern from models.py lines 298-306
        for i in range(3):
            coef_to.append(np.random.rand(5))
            mean_to.append(np.random.rand())
            var_to.append(np.random.rand())
            scale_to.append(np.random.rand())

        # Convert lists to numpy arrays
        coef_array = np.column_stack(coef_to)
        mean_array = np.array(mean_to)
        var_array = np.array(var_to)
        scale_array = np.array(scale_to)

        self.assertEqual(coef_array.shape, (5, 3))
        self.assertEqual(len(mean_array), 3)

        print("✓ List append and numpy conversion pattern works correctly")


if __name__ == '__main__':
    unittest.main(verbosity=2)
