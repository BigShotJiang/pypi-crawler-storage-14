"""Test suite for celltypist numpy/pandas v2 compatibility."""
