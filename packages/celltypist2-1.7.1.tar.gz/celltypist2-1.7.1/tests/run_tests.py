#!/usr/bin/env python3
"""
Run all celltypist tests for numpy/pandas v2 compatibility.

This script runs the test suite and provides a summary of results.
"""

import sys
import unittest
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def print_banner(text):
    """Print a formatted banner."""
    width = 70
    print("\n" + "=" * width)
    print(f"{text:^{width}}")
    print("=" * width + "\n")


def main():
    """Run all tests."""
    print_banner("Celltypist numpy/pandas v2 Compatibility Tests")

    # Check versions first
    try:
        import numpy as np
        import pandas as pd

        print(f"numpy version:  {np.__version__}")
        print(f"pandas version: {pd.__version__}")

        np_major = int(np.__version__.split('.')[0])
        pd_major = int(pd.__version__.split('.')[0])

        if np_major < 2:
            print(f"\n⚠️  Warning: numpy version is {np.__version__}, expected 2.x+")
        if pd_major < 2:
            print(f"\n⚠️  Warning: pandas version is {pd.__version__}, expected 2.x+")

        print()
    except ImportError as e:
        print(f"❌ Error importing dependencies: {e}")
        return 1

    # Discover and run tests
    loader = unittest.TestLoader()
    start_dir = os.path.dirname(os.path.abspath(__file__))
    suite = loader.discover(start_dir, pattern='test_*.py')

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Print summary
    print_banner("Test Summary")
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures:  {len(result.failures)}")
    print(f"Errors:    {len(result.errors)}")

    if result.wasSuccessful():
        print("\n✅ All tests passed! numpy/pandas v2 upgrade is compatible.")
        return 0
    else:
        print("\n❌ Some tests failed. Please review the output above.")
        return 1


if __name__ == '__main__':
    sys.exit(main())
