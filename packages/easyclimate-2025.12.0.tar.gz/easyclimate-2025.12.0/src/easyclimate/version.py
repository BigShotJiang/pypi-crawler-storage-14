# src/easyclimate/version.py
__version__ = "2025.12.0"


def show_versions() -> str:
    return __version__
