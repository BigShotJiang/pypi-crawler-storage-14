import os
import re
import httpx
from . import config


def do_request(method: str, url: str, json: dict, headers: dict):
    """Make an HTTP request with the given parameters."""
    resp = httpx.request(
        method=method,
        url=url,
        json=json,
        headers=headers,
        timeout=10
    )

    print(f"[{method}] {url} → {resp.status_code}")
    if resp.text:
        print(resp.text)

    resp.raise_for_status()


def render_template(template: str, context: dict) -> str:
    """
    Render a template string with variable substitution.
    
    Supports two syntaxes:
    - {{ variable }} - looks up in context dict
    - ${VARIABLE} - looks up in environment variables and .env file
    """
    # Load environment variables from .env file
    env_vars = config.read_env_file()
    
    # Replace ${VARIABLE} with environment variables
    def replace_env(match):
        key = match.group(1).strip()
        # First check .env file, then OS environment
        value = env_vars.get(key) or os.getenv(key)
        if value is not None:
            return str(value)
        # Return original if not found
        return match.group(0)
    
    # Replace {{ variable }} with context variables
    def replace_context(match):
        key = match.group(1).strip()
        return str(context.get(key, match.group(0)))
    
    # First replace environment variables ${VAR}
    result = re.sub(r"\$\{\s*(.*?)\s*\}", replace_env, template)
    # Then replace context variables {{ var }}
    result = re.sub(r"\{\{\s*(.*?)\s*\}\}", replace_context, result)
    
    return result
