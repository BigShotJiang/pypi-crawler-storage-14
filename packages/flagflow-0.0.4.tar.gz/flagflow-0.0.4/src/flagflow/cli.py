import typer
import yaml
from .workflow_runner import run_workflow
from . import config

app = typer.Typer(pretty_exceptions_enable=False)


@app.command()
def run(
    path: str,
    authorization: str | None = typer.Option(
        None, "--auth", help="Authorization header value"
    ),
    operator_id: str | None = typer.Option(
        None, "--operator-id", help="x-operator-id header value"
    ),
    facility_id: str | None = typer.Option(
        None, "--facility-id", help="x-facility-id header value"
    ),
    header: list[str] = typer.Option(
        [], "--header", "-H", help="Header override 'Name:Value' (can be repeated)"
    ),
    body: list[str] = typer.Option(
        [], "--body", "-B", help="Body override 'path.to.key:Value' (can be repeated)"
    ),
):
    """
    Run a workflow YAML file. You can override headers via CLI options.

    Examples:
      flagflow run sample.yaml --auth "Bearer TOKEN" --operator-id 123 --facility-id 456
    """
    overrides = {}
    if authorization:
        overrides["Authorization"] = authorization
    if operator_id:
        overrides["x-operator-id"] = operator_id
    if facility_id:
        overrides["x-facility-id"] = facility_id

    # Parse repeatable --header entries (format: Name: Value)
    for entry in header:
        if ":" in entry:
            name, val = entry.split(":", 1)
            overrides[name.strip()] = val.strip()
        else:
            print(f"Ignoring malformed header override: '{entry}'. Expected 'Name:Value'.")

    # Parse repeatable --body entries (format: path.to.key:Value)
    body_overrides: dict = {}

    def _set_nested(d: dict, keys: list, value):
        cur = d
        for k in keys[:-1]:
            if k not in cur or not isinstance(cur[k], dict):
                cur[k] = {}
            cur = cur[k]
        cur[keys[-1]] = value

    for entry in body:
        if ":" in entry:
            keypath, valstr = entry.split(":", 1)
            keypath = keypath.strip()
            try:
                val = yaml.safe_load(valstr.strip())
            except Exception:
                val = valstr.strip()
            if keypath:
                keys = keypath.split(".")
                _set_nested(body_overrides, keys, val)
        else:
            print(f"Ignoring malformed body override: '{entry}'. Expected 'path.to.key:Value'.")

    run_workflow(path, header_overrides=overrides, body_overrides=body_overrides)


@app.command("set-token")
def set_token(
    token: str = typer.Option(
        None, "--token", "-t", help="Authorization token to set"
    ),
):
    """
    Set the authorization token in the .env file.
    
    Examples:
      flagflow set-token --token "your_token_here"
      flagflow set-token  # Will prompt for token
    """
    if not token:
        token = typer.prompt("Enter your authorization token", hide_input=True)
    
    if not token or not token.strip():
        typer.echo("❌ Token cannot be empty", err=True)
        raise typer.Exit(1)
    
    try:
        env_path = config.set_token(token.strip())
        typer.echo(f"✅ Authorization token saved to {env_path}")
        typer.echo("   You can now use ${AUTHORIZATION_TOKEN} in your workflow files")
    except Exception as e:
        typer.echo(f"❌ Failed to save token: {e}", err=True)
        raise typer.Exit(1)


@app.command("show-token")
def show_token():
    """
    Show the current authorization token (masked).
    
    Examples:
      flagflow show-token
    """
    token = config.get_token()
    if not token:
        typer.echo("❌ No authorization token found")
        typer.echo("   Run 'flagflow set-token' to configure one")
        raise typer.Exit(1)
    
    # Mask the token for security (show first 10 and last 10 chars)
    if len(token) > 20:
        masked = f"{token[:10]}...{token[-10:]}"
    else:
        masked = "***"
    
    typer.echo(f"🔑 Current token: {masked}")
    typer.echo(f"   Stored in: {config.get_env_file_path()}")


if __name__ == "__main__":
    app()
