import yaml
from .template_engine import render_template
from .http_client import do_request
import time


def _render_value(value, context):
    # Recursively render strings and preserve native types by parsing
    # the rendered scalar with YAML. Keep lists and dicts intact.
    if isinstance(value, str):
        rendered = render_template(value, context)
        try:
            parsed = yaml.safe_load(rendered)
        except Exception:
            parsed = rendered
        return parsed
    elif isinstance(value, dict):
        return {k: _render_value(v, context) for k, v in value.items()}
    elif isinstance(value, list):
        return [_render_value(v, context) for v in value]
    else:
        return value


def _deep_merge(a: dict, b: dict) -> dict:
    """Return a new dict with b merged into a (b overrides)."""
    if not isinstance(a, dict):
        return b
    result = {k: v for k, v in a.items()}
    for k, v in (b or {}).items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def run_workflow(path: str, header_overrides: dict | None = None, body_overrides: dict | None = None):
    if header_overrides is None:
        header_overrides = {}
    if body_overrides is None:
        body_overrides = {}

    with open(path, "r") as f:
        workflow = yaml.safe_load(f)

    steps = workflow.get("steps", [])

    for step in steps:
        # only 2 supported for now: set + wait
        if "set" in step:
            data = step["set"]
            url = render_template(data["url"], data)
            # Merge CLI-provided body overrides into the step body
            original_body = data.get("body", {}) or {}
            merged_body = _deep_merge(original_body, body_overrides)

            # Provide a context that includes the merged body for template rendering
            context = dict(data)
            context["body"] = merged_body

            body = {k: _render_value(v, context) for k, v in merged_body.items()}
            # Render headers like body, but allow CLI overrides (exact header name match)
            headers = {}
            for k, v in (data.get("headers") or {}).items():
                if k in header_overrides:
                    headers[k] = str(header_overrides[k])
                else:
                    headers[k] = str(_render_value(v, data))
            try:
                do_request(
                    method=data.get("method", "PATCH"),
                    url=url,
                    json=body,
                    headers=headers,
)
            except Exception as e:
                print(f"Error during request: {e}")
                break

        elif "wait" in step:
            time.sleep(step["wait"])

