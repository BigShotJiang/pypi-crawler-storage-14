"""Configuration management for FlagFlow."""
import os
from pathlib import Path
from typing import Optional


def get_project_root() -> Path:
    """Find the project root directory (where .env should be)."""
    # Start from current directory and walk up to find .env or pyproject.toml
    current = Path.cwd()
    while current != current.parent:
        if (current / ".env").exists() or (current / "pyproject.toml").exists():
            return current
        current = current.parent
    # Default to current directory
    return Path.cwd()


def get_env_file_path() -> Path:
    """Get the path to the .env file."""
    return get_project_root() / ".env"


def read_env_file() -> dict[str, str]:
    """Read the .env file and return key-value pairs."""
    env_path = get_env_file_path()
    env_vars = {}
    
    if not env_path.exists():
        return env_vars
    
    with open(env_path, "r") as f:
        for line in f:
            line = line.strip()
            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue
            # Parse KEY=VALUE
            if "=" in line:
                key, value = line.split("=", 1)
                env_vars[key.strip()] = value.strip()
    
    return env_vars


def write_env_file(env_vars: dict[str, str]) -> None:
    """Write environment variables to the .env file."""
    env_path = get_env_file_path()
    
    # Read existing file to preserve comments
    existing_lines = []
    if env_path.exists():
        with open(env_path, "r") as f:
            existing_lines = f.readlines()
    
    # Build new content
    new_lines = []
    updated_keys = set()
    
    for line in existing_lines:
        stripped = line.strip()
        # Keep comments and empty lines
        if not stripped or stripped.startswith("#"):
            new_lines.append(line)
        elif "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in env_vars:
                # Update existing key
                new_lines.append(f"{key}={env_vars[key]}\n")
                updated_keys.add(key)
            else:
                # Keep unchanged
                new_lines.append(line)
    
    # Add new keys that weren't in the file
    for key, value in env_vars.items():
        if key not in updated_keys:
            new_lines.append(f"{key}={value}\n")
    
    # Write to file
    with open(env_path, "w") as f:
        f.writelines(new_lines)


def set_token(token: str) -> Path:
    """Set the AUTHORIZATION_TOKEN in the .env file."""
    env_vars = read_env_file()
    env_vars["AUTHORIZATION_TOKEN"] = token
    write_env_file(env_vars)
    return get_env_file_path()


def get_token() -> Optional[str]:
    """Get the AUTHORIZATION_TOKEN from .env file or environment."""
    # First check environment variable
    token = os.getenv("AUTHORIZATION_TOKEN")
    if token:
        return token
    
    # Then check .env file
    env_vars = read_env_file()
    return env_vars.get("AUTHORIZATION_TOKEN")
