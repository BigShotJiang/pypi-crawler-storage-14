import httpx

def do_request(method: str, url: str, json: dict, headers: dict):
    resp = httpx.request(method=method, headers=headers, url=url, json=json, timeout=10)
    print(json)
    print(f"[{method}] {url} → {resp.status_code}")
    if resp.text:
        print(resp.text)

    resp.raise_for_status()

