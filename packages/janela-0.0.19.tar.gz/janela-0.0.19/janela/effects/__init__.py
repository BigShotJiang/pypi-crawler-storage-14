"""Effects available in Janela."""

from .mosaic import mosaic, mosaic_around_window

__all__ = ["mosaic", "mosaic_around_window"]
