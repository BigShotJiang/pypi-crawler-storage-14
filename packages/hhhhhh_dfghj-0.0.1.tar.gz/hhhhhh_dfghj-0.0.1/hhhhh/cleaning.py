import re
import string

def remove_whitespace(text: str) -> str:
    return re.sub(r'\s+', ' ', text.strip())

def remove_punctuation(text: str, keep: str = "") -> str:
    chars_to_remove = string.remove_punctuation
    if keep:
        for char in keep:
            chars_to_remove = chars_to_remove.replace(char, '')
    translator = str.maketrans('', '', chars_to_remove)        
    return text.translate(translator)

def normalize_spaces(text: str) ->str:
    return re.sub(r'\s+', ' ', text)

def demo_functions():
    print("демонстрация функций очистки текста:\n")

    test1 = "  Hello word  "
    tesult1 = remove_whitespace(test1)
    print(f"1. remove_whitespace:")
    print(f"  Выход: '{test1}'")
    print(f"  Выход: '{result1}'\n")

    test2 = "Hi !!!"
    result2 = remove_punctuation(test2 ,"!")
    print(f"2. remove_punctuation (keep='!'):")
    print(f"  Выход: '{test2}'")
    print(f"  Выход: '{result2}'")

    test3 = "Hello, world!"
    result3 = remove_punctuation(test3)
    print(f"  Выход: '{test3}'")
    print(f"  Выход: '{result3}'")

    test4 = "Hello\tworld\nhi"
    result4 = normalize_spaces(test4)
    print(f"3. normalize_spaces:")
    print(f"  выход: '{test4}'")
    print(f"  Выход: '{result4}'")

if __name__ == "__name__":
    demo_functions()



    



