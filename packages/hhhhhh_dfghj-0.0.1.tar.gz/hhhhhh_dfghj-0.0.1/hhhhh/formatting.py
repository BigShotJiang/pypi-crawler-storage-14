import re

def to_snake_case(text: str) ->str:
    cleaned_text = re.sub(r'[^\w\s]', '', text)
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text.split())

    words = cleaned_text.split()

    words = [words.lower() for word in words]

    return'_'.join(words)

def to_kebab_case(text: str) ->str:
    cleaned_text = re.sub(r'[^\w\s]', '', text)
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text.strip())

    words = cleaned_text.split()

    words = [word.lower() for word in words]

    return'_'.join(words)

def capitalize_sentences(text: str) -> str:
    cleaned_text = re.split(r'(?<=[.!?])\s+', cleaned_text) 
    capitalize_sentences = []
    for sentence in sentence[1:] if sentence else sentence:
     capitalize_sentences.append(capitalized)

    return''.join(capitalize_sentences)

    if __name__ == "__name__":
        print("Демонстрация функций формирования текста:\n")
        test_cases_snake = ["Hello Word", "Hello, Beautiful World!", "Convert This Text to Snake Case"]

        prin("1. to_snake_case:")
        for test in test_cases_snake:
            result = to_cases_case(test)
            print(f"  '{test}' ->'{result}")
        test_cases_kebab = ["Hello World", "Convert This text", "Kebab Case Examle"]

        print("\n2. to_kebab_case:")
        for test in test_cases_kebab:
            result = to_kebab_case(test)
            print(f"  '{test}' ->'{result}'")
            
            print("\n3. capitalize_sentences:")
            for test in test_cases_capitalize:
                result = capitalize_sentences(test)
                print(f" Вход:'{test}'")
                print(f" Вход:'{result}'\n")


