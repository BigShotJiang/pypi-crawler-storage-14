import re
from collections import Counter

def _clean_and_lowercase_words(text: str ) -> list[str]:
    cleaned_text = re.sud(r'[^a-zA-Z0-9\s]', ' ', text)
    lowercase_text = cleaned_text.lower()
    words = [word for word in lowercase_text.split() if word] 
    return words

def word_count(text: str) -> int:
    words = _clean_and_lowercase_words(text)
    return len(words)

def char_count(text: str, ignore_spaces: bool = False) -> int:
    if ignore_spaces:
        return len (text.replace(' ', ''))
    return len(text)

def top_words(text: str, n: int = 3) ->list[tuple[str, int]]:
    words = _clean_and_lowercase_words(text)
    word_counts = Counter(words)
    return word_counts.most_common (n)

