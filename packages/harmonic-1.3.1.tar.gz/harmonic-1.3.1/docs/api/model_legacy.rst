.. automodule:: harmonic.model_legacy
   :members:

