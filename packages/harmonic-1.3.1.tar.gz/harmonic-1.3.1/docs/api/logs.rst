.. automodule:: harmonic.logs
   :members: 
