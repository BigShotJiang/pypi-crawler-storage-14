.. autoclass:: harmonic.Evidence
   :members:

.. autoclass:: harmonic.Shifting
   :members:
   :undoc-members:

.. automodule:: harmonic.evidence
   :members: compute_bayes_factor, compute_ln_bayes_factor




