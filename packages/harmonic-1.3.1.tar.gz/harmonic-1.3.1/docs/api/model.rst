.. automodule:: harmonic.model
   :members:

