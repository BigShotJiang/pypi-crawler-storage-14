.. autoclass:: harmonic.Chains     
   :members:
