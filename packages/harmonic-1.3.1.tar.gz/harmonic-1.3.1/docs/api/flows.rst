.. autoclass:: harmonic.flows.RealNVP
   :members:

.. autoclass:: harmonic.flows.RQSpline
   :members:
