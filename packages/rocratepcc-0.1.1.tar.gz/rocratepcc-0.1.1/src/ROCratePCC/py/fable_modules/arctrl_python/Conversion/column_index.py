from __future__ import annotations
from typing import Any
from ...arctrl_rocrate.ldobject import LDNode
from ...fable_library.int32 import try_parse
from ...fable_library.option import value
from ...fable_library.types import FSharpRef
from ...fable_library.util import int32_to_string

def try_int(str_1: str) -> int | None:
    match_value: tuple[bool, int]
    out_arg: int = 0
    def _arrow3871(__unit: None=None, str_1: Any=str_1) -> int:
        return out_arg

    def _arrow3872(v: int, str_1: Any=str_1) -> None:
        nonlocal out_arg
        out_arg = v or 0

    match_value = (try_parse(str_1, 511, False, 32, FSharpRef(_arrow3871, _arrow3872)), out_arg)
    if match_value[0]:
        return match_value[1]

    else: 
        return None



order_name: str = "columnIndex"

def try_get_index(node: LDNode) -> int | None:
    match_value: Any | None = node.TryGetPropertyAsSingleton(order_name)
    (pattern_matching_result, ci) = (None, None)
    if match_value is not None:
        if str(type(value(match_value))) == "<class \'str\'>":
            pattern_matching_result = 0
            ci = value(match_value)

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return try_int(ci)

    elif pattern_matching_result == 1:
        return None



def set_index(node: LDNode, index: int) -> None:
    node.SetProperty(order_name, int32_to_string(index))


def ARCtrl_ROCrate_LDNode__LDNode_GetColumnIndex(this: LDNode) -> int:
    return value(try_get_index(this))


def ARCtrl_ROCrate_LDNode__LDNode_TryGetColumnIndex(this: LDNode) -> int | None:
    return try_get_index(this)


def ARCtrl_ROCrate_LDNode__LDNode_SetColumnIndex_Z524259A4(this: LDNode, index: int) -> None:
    set_index(this, index)


__all__ = ["try_int", "order_name", "try_get_index", "set_index", "ARCtrl_ROCrate_LDNode__LDNode_GetColumnIndex", "ARCtrl_ROCrate_LDNode__LDNode_TryGetColumnIndex", "ARCtrl_ROCrate_LDNode__LDNode_SetColumnIndex_Z524259A4"]

