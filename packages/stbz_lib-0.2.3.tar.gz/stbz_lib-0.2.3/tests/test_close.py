# tests/test_close.py
from stbz_lib import close

terminated = close("PUBG:")
print(terminated)
