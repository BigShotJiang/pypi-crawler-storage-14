# tests/test_shutdown.py
from stbz_lib import reboot, shutdown

# 測試關機
# shutdown()

# 測試重新開機
# reboot()
