"""Lint commands package."""

from .lint import LintCommand

__all__ = ["LintCommand"]
