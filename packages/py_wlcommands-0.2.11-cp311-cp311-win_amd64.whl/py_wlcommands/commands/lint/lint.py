"""
Lint command.
"""

import sys
from argparse import ArgumentParser
from pathlib import Path

from py_wlcommands.commands import Command, register_command, validate_command_args
from py_wlcommands.commands.format.format_command import FormatCommand
from py_wlcommands.utils.logging import log_info
from py_wlcommands.utils.subprocess_utils import SubprocessExecutor, SubprocessResult


@register_command("lint")
class LintCommand(Command):
    """Command to lint code."""

    @property
    def name(self) -> str:
        return "lint"

    @property
    def help(self) -> str:
        return "Lint code with ruff - equivalent to make lint"

    @classmethod
    def add_arguments(cls, parser: ArgumentParser) -> None:
        """Add command-specific arguments."""
        parser.add_argument(
            "paths", nargs="*", help="Paths to lint (default: current directory)"
        )
        parser.add_argument(
            "-q", "--quiet", action="store_true", help="Suppress detailed output"
        )
        parser.add_argument(
            "--fix", action="store_true", help="Automatically fix lint errors"
        )
        parser.add_argument(
            "--noreport",
            action="store_true",
            help="Do not generate lint report in todos folder",
        )
        parser.add_argument(
            "--report",
            action="store_true",
            help="Generate lint report in todos folder",
        )

    @validate_command_args()
    def execute(
        self,
        paths: list[str] | None = None,
        quiet: bool = False,
        fix: bool = False,
        noreport: bool = False,
        report: bool = False,
        **kwargs: dict[str, object],
    ) -> None:
        """
        Lint code - equivalent to make lint
        代码静态检查 - 等效于 make lint
        """
        # 忽略传递的额外参数，例如'command'
        # Ignore extra arguments passed, such as 'command'

        if not quiet:
            self._log_info("Linting code...", "正在进行代码静态检查...")

        try:
            # Get project root directory
            project_root = self._get_project_root()

            # First, format the code
            # 首先，格式化代码
            self._format_code(project_root, paths, quiet)

            # Prepare and run ruff command
            cmd = self._prepare_ruff_command(paths, fix, quiet)

            result = self._run_ruff_command(cmd, project_root, quiet, noreport)

            # Generate report if requested (default behavior)
            if report or not noreport:
                self._generate_report(result, project_root, quiet, paths, fix)

            # Handle result
            self._handle_result(result, quiet)

            # 如果有错误，退出码非0
            if result.returncode != 0:
                sys.exit(result.returncode)

        except FileNotFoundError:
            self._handle_file_not_found_error(quiet)
            sys.exit(1)
        except Exception as e:
            self._handle_general_error(e, quiet)
            sys.exit(1)

    def _get_project_root(self) -> Path:
        """Get the project root directory by looking for pyproject.toml file."""
        from py_wlcommands.utils.project_root import find_project_root

        return find_project_root()

    def _log_info(self, en_msg: str, zh_msg: str) -> None:
        """Log info message in both English and Chinese."""
        log_info(en_msg, lang="en")
        log_info(zh_msg, lang="zh")

    def _format_code(
        self, project_root: Path, paths: list[str] | None, quiet: bool
    ) -> None:
        """Format code before linting."""
        if not quiet:
            self._log_info(
                "Formatting code before linting...", "在静态检查前先格式化代码..."
            )

        format_cmd = FormatCommand()
        valid_paths: list[str] | None = None
        if paths:
            filtered = [
                p for p in paths if (project_root / p).exists() or Path(p).exists()
            ]
            valid_paths = filtered if filtered else None
        format_cmd.run(quiet=quiet, unsafe=True, paths=valid_paths, for_lint=True)

    def _prepare_ruff_command(
        self, paths: list[str] | None, fix: bool, quiet: bool
    ) -> list[str]:
        """Prepare the ruff command."""
        # Prepare ruff command (offline, no uv fetch)
        cmd = ["ruff", "check"]

        # Add paths to lint or default to current directory
        if paths:
            existing = []
            for p in paths:
                try:
                    if Path(p).exists():
                        existing.append(p)
                except Exception:
                    pass
            if existing:
                cmd.extend(existing)
            else:
                cmd.append(".")
        else:
            cmd.append(".")

        # Add fix flag if requested
        if fix:
            cmd.append("--fix")

        # Add quiet flag if requested
        if quiet:
            cmd.append("--quiet")

        return cmd

    def _run_ruff_command(
        self, cmd: list[str], project_root: Path, quiet: bool, noreport: bool
    ) -> SubprocessResult:
        """Run the ruff command and return the result (统一子进程执行)."""
        executor = SubprocessExecutor()
        capture = quiet or not noreport
        return executor.run(command=cmd, cwd=project_root, quiet=capture)

    def _generate_report(
        self,
        result: SubprocessResult,
        project_root: Path,
        quiet: bool,
        paths: list[str] | None,
        fix: bool,
    ) -> None:
        todos_dir = project_root / "todos"
        todos_dir.mkdir(exist_ok=True)

        report_file = todos_dir / "lint_report.md"

        lines: list[str] = []
        lines.append("# Lint Report\n")
        lines.append("## Configuration\n\n")
        lines.append(f"- Quiet mode: {quiet}\n")
        lines.append(f"- Fix enabled: {fix}\n")
        lines.append(f"- Paths: {', '.join(paths) if paths else '.'}\n\n")

        issues_found = False

        def check_dir(title: str, dir_path: Path) -> None:
            nonlocal issues_found
            if not dir_path.exists():
                return
            exec_res = SubprocessExecutor().run(
                ["ruff", "check", str(dir_path)], cwd=project_root, quiet=True
            )
            if exec_res.stdout.strip():
                issues_found = True
                lines.append(f"## Issues in {title}\n\n")
                lines.append("```\n")
                lines.append(exec_res.stdout)
                lines.append("```\n")
            if exec_res.stderr.strip():
                lines.append(f"## Errors in {title}\n\n")
                lines.append("```\n")
                lines.append(exec_res.stderr)
                lines.append("```\n")

        check_dir("src/", project_root / "src")
        check_dir("tools/", project_root / "tools")
        check_dir("examples/", project_root / "examples")

        if not issues_found and not result.stdout:
            lines.append("No lint issues found.\n")
        if result.stderr and not result.stdout:
            lines.append("\n## Errors\n\n")
            lines.append("```\n")
            lines.append(result.stderr)
            lines.append("```\n")

        with open(report_file, "w", encoding="utf-8") as f:
            f.writelines(lines)

        if not quiet:
            self._log_info(
                f"Lint report generated at {report_file}",
                f"静态检查报告已生成到 {report_file}",
            )

    def _handle_result(self, result: SubprocessResult, quiet: bool) -> None:
        """Handle the result of the linting process."""
        if result.returncode != 0 and not quiet:
            self._log_info(
                "Linting completed with issues:", "代码静态检查发现以下问题:"
            )
            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(result.stderr)
        elif result.returncode == 0 and not quiet:
            self._log_info(
                "Code linting completed successfully!", "代码静态检查成功完成！"
            )

    def _handle_file_not_found_error(self, quiet: bool) -> None:
        """Handle FileNotFoundError."""
        if not quiet:
            self._log_info(
                "Error: ruff is not installed or not found in PATH",
                "错误：未安装 ruff 或在 PATH 中找不到",
            )

    def _handle_general_error(self, e: Exception, quiet: bool) -> None:
        """Handle general exceptions."""
        if not quiet:
            self._log_info(f"Error during linting: {e}", f"错误：静态检查期间出错: {e}")
