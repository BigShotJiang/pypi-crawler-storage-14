from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TypedDict

from .logging import log_error, log_info
from .subprocess_utils import SubprocessExecutor


class WorkspaceDetectionError(Exception):
    def __init__(self, message: str) -> None:
        super().__init__(message)


class WorkspaceDetectionRules(TypedDict, total=False):
    use_pyproject: bool
    use_uv_lock: bool
    use_uv_init: bool
    use_uv_tree: bool
    uv_tree_min_roots: int
    cwd: str


@dataclass
class ValidationResult:
    valid: bool
    details: dict[str, str]


class WorkspaceDetector:
    def __init__(self, rules: WorkspaceDetectionRules | None = None) -> None:
        self._executor = SubprocessExecutor()
        self._cache: dict[str, bool] = {}
        self._rules: WorkspaceDetectionRules = {
            "use_pyproject": True,
            "use_uv_lock": True,
            "use_uv_init": True,
            "use_uv_tree": True,
            "uv_tree_min_roots": 2,
        }
        if rules:
            self._rules.update(rules)

    def detect(self, project_root: Path | None = None) -> bool:
        start = (project_root or Path(self._rules.get("cwd", "."))).resolve()
        key = str(start)
        if key in self._cache:
            return self._cache[key]

        try:
            root = self._find_workspace_root(start)

            if self._rules.get(
                "use_pyproject", True
            ) and self._check_pyproject_workspace(root):
                self._cache[key] = True
                return True

            if self._rules.get("use_uv_lock", True) and self._check_uv_lock_workspace(
                root
            ):
                self._cache[key] = True
                return True

            if self._rules.get("use_uv_init", True) and self._check_init_workspace(
                root
            ):
                self._cache[key] = True
                return True

            if self._rules.get("use_uv_tree", True) and self._check_tree_workspace(
                root
            ):
                self._cache[key] = True
                return True

            self._cache[key] = False
            return False
        except Exception:
            self._cache[key] = False
            return False

    def validate(self, project_root: Path | None = None) -> ValidationResult:
        root = self._find_workspace_root(
            (project_root or Path(self._rules.get("cwd", "."))).resolve()
        )
        detected = self.detect(root)
        details: dict[str, str] = {}
        pyproject_path = root / "pyproject.toml"
        uv_lock_path = root / "uv.lock"
        details["pyproject.exists"] = str(pyproject_path.exists())
        details["uv.lock.exists"] = str(uv_lock_path.exists())
        details["apps.exists"] = str((root / "apps").exists())
        details["packages.exists"] = str((root / "packages").exists())
        return ValidationResult(valid=detected, details=details)

    def get_config(self) -> WorkspaceDetectionRules:
        return self._rules.copy()

    def resolve_path(self, path: str | Path, project_root: Path | None = None) -> Path:
        root = self._find_workspace_root(
            (project_root or Path(self._rules.get("cwd", "."))).resolve()
        )
        p = Path(path)
        if p.is_absolute():
            return p
        resolved = (root / p).resolve()
        return resolved

    def get_venv_path(self, project_root: Path | None = None) -> Path | None:
        root = self._find_workspace_root(
            (project_root or Path(self._rules.get("cwd", "."))).resolve()
        )
        env_path = os.environ.get("VENV_PATH")
        if env_path:
            p = Path(env_path)
            if p.exists():
                return p.resolve()
        local = root / ".venv"
        if local.exists():
            return local.resolve()
        try:
            res = self._executor.run(
                [
                    "uv",
                    "run",
                    "python",
                    "-c",
                    "import sys;print(sys.executable)",
                ],
                cwd=root,
                quiet=True,
            )
            if res.success and res.stdout:
                exe = Path(res.stdout.strip())
                parent = exe.parent
                venv_dir = parent.parent
                if venv_dir.exists():
                    return venv_dir.resolve()
        except Exception:
            return None
        return None

    def get_active_venv_path_str(self, project_root: Path | None = None) -> str:
        root = self._find_workspace_root(
            (project_root or Path(self._rules.get("cwd", "."))).resolve()
        )
        log_info(f"Workspace venv path resolution at: {root}")

        if not self.detect(root):
            log_error("Not in a uv workspace environment")
            raise WorkspaceDetectionError("Not in a uv workspace environment")

        py = root / "pyproject.toml"
        uv_toml = root / "uv.toml"
        ws_json = root / "workspace.json"
        has_ws_conf = False
        try:
            if py.exists() and "tool.uv.workspace" in py.read_text(encoding="utf-8"):
                has_ws_conf = True
            if uv_toml.exists() or ws_json.exists():
                has_ws_conf = True
        except Exception:
            pass
        if not has_ws_conf:
            log_error("Workspace configuration file not found or invalid")
            raise WorkspaceDetectionError(
                "Workspace configuration not found or invalid"
            )

        venv_env = os.environ.get("VIRTUAL_ENV", "").strip()
        if not venv_env:
            log_error("Virtual environment is not activated (VIRTUAL_ENV not set)")
            raise WorkspaceDetectionError("Virtual environment not activated")

        venv_path = Path(venv_env)
        if not venv_path.exists():
            log_error(f"Activated virtual environment path does not exist: {venv_env}")
            raise WorkspaceDetectionError(
                "Activated virtual environment path does not exist"
            )

        resolved = venv_path.resolve()
        normalized = resolved.as_posix().rstrip("/")
        log_info(f"Resolved virtual environment path: {normalized}")
        return normalized

    def _check_pyproject_workspace(self, root: Path) -> bool:
        py = root / "pyproject.toml"
        if not py.exists():
            return False
        try:
            content = py.read_text(encoding="utf-8")
            return "[tool.uv.workspace]" in content or "tool.uv.workspace" in content
        except Exception:
            return False

    def _check_uv_lock_workspace(self, root: Path) -> bool:
        lock = root / "uv.lock"
        if not lock.exists():
            return False
        try:
            content = lock.read_text(encoding="utf-8")
            count = content.count("[package]")
            return count >= 5
        except Exception:
            return False

    def _check_init_workspace(self, root: Path) -> bool:
        try:
            result = self._executor.run(
                ["uv", "init", "--dry-run"], cwd=root, quiet=True, cache_result=True
            )
            output = (result.stdout or "") + (result.stderr or "")
            return result.success and ("is already a member of workspace" in output)
        except Exception:
            return False

    def _check_tree_workspace(self, root: Path) -> bool:
        try:
            result = self._executor.run(
                ["uv", "tree"], cwd=root, quiet=True, cache_result=True
            )
            if not result.success or not result.stdout:
                return False
            lines = result.stdout.split("\n")
            roots = self._parse_root_packages(lines)
            return len(roots) >= int(self._rules.get("uv_tree_min_roots", 2))
        except Exception:
            return False

    def _find_workspace_root(self, start: Path) -> Path:
        cur = start
        try:
            while True:
                if self._rules.get(
                    "use_pyproject", True
                ) and self._check_pyproject_workspace(cur):
                    return cur
                if self._rules.get(
                    "use_uv_lock", True
                ) and self._check_uv_lock_workspace(cur):
                    return cur
                if cur.parent == cur:
                    return start
                cur = cur.parent
        except Exception:
            return start

    def _parse_root_packages(self, lines: list[str]) -> list[str]:
        roots: list[str] = []
        for line in lines:
            if (
                not line.startswith(" ")
                and line.strip()
                and not line.startswith("Resolved")
                and not line.startswith("(*)")
            ):
                if " v" in line and not line.startswith("v"):
                    parts = line.split(" v", 1)
                    if len(parts) == 2:
                        name = parts[0]
                        ver = parts[1]
                        if (
                            name
                            and not name.startswith(("├", "└", "│"))
                            and self._is_valid_version(ver)
                        ):
                            roots.append(name)
                elif line and not line.startswith(("├", "└", "│")):
                    roots.append(line.strip())
        return roots

    def _is_valid_version(self, version: str) -> bool:
        if not version:
            return False
        return all(c.isalnum() or c in ".-+" for c in version)


# Aliases for requested method names
WorkspaceDetector.getConfig = WorkspaceDetector.get_config  # type: ignore[attr-defined]
WorkspaceDetector.resolvePath = WorkspaceDetector.resolve_path  # type: ignore[attr-defined]
WorkspaceDetector.getVenvPath = WorkspaceDetector.get_venv_path  # type: ignore[attr-defined]
WorkspaceDetector.getActiveVenvPath = WorkspaceDetector.get_active_venv_path_str  # type: ignore[attr-defined]
