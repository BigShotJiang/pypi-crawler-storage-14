# Legacy module - all functionality moved to databricks.ml_features.entities.materialized_feature
# This module is kept for potential future use but exports nothing

__all__ = []
