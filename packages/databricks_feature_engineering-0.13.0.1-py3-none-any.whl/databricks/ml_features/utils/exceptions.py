# Custom Exceptions


class ConflictError(Exception):
    """Raised when there is a conflict with the current state of a resource."""

    pass
