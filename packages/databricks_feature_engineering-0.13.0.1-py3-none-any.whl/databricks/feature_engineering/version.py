from databricks.ml_features.version import VERSION

__all__ = ["VERSION"]
