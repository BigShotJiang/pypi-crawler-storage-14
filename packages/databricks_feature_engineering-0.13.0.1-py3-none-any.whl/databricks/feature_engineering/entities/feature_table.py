from databricks.ml_features.entities.feature_table import FeatureTable

__all__ = ["FeatureTable"]
