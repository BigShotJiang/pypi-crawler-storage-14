from databricks.ml_features.entities.feature_spec_info import FeatureSpecInfo

__all__ = ["FeatureSpecInfo"]
