from databricks.ml_features.entities.materialized_view_info import MaterializedViewInfo

__all__ = ["MaterializedViewInfo"]
