# antispam_core/help_menu.py
async def start_handler_cmd(message,text):
    """نمایش منوی راهنما (start command)"""
    await message.reply(text)
