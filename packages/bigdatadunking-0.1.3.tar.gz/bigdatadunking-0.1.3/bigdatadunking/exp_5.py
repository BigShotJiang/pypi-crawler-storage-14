import os
import subprocess
import tarfile
import sys
import platform

# --- Configuration ---
PIG_VERSION = "0.17.0"
PIG_TAR_FILE = f"pig-{PIG_VERSION}.tar.gz"
PIG_DIR = f"pig-{PIG_VERSION}"
PIG_PATH = os.path.join(os.path.expanduser('~'), 'pig')  # Use user home directory for Pig installation
PIG_DOWNLOAD_URL = f"https://downloads.apache.org/pig/pig-{PIG_VERSION}/{PIG_TAR_FILE}"
PIG_SCRIPT_FILE = "program.pig"
STUDENTS_FILE = "students.csv"
DEPARTMENTS_FILE = "departments.csv"
JAVA_HOME = '/usr/lib/jvm/java-11-openjdk-amd64' # Common path in Ubuntu/Debian based systems

# --- Data and Script Content ---
students_data = """1,Ravi,CSE,85
2,Anita,IT,55
3,John,CSE,72
4,Kiran,ECE,67
5,Meera,IT,90
"""

departments_data = """CSE,Dr.Sharma
IT,Dr.Verma
ECE,Dr.Rao
"""

pig_script = r"""
-- Load student and department data
students = LOAD 'students.csv' USING PigStorage(',')
           AS (id:int, name:chararray, dept:chararray, marks:int);

departments = LOAD 'departments.csv' USING PigStorage(',')
              AS (dept:chararray, hod:chararray);

-- Filter: students with marks > 60
good_students = FILTER students BY marks > 60;

-- Project: select only name, dept, marks
projected = FOREACH good_students GENERATE name, dept, marks;

-- Group: by department
grouped = GROUP projected BY dept;

-- Sort: order students by marks descending
sorted = ORDER projected BY marks DESC;

-- Join: combine with department HOD info
joined = JOIN projected BY dept, departments BY dept;

-- Dump results
DUMP sorted;
DUMP grouped;
DUMP joined;
"""

def check_java_installed():
    """Checks for Java installation, required by Pig."""
    try:
        java_version_check = subprocess.run(["java", "-version"], check=True, capture_output=True, text=True)
        print("Java is installed.")
        # Attempt to set JAVA_HOME for the Pig execution environment
        os.environ['JAVA_HOME'] = JAVA_HOME
        os.environ['PATH'] = os.path.join(JAVA_HOME, 'bin') + os.pathsep + os.environ.get('PATH', '')
    except subprocess.CalledProcessError:
        print("Java is not configured correctly or JAVA_HOME is incorrect.")
        sys.exit(1)
    except FileNotFoundError:
        print("Error: Java executable not found. Please ensure Java 8 or 11 is installed and in your PATH.")
        sys.exit(1)

def setup_pig_and_run_script():
    """Manages the entire Pig setup, data creation, and execution process."""
    
    check_java_installed()

    print(f"--- 1. Setting up Apache Pig {PIG_VERSION} ---")

    # 1. Download Apache Pig
    if not os.path.exists(PIG_TAR_FILE):
        try:
            print(f"Downloading {PIG_TAR_FILE}...")
            # Use curl if wget is unavailable
            subprocess.run(["wget", PIG_DOWNLOAD_URL], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print("Download successful.")
        except FileNotFoundError:
            print("wget command not found. Please ensure it's installed.")
            sys.exit(1)
        except subprocess.CalledProcessError:
            print(f"Error: Failed to download Pig from {PIG_DOWNLOAD_URL}.")
            sys.exit(1)
    
    # 2. Extract and Move Pig
    if not os.path.exists(PIG_PATH):
        try:
            print(f"Extracting {PIG_TAR_FILE}...")
            with tarfile.open(PIG_TAR_FILE, "r:gz") as tar:
                tar.extractall()
            os.rename(PIG_DIR, PIG_PATH)
            print(f"Pig moved to {PIG_PATH}")
        except Exception as e:
            print(f"Error during Pig extraction/move: {e}")
            sys.exit(1)
    
    # 3. Set PIG_HOME environment variable
    os.environ['PIG_HOME'] = PIG_PATH
    os.environ['PATH'] += os.pathsep + os.path.join(os.environ['PIG_HOME'], 'bin')
    print(f"PIG_HOME set to: {os.environ['PIG_HOME']}")
    print("-" * 50)

    print("--- 2. Creating Input Data Files ---")
    
    # Create students.csv
    with open(STUDENTS_FILE, "w") as f:
        f.write(students_data)
        
    # Create departments.csv
    with open(DEPARTMENTS_FILE, "w") as f:
        f.write(departments_data)
    
    print(f"Created {STUDENTS_FILE} and {DEPARTMENTS_FILE} in current directory.")
    print("-" * 50)

    print("--- 3. Creating Pig Latin Script ---")
    
    # Create program.pig script
    with open(PIG_SCRIPT_FILE, "w") as f:
        f.write(pig_script)
    
    print(f"Created Pig script: {PIG_SCRIPT_FILE}")
    print("-" * 50)

    print("--- 4. Executing Pig Script in Local Mode ---")

    try:
        # Execute the Pig script using the pig executable via its bin path
        pig_executable = os.path.join(os.environ['PIG_HOME'], 'bin', 'pig')
        result = subprocess.run(
            [pig_executable, "-x", "local", PIG_SCRIPT_FILE],
            check=True,
            capture_output=True,
            text=True
        )
        
        # --- Parse and Print Results ---
        output_lines = result.stdout.splitlines()
        
        print("\n** Pig Script Output: DUMP Results **")
        
        results = {"sorted": [], "grouped": [], "joined": []}
        current_dump = None
        
        for line in output_lines:
            if line.startswith('(') or line.startswith('('): # Capture tuples and bags
                if current_dump:
                    results[current_dump].append(line)
            
            # Identify the start of a DUMP output by looking for specific tuples
            if "(Meera,IT,90)" in line and "sorted" not in results["sorted"]:
                 current_dump = "sorted"
            elif "(IT,{(Meera,IT,90)})" in line and "grouped" not in results["grouped"]:
                 current_dump = "grouped"
            elif "(Meera,IT,90,IT,Dr.Verma)" in line and "joined" not in results["joined"]:
                 current_dump = "joined"

        print("\n** 1. DUMP sorted (Students > 60, sorted by Marks DESC) **")
        print('\n'.join(results["sorted"]))
                
        print("\n** 2. DUMP grouped (Good Students grouped by Department) **")
        print('\n'.join(results["grouped"]))
        
        print("\n** 3. DUMP joined (Good Students joined with HOD) **")
        print('\n'.join(results["joined"]))
        
        print("\n" + "-" * 50)
        print("Pig Execution Summary:")
        for line in output_lines:
            if "Pig script completed in" in line or "Success!" in line:
                 print(line)
            
    except subprocess.CalledProcessError as e:
        print(f"Error during Pig execution. Check Pig log files for details.")
        print(f"Stderr (first 10 lines): \n{e.stderr.splitlines()[:10]}")
    except FileNotFoundError:
        print("Error: The 'pig' executable was not found. Check PIG_HOME path.")
        sys.exit(1)

# Run the entire process
if __name__ == "__main__":
    setup_pig_and_run_script()


# Setup & Execution in Linux
# Prerequisites
# Python 3: Must be installed on your Linux machine.

# Java (JDK 8 or 11): Apache Pig requires a compatible Java Development Kit.

# Step 1: Save the Code
# Save the code block above into a file named pig_execution.py.

# Step 2: Install Java (If needed)
# The script uses a default Java 11 path (/usr/lib/jvm/java-11-openjdk-amd64). If you don't have Java 11 OpenJDK installed, install it or change the JAVA_HOME variable in the script to match your existing Java path.

# For Debian/Ubuntu:

# Bash

# sudo apt update
# sudo apt install openjdk-11-jdk wget
# Step 3: Install Python Libraries
# You only need Python's built-in libraries for this script (os, subprocess, tarfile, sys). No external pip packages are required.

# Step 4: Execute the Python File
# Run the script from your terminal:

# Bash

# python3 pig_execution.py