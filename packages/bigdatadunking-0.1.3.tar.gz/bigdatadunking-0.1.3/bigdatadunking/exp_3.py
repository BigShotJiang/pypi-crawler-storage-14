import os

import subprocess

from textwrap import dedent

import sys

import shutil # For cleanup operations



# --- Configuration ---

HADOOP_VERSION = "3.3.6"

HADOOP_TAR_FILE = f"hadoop-{HADOOP_VERSION}.tar.gz"

HADOOP_DIR = f"hadoop-{HADOOP_VERSION}"

HADOOP_INSTALL_PATH = "/usr/local/hadoop"

JAVA_HOME = "/usr/lib/jvm/java-8-openjdk-amd64"



# --- Main Execution Function ---

def setup_and_run_hadoop_job():

    """Performs Hadoop installation, configuration, data setup, and job execution."""

   

    # Check if we are already in an interactive terminal that might need sudo

    if os.geteuid() != 0:

        print("Warning: This script requires root privileges (or a container environment like Colab) for installation.")

        print("Please run this script with 'sudo python3 hadoop_wordcount.py' or in a suitable environment.")

        # We will continue, assuming the environment (like Colab/Docker) handles permissions internally.

       

    print("--- 1. Setting up Hadoop Environment (Hadoop 3.3.6) ---")



    # 1.1 Download, Install, and Move Hadoop

    if not os.path.exists(HADOOP_INSTALL_PATH) or not os.path.exists(os.path.join(HADOOP_INSTALL_PATH, 'bin', 'hadoop')):

        try:

            # Consolidate shell commands for clean execution

            setup_commands = dedent(f"""

                # Install Java

                apt-get update -qq > /dev/null

                apt-get install openjdk-8-jdk-headless -qq > /dev/null

               

                # Download and Extract Hadoop

                wget -q --show-progress https://downloads.apache.org/hadoop/common/{HADOOP_VERSION}/{HADOOP_TAR_FILE}

                tar -xzf {HADOOP_TAR_FILE} > /dev/null

                rm {HADOOP_TAR_FILE} # Clean up tar file

               

                # Move to installation path

                mv {HADOOP_DIR} {HADOOP_INSTALL_PATH}

            """)

            subprocess.run(setup_commands, shell=True, check=True, executable='/bin/bash')

            print(f"Hadoop {HADOOP_VERSION} installed successfully.")

           

        except subprocess.CalledProcessError as e:

            print(f"Error during Hadoop setup:\n{e.output}")

            sys.exit(1)

        except FileNotFoundError:

            print("Error: wget command not found. Please ensure it is installed.")

            sys.exit(1)



    # 1.2 Set Environment Variables

    os.environ["JAVA_HOME"] = JAVA_HOME

    os.environ["HADOOP_HOME"] = HADOOP_INSTALL_PATH

   

    # Update PATH to include Hadoop binaries

    os.environ["PATH"] = f"{os.environ['HADOOP_HOME']}/bin:{os.environ['HADOOP_HOME']}/sbin:{os.environ['JAVA_HOME']}/bin:" + os.environ.get("PATH", "")

   

    # 1.3 Configure Hadoop (Minimal setup for HDFS)

    conf_dir = os.path.join(HADOOP_INSTALL_PATH, 'etc', 'hadoop')

   

    core_site_content = dedent("""

        <configuration>

            <property>

                <name>fs.defaultFS</name>

                <value>hdfs://localhost:9000</value>

            </property>

        </configuration>

    """)

   

    # Minimal config to suppress warnings and run without full HDFS startup

    hdfs_site_content = dedent("""

        <configuration>

            <property>

                <name>dfs.namenode.name.dir</name>

                <value>file:///tmp/hadoop-namenode</value>

            </property>

            <property>

                <name>dfs.datanode.data.dir</name>

                <value>file:///tmp/hadoop-datanode</value>

            </property>

            <property>

                <name>dfs.replication</name>

                <value>1</value>

            </property>

        </configuration>

    """)

   

    with open(os.path.join(conf_dir, 'core-site.xml'), 'w') as f:

        f.write(core_site_content)

    with open(os.path.join(conf_dir, 'hdfs-site.xml'), 'w') as f:

        f.write(hdfs_site_content)

       

    print("Hadoop configuration (core-site.xml, hdfs-site.xml) updated.")



    # 1.4 Check Hadoop version to confirm installation

    print("\nHadoop Version Check:")

    subprocess.run("hadoop version", shell=True, check=True)

    print("-" * 50)



    # --- 2. Create Input Data (Equivalent to Cell 3) ---



    print("\n--- 2. Creating Local Data and Scripts ---")

   

    # Create input directory and files

    if os.path.exists("input_data"):

        shutil.rmtree("input_data")

    os.makedirs("input_data")



    with open("input_data/input1.txt", "w") as f:

        f.write("Hello World Bye World\n")

    with open("input_data/input2.txt", "w") as f:

        f.write("Hello Hadoop Goodbye Hadoop\n")



    # Display content

    print("\nContent of Input Files (Local):")

    subprocess.run("cat input_data/*", shell=True, check=True)



    # --- 3. Define MapReduce Scripts (Equivalent to Cell 4) ---



    # Define mapper.py

    mapper_code = dedent("""

        import sys



        for line in sys.stdin:

            line = line.strip()

            # Clean up punctuation and split

            line = line.replace(",", "").replace(".", "").lower()

            for word in line.split():

                print(f"{word}\\t1")

    """)

    with open("mapper.py", "w") as f:

        f.write(mapper_code)



    # Define combiner.py

    combiner_code = dedent("""

        import sys

        from collections import defaultdict



        counts = defaultdict(int)

        for line in sys.stdin:

            try:

                word, count = line.strip().split("\\t")

                counts[word] += int(count)

            except ValueError:

                continue



        for word, count in counts.items():

            print(f"{word}\\t{count}")

    """)

    with open("combiner.py", "w") as f:

        f.write(combiner_code)



    # Define reducer.py

    reducer_code = dedent("""

        import sys



        current_word = None

        current_count = 0



        for line in sys.stdin:

            try:

                word, count = line.strip().split("\\t")

                count = int(count)

            except ValueError:

                continue



            if current_word == word:

                current_count += count

            else:

                if current_word:

                    # Output result for the previous word

                    print(f"{current_word}\\t{current_count}")

               

                # Start tracking the new word

                current_word = word

                current_count = count



        # Output the last word's count

        if current_word:

            print(f"{current_word}\\t{current_count}")

    """)

    with open("reducer.py", "w") as f:

        f.write(reducer_code)



    # Make the scripts executable

    subprocess.run("chmod +x mapper.py combiner.py reducer.py", shell=True, check=True)

    print("MapReduce scripts created and made executable.")

    print("-" * 50)



    # --- 4. Run Hadoop Streaming Job (Equivalent to Cell 5) ---



    # Illustrate the MapReduce job flow



    print("\n--- 4. Running Hadoop Streaming Word Count Job ---")



    # 4.1 HDFS setup/cleanup for local mode

    hdfs_setup_commands = dedent("""

        # Clean up existing I/O directories

        hadoop fs -rm -r -f input output

        # Create input directory

        hadoop fs -mkdir -p input

        # Upload local files to HDFS

        hadoop fs -put input_data/* input/

    """)

    subprocess.run(hdfs_setup_commands, shell=True, check=True)

    print("Data uploaded to simulated HDFS (input/ directory).")



    # 4.2 Find the hadoop-streaming JAR path dynamically

    streaming_jar = subprocess.run(

        f"ls {os.environ['HADOOP_HOME']}/share/hadoop/tools/lib/hadoop-streaming-*.jar",

        shell=True,

        capture_output=True,

        text=True,

        check=True

    ).stdout.strip().split('\n')[0] # Only take the first path



    # 4.3 Construct and run the Hadoop Streaming command

    streaming_command = dedent(f"""

        hadoop jar {streaming_jar} \\

        -input input \\

        -output output \\

        -mapper mapper.py \\

        -combiner combiner.py \\

        -reducer reducer.py \\

        -file mapper.py \\

        -file combiner.py \\

        -file reducer.py

    """)



    print("\nExecuting Streaming Command...")

    subprocess.run(streaming_command, shell=True, check=True)

    print("Hadoop MapReduce Job completed successfully.")



    # --- 5. Display Results (Equivalent to Cell 6) ---



    print("\n--- 5. Final Word Count Results ---")

   

    # Cat the output from HDFS

    result = subprocess.run("hadoop fs -cat output/part-00000", shell=True, check=True, capture_output=True, text=True)

    print(result.stdout.strip())

    print("-" * 50)



    # Final cleanup (optional, but good practice)

    shutil.rmtree("input_data", ignore_errors=True)

    os.remove("mapper.py")

    os.remove("combiner.py")

    os.remove("reducer.py")

    print("Local setup files cleaned up.")





if __name__ == "__main__":

    setup_and_run_hadoop_job()



# rerequisites

# Linux Environment: (e.g., Ubuntu 20.04/22.04)



# Python 3: Installed.



# Basic Tools: wget, tar, and permission to install packages (sudo or a compatible environment).



# Step 1: Save the Code

# Copy the code block above and save it into a file named hadoop_wordcount.py.



# Step 2: Execute the Script

# Run the script from your terminal. Since this script performs system installation (apt-get) and moves files to /usr/local/, it requires elevated permissions.



# Bash



# # Run the script with root privileges

# sudo python3 hadoop_wordcount.py