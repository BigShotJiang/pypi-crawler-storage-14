import pandas as pd
import sqlite3
import random
import os
from contextlib import contextmanager

# --- Configuration and Setup ---

DB_NAME = 'weather_hive.db'

def generate_sample_data(num_records=1000):
    """Generates a DataFrame with random weather data."""
    years = list(range(1900, 2021))
    data = {
        'record_id': range(1, num_records + 1),
        'year': [random.choice(years) for _ in range(num_records)],
        # Temperatures between -50.0 and 50.0 degrees Celsius
        'temperature_c': [random.uniform(-50.0, 50.0) for _ in range(num_records)]
    }
    return pd.DataFrame(data)

@contextmanager
def sqlite_connection(db_name):
    """Context manager to handle SQLite connection and ensure it closes."""
    conn = sqlite3.connect(db_name)
    try:
        yield conn
    finally:
        conn.close()

def setup_hive_like_db():
    """Sets up the table, index, and view, mimicking a Hive environment."""
    print("Setting up Hive-like environment...")
    
    # 1. Generate and Load Data (Simulating a CREATE TABLE AS/LOAD DATA)
    df = generate_sample_data(1000)

    with sqlite_connection(DB_NAME) as conn:
        df.to_sql('weather_data', conn, if_exists='replace', index=False)
        
        # 2. Create Index (Simulating Indexing for faster lookups)
        conn.execute('CREATE INDEX IF NOT EXISTS idx_year ON weather_data(year)')
        
        # 3. Create View (Simulating a VIEW for pre-filtered data)
        conn.execute('''
            CREATE VIEW IF NOT EXISTS positive_temps AS
            SELECT record_id, year, temperature_c
            FROM weather_data
            WHERE temperature_c > 0
        ''')

    print(f"Database '{DB_NAME}', table 'weather_data', index 'idx_year', and view 'positive_temps' created.")

# --- UDF Definition ---

def celsius_to_fahrenheit(temp_c):
    """Converts Celsius to Fahrenheit: (C * 9/5) + 32. Returns None for non-positive input."""
    if temp_c <= 0:
        # Returning None/NaN for non-positive values to match the logic in the original output
        return None 
    return (temp_c * 9/5) + 32

def register_udf(conn):
    """Registers the Celsius to Fahrenheit UDF with the SQLite connection."""
    # Register the Python function as a SQL function named 'c_to_f'
    conn.create_function('c_to_f', 1, celsius_to_fahrenheit)
    print("UDF 'c_to_f' registered.")

# --- Reporting Logic (Simulating HiveQL Queries) ---

def generate_weather_report():
    """Runs aggregate queries against the database using the UDF and view."""
    print("\nGenerating Weather Temperature Statistics Report...")
    with sqlite_connection(DB_NAME) as conn:
        register_udf(conn)
        
        # Query 1: Aggregate Min/Max Celsius from the main table
        query_table = '''
            SELECT year,
                   MIN(temperature_c) AS min_temp_c,
                   MAX(temperature_c) AS max_temp_c
            FROM weather_data
            GROUP BY year
            ORDER BY year
        '''
        report_df = pd.read_sql_query(query_table, conn)
        
        # Query 2: Aggregate Max Fahrenheit from the VIEW, using the UDF
        query_view = '''
            SELECT year,
                   c_to_f(MAX(temperature_c)) AS max_temp_f
            FROM positive_temps
            GROUP BY year
            ORDER BY year
        '''
        view_df = pd.read_sql_query(query_view, conn)
        
        # Merge the two reports (LEFT JOIN on 'year')
        result = report_df.merge(view_df, on='year', how='left')
        
        # Format the output for readability, matching the original notebook's rounding
        # Note: Replace <NA> (from None in UDF) with 'nan' string
        result['max_temp_f'] = result['max_temp_f'].round(1).astype(str).replace('<NA>', 'nan')
        result['min_temp_c'] = result['min_temp_c'].round(1)
        result['max_temp_c'] = result['max_temp_c'].round(1)

    return result

# --- Main Execution ---

if __name__ == "__main__":
    
    # Clean up previous run's DB file if it exists (optional, but good for reproducibility)
    if os.path.exists(DB_NAME):
        os.remove(DB_NAME)
        
    setup_hive_like_db()

    report = generate_weather_report()

    # Print the report
    print("\n=== Weather Report ===")
    print("Year\tMin Temp (°C)\tMax Temp (°C)\tMax Temp (°F)")
    print("-" * 50)
    
    # Custom print loop for tab-separated output
    for _, row in report.iterrows():
        min_temp_str = str(row['min_temp_c'])
        max_temp_c_str = str(row['max_temp_c'])
        
        print(f"{int(row['year'])}\t{min_temp_str}\t\t{max_temp_c_str}\t\t{row['max_temp_f']}")

    # Print a sample from the view
    print("\nSample data from view (first 5 rows):")
    with sqlite_connection(DB_NAME) as conn:
        sample_view = pd.read_sql_query('SELECT * FROM positive_temps LIMIT 5', conn)
        print(sample_view.to_string(index=False))