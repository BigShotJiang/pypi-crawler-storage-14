import os
import subprocess
from textwrap import dedent
import sys
import shutil

# --- Configuration for Windows ---
HADOOP_VERSION = "3.4.2"
HADOOP_TAR_FILE = f"hadoop-{HADOOP_VERSION}.tar.gz"
HADOOP_DIR = f"hadoop-{HADOOP_VERSION}"
# Use a local folder for installation on Windows
HADOOP_INSTALL_PATH = os.path.abspath(HADOOP_DIR) 

# IMPORTANT: Replace with your actual Java Home path for Java 8 (or compatible)
# Example: "C:\\Program Files\\Java\\jdk1.8.0_371"
# Ensure the path uses double backslashes or forward slashes
JAVA_HOME = "C:\Program Files\Java\jdk-16.0.1" # <--- **UPDATE THIS PATH**

# --- Helper Functions for Windows Shell ---

def run_powershell_command(command, description):
    """Executes a command using PowerShell."""
    print(f"Executing: {description}")
    try:
        # Using subprocess.run with shell=True for simple commands in Windows environment
        # cmd /c ensures the command interpreter (cmd) is used
        subprocess.run(
            f"powershell.exe -Command \"{command}\"", 
            shell=True, 
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        print("Success.")
    except subprocess.CalledProcessError as e:
        print(f"Error during {description}:\n{e.stderr}")
        sys.exit(1)
    except FileNotFoundError:
        print("Error: PowerShell not found. Ensure it is in your system PATH.")
        sys.exit(1)

def setup_hadoop_config_windows(conf_dir):
    """Creates/updates core-site.xml and hdfs-site.xml."""
    # Ensure the configuration directory exists
    os.makedirs(conf_dir, exist_ok=True)
    
    core_site_content = dedent("""
        <configuration>
            <property>
                <name>fs.defaultFS</name>
                <value>hdfs://localhost:9000</value>
            </property>
        </configuration>
    """)
    
    hdfs_site_content = dedent("""
        <configuration>
            <property>
                <name>dfs.namenode.name.dir</name>
                <value>file:///{HADOOP_DIR}/data/namenode</value>
            </property>
            <property>
                <name>dfs.datanode.data.dir</name>
                <value>file:///{HADOOP_DIR}/data/datanode</value>
            </property>
            <property>
                <name>dfs.replication</name>
                <value>1</value>
            </property>
        </configuration>
    """).format(HADOOP_DIR=HADOOP_INSTALL_PATH.replace("\\", "/")) # Use forward slashes in XML paths
    
    with open(os.path.join(conf_dir, 'core-site.xml'), 'w') as f:
        f.write(core_site_content)
    with open(os.path.join(conf_dir, 'hdfs-site.xml'), 'w') as f:
        f.write(hdfs_site_content)
        
    # Set the JAVA_HOME in hadoop-env.cmd (important for Windows)
    hadoop_env_path = os.path.join(conf_dir, 'hadoop-env.cmd')
    try:
        with open(hadoop_env_path, 'a') as f:
            f.write(f"\nset JAVA_HOME={JAVA_HOME}\n")
        print(f"JAVA_HOME set in {hadoop_env_path}")
    except Exception as e:
        print(f"Warning: Could not update hadoop-env.cmd: {e}")

    print("Hadoop configuration (core-site.xml, hdfs-site.xml) updated.")

# --- Main Execution Function ---
def setup_and_run_hadoop_job_windows():
    """Performs Hadoop installation, configuration, data setup, and job execution on Windows."""
    
    print(f"--- 1. Setting up Hadoop Environment (Hadoop {HADOOP_VERSION}) on Windows ---")

    # 1.1 Download and Extract Hadoop (using PowerShell's Invoke-WebRequest and Expand-Archive)
    if not os.path.exists(HADOOP_INSTALL_PATH):
        print(f"Hadoop not found at {HADOOP_INSTALL_PATH}. Attempting download and extraction...")
        # Clean up existing directories just in case
        shutil.rmtree(HADOOP_DIR, ignore_errors=True) 
        
        # Download (using curl which is aliased to Invoke-WebRequest in modern PowerShell)
        download_url = f"https://downloads.apache.org/hadoop/common/hadoop-3.4.2/hadoop-3.4.2.tar.gz"
        download_command = f"curl -Uri '{download_url}' -OutFile '{HADOOP_TAR_FILE}'"
        run_powershell_command(download_command, f"Download Hadoop {HADOOP_VERSION}")
        
        # Extract the .tar.gz file (Requires a tool like 7-Zip or tar in the PATH for .gz handling, 
        # or use tar -xf on modern Windows)
        # Assuming 'tar' is available on modern Windows
        extraction_command = f"tar -xf {HADOOP_TAR_FILE}; Remove-Item {HADOOP_TAR_FILE}"
        run_powershell_command(extraction_command, "Extract and cleanup Hadoop tar file")

        # Now the directory should exist and HADOOP_INSTALL_PATH is set correctly
        print(f"Hadoop extracted to {HADOOP_INSTALL_PATH}")
    else:
        print(f"Hadoop found at {HADOOP_INSTALL_PATH}. Skipping download.")

    # 1.2 Set Environment Variables for the script's subprocesses
    os.environ["JAVA_HOME"] = JAVA_HOME
    os.environ["HADOOP_HOME"] = HADOOP_INSTALL_PATH
    
    # Update PATH to include Hadoop binaries
    hadoop_bin_path = os.path.join(HADOOP_INSTALL_PATH, 'bin')
    os.environ["Path"] = f"{hadoop_bin_path};{os.environ.get('Path', '')}"
    
    # 1.3 Configure Hadoop
    conf_dir = os.path.join(HADOOP_INSTALL_PATH, 'etc', 'hadoop')
    setup_hadoop_config_windows(conf_dir)

    # 1.4 Check Hadoop version to confirm installation
    print("\nHadoop Version Check:")
    subprocess.run("hadoop version", shell=True, check=True)
    print("-" * 50)

    # --- 2. Create Input Data (Similar to original) ---
    print("\n--- 2. Creating Local Data and Scripts ---")
    
    # Create input directory and files
    input_data_path = "input_data"
    if os.path.exists(input_data_path):
        shutil.rmtree(input_data_path)
    os.makedirs(input_data_path)

    with open(os.path.join(input_data_path, "input1.txt"), "w") as f:
        f.write("Hello World Bye World\n")
    with open(os.path.join(input_data_path, "input2.txt"), "w") as f:
        f.write("Hello Hadoop Goodbye Hadoop\n")

    # Display content (using 'type' command on Windows)
    print("\nContent of Input Files (Local):")
    subprocess.run(f"type {input_data_path}\\*", shell=True, check=True)

    # --- 3. Define MapReduce Scripts (Similar to original) ---
    # Python scripts are cross-platform, but we need to ensure they're executable/found.
    
    # Define mapper.py (same as original)
    mapper_code = dedent("""
        import sys

        for line in sys.stdin:
            line = line.strip()
            line = line.replace(",", "").replace(".", "").lower()
            for word in line.split():
                print(f"{word}\\t1")
    """)
    with open("mapper.py", "w") as f:
        f.write(mapper_code)

    # Define combiner.py (same as original)
    combiner_code = dedent("""
        import sys
        from collections import defaultdict

        counts = defaultdict(int)
        for line in sys.stdin:
            try:
                word, count = line.strip().split("\\t")
                counts[word] += int(count)
            except ValueError:
                continue

        for word, count in counts.items():
            print(f"{word}\\t{count}")
    """)
    with open("combiner.py", "w") as f:
        f.write(combiner_code)

    # Define reducer.py (same as original)
    reducer_code = dedent("""
        import sys

        current_word = None
        current_count = 0

        for line in sys.stdin:
            try:
                word, count = line.strip().split("\\t")
                count = int(count)
            except ValueError:
                continue

            if current_word == word:
                current_count += count
            else:
                if current_word:
                    print(f"{current_word}\\t{current_count}")
                
                current_word = word
                current_count = count

        if current_word:
            print(f"{current_word}\\t{current_count}")
    """)
    with open("reducer.py", "w") as f:
        f.write(reducer_code)

    # No 'chmod +x' needed on Windows for Python scripts, but ensure they are in the working directory
    print("MapReduce scripts created.")
    print("-" * 50)

    # --- 4. Run Hadoop Streaming Job ---
    print("\n--- 4. Running Hadoop Streaming Word Count Job ---")

    # 4.1 HDFS setup/cleanup for local mode
    # Use 'cmd /c' to run Hadoop commands since they are executables in the Path
    
    # The hadoop fs command is used for HDFS operations, even in local/standalone mode.
    # We must use proper Windows paths for the Python executables
    hdfs_setup_commands = [
        "hadoop fs -rm -r -f input output",
        "hadoop fs -mkdir -p input",
        f"hadoop fs -put {input_data_path}/* input/"
    ]
    
    for cmd in hdfs_setup_commands:
        subprocess.run(f"cmd /c {cmd}", shell=True, check=True)
        
    print("Data uploaded to simulated HDFS (input/ directory).")

    # 4.2 Find the hadoop-streaming JAR path dynamically
    streaming_jar_pattern = os.path.join(os.environ['HADOOP_HOME'], 'share', 'hadoop', 'tools', 'lib', 'hadoop-streaming-*.jar')
    
    try:
        # Using glob on Windows paths to find the file
        import glob
        streaming_jar = glob.glob(streaming_jar_pattern)[0]
    except IndexError:
        print("Error: Could not find hadoop-streaming JAR file.")
        sys.exit(1)
        
    # Replace backslashes with forward slashes in the path for the command line argument
    streaming_jar_cmd = streaming_jar.replace(os.sep, '/') 

    # 4.3 Construct and run the Hadoop Streaming command
    # Use 'python' explicitly for the mapper/combiner/reducer if it's not the default interpreter
    # Also, we use the local files directly.
    streaming_command = dedent(f"""
        hadoop jar {streaming_jar_cmd} ^
        -input input ^
        -output output ^
        -mapper python mapper.py ^
        -combiner python combiner.py ^
        -reducer python reducer.py ^
        -file mapper.py ^
        -file combiner.py ^
        -file reducer.py
    """)

    print("\nExecuting Streaming Command...")
    # Run the streaming command using cmd /c and the caret (^) for line continuation
    subprocess.run(f"cmd /c {streaming_command.strip()}", shell=True, check=True)
    print("Hadoop MapReduce Job completed successfully.")

    # --- 5. Display Results (Similar to original) ---
    print("\n--- 5. Final Word Count Results ---")
    
    # Cat the output from HDFS
    result = subprocess.run(
        "hadoop fs -cat output/part-00000", 
        shell=True, 
        check=True, 
        capture_output=True, 
        text=True
    )
    print(result.stdout.strip())
    print("-" * 50)

    # Final cleanup
    shutil.rmtree(input_data_path, ignore_errors=True)
    os.remove("mapper.py")
    os.remove("combiner.py")
    os.remove("reducer.py")
    print("Local setup files cleaned up.")


if __name__ == "__main__":
    # Ensure JAVA_HOME is updated before running!
    if "C:\\path\\to\\your\\Java\\JDK" in JAVA_HOME:
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("!!! ERROR: Please update the JAVA_HOME variable in the code!!!")
        print("!!! to your actual Java JDK path on Windows.             !!!")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        sys.exit(1)
        
    setup_and_run_hadoop_job_windows()