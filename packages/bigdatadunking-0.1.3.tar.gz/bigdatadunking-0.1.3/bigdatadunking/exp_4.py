import os
import subprocess
import tarfile
import sys

# --- Configuration ---
HADOOP_VERSION = "3.3.6"
HADOOP_TAR_FILE = f"hadoop-{HADOOP_VERSION}.tar.gz"
HADOOP_DIR = f"hadoop-{HADOOP_VERSION}"
HADOOP_INSTALL_PATH = "/usr/local/hadoop"
HADOOP_DOWNLOAD_URL = f"https://downloads.apache.org/hadoop/common/hadoop-{HADOOP_VERSION}/{HADOOP_TAR_FILE}"
JAVA_HOME = "/usr/lib/jvm/java-8-openjdk-amd64"

INPUT_FILE = "weather_data.txt"
HDFS_INPUT_PATH = "/user/root/input"
HDFS_OUTPUT_PATH = "/user/root/output"

# --- Hadoop Configuration Files (Minimal Configuration for Pseudo-Distributed Mode) ---

# Core-site.xml content (used for fs.defaultFS)
core_site_content = f"""
<configuration>
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://localhost:9000</value>
    </property>
</configuration>
"""

# Hdfs-site.xml content (used for replication factor and namenode/datanode directories)
hdfs_site_content = """
<configuration>
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>file:///usr/local/hadoop/hdfs/namenode</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>file:///usr/local/hadoop/hdfs/datanode</value>
    </property>
</configuration>
"""

# --- Python Mapper and Reducer Scripts ---

mapper_code = f"""#!/usr/bin/env python3
import sys
for line in sys.stdin:
    try:
        line = line.strip()
        datetime, temp = line.split(",")
        date = datetime.split(" ")[0]
        # Output: YYYY-MM-DD\tTemperature
        print(f"{{date}}\\t{{temp}}")
    except:
        continue
"""

reducer_code = f"""#!/usr/bin/env python3
import sys
# Hadoop Streaming ensures input is sorted by key (date)
current_date = None
temps = []
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    
    # Input: YYYY-MM-DD\tTemperature
    try:
        date, temp = line.split("\\t")
        temp = float(temp)
    except ValueError:
        continue  # Skip malformed lines

    if current_date == date:
        temps.append(temp)
    else:
        if current_date:
            # Output max/min for the previous date group
            print(f"{{current_date}}\\tmax={{max(temps)}}\\tmin={{min(temps)}}")
        current_date = date
        temps = [temp]

# Handle the last key group
if current_date:
    print(f"{{current_date}}\\tmax={{max(temps)}}\\tmin={{min(temps)}}")
"""

# Sample weather data
data = f"""2025-09-01 14:00,35
2025-09-01 15:00,33
2025-09-01 16:00,37
2025-09-02 14:00,32
2025-09-02 15:00,34
"""

# --- Utility Functions ---

def run_command(command, check=True):
    """Executes a shell command and prints output."""
    print(f"Executing: {command}")
    try:
        subprocess.run(command, shell=True, check=check, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    except subprocess.CalledProcessError as e:
        print(f"Command failed with exit code {e.returncode}: {command}")
        print(f"Output:\n{e.output}")
        if check:
            sys.exit(1)
            
def setup_hadoop_environment():
    """Installs Hadoop and sets environment variables."""
    if not os.path.exists(HADOOP_INSTALL_PATH):
        print("--- 1. Downloading and Installing Hadoop ---")
        run_command(f"wget {HADOOP_DOWNLOAD_URL}", check=False)
        run_command(f"tar -xvzf {HADOOP_TAR_FILE} > /dev/null")
        run_command(f"mv {HADOOP_DIR} {HADOOP_INSTALL_PATH}")
        print(f"Hadoop {HADOOP_VERSION} installed to {HADOOP_INSTALL_PATH}")

    # Set environment variables for the current process
    os.environ["JAVA_HOME"] = JAVA_HOME
    os.environ["HADOOP_HOME"] = HADOOP_INSTALL_PATH
    os.environ["PATH"] = f"{os.environ['PATH']}:{HADOOP_INSTALL_PATH}/bin:{HADOOP_INSTALL_PATH}/sbin"
    os.environ["HADOOP_CONF_DIR"] = os.path.join(HADOOP_INSTALL_PATH, 'etc', 'hadoop')

    print("--- 2. Configuring Hadoop ---")
    
    # 2.1 Write Configuration files
    conf_dir = os.environ["HADOOP_CONF_DIR"]
    with open(os.path.join(conf_dir, 'core-site.xml'), 'w') as f:
        f.write(core_site_content)
    with open(os.path.join(conf_dir, 'hdfs-site.xml'), 'w') as f:
        f.write(hdfs_site_content)

    # 2.2 Format NameNode and Start Hadoop in Pseudo-Distributed Mode
    if not os.path.exists(os.path.join(HADOOP_INSTALL_PATH, 'hdfs', 'namenode', 'current')):
        print("Formatting NameNode...")
        # Force Python to find the executable from the updated PATH
        run_command("hdfs namenode -format -force -nonInteractive")
    
    print("Starting Hadoop services...")
    # Suppress output for start-dfs.sh to keep logs clean
    run_command("start-dfs.sh", check=False)
    
    print("Verifying Hadoop installation:")
    run_command("hadoop version")
    print("-" * 50)

def create_local_files():
    """Creates mapper.py, reducer.py, and the input data file locally."""
    print("--- 3. Creating Local Scripts and Data ---")
    with open("mapper.py", "w") as f:
        f.write(mapper_code)
    with open("reducer.py", "w") as f:
        f.write(reducer_code)
    with open(INPUT_FILE, "w") as f:
        f.write(data)
    
    # Make scripts executable
    run_command("chmod +x mapper.py reducer.py", check=False)
    print("Local scripts (mapper.py, reducer.py) and data created.")
    print("-" * 50)

def run_streaming_job():
    """Executes the MapReduce streaming job."""
    print("--- 4. Running MapReduce Streaming Job ---")
    
    # Ensure Hadoop Streaming JAR path is correct (use wildcard)
    streaming_jar = os.path.join(HADOOP_INSTALL_PATH, 'share', 'hadoop', 'tools', 'lib', 'hadoop-streaming-*.jar')
    
    # 4.1 HDFS setup
    run_command(f"hdfs dfs -mkdir -p {HDFS_INPUT_PATH}", check=False)
    run_command(f"hdfs dfs -put -f {INPUT_FILE} {HDFS_INPUT_PATH}/", check=False)
    run_command(f"hdfs dfs -rm -r -f {HDFS_OUTPUT_PATH}", check=False)
    
    # 4.2 Execute the Streaming Job
    command = (
        f"hadoop jar {streaming_jar} "
        f"-input {HDFS_INPUT_PATH}/{INPUT_FILE} "
        f"-output {HDFS_OUTPUT_PATH} "
        f"-mapper ./mapper.py "  # Python scripts use the relative path inside the distributed cache
        f"-reducer ./reducer.py "
        f"-file mapper.py "     # Distribute mapper script to TaskTrackers
        f"-file reducer.py"     # Distribute reducer script to TaskTrackers
    )
    run_command(command)
    
    # 4.3 View results
    print("\n--- 5. Final Results (Min/Max Temperature by Date) ---")
    run_command(f"hdfs dfs -cat {HDFS_OUTPUT_PATH}/part-00000")
    print("-" * 50)

def cleanup():
    """Stops Hadoop services and cleans up local files."""
    print("--- 6. Cleanup ---")
    run_command("stop-dfs.sh", check=False)
    run_command(f"rm -f {INPUT_FILE} mapper.py reducer.py {HADOOP_TAR_FILE}", check=False)
    
# --- Main Execution ---

if __name__ == "__main__":
    
    # Check for Java installation first (required for apt install and Hadoop)
    run_command("apt-get update -qq", check=False)
    run_command("apt-get install openjdk-8-jdk-headless -qq > /dev/null", check=False)
    
    if 'T4' in os.environ.get('GPU_TYPE', ''):
        print("Note: Detected Colab/GPU environment. Setup might differ on standard Linux VMs.")

    setup_hadoop_environment()
    create_local_files()
    run_streaming_job()
    # cleanup() # Uncomment this line if you want to stop Hadoop services after run

# Prerequisites
# Linux Environment: (e.g., Ubuntu, Debian, CentOS).

# Python 3: Installed and accessible via python3.

# Basic Tools: wget, tar, and administrative access (sudo or a compatible environment like Colab/Docker where these actions are permitted).

# Step 1: Save the Code
# Save the Python script above into a file named hadoop_streaming_job.py.

# Step 2: Ensure Java 8 is Installable
# The script installs OpenJDK 8 Headless which is compatible with Hadoop 3.3.6.

# Step 3: Run the Script
# Execute the script from your terminal:

# Bash

# python3 hadoop_streaming_job.py