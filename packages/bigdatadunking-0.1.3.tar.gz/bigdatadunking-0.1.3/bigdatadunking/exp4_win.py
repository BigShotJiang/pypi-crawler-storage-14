import os
import subprocess
import shutil
import sys
import platform
from textwrap import dedent

# --- Configuration ---
HADOOP_VERSION = "3.3.6"
HADOOP_TAR_FILE = f"hadoop-{HADOOP_VERSION}.tar.gz"
HADOOP_DIR = f"hadoop-{HADOOP_VERSION}"
HADOOP_INSTALL_PATH = os.path.abspath(HADOOP_DIR) # Local installation directory
HADOOP_DOWNLOAD_URL =  f"https://downloads.apache.org/hadoop/common/hadoop-3.4.2/hadoop-3.4.2.tar.gz"

# IMPORTANT: You MUST update this path to your actual Windows JDK location.
# Example: "C:\\Program Files\\Java\\jdk1.8.0_371" or "C:\\Program Files\\Java\\jdk-11"
JAVA_HOME = "C:\\path\\to\\your\\Java\\JDK" # <--- **UPDATE THIS PATH**

INPUT_FILE = "weather_data.txt"
HDFS_INPUT_PATH = "/user/root/input"
HDFS_OUTPUT_PATH = "/user/root/output"

# --- Hadoop Configuration Files (Minimal Configuration for Pseudo-Distributed Mode) ---

# Replace forward slashes with double backslashes for Python string formatting
HADOOP_INSTALL_PATH_XML = HADOOP_INSTALL_PATH.replace("\\", "/")

core_site_content = f"""
<configuration>
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://localhost:9000</value>
    </property>
</configuration>
"""

hdfs_site_content = f"""
<configuration>
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>file:///{HADOOP_INSTALL_PATH_XML}/hdfs/namenode</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>file:///{HADOOP_INSTALL_PATH_XML}/hdfs/datanode</value>
    </property>
</configuration>
"""

# --- Python Mapper and Reducer Scripts ---

mapper_code = dedent("""
#!/usr/bin/env python3
import sys
for line in sys.stdin:
    try:
        line = line.strip()
        datetime, temp = line.split(",")
        date = datetime.split(" ")[0]
        # Output: YYYY-MM-DD\\tTemperature
        print(f"{date}\\t{temp}")
    except:
        continue
""")

reducer_code = dedent("""
#!/usr/bin/env python3
import sys
# Hadoop Streaming ensures input is sorted by key (date)
current_date = None
temps = []
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    
    # Input: YYYY-MM-DD\\tTemperature
    try:
        date, temp = line.split("\\t")
        temp = float(temp)
    except ValueError:
        continue  # Skip malformed lines

    if current_date == date:
        temps.append(temp)
    else:
        if current_date:
            # Output max/min for the previous date group
            print(f"{current_date}\\tmax={max(temps)}\\tmin={min(temps)}")
        current_date = date
        temps = [temp]

# Handle the last key group
if current_date:
    print(f"{current_date}\\tmax={max(temps)}\\tmin={min(temps)}")
""")

# Sample weather data
data = dedent("""
2025-09-01 14:00,35
2025-09-01 15:00,33
2025-09-01 16:00,37
2025-09-02 14:00,32
2025-09-02 15:00,34
""")

# --- Utility Functions ---

def run_command(command, description, check=True):
    """Executes a command using the Windows command interpreter (cmd)."""
    print(f"\n--- {description} ---")
    try:
        # Using cmd /c for standard Windows commands and batch file execution
        subprocess.run(
            f"cmd /c {command}", 
            shell=True, 
            check=check, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, 
            text=True
        )
        print("Success.")
    except subprocess.CalledProcessError as e:
        print(f"Command failed with exit code {e.returncode}: {command}")
        print(f"Output:\n{e.output}")
        if check:
            sys.exit(1)

def run_powershell_command(command, description):
    """Executes a command using PowerShell."""
    print(f"\n--- {description} ---")
    try:
        # Use subprocess.run to invoke PowerShell
        subprocess.run(
            f"powershell.exe -Command \"{command}\"", 
            shell=True, 
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        print("Success.")
    except subprocess.CalledProcessError as e:
        print(f"Error during {description}:\n{e.stderr}")
        sys.exit(1)
    except FileNotFoundError:
        print("Error: PowerShell not found.")
        sys.exit(1)
        
def setup_hadoop_environment():
    """Installs Hadoop and sets environment variables."""
    
    if "C:\\path\\to\\your\\Java\\JDK" in JAVA_HOME:
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("!!! ERROR: Please update the JAVA_HOME variable in the code!!!")
        print("!!! to your actual Java JDK path on Windows.             !!!")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        sys.exit(1)

    if not os.path.exists(HADOOP_INSTALL_PATH):
        # 1. Download and Extract Hadoop (using PowerShell's Invoke-WebRequest and tar)
        shutil.rmtree(HADOOP_DIR, ignore_errors=True)
        
        download_url = HADOOP_DOWNLOAD_URL
        download_command = f"curl -Uri '{download_url}' -OutFile '{HADOOP_TAR_FILE}'"
        run_powershell_command(download_command, f"Downloading Hadoop {HADOOP_VERSION}")
        
        extraction_command = f"tar -xf {HADOOP_TAR_FILE}; Remove-Item {HADOOP_TAR_FILE}"
        run_powershell_command(extraction_command, "Extracting and cleaning up Hadoop tar file")

        print(f"Hadoop {HADOOP_VERSION} installed to {HADOOP_INSTALL_PATH}")
    else:
        print(f"Hadoop found at {HADOOP_INSTALL_PATH}. Skipping download.")


    # Set environment variables for the current process
    os.environ["JAVA_HOME"] = JAVA_HOME
    os.environ["HADOOP_HOME"] = HADOOP_INSTALL_PATH
    
    # Update PATH to include Hadoop binaries
    os.environ["Path"] = f"{HADOOP_INSTALL_PATH}\\bin;{os.environ.get('Path', '')}"
    
    os.environ["HADOOP_CONF_DIR"] = os.path.join(HADOOP_INSTALL_PATH, 'etc', 'hadoop')

    run_command("hadoop version", "Verifying Hadoop installation")
    
    print("\n--- Configuring Hadoop ---")
    
    # 2.1 Write Configuration files
    conf_dir = os.environ["HADOOP_CONF_DIR"]
    with open(os.path.join(conf_dir, 'core-site.xml'), 'w') as f:
        f.write(core_site_content)
    with open(os.path.join(conf_dir, 'hdfs-site.xml'), 'w') as f:
        f.write(hdfs_site_content)
        
    # 2.2 Configure JAVA_HOME in hadoop-env.cmd
    hadoop_env_path = os.path.join(conf_dir, 'hadoop-env.cmd')
    try:
        with open(hadoop_env_path, 'a') as f:
            f.write(f"\nset JAVA_HOME={JAVA_HOME}\n")
        print(f"JAVA_HOME set in {hadoop_env_path}")
    except Exception as e:
        print(f"Warning: Could not update hadoop-env.cmd: {e}")

    # 2.3 Format NameNode and Start Hadoop
    if not os.path.exists(os.path.join(HADOOP_INSTALL_PATH, 'hdfs', 'namenode', 'current')):
        run_command("hdfs namenode -format -force -nonInteractive", "Formatting NameNode")
    
    # Start HDFS (using Windows specific start-dfs.cmd)
    run_command("start-dfs.cmd", "Starting Hadoop DFS Services (Requires winutils.exe)", check=False)
    
    print("-" * 50)

def create_local_files():
    """Creates mapper.py, reducer.py, and the input data file locally."""
    print("--- Creating Local Scripts and Data ---")
    with open("mapper.py", "w") as f:
        f.write(mapper_code)
    with open("reducer.py", "w") as f:
        f.write(reducer_code)
    with open(INPUT_FILE, "w") as f:
        f.write(data)
    
    print("Local scripts (mapper.py, reducer.py) and data created.")
    print("-" * 50)

def run_streaming_job():
    """Executes the MapReduce streaming job."""
    print("--- Running MapReduce Streaming Job ---")
    
    # Ensure Hadoop Streaming JAR path is correct (use wildcard)
    streaming_jar_pattern = os.path.join(HADOOP_INSTALL_PATH, 'share', 'hadoop', 'tools', 'lib', 'hadoop-streaming-*.jar')
    
    try:
        import glob
        streaming_jar = glob.glob(streaming_jar_pattern)[0]
    except IndexError:
        print("Error: Could not find hadoop-streaming JAR file.")
        sys.exit(1)
        
    streaming_jar_cmd = streaming_jar.replace(os.sep, '/') 

    # 4.1 HDFS setup
    run_command(f"hdfs dfs -mkdir -p {HDFS_INPUT_PATH}", "Creating HDFS input directory", check=False)
    run_command(f"hdfs dfs -put -f {INPUT_FILE} {HDFS_INPUT_PATH}/", "Uploading data to HDFS", check=False)
    run_command(f"hdfs dfs -rm -r -f {HDFS_OUTPUT_PATH}", "Cleaning up old HDFS output directory", check=False)
    
    # 4.2 Execute the Streaming Job (using caret ^ for line continuation in CMD)
    command = dedent(f"""
        hadoop jar {streaming_jar_cmd} ^
        -input {HDFS_INPUT_PATH}/{INPUT_FILE} ^
        -output {HDFS_OUTPUT_PATH} ^
        -mapper python mapper.py ^
        -reducer python reducer.py ^
        -file mapper.py ^
        -file reducer.py
    """).strip()
    
    run_command(command, "Executing Hadoop Streaming Job")
    
    # 4.3 View results
    run_command(f"hdfs dfs -cat {HDFS_OUTPUT_PATH}/part-00000", "Final Results (Min/Max Temperature by Date)")
    print("-" * 50)

def cleanup():
    """Stops Hadoop services and cleans up local files."""
    print("--- Cleanup ---")
    run_command("stop-dfs.cmd", "Stopping Hadoop DFS Services", check=False)
    
    # Cleanup local files
    try:
        os.remove(INPUT_FILE)
        os.remove("mapper.py")
        os.remove("reducer.py")
        shutil.rmtree(HADOOP_INSTALL_PATH, ignore_errors=True)
        print("Local data, scripts, and Hadoop installation folder cleaned up.")
    except Exception as e:
        print(f"Warning: Could not clean up all files. {e}")
    
# --- Main Execution ---

if __name__ == "__main__":
    
    setup_hadoop_environment()
    create_local_files()
    run_streaming_job()
    # cleanup() # Uncomment this line if you want to stop Hadoop services after run