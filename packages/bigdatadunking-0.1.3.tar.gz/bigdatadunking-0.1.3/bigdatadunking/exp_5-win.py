import os
import subprocess
import tarfile
import sys
import shutil
import platform
from textwrap import dedent

# --- Configuration for Windows ---
PIG_VERSION = "0.17.0"
PIG_TAR_FILE = f"pig-{PIG_VERSION}.tar.gz"
PIG_DIR = f"pig-{PIG_VERSION}"
# Use a temporary local folder for Pig installation
PIG_PATH = os.path.abspath(PIG_DIR) 
PIG_DOWNLOAD_URL = f"https://archive.apache.org/dist/pig/pig-{PIG_VERSION}/{PIG_TAR_FILE}"

PIG_SCRIPT_FILE = "program.pig"
STUDENTS_FILE = "students.csv"
DEPARTMENTS_FILE = "departments.csv"

# IMPORTANT: You MUST update this path to your actual Windows JDK location.
# Example: "C:\\Program Files\\Java\\jdk1.8.0_371" or "C:\\Program Files\\Java\\jdk-11"
JAVA_HOME = "C:\\Program Files\\Java\\jdk-16.0.1" # <--- UPDATE THIS PATH

# --- Data and Script Content ---
students_data = """1,Ravi,CSE,85
2,Anita,IT,55
3,John,CSE,72
4,Kiran,ECE,67
5,Meera,IT,90
"""

departments_data = """CSE,Dr.Sharma
IT,Dr.Verma
ECE,Dr.Rao
"""

pig_script = r"""
-- Load student and department data
students = LOAD 'students.csv' USING PigStorage(',')
           AS (id:int, name:chararray, dept:chararray, marks:int);

departments = LOAD 'departments.csv' USING PigStorage(',')
              AS (dept:chararray, hod:chararray);

-- Filter: students with marks > 60
good_students = FILTER students BY marks > 60;

-- Project: select only name, dept, marks
projected = FOREACH good_students GENERATE name, dept, marks;

-- Group: by department
grouped = GROUP projected BY dept;

-- Sort: order students by marks descending
sorted = ORDER projected BY marks DESC;

-- Join: combine with department HOD info
joined = JOIN projected BY dept, departments BY dept;

-- Dump results
DUMP sorted;
DUMP grouped;
DUMP joined;
"""

def run_powershell_command(command, description):
    """Executes a command using PowerShell."""
    print(f"Executing: {description}")
    try:
        # Use subprocess.run to invoke PowerShell and execute the command
        subprocess.run(
            f"powershell.exe -Command \"{command}\"", 
            shell=True, 
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        print("Success.")
    except subprocess.CalledProcessError as e:
        print(f"Error during {description}:\n{e.stderr}")
        sys.exit(1)
    except FileNotFoundError:
        print("Error: PowerShell not found. Ensure it is in your system PATH.")
        sys.exit(1)


def check_java_installed():
    """Checks for Java installation and configures JAVA_HOME environment variable."""
    if "C:\\path\\to\\your\\Java\\JDK" in JAVA_HOME:
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("!!! ERROR: Please update the JAVA_HOME variable in the code!!!")
        print("!!! to your actual Java JDK path on Windows.             !!!")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        sys.exit(1)
        
    try:
        # Check if the java executable is available
        java_version_check = subprocess.run(["java", "-version"], check=True, capture_output=True, text=True)
        print("Java is installed and available in PATH.")
        
        # Set environment variables for Pig execution
        os.environ['JAVA_HOME'] = JAVA_HOME
        
        # Add Java bin to the PATH for the subprocess
        java_bin_path = os.path.join(JAVA_HOME, 'bin')
        os.environ['PATH'] = java_bin_path + os.pathsep + os.environ.get('PATH', '')
        
    except subprocess.CalledProcessError:
        print("Java is installed but failed to run. Check your PATH.")
        sys.exit(1)
    except FileNotFoundError:
        print("Error: Java executable not found. Please ensure Java 8 or 11 is installed and in your PATH.")
        sys.exit(1)
    print(f"Set JAVA_HOME to: {os.environ['JAVA_HOME']}")


def setup_pig_and_run_script():
    """Manages the entire Pig setup, data creation, and execution process for Windows."""
    
    check_java_installed()

    print(f"--- 1. Setting up Apache Pig {PIG_VERSION} ---")

    # 1. Download and Extract Pig
    if not os.path.exists(PIG_PATH):
        
        # Clean up existing directories just in case
        shutil.rmtree(PIG_DIR, ignore_errors=True) 
        
        # Download (using PowerShell's Invoke-WebRequest/curl)
        print(f"Downloading {PIG_TAR_FILE}...")
        download_command = f"curl -Uri '{PIG_DOWNLOAD_URL}' -OutFile '{PIG_TAR_FILE}'"
        run_powershell_command(download_command, f"Download Pig {PIG_VERSION}")
        
        # Extract the .tar.gz file using Python's cross-platform tarfile module
        try:
            print(f"Extracting {PIG_TAR_FILE}...")
            with tarfile.open(PIG_TAR_FILE, "r:gz") as tar:
                # Extracts to pig-0.17.0 folder
                tar.extractall()
            
            # The extracted folder is PIG_DIR, which is now PIG_PATH
            if not os.path.exists(PIG_PATH):
                 os.rename(PIG_DIR, PIG_PATH)
            
            os.remove(PIG_TAR_FILE) # Cleanup tar file
            print(f"Pig installed to {PIG_PATH}")
            
        except tarfile.TarError as e:
            print(f"Error extracting tar file. Ensure the download was complete. Error: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"Error during Pig extraction/move: {e}")
            sys.exit(1)
    else:
        print(f"Pig found at {PIG_PATH}. Skipping download and extraction.")

    # 2. Set PIG_HOME environment variable
    os.environ['PIG_HOME'] = PIG_PATH
    pig_bin_path = os.path.join(os.environ['PIG_HOME'], 'bin')
    os.environ['PATH'] += os.pathsep + pig_bin_path
    
    print(f"PIG_HOME set to: {os.environ['PIG_HOME']}")
    print("-" * 50)

    print("--- 2. Creating Input Data Files ---")
    
    # Create students.csv
    with open(STUDENTS_FILE, "w") as f:
        f.write(students_data)
        
    # Create departments.csv
    with open(DEPARTMENTS_FILE, "w") as f:
        f.write(departments_data)
    
    print(f"Created {STUDENTS_FILE} and {DEPARTMENTS_FILE} in current directory.")
    print("-" * 50)

    print("--- 3. Creating Pig Latin Script ---")
    
    # Create program.pig script
    with open(PIG_SCRIPT_FILE, "w") as f:
        f.write(pig_script)
    
    print(f"Created Pig script: {PIG_SCRIPT_FILE}")
    print("-" * 50)

    print("--- 4. Executing Pig Script in Local Mode ---")

    try:
        # On Windows, the Pig executable is pig.cmd
        pig_executable = os.path.join(os.environ['PIG_HOME'], 'bin', 'pig.cmd')
        
        # We must use 'cmd /c' to properly execute batch files like pig.cmd
        command = f"\"{pig_executable}\" -x local {PIG_SCRIPT_FILE}"

        # Execute the Pig script
        print(f"Running command: {command}")
        result = subprocess.run(
            command,
            shell=True, # Important for pig.cmd execution
            check=True,
            capture_output=True,
            text=True
        )
        
        # --- Parse and Print Results ---
        output_lines = result.stdout.splitlines()
        
        print("\n** Pig Script Output: DUMP Results **")
        
        results = {"sorted": [], "grouped": [], "joined": []}
        # Simple heuristic to capture DUMP output, ignoring logging chatter
        
        capture_mode = False
        
        for line in output_lines:
            # Start of DUMP output is usually marked by the tuple data structure
            if line.strip().startswith('('):
                if not capture_mode:
                    # Heuristics to guess which DUMP we are seeing
                    if "(Meera,IT,90)" in line:
                         current_dump_key = "sorted"
                    elif "(IT,{(Meera,IT,90),(John,CSE,72),(Kiran,ECE,67)})" in line:
                         current_dump_key = "grouped"
                    elif "(Meera,IT,90,IT,Dr.Verma)" in line:
                         current_dump_key = "joined"
                    else:
                         # Skip lines that are tuples but don't match the expected output structure
                         continue
                         
                    capture_mode = True
                
                if capture_mode:
                    results[current_dump_key].append(line.strip())
            else:
                capture_mode = False # Stop capturing after data lines end

        print("\n** 1. DUMP sorted (Students > 60, sorted by Marks DESC) **")
        print('\n'.join(results["sorted"]))
                
        print("\n** 2. DUMP grouped (Good Students grouped by Department) **")
        print('\n'.join(results["grouped"]))
        
        print("\n** 3. DUMP joined (Good Students joined with HOD) **")
        print('\n'.join(results["joined"]))
        
        print("\n" + "-" * 50)
        print("Pig Execution Summary:")
        # Print Pig success message if available in stdout
        for line in output_lines:
            if "Pig script completed in" in line or "Success!" in line or "finished running" in line:
                 print(line)
            
    except subprocess.CalledProcessError as e:
        print(f"Error during Pig execution. Check Pig log files for details.")
        print(f"Stderr (first 10 lines): \n{e.stderr.splitlines()[:10]}")
    except FileNotFoundError:
        print("Error: The 'pig.cmd' executable was not found. Check PIG_HOME path.")
        sys.exit(1)
        
    finally:
        # Cleanup local files
        try:
            os.remove(STUDENTS_FILE)
            os.remove(DEPARTMENTS_FILE)
            os.remove(PIG_SCRIPT_FILE)
            shutil.rmtree(PIG_PATH, ignore_errors=True)
            print("\nLocal data and Pig installation folder cleaned up.")
        except Exception as e:
            print(f"Warning: Could not clean up all files. {e}")


if __name__ == "__main__":
    setup_pig_and_run_script()