import seabreeze  # import the seabreeze package to communicate with the spectrometer
seabreeze.use("cseabreeze")  # specify to use the cseabreeze extension
from seabreeze.spectrometers import Spectrometer


class OceanInsight:
    """Ocean Insight spectrometer plugin for ONE-PIX (seabreeze-based)."""

    def __init__(self, integration_time_ms):
        self.integration_time_ms = integration_time_ms
        self.spec = []
        self.DeviceName = ""

    def spec_open(self):
        """Initialise the connection with the spectrometer."""
        try:
            self.spec = Spectrometer.from_first_available()
            self.spec.close()
            self.spec.open()
            self.DeviceName = str(self.spec.serial_number)
        except seabreeze.cseabreeze.SeaBreezeError as e:
            raise Exception(f"No Ocean Insight device was detected: {e}")

    def set_integration_time(self):
        """Set integration time in milliseconds."""
        self.integration_time_ms = int(self.integration_time_ms)
        if self.integration_time_ms * 1e3 < self.spec.integration_time_micros_limits[0]:
            raise Exception(
                "Spectrometer saturation at lower integration time. "
                "Adapt your acquisition configuration to reduce optical intensity."
            )
        else:
            self.spec.integration_time_micros(self.integration_time_ms * 1e3)

    def get_wavelengths(self):
        """Return the sampled wavelengths by the spectrometer."""
        return self.spec.wavelengths()

    def get_intensities(self):
        """Measure a spectrum."""
        return self.spec.intensities()

    def spec_close(self):
        """End communication with the spectrometer."""
        self.spec.close()
