import json
import os
from typing import Any, Iterable, Mapping, MutableMapping, Sequence, TypedDict

import requests as _requests

from ._utils import (
    LEGACY_MOUNT_ROOT,
    MOUNT_ROOT,
    TOKEN_ENV,
    _api_request,
    _api_url,
    _default_provenance,
    _ensure_mapping,
    _is_sequence,
    _prepare_agent_inputs,
    _record_mutation,
    _upload_agent_files,
    _upload_agent_run_file,
    _upload_document,
    _upload_session_file,
    open_file,
    resolve_path,
    to_filerefs,
    get_access_token,
    get_google_access_token,
    log_timed,
    LumeraAPIError,
    RecordNotUniqueError,
)

# Expose requests module for backward-compatible monkeypatching in tests.
requests = _requests


# ---------------------------------------------------------------------------
# Unified FileRef helpers
# ---------------------------------------------------------------------------


class FileRef(TypedDict, total=False):
    scope: str
    id: str
    name: str
    path: str
    run_path: str
    object_name: str
    mime: str
    size: int


class CollectionField(TypedDict, total=False):
    id: str
    name: str
    type: str
    system: bool
    required: bool
    presentable: bool
    hidden: bool
    options: dict[str, Any]


class HookReplayResult(TypedDict, total=False):
    hook_id: str
    hook_name: str
    status: str
    error: str
    event_log_id: str
    replay_id: str

_UNSET = object()


def list_collections() -> dict[str, Any]:
    """Return all PocketBase collections visible to the current tenant."""

    return _api_request("GET", "collections")


def get_collection(collection_id_or_name: str) -> dict[str, Any]:
    """Retrieve a single PocketBase collection by name or id."""

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")
    return _api_request("GET", f"collections/{collection_id_or_name}")


def create_collection(
    name: str,
    *,
    collection_type: str = "base",
    schema: Iterable[CollectionField] | None = None,
    indexes: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Create a new PocketBase collection and return the server payload."""

    if not name or not name.strip():
        raise ValueError("name is required")

    payload: dict[str, Any] = {"name": name.strip()}
    if collection_type:
        payload["type"] = collection_type
    if schema is not None:
        payload["schema"] = [dict(field) for field in schema]
    if indexes is not None:
        payload["indexes"] = list(indexes)

    return _api_request("POST", "collections", json_body=payload)


def update_collection(
    collection_id_or_name: str,
    *,
    name: str | None | object = _UNSET,
    collection_type: str | None | object = _UNSET,
    schema: Iterable[CollectionField] | object = _UNSET,
    indexes: Iterable[str] | object = _UNSET,
) -> dict[str, Any]:
    """Update a PocketBase collection."""

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")

    payload: dict[str, Any] = {}

    if name is not _UNSET:
        if name is None or not str(name).strip():
            raise ValueError("name cannot be empty")
        payload["name"] = str(name).strip()

    if collection_type is not _UNSET:
        payload["type"] = collection_type

    if schema is not _UNSET:
        if schema is None:
            raise ValueError("schema cannot be None; provide an iterable of fields")
        payload["schema"] = [dict(field) for field in schema]

    if indexes is not _UNSET:
        payload["indexes"] = list(indexes) if indexes is not None else []

    if not payload:
        raise ValueError("no fields provided to update")

    return _api_request("PATCH", f"collections/{collection_id_or_name}", json_body=payload)


def delete_collection(collection_id_or_name: str) -> None:
    """Delete a PocketBase collection by name or id."""

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")
    _api_request("DELETE", f"collections/{collection_id_or_name}")


def list_records(
    collection_id_or_name: str,
    *,
    page: int | None = None,
    per_page: int | None = None,
    limit: int | None = None,
    offset: int | None = None,
    sort: str | None = None,
    filter: Mapping[str, Any] | Sequence[Any] | None = None,
) -> dict[str, Any]:
    """List records for the given PocketBase collection.

    Args:
        collection_id_or_name: Collection name or ID. Required.
        page: 1-based page index for paginated queries (mutually exclusive
            with ``offset``/``limit``).
        per_page: Page size (max 200). Only used when ``page`` is provided.
        limit: Alternative to ``per_page`` for cursor-style queries.
        offset: Starting offset for cursor-style queries.
        sort: Optional sort expression (e.g. ``"-created"``).
        filter: Accepts either a raw PocketBase filter string (e.g.
            ``"status = 'ok'"``) or a structured filter encoded as a mapping/
            sequence. Structured filters mirror the Page Builder helpers, e.g.:

            * ``{"and": [{"status": {"eq": "active"}}, {"owner_id": user_id}]}``
            * ``{"or": [{"created": {"gt": "2024-01-01"}}, {"stage": "new"}]}``

            The SDK JSON-encodes structured filters so the API can build
            tenant-aware expressions automatically.

    Returns:
        The raw response from ``GET /collections/{id}/records`` including
        ``items``, ``page``/``perPage`` metadata, etc.
    """

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")

    params: dict[str, Any] = {}
    if page is not None:
        params["page"] = page
    if per_page is not None:
        params["perPage"] = per_page
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    if sort is not None:
        params["sort"] = sort
    if filter is not None:
        params["filter"] = json.dumps(filter)

    path = f"collections/{collection_id_or_name}/records"
    return _api_request("GET", path, params=params or None)


def query_sql(
    sql: str,
    *,
    params: Mapping[str, Any] | None = None,
    args: Sequence[Any] | None = None,
) -> dict[str, Any]:
    """Execute a read-only PocketBase SQL query via ``POST /pb/sql``.

    Args:
        sql: The SQL statement to execute. Must be a SELECT/read-only
            query; write operations are rejected by the API.
        params: Optional dict of named parameters referenced in the SQL via
            ``{{param}}`` placeholders. Mutually exclusive with ``args``.
        args: Optional sequence of positional parameters for ``?``
            placeholders. Mutually exclusive with ``params``.

    Returns:
        The JSON response from ``/pb/sql`` including ``columns`` and
        ``rows`` (when applicable), ``rowsAffected``/``lastInsertId`` (for
        compatible statements), and ``durationMs``.
    """

    sql_text = (sql or "").strip()
    if not sql_text:
        raise ValueError("sql is required")
    if params and args:
        raise ValueError("provide either params or args, not both")

    payload: dict[str, Any] = {"sql": sql_text}
    if params is not None:
        if not isinstance(params, Mapping):
            raise TypeError("params must be a mapping")
        payload["params"] = dict(params)
    if args is not None:
        if isinstance(args, (str, bytes)):
            raise TypeError("args must be a sequence of values, not a string")
        payload["args"] = list(args)

    response = _api_request("POST", "pb/sql", json_body=payload)
    if isinstance(response, MutableMapping):
        return dict(response)
    raise RuntimeError("unexpected response payload")


def get_record(collection_id_or_name: str, record_id: str) -> dict[str, Any]:
    """Retrieve a single record by id."""

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")
    if not record_id:
        raise ValueError("record_id is required")

    path = f"collections/{collection_id_or_name}/records/{record_id}"
    return _api_request("GET", path)


def get_record_by_external_id(collection_id_or_name: str, external_id: str) -> dict[str, Any]:
    """Retrieve a record by its unique external_id."""

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")
    if not external_id:
        raise ValueError("external_id is required")

    response = list_records(
        collection_id_or_name,
        per_page=1,
        filter={"external_id": external_id},
    )
    items = response.get("items") if isinstance(response, dict) else None
    if not items:
        url = _api_url(f"collections/{collection_id_or_name}/records")
        raise LumeraAPIError(404, "record not found", url=url, payload=None)
    first = items[0]
    if not isinstance(first, dict):
        raise RuntimeError("unexpected response payload")
    return first


def run_agent(
    agent_id: str,
    *,
    inputs: Mapping[str, Any] | str | None = None,
    files: Mapping[str, str | os.PathLike[str] | Sequence[str | os.PathLike[str]]] | None = None,
    status: str | None = None,
    outputs: Mapping[str, Any] | str | None = None,
    error: str | None = None,
    provenance: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Create an agent run and optionally upload files for file inputs."""

    agent_id = agent_id.strip()
    if not agent_id:
        raise ValueError("agent_id is required")

    run_id: str | None = None

    prepared_inputs = _prepare_agent_inputs(inputs) or {}

    file_map = files or {}
    run_id, upload_descriptors = _upload_agent_files(
        run_id, file_map, api_request=_api_request
    )

    final_inputs = json.loads(json.dumps(prepared_inputs)) if prepared_inputs else {}
    for key, descriptors in upload_descriptors.items():
        if len(descriptors) == 1 and not _is_sequence(file_map.get(key)):
            final_inputs[key] = descriptors[0]
        else:
            final_inputs[key] = descriptors

    cleaned_status = status.strip() if isinstance(status, str) else ""
    payload: dict[str, Any] = {
        "agent_id": agent_id,
        "inputs": json.dumps(final_inputs),
        "status": cleaned_status or "queued",
    }
    if run_id:
        payload["id"] = run_id
    if error is not None:
        payload["error"] = error
    payload["lm_provenance"] = _ensure_mapping(
        provenance, name="provenance"
    ) or _default_provenance(agent_id, run_id)

    run = _api_request("POST", "agent-runs", json_body=payload)
    if not isinstance(run, dict):
        raise RuntimeError("unexpected response payload")
    return run


def _prepare_agent_inputs(
    inputs: Mapping[str, Any] | str | None,
) -> dict[str, Any] | None:
    if inputs is None:
        return None
    if isinstance(inputs, str):
        inputs = inputs.strip()
        if not inputs:
            return {}
        try:
            parsed = json.loads(inputs)
        except json.JSONDecodeError as exc:
            raise ValueError("inputs must be JSON-serialisable") from exc
        if not isinstance(parsed, dict):
            raise TypeError("inputs JSON must deserialize to an object")
        return parsed

    # Mapping path – normalise via JSON roundtrip to guarantee compatibility
    try:
        serialised = json.dumps(inputs)
        parsed = json.loads(serialised)
    except (TypeError, ValueError) as exc:
        raise ValueError("inputs must be JSON-serialisable") from exc
    if not isinstance(parsed, dict):
        raise TypeError("inputs mapping must serialize to a JSON object")
    return parsed


def create_record(
    collection_id_or_name: str,
    payload: Mapping[str, Any] | None = None,
    *,
    files: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a record in the specified collection."""

    return _record_mutation(
        "POST", collection_id_or_name, payload, files=files, api_request=_api_request
    )


def update_record(
    collection_id_or_name: str,
    record_id: str,
    payload: Mapping[str, Any] | None = None,
    *,
    files: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Update an existing record."""

    return _record_mutation(
        "PATCH",
        collection_id_or_name,
        payload,
        record_id=record_id,
        files=files,
        api_request=_api_request,
    )


def delete_record(collection_id_or_name: str, record_id: str) -> None:
    """Delete a record from the specified collection."""

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")
    if not record_id:
        raise ValueError("record_id is required")

    path = f"collections/{collection_id_or_name}/records/{record_id}"
    _api_request("DELETE", path)


def replay_hook(
    collection_id_or_name: str,
    event: str,
    record_id: str,
    *,
    hook_ids: Sequence[str] | None = None,
    original_event_id: str | None = None,
) -> list[HookReplayResult]:
    """Trigger PocketBase hooks for a record and return execution results."""

    collection = collection_id_or_name.strip()
    hook_event = event.strip()
    record = record_id.strip()
    if not collection:
        raise ValueError("collection_id_or_name is required")
    if not hook_event:
        raise ValueError("event is required")
    if not record:
        raise ValueError("record_id is required")

    payload: dict[str, Any] = {
        "collection": collection,
        "event": hook_event,
        "record_id": record,
    }

    if hook_ids:
        trimmed = [value.strip() for value in hook_ids if isinstance(value, str) and value.strip()]
        if trimmed:
            payload["hook_ids"] = trimmed

    if original_event_id and original_event_id.strip():
        payload["original_event_id"] = original_event_id.strip()

    response = _api_request("POST", "hooks/replay", json_body=payload)
    if not isinstance(response, Mapping):
        return []

    raw_results = response.get("results")
    if not isinstance(raw_results, list):
        return []

    results: list[HookReplayResult] = []
    for item in raw_results:
        if not isinstance(item, Mapping):
            continue
        result: HookReplayResult = {}
        for key in (
            "hook_id",
            "hook_name",
            "status",
            "error",
            "event_log_id",
            "replay_id",
        ):
            value = item.get(key)
            if isinstance(value, str):
                result[key] = value
        results.append(result)
    return results


def claim_locks(
    *,
    job_type: str,
    collection: str,
    record_ids: Sequence[str],
    job_id: str | None = None,
    claimed_by: str | None = None,
    ttl_seconds: int | None = None,
    provenance: Mapping[str, Any] | None = None,
) -> Mapping[str, Any]:
    """Claim one or more records (or logical resources) in ``lm_locks``.

    Args:
        job_type: Logical workflow name (e.g. ``exports.ar``). Required.
        collection: Namespace for the resource family. This is usually a
            Lumera collection but it can be any identifier (e.g.
            ``"cron:billing"``) as long as the combination of
            ``collection`` + ``record_id`` is stable.
        record_ids: Iterable of record/resource identifiers to lease. Each
            entry is trimmed and empty values are ignored.
        job_id: Optional run identifier. When supplied, releases and
            reclaims can target the locks owned by this specific run without
            disturbing other workers using the same ``job_type``.
        claimed_by: Optional worker identifier recorded in the lock row.
        ttl_seconds: Optional lease duration; defaults to the server TTL
            (15 minutes) when omitted or non-positive.
        provenance: Optional structured payload describing the actor/run. If
            omitted we fall back to :func:`_default_provenance` using the
            derived ``claimed_by`` and ``job_id`` inputs.

    Returns:
        The JSON body returned by ``/locks/claim`` describing the claim
        outcome (typically the ``claimed``/``skipped`` ids and TTL).
    """

    jt = job_type.strip()
    coll = collection.strip()
    if not jt:
        raise ValueError("job_type is required")
    if not coll:
        raise ValueError("collection is required")
    trimmed = [value.strip() for value in record_ids if isinstance(value, str) and value.strip()]
    if not trimmed:
        raise ValueError("record_ids must include at least one value")
    body: dict[str, Any] = {"job_type": jt, "collection": coll, "record_ids": trimmed}
    job_ref = job_id.strip() if isinstance(job_id, str) else ""
    if job_ref:
        body["job_id"] = job_ref

    claimed_by_ref = claimed_by.strip() if isinstance(claimed_by, str) else ""
    if claimed_by_ref:
        body["claimed_by"] = claimed_by_ref
    if ttl_seconds and ttl_seconds > 0:
        body["ttl_seconds"] = ttl_seconds

    if provenance is not None:
        body["provenance"] = _ensure_mapping(provenance, name="provenance")
    else:
        body["provenance"] = _default_provenance(claimed_by_ref, job_ref or None)

    response = _api_request("POST", "locks/claim", json_body=body)
    if isinstance(response, MutableMapping):
        return response
    raise RuntimeError("unexpected response payload")


def release_locks(
    *,
    job_type: str,
    record_ids: Sequence[str] | None = None,
    job_id: str | None = None,
    collection: str | None = None,
) -> int:
    """Release previously claimed locks.

    Provide whatever context you used when claiming (``job_type`` plus
    optional ``job_id``/``collection``/``record_ids``) to target a subset of
    locks for deletion. When only ``job_type`` is specified, every lock of
    that type is released for the company; add finer filters to avoid
    dropping other workers' leases.
    """
    jt = job_type.strip()
    if not jt:
        raise ValueError("job_type is required")
    body: dict[str, Any] = {"job_type": jt}
    if job_id and job_id.strip():
        body["job_id"] = job_id.strip()
    if collection and collection.strip():
        body["collection"] = collection.strip()
    if record_ids:
        trimmed = [
            value.strip() for value in record_ids if isinstance(value, str) and value.strip()
        ]
        if trimmed:
            body["record_ids"] = trimmed

    response = _api_request("POST", "locks/release", json_body=body)
    if isinstance(response, MutableMapping):
        released = response.get("released")
        if isinstance(released, int):
            return released
    raise RuntimeError("unexpected response payload")


def reclaim_locks(
    *,
    job_type: str,
    collection: str | None = None,
    ttl_seconds: int | None = None,
) -> int:
    """Delete stale locks whose leases have expired.

    Typically run periodically (or before a new batch starts) to evict
    locks older than ``ttl_seconds``. If ``collection`` is supplied only
    that namespace is scanned, otherwise every lock for ``job_type`` is
    considered.
    """
    jt = job_type.strip()
    if not jt:
        raise ValueError("job_type is required")
    body: dict[str, Any] = {"job_type": jt}
    if collection and collection.strip():
        body["collection"] = collection.strip()
    if ttl_seconds and ttl_seconds > 0:
        body["ttl_seconds"] = ttl_seconds
    response = _api_request("POST", "locks/reclaim", json_body=body)
    if isinstance(response, MutableMapping):
        reclaimed = response.get("reclaimed")
        if isinstance(reclaimed, int):
            return reclaimed
    raise RuntimeError("unexpected response payload")


def upsert_record(
    collection_id_or_name: str,
    payload: Mapping[str, Any] | None = None,
    *,
    files: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Create or update a record identified by external_id."""

    if not collection_id_or_name:
        raise ValueError("collection_id_or_name is required")

    data = _ensure_mapping(payload, name="payload")
    external_id = str(data.get("external_id", "")).strip()
    if not external_id:
        raise ValueError("payload.external_id is required for upsert")
    data["external_id"] = external_id

    path = f"collections/{collection_id_or_name}/records/upsert"
    if files:
        form = {"@jsonPayload": json.dumps(data)}
        response = _api_request("POST", path, data=form, files=files)
    else:
        response = _api_request("POST", path, json_body=data)

    if not isinstance(response, dict):
        raise RuntimeError("unexpected response payload")
    return response


def save_to_lumera(file_path: str) -> dict:
    """Upload *file_path* to the current context.

    Priority:
      1) If running inside an Agent executor (LUMERA_RUN_ID), upload to that run
      2) Else if running in Playground (LUMERA_SESSION_ID), upload to the session
      3) Else, upload to global Documents
    """

    run_id = os.getenv("LUMERA_RUN_ID", "").strip()
    if run_id:
        return _upload_agent_run_file(file_path, run_id)

    session_id = os.getenv("LUMERA_SESSION_ID", "").strip()
    if session_id:
        return _upload_session_file(file_path, session_id)
    return _upload_document(file_path)
