#! /usr/bin/env bash

alias @camera=bluer_sbc_camera

alias @designs=bluer-designs

alias grove=bluer_sbc_grove

alias @sbc=bluer_sbc
