"""
API client implementations for all Open-Meteo endpoints.
"""

from openmeteo.clients.forecast import ForecastClient
from openmeteo.clients.historical import HistoricalClient
from openmeteo.clients.air_quality import AirQualityClient
from openmeteo.clients.marine import MarineClient
from openmeteo.clients.flood import FloodClient
from openmeteo.clients.climate import ClimateClient
from openmeteo.clients.ensemble import EnsembleClient
from openmeteo.clients.geocoding import GeocodingClient
from openmeteo.clients.elevation import ElevationClient

__all__ = [
    "ForecastClient",
    "HistoricalClient",
    "AirQualityClient",
    "MarineClient",
    "FloodClient",
    "ClimateClient",
    "EnsembleClient",
    "GeocodingClient",
    "ElevationClient",
]
