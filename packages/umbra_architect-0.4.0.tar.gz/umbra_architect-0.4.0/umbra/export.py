"""
Export functionality for Umbra.
Generates stunning interactive HTML dashboards.
"""

from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional


HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{project_name} - Umbra Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: #1a1a24;
            --accent: #6366f1;
            --accent-glow: rgba(99, 102, 241, 0.3);
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --border: #2d2d3a;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Space Grotesk', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            line-height: 1.6;
        }}
        
        /* Animated background */
        .bg-pattern {{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: 
                radial-gradient(circle at 25% 25%, var(--accent-glow) 0%, transparent 50%),
                radial-gradient(circle at 75% 75%, rgba(16, 185, 129, 0.1) 0%, transparent 50%);
            pointer-events: none;
            z-index: 0;
        }}
        
        .container {{
            position: relative;
            z-index: 1;
            max-width: 1600px;
            margin: 0 auto;
            padding: 2rem;
        }}
        
        /* Header */
        header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid var(--border);
        }}
        
        .logo {{
            display: flex;
            align-items: center;
            gap: 1rem;
        }}
        
        .logo-icon {{
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), #8b5cf6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }}
        
        .logo h1 {{
            font-size: 1.5rem;
            font-weight: 600;
        }}
        
        .logo .project-name {{
            color: var(--accent);
        }}
        
        .timestamp {{
            color: var(--text-muted);
            font-size: 0.85rem;
            font-family: 'JetBrains Mono', monospace;
        }}
        
        /* Health Score */
        .health-banner {{
            background: var(--bg-card);
            border-radius: 16px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 2rem;
            border: 1px solid var(--border);
        }}
        
        .health-score {{
            display: flex;
            align-items: center;
            gap: 1rem;
        }}
        
        .score-circle {{
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.8rem;
            position: relative;
        }}
        
        .score-circle::before {{
            content: '';
            position: absolute;
            inset: -3px;
            border-radius: 50%;
            padding: 3px;
            background: linear-gradient(135deg, var(--score-color), transparent);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
        }}
        
        .score-grade {{
            font-size: 0.7rem;
            color: var(--text-muted);
        }}
        
        .score-A {{ --score-color: var(--success); color: var(--success); }}
        .score-B {{ --score-color: #22c55e; color: #22c55e; }}
        .score-C {{ --score-color: var(--warning); color: var(--warning); }}
        .score-D {{ --score-color: #f97316; color: #f97316; }}
        .score-F {{ --score-color: var(--danger); color: var(--danger); }}
        
        .health-details {{
            flex: 1;
        }}
        
        .health-status {{
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }}
        
        .health-summary {{
            color: var(--text-secondary);
            font-size: 0.9rem;
        }}
        
        .health-stats {{
            display: flex;
            gap: 1.5rem;
        }}
        
        .stat {{
            text-align: center;
            padding: 0.5rem 1rem;
            background: var(--bg-secondary);
            border-radius: 8px;
        }}
        
        .stat-value {{
            font-size: 1.5rem;
            font-weight: 700;
            font-family: 'JetBrains Mono', monospace;
        }}
        
        .stat-label {{
            font-size: 0.75rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        
        /* Grid Layout */
        .dashboard-grid {{
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 1.5rem;
        }}
        
        @media (max-width: 1200px) {{
            .dashboard-grid {{
                grid-template-columns: 1fr;
            }}
        }}
        
        /* Cards */
        .card {{
            background: var(--bg-card);
            border-radius: 16px;
            border: 1px solid var(--border);
            overflow: hidden;
        }}
        
        .card-header {{
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 600;
        }}
        
        .card-header .icon {{
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }}
        
        .card-body {{
            padding: 1.5rem;
        }}
        
        /* Diagram */
        .diagram-container {{
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 2rem;
            min-height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        
        .mermaid {{
            width: 100%;
        }}
        
        .mermaid svg {{
            max-width: 100%;
            height: auto;
        }}
        
        /* Metrics Grid */
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }}
        
        @media (max-width: 800px) {{
            .metrics-grid {{
                grid-template-columns: repeat(2, 1fr);
            }}
        }}
        
        .metric-card {{
            background: var(--bg-secondary);
            border-radius: 12px;
            padding: 1.25rem;
            text-align: center;
            transition: transform 0.2s, box-shadow 0.2s;
        }}
        
        .metric-card:hover {{
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }}
        
        .metric-icon {{
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }}
        
        .metric-value {{
            font-size: 1.75rem;
            font-weight: 700;
            font-family: 'JetBrains Mono', monospace;
            color: var(--accent);
        }}
        
        .metric-label {{
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 0.25rem;
        }}
        
        /* Sidebar */
        .sidebar {{
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }}
        
        /* Summary */
        .summary-content {{
            font-size: 0.95rem;
            color: var(--text-secondary);
        }}
        
        .summary-content strong {{
            color: var(--accent);
        }}
        
        .summary-content h3 {{
            color: var(--text-primary);
            font-size: 1rem;
            margin: 1.25rem 0 0.5rem 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}
        
        .summary-content code {{
            background: var(--bg-secondary);
            padding: 0.15rem 0.5rem;
            border-radius: 4px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.85rem;
            color: var(--accent);
        }}
        
        .summary-content ul {{
            list-style: none;
            margin-top: 0.5rem;
        }}
        
        .summary-content li {{
            padding: 0.4rem 0;
            padding-left: 1.25rem;
            position: relative;
        }}
        
        .summary-content li::before {{
            content: "→";
            position: absolute;
            left: 0;
            color: var(--accent);
        }}
        
        .summary-content table {{
            width: 100%;
            border-collapse: collapse;
            margin: 0.75rem 0;
            font-size: 0.9rem;
        }}
        
        .summary-content th,
        .summary-content td {{
            padding: 0.5rem;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }}
        
        .summary-content th {{
            color: var(--text-muted);
            font-weight: 500;
        }}
        
        /* Insights */
        .insights-list {{
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }}
        
        .insight-item {{
            background: var(--bg-secondary);
            border-radius: 8px;
            padding: 1rem;
            border-left: 3px solid var(--insight-color);
        }}
        
        .insight-warning {{ --insight-color: var(--warning); }}
        .insight-critical {{ --insight-color: var(--danger); }}
        .insight-info {{ --insight-color: var(--accent); }}
        
        .insight-title {{
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 0.25rem;
        }}
        
        .insight-desc {{
            font-size: 0.8rem;
            color: var(--text-muted);
        }}
        
        .no-insights {{
            text-align: center;
            padding: 2rem;
            color: var(--text-muted);
        }}
        
        .no-insights .icon {{
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }}
        
        /* Key Files */
        .files-list {{
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }}
        
        .file-item {{
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem;
            background: var(--bg-secondary);
            border-radius: 8px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.85rem;
            transition: background 0.2s;
        }}
        
        .file-item:hover {{
            background: var(--bg-primary);
        }}
        
        .file-icon {{
            color: var(--accent);
        }}
        
        .file-name {{
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        
        .file-lines {{
            color: var(--text-muted);
            font-size: 0.75rem;
        }}
        
        /* Footer */
        footer {{
            text-align: center;
            margin-top: 3rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border);
            color: var(--text-muted);
            font-size: 0.85rem;
        }}
        
        footer a {{
            color: var(--accent);
            text-decoration: none;
        }}
        
        footer a:hover {{
            text-decoration: underline;
        }}
        
        /* Animations */
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(10px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        
        .card {{
            animation: fadeIn 0.5s ease-out;
        }}
        
        .card:nth-child(2) {{ animation-delay: 0.1s; }}
        .card:nth-child(3) {{ animation-delay: 0.2s; }}
        .card:nth-child(4) {{ animation-delay: 0.3s; }}
    </style>
</head>
<body>
    <div class="bg-pattern"></div>
    
    <div class="container">
        <header>
            <div class="logo">
                <div class="logo-icon">🌑</div>
                <div>
                    <h1>Umbra Dashboard</h1>
                    <span class="project-name">{project_name}</span>
                </div>
            </div>
            <div class="timestamp">Generated: {timestamp}</div>
        </header>
        
        <!-- Health Score Banner -->
        <div class="health-banner">
            <div class="health-score">
                <div class="score-circle score-{health_grade}">
                    {health_score}
                    <span class="score-grade">{health_grade}</span>
                </div>
            </div>
            <div class="health-details">
                <div class="health-status">{health_status}</div>
                <div class="health-summary">{health_summary}</div>
            </div>
            <div class="health-stats">
                <div class="stat">
                    <div class="stat-value">{total_files}</div>
                    <div class="stat-label">Files</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{total_lines}</div>
                    <div class="stat-label">Lines</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{total_issues}</div>
                    <div class="stat-label">Issues</div>
                </div>
            </div>
        </div>
        
        <!-- Metrics -->
        <div class="metrics-grid">
            {metrics_html}
        </div>
        
        <!-- Main Grid -->
        <div class="dashboard-grid">
            <main>
                <div class="card">
                    <div class="card-header">
                        <span class="icon">📊</span>
                        Architecture Diagram
                    </div>
                    <div class="card-body">
                        <div class="diagram-container">
                            <pre class="mermaid">
{mermaid_diagram}
                            </pre>
                        </div>
                    </div>
                </div>
            </main>
            
            <aside class="sidebar">
                <div class="card">
                    <div class="card-header">
                        <span class="icon">📋</span>
                        Project Summary
                    </div>
                    <div class="card-body">
                        <div class="summary-content">
                            {summary_html}
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <span class="icon">⚠️</span>
                        Insights
                    </div>
                    <div class="card-body">
                        {insights_html}
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <span class="icon">📁</span>
                        Key Files
                    </div>
                    <div class="card-body">
                        {files_html}
                    </div>
                </div>
            </aside>
        </div>
        
        <footer>
            Generated by <a href="https://github.com/rida12b/Umbra">Umbra</a> - The Shadow Architect
            <br>
            <span style="font-size: 0.75rem;">pip install umbra-architect</span>
        </footer>
    </div>
    
    <script>
        mermaid.initialize({{
            startOnLoad: true,
            theme: 'dark',
            themeVariables: {{
                primaryColor: '#6366f1',
                primaryTextColor: '#f1f5f9',
                primaryBorderColor: '#2d2d3a',
                lineColor: '#6366f1',
                secondaryColor: '#1a1a24',
                tertiaryColor: '#12121a',
                background: '#0a0a0f',
                mainBkg: '#1a1a24',
                nodeBorder: '#6366f1',
                clusterBkg: '#12121a',
                clusterBorder: '#2d2d3a',
                titleColor: '#f1f5f9',
                edgeLabelBackground: '#1a1a24'
            }},
            flowchart: {{
                curve: 'basis',
                padding: 20
            }}
        }});
    </script>
</body>
</html>
'''


def markdown_to_html(md: str) -> str:
    """Convert simple markdown to HTML."""
    import re
    
    html = md
    
    # Bold
    html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
    
    # Code
    html = re.sub(r'`(.+?)`', r'<code>\1</code>', html)
    
    # Headers with emojis
    html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
    
    # Tables
    if '|' in html and '---' in html:
        lines = html.split('\n')
        in_table = False
        result = []
        for line in lines:
            if '|' in line and '---' not in line:
                cells = [c.strip() for c in line.split('|')[1:-1]]
                if not in_table:
                    result.append('<table><tbody>')
                    in_table = True
                result.append('<tr>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>')
            else:
                if in_table and '---' not in line:
                    result.append('</tbody></table>')
                    in_table = False
                if '---' not in line:
                    result.append(line)
        if in_table:
            result.append('</tbody></table>')
        html = '\n'.join(result)
    
    # Lists
    lines = html.split('\n')
    in_list = False
    result = []
    for line in lines:
        if line.strip().startswith('- '):
            if not in_list:
                result.append('<ul>')
                in_list = True
            result.append(f'<li>{line.strip()[2:]}</li>')
        else:
            if in_list:
                result.append('</ul>')
                in_list = False
            result.append(line)
    if in_list:
        result.append('</ul>')
    
    html = '\n'.join(result)
    
    # Paragraphs
    lines = html.split('\n')
    result = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('<') and not stripped.startswith('#'):
            result.append(f'<p>{line}</p>')
        else:
            result.append(line)
    
    return '\n'.join(result)


def generate_insights_html(insights: list) -> str:
    """Generate HTML for insights list."""
    if not insights:
        return '''
        <div class="no-insights">
            <div class="icon">✨</div>
            <div>No issues detected!</div>
        </div>
        '''
    
    html_parts = ['<div class="insights-list">']
    for insight in insights[:5]:  # Show max 5
        severity = insight.severity.value if hasattr(insight.severity, 'value') else str(insight.severity)
        html_parts.append(f'''
        <div class="insight-item insight-{severity}">
            <div class="insight-title">{insight.title}</div>
            <div class="insight-desc">{insight.recommendation}</div>
        </div>
        ''')
    html_parts.append('</div>')
    return '\n'.join(html_parts)


def generate_files_html(largest_files: list) -> str:
    """Generate HTML for key files list."""
    if not largest_files:
        return '<div class="no-insights">No files analyzed yet.</div>'
    
    html_parts = ['<div class="files-list">']
    for filepath, lines in largest_files[:5]:
        icon = "🐍" if filepath.endswith('.py') else "📄"
        html_parts.append(f'''
        <div class="file-item">
            <span class="file-icon">{icon}</span>
            <span class="file-name">{filepath}</span>
            <span class="file-lines">{lines} lines</span>
        </div>
        ''')
    html_parts.append('</div>')
    return '\n'.join(html_parts)


def generate_metrics_html(metrics: Dict[str, Any]) -> str:
    """Generate HTML for metrics cards."""
    items = [
        ("📁", metrics.get('total_files', 0), "Total Files"),
        ("📝", metrics.get('total_lines', 0), "Lines of Code"),
        ("🐍", metrics.get('files_by_type', {}).get('.py', 0), "Python Files"),
        ("⚡", metrics.get('files_by_type', {}).get('.js', 0) + metrics.get('files_by_type', {}).get('.ts', 0), "JS/TS Files"),
    ]
    
    html_parts = []
    for icon, value, label in items:
        html_parts.append(f'''
        <div class="metric-card">
            <div class="metric-icon">{icon}</div>
            <div class="metric-value">{value:,}</div>
            <div class="metric-label">{label}</div>
        </div>
        ''')
    return '\n'.join(html_parts)


def export_html(
    input_file: str,
    output_file: str,
    project_name: str | None = None,
    analysis: Dict[str, Any] | None = None,
) -> None:
    """
    Export architecture to stunning HTML dashboard.
    
    Args:
        input_file: Path to LIVE_ARCHITECTURE.md
        output_file: Output HTML path
        project_name: Optional project name
        analysis: Optional analysis data from insights module
    """
    input_path = Path(input_file)
    
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_file}")
    
    content = input_path.read_text(encoding="utf-8")
    
    # Extract mermaid diagram
    mermaid = ""
    if "```mermaid" in content:
        start = content.index("```mermaid") + len("```mermaid")
        end = content.index("```", start)
        mermaid = content[start:end].strip()
    
    # Extract summary
    summary = ""
    if "## Project Summary" in content:
        start = content.index("## Project Summary") + len("## Project Summary")
        end = content.index("## System Overview") if "## System Overview" in content else len(content)
        summary = content[start:end].strip()
    
    # Default analysis data
    if analysis is None:
        analysis = {
            'metrics': {'total_files': 0, 'total_lines': 0, 'files_by_type': {}, 'largest_files': []},
            'insights': [],
            'health': {'score': 85, 'grade': 'B', 'status': 'Good', 'total_issues': 0}
        }
    
    metrics = analysis.get('metrics', {})
    insights = analysis.get('insights', [])
    health = analysis.get('health', {})
    
    # Generate HTML
    html = HTML_TEMPLATE.format(
        project_name=project_name or "Project",
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M"),
        mermaid_diagram=mermaid,
        summary_html=markdown_to_html(summary),
        health_score=health.get('score', 85),
        health_grade=health.get('grade', 'B'),
        health_status=health.get('status', 'Good'),
        health_summary=f"{health.get('total_issues', 0)} issues found across the codebase",
        total_files=metrics.get('total_files', 0),
        total_lines=metrics.get('total_lines', 0),
        total_issues=health.get('total_issues', 0),
        metrics_html=generate_metrics_html(metrics),
        insights_html=generate_insights_html(insights),
        files_html=generate_files_html(metrics.get('largest_files', [])),
    )
    
    # Write output
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
