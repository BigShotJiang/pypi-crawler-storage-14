"""
🌑 Umbra - The Shadow Architect

A living architecture diagram that updates in real-time.
"""

__version__ = "0.4.0"

