def test_import():
    import barc4beams
    assert hasattr(barc4beams, "__version__")