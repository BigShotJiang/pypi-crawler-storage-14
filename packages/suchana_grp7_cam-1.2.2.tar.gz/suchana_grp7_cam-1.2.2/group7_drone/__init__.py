__version__ = "1.0.0"
name = "Group7 Drone Camera"
