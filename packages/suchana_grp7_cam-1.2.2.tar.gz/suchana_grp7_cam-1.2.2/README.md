# Group7 Drone Camera — Advanced AI Live Vision System 🚁📡

### © 2025 Suchana SpaceExpo  
### In Collaboration With **Anu Electronics, Chennai**

---

## 🔍 Project Overview

**Group7 Drone Camera** is an advanced AI-powered real-time drone vision system designed for:

- Smart Surveillance  
- Object Detection & Tracking  
- Live Video Streaming to YouTube (RTMP)  
- Automated Image Capture & Upload  
- Cloud Logging to Google Sheets  
- Instant Email Notifications with Captured Images  

Engineered for **robust aerospace and security applications**, delivering reliable performance in the field.

---

## 🧠 Core Capabilities

| Feature | Description |
|--------|-------------|
| 🧩 AI Detection | YOLOv8 real-time inference |
| 🎯 Tracking System | Follow targets with ID + dynamic focus |
| 🔥 IR/Heat Visualization | Multiple colormaps (Thermal mode) |
| 🌍 Cloud Integration | Firebase + Google Drive + Gmail API |
| 📊 Logging | Auto-upload logs to Google Sheets |
| 📸 Auto Capture | Image capture every X seconds |
| 🎥 Streaming | Full HD RTMP to YouTube |
| 🔒 Licensing | Cloud-controlled activation |

---

## 📦 Components Installed

- Python 3.8+  
- Ultralytics YOLOv8  
- PyTorch  
- OpenCV  
- FFmpeg  
- Firebase Admin SDK  
- Google APIs for Gmail, Drive & Sheets  
- Matplotlib and analytics utilities  

---

## 🛠 Hardware Requirements

| Component | Requirement |
|----------|------------|
| Drone or Laptop system | Windows 10/11 (Recommended) |
| Camera | USB Camera / Drone Camera Feed |
| Internet | Required for cloud functionality |
| GPU | Optional, CPU fallback supported |

---

## 📡 Streaming Specifications

- Resolution: **1920×1080**
- Frame Rate: **20 FPS**
- Encoder: **libx264 (veryfast preset)**
- Bitrate: **6 Mbps**
- Audio: Auto null source (no audio required)

---

## 🔐 Security & Licensing

This software operates under **remote license control**  
via Firebase, allowing Suchana SpaceExpo to:

✔ Activate / Deactivate usage  
✔ Track machine IDs  
✔ Enforce subscription rules  

🚫 Unauthorized redistribution strictly prohibited.

---

## 🧭 Support

Website: https://suchanaspace.live  
Email: support@suchanaspace.live  
Partner: https://anuelectronics.in  

---

## 🏢 Contributors

| Organization | Role |
|-------------|-----|
| **Suchana SpaceExpo** | Software, AI Vision, Architecture |
| **Anu Electronics, Chennai** | Hardware & Electronics Integration |

---

## 📜 Legal

© 2025 Suchana SpaceExpo. All Rights Reserved.  
Co-Developed with Anu Electronics, Chennai.

See **LICENSE.txt** for complete legal terms.
