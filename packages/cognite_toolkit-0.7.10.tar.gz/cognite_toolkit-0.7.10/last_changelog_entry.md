## Changelog 

### Fixed

- Uploading timeseries or events using `cdf data upload dir` no longer
creates assets.