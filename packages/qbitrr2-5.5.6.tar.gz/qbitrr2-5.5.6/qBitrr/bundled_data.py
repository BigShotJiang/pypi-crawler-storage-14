version = "5.5.6"
git_hash = "addcf902"
license_text = (
    "Licence can be found on:\n\nhttps://github.com/Feramance/qBitrr/blob/master/LICENSE"
)
patched_version = f"{version}-{git_hash}"
tagged_version = f"{version}"
