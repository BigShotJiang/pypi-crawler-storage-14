import subprocess
import time
import platform
import shutil
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, DataTable, Static
from textual.containers import Container
from typing import Literal
from textual.binding import Binding


def get_platform() -> str:
    """Detect the current platform."""
    system = platform.system().lower()
    if system == "windows":
        # Check if WSL is available
        if shutil.which("wsl"):
            return "windows_wsl"
        return "windows"
    elif system == "linux":
        return "linux"
    elif system == "darwin":
        return "macos"
    return "unknown"


PLATFORM = get_platform()


def run_docker_command(command_parts: list[str]) -> tuple[int, str]:
    """Executes a docker command based on platform."""
    if PLATFORM == "windows_wsl":
        full_command = ["wsl", "docker"] + command_parts
    else:
        full_command = ["docker"] + command_parts
    
    try:
        result = subprocess.run(full_command, capture_output=True, text=True, check=False)
        return result.returncode, (result.stdout + result.stderr).strip()
    except FileNotFoundError:
        if PLATFORM == "windows_wsl":
            return 1, "Error: 'wsl' not found."
        else:
            return 1, "Error: 'docker' not found."
    except Exception as e:
        return 1, str(e)


class DockerTUI(App[None]):
    """Fast TUI for Docker."""
    
    mode: Literal["CONTAINERS", "IMAGES", "VOLUMES"] = "CONTAINERS"
    
    BINDINGS = [
        Binding("q", "quit", "Quit", show=True),
        Binding("a", "refresh", "Refresh", show=True),
        Binding("g", "toggle_stats", "Stats ON/OFF", show=True),
        Binding("r", "restart_container", "Restart", show=True),
        Binding("x", "stop_container", "Stop", show=True),
        Binding("s", "start_container", "Start", show=True),
        Binding("l", "watch_logs", "Logs", show=True),
        Binding("d", "delete_item", "Delete", show=True),
        Binding("p", "show_prune_menu", "Prune", show=True),
        Binding("c", "set_mode('CONTAINERS')", "Containers", show=True),
        Binding("i", "set_mode('IMAGES')", "Images", show=True),
        Binding("v", "set_mode('VOLUMES')", "Volumes", show=True),
        Binding("m", "toggle_multi_select", "Mark", show=True),
        Binding("t", "launch_terminal", "Terminal", show=True),
    ]
    
    CSS = """
    #container-list {
        height: 70%;
    }
    #log-panel {
        height: 30%;
        border-top: heavy white;
        padding: 1;
        overflow-y: auto;
        color: #ADFF2F;
    }
    """
    
    def __init__(self):
        super().__init__()
        self._prune_ready = False
        self._prune_timer = None
        self._selected_items = []
        self._multi_select_mode = False
        self.selected_row_data = None
        self._show_stats = False
        self._stats_cache = {}
        self._stats_cache_time = 0
        self._cache_ttl = 2.0
    
    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(DataTable(id="container-list"), id="main-area")
        yield Static("Ready.", id="log-panel")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#log-panel", Static).markup = False
        platform_name = {
            "windows_wsl": "Windows (WSL)",
            "linux": "Linux",
            "macos": "macOS",
            "windows": "Windows (native)",
            "unknown": "Unknown"
        }.get(PLATFORM, "Unknown")
        self.notify(f"Platform: {platform_name}", severity="information", timeout=2)
        self.action_set_mode(self.mode)
    
    def action_toggle_stats(self) -> None:
        """Toggle stats display for containers."""
        self._show_stats = not self._show_stats
        status = "ON" if self._show_stats else "OFF"
        self.notify(f"Stats display: {status}", severity="information")
        if self.mode == "CONTAINERS":
            self.update_data_list()
    
    def action_set_mode(self, new_mode: str) -> None:
        self.mode = new_mode
        self.update_data_list()
        self.notify(f"Switched to {self.mode}", severity="information", timeout=1)

    def action_refresh(self) -> None:
        self._stats_cache.clear()
        self.update_data_list()
        self.notify(f"{self.mode} refreshed.", severity="information", timeout=1)

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        try:
            self.selected_row_data = list(event.sender.get_row(event.row_key)) if event.row_key else None
        except:
            self.selected_row_data = None

    def update_data_list(self) -> None:
        """Fast data update with optional stats."""
        table = self.query_one(DataTable)
        output_widget = self.query_one("#log-panel", Static)
        
        if self.mode == "CONTAINERS":
            if self._show_stats:
                columns = ("MARK", "ID", "Names", "Image", "Status", "Ports", "CPU%", "Mem%")
                command = ["ps", "-a", "--format", "{{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}"]
            else:
                columns = ("MARK", "ID", "Names", "Image", "Status", "Ports")
                command = ["ps", "-a", "--format", "{{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}"]
            item_count = 5
        elif self.mode == "IMAGES":
            columns = ("MARK", "ID", "Repository", "Tag", "Size")
            command = ["image", "ls", "--format", "{{.ID}}\t{{.Repository}}\t{{.Tag}}\t{{.Size}}"]
            item_count = 4
        else:
            columns = ("MARK", "Name", "Driver")
            command = ["volume", "ls", "--format", "{{.Name}}\t{{.Driver}}"]
            item_count = 2

        table.clear()
        for col_key in list(table.columns.keys()):
            try:
                table.remove_column(col_key)
            except:
                pass

        try:
            table.add_columns(*columns)
        except Exception as e:
            self.notify(f"Column error: {e}", severity="error")
            return
            
        exit_code, output = run_docker_command(command)
        if exit_code != 0:
            self.notify(f"Failed to get {self.mode}.", severity="error")
            output_widget.update(output)
            return

        lines = output.split('\n')
        marked_ids = [item[0] for item in self._selected_items] if self._multi_select_mode else []
        
        stats_data = {}
        if self.mode == "CONTAINERS" and self._show_stats:
            current_time = time.time()
            if current_time - self._stats_cache_time > self._cache_ttl or not self._stats_cache:
                running_ids = []
                for line in lines:
                    if line:
                        parts = line.split('\t')
                        if len(parts) >= 4 and 'up' in parts[3].lower():
                            running_ids.append(parts[0][:12])
                
                if running_ids:
                    stats_cmd = ["stats", "--no-stream", "--format", "{{.ID}}\t{{.CPUPerc}}\t{{.MemPerc}}"] + running_ids
                    stats_exit, stats_output = run_docker_command(stats_cmd)
                    if stats_exit == 0:
                        for stats_line in stats_output.split('\n'):
                            if stats_line:
                                stats_parts = stats_line.split('\t')
                                if len(stats_parts) == 3:
                                    self._stats_cache[stats_parts[0]] = {
                                        'cpu': stats_parts[1],
                                        'mem': stats_parts[2]
                                    }
                        self._stats_cache_time = current_time
            
            stats_data = self._stats_cache
        
        for line in lines:
            if line:
                parts = line.split('\t')
                if len(parts) == item_count:
                    row_data = list(parts)
                    
                    if self.mode == "CONTAINERS" and self._show_stats:
                        container_id = row_data[0][:12]
                        if container_id in stats_data:
                            row_data.append(stats_data[container_id]['cpu'])
                            row_data.append(stats_data[container_id]['mem'])
                        else:
                            row_data.extend(['--', '--'])
                    
                    marker = ' [X]' if self._multi_select_mode and row_data[0] in marked_ids else '    '
                    row_data.insert(0, marker)
                    table.add_row(*row_data, key=row_data[1])
        
        output_widget.update(f"OK: {len(lines)} items")

    def action_launch_terminal(self) -> None:
        if self.mode != "CONTAINERS":
            self.notify("Terminal is only for containers.", severity="error")
            return
        
        table = self.query_one(DataTable)
        if table.cursor_row is None:
            return
        
        try:
            col_labels = [str(col.label) for col in table.columns.values()]
            id_idx = col_labels.index('ID')
            name_idx = col_labels.index('Names')
            status_idx = col_labels.index('Status')
        except:
            return
        
        row = table.get_row_at(table.cursor_row)
        cid, cname, status = row[id_idx], row[name_idx], row[status_idx]
        
        if 'up' not in status.lower():
            self.notify("Container not running.", severity="error")
            return
        
        # Platform-specific terminal launch
        if PLATFORM == "windows_wsl":
            # Windows Terminal with WSL
            cmd = ["wt.exe", "-w", "0", "--title", f"Terminal: {cname}", "wsl", "docker", "exec", "-it", cid, "/bin/bash"]
        elif PLATFORM == "linux":
            # Try common Linux terminals
            if shutil.which("gnome-terminal"):
                cmd = ["gnome-terminal", "--", "docker", "exec", "-it", cid, "/bin/bash"]
            elif shutil.which("konsole"):
                cmd = ["konsole", "-e", "docker", "exec", "-it", cid, "/bin/bash"]
            elif shutil.which("xterm"):
                cmd = ["xterm", "-e", "docker", "exec", "-it", cid, "/bin/bash"]
            else:
                self.notify("No supported terminal found.", severity="error")
                return
        elif PLATFORM == "macos":
            # macOS Terminal.app
            script = f'tell app "Terminal" to do script "docker exec -it {cid} /bin/bash"'
            cmd = ["osascript", "-e", script]
        else:
            self.notify("Terminal launch not supported on this platform.", severity="error")
            return
        
        try:
            subprocess.Popen(cmd, shell=False)
            self.notify(f"Terminal: {cname}", severity="information")
        except:
            self.notify("Failed to launch terminal.", severity="error")

    def action_toggle_multi_select(self) -> None:
        table = self.query_one(DataTable)
        current_data = None
        
        if table.cursor_row is not None:
            try:
                current_data = list(table.get_row_at(table.cursor_row))
            except:
                pass
        
        if current_data and len(current_data) > 1:
            row_data = current_data[1:]
            item_id = row_data[0]
            
            if self._multi_select_mode:
                is_marked = any(item[0] == item_id for item in self._selected_items)
                if is_marked:
                    self._selected_items = [item for item in self._selected_items if item[0] != item_id]
                    if not self._selected_items:
                        self._multi_select_mode = False
                        self.notify("Multi-select OFF", severity="information")
                    else:
                        self.notify(f"Unmarked ({len(self._selected_items)} selected)", timeout=1)
                else:
                    self._selected_items.append(row_data)
                    self.notify(f"Marked ({len(self._selected_items)} selected)", timeout=1)
                self.update_data_list()
            else:
                self._multi_select_mode = True
                self._selected_items.clear()
                self.notify("Multi-select ON. Press 'M' to mark.", severity="warning")
                self.update_data_list()

    def _execute_container_action(self, action: str) -> None:
        items = self._get_items_to_process()
        if not items:
            return

        table = self.query_one(DataTable)
        try:
            col_labels = [str(col.label) for col in table.columns.values()]
            id_idx = col_labels.index('ID')
            name_idx = col_labels.index('Names')
        except:
            id_idx, name_idx = 0, 2

        success = 0
        for item in items:
            cid, cname = item[id_idx], item[name_idx]
            if run_docker_command([action, cid])[0] == 0:
                success += 1
                self.append_to_log(f"✅ {action} {cname}")
            else:
                self.append_to_log(f"❌ Failed {action} {cname}")

        if success == len(items):
            self.notify(f"✅ {action}ed {success} container(s)", severity="information")
        elif success > 0:
            self.notify(f"⚠️ Partial: {success}/{len(items)}", severity="warning")
        else:
            self.notify(f"❌ Failed", severity="error")
        
        if self._multi_select_mode:
            self._selected_items.clear()
            self._multi_select_mode = False
        
        self.update_data_list()
        
    def action_restart_container(self) -> None:
        if self.mode != "CONTAINERS":
            return
        self._execute_container_action("restart")

    def action_stop_container(self) -> None:
        if self.mode != "CONTAINERS":
            return
        self._execute_container_action("stop")

    def action_start_container(self) -> None:
        if self.mode != "CONTAINERS":
            return
        self._execute_container_action("start")

    def action_watch_logs(self) -> None:
        if self.mode != "CONTAINERS":
            self.notify("Logs only for containers.", severity="warning")
            return
        
        table = self.query_one(DataTable)
        if table.cursor_row is None:
            return
        
        try:
            col_labels = [str(col.label) for col in table.columns.values()]
            id_idx = col_labels.index('ID')
            name_idx = col_labels.index('Names')
            status_idx = col_labels.index('Status')
        except:
            return
        
        row = table.get_row_at(table.cursor_row)
        cid, cname, status = row[id_idx], row[name_idx], row[status_idx]
        
        if 'up' not in status.lower():
            self.notify("Container not running.", severity="error")
            return
        
        # Platform-specific logs launch
        if PLATFORM == "windows_wsl":
            # Windows Terminal with WSL
            cmd = ["wt.exe", "-w", "0", "--title", f"Logs: {cname}", "wsl", "docker", "logs", "-f", "--tail", "50", cid]
        elif PLATFORM == "linux":
            # Try common Linux terminals
            if shutil.which("gnome-terminal"):
                cmd = ["gnome-terminal", "--", "docker", "logs", "-f", "--tail", "50", cid]
            elif shutil.which("konsole"):
                cmd = ["konsole", "-e", "docker", "logs", "-f", "--tail", "50", cid]
            elif shutil.which("xterm"):
                cmd = ["xterm", "-e", "docker", "logs", "-f", "--tail", "50", cid]
            else:
                self.notify("No supported terminal found.", severity="error")
                return
        elif PLATFORM == "macos":
            # macOS Terminal.app
            script = f'tell app "Terminal" to do script "docker logs -f --tail 50 {cid}"'
            cmd = ["osascript", "-e", script]
        else:
            self.notify("Logs launch not supported on this platform.", severity="error")
            return
        
        try:
            subprocess.Popen(cmd, shell=False)
            self.notify(f"Logs: {cname}", severity="information")
        except:
            self.notify("Failed to launch terminal.", severity="error")

    def _get_items_to_process(self) -> list[list[str]] | None:
        table = self.query_one(DataTable)
        
        if self._multi_select_mode:
            if not self._selected_items:
                self.notify("No items selected.", severity="warning")
                return None
            return self._selected_items
        else:
            if table.cursor_row is not None:
                try:
                    data = list(table.get_row_at(table.cursor_row))
                    return [data[1:]] if len(data) > 1 else None
                except:
                    pass
            self.notify("Select an item.", severity="warning")
            return None

    def action_delete_item(self) -> None:
        items = self._get_items_to_process()
        if not items:
            return

        table = self.query_one(DataTable)
        try:
            col_labels = [str(col.label) for col in table.columns.values()][1:]
            
            # Handle different column names for different modes
            if self.mode == "VOLUMES":
                id_idx = col_labels.index('Name')  # Volumes use 'Name' not 'ID'
                status_idx = None
            else:
                id_idx = col_labels.index('ID')
                status_idx = col_labels.index('Status') if self.mode == "CONTAINERS" else None
        except:
            self.notify("Column error.", severity="error")
            return

        success = 0
        for item in items:
            item_id = item[id_idx]
            
            if self.mode == "CONTAINERS":
                if status_idx is not None and 'up' in item[status_idx].lower():
                    self.notify(f"Stop {item_id[:12]} first.", severity="error")
                    continue
                cmd = ["rm", item_id]
            elif self.mode == "IMAGES":
                cmd = ["rmi", item_id]
            else:
                cmd = ["volume", "rm", item_id, "-f"]
            
            if run_docker_command(cmd)[0] == 0:
                success += 1
                self.append_to_log(f"✅ Deleted {item_id[:12]}")
            else:
                self.append_to_log(f"❌ Failed {item_id[:12]}")
        
        if success == len(items):
            self.notify(f"✅ Deleted {success} item(s)", severity="information")
        elif success > 0:
            self.notify(f"⚠️ Partial: {success}/{len(items)}", severity="warning")
        else:
            self.notify("❌ Delete failed", severity="error")

        if self._multi_select_mode:
            self._selected_items.clear()
        
        self.update_data_list()

    def append_to_log(self, text: str) -> None:
        panel = self.query_one("#log-panel", Static)
        current = panel.text if hasattr(panel, 'text') else ""
        if "Ready." in current or "Status/Output" in current:
            current = ""
        new_text = current + "\n" + text
        lines = new_text.splitlines()
        panel.update("\n".join(lines[-100:]))
        panel.scroll_end()

    def action_show_prune_menu(self) -> None:
        if self._prune_ready:
            if self._prune_timer:
                self._prune_timer.stop()
            self._prune_ready = False
            self._execute_prune()
        else:
            self._prune_ready = True
            self.notify("⚠️ Press 'P' again in 5s to prune.", severity="warning", timeout=5)
            self.append_to_log("WARN: Press 'P' again to prune unused Docker resources.")
            self._prune_timer = self.set_timer(5, self._reset_prune)

    def _reset_prune(self) -> None:
        self._prune_ready = False
        self._prune_timer = None
        self.notify("Prune cancelled.", severity="information")

    def _execute_prune(self) -> None:
        self.append_to_log("\n--- Starting Prune ---")
        exit_code, output = run_docker_command(["system", "prune", "-a", "-f"])
        if exit_code == 0:
            self.append_to_log(f"✅ Prune complete\n{output}")
            self.notify("✅ Prune complete", severity="information")
        else:
            self.append_to_log(f"❌ Prune failed\n{output}")
            self.notify("❌ Prune failed", severity="error")
        self.update_data_list()

    def action_quit(self) -> None:
        self.exit()


def main():
    app = DockerTUI()
    app.run()


if __name__ == "__main__":
    main()