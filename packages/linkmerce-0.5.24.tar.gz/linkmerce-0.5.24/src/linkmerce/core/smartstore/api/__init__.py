from linkmerce.core.smartstore.api.common import SmartstoreAPI
