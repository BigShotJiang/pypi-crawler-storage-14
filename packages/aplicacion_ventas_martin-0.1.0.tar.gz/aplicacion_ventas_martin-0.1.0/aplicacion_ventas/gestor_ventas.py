from .descuentos import Descuento
from .impuestos import Impuestos
from .precios import Precio

class GestorVentas:
    def __init__(self,precio_base,impuesto_porcentaje,descuento_porcentaje):
        self.precio_base = precio_base
        self.impuesto_porcentaje = Impuestos(impuesto_porcentaje)
        self.descuento_porcentaje = Descuento(descuento_porcentaje)
    def calcular_precio_final(self):
        impuesto_aplicado = self.impuesto_porcentaje.aplicar_impuesto(self.precio_base)
        descuento_aplicado = self.descuento_porcentaje.aplicar_descuento(self.precio_base)
        precio_final = Precio.calcular_precio_final(self.precio_base,impuesto_aplicado,descuento_aplicado)
        return round (precio_final,2)




