# Aplicación de Ventas

Este paquete proporciona funcionalidades para gestionar ventas, incluyendo cálculos de precios, impuestos y descuentos.

## Instalación

Puedes instalar el paquete usando:

```bash
pip install .
"
