![image](https://raw.githubusercontent.com/npiocean/kval/master/graphics/kval_banner.png)

Collection of Python tools for working with oceanography data processing and analysis.

Maintained by the Oceanography section at the [Norwegian Polar Institute](https://www.npolar.no/en/) and supported by the [HiAOOS](https://hiaoos.eu/) project.
___


#### [Documentation page](https://kval.readthedocs.io/) *(in development)*


___

### Installation

Conda:

    conda install -c npiocean -c conda-forge kval


Pip [^tag] :

    pip install kval


[^tag]: Conda is recommended for Windows users as we have experienced errors with the dependent library `compliance-checker` on Windows+pip.


___

About the latest release, `0.4.2`:

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.17723685.svg)](https://doi.org/10.5281/zenodo.17723685)


- Various fixes, mostly small bugs.
- Removed jupyterlab dependency.
- Resolved some version-related issues leading to problems with interactive plots.
- Cleaned up the source code a bit. 

`kval` is in active development.

___
