# kval


![image](https://raw.githubusercontent.com/npiocean/kval/master/graphics/kval_banner_text.png)




```{toctree}
:maxdepth: 2

usage/using_kval
examples/examples
other/about

```
