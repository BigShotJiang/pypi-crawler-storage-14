
# Installation


Conda [^tag]:

```
conda install -c npiocean -c conda-forge kval
```

Pip:

```
pip install kval
```
[^tag]: We aim to distribute this on [conda-forge](https://conda-forge.org/) eventually. Since some dependent packages are not available there, we are using the [anaconda.org NPIOcean channel](https://anaconda.org/npiocean) for now.

