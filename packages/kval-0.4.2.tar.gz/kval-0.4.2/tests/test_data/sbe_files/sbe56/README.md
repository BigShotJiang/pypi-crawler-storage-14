`SBE56-1232_test.csv`:
    Copy of the file `NAN-22_2022-2024_168m_SBE56-1232.csv` file from the Nansen-22 mooring where I have chopped out most of the data rows (original file size was 6.9M)

`SBE05602355_NABOS-test.csv `:
    Copy of the file `SBE05602355_2015-09-04_2.csv`
     obtained from https://www.arcticdata.io/catalog/view/resource_map_urn%3Auuid%3Adb71ae9a-d373-4752-b438-dc928a174025 (from NABOS mooring n1_5a, 2013-2015). I have chopped out most of the data rows (original file size was 2M).
