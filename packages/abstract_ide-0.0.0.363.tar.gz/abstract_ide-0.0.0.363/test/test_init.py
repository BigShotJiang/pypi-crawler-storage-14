from src import *
get_for_all_tabs("/home/flerb/Documents/pythonTools/modules/src/modules/abstract_ide/src/abstract_ide/consoles")
