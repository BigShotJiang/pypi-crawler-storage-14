from src import startClipitConsole
startClipitConsole()
