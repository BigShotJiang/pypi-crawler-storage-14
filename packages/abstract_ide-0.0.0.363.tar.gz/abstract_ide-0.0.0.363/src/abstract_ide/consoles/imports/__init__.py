##from abstract_paths import ContentFinderConsole
##from abstract_gui.QT6 import launcherWindowTab,windowManagerConsole, QMainWindow,QTabWidget
##from abstract_apis import apiTab
##from abstract_clipit import clipitTab
##from abstract_react import reactRunnerConsole
from abstract_gui.QT6 import *
from abstract_gui.QT6.utils.log_utils import *
#defaultRoot = '/mnt/24T/consolidated/gts'
#mapPath = '/home/computron/Desktop/New Folder 11/newit/DIRS_JS.json'
#startImageViewerConsole(defaultRoot=defaultRoot,mapPath=mapPath)
from abstract_gui.QT6 import attach_textedit_to_logs,get_log_file_path
