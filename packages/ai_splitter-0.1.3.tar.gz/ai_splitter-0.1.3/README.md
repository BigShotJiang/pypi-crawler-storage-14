# 🧠 AI Splitter
### *AI-Based CO-Wise Mark Splitter with Excel Export for Assessments*
**By Sathish Ramanujam** • <https://professor-sathish.github.io/>

---

## 📌 Overview

**AI Splitter** is a simple and powerful tool for generating **Course Outcome (CO)–wise mark split-ups** for assessments.
It uses **AI-powered logic** to automatically distribute marks based on your inputs and exports clean, formatted **Excel split-up sheets** instantly.

This tool is built for:

- Faculty members  
- Assessment coordinators  
- Examination cell teams  
- Academic departments  

The entire app runs in a **Streamlit UI** and exposes a **single command**:

```
ai-splitter
```

which opens the app immediately.

---

## 🚀 Features

- ✔ Automatic **CO-wise mark splitting**  
- ✔ Instant **Excel export** (openpyxl)  
- ✔ Clean Streamlit UI  
- ✔ Works for all assessments (CIA, Assignment, Model, etc.)  
- ✔ Lightweight & fast  
- ✔ No configuration needed  
- ✔ 100% offline after installation  

---

## 📥 Installation

### 1. Install via pip

```bash
pip install ai-splitter
```

### 2. Run the app

```bash
ai-splitter
```

This launches your browser with the full Streamlit UI.

---

## ▶️ Usage

Once the app launches:

1. Enter Assessment Name  
2. Enter Total Marks  
3. Enter Required CO Split Breakdown  
4. Click **Generate**  
5. Download the Excel output  

Simple, fast, accurate.

---

## 🖥️ Launching the App Manually (Optional)

If you want to run the app manually:

```bash
streamlit run ai_splitter/app.py
```

OR using Python:

```bash
python -m streamlit run ai_splitter/app.py
```

---

## ⚠️ Windows Users — Important (PATH Fix)

If you installed Python from the **Microsoft Store**, the `ai-splitter` command may not work immediately.

You may see:

```
'ai-splitter' is not recognized as an internal or external command
```

This happens because Microsoft Store Python does **not** add the Scripts folder to PATH.

### ✔ Fix

Add this folder to your PATH:

```
%LocalAppData%\Packages\PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0\LocalCache\local-packages\Python311\Scripts
```

#### Steps:

1. Press **Win + R** → type `sysdm.cpl` → Enter  
2. Go to **Advanced** → **Environment Variables**  
3. Under **User variables**, select **Path**  
4. Click **Edit** → **New**  
5. Paste:

```
%LocalAppData%\Packages\PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0\LocalCache\local-packages\Python311\Scripts
```

6. Save → close CMD → open new CMD  
7. Run:

```
ai-splitter
```

### ✔ Recommended Alternative (Best Practice)

Install Python from:

https://www.python.org/downloads/

Enable:

- **Add Python to PATH**  
- **Install for all users**

---

## 🧩 CLI Command Reference

### Launch the application:

```bash
ai-splitter
```

### Show help:

```bash
ai-splitter --help
```

---

## 📦 Version

Current version: **0.1.2**

---

## 👨‍💻 Developer

**AI Splitter**  
Created by **Sathish Ramanujam**  
Website: <https://professor-sathish.github.io/>  
Department of Information Technology, KGiSL Institute of Technology  

---

## 🔖 License

MIT License  
Free for academic and educational use.

---

## ❤️ Acknowledgements

- Built with **Python 3.9+**  
- UI powered by **Streamlit**  
- Excel generation using **openpyxl**  
- Developed with love for the academic community  
