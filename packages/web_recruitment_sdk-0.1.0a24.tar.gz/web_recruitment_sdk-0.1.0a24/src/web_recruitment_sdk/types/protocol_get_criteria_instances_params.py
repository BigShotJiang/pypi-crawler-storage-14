# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ProtocolGetCriteriaInstancesParams"]


class ProtocolGetCriteriaInstancesParams(TypedDict, total=False):
    trially_patient_id: Required[str]
