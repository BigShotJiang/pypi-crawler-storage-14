# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["ConcurrencyReleaseSlotResponse"]


class ConcurrencyReleaseSlotResponse(BaseModel):
    current_count: int
    """Current number of concurrent operations after release"""

    success: bool
    """Whether the slot was released"""

    tenant_id: str
    """The tenant ID"""
