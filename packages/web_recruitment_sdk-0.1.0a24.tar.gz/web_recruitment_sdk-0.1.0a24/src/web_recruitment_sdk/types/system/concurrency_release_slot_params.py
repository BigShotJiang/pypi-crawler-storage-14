# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ConcurrencyReleaseSlotParams"]


class ConcurrencyReleaseSlotParams(TypedDict, total=False):
    tenant_id: Required[str]
    """The tenant ID"""

    concurrency_limit: int
