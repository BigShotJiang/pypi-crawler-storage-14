# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["ConcurrencyAcquireSlotResponse"]


class ConcurrencyAcquireSlotResponse(BaseModel):
    current_count: int
    """Current number of concurrent operations"""

    limit: int
    """Maximum concurrency limit"""

    success: bool
    """Whether the slot was acquired"""

    tenant_id: str
    """The tenant ID"""
