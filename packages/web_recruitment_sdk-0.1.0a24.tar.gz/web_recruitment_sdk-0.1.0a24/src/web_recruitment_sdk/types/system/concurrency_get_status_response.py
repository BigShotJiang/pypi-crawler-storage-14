# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["ConcurrencyGetStatusResponse"]


class ConcurrencyGetStatusResponse(BaseModel):
    available_slots: int
    """Number of available slots"""

    current_count: int
    """Current number of concurrent operations"""

    limit: int
    """Maximum concurrency limit"""

    tenant_id: str
    """The tenant ID"""
