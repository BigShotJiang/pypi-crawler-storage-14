# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["CampaignGetAnalyticsParams"]


class CampaignGetAnalyticsParams(TypedDict, total=False):
    time_range: Annotated[Literal["7d", "30d", "all"], PropertyInfo(alias="timeRange")]
