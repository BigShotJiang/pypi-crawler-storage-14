# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import date, datetime
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from ..._utils import PropertyInfo
from ..._models import BaseModel

__all__ = [
    "CandidateCampaignCancelResponse",
    "Candidate",
    "CandidatePerson",
    "CandidateSite",
    "OutreachAttempt",
    "OutreachAttemptPhoneCallAttemptRead",
    "OutreachAttemptPhoneCallAttemptReadOutreachAction",
    "OutreachAttemptPhoneCallAttemptReadOutreachActionPhoneCallActionRead",
    "OutreachAttemptPhoneCallAttemptReadOutreachActionSMSActionRead",
    "OutreachAttemptSMSAttemptRead",
    "OutreachAttemptSMSAttemptReadOutreachAction",
    "OutreachAttemptSMSAttemptReadOutreachActionPhoneCallActionRead",
    "OutreachAttemptSMSAttemptReadOutreachActionSMSActionRead",
]


class CandidatePerson(BaseModel):
    id: int

    dob: Optional[date] = None

    email: Optional[str] = None

    family_name: str = FieldInfo(alias="familyName")

    given_name: str = FieldInfo(alias="givenName")

    cell_phone: Optional[str] = FieldInfo(alias="cellPhone", default=None)

    city: Optional[str] = None

    do_not_call: Optional[bool] = FieldInfo(alias="doNotCall", default=None)

    home_phone: Optional[str] = FieldInfo(alias="homePhone", default=None)

    middle_name: Optional[str] = FieldInfo(alias="middleName", default=None)

    preferred_language: Optional[Literal["ENGLISH", "SPANISH"]] = FieldInfo(alias="preferredLanguage", default=None)

    source: Optional[Literal["EHR", "CSV"]] = None

    state: Optional[
        Literal[
            "AL",
            "AK",
            "AS",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "DC",
            "FL",
            "FM",
            "GA",
            "GU",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MH",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "MP",
            "OH",
            "OK",
            "OR",
            "PW",
            "PA",
            "PR",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "TT",
            "UT",
            "VT",
            "VA",
            "VI",
            "WA",
            "WV",
            "WI",
            "WY",
        ]
    ] = None
    """US state codes and territories."""

    street_address: Optional[str] = FieldInfo(alias="streetAddress", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)


class CandidateSite(BaseModel):
    name: str

    id: Optional[int] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    is_on_carequality: Optional[bool] = FieldInfo(alias="isOnCarequality", default=None)

    latitude: Optional[float] = None

    longitude: Optional[float] = None

    trially_site_id: Optional[str] = FieldInfo(alias="triallySiteId", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)


class Candidate(BaseModel):
    id: int

    person_id: int = FieldInfo(alias="personId")

    site_id: int = FieldInfo(alias="siteId")

    person: Optional[CandidatePerson] = None

    site: Optional[CandidateSite] = None


class OutreachAttemptPhoneCallAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class OutreachAttemptPhoneCallAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


OutreachAttemptPhoneCallAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        OutreachAttemptPhoneCallAttemptReadOutreachActionPhoneCallActionRead,
        OutreachAttemptPhoneCallAttemptReadOutreachActionSMSActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class OutreachAttemptPhoneCallAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["PHONE_CALL"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    caller_phone_number: Optional[str] = FieldInfo(alias="callerPhoneNumber", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    duration_seconds: Optional[int] = FieldInfo(alias="durationSeconds", default=None)

    outreach_actions: Optional[List[OutreachAttemptPhoneCallAttemptReadOutreachAction]] = FieldInfo(
        alias="outreachActions", default=None
    )

    recipient_phone_number: Optional[str] = FieldInfo(alias="recipientPhoneNumber", default=None)

    transcript_url: Optional[str] = FieldInfo(alias="transcriptUrl", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class OutreachAttemptSMSAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class OutreachAttemptSMSAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


OutreachAttemptSMSAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        OutreachAttemptSMSAttemptReadOutreachActionPhoneCallActionRead,
        OutreachAttemptSMSAttemptReadOutreachActionSMSActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class OutreachAttemptSMSAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["SMS"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    outreach_actions: Optional[List[OutreachAttemptSMSAttemptReadOutreachAction]] = FieldInfo(
        alias="outreachActions", default=None
    )

    recipient_phone_number: Optional[str] = FieldInfo(alias="recipientPhoneNumber", default=None)

    sender_phone_number: Optional[str] = FieldInfo(alias="senderPhoneNumber", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


OutreachAttempt: TypeAlias = Annotated[
    Union[OutreachAttemptPhoneCallAttemptRead, OutreachAttemptSMSAttemptRead],
    PropertyInfo(discriminator="attempt_type"),
]


class CandidateCampaignCancelResponse(BaseModel):
    id: int

    campaign_id: int = FieldInfo(alias="campaignId")

    candidate_id: int = FieldInfo(alias="candidateId")

    candidate: Optional[Candidate] = None

    outreach_attempts: Optional[List[OutreachAttempt]] = FieldInfo(alias="outreachAttempts", default=None)

    status: Optional[Literal["NOT_STARTED", "IN_PROGRESS", "SUCCESSFUL", "UNSUCCESSFUL"]] = None
    """Candidate's journey state within a campaign"""

    workflow_id: Optional[str] = FieldInfo(alias="workflowId", default=None)
