# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["CampaignStartParams"]


class CampaignStartParams(TypedDict, total=False):
    use_temporal: bool
    """Whether to use Temporal to restart the campaign"""
