# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["CampaignGetAnalyticsResponse", "Data", "DataBreakdown", "Metadata", "MetadataKpis"]


class DataBreakdown(BaseModel):
    count: int

    label: str

    metadata: Optional[object] = None


class Data(BaseModel):
    label: str

    total: int

    breakdown: Optional[List[DataBreakdown]] = None


class MetadataKpis(BaseModel):
    conversion_rate: float = FieldInfo(alias="conversionRate")

    cost_per_successful_outreach: float = FieldInfo(alias="costPerSuccessfulOutreach")

    pickup_rate: float = FieldInfo(alias="pickupRate")

    total_calls: int = FieldInfo(alias="totalCalls")


class Metadata(BaseModel):
    kpis: MetadataKpis
    """Campaign analytics KPIs"""


class CampaignGetAnalyticsResponse(BaseModel):
    data: List[Data]

    metadata: Metadata
    """Metadata structure for campaign analytics response"""

    total: int
