# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["WorkflowSignalParams"]


class WorkflowSignalParams(TypedDict, total=False):
    signal_name: Required[str]
    """Name of the signal to send"""

    body: Optional[object]
