# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["AccountUpdateParams"]


class AccountUpdateParams(TypedDict, total=False):
    has_carequality_sites: Annotated[Optional[bool], PropertyInfo(alias="hasCarequalitySites")]

    has_connect_product_enabled: Annotated[Optional[bool], PropertyInfo(alias="hasConnectProductEnabled")]

    has_match_product_enabled: Annotated[Optional[bool], PropertyInfo(alias="hasMatchProductEnabled")]
