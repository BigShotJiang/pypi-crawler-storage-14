# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date
from typing_extensions import Literal

import httpx

from .persons import (
    PersonsResource,
    AsyncPersonsResource,
    PersonsResourceWithRawResponse,
    AsyncPersonsResourceWithRawResponse,
    PersonsResourceWithStreamingResponse,
    AsyncPersonsResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.outreach import campaign_start_params, campaign_create_params, campaign_get_analytics_params
from ....types.outreach.campaign_list_response import CampaignListResponse
from ....types.outreach.campaign_pause_response import CampaignPauseResponse
from ....types.outreach.campaign_start_response import CampaignStartResponse
from ....types.outreach.campaign_create_response import CampaignCreateResponse
from ....types.outreach.campaign_get_analytics_response import CampaignGetAnalyticsResponse
from ....types.outreach.campaign_get_candidates_response import CampaignGetCandidatesResponse

__all__ = ["CampaignsResource", "AsyncCampaignsResource"]


class CampaignsResource(SyncAPIResource):
    @cached_property
    def persons(self) -> PersonsResource:
        return PersonsResource(self._client)

    @cached_property
    def with_raw_response(self) -> CampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CampaignsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        action_type: Literal["PHONE_CALL", "SMS"],
        booking_url: str,
        candidate_ids: Iterable[int],
        hours_between_attempts: int,
        max_attempts_per_candidate: int,
        name: str,
        outreach_hours_end: int,
        outreach_hours_start: int,
        start_date: Union[str, date],
        use_temporal: bool | Omit = omit,
        end_date: Union[str, date, None] | Omit = omit,
        principal_investigator: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignCreateResponse:
        """
        Create a new outreach campaign with candidate validation.

        Campaign dates (start_date, end_date) specify day boundaries - the first and
        last days when outreach can occur. Actual outreach times are determined by
        outreach_hours_start/end in each candidate's local timezone.

        Args:
          action_type: Type of outreach action to perform

          candidate_ids: List of candidate IDs to include in campaign

          hours_between_attempts: Minimum hours between outreach attempts

          max_attempts_per_candidate: Maximum number of outreach attempts per candidate

          outreach_hours_end: End hour for outreach in candidate's local timezone (0-23)

          outreach_hours_start: Start hour for outreach in candidate's local timezone (0-23)

          start_date: First day of the campaign (YYYY-MM-DD)

          use_temporal: Whether to use Temporal to start the campaign

          end_date: Last day of the campaign (YYYY-MM-DD)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/outreach/campaigns",
            body=maybe_transform(
                {
                    "action_type": action_type,
                    "booking_url": booking_url,
                    "candidate_ids": candidate_ids,
                    "hours_between_attempts": hours_between_attempts,
                    "max_attempts_per_candidate": max_attempts_per_candidate,
                    "name": name,
                    "outreach_hours_end": outreach_hours_end,
                    "outreach_hours_start": outreach_hours_start,
                    "start_date": start_date,
                    "end_date": end_date,
                    "principal_investigator": principal_investigator,
                },
                campaign_create_params.CampaignCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"use_temporal": use_temporal}, campaign_create_params.CampaignCreateParams),
            ),
            cast_to=CampaignCreateResponse,
        )

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignListResponse:
        """Get all outreach campaigns"""
        return self._get(
            "/outreach/campaigns",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignListResponse,
        )

    def delete(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete an outreach campaign, cancelling all in-progress candidate workflows

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/outreach/campaigns/{campaign_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get_analytics(
        self,
        campaign_id: int,
        *,
        time_range: Literal["7d", "30d", "all"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetAnalyticsResponse:
        """
        Get analytics data for a campaign.

        Returns funnel stages and KPIs for the specified time range. Currently supports
        dormant-lead campaign workflow only.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            f"/outreach/campaigns/{campaign_id}/analytics",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"time_range": time_range}, campaign_get_analytics_params.CampaignGetAnalyticsParams
                ),
            ),
            cast_to=CampaignGetAnalyticsResponse,
        )

    def get_candidates(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetCandidatesResponse:
        """
        Get all candidate campaigns for a campaign with candidate info and outreach
        attempts

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            f"/outreach/campaigns/{campaign_id}/candidates",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignGetCandidatesResponse,
        )

    def pause(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignPauseResponse:
        """
        Pause an outreach campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            f"/outreach/campaigns/{campaign_id}/pause",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignPauseResponse,
        )

    def start(
        self,
        campaign_id: int,
        *,
        use_temporal: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignStartResponse:
        """
        Start or resume an outreach campaign (NOT_STARTED or PAUSED).

        For Temporal campaigns (use_temporal=True) with PAUSED status, this will restart
        workflows for all NOT_STARTED candidates, calculating remaining attempts
        dynamically.

        Args:
          use_temporal: Whether to use Temporal to restart the campaign

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            f"/outreach/campaigns/{campaign_id}/start",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"use_temporal": use_temporal}, campaign_start_params.CampaignStartParams),
            ),
            cast_to=CampaignStartResponse,
        )


class AsyncCampaignsResource(AsyncAPIResource):
    @cached_property
    def persons(self) -> AsyncPersonsResource:
        return AsyncPersonsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncCampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCampaignsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        action_type: Literal["PHONE_CALL", "SMS"],
        booking_url: str,
        candidate_ids: Iterable[int],
        hours_between_attempts: int,
        max_attempts_per_candidate: int,
        name: str,
        outreach_hours_end: int,
        outreach_hours_start: int,
        start_date: Union[str, date],
        use_temporal: bool | Omit = omit,
        end_date: Union[str, date, None] | Omit = omit,
        principal_investigator: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignCreateResponse:
        """
        Create a new outreach campaign with candidate validation.

        Campaign dates (start_date, end_date) specify day boundaries - the first and
        last days when outreach can occur. Actual outreach times are determined by
        outreach_hours_start/end in each candidate's local timezone.

        Args:
          action_type: Type of outreach action to perform

          candidate_ids: List of candidate IDs to include in campaign

          hours_between_attempts: Minimum hours between outreach attempts

          max_attempts_per_candidate: Maximum number of outreach attempts per candidate

          outreach_hours_end: End hour for outreach in candidate's local timezone (0-23)

          outreach_hours_start: Start hour for outreach in candidate's local timezone (0-23)

          start_date: First day of the campaign (YYYY-MM-DD)

          use_temporal: Whether to use Temporal to start the campaign

          end_date: Last day of the campaign (YYYY-MM-DD)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/outreach/campaigns",
            body=await async_maybe_transform(
                {
                    "action_type": action_type,
                    "booking_url": booking_url,
                    "candidate_ids": candidate_ids,
                    "hours_between_attempts": hours_between_attempts,
                    "max_attempts_per_candidate": max_attempts_per_candidate,
                    "name": name,
                    "outreach_hours_end": outreach_hours_end,
                    "outreach_hours_start": outreach_hours_start,
                    "start_date": start_date,
                    "end_date": end_date,
                    "principal_investigator": principal_investigator,
                },
                campaign_create_params.CampaignCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"use_temporal": use_temporal}, campaign_create_params.CampaignCreateParams
                ),
            ),
            cast_to=CampaignCreateResponse,
        )

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignListResponse:
        """Get all outreach campaigns"""
        return await self._get(
            "/outreach/campaigns",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignListResponse,
        )

    async def delete(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete an outreach campaign, cancelling all in-progress candidate workflows

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/outreach/campaigns/{campaign_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get_analytics(
        self,
        campaign_id: int,
        *,
        time_range: Literal["7d", "30d", "all"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetAnalyticsResponse:
        """
        Get analytics data for a campaign.

        Returns funnel stages and KPIs for the specified time range. Currently supports
        dormant-lead campaign workflow only.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            f"/outreach/campaigns/{campaign_id}/analytics",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"time_range": time_range}, campaign_get_analytics_params.CampaignGetAnalyticsParams
                ),
            ),
            cast_to=CampaignGetAnalyticsResponse,
        )

    async def get_candidates(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetCandidatesResponse:
        """
        Get all candidate campaigns for a campaign with candidate info and outreach
        attempts

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            f"/outreach/campaigns/{campaign_id}/candidates",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignGetCandidatesResponse,
        )

    async def pause(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignPauseResponse:
        """
        Pause an outreach campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            f"/outreach/campaigns/{campaign_id}/pause",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignPauseResponse,
        )

    async def start(
        self,
        campaign_id: int,
        *,
        use_temporal: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignStartResponse:
        """
        Start or resume an outreach campaign (NOT_STARTED or PAUSED).

        For Temporal campaigns (use_temporal=True) with PAUSED status, this will restart
        workflows for all NOT_STARTED candidates, calculating remaining attempts
        dynamically.

        Args:
          use_temporal: Whether to use Temporal to restart the campaign

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            f"/outreach/campaigns/{campaign_id}/start",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"use_temporal": use_temporal}, campaign_start_params.CampaignStartParams
                ),
            ),
            cast_to=CampaignStartResponse,
        )


class CampaignsResourceWithRawResponse:
    def __init__(self, campaigns: CampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = to_raw_response_wrapper(
            campaigns.create,
        )
        self.list = to_raw_response_wrapper(
            campaigns.list,
        )
        self.delete = to_raw_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = to_raw_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = to_raw_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = to_raw_response_wrapper(
            campaigns.pause,
        )
        self.start = to_raw_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> PersonsResourceWithRawResponse:
        return PersonsResourceWithRawResponse(self._campaigns.persons)


class AsyncCampaignsResourceWithRawResponse:
    def __init__(self, campaigns: AsyncCampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = async_to_raw_response_wrapper(
            campaigns.create,
        )
        self.list = async_to_raw_response_wrapper(
            campaigns.list,
        )
        self.delete = async_to_raw_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = async_to_raw_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = async_to_raw_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = async_to_raw_response_wrapper(
            campaigns.pause,
        )
        self.start = async_to_raw_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> AsyncPersonsResourceWithRawResponse:
        return AsyncPersonsResourceWithRawResponse(self._campaigns.persons)


class CampaignsResourceWithStreamingResponse:
    def __init__(self, campaigns: CampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = to_streamed_response_wrapper(
            campaigns.create,
        )
        self.list = to_streamed_response_wrapper(
            campaigns.list,
        )
        self.delete = to_streamed_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = to_streamed_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = to_streamed_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = to_streamed_response_wrapper(
            campaigns.pause,
        )
        self.start = to_streamed_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> PersonsResourceWithStreamingResponse:
        return PersonsResourceWithStreamingResponse(self._campaigns.persons)


class AsyncCampaignsResourceWithStreamingResponse:
    def __init__(self, campaigns: AsyncCampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = async_to_streamed_response_wrapper(
            campaigns.create,
        )
        self.list = async_to_streamed_response_wrapper(
            campaigns.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = async_to_streamed_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = async_to_streamed_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = async_to_streamed_response_wrapper(
            campaigns.pause,
        )
        self.start = async_to_streamed_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> AsyncPersonsResourceWithStreamingResponse:
        return AsyncPersonsResourceWithStreamingResponse(self._campaigns.persons)
