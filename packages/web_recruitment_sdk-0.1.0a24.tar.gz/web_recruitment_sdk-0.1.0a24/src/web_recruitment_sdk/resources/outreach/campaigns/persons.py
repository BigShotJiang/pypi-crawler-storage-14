# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ...._types import Body, Query, Headers, NotGiven, not_given
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.outreach.campaigns.person_get_actions_response import PersonGetActionsResponse
from ....types.outreach.campaigns.person_get_attempts_response import PersonGetAttemptsResponse

__all__ = ["PersonsResource", "AsyncPersonsResource"]


class PersonsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PersonsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return PersonsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PersonsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return PersonsResourceWithStreamingResponse(self)

    def get_actions(
        self,
        person_id: int,
        *,
        campaign_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonGetActionsResponse:
        """
        Get all outreach actions for a person in a campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            f"/outreach/campaigns/{campaign_id}/persons/{person_id}/actions",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonGetActionsResponse,
        )

    def get_attempts(
        self,
        person_id: int,
        *,
        campaign_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonGetAttemptsResponse:
        """
        Get all outreach attempts for a person in a campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            f"/outreach/campaigns/{campaign_id}/persons/{person_id}/attempts",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonGetAttemptsResponse,
        )


class AsyncPersonsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPersonsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncPersonsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPersonsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncPersonsResourceWithStreamingResponse(self)

    async def get_actions(
        self,
        person_id: int,
        *,
        campaign_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonGetActionsResponse:
        """
        Get all outreach actions for a person in a campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            f"/outreach/campaigns/{campaign_id}/persons/{person_id}/actions",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonGetActionsResponse,
        )

    async def get_attempts(
        self,
        person_id: int,
        *,
        campaign_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonGetAttemptsResponse:
        """
        Get all outreach attempts for a person in a campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            f"/outreach/campaigns/{campaign_id}/persons/{person_id}/attempts",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonGetAttemptsResponse,
        )


class PersonsResourceWithRawResponse:
    def __init__(self, persons: PersonsResource) -> None:
        self._persons = persons

        self.get_actions = to_raw_response_wrapper(
            persons.get_actions,
        )
        self.get_attempts = to_raw_response_wrapper(
            persons.get_attempts,
        )


class AsyncPersonsResourceWithRawResponse:
    def __init__(self, persons: AsyncPersonsResource) -> None:
        self._persons = persons

        self.get_actions = async_to_raw_response_wrapper(
            persons.get_actions,
        )
        self.get_attempts = async_to_raw_response_wrapper(
            persons.get_attempts,
        )


class PersonsResourceWithStreamingResponse:
    def __init__(self, persons: PersonsResource) -> None:
        self._persons = persons

        self.get_actions = to_streamed_response_wrapper(
            persons.get_actions,
        )
        self.get_attempts = to_streamed_response_wrapper(
            persons.get_attempts,
        )


class AsyncPersonsResourceWithStreamingResponse:
    def __init__(self, persons: AsyncPersonsResource) -> None:
        self._persons = persons

        self.get_actions = async_to_streamed_response_wrapper(
            persons.get_actions,
        )
        self.get_attempts = async_to_streamed_response_wrapper(
            persons.get_attempts,
        )
