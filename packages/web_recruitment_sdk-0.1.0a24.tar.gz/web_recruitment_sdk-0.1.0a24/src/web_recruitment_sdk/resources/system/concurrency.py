# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.system import (
    concurrency_get_status_params,
    concurrency_acquire_slot_params,
    concurrency_release_slot_params,
)
from ...types.system.concurrency_get_status_response import ConcurrencyGetStatusResponse
from ...types.system.concurrency_acquire_slot_response import ConcurrencyAcquireSlotResponse
from ...types.system.concurrency_release_slot_response import ConcurrencyReleaseSlotResponse

__all__ = ["ConcurrencyResource", "AsyncConcurrencyResource"]


class ConcurrencyResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ConcurrencyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return ConcurrencyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ConcurrencyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return ConcurrencyResourceWithStreamingResponse(self)

    def acquire_slot(
        self,
        *,
        tenant_id: str,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyAcquireSlotResponse:
        """
        Acquire a concurrency slot for a tenant.

        Atomically checks and increments the tenant's concurrency counter. Returns an
        error if the tenant has reached their concurrency limit.

        Args:
          tenant_id: The tenant ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/system/concurrency/acquire",
            body=maybe_transform(
                {"tenant_id": tenant_id}, concurrency_acquire_slot_params.ConcurrencyAcquireSlotParams
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"concurrency_limit": concurrency_limit},
                    concurrency_acquire_slot_params.ConcurrencyAcquireSlotParams,
                ),
            ),
            cast_to=ConcurrencyAcquireSlotResponse,
        )

    def get_status(
        self,
        tenant_id: str,
        *,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyGetStatusResponse:
        """
        Get the current concurrency status for a tenant.

        Returns the current count, limit, and available slots.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_id:
            raise ValueError(f"Expected a non-empty value for `tenant_id` but received {tenant_id!r}")
        return self._get(
            f"/system/concurrency/status/{tenant_id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"concurrency_limit": concurrency_limit}, concurrency_get_status_params.ConcurrencyGetStatusParams
                ),
            ),
            cast_to=ConcurrencyGetStatusResponse,
        )

    def release_slot(
        self,
        *,
        tenant_id: str,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyReleaseSlotResponse:
        """
        Release a concurrency slot for a tenant.

        Atomically decrements the tenant's concurrency counter. Safe to call even if the
        counter is already at 0.

        Args:
          tenant_id: The tenant ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/system/concurrency/release",
            body=maybe_transform(
                {"tenant_id": tenant_id}, concurrency_release_slot_params.ConcurrencyReleaseSlotParams
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"concurrency_limit": concurrency_limit},
                    concurrency_release_slot_params.ConcurrencyReleaseSlotParams,
                ),
            ),
            cast_to=ConcurrencyReleaseSlotResponse,
        )


class AsyncConcurrencyResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncConcurrencyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncConcurrencyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncConcurrencyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncConcurrencyResourceWithStreamingResponse(self)

    async def acquire_slot(
        self,
        *,
        tenant_id: str,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyAcquireSlotResponse:
        """
        Acquire a concurrency slot for a tenant.

        Atomically checks and increments the tenant's concurrency counter. Returns an
        error if the tenant has reached their concurrency limit.

        Args:
          tenant_id: The tenant ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/system/concurrency/acquire",
            body=await async_maybe_transform(
                {"tenant_id": tenant_id}, concurrency_acquire_slot_params.ConcurrencyAcquireSlotParams
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"concurrency_limit": concurrency_limit},
                    concurrency_acquire_slot_params.ConcurrencyAcquireSlotParams,
                ),
            ),
            cast_to=ConcurrencyAcquireSlotResponse,
        )

    async def get_status(
        self,
        tenant_id: str,
        *,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyGetStatusResponse:
        """
        Get the current concurrency status for a tenant.

        Returns the current count, limit, and available slots.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_id:
            raise ValueError(f"Expected a non-empty value for `tenant_id` but received {tenant_id!r}")
        return await self._get(
            f"/system/concurrency/status/{tenant_id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"concurrency_limit": concurrency_limit}, concurrency_get_status_params.ConcurrencyGetStatusParams
                ),
            ),
            cast_to=ConcurrencyGetStatusResponse,
        )

    async def release_slot(
        self,
        *,
        tenant_id: str,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyReleaseSlotResponse:
        """
        Release a concurrency slot for a tenant.

        Atomically decrements the tenant's concurrency counter. Safe to call even if the
        counter is already at 0.

        Args:
          tenant_id: The tenant ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/system/concurrency/release",
            body=await async_maybe_transform(
                {"tenant_id": tenant_id}, concurrency_release_slot_params.ConcurrencyReleaseSlotParams
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"concurrency_limit": concurrency_limit},
                    concurrency_release_slot_params.ConcurrencyReleaseSlotParams,
                ),
            ),
            cast_to=ConcurrencyReleaseSlotResponse,
        )


class ConcurrencyResourceWithRawResponse:
    def __init__(self, concurrency: ConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire_slot = to_raw_response_wrapper(
            concurrency.acquire_slot,
        )
        self.get_status = to_raw_response_wrapper(
            concurrency.get_status,
        )
        self.release_slot = to_raw_response_wrapper(
            concurrency.release_slot,
        )


class AsyncConcurrencyResourceWithRawResponse:
    def __init__(self, concurrency: AsyncConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire_slot = async_to_raw_response_wrapper(
            concurrency.acquire_slot,
        )
        self.get_status = async_to_raw_response_wrapper(
            concurrency.get_status,
        )
        self.release_slot = async_to_raw_response_wrapper(
            concurrency.release_slot,
        )


class ConcurrencyResourceWithStreamingResponse:
    def __init__(self, concurrency: ConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire_slot = to_streamed_response_wrapper(
            concurrency.acquire_slot,
        )
        self.get_status = to_streamed_response_wrapper(
            concurrency.get_status,
        )
        self.release_slot = to_streamed_response_wrapper(
            concurrency.release_slot,
        )


class AsyncConcurrencyResourceWithStreamingResponse:
    def __init__(self, concurrency: AsyncConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire_slot = async_to_streamed_response_wrapper(
            concurrency.acquire_slot,
        )
        self.get_status = async_to_streamed_response_wrapper(
            concurrency.get_status,
        )
        self.release_slot = async_to_streamed_response_wrapper(
            concurrency.release_slot,
        )
