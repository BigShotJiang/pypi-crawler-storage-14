# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Literal

import httpx

from .schedule import (
    ScheduleResource,
    AsyncScheduleResource,
    ScheduleResourceWithRawResponse,
    AsyncScheduleResourceWithRawResponse,
    ScheduleResourceWithStreamingResponse,
    AsyncScheduleResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.workflows import greeting_start_params, greeting_execute_params
from ....types.workflows.greeting_start_response import GreetingStartResponse

__all__ = ["GreetingResource", "AsyncGreetingResource"]


class GreetingResource(SyncAPIResource):
    @cached_property
    def schedule(self) -> ScheduleResource:
        return ScheduleResource(self._client)

    @cached_property
    def with_raw_response(self) -> GreetingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return GreetingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> GreetingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return GreetingResourceWithStreamingResponse(self)

    def execute(
        self,
        *,
        language: str,
        name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """Execute a greeting workflow and wait for its result.

        This will block until the
        workflow completes.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/workflows/greeting/execute",
            body=maybe_transform(
                {
                    "language": language,
                    "name": name,
                },
                greeting_execute_params.GreetingExecuteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=str,
        )

    def start(
        self,
        *,
        language: str,
        name: str,
        execute_at: Union[str, datetime, None] | Omit = omit,
        timezone: Literal[
            "US/Eastern",
            "US/Central",
            "US/Mountain",
            "US/Pacific",
            "US/Alaska",
            "US/Hawaii",
            "US/Arizona",
            "America/New_York",
            "America/Chicago",
            "America/Denver",
            "America/Los_Angeles",
            "America/Phoenix",
            "America/Anchorage",
            "America/Honolulu",
            "America/Toronto",
            "America/Mexico_City",
            "America/Sao_Paulo",
            "America/Buenos_Aires",
            "Europe/London",
            "Europe/Paris",
            "Europe/Berlin",
            "Europe/Madrid",
            "Europe/Rome",
            "Europe/Amsterdam",
            "Europe/Brussels",
            "Europe/Vienna",
            "Europe/Zurich",
            "Europe/Stockholm",
            "Europe/Moscow",
            "Europe/Istanbul",
            "Asia/Tokyo",
            "Asia/Shanghai",
            "Asia/Hong_Kong",
            "Asia/Singapore",
            "Asia/Seoul",
            "Asia/Kolkata",
            "Asia/Dubai",
            "Asia/Bangkok",
            "Asia/Jakarta",
            "Asia/Manila",
            "Australia/Sydney",
            "Australia/Melbourne",
            "Australia/Perth",
            "Pacific/Auckland",
            "UTC",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GreetingStartResponse:
        """Start a greeting workflow without waiting for its result.

        Returns the workflow
        ID immediately.

        Examples:

        - Start immediately: No execute_at parameter
        - Start at specific time: execute_at=2025-12-25T09:00:00&timezone=US_CENTRAL

        Args:
          execute_at: Specific datetime to execute workflow (format: 2025-12-25T09:00:00)

          timezone: IANA timezone for execute_at

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/workflows/greeting/start",
            body=maybe_transform(
                {
                    "language": language,
                    "name": name,
                },
                greeting_start_params.GreetingStartParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "execute_at": execute_at,
                        "timezone": timezone,
                    },
                    greeting_start_params.GreetingStartParams,
                ),
            ),
            cast_to=GreetingStartResponse,
        )


class AsyncGreetingResource(AsyncAPIResource):
    @cached_property
    def schedule(self) -> AsyncScheduleResource:
        return AsyncScheduleResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncGreetingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncGreetingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncGreetingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncGreetingResourceWithStreamingResponse(self)

    async def execute(
        self,
        *,
        language: str,
        name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """Execute a greeting workflow and wait for its result.

        This will block until the
        workflow completes.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/workflows/greeting/execute",
            body=await async_maybe_transform(
                {
                    "language": language,
                    "name": name,
                },
                greeting_execute_params.GreetingExecuteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=str,
        )

    async def start(
        self,
        *,
        language: str,
        name: str,
        execute_at: Union[str, datetime, None] | Omit = omit,
        timezone: Literal[
            "US/Eastern",
            "US/Central",
            "US/Mountain",
            "US/Pacific",
            "US/Alaska",
            "US/Hawaii",
            "US/Arizona",
            "America/New_York",
            "America/Chicago",
            "America/Denver",
            "America/Los_Angeles",
            "America/Phoenix",
            "America/Anchorage",
            "America/Honolulu",
            "America/Toronto",
            "America/Mexico_City",
            "America/Sao_Paulo",
            "America/Buenos_Aires",
            "Europe/London",
            "Europe/Paris",
            "Europe/Berlin",
            "Europe/Madrid",
            "Europe/Rome",
            "Europe/Amsterdam",
            "Europe/Brussels",
            "Europe/Vienna",
            "Europe/Zurich",
            "Europe/Stockholm",
            "Europe/Moscow",
            "Europe/Istanbul",
            "Asia/Tokyo",
            "Asia/Shanghai",
            "Asia/Hong_Kong",
            "Asia/Singapore",
            "Asia/Seoul",
            "Asia/Kolkata",
            "Asia/Dubai",
            "Asia/Bangkok",
            "Asia/Jakarta",
            "Asia/Manila",
            "Australia/Sydney",
            "Australia/Melbourne",
            "Australia/Perth",
            "Pacific/Auckland",
            "UTC",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GreetingStartResponse:
        """Start a greeting workflow without waiting for its result.

        Returns the workflow
        ID immediately.

        Examples:

        - Start immediately: No execute_at parameter
        - Start at specific time: execute_at=2025-12-25T09:00:00&timezone=US_CENTRAL

        Args:
          execute_at: Specific datetime to execute workflow (format: 2025-12-25T09:00:00)

          timezone: IANA timezone for execute_at

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/workflows/greeting/start",
            body=await async_maybe_transform(
                {
                    "language": language,
                    "name": name,
                },
                greeting_start_params.GreetingStartParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "execute_at": execute_at,
                        "timezone": timezone,
                    },
                    greeting_start_params.GreetingStartParams,
                ),
            ),
            cast_to=GreetingStartResponse,
        )


class GreetingResourceWithRawResponse:
    def __init__(self, greeting: GreetingResource) -> None:
        self._greeting = greeting

        self.execute = to_raw_response_wrapper(
            greeting.execute,
        )
        self.start = to_raw_response_wrapper(
            greeting.start,
        )

    @cached_property
    def schedule(self) -> ScheduleResourceWithRawResponse:
        return ScheduleResourceWithRawResponse(self._greeting.schedule)


class AsyncGreetingResourceWithRawResponse:
    def __init__(self, greeting: AsyncGreetingResource) -> None:
        self._greeting = greeting

        self.execute = async_to_raw_response_wrapper(
            greeting.execute,
        )
        self.start = async_to_raw_response_wrapper(
            greeting.start,
        )

    @cached_property
    def schedule(self) -> AsyncScheduleResourceWithRawResponse:
        return AsyncScheduleResourceWithRawResponse(self._greeting.schedule)


class GreetingResourceWithStreamingResponse:
    def __init__(self, greeting: GreetingResource) -> None:
        self._greeting = greeting

        self.execute = to_streamed_response_wrapper(
            greeting.execute,
        )
        self.start = to_streamed_response_wrapper(
            greeting.start,
        )

    @cached_property
    def schedule(self) -> ScheduleResourceWithStreamingResponse:
        return ScheduleResourceWithStreamingResponse(self._greeting.schedule)


class AsyncGreetingResourceWithStreamingResponse:
    def __init__(self, greeting: AsyncGreetingResource) -> None:
        self._greeting = greeting

        self.execute = async_to_streamed_response_wrapper(
            greeting.execute,
        )
        self.start = async_to_streamed_response_wrapper(
            greeting.start,
        )

    @cached_property
    def schedule(self) -> AsyncScheduleResourceWithStreamingResponse:
        return AsyncScheduleResourceWithStreamingResponse(self._greeting.schedule)
