# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Mapping, cast

import httpx

from ..types import candidate_import_csv_params
from .._types import Body, Query, Headers, NotGiven, FileTypes, not_given
from .._utils import extract_files, maybe_transform, deepcopy_minimal, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.candidate_import_csv_response import CandidateImportCsvResponse

__all__ = ["CandidatesResource", "AsyncCandidatesResource"]


class CandidatesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CandidatesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CandidatesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CandidatesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CandidatesResourceWithStreamingResponse(self)

    def import_csv(
        self,
        *,
        fallback_zip_code: str,
        file: FileTypes,
        site_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateImportCsvResponse:
        """
        Upload and import candidates from CSV file for outreach.

        CSV Columns Expected:

        - LAST NAME, FIRST NAME, MIDDLE, DOB, PHONE1, SMS PHONE1 OK, PHONE2, SMS PHONE2
          OK, EMAIL, ZIP

        Authorization: User must have candidate creation permissions for the site.

        Args:
          fallback_zip_code: Default zip code if not provided in CSV

          file: CSV file containing candidate data to upload and import

          site_id: Site ID for the candidates

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_minimal(
            {
                "fallback_zip_code": fallback_zip_code,
                "file": file,
                "site_id": site_id,
            }
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["file"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return self._post(
            "/candidates/import-csv",
            body=maybe_transform(body, candidate_import_csv_params.CandidateImportCsvParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateImportCsvResponse,
        )


class AsyncCandidatesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCandidatesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCandidatesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCandidatesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCandidatesResourceWithStreamingResponse(self)

    async def import_csv(
        self,
        *,
        fallback_zip_code: str,
        file: FileTypes,
        site_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateImportCsvResponse:
        """
        Upload and import candidates from CSV file for outreach.

        CSV Columns Expected:

        - LAST NAME, FIRST NAME, MIDDLE, DOB, PHONE1, SMS PHONE1 OK, PHONE2, SMS PHONE2
          OK, EMAIL, ZIP

        Authorization: User must have candidate creation permissions for the site.

        Args:
          fallback_zip_code: Default zip code if not provided in CSV

          file: CSV file containing candidate data to upload and import

          site_id: Site ID for the candidates

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_minimal(
            {
                "fallback_zip_code": fallback_zip_code,
                "file": file,
                "site_id": site_id,
            }
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["file"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return await self._post(
            "/candidates/import-csv",
            body=await async_maybe_transform(body, candidate_import_csv_params.CandidateImportCsvParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateImportCsvResponse,
        )


class CandidatesResourceWithRawResponse:
    def __init__(self, candidates: CandidatesResource) -> None:
        self._candidates = candidates

        self.import_csv = to_raw_response_wrapper(
            candidates.import_csv,
        )


class AsyncCandidatesResourceWithRawResponse:
    def __init__(self, candidates: AsyncCandidatesResource) -> None:
        self._candidates = candidates

        self.import_csv = async_to_raw_response_wrapper(
            candidates.import_csv,
        )


class CandidatesResourceWithStreamingResponse:
    def __init__(self, candidates: CandidatesResource) -> None:
        self._candidates = candidates

        self.import_csv = to_streamed_response_wrapper(
            candidates.import_csv,
        )


class AsyncCandidatesResourceWithStreamingResponse:
    def __init__(self, candidates: AsyncCandidatesResource) -> None:
        self._candidates = candidates

        self.import_csv = async_to_streamed_response_wrapper(
            candidates.import_csv,
        )
