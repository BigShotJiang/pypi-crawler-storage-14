# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from web_recruitment_sdk import WebRecruitmentSDK, AsyncWebRecruitmentSDK
from web_recruitment_sdk.types.system import (
    ConcurrencyGetStatusResponse,
    ConcurrencyAcquireSlotResponse,
    ConcurrencyReleaseSlotResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestConcurrency:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_acquire_slot(self, client: WebRecruitmentSDK) -> None:
        concurrency = client.system.concurrency.acquire_slot(
            tenant_id="tenant_id",
        )
        assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_acquire_slot_with_all_params(self, client: WebRecruitmentSDK) -> None:
        concurrency = client.system.concurrency.acquire_slot(
            tenant_id="tenant_id",
            concurrency_limit=0,
        )
        assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_acquire_slot(self, client: WebRecruitmentSDK) -> None:
        response = client.system.concurrency.with_raw_response.acquire_slot(
            tenant_id="tenant_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        concurrency = response.parse()
        assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_acquire_slot(self, client: WebRecruitmentSDK) -> None:
        with client.system.concurrency.with_streaming_response.acquire_slot(
            tenant_id="tenant_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            concurrency = response.parse()
            assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_status(self, client: WebRecruitmentSDK) -> None:
        concurrency = client.system.concurrency.get_status(
            tenant_id="tenant_id",
        )
        assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_status_with_all_params(self, client: WebRecruitmentSDK) -> None:
        concurrency = client.system.concurrency.get_status(
            tenant_id="tenant_id",
            concurrency_limit=0,
        )
        assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_status(self, client: WebRecruitmentSDK) -> None:
        response = client.system.concurrency.with_raw_response.get_status(
            tenant_id="tenant_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        concurrency = response.parse()
        assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_status(self, client: WebRecruitmentSDK) -> None:
        with client.system.concurrency.with_streaming_response.get_status(
            tenant_id="tenant_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            concurrency = response.parse()
            assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_get_status(self, client: WebRecruitmentSDK) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `tenant_id` but received ''"):
            client.system.concurrency.with_raw_response.get_status(
                tenant_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_release_slot(self, client: WebRecruitmentSDK) -> None:
        concurrency = client.system.concurrency.release_slot(
            tenant_id="tenant_id",
        )
        assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_release_slot_with_all_params(self, client: WebRecruitmentSDK) -> None:
        concurrency = client.system.concurrency.release_slot(
            tenant_id="tenant_id",
            concurrency_limit=0,
        )
        assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_release_slot(self, client: WebRecruitmentSDK) -> None:
        response = client.system.concurrency.with_raw_response.release_slot(
            tenant_id="tenant_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        concurrency = response.parse()
        assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_release_slot(self, client: WebRecruitmentSDK) -> None:
        with client.system.concurrency.with_streaming_response.release_slot(
            tenant_id="tenant_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            concurrency = response.parse()
            assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncConcurrency:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_acquire_slot(self, async_client: AsyncWebRecruitmentSDK) -> None:
        concurrency = await async_client.system.concurrency.acquire_slot(
            tenant_id="tenant_id",
        )
        assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_acquire_slot_with_all_params(self, async_client: AsyncWebRecruitmentSDK) -> None:
        concurrency = await async_client.system.concurrency.acquire_slot(
            tenant_id="tenant_id",
            concurrency_limit=0,
        )
        assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_acquire_slot(self, async_client: AsyncWebRecruitmentSDK) -> None:
        response = await async_client.system.concurrency.with_raw_response.acquire_slot(
            tenant_id="tenant_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        concurrency = await response.parse()
        assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_acquire_slot(self, async_client: AsyncWebRecruitmentSDK) -> None:
        async with async_client.system.concurrency.with_streaming_response.acquire_slot(
            tenant_id="tenant_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            concurrency = await response.parse()
            assert_matches_type(ConcurrencyAcquireSlotResponse, concurrency, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_status(self, async_client: AsyncWebRecruitmentSDK) -> None:
        concurrency = await async_client.system.concurrency.get_status(
            tenant_id="tenant_id",
        )
        assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_status_with_all_params(self, async_client: AsyncWebRecruitmentSDK) -> None:
        concurrency = await async_client.system.concurrency.get_status(
            tenant_id="tenant_id",
            concurrency_limit=0,
        )
        assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_status(self, async_client: AsyncWebRecruitmentSDK) -> None:
        response = await async_client.system.concurrency.with_raw_response.get_status(
            tenant_id="tenant_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        concurrency = await response.parse()
        assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_status(self, async_client: AsyncWebRecruitmentSDK) -> None:
        async with async_client.system.concurrency.with_streaming_response.get_status(
            tenant_id="tenant_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            concurrency = await response.parse()
            assert_matches_type(ConcurrencyGetStatusResponse, concurrency, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_get_status(self, async_client: AsyncWebRecruitmentSDK) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `tenant_id` but received ''"):
            await async_client.system.concurrency.with_raw_response.get_status(
                tenant_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_release_slot(self, async_client: AsyncWebRecruitmentSDK) -> None:
        concurrency = await async_client.system.concurrency.release_slot(
            tenant_id="tenant_id",
        )
        assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_release_slot_with_all_params(self, async_client: AsyncWebRecruitmentSDK) -> None:
        concurrency = await async_client.system.concurrency.release_slot(
            tenant_id="tenant_id",
            concurrency_limit=0,
        )
        assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_release_slot(self, async_client: AsyncWebRecruitmentSDK) -> None:
        response = await async_client.system.concurrency.with_raw_response.release_slot(
            tenant_id="tenant_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        concurrency = await response.parse()
        assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_release_slot(self, async_client: AsyncWebRecruitmentSDK) -> None:
        async with async_client.system.concurrency.with_streaming_response.release_slot(
            tenant_id="tenant_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            concurrency = await response.parse()
            assert_matches_type(ConcurrencyReleaseSlotResponse, concurrency, path=["response"])

        assert cast(Any, response.is_closed) is True
