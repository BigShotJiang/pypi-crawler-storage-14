# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from web_recruitment_sdk import WebRecruitmentSDK, AsyncWebRecruitmentSDK
from web_recruitment_sdk.types.outreach.campaigns import PersonGetActionsResponse, PersonGetAttemptsResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPersons:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_actions(self, client: WebRecruitmentSDK) -> None:
        person = client.outreach.campaigns.persons.get_actions(
            person_id=0,
            campaign_id=0,
        )
        assert_matches_type(PersonGetActionsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_actions(self, client: WebRecruitmentSDK) -> None:
        response = client.outreach.campaigns.persons.with_raw_response.get_actions(
            person_id=0,
            campaign_id=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        person = response.parse()
        assert_matches_type(PersonGetActionsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_actions(self, client: WebRecruitmentSDK) -> None:
        with client.outreach.campaigns.persons.with_streaming_response.get_actions(
            person_id=0,
            campaign_id=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            person = response.parse()
            assert_matches_type(PersonGetActionsResponse, person, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_attempts(self, client: WebRecruitmentSDK) -> None:
        person = client.outreach.campaigns.persons.get_attempts(
            person_id=0,
            campaign_id=0,
        )
        assert_matches_type(PersonGetAttemptsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_attempts(self, client: WebRecruitmentSDK) -> None:
        response = client.outreach.campaigns.persons.with_raw_response.get_attempts(
            person_id=0,
            campaign_id=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        person = response.parse()
        assert_matches_type(PersonGetAttemptsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_attempts(self, client: WebRecruitmentSDK) -> None:
        with client.outreach.campaigns.persons.with_streaming_response.get_attempts(
            person_id=0,
            campaign_id=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            person = response.parse()
            assert_matches_type(PersonGetAttemptsResponse, person, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncPersons:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_actions(self, async_client: AsyncWebRecruitmentSDK) -> None:
        person = await async_client.outreach.campaigns.persons.get_actions(
            person_id=0,
            campaign_id=0,
        )
        assert_matches_type(PersonGetActionsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_actions(self, async_client: AsyncWebRecruitmentSDK) -> None:
        response = await async_client.outreach.campaigns.persons.with_raw_response.get_actions(
            person_id=0,
            campaign_id=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        person = await response.parse()
        assert_matches_type(PersonGetActionsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_actions(self, async_client: AsyncWebRecruitmentSDK) -> None:
        async with async_client.outreach.campaigns.persons.with_streaming_response.get_actions(
            person_id=0,
            campaign_id=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            person = await response.parse()
            assert_matches_type(PersonGetActionsResponse, person, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_attempts(self, async_client: AsyncWebRecruitmentSDK) -> None:
        person = await async_client.outreach.campaigns.persons.get_attempts(
            person_id=0,
            campaign_id=0,
        )
        assert_matches_type(PersonGetAttemptsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_attempts(self, async_client: AsyncWebRecruitmentSDK) -> None:
        response = await async_client.outreach.campaigns.persons.with_raw_response.get_attempts(
            person_id=0,
            campaign_id=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        person = await response.parse()
        assert_matches_type(PersonGetAttemptsResponse, person, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_attempts(self, async_client: AsyncWebRecruitmentSDK) -> None:
        async with async_client.outreach.campaigns.persons.with_streaming_response.get_attempts(
            person_id=0,
            campaign_id=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            person = await response.parse()
            assert_matches_type(PersonGetAttemptsResponse, person, path=["response"])

        assert cast(Any, response.is_closed) is True
