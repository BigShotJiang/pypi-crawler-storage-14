from enum import Enum

class OpenAIModels(str, Enum):
    gpt_5 = 'gpt-5'
    gpt_5_codex = 'gpt-5-codex'
    gpt_5_mini = 'gpt-5-mini'
    gpt_5_nano = 'gpt-5-nano'
    o3 = 'o3'
    gpt_4o = 'gpt-4o'