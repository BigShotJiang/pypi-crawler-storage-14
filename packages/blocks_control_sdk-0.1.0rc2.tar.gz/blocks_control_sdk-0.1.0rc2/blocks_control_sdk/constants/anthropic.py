from enum import Enum

class AnthropicModels(str, Enum):
    claude_3_5_haiku = 'claude-3-5-haiku-latest'
    claude_4_5_haiku = 'claude-haiku-4-5-20251001'
    claude_3_5_sonnet = 'claude-3-5-sonnet-20241022'
    claude_3_7_sonnet = 'claude-3-7-sonnet-latest'
    claude_4_sonnet_20250514 = 'claude-sonnet-4-20250514'
    claude_4_opus_20250514 = 'claude-opus-4-20250514'
    claude_4_1_opus_20250805 = 'claude-opus-4-1-20250805'
    sonnet = 'sonnet' # default to latest in claude code
    opus = 'opus' # default to latest in claude code
