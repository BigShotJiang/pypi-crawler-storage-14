1.  Go to *Employees*
2.  On the employee form view you will have 3 separate fields, one for
    Firstname, second for Lastname, both required and Mother's Last Name
    (optional).
