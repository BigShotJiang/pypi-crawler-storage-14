"""
Core modules for the ELITE retrieval framework.

This package retains the original module layout (core_functions, utils, prompt,
dataloader, deepseek_api) so existing imports like ``import src.core_functions``
continue to work after packaging.
"""

__all__ = [
    "core_functions",
    "utils",
    "prompt",
    "dataloader",
    "deepseek_api",
]
