import logging
import ollama
from ollama import Client
import numpy as np
import requests
import re
import time
import numpy as np
import nltk.tokenize
from nltk.tokenize import word_tokenize
#from google import genai
import local_config as local_config
import src.prompt as prompt
import ollama
#from string_noise import noise
import numpy as np
from numpy.linalg import norm
from src.prompt import format_prompt
import os
from typing import Optional, Dict, Any, List
import openai
from openai import OpenAI
import json
import ast

recall_index=local_config.recall_index
neighbor_num=local_config.neighbor_num
voter_num=local_config.voter_num
num_ctx=local_config.num_ctx
question_prompt_cot=prompt.question_prompt_cot
question_prompt_cot_final=prompt.question_prompt_cot_final
#config ollama api and model
url=local_config.url
common_model = local_config.common_model

def get_embedding(text):
    model = embedder_config["model"]
    try:
        response = embedder.embeddings(model=model, prompt=text)
        return response["embedding"]
    except Exception as e:
        print(f"Error getting embedding: {e}")
        return None

# Configuration for the embedding model
embedder_config = {
    "model": "nomic-embed-text",
    "ollama_base_url": "http://localhost:11434"
}

embedder = Client(host=embedder_config["ollama_base_url"])

#utils
def calculate_cosine_similarity(vec1, vec2):
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

def majority_voting(answers):
    """
    实现少数服从多数逻辑，支持 5 个答案。
    
    参数：
    - answer1, answer2, answer3, answer4, answer5: 5 次调用的结果
    
    返回：
    - 最终的结果：返回次数最多的答案；如果出现次数相同，返回第一个答案。
    """
    # 将所有答案存入一个列表
    
    
    # 使用字典统计每个答案的出现次数
    counts = {}
    for answer in answers:
        counts[answer] = counts.get(answer, 0) + 1
    
    # 找到出现次数最多的答案
    max_count = max(counts.values())
    for answer in answers:
        if counts[answer] == max_count:
            return answer  # 返回第一个满足条件的答案

def get_majority_answer(sentences_list,sorted_results, num_answers,question):
    """
    发送多次请求并通过投票机制选择多数答案。
    
    参数:
        combined_prompt (str): 输入的提示信息。
        num_answers (int): 需要获取的答案数量。

    返回:
        str: 最终的多数答案。
    """
    # 用于模拟 send 函数的结果 (可以替换为实际的 send 函数)
    

    top_k_sentences = sorted_results[:recall_index]
    
    
    all_sentences=extract_neighboring_sentences(sentences_list, top_k_sentences, k_neighbors=neighbor_num)
    
    all_sentences_sorted = sorted(all_sentences, key=lambda x: x['SID'])  # 按照 SID 排序

    retrieve_data = ""

    for entry in all_sentences_sorted:
        retrieve_data += "SentenceID" + str(entry['SID']) + ":" + entry['sentence'] + "\n\n"  # 提取 'sentence' 并加上换行符

    final_input=retrieve_data+"\n\n"+question_prompt_cot+"\n\n"+question+"\n\n"+" PROMPT: tell me do you think if the retrieved information is enough for answering this question"

    # 收集多个答案
    answers = []
    answers_cot=[]
    for _ in range(num_answers):
        ans_cot1=send(final_input)
        #ans_cot2=send("RETRIEVED DATA:"+retrieve_data+"\n\nQUESTION :"+question_formatted+"\n\nSOMEONE'S THINKING:"+ans_cot1+"\n\nPROMPT: Combine the retrieved data with the previous person's reasoning, and come to your own conclusion. Carefully review the previous reasoning and analyze it with the SentenceIDs to determine the answer.")
        ans=send(ans_cot1+"\n\n"+question_prompt_cot_final)
        
        answers.append(ans[0])
        answers_cot.append(ans_cot1)

    

    # 投票统计答案出现次数
    counts = {}
    for answer in answers:
        counts[answer] = counts.get(answer, 0) + 1

    # 找到出现次数最多的答案
    max_count = max(counts.values())
    for answer in answers:
        if counts[answer] == max_count:
            return answer,answers,answers_cot,final_input  # 返回第一个满足条件的答案    

def preprocess_text(sentence,stopwords):
    """
    预处理文本：移除停用词并返回关键词集合。
    """
    stop_words = stopwords
    words = word_tokenize(sentence.lower())
    keywords = set(word for word in words if word not in stop_words)

    return keywords

def find_semantic_common_words(set1, set2):
    """
    查找两个集合中的公共词汇，忽略大小写。
    """
    # 转换集合中的所有字符串为小写
    set1_lower = {word.lower() for word in set1}
    set2_lower = {word.lower() for word in set2}
    
    # 找到交集
    common_words = set1_lower & set2_lower
    return list(common_words)  # 返回列表格式

def count_common_keywords(sentence1, sentence2,stopwords):
    """
    统计两个句子的共同关键词数量。
    """
    keywords1 = preprocess_text(sentence1,stopwords)
    keywords2 = preprocess_text(sentence2,stopwords)
    #print(keywords1)
    #print(keywords2)
    common_keywords = find_semantic_common_words(keywords1,keywords2)
    #print(common_keywords)
    #exit()
    return len(common_keywords),common_keywords

def send(chat):
    """
    Send function with configurable provider support
    Uses local_config.llm_provider to determine which provider to use
    """
    # Use the enhanced send system with configured provider
    print("\033[1;31mContext length input to LLM:\033[0m")
    print(f"\033[1;31m{len(chat)}\033[0m")
    try:
        provider = getattr(local_config, 'llm_provider', 'ollama')
        use_fallback = getattr(local_config, 'use_fallback', True)
        print(f"Using {provider} ")
        result = llm_manager.send(
            prompt=chat, 
            provider=provider,
            use_fallback=use_fallback,
            num_ctx=num_ctx
        )
        
        if result['success']:
            return result['content']
        else:
            # Fallback to original ollama implementation if all providers fail
            print(f"All providers failed: {result['error']}, using original ollama fallback")
            return send_original_ollama(chat)
            
    except Exception as e:
        print(f"Error in enhanced send: {e}, using original ollama fallback")
        return send_original_ollama(chat)

def send_original_ollama(chat):
    """Original Ollama-only send function as fallback"""
    prompt = chat
    payload = {
        "model": common_model,  
        "prompt": prompt,
        "stream": False,
        "options":{
            "num_ctx":num_ctx,
        }
    }
    response = requests.post(url, json=payload)
    ret = response.json()["response"]
    return ret

def send_json(chat):
    """Send function with JSON format output"""
    try:
        provider = getattr(local_config, 'llm_provider', 'ollama')
        use_fallback = getattr(local_config, 'use_fallback', True)
        
        result = llm_manager.send(
            prompt=chat, 
            provider=provider,
            use_fallback=use_fallback,
            num_ctx=num_ctx,
            format='json'
        )
        
        if result['success']:
            return result['content']
        else:
            print(f"JSON send failed: {result['error']}, using original ollama fallback")
            return send_json_original_ollama(chat)
            
    except Exception as e:
        print(f"Error in enhanced send_json: {e}, using original ollama fallback")
        return send_json_original_ollama(chat)

def send_json_original_ollama(chat):
    """Original Ollama-only send_json function as fallback"""
    prompt = chat
    payload = {
        "model": common_model,  
        "prompt": prompt,
        "stream": False,
        "options":{
            "num_ctx":num_ctx,
        },
        "format":"json"
    }
    response = requests.post(url, json=payload)
    ret = response.json()["response"]
    return ret

def send_with_seed(chat,seed):#回答的时候用
      # Prompt for summarization
    prompt =chat# Combine the prompt and the text
    # Parameters to pass to Ollama for generating a summary
    payload = {
        "model": common_model,  
        "prompt": prompt,
        "stream": False,
        "options":{
            "num_ctx":num_ctx
        }
        
       
    }
    response = requests.post(url, json=payload)
    #print(response.json()["prompt_eval_count"])
    #print(response.json()["eval_count"])
    ret=response.json()["response"]

    return ret

def chat(chat):
      # Prompt for summarization
    url="http://localhost:11434/api/chat"
    prompt =chat# Combine the prompt and the text

    # Parameters to pass to Ollama for generating a summary
    payload = {
        "model": common_model, 
        "messages": [
                    {
                    "role": "user",
                    "content": prompt
                    }
                ],
        "stream": False,
        "options": {
                       
                        "seed": 42,
                        "num_predict": 1000,
                        "temperature": 0.1,
                        "num_ctx": 10000,
                        "stop": [],
                    }
        
    }
    response = requests.post(url, json=payload)
    print(response.json())
    #print(response.json()['message']['content'])
    exit()
    
    
    return ret

def send_by_specific_model(chat,model):
      # Prompt for summarization

    prompt =chat# Combine the prompt and the text

    # Parameters to pass to Ollama for generating a summary
    payload = {
        "model": model,  
        "prompt": prompt,
        "stream": False,
        "max_tokens": 110000,
        "num_ctx": 110000,
        "num_predict":1000
    }
    response = requests.post(url, json=payload)
   
    ret=response.json()["response"]

    return ret

# ========= Enhanced Multi-Provider Send Functions =========

class LLMProvider:
    """Base class for LLM providers"""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
    
    def send(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Send prompt to provider and return standardized response"""
        raise NotImplementedError

class OllamaProvider(LLMProvider):
    """Ollama provider implementation"""
    
    def send(self, prompt: str, **kwargs) -> Dict[str, Any]:
        try:
            model = kwargs.get('model', self.config.get('model', common_model))
            url = self.config.get('url', 'http://localhost:11434/api/generate')
            
            payload = {
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_ctx": kwargs.get('num_ctx', num_ctx),
                    "temperature": kwargs.get('temperature', 0.1),
                }
            }
            
            if kwargs.get('format') == 'json':
                payload['format'] = 'json'
            
            response = requests.post(url, json=payload, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            return {
                'content': result["response"],
                'provider': 'ollama',
                'model': model,
                'success': True,
                'error': None
            }
            
        except Exception as e:
            return {
                'content': None,
                'provider': 'ollama',
                'model': model,
                'success': False,
                'error': str(e)
            }

class OpenAIProvider(LLMProvider):
    """OpenAI API provider implementation"""
    
    def send(self, prompt: str, **kwargs) -> Dict[str, Any]:
        try:
            api_key = self.config.get('api_key') or os.getenv('OPENAI_API_KEY')
            if not api_key:
                raise ValueError("OpenAI API key not found")
            
            model = kwargs.get('model', self.config.get('model', 'gpt-3.5-turbo'))
            url = "https://api.openai.com/v1/chat/completions"
            
            headers = {
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": kwargs.get('temperature', 0.1),
                "max_tokens": kwargs.get('max_tokens', 4000),
            }
            
            if kwargs.get('format') == 'json':
                payload['response_format'] = {"type": "json_object"}
            
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            return {
                'content': result['choices'][0]['message']['content'],
                'provider': 'openai',
                'model': model,
                'success': True,
                'error': None,
                'usage': result.get('usage', {})
            }
            
        except Exception as e:
            return {
                'content': None,
                'provider': 'openai',
                'model': kwargs.get('model', 'gpt-3.5-turbo'),
                'success': False,
                'error': str(e)
            }

class DeepSeekProvider(LLMProvider):
    """DeepSeek API provider implementation using OpenAI client"""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.client = None
        self._init_client()
    
    def _init_client(self):
        """Initialize OpenAI client for DeepSeek"""
        try:
            
            api_key = self.config.get('api_key') or os.getenv('DEEPSEEK_API_KEY')
            if not api_key:
                raise ValueError("DeepSeek API key not found")
            
            self.client = OpenAI(
                api_key=api_key,
                base_url="https://api.deepseek.com"
            )
        except ImportError:
            print("Warning: openai package not installed. DeepSeek provider will be unavailable.")
            self.client = None
        except Exception as e:
            print(f"Warning: Failed to initialize DeepSeek client: {e}")
            self.client = None
    
    def send(self, prompt: str, **kwargs) -> Dict[str, Any]:
        try:
            if self.client is None:
                raise ValueError("DeepSeek client not initialized")
            
            model = kwargs.get('model', self.config.get('model', 'deepseek-chat'))
            
            # Prepare messages
            messages = [{"role": "user", "content": prompt}]
            
            # Prepare completion parameters
            completion_kwargs = {
                "model": model,
                "messages": messages,
                "temperature": kwargs.get('temperature', 0.1),
                "max_tokens": kwargs.get('max_tokens', 4000),
                "stream": False,
            }
            
            # Add JSON format if requested
            if kwargs.get('format') == 'json':
                completion_kwargs['response_format'] = {"type": "json_object"}
            
            # Make the API call
            response = self.client.chat.completions.create(**completion_kwargs)
            
            content = response.choices[0].message.content or ""
            
            return {
                'content': content.strip(),
                'provider': 'deepseek',
                'model': model,
                'success': True,
                'error': None,
                'usage': response.usage.__dict__ if response.usage else {}
            }
            
        except Exception as e:
            return {
                'content': None,
                'provider': 'deepseek',
                'model': kwargs.get('model', 'deepseek-chat'),
                'success': False,
                'error': str(e)
            }

class LLMManager:
    """Manager for multiple LLM providers with fallback support"""
    
    def __init__(self):
        self.providers = {}
        self.primary_provider = 'ollama'
        self.fallback_order = ['ollama', 'openai', 'deepseek']
        self._setup_providers()
    
    def _setup_providers(self):
        """Initialize all available providers"""
        # Ollama provider
        self.providers['ollama'] = OllamaProvider('ollama', {
            'url': 'http://localhost:11434/api/generate',
            'model': common_model
        })
        
        # OpenAI provider
        if os.getenv('OPENAI_API_KEY'):
            self.providers['openai'] = OpenAIProvider('openai', {
                'api_key': os.getenv('OPENAI_API_KEY'),
                'model': 'gpt-3.5-turbo'
            })
        
        # DeepSeek provider  
        if os.getenv('DEEPSEEK_API_KEY'):
            self.providers['deepseek'] = DeepSeekProvider('deepseek', {
                'api_key': os.getenv('DEEPSEEK_API_KEY'),
                'model': 'deepseek-chat'
            })
    
    def set_primary_provider(self, provider_name: str):
        """Set the primary provider to use"""
        if provider_name in self.providers:
            self.primary_provider = provider_name
        else:
            raise ValueError(f"Provider {provider_name} not available")
    
    def send(self, prompt: str, provider: Optional[str] = None, use_fallback: bool = True, **kwargs) -> Dict[str, Any]:
        """
        Send prompt using specified provider or primary provider with fallback
        
        Args:
            prompt: The text prompt to send
            provider: Specific provider to use (optional)
            use_fallback: Whether to try fallback providers if primary fails
            **kwargs: Additional parameters for the provider
        
        Returns:
            Dict with response content and metadata
        """
        # Determine which provider to try first

        if provider and provider in self.providers:
            providers_to_try = [provider]
        else:
            providers_to_try = [self.primary_provider]
        
        # Add fallback providers if enabled
        if use_fallback:
            for fallback in self.fallback_order:
                if fallback not in providers_to_try and fallback in self.providers:
                    providers_to_try.append(fallback)
        
        # Try each provider in order
        last_error = None
        for provider_name in providers_to_try:
            provider_obj = self.providers[provider_name]
            result = provider_obj.send(prompt, **kwargs)
            
            if result['success']:
                return result
            else:
                last_error = result['error']
                print(f"Provider {provider_name} failed: {last_error}")
        
        # All providers failed
        return {
            'content': None,
            'provider': None,
            'model': None,
            'success': False,
            'error': f"All providers failed. Last error: {last_error}"
        }
    
    def get_available_providers(self) -> List[str]:
        """Get list of available providers"""
        return list(self.providers.keys())

# Global LLM manager instance
llm_manager = LLMManager()

def send_enhanced(prompt: str, provider: Optional[str] = None, **kwargs) -> str:
    """
    Enhanced send function with multi-provider support
    
    Args:
        prompt: The text prompt to send
        provider: Specific provider to use ('ollama', 'openai', 'deepseek')
        **kwargs: Additional parameters
    
    Returns:
        str: Response content (maintains compatibility with original send function)
    """
    result = llm_manager.send(prompt, provider=provider, **kwargs)
    
    if result['success']:
        return result['content']
    else:
        # Fallback to original send function for compatibility
        print(f"Enhanced send failed: {result['error']}, falling back to original send")
        return send(prompt)

def send_enhanced_full(prompt: str, provider: Optional[str] = None, **kwargs) -> Dict[str, Any]:
    """
    Enhanced send function that returns full response metadata
    
    Args:
        prompt: The text prompt to send  
        provider: Specific provider to use ('ollama', 'openai', 'deepseek')
        **kwargs: Additional parameters
    
    Returns:
        Dict: Full response with metadata
    """
    return llm_manager.send(prompt, provider=provider, **kwargs)

def set_default_provider(provider: str):
    """
    Set the default provider for enhanced send functions
    
    Args:
        provider: Provider name ('ollama', 'openai', 'deepseek')
    """
    llm_manager.set_primary_provider(provider)

def get_available_providers() -> List[str]:
    """Get list of available LLM providers"""
    return llm_manager.get_available_providers()

def test_providers():
    """Test all available providers with a simple prompt"""
    test_prompt = "Say 'Hello' and nothing else."
    results = {}
    
    for provider in llm_manager.get_available_providers():
        print(f"Testing {provider}...")
        result = llm_manager.send(test_prompt, provider=provider, use_fallback=False)
        results[provider] = {
            'success': result['success'],
            'response': result.get('content', '')[:50] if result.get('content') else None,
            'error': result.get('error', None)
        }
        
        if result['success']:
            print(f"✓ {provider}: {result['content'][:50]}...")
        else:
            print(f"✗ {provider}: {result['error']}")
    
    return results

def format_question_and_options(query):
    """
    格式化问题文本、选项，并包括QID。
    Args:
        query (dict): 包含 'QID', 'Question', 和 'Options' 的字典。
    Returns:
        str: 格式化后的字符串，包含 QID、问题和选项。
    """
    # 提取 QID 和问题文本
    qid = query.get('QID', 'Unknown QID')
    question_text = query.get('Question', 'No Question Provided')
    
    # 开始构建格式化字符串
    formatted_text = f'"QID": "{qid}",\n"Question": "{question_text}",\n"Options": {{\n'
    
    # 遍历选项
    options = query.get('Options', {})
    option_parts = []
    for key, value in options.items():
        option_parts.append(f'    "{key}": "{value}"')
    
    # 将选项合并成一个字符串，并加入到问题字符串中
    formatted_text += ",\n".join(option_parts)
    formatted_text += '\n}'
    
    return formatted_text,question_text

def split_into_sentences_and_count_tokens(text):
    """
    将输入文本分割成句子，并统计每个句子的单词数量。
    """
    # 分句，使用正则表达式匹配句子结束标点（如 . ! ?）并保留标点
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    
    # 统计每个句子的单词数量
    results = []
    for sentence in sentences:
        # 使用空格分词，过滤掉空字符
        tokens = [word for word in sentence.split() if word.strip()]
        token_count = len(tokens)
        results.append({"sentence": sentence, "token_count": token_count})
    
    return results

def extract_neighboring_sentences(sentence_list, top_k_sentences, k_neighbors=5):
    """
    从 sentence_list 中提取 top_k_sentences 的句子及其前后 k_neighbors 个句子。
    
    Args:
        sentence_list (list of dict): 原始句子列表，每个元素是一个字典，包含 SID 和 sentence。
        top_k_sentences (list of tuple): 已选中的句子列表，每个元素是 (sid, sentence, similarity) 的元组。
        k_neighbors (int): 需要提取的相邻句子个数（默认前后各 5 个）。
        
    Returns:
        List of dict: 包含提取结果的句子列表。
    """

    
    # 构建 sid 到句子索引的映射
    sid_to_index = {item['SID']: idx for idx, item in enumerate(sentence_list)}
    
    # 初始化结果列表
    extracted_sentences = []
    
    for sid, _ , _ , _ in top_k_sentences:
        # 获取当前句子的索引
        if sid in sid_to_index:
            current_index = sid_to_index[sid]
            
            # 确定前后句子的范围
            start_index = max(0, current_index - k_neighbors)
            end_index = min(len(sentence_list), current_index + k_neighbors + 1)
            
            # 提取范围内的句子
            neighboring_sentences = sentence_list[start_index:end_index]
            
            # 将句子加入结果列表
            extracted_sentences.extend(neighboring_sentences)
    
    return extracted_sentences

def split_into_sentences_and_count_tokens_with_sid(text):
    """
    将输入文本分割成句子，统计每个句子的单词数量，并为每个句子分配一个 SID。
    """
    # 分句，使用正则表达式匹配句子结束标点（如 . ! ?）并保留标点
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    
    # 统计每个句子的单词数量，并添加 SID
    results = []
    for sid, sentence in enumerate(sentences, start=1):  # SID 从 1 开始
        # 使用空格分词，过滤掉空字符
        tokens = [word for word in sentence.split() if word.strip()]
        token_count = len(tokens)
        results.append({
            "SID": sid,  # 添加句子标识
            "sentence": sentence,
            "token_count": token_count
        })
    return results

def split_into_sentences_and_count_tokens_with_sid_cos(text):
    """
    将输入文本分割成句子，统计每个句子的单词数量，并为每个句子分配一个 SID。
    """
    # 分句，使用正则表达式匹配句子结束标点（如 . ! ?）并保留标点
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    
    # 统计每个句子的单词数量，并添加 SID
    results = []
    for sid, sentence in enumerate(sentences, start=1):  # SID 从 1 开始
        # 使用空格分词，过滤掉空字符
        tokens = [word for word in sentence.split() if word.strip()]
        token_count = len(tokens)
        results.append({
            "SID": sid,  # 添加句子标识
            "sentence": sentence,
            "token_count": token_count,
            "cos":get_embedding(sentence)
        })
    return results

# Configure logging to write to the specified file
def setup_logger(log_file):
    """
    配置日志记录器，并清空日志文件内容。
    """
    # 清空日志文件内容
    with open(log_file, 'w') as f:
        f.truncate(0)  # 清空文件内容

    # 清除旧的处理器，避免重复日志
    logging.getLogger().handlers = []

    # 配置新的日志处理器
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logging.debug("检查日志是否仍然是 DEBUG 级别")
   # print("当前日志级别:", logging.getLogger().getEffectiveLevel())  # 输出当前日志级别

def get_top_k_sentences(sentences_list, question, literary_stopwords, recall_index):
    """
    Calculate similarity between a question and sentences, and return the top-k sentences.

    Args:
        sentences_list (list): List of dictionaries containing 'sentence' and 'SID'.
        question (str): The target question for similarity comparison.
        literary_stopwords (set): A set of stopwords to exclude from similarity calculation.
        recall_index (int): Number of top sentences to return.

    Returns:
        list: A list of tuples with (SID, sentence, similarity, common_words) for top-k sentences.
    """
    similarity_results = []

    for result in sentences_list:
        # Extract current sentence and SID
        sentence = result['sentence']
        sid = result['SID']

        # Calculate similarity with target text
        similarity, common_words = count_common_keywords(question, sentence, literary_stopwords)
        
        
        # bm25_similarity=bm25.bm25_score(query=preprocess_text(question,literary_stopwords), document=result, corpus=sentences_list)
        # exit()
        #print(similarity)
        #print(common_words)
        #exit()
        # Append results
        similarity_results.append((sid, sentence, similarity, common_words))

    # Sort results by similarity in descending order
    sorted_results = sorted(similarity_results, key=lambda x: x[2], reverse=True)

    # Return top-k sentences
    top_k_sentences = sorted_results[:recall_index]
    return top_k_sentences

def get_top_k_sentences_cos(sentences_list, question, recall_index):
    """
    Calculate similarity between a question and sentences, and return the top-k sentences.

    Args:
        sentences_list (list): List of dictionaries containing 'sentence' and 'SID'.
        question (str): The target question for similarity comparison.
        literary_stopwords (set): A set of stopwords to exclude from similarity calculation.
        recall_index (int): Number of top sentences to return.

    Returns:
        list: A list of tuples with (SID, sentence, similarity, common_words) for top-k sentences.
    """
    similarity_results = []
    target_embedding=get_embedding(question)
    for result in sentences_list:
        # Extract current sentence and SID
        sentence = result['sentence']
        sid = result['SID']
        cos_sim_sentence=result['cos']
        # Calculate similarity with target text
        similarity = calculate_cosine_similarity(cos_sim_sentence,target_embedding)
        #print(similarity)
        #print(common_words)
        #exit()
        # Append results
        similarity_results.append((sid, sentence, similarity))

    # Sort results by similarity in descending order
    sorted_results = sorted(similarity_results, key=lambda x: x[2], reverse=True)

    # Return top-k sentences
    top_k_sentences = sorted_results[:recall_index]
    return top_k_sentences



def extract_chapter_info(sentence):
    """
    提取句子中包含的 'chapter' 或其大小写变体，及后面的一个单词。

    Args:
        sentence (str): 输入的句子。

    Returns:
        str: 提取的 'chapter' 和后面的一个单词，若发现是'twenty'及以上，则返回 chapter 和后两个单词。
    """
    # 使用正则表达式匹配 'chapter'（大小写忽略）及其后面的单词
    match = re.search(r'\bchapter\b\s+(\w+(?:\s+\w+)?)', sentence, re.IGNORECASE)
    if match:
        next_word = match.group(1)
        # 如果 next_word 包含 'twenty' 或后续结构，则返回后两个单词
        words = next_word.split()
        if next_word.lower().startswith("twenty") or any(w.lower() in ["thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety", "hundred"] for w in words):
            return f"chapter {' '.join(words[:2])}" if len(words) > 1 else f"chapter {words[0]}"
        return f"chapter {next_word}"
    return "None"  # 若未找到匹配项，则返回 None

def clean_chapter_list(chapter_list):
    ret=[]
    for result in chapter_list:
        result = list(result)  # 将元组转换为列表
        
        temp=extract_chapter_info(result[1])
        result[1]=temp
        if(temp != "None"):
            ret.append(result)
        #print(result[0],":",result[1])
        #print("\n")
    return ret

def insert_chapter_information(chapter_list,all_sentences_sorted):
    chapter_pointer = 1
    sentence_pointer = 0

    # 遍历 chapter_list 和 all_sentences_sorted
    while chapter_pointer < len(chapter_list) and sentence_pointer < len(all_sentences_sorted):
        # 如果当前章节对应的 SID 小于等于当前句子的 SID，插入章节信息
        #print(chapter_list[chapter_pointer][0])
        #print(all_sentences_sorted[sentence_pointer]['SID'])
        if chapter_list[chapter_pointer][0] > all_sentences_sorted[sentence_pointer]['SID']:
            all_sentences_sorted[sentence_pointer]['sentence'] += f" .(FROM  {chapter_list[chapter_pointer-1][1]})."
            sentence_pointer += 1  # 移动到下一个句子
        else:
            chapter_pointer += 1  # 移动到下一个章节
    return all_sentences_sorted

def calculate_score(correct_answers, user_answers):
    # 计算正确率并生成TF列表
    tf_list = [True if correct == user else False for correct, user in zip(correct_answers, user_answers)]
    correct_count = sum(tf_list)  # 统计正确的数量
    total_count = len(correct_answers)  # 总题目数量
    accuracy = correct_count / total_count  # 计算正确率
    return accuracy

# def mask_text(text, p, n):
#     if p != 0:
#         p = 1 - pow((1 - p), 1/n) #since this is a process of n randomizations
#     #print(p)
#     if(n >= 1):
#         text = noise.ocr(text, probability=p)
#     if(n >= 2):
#         text = noise.moe(text, probability=p) 
#     if(n >= 3):
#         text = noise.homoglyph(text, probability=p)
#     return text

def cos_similarity(vec1, vec2):
    return (np.dot(vec1, vec2) / (norm(vec1) * norm(vec2)))

# def compute_imp(query, ori_memory):
#     q_prompt = f"You will be given a question and some information that could be used to answer the question. Your task is to answer the question. Note that not all information are useful to your answer, they could be irrelevant. You SHOULD disregard all irrelevent sentences and NOT make ANY inference based on YOUR knowledge. You DO NOT need to describe the text. Here is the question: {query}"
#     ori_text = send(q_prompt + "\nGiven the information: " + ori_memory)
#     baseline_text = mask_text(ori_memory, 0.1, 3)
#     noisy_text = mask_text(ori_memory, 0.9, 3)
#     baseline_text = send(q_prompt + "\nGiven the information: " + baseline_text)
#     noisy_text = send(q_prompt + "\nGiven the information: " + noisy_text)
#     ori_emb = ollama.embed(model="mxbai-embed-large", input=ori_text)["embeddings"][0]
#     baseline_emb = ollama.embed(model="mxbai-embed-large", input=baseline_text)["embeddings"][0]
#     noisy_emb = ollama.embed(model="mxbai-embed-large", input=noisy_text)["embeddings"][0]
#     return (2 - cos_similarity(ori_emb, noisy_emb) - cos_similarity(baseline_emb, noisy_emb))/2

def augment_keywords( query, retrieve_data):
    prompt = f"""
    IMPORTANT RULE:{format_prompt}
    Retrieved information{retrieve_data}
    QUERY: {query}
    IMPORTANT RULE:{format_prompt}
    \nPROMPT: Extract proper keywords from retrieved data in order to search more relevant information
    IMPORTANT RULE:{format_prompt}
    """
    keywords = send(prompt)
    return keywords

def depth_expand(retrieve_data,query):
    prompt = f"""
    IMPORTANT RULE:{format_prompt}
    Retrieved information{retrieve_data}
    QUERY: {query}
    IMPORTANT RULE:{format_prompt}
    \nPROMPT: Extract proper keywords from retrieved data in order to search more relevant information
    IMPORTANT RULE:{format_prompt}
  
    """
    return send(prompt)

def compress(retrieve_data,query):
    prompt = f"""
    write more than 400 words!!
    filter important information from RETRIEVAL which can help to solve this query{query}, do not explain, only response with original sentences
    RETRIEVAL:{retrieve_data}
    filter important information from RETRIEVAL which can help to solve this query{query}, do not explain, only response with original sentences
    filter important information from RETRIEVAL which can help to solve this query{query}, do not explain, only response with original sentences
    write more
    write more than 400 words!!
    """
    return send(prompt)

def retrieve(text_input:str,query:str):
    temp_literary_stopwords=local_config.literary_stopwords
    recall_index=local_config.recall_index
    neighbor_num=local_config.neighbor_num
    deep_search_num=local_config.deep_search_num
    deep_search_index=local_config.deep_search_index
    start_prepare_time=time.time()
    logging.debug("splitting...")
    sentences_list = split_into_sentences_and_count_tokens_with_sid(text_input)
    logging.debug("splitting done")
    end_prepare_time=time.time()
    preparetime=end_prepare_time-start_prepare_time
    start_retrieve_time = time.time()
    logging.debug("extracting...")

    keywords_extracted = send(
            f"QUERY: {query}" 
            "\nPROMPT: Extract proper keywords from both the query and its options. "
            "Output the keywords **ONLY** in the following format: "
            "\n[\"keyword1\", \"keyword2\", \"keyword3\", ...] (A JSON array of strings). "
            "DO NOT include any extra text, explanation, or formatting!!"
            "Note: Do not include 'chapter' as a keyword."
        )    
    print("here are keywords extracted from the query:")
    print(keywords_extracted)
    #得到topk个句子
    logging.debug(recall_index)
    top_k_sentences=get_top_k_sentences(sentences_list=sentences_list,question=keywords_extracted,recall_index=recall_index,literary_stopwords=temp_literary_stopwords)
    cnt=0
    for item in top_k_sentences:
        cnt+=1
        print(item)
        if(cnt>=5):
            break
    
    print("get top k sentence done!")
    # 遍历所有 topk sentences
    Max=top_k_sentences[0][2]
    first_class_index =1

    for sid, _, similarity, common_words in top_k_sentences:
        if similarity < Max :
            break
        elif first_class_index >= deep_search_index:
            break
        first_class_index += 1
    for i in range(first_class_index+first_class_index):
            # Convert the tuple to a list
            temp_index=top_k_sentences[i][0]
            # Modify the second element of the list
            temp = (
                "\n!!!PAY MORE ATTENTION TO THIS IMPORTANT SENTENCE!!!\n<START OF THIS SENTENCE>\n"
                + top_k_sentences[i][1]
                + "\n<END OF THIS SENTENCE>\n"
            )

            sentences_list[temp_index-1]['sentence']=temp
    deep_search_neighbour_num = (deep_search_num // first_class_index - 1) // 2
    logging.debug(f"first_class_index:{first_class_index}")
    logging.debug(f"deep neighbour num:{deep_search_neighbour_num}")
    chapter_list=get_top_k_sentences(sentences_list,"CHAPTER",temp_literary_stopwords,100)
    chapter_list=clean_chapter_list(chapter_list)
    #插入chapter信息到所有句子中
    all_sentence_1=extract_neighboring_sentences(sentences_list, top_k_sentences[:first_class_index], k_neighbors=deep_search_neighbour_num)#加深搜索
    all_sentence_2=extract_neighboring_sentences(sentences_list, top_k_sentences[first_class_index:], k_neighbors=neighbor_num)#正常搜索
    all_sentences=all_sentence_1+all_sentence_2
    all_sentences_sorted = sorted(all_sentences, key=lambda x: x['SID'])  # 按照 SID 排序
    all_sentences_sorted=insert_chapter_information(chapter_list=chapter_list,all_sentences_sorted=all_sentences_sorted)
    retrieve_data = ""
    for entry in all_sentences_sorted:
        if len(entry['sentence']) <=3:
            pass
        else:
            retrieve_data += "SentenceID" + str(entry['SID']) + ":" + entry['sentence'] + "\n\n"  # 提取 'sentence' 并加上换行符
    end_retrieve_time = time.time()
    retrieve_time=end_retrieve_time-start_retrieve_time
    print("---retrieve done!---")
    resp={
        'retrieve_data':retrieve_data,
        'prepare_time':preparetime,
        'retrieve_time':retrieve_time,
        'keywords_extracted':keywords_extracted,
    }
    return resp

SUFFICIENCY_PROMPT = """
You are an impartial judge that only answers "yes" or "no".
Question:
{query}

Retrieved information:
{retrieved}

Is the information above sufficient to answer the question accurately and confidently?
Reply with ONLY "yes" or "no".
""".strip()


def _check_retrieval_sufficient(query: str, retrieved: str, provider: str = "deepseek") -> str:
    """
    使用指定模型判断检索结果是否足够回答问题。
    优先调用 deepseek，失败时回退到 send。
    """
    prompt = SUFFICIENCY_PROMPT.format(query=query, retrieved=retrieved)
    provider = provider or ""

    if provider and provider in llm_manager.get_available_providers():
        try:
            result = llm_manager.send(prompt, provider=provider, use_fallback=False)
            if result.get("success"):
                return (result.get("content") or "").strip().lower()
        except Exception as exc:
            logging.warning("Sufficiency check via %s failed: %s", provider, exc)

    try:
        return send(prompt).strip().lower()
    except Exception as exc:
        logging.error("Fallback sufficiency check failed: %s", exc)
        return "no"


def retrieve_iter(text_input: str, query: str, max_iterations: int = 3, provider: str = "deepseek") -> dict:
    """
    迭代调用 retrieve，使用 deepseek 判断信息是否足够。
    若不足，则将上次的 retrieve 结果作为输入继续检索，最多迭代 max_iterations 次。
    """
    current_input = text_input
    aggregated_data = ""
    all_keywords = []
    iteration_logs = []
    last_resp = None

    for iteration in range(1, max_iterations + 1):
        resp = retrieve(current_input, query)
        last_resp = resp
        aggregated_data += f"\n=== Iteration {iteration} ===\n{resp['retrieve_data']}"
        all_keywords.append(resp.get("keywords_extracted", ""))

        suff_response = _check_retrieval_sufficient(query, resp["retrieve_data"], provider=provider)
        iteration_logs.append(
            {
                "iteration": iteration,
                "keywords": resp.get("keywords_extracted", ""),
                "retrieve_time": resp.get("retrieve_time", 0.0),
                "sufficient_response": suff_response,
            }
        )

        if "yes" in suff_response:
            break

        current_input = resp["retrieve_data"]

    if last_resp is None:
        return {
            "retrieve_data": "",
            "prepare_time": 0.0,
            "retrieve_time": 0.0,
            "keywords_extracted": "",
            "iteration_count": 0,
            "sufficient_reached": False,
            "iteration_logs": iteration_logs,
        }

    last_resp["retrieve_data"] = aggregated_data
    last_resp["keywords_extracted"] = " ".join(k for k in all_keywords if k)
    last_resp["iteration_logs"] = iteration_logs
    last_resp["iteration_count"] = len(iteration_logs)
    last_resp["sufficient_reached"] = "yes" in (iteration_logs[-1]["sufficient_response"] if iteration_logs else "")
    return last_resp

def retrieve_useful(text_input:str,query:str,cached_keywords:str):
    temp_literary_stopwords=local_config.literary_stopwords
    recall_index=local_config.recall_index
    neighbor_num=local_config.neighbor_num
    deep_search_num=local_config.deep_search_num
    deep_search_index=local_config.deep_search_index
    start_prepare_time=time.time()
    logging.debug("splitting...")
    sentences_list = split_into_sentences_and_count_tokens_with_sid(text_input)
    logging.debug("splitting done")
    end_prepare_time=time.time()
    preparetime=end_prepare_time-start_prepare_time
    start_retrieve_time = time.time()
    logging.debug("extracting...")
    router_index = send(f"""
                        You are a query classifier.

                        QUERY: {query}

                        INSTRUCTIONS:
                        Please judge the type of the question. Your task is to classify it into one of the following two categories:

                        1. If the question is asking for a high-level overview, summary of the whole document, general gist, or global understanding, respond with exactly:
                        global

                        2. If the question is asking for specific details, particular facts, numbers, entities, events, or local information from a specific part of the document, respond with exactly:
                        detailed

                        Do NOT respond with anything other than "global" or "detailed".
                        Do NOT explain your reasoning.
                        Do NOT include punctuation or extra words.
                        Just return: global OR detailed
                        """)
    
    print("\033[1;32m" + router_index + "\033[0m")
    if router_index[0]=="g":
        print("\033[33m" + "A global question detected!" + "\033[0m")
        keywords_extracted = send(
                f"QUERY: {query}" +"Here are some cached keywords"+cached_keywords+
                "\nPROMPT: select keywords from given query and cached keywords "
                "However, the selected cached keywords must have stong relevance to the qeury"
                "Output the keywords **ONLY** in the following format: "
                "\n[\"keyword1\", \"keyword2\", \"keyword3\", ...] (A JSON array of strings). "
                "DO NOT include any extra text, explanation, or formatting!!"
                "Note: Do not include 'chapter' as a keyword."
            ) 
        keywords_extracted = send(
                f"QUERY: {query}" +"Here are some cached keywords"+keywords_extracted+
                "\nPROMPT: Extract proper keywords from given query and cached keywords "
                "Output the keywords **ONLY** in the following format: "
                "\n[\"keyword1\", \"keyword2\", \"keyword3\", ...] (A JSON array of strings). "
                "DO NOT include any extra text, explanation, or formatting!!"
                "Note: Do not include 'chapter' as a keyword."
            )  
    
    else:
        print("\033[33m" + "A detailed question detected!" + "\033[0m")

        keywords_extracted = send(
                f"QUERY: {query}" 
                "\nPROMPT: Extract proper keywords from given query and cached keywords "
                "Output the keywords **ONLY** in the following format: "
                "\n[\"keyword1\", \"keyword2\", \"keyword3\", ...] (A JSON array of strings). "
                "DO NOT include any extra text, explanation, or formatting!!"
                "Note: Do not include 'chapter' as a keyword."
            )    
    print("here are keywords extracted from the query:")
    print("\033[33m" + keywords_extracted + "\033[0m")
    
    #得到topk个句子
    logging.debug(recall_index)
    top_k_sentences=get_top_k_sentences(sentences_list=sentences_list,question=keywords_extracted,recall_index=recall_index,literary_stopwords=temp_literary_stopwords)
    cnt=0
    # for item in top_k_sentences:
    #     cnt+=1
    #     print(item)
    #     if(cnt>=5):
    #         break
    
    print("get top k sentence done!")
    # 遍历所有 topk sentences
    Max=top_k_sentences[0][2]
    first_class_index =1

    for sid, _, similarity, common_words in top_k_sentences:
        if similarity < Max :
            break
        elif first_class_index >= deep_search_index:
            break
        first_class_index += 1
    # for i in range(first_class_index+first_class_index):
    #         # Convert the tuple to a list
    #         temp_index=top_k_sentences[i][0]
    #         # Modify the second element of the list
    #         temp = (
    #             "\n!!!PAY MORE ATTENTION TO THIS IMPORTANT SENTENCE!!!\n<START OF THIS SENTENCE>\n"
    #             + top_k_sentences[i][1]
    #             + "\n<END OF THIS SENTENCE>\n"
    #         )

    #         sentences_list[temp_index-1]['sentence']=temp
    deep_search_neighbour_num = (deep_search_num // first_class_index - 1) // 2
    logging.debug(f"first_class_index:{first_class_index}")
    logging.debug(f"deep neighbour num:{deep_search_neighbour_num}")
    chapter_list=get_top_k_sentences(sentences_list,"CHAPTER",temp_literary_stopwords,100)
    chapter_list=clean_chapter_list(chapter_list)
    #插入chapter信息到所有句子中
    all_sentence_1=extract_neighboring_sentences(sentences_list, top_k_sentences[:first_class_index], k_neighbors=deep_search_neighbour_num)#加深搜索
    all_sentence_2=extract_neighboring_sentences(sentences_list, top_k_sentences[first_class_index:], k_neighbors=neighbor_num)#正常搜索
    all_sentences=all_sentence_1+all_sentence_2
    #all_sentences_sorted = sorted(all_sentences, key=lambda x: x['SID'])  # 按照 SID 排序
    # 用一个字典来去重，确保每个 SID 只保留一个句子（保留第一个出现的）
    unique_sentences_dict = {}
    for sentence in all_sentences:
        sid = sentence['SID']
        if sid not in unique_sentences_dict:
            unique_sentences_dict[sid] = sentence

    # 然后再按 SID 升序排序
    all_sentences_sorted = sorted(unique_sentences_dict.values(), key=lambda x: x['SID'])

    all_sentences_sorted=insert_chapter_information(chapter_list=chapter_list,all_sentences_sorted=all_sentences_sorted)
    retrieve_data = "SentenceID indicates the position of the sentence within the entire context."
    for entry in all_sentences_sorted:
        if len(entry['sentence']) <=3:
            pass
        else:
            retrieve_data += "SentenceID" + str(entry['SID']) + ":" + entry['sentence']   # 提取 'sentence' 并加上换行符
    end_retrieve_time = time.time()
    retrieve_time=end_retrieve_time-start_retrieve_time
    print("---retrieve done!---")
    resp={
        'retrieve_data':retrieve_data,
        'prepare_time':preparetime,
        'retrieve_time':retrieve_time,
        'keywords_extracted':keywords_extracted,
    }
    return resp


def is_counting(query):
    """
    检测是否为简单计数问题，直接统计关键词出现次数
    """
    index = query.find("\"Options\"")
    question = query[:index-1] if index != -1 else query
    
    id_prompt = (f"""We define a "simple counting problem" as a question that can be solved **only by counting exact matches of a specific keyword, phrase, or sentence** — no reasoning, inference, or interpretation is allowed.

Here are labeled examples:
1. Q: How many times is the word "Leo" mentioned? → Yes
2. Q: Count the occurrences of the phrase "I'm sorry". → Yes
3. Q: Which chapters mention "freedom"? → No (asks for locations, not count)
4. Q: How often is the word "fight" used in the text? → Yes
5. Q: When did John and Alice meet? → No (requires reasoning about events)
6. Q: How many times does the word "war" appear? → Yes
7. Q: In how many scenes are both Bob and Alice present? → No (requires reasoning on presence and co-occurrence)

Now classify this question:  
{question}

First answer with "Yes" or "No", then briefly explain your reasoning.
<example answer> Yes, because the question can be solved by counting the occurrence of the word "Leo".""")
    
    gen_param = (f"""Given that the question below is a simple counting numbers problem that only requires looking up and count the number of occurance of a specific keyword, phrase, or sentence.
                 your task is to find find THE keyword, phrase, or sentense that should be used for the question: {question}. 
                 NOTE that you MUST find one and ONLY one of such keyword, phrase or sentence and MUST NOT find both a keyword and a sentence, etc.
                 In your answer, put the keyword, phrase, or sentense as a single json string inside a json array. <example> ["answer text"].
                 Do not include any extra text, explanation, or formatting. However, you MUST keep all the formatting contained in the keyword.""")
    
    resp = send(id_prompt)
    
    resp = re.sub(r'[^a-zA-Z]', '', resp)
    print("is counting:",resp)
    if resp.strip() and 'yes' in resp.strip().lower():
        while True:
            try:
                resp = send(gen_param)
                resp = ast.literal_eval(resp)
                break
            except Exception as e:
                print(f"Error parsing counting keyword: {e}")
                return None
        
        expand = (f"""Given a sentence or word, if applicable, provide a list containing the original sentence or word and all its forms (plural, past tense form, present continuing form, perfect tense form). Note that if there is a 'be' or 'been', you should expand all varieties of it into the list.
                  In your answer, put the keyword, phrase, or sentense as json strings inside a json array. <example> ["answer text", "answer text", ...]. 
                  Do not include any extra text, explanation, or formatting. If the input word or sentence is not applicable, then simple output the exact word or sentence in format ["the input"]
                  Here is the sentence or word: {resp[0]}
                  Your Answer: """)
        
        while True:
            try:
                resp = send(expand)
                resp = ast.literal_eval(resp)
                break
            except Exception as e:
                print(f"Error expanding keywords: {e}")
                return [resp[0]] if resp else None
        
        if isinstance(resp[0], list):
            temp = []
            for ins in resp:
                temp.extend(ins)
            resp = temp
        
        print("EXPANDED COUNTING KEYWORDS: ", resp)
        return resp
    return None

def is_imp_counting(query):
    """
    检测是否为推理性计数问题，需要推理后计数
    """
    index = query.find("\"Options\"")
    question = query[:index-1] if index != -1 else query
    
    id_prompt = (f"""We define a "reasoning-based counting problem" as a question that **requires counting events or patterns, but only after some logical reasoning or filtering** — for example, identifying when two people meet, or when a condition is met.

Important rules:
- These questions **usually involve a number-based answer (e.g. 3, 5, 10)**.
- It is NOT a reasoning-based counting problem if it just asks for chapter names or locations of keywords.
- It IS a reasoning-based counting problem if some inference must be done before counting.

Labeled examples:
1. Q: How many times did Alice and Bob meet? → Yes (need to reason about co-occurrence)
2. Q: In how many scenes does John apologize? → Yes (need to understand event semantics)
3. Q: Count how many times the phrase "he smiled" appears. → No (direct counting)
4. Q: Which chapters mention "justice"? → No (not asking for count)
5. Q: How many times did the hero kill a monster? → Yes (need event matching, not just keywords)
6. Q: How many letters does she write? → Yes (need to identify event type)

Now classify the following question:
{question}

First answer with "Yes" or "No", then briefly explain your reasoning.
<example answer> Yes, because it requires identifying when both characters appear together and interact, which needs reasoning.
""")
    
    gen_param = (f"""Given that the question below is a counting numbers problem that requires looking up and count the number of occurance of a specific event.
                 your task is to find find THE event that should be used for the question: {question}. 
                 NOTE that you MUST find one and ONLY one of such event as a keyword or a phrase and MUST NOT find both a keyword and a phrase, etc.
                 In your answer, put the keyword or phrase as a single json string inside a json array. <example> ["answer text"]. If you have a phrase made up of multiple words, you should also append the important words in the list. <example> ["NameA meets NameB", "NameA", "NameB", "meet"]
                 Do not include any extra text, explanation, or formatting. However, you MUST keep all the formatting contained in the keyword.""")
    
    resp = send(id_prompt)
    resp = re.sub(r'[^a-zA-Z]', '', resp)
    print("is imp counting",resp)
    if resp.strip() and 'yes' in resp.strip().lower():
        while True:
            try:
                resp = send(gen_param)
                resp = ast.literal_eval(resp)
                break
            except Exception as e:
                print(f"Error parsing imp counting keyword: {e}")
                return None
        
        expand = (f"""Given a list of phrase, sentence or words, if the input is a word, when applicable, provide a list containing the original word and all its forms (plural, past tense form, present continuing form, perfect tense form).
                  IF the input is phrase or sentences, check whether it is a short subject verb phrase like "He cry", "She laughed", etc. If so, provide a list containing the original phrase or word and all its forms. If NOT, do not change ANYTHING.
                  In your answer, put the keyword, phrase, or sentense as json strings inside a json array. <example> ["answer text", "answer text", ...]. 
                  Do not include any extra text, explanation, or formatting. If the input word or sentence is not applicable, then simple output the exact word or sentence in format ["the input"].
                  Here is the LIST OF INPUT: {str(resp[0])}
                  Your Answer: """)
        
        while True:
            try:
                resp = send(expand)
                resp = ast.literal_eval(resp)
                break
            except Exception as e:
                print(f"Error expanding imp keywords: {e}")
                return [resp[0]] if resp else None
        
        if isinstance(resp[0], list):
            temp = []
            for ins in resp:
                temp.extend(ins)
            resp = temp
        
        print("EXPANDED IMP COUNTING KEYWORDS: ", resp)
        return resp
    return None

def count_in_text(text, keys, query):
    """
    在文本中计数关键词出现次数并返回对应选项
    """
    text = text.lower()
    num_matches = 0
    for key in keys:
        key = key.lower()
        pattern = r'\b' + re.escape(key) + r'\b'
        num_matches += len(re.findall(pattern, text))
    
    # 尝试解析选项
    try:
        query = '{' + query + '}' if not query.startswith('{') else query
        query_dict = ast.literal_eval(query)
        options = query_dict.get("Options", {})
        
        # 检查哪个选项包含计数结果
        for option_key in ['A', 'B', 'C', 'D']:
            if option_key in options and str(num_matches) in str(options[option_key]):
                print(f"COUNT: {num_matches}, MATCHED OPTION: {option_key}")
                return option_key
        
        # 如果没有精确匹配，使用LLM选择最接近的选项
        prompt = (f"""Given that the total number is {num_matches}, 
                  match the choice that has the same number. If there is no matches, choose the choice with CLOSEST number if the number provided is not 0. If the number provided above is 0, choose the choice corresponds to "no, never".
                  The choices are: {options}. You MUST select a choice from A, B, C, or D. Do not include any extra text, explanation, or formatting.""")
        
        ans = send(prompt).strip().split()[0].upper().replace('.', '').replace(')', '')
        print(f"COUNT: {num_matches}, LLM SELECTED: {ans}")
        return ans
        
    except Exception as e:
        print(f"Error in count_in_text: {e}")
        return "A"  # 默认返回A

def retrieveIter(text_input:str, query:str, cached_keywords:str, max_iterations:int=3)->dict:
    """
    带有 sufficient 判断的迭代检索函数，包含计数问题检测
    
    Args:
        text_input: 输入文本
        query: 查询问题
        cached_keywords: 缓存的关键词
        max_iterations: 最大迭代次数
    
    Returns:
        dict: 包含检索结果、关键词、迭代信息等
    """
    start_time = time.time()
    
    # 首先检测是否为计数问题
    print(f"\033[1;34m=== Starting Query Analysis ===\033[0m")
    
    # 检测简单计数问题
    counting_keyword = is_counting(query)
    if counting_keyword is not None:
        print(f"\033[1;32m✓ Simple counting problem detected!\033[0m")
        print(f"\033[33mKeywords: {counting_keyword}\033[0m")
        
        count_result = count_in_text(text_input, counting_keyword, query)
        
        return {
            'retrieve_data': f"COUNTING RESULT: Found {count_result} based on keywords {counting_keyword}",
            'keywords_extracted': str(counting_keyword),
            'total_time': time.time() - start_time,
            'prepare_time': 0.0,
            'retrieve_time': time.time() - start_time,
            'iteration_count': 0,
            'sufficient_reached': True,
            'iteration_logs': [],
            'counting_result': count_result,
            'is_counting_problem': True
        }
    
    
    
    # 如果不是计数问题，执行正常的迭代检索
    print(f"\033[1;33m→ Regular retrieval problem detected\033[0m")
    
    temp_literary_stopwords = local_config.literary_stopwords
    recall_index = local_config.recall_index
    neighbor_num = local_config.neighbor_num
    deep_search_num = local_config.deep_search_num
    deep_search_index = local_config.deep_search_index
    
    # 初始化
    sentences_list = split_into_sentences_and_count_tokens_with_sid(text_input)
    all_keywords = cached_keywords
    all_retrieved_data = ""
    iteration_count = 0
    sufficient_reached = False
    iteration_logs = []
    
    print(f"\033[1;34m=== Starting Iterative Retrieval (Max: {max_iterations} iterations) ===\033[0m")
    
    for iteration in range(max_iterations):
        iteration_count += 1
        iter_start_time = time.time()
        
        print(f"\033[1;33m--- Iteration {iteration_count} ---\033[0m")
        
       

        keywords_extracted = send(
            f"QUERY: {query}\n"
            "PROMPT: Extract proper keywords from the query. "
            f"{prompt.format_prompt}"
        )
        
        print(f"\033[36mKeywords extracted: {keywords_extracted}\033[0m")
        
        # 执行检索
        top_k_sentences = get_top_k_sentences(
            sentences_list=sentences_list,
            question=keywords_extracted,
            recall_index=recall_index,
            literary_stopwords=temp_literary_stopwords
        )
        
        # Deep search 逻辑
        Max = top_k_sentences[0][2]
        first_class_index = 1
        
        for sid, _, similarity, common_words in top_k_sentences:
            if similarity < Max:
                break
            elif first_class_index >= deep_search_index:
                break
            first_class_index += 1
        
        deep_search_neighbour_num = (deep_search_num // first_class_index - 1) // 2
        
        # 提取章节信息
        chapter_list = get_top_k_sentences(sentences_list, "CHAPTER", temp_literary_stopwords, 100)
        chapter_list = clean_chapter_list(chapter_list)
        
        # 提取邻居句子 - 使用完整的检索逻辑
        print(f"\033[92m📖 Iteration {iteration_count}: Using full retrieval with recall_index={recall_index}, neighbors={neighbor_num}\033[0m")
        all_sentence_1 = extract_neighboring_sentences(sentences_list, top_k_sentences[:first_class_index], k_neighbors=deep_search_neighbour_num)
        all_sentence_2 = extract_neighboring_sentences(sentences_list, top_k_sentences[first_class_index:], k_neighbors=neighbor_num)
        all_sentences = all_sentence_1 + all_sentence_2
        
        # 去重并排序
        unique_sentences_dict = {}
        for sentence in all_sentences:
            sid = sentence['SID']
            if sid not in unique_sentences_dict:
                unique_sentences_dict[sid] = sentence
        
        all_sentences_sorted = sorted(unique_sentences_dict.values(), key=lambda x: x['SID'])
        all_sentences_sorted = insert_chapter_information(chapter_list=chapter_list, all_sentences_sorted=all_sentences_sorted)
        
        # 显示本次迭代检索到的句子数量
        print(f"\033[96m📊 Iteration {iteration_count}: Retrieved {len(all_sentences_sorted)} sentences\033[0m")
        
        # 构建当前迭代的检索数据
        current_retrieve_data = "SentenceID indicates the position of the sentence within the entire context.\n"
        sentence_count_added = 0
        for entry in all_sentences_sorted:
            if len(entry['sentence']) > 3:
                current_retrieve_data += f"SentenceID{entry['SID']}:{entry['sentence']}\n"
                sentence_count_added += 1
        
        print(f"\033[94m🔍 Debug: Actually added {sentence_count_added} sentences to current_retrieve_data\033[0m")
        
        # 累积检索数据
        all_retrieved_data += f"\n=== Iteration {iteration_count} Results ===\n" + current_retrieve_data
        
        iter_end_time = time.time()
        iter_time = iter_end_time - iter_start_time
        
        # Sufficient 判断
        sufficient_prompt = f"""
        QUERY: {query}
        
        RETRIEVED INFORMATION:
        {current_retrieve_data}
        
        PROMPT: Based on the retrieved information above, do you think there is sufficient information to answer the query comprehensively and accurately?
        
        Consider the following:
        1. Does the retrieved information directly address the key aspects of the query?
        2. Are there enough relevant details to provide a complete answer?
        3. Is the information specific enough to avoid ambiguity?
        
        Respond with ONLY one word:
        - "yes" if the information is adequate to answer the query
        - "no" if more information is needed
        
        DO NOT include any explanation or extra text. Respond with ONLY one word:
        - "yes" if the information is adequate to answer the query
        - "no" if more information is needed
        
        DO NOT include any explanation or extra text. Respond with ONLY one word:
        - "yes" if the information is adequate to answer the query
        - "no" if more information is needed
        
        DO NOT include any explanation or extra text. Respond with ONLY one word:
        - "yes" if the information is adequate to answer the query
        - "no" if more information is needed
        
        DO NOT include any explanation or extra text.
        """
        
        sufficient_response = send(sufficient_prompt).strip().lower()
        
        iteration_log = {
            'iteration': iteration_count,
            'keywords': keywords_extracted,
            'top_sentences_count': len(top_k_sentences),
            'retrieve_time': iter_time,
            'sufficient_response': sufficient_response,
            'data_length': len(current_retrieve_data)
        }
        iteration_logs.append(iteration_log)
        
        print(f"\033[1;35mSufficient check: {sufficient_response}\033[0m")
        print(f"\033[90mIteration {iteration_count} time: {iter_time:.2f}s\033[0m")
        
        # 判断是否足够
        if "yes" in sufficient_response:
            sufficient_reached = True
            print(f"\033[1;32m✓ Information sufficient after {iteration_count} iteration(s)\033[0m")
            break
        else:
            # 更新关键词用于下次迭代
            augment_prompt = f"""
            QUERY: {query}
            CURRENT RETRIEVED INFORMATION:
            {current_retrieve_data}
            
            PROMPT: The current information is insufficient to answer the query. 
            Extract additional keywords that might help find more relevant information.
            Focus on aspects that seem missing or need more detail.
            
            {prompt.format_prompt}
            """
            
            additional_keywords = send(augment_prompt)
            all_keywords += " " + additional_keywords
            
            print(f"\033[93mInsufficient - adding keywords: {additional_keywords}\033[0m")
    
    total_time = time.time() - start_time
    
    # 最终结果
    if not sufficient_reached:
        print(f"\033[1;31m⚠ Reached max iterations ({max_iterations}) without achieving sufficiency\033[0m")
    
    print(f"\033[1;34m=== Iterative Retrieval Complete ===\033[0m")
    print(f"\033[90mTotal time: {total_time:.2f}s, Iterations: {iteration_count}\033[0m")
    
    return {
        'retrieve_data': all_retrieved_data,
        'keywords_extracted': all_keywords,
        'total_time': total_time,
        'prepare_time': 0.0,
        'retrieve_time': total_time,
        'iteration_count': iteration_count,
        'sufficient_reached': sufficient_reached,
        'iteration_logs': iteration_logs
    }
