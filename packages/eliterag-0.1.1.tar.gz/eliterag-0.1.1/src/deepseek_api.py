import time
from typing import Dict, Any, Optional

# Please install OpenAI SDK first: `pip3 install openai`
try:
    from openai import OpenAI
except ImportError:
    print("Please install OpenAI SDK first: `pip3 install openai`")
    OpenAI = None

class DeepSeekAPI:
    def __init__(self, api_key: str, base_url: str = "https://api.deepseek.com"):
        if OpenAI is None:
            raise ImportError("OpenAI SDK not installed. Please run: pip3 install openai")
        
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url
        )
    
    def chat_completion(self, 
                       messages: list,
                       model: str = "deepseek-chat",
                       temperature: float = 0.7,
                       max_tokens: int = 2048) -> Dict[str, Any]:
        """
        Send chat completion request to DeepSeek API using OpenAI SDK
        """
        try:
            response = self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=False
            )
            
            return {
                "choices": [{
                    "message": {
                        "content": response.choices[0].message.content
                    }
                }]
            }
        except Exception as e:
            print(f"DeepSeek API request failed: {e}")
            return {"error": str(e)}
    
    def send_message(self, prompt: str, model: str = "deepseek-chat") -> str:
        """
        Send a simple message and return the response text
        """
        messages = [
            {"role": "system", "content": "You are a helpful assistant"},
            {"role": "user", "content": prompt}
        ]
        
        result = self.chat_completion(messages, model)
        
        if "error" in result:
            return f"Error: {result['error']}"
        
        try:
            return result["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            return f"Error parsing response: {e}"

# Global DeepSeek client instance
deepseek_client = None

def init_deepseek_client(api_key: str):
    """Initialize the global DeepSeek client"""
    global deepseek_client
    try:
        deepseek_client = DeepSeekAPI(api_key)
        print("DeepSeek client initialized successfully")
    except Exception as e:
        print(f"Failed to initialize DeepSeek client: {e}")
        deepseek_client = None

def send_deepseek(prompt: str, model: str = "deepseek-chat") -> Dict[str, Any]:
    """
    Send request to DeepSeek API - compatible with existing send() function interface
    """
    if deepseek_client is None:
        return {"response": "Error: DeepSeek client not initialized", "time": 0}
    
    start_time = time.time()
    response_text = deepseek_client.send_message(prompt, model)
    end_time = time.time()
    
    return {
        "response": response_text,
        "time": end_time - start_time
    }

def get_deepseek_embedding(text: str) -> Optional[list]:
    """
    DeepSeek doesn't provide embedding API, so we'll use a simple text processing approach
    or return None to indicate embeddings are not available
    """
    print("Warning: DeepSeek API doesn't provide embeddings. Using text-based similarity.")
    return None