"""
User-facing import surface for the ELITE retrieval framework.

Example:
    import elite.core_functions as cf
    resp = cf.retrieve(text, query)

This package forwards to the original implementation in ``src.*`` to keep
behavior identical while providing a stable ``elite`` namespace for pip users.
"""

from src import core_functions, utils, prompt, dataloader, deepseek_api  # re-export

__all__ = [
    "core_functions",
    "utils",
    "prompt",
    "dataloader",
    "deepseek_api",
]
