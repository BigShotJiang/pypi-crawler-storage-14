"""Thin wrapper exposing DeepSeek helper under the ``elite`` namespace."""

from src.deepseek_api import *  # noqa: F401,F403
