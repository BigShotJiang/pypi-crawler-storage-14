"""Thin wrapper exposing prompt templates under the ``elite`` namespace."""

from src.prompt import *  # noqa: F401,F403
