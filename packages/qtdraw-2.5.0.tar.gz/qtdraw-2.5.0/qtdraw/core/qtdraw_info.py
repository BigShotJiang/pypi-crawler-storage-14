__version__ = "2.5.0"
__date__ = "2021 -"
__author__ = "Hiroaki Kusunose"
__top_dir__ = __file__.replace("\\", "/").rsplit("/", 3)[0]  # 3 = 3 higher directory (w/o postfix).
