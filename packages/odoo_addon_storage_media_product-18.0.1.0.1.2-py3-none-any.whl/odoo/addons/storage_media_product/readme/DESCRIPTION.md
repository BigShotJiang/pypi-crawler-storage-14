Attach images to products and categories
