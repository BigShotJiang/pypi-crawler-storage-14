from __future__ import annotations


from ai_splitter.core import (
    BANNER,
    parse_input_text,
    assessment_pattern,
    random_split_total,
    random_split_total_strict,
    generate_assessment_excel,
)

__all__ = [
    "BANNER",
    "parse_input_text",
    "assessment_pattern",
    "random_split_total",
    "random_split_total_strict",
    "generate_assessment_excel",
]

__version__ = "0.1.1"
