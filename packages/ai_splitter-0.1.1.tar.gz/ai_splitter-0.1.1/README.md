# AI Splitter

**AI Spliiter By Sathish Ramanujam – (https://professor-sathish.github.io/)**

`ai-splitter` is a Python package and Streamlit app that automatically splits a **student’s total marks** into **question-wise** and **CO-wise** marks, and exports a fully formatted **Excel CO Evaluation Sheet**.

It is designed for **faculty, CO coordinators, and exam cell members** who handle outcome-based assessments (OBA).

---

## Features

- 🎯 Supports multiple regulations .
- 🧮 Built-in **assessment patterns** (IA1, IA2, Model, Lab, Project).
- ⚙️ **Custom assessment mode (CUS)** – define your own question pattern.
- 📊 Generates a completely formatted **Excel sheet** ready to submit:
  - Question-wise marks  
  - CO-wise totals  
  - Grand total per student  
  - Colored headers, borders, and “Verified & Approved By” row
- 🧠 Randomized mark split logic:
  - Normal mode: “band” logic (weak/average/good/excellent)
  - Custom mode: strict sum + per-question max validation
- 🖥️ Streamlit UI for non-programmers.

---

## Installation

> Once published on PyPI you’ll be able to do:

```bash
pip install ai-splitter
