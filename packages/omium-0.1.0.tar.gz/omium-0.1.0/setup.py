from setuptools import setup

# All metadata and dependencies are defined in pyproject.toml (PEP 621).
# This file exists only as a shim for older tooling that imports `setup.py`.
setup()
