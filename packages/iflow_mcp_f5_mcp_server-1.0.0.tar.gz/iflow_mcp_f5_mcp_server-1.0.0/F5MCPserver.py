"""

This is a MCP server, that interacts with an F5 device using iControl REST API.


"""

import asyncio
import logging
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool
from Tools.F5object import F5_object

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize MCP server
server = Server("f5-mcp-server")


@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """List available F5 management tools."""
    return [
        Tool(
            name="show_stats_tool",
            description="Shows the stats of an object from an F5 device using the iControl REST API",
            inputSchema={
                "type": "object",
                "properties": {
                    "object_name": {"type": "string", "description": "Name of the object"},
                    "object_type": {"type": "string", "description": "Type of object: virtual, pool, irule, or profile"}
                },
                "required": ["object_name", "object_type"]
            }
        ),
        Tool(
            name="show_logs_tool", 
            description="Shows logs from an F5 device using the iControl REST API",
            inputSchema={
                "type": "object",
                "properties": {
                    "lines_number": {"type": "string", "description": "Number of log lines to return"}
                },
                "required": ["lines_number"]
            }
        ),
        Tool(
            name="list_tool",
            description="Lists objects on an F5 device using the iControl REST API", 
            inputSchema={
                "type": "object",
                "properties": {
                    "object_name": {"type": "string", "description": "Name of the object"},
                    "object_type": {"type": "string", "description": "Type of object: virtual, pool, irule, or profile"}
                },
                "required": ["object_name", "object_type"]
            }
        ),
        Tool(
            name="create_tool",
            description="Creates an object on an F5 device using the iControl REST API",
            inputSchema={
                "type": "object", 
                "properties": {
                    "url_body": {"type": "object", "description": "Configuration of the object"},
                    "object_type": {"type": "string", "description": "Type of object: virtual, pool, irule, or profile"}
                },
                "required": ["url_body", "object_type"]
            }
        ),
        Tool(
            name="update_tool",
            description="Updates an object on an F5 device using the iControl REST API",
            inputSchema={
                "type": "object",
                "properties": {
                    "url_body": {"type": "object", "description": "Configuration of the object"},
                    "object_type": {"type": "string", "description": "Type of object: virtual, pool, irule, or profile"},
                    "object_name": {"type": "string", "description": "Name of the object"}
                },
                "required": ["url_body", "object_type", "object_name"]
            }
        ),
        Tool(
            name="delete_tool",
            description="Deletes an object from an F5 device using the iControl REST API",
            inputSchema={
                "type": "object",
                "properties": {
                    "object_type": {"type": "string", "description": "Type of object: virtual, pool, irule, or profile"},
                    "object_name": {"type": "string", "description": "Name of the object"}
                },
                "required": ["object_type", "object_name"]
            }
        )
    ]

@server.call_tool()
async def handle_call_tool(name: str, arguments: dict) -> list[dict]:
    """Handle tool calls."""
    try:
        if name == "show_stats_tool":
            stats = F5_object(object_name=arguments["object_name"], object_type=arguments["object_type"])
            result = stats.stats()
        elif name == "show_logs_tool":
            logs = F5_object(lines_number=arguments["lines_number"])
            result = logs.logs()
        elif name == "list_tool":
            f5_list = F5_object(object_name=arguments["object_name"], object_type=arguments["object_type"])
            result = f5_list.list()
        elif name == "create_tool":
            create = F5_object(url_body=arguments["url_body"], object_type=arguments["object_type"])
            result = create.create()
        elif name == "update_tool":
            update = F5_object(url_body=arguments["url_body"], object_type=arguments["object_type"], object_name=arguments["object_name"])
            result = update.update()
        elif name == "delete_tool":
            delete = F5_object(object_type=arguments["object_type"], object_name=arguments["object_name"])
            result = delete.delete()
        else:
            raise ValueError(f"Unknown tool: {name}")
            
        return [{"type": "text", "text": str(result)}]
    except Exception as e:
        logger.error(f"Error calling tool {name}: {e}")
        return [{"type": "text", "text": f"Error: {str(e)}"}]

async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())

def main():
    """Entry point for the server."""
    asyncio.run(main())

if __name__ == "__main__":
    main()
