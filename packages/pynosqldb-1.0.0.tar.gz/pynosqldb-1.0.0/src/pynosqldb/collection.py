from .storage.engine import StorageEngine
from .query.matcher import match_document
from .update.updater import apply_update
from .util import generate_doc_id

class Collection:
    """
    Represents a single collection in the database.
    """

    def __init__(self, name, storage: StorageEngine, index_manager):
        self.name = name
        self.storage = storage
        self.index_manager = index_manager
        self.offsets = {}  # doc_id -> integer file offset

    # ---------------------------
    # INSERT
    # ---------------------------
    def insert(self, doc: dict):
        if "_id" not in doc:
            doc["_id"] = generate_doc_id()

        doc_id = doc["_id"]
        record = {"op": "insert", "doc_id": doc_id, "doc": doc}
        offset = self.storage.append(record)
        self.offsets[doc_id] = offset  # store numeric offset

        # update indexes
        for field, tree in self.index_manager.indexes.get(self.name, {}).items():
            if field in doc:
                tree.insert(doc[field], offset)

        return doc_id

    # ---------------------------
    # FIND
    # ---------------------------
    def find(self, query: dict):
        results = []

        for doc_id, offset in self.offsets.items():
            record = self.storage.read(offset)
            if record is None or record["op"] == "delete":
                continue
            doc = record["doc"]
            if match_document(doc, query):
                results.append(doc)

        return results

    # ---------------------------
    # UPDATE
    # ---------------------------
    def update(self, query: dict, update_doc: dict):
        updated_count = 0

        for doc_id, offset in list(self.offsets.items()):
            record = self.storage.read(offset)
            if record is None or record["op"] == "delete":
                continue
            doc = record["doc"]

            if match_document(doc, query):
                # Apply updates and append new record
                new_doc = apply_update(doc.copy(), update_doc)
                new_record = {"op": "insert", "doc_id": doc_id, "doc": new_doc}
                new_offset = self.storage.append(new_record)
                self.offsets[doc_id] = new_offset

                # update indexes
                for field, tree in self.index_manager.indexes.get(self.name, {}).items():
                    if field in new_doc:
                        tree.insert(new_doc[field], new_offset)

                updated_count += 1

        return updated_count

    # ---------------------------
    # DELETE
    # ---------------------------
    def delete(self, query: dict):
        deleted_count = 0

        for doc_id, offset in list(self.offsets.items()):
            record = self.storage.read(offset)
            if record is None or record["op"] == "delete":
                continue
            doc = record["doc"]

            if match_document(doc, query):
                tombstone = {"op": "delete", "doc_id": doc_id}
                new_offset = self.storage.append(tombstone)
                self.offsets[doc_id] = new_offset  # store numeric offset
                deleted_count += 1

        return deleted_count
