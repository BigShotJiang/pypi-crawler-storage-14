class PyNoSQLError(Exception):
    """Base class for all errors in PyNoSQLDB."""
    pass


class StorageError(PyNoSQLError):
    """Errors related to file storage or corruption."""
    pass


class QueryError(PyNoSQLError):
    """Errors related to malformed queries."""
    pass


class UpdateError(PyNoSQLError):
    """Errors related to invalid updates."""
    pass


class IndexError(PyNoSQLError):
    """Errors related to index operations."""
    pass
