import time
import uuid
import hashlib


def now_ms():
    """Return current time in milliseconds."""
    return int(time.time() * 1000)


def generate_doc_id():
    """Generate unique document ID."""
    return uuid.uuid4().hex


def hash_key(key):
    """Return stable hash for indexing purposes."""
    return int(hashlib.sha256(key.encode()).hexdigest(), 16)