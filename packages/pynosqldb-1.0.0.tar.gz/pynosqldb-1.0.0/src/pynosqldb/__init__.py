"""
PyNoSQLDB — A lightweight embedded NoSQL database engine, JSON-document based,
inspired by MongoDB and SQLite.

Example usage:

    from pynosqldb import Database

    db = Database("mydb.pndb")
    db.open()

    users = db.collection("users")
    users.insert({"name": "Alice", "age": 30})

    print(users.find({"age": {"$gt": 25}}))
"""

from .database import Database

__all__ = ["Database"]
__version__ = "1.0.0"
