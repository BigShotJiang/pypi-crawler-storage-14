from .operators import (
    set_op,
    unset_op,
    inc_op,
    push_op,
    pull_op,
    add_to_set_op
)

def apply_update(doc, update_doc):
    """
    Apply MongoDB-style update operations to a document.
    Supported:
        $set, $unset, $inc, $push, $pull, $addToSet
    """

    for op, changes in update_doc.items():

        if op == "$set":
            for field, value in changes.items():
                set_op(doc, field, value)

        elif op == "$unset":
            for field in changes.keys():
                unset_op(doc, field)

        elif op == "$inc":
            for field, value in changes.items():
                inc_op(doc, field, value)

        elif op == "$push":
            for field, value in changes.items():
                push_op(doc, field, value)

        elif op == "$pull":
            for field, value in changes.items():
                pull_op(doc, field, value)

        elif op == "$addToSet":
            for field, value in changes.items():
                add_to_set_op(doc, field, value)

        else:
            raise ValueError(f"Unknown update operator: {op}")

    return doc
