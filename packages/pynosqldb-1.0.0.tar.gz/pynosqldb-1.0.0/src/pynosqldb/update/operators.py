def set_op(doc, field, value):
    """Set a nested field."""
    parts = field.split(".")
    target = doc
    for p in parts[:-1]:
        if p not in target or not isinstance(target[p], dict):
            target[p] = {}
        target = target[p]
    target[parts[-1]] = value


def unset_op(doc, field):
    """Remove a nested field."""
    parts = field.split(".")
    target = doc
    for p in parts[:-1]:
        if p not in target:
            return
        target = target[p]
    target.pop(parts[-1], None)


def inc_op(doc, field, value):
    """Increment a numeric field."""
    parts = field.split(".")
    target = doc
    for p in parts[:-1]:
        if p not in target:
            target[p] = {}
        target = target[p]

    last = parts[-1]
    target[last] = target.get(last, 0) + value


def push_op(doc, field, value):
    """Append to an array."""
    parts = field.split(".")
    target = doc
    for p in parts[:-1]:
        if p not in target:
            target[p] = {}
        target = target[p]

    arr = target.get(parts[-1], [])
    if not isinstance(arr, list):
        raise TypeError(f"Field '{field}' is not an array")
    arr.append(value)
    target[parts[-1]] = arr


def pull_op(doc, field, value):
    """Remove matching element(s) from an array."""
    parts = field.split(".")
    target = doc
    for p in parts[:-1]:
        if p not in target:
            return
        target = target[p]

    arr = target.get(parts[-1], [])
    if isinstance(arr, list):
        target[parts[-1]] = [v for v in arr if v != value]


def add_to_set_op(doc, field, value):
    """Add to array if it doesn't already exist."""
    parts = field.split(".")
    target = doc
    for p in parts[:-1]:
        if p not in target:
            target[p] = {}
        target = target[p]

    arr = target.get(parts[-1], [])
    if not isinstance(arr, list):
        raise TypeError(f"Field '{field}' is not an array")

    if value not in arr:
        arr.append(value)

    target[parts[-1]] = arr
