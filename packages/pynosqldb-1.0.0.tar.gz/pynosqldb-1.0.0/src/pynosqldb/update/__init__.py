from .updater import apply_update

__all__ = ["apply_update"]
