import argparse
import json
from pynosqldb.database import Database

def parse_args():
    parser = argparse.ArgumentParser(description="PyNoSQLDB CLI")
    parser.add_argument("dbpath", help="Path to the database")
    parser.add_argument("command", help="Command: insert/find/update/delete/create_index/compact")
    parser.add_argument("collection", help="Collection name")
    parser.add_argument("--query", help="Query JSON", default="{}")
    parser.add_argument("--update", help="Update JSON for update command", default="{}")
    parser.add_argument("--document", help="Document JSON for insert command", default="{}")
    parser.add_argument("--field", help="Field name for create_index", default="")
    return parser.parse_args()

def main():
    args = parse_args()

    db = Database(args.dbpath)
    db.open()
    coll = db.collection(args.collection)

    try:
        if args.command == "insert":
            doc = json.loads(args.document)
            doc_id = coll.insert(doc)
            print(f"Inserted _id: {doc_id}")

        elif args.command == "find":
            query = json.loads(args.query)
            results = coll.find(query)
            print(json.dumps(results, indent=2))

        elif args.command == "update":
            query = json.loads(args.query)
            update_doc = json.loads(args.update)
            count = coll.update(query, update_doc)
            print(f"Updated {count} documents")

        elif args.command == "delete":
            query = json.loads(args.query)
            count = coll.delete(query)
            print(f"Deleted {count} documents")

        elif args.command == "create_index":
            field = args.field
            if not field:
                print("Field name is required for create_index")
            else:
                db.create_index(args.collection, field)
                print(f"Index created on field '{field}'")

        elif args.command == "compact":
            db.compact()
            print("Database compacted")

        else:
            print(f"Unknown command: {args.command}")

    finally:
        db.close()

if __name__ == "__main__":
    main()
