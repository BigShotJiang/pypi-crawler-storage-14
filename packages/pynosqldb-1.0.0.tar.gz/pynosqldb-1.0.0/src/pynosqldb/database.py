import os
from .storage.engine import StorageEngine
from .storage.metadata import Metadata
from .storage.compaction import CompactionEngine
from .index.index_manager import IndexManager
from .collection import Collection

class Database:
    """
    Main database class — manages collections, storage, and indexes.
    """

    def __init__(self, path):
        self.path = path
        self.storage = StorageEngine(path + ".data")
        self.meta = Metadata(path + ".meta")
        self.index_manager = IndexManager(path)
        self.collections = {}

    # ---------------------------
    # OPEN / CLOSE
    # ---------------------------

    def open(self):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        self.storage.open()
        self.meta.load()
        self.index_manager.load_indexes(self.meta)

        # initialize collection objects
        for cname in self.meta.data["collections"]:
            self.collections[cname] = Collection(cname, self.storage, self.index_manager)

    def close(self):
        # 1. Close all collection-related index files first
        if self.index_manager:
            self.index_manager.close_all()  

        # 2. Close main storage engine and WAL
        if self.storage:
            self.storage.close()

        # 3. Save metadata and close any metadata-related files
        if self.meta:
            self.meta.save()



    # ---------------------------
    # COLLECTION MANAGEMENT
    # ---------------------------

    def collection(self, name):
        if name not in self.collections:
            # register in metadata
            self.meta.register_collection(name)
            self.meta.save()

            # create collection object
            self.collections[name] = Collection(name, self.storage, self.index_manager)

        return self.collections[name]

    # ---------------------------
    # INDEX MANAGEMENT
    # ---------------------------

    def create_index(self, collection_name, field):
        self.index_manager.create_index(collection_name, field)
        # store index info in metadata
        self.meta.data["indexes"].setdefault(collection_name, {})
        self.meta.data["indexes"][collection_name][field] = f"{self.path}.{collection_name}.{field}.idx"
        self.meta.save()

    # ---------------------------
    # COMPACTION
    # ---------------------------

    def compact(self):
        compactor = CompactionEngine(self.storage.path, self.meta)
        compactor.compact(self.collections)
