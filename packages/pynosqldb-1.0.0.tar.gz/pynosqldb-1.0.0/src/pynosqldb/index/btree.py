import os
from .index_file import IndexFile

class BTree:
    """
    Persistent B-Tree for indexing.
    Node format:
        {
            "keys":    [list of keys],
            "values":  [list of file offsets],
            "children":[list of child node IDs],
            "leaf":    bool
        }
    """

    ORDER = 32  # branching factor

    def __init__(self, path):
        self.path = path
        self.file = IndexFile(path)
        self.file.open()

        # Initialize root
        if os.path.getsize(path) == 0:
            self.root = self.file.alloc_block()
        else:
            self.root = 0  # first block is root

    # ---------------------------
    # Close file
    # ---------------------------
    def close(self):
        """Close underlying file safely."""
        if self.file:
            self.file.close()

    # ---------------------------
    # Node helpers
    # ---------------------------
    def read(self, node_id):
        return self.file.read_node(node_id)

    def write(self, node_id, node):
        self.file.write_node(node_id, node)

    # ---------------------------
    # Search
    # ---------------------------
    def search(self, key):
        """Return offsets for a key."""
        return self._search_node(self.root, key)

    def _search_node(self, node_id, key):
        node = self.read(node_id)

        for i, k in enumerate(node["keys"]):
            if key == k:
                return node["values"][i]
            if key < k:
                if node["leaf"]:
                    return []
                return self._search_node(node["children"][i], key)

        if node["leaf"]:
            return []
        return self._search_node(node["children"][-1], key)

    # ---------------------------
    # Insert
    # ---------------------------
    def insert(self, key, offset):
        root_node = self.read(self.root)
        if len(root_node["keys"]) == 2 * self.ORDER - 1:
            # split root
            new_root = self.file.alloc_block()
            self.write(new_root, {"keys": [], "values": [], "children": [self.root], "leaf": False})
            self._split_child(new_root, 0)
            self.root = new_root

        self._insert_nonfull(self.root, key, offset)

    def _insert_nonfull(self, node_id, key, offset):
        node = self.read(node_id)

        if node["leaf"]:
            # insert key in sorted order
            i = len(node["keys"]) - 1
            node["keys"].append(None)
            node["values"].append(None)

            while i >= 0 and key < node["keys"][i]:
                node["keys"][i + 1] = node["keys"][i]
                node["values"][i + 1] = node["values"][i]
                i -= 1

            node["keys"][i + 1] = key
            node["values"][i + 1] = [offset]  # store list of offsets
            self.write(node_id, node)
            return

        # internal node
        i = len(node["keys"]) - 1
        while i >= 0 and key < node["keys"][i]:
            i -= 1
        i += 1

        child_id = node["children"][i]
        child = self.read(child_id)

        if len(child["keys"]) == 2 * self.ORDER - 1:
            self._split_child(node_id, i)
            node = self.read(node_id)
            if key > node["keys"][i]:
                i += 1

        self._insert_nonfull(node["children"][i], key, offset)

    # ---------------------------
    # Split child
    # ---------------------------
    def _split_child(self, parent_id, i):
        parent = self.read(parent_id)
        child_id = parent["children"][i]
        child = self.read(child_id)

        mid = self.ORDER - 1

        # new right sibling
        new_id = self.file.alloc_block()
        new_node = {
            "keys": child["keys"][mid + 1:],
            "values": child["values"][mid + 1:],
            "children": child["children"][mid + 1:] if not child["leaf"] else [],
            "leaf": child["leaf"]
        }
        self.write(new_id, new_node)

        # shrink original child
        child["keys"] = child["keys"][:mid]
        child["values"] = child["values"][:mid]
        if not child["leaf"]:
            child["children"] = child["children"][:mid + 1]
        self.write(child_id, child)

        # promote key to parent
        parent["keys"].insert(i, child["keys"][mid] if mid < len(child["keys"]) else new_node["keys"][0])
        parent["values"].insert(i, child["values"][mid] if mid < len(child["values"]) else new_node["values"][0])
        parent["children"].insert(i + 1, new_id)
        self.write(parent_id, parent)
