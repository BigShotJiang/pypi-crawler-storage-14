import msgpack
import os

class IndexFile:
    """
    Block file used by BTree nodes.
    Each block = one node.
    """

    BLOCK_SIZE = 4096  # 4KB node size

    def __init__(self, path):
        self.path = path
        self.file = None

    def open(self):
        if not os.path.exists(self.path):
            with open(self.path, "wb") as f:
                pass
        self.file = open(self.path, "rb+")

    def close(self):
        if self.file:
            self.file.close()

    # ----------------------------

    def read_node(self, block_id):
        self.file.seek(block_id * self.BLOCK_SIZE)
        data = self.file.read(self.BLOCK_SIZE)
        return msgpack.unpackb(data.rstrip(b"\x00"))

    def write_node(self, block_id, node):
        packed = msgpack.packb(node)
        padded = packed.ljust(self.BLOCK_SIZE, b"\x00")

        self.file.seek(block_id * self.BLOCK_SIZE)
        self.file.write(padded)
        self.file.flush()

    # ----------------------------

    def alloc_block(self):
        """Allocate new block at end."""
        self.file.seek(0, os.SEEK_END)
        size = self.file.tell()
        new_block_id = size // self.BLOCK_SIZE

        # Write an empty block
        self.write_node(new_block_id, {"keys": [], "children": [], "leaf": True})
        return new_block_id
