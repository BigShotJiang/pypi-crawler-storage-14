import os
from .btree import BTree

class IndexManager:
    """
    Manages B-Tree indexes for all collections.
    Automatically loads and closes index files.
    """

    def __init__(self, db_path):
        self.db_path = db_path
        # Structure: {collection_name: {field_name: BTree}}
        self.indexes = {}

    # ---------------------------
    # Load indexes from metadata
    # ---------------------------
    def load_indexes(self, metadata):
        self.indexes = {}
        for coll, fields in metadata.data.get("indexes", {}).items():
            self.indexes[coll] = {}
            for field, idx_path in fields.items():
                if os.path.exists(idx_path):
                    tree = BTree(idx_path)
                    self.indexes[coll][field] = tree

    # ---------------------------
    # Create index
    # ---------------------------
    def create_index(self, collection_name, field):
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        self.indexes.setdefault(collection_name, {})
        idx_path = f"{self.db_path}.{collection_name}.{field}.idx"

        if field not in self.indexes[collection_name]:
            tree = BTree(idx_path)
            self.indexes[collection_name][field] = tree

    # ---------------------------
    # Search helper
    # ---------------------------
    def search(self, collection_name, field, key):
        tree = self.indexes.get(collection_name, {}).get(field)
        if tree:
            return tree.search(key)
        return []

    # ---------------------------
    # Close all B-Trees
    # ---------------------------
    def close_all(self):
        for coll, fields in self.indexes.items():
            for tree in fields.values():
                tree.close()
