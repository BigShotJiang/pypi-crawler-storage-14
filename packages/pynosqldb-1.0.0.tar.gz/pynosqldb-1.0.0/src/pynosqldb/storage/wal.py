import os
import msgpack

class WAL:
    """
    Simple append-only Write-Ahead Log storing MessagePack-encoded records.
    Supports append, read, replay, open, and close.
    """

    def __init__(self, path):
        self.path = path
        self.file = None

    def open(self):
        """Open WAL file for appending and reading."""
        self.file = open(self.path, "a+b")

    def append(self, record):
        """Append a record to the WAL and return its offset."""
        if self.file is None:
            self.open()

        packed = msgpack.packb(record)
        offset = self.file.tell()
        self.file.write(len(packed).to_bytes(4, "big"))
        self.file.write(packed)
        self.file.flush()
        return offset

    def read(self, offset):
        """Read a record from a given offset in the WAL."""
        if self.file is None:
            self.open()

        self.file.seek(offset)
        length_bytes = self.file.read(4)
        if not length_bytes:
            return None
        length = int.from_bytes(length_bytes, "big")
        packed = self.file.read(length)
        return msgpack.unpackb(packed, raw=False)

    def replay(self, storage_engine):
        """Replay all WAL entries into the main storage engine and clear WAL."""
        if not os.path.exists(self.path):
            return

        with open(self.path, "rb") as f:
            while True:
                length_bytes = f.read(4)
                if not length_bytes:
                    break
                length = int.from_bytes(length_bytes, "big")
                entry = f.read(length)

                # Append directly to main storage
                storage_engine.file.seek(0, os.SEEK_END)
                storage_engine.file.write(length.to_bytes(4, "big"))
                storage_engine.file.write(entry)

        # Clear WAL after replay
        open(self.path, "wb").close()

    def close(self):
        if self.file:
            self.file.close()
            self.file = None
