import json
import os

class Metadata:
    """
    Stores metadata about:
    - collections
    - last document ID
    - index definitions
    """

    def __init__(self, path):
        self.path = path
        self.data = {
            "collections": {}, 
            "indexes": {}
        }

    def load(self):
        if not os.path.exists(self.path):
            return
        with open(self.path, "r") as f:
            self.data = json.load(f)

    def save(self):
        with open(self.path, "w") as f:
            json.dump(self.data, f, indent=2)

    # -----------------------------
    # Collection metadata
    # -----------------------------

    def register_collection(self, name):
        if name not in self.data["collections"]:
            self.data["collections"][name] = {"doc_id": 0}

    def next_doc_id(self, name):
        self.data["collections"][name]["doc_id"] += 1
        return self.data["collections"][name]["doc_id"]
