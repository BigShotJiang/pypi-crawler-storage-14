import msgpack
import os
from .engine import StorageEngine

class CompactionEngine:
    """
    Copies only the latest version of each document into a new DB file,
    removing stale records and deleting tombstones.
    """

    def __init__(self, db_path, metadata):
        self.db_path = db_path
        self.new_path = db_path + ".compact"
        self.metadata = metadata

    def compact(self, collections):
        # Create new compact file engine
        new_engine = StorageEngine(self.new_path)
        new_engine.open()  # open the new storage

        # Close original storage engines first (important on Windows)
        for col in collections.values():
            if col.storage.file:
                col.storage.file.close()
                col.storage.file = None

        # For every collection
        for cname, col in collections.items():
            latest = {}

            # Read all old records using numeric offsets
            for doc_id, offset in col.offsets.items():
                record = col.storage.read(offset) if col.storage.file else None
                if record is None:
                    continue

                if record["op"] == "delete":
                    latest.pop(record["doc_id"], None)
                    continue

                latest[record["doc_id"]] = record

            # Write only latest versions to new engine
            new_offsets = {}
            for doc_id, record in latest.items():
                new_offset = new_engine.append(record)
                new_offsets[doc_id] = new_offset

            # Replace old offsets in collection with new ones
            col.offsets = new_offsets

        # Close new engine
        new_engine.close()

        # Replace old DB file with compacted one
        os.replace(self.new_path, self.db_path)
