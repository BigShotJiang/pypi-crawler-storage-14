import os
import struct
import msgpack

class BlockFile:
    """
    A fixed-block file used for index trees, metadata tables,
    and free-space maps.
    """

    BLOCK_SIZE = 4096  # 4 KB blocks

    def __init__(self, path):
        self.path = path
        self.file = None

    def open(self):
        if not os.path.exists(self.path):
            with open(self.path, "wb") as f:
                pass
        self.file = open(self.path, "rb+")

    def close(self):
        if self.file:
            self.file.close()

    def write_block(self, block_id, data):
        """Write msgpack data into a fixed-size block."""
        packed = msgpack.packb(data)
        padded = packed.ljust(self.BLOCK_SIZE, b"\x00")

        self.file.seek(block_id * self.BLOCK_SIZE)
        self.file.write(padded)
        self.file.flush()

    def read_block(self, block_id):
        """Read and decode a block."""
        self.file.seek(block_id * self.BLOCK_SIZE)
        raw = self.file.read(self.BLOCK_SIZE)
        return msgpack.unpackb(raw.rstrip(b"\x00"))
