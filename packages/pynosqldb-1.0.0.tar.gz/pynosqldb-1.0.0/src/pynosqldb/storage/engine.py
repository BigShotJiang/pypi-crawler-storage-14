import os
import msgpack
from .wal import WAL

class StorageEngine:
    """
    Low-level storage engine for PyNoSQL.
    Stores MessagePack-encoded records in a main file,
    and uses WAL for durability.
    """

    def __init__(self, path):
        self.path = path
        self.file = None
        self.wal = WAL(path + ".wal")

    def open(self):
        """Open main DB file and WAL."""
        self.file = open(self.path, "a+b")
        self.wal.open()

    def append(self, record):
        """Append a record with WAL logging; return numeric offset."""
        if self.file is None:
            self.open()

        # Log to WAL first
        self.wal.append(record)

        # Pack and write to main file
        packed = msgpack.packb(record)
        offset = self.file.tell()
        self.file.write(len(packed).to_bytes(4, "big"))
        self.file.write(packed)
        self.file.flush()
        return offset

    def read(self, offset):
        """Read record at given integer offset."""
        if self.file is None:
            self.open()

        offset = int(offset)  # ensure numeric
        self.file.seek(offset)
        length_bytes = self.file.read(4)
        if not length_bytes:
            return None
        length = int.from_bytes(length_bytes, "big")
        packed = self.file.read(length)
        return msgpack.unpackb(packed, raw=False)

    def replay_wal(self):
        """Replay WAL into main storage file."""
        self.wal.replay(self)

    def close(self):
        """Close main file and WAL."""
        if self.file:
            self.file.close()
            self.file = None
        if self.wal:
            self.wal.close()
            self.wal = None
