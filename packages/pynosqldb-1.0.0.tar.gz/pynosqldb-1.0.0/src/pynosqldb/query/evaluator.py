from .operators import OPERATORS

def eval_field(value, condition):
    """
    Evaluate a field against a condition.
    Condition can be:
        - literal (value must match exactly)
        - operator expression {"$gt": 5}
        - multiple ops {"$gt":5, "$lt":10}
    """
    if not isinstance(condition, dict):
        return value == condition

    for op, expected in condition.items():
        if op not in OPERATORS:
            raise ValueError(f"Unknown operator {op}")
        if not OPERATORS[op](value, expected):
            return False

    return True
