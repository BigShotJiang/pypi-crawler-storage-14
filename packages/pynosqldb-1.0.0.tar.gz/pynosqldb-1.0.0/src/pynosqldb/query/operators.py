def op_eq(v, e): return v == e
def op_ne(v, e): return v != e
def op_gt(v, e): return v > e
def op_gte(v, e): return v >= e
def op_lt(v, e): return v < e
def op_lte(v, e): return v <= e
def op_in(v, e): return v in e if isinstance(e, list) else False
def op_nin(v, e): return v not in e if isinstance(e, list) else True
def op_exists(v, e): return (v is not None) if e else (v is None)
def op_regex(v, e):
    import re
    if not isinstance(v, str):
        return False
    return re.search(e, v) is not None
def op_type(v, e):
    """Check value type (string, number, array, object, bool, null)."""
    types = {
        "string": str,
        "number": (int, float),
        "array": list,
        "object": dict,
        "bool": bool,
        "null": type(None)
    }
    return isinstance(v, types.get(e, object))

OPERATORS = {
    "$eq":  op_eq,
    "$ne":  op_ne,
    "$gt":  op_gt,
    "$gte": op_gte,
    "$lt":  op_lt,
    "$lte": op_lte,
    "$in":  op_in,
    "$nin": op_nin,
    "$exists": op_exists,
    "$regex": op_regex,
    "$type": op_type
}
