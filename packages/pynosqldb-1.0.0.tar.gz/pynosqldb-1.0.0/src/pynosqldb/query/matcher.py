from .evaluator import eval_field

def get_nested(document, key):
    """
    Retrieve nested field value.
    Example: key "user.name" returns doc["user"]["name"]
    """
    parts = key.split(".")
    value = document
    for p in parts:
        if isinstance(value, dict) and p in value:
            value = value[p]
        else:
            return None
    return value

def match_document(doc, query):
    """
    Check whether a document matches a query.
    Supports:
        - field queries
        - nested fields: {"user.name": "Alice"}
        - logical operators: $and, $or, $not
    """

    for key, condition in query.items():

        # Handle logical operators
        if key == "$and":
            return all(match_document(doc, subq) for subq in condition)

        if key == "$or":
            return any(match_document(doc, subq) for subq in condition)

        if key == "$not":
            return not match_document(doc, condition)

        # Normal field matching
        value = get_nested(doc, key)
        if not eval_field(value, condition):
            return False

    return True
