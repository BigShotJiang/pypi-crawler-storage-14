import asyncio
from typing import List, Callable, Optional
from bleak import BleakScanner
from bleak.backends.device import BLEDevice

from ..models.mudra_device import MudraDevice


class BleService:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        self._scanner = None
        self._scan_task = None
        self._is_scanning = False
        self._callback: Optional[Callable[[List[MudraDevice]], None]] = None

    async def scan(self, callback: Callable[[List[MudraDevice]], None]):
        """
        Start scanning for BLE devices and call the callback with a list of MudraDevice.
        
        Args:
            callback: A function that will be called with a list of MudraDevice objects
        """
        if self._is_scanning:
            return
        
        self._callback = callback
        self._is_scanning = True
        self._scan_task = asyncio.create_task(self._scan_loop())

    async def _scan_loop(self):
        """Internal method that handles the scanning loop."""
        discovered_devices = {}
        
        def detection_callback(device: BLEDevice, advertisement_data):
            """Callback for when a device is detected during scanning."""
            # Filter devices by Mudra prefix if name is available
            should_include = False
            if device.name and "Mudra" in device.name.lower():
                should_include = True
            elif not device.name:  # Include devices without names (might be Mudra devices)
                should_include = True
            
            if should_include and device.address not in discovered_devices:
                discovered_devices[device.address] = MudraDevice(device)
                # Call callback immediately when a new device is found
                if self._callback:
                    mudra_devices = list(discovered_devices.values())
                    self._callback(mudra_devices)
        
        try:
            self._scanner = BleakScanner(detection_callback=detection_callback)
            await self._scanner.start()
            
            # Keep scanning until stopped
            while self._is_scanning:
                await asyncio.sleep(0.1)  # Small sleep to prevent busy waiting
        except asyncio.CancelledError:
            pass
        except Exception:
            # Handle any errors during scanning
            if self._is_scanning:
                raise
        finally:
            if self._scanner:
                try:
                    await self._scanner.stop()
                except Exception:
                    pass
            self._scanner = None

    async def stop_scanning(self):
        """
        Stop scanning for BLE devices.
        """
        self._is_scanning = False
        
        if self._scan_task and not self._scan_task.done():
            self._scan_task.cancel()
            try:
                await self._scan_task
            except asyncio.CancelledError:
                pass
        
        if self._scanner:
            try:
                await self._scanner.stop()
            except Exception:
                pass
        
        self._scanner = None
        self._scan_task = None
        self._callback = None
