import os
from typing import Dict, Any, Optional, List, Tuple, Union
from autocoder.common import AutoCoderArgs, SourceCode
from autocoder.common.autocoderargs_parser import AutoCoderArgsParser
from autocoder.common.v2.agent.agentic_edit_tools.base_tool_resolver import (
    BaseToolResolver,
)
from autocoder.common.v2.agent.agentic_edit_types import ReadFileTool, ToolResult
from autocoder.common.pruner.context_pruner import PruneContext
from autocoder.common.tokens import count_string_tokens as count_tokens
from loguru import logger
import typing
import json
from autocoder.rag.loaders import (
    extract_text_from_pdf,
    extract_text_from_docx,
    extract_text_from_ppt,
)
from autocoder.common.llms.manager import LLMManager
from autocoder.common.wrap_llm_hint.utils import add_hint_to_text

if typing.TYPE_CHECKING:
    from autocoder.common.v2.agent.agentic_edit import AgenticEdit


class ReadFileToolResolver(BaseToolResolver):
    def __init__(
        self, agent: Optional["AgenticEdit"], tool: ReadFileTool, args: AutoCoderArgs
    ):
        super().__init__(agent, tool, args)
        self.tool: ReadFileTool = tool  # For type hinting

        # Initialize AutoCoderArgs parser for flexible parameter parsing
        self.args_parser = AutoCoderArgsParser()

        # 解析 context_prune_safe_zone_tokens 参数
        parsed_safe_zone_tokens = self._get_parsed_safe_zone_tokens()

        self.context_pruner = (
            PruneContext(
                max_tokens=parsed_safe_zone_tokens,
                args=self.args,
                llm=self.agent.context_prune_llm,
            )
            if self.agent and self.agent.context_prune_llm
            else None
        )

        # LLM manager for model context window queries
        self.llm_manager = LLMManager()

    def _get_parsed_safe_zone_tokens(self) -> int:
        """
        解析 context_prune_safe_zone_tokens 参数，支持多种格式

        Returns:
            解析后的 token 数量
        """
        return self.args_parser.parse_context_prune_safe_zone_tokens(
            self.args.context_prune_safe_zone_tokens, self.args.code_model
        )

    def _parse_int_list(
        self, items: List[Optional[str]], field_name: str
    ) -> Tuple[bool, Optional[List[Optional[int]]], Optional[str]]:
        """
        将字符串列表解析为整数列表；空字符串或 None 视为 None。
        返回 (ok, parsed_list_or_none, error_message_or_none)。
        """
        if not items:
            return True, None, None
        parsed: List[Optional[int]] = []
        for raw in items:
            if raw is None or raw == "":
                parsed.append(None)
            else:
                try:
                    parsed.append(int(raw))
                except Exception:
                    return (
                        False,
                        None,
                        f"Parameter '{field_name}' must be integers when provided as list. Got: {raw}",
                    )
        return True, parsed, None

    def _validate_count(
        self, paths: List[str], items: List[Optional[str]], name: str
    ) -> Optional[str]:
        """
        校验当提供多文件时，对应参数列表数量是否与 paths 数量一致。
        不一致则返回错误信息字符串；一致返回 None。
        """
        if items and len(items) != len(paths):
            return (
                f"Detected multiple paths ({len(paths)} items) but '{name}' has {len(items)} items. "
                f"When reading multiple files, please provide '{name}' as a comma-separated list with exactly {len(paths)} items, "
                f"or omit '{name}' entirely."
            )
        return None

    def _extract_lines_by_range(
        self, content: str, start_line: Optional[int], end_line: Optional[int]
    ) -> str:
        """根据行号范围提取文件内容

        参数说明:
        - start_line: 起始行号。正数表示从第N行开始(1-based)，负数表示从倒数第N行开始
        - end_line: 结束行号。正数表示到第N行结束(1-based)，-1表示到文件末尾
        """
        if start_line is None and end_line is None:
            return content

        lines = content.split("\n")
        total_lines = len(lines)

        # 处理行号参数（转换为0-based索引）
        start_idx = 0
        end_idx = total_lines

        if start_line is not None:
            if start_line < 0:
                # 负数表示从倒数第N行开始
                start_idx = max(0, total_lines + start_line)
            else:
                # 正数表示从第N行开始(1-based)
                start_idx = max(0, start_line - 1)

        if end_line is not None:
            if end_line == -1:
                # -1 表示到文件末尾
                end_idx = total_lines
            elif end_line < -1:
                # 其他负数表示到倒数第N行结束
                end_idx = max(0, total_lines + end_line + 1)
            else:
                # 正数表示到第N行结束(1-based)
                end_idx = min(total_lines, end_line)

        # 验证行号范围
        if start_line is not None and start_line > 0 and start_idx >= total_lines:
            return f"Error: start_line {start_line} exceeds total lines {total_lines}"

        if start_line is not None and start_line < 0 and abs(start_line) > total_lines:
            return f"Error: start_line {start_line} (倒数第{abs(start_line)}行) exceeds total lines {total_lines}"

        if start_idx >= end_idx and not (end_line == -1 and start_idx == total_lines):
            if start_line is not None and start_line < 0:
                start_desc = f"倒数第{abs(start_line)}行"
            else:
                start_desc = f"第{start_line}行"

            if end_line == -1:
                end_desc = "文件末尾"
            elif end_line is not None and end_line < -1:
                end_desc = f"倒数第{abs(end_line)}行"
            else:
                end_desc = f"第{end_line}行"

            return f"Error: start_line ({start_desc}) should be before end_line ({end_desc})"

        # 提取指定行范围
        extracted_lines = lines[start_idx:end_idx]
        return "\n".join(extracted_lines)

    def _extract_content_by_query(
        self, content: str, query: str, file_path: str
    ) -> str:
        """根据查询描述提取最相关的内容"""
        if not query or not self.context_pruner:
            return content

        # 使用 context_pruner 的查询功能提取相关内容
        try:
            # 创建一个包含查询的伪对话
            query_conversation = {"role": "user", "content": query}

            source_code = SourceCode(
                module_name=file_path, source_code=content, tokens=count_tokens(content)
            )

            # 使用 context_pruner 根据查询提取相关内容
            pruned_sources = self.context_pruner.handle_overflow(
                file_sources=[source_code],
                conversations=[query_conversation],
                strategy=self.args.context_prune_strategy,
            )

            if pruned_sources:
                return pruned_sources[0].source_code
            else:
                return content

        except Exception as e:
            logger.warning(f"Error extracting content by query '{query}': {str(e)}")
            return content

    def _prune_file_content(self, content: str, file_path: str) -> str:
        """对文件内容进行剪枝处理"""
        if not self.context_pruner:
            return content

        # 计算 token 数量
        tokens = count_tokens(content)
        parsed_safe_zone_tokens = self._get_parsed_safe_zone_tokens()
        if tokens <= parsed_safe_zone_tokens:
            return content

        # 创建 SourceCode 对象
        source_code = SourceCode(
            module_name=file_path, source_code=content, tokens=tokens
        )

        # 使用 context_pruner 进行剪枝
        pruned_sources = self.context_pruner.handle_overflow(
            file_sources=[source_code],
            conversations=self.agent.current_conversations if self.agent else [],
            strategy=self.args.context_prune_strategy,
        )

        if not pruned_sources:
            return content

        return pruned_sources[0].source_code

    def _get_model_context_window(self) -> int:
        """获取当前代码模型的上下文窗口大小，默认 128000"""
        try:
            model_name = self.args.code_model or self.args.model
            model = self.llm_manager.get_model(model_name)
            if model and model.context_window:
                return int(model.context_window)
        except Exception as e:
            logger.warning(f"Failed to get model context window: {e}")
        return 128000

    def _get_pruned_conversations(self) -> List[Dict[str, Any]]:
        """获取已按 agent 逻辑剪枝后的对话，用于计算 token 开销"""
        try:
            if not self.agent:
                return []
            conversations = self.agent.current_conversations or []
            # 复用 Agentic 对话修剪器，保持与主循环一致
            agentic_pruner = self.agent.agentic_pruner
            if agentic_pruner and conversations:
                from copy import deepcopy

                return agentic_pruner.prune_conversations(deepcopy(conversations))
            return conversations
        except Exception as e:
            logger.warning(f"Failed to get pruned conversations: {e}")
            return []

    def _prune_file_to_fit_context_window(
        self, content: str, file_path: str
    ) -> Tuple[bool, str]:
        """
        如果 对话token + 文件token 可能超出模型上下文窗口，不在此处裁剪文件，
        而是返回带有提示信息的结果，提示大模型应先对会话进行删减后再读取文件。
        """
        if not self.agent:
            return False, content

        try:
            model_window = self._get_model_context_window()
            pruned_convs = self._get_pruned_conversations()
            conv_tokens = count_tokens(json.dumps(pruned_convs, ensure_ascii=False))
            file_tokens = count_tokens(content)

            if conv_tokens + file_tokens <= model_window:
                return False, content

            # 构造提示信息，指导大模型优先裁剪会话（如使用 conversation_message_ids_write），然后再调用 read_file
            hint = (
                "The combined size of current conversation and requested file likely exceeds the model context window. "
                "Please prune the conversation first (e.g., delete unnecessary tool_result messages using conversation_message_ids_write), "
                "then call read_file again. "
                f"Details: conversation_tokens={conv_tokens}, file_tokens={file_tokens}, window={model_window}, file={file_path}"
            )

            logger.info(
                f"Conversation + file tokens exceed window ({conv_tokens}+{file_tokens}>{model_window}). Returning hint instead of file content."
            )

            # 返回包含提示的包装文本，前置文件前500字符作为上下文
            prefix = content[:500] if content else ""
            return True, add_hint_to_text(prefix, hint)
        except Exception as e:
            logger.warning(f"Failed to calculate context window overflow: {e}")
            return False, content

    def _parse_single_int(
        self, value: Optional[Union[str, int]], field_name: str
    ) -> Optional[int]:
        """
        将单个值解析为整数；允许传入 int 或数字字符串。包含逗号时返回错误提示由调用方处理。
        """
        if value is None:
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            v = value.strip()
            if not v:
                return None
            # 逗号分割在多文件模式处理，此处单文件不允许出现逗号
            if "," in v:
                raise ValueError(
                    f"Parameter '{field_name}' contains comma-separated values in single-file mode. "
                    f"Please provide a single value or pass multiple files in 'path' with matching comma-separated {field_name} values."
                )
            try:
                return int(v)
            except Exception as e:
                raise ValueError(
                    f"Parameter '{field_name}' must be an integer. Got: {value}"
                ) from e
        raise ValueError(f"Unsupported type for '{field_name}': {type(value)}")

    def _split_values(self, raw: Optional[Union[str, int]]) -> List[Optional[str]]:
        """
        将入参转为字符串列表；None -> []；int -> [str(int)]；str -> 按逗号分割并 strip。
        """
        if raw is None:
            return []
        if isinstance(raw, int):
            return [str(raw)]
        if isinstance(raw, str):
            parts = [p.strip() for p in raw.split(",")]
            return [p if p != "" else None for p in parts]
        return []

    def _read_file_content(
        self,
        file_path_to_read: str,
        start_line: Optional[int],
        end_line: Optional[int],
        query: Optional[str],
    ) -> str:
        content = ""
        ext = os.path.splitext(file_path_to_read)[1].lower()

        if ext == ".pdf":
            logger.info(f"Extracting text from PDF: {file_path_to_read}")
            content = extract_text_from_pdf(file_path_to_read)
        elif ext == ".docx":
            logger.info(f"Extracting text from DOCX: {file_path_to_read}")
            content = extract_text_from_docx(file_path_to_read)
        elif ext in (".pptx", ".ppt"):
            logger.info(f"Extracting text from PPT/PPTX: {file_path_to_read}")
            slide_texts = []
            for slide_identifier, slide_text_content in extract_text_from_ppt(
                file_path_to_read
            ):
                slide_texts.append(
                    f"--- Slide {slide_identifier} ---\n{slide_text_content}"
                )
            content = "\n\n".join(slide_texts) if slide_texts else ""
        else:
            logger.info(f"Reading plain text file: {file_path_to_read}")
            with open(file_path_to_read, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()

        # 处理新参数（按调用时传入的 per-file 参数）
        # 1. 先根据行号范围提取内容
        if start_line is not None or end_line is not None:
            content = self._extract_lines_by_range(content, start_line, end_line)

        # 2. 如果有查询，根据查询提取相关内容
        if query:
            content = self._extract_content_by_query(content, query, file_path_to_read)

        # 3. 检查当前对话 + 文件是否超出模型窗口，若需要提示会话剪枝则直接返回带提示内容
        should_prune, maybe_hinted_content = self._prune_file_to_fit_context_window(
            content, file_path_to_read
        )
        if should_prune:
            return maybe_hinted_content

        # 4. 最后进行常规的剪枝处理（基于 safe_zone_tokens 的兜底）
        return self._prune_file_content(maybe_hinted_content, file_path_to_read)

    def _build_line_range_message(
        self, start_line: Optional[int], end_line: Optional[int]
    ) -> Optional[str]:
        """
        构建单文件的行区间描述字符串，如 lines 1-end / lines 3-10。
        若无行区间限制，返回 None。
        """
        if start_line is None and end_line is None:
            return None

        if start_line is not None:
            start = f"-{abs(start_line)}" if start_line < 0 else str(start_line)
        else:
            start = "1"

        if end_line == -1:
            end = "end"
        elif end_line is not None:
            end = str(end_line)
        else:
            end = "end"

        return f"lines {start}-{end}"

    def _build_single_file_message(
        self,
        file_path: str,
        start_line: Optional[int],
        end_line: Optional[int],
        query: Optional[str],
    ) -> str:
        """构建单文件读取的成功消息"""
        message_parts = [f"{file_path}"]
        line_range = self._build_line_range_message(start_line, end_line)
        if line_range:
            message_parts.append(line_range)
        if query:
            message_parts.append(f"filtered by query: '{query}'")
        return " ".join(message_parts)

    def read_file_normal(self, file_path: str) -> ToolResult:
        """Read file directly without using shadow manager"""
        try:
            if not os.path.exists(file_path):
                return ToolResult(
                    success=False, message=f"Error: File not found at path: {file_path}"
                )
            if not os.path.isfile(file_path):
                return ToolResult(
                    success=False, message=f"Error: Path is not a file: {file_path}"
                )

            # 解析单文件参数
            try:
                start_line = self._parse_single_int(self.tool.start_line, "start_line")
                end_line = self._parse_single_int(self.tool.end_line, "end_line")
            except ValueError as ve:
                return ToolResult(success=False, message=str(ve))

            content = self._read_file_content(
                file_path, start_line, end_line, self.tool.query
            )
            message = self._build_single_file_message(
                file_path, start_line, end_line, self.tool.query
            )

            logger.info(f"Successfully processed file: {message}")
            return ToolResult(success=True, message=message, content=content)

        except Exception as e:
            logger.warning(f"Error processing file '{file_path}': {str(e)}")
            logger.exception(e)
            return ToolResult(
                success=False,
                message=f"An error occurred while processing the file '{file_path}': {str(e)}",
            )

    def resolve(self) -> ToolResult:
        """Resolve the read file tool by calling the appropriate implementation, 支持多文件读取"""
        raw_path = self.tool.path or ""
        # 拆分路径
        paths = [p.strip() for p in raw_path.split(",") if p.strip()]

        if not paths:
            return ToolResult(
                success=False, message="Error: 'path' is required for read_file."
            )

        # 单文件：沿用原有逻辑并对逗号误用进行保护
        if len(paths) == 1:
            # 校验不允许在单文件模式里给出逗号分割的 start_line/end_line
            if (
                isinstance(self.tool.start_line, str)
                and self.tool.start_line
                and "," in self.tool.start_line
            ):
                return ToolResult(
                    success=False,
                    message="Detected single file in 'path' but start_line contains comma-separated values. "
                    "Please provide a single value for start_line or pass multiple files with matching start_line list.",
                )
            if (
                isinstance(self.tool.end_line, str)
                and self.tool.end_line
                and "," in self.tool.end_line
            ):
                return ToolResult(
                    success=False,
                    message="Detected single file in 'path' but end_line contains comma-separated values. "
                    "Please provide a single value for end_line or pass multiple files with matching end_line list.",
                )
            return self.read_file_normal(paths[0])

        # 多文件：要求三个可选参数（如提供）也必须用逗号分割，并与 path 数量一致
        start_line_items = self._split_values(self.tool.start_line)
        end_line_items = self._split_values(self.tool.end_line)
        query_items = self._split_values(self.tool.query)

        # 如果提供了 start_line/end_line/query，则它们的数量必须与 paths 匹配
        for fname, items in (
            ("start_line", start_line_items),
            ("end_line", end_line_items),
            ("query", query_items),
        ):
            err = self._validate_count(paths, items, fname)
            if err:
                return ToolResult(success=False, message=err)

        # 将 start_line / end_line 转为 int 列表（或 None）
        ok, start_lines, err_msg = self._parse_int_list(start_line_items, "start_line")
        if not ok:
            return ToolResult(
                success=False, message=err_msg or "Invalid start_line list."
            )
        ok, end_lines, err_msg = self._parse_int_list(end_line_items, "end_line")
        if not ok:
            return ToolResult(
                success=False, message=err_msg or "Invalid end_line list."
            )

        # query 列表（或 None）
        queries: Optional[List[Optional[str]]] = query_items if query_items else None

        # 对每个文件执行读取
        aggregated_contents: List[str] = []
        success_count = 0
        fail_details: List[str] = []

        for idx, file_path in enumerate(paths):
            s = start_lines[idx] if start_lines is not None else None
            e = end_lines[idx] if end_lines is not None else None
            q = queries[idx] if queries is not None else None

            if not os.path.exists(file_path):
                fail_details.append(f"[{idx+1}] not found: {file_path}")
                continue
            if not os.path.isfile(file_path):
                fail_details.append(f"[{idx+1}] not a file: {file_path}")
                continue

            try:
                content = self._read_file_content(file_path, s, e, q)
                header = f"---- File: {file_path} ----"
                aggregated_contents.append(f"{header}\n{content}")
                success_count += 1
            except Exception as ex:
                logger.exception(ex)
                fail_details.append(f"[{idx+1}] error reading {file_path}: {str(ex)}")

        # 汇总结果
        if success_count == 0:
            msg = "Failed to read all requested files. " + (
                "; ".join(fail_details) if fail_details else ""
            )
            return ToolResult(success=False, message=msg)

        summary = f"{success_count}/{len(paths)} files read: {', '.join(paths)}"
        if fail_details:
            summary += f" | failures: {'; '.join(fail_details)}"

        return ToolResult(
            success=True,
            message=summary,
            content="\n\n".join(aggregated_contents),
        )
