# DR-Agent UI

Pre-compiled web interface for DR-Agent workflows. This package contains static files for the DR-Agent chat interface, allowing you to serve a complete web UI without requiring a separate Node.js frontend server. 