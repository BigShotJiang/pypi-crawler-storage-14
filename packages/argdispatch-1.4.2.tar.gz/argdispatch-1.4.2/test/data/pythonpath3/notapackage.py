"""Docstring of module notapackage."""

import sys

if __name__ == "__main__":
    print("Running python module notapackage " + " ".join(sys.argv[1:]))
