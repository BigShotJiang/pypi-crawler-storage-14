"""Docstring of module withoutinit.bar."""

import sys

if __name__ == "__main__":
    print("Running python module withoutinit.bar " + " ".join(sys.argv[1:]))
