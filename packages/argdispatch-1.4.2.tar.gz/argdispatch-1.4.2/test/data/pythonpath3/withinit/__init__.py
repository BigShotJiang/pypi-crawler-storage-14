"""Docstring of module withinit.__init__."""

import sys

if __name__ == "__main__":
    print("Running python module withinit.__init__ " + " ".join(sys.argv[1:]))
