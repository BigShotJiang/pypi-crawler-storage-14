"""Docstring of module withinit2.foo."""

import sys

if __name__ == "__main__":
    print("Running python module withinit2.foo " + " ".join(sys.argv[1:]))
