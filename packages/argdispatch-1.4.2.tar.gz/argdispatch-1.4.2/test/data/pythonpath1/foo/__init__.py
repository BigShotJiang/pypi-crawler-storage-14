"""This is the docstring of module foo.__init__."""
