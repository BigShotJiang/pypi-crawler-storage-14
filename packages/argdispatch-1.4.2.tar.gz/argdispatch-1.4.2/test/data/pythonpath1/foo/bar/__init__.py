"""This is the docstring of package foo.bar.__init__"""
