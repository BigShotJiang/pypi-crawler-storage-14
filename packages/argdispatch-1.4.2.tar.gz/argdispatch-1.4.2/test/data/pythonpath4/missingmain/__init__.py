"""This is a module without a __main__ submodule."""
