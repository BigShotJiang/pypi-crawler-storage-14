__all__ = ['main']

import sys
import warnings

from .function import *
from .json_stream import *
from .output import *
from .parse_arguments import *

warnings.filterwarnings('ignore', 'Metadata Warning, tag', UserWarning)

def main():
    sys.path.pop(0)
    [_, command, *arguments] = sys.argv
    if command == 'throttle': arguments = ['=', *arguments]
    fn = function(command)
    if len(arguments) == 1 and arguments[0].startswith('%%'):
        for a in json_stream():
            args = a.get('args', [])
            kwargs = a.get('kwargs', {})
            options = a.get('options', {})
            raw = options.get('raw', False)
            output(fn(*args, **kwargs), fn, raw)
            if len(arguments[0]) > 2: return
    else:
        args, kwargs, options = parse_arguments(arguments)
        raw = options.get('raw', False)
        try:
            if '%' in args:
                i = args.index('%')
                for a in json_stream():
                    args[i] = a
                    output(fn(*args, **kwargs), fn, raw)
            else:
                output(fn(*args, **kwargs), fn, raw)
        except BrokenPipeError:
            pass
