__all__ = ['function']

from random import randint as random
from urllib.parse import unquote

from ..config import config
from ..require import require

from .partition import *
from .throttle import *

FN = {
    'config': config,
    'partition': partition,
    'random': random,
    'throttle': throttle,
    'urldecode': unquote,
}

def function(name):
    if name in FN:
        return FN[name]
    return require(name, cli=True)
