__all__ = ['json_stream']

import json
import sys

def json_stream(echo=False):
    while True:
        line = sys.stdin.readline() # readlines is buffered
        if not line: break
        if echo:
            sys.stdout.write(line)
            sys.stdout.flush()
        yield json.loads(line)
