MODELS =  {
"Nova Pro":"amazon.nova-pro-v1:0",
"Nova Premier":"amazon.nova-premier-v1:0",
"Claude 3.5 Sonnet v2":"anthropic.claude-3-5-sonnet-20241022-v2:0",
"Claude Sonnet 4":"anthropic.claude-sonnet-4-20250514-v1:0",
}
