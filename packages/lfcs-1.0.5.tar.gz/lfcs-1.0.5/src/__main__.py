"""
Entry point when running as: python -m src
"""

from .main import main

if __name__ == "__main__":
    main()
