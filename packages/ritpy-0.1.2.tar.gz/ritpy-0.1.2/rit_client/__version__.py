"""Version information for rit_client package."""

__version__ = "0.1.0"
__author__ = "Edoardo Cocciò"
__description__ = "Python wrapper for the Rotman Interactive Trader (RIT) REST API"
