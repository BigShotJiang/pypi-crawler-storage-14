
# ToDo attaches
class AllureListener:
    def __init__(self, lifecycle):
        self.lifecycle = lifecycle
