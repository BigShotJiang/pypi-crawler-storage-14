# Amulet IO

A tiny C++ header-only binary reader and writer library.
