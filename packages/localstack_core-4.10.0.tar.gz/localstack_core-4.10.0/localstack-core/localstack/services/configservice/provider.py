from localstack.aws.api.config import ConfigApi


class ConfigProvider(ConfigApi):
    pass
