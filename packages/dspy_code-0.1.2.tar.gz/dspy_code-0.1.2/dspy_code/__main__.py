"""
Entry point for running DSPy Code as a module.

Allows execution via: python -m dspy_code
"""

from .main import main

if __name__ == "__main__":
    main()
