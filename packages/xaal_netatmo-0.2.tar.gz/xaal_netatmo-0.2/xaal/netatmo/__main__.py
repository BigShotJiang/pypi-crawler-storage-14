from . import gw
from xaal.lib import helpers

helpers.run_async_package(gw.PACKAGE_NAME,gw.setup)