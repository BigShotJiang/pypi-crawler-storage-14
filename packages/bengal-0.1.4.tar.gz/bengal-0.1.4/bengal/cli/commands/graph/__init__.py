from __future__ import annotations

from .__main__ import graph_cli

__all__ = ["graph_cli"]
