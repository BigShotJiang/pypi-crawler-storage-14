"""
Allow running Bengal CLI as a module: python -m bengal.cli
"""


from __future__ import annotations

from bengal.cli import main

if __name__ == "__main__":
    main()
