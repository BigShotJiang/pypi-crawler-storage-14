---
title: Resume
type: resume
template: resume/single.html
description: Professional resume and CV
---

This homepage uses the resume template to display your CV.
All resume data comes from `data/resume.yaml`.
