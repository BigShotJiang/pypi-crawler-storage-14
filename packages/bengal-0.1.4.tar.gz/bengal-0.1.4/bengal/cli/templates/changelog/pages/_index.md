---
title: Changelog
type: changelog
description: Release notes and version history
---

# Release History

Track all changes, improvements, and bug fixes across versions.

All release data is loaded from `data/changelog.yaml`.
