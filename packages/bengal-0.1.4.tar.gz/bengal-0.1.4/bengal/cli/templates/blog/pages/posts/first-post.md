---
title: My First Blog Post
date: {{date}}
tags: [welcome, introduction]
category: meta
description: Welcome to my new blog built with Bengal SSG
---

# My First Blog Post

Welcome to my blog! This is my first post, and I'm excited to start sharing my thoughts and ideas.

## Why I Started This Blog

I wanted a place to document my journey and share what I learn along the way.

## What to Expect

- Regular posts about topics I'm passionate about
- Tutorials and how-to guides
- Personal reflections and experiences

Stay tuned for more content!
