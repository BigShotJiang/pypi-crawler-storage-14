---
title: My Blog
description: Welcome to my blog where I share thoughts and ideas
type: blog
show_recent_posts: true
blog_section: posts
---

# Welcome to My Blog

This is your new Bengal blog! I write about technology, life, and everything in between.

## Recent Posts

Check out my latest posts below or browse by [tags](/tags) and [categories](/categories).
