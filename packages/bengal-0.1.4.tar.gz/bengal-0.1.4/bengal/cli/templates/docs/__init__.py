"""Docs site template."""


from __future__ import annotations

from .template import TEMPLATE

__all__ = ["TEMPLATE"]
