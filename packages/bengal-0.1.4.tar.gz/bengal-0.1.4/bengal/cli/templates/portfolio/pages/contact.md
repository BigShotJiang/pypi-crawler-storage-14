---
title: Contact
description: Get in touch
---

# Let's Work Together

I'm always interested in hearing about new projects and opportunities.

## Get in Touch

- **Email**: your.email@example.com
- **GitHub**: [github.com/yourusername](https://github.com/yourusername)
- **LinkedIn**: [linkedin.com/in/yourprofile](https://linkedin.com/in/yourprofile)
- **Twitter**: [@yourusername](https://twitter.com/yourusername)

## Availability

I'm currently available for:

- Freelance projects
- Contract work
- Consulting opportunities
- Open source collaboration

Feel free to reach out via email or connect on social media!
