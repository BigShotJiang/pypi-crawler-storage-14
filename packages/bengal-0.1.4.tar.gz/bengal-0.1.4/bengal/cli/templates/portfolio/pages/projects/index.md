---
title: Projects
description: My portfolio of work
---

# Projects

Here's a collection of projects I've worked on.

## Featured Work

Browse through my projects to see examples of my work and the technologies I use.
