---
title: Portfolio
description: Welcome to my portfolio
layout: home
---

# Hi, I'm [Your Name]

I'm a [Your Profession] passionate about creating amazing things.

## Featured Projects

Check out some of my recent work below.

---

## About Me

I specialize in [your specialties] and love solving complex problems.

[View All Projects](/projects) | [About Me](/about) | [Contact](/contact)
