---
title: About
description: Learn more about me
---

# About Me

I'm a creative professional with a passion for [your passion].

## Skills

- **Frontend**: React, Vue, CSS
- **Backend**: Python, Node.js
- **Tools**: Git, Docker, AWS

## Experience

### Current Position
**Company Name** - Role (2023 - Present)

- Achievement or responsibility
- Another achievement
- Key project

### Previous Position
**Previous Company** - Role (2021 - 2023)

- Key accomplishments
- Technologies used

## Education

**University Name**
Bachelor's Degree in Computer Science (2017-2021)

## Let's Connect

- Email: your.email@example.com
- GitHub: github.com/yourusername
- LinkedIn: linkedin.com/in/yourprofile
