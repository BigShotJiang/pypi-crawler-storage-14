"""
Configuration management for Bengal SSG.
"""


from __future__ import annotations

from bengal.config.loader import ConfigLoader

__all__ = ["ConfigLoader"]
