"""Asset processing package for Bengal SSG."""
