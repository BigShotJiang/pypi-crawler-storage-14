"""Allow running bengal as a module: python -m bengal"""


from __future__ import annotations

from bengal.cli import main

if __name__ == "__main__":
    main()
