# tests/test_db.py
import json
from dataclasses import dataclass
from typing import List

import pytest

from nc_db.src.db.DbConfig import DbConfig
from nc_db.src.db.db import Db


# -------------------- HELPERS --------------------

class SCGModel:
    def __init__(self, id_: int, body: dict):
        self.id = id_
        self.body = body


def scg_mapper(id_: int, body: dict) -> SCGModel:
    return SCGModel(id_, body)


config = DbConfig(
    user="nc_admin",
    password="bob",
    host="localhost",
    port=5432,
    dbname="nc-data",
)


@pytest.fixture()
def db(test_schema: str) -> Db:
    """
    Ensure the required tables exist in the ephemeral test schema and
    return a Db instance bound to that schema.
    """
    # Create tables your tests reference
    with config.get_connection() as con:
        with con.cursor() as cur:
            cur.execute(f'''
                CREATE TABLE IF NOT EXISTS "{test_schema}".items (
                    id   BIGSERIAL PRIMARY KEY,
                    body JSONB NOT NULL
                );
            ''')
            cur.execute(f'''
                CREATE TABLE IF NOT EXISTS "{test_schema}".scg (
                    id   BIGSERIAL PRIMARY KEY,
                    body JSONB NOT NULL
                );
            ''')
        con.commit()

    # Now instantiate Db (so its table_set sees the fresh tables)
    return Db(schema=test_schema, config=config)


# -------------------- TESTS --------------------

def test_update_merge_preserves_existing_fields_and_sets_body_id(db: Db):
    # Insert two baseline rows (no explicit id; DB assigns)
    id1 = db.insert("items", {"body": {"name": "alpha", "count": 1}})
    id2 = db.insert("items", {"body": {"name": "beta", "count": 2}})

    # Merge updates: patch should merge into existing body and NOT drop other keys
    updated_ids = db.update(
        "items",
        ids=[],  # derive ids from each item/body
        items=[
            {"body": {"id": id1, "count": 10, "extra": "A"}},
            {"body": json.dumps({"id": id2, "count": 20, "extra": "B"})},  # JSON string body accepted
        ],
        mode="merge",
    )

    assert sorted(updated_ids) == sorted([id1, id2])

    rows = {row["id"]: row["body"] for row in db.get("items")}
    # Existing field "name" should remain; "count" changed; "extra" added; body["id"] forced to row id
    assert rows[id1]["name"] == "alpha"
    assert rows[id1]["count"] == 10
    assert rows[id1]["extra"] == "A"
    assert rows[id1]["id"] == id1

    assert rows[id2]["name"] == "beta"
    assert rows[id2]["count"] == 20
    assert rows[id2]["extra"] == "B"
    assert rows[id2]["id"] == id2


def test_update_replace_overwrites_body_but_keeps_correct_id(db: Db):
    id1 = db.insert("items", {"body": {"name": "keep_me", "x": 1}})
    id2 = db.insert("items", {"body": {"name": "keep_me_too", "x": 2}})

    # Replace: old keys should be dropped unless provided in new body
    updated = db.update(
        "items",
        ids=[id1, id2],  # explicit ids param should take precedence over body ids
        items=[
            {"body": {"id": 999999, "x": 100, "only_new": True}},  # mismatched id shouldn't matter
            {"body": {"x": 200}},  # missing id is fine; SQL sets it
        ],
        mode="replace",
    )
    assert updated == [id1, id2]

    after = {row["id"]: row["body"] for row in db.get("items")}
    # Old "name" removed due to replace; new fields present; body["id"] must equal row id
    assert after[id1] == {"x": 100, "only_new": True, "id": id1}
    assert after[id2] == {"x": 200, "id": id2}


def test_update_accepts_whole_item_as_body_and_json_string(db: Db):
    id1 = db.insert("items", {"body": {"seed": 1}})
    id2 = db.insert("items", {"body": {"seed": 2}})

    # 1) Whole dict as body (no 'body' wrapper)
    # 2) JSON string body
    updated = db.update(
        "items",
        ids=[],  # derive from item/body
        items=[
            {"id": id1, "foo": "bar"},  # treated as full body
            {"id": id2, "body": json.dumps({"baz": 42})},
        ],
        mode="merge",
    )
    assert sorted(updated) == sorted([id1, id2])

    rows = {row["id"]: row["body"] for row in db.get("items")}
    # Merge should combine with existing seed keys
    assert rows[id1]["foo"] == "bar"
    assert rows[id1]["seed"] == 1
    assert rows[id1]["id"] == id1

    assert rows[id2]["baz"] == 42
    assert rows[id2]["seed"] == 2
    assert rows[id2]["id"] == id2


def test_update_missing_ids_raises_when_not_derivable(db: Db):
    db.insert("items", {"body": {"seed": 1}})

    # No ids param, and bodies lack id → should raise ValueError
    with pytest.raises(ValueError, match="Missing id"):
        db.update(
            "items",
            ids=[],
            items=[{"body": {"foo": "bar"}}, {"body": {"baz": 1}}],
            mode="merge",
        )


def test_update_type_errors(db: Db):
    id1 = db.insert("items", {"body": {"seed": 1}})

    # Non-dict item
    with pytest.raises(TypeError, match="Each item must be a dict"):
        db.update("items", ids=[id1], items=["not a dict"], mode="merge")

    # Bad body type
    with pytest.raises(TypeError, match="'body' must be a dict or JSON string"):
        db.update("items", ids=[id1], items=[{"body": 123}], mode="merge")

    # Non-integer id (from body or item)
    with pytest.raises(TypeError, match="id must be an integer"):
        db.update("items", ids=[], items=[{"body": {"id": "abc", "v": 1}}], mode="merge")


def test_update_explicit_ids_param_overrides_item_body_ids(db: Db):
    id1 = db.insert("items", {"body": {"v": 1}})
    id2 = db.insert("items", {"body": {"v": 2}})

    # Supply ids positional alignment; body has misleading ids
    out = db.update(
        "items",
        ids=[id1, id2],
        items=[
            {"body": {"id": 9999, "v": 10}},
            {"body": {"id": 8888, "v": 20}},
        ],
        mode="merge",
    )
    assert out == [id1, id2]

    rows = {row["id"]: row["body"] for row in db.get("items")}
    assert rows[id1]["v"] == 10 and rows[id1]["id"] == id1
    assert rows[id2]["v"] == 20 and rows[id2]["id"] == id2


def test_table_discovery_and_validation(test_schema):
    db = Db(schema=test_schema, config=config)
    assert "scg" in db.table_set


def test_insert_trusts_id_in_body(test_schema):
    db = Db(schema=test_schema)
    db.delete_all("scg")

    supplied = {"body": {"id": 999, "name": "from-body"}}
    new_id = db.insert("scg", supplied)

    assert new_id == 999  # we *trust* provided id

    row = db.get("scg", ids=[999])[0]
    assert row["id"] == 999
    assert row["body"]["id"] == 999
    assert row["body"]["name"] == "from-body"


def test_insert_trusts_top_level_id_over_body(test_schema):
    db = Db(schema=test_schema)
    db.delete_all("scg")

    # If both exist, top-level id should win (per the code: item.get("id", body.get("id")))
    supplied = {"id": 222, "body": {"id": 111, "name": "conflict"}}
    new_id = db.insert("scg", supplied)

    assert new_id == 222

    row = db.get("scg", ids=[222])[0]
    assert row["id"] == 222
    assert row["body"]["id"] == 222  # body normalized to match row id
    assert row["body"]["name"] == "conflict"


def test_insert_without_id_assigns_sequence_and_sets_body_id(test_schema):
    db = Db(schema=test_schema, config=config)
    db.delete_all("scg")

    new_id = db.insert("scg", {"body": {"name": "alpha"}})

    row = db.get("scg", ids=[new_id])[0]
    assert row["id"] == new_id
    assert row["body"]["id"] == new_id
    assert row["body"]["name"] == "alpha"


def test_insert_duplicate_explicit_id_raises(test_schema):
    db = Db(schema=test_schema)
    db.delete_all("scg")

    first = {"body": {"id": 7, "name": "one"}}
    assert db.insert("scg", first) == 7

    dup = {"body": {"id": 7, "name": "two"}}
    with pytest.raises(ValueError):  # raised from caught IntegrityError
        db.insert("scg", dup)


def test_insert_accepts_json_string_body_and_sanitizes_id(test_schema):
    db = Db(schema=test_schema, config=config)
    db.delete_all("scg")

    body_str = json.dumps({"id": 12345, "name": "json-body"})
    new_id = db.insert("scg", {"body": body_str})
    row = db.get("scg", ids=[new_id])[0]

    assert row["id"] == new_id
    assert row["body"]["id"] == new_id
    assert row["body"]["name"] == "json-body"


def test_insert_raises_on_missing_or_bad_body(test_schema):
    db = Db(schema=test_schema, config=config)

    with pytest.raises(TypeError):
        db.insert("scg", {})  # missing 'body'

    with pytest.raises(TypeError):
        db.insert("scg", {"body": 123})  # non-dict, non-str body

    with pytest.raises(TypeError):
        db.insert("scg", {"body": b"not-a-string"})  # bytes not allowed

    with pytest.raises(json.JSONDecodeError):
        db.insert("scg", {"body": "{not-valid-json}"})  # invalid JSON string

@dataclass
class ItemModel:
    id: int
    name: str
    count: int


def test_search_returns_exact_match_nested_json_property(db: Db):
    # Insert some rows into the "items" table
    id1 = db.insert("items", {"body": {"name": "alpha", "count": 1}})
    id2 = db.insert("items", {"body": {"name": "beta", "count": 2}})
    id3 = db.insert("items", {"body": {"name": "alpha", "count": 3}})

    # When: search for an exact match on nested path test_array.test_prop_1 == "hello world"
    results = db.search(ItemModel, "items", "name", "beta")

    # Then: we only get the row with that nested property/value
    assert len(results) == 1
    item = results[0]

    assert isinstance(item, ItemModel)
    assert item.id == id2
    assert item.name == "beta"
    assert item.count == 2

    # Optional: confirm raw body still has the nested structure if you want
    row = db.get("items", [id2])[0]
    body = row["body"]
    assert body["name"] == "beta"


def test_search_returns_exact_match_as_model_instances(db: Db):
    # Insert some rows into the "items" table
    id1 = db.insert("items", {"body": {"name": "alpha", "count": 1}})
    id2 = db.insert("items", {"body": {"name": "beta", "count": 2}})
    id3 = db.insert("items", {"body": {"name": "alpha", "count": 3}})

    # When: search for an exact match on name == "alpha"
    results = db.search(ItemModel, "items", "name", "alpha")

    # Then: we get only rows where body["name"] == "alpha"
    assert len(results) == 2

    # All results are ItemModel instances
    assert all(isinstance(item, ItemModel) for item in results)

    # Collect ids and make sure they match the inserted alpha rows, not beta
    result_ids = sorted(item.id for item in results)
    assert result_ids == sorted([id1, id3])
    assert id2 not in result_ids

    # Also verify the other fields came through correctly
    # Turn results into dict by id for easy checking
    by_id = {item.id: item for item in results}

    assert by_id[id1].name == "alpha"
    assert by_id[id1].count == 1

    assert by_id[id3].name == "alpha"
    assert by_id[id3].count == 3


def test_search_raises_if_property_not_on_cls(db: Db):
    # Insert a row so the table is definitely non-empty
    db.insert("items", {"body": {"name": "alpha", "count": 1}})

    # ItemModel has fields: id, name, count
    # There is NO field called "does_not_exist", so this should raise
    with pytest.raises(AttributeError):
        db.search(ItemModel, "items", "does_not_exist", "whatever")


def test_get_all_and_by_ids(test_schema):
    db = Db(schema=test_schema, config=config)
    db.delete_all("scg")

    ids: List[int] = []
    for name in ("a", "b", "c"):
        ids.append(db.insert("scg", {"body": {"name": name}}))

    all_rows = db.get("scg")
    assert [r["id"] for r in all_rows] == ids
    assert [r["body"]["name"] for r in all_rows] == ["a", "b", "c"]
    assert [r["body"]["id"] for r in all_rows] == ids  # body id is set

    subset = db.get("scg", ids=[ids[1]])
    assert len(subset) == 1
    assert subset[0]["id"] == ids[1]
    assert subset[0]["body"]["name"] == "b"
    assert subset[0]["body"]["id"] == ids[1]


def test_get_by_ids_empty_list_returns_empty(test_schema):
    db = Db(schema=test_schema, config=config)
    assert db.get("scg", ids=[]) == []


def test_get_with_mapper_returns_models(test_schema):
    db = Db(schema=test_schema, config=config)
    db.delete_all("scg")
    id1 = db.insert("scg", {"body": {"name": "mapped"}})

    models = db.get("scg", ids=[id1], mapper=scg_mapper)
    assert len(models) == 1
    m = models[0]
    assert isinstance(m, SCGModel)
    assert m.id == id1
    assert m.body["name"] == "mapped"
    assert m.body["id"] == id1  # body id is set prior to mapping


def test_delete_by_ids(test_schema):
    db = Db(schema=test_schema, config=config)
    db.delete_all("scg")
    id1 = db.insert("scg", {"body": {"name": "delme"}})
    id2 = db.insert("scg", {"body": {"name": "keep"}})

    deleted = db.delete("scg", [id1])
    assert deleted == [id1]

    remaining = db.get("scg")
    assert [r["id"] for r in remaining] == [id2]


def test_delete_all_returns_ids(test_schema):
    db = Db(schema=test_schema, config=config)
    db.delete_all("scg")
    ids = [db.insert("scg", {"body": {"n": n}}) for n in (1, 2, 3)]
    deleted = db.delete_all("scg")
    assert set(deleted) == set(ids)
    assert db.get("scg") == []


def test_truncate_restart_identity_resets_sequence(test_schema):
    db = Db(schema=test_schema, config=config)
    db.delete_all("scg")

    id_a = db.insert("scg", {"body": {"k": "v"}})
    assert id_a == 1

    db.delete_all("scg")
    id_b = db.insert("scg", {"body": {"k": "v2"}})
    # If your sequence is not affected by delete_all, this will usually be 2+.
    assert id_b >= 2

    db.truncate_restart_identity("scg")
    id_c = db.insert("scg", {"body": {"k": "v3"}})
    assert id_c == 1


def test_unknown_table_raises(test_schema):
    db = Db(schema=test_schema, config=config)
    with pytest.raises(ValueError):
        db.insert("nope", {"body": {"x": 1}})
