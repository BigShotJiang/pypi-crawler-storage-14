# nc_db/db/DbConfig.py
import os
from pathlib import Path
from typing import Optional

from psycopg_pool import ConnectionPool
import psycopg
from dotenv import load_dotenv

# Load .env once when this module is imported.
# The project sources were moved under ``nc_db/nc_db`` so resolve both the new
# path and the previous layout for compatibility.
_FILE_PATH = Path(__file__).resolve()
_ENV_RELATIVE = Path("k8s/postgres/base/secrets/postgres.root.env")


def _discover_project_root() -> Path:
    """
    Return the directory that contains the Kubernetes manifests / secrets.
    Handles both the current layout (../..) and the previous top-level layout.
    """
    for depth in (2, 3):
        try:
            candidate = _FILE_PATH.parents[depth]
        except IndexError:
            continue

        if (candidate / _ENV_RELATIVE).is_file():
            return candidate

    # Fallback to the relative parent chain so path computations still work
    return _FILE_PATH.parents[2]


PROJECT_ROOT = _discover_project_root()
ENV_PATH = PROJECT_ROOT / _ENV_RELATIVE
load_dotenv(ENV_PATH)


class DbConfig:
    def __init__(
        self,
        user: str,
        password: str,
        host: str,
        port: int,
        dbname: str,
        min_size: int = 1,
        max_size: int = 5,
    ) -> None:
        # Store parameters on the instance
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.dbname = dbname
        self.min_size = min_size
        self.max_size = max_size

        # Build DSN string
        self.dsn = (
            f"postgresql://{self.user}:{self.password}"
            f"@{self.host}:{self.port}/{self.dbname}"
        )

        # Create a connection pool
        self.pool: Optional[ConnectionPool] = ConnectionPool(
            conninfo=self.dsn,
            min_size=self.min_size,
            max_size=self.max_size,
        )

    @classmethod
    def from_env(cls) -> "DbConfig":
        """
        Create a DbConfig using environment variables / .env file.
        """
        return cls(
            user=os.getenv("POSTGRES_USER", "n/a"),
            password=os.getenv("POSTGRES_PASSWORD", "n/a"),
            host=os.getenv("POSTGRES_DB_HOST", "n/a"),
            port=int(os.getenv("POSTGRES_DB_PORT", "00000")),
            dbname=os.getenv("POSTGRES_DB", "n/a"),
        )

    def get_connection(self) -> psycopg.Connection:
        """
        Get a connection from the pool as a context manager-compatible object:
        with config.get_connection() as conn: ...
        """
        if self.pool is None:
            raise RuntimeError("Connection pool is not initialized")
        return self.pool.connection()

    def get_healthcheck(self, schema: str = "nc"):
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT id, ok FROM {schema}.healthcheck;")
                return cur.fetchall()

    def close(self) -> None:
        if self.pool:
            self.pool.close()
