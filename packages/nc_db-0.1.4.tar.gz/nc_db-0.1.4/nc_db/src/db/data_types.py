from pydantic import BaseModel

NEW_ID = -1


class DbItem(BaseModel):
    id: int = NEW_ID
