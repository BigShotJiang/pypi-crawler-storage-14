#!/usr/bin/env python3
"""
Reset a PostgreSQL StatefulSet (Kubernetes) to a clean state.

What it does:
1) Scale the StatefulSet down to 0 (graceful stop).
2) Delete the data PVC for a given pod ordinal (wipes data).
3) (Optional) Delete the backing PV if reclaimPolicy=Retain or you want to force-remove it.
4) Scale the StatefulSet back up to 1 (or a target) and wait for readiness.

Defaults match your example:
  namespace: nc_db
  statefulset: postgres
  volumeClaimTemplates name: data
  ordinal: 0
  scale-up replicas: 1

Usage examples:
  python k8s/scripts/full_pod_reset.py
  python k8s/scripts/full_pod_reset.py --namespace nc_db --statefulset postgres --vct data --ordinal 0 --replicas 1 --delete-pv
  KUBECTL_BIN="microk8s.kubectl" python k8s/scripts/full_pod_reset.py

Requires:
  - kubectl (or microk8s.kubectl) in PATH
  - current kube-context pointing at the correct cluster/namespace
"""

import argparse
import os
import subprocess
import sys
import time
from typing import Optional, Tuple


def run_cmd(cmd: list[str], check: bool = True, capture: bool = True) -> Tuple[int, str]:
    """Run a shell command. Returns (exit_code, stdout). Raises on error if check=True."""
    proc = subprocess.run(
        cmd,
        check=False,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.STDOUT,
    )
    if check and proc.returncode != 0:
        raise RuntimeError(f"Command failed ({proc.returncode}): {' '.join(cmd)}\n{proc.stdout}")
    return proc.returncode, (proc.stdout or "")


def wait_for_pod_gone(kubectl: str, ns: str, pod: str, timeout_s: int = 180) -> None:
    """Wait until the specific pod no longer exists."""
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        rc, _ = run_cmd([kubectl, "-n", ns, "get", "pod", pod], check=False)
        if rc != 0:
            return
        time.sleep(2)
    raise TimeoutError(f"Timed out waiting for pod/{pod} to be deleted")


def wait_for_rollout_ready(kubectl: str, ns: str, sts: str, timeout_s: int = 300) -> None:
    """Wait for StatefulSet rollout to complete."""
    _, out = run_cmd([kubectl, "-n", ns, "rollout", "status", f"statefulset/{sts}", f"--timeout={timeout_s}s"])
    print(out.strip())


def get_pv_name_for_pvc(kubectl: str, ns: str, pvc: str) -> Optional[str]:
    """Return the PV name bound to a PVC (or None if not bound/not found)."""
    rc, out = run_cmd(
        [kubectl, "-n", ns, "get", "pvc", pvc, "-o", "jsonpath={.spec.volumeName}"],
        check=False,
    )
    pv = out.strip()
    if rc != 0 or not pv:
        return None
    return pv


def get_pv_reclaim_policy(kubectl: str, pv: str) -> Optional[str]:
    """Return reclaim policy for a PV (e.g., Retain/Delete/Recycle), or None if not found."""
    rc, out = run_cmd(
        [kubectl, "get", "pv", pv, "-o", "jsonpath={.spec.persistentVolumeReclaimPolicy}"],
        check=False,
    )
    pol = out.strip()
    if rc != 0 or not pol:
        return None
    return pol


def main():
    parser = argparse.ArgumentParser(description="Factory-reset a PostgreSQL StatefulSet (wipe data PVC and restart).")
    parser.add_argument("--namespace", "-n", default="nc_db", help="Kubernetes namespace")
    parser.add_argument("--statefulset", "--sts", default="postgres", dest="statefulset", help="StatefulSet name")
    parser.add_argument("--vct", default="data", help="volumeClaimTemplates name (e.g., 'data')")
    parser.add_argument("--ordinal", type=int, default=0, help="Pod ordinal to reset (e.g., 0 for <sts>-0)")
    parser.add_argument("--replicas", type=int, default=1, help="Replicas to scale up after wipe")
    parser.add_argument("--delete-pv", action="store_true", help="Also delete the bound PV (useful if Retain)")
    parser.add_argument("--kubectl", default=os.environ.get("KUBECTL_BIN", "kubectl"), help="kubectl binary to use")
    parser.add_argument("--yes", "-y", action="store_true", help="Do not prompt for confirmation")
    args = parser.parse_args()

    ns = args.namespace
    sts = args.statefulset
    vct = args.vct
    ordinal = args.ordinal
    replicas = args.replicas
    kubectl = args.kubectl

    pod_name = f"{sts}-{ordinal}"
    pvc_name = f"{vct}-{pod_name}"

    print(f"Namespace: {ns}")
    print(f"StatefulSet: {sts}")
    print(f"Target pod ordinal: {ordinal} -> pod/{pod_name}")
    print(f"PVC to delete: {pvc_name}")
    print(f"Scale up replicas after wipe: {replicas}")
    print(f"Kubectl: {kubectl}")

    if not args.yes:
        resp = input("Proceed with FULL RESET (this will DELETE data on the PVC)? [y/N]: ").strip().lower()
        if resp not in ("y", "yes"):
            print("Aborted.")
            sys.exit(1)

    # 1) Scale down to 0
    print("\n[1/5] Scaling StatefulSet down to 0 replicas...")
    run_cmd([kubectl, "-n", ns, "scale", f"statefulset/{sts}", "--replicas=0"])
    print("Waiting for pod to terminate...")
    try:
        wait_for_pod_gone(kubectl, ns, pod_name, timeout_s=180)
    except TimeoutError as e:
        print(f"Warning: {e}. Continuing…")

    # Resolve PV name BEFORE deleting the PVC
    pv_name = get_pv_name_for_pvc(kubectl, ns, pvc_name)
    if pv_name:
        print(f"PVC {pvc_name} is bound to PV {pv_name}")
        reclaim = get_pv_reclaim_policy(kubectl, pv_name) or "Unknown"
        print(f"PV reclaimPolicy: {reclaim}")
    else:
        print(f"Could not resolve a PV for PVC {pvc_name} (it may not exist or be Pending).")

    # 2) Delete the PVC (the wipe)
    print(f"\n[2/5] Deleting PVC {pvc_name}...")
    run_cmd([kubectl, "-n", ns, "delete", "pvc", pvc_name, "--ignore-not-found=true"])

    # 3) Optionally delete the PV
    if args.delete_pv and pv_name:
        print(f"\n[3/5] Deleting PV {pv_name} (because --delete-pv was set)...")
        run_cmd([kubectl, "delete", "pv", pv_name])
    else:
        print("\n[3/5] Skipping PV deletion.")

    # 4) Scale up
    print(f"\n[4/5] Scaling StatefulSet up to {replicas} replicas...")
    run_cmd([kubectl, "-n", ns, "scale", f"statefulset/{sts}", f"--replicas={replicas}"])

    # 5) Wait for rollout ready
    print("\n[5/5] Waiting for rollout to complete…")
    wait_for_rollout_ready(kubectl, ns, sts, timeout_s=600)

    print("\n✅ Reset complete. A new PVC will have been created automatically by the StatefulSet.")
    print("Tip: watch the pod come up with:")
    print(f"  {kubectl} -n {ns} get pods -w")
    print("To view logs:")
    print(f"  {kubectl} -n {ns} logs statefulset/{sts} --tail=100 -f")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)
    except Exception as exc:
        print(f"\n❌ Error: {exc}")
        sys.exit(1)
