CREATE SCHEMA IF NOT EXISTS nc;

CREATE TABLE IF NOT EXISTS nc.healthcheck (
  id int PRIMARY KEY,
  ok boolean NOT NULL
);

INSERT INTO nc.healthcheck (id, ok)
VALUES (1, true)
ON CONFLICT (id) DO NOTHING;