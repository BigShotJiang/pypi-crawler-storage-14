from pyDOE3.grid_designs.doe_sukharev import sukharev_grid

__all__ = ["sukharev_grid"]
