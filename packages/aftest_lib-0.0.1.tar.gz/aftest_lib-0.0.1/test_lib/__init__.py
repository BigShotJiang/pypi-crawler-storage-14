import time

def custom_timer():
    while True:
        time.sleep(1)
        print("Hello")