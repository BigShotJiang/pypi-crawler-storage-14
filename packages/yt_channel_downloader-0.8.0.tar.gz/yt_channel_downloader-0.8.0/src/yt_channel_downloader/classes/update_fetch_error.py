class UpdateFetchError(RuntimeError):
    """Raised when the GitHub release metadata cannot be retrieved."""
