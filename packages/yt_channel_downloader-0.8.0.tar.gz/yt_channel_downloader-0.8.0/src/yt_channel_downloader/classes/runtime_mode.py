import enum


class RuntimeMode(enum.Enum):
    SOURCE = "source"
    FROZEN = "frozen"
