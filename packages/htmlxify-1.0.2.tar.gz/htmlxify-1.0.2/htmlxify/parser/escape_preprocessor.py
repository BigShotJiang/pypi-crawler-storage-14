"""
Escape Block Preprocessor - Handles escape{...} blocks before main parsing
Supports multi-line content including braces, parentheses, and special characters
"""

import re
from typing import Tuple, Dict, Optional, Any, List, Union


class EscapeBlockPreprocessor:
    """
    Preprocesses source code to handle escape blocks and comments.
    
    escape{
        {}
        ()
        ⚡-call
        any special characters #$%^&*()
    }
    
    These blocks are extracted and replaced with unique placeholders,
    then restored after AST building.
    
    Comments (// ...) are stripped from the source.
    """
    
    ESCAPE_PATTERN = re.compile(r'escape\s*\{', re.MULTILINE)
    
    def __init__(self):
        self.escape_blocks: Dict[str, str] = {}
        self.counter = 0
    
    def preprocess(self, source: str) -> str:
        """
        Extract escape blocks and replace with placeholders.
        Returns modified source with placeholders.
        Comments are preserved (not stripped).
        """
        result = source
        
        # First, handle escape blocks (before stripping comments inside them)
        while True:
            match = self.ESCAPE_PATTERN.search(result)
            if not match:
                break
            
            start_pos = match.start()
            brace_start = match.end() - 1  # Position of opening {
            
            # Find matching closing brace
            content, end_pos = self._find_matching_brace(result, brace_start)
            
            if content is None:
                # No matching brace found, skip this match
                break
            
            # Create placeholder
            placeholder = f"__ESCAPE_BLOCK_{self.counter}__"
            self.escape_blocks[placeholder] = content
            self.counter += 1
            
            # Replace escape{...} with a simple element containing the placeholder
            replacement = f'__escape_placeholder__ {{ {placeholder} }}'
            result = result[:start_pos] + replacement + result[end_pos + 1:]
        
        return result
    
    def _find_matching_brace(self, source: str, start: int) -> Tuple[Optional[str], int]:
        """
        Find the matching closing brace, handling nested braces.
        Returns (content, end_position) or (None, -1) if not found.
        """
        if start >= len(source) or source[start] != '{':
            return None, -1
        
        depth = 1
        pos = start + 1
        content_start = pos
        
        while pos < len(source) and depth > 0:
            char = source[pos]
            if char == '{':
                depth += 1
            elif char == '}':
                depth -= 1
            pos += 1
        
        if depth == 0:
            # Found matching brace
            content = source[content_start:pos - 1]
            return content.strip(), pos - 1
        
        return None, -1
    
    def restore_escape_content(self, ast: Dict[str, Any]) -> Dict[str, Any]:
        """
        Walk the AST and restore escape block content.
        """
        result = self._walk_and_restore(ast)
        return result if isinstance(result, dict) else ast
    
    def _walk_and_restore(self, node: Any) -> Any:
        """Recursively walk AST and restore escape placeholders"""
        if isinstance(node, dict):
            # Check if this is a placeholder element
            if node.get('tag') == '__escape_placeholder__':
                # Convert to Text node with raw content
                children = node.get('children', [])
                if children and isinstance(children[0], dict):
                    text_value = children[0].get('value', '')
                    # Check if it's a placeholder
                    if text_value in self.escape_blocks:
                        return {
                            'type': 'Text',
                            'value': self.escape_blocks[text_value],
                            'raw': True
                        }
            
            # Check Text nodes for placeholders
            if node.get('type') == 'Text':
                value = node.get('value', '')
                if value in self.escape_blocks:
                    return {
                        'type': 'Text',
                        'value': self.escape_blocks[value],
                        'raw': True
                    }
            
            # Recursively process children
            new_node = {}
            for key, value in node.items():
                if key == 'children' and isinstance(value, list):
                    new_children = []
                    for child in value:
                        restored = self._walk_and_restore(child)
                        if restored is not None:
                            new_children.append(restored)
                    new_node[key] = new_children
                else:
                    new_node[key] = self._walk_and_restore(value)
            return new_node
        
        elif isinstance(node, list):
            return [self._walk_and_restore(item) for item in node if item is not None]
        
        return node
