#!/usr/bin/env python3
"""
HTMLXIFY Language Server
A complete Language Server Protocol (LSP) implementation for HTMLXIFY.

This server provides full IDE support for HTMLXIFY files (.htmlx, .htmlxify).
Works with any IDE that supports LSP: VS Code, Neovim, Sublime Text, Emacs, etc.

Features:
- Real-time diagnostics (syntax + semantic errors)
- Code completion (tags, attributes, snippets)
- Hover information with documentation
- Go-to-definition for IDs and classes
- Find all references
- Document symbols/outline
- Document formatting
- Folding ranges
- Semantic tokens (syntax highlighting)
- Signature help for attributes
- Code actions (quick fixes)
"""

import re
import sys
import logging
from typing import Optional, List, Dict, Any, Tuple, Set
from pathlib import Path
from urllib.parse import urlparse, unquote
from htmlxify.parser.ast_builder import ASTBuilder
from htmlxify.parser.indent_processor import IndentationProcessor
from htmlxify.parser.escape_preprocessor import EscapeBlockPreprocessor
from htmlxify.validator.semantic import SemanticValidator
from htmlxify.generators.html_gen import HTMLGenerator
from htmlxify.generators.css_gen import CSSGenerator
from htmlxify.generators.js_gen import JSGenerator


from pygls.server import LanguageServer
from pygls.workspace import TextDocument
from lsprotocol import types

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("htmlxify-lsp")

# Add parent directory to path for htmlxify imports
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from htmlxify.parser.ast_builder import ASTBuilder
    from htmlxify.parser.escape_preprocessor import EscapeBlockPreprocessor
    from htmlxify.validator.semantic import SemanticValidator
    HTMLXIFY_AVAILABLE = True
except ImportError as e:
    logger.warning(f"HTMLXIFY core not available: {e}")
    HTMLXIFY_AVAILABLE = False


# =============================================================================
# LANGUAGE DATA
# =============================================================================

# HTML5 tags organized by category
HTML_TAGS = {
    # Document structure
    "html": {"void": False, "category": "structure", "doc": "Root element of an HTML document."},
    "head": {"void": False, "category": "structure", "doc": "Container for metadata (title, scripts, styles)."},
    "body": {"void": False, "category": "structure", "doc": "Container for the visible page content."},
    "title": {"void": False, "category": "structure", "doc": "Document title shown in browser tab."},
    "meta": {"void": True, "category": "structure", "doc": "Metadata about the document.", "attrs": ["name", "content", "charset", "http-equiv"]},
    "link": {"void": True, "category": "structure", "doc": "External resource link (CSS, icons).", "attrs": ["rel", "href", "type", "media"]},
    "script": {"void": False, "category": "structure", "doc": "JavaScript code or external script.", "attrs": ["src", "type", "async", "defer"]},
    "style": {"void": False, "category": "structure", "doc": "Embedded CSS styles.", "attrs": ["type", "media"]},
    "base": {"void": True, "category": "structure", "doc": "Base URL for relative URLs."},
    
    # Sectioning
    "header": {"void": False, "category": "sectioning", "doc": "Header section of page or article."},
    "footer": {"void": False, "category": "sectioning", "doc": "Footer section of page or article."},
    "nav": {"void": False, "category": "sectioning", "doc": "Navigation section with links."},
    "main": {"void": False, "category": "sectioning", "doc": "Main content (only one per page)."},
    "section": {"void": False, "category": "sectioning", "doc": "Standalone section of content."},
    "article": {"void": False, "category": "sectioning", "doc": "Self-contained composition (blog post, comment)."},
    "aside": {"void": False, "category": "sectioning", "doc": "Tangentially related content (sidebar)."},
    "address": {"void": False, "category": "sectioning", "doc": "Contact information."},
    
    # Content grouping
    "div": {"void": False, "category": "grouping", "doc": "Generic container for flow content."},
    "p": {"void": False, "category": "grouping", "doc": "Paragraph of text."},
    "h1": {"void": False, "category": "heading", "doc": "Top-level heading (one per page)."},
    "h2": {"void": False, "category": "heading", "doc": "Second-level heading."},
    "h3": {"void": False, "category": "heading", "doc": "Third-level heading."},
    "h4": {"void": False, "category": "heading", "doc": "Fourth-level heading."},
    "h5": {"void": False, "category": "heading", "doc": "Fifth-level heading."},
    "h6": {"void": False, "category": "heading", "doc": "Sixth-level heading."},
    "blockquote": {"void": False, "category": "grouping", "doc": "Extended quotation.", "attrs": ["cite"]},
    "pre": {"void": False, "category": "grouping", "doc": "Preformatted text (preserves whitespace)."},
    "hr": {"void": True, "category": "grouping", "doc": "Thematic break (horizontal rule)."},
    "figure": {"void": False, "category": "grouping", "doc": "Self-contained content with optional caption."},
    "figcaption": {"void": False, "category": "grouping", "doc": "Caption for a figure."},
    
    # Lists
    "ul": {"void": False, "category": "list", "doc": "Unordered (bulleted) list."},
    "ol": {"void": False, "category": "list", "doc": "Ordered (numbered) list.", "attrs": ["start", "type", "reversed"]},
    "li": {"void": False, "category": "list", "doc": "List item.", "attrs": ["value"]},
    "dl": {"void": False, "category": "list", "doc": "Description list."},
    "dt": {"void": False, "category": "list", "doc": "Description term."},
    "dd": {"void": False, "category": "list", "doc": "Description details."},
    
    # Inline text
    "span": {"void": False, "category": "inline", "doc": "Generic inline container."},
    "a": {"void": False, "category": "inline", "doc": "Hyperlink.", "attrs": ["href", "target", "rel", "download"]},
    "strong": {"void": False, "category": "inline", "doc": "Strong importance (bold)."},
    "em": {"void": False, "category": "inline", "doc": "Emphasis (italic)."},
    "b": {"void": False, "category": "inline", "doc": "Bold text (stylistic)."},
    "i": {"void": False, "category": "inline", "doc": "Italic text (stylistic)."},
    "u": {"void": False, "category": "inline", "doc": "Underlined text."},
    "s": {"void": False, "category": "inline", "doc": "Strikethrough text."},
    "mark": {"void": False, "category": "inline", "doc": "Highlighted/marked text."},
    "small": {"void": False, "category": "inline", "doc": "Smaller text (fine print)."},
    "sub": {"void": False, "category": "inline", "doc": "Subscript text."},
    "sup": {"void": False, "category": "inline", "doc": "Superscript text."},
    "code": {"void": False, "category": "inline", "doc": "Code snippet."},
    "kbd": {"void": False, "category": "inline", "doc": "Keyboard input."},
    "samp": {"void": False, "category": "inline", "doc": "Sample output."},
    "var": {"void": False, "category": "inline", "doc": "Variable in math/programming."},
    "abbr": {"void": False, "category": "inline", "doc": "Abbreviation.", "attrs": ["title"]},
    "cite": {"void": False, "category": "inline", "doc": "Citation/reference."},
    "q": {"void": False, "category": "inline", "doc": "Inline quotation.", "attrs": ["cite"]},
    "time": {"void": False, "category": "inline", "doc": "Date/time.", "attrs": ["datetime"]},
    "br": {"void": True, "category": "inline", "doc": "Line break."},
    "wbr": {"void": True, "category": "inline", "doc": "Word break opportunity."},
    
    # Forms
    "form": {"void": False, "category": "form", "doc": "Form for user input.", "attrs": ["action", "method", "enctype", "target", "autocomplete", "novalidate"]},
    "input": {"void": True, "category": "form", "doc": "Input field.", "attrs": ["type", "name", "value", "placeholder", "required", "disabled", "readonly", "pattern", "min", "max", "step", "autocomplete", "autofocus", "checked", "multiple", "accept"]},
    "button": {"void": False, "category": "form", "doc": "Clickable button.", "attrs": ["type", "name", "value", "disabled", "form"]},
    "select": {"void": False, "category": "form", "doc": "Dropdown select.", "attrs": ["name", "multiple", "size", "required", "disabled"]},
    "option": {"void": False, "category": "form", "doc": "Select option.", "attrs": ["value", "selected", "disabled"]},
    "optgroup": {"void": False, "category": "form", "doc": "Option group.", "attrs": ["label", "disabled"]},
    "textarea": {"void": False, "category": "form", "doc": "Multi-line text input.", "attrs": ["name", "rows", "cols", "placeholder", "required", "disabled", "readonly", "maxlength"]},
    "label": {"void": False, "category": "form", "doc": "Label for form element.", "attrs": ["for"]},
    "fieldset": {"void": False, "category": "form", "doc": "Group of form controls.", "attrs": ["disabled", "form", "name"]},
    "legend": {"void": False, "category": "form", "doc": "Caption for fieldset."},
    "datalist": {"void": False, "category": "form", "doc": "Predefined options for input."},
    "output": {"void": False, "category": "form", "doc": "Calculation result.", "attrs": ["for", "form", "name"]},
    "progress": {"void": False, "category": "form", "doc": "Progress indicator.", "attrs": ["value", "max"]},
    "meter": {"void": False, "category": "form", "doc": "Scalar measurement.", "attrs": ["value", "min", "max", "low", "high", "optimum"]},
    
    # Tables
    "table": {"void": False, "category": "table", "doc": "Table container."},
    "thead": {"void": False, "category": "table", "doc": "Table header group."},
    "tbody": {"void": False, "category": "table", "doc": "Table body group."},
    "tfoot": {"void": False, "category": "table", "doc": "Table footer group."},
    "tr": {"void": False, "category": "table", "doc": "Table row."},
    "th": {"void": False, "category": "table", "doc": "Table header cell.", "attrs": ["colspan", "rowspan", "scope", "headers"]},
    "td": {"void": False, "category": "table", "doc": "Table data cell.", "attrs": ["colspan", "rowspan", "headers"]},
    "caption": {"void": False, "category": "table", "doc": "Table caption."},
    "colgroup": {"void": False, "category": "table", "doc": "Column group.", "attrs": ["span"]},
    "col": {"void": True, "category": "table", "doc": "Column definition.", "attrs": ["span"]},
    
    # Media
    "img": {"void": True, "category": "media", "doc": "Image.", "attrs": ["src", "alt", "width", "height", "loading", "srcset", "sizes", "crossorigin"]},
    "video": {"void": False, "category": "media", "doc": "Video player.", "attrs": ["src", "poster", "controls", "autoplay", "loop", "muted", "width", "height", "preload"]},
    "audio": {"void": False, "category": "media", "doc": "Audio player.", "attrs": ["src", "controls", "autoplay", "loop", "muted", "preload"]},
    "source": {"void": True, "category": "media", "doc": "Media source.", "attrs": ["src", "type", "media", "srcset", "sizes"]},
    "track": {"void": True, "category": "media", "doc": "Text track for media.", "attrs": ["src", "kind", "srclang", "label", "default"]},
    "picture": {"void": False, "category": "media", "doc": "Responsive image container."},
    "canvas": {"void": False, "category": "media", "doc": "Drawing canvas.", "attrs": ["width", "height"]},
    "svg": {"void": False, "category": "media", "doc": "SVG graphics container."},
    "iframe": {"void": False, "category": "media", "doc": "Inline frame.", "attrs": ["src", "srcdoc", "name", "width", "height", "sandbox", "allow", "loading"]},
    "embed": {"void": True, "category": "media", "doc": "External content.", "attrs": ["src", "type", "width", "height"]},
    "object": {"void": False, "category": "media", "doc": "External resource.", "attrs": ["data", "type", "width", "height", "name"]},
    "param": {"void": True, "category": "media", "doc": "Object parameter.", "attrs": ["name", "value"]},
    
    # Interactive
    "details": {"void": False, "category": "interactive", "doc": "Disclosure widget.", "attrs": ["open"]},
    "summary": {"void": False, "category": "interactive", "doc": "Summary for details."},
    "dialog": {"void": False, "category": "interactive", "doc": "Dialog box.", "attrs": ["open"]},
    "menu": {"void": False, "category": "interactive", "doc": "Menu of commands."},
    
    # Other
    "template": {"void": False, "category": "scripting", "doc": "HTML template."},
    "slot": {"void": False, "category": "scripting", "doc": "Web component slot.", "attrs": ["name"]},
    "noscript": {"void": False, "category": "scripting", "doc": "Fallback for no-script."},
    "data": {"void": False, "category": "other", "doc": "Machine-readable data.", "attrs": ["value"]},
    "area": {"void": True, "category": "other", "doc": "Image map area.", "attrs": ["shape", "coords", "href", "alt", "target"]},
    "map": {"void": False, "category": "other", "doc": "Image map.", "attrs": ["name"]},
}

# Global HTML attributes
GLOBAL_ATTRIBUTES = [
    ("id", "Unique identifier for the element."),
    ("class", "CSS class name(s) for styling."),
    ("style", "Inline CSS styles."),
    ("title", "Advisory information (tooltip)."),
    ("lang", "Language of the element's content."),
    ("dir", "Text direction (ltr, rtl, auto)."),
    ("hidden", "Hides the element."),
    ("tabindex", "Tab order for keyboard navigation."),
    ("accesskey", "Keyboard shortcut."),
    ("contenteditable", "Makes content editable."),
    ("draggable", "Makes element draggable."),
    ("spellcheck", "Enable/disable spell checking."),
    ("translate", "Should content be translated."),
    ("data-*", "Custom data attributes."),
    ("aria-*", "Accessibility attributes."),
    ("role", "ARIA role for accessibility."),
]

# HTMLXIFY special attributes
SPECIAL_ATTRIBUTES = {
    "⚡-call": "Backend function call. Triggers server-side function when element renders.",
    "@-call": "Backend function call (alias for ⚡-call).",
    "⚡-data": "Dynamic data binding. Binds server-side data to element content.",
    "@-data": "Dynamic data binding (alias for ⚡-data).",
}

# Common CSS class snippets
CSS_CLASS_SNIPPETS = [
    ("container", "Container for centering content"),
    ("flex", "Flexbox container"),
    ("grid", "Grid container"),
    ("hidden", "Hide element"),
    ("text-center", "Center text"),
    ("text-left", "Left-align text"),
    ("text-right", "Right-align text"),
    ("btn", "Button styling"),
    ("btn-primary", "Primary button"),
    ("card", "Card container"),
    ("form-control", "Form input styling"),
]

# Semantic token types for syntax highlighting
SEMANTIC_TOKEN_TYPES = [
    "namespace",    # 0
    "type",         # 1 - tag names
    "class",        # 2 - class selectors
    "enum",         # 3
    "interface",    # 4
    "struct",       # 5
    "typeParameter",# 6
    "parameter",    # 7 - attribute names
    "variable",     # 8 - id selectors
    "property",     # 9
    "enumMember",   # 10
    "event",        # 11 - special attributes
    "function",     # 12
    "method",       # 13
    "macro",        # 14 - escape blocks
    "keyword",      # 15
    "modifier",     # 16
    "comment",      # 17
    "string",       # 18 - attribute values
    "number",       # 19
    "regexp",       # 20
    "operator",     # 21
]

SEMANTIC_TOKEN_MODIFIERS = [
    "declaration",
    "definition",
    "readonly",
    "static",
    "deprecated",
    "abstract",
    "async",
    "modification",
    "documentation",
    "defaultLibrary",
]


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def uri_to_path(uri: str) -> Path:
    """Convert a file URI to a Path object."""
    if uri.startswith("file://"):
        # Handle Windows paths like file:///C:/...
        path = unquote(urlparse(uri).path)
        if sys.platform == "win32" and path.startswith("/"):
            path = path[1:]  # Remove leading slash on Windows
        return Path(path)
    return Path(uri)


def get_word_at_position(document: TextDocument, position: types.Position) -> Tuple[str, types.Range]:
    """Get the word at the given position and its range."""
    try:
        line = document.lines[position.line]
    except IndexError:
        return "", types.Range(start=position, end=position)
    
    # Find word boundaries
    col = position.character
    start = col
    end = col
    
    # Expand left
    while start > 0 and (line[start-1].isalnum() or line[start-1] in '_-@⚡'):
        start -= 1
    
    # Expand right
    while end < len(line) and (line[end].isalnum() or line[end] in '_-@⚡'):
        end += 1
    
    word = line[start:end]
    word_range = types.Range(
        start=types.Position(line=position.line, character=start),
        end=types.Position(line=position.line, character=end)
    )
    
    return word, word_range


def parse_document_structure(source: str) -> Dict[str, Any]:
    """Parse document to extract IDs, classes, and element structure."""
    result = {
        "ids": {},       # id -> {line, col, tag}
        "classes": {},   # class -> [{line, col, tag}, ...]
        "elements": [],  # [{tag, line, col, id, classes, children}, ...]
        "errors": [],
    }
    
    lines = source.split('\n')
    
    # Patterns for parsing
    element_pattern = re.compile(r'^(\s*)(\w+)((?:\.[a-zA-Z_][\w-]*)*)(#[\w-]+)?')
    class_pattern = re.compile(r'\.([a-zA-Z_][\w-]*)')
    id_pattern = re.compile(r'#([\w-]+)')
    
    for line_num, line in enumerate(lines):
        match = element_pattern.match(line)
        if match:
            indent = len(match.group(1))
            tag = match.group(2)
            class_str = match.group(3) or ""
            id_str = match.group(4) or ""
            
            # Extract classes
            classes = class_pattern.findall(class_str)
            for cls in classes:
                if cls not in result["classes"]:
                    result["classes"][cls] = []
                result["classes"][cls].append({
                    "line": line_num,
                    "col": line.find(f".{cls}"),
                    "tag": tag
                })
            
            # Extract ID
            id_match = id_pattern.search(id_str)
            if id_match:
                id_name = id_match.group(1)
                if id_name in result["ids"]:
                    result["errors"].append({
                        "line": line_num,
                        "message": f"Duplicate ID '{id_name}'",
                        "severity": "error"
                    })
                else:
                    result["ids"][id_name] = {
                        "line": line_num,
                        "col": line.find(f"#{id_name}"),
                        "tag": tag
                    }
            
            result["elements"].append({
                "tag": tag,
                "line": line_num,
                "col": indent,
                "indent": indent,
                "id": id_match.group(1) if id_match else None,
                "classes": classes,
            })
    
    return result


# =============================================================================
# LANGUAGE SERVER CLASS
# =============================================================================

class HtmlxifyLanguageServer(LanguageServer):
    """Full-featured Language Server for HTMLXIFY files."""
    
    def __init__(self):
        super().__init__(
            name="htmlxify-language-server",
            version="1.0.0"
        )
        
        # Document cache for parsed structures
        self.document_cache: Dict[str, Dict[str, Any]] = {}
        
        # Initialize escape preprocessor if available
        if HTMLXIFY_AVAILABLE:
            self.escape_preprocessor = EscapeBlockPreprocessor()
        else:
            self.escape_preprocessor = None
        
        logger.info("HTMLXIFY Language Server initialized")
    
    def get_document_structure(self, uri: str) -> Dict[str, Any]:
        """Get or compute document structure."""
        document = self.workspace.get_text_document(uri)
        
        # Check cache
        doc_version = getattr(document, 'version', 0)
        cached = self.document_cache.get(uri)
        if cached and cached.get('version') == doc_version:
            return cached['structure']
        
        # Parse fresh
        structure = parse_document_structure(document.source)
        self.document_cache[uri] = {
            'version': doc_version,
            'structure': structure
        }
        
        return structure


# Create global server instance
server = HtmlxifyLanguageServer()


@server.feature(types.TEXT_DOCUMENT_DID_OPEN)
async def did_open(ls: HtmlxifyLanguageServer, params: types.DidOpenTextDocumentParams):
    """Handle document open - validate immediately."""
    await validate_document(ls, params.text_document.uri)


@server.feature(types.TEXT_DOCUMENT_DID_CHANGE)
async def did_change(ls: HtmlxifyLanguageServer, params: types.DidChangeTextDocumentParams):
    """Handle document change - validate on each change."""
    await validate_document(ls, params.text_document.uri)


@server.feature(types.TEXT_DOCUMENT_DID_SAVE)
async def did_save(ls: HtmlxifyLanguageServer, params: types.DidSaveTextDocumentParams):
    """Handle document save - validate after save."""
    await validate_document(ls, params.text_document.uri)


async def validate_document(ls: HtmlxifyLanguageServer, uri: str):
    """Validate an HTMLXIFY document and publish diagnostics."""
    document = ls.workspace.get_text_document(uri)
    source = document.source
    filename = Path(uri).name if uri.startswith("file://") else uri
    
    diagnostics: List[types.Diagnostic] = []
    
    try:
        # Preprocess escape blocks if available
        if ls.escape_preprocessor is not None:
            processed_source = ls.escape_preprocessor.preprocess(source)
        else:
            processed_source = source
        
        # Try to parse
        ast_builder = ASTBuilder(processed_source, filename)
        ast = ast_builder.parse()
        
        # Restore escape content if preprocessor available
        if ls.escape_preprocessor is not None:
            ast = ls.escape_preprocessor.restore_escape_content(ast)
        
        # Run semantic validation
        validator = SemanticValidator(ast, filename)
        
        # Capture validation errors
        import io
        import sys
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        
        is_valid = validator.validate()
        
        validation_output = sys.stdout.getvalue()
        sys.stdout = old_stdout
        
        if not is_valid:
            # Parse validation errors from output
            for line in validation_output.split('\n'):
                if 'Error' in line or 'Warning' in line:
                    # Try to extract line number
                    match = re.search(r'line (\d+)', line, re.IGNORECASE)
                    line_num = int(match.group(1)) - 1 if match else 0
                    
                    severity = types.DiagnosticSeverity.Error if 'Error' in line else types.DiagnosticSeverity.Warning
                    
                    diagnostics.append(types.Diagnostic(
                        range=types.Range(
                            start=types.Position(line=line_num, character=0),
                            end=types.Position(line=line_num, character=100)
                        ),
                        message=line.strip(),
                        severity=severity,
                        source="htmlxify"
                    ))
                    
    except Exception as e:
        error_msg = str(e)
        
        # Try to extract line number from error
        line_num = 0
        match = re.search(r'line (\d+)', error_msg, re.IGNORECASE)
        if match:
            line_num = int(match.group(1)) - 1
        
        # Also check for Lark-specific error format
        match = re.search(r'at line (\d+)', error_msg)
        if match:
            line_num = int(match.group(1)) - 1
        
        diagnostics.append(types.Diagnostic(
            range=types.Range(
                start=types.Position(line=line_num, character=0),
                end=types.Position(line=line_num, character=100)
            ),
            message=f"Parse error: {error_msg}",
            severity=types.DiagnosticSeverity.Error,
            source="htmlxify"
        ))
    
    # Publish diagnostics
    ls.publish_diagnostics(uri, diagnostics)


@server.feature(types.TEXT_DOCUMENT_COMPLETION)
def completions(ls: HtmlxifyLanguageServer, params: types.CompletionParams) -> types.CompletionList:
    """Provide code completion suggestions."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    position = params.position
    
    try:
        line = document.lines[position.line]
        line_before_cursor = line[:position.character]
    except IndexError:
        return types.CompletionList(is_incomplete=False, items=[])
    
    items: List[types.CompletionItem] = []
    
    # Check context: inside parentheses = attributes, otherwise = tags
    open_paren = line_before_cursor.rfind('(')
    close_paren = line_before_cursor.rfind(')')
    
    if open_paren > close_paren:
        # Attributes context
        tag_match = re.search(r'(\w+)\s*[.#]?\w*\s*\(', line_before_cursor)
        tag_name = tag_match.group(1) if tag_match else None
        
        # Global attributes
        for attr, doc in GLOBAL_ATTRIBUTES:
            items.append(types.CompletionItem(
                label=attr, kind=types.CompletionItemKind.Property,
                detail="Global attribute", documentation=doc,
                insert_text=f'{attr}:""' if not attr.endswith('*') else attr.rstrip('*'),
            ))
        
        # Tag-specific attributes
        if tag_name and tag_name in HTML_TAGS:
            for attr in HTML_TAGS[tag_name].get("attrs", []):
                items.append(types.CompletionItem(
                    label=attr, kind=types.CompletionItemKind.Property,
                    detail=f"<{tag_name}> attribute", insert_text=f'{attr}:""',
                ))
        
        # HTMLXIFY special attributes
        for attr, doc in SPECIAL_ATTRIBUTES.items():
            items.append(types.CompletionItem(
                label=attr, kind=types.CompletionItemKind.Event,
                detail="HTMLXIFY attribute", documentation=doc,
                insert_text=f'{attr}:""',
            ))
    else:
        # Tags context
        for tag, info in HTML_TAGS.items():
            items.append(types.CompletionItem(
                label=tag, kind=types.CompletionItemKind.Class,
                detail=f"<{tag}> - {info['category']}",
                documentation=info["doc"],
                insert_text=f"{tag} {{ $0 }}" if not info["void"] else tag,
                insert_text_format=types.InsertTextFormat.Snippet,
            ))
        
        # Escape block
        items.append(types.CompletionItem(
            label="escape", kind=types.CompletionItemKind.Snippet,
            detail="Raw content block",
            documentation="Include raw content with {}, (), special chars",
            insert_text="escape{ $0 }",
            insert_text_format=types.InsertTextFormat.Snippet,
        ))
    
    return types.CompletionList(is_incomplete=False, items=items)


@server.feature(types.TEXT_DOCUMENT_HOVER)
def hover(ls: HtmlxifyLanguageServer, params: types.HoverParams) -> Optional[types.Hover]:
    """Provide hover information for tags and attributes."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    position = params.position
    
    word, word_range = get_word_at_position(document, position)
    if not word:
        return None
    
    # HTML tag
    if word in HTML_TAGS:
        info = HTML_TAGS[word]
        attrs = info.get("attrs", [])
        attr_text = ", ".join(attrs[:5]) + ("..." if len(attrs) > 5 else "") if attrs else "None specific"
        
        return types.Hover(
            contents=types.MarkupContent(
                kind=types.MarkupKind.Markdown,
                value=f"## `<{word}>`\n\n{info['doc']}\n\n**Category:** {info['category']}\n\n**Attributes:** {attr_text}\n\n```htmlxify\n{word} {{ content }}\n```"
            ),
            range=word_range
        )
    
    # Special attributes
    if word in SPECIAL_ATTRIBUTES:
        return types.Hover(
            contents=types.MarkupContent(
                kind=types.MarkupKind.Markdown,
                value=f"## `{word}`\n\n{SPECIAL_ATTRIBUTES[word]}\n\n```htmlxify\nbutton({word}:\"handler\") {{ Click }}\n```"
            ),
            range=word_range
        )
    
    # Escape keyword
    if word == "escape":
        return types.Hover(
            contents=types.MarkupContent(
                kind=types.MarkupKind.Markdown,
                value="## `escape{}`\n\nRaw content block. Preserves:\n- Braces `{}`\n- Parentheses `()`\n- Special characters\n- Whitespace\n\n```htmlxify\npre { escape{ code here } }\n```"
            ),
            range=word_range
        )
    
    return None


@server.feature(types.TEXT_DOCUMENT_DOCUMENT_SYMBOL)
def document_symbols(ls: HtmlxifyLanguageServer, params: types.DocumentSymbolParams) -> List[types.DocumentSymbol]:
    """Provide document outline/symbols."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    source = document.source
    lines = source.split('\n')
    
    symbols: List[types.DocumentSymbol] = []
    
    # Simple regex-based symbol extraction
    tag_pattern = re.compile(r'^(\s*)(\w+)([.#][\w-]+)*\s*(?:\([^)]*\))?\s*\{')
    
    for i, line in enumerate(lines):
        match = tag_pattern.match(line)
        if match:
            indent = len(match.group(1))
            tag_name = match.group(2)
            modifiers = match.group(3) or ""
            
            # Determine symbol kind based on tag
            if tag_name in ['section', 'article', 'header', 'footer', 'nav', 'main', 'aside']:
                kind = types.SymbolKind.Module
            elif tag_name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                kind = types.SymbolKind.String
            elif tag_name in ['form']:
                kind = types.SymbolKind.Interface
            elif tag_name in ['button', 'input', 'select', 'textarea']:
                kind = types.SymbolKind.Field
            elif tag_name in ['a']:
                kind = types.SymbolKind.Event
            elif tag_name in ['div', 'span']:
                kind = types.SymbolKind.Variable
            else:
                kind = types.SymbolKind.Class
            
            name = f"{tag_name}{modifiers}"
            
            symbols.append(types.DocumentSymbol(
                name=name,
                kind=kind,
                range=types.Range(
                    start=types.Position(line=i, character=0),
                    end=types.Position(line=i, character=len(line))
                ),
                selection_range=types.Range(
                    start=types.Position(line=i, character=indent),
                    end=types.Position(line=i, character=indent + len(tag_name))
                )
            ))
    
    return symbols


@server.feature(types.TEXT_DOCUMENT_FORMATTING)
def formatting(ls: HtmlxifyLanguageServer, params: types.DocumentFormattingParams) -> List[types.TextEdit]:
    """Provide document formatting."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    source = document.source
    lines = source.split('\n')
    
    edits: List[types.TextEdit] = []
    
    indent_level = 0
    indent_size = params.options.tab_size or 2
    use_tabs = not params.options.insert_spaces
    indent_char = '\t' if use_tabs else ' ' * indent_size
    
    formatted_lines = []
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        
        if not stripped:
            formatted_lines.append('')
            continue
        
        # Adjust indent level for closing braces at start of line
        if stripped.startswith('}'):
            indent_level = max(0, indent_level - 1)
        
        # Apply indentation
        formatted_line = indent_char * indent_level + stripped
        formatted_lines.append(formatted_line)
        
        # Adjust indent level for opening braces
        open_braces = stripped.count('{')
        close_braces = stripped.count('}')
        
        # Don't count braces that are both opened and closed on same line at end
        if stripped.endswith('}') and not stripped.endswith('{}'):
            close_braces -= 1
        
        indent_level += open_braces - close_braces
        indent_level = max(0, indent_level)
    
    formatted_source = '\n'.join(formatted_lines)
    
    if formatted_source != source:
        edits.append(types.TextEdit(
            range=types.Range(
                start=types.Position(line=0, character=0),
                end=types.Position(line=len(lines), character=0)
            ),
            new_text=formatted_source
        ))
    
    return edits


def start_server():
    """Start the language server."""
    server.start_io()


# =============================================================================
# GO-TO-DEFINITION - Jump to ID/class definitions
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_DEFINITION)
def goto_definition(ls: HtmlxifyLanguageServer, params: types.DefinitionParams) -> Optional[types.Location]:
    """Go to definition of ID or class."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    word, _ = get_word_at_position(document, params.position)
    
    if not word:
        return None
    
    structure = ls.get_document_structure(params.text_document.uri)
    
    # Check if it's an ID reference
    if word in structure["ids"]:
        info = structure["ids"][word]
        return types.Location(
            uri=params.text_document.uri,
            range=types.Range(
                start=types.Position(line=info["line"], character=info["col"]),
                end=types.Position(line=info["line"], character=info["col"] + len(word) + 1)
            )
        )
    
    # Check if it's a class reference
    if word in structure["classes"] and structure["classes"][word]:
        info = structure["classes"][word][0]  # First definition
        return types.Location(
            uri=params.text_document.uri,
            range=types.Range(
                start=types.Position(line=info["line"], character=info["col"]),
                end=types.Position(line=info["line"], character=info["col"] + len(word) + 1)
            )
        )
    
    return None


# =============================================================================
# FIND REFERENCES - Find all usages of ID/class
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_REFERENCES)
def find_references(ls: HtmlxifyLanguageServer, params: types.ReferenceParams) -> List[types.Location]:
    """Find all references to an ID or class."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    word, _ = get_word_at_position(document, params.position)
    
    if not word:
        return []
    
    structure = ls.get_document_structure(params.text_document.uri)
    locations = []
    
    # Find class references
    if word in structure["classes"]:
        for info in structure["classes"][word]:
            locations.append(types.Location(
                uri=params.text_document.uri,
                range=types.Range(
                    start=types.Position(line=info["line"], character=info["col"]),
                    end=types.Position(line=info["line"], character=info["col"] + len(word) + 1)
                )
            ))
    
    # Find ID reference
    if word in structure["ids"]:
        info = structure["ids"][word]
        locations.append(types.Location(
            uri=params.text_document.uri,
            range=types.Range(
                start=types.Position(line=info["line"], character=info["col"]),
                end=types.Position(line=info["line"], character=info["col"] + len(word) + 1)
            )
        ))
    
    return locations


# =============================================================================
# FOLDING RANGES - Collapsible code sections
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_FOLDING_RANGE)
def folding_ranges(ls: HtmlxifyLanguageServer, params: types.FoldingRangeParams) -> List[types.FoldingRange]:
    """Provide folding ranges for code blocks."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    lines = document.source.split('\n')
    
    ranges = []
    stack = []  # Stack of (start_line, indent)
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        
        # Track opening braces
        if '{' in stripped and not stripped.startswith('//'):
            stack.append(i)
        
        # Track closing braces
        if '}' in stripped and stack:
            start_line = stack.pop()
            if i > start_line:  # Only fold if more than 1 line
                ranges.append(types.FoldingRange(
                    start_line=start_line,
                    end_line=i,
                    kind=types.FoldingRangeKind.Region
                ))
        
        # Comment folding
        if stripped.startswith('//') and i > 0:
            prev = lines[i-1].strip()
            if not prev.startswith('//'):
                # Start of comment block
                comment_start = i
                while i < len(lines) - 1 and lines[i+1].strip().startswith('//'):
                    i += 1
                if i > comment_start:
                    ranges.append(types.FoldingRange(
                        start_line=comment_start,
                        end_line=i,
                    kind=types.FoldingRangeKind.Comment
                ))
    
    return ranges


# =============================================================================
# CODE ACTIONS - Quick fixes and refactoring
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_CODE_ACTION)
def code_actions(ls: HtmlxifyLanguageServer, params: types.CodeActionParams) -> List[types.CodeAction]:
    """Provide code actions (quick fixes)."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    actions = []
    
    # Get diagnostics in range
    for diagnostic in params.context.diagnostics:
        line_num = diagnostic.range.start.line
        try:
            line = document.lines[line_num]
        except IndexError:
            continue
        
        # Fix: Convert ⚡ to @ or vice versa
        if '⚡-call' in line or '⚡-data' in line:
            new_line = line.replace('⚡-call', '@-call').replace('⚡-data', '@-data')
            actions.append(types.CodeAction(
                title="Replace ⚡ with @ alias",
                kind=types.CodeActionKind.QuickFix,
                edit=types.WorkspaceEdit(
                    changes={
                        params.text_document.uri: [
                            types.TextEdit(
                                range=types.Range(
                                    start=types.Position(line=line_num, character=0),
                                    end=types.Position(line=line_num, character=len(line))
                                ),
                                new_text=new_line
                            )
                        ]
                    }
                )
            ))
        
        # Fix: Add missing closing brace
        if 'unexpected' in diagnostic.message.lower() or 'brace' in diagnostic.message.lower():
            actions.append(types.CodeAction(
                title="Add closing brace }",
                kind=types.CodeActionKind.QuickFix,
                edit=types.WorkspaceEdit(
                    changes={
                        params.text_document.uri: [
                            types.TextEdit(
                                range=types.Range(
                                    start=types.Position(line=line_num + 1, character=0),
                                    end=types.Position(line=line_num + 1, character=0)
                                ),
                                new_text="}\n"
                            )
                        ]
                    }
                )
            ))
    
    # Refactoring: Wrap in div
    if params.range.start.line != params.range.end.line or params.range.start.character != params.range.end.character:
        actions.append(types.CodeAction(
            title="Wrap selection in div",
            kind=types.CodeActionKind.RefactorExtract,
            edit=types.WorkspaceEdit(
                changes={
                    params.text_document.uri: [
                        types.TextEdit(
                            range=types.Range(
                                start=params.range.start,
                                end=params.range.start
                            ),
                            new_text="div {\n  "
                        ),
                        types.TextEdit(
                            range=types.Range(
                                start=params.range.end,
                                end=params.range.end
                            ),
                            new_text="\n}"
                        )
                    ]
                }
            )
        ))
    
    return actions


# =============================================================================
# RENAME - Rename IDs and classes across document
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_RENAME)
def rename(ls: HtmlxifyLanguageServer, params: types.RenameParams) -> Optional[types.WorkspaceEdit]:
    """Rename an ID or class throughout the document."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    word, _ = get_word_at_position(document, params.position)
    
    if not word:
        return None
    
    structure = ls.get_document_structure(params.text_document.uri)
    edits = []
    
    # Rename class
    if word in structure["classes"]:
        for info in structure["classes"][word]:
            edits.append(types.TextEdit(
                range=types.Range(
                    start=types.Position(line=info["line"], character=info["col"] + 1),  # Skip the dot
                    end=types.Position(line=info["line"], character=info["col"] + 1 + len(word))
                ),
                new_text=params.new_name
            ))
    
    # Rename ID
    if word in structure["ids"]:
        info = structure["ids"][word]
        edits.append(types.TextEdit(
            range=types.Range(
                start=types.Position(line=info["line"], character=info["col"] + 1),  # Skip the hash
                end=types.Position(line=info["line"], character=info["col"] + 1 + len(word))
            ),
            new_text=params.new_name
        ))
    
    if edits:
        return types.WorkspaceEdit(changes={params.text_document.uri: edits})
    
    return None


@server.feature(types.TEXT_DOCUMENT_PREPARE_RENAME)
def prepare_rename(ls: HtmlxifyLanguageServer, params: types.PrepareRenameParams) -> Optional[types.Range]:
    """Check if rename is valid at position."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    word, word_range = get_word_at_position(document, params.position)
    
    if not word:
        return None
    
    structure = ls.get_document_structure(params.text_document.uri)
    
    # Can only rename IDs and classes
    if word in structure["ids"] or word in structure["classes"]:
        return word_range
    
    return None


# =============================================================================
# SIGNATURE HELP - Show attribute syntax help
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_SIGNATURE_HELP)
def signature_help(ls: HtmlxifyLanguageServer, params: types.SignatureHelpParams) -> Optional[types.SignatureHelp]:
    """Provide signature help inside attribute parentheses."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    position = params.position
    
    try:
        line = document.lines[position.line]
        line_before = line[:position.character]
    except IndexError:
        return None
    
    # Check if inside parentheses
    open_paren = line_before.rfind('(')
    close_paren = line_before.rfind(')')
    
    if open_paren <= close_paren:
        return None
    
    # Find tag name
    tag_match = re.search(r'(\w+)\s*[.#]?[\w-]*\s*\($', line_before[:open_paren+1])
    if not tag_match:
        return None
    
    tag = tag_match.group(1)
    
    # Build signature
    params_list = []
    
    # Global attributes
    params_list.append(types.ParameterInformation(label="id", documentation="Unique element identifier"))
    params_list.append(types.ParameterInformation(label="class", documentation="CSS class name(s)"))
    
    # Tag-specific
    if tag in HTML_TAGS and "attrs" in HTML_TAGS[tag]:
        for attr in HTML_TAGS[tag]["attrs"]:
            params_list.append(types.ParameterInformation(label=attr, documentation=f"<{tag}> attribute"))
    
    # Special attributes
    params_list.append(types.ParameterInformation(label="⚡-call", documentation="Backend function call"))
    params_list.append(types.ParameterInformation(label="@-call", documentation="Backend function call (alias)"))
    params_list.append(types.ParameterInformation(label="⚡-data", documentation="Dynamic data binding"))
    params_list.append(types.ParameterInformation(label="@-data", documentation="Dynamic data binding (alias)"))
    
    sig = types.SignatureInformation(
        label=f'{tag}(attr: "value", ...)',
        documentation=f"Attributes for <{tag}> element. Use key:\"value\" or key:value syntax.",
        parameters=params_list
    )
    
    return types.SignatureHelp(signatures=[sig], active_signature=0)


# =============================================================================
# DOCUMENT HIGHLIGHT - Highlight same symbols
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_DOCUMENT_HIGHLIGHT)
def document_highlight(ls: HtmlxifyLanguageServer, params: types.DocumentHighlightParams) -> List[types.DocumentHighlight]:
    """Highlight all occurrences of a symbol."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    word, _ = get_word_at_position(document, params.position)
    
    if not word:
        return []
    
    highlights = []
    structure = ls.get_document_structure(params.text_document.uri)
    
    # Highlight classes
    if word in structure["classes"]:
        for info in structure["classes"][word]:
            highlights.append(types.DocumentHighlight(
                range=types.Range(
                    start=types.Position(line=info["line"], character=info["col"]),
                    end=types.Position(line=info["line"], character=info["col"] + len(word) + 1)
                ),
                kind=types.DocumentHighlightKind.Read
            ))
    
    # Highlight ID
    if word in structure["ids"]:
        info = structure["ids"][word]
        highlights.append(types.DocumentHighlight(
            range=types.Range(
                start=types.Position(line=info["line"], character=info["col"]),
                end=types.Position(line=info["line"], character=info["col"] + len(word) + 1)
            ),
            kind=types.DocumentHighlightKind.Write
        ))
    
    return highlights


# =============================================================================
# WORKSPACE SYMBOLS - Search symbols across files
# =============================================================================

@server.feature(types.WORKSPACE_SYMBOL)
def workspace_symbol(ls: HtmlxifyLanguageServer, params: types.WorkspaceSymbolParams) -> List[types.SymbolInformation]:
    """Search for symbols across the workspace."""
    query = params.query.lower()
    symbols = []
    
    # Iterate through cached document structures
    for uri, cached in ls.document_cache.items():
        structure = cached.get('structure', {})
        
        # Search IDs
        for id_name, info in structure.get("ids", {}).items():
            if query in id_name.lower():
                symbols.append(types.SymbolInformation(
                    name=f"#{id_name}",
                    kind=types.SymbolKind.Variable,
                    location=types.Location(
                        uri=uri,
                        range=types.Range(
                            start=types.Position(line=info["line"], character=info["col"]),
                            end=types.Position(line=info["line"], character=info["col"] + len(id_name) + 1)
                        )
                    )
                ))
        
        # Search classes
        for class_name in structure.get("classes", {}):
            if query in class_name.lower():
                info = structure["classes"][class_name][0]
                symbols.append(types.SymbolInformation(
                    name=f".{class_name}",
                    kind=types.SymbolKind.Class,
                    location=types.Location(
                        uri=uri,
                        range=types.Range(
                            start=types.Position(line=info["line"], character=info["col"]),
                            end=types.Position(line=info["line"], character=info["col"] + len(class_name) + 1)
                        )
                    )
                ))
        
        # Search elements
        for elem in structure.get("elements", []):
            if query in elem["tag"].lower():
                symbols.append(types.SymbolInformation(
                    name=elem["tag"],
                    kind=types.SymbolKind.Struct,
                    location=types.Location(
                        uri=uri,
                        range=types.Range(
                            start=types.Position(line=elem["line"], character=0),
                            end=types.Position(line=elem["line"], character=len(elem["tag"]))
                        )
                    )
                ))
    
    return symbols


# =============================================================================
# DOCUMENT LINKS - Clickable URLs
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_DOCUMENT_LINK)
def document_links(ls: HtmlxifyLanguageServer, params: types.DocumentLinkParams) -> List[types.DocumentLink]:
    """Extract clickable links from the document."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    links = []
    
    # URL patterns
    url_pattern = re.compile(r'(https?://[^\s\'"<>()]+)')
    
    for i, line in enumerate(document.lines):
        for match in url_pattern.finditer(line):
            links.append(types.DocumentLink(
                range=types.Range(
                    start=types.Position(line=i, character=match.start()),
                    end=types.Position(line=i, character=match.end())
                ),
                target=match.group(1)
            ))
    
    return links


# =============================================================================
# SELECTION RANGE - Smart expand/shrink selection
# =============================================================================

@server.feature(types.TEXT_DOCUMENT_SELECTION_RANGE)
def selection_range(ls: HtmlxifyLanguageServer, params: types.SelectionRangeParams) -> List[types.SelectionRange]:
    """Provide smart selection ranges for expand/shrink selection."""
    document = ls.workspace.get_text_document(params.text_document.uri)
    text = document.source
    lines = document.lines
    ranges = []
    
    for position in params.positions:
        line_num = position.line
        col = position.character
        
        if line_num >= len(lines):
            ranges.append(None)
            continue
        
        line = lines[line_num]
        
        # Selection levels: word -> line content -> line -> block -> document
        selections = []
        
        # 1. Word selection
        word_start = col
        word_end = col
        while word_start > 0 and line[word_start - 1].isalnum():
            word_start -= 1
        while word_end < len(line) and line[word_end].isalnum():
            word_end += 1
        
        if word_start != word_end:
            word_range = types.Range(
                start=types.Position(line=line_num, character=word_start),
                end=types.Position(line=line_num, character=word_end)
            )
            selections.append(word_range)
        
        # 2. Line content (trimmed)
        stripped = line.rstrip()
        content_start = len(line) - len(line.lstrip())
        if stripped:
            line_content_range = types.Range(
                start=types.Position(line=line_num, character=content_start),
                end=types.Position(line=line_num, character=len(stripped))
            )
            selections.append(line_content_range)
        
        # 3. Full line
        full_line_range = types.Range(
            start=types.Position(line=line_num, character=0),
            end=types.Position(line=line_num, character=len(line))
        )
        selections.append(full_line_range)
        
        # 4. Full document
        doc_range = types.Range(
            start=types.Position(line=0, character=0),
            end=types.Position(line=len(lines) - 1, character=len(lines[-1]) if lines else 0)
        )
        selections.append(doc_range)
        
        # Build nested selection ranges
        current = types.SelectionRange(range=selections[-1], parent=None)
        for r in reversed(selections[:-1]):
            current = types.SelectionRange(range=r, parent=current)
        
        ranges.append(current)
    
    return ranges


if __name__ == "__main__":
    start_server()