"""
HTMLXIFY Language Server
A Language Server Protocol (LSP) implementation for HTMLXIFY.

This language server provides:
- Real-time syntax validation and error reporting
- Code completion for HTML tags, attributes, and special attributes
- Hover information for tags and attributes
- Go-to-definition support
- Document symbols
- Semantic highlighting

Works with any IDE that supports LSP:
- VS Code
- Neovim
- Sublime Text
- Emacs
- JetBrains IDEs
- And more...
"""

from .server import HtmlxifyLanguageServer

__version__ = "1.0.0"
__all__ = ["HtmlxifyLanguageServer"]
