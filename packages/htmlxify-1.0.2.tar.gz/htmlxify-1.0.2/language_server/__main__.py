#!/usr/bin/env python3
"""
HTMLXIFY Language Server - Entry Point

Run with: python -m language_server
Or after installation: htmlxify-lsp
"""

from .server import start_server

if __name__ == "__main__":
    start_server()
