# AI Tools - Image & Video Generation

A comprehensive desktop application for AI-powered image and video generation with batch processing capabilities. Built with PyQt6, Peewee ORM, and managed with uv.

## Features

- **Image Generation**: Generate images using Google Nano Banana API
- **Video Generation**: Create videos using OpenAI Sora2 API with text and optional image inputs
- **Batch Processing**: Process multiple prompts simultaneously
- **Task Management**: Track progress and manage generation tasks
- **Database Storage**: SQLite database for persistent task history
- **User-Friendly Interface**: Modern PyQt6-based GUI

## Requirements

- Python 3.8+
- uv (Python package manager)
- API Keys for Google Nano Banana and OpenAI Sora2

## Installation

### 1. Install uv (if not already installed)

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 2. Clone and Setup Project

```bash
git clone <repository-url>
cd ai-tools
```

### 3. Install Dependencies

```bash
uv pip install -e .
```

### 4. Configure API Keys

Copy the example environment file and add your API keys:

```bash
cp .env.example .env
```

Edit `.env` file with your API keys:

```env
# Google API Key for Nano Banana image generation
GOOGLE_API_KEY=your_google_api_key_here

# OpenAI API Key for Sora2 video generation
OPENAI_API_KEY=your_openai_api_key_here

# Optional: API Endpoints (defaults will be used if not set)
GOOGLE_NANO_BANANA_ENDPOINT=https://api.google.com/nano-banana/v1/generate
OPENAI_SORA2_ENDPOINT=https://api.openai.com/v1/video/generations

# Batch processing settings
MAX_BATCH_SIZE=10
MAX_CONCURRENT_TASKS=3
```

## Usage

### Run the Application

```bash
uv run ai-tools
```

Or directly:

```bash
python -m ai_tools.main
```

### Image Generation

1. Navigate to the "Image Generation" tab
2. Enter your prompt in the text area
3. For batch processing:
   - Check "Enable Batch Processing"
   - Enter multiple prompts (one per line)
   - Or load prompts from a text file
4. Click "Generate Image(s)"
5. Monitor progress and view results

### Video Generation

1. Navigate to the "Video Generation" tab
2. Enter your text prompt
3. Optionally select an input image for image-to-video generation
4. Configure video settings (duration, FPS, resolution)
5. For batch processing:
   - Check "Enable Batch Processing"
   - Enter multiple prompts
6. Click "Generate Video(s)"

### Batch Management

1. Navigate to the "Batch Manager" tab
2. View all batch jobs and their status
3. Cancel or delete batches as needed
4. View individual tasks within each batch

### Task History

1. Navigate to the "Task History" tab
2. Filter tasks by type, status, or date range
3. View output files
4. Retry failed or cancelled tasks
5. Delete unwanted tasks

## Project Structure

```
ai-tools/
├── src/
│   └── ai_tools/
│       ├── __init__.py
│       ├── main.py              # Application entry point
│       ├── config.py            # Configuration management
│       ├── database.py          # Database models and operations
│       ├── ui/                  # User interface components
│       │   ├── main_window.py   # Main application window
│       │   ├── image_generation_tab.py
│       │   ├── video_generation_tab.py
│       │   ├── batch_manager_tab.py
│       │   ├── task_history_tab.py
│       │   └── workers.py       # Background worker threads
│       └── generators/          # AI generation modules
│           ├── image_generator.py
│           └── video_generator.py
├── pyproject.toml               # Project configuration
├── .env.example                 # Environment variables template
└── README.md
```

## API Integration

### Google Nano Banana API

Used for image generation. Requires a valid Google API key.

**Features:**
- Text-to-image generation
- Configurable image dimensions
- Batch processing support

### OpenAI Sora2 API

Used for video generation. Requires a valid OpenAI API key.

**Features:**
- Text-to-video generation
- Image-to-video generation (with optional input image)
- Configurable duration, FPS, and resolution
- Batch processing support

## Database Schema

The application uses SQLite with the following main tables:

- **tasks**: Individual generation tasks
- **batches**: Groups of related tasks
- **batch_tasks**: Junction table for batch-task relationships

## Configuration

Configuration is managed through environment variables and the `config.py` module:

- API keys and endpoints
- Batch processing limits
- Output directory settings
- UI preferences

## Error Handling

The application includes comprehensive error handling:

- API connection failures
- Invalid API keys
- File system errors
- Database operations
- Network timeouts

## Troubleshooting

### Common Issues

1. **Missing API Keys**: Ensure your `.env` file contains valid API keys
2. **Database Errors**: Check write permissions in the output directory
3. **Network Issues**: Verify internet connectivity and API endpoint availability
4. **Memory Issues**: Reduce batch size for large processing jobs

### Logs and Debugging

The application logs detailed information about:
- API requests and responses
- Database operations
- File system operations
- Error conditions

Check the console output for detailed error messages.

## Development

### Adding New Features

1. Update the database schema if needed
2. Add new UI components in the `ui/` directory
3. Implement generation logic in the `generators/` directory
4. Update configuration in `config.py`
5. Add appropriate error handling

### Testing

```bash
# Run the application
uv run ai-tools

# Test image generation
# Test video generation
# Test batch processing
# Verify database operations
```

## License

MIT License - see LICENSE file for details.

## Support

For issues and feature requests, please use the GitHub issue tracker.