import sys
import os
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QGuiApplication
from ai_tools.ui.main_window import MainWindow
from ai_tools.config import Config

def main():
    """Main application entry point."""
    if hasattr(Qt, "HighDpiScaleFactorRoundingPolicy"):
        QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )
    app = QApplication(sys.argv)
    app.setApplicationName("嗖嘎AI视频生成器")
    app.setApplicationVersion("0.1.0")
    
    # High DPI handling: Qt6 enables high DPI by default; guard Qt5-only attributes
    if hasattr(Qt.ApplicationAttribute, "AA_EnableHighDpiScaling"):
        app.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling, True)
    if hasattr(Qt.ApplicationAttribute, "AA_UseHighDpiPixmaps"):
        app.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps, True)
    
    # Initialize configuration
    config = Config()
    
    # Create and show main window
    window = MainWindow(config)
    window.show()
    
    return app.exec()

if __name__ == "__main__":
    sys.exit(main())
