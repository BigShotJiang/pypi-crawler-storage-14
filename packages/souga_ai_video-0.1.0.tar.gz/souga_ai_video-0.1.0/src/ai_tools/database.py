import json
from datetime import datetime
from pathlib import Path
from peewee import *
from playhouse.sqlite_ext import JSONField

# Global database instance
db = SqliteDatabase(None)

class BaseModel(Model):
    """Base model for all database tables."""
    class Meta:
        database = db

class Task(BaseModel):
    """Task model for tracking generation tasks."""
    id = AutoField()
    task_type = CharField()  # 'image' or 'video'
    status = CharField(default='pending')  # pending, running, completed, failed
    prompt = TextField()
    input_image_path = TextField(null=True)  # For video generation with image input
    output_path = TextField(null=True)
    error_message = TextField(null=True)
    created_at = DateTimeField(default=datetime.now)
    started_at = DateTimeField(null=True)
    completed_at = DateTimeField(null=True)
    api_provider = CharField()  # 'google' or 'openai'
    api_response = JSONField(null=True)
    remote_task_id = TextField(null=True)
    
    class Meta:
        table_name = 'tasks'

class Batch(BaseModel):
    """Batch model for grouping multiple tasks."""
    id = AutoField()
    name = CharField()
    task_type = CharField()  # 'image' or 'video'
    status = CharField(default='pending')  # pending, running, completed, failed
    total_tasks = IntegerField(default=0)
    completed_tasks = IntegerField(default=0)
    failed_tasks = IntegerField(default=0)
    created_at = DateTimeField(default=datetime.now)
    completed_at = DateTimeField(null=True)
    
    class Meta:
        table_name = 'batches'

class BatchTask(BaseModel):
    """Junction table for batch-task relationship."""
    batch = ForeignKeyField(Batch, backref='tasks')
    task = ForeignKeyField(Task, backref='batches')
    
    class Meta:
        table_name = 'batch_tasks'
        primary_key = CompositeKey('batch', 'task')

def init_database(db_path: Path):
    """Initialize database with given path."""
    db.init(str(db_path))
    db.create_tables([Task, Batch, BatchTask], safe=True)
    try:
        cols = db.execute_sql("PRAGMA table_info(tasks);").fetchall()
        names = [c[1] for c in cols]
        if 'remote_task_id' not in names:
            db.execute_sql("ALTER TABLE tasks ADD COLUMN remote_task_id TEXT;")
    except Exception:
        pass
    return db

def get_database_stats():
    """Get database statistics."""
    stats = {
        'total_tasks': Task.select().count(),
        'pending_tasks': Task.select().where(Task.status == 'pending').count(),
        'running_tasks': Task.select().where(Task.status == 'running').count(),
        'completed_tasks': Task.select().where(Task.status == 'completed').count(),
        'failed_tasks': Task.select().where(Task.status == 'failed').count(),
        'total_batches': Batch.select().count(),
    }
    return stats
