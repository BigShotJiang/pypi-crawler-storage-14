from PyQt6.QtCore import QThread, pyqtSignal
from datetime import datetime

from ai_tools.database import Task

class VideoGenerationWorker(QThread):
    """Worker thread for video generation."""
    
    progress_updated = pyqtSignal(int, int)  # completed, total
    finished = pyqtSignal(int, int)  # success_count, total_count
    
    def __init__(self, generator, prompts, task_ids, input_images=None, aspect_ratio='9:16', duration=15):
        super().__init__()
        self.generator = generator
        self.prompts = prompts
        self.task_ids = task_ids
        self.input_images = input_images or [None] * len(prompts)
        self.aspect_ratio = aspect_ratio
        self.duration = duration
        self.success_count = 0
        
    def run(self):
        """Run the video generation process."""
        total = len(self.prompts)
        completed = 0
        
        for i, (prompt, task_id, input_image) in enumerate(zip(self.prompts, self.task_ids, self.input_images)):
            try:
                # Update task status
                task = Task.get_by_id(task_id)
                task.status = 'running'
                task.started_at = datetime.now()
                task.save()
                
                # Generate video
                output_path = self.generator.generate_video(prompt, task_id, input_image, self.aspect_ratio, self.duration)
                
                if output_path:
                    # Update task as completed
                    task.status = 'completed'
                    task.output_path = output_path
                    task.completed_at = datetime.now()
                    task.save()
                    try:
                        self.generator.config.logger.info(f"Video task {task_id} completed: {output_path}")
                    except Exception:
                        pass
                else:
                    # Update task as failed
                    task.status = 'failed'
                    task.error_message = 'Generation failed'
                    task.completed_at = datetime.now()
                    task.save()
                    try:
                        self.generator.config.logger.error(f"Video task {task_id} failed")
                    except Exception:
                        pass
                    
            except Exception as e:
                # Update task as failed
                try:
                    task = Task.get_by_id(task_id)
                    task.status = 'failed'
                    task.error_message = str(e)
                    task.completed_at = datetime.now()
                    task.save()
                    try:
                        self.generator.config.logger.error(f"Video task {task_id} exception: {e}")
                    except Exception:
                        pass
                except:
                    pass
                    
            completed += 1
            self.progress_updated.emit(completed, total)
            
        self.finished.emit(self.success_count, total)

class VideoResumeWorker(QThread):
    """Worker to force-resume failed video tasks via remote_task_id."""
    progress_updated = pyqtSignal(int, int)
    finished = pyqtSignal(int, int)

    def __init__(self, generator, task_ids):
        super().__init__()
        self.generator = generator
        self.task_ids = task_ids
        self.success_count = 0

    def run(self):
        total = len(self.task_ids)
        completed = 0
        from ai_tools.database import Task
        from datetime import datetime
        for task_id in self.task_ids:
            try:
                task = Task.get_by_id(task_id)
                # Only handle video failed tasks
                if task.task_type != 'video':
                    completed += 1
                    self.progress_updated.emit(completed, total)
                    continue
                # Mark running before resume
                task.status = 'running'
                task.started_at = task.started_at or datetime.now()
                task.save()
                out = self.generator.resume_video_task(task)
                if out:
                    task.status = 'completed'
                    task.output_path = out
                    task.completed_at = datetime.now()
                    task.save()
                    self.success_count += 1
                    try:
                        self.generator.config.logger.info(f"Force resume: task {task_id} completed")
                    except Exception:
                        pass
                else:
                    task.status = 'failed'
                    task.error_message = (task.error_message or '') + ' | force resume failed'
                    task.completed_at = datetime.now()
                    task.save()
                    try:
                        self.generator.config.logger.error(f"Force resume: task {task_id} failed")
                    except Exception:
                        pass
            except Exception as e:
                try:
                    t = Task.get_by_id(task_id)
                    t.status = 'failed'
                    t.error_message = (t.error_message or '') + f' | force resume exception: {e}'
                    t.completed_at = datetime.now()
                    t.save()
                except Exception:
                    pass
            completed += 1
            self.progress_updated.emit(completed, total)
        self.finished.emit(self.success_count, total)
