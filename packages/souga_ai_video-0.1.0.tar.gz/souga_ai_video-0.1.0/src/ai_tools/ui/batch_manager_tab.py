from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                              QLabel, QGroupBox, QTableWidget, QTableWidgetItem, 
                              QHeaderView, QMessageBox, QProgressBar)
from PyQt6.QtCore import Qt, QTimer

from ai_tools.config import Config
from ai_tools.database import Batch, Task, BatchTask, get_database_stats

class BatchManagerTab(QWidget):
    """Tab for managing batch processing tasks."""
    
    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface."""
        layout = QVBoxLayout(self)
        
        # Batch overview section
        overview_group = QGroupBox("Batch Overview")
        overview_layout = QVBoxLayout(overview_group)
        
        # Statistics
        stats_layout = QHBoxLayout()
        
        self.total_batches_label = QLabel("Total Batches: 0")
        self.pending_batches_label = QLabel("Pending: 0")
        self.running_batches_label = QLabel("Running: 0")
        self.completed_batches_label = QLabel("Completed: 0")
        self.failed_batches_label = QLabel("Failed: 0")
        
        stats_layout.addWidget(self.total_batches_label)
        stats_layout.addWidget(self.pending_batches_label)
        stats_layout.addWidget(self.running_batches_label)
        stats_layout.addWidget(self.completed_batches_label)
        stats_layout.addWidget(self.failed_batches_label)
        stats_layout.addStretch()
        
        overview_layout.addLayout(stats_layout)
        
        layout.addWidget(overview_group)
        
        # Batch list section
        batch_list_group = QGroupBox("Batch List")
        batch_list_layout = QVBoxLayout(batch_list_group)
        
        # Batch table
        self.batch_table = QTableWidget()
        self.batch_table.setColumnCount(7)
        self.batch_table.setHorizontalHeaderLabels([
            "ID", "Name", "Type", "Status", "Total Tasks", "Completed", "Created"
        ])
        self.batch_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.batch_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        batch_list_layout.addWidget(self.batch_table)
        
        # Batch control buttons
        batch_button_layout = QHBoxLayout()
        
        self.refresh_batches_btn = QPushButton("Refresh")
        self.refresh_batches_btn.clicked.connect(self.refresh_batches)
        batch_button_layout.addWidget(self.refresh_batches_btn)
        
        self.view_tasks_btn = QPushButton("View Tasks")
        self.view_tasks_btn.clicked.connect(self.view_selected_batch_tasks)
        batch_button_layout.addWidget(self.view_tasks_btn)
        
        self.cancel_batch_btn = QPushButton("Cancel Batch")
        self.cancel_batch_btn.clicked.connect(self.cancel_selected_batch)
        batch_button_layout.addWidget(self.cancel_batch_btn)
        
        self.delete_batch_btn = QPushButton("Delete Batch")
        self.delete_batch_btn.clicked.connect(self.delete_selected_batch)
        batch_button_layout.addWidget(self.delete_batch_btn)
        
        batch_button_layout.addStretch()
        batch_list_layout.addLayout(batch_button_layout)
        
        layout.addWidget(batch_list_group)
        
        # Selected batch tasks section
        tasks_group = QGroupBox("Selected Batch Tasks")
        tasks_layout = QVBoxLayout(tasks_group)
        
        self.tasks_table = QTableWidget()
        self.tasks_table.setColumnCount(6)
        self.tasks_table.setHorizontalHeaderLabels([
            "ID", "Status", "Prompt", "Created", "Completed", "Output"
        ])
        self.tasks_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.tasks_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        tasks_layout.addWidget(self.tasks_table)
        
        layout.addWidget(tasks_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Status label
        self.status_label = QLabel("Ready")
        layout.addWidget(self.status_label)
        
        # Setup refresh timer
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.refresh_batches)
        self.refresh_timer.start(10000)  # Update every 10 seconds
        
        # Initial refresh
        self.refresh_batches()
        
    def refresh_batches(self):
        """Refresh the batch list and statistics."""
        try:
            # Get batch statistics
            batches = Batch.select()
            
            total = batches.count()
            pending = batches.where(Batch.status == 'pending').count()
            running = batches.where(Batch.status == 'running').count()
            completed = batches.where(Batch.status == 'completed').count()
            failed = batches.where(Batch.status == 'failed').count()
            
            # Update statistics labels
            self.total_batches_label.setText(f"Total Batches: {total}")
            self.pending_batches_label.setText(f"Pending: {pending}")
            self.running_batches_label.setText(f"Running: {running}")
            self.completed_batches_label.setText(f"Completed: {completed}")
            self.failed_batches_label.setText(f"Failed: {failed}")
            
            # Update batch table
            self.batch_table.setRowCount(total)
            for row, batch in enumerate(batches.order_by(Batch.created_at.desc())):
                self.batch_table.setItem(row, 0, QTableWidgetItem(str(batch.id)))
                self.batch_table.setItem(row, 1, QTableWidgetItem(batch.name))
                self.batch_table.setItem(row, 2, QTableWidgetItem(batch.task_type))
                self.batch_table.setItem(row, 3, QTableWidgetItem(batch.status))
                self.batch_table.setItem(row, 4, QTableWidgetItem(str(batch.total_tasks)))
                self.batch_table.setItem(row, 5, QTableWidgetItem(str(batch.completed_tasks)))
                self.batch_table.setItem(row, 6, QTableWidgetItem(batch.created_at.strftime('%Y-%m-%d %H:%M')))
                
                # Color code by status
                if batch.status == 'completed':
                    self.batch_table.item(row, 3).setBackground(Qt.GlobalColor.green)
                elif batch.status == 'failed':
                    self.batch_table.item(row, 3).setBackground(Qt.GlobalColor.red)
                elif batch.status == 'running':
                    self.batch_table.item(row, 3).setBackground(Qt.GlobalColor.yellow)
                    
            self.status_label.setText("Batch list refreshed")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to refresh batches: {str(e)}")
            self.status_label.setText("Error refreshing batches")
            
    def view_selected_batch_tasks(self):
        """View tasks in the selected batch."""
        current_row = self.batch_table.currentRow()
        if current_row >= 0:
            batch_id = int(self.batch_table.item(current_row, 0).text())
            self.show_batch_tasks(batch_id)
        else:
            QMessageBox.warning(self, "Warning", "Please select a batch first")
            
    def show_batch_tasks(self, batch_id: int):
        """Show tasks for a specific batch."""
        try:
            # Get batch tasks
            batch = Batch.get_by_id(batch_id)
            tasks = (Task
                    .select()
                    .join(BatchTask)
                    .where(BatchTask.batch == batch)
                    .order_by(Task.created_at))
            
            self.tasks_table.setRowCount(len(tasks))
            for row, task in enumerate(tasks):
                self.tasks_table.setItem(row, 0, QTableWidgetItem(str(task.id)))
                self.tasks_table.setItem(row, 1, QTableWidgetItem(task.status))
                self.tasks_table.setItem(row, 2, QTableWidgetItem(task.prompt[:100] + "..." if len(task.prompt) > 100 else task.prompt))
                self.tasks_table.setItem(row, 3, QTableWidgetItem(task.created_at.strftime('%Y-%m-%d %H:%M')))
                self.tasks_table.setItem(row, 4, QTableWidgetItem(
                    task.completed_at.strftime('%Y-%m-%d %H:%M') if task.completed_at else ""
                ))
                self.tasks_table.setItem(row, 5, QTableWidgetItem(task.output_path or ""))
                
                # Color code by status
                if task.status == 'completed':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.green)
                elif task.status == 'failed':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.red)
                elif task.status == 'running':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.yellow)
                    
            self.status_label.setText(f"Showing tasks for batch: {batch.name}")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load batch tasks: {str(e)}")
            
    def cancel_selected_batch(self):
        """Cancel the selected batch."""
        current_row = self.batch_table.currentRow()
        if current_row >= 0:
            batch_id = int(self.batch_table.item(current_row, 0).text())
            try:
                batch = Batch.get_by_id(batch_id)
                if batch.status in ['pending', 'running']:
                    # Update batch status
                    batch.status = 'cancelled'
                    batch.save()
                    
                    # Cancel pending tasks
                    (Task
                     .update(status='cancelled')
                     .where((Task.id.in_(
                         BatchTask.select(BatchTask.task)
                         .where(BatchTask.batch == batch)
                     )) & (Task.status == 'pending'))
                     .execute())
                    
                    QMessageBox.information(self, "Success", "Batch cancelled successfully")
                    self.refresh_batches()
                else:
                    QMessageBox.warning(self, "Warning", "Cannot cancel completed or failed batch")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to cancel batch: {str(e)}")
        else:
            QMessageBox.warning(self, "Warning", "Please select a batch first")
            
    def delete_selected_batch(self):
        """Delete the selected batch."""
        current_row = self.batch_table.currentRow()
        if current_row >= 0:
            batch_id = int(self.batch_table.item(current_row, 0).text())
            reply = QMessageBox.question(
                self, "Confirm Delete", 
                "Are you sure you want to delete this batch? This will also delete all associated tasks.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if reply == QMessageBox.StandardButton.Yes:
                try:
                    batch = Batch.get_by_id(batch_id)
                    
                    # Delete associated tasks and batch tasks
                    (Task
                     .delete()
                     .where(Task.id.in_(
                         BatchTask.select(BatchTask.task)
                         .where(BatchTask.batch == batch)
                     ))
                     .execute())
                     
                    (BatchTask
                     .delete()
                     .where(BatchTask.batch == batch)
                     .execute())
                     
                    # Delete batch
                    batch.delete_instance()
                    
                    QMessageBox.information(self, "Success", "Batch deleted successfully")
                    self.refresh_batches()
                    self.tasks_table.setRowCount(0)  # Clear tasks table
                    
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to delete batch: {str(e)}")
        else:
            QMessageBox.warning(self, "Warning", "Please select a batch first")