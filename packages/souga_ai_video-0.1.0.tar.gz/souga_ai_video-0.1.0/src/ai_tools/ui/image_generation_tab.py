from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                              QTextEdit, QLabel, QGroupBox, QSpinBox, QCheckBox,
                              QFileDialog, QTableWidget, QTableWidgetItem, QHeaderView,
                              QProgressBar, QMessageBox)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QPixmap, QImage

import os
from pathlib import Path
from datetime import datetime

from ai_tools.config import Config
from ai_tools.database import Task, Batch, BatchTask, get_database_stats
from ai_tools.generators.image_generator import ImageGenerator
from ai_tools.ui.workers import ImageGenerationWorker

class ImageGenerationTab(QWidget):
    """Tab for image generation functionality."""
    
    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        self.generator = ImageGenerator(config)
        self.current_batch = None
        self.is_generating = False
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface."""
        layout = QVBoxLayout(self)
        
        # Input section
        input_group = QGroupBox("Image Generation Input")
        input_layout = QVBoxLayout(input_group)
        
        # Prompt input
        prompt_label = QLabel("Prompt:")
        self.prompt_input = QTextEdit()
        self.prompt_input.setMaximumHeight(100)
        self.prompt_input.setPlaceholderText("Enter your image generation prompt here...")
        self.prompt_input.textChanged.connect(self.on_prompt_changed)
        input_layout.addWidget(prompt_label)
        input_layout.addWidget(self.prompt_input)
        
        # Batch settings
        batch_layout = QHBoxLayout()
        
        self.batch_checkbox = QCheckBox("Enable Batch Processing")
        self.batch_checkbox.stateChanged.connect(self.toggle_batch_mode)
        batch_layout.addWidget(self.batch_checkbox)
        
        batch_size_label = QLabel("Batch Size:")
        self.batch_size_spinbox = QSpinBox()
        self.batch_size_spinbox.setRange(1, self.config.max_batch_size)
        self.batch_size_spinbox.setValue(1)
        self.batch_size_spinbox.setEnabled(False)
        batch_layout.addWidget(batch_size_label)
        batch_layout.addWidget(self.batch_size_spinbox)
        
        batch_layout.addStretch()
        input_layout.addLayout(batch_layout)
        
        # Control buttons
        button_layout = QHBoxLayout()
        
        self.generate_btn = QPushButton("Generate Image(s)")
        self.generate_btn.clicked.connect(self.generate_images)
        button_layout.addWidget(self.generate_btn)
        
        self.load_prompts_btn = QPushButton("Load Prompts from File")
        self.load_prompts_btn.clicked.connect(self.load_prompts_from_file)
        self.load_prompts_btn.setEnabled(False)
        button_layout.addWidget(self.load_prompts_btn)
        
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.clicked.connect(self.clear_inputs)
        button_layout.addWidget(self.clear_btn)
        
        button_layout.addStretch()
        input_layout.addLayout(button_layout)
        
        layout.addWidget(input_group)
        
        # Progress section
        progress_group = QGroupBox("Progress")
        progress_layout = QVBoxLayout(progress_group)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        progress_layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("Ready")
        progress_layout.addWidget(self.status_label)
        
        layout.addWidget(progress_group)
        
        # Results section
        results_group = QGroupBox("Recent Tasks")
        results_layout = QVBoxLayout(results_group)
        
        self.tasks_table = QTableWidget()
        self.tasks_table.setColumnCount(6)
        self.tasks_table.setHorizontalHeaderLabels([
            "ID", "Status", "Prompt", "Created", "Completed", "Output"
        ])
        self.tasks_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.tasks_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.tasks_table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        results_layout.addWidget(self.tasks_table)
        
        # Results buttons
        results_button_layout = QHBoxLayout()
        
        self.refresh_tasks_btn = QPushButton("Refresh")
        self.refresh_tasks_btn.clicked.connect(self.refresh_tasks)
        results_button_layout.addWidget(self.refresh_tasks_btn)
        
        self.view_output_btn = QPushButton("View Output")
        self.view_output_btn.clicked.connect(self.view_selected_output)
        results_button_layout.addWidget(self.view_output_btn)
        
        self.open_folder_btn = QPushButton("Open Output Folder")
        self.open_folder_btn.clicked.connect(self.open_output_folder)
        results_button_layout.addWidget(self.open_folder_btn)

        self.select_all_btn = QPushButton("全选")
        self.select_all_btn.clicked.connect(self.select_all_tasks)
        results_button_layout.addWidget(self.select_all_btn)

        self.delete_task_btn = QPushButton("批量删除")
        self.delete_task_btn.clicked.connect(self.delete_selected_task)
        results_button_layout.addWidget(self.delete_task_btn)
        
        results_button_layout.addStretch()
        results_layout.addLayout(results_button_layout)
        
        layout.addWidget(results_group)
        
        # Initial refresh
        self.refresh_tasks()
        
    def toggle_batch_mode(self, state):
        """Toggle batch processing mode."""
        is_batch = state == Qt.CheckState.Checked.value
        self.batch_size_spinbox.setEnabled(is_batch)
        self.load_prompts_btn.setEnabled(is_batch)
        self.generate_btn.setText("Generate Images" if is_batch else "Generate Image")
        
    def load_prompts_from_file(self):
        """Load multiple prompts from a text file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Prompts", "", "Text Files (*.txt)"
        )
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    prompts = [line.strip() for line in f if line.strip()]
                
                if prompts:
                    self.prompt_input.clear()
                    self.prompt_input.setPlainText("\n".join(prompts))
                    self.batch_size_spinbox.setValue(min(len(prompts), self.config.max_batch_size))
                    QMessageBox.information(self, "Success", f"Loaded {len(prompts)} prompts")
                else:
                    QMessageBox.warning(self, "Warning", "No valid prompts found in file")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load prompts: {str(e)}")
                
    def generate_images(self):
        """Generate images based on current input."""
        if not (self.config.google_api_key or self.config.duomi_api_key):
            QMessageBox.warning(self, "Missing API Key", "需要配置 Google 或 Duomi 的 API Key 才能生成图片")
            return
            
        prompt_text = self.prompt_input.toPlainText().strip()
        if not prompt_text:
            QMessageBox.warning(self, "Missing Input", "Please enter a prompt")
            return
            
        if self.batch_checkbox.isChecked():
            # Batch processing
            prompts = [p.strip() for p in prompt_text.split('\n') if p.strip()]
            if not prompts:
                QMessageBox.warning(self, "Missing Input", "Please enter at least one prompt")
                return
                
            batch_size = min(self.batch_size_spinbox.value(), len(prompts), self.config.max_batch_size)
            prompts = prompts[:batch_size]
            
            self.start_batch_generation(prompts)
        else:
            # Single image generation
            self.start_single_generation(prompt_text)
            
    def start_single_generation(self, prompt: str):
        """Start single image generation."""
        try:
            # Prevent duplicate pending/running tasks for same prompt/provider
            exists = (Task
                      .select()
                      .where(
                          (Task.task_type == 'image') &
                          (Task.api_provider == 'google') &
                          (Task.prompt == prompt) &
                          (Task.status.in_(['pending', 'running']))
                      )
                      .exists())
            if exists:
                QMessageBox.information(self, "Duplicate Task", "已存在相同的未完成任务，已避免重复创建。")
                return
            # Create task in database
            task = Task.create(
                task_type='image',
                status='pending',
                prompt=prompt,
                api_provider='google'
            )
            
            # Start generation worker
            self.generation_worker = ImageGenerationWorker(self.generator, [prompt], [task.id])
            self.generation_worker.progress_updated.connect(self.update_progress)
            self.generation_worker.finished.connect(self.generation_finished)
            self.generation_worker.start()
            
            self.generate_btn.setEnabled(False)
            self.is_generating = True
            self.progress_bar.setVisible(True)
            self.status_label.setText("Generating image...")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start generation: {str(e)}")
            self.generate_btn.setEnabled(True)
            self.is_generating = False
            
    def start_batch_generation(self, prompts: list):
        """Start batch image generation."""
        try:
            # Create batch
            batch = Batch.create(
                name=f"Image Batch {datetime.now().strftime('%Y%m%d_%H%M%S')}",
                task_type='image',
                status='pending',
                total_tasks=len(prompts)
            )
            
            # Create tasks
            tasks = []
            for prompt in prompts:
                task = Task.create(
                    task_type='image',
                    status='pending',
                    prompt=prompt,
                    api_provider='google'
                )
                BatchTask.create(batch=batch, task=task)
                tasks.append(task)
            
            # Start generation worker
            self.generation_worker = ImageGenerationWorker(
                self.generator, prompts, [t.id for t in tasks]
            )
            self.generation_worker.progress_updated.connect(self.update_progress)
            self.generation_worker.finished.connect(self.generation_finished)
            self.generation_worker.start()
            
            self.generate_btn.setEnabled(False)
            self.is_generating = True
            self.progress_bar.setVisible(True)
            self.progress_bar.setMaximum(len(prompts))
            self.status_label.setText(f"Generating {len(prompts)} images...")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start batch generation: {str(e)}")
            self.generate_btn.setEnabled(True)
            self.is_generating = False
            
    def update_progress(self, completed: int, total: int):
        """Update progress bar."""
        self.progress_bar.setValue(completed)
        self.status_label.setText(f"Generated {completed} of {total} images...")
        
    def generation_finished(self, success_count: int, total_count: int):
        """Handle generation completion."""
        self.generate_btn.setEnabled(True)
        self.is_generating = False
        self.progress_bar.setVisible(False)
        
        if success_count == total_count:
            self.status_label.setText(f"Successfully generated {success_count} images")
        else:
            self.status_label.setText(f"Generated {success_count} of {total_count} images (some failed)")
            
        self.refresh_tasks()
        
    def clear_inputs(self):
        """Clear all input fields."""
        self.prompt_input.clear()
        self.batch_checkbox.setChecked(False)
        self.batch_size_spinbox.setValue(1)

    def on_prompt_changed(self):
        if not self.is_generating:
            self.generate_btn.setEnabled(True)
        
    def refresh_tasks(self):
        """Refresh the tasks table."""
        try:
            # Get recent image tasks
            tasks = Task.select().where(Task.task_type == 'image').order_by(Task.created_at.desc()).limit(50)
            
            self.tasks_table.setRowCount(len(tasks))
            for row, task in enumerate(tasks):
                self.tasks_table.setItem(row, 0, QTableWidgetItem(str(task.id)))
                self.tasks_table.setItem(row, 1, QTableWidgetItem(task.status))
                self.tasks_table.setItem(row, 2, QTableWidgetItem(task.prompt[:100] + "..." if len(task.prompt) > 100 else task.prompt))
                self.tasks_table.setItem(row, 3, QTableWidgetItem(task.created_at.strftime('%Y-%m-%d %H:%M')))
                self.tasks_table.setItem(row, 4, QTableWidgetItem(
                    task.completed_at.strftime('%Y-%m-%d %H:%M') if task.completed_at else ""
                ))
                self.tasks_table.setItem(row, 5, QTableWidgetItem(task.output_path or ""))
                
                # Color code by status
                if task.status == 'completed':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.green)
                elif task.status == 'failed':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.red)
                elif task.status == 'running':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.yellow)
                    
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to refresh tasks: {str(e)}")
            
    def view_selected_output(self):
        """View output of selected task."""
        current_row = self.tasks_table.currentRow()
        if current_row >= 0:
            task_id = self.tasks_table.item(current_row, 0).text()
            output_path = self.tasks_table.item(current_row, 5).text()
            
            if output_path and os.path.exists(output_path):
                # TODO: Implement image viewer
                QMessageBox.information(self, "View Output", f"Output file: {output_path}")
            else:
                QMessageBox.warning(self, "Warning", "No output file available for this task")
        else:
            QMessageBox.warning(self, "Warning", "请选择任务")

    def delete_selected_task(self):
        """Batch delete selected tasks."""
        rows = sorted({idx.row() for idx in self.tasks_table.selectedIndexes()})
        if not rows:
            QMessageBox.warning(self, "Warning", "请选择任务")
            return
        try:
            ids = []
            for r in rows:
                item = self.tasks_table.item(r, 0)
                if item:
                    ids.append(int(item.text()))
            if not ids:
                QMessageBox.warning(self, "Warning", "未获取到任务ID")
                return
            # 单次确认，更简单
            reply = QMessageBox.question(
                self, "批量删除", f"确定删除选中的 {len(ids)} 个任务？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
            # 使用逐条删除以保持与单删一致行为
            for tid in ids:
                Task.delete_by_id(tid)
            QMessageBox.information(self, "成功", f"已删除 {len(ids)} 个任务")
            self.refresh_tasks()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"批量删除失败: {str(e)}")

    def select_all_tasks(self):
        """Select all tasks in the table."""
        self.tasks_table.selectAll()
                
    def open_output_folder(self):
        """Open the output folder."""
        try:
            os.startfile(str(self.config.output_dir))
        except AttributeError:
            # For non-Windows systems
            import subprocess
            subprocess.run(['open', str(self.config.output_dir)])
