from PyQt6.QtWidgets import (QMainWindow, QTabWidget, QVBoxLayout, QHBoxLayout, 
                             QWidget, QPushButton, QLabel, QStatusBar, QMessageBox,
                             QDialog, QFormLayout, QLineEdit, QDialogButtonBox, QGroupBox)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QIcon

from ai_tools.config import Config
from ai_tools.database import init_database, get_database_stats
from ai_tools.ui.image_generation_tab import ImageGenerationTab
from ai_tools.ui.video_generation_tab import VideoGenerationTab
from ai_tools.ui.batch_manager_tab import BatchManagerTab
from ai_tools.ui.task_history_tab import TaskHistoryTab
from ai_tools.ui.workers import RecoveryWorker

class MainWindow(QMainWindow):
    """Main application window."""
    
    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        self.db = None
        self.init_database()
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle(self.config.window_title)
        self.setGeometry(100, 100, *self.config.window_size)
        
        # Create central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Create tab widget
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)
        
        # Create tabs
        self.image_tab = ImageGenerationTab(self.config)
        self.video_tab = VideoGenerationTab(self.config)
        self.batch_tab = BatchManagerTab(self.config)
        self.history_tab = TaskHistoryTab(self.config)
        
        # Add tabs
        self.tabs.addTab(self.image_tab, "Image Generation")
        self.tabs.addTab(self.video_tab, "Video Generation")
        self.tabs.addTab(self.batch_tab, "Batch Manager")
        self.tabs.addTab(self.history_tab, "Task History")
        
        # Create status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Create control panel
        control_panel = QWidget()
        control_layout = QHBoxLayout(control_panel)
        
        # Add control buttons
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh_data)
        control_layout.addWidget(self.refresh_btn)
        
        self.settings_btn = QPushButton("Settings")
        self.settings_btn.clicked.connect(self.show_settings)
        control_layout.addWidget(self.settings_btn)
        
        control_layout.addStretch()
        
        # Add status label
        self.status_label = QLabel("Ready")
        control_layout.addWidget(self.status_label)
        
        main_layout.addWidget(control_panel)
        
        # Setup refresh timer
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.update_status)
        self.refresh_timer.start(5000)  # Update every 5 seconds
        
        # Validate API keys
        self.validate_api_keys()
        
    def init_database(self):
        """Initialize database connection."""
        try:
            self.db = init_database(self.config.db_path)
            if hasattr(self, "status_label"):
                self.update_status()
            # Start recovery if there are running tasks
            try:
                self.recovery_worker = RecoveryWorker(self.config)
                self.recovery_worker.start()
            except Exception:
                pass
        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Failed to initialize database: {str(e)}")
            
    def validate_api_keys(self):
        """Validate API keys and show warnings if missing."""
        missing_keys = self.config.validate_api_keys()
        if missing_keys:
            key_list = ", ".join(missing_keys)
            QMessageBox.warning(
                self, 
                "Missing API Keys", 
                f"The following API keys are missing: {key_list}\n\n"
                "Please set them in the .env file or settings."
            )
            
    def refresh_data(self):
        """Refresh all data across tabs."""
        self.image_tab.refresh_tasks()
        self.video_tab.refresh_tasks()
        self.batch_tab.refresh_batches()
        self.history_tab.refresh_history()
        self.update_status()
        
    def update_status(self):
        """Update status bar with current statistics."""
        if self.db:
            try:
                stats = get_database_stats()
                status_text = (f"Tasks: {stats['total_tasks']} | "
                             f"Pending: {stats['pending_tasks']} | "
                             f"Running: {stats['running_tasks']} | "
                             f"Completed: {stats['completed_tasks']} | "
                             f"Failed: {stats['failed_tasks']} | "
                             f"Batches: {stats['total_batches']}")
                self.status_label.setText(status_text)
            except Exception as e:
                self.status_label.setText("Database error")
                
    def show_settings(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Settings")
        root = QVBoxLayout(dialog)
        dialog.setMinimumWidth(520)
        dialog.setStyleSheet(
            "QGroupBox{font-weight:bold;margin-top:10px;}"
            "QGroupBox::title{subcontrol-origin:margin;left:10px;padding:0 3px;}"
            "QLineEdit{padding:6px;border:1px solid #bbb;border-radius:4px;}"
            "QDialog{background:#fafafa;}"
        )

        proxy_group = QGroupBox("Duomi Proxy")
        proxy_form = QFormLayout(proxy_group)
        duomi_key = QLineEdit(self.config.duomi_api_key)
        duomi_base = QLineEdit(self.config.duomi_api_base)
        duomi_key.setEchoMode(QLineEdit.EchoMode.Password)
        proxy_form.addRow("API Key", duomi_key)
        proxy_form.addRow("API Base", duomi_base)

        providers_group = QGroupBox("Direct Providers (Optional)")
        providers_form = QFormLayout(providers_group)
        google_key = QLineEdit(self.config.google_api_key)
        openai_key = QLineEdit(self.config.openai_api_key)
        google_key.setEchoMode(QLineEdit.EchoMode.Password)
        openai_key.setEchoMode(QLineEdit.EchoMode.Password)
        providers_form.addRow("Google API Key", google_key)
        providers_form.addRow("OpenAI API Key", openai_key)

        root.addWidget(proxy_group)
        root.addWidget(providers_group)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        root.addWidget(buttons)

        def save():
            values = {
                "DUOMI_API_KEY": duomi_key.text().strip(),
                "DUOMI_API_BASE": duomi_base.text().strip() or "https://duomiapi.com",
                "GOOGLE_API_KEY": google_key.text().strip(),
                "OPENAI_API_KEY": openai_key.text().strip(),
            }
            try:
                env_path = self.config.env_file_path
                lines = []
                if env_path.exists():
                    lines = env_path.read_text(encoding="utf-8").splitlines()
                kv = {}
                for line in lines:
                    if not line or line.strip().startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    kv[k.strip()] = v
                kv.update(values)
                new_lines = [f"{k}={kv[k]}" for k in kv]
                env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
                self.config.duomi_api_key = values["DUOMI_API_KEY"]
                self.config.duomi_api_base = values["DUOMI_API_BASE"]
                self.config.google_api_key = values["GOOGLE_API_KEY"]
                self.config.openai_api_key = values["OPENAI_API_KEY"]
                self.config.use_duomi_proxy = bool(self.config.duomi_api_key)
                self.config.google_nano_banana_submit = f"{self.config.duomi_api_base}/api/gemini/nano-banana"
                self.config.google_nano_banana_status = f"{self.config.duomi_api_base}/api/gemini/nano-banana/{{task_id}}"
                self.config.openai_sora2_submit = f"{self.config.duomi_api_base}/v1/videos/generations"
                self.config.openai_sora2_status = f"{self.config.duomi_api_base}/v1/videos/tasks/{{task_id}}"
                self.validate_api_keys()
                self.update_status()
                dialog.accept()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

        buttons.accepted.connect(save)
        buttons.rejected.connect(dialog.reject)
        dialog.exec()
        
    def closeEvent(self, event):
        """Handle application close event."""
        self.refresh_timer.stop()
        if self.db:
            self.db.close()
        event.accept()
