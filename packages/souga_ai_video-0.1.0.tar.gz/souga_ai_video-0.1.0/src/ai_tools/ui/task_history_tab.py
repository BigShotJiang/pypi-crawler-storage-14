from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                              QLabel, QGroupBox, QTableWidget, QTableWidgetItem, 
                              QHeaderView, QMessageBox, QComboBox, QDateEdit, QCheckBox)
from PyQt6.QtCore import Qt, QDate, QTimer

from ai_tools.config import Config
from ai_tools.database import Task, Batch, BatchTask

class TaskHistoryTab(QWidget):
    """Tab for viewing task history."""
    
    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface."""
        layout = QVBoxLayout(self)
        
        # Filters section
        filters_group = QGroupBox("Filters")
        filters_layout = QHBoxLayout(filters_group)
        
        # Task type filter
        self.task_type_combo = QComboBox()
        self.task_type_combo.addItem("All Types", "")
        self.task_type_combo.addItem("Image Generation", "image")
        self.task_type_combo.addItem("Video Generation", "video")
        self.task_type_combo.currentTextChanged.connect(self.apply_filters)
        filters_layout.addWidget(QLabel("Task Type:"))
        filters_layout.addWidget(self.task_type_combo)
        
        # Status filter
        self.status_combo = QComboBox()
        self.status_combo.addItem("All Statuses", "")
        self.status_combo.addItem("Pending", "pending")
        self.status_combo.addItem("Running", "running")
        self.status_combo.addItem("Completed", "completed")
        self.status_combo.addItem("Failed", "failed")
        self.status_combo.addItem("Cancelled", "cancelled")
        self.status_combo.currentTextChanged.connect(self.apply_filters)
        filters_layout.addWidget(QLabel("Status:"))
        filters_layout.addWidget(self.status_combo)
        
        # Date filter
        self.date_checkbox = QCheckBox("Filter by Date")
        self.date_checkbox.stateChanged.connect(self.toggle_date_filter)
        filters_layout.addWidget(self.date_checkbox)
        
        self.start_date_edit = QDateEdit()
        self.start_date_edit.setDate(QDate.currentDate().addDays(-7))
        self.start_date_edit.setEnabled(False)
        self.start_date_edit.dateChanged.connect(self.apply_filters)
        filters_layout.addWidget(QLabel("From:"))
        filters_layout.addWidget(self.start_date_edit)
        
        self.end_date_edit = QDateEdit()
        self.end_date_edit.setDate(QDate.currentDate())
        self.end_date_edit.setEnabled(False)
        self.end_date_edit.dateChanged.connect(self.apply_filters)
        filters_layout.addWidget(QLabel("To:"))
        filters_layout.addWidget(self.end_date_edit)
        
        filters_layout.addStretch()
        
        # Clear filters button
        self.clear_filters_btn = QPushButton("Clear Filters")
        self.clear_filters_btn.clicked.connect(self.clear_filters)
        filters_layout.addWidget(self.clear_filters_btn)
        
        layout.addWidget(filters_group)
        
        # Statistics section
        stats_group = QGroupBox("Statistics")
        stats_layout = QHBoxLayout(stats_group)
        
        self.total_tasks_label = QLabel("Total Tasks: 0")
        self.image_tasks_label = QLabel("Image Tasks: 0")
        self.video_tasks_label = QLabel("Video Tasks: 0")
        self.completed_tasks_label = QLabel("Completed: 0")
        self.failed_tasks_label = QLabel("Failed: 0")
        
        stats_layout.addWidget(self.total_tasks_label)
        stats_layout.addWidget(self.image_tasks_label)
        stats_layout.addWidget(self.video_tasks_label)
        stats_layout.addWidget(self.completed_tasks_label)
        stats_layout.addWidget(self.failed_tasks_label)
        stats_layout.addStretch()
        
        layout.addWidget(stats_group)
        
        # Tasks table section
        tasks_group = QGroupBox("Task History")
        tasks_layout = QVBoxLayout(tasks_group)
        
        # Tasks table
        self.tasks_table = QTableWidget()
        self.tasks_table.setColumnCount(8)
        self.tasks_table.setHorizontalHeaderLabels([
            "ID", "Type", "Status", "Prompt", "Input Image", "Created", "Completed", "Output"
        ])
        self.tasks_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.tasks_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        tasks_layout.addWidget(self.tasks_table)
        
        # Control buttons
        button_layout = QHBoxLayout()
        
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh_history)
        button_layout.addWidget(self.refresh_btn)
        
        self.view_output_btn = QPushButton("View Output")
        self.view_output_btn.clicked.connect(self.view_selected_output)
        button_layout.addWidget(self.view_output_btn)
        
        self.view_batch_btn = QPushButton("View Batch")
        self.view_batch_btn.clicked.connect(self.view_selected_batch)
        button_layout.addWidget(self.view_batch_btn)
        
        self.retry_task_btn = QPushButton("Retry Task")
        self.retry_task_btn.clicked.connect(self.retry_selected_task)
        button_layout.addWidget(self.retry_task_btn)
        
        self.delete_task_btn = QPushButton("Delete Task")
        self.delete_task_btn.clicked.connect(self.delete_selected_task)
        button_layout.addWidget(self.delete_task_btn)
        
        button_layout.addStretch()
        
        tasks_layout.addLayout(button_layout)
        
        layout.addWidget(tasks_group)
        
        # Status label
        self.status_label = QLabel("Ready")
        layout.addWidget(self.status_label)
        
        # Setup refresh timer
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.refresh_history)
        self.refresh_timer.start(30000)  # Update every 30 seconds
        
        # Initial refresh
        self.refresh_history()
        
    def toggle_date_filter(self, state):
        """Toggle date filter enabled state."""
        enabled = state == Qt.CheckState.Checked.value
        self.start_date_edit.setEnabled(enabled)
        self.end_date_edit.setEnabled(enabled)
        if enabled:
            self.apply_filters()
        else:
            self.refresh_history()
            
    def clear_filters(self):
        """Clear all filters."""
        self.task_type_combo.setCurrentIndex(0)
        self.status_combo.setCurrentIndex(0)
        self.date_checkbox.setChecked(False)
        self.start_date_edit.setDate(QDate.currentDate().addDays(-7))
        self.end_date_edit.setDate(QDate.currentDate())
        self.refresh_history()
        
    def apply_filters(self):
        """Apply filters to task history."""
        try:
            # Build query
            query = Task.select()
            
            # Task type filter
            task_type = self.task_type_combo.currentData()
            if task_type:
                query = query.where(Task.task_type == task_type)
            
            # Status filter
            status = self.status_combo.currentData()
            if status:
                query = query.where(Task.status == status)
            
            # Date filter
            if self.date_checkbox.isChecked():
                start_date = self.start_date_edit.date().toPyDate()
                end_date = self.end_date_edit.date().toPyDate()
                query = query.where(
                    (Task.created_at >= start_date) & 
                    (Task.created_at <= end_date)
                )
            
            # Order by creation date (newest first)
            query = query.order_by(Task.created_at.desc())
            
            # Update table
            tasks = list(query)
            self.update_tasks_table(tasks)
            
            # Update statistics
            self.update_statistics(tasks)
            
            self.status_label.setText(f"Showing {len(tasks)} tasks with applied filters")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to apply filters: {str(e)}")
            self.status_label.setText("Error applying filters")
            
    def refresh_history(self):
        """Refresh task history."""
        try:
            # Get all tasks
            tasks = list(Task.select().order_by(Task.created_at.desc()).limit(1000))
            
            self.update_tasks_table(tasks)
            self.update_statistics(tasks)
            
            self.status_label.setText(f"Showing {len(tasks)} recent tasks")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to refresh history: {str(e)}")
            self.status_label.setText("Error refreshing history")
            
    def update_tasks_table(self, tasks):
        """Update the tasks table with given tasks."""
        self.tasks_table.setRowCount(len(tasks))
        
        for row, task in enumerate(tasks):
            self.tasks_table.setItem(row, 0, QTableWidgetItem(str(task.id)))
            self.tasks_table.setItem(row, 1, QTableWidgetItem(task.task_type))
            self.tasks_table.setItem(row, 2, QTableWidgetItem(task.status))
            self.tasks_table.setItem(row, 3, QTableWidgetItem(
                task.prompt[:100] + "..." if len(task.prompt) > 100 else task.prompt
            ))
            self.tasks_table.setItem(row, 4, QTableWidgetItem(
                "Yes" if task.input_image_path else "No"
            ))
            self.tasks_table.setItem(row, 5, QTableWidgetItem(
                task.created_at.strftime('%Y-%m-%d %H:%M')
            ))
            self.tasks_table.setItem(row, 6, QTableWidgetItem(
                task.completed_at.strftime('%Y-%m-%d %H:%M') if task.completed_at else ""
            ))
            self.tasks_table.setItem(row, 7, QTableWidgetItem(task.output_path or ""))
            
            # Color code by status
            if task.status == 'completed':
                self.tasks_table.item(row, 2).setBackground(Qt.GlobalColor.green)
            elif task.status == 'failed':
                self.tasks_table.item(row, 2).setBackground(Qt.GlobalColor.red)
            elif task.status == 'running':
                self.tasks_table.item(row, 2).setBackground(Qt.GlobalColor.yellow)
            elif task.status == 'cancelled':
                self.tasks_table.item(row, 2).setBackground(Qt.GlobalColor.gray)
                
    def update_statistics(self, tasks):
        """Update statistics labels."""
        total = len(tasks)
        image_tasks = sum(1 for task in tasks if task.task_type == 'image')
        video_tasks = sum(1 for task in tasks if task.task_type == 'video')
        completed = sum(1 for task in tasks if task.status == 'completed')
        failed = sum(1 for task in tasks if task.status == 'failed')
        
        self.total_tasks_label.setText(f"Total Tasks: {total}")
        self.image_tasks_label.setText(f"Image Tasks: {image_tasks}")
        self.video_tasks_label.setText(f"Video Tasks: {video_tasks}")
        self.completed_tasks_label.setText(f"Completed: {completed}")
        self.failed_tasks_label.setText(f"Failed: {failed}")
        
    def view_selected_output(self):
        """View output of selected task."""
        current_row = self.tasks_table.currentRow()
        if current_row >= 0:
            task_id = int(self.tasks_table.item(current_row, 0).text())
            try:
                task = Task.get_by_id(task_id)
                if task.output_path and Path(task.output_path).exists():
                    # TODO: Implement file viewer
                    import os
                    os.startfile(task.output_path)
                else:
                    QMessageBox.warning(self, "Warning", "No output file available for this task")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to open output: {str(e)}")
        else:
            QMessageBox.warning(self, "Warning", "Please select a task first")
            
    def view_selected_batch(self):
        """View batch information for selected task."""
        current_row = self.tasks_table.currentRow()
        if current_row >= 0:
            task_id = int(self.tasks_table.item(current_row, 0).text())
            try:
                # Check if task belongs to any batch
                batch_tasks = BatchTask.select().where(BatchTask.task == task_id)
                if batch_tasks.exists():
                    batch_task = batch_tasks.get()
                    batch = batch_task.batch
                    QMessageBox.information(
                        self, "Batch Information",
                        f"Task belongs to batch: {batch.name}\n"
                        f"Batch ID: {batch.id}\n"
                        f"Batch Type: {batch.task_type}\n"
                        f"Batch Status: {batch.status}\n"
                        f"Total Tasks: {batch.total_tasks}\n"
                        f"Completed Tasks: {batch.completed_tasks}"
                    )
                else:
                    QMessageBox.information(self, "Batch Information", "This task is not part of any batch")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to get batch information: {str(e)}")
        else:
            QMessageBox.warning(self, "Warning", "Please select a task first")
            
    def retry_selected_task(self):
        """Retry the selected task."""
        current_row = self.tasks_table.currentRow()
        if current_row >= 0:
            task_id = int(self.tasks_table.item(current_row, 0).text())
            try:
                task = Task.get_by_id(task_id)
                if task.status in ['failed', 'cancelled']:
                    # Reset task status
                    task.status = 'pending'
                    task.error_message = None
                    task.started_at = None
                    task.completed_at = None
                    task.save()
                    
                    QMessageBox.information(self, "Success", "Task marked for retry")
                    self.refresh_history()
                else:
                    QMessageBox.warning(self, "Warning", "Only failed or cancelled tasks can be retried")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to retry task: {str(e)}")
        else:
            QMessageBox.warning(self, "Warning", "Please select a task first")
            
    def delete_selected_task(self):
        """Delete the selected task."""
        current_row = self.tasks_table.currentRow()
        if current_row >= 0:
            task_id = int(self.tasks_table.item(current_row, 0).text())
            reply = QMessageBox.question(
                self, "Confirm Delete", 
                "Are you sure you want to delete this task? This action cannot be undone.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if reply == QMessageBox.StandardButton.Yes:
                try:
                    # Delete task (this will also delete associated batch tasks due to foreign key)
                    Task.delete_by_id(task_id)
                    
                    QMessageBox.information(self, "Success", "Task deleted successfully")
                    self.refresh_history()
                    
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to delete task: {str(e)}")
        else:
            QMessageBox.warning(self, "Warning", "Please select a task first")