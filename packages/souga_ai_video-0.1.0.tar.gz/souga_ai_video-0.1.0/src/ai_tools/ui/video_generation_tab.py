from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                              QTextEdit, QLabel, QGroupBox, QSpinBox, QCheckBox,
                              QFileDialog, QTableWidget, QTableWidgetItem, QHeaderView,
                              QProgressBar, QMessageBox, QLineEdit, QComboBox)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QPixmap

import os
import requests
from pathlib import Path
from datetime import datetime

from ai_tools.config import Config
from ai_tools.database import Task, Batch, BatchTask
from ai_tools.generators.video_generator import VideoGenerator
from ai_tools.ui.video_workers import VideoGenerationWorker, VideoResumeWorker

class VideoGenerationTab(QWidget):
    """Tab for video generation functionality."""
    
    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        self.generator = VideoGenerator(config)
        self.current_batch = None
        self.input_image_path = None
        self.is_generating = False
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface."""
        layout = QVBoxLayout(self)
        
        # Input section
        input_group = QGroupBox("Video Generation Input")
        input_layout = QVBoxLayout(input_group)
        
        # Text prompt input
        prompt_label = QLabel("Text Prompt:")
        self.prompt_input = QTextEdit()
        self.prompt_input.setMaximumHeight(100)
        self.prompt_input.setPlaceholderText("Enter your video generation prompt here...")
        self.prompt_input.textChanged.connect(self.on_prompt_changed)
        input_layout.addWidget(prompt_label)
        input_layout.addWidget(self.prompt_input)
        
        # Image input (optional)
        image_layout = QHBoxLayout()
        
        self.input_image_label = QLabel("Input Image (optional):")
        self.input_image_path_edit = QLineEdit()
        self.input_image_path_edit.setReadOnly(False)
        self.input_image_path_edit.setPlaceholderText("本地图片路径或远程 URL (可选)")
        self.input_image_path_edit.textChanged.connect(self.on_image_path_changed)
        
        self.select_image_btn = QPushButton("Select Image")
        self.select_image_btn.clicked.connect(self.select_input_image)
        
        self.clear_image_btn = QPushButton("Clear")
        self.clear_image_btn.clicked.connect(self.clear_input_image)
        
        image_layout.addWidget(self.input_image_label)
        image_layout.addWidget(self.input_image_path_edit)
        image_layout.addWidget(self.select_image_btn)
        image_layout.addWidget(self.clear_image_btn)

        input_layout.addLayout(image_layout)
        # Preview
        self.preview_label = QLabel("预览")
        self.preview_label.setFixedHeight(160)
        self.preview_label.setStyleSheet("border:1px solid #ccc;background:#fff;padding:4px;")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        input_layout.addWidget(self.preview_label)
        
        # Video settings
        settings_layout = QHBoxLayout()
        
        duration_label = QLabel("Duration (seconds):")
        self.duration_combo = QComboBox()
        self.duration_combo.addItems(["10", "15"])
        self.duration_combo.setCurrentText("15")
        settings_layout.addWidget(duration_label)
        settings_layout.addWidget(self.duration_combo)
        
        fps_label = QLabel("FPS:")
        self.fps_spinbox = QSpinBox()
        self.fps_spinbox.setRange(8, 60)
        self.fps_spinbox.setValue(24)
        settings_layout.addWidget(fps_label)
        settings_layout.addWidget(self.fps_spinbox)
        
        ar_label = QLabel("宽高比:")
        self.ar_combo = QComboBox()
        self.ar_combo.addItem("9:16 (竖屏)", "9:16")
        self.ar_combo.addItem("16:9 (横屏)", "16:9")
        self.ar_combo.setCurrentIndex(0)
        settings_layout.addWidget(ar_label)
        settings_layout.addWidget(self.ar_combo)
        
        settings_layout.addStretch()
        input_layout.addLayout(settings_layout)
        
        # Batch settings
        batch_layout = QHBoxLayout()
        
        self.batch_checkbox = QCheckBox("Enable Batch Processing")
        self.batch_checkbox.stateChanged.connect(self.toggle_batch_mode)
        batch_layout.addWidget(self.batch_checkbox)
        
        batch_size_label = QLabel("Batch Size:")
        self.batch_size_spinbox = QSpinBox()
        self.batch_size_spinbox.setRange(1, self.config.max_batch_size)
        self.batch_size_spinbox.setValue(1)
        self.batch_size_spinbox.setEnabled(False)
        batch_layout.addWidget(batch_size_label)
        batch_layout.addWidget(self.batch_size_spinbox)
        
        batch_layout.addStretch()
        input_layout.addLayout(batch_layout)
        
        # Control buttons
        button_layout = QHBoxLayout()
        
        self.generate_btn = QPushButton("Generate Video(s)")
        self.generate_btn.clicked.connect(self.generate_videos)
        button_layout.addWidget(self.generate_btn)
        
        self.load_prompts_btn = QPushButton("Load Prompts from File")
        self.load_prompts_btn.clicked.connect(self.load_prompts_from_file)
        self.load_prompts_btn.setEnabled(False)
        button_layout.addWidget(self.load_prompts_btn)
        
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.clicked.connect(self.clear_inputs)
        button_layout.addWidget(self.clear_btn)
        
        button_layout.addStretch()
        input_layout.addLayout(button_layout)
        
        layout.addWidget(input_group)
        
        # Progress section
        progress_group = QGroupBox("Progress")
        progress_layout = QVBoxLayout(progress_group)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        progress_layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("Ready")
        progress_layout.addWidget(self.status_label)
        
        layout.addWidget(progress_group)
        
        # Results section
        results_group = QGroupBox("Recent Tasks")
        results_layout = QVBoxLayout(results_group)
        
        self.tasks_table = QTableWidget()
        self.tasks_table.setColumnCount(8)
        self.tasks_table.setHorizontalHeaderLabels([
            "ID", "Status", "Prompt", "Input Image", "Created", "Completed", "Output", "Remote ID"
        ])
        self.tasks_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.tasks_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.tasks_table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        results_layout.addWidget(self.tasks_table)
        
        # Results buttons
        results_button_layout = QHBoxLayout()
        
        self.refresh_tasks_btn = QPushButton("Refresh")
        self.refresh_tasks_btn.clicked.connect(self.refresh_tasks)
        results_button_layout.addWidget(self.refresh_tasks_btn)
        
        self.view_output_btn = QPushButton("View Output")
        self.view_output_btn.clicked.connect(self.view_selected_output)
        results_button_layout.addWidget(self.view_output_btn)
        
        self.open_folder_btn = QPushButton("Open Output Folder")
        self.open_folder_btn.clicked.connect(self.open_output_folder)
        results_button_layout.addWidget(self.open_folder_btn)

        self.select_all_btn = QPushButton("全选")
        self.select_all_btn.clicked.connect(self.select_all_tasks)
        results_button_layout.addWidget(self.select_all_btn)

        self.delete_task_btn = QPushButton("批量删除")
        self.delete_task_btn.clicked.connect(self.delete_selected_task)
        results_button_layout.addWidget(self.delete_task_btn)

        self.force_resume_btn = QPushButton("强制恢复运行")
        self.force_resume_btn.clicked.connect(self.force_resume_selected_tasks)
        results_button_layout.addWidget(self.force_resume_btn)

        self.remote_id_edit = QLineEdit()
        self.remote_id_edit.setPlaceholderText("远端任务ID")
        results_button_layout.addWidget(self.remote_id_edit)
        self.bind_remote_btn = QPushButton("绑定任务ID")
        self.bind_remote_btn.clicked.connect(self.bind_remote_id_to_selected)
        results_button_layout.addWidget(self.bind_remote_btn)
        
        results_button_layout.addStretch()
        results_layout.addLayout(results_button_layout)
        
        layout.addWidget(results_group)
        
        # Initial refresh
        self.refresh_tasks()
        
    def toggle_batch_mode(self, state):
        """Toggle batch processing mode."""
        is_batch = state == Qt.CheckState.Checked.value
        self.batch_size_spinbox.setEnabled(is_batch)
        self.load_prompts_btn.setEnabled(is_batch)
        self.generate_btn.setText("Generate Videos" if is_batch else "Generate Video")
        
    def select_input_image(self):
        """Select input image for video generation."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Input Image", "", "Image Files (*.png *.jpg *.jpeg *.bmp *.gif)"
        )
        if file_path:
            self.input_image_path = file_path
            self.input_image_path_edit.setText(file_path)
            
    def clear_input_image(self):
        """Clear selected input image."""
        self.input_image_path = None
        self.input_image_path_edit.clear()
        self.update_image_preview()

    def on_image_path_changed(self, text: str):
        """Sync input image path when user edits manually."""
        self.input_image_path = text.strip() or None
        self.update_image_preview()

    def update_image_preview(self):
        """Update preview for selected image path or URL."""
        try:
            if not self.input_image_path:
                self.preview_label.setPixmap(QPixmap())
                self.preview_label.setText("预览")
                return
            path = self.input_image_path
            pix = QPixmap()
            if isinstance(path, str) and path.lower().startswith("http"):
                resp = requests.get(path, timeout=10)
                if resp.status_code == 200:
                    if not pix.loadFromData(resp.content):
                        self.preview_label.setText("无法加载图片")
                        return
                else:
                    self.preview_label.setText("下载失败")
                    return
            else:
                if os.path.exists(path):
                    if not pix.load(path):
                        self.preview_label.setText("无法加载图片")
                        return
                else:
                    self.preview_label.setText("路径不存在")
                    return
            scaled = pix.scaled(self.preview_label.width(), self.preview_label.height(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.preview_label.setPixmap(scaled)
            self.preview_label.setText("")
        except Exception:
            self.preview_label.setText("预览失败")
        
    def load_prompts_from_file(self):
        """Load multiple prompts from a text file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Prompts", "", "Text Files (*.txt)"
        )
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    prompts = [line.strip() for line in f if line.strip()]
                
                if prompts:
                    self.prompt_input.clear()
                    self.prompt_input.setPlainText("\n".join(prompts))
                    self.batch_size_spinbox.setValue(min(len(prompts), self.config.max_batch_size))
                    QMessageBox.information(self, "Success", f"Loaded {len(prompts)} prompts")
                else:
                    QMessageBox.warning(self, "Warning", "No valid prompts found in file")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load prompts: {str(e)}")
                
    def generate_videos(self):
        """Generate videos based on current input."""
        if not (self.config.openai_api_key or self.config.duomi_api_key):
            QMessageBox.warning(self, "Missing API Key", "需要配置 OpenAI 或 Duomi 的 API Key 才能生成视频")
            return
            
        prompt_text = self.prompt_input.toPlainText().strip()
        if not prompt_text:
            QMessageBox.warning(self, "Missing Input", "Please enter a prompt")
            return
            
        if self.batch_checkbox.isChecked():
            # Batch processing
            prompts = [p.strip() for p in prompt_text.split('\n') if p.strip()]
            if not prompts:
                QMessageBox.warning(self, "Missing Input", "Please enter at least one prompt")
                return
                
            batch_size = min(self.batch_size_spinbox.value(), len(prompts), self.config.max_batch_size)
            prompts = prompts[:batch_size]
            
            self.start_batch_generation(prompts)
        else:
            # Single video generation
            self.start_single_generation(prompt_text)
            
    def start_single_generation(self, prompt: str):
        """Start single video generation."""
        try:
            # Prevent duplicate pending/running tasks for same prompt/provider and input image
            exists = (Task
                      .select()
                      .where(
                          (Task.task_type == 'video') &
                          (Task.api_provider == 'openai') &
                          (Task.prompt == prompt) &
                          (Task.input_image_path == self.input_image_path) &
                          (Task.status.in_(['pending', 'running']))
                      )
                      .exists())
            if exists:
                QMessageBox.information(self, "Duplicate Task", "已存在相同的未完成视频任务，已避免重复创建。")
                return
            # Create task in database
            task = Task.create(
                task_type='video',
                status='pending',
                prompt=prompt,
                input_image_path=self.input_image_path,
                api_provider='openai'
            )
            
            # Start generation worker
            ar = self.ar_combo.currentData() or "9:16"
            try:
                dur = int(self.duration_combo.currentText())
            except Exception:
                dur = 15
            self.generation_worker = VideoGenerationWorker(
                self.generator, [prompt], [task.id], [self.input_image_path], aspect_ratio=ar, duration=dur
            )
            self.generation_worker.progress_updated.connect(self.update_progress)
            self.generation_worker.finished.connect(self.generation_finished)
            self.generation_worker.start()
            
            self.generate_btn.setEnabled(False)
            self.is_generating = True
            self.progress_bar.setVisible(True)
            self.status_label.setText("Generating video...")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start generation: {str(e)}")
            self.generate_btn.setEnabled(True)
            self.is_generating = False
            
    def start_batch_generation(self, prompts: list):
        """Start batch video generation."""
        try:
            # Create batch
            batch = Batch.create(
                name=f"Video Batch {datetime.now().strftime('%Y%m%d_%H%M%S')}",
                task_type='video',
                status='pending',
                total_tasks=len(prompts)
            )
            
            # Create tasks
            tasks = []
            input_images = []
            for prompt in prompts:
                task = Task.create(
                    task_type='video',
                    status='pending',
                    prompt=prompt,
                    input_image_path=self.input_image_path,
                    api_provider='openai'
                )
                BatchTask.create(batch=batch, task=task)
                tasks.append(task)
                input_images.append(self.input_image_path)
            
            # Start generation worker
            ar = self.ar_combo.currentData() or "9:16"
            try:
                dur = int(self.duration_combo.currentText())
            except Exception:
                dur = 15
            self.generation_worker = VideoGenerationWorker(
                self.generator, prompts, [t.id for t in tasks], input_images, aspect_ratio=ar, duration=dur
            )
            self.generation_worker.progress_updated.connect(self.update_progress)
            self.generation_worker.finished.connect(self.generation_finished)
            self.generation_worker.start()
            
            self.generate_btn.setEnabled(False)
            self.is_generating = True
            self.progress_bar.setVisible(True)
            self.progress_bar.setMaximum(len(prompts))
            self.status_label.setText(f"Generating {len(prompts)} videos...")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start batch generation: {str(e)}")
            self.generate_btn.setEnabled(True)
            self.is_generating = False
            
    def update_progress(self, completed: int, total: int):
        """Update progress bar."""
        self.progress_bar.setValue(completed)
        self.status_label.setText(f"Generated {completed} of {total} videos...")
        
    def generation_finished(self, success_count: int, total_count: int):
        """Handle generation completion."""
        self.generate_btn.setEnabled(True)
        self.is_generating = False
        try:
            self.force_resume_btn.setEnabled(True)
        except Exception:
            pass
        self.progress_bar.setVisible(False)
        
        if success_count == total_count:
            self.status_label.setText(f"Successfully generated {success_count} videos")
        else:
            self.status_label.setText(f"Generated {success_count} of {total_count} videos (some failed)")
            
        self.refresh_tasks()
        
    def clear_inputs(self):
        """Clear all input fields."""
        self.prompt_input.clear()
        self.clear_input_image()
        self.batch_checkbox.setChecked(False)
        self.batch_size_spinbox.setValue(1)

    def on_prompt_changed(self):
        if not self.is_generating:
            self.generate_btn.setEnabled(True)
        
    def refresh_tasks(self):
        """Refresh the tasks table."""
        try:
            # Get recent video tasks
            tasks = Task.select().where(Task.task_type == 'video').order_by(Task.created_at.desc()).limit(50)
            
            self.tasks_table.setRowCount(len(tasks))
            for row, task in enumerate(tasks):
                self.tasks_table.setItem(row, 0, QTableWidgetItem(str(task.id)))
                self.tasks_table.setItem(row, 1, QTableWidgetItem(task.status))
                self.tasks_table.setItem(row, 2, QTableWidgetItem(task.prompt[:100] + "..." if len(task.prompt) > 100 else task.prompt))
                self.tasks_table.setItem(row, 3, QTableWidgetItem(
                    "Yes" if task.input_image_path else "No"
                ))
                self.tasks_table.setItem(row, 4, QTableWidgetItem(task.created_at.strftime('%Y-%m-%d %H:%M')))
                self.tasks_table.setItem(row, 5, QTableWidgetItem(
                    task.completed_at.strftime('%Y-%m-%d %H:%M') if task.completed_at else ""
                ))
                self.tasks_table.setItem(row, 6, QTableWidgetItem(task.output_path or ""))
                self.tasks_table.setItem(row, 7, QTableWidgetItem(task.remote_task_id or ""))
                
                # Color code by status
                if task.status == 'completed':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.green)
                elif task.status == 'failed':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.red)
                elif task.status == 'running':
                    self.tasks_table.item(row, 1).setBackground(Qt.GlobalColor.yellow)
                    
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to refresh tasks: {str(e)}")
            
    def view_selected_output(self):
        """View output of selected task."""
        current_row = self.tasks_table.currentRow()
        if current_row >= 0:
            task_id = self.tasks_table.item(current_row, 0).text()
            output_path = self.tasks_table.item(current_row, 6).text()
            
            if output_path and os.path.exists(output_path):
                # TODO: Implement video viewer
                QMessageBox.information(self, "View Output", f"Output file: {output_path}")
            else:
                QMessageBox.warning(self, "Warning", "No output file available for this task")
        else:
            QMessageBox.warning(self, "Warning", "请选择任务")

    def delete_selected_task(self):
        """Batch delete selected tasks."""
        rows = sorted({idx.row() for idx in self.tasks_table.selectedIndexes()})
        if not rows:
            QMessageBox.warning(self, "Warning", "请选择任务")
            return
        try:
            ids = []
            for r in rows:
                item = self.tasks_table.item(r, 0)
                if item:
                    ids.append(int(item.text()))
            if not ids:
                QMessageBox.warning(self, "Warning", "未获取到任务ID")
                return
            reply = QMessageBox.question(
                self, "批量删除", f"确定删除选中的 {len(ids)} 个任务？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
            for tid in ids:
                Task.delete_by_id(tid)
            QMessageBox.information(self, "成功", f"已删除 {len(ids)} 个任务")
            self.refresh_tasks()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"批量删除失败: {str(e)}")

    def select_all_tasks(self):
        """Select all tasks in the table."""
        self.tasks_table.selectAll()
                
    def open_output_folder(self):
        """Open the output folder."""
        try:
            os.startfile(str(self.config.output_dir))
        except AttributeError:
            # For non-Windows systems
            import subprocess
            subprocess.run(['open', str(self.config.output_dir)])

    def force_resume_selected_tasks(self):
        """Force resume selected failed video tasks."""
        try:
            rows = sorted({idx.row() for idx in self.tasks_table.selectedIndexes()})
            if not rows:
                QMessageBox.warning(self, "Warning", "请选择任务")
                return
            ids = []
            for r in rows:
                id_item = self.tasks_table.item(r, 0)
                status_item = self.tasks_table.item(r, 1)
                remote_item = self.tasks_table.item(r, 7)
                if id_item and status_item and status_item.text() == 'failed':
                    if remote_item and remote_item.text():
                        ids.append(int(id_item.text()))
            if not ids:
                QMessageBox.warning(self, "Warning", "未选中失败状态的视频任务或缺少任务ID")
                return
            self.resume_worker = VideoResumeWorker(self.generator, ids)
            self.resume_worker.progress_updated.connect(self.update_progress)
            self.resume_worker.finished.connect(self.generation_finished)
            self.resume_worker.start()
            self.force_resume_btn.setEnabled(False)
            self.progress_bar.setVisible(True)
            self.progress_bar.setMaximum(len(ids))
            self.status_label.setText(f"强制恢复 {len(ids)} 个任务...")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"强制恢复失败: {str(e)}")

    def bind_remote_id_to_selected(self):
        try:
            remote_id = self.remote_id_edit.text().strip()
            if not remote_id:
                QMessageBox.warning(self, "Warning", "请输入远端任务ID")
                return
            rows = sorted({idx.row() for idx in self.tasks_table.selectedIndexes()})
            if not rows:
                QMessageBox.warning(self, "Warning", "请选择任务")
                return
            from ai_tools.database import Task
            count = 0
            for r in rows:
                id_item = self.tasks_table.item(r, 0)
                status_item = self.tasks_table.item(r, 1)
                if id_item:
                    tid = int(id_item.text())
                    try:
                        t = Task.get_by_id(tid)
                        t.remote_task_id = remote_id
                        t.save()
                        count += 1
                        self.tasks_table.setItem(r, 7, QTableWidgetItem(remote_id))
                    except Exception as e:
                        self.config.logger.error(f"Bind remote id error: {e}")
            QMessageBox.information(self, "成功", f"已绑定 {count} 个任务ID")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"绑定任务ID失败: {str(e)}")
