from PyQt6.QtCore import QThread, pyqtSignal
from datetime import datetime

from ai_tools.database import Task
from ai_tools.generators.image_generator import ImageGenerator
from ai_tools.generators.video_generator import VideoGenerator

class ImageGenerationWorker(QThread):
    """Worker thread for image generation."""
    
    progress_updated = pyqtSignal(int, int)  # completed, total
    finished = pyqtSignal(int, int)  # success_count, total_count
    
    def __init__(self, generator, prompts, task_ids):
        super().__init__()
        self.generator = generator
        self.prompts = prompts
        self.task_ids = task_ids
        self.success_count = 0
        
    def run(self):
        """Run the image generation process."""
        total = len(self.prompts)
        completed = 0
        
        for i, (prompt, task_id) in enumerate(zip(self.prompts, self.task_ids)):
            try:
                # Update task status
                task = Task.get_by_id(task_id)
                task.status = 'running'
                task.started_at = datetime.now()
                task.save()
                try:
                    from ai_tools.config import Config
                except Exception:
                    Config = None
                if Config:
                    pass
                
                # Generate image
                output_path = self.generator.generate_image(prompt, task_id)
                
                if output_path:
                    # Update task as completed
                    task.status = 'completed'
                    task.output_path = output_path
                    task.completed_at = datetime.now()
                    task.save()
                    try:
                        self.generator.config.logger.info(f"Image task {task_id} completed: {output_path}")
                    except Exception:
                        pass
                else:
                    # Update task as failed
                    task.status = 'failed'
                    task.error_message = 'Generation failed'
                    task.completed_at = datetime.now()
                    task.save()
                    try:
                        self.generator.config.logger.error(f"Image task {task_id} failed")
                    except Exception:
                        pass
                    
            except Exception as e:
                # Update task as failed
                try:
                    task = Task.get_by_id(task_id)
                    task.status = 'failed'
                    task.error_message = str(e)
                    task.completed_at = datetime.now()
                    task.save()
                    try:
                        self.generator.config.logger.error(f"Image task {task_id} exception: {e}")
                    except Exception:
                        pass
                except:
                    pass
                    
            completed += 1
            self.progress_updated.emit(completed, total)
            
        self.finished.emit(self.success_count, total)

class RecoveryWorker(QThread):
    """Worker to recover and resume 'running' tasks after app restart."""
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.image_gen = ImageGenerator(config)
        self.video_gen = VideoGenerator(config)

    def run(self):
        try:
            running_tasks = list(Task.select().where(Task.status == 'running').limit(100))
            if not running_tasks:
                return
            self.config.logger.info(f"Recovery: found {len(running_tasks)} running tasks")
            for task in running_tasks:
                try:
                    if task.task_type == 'image' and task.api_provider == 'google':
                        out = self.image_gen.resume_image_task(task)
                    elif task.task_type == 'video' and task.api_provider == 'openai':
                        out = self.video_gen.resume_video_task(task)
                    else:
                        out = None
                    if out:
                        task.status = 'completed'
                        task.output_path = out
                        task.completed_at = datetime.now()
                        task.save()
                        self.config.logger.info(f"Recovery: task {task.id} completed")
                    else:
                        # keep as running or mark failed based on presence of remote id
                        if not task.remote_task_id:
                            task.status = 'failed'
                            task.error_message = 'No remote_task_id, cannot resume'
                            task.completed_at = datetime.now()
                            task.save()
                            self.config.logger.warning(f"Recovery: task {task.id} failed due to missing remote id")
                except Exception as e:
                    try:
                        task.status = 'failed'
                        task.error_message = str(e)
                        task.completed_at = datetime.now()
                        task.save()
                        self.config.logger.error(f"Recovery: task {task.id} exception: {e}")
                    except Exception:
                        pass
        except Exception as e:
            try:
                self.config.logger.error(f"Recovery worker error: {e}")
            except Exception:
                pass
