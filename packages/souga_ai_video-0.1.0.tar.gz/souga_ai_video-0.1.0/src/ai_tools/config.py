import os
import sys
import logging
from pathlib import Path
from dotenv import load_dotenv

class Config:
    """Application configuration management."""
    
    def __init__(self):
        load_dotenv()
        
        # Database configuration
        self.db_path = Path.home() / ".ai_tools" / "database.db"
        self.db_path.parent.mkdir(exist_ok=True)
        
        # API Keys
        self.google_api_key = os.getenv("GOOGLE_API_KEY", "")
        self.openai_api_key = os.getenv("OPENAI_API_KEY", "")
        self.duomi_api_key = os.getenv("DUOMI_API_KEY", "")
        
        # API Endpoints
        self.duomi_api_base = os.getenv("DUOMI_API_BASE", "https://duomiapi.com")

        # Google Nano Banana via Duomi
        self.google_nano_banana_submit = os.getenv(
            "GOOGLE_NANO_BANANA_SUBMIT_ENDPOINT",
            f"{self.duomi_api_base}/api/gemini/nano-banana"
        )
        self.google_nano_banana_status = os.getenv(
            "GOOGLE_NANO_BANANA_STATUS_ENDPOINT",
            f"{self.duomi_api_base}/api/gemini/nano-banana/{{task_id}}"
        )

        # OpenAI Sora2 via Duomi
        self.openai_sora2_submit = os.getenv(
            "OPENAI_SORA2_SUBMIT_ENDPOINT",
            f"{self.duomi_api_base}/v1/videos/generations"
        )
        self.openai_sora2_status = os.getenv(
            "OPENAI_SORA2_STATUS_ENDPOINT",
            f"{self.duomi_api_base}/v1/videos/tasks/{{task_id}}"
        )

        
        # Batch processing settings
        self.max_batch_size = int(os.getenv("MAX_BATCH_SIZE", "10"))
        self.max_concurrent_tasks = int(os.getenv("MAX_CONCURRENT_TASKS", "3"))
        
        # File paths
        self.output_dir = Path.home() / ".ai_tools" / "output"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir = Path.home() / ".ai_tools" / "logs"
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.logs_dir / "app.log"
        
        # UI settings
        self.window_title = "嗖嘎AI视频生成器"
        self.window_size = (1200, 800)

        self.use_duomi_proxy = bool(self.duomi_api_key)
        self.env_file_path = Path.cwd() / ".env"
        self.setup_logger()
        
    def validate_api_keys(self):
        """Validate that required API keys are set."""
        missing_keys = []
        # If Duomi proxy is configured, keys for direct providers are optional
        if not self.use_duomi_proxy:
            if not self.google_api_key:
                missing_keys.append("GOOGLE_API_KEY")
            if not self.openai_api_key:
                missing_keys.append("OPENAI_API_KEY")
        else:
            if not self.duomi_api_key:
                missing_keys.append("DUOMI_API_KEY")
            
        return missing_keys

    def setup_logger(self):
        try:
            from loguru import logger as _logger
            _logger.remove()
            _logger.add(sys.stdout, level="INFO", backtrace=False, diagnose=False,
                        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | {level} | {message}")
            _logger.add(str(self.log_file), level="INFO", rotation="10 MB", retention="14 days",
                        encoding="utf-8", enqueue=True,
                        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}")
            self.logger = _logger
        except Exception:
            logger = logging.getLogger("ai_tools")
            if not logger.handlers:
                logger.setLevel(logging.INFO)
                ch = logging.StreamHandler(sys.stdout)
                fh = logging.FileHandler(str(self.log_file))
                fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
                ch.setFormatter(fmt)
                fh.setFormatter(fmt)
                logger.addHandler(ch)
                logger.addHandler(fh)
            self.logger = logger
