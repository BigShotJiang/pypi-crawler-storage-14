import requests
import json
from pathlib import Path
from datetime import datetime
from PIL import Image
import io

from ai_tools.config import Config
from ai_tools.database import Task

class ImageGenerator:
    """Image generator using Google Nano Banana via Duomi proxy (task polling)."""
    
    def __init__(self, config: Config):
        self.config = config
        self.session = requests.Session()
        
    def generate_image(self, prompt: str, task_id: int) -> str:
        """
        Generate an image using the Google Nano Banana API.
        
        Args:
            prompt: Text prompt for image generation
            task_id: Task ID for output file naming
            
        Returns:
            Path to generated image file or None if failed
        """
        try:
            # Headers for Duomi proxy
            headers = {
                'Authorization': self.config.duomi_api_key or '',
                'Content-Type': 'application/json'
            }
            
            # Payload per Duomi Nano Banana API
            payload = {
                'model': 'gemini-3-pro-image-preview',
                'prompt': prompt,
                'aspect_ratio': '',
                'image_size': '4K'
            }
            
            # Submit task
            submit = self.session.post(
                self.config.google_nano_banana_submit,
                headers=headers,
                data=json.dumps(payload),
                timeout=30
            )
            if submit.status_code != 200:
                self.config.logger.error(f"Image submit error {submit.status_code}: {submit.text}")
                return None
            submit_data = submit.json()
            task_uuid = submit_data.get('data', {}).get('task_id') or submit_data.get('task_id')
            if not task_uuid:
                self.config.logger.error(f"Image submit invalid response: {submit_data}")
                return None
            self.config.logger.info(f"Image task submitted: {task_uuid}")
            try:
                t = Task.get_by_id(task_id)
                t.remote_task_id = task_uuid
                t.save()
            except Exception:
                pass
            
            # Poll status
            import time
            status_url = self.config.google_nano_banana_status.replace('{task_id}', task_uuid)
            deadline = time.time() + 10 * 60
            last_state = None
            while time.time() < deadline:
                status_resp = self.session.get(status_url, headers={'Authorization': headers['Authorization']}, timeout=15)
                if status_resp.status_code != 200:
                    self.config.logger.warning(f"Image status {task_uuid} HTTP {status_resp.status_code}")
                    time.sleep(3)
                    continue
                status_data = status_resp.json()
                data = status_data.get('data') or {}
                state = data.get('state')
                last_state = state
                if state == 'succeeded':
                    images = (data.get('data') or {}).get('images') or data.get('images') or []
                    if not images:
                        self.config.logger.error(f"Image succeeded but no images field: {status_data}")
                        return None
                    info = images[0]
                    url = info.get('url')
                    file_name = info.get('file_name') or 'output.jpeg'
                    if not url:
                        self.config.logger.error(f"Image url missing: {status_data}")
                        return None
                    file_resp = self.session.get(url, stream=True, timeout=300)
                    if file_resp.status_code != 200:
                        self.config.logger.error(f"Image download error HTTP {file_resp.status_code}")
                        return None
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    # Ensure unique filename
                    filename = f"image_{task_id}_{timestamp}_{Path(file_name).name}"
                    output_path = self.config.output_dir / filename
                    with open(output_path, 'wb') as f:
                        for chunk in file_resp.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                    self.config.logger.info(f"Image saved: {output_path}")
                    return str(output_path)
                elif state in ('failed', 'error'):
                    self.config.logger.error(f"Image task failed {task_uuid}: {status_data}")
                    return None
                time.sleep(3)
            self.config.logger.error(f"Image task timeout {task_uuid}, last state: {last_state}")
            return None
            
        except requests.exceptions.RequestException as e:
            print(f"Network error during image generation: {str(e)}")
            return None
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {str(e)}")
            return None
        except Exception as e:
            print(f"Unexpected error during image generation: {str(e)}")
            return None
            
    def validate_api_key(self) -> bool:
        """Validate availability of Duomi proxy key or Google key."""
        try:
            return bool(self.config.duomi_api_key or self.config.google_api_key)
        
        except Exception as e:
            self.config.logger.error(f"Image API key validation error: {str(e)}")
            return False

    def resume_image_task(self, task: Task) -> str | None:
        """Resume polling for a previously submitted image task using remote_task_id."""
        try:
            if not task.remote_task_id:
                return None
            headers = {'Authorization': self.config.duomi_api_key or ''}
            import time
            status_url = self.config.google_nano_banana_status.replace('{task_id}', task.remote_task_id)
            deadline = time.time() + 10 * 60
            last_state = None
            while time.time() < deadline:
                status_resp = self.session.get(status_url, headers=headers, timeout=15)
                if status_resp.status_code != 200:
                    self.config.logger.warning(f"Image status {task.remote_task_id} HTTP {status_resp.status_code}")
                    time.sleep(3)
                    continue
                status_data = status_resp.json()
                data = status_data.get('data') or {}
                state = data.get('state')
                last_state = state
                if state == 'succeeded':
                    images = (data.get('data') or {}).get('images') or data.get('images') or []
                    if not images:
                        self.config.logger.error(f"Image succeeded but no images field: {status_data}")
                        return None
                    info = images[0]
                    url = info.get('url')
                    file_name = info.get('file_name') or 'output.jpeg'
                    if not url:
                        self.config.logger.error(f"Image url missing: {status_data}")
                        return None
                    file_resp = self.session.get(url, stream=True, timeout=300)
                    if file_resp.status_code != 200:
                        self.config.logger.error(f"Image download error HTTP {file_resp.status_code}")
                        return None
                    from datetime import datetime
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = f"image_{task.id}_{timestamp}_{Path(file_name).name}"
                    output_path = self.config.output_dir / filename
                    with open(output_path, 'wb') as f:
                        for chunk in file_resp.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                    self.config.logger.info(f"Image recovered and saved: {output_path}")
                    return str(output_path)
                elif state in ('failed', 'error'):
                    self.config.logger.error(f"Recovered image task failed {task.remote_task_id}: {status_data}")
                    return None
                time.sleep(3)
            self.config.logger.error(f"Recovered image task timeout {task.remote_task_id}, last state: {last_state}")
            return None
        except Exception as e:
            self.config.logger.error(f"Resume image task error: {e}")
            return None
