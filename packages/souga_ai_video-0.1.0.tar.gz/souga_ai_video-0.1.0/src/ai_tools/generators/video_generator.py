import requests
import json
from pathlib import Path
from datetime import datetime

from ai_tools.config import Config
from ai_tools.database import Task

class VideoGenerator:
    """Video generator using OpenAI Sora2 via Duomi proxy (task polling)."""
    
    def __init__(self, config: Config):
        self.config = config
        self.session = requests.Session()
        
    def generate_video(self, prompt: str, task_id: int, input_image_path: str = None,
                       aspect_ratio: str = '9:16', duration: int = 15) -> str:
        """
        Generate a video using the OpenAI Sora2 API.
        
        Args:
            prompt: Text prompt for video generation
            task_id: Task ID for output file naming
            input_image_path: Optional input image path for image-to-video generation
            
        Returns:
            Path to generated video file or None if failed
        """
        try:
            # Build headers for Duomi proxy
            headers = {
                'Authorization': self.config.duomi_api_key or '',
                'Content-Type': 'application/json'
            }
            
            # Payload per Duomi Sora2 API
            # Enforce allowed values
            ar = aspect_ratio if aspect_ratio in ('16:9', '9:16') else '9:16'
            dur = duration if duration in (10, 15) else 15
            payload = {
                'model': 'sora-2',
                'prompt': prompt,
                'aspect_ratio': ar,
                'duration': dur
            }
            self.config.logger.info(f"Video params: aspect_ratio={ar}, duration={dur}s")
            # Optional image URL (Duomi expects remote URL list)
            if input_image_path and isinstance(input_image_path, str) and input_image_path.lower().startswith('http'):
                payload['image_urls'] = [input_image_path]
            
            
            # Submit generation task
            submit = self.session.post(
                self.config.openai_sora2_submit,
                headers=headers,
                data=json.dumps(payload),
                timeout=30
            )
            if submit.status_code != 200:
                self.config.logger.error(f"Video submit error {submit.status_code}: {submit.text}")
                return None
            submit_data = submit.json()
            task_uuid = submit_data.get('id') or submit_data.get('data', {}).get('task_id')
            if not task_uuid:
                self.config.logger.error(f"Video submit invalid response: {submit_data}")
                return None
            self.config.logger.info(f"Video task submitted: {task_uuid}")
            try:
                t = Task.get_by_id(task_id)
                t.remote_task_id = task_uuid
                t.save()
            except Exception:
                pass
            
            # Poll task status until succeeded
            import time
            status_url = self.config.openai_sora2_status.replace('{task_id}', task_uuid)
            deadline = time.time() + 15 * 60
            last_state = None
            while time.time() < deadline:
                status_resp = self.session.get(status_url, headers={'Authorization': headers['Authorization']}, timeout=15)
                if status_resp.status_code != 200:
                    self.config.logger.warning(f"Video status {task_uuid} HTTP {status_resp.status_code}")
                    time.sleep(5)
                    continue
                status_data = status_resp.json()
                data = status_data.get('data') or status_data
                state = data.get('state') or status_data.get('state')
                last_state = state
                if state == 'succeeded':
                    videos = (data.get('data') or {}).get('videos') or data.get('videos') or []
                    if not videos:
                        self.config.logger.error(f"Video succeeded but no videos field: {status_data}")
                        return None
                    url = videos[0].get('url')
                    if not url:
                        self.config.logger.error(f"Video url missing: {status_data}")
                        return None
                    # Download final video
                    file_resp = self.session.get(url, stream=True, timeout=600)
                    if file_resp.status_code != 200:
                        self.config.logger.error(f"Video download error HTTP {file_resp.status_code}")
                        return None
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = f"video_{task_id}_{timestamp}.mp4"
                    output_path = self.config.output_dir / filename
                    with open(output_path, 'wb') as f:
                        for chunk in file_resp.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                    self.config.logger.info(f"Video saved: {output_path}")
                    return str(output_path)
                elif state in ('failed', 'error'):
                    self.config.logger.error(f"Video task failed {task_uuid}: {status_data}")
                    return None
                time.sleep(5)
            self.config.logger.error(f"Video task timeout {task_uuid}, last state: {last_state}")
            return None
            
        except requests.exceptions.RequestException as e:
            print(f"Network error during video generation: {str(e)}")
            return None
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {str(e)}")
            return None
        except Exception as e:
            print(f"Unexpected error during video generation: {str(e)}")
            return None
            
    def validate_api_key(self) -> bool:
        """Validate availability of Duomi proxy key or OpenAI key."""
        try:
            return bool(self.config.duomi_api_key or self.config.openai_api_key)
        
        except Exception as e:
            self.config.logger.error(f"Video API key validation error: {str(e)}")
            return False

    def resume_video_task(self, task: Task) -> str | None:
        """Resume polling for a previously submitted video task using remote_task_id."""
        try:
            if not task.remote_task_id:
                return None
            headers = {'Authorization': self.config.duomi_api_key or ''}
            import time
            status_url = self.config.openai_sora2_status.replace('{task_id}', task.remote_task_id)
            deadline = time.time() + 15 * 60
            last_state = None
            while time.time() < deadline:
                status_resp = self.session.get(status_url, headers=headers, timeout=15)
                if status_resp.status_code != 200:
                    self.config.logger.warning(f"Video status {task.remote_task_id} HTTP {status_resp.status_code}")
                    time.sleep(5)
                    continue
                status_data = status_resp.json()
                data = status_data.get('data') or status_data
                state = data.get('state') or status_data.get('state')
                last_state = state
                if state == 'succeeded':
                    videos = (data.get('data') or {}).get('videos') or data.get('videos') or []
                    if not videos:
                        self.config.logger.error(f"Video succeeded but no videos field: {status_data}")
                        return None
                    url = videos[0].get('url')
                    if not url:
                        self.config.logger.error(f"Video url missing: {status_data}")
                        return None
                    file_resp = self.session.get(url, stream=True, timeout=600)
                    if file_resp.status_code != 200:
                        self.config.logger.error(f"Video download error HTTP {file_resp.status_code}")
                        return None
                    from datetime import datetime
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = f"video_{task.id}_{timestamp}.mp4"
                    output_path = self.config.output_dir / filename
                    with open(output_path, 'wb') as f:
                        for chunk in file_resp.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                    self.config.logger.info(f"Video recovered and saved: {output_path}")
                    return str(output_path)
                elif state in ('failed', 'error'):
                    self.config.logger.error(f"Recovered video task failed {task.remote_task_id}: {status_data}")
                    return None
                time.sleep(5)
            self.config.logger.error(f"Recovered video task timeout {task.remote_task_id}, last state: {last_state}")
            return None
        except Exception as e:
            self.config.logger.error(f"Resume video task error: {e}")
            return None
