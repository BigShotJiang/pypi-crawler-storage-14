class MirandaStopCurrentIterator(Exception):
    pass
