# django_core_micha/api_urls.py
from django.urls import path, include
from django_core_micha.auth.views import csrf_token_view
from django_core_micha.invitations.views import PasswordResetConfirmView
from django_core_micha.invitations import urls as invitations_urls

urlpatterns = [
    path("auth/", include("allauth.headless.urls")),
    path("csrf/", csrf_token_view, name="csrf-token"),
    path(
        "users/password-reset/<uidb64>/<token>/", PasswordResetConfirmView.as_view(), name="password-reset-api"),
    # Access-Code-API der Lib:
    path("", include(invitations_urls)),
]
