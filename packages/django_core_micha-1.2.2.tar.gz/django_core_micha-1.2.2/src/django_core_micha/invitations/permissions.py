# django_core_micha/invitations/permissions.py
from django.conf import settings


def user_has_access_code_admin_rights(user) -> bool:
    """
    Returns True if a user is allowed to manage access codes.
    Default: superuser/staff or profile.role in ACCESS_CODE_ADMIN_ROLES.
    """
    if not user or not user.is_authenticated:
        return False

    if user.is_superuser or user.is_staff:
        return True

    allowed_roles = getattr(settings, "ACCESS_CODE_ADMIN_ROLES", ("admin",))
    profile = getattr(user, "profile", None)
    role = getattr(profile, "role", None)

    return role in allowed_roles
