#### Pre-LLM
  - [Spotlight](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/altk/pre_llm/spotlight/README.md)
#### Pre-tool
  - [Refraction](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/altk/pre_tool/refraction/README.md)
  - [SPARC](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/altk/pre_tool/sparc/README.md)
#### Post-tool
  - [JSON Processor](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/altk/post_tool/code_generation/README.md)
  - [RAG Repair](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/altk/post_tool/rag_repair/README.md)
  - [Silent Review](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/altk/post_tool/silent_review/README.md)
#### Pre-response
  - [Policy Guard](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/altk/pre_response/policy_guard/README.md)
