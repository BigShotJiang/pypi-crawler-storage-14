# Examples

1. [Spotlight Jupyter Notebook]( https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/examples/spotlight.ipynb)
2. [SPARC Example](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/examples/langgraph_agent_sparc_example.py)
3. [JSON Processor Jupyter Notebook](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/examples/json_processor_getting_started.ipynb)
4. [RAG Repair Jupyter Notebook]( https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/examples/rag_repair.ipynb)
5. [Silent Review Jupyter Notebook](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/examples/silent_review.ipynb)
6. [Policy Guard Jupyter Notebook](https://github.com/AgentToolkit/agent-lifecycle-toolkit/blob/main/examples/policy_guard_example.ipynb)
