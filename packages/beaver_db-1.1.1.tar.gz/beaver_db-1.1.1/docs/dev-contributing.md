# Future Roadmap & Contributing

**Chapter Outline:**

* **12.1. The Future of BeaverDB**
    * The `BeaverClient` as a drop-in network client.
    * Replacing `faiss` with a simpler, pure-`numpy` linear search.
* **12.2. How to Contribute**
    * (Standard contribution guidelines, linking to Makefile, etc.)
