__extension_version__ = "0.55.1"
__extension_name__ = "pytket-quantinuum"
