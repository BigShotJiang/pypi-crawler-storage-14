from edgy.core.tenancy.utils import create_schema, create_tables

__all__ = [
    "create_tables",
    "create_schema",
]
