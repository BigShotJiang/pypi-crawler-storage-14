"""Streaming engine shared utilities."""

__all__ = ["sinks"]
