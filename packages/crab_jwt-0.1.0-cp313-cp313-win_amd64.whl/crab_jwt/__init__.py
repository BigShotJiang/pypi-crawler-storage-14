"""
crab-jwt: Minimal JWT/JWKS library with RS256 support

A fast, secure JWT library powered by Rust.

Example:
    >>> from crab_jwt import KeyPair, JwtBuilder, verify
    >>>
    >>> # Generate keys
    >>> keys = KeyPair.generate()
    >>>
    >>> # Create token
    >>> token = (JwtBuilder()
    ...     .subject("user123")
    ...     .issuer("my-app")
    ...     .expiration_in(3600)
    ...     .sign(keys))
    >>>
    >>> # Verify token
    >>> claims = verify(token, keys.to_public_pem())
    >>> print(claims.sub)
    user123
"""

from crab_jwt._crab_jwt import (
    KeyPair,
    Claims,
    JwtBuilder,
    Jwks,
    verify,
    verify_with_jwks,
)

__all__ = [
    "KeyPair",
    "Claims",
    "JwtBuilder",
    "Jwks",
    "verify",
    "verify_with_jwks",
]

__version__ = "0.1.0"
