use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};
use rsa::pkcs8::DecodePublicKey;
use std::collections::HashMap;

/// Convert crab_jwt::Error to PyErr
fn to_py_err(e: crab_jwt::Error) -> PyErr {
    PyValueError::new_err(e.to_string())
}

/// RSA key pair for signing and verifying JWTs
#[pyclass]
pub struct KeyPair {
    inner: crab_jwt::KeyPair,
}

#[pymethods]
impl KeyPair {
    /// Generate a new RSA 2048-bit key pair
    #[staticmethod]
    fn generate() -> PyResult<Self> {
        let inner = crab_jwt::KeyPair::generate().map_err(to_py_err)?;
        Ok(Self { inner })
    }

    /// Import key pair from a private key PEM string
    #[staticmethod]
    fn from_private_pem(pem: &str) -> PyResult<Self> {
        let inner = crab_jwt::KeyPair::from_private_pem(pem).map_err(to_py_err)?;
        Ok(Self { inner })
    }

    /// Export private key to PEM format
    fn to_private_pem(&self) -> PyResult<String> {
        self.inner.to_private_pem().map_err(to_py_err)
    }

    /// Export public key to PEM format
    fn to_public_pem(&self) -> PyResult<String> {
        self.inner.to_public_pem().map_err(to_py_err)
    }
}

/// JWT Claims
#[pyclass]
pub struct Claims {
    inner: crab_jwt::Claims,
}

#[pymethods]
impl Claims {
    /// Subject claim
    #[getter]
    fn sub(&self) -> Option<String> {
        self.inner.sub.clone()
    }

    /// Issuer claim
    #[getter]
    fn iss(&self) -> Option<String> {
        self.inner.iss.clone()
    }

    /// Audience claim
    #[getter]
    fn aud(&self) -> Option<String> {
        self.inner.aud.clone()
    }

    /// Expiration time (Unix timestamp)
    #[getter]
    fn exp(&self) -> Option<u64> {
        self.inner.exp
    }

    /// Issued at time (Unix timestamp)
    #[getter]
    fn iat(&self) -> Option<u64> {
        self.inner.iat
    }

    /// Not before time (Unix timestamp)
    #[getter]
    fn nbf(&self) -> Option<u64> {
        self.inner.nbf
    }

    /// JWT ID
    #[getter]
    fn jti(&self) -> Option<String> {
        self.inner.jti.clone()
    }

    /// Check if the token has expired
    fn is_expired(&self) -> bool {
        self.inner.is_expired()
    }

    /// Check if the token is valid based on time (exp and nbf)
    fn is_valid_time(&self) -> bool {
        self.inner.is_valid_time()
    }

    /// Get a custom claim value
    fn get(&self, py: Python<'_>, key: &str) -> Option<PyObject> {
        self.inner.custom.get(key).map(|v| json_to_py(py, v))
    }

    /// Get all custom claims as a dict
    fn custom_claims(&self, py: Python<'_>) -> PyResult<PyObject> {
        let dict = PyDict::new_bound(py);
        for (k, v) in &self.inner.custom {
            dict.set_item(k, json_to_py(py, v))?;
        }
        Ok(dict.into())
    }

    fn __repr__(&self) -> String {
        format!(
            "Claims(sub={:?}, iss={:?}, exp={:?})",
            self.inner.sub, self.inner.iss, self.inner.exp
        )
    }
}

/// Convert serde_json::Value to Python object
fn json_to_py(py: Python<'_>, value: &serde_json::Value) -> PyObject {
    match value {
        serde_json::Value::Null => py.None(),
        serde_json::Value::Bool(b) => b.to_object(py),
        serde_json::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                i.to_object(py)
            } else if let Some(f) = n.as_f64() {
                f.to_object(py)
            } else {
                py.None()
            }
        }
        serde_json::Value::String(s) => s.to_object(py),
        serde_json::Value::Array(arr) => {
            let list = PyList::new_bound(py, arr.iter().map(|v| json_to_py(py, v)));
            list.to_object(py)
        }
        serde_json::Value::Object(obj) => {
            let dict = PyDict::new_bound(py);
            for (k, v) in obj {
                let _ = dict.set_item(k, json_to_py(py, v));
            }
            dict.to_object(py)
        }
    }
}

/// Convert Python object to serde_json::Value
fn py_to_json(obj: &Bound<'_, PyAny>) -> PyResult<serde_json::Value> {
    if obj.is_none() {
        Ok(serde_json::Value::Null)
    } else if let Ok(b) = obj.extract::<bool>() {
        Ok(serde_json::Value::Bool(b))
    } else if let Ok(i) = obj.extract::<i64>() {
        Ok(serde_json::Value::Number(i.into()))
    } else if let Ok(f) = obj.extract::<f64>() {
        Ok(serde_json::Number::from_f64(f)
            .map(serde_json::Value::Number)
            .unwrap_or(serde_json::Value::Null))
    } else if let Ok(s) = obj.extract::<String>() {
        Ok(serde_json::Value::String(s))
    } else if let Ok(dict) = obj.downcast::<PyDict>() {
        let mut map = serde_json::Map::new();
        for (k, v) in dict.iter() {
            let key: String = k.extract()?;
            map.insert(key, py_to_json(&v)?);
        }
        Ok(serde_json::Value::Object(map))
    } else if let Ok(list) = obj.downcast::<PyList>() {
        let arr: Result<Vec<_>, _> = list.iter().map(|o| py_to_json(&o)).collect();
        Ok(serde_json::Value::Array(arr?))
    } else {
        // Try to convert to string as fallback
        if let Ok(s) = obj.str() {
            Ok(serde_json::Value::String(s.to_string()))
        } else {
            Err(PyValueError::new_err("Unsupported type for claim value"))
        }
    }
}

/// Builder for creating JWT tokens
#[pyclass]
pub struct JwtBuilder {
    sub: Option<String>,
    iss: Option<String>,
    aud: Option<String>,
    exp: Option<u64>,
    iat: Option<u64>,
    nbf: Option<u64>,
    jti: Option<String>,
    custom: HashMap<String, serde_json::Value>,
}

#[pymethods]
impl JwtBuilder {
    /// Create a new JWT builder
    #[new]
    fn new() -> Self {
        Self {
            sub: None,
            iss: None,
            aud: None,
            exp: None,
            iat: None,
            nbf: None,
            jti: None,
            custom: HashMap::new(),
        }
    }

    /// Set the subject claim
    fn subject(mut slf: PyRefMut<'_, Self>, sub: String) -> PyRefMut<'_, Self> {
        slf.sub = Some(sub);
        slf
    }

    /// Set the issuer claim
    fn issuer(mut slf: PyRefMut<'_, Self>, iss: String) -> PyRefMut<'_, Self> {
        slf.iss = Some(iss);
        slf
    }

    /// Set the audience claim
    fn audience(mut slf: PyRefMut<'_, Self>, aud: String) -> PyRefMut<'_, Self> {
        slf.aud = Some(aud);
        slf
    }

    /// Set the expiration time (Unix timestamp)
    fn expiration(mut slf: PyRefMut<'_, Self>, exp: u64) -> PyRefMut<'_, Self> {
        slf.exp = Some(exp);
        slf
    }

    /// Set expiration to current time + seconds
    fn expiration_in(mut slf: PyRefMut<'_, Self>, seconds: u64) -> PyRefMut<'_, Self> {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        slf.exp = Some(now + seconds);
        slf
    }

    /// Set the issued at time (Unix timestamp)
    fn issued_at(mut slf: PyRefMut<'_, Self>, iat: u64) -> PyRefMut<'_, Self> {
        slf.iat = Some(iat);
        slf
    }

    /// Set issued at to current time
    fn issued_now(mut slf: PyRefMut<'_, Self>) -> PyRefMut<'_, Self> {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        slf.iat = Some(now);
        slf
    }

    /// Set the not before time (Unix timestamp)
    fn not_before(mut slf: PyRefMut<'_, Self>, nbf: u64) -> PyRefMut<'_, Self> {
        slf.nbf = Some(nbf);
        slf
    }

    /// Set the JWT ID
    fn jwt_id(mut slf: PyRefMut<'_, Self>, jti: String) -> PyRefMut<'_, Self> {
        slf.jti = Some(jti);
        slf
    }

    /// Add a custom claim
    fn claim(&mut self, key: String, value: &Bound<'_, PyAny>) -> PyResult<()> {
        let json_value = py_to_json(value)?;
        self.custom.insert(key, json_value);
        Ok(())
    }

    /// Sign the JWT with a private key and return the token string
    fn sign(&self, keys: &KeyPair) -> PyResult<String> {
        let mut builder = crab_jwt::Jwt::builder();

        if let Some(ref sub) = self.sub {
            builder = builder.subject(sub);
        }
        if let Some(ref iss) = self.iss {
            builder = builder.issuer(iss);
        }
        if let Some(ref aud) = self.aud {
            builder = builder.audience(aud);
        }
        if let Some(exp) = self.exp {
            builder = builder.expiration(exp);
        }
        if let Some(iat) = self.iat {
            builder = builder.issued_at(iat);
        }
        if let Some(nbf) = self.nbf {
            builder = builder.not_before(nbf);
        }
        if let Some(ref jti) = self.jti {
            builder = builder.jwt_id(jti);
        }
        for (key, value) in &self.custom {
            builder = builder.claim(key, value.clone());
        }

        builder.sign(&keys.inner.private).map_err(to_py_err)
    }
}

/// JSON Web Key Set
#[pyclass]
pub struct Jwks {
    inner: crab_jwt::Jwks,
}

#[pymethods]
impl Jwks {
    /// Create a new empty JWKS
    #[new]
    fn new() -> Self {
        Self {
            inner: crab_jwt::Jwks::new(),
        }
    }

    /// Create JWKS from a public key PEM
    #[staticmethod]
    fn from_public_key(public_pem: &str, kid: &str) -> PyResult<Self> {
        let public_key = crab_jwt::RsaPublicKey::from_public_key_pem(public_pem)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        let inner = crab_jwt::Jwks::from_public_key(&public_key, kid).map_err(to_py_err)?;
        Ok(Self { inner })
    }

    /// Parse JWKS from JSON string
    #[staticmethod]
    fn from_json(json: &str) -> PyResult<Self> {
        let inner = crab_jwt::Jwks::from_json(json).map_err(to_py_err)?;
        Ok(Self { inner })
    }

    /// Add a key to the JWKS
    fn add_key(&mut self, public_pem: &str, kid: &str) -> PyResult<()> {
        let public_key = crab_jwt::RsaPublicKey::from_public_key_pem(public_pem)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        self.inner.add_key(&public_key, kid).map_err(to_py_err)
    }

    /// Serialize to JSON string
    fn to_json(&self) -> String {
        self.inner.to_json()
    }

    /// Get key IDs
    fn key_ids(&self) -> Vec<String> {
        self.inner.keys.iter().map(|k| k.kid.clone()).collect()
    }

    /// Number of keys
    fn __len__(&self) -> usize {
        self.inner.keys.len()
    }

    fn __repr__(&self) -> String {
        format!("Jwks(keys={})", self.inner.keys.len())
    }
}

/// Verify a JWT token and return the claims
#[pyfunction]
fn verify(token: &str, public_pem: &str) -> PyResult<Claims> {
    let public_key = crab_jwt::RsaPublicKey::from_public_key_pem(public_pem)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    let inner = crab_jwt::Jwt::verify(token, &public_key).map_err(to_py_err)?;
    Ok(Claims { inner })
}

/// Verify a JWT token using a JWKS and key ID
#[pyfunction]
fn verify_with_jwks(token: &str, jwks: &Jwks, kid: &str) -> PyResult<Claims> {
    let public_key = jwks.inner.get_key(kid).map_err(to_py_err)?;
    let inner = crab_jwt::Jwt::verify(token, &public_key).map_err(to_py_err)?;
    Ok(Claims { inner })
}

/// Python module
#[pymodule]
fn _crab_jwt(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<KeyPair>()?;
    m.add_class::<Claims>()?;
    m.add_class::<JwtBuilder>()?;
    m.add_class::<Jwks>()?;
    m.add_function(wrap_pyfunction!(verify, m)?)?;
    m.add_function(wrap_pyfunction!(verify_with_jwks, m)?)?;
    Ok(())
}
