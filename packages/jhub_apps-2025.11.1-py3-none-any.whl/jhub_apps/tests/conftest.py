pytest_plugins = ["jhub_apps.tests.common.api_fixtures"]
