# codefusion/ui/interactive.py
import typing as t
from pathlib import Path
import pyperclip
import logging
import sys

from ..core.app import CodeFusionApp
from .preview import display_file_preview

logger = logging.getLogger(__name__)

try:
    from rich.console import Console
    from rich.prompt import Confirm, Prompt, IntPrompt
    from rich.panel import Panel
    from rich.text import Text
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

def interactive_compilation_flow(app: CodeFusionApp) -> bool:
    if not RICH_AVAILABLE:
        # Fallback for non-rich environments (if any, though it's a dependency)
        print("Rich library not found. Interactive mode degraded.")
        return simple_interactive_flow(app)

    console = Console()
    
    while True:
        # 1. Scan
        files_to_process, final_extensions = app.scan()

        if not files_to_process:
            console.print("[red]❌ No files found to process![/red]")
            # We allow user to go to options even if no files found, to maybe fix filters
            if not Confirm.ask("Go to options to adjust filters?", default=True):
                 return False
            if not interactive_options_menu(app, console):
                return False
            continue

        # 2. Preview
        display_file_preview(files_to_process, app.root_dir, final_extensions)

        # 3. Estimate Tokens (Rough approximation: 4 chars per token)
        total_size = sum(f.stat().st_size for f in files_to_process if f.exists())
        est_tokens = total_size / 4
        console.print(f"[dim]Estimated Tokens: ~{int(est_tokens):,}[/dim]")

        # 4. Prompt
        console.print("\n[bold]Actions:[/bold]")
        console.print("  [green]y[/green] : Proceed with compilation")
        console.print("  [yellow]o[/yellow] : Options (Filters, Output, Clipboard)")
        console.print("  [red]n[/red] : Cancel and Exit")

        choice = Prompt.ask("Choose an action", choices=["y", "n", "o"], default="y")

        if choice == "n":
            console.print("[yellow]⏸️  Compilation cancelled by user.[/yellow]")
            return False
        elif choice == "o":
            interactive_options_menu(app, console)
            # Loop back to scan/preview
            continue
        elif choice == "y":
            # Proceed
            success = app.writer.write(files_to_process, final_extensions)

            if success and app.copy_to_clipboard:
                if app.output_file and app.output_file.exists():
                    try:
                        content = app.output_file.read_text(encoding='utf-8')
                        pyperclip.copy(content)
                        console.print(Panel("[bold green]✅ Content copied to clipboard![/bold green]", title="Clipboard"))
                    except Exception as e:
                        console.print(f"[red]Failed to copy to clipboard: {e}[/red]")
                else:
                    console.print("[yellow]Output not file-based, cannot copy to clipboard automatically.[/yellow]")

            return success

def interactive_options_menu(app: CodeFusionApp, console) -> bool:
    """
    Displays and handles the options menu.
    """
    while True:
        console.clear()
        console.print(Panel("[bold blue]⚙️  Configuration Options[/bold blue]"))

        # Current State Display
        console.print(f"[1] Output File: [cyan]{app.output_file or 'STDOUT'}[/cyan]")
        console.print(f"[2] Copy to Clipboard: [{'green' if app.copy_to_clipboard else 'red'}]{'ON' if app.copy_to_clipboard else 'OFF'}[/]")

        ext_str = ", ".join(sorted(app.file_filter.user_extensions)) if app.file_filter.user_extensions else "Auto-detect"
        console.print(f"[3] Extensions: [cyan]{ext_str}[/cyan]")

        console.print(f"[4] Include Empty Files: [{'green' if app.file_filter.include_empty else 'red'}]{'YES' if app.file_filter.include_empty else 'NO'}[/]")
        console.print(f"[5] Output Template: [cyan]{app.writer.template}[/cyan]")
        console.print(f"[6] Ignore File: [cyan]{app.ignore_manager.ignore_file_name}[/cyan]")

        console.print("\n[0] ↩️  Done / Back to Preview")
        console.print("[x] ❌ Exit Application")

        choice = Prompt.ask("Select an option", choices=["0", "x", "1", "2", "3", "4", "5", "6"], default="0")

        if choice == "0":
            break

        elif choice == "x":
            console.print("[yellow]Exiting application...[/yellow]")
            sys.exit(0)

        elif choice == "1":
            console.print("[dim](Leave empty to keep current)[/dim]")
            new_path = Prompt.ask("Enter new output path (or 'stdout')")
            if not new_path.strip():
                continue

            if new_path.lower() == 'stdout':
                app.output_file = None
                app.writer.output_file = None
                app.writer.to_stdout = True
            else:
                app.output_file = Path(new_path)
                app.writer.output_file = Path(new_path)
                app.writer.to_stdout = False
                # Update ignore manager output file so it doesn't scan the output file
                app.ignore_manager.output_file = app.output_file

        elif choice == "2":
            app.copy_to_clipboard = not app.copy_to_clipboard

        elif choice == "3":
            console.print("[dim](Leave empty to keep current, enter 'auto' for auto-detect)[/dim]")
            current = " ".join(sorted(app.file_filter.user_extensions)) if app.file_filter.user_extensions else ""
            new_exts = Prompt.ask("Enter extensions (space separated, e.g., 'py js')", default=current)

            # If user enters nothing but the prompt had a default, Prompt returns the default.
            # To allow cancelling, Prompt.ask behaves such that default is returned on empty input.
            # This is tricky. If they want to cancel, they might just hit enter, but that returns 'current'.
            # If they want to CLEAR, they need to type something specific?
            # Actually, Prompt.ask returns the default if input is empty.
            # Let's change the logic:
            # To switch to auto-detect, user must type 'auto'.
            # To keep current, they just hit enter (which returns current).

            if new_exts.strip().lower() == 'auto':
                app.file_filter.user_extensions = None
                app.scanner.file_filter.user_extensions = None
            elif new_exts.strip():
                 # Ensure leading dots
                ext_set = {f".{ext.lstrip('.')}" for ext in new_exts.split()}
                app.file_filter.user_extensions = ext_set
                app.scanner.file_filter.user_extensions = ext_set

        elif choice == "4":
            app.file_filter.include_empty = not app.file_filter.include_empty
            app.scanner.file_filter.include_empty = app.file_filter.include_empty

        elif choice == "5":
            new_template = Prompt.ask("Select template", choices=["default", "markdown", "html", "json"], default=app.writer.template)
            app.writer.template = new_template

        elif choice == "6":
            console.print("[dim](Leave empty to keep current)[/dim]")
            new_ignore = Prompt.ask("Enter ignore file name", default=app.ignore_manager.ignore_file_name)
            if new_ignore.strip():
                app.ignore_manager.ignore_file_name = new_ignore.strip()
                # Reload ignore patterns
                app.ignore_manager._load_patterns()

    return True

def simple_interactive_flow(app: CodeFusionApp) -> bool:
    """Fallback for non-rich environments."""
    files_to_process, final_extensions = app.scan()
    if not files_to_process:
        print("❌ No files found to process!")
        return False

    display_file_preview(files_to_process, app.root_dir, final_extensions)
    
    response = input("\n🚀 Proceed with compilation? (Y/n): ").strip().lower()
    if response in ('', 'y', 'yes'):
        return app.writer.write(files_to_process, final_extensions)
    return False
