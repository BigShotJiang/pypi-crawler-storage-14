# Static version file
__version__ = "1.0.4"
version = "1.0.4"
__version_tuple__ = (1, 0, 4)
version_tuple = (1, 0, 4)
