"""WISTX MCP Server - Model Context Protocol server for DevOps."""

__version__ = "0.1.0"

