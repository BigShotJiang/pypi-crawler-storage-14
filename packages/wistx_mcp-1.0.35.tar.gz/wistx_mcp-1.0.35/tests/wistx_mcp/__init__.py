"""Tests for wistx_mcp package."""

