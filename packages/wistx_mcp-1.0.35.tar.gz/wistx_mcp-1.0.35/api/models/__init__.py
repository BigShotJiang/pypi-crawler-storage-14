"""Pydantic models."""

