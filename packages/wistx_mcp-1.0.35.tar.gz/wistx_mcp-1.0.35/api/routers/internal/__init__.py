"""Internal admin endpoints."""

from api.routers.internal import admin, webhooks, github_webhooks

__all__ = ["admin", "webhooks", "github_webhooks"]

