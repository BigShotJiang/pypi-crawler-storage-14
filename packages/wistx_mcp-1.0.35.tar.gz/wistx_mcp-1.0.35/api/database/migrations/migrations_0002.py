"""Migration 0002 import."""

from api.database.migrations.migrations_0002_add_custom_compliance_fields import (
    Migration0002AddCustomComplianceFields,
)

__all__ = ["Migration0002AddCustomComplianceFields"]




