🚀 athul-nair

pip install athul-nair — An interactive CLI portfolio for Athul Nair
View AI/ML projects, Flutter apps, experience, skills, and more — directly from the terminal.

📦 Installation
pip install athul-nair
athul

🧪 CLI Commands
Command	Description
athul	Show summary (default view)
athul info	About + contact info
athul skills	List all skills
athul experience	Show work experience
athul projects	Show all projects
athul projects --group ai	Only AI/ML projects
athul projects --group flutter	Only Flutter apps
athul contact	Contact details
athul json	Raw JSON profile
athul list	List all commands
athul credits	Fun easter-egg message
👤 About Me

I am an AI/ML and Flutter developer focused on building intelligent systems, NLP applications, automation workflows, and scalable MLOps-ready pipelines.

My background includes marketing, creative design, technical leadership, and guiding large groups — strengthening my communication and leadership abilities.

I enjoy building Gen-Z styled apps, automation tools, predictive AI models, and complete ML pipelines from development to deployment.

💼 Experience
Marketing Intern — Hugg.co.in

Worked on brand awareness, digital marketing strategy, and campaign execution.

Graphic Designer — KingHills Travel

Designed travel posters, social media creatives, and promotional content.

CTO — Department of Entrepreneurship

Managed technology operations for 180+ innovation & startup events.

Trip Leader — Guided a Group of 80 People

Handled coordination, problem-solving, and logistics for a large travel group.

🧠 Skills
AI / ML / MLOps

ML, Deep Learning, CNNs

NLP

TensorFlow, OpenCV

ML Pipelines, MLOps (learning)

RAG, Vector Databases

FastAPI

Automation

n8n Automations

Google Sheets API

REST APIs

Programming Languages

Python, Java, C, C++, SQL, Dart

App Development

Flutter

Android (XML, Jetpack Compose)

Tailwind, Bootstrap, HTML5, CSS3

Backend / Cloud

Firebase

Supabase

Docker

Google Cloud

Tools

Git, GitHub

Linux

VS Code, PyCharm

🚀 Projects
🔹 AI / ML Projects
VisionWear – Fashion Image Classifier (CNN)

90%+ accuracy fashion classifier using TensorFlow + CNN pipeline.

Attendify Vision – AI Attendance (OpenCV + Sheets)

Real-time face attendance with auto-logging to Google Sheets.

StackOverflow Language Classifier (CNN + NLP)

Predicts programming languages based on StackOverflow text.

Train Delay Prediction

ML-based train delay prediction system using API data.

AI Process Analyzer

AI-powered system performance analyzer for bottleneck detection.

Smart Shopping Cart (Computer Vision)

Automatically detects cart items using CV and generates bills.

🔹 Flutter App Development
UniMeet – Productivity & Scheduling App

Find common free time, real-time class info, AI avatars, Gen-Z UI.

LivinKey – PG Complaint App (Freelance)

End-to-end tenant complaint management with live updates.

Cosmic – Flame Engine Game

Space shooter game that lets a spaceship destroy user-uploaded images.

Agris – Smart Task Manager

Voice-powered task manager with alarms, routines, and progress tracking.

📫 Contact

Email: athulnair983@gmail.com

GitHub: https://github.com/Athul-n-air

LinkedIn: https://www.linkedin.com/in/athul-nair-ai/

📄 License

This project is licensed under the MIT License.