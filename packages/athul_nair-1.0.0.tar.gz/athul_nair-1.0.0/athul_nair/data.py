# athul_nair/data.py

PROFILE = {
    "name": "Athul Nair",
    "title": "AI/ML Developer · Flutter Developer · Automation Engineer",

    "about": [
        "I am an AI/ML and Flutter developer focused on building intelligent systems, NLP applications, "
        "automation workflows, and scalable MLOps-ready pipelines.",
        "My background includes marketing, creative design, technical leadership, and guiding large groups, "
        "which strengthens my communication and leadership skills.",
        "I enjoy creating Gen-Z styled applications, predictive AI models, automation tools, and complete ML pipelines "
        "from development to deployment."
    ],

    "contact": {
        "email": "athulnair983@gmail.com",
        "github": "https://github.com/Athul-n-air",
        "linkedin": "https://www.linkedin.com/in/athul-nair-ai/",
    },

    "experience": [
        {
            "role": "Marketing Intern",
            "company": "Hugg.co.in",
            "description": "Worked on digital marketing strategy, brand growth, and campaign execution."
        },
        {
            "role": "Graphic Designer",
            "company": "KingHills Travel",
            "description": "Designed travel posters, graphics, and promotional creatives."
        },
        {
            "role": "CTO",
            "company": "Department of Entrepreneurship",
            "description": "Led technical operations for 180+ entrepreneurship events, guiding innovation and execution."
        },
        {
            "role": "Trip Leader",
            "company": "Independent",
            "description": "Guided a group trip of 80 people, demonstrating strong leadership and coordination skills."
        },
    ],

    "skills": {
        "ai_ml_mlopsl": [
            "Machine Learning", "Deep Learning", "CNNs", "NLP",
            "TensorFlow", "OpenCV",
            "ML Pipelines", "MLOps (learning)",
            "VectorDBs", "RAG", "FastAPI"
        ],
        "automation": [
            "n8n Automations",
            "Google Sheets API",
            "REST APIs"
        ],
        "languages": [
            "Python",
            "Java",
            "C", "C++",
            "SQL",
            "Dart (Flutter)"
        ],
        "frontend_appdev": [
            "Flutter",
            "Android (XML + Jetpack Compose)",
            "Tailwind CSS", "Bootstrap",
            "HTML5", "CSS3"
        ],
        "backend_cloud": [
            "Firebase",
            "Supabase",
            "Docker",
            "Google Cloud Tools"
        ],
        "tools": [
            "Git", "GitHub",
            "Linux",
            "VS Code", "PyCharm"
        ]
    },

    "projects": {
        "ai_ml": [
            {
                "name": "VisionWear – Fashion Image Classifier",
                "tech": ["TensorFlow", "CNN", "Python"],
                "description": "90%+ accuracy fashion classifier with full preprocessing, training, and evaluation pipeline."
            },
            {
                "name": "Attendify Vision – AI Attendance System",
                "tech": ["OpenCV", "Python", "Google Sheets API"],
                "description": "Real-time face attendance system with Google Sheets automation."
            },
            {
                "name": "StackOverflow Language Classifier",
                "tech": ["TensorFlow", "CNN", "NLP"],
                "description": "CNN + NLP classifier that predicts programming languages from StackOverflow text."
            },
            {
                "name": "Train Delay Prediction System",
                "tech": ["Python", "Machine Learning"],
                "description": "Predicts train delays using ML models combined with API-based real-time data."
            },
            {
                "name": "AI Process Analyzer",
                "tech": ["Python", "System Monitoring"],
                "description": "Analyzes system processes to detect performance bottlenecks using AI heuristics."
            },
            {
                "name": "Smart Shopping Cart (Computer Vision)",
                "tech": ["Python", "Computer Vision"],
                "description": "Computer vision powered cart that auto-detects items for instant billing."
            },
        ],

        "flutter_apps": [
            {
                "name": "UniMeet – College Productivity App",
                "tech": ["Flutter", "Firebase"],
                "description": "Connect with friends using codes, find free time, track classes; includes AI-generated avatars."
            },
            {
                "name": "LivinKey – PG Complaint Management App",
                "tech": ["Flutter", "Firebase"],
                "description": "Tenant → Owner complaint system with real-time updates and dashboard view."
            },
            {
                "name": "Cosmic – Flame Engine Game",
                "tech": ["Flutter", "Flame Engine"],
                "description": "Space shooter game where a spaceship destroys user-uploaded images piece by piece."
            },
            {
                "name": "Agris – Smart Task Managing App",
                "tech": ["Flutter", "Riverpod"],
                "description": "Voice-powered task manager with alarms, routines, and progress tracking."
            }
        ]
    }
}
