# athul_nair/cli.py

import argparse
import json
from textwrap import indent
from .data import PROFILE

LINE = "=" * 60


def print_header():
    print(LINE)
    print(f"{PROFILE['name']} - {PROFILE['title']}")
    print(LINE)
    print()


# ---------------------- INFO COMMAND ---------------------- #

def cmd_info(args):
    print_header()
    print("About:")
    for line in PROFILE["about"]:
        print(indent(line, "  "))
    print()

    print("Contact:")
    for key, val in PROFILE["contact"].items():
        print(f"  {key.title():10}: {val}")
    print()


# ---------------------- SKILLS COMMAND ---------------------- #

def cmd_skills(args):
    print_header()
    print("Skills:\n")

    skills = PROFILE["skills"]

    labels = {
        "ai_ml_mlopsl": "AI / ML / MLOps",
        "automation": "Automation & Integrations",
        "languages": "Programming Languages",
        "frontend_appdev": "App & Frontend Development",
        "backend_cloud": "Backend & Cloud",
        "tools": "Tools",
    }

    for key, title in labels.items():
        print(f"- {title}:")
        for item in skills[key]:
            print(f"    • {item}")
        print()


# ---------------------- EXPERIENCE COMMAND ---------------------- #

def cmd_experience(args):
    print_header()
    print("Experience:\n")

    for exp in PROFILE["experience"]:
        print(f"- {exp['role']} — {exp['company']}")
        print(f"  {exp['description']}")
        print()


# ---------------------- PROJECTS COMMAND ---------------------- #

def _print_projects(group, title):
    print_header()
    print(f"{title}:\n")

    for p in group:
        print(f"- {p['name']}")
        print(f"  Tech: {', '.join(p['tech'])}")
        print(f"  {p['description']}")
        print()


def cmd_projects(args):
    if args.group == "ai":
        _print_projects(PROFILE["projects"]["ai_ml"], "AI / ML Projects")
    elif args.group == "flutter":
        _print_projects(PROFILE["projects"]["flutter_apps"], "Flutter App Projects")
