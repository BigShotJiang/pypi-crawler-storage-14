# pandas-tibble [![PyPI Version](https://img.shields.io/pypi/v/pandas-tibble.svg)](https://pypi.org/project/pandas-tibble/)

![Downloads](https://img.shields.io/pypi/dm/pandas-tibble)

Display pandas DataFrames with R-style tibble formatting in the terminal.

## What it does

- Prints DataFrames with column type annotations (`<chr>`, `<int>`, `<dbl>`, `<date>`, `<datetime>`)
- Shows dimensions at the top
- Distinguishes between date and datetime types
- Provides glimpse() for quick column overview

## Installation

```bash
pip install pandas-tibble
```

For development:
```bash
git clone https://github.com/caspercrause/pandas-tibble.git
cd pandas-tibble
poetry install
```

## Requirements

- Python >= 3.10.0
- pandas >= 2.0.0
- rich >= 13.0.0

## Usage

### tibble()

Display DataFrame with type annotations:

```python
import pandas as pd
from pandas_tibble import tibble
from datetime import date

df = pd.DataFrame({
    'start_date': [date(2024, 1, i) for i in range(1, 6)],
    'name': ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve'],
    'value': [100, 200, 300, 400, 500]
})

tibble(df)
```

Output:
```
# A DataFrame: 5 × 3

start_date  name     value
<date>      <chr>    <int>
━━━━━━━━━━━━━━━━━━━━━━━━━━━
2024-01-01  Alice    100
2024-01-02  Bob      200
2024-01-03  Charlie  300
2024-01-04  Diana    400
2024-01-05  Eve      500
```

Options:
```python
tibble(df, max_rows=20)         # Show more rows
tibble(df, show_index=True)     # Include index column
```

### glimpse()

Quick column overview:

```python
glimpse(df)
```

Output:
```
Rows: 5
Columns: 3

start_date  <date>  2024-01-01, 2024-01-02, 2024-01-03...
name        <chr>   Alice, Bob, Charlie...
value       <int>   100, 200, 300...
```

## Type mapping

| pandas dtype | Display | Format |
|--------------|---------|---------|
| `object` (string) | `<chr>` | as-is |
| `int64` | `<int>` | as-is |
| `float64` | `<dbl>` | 2 decimals |
| `bool` | `<lgl>` | True/False |
| `datetime64[ns]` | `<datetime>` | YYYY-MM-DD HH:MM:SS |
| `object` (date) | `<date>` | YYYY-MM-DD |
| `category` | `<fctr>` | as-is |
| `timedelta64[ns]` | `<timedelta>` | as-is |

Missing values display as `NA`.

## What it doesn't do

- Does not create a Tibble class (works with standard pandas DataFrames)
- Does not modify DataFrame behavior
- Does not replicate R tibble's subsetting rules
- Does not support tibble construction syntax

This is a display library, not a DataFrame replacement.

## License

MIT

## Author

Casper Crause
