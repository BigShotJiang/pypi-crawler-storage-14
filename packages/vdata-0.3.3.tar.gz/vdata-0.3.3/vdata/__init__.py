"""Annotated, temporal and multivariate observation data."""

from importlib.metadata import metadata

from vdata.data import VData, VDataView, concatenate, convert_anndata_to_vdata
from vdata.IO import (
    IncoherenceError,
    ShapeError,
    VBaseError,
    VLockError,
)
from vdata.tdf import RepeatingIndex, TemporalDataFrame, TemporalDataFrameView
from vdata.timepoint import TimePoint

read = VData.read
read_from_csv = VData.read_from_csv
read_from_anndata = VData.read_from_anndata
read_from_pickle = VData.read_from_pickle

__version__ = metadata("vdata").get("version")


__all__ = [
    "VData",
    "TemporalDataFrame",
    "VDataView",
    "TemporalDataFrameView",
    "convert_anndata_to_vdata",
    "concatenate",
    "VBaseError",
    "ShapeError",
    "IncoherenceError",
    "VLockError",
    "TimePoint",
    "RepeatingIndex",
]
