import argparse
import traceback
from pathlib import Path

import ch5mpy as ch
from py import sys

from vdata.update.update import update_vdata


def print_err(msg: str) -> None:
    print("\033[31m[ERROR] " + msg + "\033[0m", file=sys.stderr)


def main() -> int:
    parser = argparse.ArgumentParser(prog="vdata-update", description="Update a VData from an older version")

    parser.add_argument("filename")
    parser.add_argument("-o", "--out-file", default=None, type=str)
    parser.add_argument("-v", "--verbose", default=False, action="store_true")

    args = parser.parse_args()

    data = ch.H5Dict.read(args.filename, mode=ch.H5Mode.READ_WRITE)

    ez_filename = Path(data.filename)
    ez_filename = ez_filename.with_stem("~" + ez_filename.stem)

    try:
        update_vdata(data, output_file=args.out_file, verbose=args.verbose)

    except Exception as e:
        print_err(" ".join(filter(lambda a: isinstance(a, str), e.args)))  # pyright: ignore[reportUnnecessaryIsInstance]

        if args.verbose:
            traceback.print_tb(e.__traceback__)

        return 1

    print("\033[32m[Done]\033[0m")
    return 0
