# Allow users to access the submodules of customers
