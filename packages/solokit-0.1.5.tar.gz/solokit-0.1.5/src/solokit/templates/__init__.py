"""Templates for work item specs, configuration, and test setup."""
