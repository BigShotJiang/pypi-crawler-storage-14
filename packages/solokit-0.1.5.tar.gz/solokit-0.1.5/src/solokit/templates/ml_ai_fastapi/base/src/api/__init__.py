"""
API package - contains all API routes and endpoints
"""
