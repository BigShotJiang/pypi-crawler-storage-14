from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import Header, Footer, DataTable, Static, Input, Button, TextArea
from textual.binding import Binding
from textual.screen import Screen, ModalScreen
from textual import events
from textual.message import Message
from rich.text import Text
from datetime import datetime
import asyncio
from typing import List, Optional, Set

from .core import fetch_emails, EmailMessage, AuthError
from .notifyer import notify


class EmailModal(ModalScreen):
    """A modal screen to display a single email."""

    BINDINGS = [("escape", "close_modal", "Close")]

    DEFAULT_CSS = """
        EmailModal {
            align: center middle;
        }
    """

    def __init__(self, email: EmailMessage, **kwargs):
        super().__init__(**kwargs)
        self.email = email

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-container"):
            yield Static(f"[b]From:[/b] {self.email.sender}", id="modal-from")
            yield Static(f"[b]To:[/b] {self.email.recipient}", id="modal-to")
            yield Static(f"[b]Subject:[/b] {self.email.subject}", id="modal-subject")
            yield Static(
                f"[b]Date:[/b] {self.email.date.strftime('%Y-%m-%d %H:%M:%S')}",
                id="modal-date",
            )
            yield TextArea(self.email.body, id="modal-body", read_only=True)
            yield Button("Back", variant="primary", id="back-button")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "back-button":
            self.app.pop_screen()

    def action_close_modal(self) -> None:
        self.app.pop_screen()


class ComposeModal(ModalScreen):
    """A modal screen to compose a new email."""

    DEFAULT_CSS = """
    ComposeModal {
        align: center middle;
    }
    #compose-container {
        width: 80%;
        height: 80%;
        padding: 2;
        background: $panel;
        border: thick $primary;
    }
    #compose-header {
        width: 100%;
        text-align: center;
        padding-bottom: 1;
    }
    #compose-body {
        height: 1fr;
        width: 1fr;
    }
    #compose-buttons {
        width: 100%;
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="compose-container"):
            yield Static("✍️ Compose New Email", id="compose-header")
            yield Input(placeholder="To:", id="compose-to")
            yield Input(placeholder="Subject:", id="compose-subject")
            yield TextArea(placeholder="Body:", id="compose-body")
            with Horizontal(id="compose-buttons"):
                yield Button("Send", variant="primary", id="send-button")
                yield Button("Cancel", id="cancel-button")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "send-button":
            self.app.pop_screen()
            self.app.update_status("📧 Email sent (dummy action)!")
        elif event.button.id == "cancel-button":
            self.app.pop_screen()


class NetworkErrorModal(ModalScreen):
    """A modal screen to display a network error."""

    DEFAULT_CSS = """
    NetworkErrorModal {
        align: center middle;
    }
    #error-container {
        width: 50%;
        height: auto;
        padding: 2;
        background: $error;
        border: thick $error-darken-2;
    }
    #error-title {
        width: 100%;
        text-align: center;
        padding-bottom: 1;
    }
    #error-message {
        text-align: center;
    }
    #retry-button {
        width: 100%;
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="error-container"):
            yield Static("🔌 Network Error", id="error-title")
            yield Static(
                "Could not connect to the email server. "
                "Please check your internet connection.",
                id="error-message",
            )
            yield Button("Retry", variant="error", id="retry-button")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "retry-button":
            self.app.pop_screen()
            self.app.action_refresh()


class InboxZeroApp(App):
    CSS = """
    Screen {
        background: $surface;
    }
    
    #main-container {
        height: 1fr;
        layout: vertical;
    }
    
    #top-ui {
        height: auto;
        padding: 1;
    }
    
    #search-and-compose {
        height: auto;
    }

    #email-list {
       width: 100%;
       height: 1fr;
       border: solid $primary;
   }
    
    #status-bar {
        dock: bottom;
        height: 3;
        background: $boost;
        color: $text;
        padding: 1;
    }

    #modal-container {
        width: 80%;
        height: 80%;
        padding: 1;
        background: $panel-darken-2 80%;
        border: thick $primary;
    }

    #modal-body {
        height: 1fr;
        width: 1fr;
    }
    
    #back-button {
        width: 100%;
    }
    
    #search-input {
        width: 4fr;
    }
    
    #compose-button {
        width: 1fr;
    }
    """

    BINDINGS = [
        Binding("d", "delete_email", "Delete"),
        Binding("a", "archive_email", "Archive"),
        Binding("r", "reply_email", "Reply"),
        Binding("s", "snooze_email", "Snooze"),
        Binding("enter", "open_email", "Open"),
        Binding("m", "mark_read", "Mark Read"),
        Binding("u", "mark_unread", "Mark Unread"),
        Binding("ctrl+r", "refresh", "Refresh"),
        Binding("q", "quit", "Quit"),
        Binding("?", "help", "Help"),
    ]

    def __init__(self):
        super().__init__()
        self.emails: List[EmailMessage] = []
        self.current_selection: Optional[int] = None
        self.is_loading = False
        self.notified_uids: Set[int] = set()
        self.fetch_worker = None

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        yield Header(show_clock=True)

        with Vertical(id="top-ui"):
            with Horizontal(id="search-and-compose"):
                yield Input(placeholder="Search emails...", id="search-input")
                yield Button("Compose", variant="primary", id="compose-button")

        with Vertical(id="main-container"):
            email_table = DataTable(id="email-list", cursor_type="row")
            email_table.add_columns("📧", "From", "Subject", "Date")
            yield email_table

        yield Static("Initializing...", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        """Load emails when app starts"""
        self.update_status("🔄 Connecting to email server...")
        # Start background email fetching
        self.fetch_worker = self.run_worker(self._email_fetch_loop, exclusive=True)

    def on_unmount(self) -> None:
        """Cancel workers when app closes"""
        if self.fetch_worker:
            self.fetch_worker.cancel()

    async def _email_fetch_loop(self):
        """Background loop to fetch emails periodically."""
        # Initial fetch
        await self._fetch_and_update_emails()

        # Periodic refresh every 60 seconds
        while True:
            await asyncio.sleep(60)
            await self._fetch_and_update_emails()

    async def _fetch_and_update_emails(self):
        """Fetch emails and update UI with notifications for new emails."""
        if self.is_loading:
            return

        self.is_loading = True

        try:
            # Fetch emails in background thread
            self.update_status("🔄 Fetching emails...")
            current_emails = await asyncio.to_thread(fetch_emails, num_emails=50)

            if not current_emails:
                self.update_status("📭 No emails found in inbox")
                self.update_table([])
                return

            # Detect new emails for notifications
            previous_uids = {email.uid for email in self.emails}
            new_emails = [
                e for e in current_emails if e.uid not in previous_uids and e.unread
            ]

            # Send notifications for new unread emails
            if new_emails and previous_uids:  # Only notify if not initial load
                self._send_notifications(new_emails)

            # Update the table with all current emails
            self.update_table(current_emails)

            # Update status bar
            unread_count = sum(1 for e in current_emails if e.unread)
            self.update_status(
                f"📬 {len(current_emails)} emails ({unread_count} unread)"
            )

        except AuthError as e:
            self.update_status(f"🔐 Authentication failed: {str(e)}")
            self.notify(str(e), severity="error", timeout=5)
        except Exception as e:
            error_msg = str(e)[:50]
            self.update_status(f"❌ Error: {error_msg}")
            self.log.error(f"Email fetch error: {e}")
        finally:
            self.is_loading = False

    def _send_notifications(self, new_emails: List[EmailMessage]):
        """Send desktop notifications for new emails."""
        if not new_emails:
            return

        try:
            if len(new_emails) == 1:
                email = new_emails[0]
                sender = email.sender.split("<")[0].strip()
                notify(
                    f"From: {sender}\nSubject: {email.subject[:60]}",
                    title="📧 New Email",
                    urgency="normal",
                )
            else:
                notify(
                    f"You have {len(new_emails)} new unread emails",
                    title="📧 New Emails",
                    urgency="normal",
                )
        except Exception as e:
            self.log.error(f"Notification error: {e}")

    def update_table(self, emails_to_display: List[EmailMessage]):
        """Update the email table efficiently."""
        table = self.query_one("#email-list", DataTable)

        # Store current selection
        current_selection_uid = self.current_selection
        current_row_index = -1

        if self.emails and current_selection_uid is not None:
            for i, email_msg in enumerate(self.emails):
                if email_msg.uid == current_selection_uid:
                    current_row_index = i
                    break

        # Update internal email list
        self.emails = emails_to_display

        # Clear and rebuild table
        table.clear()

        if not self.emails:
            # Show empty state
            table.add_row("📭", "No emails found", "", "", key="no_emails")
        else:
            for email_msg in self.emails:
                icon = "🔵" if email_msg.unread else "⚪"
                from_field = email_msg.sender.split("<")[0].strip()[:30]
                subject = (
                    email_msg.subject[:50] + "..."
                    if len(email_msg.subject) > 50
                    else email_msg.subject
                )
                date = email_msg.date.strftime("%Y-%m-%d %H:%M")
                table.add_row(icon, from_field, subject, date, key=str(email_msg.uid))

            # Restore cursor position
            if current_selection_uid is not None:
                new_row_index = -1
                for i, email_msg in enumerate(self.emails):
                    if email_msg.uid == current_selection_uid:
                        new_row_index = i
                        break

                if new_row_index != -1:
                    table.move_cursor(row=new_row_index)
                else:
                    table.move_cursor(row=0)
            else:
                # Select first email
                table.move_cursor(row=0)

        # Focus table
        if self.emails and not table.has_focus:
            table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected):
        """Handle row selection - store selection and show preview."""
        row_key_value = str(event.row_key.value)

        # Skip special rows
        if not row_key_value.isdigit():
            return

        self.current_selection = int(row_key_value)
        selected_email = next(
            (e for e in self.emails if e.uid == self.current_selection), None
        )

        if selected_email:
            preview = f"From: {selected_email.sender.split('<')[0].strip()} | Subject: {selected_email.subject[:40]}"
            self.update_status(preview)

    def action_open_email(self) -> None:
        """Opens the selected email in a modal view."""
        if self.current_selection is not None:
            selected_email = next(
                (e for e in self.emails if e.uid == self.current_selection), None
            )
            if selected_email:
                self.push_screen(EmailModal(selected_email))
            else:
                self.update_status("❌ No email selected")
        else:
            self.update_status("❌ Please select an email first")

    def action_refresh(self) -> None:
        """Manually refresh emails."""
        self.update_status("🔄 Refreshing...")
        # Trigger immediate fetch
        self.run_worker(self._fetch_and_update_emails, exclusive=False)

    def update_status(self, message: str):
        """Update status bar with timestamp."""
        try:
            status = self.query_one("#status-bar", Static)
            timestamp = datetime.now().strftime("%H:%M:%S")
            status.update(f"[{timestamp}] {message} | ⌨️  Press ? for help")
        except Exception:
            pass  # Widget might not be mounted yet

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "compose-button":
            self.push_screen(ComposeModal())


class NetworkErrorModal(ModalScreen):
    """A modal screen to display a network error."""

    DEFAULT_CSS = """
    NetworkErrorModal {
        align: center middle;
    }
    #error-container {
        width: 50%;
        height: auto;
        padding: 2;
        background: $error;
        border: thick $error-darken-2;
    }
    #error-title {
        width: 100%;
        text-align: center;
        padding-bottom: 1;
    }
    #error-message {
        text-align: center;
    }
    #retry-button {
        width: 100%;
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="error-container"):
            yield Static("🔌 Network Error", id="error-title")
            yield Static(
                "Could not connect to the email server. "
                "Please check your internet connection.",
                id="error-message",
            )
            yield Button("Retry", variant="error", id="retry-button")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "retry-button":
            self.app.pop_screen()
            self.app.action_refresh()


class ComposeModal(ModalScreen):
    """A modal screen to compose a new email."""

    DEFAULT_CSS = """
    ComposeModal {
        align: center middle;
    }
    #compose-container {
        width: 80%;
        height: 80%;
        padding: 2;
        background: $panel;
        border: thick $primary;
    }
    #compose-header {
        width: 100%;
        text-align: center;
        padding-bottom: 1;
    }
    #compose-body {
        height: 1fr;
        width: 1fr;
    }
    #compose-buttons {
        width: 100%;
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="compose-container"):
            yield Static("✍️ Compose New Email", id="compose-header")
            yield Input(placeholder="To:", id="compose-to")
            yield Input(placeholder="Subject:", id="compose-subject")
            yield TextArea(placeholder="Body:", id="compose-body")
            with Horizontal(id="compose-buttons"):
                yield Button("Send", variant="primary", id="send-button")
                yield Button("Cancel", id="cancel-button")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "send-button":
            self.app.pop_screen()
            self.app.update_status("📧 Email sent (dummy action)!")
        elif event.button.id == "cancel-button":
            self.app.pop_screen()

class LoginModel(ModalScreen):
    """A modal screen for user login."""

    DEFAULT_CSS = """
    LoginModel {
        align: center middle;
    }

    #login-container {
        width: 50%;
        height: auto;
        padding: 2;
        background: $panel;
        border: thick $primary;
    }

    #login-title {
        width: 100%;
        text-align: center;
        padding-bottom: 1;
    }

    #login-inputs {
        padding: 1 0;
    }
    """
    logo = r"""
██╗███╗ ██╗██████╗  ██████╗ ██╗ ██╗ ███████╗
██║████╗██║██╔══██╗██╔═══██╗██║ ██║ ██╔════╝
██║██╔████║██████╔╝██║   ██║██║ ██║ ███████╗
██║██║╚███║██╔══██╗██║   ██║██║ ██║ ╚════██║
██║██║ ╚██║██████╔╝╚██████╔╝███████╗███████║
╚═╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝╚══════╝
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="login-container"):
            yield Static(self.logo, id="login-title")
            with Vertical(id="login-inputs"):
                yield Input(placeholder="Email Address")
                yield Input(placeholder="App Password", password=True)
            yield Button("Login", variant="primary", id="login-button")
            yield Button("Help", id="help-button")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "login-button":
            # Dummy login logic
            email = self.query_one("#login-inputs > Input:first-child").value
            password = self.query_one("#login-inputs > Input:last-child").value
            if email and password:
                self.app.pop_screen()  # Dismiss login screen
                # Start the email fetcher after successful login
                if self.app.email_fetcher:
                    self.app.email_fetcher.start()
                else:
                    self.app.update_status("Error: Email fetcher not initialized.")
            else:
                self.app.bell()  # Indicate invalid input
