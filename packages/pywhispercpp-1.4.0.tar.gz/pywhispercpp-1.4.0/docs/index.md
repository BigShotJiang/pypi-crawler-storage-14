# PyWhisperCpp API Reference


::: pywhispercpp.model

::: pywhispercpp.constants
    options:
        show_if_no_docstring: true

::: pywhispercpp.utils

::: pywhispercpp.examples
    options:
        show_if_no_docstring: false