emm.indexing package
====================

Submodules
----------

emm.indexing.base\_indexer module
---------------------------------

.. automodule:: emm.indexing.base_indexer
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.pandas\_candidate\_selection module
------------------------------------------------

.. automodule:: emm.indexing.pandas_candidate_selection
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.pandas\_cos\_sim\_matcher module
---------------------------------------------

.. automodule:: emm.indexing.pandas_cos_sim_matcher
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.pandas\_naive\_indexer module
------------------------------------------

.. automodule:: emm.indexing.pandas_naive_indexer
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.pandas\_normalized\_tfidf module
---------------------------------------------

.. automodule:: emm.indexing.pandas_normalized_tfidf
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.pandas\_sni module
-------------------------------

.. automodule:: emm.indexing.pandas_sni
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.spark\_candidate\_selection module
-----------------------------------------------

.. automodule:: emm.indexing.spark_candidate_selection
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.spark\_character\_tokenizer module
-----------------------------------------------

.. automodule:: emm.indexing.spark_character_tokenizer
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.spark\_cos\_sim\_matcher module
--------------------------------------------

.. automodule:: emm.indexing.spark_cos_sim_matcher
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.spark\_indexing\_utils module
------------------------------------------

.. automodule:: emm.indexing.spark_indexing_utils
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.spark\_normalized\_tfidf module
--------------------------------------------

.. automodule:: emm.indexing.spark_normalized_tfidf
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.spark\_sni module
------------------------------

.. automodule:: emm.indexing.spark_sni
   :members:
   :undoc-members:
   :show-inheritance:

emm.indexing.spark\_word\_tokenizer module
------------------------------------------

.. automodule:: emm.indexing.spark_word_tokenizer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: emm.indexing
   :members:
   :undoc-members:
   :show-inheritance:
