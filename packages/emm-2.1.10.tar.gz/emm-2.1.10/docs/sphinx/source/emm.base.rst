emm.base package
================

Submodules
----------

emm.base.module module
----------------------

.. automodule:: emm.base.module
   :members:
   :undoc-members:
   :show-inheritance:

emm.base.pipeline module
------------------------

.. automodule:: emm.base.pipeline
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: emm.base
   :members:
   :undoc-members:
   :show-inheritance:
