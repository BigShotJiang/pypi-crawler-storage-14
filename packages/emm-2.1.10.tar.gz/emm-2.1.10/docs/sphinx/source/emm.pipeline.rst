emm.pipeline package
====================

Submodules
----------

emm.pipeline.base\_entity\_matching module
------------------------------------------

.. automodule:: emm.pipeline.base_entity_matching
   :members:
   :undoc-members:
   :show-inheritance:

emm.pipeline.pandas\_entity\_matching module
--------------------------------------------

.. automodule:: emm.pipeline.pandas_entity_matching
   :members:
   :undoc-members:
   :show-inheritance:

emm.pipeline.spark\_entity\_matching module
-------------------------------------------

.. automodule:: emm.pipeline.spark_entity_matching
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: emm.pipeline
   :members:
   :undoc-members:
   :show-inheritance:
