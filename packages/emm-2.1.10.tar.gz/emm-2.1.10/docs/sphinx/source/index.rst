.. Entity Matching Model documentation master file

.. include:: ../../../README.md
   :parser: myst_parser.sphinx_

Table of Contents
-----------------

.. toctree::
    :maxdepth: 2

    overview
    pipeline
    fitting
    parameters
    persistence
    spark

    api_index

Index
-----

:ref:`genindex`
