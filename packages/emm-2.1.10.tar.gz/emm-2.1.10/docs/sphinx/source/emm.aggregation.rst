emm.aggregation package
=======================

Submodules
----------

emm.aggregation.base\_entity\_aggregation module
------------------------------------------------

.. automodule:: emm.aggregation.base_entity_aggregation
   :members:
   :undoc-members:
   :show-inheritance:

emm.aggregation.pandas\_entity\_aggregation module
--------------------------------------------------

.. automodule:: emm.aggregation.pandas_entity_aggregation
   :members:
   :undoc-members:
   :show-inheritance:

emm.aggregation.spark\_entity\_aggregation module
-------------------------------------------------

.. automodule:: emm.aggregation.spark_entity_aggregation
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: emm.aggregation
   :members:
   :undoc-members:
   :show-inheritance:
