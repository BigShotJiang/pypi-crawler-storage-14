The example dataset used in the EMM package is sample from an open dataset from the Dutch chamber of commerce (KVK).
source: https://web.archive.org/web/20140225151639if_/http://www.kvk.nl/download/LEI_Full_tcm109-377398.csv
