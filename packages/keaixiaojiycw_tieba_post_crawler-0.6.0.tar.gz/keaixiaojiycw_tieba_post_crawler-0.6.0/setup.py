from setuptools import setup, find_packages

# 确保 README.md 文件存在于项目根目录
try:
    with open('README.md', 'r', encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = '贴吧一体化异步爬取与HTML/LLM数据处理工具箱'

setup(
    # --- 1. 修改分发名 (Distribution Name) ---
    name='keaixiaojiycw-tieba-post-crawler', 
    
    version='0.6.0',
    description='贴吧一体化异步爬取与HTML/LLM数据处理工具箱',
    long_description=long_description,
    long_description_content_type='text/markdown',
    
    # TODO: 请修改为您的信息
    author='keaixiaojiycw', 
    author_email='your.email@example.com', 
    url='https://github.com/yourusername/keaixiaojiycw-tieba-post-crawler', 
    license='MIT',

    # --- 2. 保持包名不变 (即目录名 tieba_toolkit) ---
    packages=find_packages(), 
    
    install_requires=[
        'aiotieba',
        'aiohttp',
        'aiofiles',
    ],
    
    # --- 3. 命令行入口 (CLI): 使用 tieba-crawler 名称 ---
    entry_points={
        'console_scripts': [
            # 用户将运行 tieba-crawler 命令
            'tieba-crawler = tieba_toolkit.cli:main', 
        ],
    },
    
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'Topic :: Internet :: WWW/HTTP :: Indexing/Search',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.8',
)