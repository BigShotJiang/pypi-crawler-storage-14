# -*- coding: utf-8 -*-
import json
import sys
from pathlib import Path
from typing import Dict, Any, List

# ==============================================================================
# 目录配置 (与爬虫保持一致)
# ==============================================================================
THREAD_ROOT = Path("threads")
THREAD_INDEX_JSON = THREAD_ROOT / "index.json"

# ==============================================================================
# 辅助函数：加载检查点 (从 crawler.py 提取)
# ==============================================================================

def load_checkpoint(tid: int) -> Dict[str, Any]:
    """尝试加载指定帖子的检查点文件以获取最后页码和PID数量。"""
    f = THREAD_ROOT / str(tid) / "checkpoint.json"
    if f.exists():
        try:
            with open(f, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except:
            pass
    # 默认值
    return {"last_page": 0, "seen_pids": []}

# ==============================================================================
# 1. 核心功能：列出已爬取目录 (供 cli.py 的 'list' 命令调用)
# ==============================================================================

def list_crawled_threads() -> List[Path]:
    """
    列出已爬取帖子的目录，并打印详细信息。
    返回一个包含帖子目录路径的列表。
    """
    if not THREAD_INDEX_JSON.exists():
        print("未找到目录文件 (threads/index.json)。请先运行爬虫。", file=sys.stderr)
        return []

    try:
        with open(THREAD_INDEX_JSON, 'r', encoding='utf-8') as f:
            index_map = json.load(f)
    except json.JSONDecodeError:
        print("错误: 目录文件 index.json 格式错误。", file=sys.stderr)
        return []

    print("\n" + "=" * 50)
    print("已爬取帖子目录 (Crawl Index)")
    print("=" * 50)
    print(f"{'No.':<5} | {'TID':<12} | {'Title':<22} | {'Pages':<8} | {'PIDs':<8}")
    print("-" * 50)
    
    thread_data = []
    
    # 按照 TID 排序，并获取详细信息
    for tid_str, title in sorted(index_map.items(), key=lambda item: int(item[0])):
        tid = int(tid_str)
        thread_path = THREAD_ROOT / tid_str
        
        # 尝试加载检查点获取页码和PID数量
        checkpoint = load_checkpoint(tid)
        last_page = checkpoint.get("last_page", 0)
        # 注意: 这里的 seen_pids 是列表，统计数量即可
        pids_count = len(checkpoint.get("seen_pids", []))
        
        thread_data.append({
            'tid': tid, 
            'title': title, 
            'last_page': last_page, 
            'pids_count': pids_count,
            'path': thread_path
        })
        
    for i, item in enumerate(thread_data, 1):
        # 截断标题，确保格式整齐
        display_title = item['title'][:20] + ('...' if len(item['title']) > 20 else '')
        print(
            f"{i:<5} | {item['tid']:<12} | {display_title:<22} | {item['last_page']:<8} | {item['pids_count']:<8}"
        )

    # 返回帖子目录路径列表
    return [item['path'] for item in thread_data]

# ==============================================================================
# 2. 核心功能：转换已爬取内容 (供 cli.py 的 'convert' 命令调用)
# ==============================================================================

def convert_thread(tid: int, convert_type: str, start_page: int = 1, end_page: int = None):
    """
    将已爬取的JSON数据转换为指定格式。
    注意：您需要在此处补充完整的转换逻辑（例如，基于您 converter2.9.py 中的 HTML/JSONL 生成代码）。
    """
    print(f"--- 转换任务启动 ---")
    print(f"帖子ID: {tid}")
    print(f"目标格式: {convert_type.upper()}")
    print(f"页码范围: {start_page} 到 {end_page if end_page is not None else '最大页'}")
    
    # ---------------------------------------------------------------------
    # TODO: 在此处添加您的实际转换逻辑！
    # ---------------------------------------------------------------------
    
    # 这是一个占位提示，确保功能可以被调用
    print("转换功能尚未实现：请在 `tieba_toolkit/converter.py` 的 convert_thread 函数中，")
    print("根据您的需求（例如调用 converter2.9.py 中的 HTML/JSONL 生成逻辑）来填充转换代码。")
    print("转换完成 (占位符执行结束)。")


# 确保只有在直接运行时才执行主流程（如果此文件有自己的菜单的话，但现在我们依赖 cli.py）
if __name__ == "__main__":
    list_crawled_threads()