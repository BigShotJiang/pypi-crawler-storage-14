# -*- coding: utf-8 -*-
import argparse
import asyncio
import os
import sys

# 从__init__中导入核心功能
from . import dump_thread, convert_thread, list_crawled_threads 

def get_bduss_from_env() -> str:
    """从环境变量中获取 BDUSS"""
    bduss = os.environ.get("TIEBA_BDUSS")
    if not bduss:
        print("错误: TIEBA_BDUSS 环境变量未设置！", file=sys.stderr)
        print("请运行以下命令设置您的 BDUSS：", file=sys.stderr)
        print("PowerShell: $env:TIEBA_BDUSS=\"您的实际BDUSS字符串\"", file=sys.stderr)
        print("Bash/Linux: export TIEBA_BDUSS=\"您的实际BDUSS字符串\"", file=sys.stderr)
        sys.exit(1)
    return bduss

def main():
    """主命令行解析函数"""
    parser = argparse.ArgumentParser(
        description="贴吧帖子异步爬取、转换工具 (keaixiaojiycw-tieba-post-crawler)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # --- CRAWL Command ---
    crawl_parser = subparsers.add_parser("crawl", help="爬取指定帖子ID的内容。")
    crawl_parser.add_argument(
        "tid", 
        type=int, 
        help="要爬取的帖子ID (TID)"
    )
    crawl_parser.add_argument(
        "-m", "--max-pages", 
        type=int, 
        default=2400, 
        help="最大爬取页数 (默认为 2400)"
    )
    
    # --- CONVERT Command ---
    convert_parser = subparsers.add_parser("convert", help="将已爬取的JSON数据转换为HTML或LLM格式。")
    convert_parser.add_argument(
        "tid", 
        type=int, 
        help="要转换的帖子ID (TID)"
    )
    convert_parser.add_argument(
        "-t", "--type", 
        choices=['html', 'llm'], 
        default='html', 
        help="转换目标格式 (html 或 llm，默认为 html)"
    )
    convert_parser.add_argument(
        "-s", "--start", 
        type=int, 
        default=1, 
        help="起始页码 (默认为 1)"
    )
    convert_parser.add_argument(
        "-e", "--end", 
        type=int, 
        help="结束页码 (默认为最大页码)"
    )

    # --- LIST Command ---
    list_parser = subparsers.add_parser("list", help="列出已爬取的帖子目录。")

    args = parser.parse_args()

    # --- 1. 爬取 (Crawl) 逻辑 ---
    if args.command == "crawl":
        try:
            # 检查并获取 BDUSS
            bduss = get_bduss_from_env()
            
            # 运行异步爬虫函数
            asyncio.run(dump_thread(
                tid=args.tid, 
                bduss=bduss, 
                max_pages=args.max_pages
            ))
        except Exception as e:
            print(f"爬取任务发生严重错误: {e}", file=sys.stderr)
            sys.exit(1)

    # --- 2. 转换 (Convert) 逻辑 ---
    elif args.command == "convert":
        # 转换逻辑假设在 converter.py 中实现
        try:
            convert_thread(
                tid=args.tid,
                convert_type=args.type,
                start_page=args.start,
                end_page=args.end,
            )
        except NameError:
            print("错误：转换功能所需函数 `convert_thread` 未在模块中定义。请检查您的 `converter.py`。", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"转换任务发生错误: {e}", file=sys.stderr)
            sys.exit(1)
            
    # --- 3. 列表 (List) 逻辑 ---
    elif args.command == "list":
        try:
            list_crawled_threads()
        except NameError:
            print("错误：列表功能所需函数 `list_crawled_threads` 未在模块中定义。请检查您的 `converter.py` 或 `utils.py`。", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"列表任务发生错误: {e}", file=sys.stderr)
            sys.exit(1)
    
if __name__ == "__main__":
    main()