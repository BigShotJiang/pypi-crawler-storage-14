from setuptools import setup, find_packages

setup(
    name="igbyte",  # Your package name on PyPI
    version="0.1.4",  # Initial version
    author="AnkuCode",
    author_email="ankucode@gmail.com",
    description="A lightweight Python package providing handy Instagram utilities including search profile by user id,sending reset on acc,downloading reels",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires='>=3.7',
    install_requires=[
        "requests", 
        "user-agent", # Add any dependencies your package needs
    ],
    keywords="instagram api",
)
