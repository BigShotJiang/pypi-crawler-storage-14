def type_to_port(type) -> str:
    # TODO this is wrong
    typename = str(type)
    data_types = {"int", "integer", "real", "float", "double", "string"}
    mixed_types = {"event_data", "event data"}

    if typename in data_types:
        return "data"
    if typename in mixed_types:
        return "event data"
    return "data"

def type_to_aadl_type(type) -> str:
    typename = str(type)
    # Boolean,
    # Character,
    # Float, Float_32, Float_64,
    # Integer, Integer_8, Integer_16, Integer_32, Integer_64,
    # Natural,
    # String,
    # Unsigned_8, Unsigned_16, Unsigned_32, Unsigned_64
    mapping = {
        "boolean": "Base_Types::Boolean",
        "nat": "Base_Types::Natural",
        "real": "Base_Types::Float",
    }
    # TODO Seq -> Array[...]
    # TODO Matrix to Array[Array[...]]
    return mapping.get(typename, f"messages::{typename}")
