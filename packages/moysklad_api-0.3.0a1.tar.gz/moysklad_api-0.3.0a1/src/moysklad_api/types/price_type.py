from pydantic import Field

from .entity import Entity


class PriceType(Entity):
    id: str
    name: str
    external_code: str = Field(..., alias="externalCode")
