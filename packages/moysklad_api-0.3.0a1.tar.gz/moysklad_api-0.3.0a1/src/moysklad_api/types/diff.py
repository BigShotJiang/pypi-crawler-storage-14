from pydantic import BaseModel, Field

from .entity import Entity


class Diff(BaseModel):
    old_value: str | Entity = Field(..., alias="oldValue")
    new_value: str | Entity = Field(..., alias="newValue")
