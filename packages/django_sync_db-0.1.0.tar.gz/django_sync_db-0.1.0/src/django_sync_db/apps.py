from django.apps import AppConfig


class SyncConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_sync_db"
    
    def ready(self):
        import django_sync_db.signals  # noqa