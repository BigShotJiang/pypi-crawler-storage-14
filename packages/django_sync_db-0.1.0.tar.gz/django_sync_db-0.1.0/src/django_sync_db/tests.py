from django.test import TestCase
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import datetime, timedelta
from .models import ExternalDatabase, TableMapping, SyncTask, SyncLog, DailySyncTask
from .services import DatabaseConnection, DataSyncService


class ExternalDatabaseModelTest(TestCase):
    """外部数据库模型测试"""
    
    def setUp(self):
        self.db = ExternalDatabase.objects.create(
            name="测试数据库",
            db_type="mysql",
            host="localhost",
            port=3306,
            database_name="test_db",
            username="test_user",
            password="test_password"
        )
    
    def test_database_creation(self):
        """测试数据库创建"""
        self.assertEqual(self.db.name, "测试数据库")
        self.assertEqual(self.db.db_type, "mysql")
        self.assertTrue(self.db.is_active)
    
    def test_database_str(self):
        """测试字符串表示"""
        expected = "测试数据库 (mysql)"
        self.assertEqual(str(self.db), expected)


class TableMappingModelTest(TestCase):
    """表映射模型测试"""
    
    def setUp(self):
        self.external_db = ExternalDatabase.objects.create(
            name="测试数据库",
            db_type="mysql",
            host="localhost",
            port=3306,
            database_name="test_db",
            username="test_user",
            password="test_password"
        )
        
        self.mapping = TableMapping.objects.create(
            external_db=self.external_db,
            external_table="users",
            local_model="User",
            field_mapping={"id": "user_id", "name": "username"},
            filter_sql="status = 'active'"
        )
    
    def test_mapping_creation(self):
        """测试映射创建"""
        self.assertEqual(self.mapping.external_table, "users")
        self.assertEqual(self.mapping.local_model, "User")
        self.assertEqual(self.mapping.field_mapping["id"], "user_id")
    
    def test_mapping_str(self):
        """测试字符串表示"""
        expected = "users -> User"
        self.assertEqual(str(self.mapping), expected)


class SyncTaskModelTest(TestCase):
    """同步任务模型测试"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username="testuser",
            password="testpass123"
        )
        
        self.external_db = ExternalDatabase.objects.create(
            name="测试数据库",
            db_type="mysql",
            host="localhost",
            port=3306,
            database_name="test_db",
            username="test_user",
            password="test_password"
        )
        
        self.mapping = TableMapping.objects.create(
            external_db=self.external_db,
            external_table="users",
            local_model="User",
            field_mapping={"id": "user_id", "name": "username"}
        )
        
        self.task = SyncTask.objects.create(
            table_mapping=self.mapping,
            task_id="test_task_123",
            status="pending",
            created_by=self.user
        )
    
    def test_task_creation(self):
        """测试任务创建"""
        self.assertEqual(self.task.table_mapping, self.mapping)
        self.assertEqual(self.task.task_id, "test_task_123")
        self.assertEqual(self.task.status, "pending")
        self.assertEqual(self.task.created_by, self.user)
    
    def test_task_str(self):
        """测试字符串表示"""
        expected = f"同步任务 {self.task.id} - {self.mapping}"
        self.assertEqual(str(self.task), expected)


class SyncLogModelTest(TestCase):
    """同步日志模型测试"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username="testuser",
            password="testpass123"
        )
        
        self.external_db = ExternalDatabase.objects.create(
            name="测试数据库",
            db_type="mysql",
            host="localhost",
            port=3306,
            database_name="test_db",
            username="test_user",
            password="test_password"
        )
        
        self.mapping = TableMapping.objects.create(
            external_db=self.external_db,
            external_table="users",
            local_model="User",
            field_mapping={"id": "user_id", "name": "username"}
        )
        
        self.task = SyncTask.objects.create(
            table_mapping=self.mapping,
            task_id="test_task_123",
            status="pending",
            created_by=self.user
        )
        
        self.log = SyncLog.objects.create(
            sync_task=self.task,
            level="INFO",
            message="测试日志消息",
            details={"test": "data"}
        )
    
    def test_log_creation(self):
        """测试日志创建"""
        self.assertEqual(self.log.sync_task, self.task)
        self.assertEqual(self.log.level, "INFO")
        self.assertEqual(self.log.message, "测试日志消息")
        self.assertEqual(self.log.details["test"], "data")
    
    def test_log_str(self):
        """测试字符串表示"""
        expected = f"[INFO] {self.task} - {self.log.created_at}"
        self.assertEqual(str(self.log), expected)


class DailySyncTaskModelTest(TestCase):
    """每日同步任务模型测试"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username="testuser",
            password="testpass123"
        )
        
        self.external_db = ExternalDatabase.objects.create(
            name="测试数据库",
            db_type="mysql",
            host="localhost",
            port=3306,
            database_name="test_db",
            username="test_user",
            password="test_password"
        )
        
        self.mapping = TableMapping.objects.create(
            external_db=self.external_db,
            external_table="users",
            local_model="User",
            field_mapping={"id": "user_id", "name": "username"}
        )
        
        self.parent_task = SyncTask.objects.create(
            table_mapping=self.mapping,
            task_id="test_task_123",
            status="completed",
            created_by=self.user
        )
        
        self.daily_task = DailySyncTask.objects.create(
            parent_task=self.parent_task,
            sync_date=timezone.now().date(),
            status="pending"
        )
    
    def test_daily_task_creation(self):
        """测试每日任务创建"""
        self.assertEqual(self.daily_task.parent_task, self.parent_task)
        self.assertEqual(self.daily_task.status, "pending")
        self.assertEqual(self.daily_task.sync_date, timezone.now().date())
    
    def test_daily_task_str(self):
        """测试字符串表示"""
        expected = f"{self.daily_task.sync_date} - {self.mapping.external_table}"
        self.assertEqual(str(self.daily_task), expected)


class DatabaseConnectionTest(TestCase):
    """数据库连接测试"""
    
    def setUp(self):
        self.db = ExternalDatabase.objects.create(
            name="测试数据库",
            db_type="sqlite",
            host="",
            port=0,
            database_name=":memory:",
            username="",
            password=""
        )
        
        self.mssql_db = ExternalDatabase.objects.create(
            name="测试MSSQL数据库",
            db_type="mssql",
            host="localhost",
            port=1433,
            database_name="test_db",
            username="sa",
            password="password123",
            extra_params={
                'driver': 'ODBC Driver 17 for SQL Server',
                'timeout': 30
            }
        )
    
    def test_connection_creation(self):
        """测试连接创建"""
        conn = DatabaseConnection(self.db)
        self.assertEqual(conn.external_db, self.db)
        self.assertIsNone(conn.connection)
    
    def test_sqlite_connection(self):
        """测试SQLite连接"""
        conn = DatabaseConnection(self.db)
        try:
            # 创建测试表
            conn.connect()
            cursor = conn.connection.cursor()
            cursor.execute("CREATE TABLE test_table (id INTEGER PRIMARY KEY, name TEXT)")
            cursor.execute("INSERT INTO test_table (name) VALUES ('test')")
            conn.connection.commit()
            
            # 测试查询（保持连接）
            result = conn.execute_query("SELECT * FROM test_table", keep_connection=True)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0]['name'], 'test')
            
            # 再次测试查询
            result2 = conn.execute_query("SELECT * FROM test_table", keep_connection=True)
            self.assertEqual(len(result2), 1)
            
            conn.close()
        except Exception as e:
            self.fail(f"SQLite连接测试失败: {e}")
    
    def test_mssql_connection_creation(self):
        """测试MSSQL连接创建"""
        conn = DatabaseConnection(self.mssql_db)
        self.assertEqual(conn.external_db, self.mssql_db)
        self.assertIsNone(conn.connection)
    
    def test_mssql_connection_string_building(self):
        """测试MSSQL连接字符串构建"""
        conn = DatabaseConnection(self.mssql_db)
        
        # 模拟连接字符串构建逻辑
        driver = self.mssql_db.extra_params.get('driver', 'ODBC Driver 17 for SQL Server')
        expected_parts = [
            f"DRIVER={{{driver}}}",
            f"SERVER={self.mssql_db.host},{self.mssql_db.port}",
            f"DATABASE={self.mssql_db.database_name}",
            f"UID={self.mssql_db.username}",
            f"PWD={self.mssql_db.password}",
            "TrustServerCertificate=yes"
        ]
        
        # 验证连接字符串包含必要的部分
        for part in expected_parts:
            self.assertIn(part, "DRIVER={ODBC Driver 17 for SQL Server}")


class DataSyncServiceTest(TestCase):
    """数据同步服务测试"""
    
    def setUp(self):
        self.user = User.objects.create_user(
            username="testuser",
            password="testpass123"
        )
        
        self.external_db = ExternalDatabase.objects.create(
            name="测试数据库",
            db_type="sqlite",
            host="",
            port=0,
            database_name=":memory:",
            username="",
            password=""
        )
        
        self.mapping = TableMapping.objects.create(
            external_db=self.external_db,
            external_table="test_table",
            local_model="TestModel",
            field_mapping={"id": "test_id", "name": "test_name"}
        )
        
        self.task = SyncTask.objects.create(
            table_mapping=self.mapping,
            task_id="test_task_123",
            status="running",
            created_by=self.user
        )
    
    def test_service_creation(self):
        """测试服务创建"""
        service = DataSyncService(self.task)
        self.assertEqual(service.sync_task, self.task)
        self.assertEqual(service.table_mapping, self.mapping)
        self.assertEqual(service.external_db, self.external_db)
    
    def test_data_transformation(self):
        """测试数据转换"""
        service = DataSyncService(self.task)
        
        test_data = {
            "id": 1,
            "name": "test",
            "extra_field": "should_be_ignored"
        }
        
        transformed = service.transform_data(test_data)
        
        expected = {
            "test_id": 1,
            "test_name": "test"
        }
        
        self.assertEqual(transformed, expected)
    
    def test_query_building(self):
        """测试查询构建"""
        service = DataSyncService(self.task)
        
        # 基本查询
        query = service.build_query()
        self.assertEqual(query, "SELECT * FROM test_table")
        
        # 带筛选条件的查询
        self.mapping.filter_sql = "status = 'active'"
        query = service.build_query()
        self.assertEqual(query, "SELECT * FROM test_table WHERE status = 'active'")
        
        # 带日期过滤的查询
        start_date = datetime(2024, 1, 1)
        end_date = datetime(2024, 12, 31)
        date_filter = service.get_date_filter(start_date, end_date)
        
        self.mapping.filter_sql = ""
        query = service.build_query(date_filter)
        self.assertIn("WHERE", query)
        self.assertIn("created_at >= '2024-01-01'", query)
        self.assertIn("created_at <= '2024-12-31'", query)