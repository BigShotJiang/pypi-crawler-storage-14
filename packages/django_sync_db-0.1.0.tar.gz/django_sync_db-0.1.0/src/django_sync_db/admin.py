from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import ExternalDatabase, TableMapping, SyncTask, SyncLog, DailySyncTask
from .tasks import test_connection, start_sync_task, create_daily_sync_tasks


@admin.register(ExternalDatabase)
class ExternalDatabaseAdmin(admin.ModelAdmin):
    list_display = ['name', 'db_type', 'host', 'port', 'database_name', 'is_active', 'created_at']
    list_filter = ['db_type', 'is_active', 'created_at']
    search_fields = ['name', 'host', 'database_name']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('基本信息', {
            'fields': ('name', 'db_type', 'is_active')
        }),
        ('连接配置', {
            'fields': ('host', 'port', 'database_name', 'username', 'password')
        }),
        ('额外配置', {
            'fields': ('extra_params',),
            'classes': ('collapse',)
        }),
        ('时间信息', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )

    actions = ['test_selected_connections']

    def test_selected_connections(self, request, queryset):
        """测试选中的数据库连接"""
        for db in queryset:
            try:
                task = test_connection.delay(db.id)
                self.message_user(request, f"已提交连接测试任务: {db.name} (任务ID: {task.id})")
            except Exception as e:
                self.message_user(request, f"测试 {db.name} 连接失败: {str(e)}", level='error')
    test_selected_connections.short_description = "测试选中数据库连接"


class FieldMappingInline(admin.TabularInline):
    model = TableMapping
    extra = 0
    fields = ['external_table', 'local_model', 'is_active']


@admin.register(TableMapping)
class TableMappingAdmin(admin.ModelAdmin):
    list_display = ['external_table', 'local_model', 'external_db', 'is_active', 'created_at']
    list_filter = ['external_db', 'is_active', 'created_at']
    search_fields = ['external_table', 'local_model']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('基本信息', {
            'fields': ('external_db', 'external_table', 'local_model', 'is_active')
        }),
        ('映射配置', {
            'fields': ('field_mapping', 'filter_sql')
        }),
        ('时间信息', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )

    actions = ['start_sync_for_selected']

    def start_sync_for_selected(self, request, queryset):
        """为选中的表映射启动同步任务"""
        for mapping in queryset:
            try:
                task = start_sync_task.delay(mapping.id, request.user.id)
                self.message_user(request, f"已启动同步任务: {mapping.external_table} (任务ID: {task.id})")
            except Exception as e:
                self.message_user(request, f"启动 {mapping.external_table} 同步失败: {str(e)}", level='error')
    start_sync_for_selected.short_description = "启动选中表同步"


class SyncLogInline(admin.TabularInline):
    model = SyncLog
    extra = 0
    readonly_fields = ['level', 'message', 'details', 'created_at']
    can_delete = False
    max_num = 10

    def has_add_permission(self, request, obj=None):
        return False


class DailySyncTaskInline(admin.TabularInline):
    model = DailySyncTask
    extra = 0
    readonly_fields = ['sync_date', 'status', 'total_records', 'success_records', 'execution_time']
    can_delete = False
    max_num = 20

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(SyncTask)
class SyncTaskAdmin(admin.ModelAdmin):
    list_display = ['id', 'table_mapping', 'status', 'progress', 'created_by', 'created_at']
    list_filter = ['status', 'created_at', 'table_mapping__external_db']
    search_fields = ['table_mapping__external_table', 'table_mapping__local_model']
    readonly_fields = ['task_id', 'total_records', 'processed_records', 'success_records', 
                      'failed_records', 'execution_time', 'created_at', 'started_at', 'completed_at']
    
    fieldsets = (
        ('任务信息', {
            'fields': ('table_mapping', 'task_id', 'status', 'created_by')
        }),
        ('时间范围', {
            'fields': ('start_date', 'end_date')
        }),
        ('执行统计', {
            'fields': ('total_records', 'processed_records', 'success_records', 'failed_records', 'execution_time')
        }),
        ('错误信息', {
            'fields': ('error_message',),
            'classes': ('collapse',)
        }),
        ('时间信息', {
            'fields': ('created_at', 'started_at', 'completed_at'),
            'classes': ('collapse',)
        })
    )

    inlines = [SyncLogInline, DailySyncTaskInline]
    actions = ['retry_failed_tasks', 'create_daily_tasks']

    def progress(self, obj):
        """显示进度条"""
        if obj.total_records > 0:
            percentage = (obj.processed_records / obj.total_records) * 100
            return format_html(
                '<div style="width: 100px; background-color: #f0f0f0; border-radius: 3px;">'
                '<div style="width: {}%; background-color: {}; border-radius: 3px; height: 20px; line-height: 20px; text-align: center; color: white;">'
                '{:.1f}%'
                '</div></div>',
                percentage,
                '#28a745' if obj.status == 'completed' else '#ffc107' if obj.status == 'running' else '#dc3545',
                percentage
            )
        return "无数据"
    progress.short_description = '进度'

    def retry_failed_tasks(self, request, queryset):
        """重试失败的任务"""
        for task in queryset.filter(status='failed'):
            try:
                # 重置任务状态
                task.status = 'pending'
                task.error_message = ''
                task.save()
                
                # 重新启动任务
                new_task = start_sync_task.delay(task.table_mapping.id, task.created_by.id)
                self.message_user(request, f"已重新提交任务: {task.id} (新任务ID: {new_task.id})")
            except Exception as e:
                self.message_user(request, f"重试任务 {task.id} 失败: {str(e)}", level='error')
    retry_failed_tasks.short_description = "重试失败任务"

    def create_daily_tasks(self, request, queryset):
        """创建每日同步任务"""
        for task in queryset:
            try:
                celery_task = create_daily_sync_tasks.delay(task.id)
                self.message_user(request, f"已创建每日同步任务: {task.id} (任务ID: {celery_task.id})")
            except Exception as e:
                self.message_user(request, f"创建每日任务失败: {task.id} - {str(e)}", level='error')
    create_daily_tasks.short_description = "创建每日同步任务"


@admin.register(SyncLog)
class SyncLogAdmin(admin.ModelAdmin):
    list_display = ['sync_task', 'level', 'message_preview', 'created_at']
    list_filter = ['level', 'created_at', 'sync_task__status']
    search_fields = ['message', 'sync_task__table_mapping__external_table']
    readonly_fields = ['sync_task', 'level', 'message', 'details', 'created_at']
    
    def message_preview(self, obj):
        """预览消息内容"""
        if len(obj.message) > 50:
            return obj.message[:50] + "..."
        return obj.message
    message_preview.short_description = '消息'

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(DailySyncTask)
class DailySyncTaskAdmin(admin.ModelAdmin):
    list_display = ['sync_date', 'parent_task', 'status', 'progress', 'total_records', 'success_records']
    list_filter = ['status', 'sync_date', 'parent_task__table_mapping__external_db']
    search_fields = ['parent_task__table_mapping__external_table']
    readonly_fields = ['parent_task', 'sync_date', 'task_id', 'total_records', 'processed_records', 
                      'success_records', 'failed_records', 'execution_time', 'created_at', 
                      'started_at', 'completed_at']
    
    fieldsets = (
        ('任务信息', {
            'fields': ('parent_task', 'sync_date', 'task_id', 'status')
        }),
        ('执行统计', {
            'fields': ('total_records', 'processed_records', 'success_records', 'failed_records', 'execution_time')
        }),
        ('错误信息', {
            'fields': ('error_message',),
            'classes': ('collapse',)
        }),
        ('时间信息', {
            'fields': ('created_at', 'started_at', 'completed_at'),
            'classes': ('collapse',)
        })
    )

    def progress(self, obj):
        """显示进度条"""
        if obj.total_records > 0:
            percentage = (obj.processed_records / obj.total_records) * 100
            return format_html(
                '<div style="width: 100px; background-color: #f0f0f0; border-radius: 3px;">'
                '<div style="width: {}%; background-color: {}; border-radius: 3px; height: 20px; line-height: 20px; text-align: center; color: white;">'
                '{:.1f}%'
                '</div></div>',
                percentage,
                '#28a745' if obj.status == 'completed' else '#ffc107' if obj.status == 'running' else '#dc3545',
                percentage
            )
        return "无数据"
    progress.short_description = '进度'

    def has_add_permission(self, request):
        return False