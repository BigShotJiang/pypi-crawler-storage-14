import logging
from datetime import datetime, timedelta
from celery import shared_task
from django.utils import timezone
from django.contrib.auth.models import User
from .models import ExternalDatabase, TableMapping, SyncTask, DailySyncTask
from .services import DatabaseConnection, DataSyncService

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def test_connection(self, db_id: int):
    """测试数据库连接"""
    try:
        external_db = ExternalDatabase.objects.get(id=db_id)
        db_connection = DatabaseConnection(external_db)
        
        if db_connection.test_connection():
            logger.info(f"数据库连接测试成功: {external_db.name}")
            return {'success': True, 'message': '连接成功'}
        else:
            logger.error(f"数据库连接测试失败: {external_db.name}")
            return {'success': False, 'message': '连接失败'}
            
    except ExternalDatabase.DoesNotExist:
        logger.error(f"数据库配置不存在: {db_id}")
        return {'success': False, 'message': '数据库配置不存在'}
    except Exception as e:
        logger.error(f"测试连接时发生错误: {str(e)}")
        return {'success': False, 'message': str(e)}


@shared_task(bind=True, max_retries=3)
def start_sync_task(self, mapping_id: int, user_id: int = None, 
                   start_date: str = None, end_date: str = None):
    """启动同步任务"""
    try:
        # 获取表映射配置
        table_mapping = TableMapping.objects.get(id=mapping_id)
        
        # 创建同步任务记录
        sync_task = SyncTask.objects.create(
            table_mapping=table_mapping,
            task_id=self.request.id,
            status='running',
            start_date=datetime.strptime(start_date, '%Y-%m-%d').date() if start_date else None,
            end_date=datetime.strptime(end_date, '%Y-%m-%d').date() if end_date else None,
            created_by=User.objects.get(id=user_id) if user_id else None,
            started_at=timezone.now()
        )
        
        logger.info(f"开始同步任务: {sync_task.id} - {table_mapping.external_table}")
        
        # 执行数据同步
        sync_service = DataSyncService(sync_task)
        
        start_dt = datetime.strptime(start_date, '%Y-%m-%d') if start_date else None
        end_dt = datetime.strptime(end_date, '%Y-%m-%d') if end_date else None
        
        result = sync_service.sync_data(start_dt, end_dt)
        
        # 更新任务状态
        sync_task.status = 'completed'
        sync_task.completed_at = timezone.now()
        sync_task.save()
        
        logger.info(f"同步任务完成: {sync_task.id}")
        
        return {
            'success': True,
            'task_id': sync_task.id,
            'result': result
        }
        
    except TableMapping.DoesNotExist:
        logger.error(f"表映射配置不存在: {mapping_id}")
        return {'success': False, 'message': '表映射配置不存在'}
    except Exception as e:
        logger.error(f"同步任务执行失败: {str(e)}")
        
        # 更新任务状态为失败
        try:
            sync_task = SyncTask.objects.get(task_id=self.request.id)
            sync_task.status = 'failed'
            sync_task.error_message = str(e)
            sync_task.completed_at = timezone.now()
            sync_task.save()
        except:
            pass
        
        # 重试机制
        if self.request.retries < self.max_retries:
            logger.info(f"准备重试同步任务: {self.request.retries + 1}/{self.max_retries}")
            raise self.retry(countdown=60 * (self.request.retries + 1))
        
        return {'success': False, 'message': str(e)}


@shared_task(bind=True, max_retries=2)
def create_daily_sync_tasks(self, sync_task_id: int):
    """创建每日同步任务"""
    try:
        sync_task = SyncTask.objects.get(id=sync_task_id)
        
        # 计算日期范围
        end_date = sync_task.end_date or timezone.now().date()
        start_date = sync_task.start_date or (end_date - timedelta(days=364))
        
        current_date = start_date
        daily_tasks = []
        
        while current_date <= end_date:
            # 检查是否已存在该日期的任务
            if not DailySyncTask.objects.filter(
                parent_task=sync_task, 
                sync_date=current_date
            ).exists():
                
                daily_task = DailySyncTask.objects.create(
                    parent_task=sync_task,
                    sync_date=current_date,
                    status='pending'
                )
                daily_tasks.append(daily_task)
                
                # 启动每日同步任务
                execute_daily_sync.delay(daily_task.id)
            
            current_date += timedelta(days=1)
        
        logger.info(f"创建了 {len(daily_tasks)} 个每日同步任务")
        
        return {
            'success': True,
            'daily_tasks_count': len(daily_tasks),
            'date_range': f"{start_date} 至 {end_date}"
        }
        
    except SyncTask.DoesNotExist:
        logger.error(f"同步任务不存在: {sync_task_id}")
        return {'success': False, 'message': '同步任务不存在'}
    except Exception as e:
        logger.error(f"创建每日同步任务失败: {str(e)}")
        
        if self.request.retries < self.max_retries:
            raise self.retry(countdown=60 * (self.request.retries + 1))
        
        return {'success': False, 'message': str(e)}


@shared_task(bind=True, max_retries=3)
def execute_daily_sync(self, daily_task_id: int):
    """执行每日同步任务"""
    try:
        daily_task = DailySyncTask.objects.get(id=daily_task_id)
        sync_task = daily_task.parent_task
        table_mapping = sync_task.table_mapping
        
        # 更新任务状态
        daily_task.status = 'running'
        daily_task.started_at = timezone.now()
        daily_task.save()
        
        logger.info(f"开始执行每日同步任务: {daily_task.sync_date}")
        
        # 创建数据同步服务
        sync_service = DataSyncService(sync_task)
        
        # 设置日期范围（单日）
        start_dt = datetime.combine(daily_task.sync_date, datetime.min.time())
        end_dt = datetime.combine(daily_task.sync_date, datetime.max.time())
        
        # 执行同步
        result = sync_service.sync_data(start_dt, end_dt)
        
        # 更新任务状态
        daily_task.status = 'completed'
        daily_task.total_records = result['total']
        daily_task.success_records = result['success']
        daily_task.failed_records = result['failed']
        daily_task.execution_time = result['execution_time']
        daily_task.processed_records = result['total']
        daily_task.completed_at = timezone.now()
        daily_task.save()
        
        logger.info(f"每日同步任务完成: {daily_task.sync_date} - 成功{result['success']}条")
        
        return {
            'success': True,
            'daily_task_id': daily_task_id,
            'sync_date': daily_task.sync_date.strftime('%Y-%m-%d'),
            'result': result
        }
        
    except DailySyncTask.DoesNotExist:
        logger.error(f"每日同步任务不存在: {daily_task_id}")
        return {'success': False, 'message': '每日同步任务不存在'}
    except Exception as e:
        logger.error(f"执行每日同步任务失败: {str(e)}")
        
        # 更新任务状态为失败
        try:
            daily_task = DailySyncTask.objects.get(id=daily_task_id)
            daily_task.status = 'failed'
            daily_task.error_message = str(e)
            daily_task.completed_at = timezone.now()
            daily_task.save()
        except:
            pass
        
        # 重试机制
        if self.request.retries < self.max_retries:
            logger.info(f"准备重试每日同步任务: {self.request.retries + 1}/{self.max_retries}")
            raise self.retry(countdown=60 * (self.request.retries + 1))
        
        return {'success': False, 'message': str(e)}


@shared_task
def cleanup_old_logs(days: int = 30):
    """清理旧的同步日志"""
    try:
        from datetime import timedelta
        
        cutoff_date = timezone.now() - timedelta(days=days)
        
        # 删除旧的同步日志
        deleted_logs = SyncLog.objects.filter(created_at__lt=cutoff_date).delete()
        
        logger.info(f"清理了 {deleted_logs[0]} 条旧日志记录")
        
        return {
            'success': True,
            'deleted_count': deleted_logs[0],
            'cutoff_date': cutoff_date
        }
        
    except Exception as e:
        logger.error(f"清理日志失败: {str(e)}")
        return {'success': False, 'message': str(e)}


@shared_task
def retry_failed_daily_tasks():
    """重试失败的每日同步任务"""
    try:
        failed_tasks = DailySyncTask.objects.filter(status='failed')
        
        retried_count = 0
        for daily_task in failed_tasks:
            # 重置任务状态
            daily_task.status = 'pending'
            daily_task.error_message = ''
            daily_task.save()
            
            # 重新执行任务
            execute_daily_sync.delay(daily_task.id)
            retried_count += 1
        
        logger.info(f"重试了 {retried_count} 个失败的每日同步任务")
        
        return {
            'success': True,
            'retried_count': retried_count
        }
        
    except Exception as e:
        logger.error(f"重试失败任务时发生错误: {str(e)}")
        return {'success': False, 'message': str(e)}


@shared_task(bind=True)
def test_table_mapping(self, mapping_id: int):
    """测试表映射配置"""
    try:
        table_mapping = TableMapping.objects.get(id=mapping_id)
        
        # 创建临时同步任务用于测试
        temp_sync_task = SyncTask.objects.create(
            table_mapping=table_mapping,
            task_id=f"test_{self.request.id}",
            status='running'
        )
        
        sync_service = DataSyncService(temp_sync_task)
        result = sync_service.test_mapping()
        
        # 删除临时任务
        temp_sync_task.delete()
        
        return result
        
    except TableMapping.DoesNotExist:
        return {'success': False, 'error': '表映射配置不存在'}
    except Exception as e:
        return {'success': False, 'error': str(e)}


# 定时任务配置
@shared_task
def schedule_daily_cleanup():
    """调度每日清理任务"""
    cleanup_old_logs.delay(30)


@shared_task
def schedule_daily_retry():
    """调度每日重试任务"""
    retry_failed_daily_tasks.delay()