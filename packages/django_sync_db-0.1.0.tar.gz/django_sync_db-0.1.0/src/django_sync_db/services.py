import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import pymysql
import psycopg2
import pymongo
import sqlite3
import pyodbc
from django.db import connections, transaction
from django.utils import timezone
from .models import ExternalDatabase, TableMapping, SyncTask, SyncLog, DailySyncTask

logger = logging.getLogger(__name__)


class DatabaseConnectionError(Exception):
    """数据库连接异常"""
    pass


class DatabaseConnection:
    """数据库连接管理器"""
    
    def __init__(self, external_db: ExternalDatabase):
        self.external_db = external_db
        self.connection = None
        self.cursor = None
        
    def connect(self):
        """建立数据库连接"""
        try:
            # 如果已经连接，直接返回
            if self.connection:
                return True
                
            if self.external_db.db_type == 'mysql':
                self.connection = pymysql.connect(
                    host=self.external_db.host,
                    port=self.external_db.port,
                    user=self.external_db.username,
                    password=self.external_db.password,
                    database=self.external_db.database_name,
                    charset='utf8mb4',
                    **self.external_db.extra_params
                )
            elif self.external_db.db_type == 'postgresql':
                self.connection = psycopg2.connect(
                    host=self.external_db.host,
                    port=self.external_db.port,
                    user=self.external_db.username,
                    password=self.external_db.password,
                    database=self.external_db.database_name,
                    **self.external_db.extra_params
                )
            elif self.external_db.db_type == 'mongodb':
                client_uri = f"mongodb://{self.external_db.username}:{self.external_db.password}@{self.external_db.host}:{self.external_db.port}"
                self.connection = pymongo.MongoClient(client_uri, **self.external_db.extra_params)
                self.connection = self.connection[self.external_db.database_name]
            elif self.external_db.db_type == 'mssql':
                # 构建MSSQL连接字符串
                driver = self.external_db.extra_params.get('driver', 'ODBC Driver 17 for SQL Server')
                connection_string = (
                    f"DRIVER={{{driver}}};"
                    f"SERVER={self.external_db.host},{self.external_db.port};"
                    f"DATABASE={self.external_db.database_name};"
                    f"UID={self.external_db.username};"
                    f"PWD={self.external_db.password};"
                    f"TrustServerCertificate=yes;"  # 信任服务器证书，避免SSL问题
                )
                
                # 添加额外的连接参数
                extra_params = self.external_db.extra_params
                if 'timeout' in extra_params:
                    connection_string += f"Timeout={extra_params['timeout']};"
                if 'encrypt' in extra_params:
                    connection_string += f"Encrypt={extra_params['encrypt']};"
                if 'connection_timeout' in extra_params:
                    connection_string += f"Connection Timeout={extra_params['connection_timeout']};"
                
                self.connection = pyodbc.connect(connection_string)
                
            elif self.external_db.db_type == 'sqlite':
                # 对于SQLite内存数据库，使用单例模式
                if self.external_db.database_name == ':memory:':
                    if not hasattr(DatabaseConnection, '_memory_connections'):
                        DatabaseConnection._memory_connections = {}
                    
                    db_key = f"{self.external_db.name}_{id(self.external_db)}"
                    if db_key not in DatabaseConnection._memory_connections:
                        DatabaseConnection._memory_connections[db_key] = sqlite3.connect(':memory:', check_same_thread=False)
                    
                    self.connection = DatabaseConnection._memory_connections[db_key]
                else:
                    self.connection = sqlite3.connect(self.external_db.database_name)
            else:
                raise DatabaseConnectionError(f"不支持的数据库类型: {self.external_db.db_type}")
                
            logger.info(f"成功连接到数据库: {self.external_db.name}")
            return True
            
        except Exception as e:
            logger.error(f"连接数据库失败 {self.external_db.name}: {str(e)}")
            raise DatabaseConnectionError(f"连接失败: {str(e)}")
    
    def test_connection(self) -> bool:
        """测试数据库连接"""
        try:
            self.connect()
            if self.external_db.db_type in ['mysql', 'postgresql', 'sqlite', 'mssql']:
                cursor = self.connection.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()
                cursor.close()
            elif self.external_db.db_type == 'mongodb':
                self.connection.list_collection_names()
            
            self.close()
            return True
        except Exception as e:
            logger.error(f"测试连接失败: {str(e)}")
            return False
    
    def get_table_columns(self, table_name: str) -> List[str]:
        """获取表字段列表"""
        try:
            self.connect()
            
            if self.external_db.db_type == 'mysql':
                cursor = self.connection.cursor()
                cursor.execute(f"DESCRIBE {table_name}")
                columns = [row[0] for row in cursor.fetchall()]
                cursor.close()
            elif self.external_db.db_type == 'postgresql':
                cursor = self.connection.cursor()
                cursor.execute("""
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_name = %s
                """, (table_name,))
                columns = [row[0] for row in cursor.fetchall()]
                cursor.close()
            elif self.external_db.db_type == 'mssql':
                cursor = self.connection.cursor()
                cursor.execute("""
                    SELECT COLUMN_NAME 
                    FROM INFORMATION_SCHEMA.COLUMNS 
                    WHERE TABLE_NAME = ?
                """, (table_name,))
                columns = [row[0] for row in cursor.fetchall()]
                cursor.close()
            elif self.external_db.db_type == 'sqlite':
                cursor = self.connection.cursor()
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns = [row[1] for row in cursor.fetchall()]
                cursor.close()
            elif self.external_db.db_type == 'mongodb':
                collection = self.connection[table_name]
                doc = collection.find_one()
                columns = list(doc.keys()) if doc else []
            else:
                raise DatabaseConnectionError(f"不支持的数据库类型: {self.external_db.db_type}")
            
            self.close()
            return columns
            
        except Exception as e:
            logger.error(f"获取表字段失败: {str(e)}")
            raise DatabaseConnectionError(f"获取表字段失败: {str(e)}")
    
    def execute_query(self, query: str, params: Optional[tuple] = None, keep_connection: bool = False) -> List[Dict[str, Any]]:
        """执行查询并返回结果"""
        try:
            self.connect()
            
            if self.external_db.db_type in ['mysql', 'postgresql', 'sqlite']:
                cursor = self.connection.cursor()
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                rows = cursor.fetchall()
                
                result = []
                for row in rows:
                    result.append(dict(zip(columns, row)))
                
                cursor.close()
            elif self.external_db.db_type == 'mssql':
                cursor = self.connection.cursor()
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                
                columns = [column[0] for column in cursor.description] if cursor.description else []
                rows = cursor.fetchall()
                
                result = []
                for row in rows:
                    result.append(dict(zip(columns, row)))
                
                cursor.close()
            elif self.external_db.db_type == 'mongodb':
                # MongoDB查询需要特殊处理
                collection_name = query  # 这里简化处理，实际应该解析查询
                collection = self.connection[collection_name]
                cursor = collection.find({})
                result = list(cursor)
            else:
                raise DatabaseConnectionError(f"不支持的数据库类型: {self.external_db.db_type}")
            
            if not keep_connection:
                self.close()
            return result
            
        except Exception as e:
            logger.error(f"执行查询失败: {str(e)}")
            raise DatabaseConnectionError(f"执行查询失败: {str(e)}")
    
    def close(self):
        """关闭数据库连接"""
        if self.connection:
            if self.external_db.db_type in ['mysql', 'postgresql', 'sqlite', 'mssql']:
                self.connection.close()
            elif self.external_db.db_type == 'mongodb':
                self.connection.client.close()
            self.connection = None


class DataSyncService:
    """数据同步服务"""
    
    def __init__(self, sync_task: SyncTask):
        self.sync_task = sync_task
        self.table_mapping = sync_task.table_mapping
        self.external_db = self.table_mapping.external_db
        self.db_connection = DatabaseConnection(self.external_db)
        
    def log(self, level: str, message: str, details: Optional[Dict] = None):
        """记录同步日志"""
        SyncLog.objects.create(
            sync_task=self.sync_task,
            level=level,
            message=message,
            details=details or {}
        )
        logger.info(f"[{level}] {message}")
    
    def build_query(self, date_filter: Optional[str] = None) -> str:
        """构建查询SQL"""
        base_query = f"SELECT * FROM {self.table_mapping.external_table}"
        
        conditions = []
        
        # 添加筛选条件
        if self.table_mapping.filter_sql:
            conditions.append(self.table_mapping.filter_sql)
        
        # 添加日期过滤
        if date_filter:
            conditions.append(date_filter)
        
        if conditions:
            base_query += " WHERE " + " AND ".join(conditions)
        
        return base_query
    
    def get_date_filter(self, start_date: Optional[datetime] = None, 
                       end_date: Optional[datetime] = None) -> Optional[str]:
        """生成日期过滤条件"""
        if not start_date and not end_date:
            return None
        
        # 假设表中有created_at字段，实际应该从配置中获取
        conditions = []
        if start_date:
            conditions.append(f"created_at >= '{start_date.strftime('%Y-%m-%d')}'")
        if end_date:
            conditions.append(f"created_at <= '{end_date.strftime('%Y-%m-%d')}'")
        
        return " AND ".join(conditions) if conditions else None
    
    def transform_data(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """根据字段映射转换数据"""
        transformed = {}
        field_mapping = self.table_mapping.field_mapping
        
        for external_field, local_field in field_mapping.items():
            if external_field in record:
                transformed[local_field] = record[external_field]
        
        return transformed
    
    def save_to_local_db(self, data: List[Dict[str, Any]]) -> int:
        """保存数据到本地数据库"""
        if not data:
            return 0
        
        # 这里需要根据实际的本地模型来保存数据
        # 简化实现，实际应该动态获取模型类
        saved_count = 0
        
        try:
            with transaction.atomic():
                for record in data:
                    transformed_record = self.transform_data(record)
                    # 这里应该根据local_model动态获取模型类并保存
                    # ModelClass.objects.create(**transformed_record)
                    saved_count += 1
                    
        except Exception as e:
            self.log('ERROR', f"保存数据到本地数据库失败: {str(e)}")
            raise
        
        return saved_count
    
    def sync_data(self, start_date: Optional[datetime] = None, 
                 end_date: Optional[datetime] = None) -> Dict[str, int]:
        """执行数据同步"""
        start_time = time.time()
        
        try:
            self.log('INFO', f"开始同步数据: {self.table_mapping.external_table}")
            
            # 构建查询
            date_filter = self.get_date_filter(start_date, end_date)
            query = self.build_query(date_filter)
            
            self.log('DEBUG', f"执行查询: {query}")
            
            # 执行查询
            data = self.db_connection.execute_query(query)
            total_records = len(data)
            
            self.sync_task.total_records = total_records
            self.sync_task.save()
            
            self.log('INFO', f"查询到 {total_records} 条记录")
            
            if not data:
                self.log('WARNING', "没有数据需要同步")
                return {
                    'total': 0,
                    'success': 0,
                    'failed': 0
                }
            
            # 分批处理数据
            batch_size = 1000
            success_count = 0
            failed_count = 0
            
            for i in range(0, total_records, batch_size):
                batch_data = data[i:i + batch_size]
                
                try:
                    saved_count = self.save_to_local_db(batch_data)
                    success_count += saved_count
                    
                    self.sync_task.processed_records = min(i + batch_size, total_records)
                    self.sync_task.success_records = success_count
                    self.sync_task.save()
                    
                    self.log('INFO', f"已处理 {min(i + batch_size, total_records)}/{total_records} 条记录")
                    
                except Exception as e:
                    failed_count += len(batch_data)
                    self.log('ERROR', f"处理批次数据失败: {str(e)}")
            
            execution_time = time.time() - start_time
            
            result = {
                'total': total_records,
                'success': success_count,
                'failed': failed_count,
                'execution_time': execution_time
            }
            
            self.sync_task.execution_time = execution_time
            self.sync_task.failed_records = failed_count
            self.sync_task.save()
            
            self.log('INFO', f"同步完成: 总计{total_records}, 成功{success_count}, 失败{failed_count}, 耗时{execution_time:.2f}秒")
            
            return result
            
        except Exception as e:
            self.log('ERROR', f"同步过程中发生错误: {str(e)}")
            raise
    
    def test_mapping(self) -> Dict[str, Any]:
        """测试表映射配置"""
        try:
            # 测试数据库连接
            if not self.db_connection.test_connection():
                return {
                    'success': False,
                    'error': '数据库连接失败'
                }
            
            # 测试表是否存在
            columns = self.db_connection.get_table_columns(self.table_mapping.external_table)
            
            # 验证字段映射
            field_mapping = self.table_mapping.field_mapping
            missing_fields = []
            
            for external_field in field_mapping.keys():
                if external_field not in columns:
                    missing_fields.append(external_field)
            
            if missing_fields:
                return {
                    'success': False,
                    'error': f'外部表缺少字段: {", ".join(missing_fields)}'
                }
            
            # 测试查询
            query = self.build_query()
            test_data = self.db_connection.execute_query(query + " LIMIT 1")
            
            return {
                'success': True,
                'columns': columns,
                'sample_data': test_data[0] if test_data else None
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }