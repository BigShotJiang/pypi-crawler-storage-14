from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import json


class ExternalDatabase(models.Model):
    """外部数据库连接配置"""
    DB_TYPE_CHOICES = [
        ('mysql', 'MySQL'),
        ('postgresql', 'PostgreSQL'),
        ('mongodb', 'MongoDB'),
        ('sqlite', 'SQLite'),
        ('mssql', 'Microsoft SQL Server'),
    ]
    
    name = models.CharField('数据库名称', max_length=100, unique=True)
    db_type = models.CharField('数据库类型', max_length=20, choices=DB_TYPE_CHOICES)
    host = models.CharField('主机地址', max_length=255)
    port = models.IntegerField('端口号', default=3306)
    database_name = models.CharField('数据库名', max_length=100)
    username = models.CharField('用户名', max_length=100)
    password = models.CharField('密码', max_length=255)
    extra_params = models.JSONField('额外参数', default=dict, blank=True)
    is_active = models.BooleanField('是否启用', default=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '外部数据库'
        verbose_name_plural = '外部数据库'

    def __str__(self):
        return f"{self.name} ({self.db_type})"


class TableMapping(models.Model):
    """表映射配置"""
    external_db = models.ForeignKey(ExternalDatabase, on_delete=models.CASCADE, verbose_name='外部数据库')
    external_table = models.CharField('外部表名', max_length=100)
    local_model = models.CharField('本地模型名', max_length=100)
    field_mapping = models.JSONField('字段映射', default=dict, help_text='格式: {"外部字段名": "本地字段名"}')
    filter_sql = models.TextField('筛选SQL', blank=True, help_text='用于筛选数据的SQL条件')
    is_active = models.BooleanField('是否启用', default=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '表映射'
        verbose_name_plural = '表映射'
        unique_together = ['external_db', 'external_table']

    def __str__(self):
        return f"{self.external_table} -> {self.local_model}"


class SyncTask(models.Model):
    """同步任务"""
    STATUS_CHOICES = [
        ('pending', '等待中'),
        ('running', '运行中'),
        ('completed', '已完成'),
        ('failed', '失败'),
        ('cancelled', '已取消'),
    ]
    
    table_mapping = models.ForeignKey(TableMapping, on_delete=models.CASCADE, verbose_name='表映射')
    task_id = models.CharField('任务ID', max_length=255, unique=True, null=True, blank=True)
    status = models.CharField('状态', max_length=20, choices=STATUS_CHOICES, default='pending')
    start_date = models.DateField('开始日期', null=True, blank=True)
    end_date = models.DateField('结束日期', null=True, blank=True)
    total_records = models.IntegerField('总记录数', default=0)
    processed_records = models.IntegerField('已处理记录数', default=0)
    success_records = models.IntegerField('成功记录数', default=0)
    failed_records = models.IntegerField('失败记录数', default=0)
    error_message = models.TextField('错误信息', blank=True)
    execution_time = models.FloatField('执行时间(秒)', null=True, blank=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, verbose_name='创建者')
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    started_at = models.DateTimeField('开始时间', null=True, blank=True)
    completed_at = models.DateTimeField('完成时间', null=True, blank=True)

    class Meta:
        verbose_name = '同步任务'
        verbose_name_plural = '同步任务'

    def __str__(self):
        return f"同步任务 {self.id} - {self.table_mapping}"


class SyncLog(models.Model):
    """同步日志"""
    LEVEL_CHOICES = [
        ('INFO', '信息'),
        ('WARNING', '警告'),
        ('ERROR', '错误'),
        ('DEBUG', '调试'),
    ]
    
    sync_task = models.ForeignKey(SyncTask, on_delete=models.CASCADE, verbose_name='同步任务', related_name='logs')
    level = models.CharField('日志级别', max_length=10, choices=LEVEL_CHOICES)
    message = models.TextField('日志消息')
    details = models.JSONField('详细信息', default=dict, blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '同步日志'
        verbose_name_plural = '同步日志'
        ordering = ['-created_at']

    def __str__(self):
        return f"[{self.level}] {self.sync_task} - {self.created_at}"


class DailySyncTask(models.Model):
    """每日同步任务"""
    STATUS_CHOICES = [
        ('pending', '等待中'),
        ('running', '运行中'),
        ('completed', '已完成'),
        ('failed', '失败'),
        ('skipped', '跳过'),
    ]
    
    parent_task = models.ForeignKey(SyncTask, on_delete=models.CASCADE, verbose_name='父任务', related_name='daily_tasks')
    sync_date = models.DateField('同步日期')
    task_id = models.CharField('任务ID', max_length=255, unique=True, null=True, blank=True)
    status = models.CharField('状态', max_length=20, choices=STATUS_CHOICES, default='pending')
    total_records = models.IntegerField('总记录数', default=0)
    processed_records = models.IntegerField('已处理记录数', default=0)
    success_records = models.IntegerField('成功记录数', default=0)
    failed_records = models.IntegerField('失败记录数', default=0)
    error_message = models.TextField('错误信息', blank=True)
    execution_time = models.FloatField('执行时间(秒)', null=True, blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    started_at = models.DateTimeField('开始时间', null=True, blank=True)
    completed_at = models.DateTimeField('完成时间', null=True, blank=True)

    class Meta:
        verbose_name = '每日同步任务'
        verbose_name_plural = '每日同步任务'
        unique_together = ['parent_task', 'sync_date']
        ordering = ['-sync_date']

    def __str__(self):
        return f"{self.sync_date} - {self.parent_task.table_mapping.external_table}"