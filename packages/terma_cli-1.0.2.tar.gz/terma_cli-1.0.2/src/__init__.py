
"""
__init__.py — imports and runs the command-line interface (CLI) application for Terma.
"""

if __name__ == "__main__":
    from src.cli import app
    app()
