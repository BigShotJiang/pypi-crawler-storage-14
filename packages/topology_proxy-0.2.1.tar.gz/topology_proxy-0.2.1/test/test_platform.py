# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 Hewlett Packard Enterprise Development LP.
# All Rights Reserved.
#
# The contents of this software are proprietary and confidential to the Hewlett
# Packard Enterprise Development LP. No part of this program may be
# photocopied, reproduced, or translated into another programming language
# without prior written consent of the Hewlett Packard Enterprise Development
# LP.

"""
Tests the platform module.
"""

from topology.manager import TopologyManager
from topotest_platform.platform import INJECTED_METADATA


def test_platform():
    """
    Use topology manager to build a topology that uses the topotest platform
    which inherits from the proxy platform.

    The topotest platform is a minimal package defined for testing purposes
    only and is located in the test/topotest_platform directory.
    """
    # Find a resource of the required platform on production and reserve it
    topodesc = f"""
        [type=debug] my_node
    """  # noqa
    # use hmmock to just find the topo with no reservation
    tpmgr = TopologyManager(engine='topotest')
    tpmgr.parse(topodesc)
    tpmgr.resolve()
    tpmgr.build()

    # Verify that topotest platform proxies to debug platform
    platform = tpmgr._platform
    assert platform.__class__.__name__ == 'TestPlatform'
    assert platform._wrapped_platform.__class__.__name__ == 'DebugPlatform'

    # Verify the Test Platform injected metadata to the node
    node = tpmgr.get('my_node')
    for key, value in INJECTED_METADATA.items():
        assert node.metadata[key] == value
