# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 Hewlett Packard Enterprise Development LP.
# All Rights Reserved.
#
# The contents of this software are proprietary and confidential to the Hewlett
# Packard Enterprise Development LP. No part of this program may be
# photocopied, reproduced, or translated into another programming language
# without prior written consent of the Hewlett Packard Enterprise Development
# LP.

"""
Tests to check valid package version.
"""

from packaging import version

from topology_proxy import __version__


def test_version():
    """
    Check that version is PEP 440 compliant.

        https://www.python.org/dev/peps/pep-0440/

    This is basically the basic test to bootstrap a pytest testing suite.
    """
    assert version.parse(__version__) >= version.parse('0.1.0')
