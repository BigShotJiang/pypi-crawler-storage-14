==============
Topology Proxy
==============

Topology Proxy platform


A proxy platform class wraps a platform class and intercepts every call
from topology core to the wrapped platform.

In the constructor, the proxy platform class receives a graph object from
topology core and replaces it with a new graph object that is a modified
version of the original graph object.

During the interception of the calls, the proxy platform class uses the
identifier of every object being passed by topology core to find the
corresponding object in the modified graph object and pass it to the
wrapped platform instead of the original object.

The following diagram shows the relationship between the proxy platform,
the wrapped platform and the topology core. The method add_node() is
used as an example to illustrate the interception of calls.

.. code-block::

    +------------+              +-----------+   replacement   +-----------+
    |            |    graph     |           |     graph       |           |
    |            |    node      |           |     node        |           |
    |  Topology  | -----------> |  Proxy    | --------------> |  Wrapped  |
    |  Core      | add_node()   |  Platform |   add_node()    |  Platform |
    |            |              |           |                 |           |
    |            |              |           |                 |           |
    +------------+              +-----------+                 +-----------+


Documentation
=============

    https://darks.rose.rdlabs.hpecorp.net/docs/topology_proxy


Install
=======

.. code-block:: sh

    pip3 install --trusted-host pvsdk-pypi.rose.rdlabs.hpecorp.net --index-url https://pvsdk-pypi.rose.rdlabs.hpecorp.net/ topology_proxy


Changelog
=========

0.1.0 (2020-02-01)
------------------

New
~~~

- Development preview.


License
=======

::

   Copyright (C) 2023 Hewlett Packard Enterprise Development LP.
   All Rights Reserved.

   The contents of this software are proprietary and confidential to the
   Hewlett Packard Enterprise Development LP. No part of this program may be
   photocopied, reproduced, or translated into another programming language
   without prior written consent of the Hewlett Packard Enterprise Development
   LP.
