# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 Hewlett Packard Enterprise Development LP.
# All Rights Reserved.
#
# The contents of this software are proprietary and confidential to the Hewlett
# Packard Enterprise Development LP. No part of this program may be
# photocopied, reproduced, or translated into another programming language
# without prior written consent of the Hewlett Packard Enterprise Development
# LP.

"""
topology_proxy module entry point.
"""

__author__ = 'Hewlett Packard Enterprise Development LP'
__email__ = 'tnf@groups.ext.hpe.com'
__version__ = '0.2.1'
