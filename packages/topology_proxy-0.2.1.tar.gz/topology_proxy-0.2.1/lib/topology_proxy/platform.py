# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 Hewlett Packard Enterprise Development LP.
# All Rights Reserved.
#
# The contents of this software are proprietary and confidential to the Hewlett
# Packard Enterprise Development LP. No part of this program may be
# photocopied, reproduced, or translated into another programming language
# without prior written consent of the Hewlett Packard Enterprise Development
# LP.

"""
topology_proxy platform module
"""

from typing import Tuple
from abc import ABC, abstractmethod

from topology.platforms.node import BaseNode
from topology.platforms.platform import BasePlatform
from topology.graph import TopologyGraph, Node, Port, Link


class ProxyPlatform(ABC, BasePlatform):
    """
    Abstract class that defines the interface for a proxy platform.

    A proxy platform class wraps a platform class and intercepts every call
    from topology core to the wrapped platform.

    In the constructor, the proxy platform class receives a graph object from
    topology core and replaces it with a new graph object that is a modified
    version of the original graph object.

    During the interception of the calls, the proxy platform class uses the
    identifier of every object being passed by topology core to find the
    corresponding object in the modified graph object and pass it to the
    wrapped platform instead of the original object.

    The following diagram shows the relationship between the proxy platform,
    the wrapped platform and the topology core. The method add_node() is
    used as an example to illustrate the interception of calls.

    +------------+              +-----------+   replacement   +-----------+
    |            |    graph     |           |     graph       |           |
    |            |    node      |           |     node        |           |
    |  Topology  | -----------> |  Proxy    | --------------> |  Wrapped  |
    |  Core      | add_node()   |  Platform |   add_node()    |  Platform |
    |            |              |           |                 |           |
    |            |              |           |                 |           |
    +------------+              +-----------+                 +-----------+
    """

    def __init__(self, timestamp, graph: TopologyGraph, **kwargs):
        self._timestamp = timestamp
        self._raw_graph = graph
        self._extra_options = kwargs

        self.graph = None
        self._wrapped_platform = None

    def resolve(self):
        """
        Resolve the proxy platform.
        """
        self.graph = self.get_graph_replacement(
            self._timestamp,
            self._raw_graph,
            **self._extra_options
        )

        self._wrapped_platform = self.create_wrapped_platform(
            self._timestamp,
            **self._extra_options
        )

    @abstractmethod
    def get_graph_replacement(
        self,
        timestamp,
        graph: TopologyGraph,
        **kwargs
    ) -> TopologyGraph:
        pass

    @abstractmethod
    def create_wrapped_platform(
        self,
        timestamp,
        **kwargs
    ) -> BasePlatform:
        pass

    def __getattr__(self, name: str):
        """
        Magic method to proxy all other calls to the wrapped platform.

        If something is not defined by the proxy platform, it will be
        proxied to the wrapped platform.

        :param name: Name of the attribute to get.
        """
        if '_wrapped_platform' in self.__dict__:
            return getattr(self._wrapped_platform, name)
        raise AttributeError(
            f"'{self.__class__.__name__}' object has no attribute '{name}'"
        )

    def add_node(self, node: Node) -> BaseNode:
        """
        Add a node to the platform.

        This method receives a Topology Graph node and must return a new
        Engine Node subclass of :class:`BaseNode` that implements the
        communication mechanism with that node.

        :param node: The Topology Graph node to add to the platform.
        :type node: :class:`topology.graph.Node`
        :rtype: BaseNode
        :return: Platform specific communication node.
        """
        repl_node = self.graph.get_node(node.identifier)
        return self._wrapped_platform.add_node(repl_node)

    def add_biport(self, node: Node, port: Port) -> str:
        """
        Add a bidirectional port to the given node.

        This method receives a Topology Graph node and a port that
        specifies the port required to be added. This methods returns nothing
        as the topology users don't expect to deal directly with ports. All
        interaction is done with the nodes.

        :param node: Topology Graph Node owner of the port, holding the node
         metadata.
        :type node: :class:`topology.graph.Node`
        :param port: The Topology Graph Port holding the port metadata.
        :type port: :class:`topology.graph.Port`
        :rtype: str
        :return: Real name of the port in the node. This real will be used to
         populate an internal map between the specification name of the port
         and the real name, which can be used to reference the port in commands
         without knowing it's real name in advance.
        """
        # Find the node and port in the validated nml manager object
        repl_node = self.graph.get_node(node.identifier)
        repl_port = self.graph.get_port_by_id(port.identifier)

        # Call method of the wrapped platform with replacement objects
        return self._wrapped_platform.add_biport(repl_node, repl_port)

    def add_bilink(
        self,
        nodeport_a: Tuple[Node, Port],
        nodeport_b: Tuple[Node, Port],
        link: Link
    ):
        """
        Add a link between given nodes and ports.

        This method receives two tuples with the nodes and ports associated
        with the link and the link object to be added to the platform.

        Notice the ``nodeport_a`` and ``nodeport_b`` are passed for backwards
        compatibility. However, now the link object contains the ports and
        nodes associated to the link, so newer platform implementations could
        just ignore ``nodeport_a`` and ``nodeport_b``.

        :param nodeport_a: A tuple (Node, Port) of the first endpoint.
        :type nodeport_a:
         (:class:`topology.graph.Node`, :class:`topology.graph.Port`)
        :param nodeport_b: A tuple (Node, Port) of the second endpoint.
        :type nodeport_b:
         (:class:`topology.graph.Node`, :class:`topology.graph.Port`)
        :param link: The Topology Graph Link.
        :type link: :class:`topology.graph.Link`
        """
        node_a, port_a = nodeport_a
        node_b, port_b = nodeport_b

        # Find the nodes, ports and link objet in the replacement graph
        repl_node_a = self.graph.get_node(node_a.identifier)
        repl_node_b = self.graph.get_node(node_b.identifier)

        repl_port_a = self.graph.get_port_by_id(port_a.identifier)
        repl_port_b = self.graph.get_port_by_id(port_b.identifier)

        repl_bilink = self.graph.get_link_by_id(link.identifier)

        # Call method of the wrapped platform with replacement objects
        return self._wrapped_platform.add_bilink(
            (repl_node_a, repl_port_a),
            (repl_node_b, repl_port_b),
            repl_bilink
        )

    # The following methods require explicit implementation in the proxy
    # platform because these are abstract methods in the BasePlatform class.
    # Notice __getattr__ does not exempt oneself from implementing abstract
    # methods.

    def pre_build(self):
        """
        Preamble hook.

        This hook is called at the first stage of the topology build.
        Use it to setup any requirements your platform has.
        """
        self._wrapped_platform.pre_build()

    def post_build(self):
        """
        Postamble hook.

        This hook is called at the last stage of the topology build.
        Use it to setup any final requirements or start any service before
        using the topology.
        """
        self._wrapped_platform.post_build()

    def destroy(self):
        """
        Platform destruction hook.

        Use this to remove all elements from the platform, perform any clean
        and return resources.
        """
        self._wrapped_platform.destroy()

    def rollback(self, stage, enodes, exception):
        """
        Platform rollback hook.

        This is called when the build fails, possibly by an exception raised in
        previous hooks.

        :param str stage: The stage the build failed. One of:
         - ``pre_build``.
         - ``add_node``.
         - ``add_biport``.
         - ``add_bilink``.
         - ``post_build``.
        :param enodes: Engine nodes already registered.
        :type enodes: OrderedDict of subclasses of :class:`BaseNode`
        :param Exception exception: The exception caught during build failure.
        """
        self._wrapped_platform.rollback(stage, enodes, exception)

    def relink(self, link_id):
        """
        Relink back a link specified in the topology.

        :param str link_id: Link identifier to be recreated.
        """
        self._wrapped_platform.relink(link_id)

    def unlink(self, link_id):
        """
        Unlink (break) a link specified in the topology.

        :param str link_id: Link identifier to be undone.
        """
        self._wrapped_platform.unlink(link_id)


__all__ = ['ProxyPlatform']
