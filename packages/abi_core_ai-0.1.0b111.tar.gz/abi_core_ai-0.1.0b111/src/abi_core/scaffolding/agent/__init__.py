"""
ABI Agent Scaffolding Templates
Plantillas para crear nuevos agentes ABI
"""

from pathlib import Path

TEMPLATE_DIR = Path(__file__).parent