version = "0.1.0"

Export convenient top-level names. Only import small, safe items —
avoid importing heavy runtime code or side-effectful modules at import-time.
from .carbon_calculator import *
from .email_service import *
from .queue_service import *

don't import app.py or lambda handlers automatically if they are runnable scripts