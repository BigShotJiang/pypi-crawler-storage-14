class CarbonCalculator:
    def __init__(self, electricity_kwh, water_litres, meals, laundry_loads):
        self.electricity = float(electricity_kwh)
        self.water = float(water_litres)
        self.meals = int(meals)
        self.laundry = float(laundry_loads)

    def calculate_total_emission(self):
        # CO₂ emission factors
        e_factor = 0.45     # kg CO₂ per kWh
        w_factor = 0.0003   # kg CO₂ per litre of water
        m_factor = 1.8      # kg CO₂ per meal
        l_factor = 0.6      # kg CO₂ per laundry load

        total = (self.electricity * e_factor +
                 self.water * w_factor +
                 self.meals * m_factor +
                 self.laundry * l_factor)
        return round(total, 2)
