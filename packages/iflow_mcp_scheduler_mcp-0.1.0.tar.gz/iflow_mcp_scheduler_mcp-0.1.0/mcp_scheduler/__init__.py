"""
MCP Scheduler - A Model Context Protocol server for task scheduling.
"""

__version__ = "0.1.0"
