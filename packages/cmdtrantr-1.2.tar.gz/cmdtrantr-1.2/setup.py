from setuptools import setup, find_packages

setup(
    name="cmdtrantr",
    version="1.2",
    description="CLI tabanlı rehber + çeviri + kelime quiz uygulaması",
    author="Muhammed Yusuf Özkaya",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "requests",
        "packaging"
    ],
    entry_points={
        "console_scripts": [
            "cmdtrantr=cmdtrantr.cli:main"
        ]
    },
    python_requires='>=3.7',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)