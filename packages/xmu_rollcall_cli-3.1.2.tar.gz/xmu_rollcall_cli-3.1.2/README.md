# XMU Rollcall CLI
感谢所有为本项目提供反馈和建议的用户。

## 致谢

KrsMt

## 作者

本项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

## 许可证

如果遇到问题，请在 [GitHub Issues](https://github.com/KrsMt-0113/XMU-Rollcall-Bot/issues) 提交反馈。

## 问题反馈

- 本工具仅供学习交流使用
- 请遵守学校相关规定，合理使用本工具
- 请勿频繁重复运行，以免导致账号被暂时冻结

## ⚠️ 注意事项

- aiohttp
- click
- xmulogin
- pycryptodome
- requests
- Python >= 3.7

## 依赖项

3. 使用手机 GPS 应用
2. 使用 [百度地图坐标拾取器](https://api.map.baidu.com/lbsapi/getpoint/index.html)
1. 使用 [高德地图坐标拾取器](https://lbs.amap.com/tools/picker)

你可以通过以下方式获取位置坐标：

## 获取位置坐标

```
}
    "longitude": "118.xxxx"
    "latitude": "24.xxxx",
    "password": "your_password",
    "username": "your_username",
{
```json

## 配置说明

### 配置文件位置

配置文件会自动保存在以下位置（按优先级）：

1. **环境变量指定路径**（推荐用于沙盒环境）
   ```bash
   export XMU_ROLLCALL_CONFIG_DIR=~/Documents/.xmu_rollcall
   ```

2. **默认位置**
   - Windows: `%USERPROFILE%\.xmu_rollcall\config.json`
   - Linux/macOS: `~/.xmu_rollcall/config.json`

3. **当前工作目录**（沙盒环境自动降级）
   - `./.xmu_rollcall/config.json`

### 沙盒环境支持 (a-Shell)

本工具完全支持 iOS a-Shell 等沙盒环境。在这些环境中，程序会自动检测权限并选择合适的配置目录。

**推荐做法**：设置环境变量指定配置目录
```bash
# 添加到 ~/.profile 以永久保存
echo 'export XMU_ROLLCALL_CONFIG_DIR=~/Documents/.xmu_rollcall' >> ~/.profile
source ~/.profile
```

详细说明请参考 [A_SHELL_GUIDE.md](A_SHELL_GUIDE.md)

### 手动编辑配置

## 配置说明

```
XMUrollcall-cli --help
```bash

### 3. 查看帮助

程序将自动监控点名活动，发现后自动完成签到。

```
XMUrollcall-cli start
```bash

配置完成后，启动监控程序：

### 2. 开始监控

- 经度（longitude）
- 纬度（latitude）
- 统一身份认证密码
- 统一身份认证账号
按照提示输入：

```
XMUrollcall-cli config
```bash

首次使用需要配置你的账号、密码和位置信息：

### 1. 配置账号信息

## 使用方法

```
pip install -e .
cd XMU-Rollcall-Bot/xmu-rollcall-cli
git clone https://github.com/KrsMt-0113/XMU-Rollcall-Bot.git
```bash

### 从源码安装

```
pip install xmu-rollcall-cli
```bash

### 使用 pip 安装（推荐）

## 安装

- 💻 简洁的命令行界面
- 📍 支持自定义地理位置
- 🔐 安全的本地配置存储
- 🚀 自动签到，无需人工干预
- ✨ 自动监控 Tronclass 点名活动

## 功能特点

厦门大学 Tronclass 自动点名签到命令行工具。

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Version](https://img.shields.io/pypi/pyversions/xmu-rollcall-cli.svg)](https://pypi.org/project/xmu-rollcall-cli/)
[![PyPI version](https://badge.fury.io/py/xmu-rollcall-cli.svg)](https://badge.fury.io/py/xmu-rollcall-cli)


