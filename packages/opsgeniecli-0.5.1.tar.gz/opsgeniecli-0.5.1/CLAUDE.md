# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is **opsgeniecli**, a command-line interface for Atlassian Opsgenie built with Typer and Rich. It wraps the `opsgenielib` library (located at `../opsgenielib` as an editable dependency) to provide convenient commands for managing alerts, on-call schedules, and configuration profiles.

## Development Commands

```bash
# Install for development (editable mode)
uv sync --dev

# Run the CLI
opsgeniecli --help

# Lint and format
ruff check src/
black .
pytype src/

# Run tests
pytest

# Run specific test file
pytest tests/test_config.py -v
```

## Architecture

### Command Structure

The CLI uses Typer's composition pattern where each feature area is a separate module with its own Typer app:

- `src/opsgeniecli/cli.py` - Main entry point that composes sub-commands
- `src/opsgeniecli/commands/alerts.py` - Alert management commands
- `src/opsgeniecli/commands/on_call.py` - On-call schedule commands
- `src/opsgeniecli/commands/config.py` - Configuration profile management

Each command module creates its own `app = typer.Typer()` instance and is added to the root app via `app.add_typer()` in `cli.py`.

### Context Object Pattern

The CLI uses a centralized context object (`OpsgenieCli` class in cli.py:19-22) attached to `ctx.obj` in the root callback. All commands access the Opsgenie client and configuration through this object:

```python
ctx.obj = OpsgenieCli(opsgenie=opsgenie, config=_config, profile=profile)
```

Command functions receive this via `ctx: typer.Context` parameter and access `ctx.obj.opsgenie`, `ctx.obj.config`, and `ctx.obj.profile`.

### Configuration Management

Configuration is stored at `~/.config/opsgenie-cli/config.json` by default and managed by the `Config` and `ConfigProfile` classes in commands/config.py. The config supports multiple profiles, each containing a team name and API key.

API credentials can be provided via:
- Config file profiles (selected with `--profile` or `OPSGENIE_PROFILE` env var)
- Environment variables: `OPSGENIE_API_KEY`, `OPSGENIE_TEAM_NAME`
- Command-line options: `--api-key`, `--team-name`

### Helper Utilities

`src/opsgeniecli/helper.py` provides two key utilities:
- `get_table(data: list[dict], ...)` - Creates Rich tables from list of dictionaries for consistent terminal output
- `_apply_regex_filters(data: list[dict], filters: dict[str, re.Pattern])` - Applies regex patterns to filter lists of dictionaries, enabling flexible CLI filtering

### Output and Filtering

All list commands use Rich tables for formatted output. Commands support regex-based filtering via `--filters` options that accept patterns in the format `attribute:regex_pattern`. The helper utilities standardize this behavior across all commands.

## Key Patterns

1. **Modular commands**: New command groups should follow the pattern of creating a separate module with its own Typer app, then adding it to the root app in cli.py
2. **Context propagation**: Always use `ctx.obj` to access the Opsgenie client rather than creating new instances
3. **Table output**: Use `helper.get_table()` for consistent terminal formatting
4. **Regex filtering**: Use `helper._apply_regex_filters()` for implementing flexible filtering on list outputs
5. **Type hints**: The codebase uses typing throughout; maintain this for pytype compatibility

## Dependencies

- **opsgenielib**: The core library for Opsgenie API interaction (local editable dependency at ../opsgenielib)
- **typer**: CLI framework
- **rich**: Terminal formatting and tables
- **pytz**: Timezone handling for alerts

## Testing Approach

When tests are added, they should:
- Mock `ctx.obj` with test instances of OpsgenieCli containing mock Opsgenie clients
- Test individual functions directly (e.g., `_apply_regex_filters`, `_get_alerts_table_data`) as unit tests
- Avoid testing through the Typer framework; test the underlying Python functions instead

Recent commit d0bda5c moved away from mocking Typer's `ctx.obj` in favor of simpler unit tests of Python functions.


# todo
- instructions how to use
- [] alerts
- [x] config
- [] escalations
- [] heartbeat
- [] integrations
- [] logs
- [x] on-call
- [] override
- [] policy-alerts
- [] policy-maintenance
- [] policy-notifications
- [] schedules
- [] teams
- [] teams-routing-rules
- [] users