This Python library designed to help users **compare electronic products** such as mobiles, laptops, TVs, and more.  
It provides tools to fetch product details, display comparisons side‑by‑side.

