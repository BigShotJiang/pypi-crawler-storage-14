from setuptools import setup

setup(use_scm_version={"fallback_version": "9999"})
