#!/bin/sh
python -m pip install . --no-deps -vv
