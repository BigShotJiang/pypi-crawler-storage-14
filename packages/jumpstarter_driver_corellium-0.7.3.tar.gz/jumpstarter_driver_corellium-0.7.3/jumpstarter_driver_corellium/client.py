from jumpstarter_driver_composite.client import CompositeClient


class CorelliumClient(CompositeClient):
    pass
