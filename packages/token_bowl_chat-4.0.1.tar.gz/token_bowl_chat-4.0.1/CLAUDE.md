# Claude Code Instructions

## Git Workflow

- Only the user (rspectre) can push code to remote repositories
- Claude can commit changes locally but should never push
