"""Swiss Data Sources."""

from .comparis import ComparisSource

SOURCE_MAP = {
    "comparis": (ComparisSource, 1, 1,)
}
