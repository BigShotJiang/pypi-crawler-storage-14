"""AR Sources consts."""

AR_GOB_ENERGY_ID = "datos.energia.gob"
AR_GOB_DATASOURCE = "http://datos.energia.gob.ar/api/3/action/datastore_search"
AR_GOB_TIMEOUT = 60
