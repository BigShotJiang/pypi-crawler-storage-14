"""Germany Data Sources."""

from .tankerkoenig import TankerKoenigSource

SOURCE_MAP = {
    "tankerkoenig": (TankerKoenigSource, 1, 1,)
}
