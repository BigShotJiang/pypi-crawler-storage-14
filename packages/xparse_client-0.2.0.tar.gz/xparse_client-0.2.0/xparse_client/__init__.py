import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s',
    encoding='utf-8'
)

from .pipeline.config import ParseConfig, ChunkConfig, EmbedConfig, PipelineStats
from .pipeline.sources import Source, S3Source, LocalSource, FtpSource, SmbSource
from .pipeline.destinations import Destination, MilvusDestination, LocalDestination, S3Destination
from .pipeline.pipeline import Pipeline, create_pipeline_from_config

__all__ = [
    'ParseConfig',
    'ChunkConfig',
    'EmbedConfig',
    'PipelineStats',
    'Source',
    'S3Source',
    'LocalSource',
    'FtpSource',
    'SmbSource',
    'Destination',
    'MilvusDestination',
    'LocalDestination',
    'S3Destination',
    'Pipeline',
    'create_pipeline_from_config',
]

__version__ = '0.2.0'
