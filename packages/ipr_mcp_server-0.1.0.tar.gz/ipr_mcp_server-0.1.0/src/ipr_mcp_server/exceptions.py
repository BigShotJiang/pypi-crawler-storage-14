"""
Domain-specific exceptions.
"""

from typing import Any, Dict, Optional


class ConfigurationError(Exception):
    """Raised when required configuration is missing."""


class TsaAPIError(Exception):
    """Raised when the TSA gateway responds with a business error."""

    def __init__(
        self,
        method: str,
        code: str,
        message: str,
        sub_code: Optional[str] = None,
        sub_msg: Optional[str] = None,
        raw: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.method = method
        self.code = code
        self.message = message
        self.sub_code = sub_code
        self.sub_msg = sub_msg
        self.raw = raw or {}
        super().__init__(self.__str__())

    def __str__(self) -> str:
        return (
            f"TSA API error calling {self.method}: code={self.code} message={self.message} "
            f"sub_code={self.sub_code} sub_msg={self.sub_msg}"
        )
