"""
Cryptographic helpers: RSA2 signing, hash utilities, and MD5/sha256 helpers.
"""

from __future__ import annotations

import base64
import hashlib
import textwrap
from typing import Any, Dict

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.serialization import load_pem_private_key


def normalize_private_key(pem: str) -> bytes:
    """
    Accept single-line PKCS#8 PEM and return proper PEM bytes.
    """

    pem = pem.strip()
    if "BEGIN" in pem:
        return pem.encode("utf-8")
    wrapped = "\n".join(textwrap.wrap(pem, width=64))
    return (
        "-----BEGIN PRIVATE KEY-----\n"
        f"{wrapped}\n"
        "-----END PRIVATE KEY-----\n"
    ).encode("utf-8")


def load_private_key(pem: str):
    """Load a PKCS#8 RSA private key."""

    key_bytes = normalize_private_key(pem)
    return load_pem_private_key(key_bytes, password=None)


def drop_empty_and_sign(params: Dict[str, Any]) -> Dict[str, Any]:
    """Remove empty values and the sign field."""

    return {
        k: v
        for k, v in params.items()
        if k != "sign" and v is not None and v != "" and not isinstance(v, bytes)
    }


def build_sign_content(params: Dict[str, Any]) -> str:
    """Build the canonical string to sign."""

    filtered = drop_empty_and_sign(params)
    ordered = sorted(filtered.items(), key=lambda item: item[0])
    pairs = [f"{str(k)}={str(v)}" for k, v in ordered]
    return "&".join(pairs)


def rsa2_sign(content: str, private_key_pem: str) -> str:
    """Sign content with RSA2 (SHA256 + PKCS#1 v1.5) and return base64."""

    private_key = load_private_key(private_key_pem)
    signature = private_key.sign(
        content.encode("utf-8"),
        padding.PKCS1v15(),
        hashes.SHA256(),
    )
    return base64.b64encode(signature).decode("utf-8")


def calc_sha256_hex(data: bytes) -> str:
    """Return SHA-256 hex digest for bytes."""

    digest = hashlib.sha256()
    digest.update(data)
    return digest.hexdigest()


def calc_md5_base64(data: bytes) -> str:
    """Return Base64 encoded MD5 digest for bytes."""

    digest = hashlib.md5()
    digest.update(data)
    return base64.b64encode(digest.digest()).decode("utf-8")
