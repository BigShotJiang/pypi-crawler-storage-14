"""
FastMCP-powered MCP server bootstrap with stdio and WebSocket transports.
"""

from __future__ import annotations

import argparse
import logging
from dataclasses import dataclass
from importlib import metadata
from typing import Any, Awaitable, Callable, TypeVar
from uuid import uuid4

import uvicorn
from fastapi import FastAPI, WebSocket
from mcp.server.fastmcp import FastMCP
from mcp.server.websocket import websocket_server
from pydantic import BaseModel

from .config import Settings, get_settings
from .exceptions import ConfigurationError
from .tools import (
    ApplyDesensitizedInput,
    ApplySourceInput,
    DownloadInput,
    HashFileInput,
    SearchInput,
    ToolContext,
    Toolset,
)

logger = logging.getLogger(__name__)

try:
    PACKAGE_VERSION = metadata.version("ipr-mcp-server")
except metadata.PackageNotFoundError:  # pragma: no cover - runtime only
    PACKAGE_VERSION = "0.0.0"

InputModelT = TypeVar("InputModelT", bound=BaseModel)
OutputModelT = TypeVar("OutputModelT", bound=BaseModel)


@dataclass
class ServerRunConfig:
    mode: str = "stdio"
    ws_host: str = "127.0.0.1"
    ws_port: int = 8765
    ws_path: str = "/mcp"


def _configure_logging() -> None:
    """Initialize a default logging configuration if none exists."""

    root_logger = logging.getLogger()
    if root_logger.handlers:
        return
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )


async def _run_tool(
    tool_name: str,
    func: Callable[[InputModelT], Awaitable[OutputModelT]],
    payload: InputModelT,
) -> dict[str, Any]:
    logger.info("Tool %s invoked", tool_name)
    try:
        result = await func(payload)
    except Exception:
        logger.exception("Tool %s failed", tool_name)
        raise
    logger.info("Tool %s completed", tool_name)
    return result.model_dump()


def _create_mcp_app(settings: Settings, toolset: Toolset) -> FastMCP:
    """Register tools on a FastMCP server instance."""

    server = FastMCP(
        settings.mcp_server_name,
        instructions=settings.mcp_server_description,
    )

    @server.tool(name="ping", description="Health check tool")
    async def ping() -> str:
        """Simple heartbeat tool to validate connectivity."""

        return "pong"

    @server.tool(
        name="ipr_apply_desensitized",
        description="Submit SHA-256 hash for desensitized solidification",
    )
    async def ipr_apply_desensitized(payload: ApplyDesensitizedInput) -> dict[str, Any]:
        return await _run_tool("ipr_apply_desensitized", toolset.apply_desensitized, payload)

    @server.tool(
        name="ipr_apply_with_source",
        description="Submit source file solidification request and upload file",
    )
    async def ipr_apply_with_source(payload: ApplySourceInput) -> dict[str, Any]:
        return await _run_tool("ipr_apply_with_source", toolset.apply_with_source, payload)

    @server.tool(
        name="ipr_download_assets",
        description="Download PDF/TSA/source URLs for a given oid",
    )
    async def ipr_download_assets(payload: DownloadInput) -> dict[str, Any]:
        return await _run_tool("ipr_download_assets", toolset.download_assets, payload)

    @server.tool(
        name="ipr_search_records",
        description="Search existing solidification records",
    )
    async def ipr_search_records(payload: SearchInput) -> dict[str, Any]:
        return await _run_tool("ipr_search_records", toolset.search_records, payload)

    @server.tool(name="ipr_calc_file_hash", description="Calculate SHA-256 hash for a local file")
    async def ipr_calc_file_hash(payload: HashFileInput) -> dict[str, Any]:
        return await _run_tool("ipr_calc_file_hash", toolset.calc_file_hash, payload)

    @server.tool(
        name="ipr_latest_callback",
        description="Fetch latest callback payload (download URLs) for a given oid",
    )
    async def ipr_latest_callback(payload: DownloadInput) -> dict[str, Any]:
        return await _run_tool("ipr_latest_callback", toolset.fetch_callback_links, payload.oid)

    return server


def _create_toolset(settings: Settings) -> Toolset:
    """Build a toolset with validated configuration."""

    try:
        return Toolset(ToolContext(settings))
    except ConfigurationError as exc:
        logger.error("Failed to start MCP server: %s", exc)
        raise


def _create_websocket_app(server: FastMCP, path: str) -> FastAPI:
    """Create a FastAPI app that exposes the MCP server over WebSocket."""

    app = FastAPI()
    normalized_path = path if path.startswith("/") else f"/{path}"

    @app.websocket(normalized_path)
    async def mcp_ws(websocket: WebSocket) -> None:
        connection_id = uuid4().hex[:8]
        logger.info("WebSocket client connected [%s]", connection_id)
        try:
            async with websocket_server(websocket.scope, websocket.receive, websocket.send) as (
                read_stream,
                write_stream,
            ):
                await server._mcp_server.run(  # type: ignore[attr-defined]  # access to underlying MCP server
                    read_stream,
                    write_stream,
                    server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                )
        except Exception:
            logger.exception("WebSocket connection failed [%s]", connection_id)
        finally:
            logger.info("WebSocket client disconnected [%s]", connection_id)

    return app


def run_stdio(server: FastMCP, settings: Settings) -> None:
    """Run the MCP server over stdio transport."""

    logger.info(
        "Starting %s (v%s) using stdio transport",
        settings.mcp_server_name,
        PACKAGE_VERSION,
    )
    server.run(transport="stdio")


def run_websocket(server: FastMCP, settings: Settings, host: str, port: int, path: str) -> None:
    """Run the MCP server over WebSocket transport using FastAPI + uvicorn."""

    logger.info(
        "Starting %s (v%s) using WebSocket transport at ws://%s:%s%s",
        settings.mcp_server_name,
        PACKAGE_VERSION,
        host,
        port,
        path if path.startswith("/") else f"/{path}",
    )
    app = _create_websocket_app(server, path)
    uvicorn.run(app, host=host, port=port, log_level="info")


def run_server(config: ServerRunConfig | None = None) -> None:
    """Entrypoint used by the CLI and module runner."""

    _configure_logging()
    settings = get_settings()
    resolved_config = config or ServerRunConfig()

    toolset = _create_toolset(settings)
    server = _create_mcp_app(settings, toolset)

    if resolved_config.mode == "stdio":
        run_stdio(server, settings)
    elif resolved_config.mode == "ws":
        run_websocket(server, settings, resolved_config.ws_host, resolved_config.ws_port, resolved_config.ws_path)
    else:  # pragma: no cover - defensive branch
        raise ValueError(f"Unknown server mode {resolved_config.mode!r}")


def parse_cli_args(argv: list[str] | None = None) -> ServerRunConfig:
    """Parse CLI arguments for selecting stdio vs WebSocket transport."""

    parser = argparse.ArgumentParser(description="Run the IPR MCP server")
    parser.add_argument(
        "--stdio",
        action="store_true",
        help="Run using stdio transport (default).",
    )
    parser.add_argument(
        "--ws",
        metavar="HOST:PORT",
        help="Run using WebSocket transport at the given host:port.",
    )
    parser.add_argument(
        "--ws-host",
        dest="ws_host",
        help="WebSocket host (implies --ws). Defaults to 127.0.0.1.",
    )
    parser.add_argument(
        "--ws-port",
        dest="ws_port",
        type=int,
        help="WebSocket port (implies --ws). Defaults to 8765.",
    )
    parser.add_argument(
        "--ws-path",
        dest="ws_path",
        default="/mcp",
        help="WebSocket path (default: /mcp).",
    )

    args = parser.parse_args(argv)

    ws_mode_requested = bool(args.ws or args.ws_host or args.ws_port)
    if args.stdio and ws_mode_requested:
        parser.error("Specify only one transport: either --stdio or --ws/--ws-host/--ws-port.")

    if ws_mode_requested:
        host = "127.0.0.1"
        port = 8765
        if args.ws:
            if ":" not in args.ws:
                parser.error("--ws must be in HOST:PORT format")
            host, port_str = args.ws.split(":", 1)
            try:
                port = int(port_str)
            except ValueError as exc:
                raise SystemExit(f"Invalid port in --ws: {port_str}") from exc
        if args.ws_host:
            host = args.ws_host
        if args.ws_port:
            port = args.ws_port

        return ServerRunConfig(mode="ws", ws_host=host, ws_port=port, ws_path=args.ws_path)

    return ServerRunConfig(mode="stdio", ws_path=args.ws_path)


if __name__ == "__main__":  # pragma: no cover - manual execution helper
    run_server(parse_cli_args())
