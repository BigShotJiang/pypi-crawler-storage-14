"""
FastAPI application that handles TSA notify_url callbacks.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

from .config import get_settings
from .constants import CALLBACK_SUCCESS_TEXT
from .storage import Storage


class CallbackPayload(BaseModel):
    code: str
    message: str | None = None
    serialNo: str
    oid: str | None = None
    opusName: str | None = None
    fileHash: str | None = None
    pdfStorePath: str | None = None
    tsaStorePath: str | None = None
    sourceFileStorePathUrl: str | None = None


def create_app() -> FastAPI:
    settings = get_settings()
    storage = Storage(settings)
    app = FastAPI(title="IPR MCP Callback API", version="0.1.0")

    @app.post("/callbacks/tsa")
    async def handle_callback(payload: CallbackPayload):
        try:
            storage.create_callback_log(payload.model_dump())
        except Exception as exc:  # pragma: no cover - safety logging
            raise HTTPException(status_code=500, detail=str(exc))
        return CALLBACK_SUCCESS_TEXT

    return app


def run() -> None:
    """Entrypoint used by console_script."""

    app = create_app()
    uvicorn.run(app, host="0.0.0.0", port=8080)
