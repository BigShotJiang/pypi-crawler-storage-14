"""
SQLite persistence for evidence records and callbacks.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime
from typing import Dict, Optional

from sqlalchemy import JSON, DateTime, Integer, String, Text, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from .config import Settings


class Base(DeclarativeBase):
    pass


class Evidence(Base):
    __tablename__ = "evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    oid: Mapped[str] = mapped_column(String(64), index=True, unique=True)
    opus_name: Mapped[str] = mapped_column(String(255))
    apply_name: Mapped[str] = mapped_column(String(255))
    file_hash: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    mode: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(32))
    pdf_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tsa_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    source_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    operated_at: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    external_user_info: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    raw_resp: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class CallbackLog(Base):
    __tablename__ = "callback_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    serial_no: Mapped[str] = mapped_column(String(128), index=True)
    oid: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    code: Mapped[str] = mapped_column(String(16))
    message: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    pdf_store_path: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tsa_store_path: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    source_file_store_path_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    raw_payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    acked: Mapped[bool] = mapped_column(default=False)


class Storage:
    """Database helper built around SQLAlchemy sessions."""

    def __init__(self, settings: Settings):
        self.engine = create_engine(settings.database_url, future=True)
        self.SessionLocal = sessionmaker(bind=self.engine, autoflush=False, autocommit=False, future=True)
        Base.metadata.create_all(self.engine)

    @contextmanager
    def session(self):
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def upsert_evidence(
        self,
        oid: str,
        payload: Dict,
        *,
        mode: str,
        status: str,
    ) -> None:
        with self.session() as sess:
            record: Optional[Evidence] = sess.query(Evidence).filter(Evidence.oid == oid).one_or_none()
            if record is None:
                record = Evidence(
                    oid=oid,
                    opus_name=payload.get("opusName", ""),
                    apply_name=payload.get("applyName", ""),
                    file_hash=payload.get("fileHash"),
                    mode=mode,
                    status=status,
                )
                sess.add(record)
            record.pdf_url = payload.get("pdfUrl") or record.pdf_url
            record.tsa_url = payload.get("tsaUrl") or record.tsa_url
            record.source_url = payload.get("uploadSourceFileUrl") or record.source_url
            record.operated_at = payload.get("operatedAt") or record.operated_at
            record.external_user_info = payload.get("externalUserInfo") or record.external_user_info
            record.raw_resp = payload
            record.status = status

    def create_callback_log(self, payload: Dict) -> None:
        with self.session() as sess:
            log = CallbackLog(
                serial_no=payload.get("serialNo", ""),
                oid=payload.get("oid"),
                code=str(payload.get("code", "")),
                message=payload.get("message"),
                pdf_store_path=payload.get("pdfStorePath"),
                tsa_store_path=payload.get("tsaStorePath"),
                source_file_store_path_url=payload.get("sourceFileStorePathUrl"),
                raw_payload=payload,
                acked=True,
            )
            sess.add(log)

    def latest_callback_for_oid(self, oid: str) -> Optional[Dict]:
        """Return the latest callback payload for a given oid."""

        with self.session() as sess:
            log: Optional[CallbackLog] = (
                sess.query(CallbackLog).filter(CallbackLog.oid == oid).order_by(CallbackLog.id.desc()).first()
            )
            return log.raw_payload if log else None
