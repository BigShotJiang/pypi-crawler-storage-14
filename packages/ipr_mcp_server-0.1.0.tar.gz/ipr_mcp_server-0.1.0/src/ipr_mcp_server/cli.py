"""
Console entry point for the MCP server.
"""

from .server import parse_cli_args, run_server


def main() -> int:
    """CLI entrypoint for stdio or WebSocket transports."""

    config = parse_cli_args()
    run_server(config)
    return 0
