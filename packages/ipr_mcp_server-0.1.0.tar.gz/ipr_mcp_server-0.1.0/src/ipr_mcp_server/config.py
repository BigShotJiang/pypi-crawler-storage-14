"""
Configuration management for the IPR MCP server.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from .exceptions import ConfigurationError


class Settings(BaseSettings):
    """Centralized application settings sourced from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
        populate_by_name=True,
    )

    tsa_base_url: str = Field(default="https://open-test.tsa.cn/", alias="TSA_BASE_URL")
    tsa_app_id: str = Field(default="", alias="TSA_APP_ID")
    tsa_private_key_pem: Optional[str] = Field(default=None, alias="TSA_PRIVATE_KEY_PEM")
    tsa_private_key_path: Optional[str] = Field(default=None, alias="TSA_PRIVATE_KEY_PATH")
    tsa_charset: str = Field(default="utf-8", alias="TSA_CHARSET")
    tsa_sign_type: str = Field(default="RSA2", alias="TSA_SIGN_TYPE")
    tsa_gateway_path: str = Field(default="/", alias="TSA_GATEWAY_PATH")
    callback_public_url: str = Field(default="", alias="CALLBACK_PUBLIC_URL")
    http_proxy: Optional[str] = Field(default=None, alias="HTTP_PROXY")
    https_proxy: Optional[str] = Field(default=None, alias="HTTPS_PROXY")
    request_timeout_seconds: float = Field(default=15.0, alias="TSA_REQUEST_TIMEOUT")
    database_url: str = Field(default="sqlite:///./ipr_mcp.db", alias="DATABASE_URL")
    storage_dir: str = Field(default="./data", alias="STORAGE_DIR")
    mcp_server_name: str = Field(default="ipr-mcp-server", alias="MCP_SERVER_NAME")
    mcp_server_description: str = Field(
        default="Unitrust copyright solidification MCP server",
        alias="MCP_SERVER_DESCRIPTION",
    )

    @field_validator("tsa_private_key_pem", mode="before")
    @classmethod
    def _expand_inline_newlines(cls, value: Optional[str]) -> Optional[str]:
        if isinstance(value, str):
            return value.replace("\\n", "\n")
        return value

    def require_private_key(self) -> str:
        """
        Ensure a TSA private key is available, preferring inline PEM content and
        falling back to reading from TSA_PRIVATE_KEY_PATH. Raises ConfigurationError
        if neither is configured.
        """

        if self.tsa_private_key_pem and self.tsa_private_key_pem.strip():
            return self.tsa_private_key_pem
        if self.tsa_private_key_path:
            pem_path = Path(self.tsa_private_key_path).expanduser()
            if not pem_path.exists():
                raise ConfigurationError(
                    f"TSA private key file not found at {pem_path}. "
                    "Set TSA_PRIVATE_KEY_PEM or provide a valid TSA_PRIVATE_KEY_PATH."
                )
            content = pem_path.read_text(encoding="utf-8")
            self.tsa_private_key_pem = content
            return self.tsa_private_key_pem
        raise ConfigurationError(
            "Missing TSA private key. Configure TSA_PRIVATE_KEY_PEM or TSA_PRIVATE_KEY_PATH."
        )


@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance."""

    return Settings()  # type: ignore[arg-type]
