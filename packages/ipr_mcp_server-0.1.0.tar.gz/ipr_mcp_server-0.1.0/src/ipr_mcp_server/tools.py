"""
Tool implementations that surface TSA capabilities to MCP clients.
"""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from .config import Settings
from .constants import (
    APPLY_ID_TYPE_MAP,
    APPLY_TYPE_MAP,
    APPLY_USER_TYPE_MAP,
    FILE_TYPE_MAP,
    OPUS_APPLY_TYPE_MAP,
    OPUS_CREATIVE_NATURE_MAP,
    OPUS_CREATIVE_TYPE_MAP,
    OPUS_STATE_MAP,
    OPUS_STORE_MAP,
    OPUS_TYPE_MAP,
    TEMPLATE_TYPE_MAP,
)
from .crypto_utils import calc_md5_base64, calc_sha256_hex
from .exceptions import ConfigurationError
from .storage import Storage
from .tsa_client import TsaClient


def _validate_enum(value: Optional[int], valid_map: Dict[int, str], field_name: str) -> Optional[int]:
    if value is None:
        return None
    if value not in valid_map:
        raise ValueError(f"{field_name} must be one of {sorted(valid_map.keys())}")
    return value


class BaseApplyFields(BaseModel):
    opusDescribe: str
    fileType: int
    applyName: str
    opusName: str
    applyIdType: Optional[int] = None
    applyIdNumber: Optional[str] = None
    opusState: Optional[int] = None
    opusPartnerId: Optional[str] = None
    opusLabel: Optional[str] = None
    opusStore: Optional[int] = None
    opusType: Optional[int] = None
    opusCreativeType: Optional[int] = None
    opusCreativeNature: Optional[int] = None
    applyType: Optional[int] = None
    applyNationality: Optional[str] = None
    applyPhone: Optional[str] = None
    applyMail: Optional[str] = None
    applyAddress: Optional[str] = None
    applyEmergencyName: Optional[str] = None
    applyEmergencyPhone: Optional[str] = None
    remark: Optional[str] = None
    applyUserType: Optional[int] = None
    opusApplyType: Optional[int] = None
    templateType: Optional[int] = None
    externalUserInfo: Optional[str] = None

    @field_validator("fileType")
    @classmethod
    def validate_file_type(cls, value: int) -> int:
        return _validate_enum(value, FILE_TYPE_MAP, "fileType")  # type: ignore[return-value]

    @field_validator("opusState")
    @classmethod
    def validate_state(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, OPUS_STATE_MAP, "opusState")

    @field_validator("opusStore")
    @classmethod
    def validate_opus_store(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, OPUS_STORE_MAP, "opusStore")

    @field_validator("opusType")
    @classmethod
    def validate_opus_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, OPUS_TYPE_MAP, "opusType")

    @field_validator("opusCreativeType")
    @classmethod
    def validate_opus_creative_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, OPUS_CREATIVE_TYPE_MAP, "opusCreativeType")

    @field_validator("opusCreativeNature")
    @classmethod
    def validate_opus_creative_nature(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, OPUS_CREATIVE_NATURE_MAP, "opusCreativeNature")

    @field_validator("applyType")
    @classmethod
    def validate_apply_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, APPLY_TYPE_MAP, "applyType")

    @field_validator("applyIdType")
    @classmethod
    def validate_apply_id_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, APPLY_ID_TYPE_MAP, "applyIdType")

    @field_validator("applyUserType")
    @classmethod
    def validate_apply_user_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, APPLY_USER_TYPE_MAP, "applyUserType")

    @field_validator("opusApplyType")
    @classmethod
    def validate_opus_apply_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, OPUS_APPLY_TYPE_MAP, "opusApplyType")

    @field_validator("templateType")
    @classmethod
    def validate_template_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, TEMPLATE_TYPE_MAP, "templateType")


class ApplyDesensitizedInput(BaseApplyFields):
    fileHash: str = Field(..., description="64-char hex SHA-256")

    @field_validator("fileHash")
    @classmethod
    def validate_hash(cls, value: str) -> str:
        if len(value) != 64:
            raise ValueError("fileHash must be 64 hex characters")
        return value


class ApplySourceInput(BaseApplyFields):
    filePath: Optional[str] = Field(default=None, description="Path to file to upload")
    fileBase64: Optional[str] = Field(default=None, description="Alternative base64 payload")

    @model_validator(mode="after")
    def check_source(self) -> "ApplySourceInput":
        if not self.filePath and not self.fileBase64:
            raise ValueError("filePath or fileBase64 must be provided")
        return self


class ApplyResult(BaseModel):
    oid: str
    pdfUrl: Optional[str] = None
    tsaUrl: Optional[str] = None
    pdfSerialNo: Optional[str] = None
    operatedAt: Optional[str] = None
    uploadSourceFileUrl: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_operated_at(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        value = data.get("operatedAt")
        if value is not None and not isinstance(value, str):
            data["operatedAt"] = str(value)
        return data


class UploadResult(BaseModel):
    oid: str
    uploadSourceFileUrl: str
    md5Hash: str
    bytesUploaded: int


class DownloadInput(BaseModel):
    oid: str


class DownloadResult(BaseModel):
    oid: str
    pdfUrl: Optional[str]
    tsaUrl: Optional[str]
    sourceFileUrl: Optional[str] = None


class SearchInput(BaseModel):
    page: int = 1
    size: int = 10
    fileHash: Optional[str] = None
    opusApplyType: Optional[int] = None
    startAt: Optional[int] = None
    endAt: Optional[int] = None
    externalUserInfo: Optional[str] = None

    @field_validator("size")
    @classmethod
    def validate_size(cls, value: int) -> int:
        if value < 1 or value > 200:
            raise ValueError("size must be between 1 and 200")
        return value

    @field_validator("opusApplyType")
    @classmethod
    def validate_search_apply_type(cls, value: Optional[int]) -> Optional[int]:
        return _validate_enum(value, OPUS_APPLY_TYPE_MAP, "opusApplyType")


class SearchResult(BaseModel):
    total: int
    page: int
    size: int
    records: List[Dict[str, Any]]


class HashFileInput(BaseModel):
    filePath: str


class HashFileResult(BaseModel):
    filePath: str
    sha256Hex: str
    bytes: int


class ToolContext:
    """Aggregates shared dependencies for tools."""

    def __init__(self, settings: Settings):
        missing_fields: List[str] = []
        private_key_error: ConfigurationError | None = None

        if not settings.tsa_app_id:
            missing_fields.append("TSA_APP_ID")
        try:
            settings.require_private_key()
        except ConfigurationError as exc:
            missing_fields.append("TSA_PRIVATE_KEY_PEM or TSA_PRIVATE_KEY_PATH")
            private_key_error = exc

        if missing_fields:
            message = f"Missing required configuration: {', '.join(missing_fields)}"
            if private_key_error:
                message = f"{message}. {private_key_error}"
                raise ConfigurationError(message) from private_key_error
            raise ConfigurationError(message)

        self.settings = settings
        self.storage = Storage(settings)
        self.client = TsaClient(settings)


class Toolset:
    def __init__(self, context: ToolContext):
        self.context = context

    async def apply_desensitized(self, payload: ApplyDesensitizedInput) -> ApplyResult:
        biz_content = payload.model_dump(by_alias=True, exclude_none=True)
        response = await self.context.client.apply_desensitized(biz_content)
        self.context.storage.upsert_evidence(
            response["oid"],
            {**biz_content, **response},
            mode="desensitized",
            status="done",
        )
        return ApplyResult(**response)

    async def apply_with_source(self, payload: ApplySourceInput) -> UploadResult:
        callback_url = self.context.settings.callback_public_url
        if not callback_url:
            raise ConfigurationError("CALLBACK_PUBLIC_URL must be configured to upload source files")
        binary = self._load_file_bytes(payload)
        md5_base64 = calc_md5_base64(binary)
        biz_content = {
            **payload.model_dump(by_alias=True, exclude_none=True, exclude={"filePath", "fileBase64"}),
            "md5Hash": md5_base64,
        }
        response = await self.context.client.apply_with_source(
            biz_content, notify_url=callback_url
        )
        upload_url = response["uploadSourceFileUrl"]
        await self.context.client.upload_source_file(upload_url, binary, md5_base64)
        oid = response["oid"]
        self.context.storage.upsert_evidence(
            oid,
            {**response, **biz_content},
            mode="source",
            status="uploaded",
        )
        return UploadResult(oid=oid, uploadSourceFileUrl=upload_url, md5Hash=md5_base64, bytesUploaded=len(binary))

    async def download_assets(self, payload: DownloadInput) -> DownloadResult:
        response = await self.context.client.download_assets(payload.model_dump(by_alias=True))
        return DownloadResult(
            oid=payload.oid,
            pdfUrl=response.get("pdfUrl"),
            tsaUrl=response.get("tsaUrl"),
            sourceFileUrl=response.get("sourceFileUrl"),
        )

    async def search_records(self, payload: SearchInput) -> SearchResult:
        response = await self.context.client.search_records(payload.model_dump(exclude_none=True))
        return SearchResult(
            total=response.get("total", 0),
            page=response.get("page", payload.page),
            size=response.get("size", payload.size),
            records=response.get("data", []),
        )

    def _load_file_bytes(self, payload: ApplySourceInput) -> bytes:
        if payload.fileBase64:
            return base64.b64decode(payload.fileBase64)
        if not payload.filePath:
            raise ValueError("filePath is required when fileBase64 is not provided")
        return Path(payload.filePath).read_bytes()

    async def calc_file_hash(self, payload: HashFileInput) -> HashFileResult:
        file_path = Path(payload.filePath)
        data = file_path.read_bytes()
        return HashFileResult(
            filePath=str(file_path),
            sha256Hex=calc_sha256_hex(data),
            bytes=len(data),
        )

    async def fetch_callback_links(self, oid: str) -> dict[str, Any]:
        """Return latest callback payload (download links) for a given oid."""

        payload = self.context.storage.latest_callback_for_oid(oid)
        if not payload:
            return {"oid": oid, "message": "No callback received yet"}
        return payload
