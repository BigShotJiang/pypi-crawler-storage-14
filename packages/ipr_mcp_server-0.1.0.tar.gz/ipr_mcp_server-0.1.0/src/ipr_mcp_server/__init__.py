"""
IPR MCP Server package.

This package exposes an MCP-compatible tool server that fronts
the Unitrust ipr.tsa.cn copyright solidification APIs.
"""

from .config import Settings, get_settings
from .server import run_server

__all__ = ["Settings", "get_settings", "run_server"]
