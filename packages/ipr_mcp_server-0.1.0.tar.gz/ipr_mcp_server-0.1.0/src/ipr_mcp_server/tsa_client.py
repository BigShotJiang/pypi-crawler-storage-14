"""
HTTP client that wraps Unitrust TSA endpoints with signing logic.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import httpx
from dateutil import tz

from .config import Settings
from .crypto_utils import build_sign_content, rsa2_sign
from .exceptions import TsaAPIError

TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"
SUCCESS_CODES = {"200", "10000"}


class TsaClient:
    """Thin wrapper around the TSA OpenAPI gateway."""

    def __init__(self, settings: Settings):
        self.settings = settings

    def _now_string(self) -> str:
        now = datetime.now(tz=timezone.utc).astimezone(tz.tzlocal())
        return now.strftime(TIMESTAMP_FORMAT)

    def _build_signed_params(
        self,
        method: str,
        biz_content: Optional[Dict[str, Any]],
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "app_id": self.settings.tsa_app_id,
            "method": method,
            "format": "json",
            "charset": self.settings.tsa_charset,
            "sign_type": self.settings.tsa_sign_type,
            "timestamp": self._now_string(),
            "version": "1.0",
        }
        if biz_content is not None:
            payload["biz_content"] = json.dumps(biz_content, ensure_ascii=False, separators=(",", ":"))
        if extra_params:
            payload.update({k: v for k, v in extra_params.items() if v})
        sign_content = build_sign_content(payload)
        payload["sign"] = rsa2_sign(sign_content, self.settings.tsa_private_key_pem)
        return payload

    def _gateway_url(self) -> str:
        base = self.settings.tsa_base_url.rstrip("/")
        path = (self.settings.tsa_gateway_path or "").strip()
        if not path:
            return base
        if not path.startswith("/"):
            path = "/" + path
        return base + path

    async def _request(
        self,
        method: str,
        biz_content: Optional[Dict[str, Any]] = None,
        http_method: str = "POST",
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        url = self._gateway_url()
        print("gateway url:", url)
        params = self._build_signed_params(method, biz_content, extra_params=extra_params)
        proxy = self.settings.https_proxy or self.settings.http_proxy
        async with httpx.AsyncClient(
            timeout=self.settings.request_timeout_seconds,
            proxy=proxy,
        ) as client:
            if http_method.upper() == "GET":
                resp = await client.get(url, params=params)
            else:
                resp = await client.post(url, data=params)
        resp.raise_for_status()
        data = resp.json()
        return self._unwrap_gateway_response(method, data)

    def _unwrap_gateway_response(self, method: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        key = method.replace(".", "_") + "_response"
        response_body = payload.get(key)
        if not response_body and isinstance(payload.get("tsa_response"), dict):
            response_body = payload["tsa_response"]
        if not response_body and isinstance(payload.get("result"), dict):
            response_body = payload["result"]
        if not response_body:
            response_body = payload
        code = str(response_body.get("code") or payload.get("code") or "500")
        if code not in SUCCESS_CODES:
            raise TsaAPIError(
                method=method,
                code=code,
                message=response_body.get("message", "unknown error"),
                sub_code=response_body.get("sub_code"),
                sub_msg=response_body.get("sub_msg"),
                raw=response_body,
            )
        return response_body

    async def apply_desensitized(self, biz_content: Dict[str, Any]) -> Dict[str, Any]:
        return await self._request("ipr.opus.apply", biz_content=biz_content, http_method="POST")

    async def apply_with_source(self, biz_content: Dict[str, Any], notify_url: Optional[str] = None) -> Dict[str, Any]:
        return await self._request(
            "ipr.opus.apply.source",
            biz_content=biz_content,
            http_method="POST",
            extra_params={"notify_url": notify_url} if notify_url else None,
        )

    async def download_assets(self, biz_content: Dict[str, Any]) -> Dict[str, Any]:
        return await self._request("ipr.opus.download", biz_content=biz_content, http_method="GET")

    async def search_records(self, biz_content: Dict[str, Any]) -> Dict[str, Any]:
        return await self._request("ipr.opus.search", biz_content=biz_content, http_method="GET")

    async def upload_source_file(self, upload_url: str, content: bytes, md5_base64: str) -> None:
        headers = {
            "Content-MD5": md5_base64,
            "x-oss-forbid-overwrite": "true",
        }
        proxy = self.settings.https_proxy or self.settings.http_proxy
        async with httpx.AsyncClient(
            timeout=self.settings.request_timeout_seconds,
            proxy=proxy,
        ) as client:
            resp = await client.put(upload_url, content=content, headers=headers)
        resp.raise_for_status()
