import pytest
from httpx import ASGITransport, AsyncClient
from ipr_mcp_server import config
from ipr_mcp_server.callback_api import create_app


@pytest.mark.asyncio
async def test_callback_persists_payload(tmp_path, monkeypatch):
    db_path = tmp_path / "callback.db"
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{db_path}")
    config.get_settings.cache_clear()
    app = create_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as client:
        payload = {
            "code": "200",
            "message": "success",
            "serialNo": "SERIAL123",
            "oid": "OID1",
            "pdfStorePath": "oss://pdf",
            "tsaStorePath": "oss://tsa",
        }
        response = await client.post("/callbacks/tsa", json=payload)
        assert response.text == '"success"'
