import json
from pathlib import Path

from ipr_mcp_server.crypto_utils import build_sign_content, calc_md5_base64, calc_sha256_hex, rsa2_sign


def test_build_sign_content_and_signature():
    params = {
        "app_id": "123456",
        "method": "ipr.opus.apply",
        "format": "json",
        "charset": "utf-8",
        "timestamp": "2024-05-01 00:00:00",
        "version": "1.0",
        "biz_content": json.dumps({"opusName": "Test"}, ensure_ascii=False, separators=(",", ":")),
        "sign_type": "RSA2",
    }
    content = build_sign_content(params)
    key = Path("tests/fixtures/test_private_key_pkcs8.pem").read_text()
    signature = rsa2_sign(content, key)
    assert (
        signature
        == "V8fLRLXpEZ6Gn/tzsBNpBswOPRweKuFzk7dMACsVck6gCUagtvoLYbFuhL34dpjxQtwaNkEdsW3uRPZlSufpEONjdHDMuBlH6i49hCUVdzXJhs+1ONs0cNZEA8ucAiXmf2OdY+o56DP5zQ2hdl1z2BjGTTD6j42r6Pin4aZFGFe5dn7sQSNi47JGac4YsHvgIobCNo5C8A4IpR/psUjGTEvozVtcDCfssGcfPTvJdhCyYkAPh6Qv9Nx3htnY6OKgpWCGrHlAGRSNbtSP+e+js9tdDGUsV7fLcRmrqYy1n/2r6YDos/NIbaD79C4giSnNqQYsWYmh3ZATEQ6fPwt+NQ=="
    )


def test_md5_and_sha256_helpers(tmp_path):
    data = b"hello world"
    sha_hex = calc_sha256_hex(data)
    md5_b64 = calc_md5_base64(data)
    assert sha_hex == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
    assert md5_b64 == "XrY7u+Ae7tCTyyK7j1rNww=="
