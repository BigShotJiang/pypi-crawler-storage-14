import pathlib

import pytest

from ipr_mcp_server.config import Settings
from ipr_mcp_server.exceptions import ConfigurationError
from ipr_mcp_server.tools import ApplyResult, HashFileInput, ToolContext, Toolset


def make_settings(tmp_path):
    db_path = tmp_path / "test.db"
    return Settings(
        tsa_base_url="https://mocked/",
        tsa_gateway_path="/gateway.do",
        tsa_app_id="app",
        tsa_private_key_pem=pathlib.Path("tests/fixtures/test_private_key_pkcs8.pem").read_text(),
        callback_public_url="https://callback.local/tsa",
        database_url=f"sqlite:///{db_path}",
    )


@pytest.mark.asyncio
async def test_calc_file_hash(tmp_path):
    sample = tmp_path / "hello.txt"
    sample.write_text("hello world")
    toolset = Toolset(ToolContext(make_settings(tmp_path)))
    result = await toolset.calc_file_hash(HashFileInput(filePath=str(sample)))
    assert result.sha256Hex == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
    assert result.bytes == 11


def test_tool_context_requires_credentials():
    settings = Settings(
        tsa_app_id="",
        tsa_private_key_pem="",
        callback_public_url="",
    )
    with pytest.raises(ConfigurationError):
        ToolContext(settings)


def test_apply_result_accepts_int_operated_at():
    result = ApplyResult(oid="oid123", operatedAt=1762940001000)
    assert result.operatedAt == "1762940001000"
