import json
from pathlib import Path

import httpx
import pytest
import respx

from ipr_mcp_server.config import Settings
from ipr_mcp_server.exceptions import TsaAPIError
from ipr_mcp_server.tsa_client import TsaClient


@pytest.mark.asyncio
@respx.mock
async def test_apply_desensitized_request_structure():
    settings = Settings(
        tsa_base_url="https://mocked.tsa.cn/",
        tsa_gateway_path="/gateway.do",
        tsa_app_id="app123",
        tsa_private_key_pem=Path("tests/fixtures/test_private_key_pkcs8.pem").read_text(),
        callback_public_url="https://callback.local/tsa",
    )
    client = TsaClient(settings)
    route = respx.post("https://mocked.tsa.cn/gateway.do").mock(
        return_value=httpx.Response(
            200,
            json={
                "ipr_opus_apply_response": {
                    "code": "200",
                    "oid": "OID123",
                    "pdfUrl": "https://pdf",
                    "tsaUrl": "https://tsa",
                }
            },
        )
    )
    payload = {
        "fileHash": "a" * 64,
        "opusName": "Sample",
        "applyName": "Tester",
        "opusDescribe": "desc",
        "fileType": 101,
    }
    data = await client.apply_desensitized(payload)
    assert data["oid"] == "OID123"
    assert route.called
    request = route.calls.last.request
    from urllib.parse import parse_qs

    form = parse_qs(request.content.decode())
    assert form["method"][0] == "ipr.opus.apply"
    assert "sign" in form
    biz = json.loads(form["biz_content"][0])
    assert biz["opusName"] == "Sample"


@pytest.mark.asyncio
@respx.mock
async def test_apply_with_source_carries_notify_url():
    settings = Settings(
        tsa_base_url="https://mocked.tsa.cn/",
        tsa_gateway_path="/gateway.do",
        tsa_app_id="app123",
        tsa_private_key_pem=Path("tests/fixtures/test_private_key_pkcs8.pem").read_text(),
        callback_public_url="https://callback.local/tsa",
    )
    client = TsaClient(settings)
    route = respx.post("https://mocked.tsa.cn/gateway.do").mock(
        return_value=httpx.Response(
            200,
            json={
                "ipr_opus_apply_source_response": {
                    "code": "200",
                    "oid": "OID999",
                    "uploadSourceFileUrl": "https://upload",
                }
            },
        )
    )
    await client.apply_with_source(
        biz_content={"opusDescribe": "desc", "fileType": 101, "applyName": "test", "opusName": "name"},
        notify_url="https://callback.local/tsa",
    )
    assert route.called
    request = route.calls.last.request
    from urllib.parse import parse_qs

    form = parse_qs(request.content.decode())
    assert form["notify_url"][0] == "https://callback.local/tsa"


def test_gateway_url_override():
    settings = Settings(
        tsa_base_url="https://mocked.tsa.cn/",
        tsa_gateway_path="",
        tsa_app_id="app123",
        tsa_private_key_pem=Path("tests/fixtures/test_private_key_pkcs8.pem").read_text(),
        callback_public_url="https://callback.local/tsa",
    )
    client = TsaClient(settings)
    assert client._gateway_url() == "https://mocked.tsa.cn"
    settings2 = Settings(
        tsa_base_url="https://mocked.tsa.cn/",
        tsa_gateway_path="custom.do",
        tsa_app_id="app123",
        tsa_private_key_pem=Path("tests/fixtures/test_private_key_pkcs8.pem").read_text(),
        callback_public_url="https://callback.local/tsa",
    )
    assert TsaClient(settings2)._gateway_url() == "https://mocked.tsa.cn/custom.do"


@pytest.mark.asyncio
@respx.mock
async def test_tsa_response_wrapper_with_code_10000():
    settings = Settings(
        tsa_base_url="https://mocked.tsa.cn/",
        tsa_gateway_path="/gateway.do",
        tsa_app_id="app123",
        tsa_private_key_pem=Path("tests/fixtures/test_private_key_pkcs8.pem").read_text(),
        callback_public_url="https://callback.local/tsa",
    )
    client = TsaClient(settings)
    respx.post("https://mocked.tsa.cn/gateway.do").mock(
        return_value=httpx.Response(
            200,
            json={
                "tsa_response": {
                    "code": "10000",
                    "msg": "success",
                    "oid": "OID-10000",
                    "request_id": "req-1",
                }
            },
        )
    )
    data = await client.apply_desensitized(
        {
            "fileHash": "a" * 64,
            "opusName": "Demo",
            "applyName": "Tester",
            "opusDescribe": "desc",
            "fileType": 101,
        }
    )
    assert data["oid"] == "OID-10000"


@pytest.mark.asyncio
@respx.mock
async def test_tsa_response_wrapper_with_failure_code():
    settings = Settings(
        tsa_base_url="https://mocked.tsa.cn/",
        tsa_gateway_path="/gateway.do",
        tsa_app_id="app123",
        tsa_private_key_pem=Path("tests/fixtures/test_private_key_pkcs8.pem").read_text(),
        callback_public_url="https://callback.local/tsa",
    )
    client = TsaClient(settings)
    respx.post("https://mocked.tsa.cn/gateway.do").mock(
        return_value=httpx.Response(
            200,
            json={
                "tsa_response": {
                    "code": "40004",
                    "message": "error",
                    "sub_code": "invalid",
                }
            },
        )
    )
    with pytest.raises(TsaAPIError):
        await client.apply_desensitized(
            {
                "fileHash": "a" * 64,
                "opusName": "Demo",
                "applyName": "Tester",
                "opusDescribe": "desc",
                "fileType": 101,
            }
        )
