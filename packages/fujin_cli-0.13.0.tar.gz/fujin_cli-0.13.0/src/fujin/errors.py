import cappa


class ImproperlyConfiguredError(cappa.Exit):
    code = 1
