server
======

.. cappa:: fujin.commands.up.Server
   :style: terminal
   :terminal-width: 0
