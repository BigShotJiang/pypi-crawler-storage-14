docs
====

.. cappa:: fujin.commands.docs.Docs
   :style: terminal
   :terminal-width: 0
