from ._base import Shape
from .mesh import TriangleMesh
from .point_cloud import PointCloud
