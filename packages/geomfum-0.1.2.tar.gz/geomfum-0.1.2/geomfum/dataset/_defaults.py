import os

GEOMFUM_DIR = os.path.expanduser(os.path.join("~", ".geomfum"))
DATA_DIR = os.path.join(GEOMFUM_DIR, "data")
