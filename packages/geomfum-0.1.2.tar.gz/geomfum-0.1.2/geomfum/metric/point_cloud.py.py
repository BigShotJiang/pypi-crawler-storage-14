"""Module containing metrics to calculate distances on a PointCloud."""
