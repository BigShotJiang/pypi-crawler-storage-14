import geomfum.wrap as _wrap  # for register

from ._base import Descriptor, SpectralDescriptor, DistanceFromLandmarksDescriptor
