import os
import sys
import shutil
import subprocess
import re
import glob

class CLASS_7zArchive:
    def __init__(self):
        self.on_progress = None
        self.seven_zip_path = self._find_7z_exe()

    # -------------------------------------------------------------
    # 自動搜尋 7z.exe
    # -------------------------------------------------------------
    def _find_7z_exe(self):
        candidate_paths = [
            r"C:\Program Files\7-Zip\7z.exe",
            r"C:\Program Files (x86)\7-Zip\7z.exe"
        ]
        # 1. 先找常用路徑
        for p in candidate_paths:
            if os.path.exists(p):
                return p
        # 2. 從 PATH 搜尋
        p = shutil.which("7z")
        if p:
            return p

        # 3. 找不到 → 拋錯
        raise FileNotFoundError("找不到 7z.exe，請確認是否已安裝 7-Zip")


    # -------------------------------------------------------------
    # 設定進度事件
    # -------------------------------------------------------------
    def CUF_SET_ProgressEvent(self, func_progress):
        self.on_progress = func_progress


    def _find_7z_exe(self):
        """
        依照優先順序尋找 7za.exe → 7z.exe
        並支援掃描所有磁碟（C, D, E, F...）
        """
        # ---------------------------
        # 1. PATH 中找 7za / 7z
        # ---------------------------
        p = shutil.which("7za")
        if p:
            return p
        p = shutil.which("7z")
        if p:
            return p
        # ---------------------------
        # 2. 常見安裝路徑
        # ---------------------------
        common_paths = [
            r"C:\Program Files\7-Zip\7za.exe",
            r"C:\Program Files (x86)\7-Zip\7za.exe",
            r"C:\Program Files\7-Zip\7z.exe",
            r"C:\Program Files (x86)\7-Zip\7z.exe",
        ]
        for p in common_paths:
            if os.path.exists(p):
                return p
        # ---------------------------
        # 3. 掃描所有磁碟（C, D, E, F...)
        #    搜尋特定資料夾名稱避免太慢
        # ---------------------------
        search_dirs = [
            "7-Zip",
            "7Zip",
            "7zip",
            "7zip\\bin",
            "Program Files\\7-Zip",
            "Program Files (x86)\\7-Zip",
        ]
        drives = []
        for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            d = f"{letter}:\\"
            if os.path.exists(d):
                drives.append(d)

        for drive in drives:
            for folder in search_dirs:
                base = os.path.join(drive, folder)

                # 若資料夾不存在跳過
                if not os.path.isdir(base):
                    continue

                # 檢查底下是否有 7za.exe 或 7z.exe
                exe_7za = os.path.join(base, "7za.exe")
                exe_7z = os.path.join(base, "7z.exe")

                if os.path.exists(exe_7za):
                    return exe_7za
                if os.path.exists(exe_7z):
                    return exe_7z

                # 若還沒找到 → 試著遞迴搜尋
                try:
                    for root, dirs, files in os.walk(base):
                        if "7za.exe" in files:
                            return os.path.join(root, "7za.exe")
                        if "7z.exe" in files:
                            return os.path.join(root, "7z.exe")
                except PermissionError:
                    pass  # 跳過無權限的資料夾

        # ---------------------------
        # 全部找不到 → 拋錯
        # ---------------------------
        raise FileNotFoundError("找不到 7za.exe 或 7z.exe，請確認是否已安裝 7-Zip")

    # -------------------------------------------------------------
    # 封裝執行 7z.exe，並解析 stdout 進度 (%)
    # -------------------------------------------------------------
    def _run_7z(self, args_list):
        """
        同時支援：
        ✔ 有 % → 觸發 int 進度
        ✔ 沒 % → 逐行觸發文字行
        """
        cmd = [self.seven_zip_path] + args_list

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            encoding="utf-8",
            errors="ignore"
        )

        progress_pattern = re.compile(r"(\d+)%")

        for line in process.stdout:
            line = line.strip()

            # 嘗試找百分比
            match = progress_pattern.search(line)
            if match:
                pct = int(match.group(1))
                if self.on_progress:
                    try:
                        self.on_progress(pct)
                    except:
                        pass
            else:
                # 沒有百分比 → 仍然要回報文字行（使用者可自訂怎麼處理）
                if self.on_progress and line:
                    try:
                        self.on_progress(line)   # 回傳文字行
                    except:
                        pass
        process.wait()


    # -------------------------------------------------------------
    # 壓縮資料夾
    # -------------------------------------------------------------
    def CUF_CompressFolder(self, Pms_FolderName:str, Pms_File7z:str, 
                           Pms_Password:str=None, 
                           Pmi_SplitSize_K:int=-1):

        if not os.path.exists(Pms_FolderName):
            raise ValueError("Pms_FolderName 必須是資料夾")

        # -------------------------------------------------------
        # 取出 Pms_File7z 的路徑並建立
        # -------------------------------------------------------
        out_dir = os.path.dirname(Pms_File7z)
        if out_dir.strip() == "":
            out_dir = os.getcwd()

        os.makedirs(out_dir, exist_ok=True)

        file_name_only = os.path.basename(Pms_File7z)   # Orange.7z

        # -------------------------------------------------------
        # 組合 7z 參數
        # -------------------------------------------------------
        args = ["a"]

        if Pms_Password:
            args.append(f"-p{Pms_Password}")

        if Pmi_SplitSize_K != -1:
            args.append(f"-v{Pmi_SplitSize_K}k")

        # 7z 輸出檔名（不能帶路徑）
        args.append(file_name_only)

        # 加入來源資料夾
        args.append(Pms_FolderName)

        # -------------------------------------------------------
        # 執行壓縮 (7z 產生在目前工作目錄)
        # -------------------------------------------------------
        self._run_7z(args)

        # -------------------------------------------------------
        # ▒▒▒ 壓縮後 → 將檔案移到 Pms_File7z 指定路徑 ▒▒▒
        # -------------------------------------------------------
        self._move_output_files(file_name_only, out_dir)


    # -------------------------------------------------------------
    # 壓縮檔案（支援萬用字元 *.txt, apple*.*）
    # -------------------------------------------------------------
    def CUF_CompressFile(self, Pms_FileSource:str, Pms_File7z:str, 
                         Pms_Password:str=None, 
                         Pmi_SplitSize_K:int=-1):
        file_list = glob.glob(Pms_FileSource)
        if not file_list:
            raise FileNotFoundError(f"找不到符合的檔案: {Pms_FileSource}")

        # -------------------------------------------------------
        # 取出 Pms_File7z 的路徑並建立
        # -------------------------------------------------------
        out_dir = os.path.dirname(Pms_File7z)
        if out_dir.strip() == "":
            out_dir = os.getcwd()

        os.makedirs(out_dir, exist_ok=True)

        file_name_only = os.path.basename(Pms_File7z)

        # -------------------------------------------------------
        # 組合 7z 參數
        # -------------------------------------------------------
        args = ["a"]

        if Pms_Password:
            args.append(f"-p{Pms_Password}")

        if Pmi_SplitSize_K not in (None, -1):
            args.append(f"-v{Pmi_SplitSize_K}k")

        args.append(file_name_only)

        for f in file_list:
            args.append(f)

        # -------------------------------------------------------
        # 執行壓縮
        # -------------------------------------------------------
        self._run_7z(args)

        # -------------------------------------------------------
        # ▒▒▒ 壓縮後 → 移動所有分割檔 / 單一檔 ▒▒▒
        # -------------------------------------------------------
        self._move_output_files(file_name_only, out_dir)


    # -------------------------------------------------------------
    # 共用：移動壓縮結果到指定目錄
    # -------------------------------------------------------------
    def _move_output_files(self, base_file_name:str, out_dir:str):
        """
        base_file_name = "Orange.7z"
        最後尋找：
            Orange.7z
            Orange.7z.001
            Orange.7z.002
            ...
        """
        for f in os.listdir("."):
            if f == base_file_name or f.startswith(base_file_name + "."):
                shutil.move(f, os.path.join(out_dir, f))


    def CUF_Decompress(self, Pms_ArchiveFile, Pms_OutputDir, Pms_Password=None):
        """
        解壓縮通用函式（最終穩定版本）
        -------------------------------------
        Pms_ArchiveFile : 壓縮檔完整路徑
        Pms_OutputDir   : 要解壓到哪裡
        Pms_Password    : 解壓密碼（可省略）
        -------------------------------------
        支援格式：
        7z, zip, rar, tar, tar.gz, tar.bz2, tar.xz
        """
        # ---------- 路徑檢查 ----------
        if not os.path.exists(Pms_ArchiveFile):
            return False, f"Compress file not found: {Pms_ArchiveFile}"

        os.makedirs(Pms_OutputDir, exist_ok=True)

        Pms_7zExe = self.seven_zip_path

        args = ["x"]

        if Pms_Password:
            args.append(f"-p{Pms_Password}")

        args.append(Pms_ArchiveFile)
        args.append(f"-o{Pms_OutputDir}")
        args.append("-y")

        # ★★★ 使用會有進度事件的版本 ★★★
        try:
            self._run_7z(args)
            return True, "Decompress successful."
        except Exception as e:
            return False, f"Decompress failure:\n{str(e)}"
        

# ================================================================================
# [使用範例]
def GE_ProgressEvent(Pmf_Percent):
    print(str(Pmf_Percent));

if(__name__=="__main__"):
    ms_Path_7z: str;
    
    obj_7z = CLASS_7zArchive();

    obj_7z.CUF_SET_ProgressEvent(GE_ProgressEvent);

    obj_7z.CUF_CompressFolder(Pms_FolderName="X:\\TEMP\\BOOK\\MUSIC", 
                              Pms_File7z="X:\\temp\\book\\PPPK\\GOOD_FILE", 
                              Pms_Password="Gotech123",
                              Pmi_SplitSize_K=640);

    obj_7z.CUF_CompressFile(Pms_FileSource="X:\\temp\\book\\*.png",
                            Pms_File7z="X:\\temp\\book\\abcde\\pqrst\\PPPK-2\\我的PNG圖檔",
                            Pms_Password="OKOKGOOD",
                            Pmi_SplitSize_K=100);

    obj_7z.CUF_Decompress(Pms_ArchiveFile="X:\\TEMP\\BOOK\\abcde\\pqrst\\PPPK-2\\我的PNG圖檔.7z.001",
                          Pms_OutputDir="X:\\temp\\OK了", 
                          Pms_Password="OKOKGOOD")