from .files import duplicate
from .files import funnel
from .torch import acceleration_device
