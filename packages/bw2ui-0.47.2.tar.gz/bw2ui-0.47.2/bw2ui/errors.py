# -*- coding: utf-8 -*-


class UnknownAction(Exception):
    pass


class UnknownDatabase(Exception):
    pass
