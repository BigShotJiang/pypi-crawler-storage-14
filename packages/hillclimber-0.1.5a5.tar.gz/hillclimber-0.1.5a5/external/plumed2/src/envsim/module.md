This module contains the [ENVIRONMENTSIMILARITY](ENVIRONMENTSIMILARITY.md) symmetry function.  This action
allows you to determine how similar the environment around atoms is to that found in some reference crystal
structure.  Full details of the method that is used to determine the crystallinity in this action are available in the documentation you can find below.

