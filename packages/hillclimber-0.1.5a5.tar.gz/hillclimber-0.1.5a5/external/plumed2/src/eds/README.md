Experiment Directed Simulation (EDS)
====================================


Install
------------------------------------
Enable compilation by adding the `--enable-modules=+eds`
to the configure command.


Documentation
------------------------------------
See the generated documentation for information on
using


Authors
------------------------------------
Glen Hocky (University of Chicago) <hockyg@uchicago.edu>
Andrew White (University of Rochester) <andrew.white@rochester.edu>


Copyright
------------------------------------
See ./COPYRIGHT
