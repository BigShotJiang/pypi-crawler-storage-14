This module contains PLUMED's core functionalities.  This includes the abstract base classes that are inherited from when building new actions and the actions that 
allow you to pass data between PLUMED, MD codes and other scripts.  If you are interested in learning more about these core functionalities and in learning how to 
implement new methods you should read [the developer documentation](../../developer-doc/html/index.html). 
