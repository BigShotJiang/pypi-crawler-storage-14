#! /usr/bin/env bash

"${PLUMED_ROOT}"/patches/patch.sh "$@"

