"""
Functions related to processing datasets.
"""

from __future__ import annotations

from cellphe.processing.image import normalise_image as normalise_image
