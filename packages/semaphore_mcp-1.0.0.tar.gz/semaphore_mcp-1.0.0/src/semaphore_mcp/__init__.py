"""
SemaphoreMCP - Model Context Protocol for SemaphoreUI.

This package provides MCP tools for interacting with SemaphoreUI API.
"""

__version__ = "0.1.0"
