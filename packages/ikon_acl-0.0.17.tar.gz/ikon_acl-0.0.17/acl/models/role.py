# acl/models/role.py
from sqlalchemy import Integer, String, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from acl.db_base import Base
from acl.models.permission import Permission

UUID_STR = String(36)

class IkonRolePermission(Base):
    __tablename__ = "ikon_role_permissions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    role_id: Mapped[str] = mapped_column(UUID_STR, nullable=False)
    permission_id: Mapped[int] = mapped_column(Integer, ForeignKey("permission.id"), nullable=False)

    permission: Mapped[Permission] = relationship("Permission")

    __table_args__ = (
        UniqueConstraint("role_id", "permission_id", name="uq_role_permission"),
    )


class IkonRoleMembership(Base):
    __tablename__ = "ikon_app_role_membership"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(UUID_STR, nullable=False)
    account_id: Mapped[str] = mapped_column(UUID_STR, nullable=False)
    role_id: Mapped[str] = mapped_column(UUID_STR, nullable=False)
