#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Crawler SDK - Academic Article Author Extraction SDK

A pluggable SDK for extracting author information from academic publisher websites.
Supports both browser-based (Playwright) and API-based extraction methods.

主要组件:
- strategies: 解析策略基类 (ParseStrategy)
- extractors: 邮箱提取器基类和责任链 (EmailExtractor, ExtractorChain)
- types: 数据类型定义 (ArticleInfo, AuthorDetail, CrawlResult, AuthorInfo)
- utils: 工具函数 (decorators, validators)

安装:
    pip install crawler-sdk

基本用法:
    >>> from crawler_sdk import ParseStrategy, AuthorInfo
    >>> from crawler_sdk.extractors import ExtractorChain, ButtonClickExtractor
    >>>
    >>> class MyStrategy(ParseStrategy):
    ...     async def extract_authors(self, page):
    ...         # 实现提取逻辑
    ...         return [AuthorInfo(author_index=1, name="John Doe", emails=["john@example.com"])]
    ...
    ...     def get_selectors(self):
    ...         return {'author': '.author', 'email': '.email'}

API 模式用法:
    >>> from crawler_sdk.extractors import APIExtractor, APIExtractorChain
    >>>
    >>> class MyAPIExtractor(APIExtractor):
    ...     async def extract(self, article_data):
    ...         # 实现 API 提取逻辑
    ...         return [AuthorInfo(...)]
"""

__version__ = '1.0.2'
__author__ = 'Marketing Crawlers Team'

# Strategies
from .strategies import ParseStrategy

# Extractors
from .extractors import (
    EmailExtractor,
    ExtractorChain,
    EMAIL_PATTERN,
    ButtonClickExtractor,
    DirectTextExtractor,
    MetadataExtractor,
    JavaScriptExtractor,
    APIExtractor,
    APIExtractorChain,
)

# Types
from .types import (
    ArticleInfo,
    AuthorDetail,
    CrawlResult,
    AuthorInfo,
)

# Utils
from .utils import (
    retry,
    rate_limit,
    timeout,
    validate_email,
    validate_url,
    validate_doi,
    validate_isbn,
    validate_phone,
    validate_ipv4,
    validate_uuid,
    normalize_publisher_name,
    matches_publisher,
    find_matching_publisher,
)


__all__ = [
    # Version
    '__version__',
    # Strategies
    'ParseStrategy',
    # Extractors (Browser-based)
    'EmailExtractor',
    'ExtractorChain',
    'EMAIL_PATTERN',
    'ButtonClickExtractor',
    'DirectTextExtractor',
    'MetadataExtractor',
    'JavaScriptExtractor',
    # Extractors (API-based)
    'APIExtractor',
    'APIExtractorChain',
    # Types
    'ArticleInfo',
    'AuthorDetail',
    'CrawlResult',
    'AuthorInfo',
    # Decorators
    'retry',
    'rate_limit',
    'timeout',
    # Validators
    'validate_email',
    'validate_url',
    'validate_doi',
    'validate_isbn',
    'validate_phone',
    'validate_ipv4',
    'validate_uuid',
    # Publisher utils
    'normalize_publisher_name',
    'matches_publisher',
    'find_matching_publisher',
]
