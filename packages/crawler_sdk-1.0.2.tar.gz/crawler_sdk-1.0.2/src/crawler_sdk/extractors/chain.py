#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
提取器链管理器模块

负责构建和执行提取器责任链，协调多个提取器按顺序尝试提取邮箱。
"""

import logging
from typing import List, Dict, Optional

from .base import EmailExtractor

logger = logging.getLogger(__name__)


class ExtractorChain:
    """
    提取器链管理器

    负责构建和执行提取器责任链，协调多个提取器按顺序尝试提取邮箱。

    Attributes:
        head: 链的头部提取器
        extractors: 链中所有提取器的列表

    Example:
        >>> chain = ExtractorChain()
        >>> chain.add(ButtonClickExtractor())
        >>> chain.add(DirectTextExtractor())
        >>> chain.add(MetadataExtractor())
        >>>
        >>> # 或使用链式调用
        >>> chain = ExtractorChain()
        >>> (chain.add(ButtonClickExtractor())
        ...       .add(DirectTextExtractor())
        ...       .add(MetadataExtractor()))
        >>>
        >>> # 执行提取
        >>> emails = await chain.execute(page, selector_config)
    """

    def __init__(self):
        """初始化提取器链"""
        self.head: Optional[EmailExtractor] = None
        self.extractors: List[EmailExtractor] = []

    def add(self, extractor: EmailExtractor) -> 'ExtractorChain':
        """
        添加提取器到链末端

        Args:
            extractor: 要添加的提取器实例

        Returns:
            self，支持链式调用

        Example:
            >>> chain.add(extractor1).add(extractor2).add(extractor3)
        """
        if not isinstance(extractor, EmailExtractor):
            raise TypeError(f"Expected EmailExtractor, got {type(extractor)}")

        self.extractors.append(extractor)

        if not self.head:
            self.head = extractor
        else:
            current = self.head
            while current.next_extractor:
                current = current.next_extractor
            current.set_next(extractor)

        logger.debug(f"➕ Added {extractor.name} to chain (position {len(self.extractors)})")

        return self

    async def execute(self, page, selector_config: Dict) -> List[str]:
        """
        执行提取器链

        从头部开始，依次执行每个提取器直到成功提取或到达链末端。

        Args:
            page: Playwright Page 对象
            selector_config: 选择器配置字典

        Returns:
            提取到的邮箱地址列表
        """
        if not self.head:
            logger.warning("⚠️  Extractor chain is empty")
            return []

        logger.info(f"🚀 Starting extractor chain with {len(self.extractors)} extractors")

        emails = await self.head.handle(page, selector_config)

        if emails:
            logger.info(f"🎯 Chain completed: extracted {len(emails)} emails")
        else:
            logger.warning("❌ Chain completed: no emails found")

        return emails

    def get_extractors(self) -> List[str]:
        """
        获取链中所有提取器的名称

        Returns:
            提取器名称列表
        """
        return [e.name for e in self.extractors]

    def clear(self) -> None:
        """清空提取器链"""
        self.head = None
        self.extractors = []
        logger.debug("🧹 Extractor chain cleared")

    def __len__(self) -> int:
        """返回链中提取器的数量"""
        return len(self.extractors)

    def __repr__(self) -> str:
        """字符串表示"""
        extractor_names = ' -> '.join(self.get_extractors())
        return f"<ExtractorChain: {extractor_names}>"
