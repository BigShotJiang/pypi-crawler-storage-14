#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
直接文本邮箱提取器

从页面可见文本中直接提取邮箱地址。
适用于邮箱明文显示在页面上的情况。
"""

import logging
from typing import List, Dict

from .base import EmailExtractor

logger = logging.getLogger(__name__)


class DirectTextExtractor(EmailExtractor):
    """
    直接文本提取器

    策略:
    1. 查找包含邮箱信息的常见容器元素
    2. 从可见文本中提取邮箱地址
    3. 支持处理常见的邮箱混淆格式(如 user[at]domain[dot]com)

    适用场景:
    - 邮箱直接显示在页面上的网站
    - 作者信息区域、联系方式区域
    - footer或sidebar中的联系邮箱

    Example:
        >>> extractor = DirectTextExtractor()
        >>> emails = await extractor.extract(page, {
        ...     'email_container': '.author-info, .contact'
        ... })
    """

    async def extract(self, page, selector_config: Dict) -> List[str]:
        """
        从可见文本直接提取邮箱

        Args:
            page: Playwright Page对象
            selector_config: 选择器配置

        Returns:
            提取到的邮箱列表
        """
        emails = []

        try:
            container_selector = selector_config.get(
                'email_container',
                '.email, .e-address, [class*="email"], [class*="contact"]'
            )

            emails.extend(await self._extract_from_containers(page, container_selector))

            author_selector = selector_config.get(
                'author_section',
                '.author, .authors, .author-info, .author-list, .author-group'
            )

            emails.extend(await self._extract_from_containers(page, author_selector))

            contact_selector = selector_config.get(
                'contact_section',
                '.contact, .correspondence, footer, .article-info'
            )

            emails.extend(await self._extract_from_containers(page, contact_selector))

            emails.extend(await self._extract_from_attributes(page))

            if not emails:
                logger.debug("Trying full page text extraction as fallback")
                emails.extend(await self._extract_from_full_page(page))

            emails = self._validate_emails(emails)

            if emails:
                logger.info(f"✅ Direct text extraction found {len(emails)} emails")

        except Exception as e:
            logger.warning(f"Direct text extraction failed: {e}")
            return []

        return emails

    async def _extract_from_containers(self, page, selector: str) -> List[str]:
        """从指定容器元素中提取邮箱"""
        emails = []

        try:
            await page.wait_for_selector(selector, timeout=3000, state='attached')
            elements = await page.query_selector_all(selector)

            logger.debug(f"Found {len(elements)} elements for selector: {selector}")

            for elem in elements:
                try:
                    if not await elem.is_visible():
                        continue

                    text = await elem.inner_text()
                    if text:
                        found = self._extract_emails_from_text(text)
                        if found:
                            emails.extend(found)
                            logger.debug(f"Found {len(found)} emails in element text")

                    import re
                    html = await elem.inner_html()
                    if html:
                        clean_html = re.sub(r'<[^>]+>', ' ', html)
                        found = self._extract_emails_from_text(clean_html)
                        if found:
                            emails.extend(found)

                except Exception as e:
                    logger.debug(f"Failed to extract from element: {e}")
                    continue

        except Exception as e:
            logger.debug(f"No elements found for selector '{selector}': {e}")

        return emails

    async def _extract_from_attributes(self, page) -> List[str]:
        """从元素属性中提取邮箱"""
        emails = []

        try:
            attribute_emails = await page.evaluate('''() => {
                const emails = [];
                const attributes = ['data-email', 'data-author-email', 'data-contact', 'data-mail'];

                attributes.forEach(attr => {
                    const elements = document.querySelectorAll(`[${attr}]`);
                    elements.forEach(el => {
                        const value = el.getAttribute(attr);
                        if (value) emails.push(value);
                    });
                });

                const mailtoLinks = document.querySelectorAll('a[href^="mailto:"]');
                mailtoLinks.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href) {
                        const email = href.replace('mailto:', '').split('?')[0];
                        emails.push(email);
                    }
                });

                return emails;
            }''')

            if attribute_emails:
                for email in attribute_emails:
                    extracted = self._extract_emails_from_text(email)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from attributes")

        except Exception as e:
            logger.debug(f"Failed to extract from attributes: {e}")

        return emails

    async def _extract_from_full_page(self, page) -> List[str]:
        """从整个页面文本中提取邮箱(备用方案)"""
        emails = []

        try:
            body_text = await page.evaluate('() => document.body.innerText')

            if body_text:
                emails = self._extract_emails_from_text(body_text)
                logger.debug(f"Full page extraction found {len(emails)} emails")

        except Exception as e:
            logger.debug(f"Failed to extract from full page: {e}")

        return emails
