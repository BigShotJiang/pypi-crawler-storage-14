"""Unit tests for core modules."""
