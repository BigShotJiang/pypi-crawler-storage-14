"""Contains interfaces to built-in and external libraries."""
