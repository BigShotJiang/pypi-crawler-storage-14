"""Contain core modules that set up and define the framework."""
