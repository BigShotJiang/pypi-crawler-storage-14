# Audio Properties MCP

调整音频属性的 MCP 服务，提供 `convert_audio_properties` 工具。返回值为英文文本。

## 安装
```bash
pip install audio-properties-mcp
```

## 运行
```bash
audio-properties-mcp
```

## 工具
- `convert_audio_properties(input_audio_path, output_audio_path, target_format, bitrate?, sample_rate?, channels?, sample_format?) -> str`
  - 注意：WAV/PCM 不支持 `bitrate`，应使用 `sample_format`（如 s16/s24/s32/flt）
  - 其它格式可设置 `bitrate`

## 示例
将 FLAC 转 48kHz 双声道 AAC：