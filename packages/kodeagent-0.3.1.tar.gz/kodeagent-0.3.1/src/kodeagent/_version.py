"""Single-source package version for KodeAgent.

Update the __version__ string here BEFORE making a release on GitHub.
"""

__version__ = '0.3.1'
