import pathlib
from setuptools import setup, find_packages

LOG_FILE = pathlib.Path.home() / ".friendlyexample_install.log"
LOG_FILE.write_text("friendlyexample was built/installed.\n")
print("Hello, from setup")

setup(
    name="python-doenv",
    version="2.2.6",
    description="A small example package",
    packages=find_packages("src"),
    package_dir={"": "src"},
    python_requires=">=3.8",
)
