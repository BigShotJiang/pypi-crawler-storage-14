# pypi_hello_world

Simple hello world example package.

```python
from pypi_hello_world import hello

print(hello("Anna"))
```
