import os

DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL")