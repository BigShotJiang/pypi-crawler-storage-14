# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Init file for azureml-explain-model/azureml/explain/model/common/storage_policy."""
from azureml.interpret.common.storage_policy import storage_policy

__all__ = ['storage_policy']
