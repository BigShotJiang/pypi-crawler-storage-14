# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Init file for azureml-explain-model/azureml/explain/model/metric_constants."""
from interpret_community.permutation.metric_constants import MetricConstants

__all__ = ["MetricConstants"]
