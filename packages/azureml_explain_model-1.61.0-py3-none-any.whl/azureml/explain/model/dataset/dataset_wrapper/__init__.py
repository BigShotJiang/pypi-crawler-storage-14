# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Init file for azureml-explain-model/azureml/explain/model/dataset/dataset_wrapper."""
from interpret_community.dataset.dataset_wrapper import DatasetWrapper

__all__ = ['DatasetWrapper']
