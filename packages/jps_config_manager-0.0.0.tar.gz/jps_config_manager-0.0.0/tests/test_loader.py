import pytest
from pathlib import Path
from jps_config_manager.config.loader import load_yaml


def test_load_yaml_none():
    assert load_yaml(None) == {}


def test_load_yaml_missing_file(tmp_path):
    missing = tmp_path / "does_not_exist.yaml"
    assert load_yaml(str(missing)) == {}


def test_load_yaml_valid(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("a: 1\nb:\n  c: d\n")
    assert load_yaml(str(f)) == {"a": 1, "b": {"c": "d"}}


def test_load_yaml_invalid(tmp_path):
    f = tmp_path / "bad.yaml"
    f.write_text("a: ::: invalid :::\n")

    with pytest.raises(ValueError):
        load_yaml(str(f))
