import pytest
from pathlib import Path
from jps_config_manager.config.manager import ConfigManager


@pytest.fixture
def sample_config():
    """Initialize a fresh instance before each test."""
    ConfigManager._instance = None  # reset singleton

    defaults = {
        "pipeline": {
            "metric": "median",
            "trim": 0.1
        },
        "paths": {
            "input_fastq": "/tmp/input.fastq",
            "work_dir": "/tmp/work"
        },
        "behavior": {"default_fallback": True},
        "numbers": {
            "int_val": 5,
            "float_val": 3.14,
            "bool_val": True
        },
        "lists": {
            "items": ["a", "b"]
        }
    }

    ConfigManager.initialize(
        project_defaults=defaults,
        default_config_file=None,
        user_config_file=None
    )

    return ConfigManager.instance()


def test_get_basic(sample_config):
    assert sample_config.get("pipeline.metric") == "median"
    assert sample_config.get(section="pipeline", param="trim") == 0.1


def test_get_missing(sample_config):
    with pytest.raises(KeyError):
        sample_config.get("pipeline.missing_param")


def test_get_int(sample_config):
    assert sample_config.get_int("numbers.int_val") == 5

    with pytest.raises(TypeError):
        sample_config.get_int("numbers.float_val")  # float not allowed

    with pytest.raises(TypeError):
        sample_config.get_int("numbers.bool_val")  # bool subclass of int


def test_get_float(sample_config):
    assert sample_config.get_float("numbers.float_val") == 3.14
    assert sample_config.get_float("numbers.int_val") == 5.0  # allowed

    with pytest.raises(TypeError):
        sample_config.get_float("lists.items")


def test_get_bool(sample_config):
    assert sample_config.get_bool("numbers.bool_val") is True

    with pytest.raises(TypeError):
        sample_config.get_bool("pipeline.metric")


def test_get_list(sample_config):
    assert sample_config.get_list("lists.items") == ["a", "b"]

    with pytest.raises(TypeError):
        sample_config.get_list("numbers.float_val")


def test_get_str(sample_config):
    assert sample_config.get_str("pipeline.metric") == "median"

    with pytest.raises(TypeError):
        sample_config.get_str("numbers.int_val")


def test_get_path_file(tmp_path):
    test_file = tmp_path / "abc.txt"
    test_file.write_text("hello")

    defaults = {"paths": {"file": str(test_file)}, "behavior": {"default_fallback": True}}
    ConfigManager._instance = None
    ConfigManager.initialize(defaults, None, None)
    cfg = ConfigManager.instance()

    p = cfg.get_path("paths.file", is_dir=False)
    assert isinstance(p, Path)
    assert p.exists()
    assert p.is_file()


def test_get_path_dir(tmp_path):
    d = tmp_path / "mydir"
    d.mkdir()

    defaults = {"paths": {"dir": str(d)}, "behavior": {"default_fallback": True}}
    ConfigManager._instance = None
    ConfigManager.initialize(defaults, None, None)
    cfg = ConfigManager.instance()

    p = cfg.get_path("paths.dir", is_dir=True)
    assert isinstance(p, Path)
    assert p.exists()
    assert p.is_dir()


def test_get_path_nonexistent(tmp_path):
    missing = tmp_path / "nope.txt"

    defaults = {"paths": {"missing": str(missing)}, "behavior": {"default_fallback": True}}
    ConfigManager._instance = None
    ConfigManager.initialize(defaults, None, None)
    cfg = ConfigManager.instance()

    with pytest.raises(FileNotFoundError):
        cfg.get_path("paths.missing", must_exist=True)
