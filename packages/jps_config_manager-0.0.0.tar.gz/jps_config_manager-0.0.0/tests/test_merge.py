import pytest


from jps_config_manager.config.merge import merge_config, _deep_merge, _schema_from
from jps_config_manager.config.validator import _validate_no_missing_keys


def test_deep_merge_basic():
    base = {"a": 1, "b": {"c": 2}}
    override = {"b": {"c": 3}}
    result = _deep_merge(base, override, fallback=True)
    assert result == {"a": 1, "b": {"c": 3}}


def test_deep_merge_none_fallback_enabled():
    base = {"a": 1}
    override = {"a": None}
    result = _deep_merge(base, override, fallback=True)
    assert result == {"a": 1}


def test_deep_merge_none_fallback_disabled():
    base = {"a": 1}
    override = {"a": None}
    result = _deep_merge(base, override, fallback=False)
    assert result == {"a": None}


def test_merge_config_priority():
    defaults = {"pipeline": {"metric": "median", "trim": 0.1}}
    default_yaml = {"pipeline": {"metric": "trimmed_mean"}}
    user_yaml = {"pipeline": {"trim": 0.2}}

    merged = merge_config(defaults, default_yaml, user_yaml)

    assert merged == {
        "pipeline": {"metric": "trimmed_mean", "trim": 0.2},
        "behavior": {"default_fallback": True},  # derived from defaults if included
    } or merged["pipeline"] == {
        "metric": "trimmed_mean", "trim": 0.2
    }


def test_merge_config_no_fallback_validation_error():
    defaults = {"pipeline": {"metric": "median", "trim": 0.1}}
    default_yaml = {}
    user_yaml = {"behavior": {"default_fallback": False},
                 "pipeline": {"metric": "x"}}

    # missing 'trim' under fallback=False
    with pytest.raises(ValueError):
        merge_config(defaults, default_yaml, user_yaml)
