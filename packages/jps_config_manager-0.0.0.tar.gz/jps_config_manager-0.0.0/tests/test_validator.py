import pytest

from jps_config_manager.config.validator import _validate_no_missing_keys


def test_schema_validation_missing_keys():
    schema = {
        "pipeline": {
            "metric": True,
            "trim": True
        }
    }

    final = {"pipeline": {"metric": "hello"}}  # missing trim

    with pytest.raises(ValueError):
        _validate_no_missing_keys(schema, final)
