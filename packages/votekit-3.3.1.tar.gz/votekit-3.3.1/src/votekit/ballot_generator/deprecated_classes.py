class DeprecatedClass:
    def __init__(self):
        raise NotImplementedError("This class is deprecated and should not be used.")


class name_BradleyTerry(DeprecatedClass):
    pass


class name_PlackettLuce(DeprecatedClass):
    pass


class short_name_PlackettLuce(DeprecatedClass):
    pass


class name_Cumulative(DeprecatedClass):
    pass


class CambridgeSampler(DeprecatedClass):
    pass


class slate_PlackettLuce(DeprecatedClass):
    pass


class slate_BradleyTerry(DeprecatedClass):
    pass


class ImpartialCulture(DeprecatedClass):
    pass


class ImpartialAnonymousCulture(DeprecatedClass):
    pass


class Spatial(DeprecatedClass):
    pass


class OneDimSpatial(DeprecatedClass):
    pass


class ClusteredSpatial(DeprecatedClass):
    pass


class AlternatingCrossover(DeprecatedClass):
    pass
