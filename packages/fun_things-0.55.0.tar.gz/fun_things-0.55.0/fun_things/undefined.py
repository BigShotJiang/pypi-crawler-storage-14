from typing import NamedTuple


undefined = NamedTuple("Undefined", [])
"""
Generic undefined data type.
"""
