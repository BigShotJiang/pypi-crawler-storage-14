"""
Each TestCase subclass should have it's standard library counterpart.
"""
import tests.test_definitions
import tests.test_chains
import tests.test_capture
import tests.test_attributes
import tests.test_doc
