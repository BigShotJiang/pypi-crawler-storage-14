"""msgtrace SDK - OpenTelemetry-based tracing for AI applications."""

from msgtrace.version import __version__

__all__ = ["__version__"]
