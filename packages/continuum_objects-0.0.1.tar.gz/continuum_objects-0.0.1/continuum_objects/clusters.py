from .abc_continuum_object import ABCContinuumObject, ABCContinuumObjectNoId
from uuid import UUID
from typing import Annotated
from pydantic import Field, NonNegativeInt, BaseModel


class Unit(ABCContinuumObjectNoId):
    value: float
    unit: str


class ABCNodeComponents(ABCContinuumObjectNoId):
    count: Annotated[
        NonNegativeInt,
        Field(default=0, description="Number of such component on the node"),
    ]


class MotherBoard(ABCNodeComponents): ...


class RAM(ABCNodeComponents):
    capacity: Annotated[Unit, Field(description="RAM capacity, in GB")]


class CPU(ABCNodeComponents): ...


class NodeGroup(ABCContinuumObjectNoId):
    count: Annotated[
        NonNegativeInt,
        Field(
            default=0, description="Number of such nodes on the node group (partition)"
        ),
    ]
    nodeComponents: Annotated[
        list[ABCNodeComponents],
        Field(
            description="List of components on the node",
        ),
    ]


class Partition(ABCContinuumObject):
    totalNodeCount: Annotated[
        NonNegativeInt,
        Field(
            description="Total number of nodes on the partition", examples=[17, 0, 1]
        ),
    ]
    nodes: Annotated[
        list[NodeGroup],
        Field(
            description="List of nodes",
        ),
    ]


class SuperComputer(ABCContinuumObject):
    hasPartitions: Annotated[
        list[Partition],
        Field(
            description="List of partitions on the cluster",
        ),
    ]
