import { defineComponent as De, inject as ti, computed as Fe, ref as Ce, reactive as $i, watch as ee, onUnmounted as Zi, createElementBlock as ae, createCommentVNode as be, openBlock as ne, normalizeStyle as $r, createElementVNode as Bt, toDisplayString as Nt, createTextVNode as cn, shallowRef as Mr, h as hn, onMounted as La, toRaw as dn, nextTick as Oa, version as Ea, isProxy as Sr, unref as _e, createVNode as Ba, withModifiers as Ia, withDirectives as Ra, vModelSelect as za, createBlock as Fa } from "vue";
import { IconLayer as so, PathLayer as Cr, ScatterplotLayer as Ha } from "@deck.gl/layers";
import { svg as ja, html as Na, render as Wa } from "lit-html";
import Va, { airport_information as no, aircraft_information as Ya, run as Ua } from "rs1090-wasm";
import { PathStyleExtension as Xa } from "@deck.gl/extensions";
function Dr(i) {
  return i && i.__esModule && Object.prototype.hasOwnProperty.call(i, "default") ? i.default : i;
}
var Gs = { exports: {} }, oo;
function Ga() {
  return oo || (oo = 1, (function(i, t) {
    (function(e, s) {
      i.exports = s();
    })(window, function() {
      return (function(e) {
        var s = {};
        function n(o) {
          if (s[o]) return s[o].exports;
          var r = s[o] = { i: o, l: !1, exports: {} };
          return e[o].call(r.exports, r, r.exports, n), r.l = !0, r.exports;
        }
        return n.m = e, n.c = s, n.d = function(o, r, a) {
          n.o(o, r) || Object.defineProperty(o, r, { enumerable: !0, get: a });
        }, n.r = function(o) {
          typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(o, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(o, "__esModule", { value: !0 });
        }, n.t = function(o, r) {
          if (1 & r && (o = n(o)), 8 & r || 4 & r && typeof o == "object" && o && o.__esModule) return o;
          var a = /* @__PURE__ */ Object.create(null);
          if (n.r(a), Object.defineProperty(a, "default", { enumerable: !0, value: o }), 2 & r && typeof o != "string") for (var l in o) n.d(a, l, (function(d) {
            return o[d];
          }).bind(null, l));
          return a;
        }, n.n = function(o) {
          var r = o && o.__esModule ? function() {
            return o.default;
          } : function() {
            return o;
          };
          return n.d(r, "a", r), r;
        }, n.o = function(o, r) {
          return Object.prototype.hasOwnProperty.call(o, r);
        }, n.p = "", n(n.s = 1);
      })([function(e, s, n) {
        var o, r;
        o = [n(2)], (r = (function(a) {
          function l(c) {
            if (l.is(c, "function")) return d ? c() : a.on("raphael.DOMload", c);
            if (l.is(c, ut)) return l._engine.create[z](l, c.splice(0, 3 + l.is(c[0], et))).add(c);
            var h = Array.prototype.slice.call(arguments, 0);
            if (l.is(h[h.length - 1], "function")) {
              var u = h.pop();
              return d ? u.call(l._engine.create[z](l, h)) : a.on("raphael.DOMload", function() {
                u.call(l._engine.create[z](l, h));
              });
            }
            return l._engine.create[z](l, arguments);
          }
          l.version = "2.3.0", l.eve = a;
          var d, f, x = /[, ]+/, b = { circle: 1, rect: 1, path: 1, ellipse: 1, text: 1, image: 1 }, k = /\{(\d+)\}/g, T = "hasOwnProperty", C = { doc: document, win: window }, A = { was: Object.prototype[T].call(C.win, "Raphael"), is: C.win.Raphael }, P = function() {
            this.ca = this.customAttributes = {};
          }, z = "apply", O = "concat", W = "ontouchstart" in window || window.TouchEvent || window.DocumentTouch && document instanceof DocumentTouch, R = "", Y = " ", B = String, H = "split", it = "click dblclick mousedown mousemove mouseout mouseover mouseup touchstart touchmove touchend touchcancel"[H](Y), ct = { mousedown: "touchstart", mousemove: "touchmove", mouseup: "touchend" }, X = B.prototype.toLowerCase, st = Math, ft = st.max, Q = st.min, G = st.abs, K = st.pow, ht = st.PI, et = "number", ut = "array", yt = Object.prototype.toString, _ = (l._ISURL = /^url\(['"]?(.+?)['"]?\)$/i, /^\s*((#[a-f\d]{6})|(#[a-f\d]{3})|rgba?\(\s*([\d\.]+%?\s*,\s*[\d\.]+%?\s*,\s*[\d\.]+%?(?:\s*,\s*[\d\.]+%?)?)\s*\)|hsba?\(\s*([\d\.]+(?:deg|\xb0|%)?\s*,\s*[\d\.]+%?\s*,\s*[\d\.]+(?:%?\s*,\s*[\d\.]+)?)%?\s*\)|hsla?\(\s*([\d\.]+(?:deg|\xb0|%)?\s*,\s*[\d\.]+%?\s*,\s*[\d\.]+(?:%?\s*,\s*[\d\.]+)?)%?\s*\))\s*$/i), y = { NaN: 1, Infinity: 1, "-Infinity": 1 }, g = /^(?:cubic-)?bezier\(([^,]+),([^,]+),([^,]+),([^\)]+)\)/, w = st.round, D = parseFloat, E = parseInt, I = B.prototype.toUpperCase, Z = l._availableAttrs = { "arrow-end": "none", "arrow-start": "none", blur: 0, "clip-rect": "0 0 1e9 1e9", cursor: "default", cx: 0, cy: 0, fill: "#fff", "fill-opacity": 1, font: '10px "Arial"', "font-family": '"Arial"', "font-size": "10", "font-style": "normal", "font-weight": 400, gradient: 0, height: 0, href: "http://raphaeljs.com/", "letter-spacing": 0, opacity: 1, path: "M0,0", r: 0, rx: 0, ry: 0, src: "", stroke: "#000", "stroke-dasharray": "", "stroke-linecap": "butt", "stroke-linejoin": "butt", "stroke-miterlimit": 0, "stroke-opacity": 1, "stroke-width": 1, target: "_blank", "text-anchor": "middle", title: "Raphael", transform: "", width: 0, x: 0, y: 0, class: "" }, F = l._availableAnimAttrs = { blur: et, "clip-rect": "csv", cx: et, cy: et, fill: "colour", "fill-opacity": et, "font-size": et, height: et, opacity: et, path: "path", r: et, rx: et, ry: et, stroke: "colour", "stroke-opacity": et, "stroke-width": et, transform: "transform", width: et, x: et, y: et }, J = /[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*/, dt = { hs: 1, rg: 1 }, gt = /,?([achlmqrstvxz]),?/gi, _t = /([achlmrqstvz])[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029,]*((-?\d*\.?\d*(?:e[\-+]?\d+)?[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,?[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*)+)/gi, Mt = /([rstm])[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029,]*((-?\d*\.?\d*(?:e[\-+]?\d+)?[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,?[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*)+)/gi, $t = /(-?\d*\.?\d*(?:e[\-+]?\d+)?)[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,?[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*/gi, Tt = (l._radial_gradient = /^r(?:\(([^,]+?)[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,[\x09\x0a\x0b\x0c\x0d\x20\xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*([^\)]+?)\))?/, {}), Lt = function(c, h) {
            return D(c) - D(h);
          }, At = function(c) {
            return c;
          }, bt = l._rectPath = function(c, h, u, p, m) {
            return m ? [["M", c + m, h], ["l", u - 2 * m, 0], ["a", m, m, 0, 0, 1, m, m], ["l", 0, p - 2 * m], ["a", m, m, 0, 0, 1, -m, m], ["l", 2 * m - u, 0], ["a", m, m, 0, 0, 1, -m, -m], ["l", 0, 2 * m - p], ["a", m, m, 0, 0, 1, m, -m], ["z"]] : [["M", c, h], ["l", u, 0], ["l", 0, p], ["l", -u, 0], ["z"]];
          }, Ft = function(c, h, u, p) {
            return p == null && (p = u), [["M", c, h], ["m", 0, -p], ["a", u, p, 0, 1, 1, 0, 2 * p], ["a", u, p, 0, 1, 1, 0, -2 * p], ["z"]];
          }, zt = l._getPath = { path: function(c) {
            return c.attr("path");
          }, circle: function(c) {
            var h = c.attrs;
            return Ft(h.cx, h.cy, h.r);
          }, ellipse: function(c) {
            var h = c.attrs;
            return Ft(h.cx, h.cy, h.rx, h.ry);
          }, rect: function(c) {
            var h = c.attrs;
            return bt(h.x, h.y, h.width, h.height, h.r);
          }, image: function(c) {
            var h = c.attrs;
            return bt(h.x, h.y, h.width, h.height);
          }, text: function(c) {
            var h = c._getBBox();
            return bt(h.x, h.y, h.width, h.height);
          }, set: function(c) {
            var h = c._getBBox();
            return bt(h.x, h.y, h.width, h.height);
          } }, jt = l.mapPath = function(c, h) {
            if (!h) return c;
            var u, p, m, v, M, $, S;
            for (m = 0, M = (c = Pi(c)).length; m < M; m++) for (v = 1, $ = (S = c[m]).length; v < $; v += 2) u = h.x(S[v], S[v + 1]), p = h.y(S[v], S[v + 1]), S[v] = u, S[v + 1] = p;
            return c;
          };
          if (l._g = C, l.type = C.win.SVGAngle || C.doc.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#BasicStructure", "1.1") ? "SVG" : "VML", l.type == "VML") {
            var Ot, ie = C.doc.createElement("div");
            if (ie.innerHTML = '<v:shape adj="1"/>', (Ot = ie.firstChild).style.behavior = "url(#default#VML)", !Ot || typeof Ot.adj != "object") return l.type = R;
            ie = null;
          }
          function Kt(c) {
            if (typeof c == "function" || Object(c) !== c) return c;
            var h = new c.constructor();
            for (var u in c) c[T](u) && (h[u] = Kt(c[u]));
            return h;
          }
          l.svg = !(l.vml = l.type == "VML"), l._Paper = P, l.fn = f = P.prototype = l.prototype, l._id = 0, l.is = function(c, h) {
            return (h = X.call(h)) == "finite" ? !y[T](+c) : h == "array" ? c instanceof Array : h == "null" && c === null || h == typeof c && c !== null || h == "object" && c === Object(c) || h == "array" && Array.isArray && Array.isArray(c) || yt.call(c).slice(8, -1).toLowerCase() == h;
          }, l.angle = function(c, h, u, p, m, v) {
            if (m == null) {
              var M = c - u, $ = h - p;
              return M || $ ? (180 + 180 * st.atan2(-$, -M) / ht + 360) % 360 : 0;
            }
            return l.angle(c, h, m, v) - l.angle(u, p, m, v);
          }, l.rad = function(c) {
            return c % 360 * ht / 180;
          }, l.deg = function(c) {
            return Math.round(180 * c / ht % 360 * 1e3) / 1e3;
          }, l.snapTo = function(c, h, u) {
            if (u = l.is(u, "finite") ? u : 10, l.is(c, ut)) {
              for (var p = c.length; p--; ) if (G(c[p] - h) <= u) return c[p];
            } else {
              var m = h % (c = +c);
              if (m < u) return h - m;
              if (m > c - u) return h - m + c;
            }
            return h;
          };
          var Ae, Si;
          l.createUUID = (Ae = /[xy]/g, Si = function(c) {
            var h = 16 * st.random() | 0;
            return (c == "x" ? h : 3 & h | 8).toString(16);
          }, function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(Ae, Si).toUpperCase();
          }), l.setWindow = function(c) {
            a("raphael.setWindow", l, C.win, c), C.win = c, C.doc = C.win.document, l._engine.initWin && l._engine.initWin(C.win);
          };
          var Pe = function(c) {
            if (l.vml) {
              var h, u = /^\s+|\s+$/g;
              try {
                var p = new ActiveXObject("htmlfile");
                p.write("<body>"), p.close(), h = p.body;
              } catch {
                h = createPopup().document.body;
              }
              var m = h.createTextRange();
              Pe = Yt(function(M) {
                try {
                  h.style.color = B(M).replace(u, R);
                  var $ = m.queryCommandValue("ForeColor");
                  return "#" + ("000000" + ($ = (255 & $) << 16 | 65280 & $ | (16711680 & $) >>> 16).toString(16)).slice(-6);
                } catch {
                  return "none";
                }
              });
            } else {
              var v = C.doc.createElement("i");
              v.title = "Raphaël Colour Picker", v.style.display = "none", C.doc.body.appendChild(v), Pe = Yt(function(M) {
                return v.style.color = M, C.doc.defaultView.getComputedStyle(v, R).getPropertyValue("color");
              });
            }
            return Pe(c);
          }, si = function() {
            return "hsb(" + [this.h, this.s, this.b] + ")";
          }, ni = function() {
            return "hsl(" + [this.h, this.s, this.l] + ")";
          }, Ci = function() {
            return this.hex;
          }, oi = function(c, h, u) {
            if (h == null && l.is(c, "object") && "r" in c && "g" in c && "b" in c && (u = c.b, h = c.g, c = c.r), h == null && l.is(c, "string")) {
              var p = l.getRGB(c);
              c = p.r, h = p.g, u = p.b;
            }
            return (c > 1 || h > 1 || u > 1) && (c /= 255, h /= 255, u /= 255), [c, h, u];
          }, ts = function(c, h, u, p) {
            var m = { r: c *= 255, g: h *= 255, b: u *= 255, hex: l.rgb(c, h, u), toString: Ci };
            return l.is(p, "finite") && (m.opacity = p), m;
          };
          function Yt(c, h, u) {
            return function p() {
              var m = Array.prototype.slice.call(arguments, 0), v = m.join("␀"), M = p.cache = p.cache || {}, $ = p.count = p.count || [];
              return M[T](v) ? ((function(S, L) {
                for (var N = 0, nt = S.length; N < nt; N++) if (S[N] === L) return S.push(S.splice(N, 1)[0]);
              })($, v), u ? u(M[v]) : M[v]) : ($.length >= 1e3 && delete M[$.shift()], $.push(v), M[v] = c[z](h, m), u ? u(M[v]) : M[v]);
            };
          }
          l.color = function(c) {
            var h;
            return l.is(c, "object") && "h" in c && "s" in c && "b" in c ? (h = l.hsb2rgb(c), c.r = h.r, c.g = h.g, c.b = h.b, c.hex = h.hex) : l.is(c, "object") && "h" in c && "s" in c && "l" in c ? (h = l.hsl2rgb(c), c.r = h.r, c.g = h.g, c.b = h.b, c.hex = h.hex) : (l.is(c, "string") && (c = l.getRGB(c)), l.is(c, "object") && "r" in c && "g" in c && "b" in c ? (h = l.rgb2hsl(c), c.h = h.h, c.s = h.s, c.l = h.l, h = l.rgb2hsb(c), c.v = h.b) : (c = { hex: "none" }).r = c.g = c.b = c.h = c.s = c.v = c.l = -1), c.toString = Ci, c;
          }, l.hsb2rgb = function(c, h, u, p) {
            var m, v, M, $, S;
            return this.is(c, "object") && "h" in c && "s" in c && "b" in c && (u = c.b, h = c.s, p = c.o, c = c.h), $ = (S = u * h) * (1 - G((c = (c *= 360) % 360 / 60) % 2 - 1)), m = v = M = u - S, ts(m += [S, $, 0, 0, $, S][c = ~~c], v += [$, S, S, $, 0, 0][c], M += [0, 0, $, S, S, $][c], p);
          }, l.hsl2rgb = function(c, h, u, p) {
            var m, v, M, $, S;
            return this.is(c, "object") && "h" in c && "s" in c && "l" in c && (u = c.l, h = c.s, c = c.h), (c > 1 || h > 1 || u > 1) && (c /= 360, h /= 100, u /= 100), $ = (S = 2 * h * (u < 0.5 ? u : 1 - u)) * (1 - G((c = (c *= 360) % 360 / 60) % 2 - 1)), m = v = M = u - S / 2, ts(m += [S, $, 0, 0, $, S][c = ~~c], v += [$, S, S, $, 0, 0][c], M += [0, 0, $, S, S, $][c], p);
          }, l.rgb2hsb = function(c, h, u) {
            var p, m;
            return c = (u = oi(c, h, u))[0], h = u[1], u = u[2], { h: (((m = (p = ft(c, h, u)) - Q(c, h, u)) == 0 ? null : p == c ? (h - u) / m : p == h ? (u - c) / m + 2 : (c - h) / m + 4) + 360) % 6 * 60 / 360, s: m == 0 ? 0 : m / p, b: p, toString: si };
          }, l.rgb2hsl = function(c, h, u) {
            var p, m, v, M;
            return c = (u = oi(c, h, u))[0], h = u[1], u = u[2], p = ((m = ft(c, h, u)) + (v = Q(c, h, u))) / 2, { h: (((M = m - v) == 0 ? null : m == c ? (h - u) / M : m == h ? (u - c) / M + 2 : (c - h) / M + 4) + 360) % 6 * 60 / 360, s: M == 0 ? 0 : p < 0.5 ? M / (2 * p) : M / (2 - 2 * p), l: p, toString: ni };
          }, l._path2string = function() {
            return this.join(",").replace(gt, "$1");
          }, l._preload = function(c, h) {
            var u = C.doc.createElement("img");
            u.style.cssText = "position:absolute;left:-9999em;top:-9999em", u.onload = function() {
              h.call(this), this.onload = null, C.doc.body.removeChild(this);
            }, u.onerror = function() {
              C.doc.body.removeChild(this);
            }, C.doc.body.appendChild(u), u.src = c;
          };
          function Te() {
            return this.hex;
          }
          function ri(c, h) {
            for (var u = [], p = 0, m = c.length; m - 2 * !h > p; p += 2) {
              var v = [{ x: +c[p - 2], y: +c[p - 1] }, { x: +c[p], y: +c[p + 1] }, { x: +c[p + 2], y: +c[p + 3] }, { x: +c[p + 4], y: +c[p + 5] }];
              h ? p ? m - 4 == p ? v[3] = { x: +c[0], y: +c[1] } : m - 2 == p && (v[2] = { x: +c[0], y: +c[1] }, v[3] = { x: +c[2], y: +c[3] }) : v[0] = { x: +c[m - 2], y: +c[m - 1] } : m - 4 == p ? v[3] = v[2] : p || (v[0] = { x: +c[p], y: +c[p + 1] }), u.push(["C", (-v[0].x + 6 * v[1].x + v[2].x) / 6, (-v[0].y + 6 * v[1].y + v[2].y) / 6, (v[1].x + 6 * v[2].x - v[3].x) / 6, (v[1].y + 6 * v[2].y - v[3].y) / 6, v[2].x, v[2].y]);
            }
            return u;
          }
          l.getRGB = Yt(function(c) {
            if (!c || (c = B(c)).indexOf("-") + 1) return { r: -1, g: -1, b: -1, hex: "none", error: 1, toString: Te };
            if (c == "none") return { r: -1, g: -1, b: -1, hex: "none", toString: Te };
            !dt[T](c.toLowerCase().substring(0, 2)) && c.charAt() != "#" && (c = Pe(c));
            var h, u, p, m, v, M, $ = c.match(_);
            return $ ? ($[2] && (p = E($[2].substring(5), 16), u = E($[2].substring(3, 5), 16), h = E($[2].substring(1, 3), 16)), $[3] && (p = E((v = $[3].charAt(3)) + v, 16), u = E((v = $[3].charAt(2)) + v, 16), h = E((v = $[3].charAt(1)) + v, 16)), $[4] && (M = $[4][H](J), h = D(M[0]), M[0].slice(-1) == "%" && (h *= 2.55), u = D(M[1]), M[1].slice(-1) == "%" && (u *= 2.55), p = D(M[2]), M[2].slice(-1) == "%" && (p *= 2.55), $[1].toLowerCase().slice(0, 4) == "rgba" && (m = D(M[3])), M[3] && M[3].slice(-1) == "%" && (m /= 100)), $[5] ? (M = $[5][H](J), h = D(M[0]), M[0].slice(-1) == "%" && (h *= 2.55), u = D(M[1]), M[1].slice(-1) == "%" && (u *= 2.55), p = D(M[2]), M[2].slice(-1) == "%" && (p *= 2.55), (M[0].slice(-3) == "deg" || M[0].slice(-1) == "°") && (h /= 360), $[1].toLowerCase().slice(0, 4) == "hsba" && (m = D(M[3])), M[3] && M[3].slice(-1) == "%" && (m /= 100), l.hsb2rgb(h, u, p, m)) : $[6] ? (M = $[6][H](J), h = D(M[0]), M[0].slice(-1) == "%" && (h *= 2.55), u = D(M[1]), M[1].slice(-1) == "%" && (u *= 2.55), p = D(M[2]), M[2].slice(-1) == "%" && (p *= 2.55), (M[0].slice(-3) == "deg" || M[0].slice(-1) == "°") && (h /= 360), $[1].toLowerCase().slice(0, 4) == "hsla" && (m = D(M[3])), M[3] && M[3].slice(-1) == "%" && (m /= 100), l.hsl2rgb(h, u, p, m)) : (($ = { r: h, g: u, b: p, toString: Te }).hex = "#" + (16777216 | p | u << 8 | h << 16).toString(16).slice(1), l.is(m, "finite") && ($.opacity = m), $)) : { r: -1, g: -1, b: -1, hex: "none", error: 1, toString: Te };
          }, l), l.hsb = Yt(function(c, h, u) {
            return l.hsb2rgb(c, h, u).hex;
          }), l.hsl = Yt(function(c, h, u) {
            return l.hsl2rgb(c, h, u).hex;
          }), l.rgb = Yt(function(c, h, u) {
            function p(m) {
              return m + 0.5 | 0;
            }
            return "#" + (16777216 | p(u) | p(h) << 8 | p(c) << 16).toString(16).slice(1);
          }), l.getColor = function(c) {
            var h = this.getColor.start = this.getColor.start || { h: 0, s: 1, b: c || 0.75 }, u = this.hsb2rgb(h.h, h.s, h.b);
            return h.h += 0.075, h.h > 1 && (h.h = 0, h.s -= 0.2, h.s <= 0 && (this.getColor.start = { h: 0, s: 1, b: h.b })), u.hex;
          }, l.getColor.reset = function() {
            delete this.start;
          }, l.parsePathString = function(c) {
            if (!c) return null;
            var h = oe(c);
            if (h.arr) return Jt(h.arr);
            var u = { a: 7, c: 6, h: 1, l: 2, m: 2, r: 4, q: 4, s: 4, t: 2, v: 1, z: 0 }, p = [];
            return l.is(c, ut) && l.is(c[0], ut) && (p = Jt(c)), p.length || B(c).replace(_t, function(m, v, M) {
              var $ = [], S = v.toLowerCase();
              if (M.replace($t, function(L, N) {
                N && $.push(+N);
              }), S == "m" && $.length > 2 && (p.push([v][O]($.splice(0, 2))), S = "l", v = v == "m" ? "l" : "L"), S == "r") p.push([v][O]($));
              else for (; $.length >= u[S] && (p.push([v][O]($.splice(0, u[S]))), u[S]); ) ;
            }), p.toString = l._path2string, h.arr = Jt(p), p;
          }, l.parseTransformString = Yt(function(c) {
            if (!c) return null;
            var h = [];
            return l.is(c, ut) && l.is(c[0], ut) && (h = Jt(c)), h.length || B(c).replace(Mt, function(u, p, m) {
              var v = [];
              X.call(p), m.replace($t, function(M, $) {
                $ && v.push(+$);
              }), h.push([p][O](v));
            }), h.toString = l._path2string, h;
          }, this, function(c) {
            if (!c) return c;
            for (var h = [], u = 0; u < c.length; u++) {
              for (var p = [], m = 0; m < c[u].length; m++) p.push(c[u][m]);
              h.push(p);
            }
            return h;
          });
          var oe = function(c) {
            var h = oe.ps = oe.ps || {};
            return h[c] ? h[c].sleep = 100 : h[c] = { sleep: 100 }, setTimeout(function() {
              for (var u in h) h[T](u) && u != c && (h[u].sleep--, !h[u].sleep && delete h[u]);
            }), h[c];
          };
          function ai(c, h, u, p, m) {
            return c * (c * (-3 * h + 9 * u - 9 * p + 3 * m) + 6 * h - 12 * u + 6 * p) - 3 * h + 3 * u;
          }
          function de(c, h, u, p, m, v, M, $, S) {
            S == null && (S = 1);
            for (var L = (S = S > 1 ? 1 : S < 0 ? 0 : S) / 2, N = [-0.1252, 0.1252, -0.3678, 0.3678, -0.5873, 0.5873, -0.7699, 0.7699, -0.9041, 0.9041, -0.9816, 0.9816], nt = [0.2491, 0.2491, 0.2335, 0.2335, 0.2032, 0.2032, 0.1601, 0.1601, 0.1069, 0.1069, 0.0472, 0.0472], U = 0, j = 0; j < 12; j++) {
              var q = L * N[j] + L, ot = ai(q, c, u, m, M), tt = ai(q, h, p, v, $), V = ot * ot + tt * tt;
              U += nt[j] * st.sqrt(V);
            }
            return L * U;
          }
          function Di(c, h, u, p, m, v, M, $) {
            if (!(ft(c, u) < Q(m, M) || Q(c, u) > ft(m, M) || ft(h, p) < Q(v, $) || Q(h, p) > ft(v, $))) {
              var S = (c - u) * (v - $) - (h - p) * (m - M);
              if (S) {
                var L = ((c * p - h * u) * (m - M) - (c - u) * (m * $ - v * M)) / S, N = ((c * p - h * u) * (v - $) - (h - p) * (m * $ - v * M)) / S, nt = +L.toFixed(2), U = +N.toFixed(2);
                if (!(nt < +Q(c, u).toFixed(2) || nt > +ft(c, u).toFixed(2) || nt < +Q(m, M).toFixed(2) || nt > +ft(m, M).toFixed(2) || U < +Q(h, p).toFixed(2) || U > +ft(h, p).toFixed(2) || U < +Q(v, $).toFixed(2) || U > +ft(v, $).toFixed(2))) return { x: L, y: N };
              }
            }
          }
          function li(c, h, u) {
            var p = l.bezierBBox(c), m = l.bezierBBox(h);
            if (!l.isBBoxIntersect(p, m)) return u ? 0 : [];
            for (var v = de.apply(0, c), M = de.apply(0, h), $ = ft(~~(v / 5), 1), S = ft(~~(M / 5), 1), L = [], N = [], nt = {}, U = u ? 0 : [], j = 0; j < $ + 1; j++) {
              var q = l.findDotsAtSegment.apply(l, c.concat(j / $));
              L.push({ x: q.x, y: q.y, t: j / $ });
            }
            for (j = 0; j < S + 1; j++) q = l.findDotsAtSegment.apply(l, h.concat(j / S)), N.push({ x: q.x, y: q.y, t: j / S });
            for (j = 0; j < $; j++) for (var ot = 0; ot < S; ot++) {
              var tt = L[j], V = L[j + 1], pt = N[ot], rt = N[ot + 1], lt = G(V.x - tt.x) < 1e-3 ? "y" : "x", at = G(rt.x - pt.x) < 1e-3 ? "y" : "x", vt = Di(tt.x, tt.y, V.x, V.y, pt.x, pt.y, rt.x, rt.y);
              if (vt) {
                if (nt[vt.x.toFixed(4)] == vt.y.toFixed(4)) continue;
                nt[vt.x.toFixed(4)] = vt.y.toFixed(4);
                var xt = tt.t + G((vt[lt] - tt[lt]) / (V[lt] - tt[lt])) * (V.t - tt.t), wt = pt.t + G((vt[at] - pt[at]) / (rt[at] - pt[at])) * (rt.t - pt.t);
                xt >= 0 && xt <= 1.001 && wt >= 0 && wt <= 1.001 && (u ? U++ : U.push({ x: vt.x, y: vt.y, t1: Q(xt, 1), t2: Q(wt, 1) }));
              }
            }
            return U;
          }
          function Ai(c, h, u) {
            c = l._path2curve(c), h = l._path2curve(h);
            for (var p, m, v, M, $, S, L, N, nt, U, j = u ? 0 : [], q = 0, ot = c.length; q < ot; q++) {
              var tt = c[q];
              if (tt[0] == "M") p = $ = tt[1], m = S = tt[2];
              else {
                tt[0] == "C" ? (nt = [p, m].concat(tt.slice(1)), p = nt[6], m = nt[7]) : (nt = [p, m, p, m, $, S, $, S], p = $, m = S);
                for (var V = 0, pt = h.length; V < pt; V++) {
                  var rt = h[V];
                  if (rt[0] == "M") v = L = rt[1], M = N = rt[2];
                  else {
                    rt[0] == "C" ? (U = [v, M].concat(rt.slice(1)), v = U[6], M = U[7]) : (U = [v, M, v, M, L, N, L, N], v = L, M = N);
                    var lt = li(nt, U, u);
                    if (u) j += lt;
                    else {
                      for (var at = 0, vt = lt.length; at < vt; at++) lt[at].segment1 = q, lt[at].segment2 = V, lt[at].bez1 = nt, lt[at].bez2 = U;
                      j = j.concat(lt);
                    }
                  }
                }
              }
            }
            return j;
          }
          l.findDotsAtSegment = function(c, h, u, p, m, v, M, $, S) {
            var L = 1 - S, N = K(L, 3), nt = K(L, 2), U = S * S, j = U * S, q = N * c + 3 * nt * S * u + 3 * L * S * S * m + j * M, ot = N * h + 3 * nt * S * p + 3 * L * S * S * v + j * $, tt = c + 2 * S * (u - c) + U * (m - 2 * u + c), V = h + 2 * S * (p - h) + U * (v - 2 * p + h), pt = u + 2 * S * (m - u) + U * (M - 2 * m + u), rt = p + 2 * S * (v - p) + U * ($ - 2 * v + p), lt = L * c + S * u, at = L * h + S * p, vt = L * m + S * M, xt = L * v + S * $, wt = 90 - 180 * st.atan2(tt - pt, V - rt) / ht;
            return (tt > pt || V < rt) && (wt += 180), { x: q, y: ot, m: { x: tt, y: V }, n: { x: pt, y: rt }, start: { x: lt, y: at }, end: { x: vt, y: xt }, alpha: wt };
          }, l.bezierBBox = function(c, h, u, p, m, v, M, $) {
            l.is(c, "array") || (c = [c, h, u, p, m, v, M, $]);
            var S = is.apply(null, c);
            return { x: S.min.x, y: S.min.y, x2: S.max.x, y2: S.max.y, width: S.max.x - S.min.x, height: S.max.y - S.min.y };
          }, l.isPointInsideBBox = function(c, h, u) {
            return h >= c.x && h <= c.x2 && u >= c.y && u <= c.y2;
          }, l.isBBoxIntersect = function(c, h) {
            var u = l.isPointInsideBBox;
            return u(h, c.x, c.y) || u(h, c.x2, c.y) || u(h, c.x, c.y2) || u(h, c.x2, c.y2) || u(c, h.x, h.y) || u(c, h.x2, h.y) || u(c, h.x, h.y2) || u(c, h.x2, h.y2) || (c.x < h.x2 && c.x > h.x || h.x < c.x2 && h.x > c.x) && (c.y < h.y2 && c.y > h.y || h.y < c.y2 && h.y > c.y);
          }, l.pathIntersection = function(c, h) {
            return Ai(c, h);
          }, l.pathIntersectionNumber = function(c, h) {
            return Ai(c, h, 1);
          }, l.isPointInsidePath = function(c, h, u) {
            var p = l.pathBBox(c);
            return l.isPointInsideBBox(p, h, u) && Ai(c, [["M", h, u], ["H", p.x2 + 10]], 1) % 2 == 1;
          }, l._removedFactory = function(c) {
            return function() {
              a("raphael.log", null, "Raphaël: you are calling to method “" + c + "” of removed object", c);
            };
          };
          var Le = l.pathBBox = function(c) {
            var h = oe(c);
            if (h.bbox) return Kt(h.bbox);
            if (!c) return { x: 0, y: 0, width: 0, height: 0, x2: 0, y2: 0 };
            for (var u, p = 0, m = 0, v = [], M = [], $ = 0, S = (c = Pi(c)).length; $ < S; $++) if ((u = c[$])[0] == "M") p = u[1], m = u[2], v.push(p), M.push(m);
            else {
              var L = is(p, m, u[1], u[2], u[3], u[4], u[5], u[6]);
              v = v[O](L.min.x, L.max.x), M = M[O](L.min.y, L.max.y), p = u[5], m = u[6];
            }
            var N = Q[z](0, v), nt = Q[z](0, M), U = ft[z](0, v), j = ft[z](0, M), q = U - N, ot = j - nt, tt = { x: N, y: nt, x2: U, y2: j, width: q, height: ot, cx: N + q / 2, cy: nt + ot / 2 };
            return h.bbox = Kt(tt), tt;
          }, Jt = function(c) {
            var h = Kt(c);
            return h.toString = l._path2string, h;
          }, Rn = l._pathToRelative = function(c) {
            var h = oe(c);
            if (h.rel) return Jt(h.rel);
            l.is(c, ut) && l.is(c && c[0], ut) || (c = l.parsePathString(c));
            var u = [], p = 0, m = 0, v = 0, M = 0, $ = 0;
            c[0][0] == "M" && (v = p = c[0][1], M = m = c[0][2], $++, u.push(["M", p, m]));
            for (var S = $, L = c.length; S < L; S++) {
              var N = u[S] = [], nt = c[S];
              if (nt[0] != X.call(nt[0])) switch (N[0] = X.call(nt[0]), N[0]) {
                case "a":
                  N[1] = nt[1], N[2] = nt[2], N[3] = nt[3], N[4] = nt[4], N[5] = nt[5], N[6] = +(nt[6] - p).toFixed(3), N[7] = +(nt[7] - m).toFixed(3);
                  break;
                case "v":
                  N[1] = +(nt[1] - m).toFixed(3);
                  break;
                case "m":
                  v = nt[1], M = nt[2];
                default:
                  for (var U = 1, j = nt.length; U < j; U++) N[U] = +(nt[U] - (U % 2 ? p : m)).toFixed(3);
              }
              else {
                N = u[S] = [], nt[0] == "m" && (v = nt[1] + p, M = nt[2] + m);
                for (var q = 0, ot = nt.length; q < ot; q++) u[S][q] = nt[q];
              }
              var tt = u[S].length;
              switch (u[S][0]) {
                case "z":
                  p = v, m = M;
                  break;
                case "h":
                  p += +u[S][tt - 1];
                  break;
                case "v":
                  m += +u[S][tt - 1];
                  break;
                default:
                  p += +u[S][tt - 2], m += +u[S][tt - 1];
              }
            }
            return u.toString = l._path2string, h.rel = Jt(u), u;
          }, ci = l._pathToAbsolute = function(c) {
            var h = oe(c);
            if (h.abs) return Jt(h.abs);
            if (l.is(c, ut) && l.is(c && c[0], ut) || (c = l.parsePathString(c)), !c || !c.length) return [["M", 0, 0]];
            var u = [], p = 0, m = 0, v = 0, M = 0, $ = 0;
            c[0][0] == "M" && (v = p = +c[0][1], M = m = +c[0][2], $++, u[0] = ["M", p, m]);
            for (var S, L, N = c.length == 3 && c[0][0] == "M" && c[1][0].toUpperCase() == "R" && c[2][0].toUpperCase() == "Z", nt = $, U = c.length; nt < U; nt++) {
              if (u.push(S = []), (L = c[nt])[0] != I.call(L[0])) switch (S[0] = I.call(L[0]), S[0]) {
                case "A":
                  S[1] = L[1], S[2] = L[2], S[3] = L[3], S[4] = L[4], S[5] = L[5], S[6] = +(L[6] + p), S[7] = +(L[7] + m);
                  break;
                case "V":
                  S[1] = +L[1] + m;
                  break;
                case "H":
                  S[1] = +L[1] + p;
                  break;
                case "R":
                  for (var j = [p, m][O](L.slice(1)), q = 2, ot = j.length; q < ot; q++) j[q] = +j[q] + p, j[++q] = +j[q] + m;
                  u.pop(), u = u[O](ri(j, N));
                  break;
                case "M":
                  v = +L[1] + p, M = +L[2] + m;
                default:
                  for (q = 1, ot = L.length; q < ot; q++) S[q] = +L[q] + (q % 2 ? p : m);
              }
              else if (L[0] == "R") j = [p, m][O](L.slice(1)), u.pop(), u = u[O](ri(j, N)), S = ["R"][O](L.slice(-2));
              else for (var tt = 0, V = L.length; tt < V; tt++) S[tt] = L[tt];
              switch (S[0]) {
                case "Z":
                  p = v, m = M;
                  break;
                case "H":
                  p = S[1];
                  break;
                case "V":
                  m = S[1];
                  break;
                case "M":
                  v = S[S.length - 2], M = S[S.length - 1];
                default:
                  p = S[S.length - 2], m = S[S.length - 1];
              }
            }
            return u.toString = l._path2string, h.abs = Jt(u), u;
          }, hi = function(c, h, u, p) {
            return [c, h, u, p, u, p];
          }, Oe = function(c, h, u, p, m, v) {
            return [1 / 3 * c + 2 / 3 * u, 1 / 3 * h + 2 / 3 * p, 1 / 3 * m + 2 / 3 * u, 1 / 3 * v + 2 / 3 * p, m, v];
          }, es = function(c, h, u, p, m, v, M, $, S, L) {
            var N, nt = 120 * ht / 180, U = ht / 180 * (+m || 0), j = [], q = Yt(function(eo, io, rs) {
              return { x: eo * st.cos(rs) - io * st.sin(rs), y: eo * st.sin(rs) + io * st.cos(rs) };
            });
            if (L) xt = L[0], wt = L[1], at = L[2], vt = L[3];
            else {
              c = (N = q(c, h, -U)).x, h = N.y, $ = (N = q($, S, -U)).x, S = N.y;
              var ot = (c - $) / 2, tt = (h - S) / 2, V = ot * ot / (u * u) + tt * tt / (p * p);
              V > 1 && (u *= V = st.sqrt(V), p *= V);
              var pt = u * u, rt = p * p, lt = (v == M ? -1 : 1) * st.sqrt(G((pt * rt - pt * tt * tt - rt * ot * ot) / (pt * tt * tt + rt * ot * ot))), at = lt * u * tt / p + (c + $) / 2, vt = lt * -p * ot / u + (h + S) / 2, xt = st.asin(((h - vt) / p).toFixed(9)), wt = st.asin(((S - vt) / p).toFixed(9));
              (xt = c < at ? ht - xt : xt) < 0 && (xt = 2 * ht + xt), (wt = $ < at ? ht - wt : wt) < 0 && (wt = 2 * ht + wt), M && xt > wt && (xt -= 2 * ht), !M && wt > xt && (wt -= 2 * ht);
            }
            var ui = wt - xt;
            if (G(ui) > nt) {
              var Oi = wt, Zt = $, pe = S;
              wt = xt + nt * (M && wt > xt ? 1 : -1), $ = at + u * st.cos(wt), S = vt + p * st.sin(wt), j = es($, S, u, p, m, 0, M, Zt, pe, [wt, Oi, at, vt]);
            }
            ui = wt - xt;
            var fi = st.cos(xt), pi = st.sin(xt), ns = st.cos(wt), we = st.sin(wt), Ve = st.tan(ui / 4), os = 4 / 3 * u * Ve, Kn = 4 / 3 * p * Ve, Jn = [c, h], gi = [c + os * pi, h - Kn * fi], Zn = [$ + os * we, S - Kn * ns], Qn = [$, S];
            if (gi[0] = 2 * Jn[0] - gi[0], gi[1] = 2 * Jn[1] - gi[1], L) return [gi, Zn, Qn][O](j);
            for (var to = [], Be = 0, Ta = (j = [gi, Zn, Qn][O](j).join()[H](",")).length; Be < Ta; Be++) to[Be] = Be % 2 ? q(j[Be - 1], j[Be], U).y : q(j[Be], j[Be + 1], U).x;
            return to;
          }, je = function(c, h, u, p, m, v, M, $, S) {
            var L = 1 - S;
            return { x: K(L, 3) * c + 3 * K(L, 2) * S * u + 3 * L * S * S * m + K(S, 3) * M, y: K(L, 3) * h + 3 * K(L, 2) * S * p + 3 * L * S * S * v + K(S, 3) * $ };
          }, is = Yt(function(c, h, u, p, m, v, M, $) {
            var S, L = m - 2 * u + c - (M - 2 * m + u), N = 2 * (u - c) - 2 * (m - u), nt = c - u, U = (-N + st.sqrt(N * N - 4 * L * nt)) / 2 / L, j = (-N - st.sqrt(N * N - 4 * L * nt)) / 2 / L, q = [h, $], ot = [c, M];
            return G(U) > "1e12" && (U = 0.5), G(j) > "1e12" && (j = 0.5), U > 0 && U < 1 && (S = je(c, h, u, p, m, v, M, $, U), ot.push(S.x), q.push(S.y)), j > 0 && j < 1 && (S = je(c, h, u, p, m, v, M, $, j), ot.push(S.x), q.push(S.y)), L = v - 2 * p + h - ($ - 2 * v + p), nt = h - p, U = (-(N = 2 * (p - h) - 2 * (v - p)) + st.sqrt(N * N - 4 * L * nt)) / 2 / L, j = (-N - st.sqrt(N * N - 4 * L * nt)) / 2 / L, G(U) > "1e12" && (U = 0.5), G(j) > "1e12" && (j = 0.5), U > 0 && U < 1 && (S = je(c, h, u, p, m, v, M, $, U), ot.push(S.x), q.push(S.y)), j > 0 && j < 1 && (S = je(c, h, u, p, m, v, M, $, j), ot.push(S.x), q.push(S.y)), { min: { x: Q[z](0, ot), y: Q[z](0, q) }, max: { x: ft[z](0, ot), y: ft[z](0, q) } };
          }), Pi = l._path2curve = Yt(function(c, h) {
            var u = !h && oe(c);
            if (!h && u.curve) return Jt(u.curve);
            for (var p = ci(c), m = h && ci(h), v = { x: 0, y: 0, bx: 0, by: 0, X: 0, Y: 0, qx: null, qy: null }, M = { x: 0, y: 0, bx: 0, by: 0, X: 0, Y: 0, qx: null, qy: null }, $ = function(lt, at, vt) {
              var xt, wt;
              if (!lt) return ["C", at.x, at.y, at.x, at.y, at.x, at.y];
              switch (!(lt[0] in { T: 1, Q: 1 }) && (at.qx = at.qy = null), lt[0]) {
                case "M":
                  at.X = lt[1], at.Y = lt[2];
                  break;
                case "A":
                  lt = ["C"][O](es[z](0, [at.x, at.y][O](lt.slice(1))));
                  break;
                case "S":
                  vt == "C" || vt == "S" ? (xt = 2 * at.x - at.bx, wt = 2 * at.y - at.by) : (xt = at.x, wt = at.y), lt = ["C", xt, wt][O](lt.slice(1));
                  break;
                case "T":
                  vt == "Q" || vt == "T" ? (at.qx = 2 * at.x - at.qx, at.qy = 2 * at.y - at.qy) : (at.qx = at.x, at.qy = at.y), lt = ["C"][O](Oe(at.x, at.y, at.qx, at.qy, lt[1], lt[2]));
                  break;
                case "Q":
                  at.qx = lt[1], at.qy = lt[2], lt = ["C"][O](Oe(at.x, at.y, lt[1], lt[2], lt[3], lt[4]));
                  break;
                case "L":
                  lt = ["C"][O](hi(at.x, at.y, lt[1], lt[2]));
                  break;
                case "H":
                  lt = ["C"][O](hi(at.x, at.y, lt[1], at.y));
                  break;
                case "V":
                  lt = ["C"][O](hi(at.x, at.y, at.x, lt[1]));
                  break;
                case "Z":
                  lt = ["C"][O](hi(at.x, at.y, at.X, at.Y));
              }
              return lt;
            }, S = function(lt, at) {
              if (lt[at].length > 7) {
                lt[at].shift();
                for (var vt = lt[at]; vt.length; ) N[at] = "A", m && (nt[at] = "A"), lt.splice(at++, 0, ["C"][O](vt.splice(0, 6)));
                lt.splice(at, 1), ot = ft(p.length, m && m.length || 0);
              }
            }, L = function(lt, at, vt, xt, wt) {
              lt && at && lt[wt][0] == "M" && at[wt][0] != "M" && (at.splice(wt, 0, ["M", xt.x, xt.y]), vt.bx = 0, vt.by = 0, vt.x = lt[wt][1], vt.y = lt[wt][2], ot = ft(p.length, m && m.length || 0));
            }, N = [], nt = [], U = "", j = "", q = 0, ot = ft(p.length, m && m.length || 0); q < ot; q++) {
              p[q] && (U = p[q][0]), U != "C" && (N[q] = U, q && (j = N[q - 1])), p[q] = $(p[q], v, j), N[q] != "A" && U == "C" && (N[q] = "C"), S(p, q), m && (m[q] && (U = m[q][0]), U != "C" && (nt[q] = U, q && (j = nt[q - 1])), m[q] = $(m[q], M, j), nt[q] != "A" && U == "C" && (nt[q] = "C"), S(m, q)), L(p, m, v, M, q), L(m, p, M, v, q);
              var tt = p[q], V = m && m[q], pt = tt.length, rt = m && V.length;
              v.x = tt[pt - 2], v.y = tt[pt - 1], v.bx = D(tt[pt - 4]) || v.x, v.by = D(tt[pt - 3]) || v.y, M.bx = m && (D(V[rt - 4]) || M.x), M.by = m && (D(V[rt - 3]) || M.y), M.x = m && V[rt - 2], M.y = m && V[rt - 1];
            }
            return m || (u.curve = Jt(p)), m ? [p, m] : p;
          }, null, Jt), ss = (l._parseDots = Yt(function(c) {
            for (var h = [], u = 0, p = c.length; u < p; u++) {
              var m = {}, v = c[u].match(/^([^:]*):?([\d\.]*)/);
              if (m.color = l.getRGB(v[1]), m.color.error) return null;
              m.opacity = m.color.opacity, m.color = m.color.hex, v[2] && (m.offset = v[2] + "%"), h.push(m);
            }
            for (u = 1, p = h.length - 1; u < p; u++) if (!h[u].offset) {
              for (var M = D(h[u - 1].offset || 0), $ = 0, S = u + 1; S < p; S++) if (h[S].offset) {
                $ = h[S].offset;
                break;
              }
              $ || ($ = 100, S = p);
              for (var L = (($ = D($)) - M) / (S - u + 1); u < S; u++) M += L, h[u].offset = M + "%";
            }
            return h;
          }), l._tear = function(c, h) {
            c == h.top && (h.top = c.prev), c == h.bottom && (h.bottom = c.next), c.next && (c.next.prev = c.prev), c.prev && (c.prev.next = c.next);
          }), ka = (l._tofront = function(c, h) {
            h.top !== c && (ss(c, h), c.next = null, c.prev = h.top, h.top.next = c, h.top = c);
          }, l._toback = function(c, h) {
            h.bottom !== c && (ss(c, h), c.next = h.bottom, c.prev = null, h.bottom.prev = c, h.bottom = c);
          }, l._insertafter = function(c, h, u) {
            ss(c, u), h == u.top && (u.top = c), h.next && (h.next.prev = c), c.next = h.next, c.prev = h, h.next = c;
          }, l._insertbefore = function(c, h, u) {
            ss(c, u), h == u.bottom && (u.bottom = c), h.prev && (h.prev.next = c), c.prev = h.prev, h.prev = c, c.next = h;
          }, l.toMatrix = function(c, h) {
            var u = Le(c), p = { _: { transform: R }, getBBox: function() {
              return u;
            } };
            return zn(p, h), p.matrix;
          }), zn = (l.transformPath = function(c, h) {
            return jt(c, ka(c, h));
          }, l._extractTransform = function(c, h) {
            if (h == null) return c._.transform;
            h = B(h).replace(/\.{3}|\u2026/g, c._.transform || R);
            var u, p, m = l.parseTransformString(h), v = 0, M = 1, $ = 1, S = c._, L = new Ne();
            if (S.transform = m || [], m) for (var N = 0, nt = m.length; N < nt; N++) {
              var U, j, q, ot, tt, V = m[N], pt = V.length, rt = B(V[0]).toLowerCase(), lt = V[0] != rt, at = lt ? L.invert() : 0;
              rt == "t" && pt == 3 ? lt ? (U = at.x(0, 0), j = at.y(0, 0), q = at.x(V[1], V[2]), ot = at.y(V[1], V[2]), L.translate(q - U, ot - j)) : L.translate(V[1], V[2]) : rt == "r" ? pt == 2 ? (tt = tt || c.getBBox(1), L.rotate(V[1], tt.x + tt.width / 2, tt.y + tt.height / 2), v += V[1]) : pt == 4 && (lt ? (q = at.x(V[2], V[3]), ot = at.y(V[2], V[3]), L.rotate(V[1], q, ot)) : L.rotate(V[1], V[2], V[3]), v += V[1]) : rt == "s" ? pt == 2 || pt == 3 ? (tt = tt || c.getBBox(1), L.scale(V[1], V[pt - 1], tt.x + tt.width / 2, tt.y + tt.height / 2), M *= V[1], $ *= V[pt - 1]) : pt == 5 && (lt ? (q = at.x(V[3], V[4]), ot = at.y(V[3], V[4]), L.scale(V[1], V[2], q, ot)) : L.scale(V[1], V[2], V[3], V[4]), M *= V[1], $ *= V[2]) : rt == "m" && pt == 7 && L.add(V[1], V[2], V[3], V[4], V[5], V[6]), S.dirtyT = 1, c.matrix = L;
            }
            c.matrix = L, S.sx = M, S.sy = $, S.deg = v, S.dx = u = L.e, S.dy = p = L.f, M == 1 && $ == 1 && !v && S.bbox ? (S.bbox.x += +u, S.bbox.y += +p) : S.dirtyT = 1;
          }), Fn = function(c) {
            var h = c[0];
            switch (h.toLowerCase()) {
              case "t":
                return [h, 0, 0];
              case "m":
                return [h, 1, 0, 0, 1, 0, 0];
              case "r":
                return c.length == 4 ? [h, 0, c[2], c[3]] : [h, 0];
              case "s":
                return c.length == 5 ? [h, 1, 1, c[3], c[4]] : c.length == 3 ? [h, 1, 1] : [h, 1];
            }
          }, $a = l._equaliseTransform = function(c, h) {
            h = B(h).replace(/\.{3}|\u2026/g, c), c = l.parseTransformString(c) || [], h = l.parseTransformString(h) || [];
            for (var u, p, m, v, M = ft(c.length, h.length), $ = [], S = [], L = 0; L < M; L++) {
              if (m = c[L] || Fn(h[L]), v = h[L] || Fn(m), m[0] != v[0] || m[0].toLowerCase() == "r" && (m[2] != v[2] || m[3] != v[3]) || m[0].toLowerCase() == "s" && (m[3] != v[3] || m[4] != v[4])) return;
              for ($[L] = [], S[L] = [], u = 0, p = ft(m.length, v.length); u < p; u++) u in m && ($[L][u] = m[u]), u in v && (S[L][u] = v[u]);
            }
            return { from: $, to: S };
          };
          function Ne(c, h, u, p, m, v) {
            c != null ? (this.a = +c, this.b = +h, this.c = +u, this.d = +p, this.e = +m, this.f = +v) : (this.a = 1, this.b = 0, this.c = 0, this.d = 1, this.e = 0, this.f = 0);
          }
          l._getContainer = function(c, h, u, p) {
            var m;
            if ((m = p != null || l.is(c, "object") ? c : C.doc.getElementById(c)) != null) return m.tagName ? h == null ? { container: m, width: m.style.pixelWidth || m.offsetWidth, height: m.style.pixelHeight || m.offsetHeight } : { container: m, width: h, height: u } : { container: 1, x: c, y: h, width: u, height: p };
          }, l.pathToRelative = Rn, l._engine = {}, l.path2curve = Pi, l.matrix = function(c, h, u, p, m, v) {
            return new Ne(c, h, u, p, m, v);
          }, (function(c) {
            function h(p) {
              return p[0] * p[0] + p[1] * p[1];
            }
            function u(p) {
              var m = st.sqrt(h(p));
              p[0] && (p[0] /= m), p[1] && (p[1] /= m);
            }
            c.add = function(p, m, v, M, $, S) {
              var L, N, nt, U, j = [[], [], []], q = [[this.a, this.c, this.e], [this.b, this.d, this.f], [0, 0, 1]], ot = [[p, v, $], [m, M, S], [0, 0, 1]];
              for (p && p instanceof Ne && (ot = [[p.a, p.c, p.e], [p.b, p.d, p.f], [0, 0, 1]]), L = 0; L < 3; L++) for (N = 0; N < 3; N++) {
                for (U = 0, nt = 0; nt < 3; nt++) U += q[L][nt] * ot[nt][N];
                j[L][N] = U;
              }
              this.a = j[0][0], this.b = j[1][0], this.c = j[0][1], this.d = j[1][1], this.e = j[0][2], this.f = j[1][2];
            }, c.invert = function() {
              var p = this, m = p.a * p.d - p.b * p.c;
              return new Ne(p.d / m, -p.b / m, -p.c / m, p.a / m, (p.c * p.f - p.d * p.e) / m, (p.b * p.e - p.a * p.f) / m);
            }, c.clone = function() {
              return new Ne(this.a, this.b, this.c, this.d, this.e, this.f);
            }, c.translate = function(p, m) {
              this.add(1, 0, 0, 1, p, m);
            }, c.scale = function(p, m, v, M) {
              m == null && (m = p), (v || M) && this.add(1, 0, 0, 1, v, M), this.add(p, 0, 0, m, 0, 0), (v || M) && this.add(1, 0, 0, 1, -v, -M);
            }, c.rotate = function(p, m, v) {
              p = l.rad(p), m = m || 0, v = v || 0;
              var M = +st.cos(p).toFixed(9), $ = +st.sin(p).toFixed(9);
              this.add(M, $, -$, M, m, v), this.add(1, 0, 0, 1, -m, -v);
            }, c.x = function(p, m) {
              return p * this.a + m * this.c + this.e;
            }, c.y = function(p, m) {
              return p * this.b + m * this.d + this.f;
            }, c.get = function(p) {
              return +this[B.fromCharCode(97 + p)].toFixed(4);
            }, c.toString = function() {
              return l.svg ? "matrix(" + [this.get(0), this.get(1), this.get(2), this.get(3), this.get(4), this.get(5)].join() + ")" : [this.get(0), this.get(2), this.get(1), this.get(3), 0, 0].join();
            }, c.toFilter = function() {
              return "progid:DXImageTransform.Microsoft.Matrix(M11=" + this.get(0) + ", M12=" + this.get(2) + ", M21=" + this.get(1) + ", M22=" + this.get(3) + ", Dx=" + this.get(4) + ", Dy=" + this.get(5) + ", sizingmethod='auto expand')";
            }, c.offset = function() {
              return [this.e.toFixed(4), this.f.toFixed(4)];
            }, c.split = function() {
              var p = {};
              p.dx = this.e, p.dy = this.f;
              var m = [[this.a, this.c], [this.b, this.d]];
              p.scalex = st.sqrt(h(m[0])), u(m[0]), p.shear = m[0][0] * m[1][0] + m[0][1] * m[1][1], m[1] = [m[1][0] - m[0][0] * p.shear, m[1][1] - m[0][1] * p.shear], p.scaley = st.sqrt(h(m[1])), u(m[1]), p.shear /= p.scaley;
              var v = -m[0][1], M = m[1][1];
              return M < 0 ? (p.rotate = l.deg(st.acos(M)), v < 0 && (p.rotate = 360 - p.rotate)) : p.rotate = l.deg(st.asin(v)), p.isSimple = !(+p.shear.toFixed(9) || p.scalex.toFixed(9) != p.scaley.toFixed(9) && p.rotate), p.isSuperSimple = !+p.shear.toFixed(9) && p.scalex.toFixed(9) == p.scaley.toFixed(9) && !p.rotate, p.noRotation = !+p.shear.toFixed(9) && !p.rotate, p;
            }, c.toTransformString = function(p) {
              var m = p || this[H]();
              return m.isSimple ? (m.scalex = +m.scalex.toFixed(4), m.scaley = +m.scaley.toFixed(4), m.rotate = +m.rotate.toFixed(4), (m.dx || m.dy ? "t" + [m.dx, m.dy] : R) + (m.scalex != 1 || m.scaley != 1 ? "s" + [m.scalex, m.scaley, 0, 0] : R) + (m.rotate ? "r" + [m.rotate, 0, 0] : R)) : "m" + [this.get(0), this.get(1), this.get(2), this.get(3), this.get(4), this.get(5)];
            };
          })(Ne.prototype);
          for (var Ma = function() {
            this.returnValue = !1;
          }, Sa = function() {
            return this.originalEvent.preventDefault();
          }, Ca = function() {
            this.cancelBubble = !0;
          }, Da = function() {
            return this.originalEvent.stopPropagation();
          }, Hn = function(c) {
            var h = C.doc.documentElement.scrollTop || C.doc.body.scrollTop, u = C.doc.documentElement.scrollLeft || C.doc.body.scrollLeft;
            return { x: c.clientX + u, y: c.clientY + h };
          }, Aa = C.doc.addEventListener ? function(c, h, u, p) {
            var m = function(M) {
              var $ = Hn(M);
              return u.call(p, M, $.x, $.y);
            };
            if (c.addEventListener(h, m, !1), W && ct[h]) {
              var v = function(M) {
                for (var $ = Hn(M), S = M, L = 0, N = M.targetTouches && M.targetTouches.length; L < N; L++) if (M.targetTouches[L].target == c) {
                  (M = M.targetTouches[L]).originalEvent = S, M.preventDefault = Sa, M.stopPropagation = Da;
                  break;
                }
                return u.call(p, M, $.x, $.y);
              };
              c.addEventListener(ct[h], v, !1);
            }
            return function() {
              return c.removeEventListener(h, m, !1), W && ct[h] && c.removeEventListener(ct[h], v, !1), !0;
            };
          } : C.doc.attachEvent ? function(c, h, u, p) {
            var m = function(v) {
              v = v || C.win.event;
              var M = C.doc.documentElement.scrollTop || C.doc.body.scrollTop, $ = C.doc.documentElement.scrollLeft || C.doc.body.scrollLeft, S = v.clientX + $, L = v.clientY + M;
              return v.preventDefault = v.preventDefault || Ma, v.stopPropagation = v.stopPropagation || Ca, u.call(p, v, S, L);
            };
            return c.attachEvent("on" + h, m), function() {
              return c.detachEvent("on" + h, m), !0;
            };
          } : void 0, Ee = [], Hs = function(c) {
            for (var h, u = c.clientX, p = c.clientY, m = C.doc.documentElement.scrollTop || C.doc.body.scrollTop, v = C.doc.documentElement.scrollLeft || C.doc.body.scrollLeft, M = Ee.length; M--; ) {
              if (h = Ee[M], W && c.touches) {
                for (var $, S = c.touches.length; S--; ) if (($ = c.touches[S]).identifier == h.el._drag.id) {
                  u = $.clientX, p = $.clientY, (c.originalEvent ? c.originalEvent : c).preventDefault();
                  break;
                }
              } else c.preventDefault();
              var L, N = h.el.node, nt = N.nextSibling, U = N.parentNode, j = N.style.display;
              C.win.opera && U.removeChild(N), N.style.display = "none", L = h.el.paper.getElementByPoint(u, p), N.style.display = j, C.win.opera && (nt ? U.insertBefore(N, nt) : U.appendChild(N)), L && a("raphael.drag.over." + h.el.id, h.el, L), u += v, p += m, a("raphael.drag.move." + h.el.id, h.move_scope || h.el, u - h.el._drag.x, p - h.el._drag.y, u, p, c);
            }
          }, js = function(c) {
            l.unmousemove(Hs).unmouseup(js);
            for (var h, u = Ee.length; u--; ) (h = Ee[u]).el._drag = {}, a("raphael.drag.end." + h.el.id, h.end_scope || h.start_scope || h.move_scope || h.el, c);
            Ee = [];
          }, Pt = l.el = {}, jn = it.length; jn--; ) (function(c) {
            l[c] = Pt[c] = function(h, u) {
              return l.is(h, "function") && (this.events = this.events || [], this.events.push({ name: c, f: h, unbind: Aa(this.shape || this.node || C.doc, c, h, u || this) })), this;
            }, l["un" + c] = Pt["un" + c] = function(h) {
              for (var u = this.events || [], p = u.length; p--; ) u[p].name != c || !l.is(h, "undefined") && u[p].f != h || (u[p].unbind(), u.splice(p, 1), !u.length && delete this.events);
              return this;
            };
          })(it[jn]);
          Pt.data = function(c, h) {
            var u = Tt[this.id] = Tt[this.id] || {};
            if (arguments.length == 0) return u;
            if (arguments.length == 1) {
              if (l.is(c, "object")) {
                for (var p in c) c[T](p) && this.data(p, c[p]);
                return this;
              }
              return a("raphael.data.get." + this.id, this, u[c], c), u[c];
            }
            return u[c] = h, a("raphael.data.set." + this.id, this, h, c), this;
          }, Pt.removeData = function(c) {
            return c == null ? delete Tt[this.id] : Tt[this.id] && delete Tt[this.id][c], this;
          }, Pt.getData = function() {
            return Kt(Tt[this.id] || {});
          }, Pt.hover = function(c, h, u, p) {
            return this.mouseover(c, u).mouseout(h, p || u);
          }, Pt.unhover = function(c, h) {
            return this.unmouseover(c).unmouseout(h);
          };
          var di = [];
          Pt.drag = function(c, h, u, p, m, v) {
            function M($) {
              ($.originalEvent || $).preventDefault();
              var S = $.clientX, L = $.clientY, N = C.doc.documentElement.scrollTop || C.doc.body.scrollTop, nt = C.doc.documentElement.scrollLeft || C.doc.body.scrollLeft;
              if (this._drag.id = $.identifier, W && $.touches) {
                for (var U, j = $.touches.length; j--; ) if (U = $.touches[j], this._drag.id = U.identifier, U.identifier == this._drag.id) {
                  S = U.clientX, L = U.clientY;
                  break;
                }
              }
              this._drag.x = S + nt, this._drag.y = L + N, !Ee.length && l.mousemove(Hs).mouseup(js), Ee.push({ el: this, move_scope: p, start_scope: m, end_scope: v }), h && a.on("raphael.drag.start." + this.id, h), c && a.on("raphael.drag.move." + this.id, c), u && a.on("raphael.drag.end." + this.id, u), a("raphael.drag.start." + this.id, m || p || this, this._drag.x, this._drag.y, $);
            }
            return this._drag = {}, di.push({ el: this, start: M }), this.mousedown(M), this;
          }, Pt.onDragOver = function(c) {
            c ? a.on("raphael.drag.over." + this.id, c) : a.unbind("raphael.drag.over." + this.id);
          }, Pt.undrag = function() {
            for (var c = di.length; c--; ) di[c].el == this && (this.unmousedown(di[c].start), di.splice(c, 1), a.unbind("raphael.drag.*." + this.id));
            !di.length && l.unmousemove(Hs).unmouseup(js), Ee = [];
          }, f.circle = function(c, h, u) {
            var p = l._engine.circle(this, c || 0, h || 0, u || 0);
            return this.__set__ && this.__set__.push(p), p;
          }, f.rect = function(c, h, u, p, m) {
            var v = l._engine.rect(this, c || 0, h || 0, u || 0, p || 0, m || 0);
            return this.__set__ && this.__set__.push(v), v;
          }, f.ellipse = function(c, h, u, p) {
            var m = l._engine.ellipse(this, c || 0, h || 0, u || 0, p || 0);
            return this.__set__ && this.__set__.push(m), m;
          }, f.path = function(c) {
            c && !l.is(c, "string") && !l.is(c[0], ut) && (c += R);
            var h = l._engine.path(l.format[z](l, arguments), this);
            return this.__set__ && this.__set__.push(h), h;
          }, f.image = function(c, h, u, p, m) {
            var v = l._engine.image(this, c || "about:blank", h || 0, u || 0, p || 0, m || 0);
            return this.__set__ && this.__set__.push(v), v;
          }, f.text = function(c, h, u) {
            var p = l._engine.text(this, c || 0, h || 0, B(u));
            return this.__set__ && this.__set__.push(p), p;
          }, f.set = function(c) {
            !l.is(c, "array") && (c = Array.prototype.splice.call(arguments, 0, arguments.length));
            var h = new Li(c);
            return this.__set__ && this.__set__.push(h), h.paper = this, h.type = "set", h;
          }, f.setStart = function(c) {
            this.__set__ = c || this.set();
          }, f.setFinish = function(c) {
            var h = this.__set__;
            return delete this.__set__, h;
          }, f.getSize = function() {
            var c = this.canvas.parentNode;
            return { width: c.offsetWidth, height: c.offsetHeight };
          }, f.setSize = function(c, h) {
            return l._engine.setSize.call(this, c, h);
          }, f.setViewBox = function(c, h, u, p, m) {
            return l._engine.setViewBox.call(this, c, h, u, p, m);
          }, f.top = f.bottom = null, f.raphael = l;
          function Nn() {
            return this.x + Y + this.y + Y + this.width + " × " + this.height;
          }
          f.getElementByPoint = function(c, h) {
            var u, p, m, v, M, $, S, L = this.canvas, N = C.doc.elementFromPoint(c, h);
            if (C.win.opera && N.tagName == "svg") {
              var nt = (p = (u = L).getBoundingClientRect(), m = u.ownerDocument, v = m.body, M = m.documentElement, $ = M.clientTop || v.clientTop || 0, S = M.clientLeft || v.clientLeft || 0, { y: p.top + (C.win.pageYOffset || M.scrollTop || v.scrollTop) - $, x: p.left + (C.win.pageXOffset || M.scrollLeft || v.scrollLeft) - S }), U = L.createSVGRect();
              U.x = c - nt.x, U.y = h - nt.y, U.width = U.height = 1;
              var j = L.getIntersectionList(U, null);
              j.length && (N = j[j.length - 1]);
            }
            if (!N) return null;
            for (; N.parentNode && N != L.parentNode && !N.raphael; ) N = N.parentNode;
            return N == this.canvas.parentNode && (N = L), N = N && N.raphael ? this.getById(N.raphaelid) : null;
          }, f.getElementsByBBox = function(c) {
            var h = this.set();
            return this.forEach(function(u) {
              l.isBBoxIntersect(u.getBBox(), c) && h.push(u);
            }), h;
          }, f.getById = function(c) {
            for (var h = this.bottom; h; ) {
              if (h.id == c) return h;
              h = h.next;
            }
            return null;
          }, f.forEach = function(c, h) {
            for (var u = this.bottom; u; ) {
              if (c.call(h, u) === !1) return this;
              u = u.next;
            }
            return this;
          }, f.getElementsByPoint = function(c, h) {
            var u = this.set();
            return this.forEach(function(p) {
              p.isPointInside(c, h) && u.push(p);
            }), u;
          }, Pt.isPointInside = function(c, h) {
            var u = this.realPath = zt[this.type](this);
            return this.attr("transform") && this.attr("transform").length && (u = l.transformPath(u, this.attr("transform"))), l.isPointInsidePath(u, c, h);
          }, Pt.getBBox = function(c) {
            if (this.removed) return {};
            var h = this._;
            return c ? (!h.dirty && h.bboxwt || (this.realPath = zt[this.type](this), h.bboxwt = Le(this.realPath), h.bboxwt.toString = Nn, h.dirty = 0), h.bboxwt) : ((h.dirty || h.dirtyT || !h.bbox) && (!h.dirty && this.realPath || (h.bboxwt = 0, this.realPath = zt[this.type](this)), h.bbox = Le(jt(this.realPath, this.matrix)), h.bbox.toString = Nn, h.dirty = h.dirtyT = 0), h.bbox);
          }, Pt.clone = function() {
            if (this.removed) return null;
            var c = this.paper[this.type]().attr(this.attr());
            return this.__set__ && this.__set__.push(c), c;
          }, Pt.glow = function(c) {
            if (this.type == "text") return null;
            var h = { width: ((c = c || {}).width || 10) + (+this.attr("stroke-width") || 1), fill: c.fill || !1, opacity: c.opacity == null ? 0.5 : c.opacity, offsetx: c.offsetx || 0, offsety: c.offsety || 0, color: c.color || "#000" }, u = h.width / 2, p = this.paper, m = p.set(), v = this.realPath || zt[this.type](this);
            v = this.matrix ? jt(v, this.matrix) : v;
            for (var M = 1; M < u + 1; M++) m.push(p.path(v).attr({ stroke: h.color, fill: h.fill ? h.color : "none", "stroke-linejoin": "round", "stroke-linecap": "round", "stroke-width": +(h.width / u * M).toFixed(3), opacity: +(h.opacity / u).toFixed(3) }));
            return m.insertBefore(this).translate(h.offsetx, h.offsety);
          };
          var Ns = function(c, h, u, p, m, v, M, $, S) {
            return S == null ? de(c, h, u, p, m, v, M, $) : l.findDotsAtSegment(c, h, u, p, m, v, M, $, (function(L, N, nt, U, j, q, ot, tt, V) {
              if (!(V < 0 || de(L, N, nt, U, j, q, ot, tt) < V)) {
                var pt, rt = 0.5, lt = 1 - rt;
                for (pt = de(L, N, nt, U, j, q, ot, tt, lt); G(pt - V) > 0.01; ) pt = de(L, N, nt, U, j, q, ot, tt, lt += (pt < V ? 1 : -1) * (rt /= 2));
                return lt;
              }
            })(c, h, u, p, m, v, M, $, S));
          }, Ws = function(c, h) {
            return function(u, p, m) {
              for (var v, M, $, S, L, N = "", nt = {}, U = 0, j = 0, q = (u = Pi(u)).length; j < q; j++) {
                if (($ = u[j])[0] == "M") v = +$[1], M = +$[2];
                else {
                  if (U + (S = Ns(v, M, $[1], $[2], $[3], $[4], $[5], $[6])) > p) {
                    if (h && !nt.start) {
                      if (N += ["C" + (L = Ns(v, M, $[1], $[2], $[3], $[4], $[5], $[6], p - U)).start.x, L.start.y, L.m.x, L.m.y, L.x, L.y], m) return N;
                      nt.start = N, N = ["M" + L.x, L.y + "C" + L.n.x, L.n.y, L.end.x, L.end.y, $[5], $[6]].join(), U += S, v = +$[5], M = +$[6];
                      continue;
                    }
                    if (!c && !h) return { x: (L = Ns(v, M, $[1], $[2], $[3], $[4], $[5], $[6], p - U)).x, y: L.y, alpha: L.alpha };
                  }
                  U += S, v = +$[5], M = +$[6];
                }
                N += $.shift() + $;
              }
              return nt.end = N, (L = c ? U : h ? nt : l.findDotsAtSegment(v, M, $[0], $[1], $[2], $[3], $[4], $[5], 1)).alpha && (L = { x: L.x, y: L.y, alpha: L.alpha }), L;
            };
          }, Wn = Ws(1), Vn = Ws(), Vs = Ws(0, 1);
          l.getTotalLength = Wn, l.getPointAtLength = Vn, l.getSubpath = function(c, h, u) {
            if (this.getTotalLength(c) - u < 1e-6) return Vs(c, h).end;
            var p = Vs(c, u, 1);
            return h ? Vs(p, h).end : p;
          }, Pt.getTotalLength = function() {
            var c = this.getPath();
            if (c) return this.node.getTotalLength ? this.node.getTotalLength() : Wn(c);
          }, Pt.getPointAtLength = function(c) {
            var h = this.getPath();
            if (h) return Vn(h, c);
          }, Pt.getPath = function() {
            var c, h = l._getPath[this.type];
            if (this.type != "text" && this.type != "set") return h && (c = h(this)), c;
          }, Pt.getSubpath = function(c, h) {
            var u = this.getPath();
            if (u) return l.getSubpath(u, c, h);
          };
          var se = l.easing_formulas = { linear: function(c) {
            return c;
          }, "<": function(c) {
            return K(c, 1.7);
          }, ">": function(c) {
            return K(c, 0.48);
          }, "<>": function(c) {
            var h = 0.48 - c / 1.04, u = st.sqrt(0.1734 + h * h), p = u - h, m = -u - h, v = K(G(p), 1 / 3) * (p < 0 ? -1 : 1) + K(G(m), 1 / 3) * (m < 0 ? -1 : 1) + 0.5;
            return 3 * (1 - v) * v * v + v * v * v;
          }, backIn: function(c) {
            var h = 1.70158;
            return c * c * ((h + 1) * c - h);
          }, backOut: function(c) {
            var h = 1.70158;
            return (c -= 1) * c * ((h + 1) * c + h) + 1;
          }, elastic: function(c) {
            return c == !!c ? c : K(2, -10 * c) * st.sin(2 * ht * (c - 0.075) / 0.3) + 1;
          }, bounce: function(c) {
            var h = 7.5625, u = 2.75;
            return c < 1 / u ? h * c * c : c < 2 / u ? h * (c -= 1.5 / u) * c + 0.75 : c < 2.5 / u ? h * (c -= 2.25 / u) * c + 0.9375 : h * (c -= 2.625 / u) * c + 0.984375;
          } };
          se.easeIn = se["ease-in"] = se["<"], se.easeOut = se["ease-out"] = se[">"], se.easeInOut = se["ease-in-out"] = se["<>"], se["back-in"] = se.backIn, se["back-out"] = se.backOut;
          var St = [], Yn = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(c) {
            setTimeout(c, 16);
          }, Ys = function() {
            for (var c = +/* @__PURE__ */ new Date(), h = 0; h < St.length; h++) {
              var u = St[h];
              if (!u.el.removed && !u.paused) {
                var p, m, v = c - u.start, M = u.ms, $ = u.easing, S = u.from, L = u.diff, N = u.to, nt = (u.t, u.el), U = {}, j = {};
                if (u.initstatus ? (v = (u.initstatus * u.anim.top - u.prev) / (u.percent - u.prev) * M, u.status = u.initstatus, delete u.initstatus, u.stop && St.splice(h--, 1)) : u.status = (u.prev + (u.percent - u.prev) * (v / M)) / u.anim.top, !(v < 0)) if (v < M) {
                  var q = $(v / M);
                  for (var ot in S) if (S[T](ot)) {
                    switch (F[ot]) {
                      case et:
                        p = +S[ot] + q * M * L[ot];
                        break;
                      case "colour":
                        p = "rgb(" + [Us(w(S[ot].r + q * M * L[ot].r)), Us(w(S[ot].g + q * M * L[ot].g)), Us(w(S[ot].b + q * M * L[ot].b))].join(",") + ")";
                        break;
                      case "path":
                        p = [];
                        for (var tt = 0, V = S[ot].length; tt < V; tt++) {
                          p[tt] = [S[ot][tt][0]];
                          for (var pt = 1, rt = S[ot][tt].length; pt < rt; pt++) p[tt][pt] = +S[ot][tt][pt] + q * M * L[ot][tt][pt];
                          p[tt] = p[tt].join(Y);
                        }
                        p = p.join(Y);
                        break;
                      case "transform":
                        if (L[ot].real) for (p = [], tt = 0, V = S[ot].length; tt < V; tt++) for (p[tt] = [S[ot][tt][0]], pt = 1, rt = S[ot][tt].length; pt < rt; pt++) p[tt][pt] = S[ot][tt][pt] + q * M * L[ot][tt][pt];
                        else {
                          var lt = function(vt) {
                            return +S[ot][vt] + q * M * L[ot][vt];
                          };
                          p = [["m", lt(0), lt(1), lt(2), lt(3), lt(4), lt(5)]];
                        }
                        break;
                      case "csv":
                        if (ot == "clip-rect") for (p = [], tt = 4; tt--; ) p[tt] = +S[ot][tt] + q * M * L[ot][tt];
                        break;
                      default:
                        var at = [][O](S[ot]);
                        for (p = [], tt = nt.paper.customAttributes[ot].length; tt--; ) p[tt] = +at[tt] + q * M * L[ot][tt];
                    }
                    U[ot] = p;
                  }
                  nt.attr(U), (function(vt, xt, wt) {
                    setTimeout(function() {
                      a("raphael.anim.frame." + vt, xt, wt);
                    });
                  })(nt.id, nt, u.anim);
                } else {
                  if ((function(vt, xt, wt) {
                    setTimeout(function() {
                      a("raphael.anim.frame." + xt.id, xt, wt), a("raphael.anim.finish." + xt.id, xt, wt), l.is(vt, "function") && vt.call(xt);
                    });
                  })(u.callback, nt, u.anim), nt.attr(N), St.splice(h--, 1), u.repeat > 1 && !u.next) {
                    for (m in N) N[T](m) && (j[m] = u.totalOrigin[m]);
                    u.el.attr(j), Ti(u.anim, u.el, u.anim.percents[0], null, u.totalOrigin, u.repeat - 1);
                  }
                  u.next && !u.stop && Ti(u.anim, u.el, u.next, null, u.totalOrigin, u.repeat);
                }
              }
            }
            St.length && Yn(Ys);
          }, Us = function(c) {
            return c > 255 ? 255 : c < 0 ? 0 : c;
          };
          function Pa(c, h, u, p, m, v) {
            var M = 3 * h, $ = 3 * (p - h) - M, S = 1 - M - $, L = 3 * u, N = 3 * (m - u) - L, nt = 1 - L - N;
            function U(j) {
              return ((S * j + $) * j + M) * j;
            }
            return (function(j, q) {
              var ot = (function(tt, V) {
                var pt, rt, lt, at, vt, xt;
                for (lt = tt, xt = 0; xt < 8; xt++) {
                  if (at = U(lt) - tt, G(at) < V) return lt;
                  if (G(vt = (3 * S * lt + 2 * $) * lt + M) < 1e-6) break;
                  lt -= at / vt;
                }
                if (rt = 1, (lt = tt) < (pt = 0)) return pt;
                if (lt > rt) return rt;
                for (; pt < rt; ) {
                  if (at = U(lt), G(at - tt) < V) return lt;
                  tt > at ? pt = lt : rt = lt, lt = (rt - pt) / 2 + pt;
                }
                return lt;
              })(j, q);
              return ((nt * ot + N) * ot + L) * ot;
            })(c, 1 / (200 * v));
          }
          function ve(c, h) {
            var u = [], p = {};
            if (this.ms = h, this.times = 1, c) {
              for (var m in c) c[T](m) && (p[D(m)] = c[m], u.push(D(m)));
              u.sort(Lt);
            }
            this.anim = p, this.top = u[u.length - 1], this.percents = u;
          }
          function Ti(c, h, u, p, m, v) {
            u = D(u);
            var M, $, S, L, N, nt, U = c.ms, j = {}, q = {}, ot = {};
            if (p) for (V = 0, pt = St.length; V < pt; V++) {
              var tt = St[V];
              if (tt.el.id == h.id && tt.anim == c) {
                tt.percent != u ? (St.splice(V, 1), S = 1) : $ = tt, h.attr(tt.totalOrigin);
                break;
              }
            }
            else p = +q;
            for (var V = 0, pt = c.percents.length; V < pt; V++) {
              if (c.percents[V] == u || c.percents[V] > p * c.top) {
                u = c.percents[V], N = c.percents[V - 1] || 0, U = U / c.top * (u - N), L = c.percents[V + 1], M = c.anim[u];
                break;
              }
              p && h.attr(c.anim[c.percents[V]]);
            }
            if (M) {
              if ($) $.initstatus = p, $.start = /* @__PURE__ */ new Date() - $.ms * p;
              else {
                for (var rt in M) if (M[T](rt) && (F[T](rt) || h.paper.customAttributes[T](rt))) switch (j[rt] = h.attr(rt), j[rt] == null && (j[rt] = Z[rt]), q[rt] = M[rt], F[rt]) {
                  case et:
                    ot[rt] = (q[rt] - j[rt]) / U;
                    break;
                  case "colour":
                    j[rt] = l.getRGB(j[rt]);
                    var lt = l.getRGB(q[rt]);
                    ot[rt] = { r: (lt.r - j[rt].r) / U, g: (lt.g - j[rt].g) / U, b: (lt.b - j[rt].b) / U };
                    break;
                  case "path":
                    var at = Pi(j[rt], q[rt]), vt = at[1];
                    for (j[rt] = at[0], ot[rt] = [], V = 0, pt = j[rt].length; V < pt; V++) {
                      ot[rt][V] = [0];
                      for (var xt = 1, wt = j[rt][V].length; xt < wt; xt++) ot[rt][V][xt] = (vt[V][xt] - j[rt][V][xt]) / U;
                    }
                    break;
                  case "transform":
                    var ui = h._, Oi = $a(ui[rt], q[rt]);
                    if (Oi) for (j[rt] = Oi.from, q[rt] = Oi.to, ot[rt] = [], ot[rt].real = !0, V = 0, pt = j[rt].length; V < pt; V++) for (ot[rt][V] = [j[rt][V][0]], xt = 1, wt = j[rt][V].length; xt < wt; xt++) ot[rt][V][xt] = (q[rt][V][xt] - j[rt][V][xt]) / U;
                    else {
                      var Zt = h.matrix || new Ne(), pe = { _: { transform: ui.transform }, getBBox: function() {
                        return h.getBBox(1);
                      } };
                      j[rt] = [Zt.a, Zt.b, Zt.c, Zt.d, Zt.e, Zt.f], zn(pe, q[rt]), q[rt] = pe._.transform, ot[rt] = [(pe.matrix.a - Zt.a) / U, (pe.matrix.b - Zt.b) / U, (pe.matrix.c - Zt.c) / U, (pe.matrix.d - Zt.d) / U, (pe.matrix.e - Zt.e) / U, (pe.matrix.f - Zt.f) / U];
                    }
                    break;
                  case "csv":
                    var fi = B(M[rt])[H](x), pi = B(j[rt])[H](x);
                    if (rt == "clip-rect") for (j[rt] = pi, ot[rt] = [], V = pi.length; V--; ) ot[rt][V] = (fi[V] - j[rt][V]) / U;
                    q[rt] = fi;
                    break;
                  default:
                    for (fi = [][O](M[rt]), pi = [][O](j[rt]), ot[rt] = [], V = h.paper.customAttributes[rt].length; V--; ) ot[rt][V] = ((fi[V] || 0) - (pi[V] || 0)) / U;
                }
                var ns = M.easing, we = l.easing_formulas[ns];
                if (!we) if ((we = B(ns).match(g)) && we.length == 5) {
                  var Ve = we;
                  we = function(os) {
                    return Pa(os, +Ve[1], +Ve[2], +Ve[3], +Ve[4], U);
                  };
                } else we = At;
                if (tt = { anim: c, percent: u, timestamp: nt = M.start || c.start || +/* @__PURE__ */ new Date(), start: nt + (c.del || 0), status: 0, initstatus: p || 0, stop: !1, ms: U, easing: we, from: j, diff: ot, to: q, el: h, callback: M.callback, prev: N, next: L, repeat: v || c.times, origin: h.attr(), totalOrigin: m }, St.push(tt), p && !$ && !S && (tt.stop = !0, tt.start = /* @__PURE__ */ new Date() - U * p, St.length == 1)) return Ys();
                S && (tt.start = /* @__PURE__ */ new Date() - tt.ms * p), St.length == 1 && Yn(Ys);
              }
              a("raphael.anim.start." + h.id, h, c);
            }
          }
          function Un(c) {
            for (var h = 0; h < St.length; h++) St[h].el.paper == c && St.splice(h--, 1);
          }
          Pt.animateWith = function(c, h, u, p, m, v) {
            if (this.removed) return v && v.call(this), this;
            var M = u instanceof ve ? u : l.animation(u, p, m, v);
            Ti(M, this, M.percents[0], null, this.attr());
            for (var $ = 0, S = St.length; $ < S; $++) if (St[$].anim == h && St[$].el == c) {
              St[S - 1].start = St[$].start;
              break;
            }
            return this;
          }, Pt.onAnimation = function(c) {
            return c ? a.on("raphael.anim.frame." + this.id, c) : a.unbind("raphael.anim.frame." + this.id), this;
          }, ve.prototype.delay = function(c) {
            var h = new ve(this.anim, this.ms);
            return h.times = this.times, h.del = +c || 0, h;
          }, ve.prototype.repeat = function(c) {
            var h = new ve(this.anim, this.ms);
            return h.del = this.del, h.times = st.floor(ft(c, 0)) || 1, h;
          }, l.animation = function(c, h, u, p) {
            if (c instanceof ve) return c;
            !l.is(u, "function") && u || (p = p || u || null, u = null), c = Object(c), h = +h || 0;
            var m, v, M = {};
            for (v in c) c[T](v) && D(v) != v && D(v) + "%" != v && (m = !0, M[v] = c[v]);
            if (m) return u && (M.easing = u), p && (M.callback = p), new ve({ 100: M }, h);
            if (p) {
              var $ = 0;
              for (var S in c) {
                var L = E(S);
                c[T](S) && L > $ && ($ = L);
              }
              !c[$ += "%"].callback && (c[$].callback = p);
            }
            return new ve(c, h);
          }, Pt.animate = function(c, h, u, p) {
            if (this.removed) return p && p.call(this), this;
            var m = c instanceof ve ? c : l.animation(c, h, u, p);
            return Ti(m, this, m.percents[0], null, this.attr()), this;
          }, Pt.setTime = function(c, h) {
            return c && h != null && this.status(c, Q(h, c.ms) / c.ms), this;
          }, Pt.status = function(c, h) {
            var u, p, m = [], v = 0;
            if (h != null) return Ti(c, this, -1, Q(h, 1)), this;
            for (u = St.length; v < u; v++) if ((p = St[v]).el.id == this.id && (!c || p.anim == c)) {
              if (c) return p.status;
              m.push({ anim: p.anim, status: p.status });
            }
            return c ? 0 : m;
          }, Pt.pause = function(c) {
            for (var h = 0; h < St.length; h++) St[h].el.id != this.id || c && St[h].anim != c || a("raphael.anim.pause." + this.id, this, St[h].anim) !== !1 && (St[h].paused = !0);
            return this;
          }, Pt.resume = function(c) {
            for (var h = 0; h < St.length; h++) if (St[h].el.id == this.id && (!c || St[h].anim == c)) {
              var u = St[h];
              a("raphael.anim.resume." + this.id, this, u.anim) !== !1 && (delete u.paused, this.status(u.anim, u.status));
            }
            return this;
          }, Pt.stop = function(c) {
            for (var h = 0; h < St.length; h++) St[h].el.id != this.id || c && St[h].anim != c || a("raphael.anim.stop." + this.id, this, St[h].anim) !== !1 && St.splice(h--, 1);
            return this;
          }, a.on("raphael.remove", Un), a.on("raphael.clear", Un), Pt.toString = function() {
            return "Raphaël’s object";
          };
          var Xn, Gn, We, qn, Li = function(c) {
            if (this.items = [], this.length = 0, this.type = "set", c) for (var h = 0, u = c.length; h < u; h++) !c[h] || c[h].constructor != Pt.constructor && c[h].constructor != Li || (this[this.items.length] = this.items[this.items.length] = c[h], this.length++);
          }, Ut = Li.prototype;
          for (var Xs in Ut.push = function() {
            for (var c, h, u = 0, p = arguments.length; u < p; u++) !(c = arguments[u]) || c.constructor != Pt.constructor && c.constructor != Li || (this[h = this.items.length] = this.items[h] = c, this.length++);
            return this;
          }, Ut.pop = function() {
            return this.length && delete this[this.length--], this.items.pop();
          }, Ut.forEach = function(c, h) {
            for (var u = 0, p = this.items.length; u < p; u++) if (c.call(h, this.items[u], u) === !1) return this;
            return this;
          }, Pt) Pt[T](Xs) && (Ut[Xs] = /* @__PURE__ */ (function(c) {
            return function() {
              var h = arguments;
              return this.forEach(function(u) {
                u[c][z](u, h);
              });
            };
          })(Xs));
          return Ut.attr = function(c, h) {
            if (c && l.is(c, ut) && l.is(c[0], "object")) for (var u = 0, p = c.length; u < p; u++) this.items[u].attr(c[u]);
            else for (var m = 0, v = this.items.length; m < v; m++) this.items[m].attr(c, h);
            return this;
          }, Ut.clear = function() {
            for (; this.length; ) this.pop();
          }, Ut.splice = function(c, h, u) {
            c = c < 0 ? ft(this.length + c, 0) : c, h = ft(0, Q(this.length - c, h));
            var p, m = [], v = [], M = [];
            for (p = 2; p < arguments.length; p++) M.push(arguments[p]);
            for (p = 0; p < h; p++) v.push(this[c + p]);
            for (; p < this.length - c; p++) m.push(this[c + p]);
            var $ = M.length;
            for (p = 0; p < $ + m.length; p++) this.items[c + p] = this[c + p] = p < $ ? M[p] : m[p - $];
            for (p = this.items.length = this.length -= h - $; this[p]; ) delete this[p++];
            return new Li(v);
          }, Ut.exclude = function(c) {
            for (var h = 0, u = this.length; h < u; h++) if (this[h] == c) return this.splice(h, 1), !0;
          }, Ut.animate = function(c, h, u, p) {
            (l.is(u, "function") || !u) && (p = u || null);
            var m, v, M = this.items.length, $ = M, S = this;
            if (!M) return this;
            p && (v = function() {
              !--M && p.call(S);
            }), u = l.is(u, "string") ? u : v;
            var L = l.animation(c, h, u, v);
            for (m = this.items[--$].animate(L); $--; ) this.items[$] && !this.items[$].removed && this.items[$].animateWith(m, L, L), this.items[$] && !this.items[$].removed || M--;
            return this;
          }, Ut.insertAfter = function(c) {
            for (var h = this.items.length; h--; ) this.items[h].insertAfter(c);
            return this;
          }, Ut.getBBox = function() {
            for (var c = [], h = [], u = [], p = [], m = this.items.length; m--; ) if (!this.items[m].removed) {
              var v = this.items[m].getBBox();
              c.push(v.x), h.push(v.y), u.push(v.x + v.width), p.push(v.y + v.height);
            }
            return { x: c = Q[z](0, c), y: h = Q[z](0, h), x2: u = ft[z](0, u), y2: p = ft[z](0, p), width: u - c, height: p - h };
          }, Ut.clone = function(c) {
            c = this.paper.set();
            for (var h = 0, u = this.items.length; h < u; h++) c.push(this.items[h].clone());
            return c;
          }, Ut.toString = function() {
            return "Raphaël‘s set";
          }, Ut.glow = function(c) {
            var h = this.paper.set();
            return this.forEach(function(u, p) {
              var m = u.glow(c);
              m?.forEach(function(v, M) {
                h.push(v);
              });
            }), h;
          }, Ut.isPointInside = function(c, h) {
            var u = !1;
            return this.forEach(function(p) {
              if (p.isPointInside(c, h)) return u = !0, !1;
            }), u;
          }, l.registerFont = function(c) {
            if (!c.face) return c;
            this.fonts = this.fonts || {};
            var h = { w: c.w, face: {}, glyphs: {} }, u = c.face["font-family"];
            for (var p in c.face) c.face[T](p) && (h.face[p] = c.face[p]);
            if (this.fonts[u] ? this.fonts[u].push(h) : this.fonts[u] = [h], !c.svg) {
              for (var m in h.face["units-per-em"] = E(c.face["units-per-em"], 10), c.glyphs) if (c.glyphs[T](m)) {
                var v = c.glyphs[m];
                if (h.glyphs[m] = { w: v.w, k: {}, d: v.d && "M" + v.d.replace(/[mlcxtrv]/g, function($) {
                  return { l: "L", c: "C", x: "z", t: "m", r: "l", v: "c" }[$] || "M";
                }) + "z" }, v.k) for (var M in v.k) v[T](M) && (h.glyphs[m].k[M] = v.k[M]);
              }
            }
            return c;
          }, f.getFont = function(c, h, u, p) {
            if (p = p || "normal", u = u || "normal", h = +h || { normal: 400, bold: 700, lighter: 300, bolder: 800 }[h] || 400, l.fonts) {
              var m, v = l.fonts[c];
              if (!v) {
                var M = new RegExp("(^|\\s)" + c.replace(/[^\w\d\s+!~.:_-]/g, R) + "(\\s|$)", "i");
                for (var $ in l.fonts) if (l.fonts[T]($) && M.test($)) {
                  v = l.fonts[$];
                  break;
                }
              }
              if (v) for (var S = 0, L = v.length; S < L && ((m = v[S]).face["font-weight"] != h || m.face["font-style"] != u && m.face["font-style"] || m.face["font-stretch"] != p); S++) ;
              return m;
            }
          }, f.print = function(c, h, u, p, m, v, M, $) {
            v = v || "middle", M = ft(Q(M || 0, 1), -1), $ = ft(Q($ || 1, 3), 1);
            var S, L = B(u)[H](R), N = 0, nt = 0, U = R;
            if (l.is(p, "string") && (p = this.getFont(p)), p) {
              S = (m || 16) / p.face["units-per-em"];
              for (var j = p.face.bbox[H](x), q = +j[0], ot = j[3] - j[1], tt = 0, V = +j[1] + (v == "baseline" ? ot + +p.face.descent : ot / 2), pt = 0, rt = L.length; pt < rt; pt++) {
                if (L[pt] == `
`) N = 0, at = 0, nt = 0, tt += ot * $;
                else {
                  var lt = nt && p.glyphs[L[pt - 1]] || {}, at = p.glyphs[L[pt]];
                  N += nt ? (lt.w || p.w) + (lt.k && lt.k[L[pt]] || 0) + p.w * M : 0, nt = 1;
                }
                at && at.d && (U += l.transformPath(at.d, ["t", N * S, tt * S, "s", S, S, q, V, "t", (c - q) / S, (h - V) / S]));
              }
            }
            return this.path(U).attr({ fill: "#000", stroke: "none" });
          }, f.add = function(c) {
            if (l.is(c, "array")) for (var h, u = this.set(), p = 0, m = c.length; p < m; p++) h = c[p] || {}, b[T](h.type) && u.push(this[h.type]().attr(h));
            return u;
          }, l.format = function(c, h) {
            var u = l.is(h, ut) ? [0][O](h) : arguments;
            return c && l.is(c, "string") && u.length - 1 && (c = c.replace(k, function(p, m) {
              return u[++m] == null ? R : u[m];
            })), c || R;
          }, l.fullfill = (Xn = /\{([^\}]+)\}/g, Gn = /(?:(?:^|\.)(.+?)(?=\[|\.|$|\()|\[('|")(.+?)\2\])(\(\))?/g, function(c, h) {
            return String(c).replace(Xn, function(u, p) {
              return (function(m, v, M) {
                var $ = M;
                return v.replace(Gn, function(S, L, N, nt, U) {
                  L = L || nt, $ && (L in $ && ($ = $[L]), typeof $ == "function" && U && ($ = $()));
                }), $ = ($ == null || $ == M ? m : $) + "";
              })(u, p, h);
            });
          }), l.ninja = function() {
            if (A.was) C.win.Raphael = A.is;
            else {
              window.Raphael = void 0;
              try {
                delete window.Raphael;
              } catch {
              }
            }
            return l;
          }, l.st = Ut, a.on("raphael.DOMload", function() {
            d = !0;
          }), (We = document).readyState == null && We.addEventListener && (We.addEventListener("DOMContentLoaded", qn = function() {
            We.removeEventListener("DOMContentLoaded", qn, !1), We.readyState = "complete";
          }, !1), We.readyState = "loading"), (function c() {
            /in/.test(We.readyState) ? setTimeout(c, 9) : l.eve("raphael.DOMload");
          })(), l;
        }).apply(s, o)) === void 0 || (e.exports = r);
      }, function(e, s, n) {
        var o, r;
        o = [n(0), n(3), n(4)], (r = (function(a) {
          return a;
        }).apply(s, o)) === void 0 || (e.exports = r);
      }, function(e, s, n) {
        var o, r, a, l, d, f, x, b, k, T, C, A, P, z;
        l = "hasOwnProperty", d = /[\.\/]/, f = /\s*,\s*/, x = function(O, W) {
          return O - W;
        }, b = { n: {} }, k = function() {
          for (var O = 0, W = this.length; O < W; O++) if (this[O] !== void 0) return this[O];
        }, T = function() {
          for (var O = this.length; --O; ) if (this[O] !== void 0) return this[O];
        }, C = Object.prototype.toString, A = String, P = Array.isArray || function(O) {
          return O instanceof Array || C.call(O) == "[object Array]";
        }, (z = function(O, W) {
          var R, Y = a, B = Array.prototype.slice.call(arguments, 2), H = z.listeners(O), it = 0, ct = [], X = {}, st = [], ft = r;
          st.firstDefined = k, st.lastDefined = T, r = O, a = 0;
          for (var Q = 0, G = H.length; Q < G; Q++) "zIndex" in H[Q] && (ct.push(H[Q].zIndex), H[Q].zIndex < 0 && (X[H[Q].zIndex] = H[Q]));
          for (ct.sort(x); ct[it] < 0; ) if (R = X[ct[it++]], st.push(R.apply(W, B)), a) return a = Y, st;
          for (Q = 0; Q < G; Q++) if ("zIndex" in (R = H[Q])) if (R.zIndex == ct[it]) {
            if (st.push(R.apply(W, B)), a) break;
            do
              if ((R = X[ct[++it]]) && st.push(R.apply(W, B)), a) break;
            while (R);
          } else X[R.zIndex] = R;
          else if (st.push(R.apply(W, B)), a) break;
          return a = Y, r = ft, st;
        })._events = b, z.listeners = function(O) {
          var W, R, Y, B, H, it, ct, X, st = P(O) ? O : O.split(d), ft = b, Q = [ft], G = [];
          for (B = 0, H = st.length; B < H; B++) {
            for (X = [], it = 0, ct = Q.length; it < ct; it++) for (R = [(ft = Q[it].n)[st[B]], ft["*"]], Y = 2; Y--; ) (W = R[Y]) && (X.push(W), G = G.concat(W.f || []));
            Q = X;
          }
          return G;
        }, z.separator = function(O) {
          O ? (O = "[" + (O = A(O).replace(/(?=[\.\^\]\[\-])/g, "\\")) + "]", d = new RegExp(O)) : d = /[\.\/]/;
        }, z.on = function(O, W) {
          if (typeof W != "function") return function() {
          };
          for (var R = P(O) ? P(O[0]) ? O : [O] : A(O).split(f), Y = 0, B = R.length; Y < B; Y++) (function(H) {
            for (var it, ct = P(H) ? H : A(H).split(d), X = b, st = 0, ft = ct.length; st < ft; st++) X = (X = X.n).hasOwnProperty(ct[st]) && X[ct[st]] || (X[ct[st]] = { n: {} });
            for (X.f = X.f || [], st = 0, ft = X.f.length; st < ft; st++) if (X.f[st] == W) {
              it = !0;
              break;
            }
            !it && X.f.push(W);
          })(R[Y]);
          return function(H) {
            +H == +H && (W.zIndex = +H);
          };
        }, z.f = function(O) {
          var W = [].slice.call(arguments, 1);
          return function() {
            z.apply(null, [O, null].concat(W).concat([].slice.call(arguments, 0)));
          };
        }, z.stop = function() {
          a = 1;
        }, z.nt = function(O) {
          var W = P(r) ? r.join(".") : r;
          return O ? new RegExp("(?:\\.|\\/|^)" + O + "(?:\\.|\\/|$)").test(W) : W;
        }, z.nts = function() {
          return P(r) ? r : r.split(d);
        }, z.off = z.unbind = function(O, W) {
          if (O) {
            var R = P(O) ? P(O[0]) ? O : [O] : A(O).split(f);
            if (R.length > 1) for (var Y = 0, B = R.length; Y < B; Y++) z.off(R[Y], W);
            else {
              R = P(O) ? O : A(O).split(d);
              var H, it, ct, X, st, ft = [b];
              for (Y = 0, B = R.length; Y < B; Y++) for (X = 0; X < ft.length; X += ct.length - 2) {
                if (ct = [X, 1], H = ft[X].n, R[Y] != "*") H[R[Y]] && ct.push(H[R[Y]]);
                else for (it in H) H[l](it) && ct.push(H[it]);
                ft.splice.apply(ft, ct);
              }
              for (Y = 0, B = ft.length; Y < B; Y++) for (H = ft[Y]; H.n; ) {
                if (W) {
                  if (H.f) {
                    for (X = 0, st = H.f.length; X < st; X++) if (H.f[X] == W) {
                      H.f.splice(X, 1);
                      break;
                    }
                    !H.f.length && delete H.f;
                  }
                  for (it in H.n) if (H.n[l](it) && H.n[it].f) {
                    var Q = H.n[it].f;
                    for (X = 0, st = Q.length; X < st; X++) if (Q[X] == W) {
                      Q.splice(X, 1);
                      break;
                    }
                    !Q.length && delete H.n[it].f;
                  }
                } else for (it in delete H.f, H.n) H.n[l](it) && H.n[it].f && delete H.n[it].f;
                H = H.n;
              }
            }
          } else z._events = b = { n: {} };
        }, z.once = function(O, W) {
          var R = function() {
            return z.off(O, R), W.apply(this, arguments);
          };
          return z.on(O, R);
        }, z.version = "0.5.0", z.toString = function() {
          return "You are running Eve 0.5.0";
        }, e.exports ? e.exports = z : (o = (function() {
          return z;
        }).apply(s, [])) === void 0 || (e.exports = o);
      }, function(e, s, n) {
        var o, r;
        o = [n(0)], (r = (function(a) {
          if (!a || a.svg) {
            var l = "hasOwnProperty", d = String, f = parseFloat, x = parseInt, b = Math, k = b.max, T = b.abs, C = b.pow, A = /[, ]+/, P = a.eve, z = "", O = " ", W = "http://www.w3.org/1999/xlink", R = { block: "M5,0 0,2.5 5,5z", classic: "M5,0 0,2.5 5,5 3.5,3 3.5,2z", diamond: "M2.5,0 5,2.5 2.5,5 0,2.5z", open: "M6,1 1,3.5 6,6", oval: "M2.5,0A2.5,2.5,0,0,1,2.5,5 2.5,2.5,0,0,1,2.5,0z" }, Y = {};
            a.toString = function() {
              return `Your browser supports SVG.
You are running Raphaël ` + this.version;
            };
            var B = function(_, y) {
              if (y) for (var g in typeof _ == "string" && (_ = B(_)), y) y[l](g) && (g.substring(0, 6) == "xlink:" ? _.setAttributeNS(W, g.substring(6), d(y[g])) : _.setAttribute(g, d(y[g])));
              else (_ = a._g.doc.createElementNS("http://www.w3.org/2000/svg", _)).style && (_.style.webkitTapHighlightColor = "rgba(0,0,0,0)");
              return _;
            }, H = function(_, y) {
              var g = "linear", w = _.id + y, D = 0.5, E = 0.5, I = _.node, Z = _.paper, F = I.style, J = a._g.doc.getElementById(w);
              if (!J) {
                if (y = (y = d(y).replace(a._radial_gradient, function(Lt, At, bt) {
                  if (g = "radial", At && bt) {
                    D = f(At);
                    var Ft = 2 * ((E = f(bt)) > 0.5) - 1;
                    C(D - 0.5, 2) + C(E - 0.5, 2) > 0.25 && (E = b.sqrt(0.25 - C(D - 0.5, 2)) * Ft + 0.5) && E != 0.5 && (E = E.toFixed(5) - 1e-5 * Ft);
                  }
                  return z;
                })).split(/\s*\-\s*/), g == "linear") {
                  var dt = y.shift();
                  if (dt = -f(dt), isNaN(dt)) return null;
                  var gt = [0, 0, b.cos(a.rad(dt)), b.sin(a.rad(dt))], _t = 1 / (k(T(gt[2]), T(gt[3])) || 1);
                  gt[2] *= _t, gt[3] *= _t, gt[2] < 0 && (gt[0] = -gt[2], gt[2] = 0), gt[3] < 0 && (gt[1] = -gt[3], gt[3] = 0);
                }
                var Mt = a._parseDots(y);
                if (!Mt) return null;
                if (w = w.replace(/[\(\)\s,\xb0#]/g, "_"), _.gradient && w != _.gradient.id && (Z.defs.removeChild(_.gradient), delete _.gradient), !_.gradient) {
                  J = B(g + "Gradient", { id: w }), _.gradient = J, B(J, g == "radial" ? { fx: D, fy: E } : { x1: gt[0], y1: gt[1], x2: gt[2], y2: gt[3], gradientTransform: _.matrix.invert() }), Z.defs.appendChild(J);
                  for (var $t = 0, Tt = Mt.length; $t < Tt; $t++) J.appendChild(B("stop", { offset: Mt[$t].offset ? Mt[$t].offset : $t ? "100%" : "0%", "stop-color": Mt[$t].color || "#fff", "stop-opacity": isFinite(Mt[$t].opacity) ? Mt[$t].opacity : 1 }));
                }
              }
              return B(I, { fill: it(w), opacity: 1, "fill-opacity": 1 }), F.fill = z, F.opacity = 1, F.fillOpacity = 1, 1;
            }, it = function(_) {
              if ((y = document.documentMode) && (y === 9 || y === 10)) return "url('#" + _ + "')";
              var y, g = document.location;
              return "url('" + (g.protocol + "//" + g.host + g.pathname + g.search) + "#" + _ + "')";
            }, ct = function(_) {
              var y = _.getBBox(1);
              B(_.pattern, { patternTransform: _.matrix.invert() + " translate(" + y.x + "," + y.y + ")" });
            }, X = function(_, y, g) {
              if (_.type == "path") {
                for (var w, D, E, I, Z, F = d(y).toLowerCase().split("-"), J = _.paper, dt = g ? "end" : "start", gt = _.node, _t = _.attrs, Mt = _t["stroke-width"], $t = F.length, Tt = "classic", Lt = 3, At = 3, bt = 5; $t--; ) switch (F[$t]) {
                  case "block":
                  case "classic":
                  case "oval":
                  case "diamond":
                  case "open":
                  case "none":
                    Tt = F[$t];
                    break;
                  case "wide":
                    At = 5;
                    break;
                  case "narrow":
                    At = 2;
                    break;
                  case "long":
                    Lt = 5;
                    break;
                  case "short":
                    Lt = 2;
                }
                if (Tt == "open" ? (Lt += 2, At += 2, bt += 2, E = 1, I = g ? 4 : 1, Z = { fill: "none", stroke: _t.stroke }) : (I = E = Lt / 2, Z = { fill: _t.stroke, stroke: "none" }), _._.arrows ? g ? (_._.arrows.endPath && Y[_._.arrows.endPath]--, _._.arrows.endMarker && Y[_._.arrows.endMarker]--) : (_._.arrows.startPath && Y[_._.arrows.startPath]--, _._.arrows.startMarker && Y[_._.arrows.startMarker]--) : _._.arrows = {}, Tt != "none") {
                  var Ft = "raphael-marker-" + Tt, zt = "raphael-marker-" + dt + Tt + Lt + At + "-obj" + _.id;
                  a._g.doc.getElementById(Ft) ? Y[Ft]++ : (J.defs.appendChild(B(B("path"), { "stroke-linecap": "round", d: R[Tt], id: Ft })), Y[Ft] = 1);
                  var jt, Ot = a._g.doc.getElementById(zt);
                  Ot ? (Y[zt]++, jt = Ot.getElementsByTagName("use")[0]) : (Ot = B(B("marker"), { id: zt, markerHeight: At, markerWidth: Lt, orient: "auto", refX: I, refY: At / 2 }), jt = B(B("use"), { "xlink:href": "#" + Ft, transform: (g ? "rotate(180 " + Lt / 2 + " " + At / 2 + ") " : z) + "scale(" + Lt / bt + "," + At / bt + ")", "stroke-width": (1 / ((Lt / bt + At / bt) / 2)).toFixed(4) }), Ot.appendChild(jt), J.defs.appendChild(Ot), Y[zt] = 1), B(jt, Z);
                  var ie = E * (Tt != "diamond" && Tt != "oval");
                  g ? (w = _._.arrows.startdx * Mt || 0, D = a.getTotalLength(_t.path) - ie * Mt) : (w = ie * Mt, D = a.getTotalLength(_t.path) - (_._.arrows.enddx * Mt || 0)), (Z = {})["marker-" + dt] = "url(#" + zt + ")", (D || w) && (Z.d = a.getSubpath(_t.path, w, D)), B(gt, Z), _._.arrows[dt + "Path"] = Ft, _._.arrows[dt + "Marker"] = zt, _._.arrows[dt + "dx"] = ie, _._.arrows[dt + "Type"] = Tt, _._.arrows[dt + "String"] = y;
                } else g ? (w = _._.arrows.startdx * Mt || 0, D = a.getTotalLength(_t.path) - w) : (w = 0, D = a.getTotalLength(_t.path) - (_._.arrows.enddx * Mt || 0)), _._.arrows[dt + "Path"] && B(gt, { d: a.getSubpath(_t.path, w, D) }), delete _._.arrows[dt + "Path"], delete _._.arrows[dt + "Marker"], delete _._.arrows[dt + "dx"], delete _._.arrows[dt + "Type"], delete _._.arrows[dt + "String"];
                for (Z in Y) if (Y[l](Z) && !Y[Z]) {
                  var Kt = a._g.doc.getElementById(Z);
                  Kt && Kt.parentNode.removeChild(Kt);
                }
              }
            }, st = { "-": [3, 1], ".": [1, 1], "-.": [3, 1, 1, 1], "-..": [3, 1, 1, 1, 1, 1], ". ": [1, 3], "- ": [4, 3], "--": [8, 3], "- .": [4, 3, 1, 3], "--.": [8, 3, 1, 3], "--..": [8, 3, 1, 3, 1, 3] }, ft = function(_, y, g) {
              if (y = st[d(y).toLowerCase()]) {
                for (var w = _.attrs["stroke-width"] || "1", D = { round: w, square: w, butt: 0 }[_.attrs["stroke-linecap"] || g["stroke-linecap"]] || 0, E = [], I = y.length; I--; ) E[I] = y[I] * w + (I % 2 ? 1 : -1) * D;
                B(_.node, { "stroke-dasharray": E.join(",") });
              } else B(_.node, { "stroke-dasharray": "none" });
            }, Q = function(_, y) {
              var g = _.node, w = _.attrs, D = g.style.visibility;
              for (var E in g.style.visibility = "hidden", y) if (y[l](E)) {
                if (!a._availableAttrs[l](E)) continue;
                var I = y[E];
                switch (w[E] = I, E) {
                  case "blur":
                    _.blur(I);
                    break;
                  case "title":
                    var Z = g.getElementsByTagName("title");
                    if (Z.length && (Z = Z[0])) Z.firstChild.nodeValue = I;
                    else {
                      Z = B("title");
                      var F = a._g.doc.createTextNode(I);
                      Z.appendChild(F), g.appendChild(Z);
                    }
                    break;
                  case "href":
                  case "target":
                    var J = g.parentNode;
                    if (J.tagName.toLowerCase() != "a") {
                      var dt = B("a");
                      J.insertBefore(dt, g), dt.appendChild(g), J = dt;
                    }
                    E == "target" ? J.setAttributeNS(W, "show", I == "blank" ? "new" : I) : J.setAttributeNS(W, E, I);
                    break;
                  case "cursor":
                    g.style.cursor = I;
                    break;
                  case "transform":
                    _.transform(I);
                    break;
                  case "arrow-start":
                    X(_, I);
                    break;
                  case "arrow-end":
                    X(_, I, 1);
                    break;
                  case "clip-rect":
                    var gt = d(I).split(A);
                    if (gt.length == 4) {
                      _.clip && _.clip.parentNode.parentNode.removeChild(_.clip.parentNode);
                      var _t = B("clipPath"), Mt = B("rect");
                      _t.id = a.createUUID(), B(Mt, { x: gt[0], y: gt[1], width: gt[2], height: gt[3] }), _t.appendChild(Mt), _.paper.defs.appendChild(_t), B(g, { "clip-path": "url(#" + _t.id + ")" }), _.clip = Mt;
                    }
                    if (!I) {
                      var $t = g.getAttribute("clip-path");
                      if ($t) {
                        var Tt = a._g.doc.getElementById($t.replace(/(^url\(#|\)$)/g, z));
                        Tt && Tt.parentNode.removeChild(Tt), B(g, { "clip-path": z }), delete _.clip;
                      }
                    }
                    break;
                  case "path":
                    _.type == "path" && (B(g, { d: I ? w.path = a._pathToAbsolute(I) : "M0,0" }), _._.dirty = 1, _._.arrows && ("startString" in _._.arrows && X(_, _._.arrows.startString), "endString" in _._.arrows && X(_, _._.arrows.endString, 1)));
                    break;
                  case "width":
                    if (g.setAttribute(E, I), _._.dirty = 1, !w.fx) break;
                    E = "x", I = w.x;
                  case "x":
                    w.fx && (I = -w.x - (w.width || 0));
                  case "rx":
                    if (E == "rx" && _.type == "rect") break;
                  case "cx":
                    g.setAttribute(E, I), _.pattern && ct(_), _._.dirty = 1;
                    break;
                  case "height":
                    if (g.setAttribute(E, I), _._.dirty = 1, !w.fy) break;
                    E = "y", I = w.y;
                  case "y":
                    w.fy && (I = -w.y - (w.height || 0));
                  case "ry":
                    if (E == "ry" && _.type == "rect") break;
                  case "cy":
                    g.setAttribute(E, I), _.pattern && ct(_), _._.dirty = 1;
                    break;
                  case "r":
                    _.type == "rect" ? B(g, { rx: I, ry: I }) : g.setAttribute(E, I), _._.dirty = 1;
                    break;
                  case "src":
                    _.type == "image" && g.setAttributeNS(W, "href", I);
                    break;
                  case "stroke-width":
                    _._.sx == 1 && _._.sy == 1 || (I /= k(T(_._.sx), T(_._.sy)) || 1), g.setAttribute(E, I), w["stroke-dasharray"] && ft(_, w["stroke-dasharray"], y), _._.arrows && ("startString" in _._.arrows && X(_, _._.arrows.startString), "endString" in _._.arrows && X(_, _._.arrows.endString, 1));
                    break;
                  case "stroke-dasharray":
                    ft(_, I, y);
                    break;
                  case "fill":
                    var Lt = d(I).match(a._ISURL);
                    if (Lt) {
                      _t = B("pattern");
                      var At = B("image");
                      _t.id = a.createUUID(), B(_t, { x: 0, y: 0, patternUnits: "userSpaceOnUse", height: 1, width: 1 }), B(At, { x: 0, y: 0, "xlink:href": Lt[1] }), _t.appendChild(At), (function(Ot) {
                        a._preload(Lt[1], function() {
                          var ie = this.offsetWidth, Kt = this.offsetHeight;
                          B(Ot, { width: ie, height: Kt }), B(At, { width: ie, height: Kt });
                        });
                      })(_t), _.paper.defs.appendChild(_t), B(g, { fill: "url(#" + _t.id + ")" }), _.pattern = _t, _.pattern && ct(_);
                      break;
                    }
                    var bt = a.getRGB(I);
                    if (bt.error) {
                      if ((_.type == "circle" || _.type == "ellipse" || d(I).charAt() != "r") && H(_, I)) {
                        if ("opacity" in w || "fill-opacity" in w) {
                          var Ft = a._g.doc.getElementById(g.getAttribute("fill").replace(/^url\(#|\)$/g, z));
                          if (Ft) {
                            var zt = Ft.getElementsByTagName("stop");
                            B(zt[zt.length - 1], { "stop-opacity": ("opacity" in w ? w.opacity : 1) * ("fill-opacity" in w ? w["fill-opacity"] : 1) });
                          }
                        }
                        w.gradient = I, w.fill = "none";
                        break;
                      }
                    } else delete y.gradient, delete w.gradient, !a.is(w.opacity, "undefined") && a.is(y.opacity, "undefined") && B(g, { opacity: w.opacity }), !a.is(w["fill-opacity"], "undefined") && a.is(y["fill-opacity"], "undefined") && B(g, { "fill-opacity": w["fill-opacity"] });
                    bt[l]("opacity") && B(g, { "fill-opacity": bt.opacity > 1 ? bt.opacity / 100 : bt.opacity });
                  case "stroke":
                    bt = a.getRGB(I), g.setAttribute(E, bt.hex), E == "stroke" && bt[l]("opacity") && B(g, { "stroke-opacity": bt.opacity > 1 ? bt.opacity / 100 : bt.opacity }), E == "stroke" && _._.arrows && ("startString" in _._.arrows && X(_, _._.arrows.startString), "endString" in _._.arrows && X(_, _._.arrows.endString, 1));
                    break;
                  case "gradient":
                    (_.type == "circle" || _.type == "ellipse" || d(I).charAt() != "r") && H(_, I);
                    break;
                  case "opacity":
                    w.gradient && !w[l]("stroke-opacity") && B(g, { "stroke-opacity": I > 1 ? I / 100 : I });
                  case "fill-opacity":
                    if (w.gradient) {
                      (Ft = a._g.doc.getElementById(g.getAttribute("fill").replace(/^url\(#|\)$/g, z))) && (zt = Ft.getElementsByTagName("stop"), B(zt[zt.length - 1], { "stop-opacity": I }));
                      break;
                    }
                  default:
                    E == "font-size" && (I = x(I, 10) + "px");
                    var jt = E.replace(/(\-.)/g, function(Ot) {
                      return Ot.substring(1).toUpperCase();
                    });
                    g.style[jt] = I, _._.dirty = 1, g.setAttribute(E, I);
                }
              }
              G(_, y), g.style.visibility = D;
            }, G = function(_, y) {
              if (_.type == "text" && (y[l]("text") || y[l]("font") || y[l]("font-size") || y[l]("x") || y[l]("y"))) {
                var g = _.attrs, w = _.node, D = w.firstChild ? x(a._g.doc.defaultView.getComputedStyle(w.firstChild, z).getPropertyValue("font-size"), 10) : 10;
                if (y[l]("text")) {
                  for (g.text = y.text; w.firstChild; ) w.removeChild(w.firstChild);
                  for (var E, I = d(y.text).split(`
`), Z = [], F = 0, J = I.length; F < J; F++) E = B("tspan"), F && B(E, { dy: 1.2 * D, x: g.x }), E.appendChild(a._g.doc.createTextNode(I[F])), w.appendChild(E), Z[F] = E;
                } else for (F = 0, J = (Z = w.getElementsByTagName("tspan")).length; F < J; F++) F ? B(Z[F], { dy: 1.2 * D, x: g.x }) : B(Z[0], { dy: 0 });
                B(w, { x: g.x, y: g.y }), _._.dirty = 1;
                var dt = _._getBBox(), gt = g.y - (dt.y + dt.height / 2);
                gt && a.is(gt, "finite") && B(Z[0], { dy: gt });
              }
            }, K = function(_) {
              return _.parentNode && _.parentNode.tagName.toLowerCase() === "a" ? _.parentNode : _;
            }, ht = function(_, y) {
              this[0] = this.node = _, _.raphael = !0, this.id = ("0000" + (Math.random() * Math.pow(36, 5) << 0).toString(36)).slice(-5), _.raphaelid = this.id, this.matrix = a.matrix(), this.realPath = null, this.paper = y, this.attrs = this.attrs || {}, this._ = { transform: [], sx: 1, sy: 1, deg: 0, dx: 0, dy: 0, dirty: 1 }, !y.bottom && (y.bottom = this), this.prev = y.top, y.top && (y.top.next = this), y.top = this, this.next = null;
            }, et = a.el;
            ht.prototype = et, et.constructor = ht, a._engine.path = function(_, y) {
              var g = B("path");
              y.canvas && y.canvas.appendChild(g);
              var w = new ht(g, y);
              return w.type = "path", Q(w, { fill: "none", stroke: "#000", path: _ }), w;
            }, et.rotate = function(_, y, g) {
              if (this.removed) return this;
              if ((_ = d(_).split(A)).length - 1 && (y = f(_[1]), g = f(_[2])), _ = f(_[0]), g == null && (y = g), y == null || g == null) {
                var w = this.getBBox(1);
                y = w.x + w.width / 2, g = w.y + w.height / 2;
              }
              return this.transform(this._.transform.concat([["r", _, y, g]])), this;
            }, et.scale = function(_, y, g, w) {
              if (this.removed) return this;
              if ((_ = d(_).split(A)).length - 1 && (y = f(_[1]), g = f(_[2]), w = f(_[3])), _ = f(_[0]), y == null && (y = _), w == null && (g = w), g == null || w == null) var D = this.getBBox(1);
              return g = g ?? D.x + D.width / 2, w = w ?? D.y + D.height / 2, this.transform(this._.transform.concat([["s", _, y, g, w]])), this;
            }, et.translate = function(_, y) {
              return this.removed ? this : ((_ = d(_).split(A)).length - 1 && (y = f(_[1])), _ = f(_[0]) || 0, y = +y || 0, this.transform(this._.transform.concat([["t", _, y]])), this);
            }, et.transform = function(_) {
              var y = this._;
              if (_ == null) return y.transform;
              if (a._extractTransform(this, _), this.clip && B(this.clip, { transform: this.matrix.invert() }), this.pattern && ct(this), this.node && B(this.node, { transform: this.matrix }), y.sx != 1 || y.sy != 1) {
                var g = this.attrs[l]("stroke-width") ? this.attrs["stroke-width"] : 1;
                this.attr({ "stroke-width": g });
              }
              return this;
            }, et.hide = function() {
              return this.removed || (this.node.style.display = "none"), this;
            }, et.show = function() {
              return this.removed || (this.node.style.display = ""), this;
            }, et.remove = function() {
              var _ = K(this.node);
              if (!this.removed && _.parentNode) {
                var y = this.paper;
                for (var g in y.__set__ && y.__set__.exclude(this), P.unbind("raphael.*.*." + this.id), this.gradient && y.defs.removeChild(this.gradient), a._tear(this, y), _.parentNode.removeChild(_), this.removeData(), this) this[g] = typeof this[g] == "function" ? a._removedFactory(g) : null;
                this.removed = !0;
              }
            }, et._getBBox = function() {
              if (this.node.style.display == "none") {
                this.show();
                var _ = !0;
              }
              var y, g = !1;
              this.paper.canvas.parentElement ? y = this.paper.canvas.parentElement.style : this.paper.canvas.parentNode && (y = this.paper.canvas.parentNode.style), y && y.display == "none" && (g = !0, y.display = "");
              var w = {};
              try {
                w = this.node.getBBox();
              } catch {
                w = { x: this.node.clientLeft, y: this.node.clientTop, width: this.node.clientWidth, height: this.node.clientHeight };
              } finally {
                w = w || {}, g && (y.display = "none");
              }
              return _ && this.hide(), w;
            }, et.attr = function(_, y) {
              if (this.removed) return this;
              if (_ == null) {
                var g = {};
                for (var w in this.attrs) this.attrs[l](w) && (g[w] = this.attrs[w]);
                return g.gradient && g.fill == "none" && (g.fill = g.gradient) && delete g.gradient, g.transform = this._.transform, g;
              }
              if (y == null && a.is(_, "string")) {
                if (_ == "fill" && this.attrs.fill == "none" && this.attrs.gradient) return this.attrs.gradient;
                if (_ == "transform") return this._.transform;
                for (var D = _.split(A), E = {}, I = 0, Z = D.length; I < Z; I++) (_ = D[I]) in this.attrs ? E[_] = this.attrs[_] : a.is(this.paper.customAttributes[_], "function") ? E[_] = this.paper.customAttributes[_].def : E[_] = a._availableAttrs[_];
                return Z - 1 ? E : E[D[0]];
              }
              if (y == null && a.is(_, "array")) {
                for (E = {}, I = 0, Z = _.length; I < Z; I++) E[_[I]] = this.attr(_[I]);
                return E;
              }
              if (y != null) {
                var F = {};
                F[_] = y;
              } else _ != null && a.is(_, "object") && (F = _);
              for (var J in F) P("raphael.attr." + J + "." + this.id, this, F[J]);
              for (J in this.paper.customAttributes) if (this.paper.customAttributes[l](J) && F[l](J) && a.is(this.paper.customAttributes[J], "function")) {
                var dt = this.paper.customAttributes[J].apply(this, [].concat(F[J]));
                for (var gt in this.attrs[J] = F[J], dt) dt[l](gt) && (F[gt] = dt[gt]);
              }
              return Q(this, F), this;
            }, et.toFront = function() {
              if (this.removed) return this;
              var _ = K(this.node);
              _.parentNode.appendChild(_);
              var y = this.paper;
              return y.top != this && a._tofront(this, y), this;
            }, et.toBack = function() {
              if (this.removed) return this;
              var _ = K(this.node), y = _.parentNode;
              return y.insertBefore(_, y.firstChild), a._toback(this, this.paper), this.paper, this;
            }, et.insertAfter = function(_) {
              if (this.removed || !_) return this;
              var y = K(this.node), g = K(_.node || _[_.length - 1].node);
              return g.nextSibling ? g.parentNode.insertBefore(y, g.nextSibling) : g.parentNode.appendChild(y), a._insertafter(this, _, this.paper), this;
            }, et.insertBefore = function(_) {
              if (this.removed || !_) return this;
              var y = K(this.node), g = K(_.node || _[0].node);
              return g.parentNode.insertBefore(y, g), a._insertbefore(this, _, this.paper), this;
            }, et.blur = function(_) {
              var y = this;
              if (+_ != 0) {
                var g = B("filter"), w = B("feGaussianBlur");
                y.attrs.blur = _, g.id = a.createUUID(), B(w, { stdDeviation: +_ || 1.5 }), g.appendChild(w), y.paper.defs.appendChild(g), y._blur = g, B(y.node, { filter: "url(#" + g.id + ")" });
              } else y._blur && (y._blur.parentNode.removeChild(y._blur), delete y._blur, delete y.attrs.blur), y.node.removeAttribute("filter");
              return y;
            }, a._engine.circle = function(_, y, g, w) {
              var D = B("circle");
              _.canvas && _.canvas.appendChild(D);
              var E = new ht(D, _);
              return E.attrs = { cx: y, cy: g, r: w, fill: "none", stroke: "#000" }, E.type = "circle", B(D, E.attrs), E;
            }, a._engine.rect = function(_, y, g, w, D, E) {
              var I = B("rect");
              _.canvas && _.canvas.appendChild(I);
              var Z = new ht(I, _);
              return Z.attrs = { x: y, y: g, width: w, height: D, rx: E || 0, ry: E || 0, fill: "none", stroke: "#000" }, Z.type = "rect", B(I, Z.attrs), Z;
            }, a._engine.ellipse = function(_, y, g, w, D) {
              var E = B("ellipse");
              _.canvas && _.canvas.appendChild(E);
              var I = new ht(E, _);
              return I.attrs = { cx: y, cy: g, rx: w, ry: D, fill: "none", stroke: "#000" }, I.type = "ellipse", B(E, I.attrs), I;
            }, a._engine.image = function(_, y, g, w, D, E) {
              var I = B("image");
              B(I, { x: g, y: w, width: D, height: E, preserveAspectRatio: "none" }), I.setAttributeNS(W, "href", y), _.canvas && _.canvas.appendChild(I);
              var Z = new ht(I, _);
              return Z.attrs = { x: g, y: w, width: D, height: E, src: y }, Z.type = "image", Z;
            }, a._engine.text = function(_, y, g, w) {
              var D = B("text");
              _.canvas && _.canvas.appendChild(D);
              var E = new ht(D, _);
              return E.attrs = { x: y, y: g, "text-anchor": "middle", text: w, "font-family": a._availableAttrs["font-family"], "font-size": a._availableAttrs["font-size"], stroke: "none", fill: "#000" }, E.type = "text", Q(E, E.attrs), E;
            }, a._engine.setSize = function(_, y) {
              return this.width = _ || this.width, this.height = y || this.height, this.canvas.setAttribute("width", this.width), this.canvas.setAttribute("height", this.height), this._viewBox && this.setViewBox.apply(this, this._viewBox), this;
            }, a._engine.create = function() {
              var _ = a._getContainer.apply(0, arguments), y = _ && _.container;
              if (!y) throw new Error("SVG container not found.");
              var g, w = _.x, D = _.y, E = _.width, I = _.height, Z = B("svg"), F = "overflow:hidden;";
              return w = w || 0, D = D || 0, B(Z, { height: I = I || 342, version: 1.1, width: E = E || 512, xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink" }), y == 1 ? (Z.style.cssText = F + "position:absolute;left:" + w + "px;top:" + D + "px", a._g.doc.body.appendChild(Z), g = 1) : (Z.style.cssText = F + "position:relative", y.firstChild ? y.insertBefore(Z, y.firstChild) : y.appendChild(Z)), (y = new a._Paper()).width = E, y.height = I, y.canvas = Z, y.clear(), y._left = y._top = 0, g && (y.renderfix = function() {
              }), y.renderfix(), y;
            }, a._engine.setViewBox = function(_, y, g, w, D) {
              P("raphael.setViewBox", this, this._viewBox, [_, y, g, w, D]);
              var E, I, Z = this.getSize(), F = k(g / Z.width, w / Z.height), J = this.top, dt = D ? "xMidYMid meet" : "xMinYMin";
              for (_ == null ? (this._vbSize && (F = 1), delete this._vbSize, E = "0 0 " + this.width + O + this.height) : (this._vbSize = F, E = _ + O + y + O + g + O + w), B(this.canvas, { viewBox: E, preserveAspectRatio: dt }); F && J; ) I = "stroke-width" in J.attrs ? J.attrs["stroke-width"] : 1, J.attr({ "stroke-width": I }), J._.dirty = 1, J._.dirtyT = 1, J = J.prev;
              return this._viewBox = [_, y, g, w, !!D], this;
            }, a.prototype.renderfix = function() {
              var _, y = this.canvas, g = y.style;
              try {
                _ = y.getScreenCTM() || y.createSVGMatrix();
              } catch {
                _ = y.createSVGMatrix();
              }
              var w = -_.e % 1, D = -_.f % 1;
              (w || D) && (w && (this._left = (this._left + w) % 1, g.left = this._left + "px"), D && (this._top = (this._top + D) % 1, g.top = this._top + "px"));
            }, a.prototype.clear = function() {
              a.eve("raphael.clear", this);
              for (var _ = this.canvas; _.firstChild; ) _.removeChild(_.firstChild);
              this.bottom = this.top = null, (this.desc = B("desc")).appendChild(a._g.doc.createTextNode("Created with Raphaël " + a.version)), _.appendChild(this.desc), _.appendChild(this.defs = B("defs"));
            }, a.prototype.remove = function() {
              for (var _ in P("raphael.remove", this), this.canvas.parentNode && this.canvas.parentNode.removeChild(this.canvas), this) this[_] = typeof this[_] == "function" ? a._removedFactory(_) : null;
            };
            var ut = a.st;
            for (var yt in et) et[l](yt) && !ut[l](yt) && (ut[yt] = /* @__PURE__ */ (function(_) {
              return function() {
                var y = arguments;
                return this.forEach(function(g) {
                  g[_].apply(g, y);
                });
              };
            })(yt));
          }
        }).apply(s, o)) === void 0 || (e.exports = r);
      }, function(e, s, n) {
        var o, r;
        o = [n(0)], (r = (function(a) {
          if (!a || a.vml) {
            var l = "hasOwnProperty", d = String, f = parseFloat, x = Math, b = x.round, k = x.max, T = x.min, C = x.abs, A = /[, ]+/, P = a.eve, z = " ", O = "", W = { M: "m", L: "l", C: "c", Z: "x", m: "t", l: "r", c: "v", z: "x" }, R = /([clmz]),?([^clmz]*)/gi, Y = / progid:\S+Blur\([^\)]+\)/g, B = /-?[^,\s-]+/g, H = "position:absolute;left:0;top:0;width:1px;height:1px;behavior:url(#default#VML)", it = 21600, ct = { path: 1, rect: 1, image: 1 }, X = { circle: 1, ellipse: 1 }, st = function(y, g, w) {
              var D = a.matrix();
              return D.rotate(-y, 0.5, 0.5), { dx: D.x(g, w), dy: D.y(g, w) };
            }, ft = function(y, g, w, D, E, I) {
              var Z = y._, F = y.matrix, J = Z.fillpos, dt = y.node, gt = dt.style, _t = 1, Mt = "", $t = it / g, Tt = it / w;
              if (gt.visibility = "hidden", g && w) {
                if (dt.coordsize = C($t) + z + C(Tt), gt.rotation = I * (g * w < 0 ? -1 : 1), I) {
                  var Lt = st(I, D, E);
                  D = Lt.dx, E = Lt.dy;
                }
                if (g < 0 && (Mt += "x"), w < 0 && (Mt += " y") && (_t = -1), gt.flip = Mt, dt.coordorigin = D * -$t + z + E * -Tt, J || Z.fillsize) {
                  var At = dt.getElementsByTagName("fill");
                  At = At && At[0], dt.removeChild(At), J && (Lt = st(I, F.x(J[0], J[1]), F.y(J[0], J[1])), At.position = Lt.dx * _t + z + Lt.dy * _t), Z.fillsize && (At.size = Z.fillsize[0] * C(g) + z + Z.fillsize[1] * C(w)), dt.appendChild(At);
                }
                gt.visibility = "visible";
              }
            };
            a.toString = function() {
              return `Your browser doesn’t support SVG. Falling down to VML.
You are running Raphaël ` + this.version;
            };
            var Q, G = function(y, g, w) {
              for (var D = d(g).toLowerCase().split("-"), E = w ? "end" : "start", I = D.length, Z = "classic", F = "medium", J = "medium"; I--; ) switch (D[I]) {
                case "block":
                case "classic":
                case "oval":
                case "diamond":
                case "open":
                case "none":
                  Z = D[I];
                  break;
                case "wide":
                case "narrow":
                  J = D[I];
                  break;
                case "long":
                case "short":
                  F = D[I];
              }
              var dt = y.node.getElementsByTagName("stroke")[0];
              dt[E + "arrow"] = Z, dt[E + "arrowlength"] = F, dt[E + "arrowwidth"] = J;
            }, K = function(y, g) {
              y.attrs = y.attrs || {};
              var w = y.node, D = y.attrs, E = w.style, I = ct[y.type] && (g.x != D.x || g.y != D.y || g.width != D.width || g.height != D.height || g.cx != D.cx || g.cy != D.cy || g.rx != D.rx || g.ry != D.ry || g.r != D.r), Z = X[y.type] && (D.cx != g.cx || D.cy != g.cy || D.r != g.r || D.rx != g.rx || D.ry != g.ry), F = y;
              for (var J in g) g[l](J) && (D[J] = g[J]);
              if (I && (D.path = a._getPath[y.type](y), y._.dirty = 1), g.href && (w.href = g.href), g.title && (w.title = g.title), g.target && (w.target = g.target), g.cursor && (E.cursor = g.cursor), "blur" in g && y.blur(g.blur), (g.path && y.type == "path" || I) && (w.path = (function(Yt) {
                var Te = /[ahqstv]/gi, ri = a._pathToAbsolute;
                if (d(Yt).match(Te) && (ri = a._path2curve), Te = /[clmz]/g, ri == a._pathToAbsolute && !d(Yt).match(Te)) {
                  var oe = d(Yt).replace(R, function(Rn, ci, hi) {
                    var Oe = [], es = ci.toLowerCase() == "m", je = W[ci];
                    return hi.replace(B, function(is) {
                      es && Oe.length == 2 && (je += Oe + W[ci == "m" ? "l" : "L"], Oe = []), Oe.push(b(is * it));
                    }), je + Oe;
                  });
                  return oe;
                }
                var ai, de, Di = ri(Yt);
                oe = [];
                for (var li = 0, Ai = Di.length; li < Ai; li++) {
                  ai = Di[li], (de = Di[li][0].toLowerCase()) == "z" && (de = "x");
                  for (var Le = 1, Jt = ai.length; Le < Jt; Le++) de += b(ai[Le] * it) + (Le != Jt - 1 ? "," : O);
                  oe.push(de);
                }
                return oe.join(z);
              })(~d(D.path).toLowerCase().indexOf("r") ? a._pathToAbsolute(D.path) : D.path), y._.dirty = 1, y.type == "image" && (y._.fillpos = [D.x, D.y], y._.fillsize = [D.width, D.height], ft(y, 1, 1, 0, 0, 0))), "transform" in g && y.transform(g.transform), Z) {
                var dt = +D.cx, gt = +D.cy, _t = +D.rx || +D.r || 0, Mt = +D.ry || +D.r || 0;
                w.path = a.format("ar{0},{1},{2},{3},{4},{1},{4},{1}x", b((dt - _t) * it), b((gt - Mt) * it), b((dt + _t) * it), b((gt + Mt) * it), b(dt * it)), y._.dirty = 1;
              }
              if ("clip-rect" in g) {
                var $t = d(g["clip-rect"]).split(A);
                if ($t.length == 4) {
                  $t[2] = +$t[2] + +$t[0], $t[3] = +$t[3] + +$t[1];
                  var Tt = w.clipRect || a._g.doc.createElement("div"), Lt = Tt.style;
                  Lt.clip = a.format("rect({1}px {2}px {3}px {0}px)", $t), w.clipRect || (Lt.position = "absolute", Lt.top = 0, Lt.left = 0, Lt.width = y.paper.width + "px", Lt.height = y.paper.height + "px", w.parentNode.insertBefore(Tt, w), Tt.appendChild(w), w.clipRect = Tt);
                }
                g["clip-rect"] || w.clipRect && (w.clipRect.style.clip = "auto");
              }
              if (y.textpath) {
                var At = y.textpath.style;
                g.font && (At.font = g.font), g["font-family"] && (At.fontFamily = '"' + g["font-family"].split(",")[0].replace(/^['"]+|['"]+$/g, O) + '"'), g["font-size"] && (At.fontSize = g["font-size"]), g["font-weight"] && (At.fontWeight = g["font-weight"]), g["font-style"] && (At.fontStyle = g["font-style"]);
              }
              if ("arrow-start" in g && G(F, g["arrow-start"]), "arrow-end" in g && G(F, g["arrow-end"], 1), g.opacity != null || g.fill != null || g.src != null || g.stroke != null || g["stroke-width"] != null || g["stroke-opacity"] != null || g["fill-opacity"] != null || g["stroke-dasharray"] != null || g["stroke-miterlimit"] != null || g["stroke-linejoin"] != null || g["stroke-linecap"] != null) {
                var bt = w.getElementsByTagName("fill");
                if (!(bt = bt && bt[0]) && (bt = Q("fill")), y.type == "image" && g.src && (bt.src = g.src), g.fill && (bt.on = !0), bt.on != null && g.fill != "none" && g.fill !== null || (bt.on = !1), bt.on && g.fill) {
                  var Ft = d(g.fill).match(a._ISURL);
                  if (Ft) {
                    bt.parentNode == w && w.removeChild(bt), bt.rotate = !0, bt.src = Ft[1], bt.type = "tile";
                    var zt = y.getBBox(1);
                    bt.position = zt.x + z + zt.y, y._.fillpos = [zt.x, zt.y], a._preload(Ft[1], function() {
                      y._.fillsize = [this.offsetWidth, this.offsetHeight];
                    });
                  } else bt.color = a.getRGB(g.fill).hex, bt.src = O, bt.type = "solid", a.getRGB(g.fill).error && (F.type in { circle: 1, ellipse: 1 } || d(g.fill).charAt() != "r") && ht(F, g.fill, bt) && (D.fill = "none", D.gradient = g.fill, bt.rotate = !1);
                }
                if ("fill-opacity" in g || "opacity" in g) {
                  var jt = ((+D["fill-opacity"] + 1 || 2) - 1) * ((+D.opacity + 1 || 2) - 1) * ((+a.getRGB(g.fill).o + 1 || 2) - 1);
                  jt = T(k(jt, 0), 1), bt.opacity = jt, bt.src && (bt.color = "none");
                }
                w.appendChild(bt);
                var Ot = w.getElementsByTagName("stroke") && w.getElementsByTagName("stroke")[0], ie = !1;
                !Ot && (ie = Ot = Q("stroke")), (g.stroke && g.stroke != "none" || g["stroke-width"] || g["stroke-opacity"] != null || g["stroke-dasharray"] || g["stroke-miterlimit"] || g["stroke-linejoin"] || g["stroke-linecap"]) && (Ot.on = !0), (g.stroke == "none" || g.stroke === null || Ot.on == null || g.stroke == 0 || g["stroke-width"] == 0) && (Ot.on = !1);
                var Kt = a.getRGB(g.stroke);
                Ot.on && g.stroke && (Ot.color = Kt.hex), jt = ((+D["stroke-opacity"] + 1 || 2) - 1) * ((+D.opacity + 1 || 2) - 1) * ((+Kt.o + 1 || 2) - 1);
                var Ae = 0.75 * (f(g["stroke-width"]) || 1);
                if (jt = T(k(jt, 0), 1), g["stroke-width"] == null && (Ae = D["stroke-width"]), g["stroke-width"] && (Ot.weight = Ae), Ae && Ae < 1 && (jt *= Ae) && (Ot.weight = 1), Ot.opacity = jt, g["stroke-linejoin"] && (Ot.joinstyle = g["stroke-linejoin"] || "miter"), Ot.miterlimit = g["stroke-miterlimit"] || 8, g["stroke-linecap"] && (Ot.endcap = g["stroke-linecap"] == "butt" ? "flat" : g["stroke-linecap"] == "square" ? "square" : "round"), "stroke-dasharray" in g) {
                  var Si = { "-": "shortdash", ".": "shortdot", "-.": "shortdashdot", "-..": "shortdashdotdot", ". ": "dot", "- ": "dash", "--": "longdash", "- .": "dashdot", "--.": "longdashdot", "--..": "longdashdotdot" };
                  Ot.dashstyle = Si[l](g["stroke-dasharray"]) ? Si[g["stroke-dasharray"]] : O;
                }
                ie && w.appendChild(Ot);
              }
              if (F.type == "text") {
                F.paper.canvas.style.display = O;
                var Pe = F.paper.span, si = D.font && D.font.match(/\d+(?:\.\d*)?(?=px)/);
                E = Pe.style, D.font && (E.font = D.font), D["font-family"] && (E.fontFamily = D["font-family"]), D["font-weight"] && (E.fontWeight = D["font-weight"]), D["font-style"] && (E.fontStyle = D["font-style"]), si = f(D["font-size"] || si && si[0]) || 10, E.fontSize = 100 * si + "px", F.textpath.string && (Pe.innerHTML = d(F.textpath.string).replace(/</g, "&#60;").replace(/&/g, "&#38;").replace(/\n/g, "<br>"));
                var ni = Pe.getBoundingClientRect();
                F.W = D.w = (ni.right - ni.left) / 100, F.H = D.h = (ni.bottom - ni.top) / 100, F.X = D.x, F.Y = D.y + F.H / 2, ("x" in g || "y" in g) && (F.path.v = a.format("m{0},{1}l{2},{1}", b(D.x * it), b(D.y * it), b(D.x * it) + 1));
                for (var Ci = ["x", "y", "text", "font", "font-family", "font-weight", "font-style", "font-size"], oi = 0, ts = Ci.length; oi < ts; oi++) if (Ci[oi] in g) {
                  F._.dirty = 1;
                  break;
                }
                switch (D["text-anchor"]) {
                  case "start":
                    F.textpath.style["v-text-align"] = "left", F.bbx = F.W / 2;
                    break;
                  case "end":
                    F.textpath.style["v-text-align"] = "right", F.bbx = -F.W / 2;
                    break;
                  default:
                    F.textpath.style["v-text-align"] = "center", F.bbx = 0;
                }
                F.textpath.style["v-text-kern"] = !0;
              }
            }, ht = function(y, g, w) {
              y.attrs = y.attrs || {}, y.attrs;
              var D = Math.pow, E = "linear", I = ".5 .5";
              if (y.attrs.gradient = g, g = (g = d(g).replace(a._radial_gradient, function(_t, Mt, $t) {
                return E = "radial", Mt && $t && (Mt = f(Mt), $t = f($t), D(Mt - 0.5, 2) + D($t - 0.5, 2) > 0.25 && ($t = x.sqrt(0.25 - D(Mt - 0.5, 2)) * (2 * ($t > 0.5) - 1) + 0.5), I = Mt + z + $t), O;
              })).split(/\s*\-\s*/), E == "linear") {
                var Z = g.shift();
                if (Z = -f(Z), isNaN(Z)) return null;
              }
              var F = a._parseDots(g);
              if (!F) return null;
              if (y = y.shape || y.node, F.length) {
                y.removeChild(w), w.on = !0, w.method = "none", w.color = F[0].color, w.color2 = F[F.length - 1].color;
                for (var J = [], dt = 0, gt = F.length; dt < gt; dt++) F[dt].offset && J.push(F[dt].offset + z + F[dt].color);
                w.colors = J.length ? J.join() : "0% " + w.color, E == "radial" ? (w.type = "gradientTitle", w.focus = "100%", w.focussize = "0 0", w.focusposition = I, w.angle = 0) : (w.type = "gradient", w.angle = (270 - Z) % 360), y.appendChild(w);
              }
              return 1;
            }, et = function(y, g) {
              this[0] = this.node = y, y.raphael = !0, this.id = a._oid++, y.raphaelid = this.id, this.X = 0, this.Y = 0, this.attrs = {}, this.paper = g, this.matrix = a.matrix(), this._ = { transform: [], sx: 1, sy: 1, dx: 0, dy: 0, deg: 0, dirty: 1, dirtyT: 1 }, !g.bottom && (g.bottom = this), this.prev = g.top, g.top && (g.top.next = this), g.top = this, this.next = null;
            }, ut = a.el;
            et.prototype = ut, ut.constructor = et, ut.transform = function(y) {
              if (y == null) return this._.transform;
              var g, w = this.paper._viewBoxShift, D = w ? "s" + [w.scale, w.scale] + "-1-1t" + [w.dx, w.dy] : O;
              w && (g = y = d(y).replace(/\.{3}|\u2026/g, this._.transform || O)), a._extractTransform(this, D + y);
              var E, I = this.matrix.clone(), Z = this.skew, F = this.node, J = ~d(this.attrs.fill).indexOf("-"), dt = !d(this.attrs.fill).indexOf("url(");
              if (I.translate(1, 1), dt || J || this.type == "image") if (Z.matrix = "1 0 0 1", Z.offset = "0 0", E = I.split(), J && E.noRotation || !E.isSimple) {
                F.style.filter = I.toFilter();
                var gt = this.getBBox(), _t = this.getBBox(1), Mt = gt.x - _t.x, $t = gt.y - _t.y;
                F.coordorigin = Mt * -it + z + $t * -it, ft(this, 1, 1, Mt, $t, 0);
              } else F.style.filter = O, ft(this, E.scalex, E.scaley, E.dx, E.dy, E.rotate);
              else F.style.filter = O, Z.matrix = d(I), Z.offset = I.offset();
              return g !== null && (this._.transform = g, a._extractTransform(this, g)), this;
            }, ut.rotate = function(y, g, w) {
              if (this.removed) return this;
              if (y != null) {
                if ((y = d(y).split(A)).length - 1 && (g = f(y[1]), w = f(y[2])), y = f(y[0]), w == null && (g = w), g == null || w == null) {
                  var D = this.getBBox(1);
                  g = D.x + D.width / 2, w = D.y + D.height / 2;
                }
                return this._.dirtyT = 1, this.transform(this._.transform.concat([["r", y, g, w]])), this;
              }
            }, ut.translate = function(y, g) {
              return this.removed ? this : ((y = d(y).split(A)).length - 1 && (g = f(y[1])), y = f(y[0]) || 0, g = +g || 0, this._.bbox && (this._.bbox.x += y, this._.bbox.y += g), this.transform(this._.transform.concat([["t", y, g]])), this);
            }, ut.scale = function(y, g, w, D) {
              if (this.removed) return this;
              if ((y = d(y).split(A)).length - 1 && (g = f(y[1]), w = f(y[2]), D = f(y[3]), isNaN(w) && (w = null), isNaN(D) && (D = null)), y = f(y[0]), g == null && (g = y), D == null && (w = D), w == null || D == null) var E = this.getBBox(1);
              return w = w ?? E.x + E.width / 2, D = D ?? E.y + E.height / 2, this.transform(this._.transform.concat([["s", y, g, w, D]])), this._.dirtyT = 1, this;
            }, ut.hide = function() {
              return !this.removed && (this.node.style.display = "none"), this;
            }, ut.show = function() {
              return !this.removed && (this.node.style.display = O), this;
            }, ut.auxGetBBox = a.el.getBBox, ut.getBBox = function() {
              var y = this.auxGetBBox();
              if (this.paper && this.paper._viewBoxShift) {
                var g = {}, w = 1 / this.paper._viewBoxShift.scale;
                return g.x = y.x - this.paper._viewBoxShift.dx, g.x *= w, g.y = y.y - this.paper._viewBoxShift.dy, g.y *= w, g.width = y.width * w, g.height = y.height * w, g.x2 = g.x + g.width, g.y2 = g.y + g.height, g;
              }
              return y;
            }, ut._getBBox = function() {
              return this.removed ? {} : { x: this.X + (this.bbx || 0) - this.W / 2, y: this.Y - this.H, width: this.W, height: this.H };
            }, ut.remove = function() {
              if (!this.removed && this.node.parentNode) {
                for (var y in this.paper.__set__ && this.paper.__set__.exclude(this), a.eve.unbind("raphael.*.*." + this.id), a._tear(this, this.paper), this.node.parentNode.removeChild(this.node), this.shape && this.shape.parentNode.removeChild(this.shape), this) this[y] = typeof this[y] == "function" ? a._removedFactory(y) : null;
                this.removed = !0;
              }
            }, ut.attr = function(y, g) {
              if (this.removed) return this;
              if (y == null) {
                var w = {};
                for (var D in this.attrs) this.attrs[l](D) && (w[D] = this.attrs[D]);
                return w.gradient && w.fill == "none" && (w.fill = w.gradient) && delete w.gradient, w.transform = this._.transform, w;
              }
              if (g == null && a.is(y, "string")) {
                if (y == "fill" && this.attrs.fill == "none" && this.attrs.gradient) return this.attrs.gradient;
                for (var E = y.split(A), I = {}, Z = 0, F = E.length; Z < F; Z++) (y = E[Z]) in this.attrs ? I[y] = this.attrs[y] : a.is(this.paper.customAttributes[y], "function") ? I[y] = this.paper.customAttributes[y].def : I[y] = a._availableAttrs[y];
                return F - 1 ? I : I[E[0]];
              }
              if (this.attrs && g == null && a.is(y, "array")) {
                for (I = {}, Z = 0, F = y.length; Z < F; Z++) I[y[Z]] = this.attr(y[Z]);
                return I;
              }
              var J;
              for (var dt in g != null && ((J = {})[y] = g), g == null && a.is(y, "object") && (J = y), J) P("raphael.attr." + dt + "." + this.id, this, J[dt]);
              if (J) {
                for (dt in this.paper.customAttributes) if (this.paper.customAttributes[l](dt) && J[l](dt) && a.is(this.paper.customAttributes[dt], "function")) {
                  var gt = this.paper.customAttributes[dt].apply(this, [].concat(J[dt]));
                  for (var _t in this.attrs[dt] = J[dt], gt) gt[l](_t) && (J[_t] = gt[_t]);
                }
                J.text && this.type == "text" && (this.textpath.string = J.text), K(this, J);
              }
              return this;
            }, ut.toFront = function() {
              return !this.removed && this.node.parentNode.appendChild(this.node), this.paper && this.paper.top != this && a._tofront(this, this.paper), this;
            }, ut.toBack = function() {
              return this.removed ? this : (this.node.parentNode.firstChild != this.node && (this.node.parentNode.insertBefore(this.node, this.node.parentNode.firstChild), a._toback(this, this.paper)), this);
            }, ut.insertAfter = function(y) {
              return this.removed ? this : (y.constructor == a.st.constructor && (y = y[y.length - 1]), y.node.nextSibling ? y.node.parentNode.insertBefore(this.node, y.node.nextSibling) : y.node.parentNode.appendChild(this.node), a._insertafter(this, y, this.paper), this);
            }, ut.insertBefore = function(y) {
              return this.removed ? this : (y.constructor == a.st.constructor && (y = y[0]), y.node.parentNode.insertBefore(this.node, y.node), a._insertbefore(this, y, this.paper), this);
            }, ut.blur = function(y) {
              var g = this.node.runtimeStyle, w = g.filter;
              return w = w.replace(Y, O), +y != 0 ? (this.attrs.blur = y, g.filter = w + z + " progid:DXImageTransform.Microsoft.Blur(pixelradius=" + (+y || 1.5) + ")", g.margin = a.format("-{0}px 0 0 -{0}px", b(+y || 1.5))) : (g.filter = w, g.margin = 0, delete this.attrs.blur), this;
            }, a._engine.path = function(y, g) {
              var w = Q("shape");
              w.style.cssText = H, w.coordsize = it + z + it, w.coordorigin = g.coordorigin;
              var D = new et(w, g), E = { fill: "none", stroke: "#000" };
              y && (E.path = y), D.type = "path", D.path = [], D.Path = O, K(D, E), g.canvas && g.canvas.appendChild(w);
              var I = Q("skew");
              return I.on = !0, w.appendChild(I), D.skew = I, D.transform(O), D;
            }, a._engine.rect = function(y, g, w, D, E, I) {
              var Z = a._rectPath(g, w, D, E, I), F = y.path(Z), J = F.attrs;
              return F.X = J.x = g, F.Y = J.y = w, F.W = J.width = D, F.H = J.height = E, J.r = I, J.path = Z, F.type = "rect", F;
            }, a._engine.ellipse = function(y, g, w, D, E) {
              var I = y.path();
              return I.attrs, I.X = g - D, I.Y = w - E, I.W = 2 * D, I.H = 2 * E, I.type = "ellipse", K(I, { cx: g, cy: w, rx: D, ry: E }), I;
            }, a._engine.circle = function(y, g, w, D) {
              var E = y.path();
              return E.attrs, E.X = g - D, E.Y = w - D, E.W = E.H = 2 * D, E.type = "circle", K(E, { cx: g, cy: w, r: D }), E;
            }, a._engine.image = function(y, g, w, D, E, I) {
              var Z = a._rectPath(w, D, E, I), F = y.path(Z).attr({ stroke: "none" }), J = F.attrs, dt = F.node, gt = dt.getElementsByTagName("fill")[0];
              return J.src = g, F.X = J.x = w, F.Y = J.y = D, F.W = J.width = E, F.H = J.height = I, J.path = Z, F.type = "image", gt.parentNode == dt && dt.removeChild(gt), gt.rotate = !0, gt.src = g, gt.type = "tile", F._.fillpos = [w, D], F._.fillsize = [E, I], dt.appendChild(gt), ft(F, 1, 1, 0, 0, 0), F;
            }, a._engine.text = function(y, g, w, D) {
              var E = Q("shape"), I = Q("path"), Z = Q("textpath");
              g = g || 0, w = w || 0, D = D || "", I.v = a.format("m{0},{1}l{2},{1}", b(g * it), b(w * it), b(g * it) + 1), I.textpathok = !0, Z.string = d(D), Z.on = !0, E.style.cssText = H, E.coordsize = it + z + it, E.coordorigin = "0 0";
              var F = new et(E, y), J = { fill: "#000", stroke: "none", font: a._availableAttrs.font, text: D };
              F.shape = E, F.path = I, F.textpath = Z, F.type = "text", F.attrs.text = d(D), F.attrs.x = g, F.attrs.y = w, F.attrs.w = 1, F.attrs.h = 1, K(F, J), E.appendChild(Z), E.appendChild(I), y.canvas.appendChild(E);
              var dt = Q("skew");
              return dt.on = !0, E.appendChild(dt), F.skew = dt, F.transform(O), F;
            }, a._engine.setSize = function(y, g) {
              var w = this.canvas.style;
              return this.width = y, this.height = g, y == +y && (y += "px"), g == +g && (g += "px"), w.width = y, w.height = g, w.clip = "rect(0 " + y + " " + g + " 0)", this._viewBox && a._engine.setViewBox.apply(this, this._viewBox), this;
            }, a._engine.setViewBox = function(y, g, w, D, E) {
              a.eve("raphael.setViewBox", this, this._viewBox, [y, g, w, D, E]);
              var I, Z, F = this.getSize(), J = F.width, dt = F.height;
              return E && (w * (I = dt / D) < J && (y -= (J - w * I) / 2 / I), D * (Z = J / w) < dt && (g -= (dt - D * Z) / 2 / Z)), this._viewBox = [y, g, w, D, !!E], this._viewBoxShift = { dx: -y, dy: -g, scale: F }, this.forEach(function(gt) {
                gt.transform("...");
              }), this;
            }, a._engine.initWin = function(y) {
              var g = y.document;
              g.styleSheets.length < 31 ? g.createStyleSheet().addRule(".rvml", "behavior:url(#default#VML)") : g.styleSheets[0].addRule(".rvml", "behavior:url(#default#VML)");
              try {
                !g.namespaces.rvml && g.namespaces.add("rvml", "urn:schemas-microsoft-com:vml"), Q = function(w) {
                  return g.createElement("<rvml:" + w + ' class="rvml">');
                };
              } catch {
                Q = function(D) {
                  return g.createElement("<" + D + ' xmlns="urn:schemas-microsoft.com:vml" class="rvml">');
                };
              }
            }, a._engine.initWin(a._g.win), a._engine.create = function() {
              var y = a._getContainer.apply(0, arguments), g = y.container, w = y.height, D = y.width, E = y.x, I = y.y;
              if (!g) throw new Error("VML container not found.");
              var Z = new a._Paper(), F = Z.canvas = a._g.doc.createElement("div"), J = F.style;
              return E = E || 0, I = I || 0, D = D || 512, w = w || 342, Z.width = D, Z.height = w, D == +D && (D += "px"), w == +w && (w += "px"), Z.coordsize = 216e5 + z + 216e5, Z.coordorigin = "0 0", Z.span = a._g.doc.createElement("span"), Z.span.style.cssText = "position:absolute;left:-9999em;top:-9999em;padding:0;margin:0;line-height:1;", F.appendChild(Z.span), J.cssText = a.format("top:0;left:0;width:{0};height:{1};display:inline-block;position:relative;clip:rect(0 {0} {1} 0);overflow:hidden", D, w), g == 1 ? (a._g.doc.body.appendChild(F), J.left = E + "px", J.top = I + "px", J.position = "absolute") : g.firstChild ? g.insertBefore(F, g.firstChild) : g.appendChild(F), Z.renderfix = function() {
              }, Z;
            }, a.prototype.clear = function() {
              a.eve("raphael.clear", this), this.canvas.innerHTML = O, this.span = a._g.doc.createElement("span"), this.span.style.cssText = "position:absolute;left:-9999em;top:-9999em;padding:0;margin:0;line-height:1;display:inline;", this.canvas.appendChild(this.span), this.bottom = this.top = null;
            }, a.prototype.remove = function() {
              for (var y in a.eve("raphael.remove", this), this.canvas.parentNode.removeChild(this.canvas), this) this[y] = typeof this[y] == "function" ? a._removedFactory(y) : null;
              return !0;
            };
            var yt = a.st;
            for (var _ in ut) ut[l](_) && !yt[l](_) && (yt[_] = /* @__PURE__ */ (function(y) {
              return function() {
                var g = arguments;
                return this.forEach(function(w) {
                  w[y].apply(w, g);
                });
              };
            })(_));
          }
        }).apply(s, o)) === void 0 || (e.exports = r);
      }]);
    });
  })(Gs)), Gs.exports;
}
var qa = Ga();
const qs = /* @__PURE__ */ Dr(qa), kt = {
  // triangle
  $0: { x: 12, y: 12, scale: 1, rotcorr: 180, path: "M0,0 6,12 12,0z" },
  // small aircraft
  $1: {
    x: 16,
    y: 17,
    scale: 1,
    rotcorr: 180,
    path: "M8,17 9,16 9,12 16,11 16,8 9,7 9,3 11,1 11,0 8,1 5,0 5,1 7,3 7,7 0,8 0,11 7,12 7,16 8,17z"
  },
  // two propeller aircraft
  $2: {
    x: 26,
    y: 18,
    scale: 1,
    rotcorr: 180,
    path: "M13,18 14,17 14,17 15,14 17,14 17,16 18,17 19,16 19,14 25,14 26,13 26,12 26,12 25,11 19,10 19,9 18,9 18,10 15,9 14,6 14,2 18,1 18,0 13,0 8,0 8,1 12,2 12,6 11,9 8,10 8,9 7,9 7,10 1,11 0,12 0,12 0,13 1,14 7,14 7,16 8,17 9,16 9,14 11,14 12,17 12,17 13,18z"
  },
  // jet with two turbines at back (Learjet or so)
  $3: {
    x: 21,
    y: 24,
    scale: 1,
    rotcorr: 180,
    path: "M11,24 12,23 12,14 20,10 21,8 13,10 12,9 12,7 14,7 13,4 12,4 12,3 14,2 15,0 12,1 11,0 10,1 7,0 8,2 10,3 10,4 9,4 8,7 10,7 10,9 9,10 0,8 1,10 10,14 10,23 11,24z"
  },
  // A320, B737
  $4: {
    x: 24,
    y: 28,
    scale: 1,
    rotcorr: 180,
    path: "M12,28 13,26 14,23 14,18 16,17 16,19 18,19 18,16 24,11 24,10 23,10 15,13 14,13 13,6 13,5 16,2 16,0 13,2 12,0 11,2 8,0 8,2 11,5 11,6 10,13 9,13 1,10 0,10 0,11 6,16 6,19 8,19 8,17 10,18 10,23 11,26 12,28z"
  },
  // B747, A380
  $5: {
    x: 30,
    y: 31,
    scale: 1,
    rotcorr: 180,
    path: "M15,31 17,28 17,22 20,20 20,22 22,22 22,19 25,17 25,19 27,19 27,16 30,13 30,11 19,14 17,14 17,7 16,5 20,2 20,0 16,1 15,0 14,1 10,0 10,2 14,5 13,7 13,14 11,14 0,11 0,13 3,16 3,19 5,19 5,17 8,19 8,22 10,22 10,20 13,22 13,28 15,31z"
  },
  // Fighter
  $6: {
    x: 16,
    y: 20,
    scale: 1,
    rotcorr: 180,
    path: "M8,20 9,18 9,14 10,12 10,11 16,8 15,6 10,5 10,3 12,2 12,1 11,0 10,0 9,2 8,1 7,2 6,0 5,0 4,1 4,2 6,3 6,5 1,6 0,8 6,11 6,12 7,14 7,18 8,20z"
  },
  // Helicopter
  $7: {
    x: 20,
    y: 23,
    scale: 1,
    rotcorr: 180,
    path: "M10,20 11,20 11,20 12,17 19,23 20,22 13,15 13,13 20,6 19,5 12,11 11,9 11,4 12,4 13,2 11,2 11,1 10,0 9,1 9,2 7,2 8,4 9,4 9,9 8,11 1,5 0,6 7,13 7,15 0,22 1,23 8,17 9,20 10,20z"
  },
  // jet with two turbines at back (smaller than $3)
  $8: {
    x: 16,
    y: 20,
    scale: 1,
    rotcorr: 180,
    path: "M8,20 9,18 9,12 16,7 16,6 9,7 10,5 10,4 9,3 10,2 11,1 11,0 8,1 5,0 5,1 6,2 7,3 6,4 6,5 7,7 0,6 0,7 7,12 7,18 8,20z"
  },
  // small jet with 4 turbines on wings, Avro RJ70
  $9: {
    x: 22,
    y: 18,
    scale: 1,
    rotcorr: 180,
    path: "M11,18 12,17 13,14 13,12 15,12 15,13 17,13 17,11 19,10 19,11 21,11 21,9 22,8 22,6 14,8 13,8 13,7 12,2 12,2 15,1 15,0 12,0 11,0 10,0 7,0 7,1 10,2 10,2 9,7 9,8 8,8 0,6 0,8 1,9 1,11 3,11 3,10 5,11 5,13 7,13 7,12 9,12 9,14 10,17 11,18z"
  },
  // Osprey (takeoff)
  $A: {
    x: 30,
    y: 21,
    scale: 1,
    rotcorr: 180,
    path: "M14,20 16,20 17,18 17,14 21,14 18,20 19,21 20,20 22,14 23,13 23,13 29,14 29,14 30,13 29,12 23,12 22,11 22,5 21,4 20,5 21,11 17,11 17,9 16,6 16,3 18,3 18,0 12,0 12,3 14,3 14,6 13,9 13,11 9,11 10,5 9,4 8,5 8,11 7,12 2,12 1,12 0,13 1,14 7,13 8,14 8,14 10,20 11,21 12,20 9,14 13,14 13,18 14,20z"
  },
  // Osprey (flight)
  $A2: {
    x: 27,
    y: 20,
    scale: 1,
    rotcorr: 180,
    path: "M14,20 15,19 15,15 16,14 19,14 20,15 16,17 20,17 20,18 21,18 21,17 27,17 21,15 22,14 21,11 21,10 20,10 20,11 16,11 16,10 15,6 15,3 16,3 16,0 11,0 11,3 12,3 12,6 11,10 11,11 7,11 7,10 6,10 5,14 6,15 0,17 6,17 6,18 7,18 7,17 11,17 7,15 8,14 11,14 12,15 12,19 13,20 14,20z"
  },
  // Transall
  $B: {
    x: 21,
    y: 20,
    scale: 1,
    rotcorr: 180,
    path: "M10,20 12,19 12,17 12,13 15,13 15,13 15,13 15,15 17,15 17,13 19,13 19,13 21,12 21,10 19,9 12,9 12,4 12,3 14,2 14,0 12,0 10,0 9,0 7,0 7,2 9,3 9,4 9,9 2,9 0,10 0,12 2,13 2,13 4,13 4,15 6,15 6,13 7,13 7,13 9,13 9,17 9,19 10,20z"
  },
  // Hercules
  $C: {
    x: 26,
    y: 24,
    scale: 1,
    rotcorr: 180,
    path: "M13,24 14,23 15,22 15,16 17,16 17,18 19,18 19,16 21,16 21,18 23,18 23,16 26,15 26,13 23,12 15,12 15,4 14,3 17,2 17,0 14,0 13,0 12,0 9,0 9,2 12,3 11,4 11,12 3,12 0,13 0,15 3,16 3,18 5,18 5,16 7,16 7,18 9,18 9,16 11,16 11,22 12,23 13,24z"
  },
  // ???
  $D: {
    x: 28,
    y: 25,
    scale: 1,
    rotcorr: 180,
    path: "M14,25 15,22 15,14 17,14 17,17 18,18 19,17 19,14 28,14 28,12 15,10 15,3 19,1 19,0 9,0 9,1 13,3 13,10 0,12 0,14 9,14 9,17 10,18 11,17 11,14 13,14 13,22 14,25z"
  },
  // Military Helicopter
  $E: {
    x: 18,
    y: 30,
    scale: 1,
    rotcorr: 180,
    path: "M9,28 10,28 10,28 11,24 17,30 18,29 11,20 11,19 18,10 17,9 11,15 11,9 10,6 10,6 10,4 11,3 10,1 9,0 8,0 5,0 5,3 8,4 8,6 7,9 7,15 1,9 0,10 7,19 7,20 0,29 1,30 7,24 8,28 9,28z"
  },
  // Glider:
  $SF25: {
    x: 10,
    y: 5,
    scale: 1.6,
    rotcorr: 0,
    path: "m 9.9426045,9.250116 c 0,-0.105041 -0.019648,-0.245689 -0.043664,-0.312551 C 9.8649535,8.842935 9.8108295,8.371017 9.8045435,8.114493 9.803882,8.087283 9.5539473,8.079763 8.6498441,8.079763 H 7.4959966 l 0.00783,-0.325223 0.00783,-0.325224 1.10985,-0.147948 C 9.2319245,7.199998 9.737399,7.127377 9.7447838,7.119992 9.7888508,7.075922 9.5909678,4.190505 9.5404112,4.139948 9.5329512,4.132448 7.3856524,3.912321 4.7686375,3.650689 l -4.75820654,-0.475695 -0.007587,-0.492542 -0.007587,-0.4925422 0.0770424,-3.051e-4 c 0.0423733,-1.678e-4 1.88358804,-0.031286 4.09158834,-0.069151 2.208,-0.037865 4.2793269,-0.068983 4.6029483,-0.069151 l 0.5883962,-3.018e-4 0.011456,-0.2430953 c 0.0063,-0.1337025 0.027051,-0.4368771 0.046111,-0.6737214 0.03932,-0.48861447 0.054908,-0.52879147 0.2856822,-0.73627707 0.080507,-0.072383 0.1693598,-0.1869829 0.205571,-0.2651414 0.07983,-0.1723046 0.099911,-0.1718062 0.1878472,0.00466 0.03901,0.078275 0.121558,0.1856619 0.183447,0.238637 0.271082,0.2320359 0.304028,0.3651824 0.354301,1.43184117 l 0.01146,0.2430953 0.588402,3.043e-4 c 0.323622,1.678e-4 2.394949,0.031286 4.602949,0.069151 2.208,0.037865 4.049215,0.068983 4.091588,0.069151 l 0.07704,3.043e-4 -0.0076,0.4925422 -0.0076,0.492542 -4.758208,0.475695 c -2.617015,0.261632 -4.764313,0.481799 -4.771774,0.489259 -0.04986,0.04986 -0.248672,2.935744 -0.20524,2.979177 0.0069,0.0069 0.512383,0.07909 1.123278,0.160399 l 1.110717,0.147838 0.0078,0.326201 0.0078,0.3262 h -1.1499 -1.149978 l -0.01752,0.145857 c -0.0096,0.08022 -0.01793,0.214619 -0.01842,0.29866 -5.02e-4,0.08404 -0.0136,0.202811 -0.02912,0.263932 -0.01552,0.06112 -0.03153,0.126395 -0.03558,0.145054 -0.0041,0.01866 -0.01606,0.04262 -0.02669,0.05325 -0.01063,0.01063 -0.01933,0.117258 -0.01933,0.236954 0,0.199106 -0.0047,0.217628 -0.05556,0.217628 -0.050176,0 -0.055565,-0.01852 -0.055565,-0.190983 z"
  },
  $SI2: {
    x: 26,
    y: 29,
    scale: 0.9,
    rotcorr: 0,
    path: "m 19.964368,1071.9917 c 0,-0.1479 -0.708303,-0.2399 -1.847142,-0.2399 -1.25149,0 -1.900887,-0.093 -2.013803,-0.2879 -0.215611,-0.3725 -0.215611,-1.9306 0,-2.303 0.110404,-0.1908 0.708126,-0.2879 1.770757,-0.2877 l 1.604097,2e-4 -0.04023,-4.7805 -0.04023,-4.7804 -7.667766,-0.1393 c -8.938858,-0.1622 -10.6152712,-0.2754 -10.88130821,-0.735 -0.2481701,-0.4287 -0.24320028,-2.2209 0.007396,-2.6539 0.23995191,-0.4144 4.34617251,-0.8175 8.37957011,-0.8224 l 2.6734951,0 0,-0.7198 c 0,-0.6397 0.04629,-0.7196 0.416649,-0.7196 0.370354,0 0.416647,0.08 0.416647,0.7196 0,0.7198 0,0.7198 0.833298,0.7198 0.833297,0 0.833297,0 0.833297,-0.7198 0,-0.6397 0.04629,-0.7196 0.416649,-0.7196 0.370354,0 0.416649,0.08 0.416649,0.7196 l 0,0.7198 2.152684,0 2.152685,0 0,-0.6621 c 0,-0.402 0.109014,-0.7796 0.277764,-0.9616 0.39401,-0.4251 0.833298,0.082 0.833298,0.9616 l 0,0.6621 2.152685,0 2.152684,0 0,-0.7198 c 0,-0.6397 0.04629,-0.7196 0.416649,-0.7196 0.370354,0 0.416649,0.08 0.416649,0.7196 0,0.7198 0,0.7198 0.833296,0.7198 0.833298,0 0.833298,0 0.833298,-0.7198 0,-0.6397 0.04629,-0.7196 0.416648,-0.7196 0.370355,0 0.416649,0.08 0.416649,0.7196 l 0,0.7198 2.673494,0 c 4.033398,0.01 8.13962,0.408 8.379571,0.8224 0.250558,0.433 0.255527,2.2252 0.0073,2.6539 -0.266036,0.4596 -1.942448,0.5728 -10.881306,0.735 l -7.667767,0.1393 -0.04023,4.7804 -0.04023,4.7805 1.604097,-2e-4 c 1.06263,-2e-4 1.660353,0.097 1.770756,0.2877 0.215612,0.3724 0.215612,1.9305 0,2.303 -0.112916,0.1951 -0.762312,0.2879 -2.013802,0.2879 -1.138839,0 -1.847141,0.092 -1.847141,0.2399 0,0.132 -0.06249,0.24 -0.138882,0.24 -0.07639,0 -0.138884,-0.108 -0.138884,-0.24 z"
  },
  $AWACS: {
    x: 26,
    y: 29,
    scale: 0.82,
    rotcorr: 0,
    path: "m 14.343596,1092.446 c -0.625928,-1.9855 0.923503,-3.2681 2.357528,-4.3114 0.638047,-0.911 2.558375,-1.4137 2.29187,-2.6824 -0.362274,-1.7564 0.05029,-3.8316 -1.945007,-4.6377 -1.636357,-1.7445 -1.31938,-4.7335 0.546742,-6.1856 -1.745001,0.2461 -3.609901,0.6206 -5.302719,1.249 -3.5415964,1.6938 -6.9829162,3.632 -10.5785055,5.1941 -0.5439413,-2.14 1.2146542,-3.7803 2.8415081,-4.8678 0.5261676,-0.6676 1.8896692,-0.9291 1.6238653,-1.9709 0.23028,-1.226 -0.6050837,-3.2618 0.47332,-3.8719 2.6153309,-0.9549 -0.026897,4.4345 1.9627108,2.5743 0.6938338,-0.8966 2.4992633,-1.3501 2.4085743,-2.6254 0.211105,-1.2601 -0.815967,-3.5113 0.535436,-3.9942 2.490841,-0.7901 -0.244444,4.8383 1.951076,2.6156 1.608072,-1.2923 3.214227,-2.5869 4.817539,-3.8851 0.08059,-2.9649 -0.196262,-5.961 0.261681,-8.8989 0.412822,-0.9973 0.517997,-4.4527 1.939053,-3.23 1.221951,2.7783 1.301796,5.8309 1.255964,8.8128 -0.02924,1.8951 -0.340617,4.0059 1.787657,4.8661 1.290079,0.8787 2.933003,2.6509 4.028181,2.9569 -0.06602,-1.3591 -0.605246,-4.008 1.619196,-3.1183 0.291731,1.5329 -0.113716,3.114 0.0099,4.6766 1.096138,0.6701 2.341176,2.1783 3.286665,2.3533 -0.311845,-1.3348 -0.553736,-3.8948 1.60534,-2.949 0.275013,1.4619 -0.09839,2.9696 -0.05541,4.4571 1.362156,1.1016 2.860751,2.0858 4.037065,3.3829 0.39777,1.2232 0.467414,3.6305 -1.233984,1.9739 -3.181761,-1.5474 -6.287606,-3.2706 -9.532607,-4.6755 -1.364436,-0.2822 -3.557771,-1.036 -4.488664,-0.9268 2.138134,1.6847 2.010353,5.3437 -0.352372,6.7679 -0.904477,0.2105 -0.572176,1.215 -0.75079,1.8975 -0.781025,2.0295 0.104268,3.6169 1.922096,4.6683 1.341759,1.1313 3.212014,2.4444 2.427988,4.4569 -1.805242,-0.1579 -4.316554,-2.0576 -5.585939,-1.4884 -0.33527,1.5767 -0.467274,-1.2308 -1.385651,-0.1469 -1.606227,0.4311 -3.160352,1.3124 -4.779356,1.563 z"
  },
  $A320: {
    x: 20,
    y: 20,
    scale: 0.75,
    rotcorr: 0,
    path: "m 32,4.8 0.3,0.1 0.8,1.2 0.9,3.1 0.6,3.1 0.5,5.2 0,6.9 3.6,2.7 -0.2,-1.5 0,-1.5 0.1,-1.2 0.2,-0.4 2.8,0 0.2,0.4 0.1,1.2 0,1.5 -0.4,2.2 -0.3,0 -0.1,0.9 14,7.7 0.4,0.4 0.2,0.7 0,1.5 -8.3,-2.4 -0.1,0.4 -0.2,0.2 -0.2,-0.2 -0.1,-0.5 -3.7,-1.1 -0.1,0.4 -0.2,0.2 -0.2,-0.2 -0.1,-0.5 -2,-0.6 0,1 -0.1,0.5 -0.1,0.1 -0.4,0 -0.1,-0.1 -0.1,-0.5 0,-1.3 -4.6,0 0,7.7 -0.1,2.8 -0.6,3.7 -0.6,3 0.1,0.4 8.5,5.9 0,1.8 -10,-2.5 -0.2,0.7 -0.1,0.8 -0.1,0.4 -0.1,-0.4 -0.1,-0.8 -0.2,-0.7 -10,2.5 0,-1.8 8.5,-5.9 0.1,-0.4 -0.6,-3 -0.6,-3.7 -0.1,-2.8 0,-7.7 -4.6,0 0,1.3 -0.1,0.5 -0.1,0.1 -0.4,0 -0.1,-0.1 -0.1,-0.5 0,-1 -2,0.6 -0.1,0.5 -0.2,0.2 -0.2,-0.2 -0.1,-0.4 -3.7,1.1 -0.1,0.5 -0.2,0.2 -0.2,-0.2 -0.1,-0.4 -8.3,2.4 0,-1.5 0.2,-0.7 0.4,-0.4 14,-7.7 -0.1,-0.9 -0.3,0 -0.4,-2.2 0,-1.5 0.1,-1.2 0.2,-0.4 2.8,0 0.2,0.4 0.1,1.6 0,1.1 -0.2,1.5 3.6,-2.8 0,-6.8 0.5,-5.2 0.6,-3.1 1,-3.1 0.7,-1.2 z"
  },
  $A330: {
    x: 20,
    y: 20,
    scale: 0.7,
    rotcorr: 0,
    path: "m 32,0.1 0.1,0 0.2,0.1 0.4,0.3 0.5,0.8 0.7,1.7 0.5,2 0.2,2.6 0,15.4 0.6,0.8 3.9,2.7 -0.2,-1.1 0,-1.2 0.2,-1.1 0.1,-0.2 2.3,0 0.1,0.2 0.2,1.1 0,1.2 -0.2,1.2 -0.3,0 -0.1,1.2 15.6,10.6 2.1,3.1 0,1 -2.1,-1.6 -7.8,-3.2 -0.1,0.4 -0.1,-0.5 -4.2,-1.4 -0.1,0.4 -0.1,-0.5 -4.4,-1.4 -1,-0.2 -0.2,0.5 -0.2,-0.5 -4,-0.4 0,14.2 -0.1,2.6 -0.4,4 0.5,0.7 7.2,5.8 0,1.6 -8.9,-2.3 -0.7,1.5 -0.1,1.3 -0.2,0 -0.1,-1.3 -0.7,-1.5 -8.9,2.3 0,-1.6 7.2,-5.8 0.5,-0.7 -0.4,-4 -0.1,-2.6 0,-14.2 -4,0.4 -0.2,0.5 -0.2,-0.5 -1,0.2 -4.4,1.4 -0.1,0.5 -0.1,-0.4 -4.2,1.4 -0.1,0.5 -0.1,-0.4 -7.8,3.2 -2.1,1.6 0,-1 2.1,-3.1 15.6,-10.6 -0.1,-1.2 -0.3,0 -0.2,-1.2 0,-1.2 0.2,-1.1 0.1,-0.2 2.3,0 0.1,0.2 0.2,1.1 0,1.2 -0.2,1.1 3.9,-2.7 0.6,-0.8 0,-15.4 0.2,-2.6 0.5,-2 0.7,-1.7 0.5,-0.8 0.4,-0.3 0.2,-0.1 z"
  },
  $A340: {
    x: 20,
    y: 20,
    scale: 0.7,
    rotcorr: 0,
    path: "m 32,0.2 0.1,0 0.2,0.1 0.3,0.3 0.5,0.8 0.7,1.7 0.5,2 0.3,2.5 0,15 0.3,0.6 0.5,0.6 3.3,2.2 -0.2,-1.1 0,-1.6 0.2,-1.4 0.1,-0.2 3,0 0.1,0.2 0.2,1.4 0,1.6 -0.2,1.4 -0.4,0 -0.4,1.3 16.4,10.8 0.2,0.5 0.1,1.5 -9,-3.1 -0.1,0.6 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -4.2,-1.4 -0.1,0.6 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -2.5,-0.8 -1.8,0 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -4.5,0 0,14.9 -0.2,1.9 -0.7,3.8 7.6,6.2 0.1,0.7 0,0.7 -0.1,0.7 -8.5,-3.1 -0.2,0.4 -0.5,1.8 -0.2,0 -0.5,-1.8 -0.2,-0.4 -8.5,3.1 -0.1,-0.7 0,-0.7 0.1,-0.7 7.6,-6.2 -0.7,-3.8 -0.2,-1.9 0,-14.9 -4.5,0 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -1.8,0 -2.5,0.8 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.6 -4.2,1.4 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.6 -9,3.1 0.1,-1.5 0.2,-0.5 16.4,-10.8 -0.4,-1.3 -0.4,0 -0.2,-1.4 0,-1.6 0.2,-1.4 0.1,-0.2 3,0 0.1,0.2 0.2,1.4 0,1.6 -0.2,1.1 3.3,-2.2 0.5,-0.6 0.3,-0.6 0,-15 0.3,-2.5 0.5,-2 0.7,-1.7 0.5,-0.8 0.3,-0.3 0.2,-0.1 z"
  },
  $A380: {
    x: 20,
    y: 20,
    scale: 0.86,
    rotcorr: 0,
    path: "m 20.170952,35.711605 c 0.240955,-0.452026 0.835455,-1.57222 0.835455,-1.57222 l 6.03507,2.126063 1.056047,-1.025537 -6.496618,-6.438864 0.883688,-9.623753 16.799383,6.948921 0.461547,-2.906545 -6.354074,-4.307448 0.109254,-3.008361 -1.776828,-1.083222 -0.608121,2.103338 -2.727027,-1.738882 0.337976,-3.132209 -1.375745,-1.158211 -1.689327,2.551609 -3.321597,-3.620931 0.01293,-3.9857346 -1.062159,-4.86699002 -1.125964,-0.70583829 h -0.08889 l -1.125965,0.70583829 -1.060843,4.86699002 0.01153,3.9857346 -3.322291,3.620931 -1.687937,-2.551609 -1.37505,1.158211 0.335961,3.132209 -2.727026,1.738882 -0.6074272,-2.103338 -1.7775233,1.083222 0.1099487,3.008361 -6.35337885,4.307448 0.46015706,2.906545 16.80070259,-6.948921 0.882994,9.623753 -6.497939,6.438864 1.056742,1.025537 6.035765,-2.126063 c -6.9e-5,0 0.935883,1.572915 0.936578,1.57222 z"
  },
  $A400: {
    x: 19,
    y: 20,
    scale: 0.6,
    rotcorr: 0,
    path: "m 10.609151,1051.8941 c 0.02312,-0.2782 0.0821,-0.6315 0.13107,-0.785 0.163705,-0.5133 0.971237,-1.2043 3.955548,-3.3847 1.549628,-1.1321 2.832287,-2.0968 2.850354,-2.1436 0.01807,-0.047 -0.09548,-0.7691 -0.252323,-1.6051 -0.801562,-4.2722 -0.912518,-5.3112 -0.913647,-8.5558 l -8.21e-4,-2.3603 -0.38728,-0.3539 c -0.512042,-0.468 -0.589696,-0.6347 -0.589696,-1.2657 v -0.5202 l -0.26169,0.029 c -0.14393,0.016 -0.889746,0.076 -1.65737,0.1347 -0.767624,0.058 -2.165049,0.1685 -3.105389,0.2444 -0.9403403,0.076 -3.5310712,0.2787 -5.757181,0.4507 -2.2261098,0.172 -4.14953142,0.3268 -4.27427033,0.3441 l -0.22679808,0.031 v -1.0457 c 0,-1.0287 0.002868,-1.0483 0.17632204,-1.2091 0.12223394,-0.1133 1.16225397,-0.4922 3.39036557,-1.2353 2.1568247,-0.7193 3.2353968,-1.1112 3.2789594,-1.1913 0.040411,-0.074 0.03885,-0.2323 -0.00414,-0.4187 -0.084642,-0.3669 -0.091233,-1.8834 -0.00964,-2.2184 0.032722,-0.1343 0.071226,-0.2908 0.085565,-0.3476 0.021026,-0.083 -0.1402442,-0.1224 -0.8332402,-0.2015 -0.4726217,-0.054 -0.8337541,-0.1234 -0.8025161,-0.1545 0.031238,-0.031 0.4257791,-0.079 0.8767582,-0.1055 l 0.8199621,-0.049 v -0.2371 c 0,-0.1558 0.056175,-0.2933 0.1636729,-0.4009 0.3101152,-0.3101 0.6737352,-0.066 0.6737352,0.4525 0,0.1992 0.01096,0.2061 0.3314745,0.2065 0.6760925,9e-4 1.4899725,0.091 1.4238515,0.1563 -0.036172,0.036 -0.4366496,0.096 -0.8899483,0.1316 -0.4532987,0.036 -0.8338619,0.075 -0.8456951,0.088 -0.011834,0.012 0.02915,0.1427 0.091073,0.291 0.091604,0.2192 0.1080329,0.4749 0.088147,1.3715 -0.020974,0.9457 -0.00959,1.1013 0.080234,1.0969 0.057573,0 0.9525514,-0.2933 1.9888437,-0.6455 l 1.884168,-0.6404 0.04411,-0.2786 c 0.02426,-0.1532 0.01175,-0.4966 -0.0278,-0.7632 -0.05857,-0.3946 -0.04908,-0.6057 0.05118,-1.138 0.06771,-0.3595 0.111615,-0.6646 0.09759,-0.6782 -0.01403,-0.014 -0.182522,-0.041 -0.374428,-0.062 -0.951561,-0.1038 -1.154518,-0.1397 -1.099702,-0.1945 0.03273,-0.033 0.395617,-0.081 0.806407,-0.1052 l 0.746894,-0.045 v -0.2337 c 0,-0.2763 0.205173,-0.5127 0.445052,-0.5127 0.212459,0 0.334985,0.1501 0.38741,0.4746 l 0.04168,0.2581 0.848855,0.069 c 0.46687,0.038 0.86584,0.088 0.886601,0.1083 0.02076,0.021 -0.343834,0.077 -0.810208,0.1232 -0.466375,0.046 -0.862941,0.1 -0.881256,0.1181 -0.01831,0.018 0.0031,0.1549 0.04766,0.3035 0.04453,0.1486 0.08097,0.6651 0.08097,1.1478 0,0.4826 0.02983,0.896 0.06631,0.9185 0.03646,0.022 0.509678,-0.1045 1.051576,-0.2823 0.858744,-0.2818 0.994798,-0.347 1.05946,-0.5079 0.171426,-0.4266 0.482992,-1.05 0.64142,-1.2835 l 0.170038,-0.2506 0.02968,-2.9192 c 0.02401,-2.3603 0.05171,-3.023 0.144746,-3.462 0.219266,-1.0345 1.118177,-2.9485 1.72438,-3.6715 0.426425,-0.5086 0.665095,-0.6071 0.91914,-0.3791 0.487951,0.4379 1.125937,1.5326 1.689772,2.8992 0.447479,1.0846 0.477771,1.3582 0.510872,4.6134 l 0.02968,2.9192 0.170037,0.2506 c 0.158428,0.2335 0.469995,0.8569 0.64142,1.2835 0.06467,0.1609 0.200716,0.2261 1.059461,0.5079 0.541898,0.1778 1.015107,0.3048 1.051575,0.2823 0.03647,-0.022 0.06631,-0.4359 0.06631,-0.9185 0,-0.4827 0.03643,-0.9992 0.08097,-1.1478 0.04453,-0.1486 0.06597,-0.2852 0.04766,-0.3035 -0.01831,-0.018 -0.41488,-0.072 -0.881255,-0.1181 -0.466374,-0.046 -0.830968,-0.1021 -0.810208,-0.1232 0.02076,-0.021 0.41973,-0.069 0.886601,-0.1083 l 0.848854,-0.069 0.04168,-0.2581 c 0.05242,-0.3245 0.174952,-0.4746 0.387411,-0.4746 0.239879,0 0.445051,0.2364 0.445051,0.5127 v 0.2337 l 0.746891,0.045 c 0.41079,0.025 0.773674,0.072 0.806407,0.1052 0.05482,0.054 -0.148141,0.091 -1.099702,0.1945 -0.191906,0.021 -0.360399,0.049 -0.374428,0.062 -0.01403,0.014 0.02988,0.3187 0.09759,0.6782 0.100255,0.5323 0.109753,0.7434 0.05118,1.138 -0.03955,0.2666 -0.05206,0.61 -0.0278,0.7632 l 0.04411,0.2786 1.884168,0.6404 c 1.036293,0.3522 1.931273,0.6427 1.988844,0.6455 0.08982,0 0.101208,-0.1512 0.08023,-1.0969 -0.01988,-0.8966 -0.0034,-1.1523 0.08815,-1.3715 0.06192,-0.1483 0.102906,-0.2792 0.09107,-0.291 -0.01183,-0.012 -0.392396,-0.051 -0.845694,-0.088 -0.453299,-0.036 -0.853776,-0.096 -0.889949,-0.1316 -0.06613,-0.066 0.747759,-0.1554 1.423853,-0.1563 0.320513,-4e-4 0.331473,-0.01 0.331473,-0.2065 0,-0.5184 0.363621,-0.7626 0.673735,-0.4525 0.107499,0.1076 0.163673,0.2451 0.163673,0.4009 v 0.2371 l 0.819962,0.049 c 0.45098,0.027 0.845521,0.075 0.876759,0.1055 0.03124,0.031 -0.329895,0.1006 -0.802516,0.1545 -0.692996,0.08 -0.854267,0.1182 -0.833241,0.2015 0.01434,0.056 0.05284,0.2133 0.08556,0.3476 0.08159,0.335 0.075,1.8515 -0.0097,2.2184 -0.04298,0.1864 -0.04454,0.3444 -0.0041,0.4187 0.04357,0.081 1.122134,0.472 3.278959,1.1913 2.228111,0.7431 3.268131,1.122 3.390365,1.2353 0.173459,0.1608 0.176323,0.1804 0.176323,1.2091 v 1.0457 l -0.226798,-0.031 c -0.12474,-0.017 -2.048161,-0.1721 -4.274271,-0.3441 -2.22611,-0.172 -4.816841,-0.3747 -5.757181,-0.4507 -0.940339,-0.076 -2.337764,-0.1859 -3.105388,-0.2444 -0.767624,-0.058 -1.513441,-0.119 -1.65737,-0.1347 l -0.26169,-0.029 v 0.5202 c 0,0.631 -0.07766,0.7977 -0.589696,1.2657 l -0.387283,0.3539 -8.24e-4,2.3603 c -0.0011,3.2446 -0.112085,4.2836 -0.913647,8.5558 -0.156844,0.836 -0.270389,1.5583 -0.252322,1.6051 0.01807,0.046 1.300725,1.0115 2.850353,2.1436 2.984311,2.1804 3.791844,2.8714 3.955547,3.3847 0.120421,0.3775 0.193545,1.291 0.103345,1.291 -0.06512,0 -1.762262,-0.6231 -6.004366,-2.2043 -0.969246,-0.3613 -1.790511,-0.6569 -1.825032,-0.6569 -0.03452,0 -0.129532,0.2198 -0.211138,0.4885 -0.08161,0.2687 -0.177969,0.4884 -0.214141,0.4884 -0.03617,0 -0.132535,-0.2197 -0.21414,-0.4884 -0.08161,-0.2687 -0.176619,-0.4885 -0.211139,-0.4885 -0.03452,0 -0.855785,0.2956 -1.825033,0.6569 -4.242104,1.5812 -5.939249,2.2043 -6.004368,2.2043 -0.04394,0 -0.0542,-0.1872 -0.02772,-0.506 z"
  },
  $B737: {
    x: 20,
    y: 20,
    scale: 0.76,
    rotcorr: 0,
    path: "m 32,4.8 0.3,0.1 0.8,1.2 0.9,3.1 0.6,3.1 0.5,5.2 0,6.9 3.6,2.7 -0.2,-1.5 0,-1.5 0.1,-1.2 0.2,-0.4 2.8,0 0.2,0.4 0.1,1.2 0,1.5 -0.4,2.2 -0.3,0 -0.1,0.9 14,7.7 0.4,0.4 0.2,0.7 0,1.5 -8.3,-2.4 -0.1,0.4 -0.2,0.2 -0.2,-0.2 -0.1,-0.5 -3.7,-1.1 -0.1,0.4 -0.2,0.2 -0.2,-0.2 -0.1,-0.5 -2,-0.6 0,1 -0.1,0.5 -0.1,0.1 -0.4,0 -0.1,-0.1 -0.1,-0.5 0,-1.3 -4.6,0 0,7.7 -0.1,2.8 -0.6,3.7 -0.6,3 0.1,0.4 8.5,5.9 0,1.8 -10,-2.5 -0.2,0.7 -0.1,0.8 -0.1,0.4 -0.1,-0.4 -0.1,-0.8 -0.2,-0.7 -10,2.5 0,-1.8 8.5,-5.9 0.1,-0.4 -0.6,-3 -0.6,-3.7 -0.1,-2.8 0,-7.7 -4.6,0 0,1.3 -0.1,0.5 -0.1,0.1 -0.4,0 -0.1,-0.1 -0.1,-0.5 0,-1 -2,0.6 -0.1,0.5 -0.2,0.2 -0.2,-0.2 -0.1,-0.4 -3.7,1.1 -0.1,0.5 -0.2,0.2 -0.2,-0.2 -0.1,-0.4 -8.3,2.4 0,-1.5 0.2,-0.7 0.4,-0.4 14,-7.7 -0.1,-0.9 -0.3,0 -0.4,-2.2 0,-1.5 0.1,-1.2 0.2,-0.4 2.8,0 0.2,0.4 0.1,1.6 0,1.1 -0.2,1.5 3.6,-2.8 0,-6.8 0.5,-5.2 0.6,-3.1 1,-3.1 0.7,-1.2 z"
  },
  $B747: {
    x: 20,
    y: 20,
    scale: 0.88,
    rotcorr: 0,
    path: "m 20.170952,35.711605 c 0.240955,-0.452026 0.835455,-1.57222 0.835455,-1.57222 l 6.03507,2.126063 1.056047,-1.025537 -6.496618,-6.438864 0.883688,-9.623753 16.799383,6.948921 0.461547,-2.906545 -6.354074,-4.307448 0.109254,-3.008361 -1.776828,-1.083222 -0.608121,2.103338 -2.727027,-1.738882 0.337976,-3.132209 -1.375745,-1.158211 -1.689327,2.551609 -3.321597,-3.620931 0.01293,-3.9857346 -1.062159,-4.86699002 -1.125964,-0.70583829 h -0.08889 l -1.125965,0.70583829 -1.060843,4.86699002 0.01153,3.9857346 -3.322291,3.620931 -1.687937,-2.551609 -1.37505,1.158211 0.335961,3.132209 -2.727026,1.738882 -0.6074272,-2.103338 -1.7775233,1.083222 0.1099487,3.008361 -6.35337885,4.307448 0.46015706,2.906545 16.80070259,-6.948921 0.882994,9.623753 -6.497939,6.438864 1.056742,1.025537 6.035765,-2.126063 c -6.9e-5,0 0.935883,1.572915 0.936578,1.57222 z"
  },
  $B777: {
    x: 20,
    y: 20,
    scale: 0.7,
    rotcorr: 0,
    path: "m 32,0.2 0.1,0 0.2,0.1 0.3,0.3 0.5,0.8 0.7,1.7 0.5,2 0.3,2.5 0,15 0.3,0.6 0.5,0.6 3.3,2.2 -0.2,-1.1 0,-1.6 0.2,-1.4 0.1,-0.2 3,0 0.1,0.2 0.2,1.4 0,1.6 -0.2,1.4 -0.4,0 -0.4,1.3 16.4,10.8 0.2,0.5 0.1,1.5 -9,-3.1 -0.1,0.6 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -4.2,-1.4 -0.1,0.6 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -2.5,-0.8 -1.8,0 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -4.5,0 0,14.9 -0.2,1.9 -0.7,3.8 7.6,6.2 0.1,0.7 0,0.7 -0.1,0.7 -8.5,-3.1 -0.2,0.4 -0.5,1.8 -0.2,0 -0.5,-1.8 -0.2,-0.4 -8.5,3.1 -0.1,-0.7 0,-0.7 0.1,-0.7 7.6,-6.2 -0.7,-3.8 -0.2,-1.9 0,-14.9 -4.5,0 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.7 -1.8,0 -2.5,0.8 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.6 -4.2,1.4 -0.1,0.7 -0.1,0.2 -0.1,-0.2 -0.1,-0.6 -9,3.1 0.1,-1.5 0.2,-0.5 16.4,-10.8 -0.4,-1.3 -0.4,0 -0.2,-1.4 0,-1.6 0.2,-1.4 0.1,-0.2 3,0 0.1,0.2 0.2,1.4 0,1.6 -0.2,1.1 3.3,-2.2 0.5,-0.6 0.3,-0.6 0,-15 0.3,-2.5 0.5,-2 0.7,-1.7 0.5,-0.8 0.3,-0.3 0.2,-0.1 z"
  },
  $B787: {
    x: 20,
    y: 20,
    scale: 0.7,
    rotcorr: 0,
    path: "m 32,0.2 0.1,0 0.4,0.3 0.7,1 0.8,1.9 0.6,2.5 0.2,2.5 0.1,2.7 0,11.4 6.5,4.6 -0.3,-0.8 -0.2,0.3 -0.2,-0.3 -0.2,0.1 -0.1,-0.3 -0.2,-0.9 -0.1,-1.3 0,-1.6 0.1,-1.2 0.1,-0.4 0.2,-0.2 3.2,0 0.2,0.2 0.1,0.4 0.2,1.2 0,1.6 -0.1,1.3 -0.4,1.4 -0.1,-0.3 -0.1,0.3 -0.1,-0.3 -0.2,0.3 -0.2,-0.3 -0.4,1.6 17.5,12.2 0.6,0.6 0.4,0.6 1.2,2 0,1 -1.6,-1.4 -0.7,-0.5 -0.9,-0.5 -7.5,-3.2 -0.1,0.8 -0.2,0.3 -0.3,-0.6 -0.1,-0.8 -3.8,-1.6 -0.1,0.8 -0.2,0.3 -0.3,-0.7 -0.1,-0.7 -3.2,-1.4 -2,0 -0.1,0.7 -0.2,0.4 -0.2,-0.4 -0.1,-0.7 -5.7,0 0,13 -0.1,1.8 -0.1,1.6 -0.5,3.3 0,0.4 0.2,0.4 7,6.4 0.2,0.3 0.1,0.3 0.4,1.3 -9.2,-3.4 -0.7,2.9 -0.4,0 -0.7,-2.9 -9.2,3.4 0.4,-1.3 0.1,-0.3 0.2,-0.3 7,-6.4 0.2,-0.4 0,-0.4 -0.5,-3.3 -0.1,-1.7 -0.1,-1.7 0,-13 -5.7,0 -0.1,0.7 -0.2,0.5 -0.2,-0.5 -0.1,-0.7 -2,0 -3.3,1.4 -0.1,0.6 -0.3,0.6 -0.2,-0.3 -0.1,-0.7 -3.6,1.7 -0.1,0.6 -0.3,0.6 -0.2,-0.3 -0.1,-0.6 -7.6,3.2 -0.9,0.5 -0.7,0.5 -1.6,1.4 0,-1 1.2,-2 0.4,-0.6 0.6,-0.6 17.5,-12.2 -0.4,-1.6 -0.2,0.3 -0.2,-0.3 -0.1,0.3 -0.1,-0.3 -0.1,0.3 -0.3,-1.4 -0.1,-1.3 0,-1.6 0.1,-1.2 0.1,-0.4 0.2,-0.2 3.2,0 0.2,0.2 0.1,0.4 0.1,1.2 0,1.6 -0.1,1.3 -0.2,0.9 -0.1,0.3 -0.2,-0.1 -0.2,0.3 -0.2,-0.3 -0.3,0.8 6.5,-4.6 0,-11.4 0.1,-2.7 0.2,-2.5 0.6,-2.5 0.8,-1.9 0.7,-1 0.4,-0.3 z"
  },
  $F15: {
    x: 20,
    y: 20,
    scale: 0.6,
    rotcorr: 0,
    path: "m 12.720751,1092.038 c -0.356706,-0.4854 -0.956831,-1.7747 -0.956831,-2.0557 0,-0.1857 0.720533,-1.1226 1.769853,-2.3012 1.376792,-1.5465 1.790412,-1.9294 1.862425,-1.7241 0.08054,0.2296 0.135532,0.2093 0.423233,-0.1565 0.241221,-0.3067 0.33122,-0.6296 0.332727,-1.194 0.0011,-0.4255 0.04311,-0.9268 0.09326,-1.114 0.09084,-0.339 0.08419,-0.3403 -1.703598,-0.3387 -1.58712,0 -2.01243,0.063 -3.675647,0.5294 -1.0344685,0.2903 -1.937655,0.5278 -2.0070814,0.5278 -0.069427,0 -0.4651626,-0.5192 -0.8794134,-1.1538 -1.2438223,-1.9054 -1.4867824,-1.4639 3.7086138,-6.7391 l 4.461797,-4.5303 0.0032,-1.3886 c 0.0017,-0.7637 0.105507,-1.831 0.230609,-2.3717 0.125101,-0.5407 0.287534,-1.5392 0.360962,-2.2189 0.200087,-1.8521 0.207282,-1.8648 1.056305,-1.8648 l 0.723159,0 0.08939,-2.609 c 0.08714,-2.5434 0.382385,-4.722 0.978724,-7.2221 0.377706,-1.5834 0.616407,-1.5151 1.056703,0.3025 0.559043,2.3079 0.796043,4.1347 0.897703,6.9196 l 0.09524,2.609 0.723792,0 c 0.398086,0 0.763755,0.065 0.812599,0.1437 0.04884,0.079 0.15182,0.7426 0.228839,1.4747 0.07702,0.732 0.242864,1.7733 0.368547,2.314 0.125685,0.5407 0.230908,1.6421 0.23383,2.4474 l 0.0053,1.4642 4.487005,4.5559 c 3.723507,3.7807 4.487004,4.6278 4.487004,4.9784 0,0.3836 -1.249116,2.6193 -1.576409,2.8216 -0.07257,0.045 -1.00769,-0.1599 -2.078051,-0.455 -1.690712,-0.4661 -2.167461,-0.5365 -3.632827,-0.5365 l -1.686718,0 0,1.1836 c 0,1.0551 0.03957,1.2208 0.364428,1.526 0.326381,0.3066 0.369806,0.3148 0.41593,0.078 0.07357,-0.3771 3.607343,3.609 3.601563,4.0627 -0.0075,0.5848 -0.940546,2.1432 -1.315161,2.1964 -0.184968,0.026 -1.099991,-0.2285 -2.033383,-0.5664 -1.005037,-0.3637 -1.73431,-0.554 -1.788381,-0.4665 -0.05021,0.081 -0.291407,-0.4295 -0.535983,-1.1351 l -0.444682,-1.2828 -1.098381,0 c -0.776638,0 -1.099059,-0.055 -1.100697,-0.1891 -0.0018,-0.1442 -0.02961,-0.1461 -0.117357,-0.01 -0.06425,0.1011 -0.547372,0.2013 -1.094228,0.2269 l -0.979186,0.046 -0.437272,1.26 c -0.2405,0.693 -0.481095,1.1891 -0.534655,1.1024 -0.06232,-0.1008 -0.691537,0.058 -1.747806,0.4416 -1.750261,0.6353 -2.224968,0.7148 -2.448953,0.41 z"
  },
  $F16: {
    x: 20,
    y: 20,
    scale: 0.6,
    rotcorr: 0,
    path: "m 19.808754,1092.7558 c -1.116025,-0.7717 -1.099627,-2.6125 -1.388116,-4.1313 -0.216638,0.15 -0.08738,1.7345 -0.121449,2.4897 0.06919,0.7244 -1.556603,-0.017 -1.097866,1.1613 -1.389019,-0.041 -2.798968,0.1089 -4.17032,-0.1332 -0.974564,-0.2458 -0.988329,-1.8214 -0.53518,-2.4642 1.488914,-1.3497 3.118483,-2.5579 4.488518,-4.0271 0.441692,-1.0582 0.12943,-2.2649 0.21696,-3.3935 -3.198416,0.028 -6.400993,-0.068 -9.5961409,0.071 -1.280678,1.3674 -0.7004539,-1.7519 -0.8334432,-2.5906 0.1178249,-1.2981 -0.2295071,-3.4192 0.2687784,-4.2446 0.3169018,1.1184 0.225064,2.3043 0.3176875,3.4564 2.9753972,-2.3363 5.9022912,-4.7335 8.8488602,-7.1059 0.532037,-3.1529 1.57549,-6.2104 1.845912,-9.4129 0.375408,-3.2796 0.910155,-6.5512 1.94412,-9.6937 1.343724,3.6518 1.820013,7.5296 2.265927,11.3726 0.326638,2.597 1.227203,5.0913 1.632855,7.6615 2.949327,2.3913 5.854498,4.8624 8.859904,7.1922 0.187314,-0.7479 -0.0037,-3.6004 0.445602,-3.149 0.06075,2.284 0.132367,4.5839 -0.0424,6.862 -0.728995,-0.5735 -2.738544,-0.395 -4.011314,-0.4191 -2.060852,-7e-4 -4.121705,-10e-5 -6.182557,-3e-4 0,1.1348 0,2.2696 0,3.4044 1.623901,1.4078 3.247827,2.8156 4.87178,4.2233 0.235392,1.1743 -0.04572,2.6942 -1.637626,2.3754 -1.123707,0.017 -2.247596,0.01 -3.371392,0.01 0.478177,-1.2766 -1.20092,-0.4087 -1.10113,-1.2225 -0.007,-0.8506 -0.01394,-1.7012 -0.02092,-2.5518 -0.274372,1.2026 -0.346042,2.482 -0.681696,3.6392 -1.00129,-0.4434 -0.822888,2.0076 -1.215389,0.615 l 3e-5,0.01 z"
  },
  $TORN: {
    x: 20,
    y: 20,
    scale: 0.6,
    rotcorr: 0,
    path: "m 19.995751,1092.1652 c -0.150693,-1.6016 -0.08058,-3.2198 -0.1722,-4.8281 -1.435177,-0.1548 -2.334768,0.096 -3.593659,0.738 -1.332791,0.2327 -3.388896,1.5828 -4.254408,1.0149 0.06317,-0.8387 -0.330774,-1.8055 0.319992,-2.4951 1.445853,-2.4474 3.173451,-4.7106 4.818235,-7.0248 -0.105269,-0.8498 0.265646,-2.2343 -0.274174,-2.6551 -4.35855,1.0889 -8.6947595,2.265 -13.0469343,3.3791 0.2752673,-1.3096 0.1255747,-3.1776 1.4276044,-3.9076 3.1313154,-1.5014 6.3141929,-2.8943 9.4348289,-4.418 0.614811,-0.8539 1.25511,-1.7693 1.688462,-2.7128 0,-1.3831 0,-2.7663 0,-4.1494 0.562003,-0.076 1.412562,0.1466 1.803279,-0.1059 0.1352,-3.0038 0.118447,-6.077 0.957159,-8.9826 0.617533,-0.9515 0.789054,-2.9963 1.070414,-3.5253 -0.04074,2.0653 1.400169,3.8144 1.448272,5.8878 0.297231,2.2286 0.422099,4.4782 0.392472,6.726 0.56773,0.074 1.42962,-0.1453 1.820515,0.106 0.03689,1.3932 -0.07358,2.8278 0.0551,4.1953 0.572757,0.8578 1.005564,1.8574 1.711527,2.5921 3.292599,1.6264 6.724724,2.9879 9.942281,4.7532 0.473575,1.1145 1.798717,4.4977 -0.657184,3.1357 -3.915085,-0.9914 -7.811706,-2.0571 -11.734415,-3.0171 -0.103419,0.8746 -0.152392,1.8781 -0.02561,2.7464 1.770504,2.4677 3.594992,4.9053 5.11955,7.5368 -0.09209,0.9856 0.456922,3.0211 -1.134027,1.9715 -1.517788,-0.6641 -3.50429,-0.8187 -4.705213,-1.8626 -0.70794,0.3244 -2.325963,-0.4716 -2.008033,0.8149 -0.104053,1.3913 0.04844,2.8071 -0.181626,4.1819 l -0.0934,0.083 -0.1288,-0.1783 -1.9e-5,-2e-4 z"
  },
  $EUFI: {
    x: 20,
    y: 20,
    scale: 0.6,
    rotcorr: 0,
    path: "m 20.049625,0.19319282 c 0.346836,1.81282578 0.951463,3.58610348 1.091119,5.43071318 1.060626,1.1387891 2.380342,2.1611588 3.2809,3.3718727 0.291748,1.2113483 -0.04932,1.5817703 -1.164136,0.9239813 -0.748347,-0.1581792 -2.137578,-1.1703168 -1.684016,0.273009 -0.0054,0.905054 0.971399,1.118925 0.614463,2.246232 0.02479,0.899759 -0.128028,1.861658 0.656311,2.495684 3.225087,4.268534 6.450174,8.537069 9.675261,12.805603 0.228397,-1.106513 0.462564,-1.848707 0.732895,-0.307602 0.05485,1.357252 0.126351,2.778961 -0.03812,4.127018 -0.335386,1.737401 -0.285809,-0.857542 -1.273962,-0.317361 -2.92441,0.196885 -5.84882,0.393769 -8.77323,0.590654 0.461145,1.176313 -0.443713,1.255733 -0.594648,2.073835 -0.283981,0.641309 0.308782,2.236929 -0.62009,2.17629 -1.101382,-0.242451 -1.654134,0.137781 -1.521668,1.29572 -0.109454,0.686238 -0.2329,2.620688 -0.315462,0.907759 -0.287601,-0.676451 0.287171,-2.351265 -0.801459,-2.10037 -1.200269,0.364073 -1.519762,-0.271966 -1.413234,-1.391748 0.302623,-1.11103 -0.684152,-1.367732 -0.766458,-2.203109 0.324271,-1.285981 -1.141784,-0.758377 -1.931002,-0.916403 C 12.713933,31.570233 10.224777,31.465495 7.7356214,31.360757 7.5643096,32.807462 7.2095659,32.413311 7.03419,31.215633 7.0740767,29.604579 6.8725823,27.968632 7.3459376,26.40228 c 0.2070037,0.874599 0.3208355,2.212353 0.9961255,0.75912 3.1751149,-4.267045 6.3502299,-8.534091 9.5253449,-12.801136 0.104216,-1.109643 -0.09944,-2.381426 0.195639,-3.390552 0.772772,-0.336901 0.536273,-2.1860426 -0.482118,-1.3111832 -0.646351,-0.024115 -2.166007,1.2151062 -2.00955,0.029634 -0.282417,-1.0363227 0.99479,-1.4765273 1.507298,-2.2090146 0.585866,-0.6838264 1.468619,-1.2435317 1.879841,-2.0003726 0.02183,-1.788216 0.764573,-3.5298844 1.091107,-5.28558278 z"
  },
  $BEACON: {
    x: 20,
    y: 20,
    scale: 0.1,
    rotcorr: 90,
    path: "M 177,126 L 172,197 L 164,197 L 164,203 L 188,203 C 189,208 194,213 200,213 C 206,217 211,208 212,203 L 236,203 L 236,197 L 228,197 L 223,126 L 177,126 z M 183,133 L 217,133 L 221,197 L 212,197 C 211,191 206,187 200,187 C 194,188 189,192 188,197 L 179,197 L 183,133 z M 200,193 C 204,193 208,196 208,200 C 208,204 204,208 200,208 C 196,208 193,204 193,200 C 193,196 196,193 200,193 z"
  },
  $CAR: {
    x: 0,
    y: 0,
    scale: 2,
    rotcorr: -180,
    path: "M0,1 2,1 2,0 4,0 4,1 8,1 8,0 10,0 10,1 12,1 12,3 9,3 6,5                 2,5 1,3 0,3z"
  },
  // TRUCK from https://icomoon.io/app/#/select
  $TRUCK: {
    x: 12,
    y: 12,
    scale: 0.1,
    rotcorr: -90,
    path: "M315.075 263.385l-14.769-29.538h-22.153v-14.768c0-4.061-3.324-7.385-7.385-7.385h-66.459c-4.061 0-7.385 3.323-7.385 7.385v59.075l7.385 7.385h9.365c-1.258 2.173-1.981 4.693-1.981 7.385 0 8.156 6.613 14.769 14.768 14.769s14.768-6.613 14.768-14.769c0-2.689-0.725-5.212-1.981-7.385h40.883c-1.258 2.173-1.981 4.693-1.981 7.385 0 8.156 6.613 14.769 14.769 14.769s14.769-6.613 14.769-14.769c0-2.689-0.724-5.212-1.981-7.385h9.365v-22.153zM278.153 263.385v-22.153h15.307l11.075 22.153h-26.384z"
  },
  $ALARMCAR: {
    x: 0,
    y: 0,
    scale: 2,
    rotcorr: -90,
    path: "M0,1 2,1 2,0 4,0 4,1 8,1 8,0 10,0 10,1 12,1 12,3 9,3 6,5 6,7 4,7 4,5 3,5 2,5 1,3 0,3z"
  },
  $PARAGLIDER: {
    x: 0,
    y: 0,
    scale: 0.01,
    rotcorr: -90,
    path: "M256.001,0C142.514,0,50.186,92.328,50.186,205.814c0,1.456,0.348,2.892,1.014,4.186l0.798,1.551 c0.154,0.3,0.325,0.591,0.511,0.871l195.784,295.246c1.009,1.62,2.487,2.87,4.227,3.598c0.121,0.051,0.239,0.105,0.362,0.15 c0.233,0.085,0.469,0.16,0.708,0.227c0.195,0.055,0.393,0.101,0.593,0.143c0.201,0.042,0.4,0.085,0.605,0.115 c0.369,0.052,0.743,0.082,1.12,0.089c0.045,0,0.088,0.011,0.132,0.011c0.005,0,0.011-0.001,0.016-0.001 c0.006,0,0.013,0.001,0.02,0.001c0.001,0,0.002,0,0.004,0c0.454,0,0.9-0.044,1.342-0.11c0.071-0.011,0.14-0.027,0.211-0.04 c0.395-0.068,0.782-0.162,1.162-0.281c0.051-0.016,0.102-0.032,0.154-0.049c1.922-0.637,3.612-1.888,4.758-3.621l196.589-297.036 c0.992-1.498,1.52-3.254,1.52-5.05C461.815,92.328,369.487,0,256.001,0z M223.634,31.592c7.533-6.373,15.31-10.463,23.214-12.248 v167.661c-11.956-7.188-25.667-11.035-40.013-11.036c-14.159,0-27.701,3.751-39.547,10.758 c2.145-43.896,11.669-84.492,27.365-115.884C203.126,53.897,212.877,40.692,223.634,31.592z M203.086,25.917 c-9.085,9.706-17.437,22.011-24.802,36.742c-16.977,33.953-27.201,77.647-29.339,124.599 c-12.055-7.354-25.924-11.289-40.442-11.289c-13.945,0-27.288,3.643-39.004,10.448C77.388,109.991,131.362,47.049,203.086,25.917z M71.159,207.431c10.547-8.521,23.563-13.16,37.344-13.16c15.119,0,29.327,5.569,40.352,15.74l-0.804,0.27l77.087,229.355 L71.159,207.431z M246.85,446.784l-79.761-237.309c10.939-9.825,24.899-15.204,39.746-15.204c14.966,0,29.037,5.464,40.014,15.442 V446.784z M265.15,19.344c7.905,1.785,15.682,5.875,23.216,12.248c10.757,9.1,20.508,22.305,28.981,39.251 c15.696,31.393,25.225,71.99,27.369,115.886c-11.845-7.008-25.389-10.759-39.55-10.76c-14.346,0-28.06,3.848-40.016,11.036V19.344 z M265.15,209.714c10.978-9.978,25.047-15.442,40.016-15.442c14.847,0,28.809,5.381,39.747,15.205L265.15,446.974V209.714z M286.903,439.69l77.046-229.408l-0.804-0.27c11.025-10.172,25.234-15.74,40.352-15.74c13.718,0,26.678,4.597,37.201,13.044 L286.903,439.69z M403.497,175.969c-14.516,0-28.387,3.935-40.442,11.289c-2.138-46.952-12.362-90.647-29.339-124.599 c-7.366-14.733-15.721-27.036-24.809-36.743c71.728,21.13,125.705,84.075,133.596,160.502 C430.786,179.612,417.442,175.969,403.497,175.969z"
  }
};
let $s = [
  { id: "A109", sym: "$7" },
  { id: "A119", sym: "$7" },
  { id: "A124", sym: "$5" },
  { id: "A129", sym: "$7" },
  { id: "A139", sym: "$7" },
  { id: "A149", sym: "$7" },
  { id: "A169", sym: "$7" },
  { id: "A2RT", sym: "$7" },
  { id: "A30", sym: "$4" },
  { id: "A31", sym: "$A320" },
  { id: "A32", sym: "$A320" },
  { id: "A33", sym: "$A330" },
  { id: "A35", sym: "$A330" },
  { id: "A34", sym: "$A340" },
  { id: "A38", sym: "$B747" },
  { id: "A400", sym: "$A400" },
  { id: "A3ST", sym: "$A330" },
  { id: "AA5", sym: "$1" },
  { id: "AC11", sym: "$1" },
  { id: "AJET", sym: "$6" },
  { id: "ALH", sym: "$7" },
  { id: "ALO2", sym: "$7" },
  { id: "ALO3", sym: "$7" },
  { id: "AN12", sym: "$C" },
  { id: "AN24", sym: "$B" },
  { id: "AN26", sym: "$9" },
  { id: "ANST", sym: "$7" },
  { id: "AS32", sym: "$7" },
  { id: "AS3B", sym: "$7" },
  { id: "AS50", sym: "$7" },
  { id: "AS55", sym: "$7" },
  { id: "AS65", sym: "$7" },
  { id: "AT4", sym: "$D" },
  { id: "AT7", sym: "$D" },
  { id: "ATP", sym: "$D" },
  { id: "B06", sym: "$7" },
  { id: "B06T", sym: "$7" },
  { id: "B105", sym: "$7" },
  { id: "B190", sym: "$2" },
  { id: "B212", sym: "$7" },
  { id: "B214", sym: "$7" },
  { id: "B222", sym: "$7" },
  { id: "B230", sym: "$7" },
  { id: "B305", sym: "$7" },
  { id: "B350", sym: "$2" },
  { id: "B407", sym: "$7" },
  { id: "B412", sym: "$7" },
  { id: "B427", sym: "$7" },
  { id: "B429", sym: "$7" },
  { id: "B430", sym: "$7" },
  { id: "B461", sym: "$9" },
  { id: "B462", sym: "$9" },
  { id: "B463", sym: "$9" },
  { id: "B47G", sym: "$7" },
  { id: "B47J", sym: "$7" },
  { id: "B47T", sym: "$7" },
  { id: "B70", sym: "$5" },
  { id: "B712", sym: "$3" },
  { id: "B72", sym: "$3" },
  { id: "B720", sym: "$5" },
  { id: "B73", sym: "$B737" },
  { id: "B74", sym: "$B747" },
  { id: "B75", sym: "$4" },
  { id: "B76", sym: "$4" },
  { id: "B77", sym: "$B777" },
  { id: "B78", sym: "$B787" },
  { id: "BA11", sym: "$3" },
  { id: "BABY", sym: "$7" },
  { id: "BDOG", sym: "$1" },
  { id: "BE19", sym: "$2" },
  { id: "BE20", sym: "$2" },
  { id: "BE33", sym: "$1" },
  { id: "BE36", sym: "$1" },
  { id: "BE40", sym: "$8" },
  { id: "BE58", sym: "$2" },
  { id: "BE9", sym: "$2" },
  { id: "BK17", sym: "$7" },
  { id: "BLCF", sym: "$5" },
  { id: "BN2P", sym: "$D" },
  { id: "BN2T", sym: "$D" },
  { id: "BRB2", sym: "$7" },
  { id: "BREZ", sym: "$1" },
  { id: "BSTP", sym: "$7" },
  { id: "C120", sym: "$1" },
  { id: "C130", sym: "$2" },
  { id: "C140", sym: "$1" },
  { id: "C150", sym: "$1" },
  { id: "C152", sym: "$1" },
  { id: "C160", sym: "$B" },
  { id: "C17", sym: "$5" },
  { id: "C172", sym: "$1" },
  { id: "C180", sym: "$1" },
  { id: "C182", sym: "$1" },
  { id: "C190", sym: "$1" },
  { id: "C208", sym: "$1" },
  { id: "C25A", sym: "$8" },
  { id: "C25B", sym: "$8" },
  { id: "C25C", sym: "$8" },
  { id: "C303", sym: "$2" },
  { id: "C30J", sym: "$C" },
  { id: "C310", sym: "$2" },
  { id: "C402", sym: "$2" },
  { id: "C404", sym: "$2" },
  { id: "C42", sym: "$1" },
  { id: "C421", sym: "$2" },
  { id: "C425", sym: "$2" },
  { id: "C5", sym: "$5" },
  { id: "C55B", sym: "$3" },
  { id: "C500", sym: "$8" },
  { id: "C501", sym: "$8" },
  { id: "C51", sym: "$8" },
  { id: "C525", sym: "$8" },
  { id: "C550", sym: "$8" },
  { id: "C560", sym: "$8" },
  { id: "C56X", sym: "$8" },
  { id: "C650", sym: "$8" },
  { id: "C680", sym: "$8" },
  { id: "C72", sym: "$1" },
  { id: "C750", sym: "$8" },
  { id: "C77R", sym: "$1" },
  { id: "C90", sym: "$2" },
  { id: "CH7", sym: "$7" },
  { id: "CHIF", sym: "$7" },
  { id: "CL30", sym: "$8" },
  { id: "CL60", sym: "$8" },
  { id: "CL61", sym: "$8" },
  { id: "CL64", sym: "$8" },
  { id: "CL65", sym: "$8" },
  { id: "CN35", sym: "$B" },
  { id: "COMU", sym: "$7" },
  { id: "CRJ1", sym: "$3" },
  { id: "CRJ2", sym: "$3" },
  { id: "CRJ7", sym: "$3" },
  { id: "CRJ9", sym: "$3" },
  { id: "CRUZ", sym: "$1" },
  { id: "D11", sym: "$1" },
  { id: "D228", sym: "$D" },
  { id: "D28", sym: "$D" },
  { id: "D328", sym: "$D" },
  { id: "DA40", sym: "$1" },
  { id: "DA42", sym: "$2" },
  { id: "DC10", sym: "$4" },
  { id: "DC8", sym: "$5" },
  { id: "DC9", sym: "$3" },
  { id: "DH8A", sym: "$D" },
  { id: "DH8B", sym: "$D" },
  { id: "DH8C", sym: "$D" },
  { id: "DH8D", sym: "$D" },
  { id: "DHC1", sym: "$1" },
  { id: "DHC6", sym: "$2" },
  { id: "DHC7", sym: "$D" },
  { id: "DHC8", sym: "$D" },
  { id: "DJIN", sym: "$7" },
  { id: "DOVE", sym: "$2" },
  { id: "DR10", sym: "$1" },
  { id: "DR22", sym: "$1" },
  { id: "DR30", sym: "$1" },
  { id: "DR40", sym: "$1" },
  { id: "DRAG", sym: "$7" },
  { id: "DYH2", sym: "$7" },
  { id: "E110", sym: "$2" },
  { id: "E120", sym: "$2" },
  { id: "E121", sym: "$2" },
  { id: "E135", sym: "$3" },
  { id: "E145", sym: "$3" },
  { id: "E170", sym: "$4" },
  { id: "E175", sym: "$4" },
  { id: "E190", sym: "$4" },
  { id: "E195", sym: "$4" },
  { id: "E300", sym: "$1" },
  { id: "E35", sym: "$3" },
  // { id: "E3CF", sym: "$AWACS" },
  // { id: "E3TF", sym: "$AWACS" },
  { id: "E400", sym: "$1" },
  { id: "E50P", sym: "$8" },
  { id: "E55P", sym: "$8" },
  // { id: "E6", sym: "$AWACS" },
  { id: "E75S", sym: "$4" },
  { id: "EA50", sym: "$8" },
  { id: "EA55", sym: "$8" },
  { id: "EC20", sym: "$7" },
  { id: "EC25", sym: "$7" },
  { id: "EC30", sym: "$7" },
  { id: "EC35", sym: "$7" },
  { id: "EC45", sym: "$7" },
  { id: "EC55", sym: "$7" },
  { id: "EH10", sym: "$E" },
  { id: "ELTO", sym: "$7" },
  { id: "EN28", sym: "$7" },
  { id: "EN48", sym: "$7" },
  { id: "ES11", sym: "$7" },
  // { id: "EUFI", sym: "$EUFI" },
  { id: "EUPA", sym: "$1" },
  { id: "EXEC", sym: "$7" },
  { id: "EXEJ", sym: "$7" },
  { id: "EXPL", sym: "$7" },
  { id: "F100", sym: "$3" },
  // { id: "F15", sym: "$F15" },
  // { id: "F15E", sym: "$F15" },
  // { id: "F16", sym: "$F16" },
  { id: "F27", sym: "$D" },
  { id: "F2EX", sym: "$8" },
  { id: "F2TH", sym: "$8" },
  { id: "F406", sym: "$2" },
  { id: "F50", sym: "$D" },
  { id: "F70", sym: "$3" },
  { id: "F900", sym: "$8" },
  { id: "FA10", sym: "$8" },
  { id: "FA20", sym: "$8" },
  { id: "FA50", sym: "$8" },
  { id: "FA7", sym: "$8" },
  { id: "FDCT", sym: "$1" },
  { id: "FH11", sym: "$7" },
  { id: "FREL", sym: "$7" },
  { id: "G109", sym: "$1" },
  { id: "G115", sym: "$1" },
  { id: "G120", sym: "$1" },
  { id: "G150", sym: "$8" },
  { id: "G200", sym: "$8" },
  { id: "G280", sym: "$8" },
  { id: "G2CA", sym: "$7" },
  { id: "G450", sym: "$8" },
  { id: "G550", sym: "$8" },
  { id: "G650", sym: "$8" },
  { id: "GA8", sym: "$1" },
  { id: "GRND", sym: "$0" },
  { id: "GALX", sym: "$8" },
  { id: "GAZL", sym: "$7" },
  { id: "GL5T", sym: "$8" },
  { id: "GLEX", sym: "$8" },
  { id: "GLF", sym: "$8" },
  { id: "GZLE", sym: "$7" },
  { id: "H12T", sym: "$7" },
  { id: "H160", sym: "$7" },
  { id: "H2", sym: "$7" },
  { id: "H21", sym: "$7" },
  { id: "H25", sym: "$8" },
  { id: "H269", sym: "$7" },
  { id: "H43A", sym: "$7" },
  { id: "H43B", sym: "$7" },
  { id: "H46", sym: "$E" },
  { id: "H47", sym: "$E" },
  { id: "H500", sym: "$7" },
  { id: "H53", sym: "$E" },
  { id: "H60", sym: "$E" },
  { id: "H64", sym: "$7" },
  { id: "H750", sym: "$8" },
  { id: "H900", sym: "$3" },
  { id: "HA4T", sym: "$8" },
  { id: "HAWK", sym: "$6" },
  { id: "HMNY", sym: "$1" },
  { id: "HUCO", sym: "$7" },
  { id: "HUNT", sym: "$6" },
  { id: "HURI", sym: "$1" },
  { id: "HX2", sym: "$7" },
  { id: "IL76", sym: "$5" },
  { id: "IL96", sym: "$5" },
  { id: "IS2", sym: "$7" },
  { id: "J328", sym: "$D" },
  { id: "JAB4", sym: "$1" },
  { id: "JAG2", sym: "$7" },
  { id: "JPRO", sym: "$6" },
  { id: "JS31", sym: "$2" },
  { id: "JS32", sym: "$2" },
  { id: "JS41", sym: "$2" },
  { id: "JS42", sym: "$2" },
  { id: "K126", sym: "$7" },
  { id: "K226", sym: "$7" },
  { id: "K35", sym: "$5" },
  { id: "KA25", sym: "$7" },
  { id: "KA26", sym: "$7" },
  { id: "KA27", sym: "$7" },
  { id: "KA50", sym: "$7" },
  { id: "KA52", sym: "$7" },
  { id: "KA62", sym: "$7" },
  { id: "KC10", sym: "$4" },
  { id: "KH4", sym: "$7" },
  { id: "KMAX", sym: "$7" },
  { id: "L101", sym: "$4" },
  { id: "L410", sym: "$2" },
  { id: "LAMA", sym: "$7" },
  { id: "LANC", sym: "$C" },
  { id: "LJ25", sym: "$8" },
  { id: "LJ31", sym: "$8" },
  { id: "LJ35", sym: "$8" },
  { id: "LJ36", sym: "$8" },
  { id: "LJ40", sym: "$8" },
  { id: "LJ45", sym: "$8" },
  { id: "LJ55", sym: "$8" },
  { id: "LJ60", sym: "$8" },
  { id: "LR2T", sym: "$7" },
  { id: "LYNX", sym: "$7" },
  { id: "M20", sym: "$1" },
  { id: "M74", sym: "$7" },
  { id: "MD11", sym: "$4" },
  { id: "MD52", sym: "$7" },
  { id: "MD60", sym: "$7" },
  { id: "MD81", sym: "$3" },
  { id: "MD82", sym: "$3" },
  { id: "MD83", sym: "$3" },
  { id: "MD87", sym: "$3" },
  { id: "MD88", sym: "$3" },
  { id: "MD90", sym: "$3" },
  { id: "MH20", sym: "$7" },
  { id: "MI10", sym: "$7" },
  { id: "MI14", sym: "$7" },
  { id: "MI2", sym: "$7" },
  { id: "MI24", sym: "$7" },
  { id: "MI26", sym: "$7" },
  { id: "MI28", sym: "$7" },
  { id: "MI34", sym: "$7" },
  { id: "MI38", sym: "$7" },
  { id: "MI4", sym: "$7" },
  { id: "MI6", sym: "$7" },
  { id: "MI8", sym: "$7" },
  { id: "NA40", sym: "$7" },
  { id: "NH90", sym: "$7" },
  { id: "OH1", sym: "$7" },
  { id: "P180", sym: "$2" },
  { id: "P210", sym: "$1" },
  { id: "P28A", sym: "$1" },
  { id: "P28R", sym: "$1" },
  { id: "P28T", sym: "$1" },
  { id: "P32R", sym: "$1" },
  { id: "P46T", sym: "$1" },
  { id: "P68", sym: "$2" },
  { id: "P750", sym: "$1" },
  { id: "PA18", sym: "$1" },
  { id: "PA22", sym: "$1" },
  { id: "PA23", sym: "$2" },
  { id: "PA24", sym: "$1" },
  { id: "PA27", sym: "$2" },
  { id: "PA28", sym: "$1" },
  { id: "PA3", sym: "$2" },
  { id: "PA4", sym: "$2" },
  { id: "PAY3", sym: "$2" },
  { id: "PC12", sym: "$1" },
  { id: "PC6T", sym: "$1" },
  { id: "PHIL", sym: "$7" },
  { id: "PNR3", sym: "$1" },
  { id: "PREM", sym: "$8" },
  { id: "PRM1", sym: "$8" },
  { id: "PSW4", sym: "$7" },
  { id: "PTS1", sym: "$1" },
  { id: "PTS2", sym: "$1" },
  { id: "PUMA", sym: "$E" },
  { id: "PUP", sym: "$1" },
  { id: "R13", sym: "$5" },
  { id: "R200", sym: "$1" },
  { id: "R22", sym: "$7" },
  { id: "R300", sym: "$1" },
  { id: "R4", sym: "$7" },
  { id: "R44", sym: "$7" },
  { id: "R5", sym: "$1" },
  { id: "R66", sym: "$7" },
  { id: "RALL", sym: "$1" },
  { id: "RJ1H", sym: "$9" },
  { id: "RJ70", sym: "$9" },
  { id: "RJ85", sym: "$9" },
  { id: "RMOU", sym: "$7" },
  { id: "RP1", sym: "$7" },
  { id: "RV", sym: "$1" },
  { id: "RVAL", sym: "$7" },
  { id: "S22", sym: "$1" },
  { id: "S274", sym: "$7" },
  { id: "S278", sym: "$7" },
  { id: "S330", sym: "$7" },
  { id: "S360", sym: "$7" },
  { id: "S51", sym: "$7" },
  { id: "S52", sym: "$7" },
  { id: "S55P", sym: "$7" },
  { id: "S55T", sym: "$7" },
  { id: "S58P", sym: "$7" },
  { id: "S58T", sym: "$7" },
  { id: "S61", sym: "$E" },
  { id: "S61R", sym: "$E" },
  { id: "S62", sym: "$E" },
  { id: "S64", sym: "$E" },
  { id: "S65C", sym: "$E" },
  { id: "S76", sym: "$7" },
  { id: "S92", sym: "$7" },
  { id: "S92", sym: "$E" },
  { id: "SB20", sym: "$D" },
  { id: "SCOR", sym: "$7" },
  { id: "SCOU", sym: "$7" },
  { id: "SF34", sym: "$2" },
  { id: "SH36", sym: "$2" },
  { id: "SH4", sym: "$7" },
  { id: "SIRA", sym: "$1" },
  // { id: "SOL2", sym: "$SI2" },
  { id: "SPIT", sym: "$1" },
  { id: "SR20", sym: "$1" },
  { id: "SR22", sym: "$1" },
  { id: "SUBA", sym: "$1" },
  { id: "SUCO", sym: "$7" },
  { id: "SW3", sym: "$2" },
  { id: "SW4", sym: "$2" },
  { id: "SYCA", sym: "$7" },
  { id: "T134", sym: "$3" },
  { id: "T154", sym: "$3" },
  { id: "T204", sym: "$4" },
  { id: "TAMP", sym: "$1" },
  { id: "TBM7", sym: "$1" },
  { id: "TBM8", sym: "$1" },
  { id: "TBM9", sym: "$2" },
  { id: "TEX2", sym: "$1" },
  { id: "TIGR", sym: "$7" },
  { id: "TL20", sym: "$1" },
  { id: "TOBA", sym: "$1" },
  // { id: "TOR", sym: "$TORN" },
  // { id: "TORN", sym: "$TORN" },
  { id: "TRIN", sym: "$1" },
  { id: "TUCA", sym: "$1" },
  { id: "UH1", sym: "$7" },
  { id: "UH12", sym: "$7" },
  { id: "UH1Y", sym: "$7" },
  { id: "ULTS", sym: "$7" },
  { id: "V22", sym: "$A" },
  { id: "V500", sym: "$7" },
  { id: "W3", sym: "$7" },
  { id: "WASP", sym: "$7" },
  { id: "WESX", sym: "$7" },
  { id: "WG30", sym: "$7" },
  { id: "X2", sym: "$7" },
  { id: "X49", sym: "$7" },
  { id: "YK40", sym: "$3" },
  { id: "YK42", sym: "$3" },
  { id: "YK50", sym: "$1" },
  { id: "YK52", sym: "$1" },
  { id: "YNHL", sym: "$7" },
  { id: "ZA6", sym: "$7" }
];
function Ka(i, t) {
  const e = i.id, s = t.id;
  return e < s ? 1 : e > s ? -1 : 0;
}
$s = $s.sort(Ka);
function Ks(i) {
  let t = {};
  if (Object.assign(t, kt.$A320), i != null)
    for (let e = 0; e < $s.length; e++) {
      const s = $s[e];
      if (i.indexOf(s.id) == 0)
        return t = {}, Object.assign(t, kt[s.sym]), t;
    }
  return t;
}
(function() {
  kt.$PARAGLIDER.scale = 0.05, kt.$BEACON.scale = 0.2, kt.$E.scale = 0.95, kt.$SF25.scale = 1.5, kt.$SI2.scale = 0.78, kt.$AWACS.scale = 0.68, kt.$A320.scale = 0.6, kt.$A330.scale = 0.53, kt.$A340.scale = 0.58, kt.$A380.scale = 0.6, kt.$B737.scale = 0.61, kt.$B747.scale = 0.9, kt.$B777.scale = 0.6, kt.$B787.scale = 0.58, kt.$F15.scale = 0.53, kt.$0.ofY = 2, kt.$1.ofX = 0, kt.$2.ofY = -1.5, kt.$2.ofX = 0.2, kt.$3.ofX = -1.15, kt.$4.ofX = 0.1, kt.$5.ofX = -0, kt.$A.ofX = -0.2, kt.$A2.ofX = -0.6, kt.$B.ofX = -0.6, kt.$AWACS.ofX = -1.2, kt.$SF25.ofX = -1.1, kt.$SF25.ofY = 1.2, kt.$SI2.ofX = -0.3, kt.$SI2.ofY = 3.7, kt.$A320.ofY = -0.9, kt.$A320.ofX = -0.4, kt.$A330.ofY = -1, kt.$A330.ofX = -1.1, kt.$A340.ofY = -0.5, kt.$A340.ofX = -0.3, kt.$A380.ofX = -0.2, kt.$A400.ofX = -1.05, kt.$B737.ofY = -0.9, kt.$B737.ofX = -0.4, kt.$F15.ofX = -0.25;
})();
const Ja = { class: "tooltip-grid" }, Za = { class: "callsign" }, Qa = { class: "typecode" }, tl = { class: "registration" }, el = { class: "icao24" }, il = {
  key: 0,
  class: "altitude"
}, sl = /* @__PURE__ */ De({
  __name: "AircraftLayer",
  setup(i) {
    const t = ti("tangramApi");
    if (!t)
      throw new Error("assert: tangram api not provided");
    const e = Fe(
      () => t.state.getEntitiesByType("jet1090_aircraft").value
    ), s = Fe(() => t.state.activeEntity.value), n = Ce(null), o = Ce(null), r = $i({ x: 0, y: 0, object: null }), a = /* @__PURE__ */ new Map(), l = (f, x) => {
      const b = `${f}-${x}`;
      if (a.has(b))
        return a.get(b);
      const k = Ks(f), T = qs.pathBBox(k.path), C = Math.floor(T.x + T.width / 2), A = Math.floor(T.y + T.height / 2), P = k.ofX || 0, z = k.ofY || 0, O = `T${-1 * C + P},${-1 * A + z}S${k.scale * 0.7}`, W = qs.mapPath(
        k.path,
        qs.toMatrix(k.path, O)
      ), Y = ja`<path stroke="#0014aa" fill="${x ? "#ff6464" : "#f9fd15"}" stroke-width="0.65" d="${W}"/>`, B = Na`<svg
    version="1.1"
    shape-rendering="geometricPrecision"
    width="64px"
    height="64px"
    viewBox="-16 -16 32 32"
    xmlns="http://www.w3.org/2000/svg"
  >
    ${Y}
  </svg>`, H = document.createElement("div");
      Wa(B, H);
      const it = H.innerHTML, ct = `data:image/svg+xml;base64,${btoa(it)}`;
      return a.set(b, ct), ct;
    }, d = {
      pickable: !0,
      billboard: !1,
      sizeScale: 1,
      getSize: 32,
      onClick: (f) => {
        f.object && t.state.setActiveEntity(f.object);
      },
      onHover: (f) => {
        f.object ? (r.object = f.object, r.x = f.x, r.y = f.y) : r.object = null;
      }
    };
    return ee(
      [e, s, () => t.map.isReady.value],
      ([f, x, b]) => {
        if (!f || !b) return;
        const k = Array.from(f.values()), T = x?.id, C = T ? k.filter((R) => R.id !== T) : k, A = T ? k.filter((R) => R.id === T) : [], P = new so({
          ...d,
          id: "aircraft-layer-base",
          data: C,
          getIcon: (R) => ({
            url: l(R.state.typecode, !1),
            width: 64,
            height: 64,
            anchorY: 32
          }),
          getPosition: (R) => [R.state.longitude, R.state.latitude],
          getAngle: (R) => {
            const Y = Ks(R.state.typecode);
            return -R.state.track + Y.rotcorr;
          }
          // no updateTriggers needed, icon depends only on typecode which is stable.
        }), z = new so({
          ...d,
          id: "aircraft-layer-selected",
          data: A,
          getIcon: (R) => ({
            url: l(R.state.typecode, !0),
            width: 64,
            height: 64,
            anchorY: 32
          }),
          getPosition: (R) => [R.state.longitude, R.state.latitude],
          getAngle: (R) => {
            const Y = Ks(R.state.typecode);
            return -R.state.track + Y.rotcorr;
          }
        }), O = t.map.setLayer(P);
        n.value || (n.value = O);
        const W = t.map.setLayer(z);
        o.value || (o.value = W);
      },
      { immediate: !0 }
    ), Zi(() => {
      n.value?.dispose(), o.value?.dispose();
    }), (f, x) => r.object ? (ne(), ae("div", {
      key: 0,
      class: "deck-tooltip",
      style: $r({ left: `${r.x}px`, top: `${r.y}px` })
    }, [
      Bt("div", Ja, [
        Bt("div", Za, Nt(r.object.state.callsign), 1),
        Bt("div", Qa, Nt(r.object.state.typecode), 1),
        Bt("div", tl, Nt(r.object.state.registration), 1),
        Bt("div", el, Nt(r.object.state.icao24), 1),
        r.object.state.altitude > 0 ? (ne(), ae("div", il, " FL" + Nt(Math.round(r.object.state.altitude / 1e3) * 10), 1)) : be("", !0)
      ])
    ], 4)) : be("", !0);
  }
}), nl = { class: "aircraft-count-widget" }, ol = { class: "count-display" }, rl = { id: "visible_count" }, al = { id: "plane_count" }, ll = /* @__PURE__ */ De({
  __name: "AircraftCountWidget",
  setup(i) {
    const t = ti("tangramApi");
    if (!t)
      throw new Error("assert: tangram api not provided");
    const e = Fe(
      () => t.state.totalCounts.value?.get("jet1090_aircraft") ?? 0
    ), s = Fe(
      () => t.state.getEntitiesByType("jet1090_aircraft").value?.size ?? 0
    );
    return (n, o) => (ne(), ae("div", nl, [
      Bt("div", ol, [
        Bt("span", rl, Nt(s.value), 1),
        o[0] || (o[0] = cn(" (", -1)),
        Bt("span", al, Nt(e.value ?? 0), 1),
        o[1] || (o[1] = cn(") ", -1))
      ]),
      o[2] || (o[2] = Bt("span", { id: "count_aircraft" }, "visible aircraft", -1))
    ]));
  }
}), wn = (i, t) => {
  const e = i.__vccOpts || i;
  for (const [s, n] of t)
    e[s] = n;
  return e;
}, cl = /* @__PURE__ */ wn(ll, [["__scopeId", "data-v-ec0d257f"]]), mt = $i({
  icao24: null,
  trajectory: [],
  loading: !1,
  error: null,
  route: {
    origin: null,
    destination: null
  }
}), un = $i({
  showRouteLines: !0
});
function Qi(i) {
  return i + 0.5 | 0;
}
const Ie = (i, t, e) => Math.max(Math.min(i, e), t);
function Fi(i) {
  return Ie(Qi(i * 2.55), 0, 255);
}
function ze(i) {
  return Ie(Qi(i * 255), 0, 255);
}
function Se(i) {
  return Ie(Qi(i / 2.55) / 100, 0, 1);
}
function ro(i) {
  return Ie(Qi(i * 100), 0, 100);
}
const re = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, A: 10, B: 11, C: 12, D: 13, E: 14, F: 15, a: 10, b: 11, c: 12, d: 13, e: 14, f: 15 }, fn = [..."0123456789ABCDEF"], hl = (i) => fn[i & 15], dl = (i) => fn[(i & 240) >> 4] + fn[i & 15], as = (i) => (i & 240) >> 4 === (i & 15), ul = (i) => as(i.r) && as(i.g) && as(i.b) && as(i.a);
function fl(i) {
  var t = i.length, e;
  return i[0] === "#" && (t === 4 || t === 5 ? e = {
    r: 255 & re[i[1]] * 17,
    g: 255 & re[i[2]] * 17,
    b: 255 & re[i[3]] * 17,
    a: t === 5 ? re[i[4]] * 17 : 255
  } : (t === 7 || t === 9) && (e = {
    r: re[i[1]] << 4 | re[i[2]],
    g: re[i[3]] << 4 | re[i[4]],
    b: re[i[5]] << 4 | re[i[6]],
    a: t === 9 ? re[i[7]] << 4 | re[i[8]] : 255
  })), e;
}
const pl = (i, t) => i < 255 ? t(i) : "";
function gl(i) {
  var t = ul(i) ? hl : dl;
  return i ? "#" + t(i.r) + t(i.g) + t(i.b) + pl(i.a, t) : void 0;
}
const ml = /^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;
function Ar(i, t, e) {
  const s = t * Math.min(e, 1 - e), n = (o, r = (o + i / 30) % 12) => e - s * Math.max(Math.min(r - 3, 9 - r, 1), -1);
  return [n(0), n(8), n(4)];
}
function yl(i, t, e) {
  const s = (n, o = (n + i / 60) % 6) => e - e * t * Math.max(Math.min(o, 4 - o, 1), 0);
  return [s(5), s(3), s(1)];
}
function xl(i, t, e) {
  const s = Ar(i, 1, 0.5);
  let n;
  for (t + e > 1 && (n = 1 / (t + e), t *= n, e *= n), n = 0; n < 3; n++)
    s[n] *= 1 - t - e, s[n] += t;
  return s;
}
function bl(i, t, e, s, n) {
  return i === n ? (t - e) / s + (t < e ? 6 : 0) : t === n ? (e - i) / s + 2 : (i - t) / s + 4;
}
function kn(i) {
  const e = i.r / 255, s = i.g / 255, n = i.b / 255, o = Math.max(e, s, n), r = Math.min(e, s, n), a = (o + r) / 2;
  let l, d, f;
  return o !== r && (f = o - r, d = a > 0.5 ? f / (2 - o - r) : f / (o + r), l = bl(e, s, n, f, o), l = l * 60 + 0.5), [l | 0, d || 0, a];
}
function $n(i, t, e, s) {
  return (Array.isArray(t) ? i(t[0], t[1], t[2]) : i(t, e, s)).map(ze);
}
function Mn(i, t, e) {
  return $n(Ar, i, t, e);
}
function _l(i, t, e) {
  return $n(xl, i, t, e);
}
function vl(i, t, e) {
  return $n(yl, i, t, e);
}
function Pr(i) {
  return (i % 360 + 360) % 360;
}
function wl(i) {
  const t = ml.exec(i);
  let e = 255, s;
  if (!t)
    return;
  t[5] !== s && (e = t[6] ? Fi(+t[5]) : ze(+t[5]));
  const n = Pr(+t[2]), o = +t[3] / 100, r = +t[4] / 100;
  return t[1] === "hwb" ? s = _l(n, o, r) : t[1] === "hsv" ? s = vl(n, o, r) : s = Mn(n, o, r), {
    r: s[0],
    g: s[1],
    b: s[2],
    a: e
  };
}
function kl(i, t) {
  var e = kn(i);
  e[0] = Pr(e[0] + t), e = Mn(e), i.r = e[0], i.g = e[1], i.b = e[2];
}
function $l(i) {
  if (!i)
    return;
  const t = kn(i), e = t[0], s = ro(t[1]), n = ro(t[2]);
  return i.a < 255 ? `hsla(${e}, ${s}%, ${n}%, ${Se(i.a)})` : `hsl(${e}, ${s}%, ${n}%)`;
}
const ao = {
  x: "dark",
  Z: "light",
  Y: "re",
  X: "blu",
  W: "gr",
  V: "medium",
  U: "slate",
  A: "ee",
  T: "ol",
  S: "or",
  B: "ra",
  C: "lateg",
  D: "ights",
  R: "in",
  Q: "turquois",
  E: "hi",
  P: "ro",
  O: "al",
  N: "le",
  M: "de",
  L: "yello",
  F: "en",
  K: "ch",
  G: "arks",
  H: "ea",
  I: "ightg",
  J: "wh"
}, lo = {
  OiceXe: "f0f8ff",
  antiquewEte: "faebd7",
  aqua: "ffff",
  aquamarRe: "7fffd4",
  azuY: "f0ffff",
  beige: "f5f5dc",
  bisque: "ffe4c4",
  black: "0",
  blanKedOmond: "ffebcd",
  Xe: "ff",
  XeviTet: "8a2be2",
  bPwn: "a52a2a",
  burlywood: "deb887",
  caMtXe: "5f9ea0",
  KartYuse: "7fff00",
  KocTate: "d2691e",
  cSO: "ff7f50",
  cSnflowerXe: "6495ed",
  cSnsilk: "fff8dc",
  crimson: "dc143c",
  cyan: "ffff",
  xXe: "8b",
  xcyan: "8b8b",
  xgTMnPd: "b8860b",
  xWay: "a9a9a9",
  xgYF: "6400",
  xgYy: "a9a9a9",
  xkhaki: "bdb76b",
  xmagFta: "8b008b",
  xTivegYF: "556b2f",
  xSange: "ff8c00",
  xScEd: "9932cc",
  xYd: "8b0000",
  xsOmon: "e9967a",
  xsHgYF: "8fbc8f",
  xUXe: "483d8b",
  xUWay: "2f4f4f",
  xUgYy: "2f4f4f",
  xQe: "ced1",
  xviTet: "9400d3",
  dAppRk: "ff1493",
  dApskyXe: "bfff",
  dimWay: "696969",
  dimgYy: "696969",
  dodgerXe: "1e90ff",
  fiYbrick: "b22222",
  flSOwEte: "fffaf0",
  foYstWAn: "228b22",
  fuKsia: "ff00ff",
  gaRsbSo: "dcdcdc",
  ghostwEte: "f8f8ff",
  gTd: "ffd700",
  gTMnPd: "daa520",
  Way: "808080",
  gYF: "8000",
  gYFLw: "adff2f",
  gYy: "808080",
  honeyMw: "f0fff0",
  hotpRk: "ff69b4",
  RdianYd: "cd5c5c",
  Rdigo: "4b0082",
  ivSy: "fffff0",
  khaki: "f0e68c",
  lavFMr: "e6e6fa",
  lavFMrXsh: "fff0f5",
  lawngYF: "7cfc00",
  NmoncEffon: "fffacd",
  ZXe: "add8e6",
  ZcSO: "f08080",
  Zcyan: "e0ffff",
  ZgTMnPdLw: "fafad2",
  ZWay: "d3d3d3",
  ZgYF: "90ee90",
  ZgYy: "d3d3d3",
  ZpRk: "ffb6c1",
  ZsOmon: "ffa07a",
  ZsHgYF: "20b2aa",
  ZskyXe: "87cefa",
  ZUWay: "778899",
  ZUgYy: "778899",
  ZstAlXe: "b0c4de",
  ZLw: "ffffe0",
  lime: "ff00",
  limegYF: "32cd32",
  lRF: "faf0e6",
  magFta: "ff00ff",
  maPon: "800000",
  VaquamarRe: "66cdaa",
  VXe: "cd",
  VScEd: "ba55d3",
  VpurpN: "9370db",
  VsHgYF: "3cb371",
  VUXe: "7b68ee",
  VsprRggYF: "fa9a",
  VQe: "48d1cc",
  VviTetYd: "c71585",
  midnightXe: "191970",
  mRtcYam: "f5fffa",
  mistyPse: "ffe4e1",
  moccasR: "ffe4b5",
  navajowEte: "ffdead",
  navy: "80",
  Tdlace: "fdf5e6",
  Tive: "808000",
  TivedBb: "6b8e23",
  Sange: "ffa500",
  SangeYd: "ff4500",
  ScEd: "da70d6",
  pOegTMnPd: "eee8aa",
  pOegYF: "98fb98",
  pOeQe: "afeeee",
  pOeviTetYd: "db7093",
  papayawEp: "ffefd5",
  pHKpuff: "ffdab9",
  peru: "cd853f",
  pRk: "ffc0cb",
  plum: "dda0dd",
  powMrXe: "b0e0e6",
  purpN: "800080",
  YbeccapurpN: "663399",
  Yd: "ff0000",
  Psybrown: "bc8f8f",
  PyOXe: "4169e1",
  saddNbPwn: "8b4513",
  sOmon: "fa8072",
  sandybPwn: "f4a460",
  sHgYF: "2e8b57",
  sHshell: "fff5ee",
  siFna: "a0522d",
  silver: "c0c0c0",
  skyXe: "87ceeb",
  UXe: "6a5acd",
  UWay: "708090",
  UgYy: "708090",
  snow: "fffafa",
  sprRggYF: "ff7f",
  stAlXe: "4682b4",
  tan: "d2b48c",
  teO: "8080",
  tEstN: "d8bfd8",
  tomato: "ff6347",
  Qe: "40e0d0",
  viTet: "ee82ee",
  JHt: "f5deb3",
  wEte: "ffffff",
  wEtesmoke: "f5f5f5",
  Lw: "ffff00",
  LwgYF: "9acd32"
};
function Ml() {
  const i = {}, t = Object.keys(lo), e = Object.keys(ao);
  let s, n, o, r, a;
  for (s = 0; s < t.length; s++) {
    for (r = a = t[s], n = 0; n < e.length; n++)
      o = e[n], a = a.replace(o, ao[o]);
    o = parseInt(lo[r], 16), i[a] = [o >> 16 & 255, o >> 8 & 255, o & 255];
  }
  return i;
}
let ls;
function Sl(i) {
  ls || (ls = Ml(), ls.transparent = [0, 0, 0, 0]);
  const t = ls[i.toLowerCase()];
  return t && {
    r: t[0],
    g: t[1],
    b: t[2],
    a: t.length === 4 ? t[3] : 255
  };
}
const Cl = /^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/;
function Dl(i) {
  const t = Cl.exec(i);
  let e = 255, s, n, o;
  if (t) {
    if (t[7] !== s) {
      const r = +t[7];
      e = t[8] ? Fi(r) : Ie(r * 255, 0, 255);
    }
    return s = +t[1], n = +t[3], o = +t[5], s = 255 & (t[2] ? Fi(s) : Ie(s, 0, 255)), n = 255 & (t[4] ? Fi(n) : Ie(n, 0, 255)), o = 255 & (t[6] ? Fi(o) : Ie(o, 0, 255)), {
      r: s,
      g: n,
      b: o,
      a: e
    };
  }
}
function Al(i) {
  return i && (i.a < 255 ? `rgba(${i.r}, ${i.g}, ${i.b}, ${Se(i.a)})` : `rgb(${i.r}, ${i.g}, ${i.b})`);
}
const Js = (i) => i <= 31308e-7 ? i * 12.92 : Math.pow(i, 1 / 2.4) * 1.055 - 0.055, mi = (i) => i <= 0.04045 ? i / 12.92 : Math.pow((i + 0.055) / 1.055, 2.4);
function Pl(i, t, e) {
  const s = mi(Se(i.r)), n = mi(Se(i.g)), o = mi(Se(i.b));
  return {
    r: ze(Js(s + e * (mi(Se(t.r)) - s))),
    g: ze(Js(n + e * (mi(Se(t.g)) - n))),
    b: ze(Js(o + e * (mi(Se(t.b)) - o))),
    a: i.a + e * (t.a - i.a)
  };
}
function cs(i, t, e) {
  if (i) {
    let s = kn(i);
    s[t] = Math.max(0, Math.min(s[t] + s[t] * e, t === 0 ? 360 : 1)), s = Mn(s), i.r = s[0], i.g = s[1], i.b = s[2];
  }
}
function Tr(i, t) {
  return i && Object.assign(t || {}, i);
}
function co(i) {
  var t = { r: 0, g: 0, b: 0, a: 255 };
  return Array.isArray(i) ? i.length >= 3 && (t = { r: i[0], g: i[1], b: i[2], a: 255 }, i.length > 3 && (t.a = ze(i[3]))) : (t = Tr(i, { r: 0, g: 0, b: 0, a: 1 }), t.a = ze(t.a)), t;
}
function Tl(i) {
  return i.charAt(0) === "r" ? Dl(i) : wl(i);
}
class Xi {
  constructor(t) {
    if (t instanceof Xi)
      return t;
    const e = typeof t;
    let s;
    e === "object" ? s = co(t) : e === "string" && (s = fl(t) || Sl(t) || Tl(t)), this._rgb = s, this._valid = !!s;
  }
  get valid() {
    return this._valid;
  }
  get rgb() {
    var t = Tr(this._rgb);
    return t && (t.a = Se(t.a)), t;
  }
  set rgb(t) {
    this._rgb = co(t);
  }
  rgbString() {
    return this._valid ? Al(this._rgb) : void 0;
  }
  hexString() {
    return this._valid ? gl(this._rgb) : void 0;
  }
  hslString() {
    return this._valid ? $l(this._rgb) : void 0;
  }
  mix(t, e) {
    if (t) {
      const s = this.rgb, n = t.rgb;
      let o;
      const r = e === o ? 0.5 : e, a = 2 * r - 1, l = s.a - n.a, d = ((a * l === -1 ? a : (a + l) / (1 + a * l)) + 1) / 2;
      o = 1 - d, s.r = 255 & d * s.r + o * n.r + 0.5, s.g = 255 & d * s.g + o * n.g + 0.5, s.b = 255 & d * s.b + o * n.b + 0.5, s.a = r * s.a + (1 - r) * n.a, this.rgb = s;
    }
    return this;
  }
  interpolate(t, e) {
    return t && (this._rgb = Pl(this._rgb, t._rgb, e)), this;
  }
  clone() {
    return new Xi(this.rgb);
  }
  alpha(t) {
    return this._rgb.a = ze(t), this;
  }
  clearer(t) {
    const e = this._rgb;
    return e.a *= 1 - t, this;
  }
  greyscale() {
    const t = this._rgb, e = Qi(t.r * 0.3 + t.g * 0.59 + t.b * 0.11);
    return t.r = t.g = t.b = e, this;
  }
  opaquer(t) {
    const e = this._rgb;
    return e.a *= 1 + t, this;
  }
  negate() {
    const t = this._rgb;
    return t.r = 255 - t.r, t.g = 255 - t.g, t.b = 255 - t.b, this;
  }
  lighten(t) {
    return cs(this._rgb, 2, t), this;
  }
  darken(t) {
    return cs(this._rgb, 2, -t), this;
  }
  saturate(t) {
    return cs(this._rgb, 1, t), this;
  }
  desaturate(t) {
    return cs(this._rgb, 1, -t), this;
  }
  rotate(t) {
    return kl(this._rgb, t), this;
  }
}
function ke() {
}
const Ll = /* @__PURE__ */ (() => {
  let i = 0;
  return () => i++;
})();
function It(i) {
  return i == null;
}
function Wt(i) {
  if (Array.isArray && Array.isArray(i))
    return !0;
  const t = Object.prototype.toString.call(i);
  return t.slice(0, 7) === "[object" && t.slice(-6) === "Array]";
}
function Dt(i) {
  return i !== null && Object.prototype.toString.call(i) === "[object Object]";
}
function qt(i) {
  return (typeof i == "number" || i instanceof Number) && isFinite(+i);
}
function ge(i, t) {
  return qt(i) ? i : t;
}
function Ct(i, t) {
  return typeof i > "u" ? t : i;
}
const Ol = (i, t) => typeof i == "string" && i.endsWith("%") ? parseFloat(i) / 100 * t : +i;
function Rt(i, t, e) {
  if (i && typeof i.call == "function")
    return i.apply(e, t);
}
function Et(i, t, e, s) {
  let n, o, r;
  if (Wt(i))
    for (o = i.length, n = 0; n < o; n++)
      t.call(e, i[n], n);
  else if (Dt(i))
    for (r = Object.keys(i), o = r.length, n = 0; n < o; n++)
      t.call(e, i[r[n]], r[n]);
}
function Ms(i, t) {
  let e, s, n, o;
  if (!i || !t || i.length !== t.length)
    return !1;
  for (e = 0, s = i.length; e < s; ++e)
    if (n = i[e], o = t[e], n.datasetIndex !== o.datasetIndex || n.index !== o.index)
      return !1;
  return !0;
}
function Ss(i) {
  if (Wt(i))
    return i.map(Ss);
  if (Dt(i)) {
    const t = /* @__PURE__ */ Object.create(null), e = Object.keys(i), s = e.length;
    let n = 0;
    for (; n < s; ++n)
      t[e[n]] = Ss(i[e[n]]);
    return t;
  }
  return i;
}
function Lr(i) {
  return [
    "__proto__",
    "prototype",
    "constructor"
  ].indexOf(i) === -1;
}
function El(i, t, e, s) {
  if (!Lr(i))
    return;
  const n = t[i], o = e[i];
  Dt(n) && Dt(o) ? Gi(n, o, s) : t[i] = Ss(o);
}
function Gi(i, t, e) {
  const s = Wt(t) ? t : [
    t
  ], n = s.length;
  if (!Dt(i))
    return i;
  e = e || {};
  const o = e.merger || El;
  let r;
  for (let a = 0; a < n; ++a) {
    if (r = s[a], !Dt(r))
      continue;
    const l = Object.keys(r);
    for (let d = 0, f = l.length; d < f; ++d)
      o(l[d], i, r, e);
  }
  return i;
}
function Ni(i, t) {
  return Gi(i, t, {
    merger: Bl
  });
}
function Bl(i, t, e) {
  if (!Lr(i))
    return;
  const s = t[i], n = e[i];
  Dt(s) && Dt(n) ? Ni(s, n) : Object.prototype.hasOwnProperty.call(t, i) || (t[i] = Ss(n));
}
const ho = {
  // Chart.helpers.core resolveObjectKey should resolve empty key to root object
  "": (i) => i,
  // default resolvers
  x: (i) => i.x,
  y: (i) => i.y
};
function Il(i) {
  const t = i.split("."), e = [];
  let s = "";
  for (const n of t)
    s += n, s.endsWith("\\") ? s = s.slice(0, -1) + "." : (e.push(s), s = "");
  return e;
}
function Rl(i) {
  const t = Il(i);
  return (e) => {
    for (const s of t) {
      if (s === "")
        break;
      e = e && e[s];
    }
    return e;
  };
}
function Cs(i, t) {
  return (ho[t] || (ho[t] = Rl(t)))(i);
}
function Sn(i) {
  return i.charAt(0).toUpperCase() + i.slice(1);
}
const Ds = (i) => typeof i < "u", He = (i) => typeof i == "function", uo = (i, t) => {
  if (i.size !== t.size)
    return !1;
  for (const e of i)
    if (!t.has(e))
      return !1;
  return !0;
};
function zl(i) {
  return i.type === "mouseup" || i.type === "click" || i.type === "contextmenu";
}
const Vt = Math.PI, fe = 2 * Vt, Fl = fe + Vt, As = Number.POSITIVE_INFINITY, Hl = Vt / 180, ue = Vt / 2, Ye = Vt / 4, fo = Vt * 2 / 3, Or = Math.log10, _i = Math.sign;
function Wi(i, t, e) {
  return Math.abs(i - t) < e;
}
function po(i) {
  const t = Math.round(i);
  i = Wi(i, t, i / 1e3) ? t : i;
  const e = Math.pow(10, Math.floor(Or(i))), s = i / e;
  return (s <= 1 ? 1 : s <= 2 ? 2 : s <= 5 ? 5 : 10) * e;
}
function jl(i) {
  const t = [], e = Math.sqrt(i);
  let s;
  for (s = 1; s < e; s++)
    i % s === 0 && (t.push(s), t.push(i / s));
  return e === (e | 0) && t.push(e), t.sort((n, o) => n - o).pop(), t;
}
function Nl(i) {
  return typeof i == "symbol" || typeof i == "object" && i !== null && !(Symbol.toPrimitive in i || "toString" in i || "valueOf" in i);
}
function vi(i) {
  return !Nl(i) && !isNaN(parseFloat(i)) && isFinite(i);
}
function Wl(i, t) {
  const e = Math.round(i);
  return e - t <= i && e + t >= i;
}
function Vl(i, t, e) {
  let s, n, o;
  for (s = 0, n = i.length; s < n; s++)
    o = i[s][e], isNaN(o) || (t.min = Math.min(t.min, o), t.max = Math.max(t.max, o));
}
function Ke(i) {
  return i * (Vt / 180);
}
function Yl(i) {
  return i * (180 / Vt);
}
function go(i) {
  if (!qt(i))
    return;
  let t = 1, e = 0;
  for (; Math.round(i * t) / t !== i; )
    t *= 10, e++;
  return e;
}
function Ul(i, t) {
  const e = t.x - i.x, s = t.y - i.y, n = Math.sqrt(e * e + s * s);
  let o = Math.atan2(s, e);
  return o < -0.5 * Vt && (o += fe), {
    angle: o,
    distance: n
  };
}
function pn(i, t) {
  return Math.sqrt(Math.pow(t.x - i.x, 2) + Math.pow(t.y - i.y, 2));
}
function Xl(i, t) {
  return (i - t + Fl) % fe - Vt;
}
function xe(i) {
  return (i % fe + fe) % fe;
}
function Er(i, t, e, s) {
  const n = xe(i), o = xe(t), r = xe(e), a = xe(o - n), l = xe(r - n), d = xe(n - o), f = xe(n - r);
  return n === o || n === r || s && o === r || a > l && d < f;
}
function le(i, t, e) {
  return Math.max(t, Math.min(e, i));
}
function Gl(i) {
  return le(i, -32768, 32767);
}
function xi(i, t, e, s = 1e-6) {
  return i >= Math.min(t, e) - s && i <= Math.max(t, e) + s;
}
function Cn(i, t, e) {
  e = e || ((r) => i[r] < t);
  let s = i.length - 1, n = 0, o;
  for (; s - n > 1; )
    o = n + s >> 1, e(o) ? n = o : s = o;
  return {
    lo: n,
    hi: s
  };
}
const Je = (i, t, e, s) => Cn(i, e, s ? (n) => {
  const o = i[n][t];
  return o < e || o === e && i[n + 1][t] === e;
} : (n) => i[n][t] < e), ql = (i, t, e) => Cn(i, e, (s) => i[s][t] >= e);
function Kl(i, t, e) {
  let s = 0, n = i.length;
  for (; s < n && i[s] < t; )
    s++;
  for (; n > s && i[n - 1] > e; )
    n--;
  return s > 0 || n < i.length ? i.slice(s, n) : i;
}
const Br = [
  "push",
  "pop",
  "shift",
  "splice",
  "unshift"
];
function Jl(i, t) {
  if (i._chartjs) {
    i._chartjs.listeners.push(t);
    return;
  }
  Object.defineProperty(i, "_chartjs", {
    configurable: !0,
    enumerable: !1,
    value: {
      listeners: [
        t
      ]
    }
  }), Br.forEach((e) => {
    const s = "_onData" + Sn(e), n = i[e];
    Object.defineProperty(i, e, {
      configurable: !0,
      enumerable: !1,
      value(...o) {
        const r = n.apply(this, o);
        return i._chartjs.listeners.forEach((a) => {
          typeof a[s] == "function" && a[s](...o);
        }), r;
      }
    });
  });
}
function mo(i, t) {
  const e = i._chartjs;
  if (!e)
    return;
  const s = e.listeners, n = s.indexOf(t);
  n !== -1 && s.splice(n, 1), !(s.length > 0) && (Br.forEach((o) => {
    delete i[o];
  }), delete i._chartjs);
}
function Zl(i) {
  const t = new Set(i);
  return t.size === i.length ? i : Array.from(t);
}
const Ir = (function() {
  return typeof window > "u" ? function(i) {
    return i();
  } : window.requestAnimationFrame;
})();
function Rr(i, t) {
  let e = [], s = !1;
  return function(...n) {
    e = n, s || (s = !0, Ir.call(window, () => {
      s = !1, i.apply(t, e);
    }));
  };
}
function Ql(i, t) {
  let e;
  return function(...s) {
    return t ? (clearTimeout(e), e = setTimeout(i, t, s)) : i.apply(this, s), t;
  };
}
const Dn = (i) => i === "start" ? "left" : i === "end" ? "right" : "center", Xt = (i, t, e) => i === "start" ? t : i === "end" ? e : (t + e) / 2, tc = (i, t, e, s) => i === (s ? "left" : "right") ? e : i === "center" ? (t + e) / 2 : t;
function zr(i, t, e) {
  const s = t.length;
  let n = 0, o = s;
  if (i._sorted) {
    const { iScale: r, vScale: a, _parsed: l } = i, d = i.dataset && i.dataset.options ? i.dataset.options.spanGaps : null, f = r.axis, { min: x, max: b, minDefined: k, maxDefined: T } = r.getUserBounds();
    if (k) {
      if (n = Math.min(
        // @ts-expect-error Need to type _parsed
        Je(l, f, x).lo,
        // @ts-expect-error Need to fix types on _lookupByKey
        e ? s : Je(t, f, r.getPixelForValue(x)).lo
      ), d) {
        const C = l.slice(0, n + 1).reverse().findIndex((A) => !It(A[a.axis]));
        n -= Math.max(0, C);
      }
      n = le(n, 0, s - 1);
    }
    if (T) {
      let C = Math.max(
        // @ts-expect-error Need to type _parsed
        Je(l, r.axis, b, !0).hi + 1,
        // @ts-expect-error Need to fix types on _lookupByKey
        e ? 0 : Je(t, f, r.getPixelForValue(b), !0).hi + 1
      );
      if (d) {
        const A = l.slice(C - 1).findIndex((P) => !It(P[a.axis]));
        C += Math.max(0, A);
      }
      o = le(C, n, s) - n;
    } else
      o = s - n;
  }
  return {
    start: n,
    count: o
  };
}
function Fr(i) {
  const { xScale: t, yScale: e, _scaleRanges: s } = i, n = {
    xmin: t.min,
    xmax: t.max,
    ymin: e.min,
    ymax: e.max
  };
  if (!s)
    return i._scaleRanges = n, !0;
  const o = s.xmin !== t.min || s.xmax !== t.max || s.ymin !== e.min || s.ymax !== e.max;
  return Object.assign(s, n), o;
}
const hs = (i) => i === 0 || i === 1, yo = (i, t, e) => -(Math.pow(2, 10 * (i -= 1)) * Math.sin((i - t) * fe / e)), xo = (i, t, e) => Math.pow(2, -10 * i) * Math.sin((i - t) * fe / e) + 1, Vi = {
  linear: (i) => i,
  easeInQuad: (i) => i * i,
  easeOutQuad: (i) => -i * (i - 2),
  easeInOutQuad: (i) => (i /= 0.5) < 1 ? 0.5 * i * i : -0.5 * (--i * (i - 2) - 1),
  easeInCubic: (i) => i * i * i,
  easeOutCubic: (i) => (i -= 1) * i * i + 1,
  easeInOutCubic: (i) => (i /= 0.5) < 1 ? 0.5 * i * i * i : 0.5 * ((i -= 2) * i * i + 2),
  easeInQuart: (i) => i * i * i * i,
  easeOutQuart: (i) => -((i -= 1) * i * i * i - 1),
  easeInOutQuart: (i) => (i /= 0.5) < 1 ? 0.5 * i * i * i * i : -0.5 * ((i -= 2) * i * i * i - 2),
  easeInQuint: (i) => i * i * i * i * i,
  easeOutQuint: (i) => (i -= 1) * i * i * i * i + 1,
  easeInOutQuint: (i) => (i /= 0.5) < 1 ? 0.5 * i * i * i * i * i : 0.5 * ((i -= 2) * i * i * i * i + 2),
  easeInSine: (i) => -Math.cos(i * ue) + 1,
  easeOutSine: (i) => Math.sin(i * ue),
  easeInOutSine: (i) => -0.5 * (Math.cos(Vt * i) - 1),
  easeInExpo: (i) => i === 0 ? 0 : Math.pow(2, 10 * (i - 1)),
  easeOutExpo: (i) => i === 1 ? 1 : -Math.pow(2, -10 * i) + 1,
  easeInOutExpo: (i) => hs(i) ? i : i < 0.5 ? 0.5 * Math.pow(2, 10 * (i * 2 - 1)) : 0.5 * (-Math.pow(2, -10 * (i * 2 - 1)) + 2),
  easeInCirc: (i) => i >= 1 ? i : -(Math.sqrt(1 - i * i) - 1),
  easeOutCirc: (i) => Math.sqrt(1 - (i -= 1) * i),
  easeInOutCirc: (i) => (i /= 0.5) < 1 ? -0.5 * (Math.sqrt(1 - i * i) - 1) : 0.5 * (Math.sqrt(1 - (i -= 2) * i) + 1),
  easeInElastic: (i) => hs(i) ? i : yo(i, 0.075, 0.3),
  easeOutElastic: (i) => hs(i) ? i : xo(i, 0.075, 0.3),
  easeInOutElastic(i) {
    return hs(i) ? i : i < 0.5 ? 0.5 * yo(i * 2, 0.1125, 0.45) : 0.5 + 0.5 * xo(i * 2 - 1, 0.1125, 0.45);
  },
  easeInBack(i) {
    return i * i * ((1.70158 + 1) * i - 1.70158);
  },
  easeOutBack(i) {
    return (i -= 1) * i * ((1.70158 + 1) * i + 1.70158) + 1;
  },
  easeInOutBack(i) {
    let t = 1.70158;
    return (i /= 0.5) < 1 ? 0.5 * (i * i * (((t *= 1.525) + 1) * i - t)) : 0.5 * ((i -= 2) * i * (((t *= 1.525) + 1) * i + t) + 2);
  },
  easeInBounce: (i) => 1 - Vi.easeOutBounce(1 - i),
  easeOutBounce(i) {
    return i < 1 / 2.75 ? 7.5625 * i * i : i < 2 / 2.75 ? 7.5625 * (i -= 1.5 / 2.75) * i + 0.75 : i < 2.5 / 2.75 ? 7.5625 * (i -= 2.25 / 2.75) * i + 0.9375 : 7.5625 * (i -= 2.625 / 2.75) * i + 0.984375;
  },
  easeInOutBounce: (i) => i < 0.5 ? Vi.easeInBounce(i * 2) * 0.5 : Vi.easeOutBounce(i * 2 - 1) * 0.5 + 0.5
};
function An(i) {
  if (i && typeof i == "object") {
    const t = i.toString();
    return t === "[object CanvasPattern]" || t === "[object CanvasGradient]";
  }
  return !1;
}
function bo(i) {
  return An(i) ? i : new Xi(i);
}
function Zs(i) {
  return An(i) ? i : new Xi(i).saturate(0.5).darken(0.1).hexString();
}
const ec = [
  "x",
  "y",
  "borderWidth",
  "radius",
  "tension"
], ic = [
  "color",
  "borderColor",
  "backgroundColor"
];
function sc(i) {
  i.set("animation", {
    delay: void 0,
    duration: 1e3,
    easing: "easeOutQuart",
    fn: void 0,
    from: void 0,
    loop: void 0,
    to: void 0,
    type: void 0
  }), i.describe("animation", {
    _fallback: !1,
    _indexable: !1,
    _scriptable: (t) => t !== "onProgress" && t !== "onComplete" && t !== "fn"
  }), i.set("animations", {
    colors: {
      type: "color",
      properties: ic
    },
    numbers: {
      type: "number",
      properties: ec
    }
  }), i.describe("animations", {
    _fallback: "animation"
  }), i.set("transitions", {
    active: {
      animation: {
        duration: 400
      }
    },
    resize: {
      animation: {
        duration: 0
      }
    },
    show: {
      animations: {
        colors: {
          from: "transparent"
        },
        visible: {
          type: "boolean",
          duration: 0
        }
      }
    },
    hide: {
      animations: {
        colors: {
          to: "transparent"
        },
        visible: {
          type: "boolean",
          easing: "linear",
          fn: (t) => t | 0
        }
      }
    }
  });
}
function nc(i) {
  i.set("layout", {
    autoPadding: !0,
    padding: {
      top: 0,
      right: 0,
      bottom: 0,
      left: 0
    }
  });
}
const _o = /* @__PURE__ */ new Map();
function oc(i, t) {
  t = t || {};
  const e = i + JSON.stringify(t);
  let s = _o.get(e);
  return s || (s = new Intl.NumberFormat(i, t), _o.set(e, s)), s;
}
function Hr(i, t, e) {
  return oc(t, e).format(i);
}
const rc = {
  values(i) {
    return Wt(i) ? i : "" + i;
  },
  numeric(i, t, e) {
    if (i === 0)
      return "0";
    const s = this.chart.options.locale;
    let n, o = i;
    if (e.length > 1) {
      const d = Math.max(Math.abs(e[0].value), Math.abs(e[e.length - 1].value));
      (d < 1e-4 || d > 1e15) && (n = "scientific"), o = ac(i, e);
    }
    const r = Or(Math.abs(o)), a = isNaN(r) ? 1 : Math.max(Math.min(-1 * Math.floor(r), 20), 0), l = {
      notation: n,
      minimumFractionDigits: a,
      maximumFractionDigits: a
    };
    return Object.assign(l, this.options.ticks.format), Hr(i, s, l);
  }
};
function ac(i, t) {
  let e = t.length > 3 ? t[2].value - t[1].value : t[1].value - t[0].value;
  return Math.abs(e) >= 1 && i !== Math.floor(i) && (e = i - Math.floor(i)), e;
}
var jr = {
  formatters: rc
};
function lc(i) {
  i.set("scale", {
    display: !0,
    offset: !1,
    reverse: !1,
    beginAtZero: !1,
    bounds: "ticks",
    clip: !0,
    grace: 0,
    grid: {
      display: !0,
      lineWidth: 1,
      drawOnChartArea: !0,
      drawTicks: !0,
      tickLength: 8,
      tickWidth: (t, e) => e.lineWidth,
      tickColor: (t, e) => e.color,
      offset: !1
    },
    border: {
      display: !0,
      dash: [],
      dashOffset: 0,
      width: 1
    },
    title: {
      display: !1,
      text: "",
      padding: {
        top: 4,
        bottom: 4
      }
    },
    ticks: {
      minRotation: 0,
      maxRotation: 50,
      mirror: !1,
      textStrokeWidth: 0,
      textStrokeColor: "",
      padding: 3,
      display: !0,
      autoSkip: !0,
      autoSkipPadding: 3,
      labelOffset: 0,
      callback: jr.formatters.values,
      minor: {},
      major: {},
      align: "center",
      crossAlign: "near",
      showLabelBackdrop: !1,
      backdropColor: "rgba(255, 255, 255, 0.75)",
      backdropPadding: 2
    }
  }), i.route("scale.ticks", "color", "", "color"), i.route("scale.grid", "color", "", "borderColor"), i.route("scale.border", "color", "", "borderColor"), i.route("scale.title", "color", "", "color"), i.describe("scale", {
    _fallback: !1,
    _scriptable: (t) => !t.startsWith("before") && !t.startsWith("after") && t !== "callback" && t !== "parser",
    _indexable: (t) => t !== "borderDash" && t !== "tickBorderDash" && t !== "dash"
  }), i.describe("scales", {
    _fallback: "scale"
  }), i.describe("scale.ticks", {
    _scriptable: (t) => t !== "backdropPadding" && t !== "callback",
    _indexable: (t) => t !== "backdropPadding"
  });
}
const Qe = /* @__PURE__ */ Object.create(null), gn = /* @__PURE__ */ Object.create(null);
function Yi(i, t) {
  if (!t)
    return i;
  const e = t.split(".");
  for (let s = 0, n = e.length; s < n; ++s) {
    const o = e[s];
    i = i[o] || (i[o] = /* @__PURE__ */ Object.create(null));
  }
  return i;
}
function Qs(i, t, e) {
  return typeof t == "string" ? Gi(Yi(i, t), e) : Gi(Yi(i, ""), t);
}
class cc {
  constructor(t, e) {
    this.animation = void 0, this.backgroundColor = "rgba(0,0,0,0.1)", this.borderColor = "rgba(0,0,0,0.1)", this.color = "#666", this.datasets = {}, this.devicePixelRatio = (s) => s.chart.platform.getDevicePixelRatio(), this.elements = {}, this.events = [
      "mousemove",
      "mouseout",
      "click",
      "touchstart",
      "touchmove"
    ], this.font = {
      family: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
      size: 12,
      style: "normal",
      lineHeight: 1.2,
      weight: null
    }, this.hover = {}, this.hoverBackgroundColor = (s, n) => Zs(n.backgroundColor), this.hoverBorderColor = (s, n) => Zs(n.borderColor), this.hoverColor = (s, n) => Zs(n.color), this.indexAxis = "x", this.interaction = {
      mode: "nearest",
      intersect: !0,
      includeInvisible: !1
    }, this.maintainAspectRatio = !0, this.onHover = null, this.onClick = null, this.parsing = !0, this.plugins = {}, this.responsive = !0, this.scale = void 0, this.scales = {}, this.showLine = !0, this.drawActiveElementsOnTop = !0, this.describe(t), this.apply(e);
  }
  set(t, e) {
    return Qs(this, t, e);
  }
  get(t) {
    return Yi(this, t);
  }
  describe(t, e) {
    return Qs(gn, t, e);
  }
  override(t, e) {
    return Qs(Qe, t, e);
  }
  route(t, e, s, n) {
    const o = Yi(this, t), r = Yi(this, s), a = "_" + e;
    Object.defineProperties(o, {
      [a]: {
        value: o[e],
        writable: !0
      },
      [e]: {
        enumerable: !0,
        get() {
          const l = this[a], d = r[n];
          return Dt(l) ? Object.assign({}, d, l) : Ct(l, d);
        },
        set(l) {
          this[a] = l;
        }
      }
    });
  }
  apply(t) {
    t.forEach((e) => e(this));
  }
}
var Ht = /* @__PURE__ */ new cc({
  _scriptable: (i) => !i.startsWith("on"),
  _indexable: (i) => i !== "events",
  hover: {
    _fallback: "interaction"
  },
  interaction: {
    _scriptable: !1,
    _indexable: !1
  }
}, [
  sc,
  nc,
  lc
]);
function hc(i) {
  return !i || It(i.size) || It(i.family) ? null : (i.style ? i.style + " " : "") + (i.weight ? i.weight + " " : "") + i.size + "px " + i.family;
}
function vo(i, t, e, s, n) {
  let o = t[n];
  return o || (o = t[n] = i.measureText(n).width, e.push(n)), o > s && (s = o), s;
}
function Ue(i, t, e) {
  const s = i.currentDevicePixelRatio, n = e !== 0 ? Math.max(e / 2, 0.5) : 0;
  return Math.round((t - n) * s) / s + n;
}
function wo(i, t) {
  !t && !i || (t = t || i.getContext("2d"), t.save(), t.resetTransform(), t.clearRect(0, 0, i.width, i.height), t.restore());
}
function mn(i, t, e, s) {
  Nr(i, t, e, s, null);
}
function Nr(i, t, e, s, n) {
  let o, r, a, l, d, f, x, b;
  const k = t.pointStyle, T = t.rotation, C = t.radius;
  let A = (T || 0) * Hl;
  if (k && typeof k == "object" && (o = k.toString(), o === "[object HTMLImageElement]" || o === "[object HTMLCanvasElement]")) {
    i.save(), i.translate(e, s), i.rotate(A), i.drawImage(k, -k.width / 2, -k.height / 2, k.width, k.height), i.restore();
    return;
  }
  if (!(isNaN(C) || C <= 0)) {
    switch (i.beginPath(), k) {
      // Default includes circle
      default:
        n ? i.ellipse(e, s, n / 2, C, 0, 0, fe) : i.arc(e, s, C, 0, fe), i.closePath();
        break;
      case "triangle":
        f = n ? n / 2 : C, i.moveTo(e + Math.sin(A) * f, s - Math.cos(A) * C), A += fo, i.lineTo(e + Math.sin(A) * f, s - Math.cos(A) * C), A += fo, i.lineTo(e + Math.sin(A) * f, s - Math.cos(A) * C), i.closePath();
        break;
      case "rectRounded":
        d = C * 0.516, l = C - d, r = Math.cos(A + Ye) * l, x = Math.cos(A + Ye) * (n ? n / 2 - d : l), a = Math.sin(A + Ye) * l, b = Math.sin(A + Ye) * (n ? n / 2 - d : l), i.arc(e - x, s - a, d, A - Vt, A - ue), i.arc(e + b, s - r, d, A - ue, A), i.arc(e + x, s + a, d, A, A + ue), i.arc(e - b, s + r, d, A + ue, A + Vt), i.closePath();
        break;
      case "rect":
        if (!T) {
          l = Math.SQRT1_2 * C, f = n ? n / 2 : l, i.rect(e - f, s - l, 2 * f, 2 * l);
          break;
        }
        A += Ye;
      /* falls through */
      case "rectRot":
        x = Math.cos(A) * (n ? n / 2 : C), r = Math.cos(A) * C, a = Math.sin(A) * C, b = Math.sin(A) * (n ? n / 2 : C), i.moveTo(e - x, s - a), i.lineTo(e + b, s - r), i.lineTo(e + x, s + a), i.lineTo(e - b, s + r), i.closePath();
        break;
      case "crossRot":
        A += Ye;
      /* falls through */
      case "cross":
        x = Math.cos(A) * (n ? n / 2 : C), r = Math.cos(A) * C, a = Math.sin(A) * C, b = Math.sin(A) * (n ? n / 2 : C), i.moveTo(e - x, s - a), i.lineTo(e + x, s + a), i.moveTo(e + b, s - r), i.lineTo(e - b, s + r);
        break;
      case "star":
        x = Math.cos(A) * (n ? n / 2 : C), r = Math.cos(A) * C, a = Math.sin(A) * C, b = Math.sin(A) * (n ? n / 2 : C), i.moveTo(e - x, s - a), i.lineTo(e + x, s + a), i.moveTo(e + b, s - r), i.lineTo(e - b, s + r), A += Ye, x = Math.cos(A) * (n ? n / 2 : C), r = Math.cos(A) * C, a = Math.sin(A) * C, b = Math.sin(A) * (n ? n / 2 : C), i.moveTo(e - x, s - a), i.lineTo(e + x, s + a), i.moveTo(e + b, s - r), i.lineTo(e - b, s + r);
        break;
      case "line":
        r = n ? n / 2 : Math.cos(A) * C, a = Math.sin(A) * C, i.moveTo(e - r, s - a), i.lineTo(e + r, s + a);
        break;
      case "dash":
        i.moveTo(e, s), i.lineTo(e + Math.cos(A) * (n ? n / 2 : C), s + Math.sin(A) * C);
        break;
      case !1:
        i.closePath();
        break;
    }
    i.fill(), t.borderWidth > 0 && i.stroke();
  }
}
function qi(i, t, e) {
  return e = e || 0.5, !t || i && i.x > t.left - e && i.x < t.right + e && i.y > t.top - e && i.y < t.bottom + e;
}
function Ls(i, t) {
  i.save(), i.beginPath(), i.rect(t.left, t.top, t.right - t.left, t.bottom - t.top), i.clip();
}
function Os(i) {
  i.restore();
}
function dc(i, t, e, s, n) {
  if (!t)
    return i.lineTo(e.x, e.y);
  if (n === "middle") {
    const o = (t.x + e.x) / 2;
    i.lineTo(o, t.y), i.lineTo(o, e.y);
  } else n === "after" != !!s ? i.lineTo(t.x, e.y) : i.lineTo(e.x, t.y);
  i.lineTo(e.x, e.y);
}
function uc(i, t, e, s) {
  if (!t)
    return i.lineTo(e.x, e.y);
  i.bezierCurveTo(s ? t.cp1x : t.cp2x, s ? t.cp1y : t.cp2y, s ? e.cp2x : e.cp1x, s ? e.cp2y : e.cp1y, e.x, e.y);
}
function fc(i, t) {
  t.translation && i.translate(t.translation[0], t.translation[1]), It(t.rotation) || i.rotate(t.rotation), t.color && (i.fillStyle = t.color), t.textAlign && (i.textAlign = t.textAlign), t.textBaseline && (i.textBaseline = t.textBaseline);
}
function pc(i, t, e, s, n) {
  if (n.strikethrough || n.underline) {
    const o = i.measureText(s), r = t - o.actualBoundingBoxLeft, a = t + o.actualBoundingBoxRight, l = e - o.actualBoundingBoxAscent, d = e + o.actualBoundingBoxDescent, f = n.strikethrough ? (l + d) / 2 : d;
    i.strokeStyle = i.fillStyle, i.beginPath(), i.lineWidth = n.decorationWidth || 2, i.moveTo(r, f), i.lineTo(a, f), i.stroke();
  }
}
function gc(i, t) {
  const e = i.fillStyle;
  i.fillStyle = t.color, i.fillRect(t.left, t.top, t.width, t.height), i.fillStyle = e;
}
function Ki(i, t, e, s, n, o = {}) {
  const r = Wt(t) ? t : [
    t
  ], a = o.strokeWidth > 0 && o.strokeColor !== "";
  let l, d;
  for (i.save(), i.font = n.string, fc(i, o), l = 0; l < r.length; ++l)
    d = r[l], o.backdrop && gc(i, o.backdrop), a && (o.strokeColor && (i.strokeStyle = o.strokeColor), It(o.strokeWidth) || (i.lineWidth = o.strokeWidth), i.strokeText(d, e, s, o.maxWidth)), i.fillText(d, e, s, o.maxWidth), pc(i, e, s, d, o), s += Number(n.lineHeight);
  i.restore();
}
function yn(i, t) {
  const { x: e, y: s, w: n, h: o, radius: r } = t;
  i.arc(e + r.topLeft, s + r.topLeft, r.topLeft, 1.5 * Vt, Vt, !0), i.lineTo(e, s + o - r.bottomLeft), i.arc(e + r.bottomLeft, s + o - r.bottomLeft, r.bottomLeft, Vt, ue, !0), i.lineTo(e + n - r.bottomRight, s + o), i.arc(e + n - r.bottomRight, s + o - r.bottomRight, r.bottomRight, ue, 0, !0), i.lineTo(e + n, s + r.topRight), i.arc(e + n - r.topRight, s + r.topRight, r.topRight, 0, -ue, !0), i.lineTo(e + r.topLeft, s);
}
const mc = /^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/, yc = /^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;
function xc(i, t) {
  const e = ("" + i).match(mc);
  if (!e || e[1] === "normal")
    return t * 1.2;
  switch (i = +e[2], e[3]) {
    case "px":
      return i;
    case "%":
      i /= 100;
      break;
  }
  return t * i;
}
const bc = (i) => +i || 0;
function Wr(i, t) {
  const e = {}, s = Dt(t), n = s ? Object.keys(t) : t, o = Dt(i) ? s ? (r) => Ct(i[r], i[t[r]]) : (r) => i[r] : () => i;
  for (const r of n)
    e[r] = bc(o(r));
  return e;
}
function _c(i) {
  return Wr(i, {
    top: "y",
    right: "x",
    bottom: "y",
    left: "x"
  });
}
function Ui(i) {
  return Wr(i, [
    "topLeft",
    "topRight",
    "bottomLeft",
    "bottomRight"
  ]);
}
function he(i) {
  const t = _c(i);
  return t.width = t.left + t.right, t.height = t.top + t.bottom, t;
}
function Gt(i, t) {
  i = i || {}, t = t || Ht.font;
  let e = Ct(i.size, t.size);
  typeof e == "string" && (e = parseInt(e, 10));
  let s = Ct(i.style, t.style);
  s && !("" + s).match(yc) && (console.warn('Invalid font style specified: "' + s + '"'), s = void 0);
  const n = {
    family: Ct(i.family, t.family),
    lineHeight: xc(Ct(i.lineHeight, t.lineHeight), e),
    size: e,
    style: s,
    weight: Ct(i.weight, t.weight),
    string: ""
  };
  return n.string = hc(n), n;
}
function ds(i, t, e, s) {
  let n, o, r;
  for (n = 0, o = i.length; n < o; ++n)
    if (r = i[n], r !== void 0 && r !== void 0)
      return r;
}
function vc(i, t, e) {
  const { min: s, max: n } = i, o = Ol(t, (n - s) / 2), r = (a, l) => e && a === 0 ? 0 : a + l;
  return {
    min: r(s, -Math.abs(o)),
    max: r(n, o)
  };
}
function ei(i, t) {
  return Object.assign(Object.create(i), t);
}
function Pn(i, t = [
  ""
], e, s, n = () => i[0]) {
  const o = e || i;
  typeof s > "u" && (s = Xr("_fallback", i));
  const r = {
    [Symbol.toStringTag]: "Object",
    _cacheable: !0,
    _scopes: i,
    _rootScopes: o,
    _fallback: s,
    _getTarget: n,
    override: (a) => Pn([
      a,
      ...i
    ], t, o, s)
  };
  return new Proxy(r, {
    /**
    * A trap for the delete operator.
    */
    deleteProperty(a, l) {
      return delete a[l], delete a._keys, delete i[0][l], !0;
    },
    /**
    * A trap for getting property values.
    */
    get(a, l) {
      return Yr(a, l, () => Ac(l, t, i, a));
    },
    /**
    * A trap for Object.getOwnPropertyDescriptor.
    * Also used by Object.hasOwnProperty.
    */
    getOwnPropertyDescriptor(a, l) {
      return Reflect.getOwnPropertyDescriptor(a._scopes[0], l);
    },
    /**
    * A trap for Object.getPrototypeOf.
    */
    getPrototypeOf() {
      return Reflect.getPrototypeOf(i[0]);
    },
    /**
    * A trap for the in operator.
    */
    has(a, l) {
      return $o(a).includes(l);
    },
    /**
    * A trap for Object.getOwnPropertyNames and Object.getOwnPropertySymbols.
    */
    ownKeys(a) {
      return $o(a);
    },
    /**
    * A trap for setting property values.
    */
    set(a, l, d) {
      const f = a._storage || (a._storage = n());
      return a[l] = f[l] = d, delete a._keys, !0;
    }
  });
}
function wi(i, t, e, s) {
  const n = {
    _cacheable: !1,
    _proxy: i,
    _context: t,
    _subProxy: e,
    _stack: /* @__PURE__ */ new Set(),
    _descriptors: Vr(i, s),
    setContext: (o) => wi(i, o, e, s),
    override: (o) => wi(i.override(o), t, e, s)
  };
  return new Proxy(n, {
    /**
    * A trap for the delete operator.
    */
    deleteProperty(o, r) {
      return delete o[r], delete i[r], !0;
    },
    /**
    * A trap for getting property values.
    */
    get(o, r, a) {
      return Yr(o, r, () => kc(o, r, a));
    },
    /**
    * A trap for Object.getOwnPropertyDescriptor.
    * Also used by Object.hasOwnProperty.
    */
    getOwnPropertyDescriptor(o, r) {
      return o._descriptors.allKeys ? Reflect.has(i, r) ? {
        enumerable: !0,
        configurable: !0
      } : void 0 : Reflect.getOwnPropertyDescriptor(i, r);
    },
    /**
    * A trap for Object.getPrototypeOf.
    */
    getPrototypeOf() {
      return Reflect.getPrototypeOf(i);
    },
    /**
    * A trap for the in operator.
    */
    has(o, r) {
      return Reflect.has(i, r);
    },
    /**
    * A trap for Object.getOwnPropertyNames and Object.getOwnPropertySymbols.
    */
    ownKeys() {
      return Reflect.ownKeys(i);
    },
    /**
    * A trap for setting property values.
    */
    set(o, r, a) {
      return i[r] = a, delete o[r], !0;
    }
  });
}
function Vr(i, t = {
  scriptable: !0,
  indexable: !0
}) {
  const { _scriptable: e = t.scriptable, _indexable: s = t.indexable, _allKeys: n = t.allKeys } = i;
  return {
    allKeys: n,
    scriptable: e,
    indexable: s,
    isScriptable: He(e) ? e : () => e,
    isIndexable: He(s) ? s : () => s
  };
}
const wc = (i, t) => i ? i + Sn(t) : t, Tn = (i, t) => Dt(t) && i !== "adapters" && (Object.getPrototypeOf(t) === null || t.constructor === Object);
function Yr(i, t, e) {
  if (Object.prototype.hasOwnProperty.call(i, t) || t === "constructor")
    return i[t];
  const s = e();
  return i[t] = s, s;
}
function kc(i, t, e) {
  const { _proxy: s, _context: n, _subProxy: o, _descriptors: r } = i;
  let a = s[t];
  return He(a) && r.isScriptable(t) && (a = $c(t, a, i, e)), Wt(a) && a.length && (a = Mc(t, a, i, r.isIndexable)), Tn(t, a) && (a = wi(a, n, o && o[t], r)), a;
}
function $c(i, t, e, s) {
  const { _proxy: n, _context: o, _subProxy: r, _stack: a } = e;
  if (a.has(i))
    throw new Error("Recursion detected: " + Array.from(a).join("->") + "->" + i);
  a.add(i);
  let l = t(o, r || s);
  return a.delete(i), Tn(i, l) && (l = Ln(n._scopes, n, i, l)), l;
}
function Mc(i, t, e, s) {
  const { _proxy: n, _context: o, _subProxy: r, _descriptors: a } = e;
  if (typeof o.index < "u" && s(i))
    return t[o.index % t.length];
  if (Dt(t[0])) {
    const l = t, d = n._scopes.filter((f) => f !== l);
    t = [];
    for (const f of l) {
      const x = Ln(d, n, i, f);
      t.push(wi(x, o, r && r[i], a));
    }
  }
  return t;
}
function Ur(i, t, e) {
  return He(i) ? i(t, e) : i;
}
const Sc = (i, t) => i === !0 ? t : typeof i == "string" ? Cs(t, i) : void 0;
function Cc(i, t, e, s, n) {
  for (const o of t) {
    const r = Sc(e, o);
    if (r) {
      i.add(r);
      const a = Ur(r._fallback, e, n);
      if (typeof a < "u" && a !== e && a !== s)
        return a;
    } else if (r === !1 && typeof s < "u" && e !== s)
      return null;
  }
  return !1;
}
function Ln(i, t, e, s) {
  const n = t._rootScopes, o = Ur(t._fallback, e, s), r = [
    ...i,
    ...n
  ], a = /* @__PURE__ */ new Set();
  a.add(s);
  let l = ko(a, r, e, o || e, s);
  return l === null || typeof o < "u" && o !== e && (l = ko(a, r, o, l, s), l === null) ? !1 : Pn(Array.from(a), [
    ""
  ], n, o, () => Dc(t, e, s));
}
function ko(i, t, e, s, n) {
  for (; e; )
    e = Cc(i, t, e, s, n);
  return e;
}
function Dc(i, t, e) {
  const s = i._getTarget();
  t in s || (s[t] = {});
  const n = s[t];
  return Wt(n) && Dt(e) ? e : n || {};
}
function Ac(i, t, e, s) {
  let n;
  for (const o of t)
    if (n = Xr(wc(o, i), e), typeof n < "u")
      return Tn(i, n) ? Ln(e, s, i, n) : n;
}
function Xr(i, t) {
  for (const e of t) {
    if (!e)
      continue;
    const s = e[i];
    if (typeof s < "u")
      return s;
  }
}
function $o(i) {
  let t = i._keys;
  return t || (t = i._keys = Pc(i._scopes)), t;
}
function Pc(i) {
  const t = /* @__PURE__ */ new Set();
  for (const e of i)
    for (const s of Object.keys(e).filter((n) => !n.startsWith("_")))
      t.add(s);
  return Array.from(t);
}
const Tc = Number.EPSILON || 1e-14, ki = (i, t) => t < i.length && !i[t].skip && i[t], Gr = (i) => i === "x" ? "y" : "x";
function Lc(i, t, e, s) {
  const n = i.skip ? t : i, o = t, r = e.skip ? t : e, a = pn(o, n), l = pn(r, o);
  let d = a / (a + l), f = l / (a + l);
  d = isNaN(d) ? 0 : d, f = isNaN(f) ? 0 : f;
  const x = s * d, b = s * f;
  return {
    previous: {
      x: o.x - x * (r.x - n.x),
      y: o.y - x * (r.y - n.y)
    },
    next: {
      x: o.x + b * (r.x - n.x),
      y: o.y + b * (r.y - n.y)
    }
  };
}
function Oc(i, t, e) {
  const s = i.length;
  let n, o, r, a, l, d = ki(i, 0);
  for (let f = 0; f < s - 1; ++f)
    if (l = d, d = ki(i, f + 1), !(!l || !d)) {
      if (Wi(t[f], 0, Tc)) {
        e[f] = e[f + 1] = 0;
        continue;
      }
      n = e[f] / t[f], o = e[f + 1] / t[f], a = Math.pow(n, 2) + Math.pow(o, 2), !(a <= 9) && (r = 3 / Math.sqrt(a), e[f] = n * r * t[f], e[f + 1] = o * r * t[f]);
    }
}
function Ec(i, t, e = "x") {
  const s = Gr(e), n = i.length;
  let o, r, a, l = ki(i, 0);
  for (let d = 0; d < n; ++d) {
    if (r = a, a = l, l = ki(i, d + 1), !a)
      continue;
    const f = a[e], x = a[s];
    r && (o = (f - r[e]) / 3, a[`cp1${e}`] = f - o, a[`cp1${s}`] = x - o * t[d]), l && (o = (l[e] - f) / 3, a[`cp2${e}`] = f + o, a[`cp2${s}`] = x + o * t[d]);
  }
}
function Bc(i, t = "x") {
  const e = Gr(t), s = i.length, n = Array(s).fill(0), o = Array(s);
  let r, a, l, d = ki(i, 0);
  for (r = 0; r < s; ++r)
    if (a = l, l = d, d = ki(i, r + 1), !!l) {
      if (d) {
        const f = d[t] - l[t];
        n[r] = f !== 0 ? (d[e] - l[e]) / f : 0;
      }
      o[r] = a ? d ? _i(n[r - 1]) !== _i(n[r]) ? 0 : (n[r - 1] + n[r]) / 2 : n[r - 1] : n[r];
    }
  Oc(i, n, o), Ec(i, o, t);
}
function us(i, t, e) {
  return Math.max(Math.min(i, e), t);
}
function Ic(i, t) {
  let e, s, n, o, r, a = qi(i[0], t);
  for (e = 0, s = i.length; e < s; ++e)
    r = o, o = a, a = e < s - 1 && qi(i[e + 1], t), o && (n = i[e], r && (n.cp1x = us(n.cp1x, t.left, t.right), n.cp1y = us(n.cp1y, t.top, t.bottom)), a && (n.cp2x = us(n.cp2x, t.left, t.right), n.cp2y = us(n.cp2y, t.top, t.bottom)));
}
function Rc(i, t, e, s, n) {
  let o, r, a, l;
  if (t.spanGaps && (i = i.filter((d) => !d.skip)), t.cubicInterpolationMode === "monotone")
    Bc(i, n);
  else {
    let d = s ? i[i.length - 1] : i[0];
    for (o = 0, r = i.length; o < r; ++o)
      a = i[o], l = Lc(d, a, i[Math.min(o + 1, r - (s ? 0 : 1)) % r], t.tension), a.cp1x = l.previous.x, a.cp1y = l.previous.y, a.cp2x = l.next.x, a.cp2y = l.next.y, d = a;
  }
  t.capBezierPoints && Ic(i, e);
}
function On() {
  return typeof window < "u" && typeof document < "u";
}
function En(i) {
  let t = i.parentNode;
  return t && t.toString() === "[object ShadowRoot]" && (t = t.host), t;
}
function Ps(i, t, e) {
  let s;
  return typeof i == "string" ? (s = parseInt(i, 10), i.indexOf("%") !== -1 && (s = s / 100 * t.parentNode[e])) : s = i, s;
}
const Es = (i) => i.ownerDocument.defaultView.getComputedStyle(i, null);
function zc(i, t) {
  return Es(i).getPropertyValue(t);
}
const Fc = [
  "top",
  "right",
  "bottom",
  "left"
];
function Ze(i, t, e) {
  const s = {};
  e = e ? "-" + e : "";
  for (let n = 0; n < 4; n++) {
    const o = Fc[n];
    s[o] = parseFloat(i[t + "-" + o + e]) || 0;
  }
  return s.width = s.left + s.right, s.height = s.top + s.bottom, s;
}
const Hc = (i, t, e) => (i > 0 || t > 0) && (!e || !e.shadowRoot);
function jc(i, t) {
  const e = i.touches, s = e && e.length ? e[0] : i, { offsetX: n, offsetY: o } = s;
  let r = !1, a, l;
  if (Hc(n, o, i.target))
    a = n, l = o;
  else {
    const d = t.getBoundingClientRect();
    a = s.clientX - d.left, l = s.clientY - d.top, r = !0;
  }
  return {
    x: a,
    y: l,
    box: r
  };
}
function Ge(i, t) {
  if ("native" in i)
    return i;
  const { canvas: e, currentDevicePixelRatio: s } = t, n = Es(e), o = n.boxSizing === "border-box", r = Ze(n, "padding"), a = Ze(n, "border", "width"), { x: l, y: d, box: f } = jc(i, e), x = r.left + (f && a.left), b = r.top + (f && a.top);
  let { width: k, height: T } = t;
  return o && (k -= r.width + a.width, T -= r.height + a.height), {
    x: Math.round((l - x) / k * e.width / s),
    y: Math.round((d - b) / T * e.height / s)
  };
}
function Nc(i, t, e) {
  let s, n;
  if (t === void 0 || e === void 0) {
    const o = i && En(i);
    if (!o)
      t = i.clientWidth, e = i.clientHeight;
    else {
      const r = o.getBoundingClientRect(), a = Es(o), l = Ze(a, "border", "width"), d = Ze(a, "padding");
      t = r.width - d.width - l.width, e = r.height - d.height - l.height, s = Ps(a.maxWidth, o, "clientWidth"), n = Ps(a.maxHeight, o, "clientHeight");
    }
  }
  return {
    width: t,
    height: e,
    maxWidth: s || As,
    maxHeight: n || As
  };
}
const Re = (i) => Math.round(i * 10) / 10;
function Wc(i, t, e, s) {
  const n = Es(i), o = Ze(n, "margin"), r = Ps(n.maxWidth, i, "clientWidth") || As, a = Ps(n.maxHeight, i, "clientHeight") || As, l = Nc(i, t, e);
  let { width: d, height: f } = l;
  if (n.boxSizing === "content-box") {
    const b = Ze(n, "border", "width"), k = Ze(n, "padding");
    d -= k.width + b.width, f -= k.height + b.height;
  }
  return d = Math.max(0, d - o.width), f = Math.max(0, s ? d / s : f - o.height), d = Re(Math.min(d, r, l.maxWidth)), f = Re(Math.min(f, a, l.maxHeight)), d && !f && (f = Re(d / 2)), (t !== void 0 || e !== void 0) && s && l.height && f > l.height && (f = l.height, d = Re(Math.floor(f * s))), {
    width: d,
    height: f
  };
}
function Mo(i, t, e) {
  const s = t || 1, n = Re(i.height * s), o = Re(i.width * s);
  i.height = Re(i.height), i.width = Re(i.width);
  const r = i.canvas;
  return r.style && (e || !r.style.height && !r.style.width) && (r.style.height = `${i.height}px`, r.style.width = `${i.width}px`), i.currentDevicePixelRatio !== s || r.height !== n || r.width !== o ? (i.currentDevicePixelRatio = s, r.height = n, r.width = o, i.ctx.setTransform(s, 0, 0, s, 0, 0), !0) : !1;
}
const Vc = (function() {
  let i = !1;
  try {
    const t = {
      get passive() {
        return i = !0, !1;
      }
    };
    On() && (window.addEventListener("test", null, t), window.removeEventListener("test", null, t));
  } catch {
  }
  return i;
})();
function So(i, t) {
  const e = zc(i, t), s = e && e.match(/^(\d+)(\.\d+)?px$/);
  return s ? +s[1] : void 0;
}
function qe(i, t, e, s) {
  return {
    x: i.x + e * (t.x - i.x),
    y: i.y + e * (t.y - i.y)
  };
}
function Yc(i, t, e, s) {
  return {
    x: i.x + e * (t.x - i.x),
    y: s === "middle" ? e < 0.5 ? i.y : t.y : s === "after" ? e < 1 ? i.y : t.y : e > 0 ? t.y : i.y
  };
}
function Uc(i, t, e, s) {
  const n = {
    x: i.cp2x,
    y: i.cp2y
  }, o = {
    x: t.cp1x,
    y: t.cp1y
  }, r = qe(i, n, e), a = qe(n, o, e), l = qe(o, t, e), d = qe(r, a, e), f = qe(a, l, e);
  return qe(d, f, e);
}
const Xc = function(i, t) {
  return {
    x(e) {
      return i + i + t - e;
    },
    setWidth(e) {
      t = e;
    },
    textAlign(e) {
      return e === "center" ? e : e === "right" ? "left" : "right";
    },
    xPlus(e, s) {
      return e - s;
    },
    leftForLtr(e, s) {
      return e - s;
    }
  };
}, Gc = function() {
  return {
    x(i) {
      return i;
    },
    setWidth(i) {
    },
    textAlign(i) {
      return i;
    },
    xPlus(i, t) {
      return i + t;
    },
    leftForLtr(i, t) {
      return i;
    }
  };
};
function bi(i, t, e) {
  return i ? Xc(t, e) : Gc();
}
function qr(i, t) {
  let e, s;
  (t === "ltr" || t === "rtl") && (e = i.canvas.style, s = [
    e.getPropertyValue("direction"),
    e.getPropertyPriority("direction")
  ], e.setProperty("direction", t, "important"), i.prevTextDirection = s);
}
function Kr(i, t) {
  t !== void 0 && (delete i.prevTextDirection, i.canvas.style.setProperty("direction", t[0], t[1]));
}
function Jr(i) {
  return i === "angle" ? {
    between: Er,
    compare: Xl,
    normalize: xe
  } : {
    between: xi,
    compare: (t, e) => t - e,
    normalize: (t) => t
  };
}
function Co({ start: i, end: t, count: e, loop: s, style: n }) {
  return {
    start: i % e,
    end: t % e,
    loop: s && (t - i + 1) % e === 0,
    style: n
  };
}
function qc(i, t, e) {
  const { property: s, start: n, end: o } = e, { between: r, normalize: a } = Jr(s), l = t.length;
  let { start: d, end: f, loop: x } = i, b, k;
  if (x) {
    for (d += l, f += l, b = 0, k = l; b < k && r(a(t[d % l][s]), n, o); ++b)
      d--, f--;
    d %= l, f %= l;
  }
  return f < d && (f += l), {
    start: d,
    end: f,
    loop: x,
    style: i.style
  };
}
function Zr(i, t, e) {
  if (!e)
    return [
      i
    ];
  const { property: s, start: n, end: o } = e, r = t.length, { compare: a, between: l, normalize: d } = Jr(s), { start: f, end: x, loop: b, style: k } = qc(i, t, e), T = [];
  let C = !1, A = null, P, z, O;
  const W = () => l(n, O, P) && a(n, O) !== 0, R = () => a(o, P) === 0 || l(o, O, P), Y = () => C || W(), B = () => !C || R();
  for (let H = f, it = f; H <= x; ++H)
    z = t[H % r], !z.skip && (P = d(z[s]), P !== O && (C = l(P, n, o), A === null && Y() && (A = a(P, n) === 0 ? H : it), A !== null && B() && (T.push(Co({
      start: A,
      end: H,
      loop: b,
      count: r,
      style: k
    })), A = null), it = H, O = P));
  return A !== null && T.push(Co({
    start: A,
    end: x,
    loop: b,
    count: r,
    style: k
  })), T;
}
function Qr(i, t) {
  const e = [], s = i.segments;
  for (let n = 0; n < s.length; n++) {
    const o = Zr(s[n], i.points, t);
    o.length && e.push(...o);
  }
  return e;
}
function Kc(i, t, e, s) {
  let n = 0, o = t - 1;
  if (e && !s)
    for (; n < t && !i[n].skip; )
      n++;
  for (; n < t && i[n].skip; )
    n++;
  for (n %= t, e && (o += n); o > n && i[o % t].skip; )
    o--;
  return o %= t, {
    start: n,
    end: o
  };
}
function Jc(i, t, e, s) {
  const n = i.length, o = [];
  let r = t, a = i[t], l;
  for (l = t + 1; l <= e; ++l) {
    const d = i[l % n];
    d.skip || d.stop ? a.skip || (s = !1, o.push({
      start: t % n,
      end: (l - 1) % n,
      loop: s
    }), t = r = d.stop ? l : null) : (r = l, a.skip && (t = l)), a = d;
  }
  return r !== null && o.push({
    start: t % n,
    end: r % n,
    loop: s
  }), o;
}
function Zc(i, t) {
  const e = i.points, s = i.options.spanGaps, n = e.length;
  if (!n)
    return [];
  const o = !!i._loop, { start: r, end: a } = Kc(e, n, o, s);
  if (s === !0)
    return Do(i, [
      {
        start: r,
        end: a,
        loop: o
      }
    ], e, t);
  const l = a < r ? a + n : a, d = !!i._fullLoop && r === 0 && a === n - 1;
  return Do(i, Jc(e, r, l, d), e, t);
}
function Do(i, t, e, s) {
  return !s || !s.setContext || !e ? t : Qc(i, t, e, s);
}
function Qc(i, t, e, s) {
  const n = i._chart.getContext(), o = Ao(i.options), { _datasetIndex: r, options: { spanGaps: a } } = i, l = e.length, d = [];
  let f = o, x = t[0].start, b = x;
  function k(T, C, A, P) {
    const z = a ? -1 : 1;
    if (T !== C) {
      for (T += l; e[T % l].skip; )
        T -= z;
      for (; e[C % l].skip; )
        C += z;
      T % l !== C % l && (d.push({
        start: T % l,
        end: C % l,
        loop: A,
        style: P
      }), f = P, x = C % l);
    }
  }
  for (const T of t) {
    x = a ? x : T.start;
    let C = e[x % l], A;
    for (b = x + 1; b <= T.end; b++) {
      const P = e[b % l];
      A = Ao(s.setContext(ei(n, {
        type: "segment",
        p0: C,
        p1: P,
        p0DataIndex: (b - 1) % l,
        p1DataIndex: b % l,
        datasetIndex: r
      }))), t0(A, f) && k(x, b - 1, T.loop, f), C = P, f = A;
    }
    x < b - 1 && k(x, b - 1, T.loop, f);
  }
  return d;
}
function Ao(i) {
  return {
    backgroundColor: i.backgroundColor,
    borderCapStyle: i.borderCapStyle,
    borderDash: i.borderDash,
    borderDashOffset: i.borderDashOffset,
    borderJoinStyle: i.borderJoinStyle,
    borderWidth: i.borderWidth,
    borderColor: i.borderColor
  };
}
function t0(i, t) {
  if (!t)
    return !1;
  const e = [], s = function(n, o) {
    return An(o) ? (e.includes(o) || e.push(o), e.indexOf(o)) : o;
  };
  return JSON.stringify(i, s) !== JSON.stringify(t, s);
}
function fs(i, t, e) {
  return i.options.clip ? i[e] : t[e];
}
function e0(i, t) {
  const { xScale: e, yScale: s } = i;
  return e && s ? {
    left: fs(e, t, "left"),
    right: fs(e, t, "right"),
    top: fs(s, t, "top"),
    bottom: fs(s, t, "bottom")
  } : t;
}
function ta(i, t) {
  const e = t._clip;
  if (e.disabled)
    return !1;
  const s = e0(t, i.chartArea);
  return {
    left: e.left === !1 ? 0 : s.left - (e.left === !0 ? 0 : e.left),
    right: e.right === !1 ? i.width : s.right + (e.right === !0 ? 0 : e.right),
    top: e.top === !1 ? 0 : s.top - (e.top === !0 ? 0 : e.top),
    bottom: e.bottom === !1 ? i.height : s.bottom + (e.bottom === !0 ? 0 : e.bottom)
  };
}
class i0 {
  constructor() {
    this._request = null, this._charts = /* @__PURE__ */ new Map(), this._running = !1, this._lastDate = void 0;
  }
  _notify(t, e, s, n) {
    const o = e.listeners[n], r = e.duration;
    o.forEach((a) => a({
      chart: t,
      initial: e.initial,
      numSteps: r,
      currentStep: Math.min(s - e.start, r)
    }));
  }
  _refresh() {
    this._request || (this._running = !0, this._request = Ir.call(window, () => {
      this._update(), this._request = null, this._running && this._refresh();
    }));
  }
  _update(t = Date.now()) {
    let e = 0;
    this._charts.forEach((s, n) => {
      if (!s.running || !s.items.length)
        return;
      const o = s.items;
      let r = o.length - 1, a = !1, l;
      for (; r >= 0; --r)
        l = o[r], l._active ? (l._total > s.duration && (s.duration = l._total), l.tick(t), a = !0) : (o[r] = o[o.length - 1], o.pop());
      a && (n.draw(), this._notify(n, s, t, "progress")), o.length || (s.running = !1, this._notify(n, s, t, "complete"), s.initial = !1), e += o.length;
    }), this._lastDate = t, e === 0 && (this._running = !1);
  }
  _getAnims(t) {
    const e = this._charts;
    let s = e.get(t);
    return s || (s = {
      running: !1,
      initial: !0,
      items: [],
      listeners: {
        complete: [],
        progress: []
      }
    }, e.set(t, s)), s;
  }
  listen(t, e, s) {
    this._getAnims(t).listeners[e].push(s);
  }
  add(t, e) {
    !e || !e.length || this._getAnims(t).items.push(...e);
  }
  has(t) {
    return this._getAnims(t).items.length > 0;
  }
  start(t) {
    const e = this._charts.get(t);
    e && (e.running = !0, e.start = Date.now(), e.duration = e.items.reduce((s, n) => Math.max(s, n._duration), 0), this._refresh());
  }
  running(t) {
    if (!this._running)
      return !1;
    const e = this._charts.get(t);
    return !(!e || !e.running || !e.items.length);
  }
  stop(t) {
    const e = this._charts.get(t);
    if (!e || !e.items.length)
      return;
    const s = e.items;
    let n = s.length - 1;
    for (; n >= 0; --n)
      s[n].cancel();
    e.items = [], this._notify(t, e, Date.now(), "complete");
  }
  remove(t) {
    return this._charts.delete(t);
  }
}
var $e = /* @__PURE__ */ new i0();
const Po = "transparent", s0 = {
  boolean(i, t, e) {
    return e > 0.5 ? t : i;
  },
  color(i, t, e) {
    const s = bo(i || Po), n = s.valid && bo(t || Po);
    return n && n.valid ? n.mix(s, e).hexString() : t;
  },
  number(i, t, e) {
    return i + (t - i) * e;
  }
};
class n0 {
  constructor(t, e, s, n) {
    const o = e[s];
    n = ds([
      t.to,
      n,
      o,
      t.from
    ]);
    const r = ds([
      t.from,
      o,
      n
    ]);
    this._active = !0, this._fn = t.fn || s0[t.type || typeof r], this._easing = Vi[t.easing] || Vi.linear, this._start = Math.floor(Date.now() + (t.delay || 0)), this._duration = this._total = Math.floor(t.duration), this._loop = !!t.loop, this._target = e, this._prop = s, this._from = r, this._to = n, this._promises = void 0;
  }
  active() {
    return this._active;
  }
  update(t, e, s) {
    if (this._active) {
      this._notify(!1);
      const n = this._target[this._prop], o = s - this._start, r = this._duration - o;
      this._start = s, this._duration = Math.floor(Math.max(r, t.duration)), this._total += o, this._loop = !!t.loop, this._to = ds([
        t.to,
        e,
        n,
        t.from
      ]), this._from = ds([
        t.from,
        n,
        e
      ]);
    }
  }
  cancel() {
    this._active && (this.tick(Date.now()), this._active = !1, this._notify(!1));
  }
  tick(t) {
    const e = t - this._start, s = this._duration, n = this._prop, o = this._from, r = this._loop, a = this._to;
    let l;
    if (this._active = o !== a && (r || e < s), !this._active) {
      this._target[n] = a, this._notify(!0);
      return;
    }
    if (e < 0) {
      this._target[n] = o;
      return;
    }
    l = e / s % 2, l = r && l > 1 ? 2 - l : l, l = this._easing(Math.min(1, Math.max(0, l))), this._target[n] = this._fn(o, a, l);
  }
  wait() {
    const t = this._promises || (this._promises = []);
    return new Promise((e, s) => {
      t.push({
        res: e,
        rej: s
      });
    });
  }
  _notify(t) {
    const e = t ? "res" : "rej", s = this._promises || [];
    for (let n = 0; n < s.length; n++)
      s[n][e]();
  }
}
class ea {
  constructor(t, e) {
    this._chart = t, this._properties = /* @__PURE__ */ new Map(), this.configure(e);
  }
  configure(t) {
    if (!Dt(t))
      return;
    const e = Object.keys(Ht.animation), s = this._properties;
    Object.getOwnPropertyNames(t).forEach((n) => {
      const o = t[n];
      if (!Dt(o))
        return;
      const r = {};
      for (const a of e)
        r[a] = o[a];
      (Wt(o.properties) && o.properties || [
        n
      ]).forEach((a) => {
        (a === n || !s.has(a)) && s.set(a, r);
      });
    });
  }
  _animateOptions(t, e) {
    const s = e.options, n = r0(t, s);
    if (!n)
      return [];
    const o = this._createAnimations(n, s);
    return s.$shared && o0(t.options.$animations, s).then(() => {
      t.options = s;
    }, () => {
    }), o;
  }
  _createAnimations(t, e) {
    const s = this._properties, n = [], o = t.$animations || (t.$animations = {}), r = Object.keys(e), a = Date.now();
    let l;
    for (l = r.length - 1; l >= 0; --l) {
      const d = r[l];
      if (d.charAt(0) === "$")
        continue;
      if (d === "options") {
        n.push(...this._animateOptions(t, e));
        continue;
      }
      const f = e[d];
      let x = o[d];
      const b = s.get(d);
      if (x)
        if (b && x.active()) {
          x.update(b, f, a);
          continue;
        } else
          x.cancel();
      if (!b || !b.duration) {
        t[d] = f;
        continue;
      }
      o[d] = x = new n0(b, t, d, f), n.push(x);
    }
    return n;
  }
  update(t, e) {
    if (this._properties.size === 0) {
      Object.assign(t, e);
      return;
    }
    const s = this._createAnimations(t, e);
    if (s.length)
      return $e.add(this._chart, s), !0;
  }
}
function o0(i, t) {
  const e = [], s = Object.keys(t);
  for (let n = 0; n < s.length; n++) {
    const o = i[s[n]];
    o && o.active() && e.push(o.wait());
  }
  return Promise.all(e);
}
function r0(i, t) {
  if (!t)
    return;
  let e = i.options;
  if (!e) {
    i.options = t;
    return;
  }
  return e.$shared && (i.options = e = Object.assign({}, e, {
    $shared: !1,
    $animations: {}
  })), e;
}
function To(i, t) {
  const e = i && i.options || {}, s = e.reverse, n = e.min === void 0 ? t : 0, o = e.max === void 0 ? t : 0;
  return {
    start: s ? o : n,
    end: s ? n : o
  };
}
function a0(i, t, e) {
  if (e === !1)
    return !1;
  const s = To(i, e), n = To(t, e);
  return {
    top: n.end,
    right: s.end,
    bottom: n.start,
    left: s.start
  };
}
function l0(i) {
  let t, e, s, n;
  return Dt(i) ? (t = i.top, e = i.right, s = i.bottom, n = i.left) : t = e = s = n = i, {
    top: t,
    right: e,
    bottom: s,
    left: n,
    disabled: i === !1
  };
}
function ia(i, t) {
  const e = [], s = i._getSortedDatasetMetas(t);
  let n, o;
  for (n = 0, o = s.length; n < o; ++n)
    e.push(s[n].index);
  return e;
}
function Lo(i, t, e, s = {}) {
  const n = i.keys, o = s.mode === "single";
  let r, a, l, d;
  if (t === null)
    return;
  let f = !1;
  for (r = 0, a = n.length; r < a; ++r) {
    if (l = +n[r], l === e) {
      if (f = !0, s.all)
        continue;
      break;
    }
    d = i.values[l], qt(d) && (o || t === 0 || _i(t) === _i(d)) && (t += d);
  }
  return !f && !s.all ? 0 : t;
}
function c0(i, t) {
  const { iScale: e, vScale: s } = t, n = e.axis === "x" ? "x" : "y", o = s.axis === "x" ? "x" : "y", r = Object.keys(i), a = new Array(r.length);
  let l, d, f;
  for (l = 0, d = r.length; l < d; ++l)
    f = r[l], a[l] = {
      [n]: f,
      [o]: i[f]
    };
  return a;
}
function tn(i, t) {
  const e = i && i.options.stacked;
  return e || e === void 0 && t.stack !== void 0;
}
function h0(i, t, e) {
  return `${i.id}.${t.id}.${e.stack || e.type}`;
}
function d0(i) {
  const { min: t, max: e, minDefined: s, maxDefined: n } = i.getUserBounds();
  return {
    min: s ? t : Number.NEGATIVE_INFINITY,
    max: n ? e : Number.POSITIVE_INFINITY
  };
}
function u0(i, t, e) {
  const s = i[t] || (i[t] = {});
  return s[e] || (s[e] = {});
}
function Oo(i, t, e, s) {
  for (const n of t.getMatchingVisibleMetas(s).reverse()) {
    const o = i[n.index];
    if (e && o > 0 || !e && o < 0)
      return n.index;
  }
  return null;
}
function Eo(i, t) {
  const { chart: e, _cachedMeta: s } = i, n = e._stacks || (e._stacks = {}), { iScale: o, vScale: r, index: a } = s, l = o.axis, d = r.axis, f = h0(o, r, s), x = t.length;
  let b;
  for (let k = 0; k < x; ++k) {
    const T = t[k], { [l]: C, [d]: A } = T, P = T._stacks || (T._stacks = {});
    b = P[d] = u0(n, f, C), b[a] = A, b._top = Oo(b, r, !0, s.type), b._bottom = Oo(b, r, !1, s.type);
    const z = b._visualValues || (b._visualValues = {});
    z[a] = A;
  }
}
function en(i, t) {
  const e = i.scales;
  return Object.keys(e).filter((s) => e[s].axis === t).shift();
}
function f0(i, t) {
  return ei(i, {
    active: !1,
    dataset: void 0,
    datasetIndex: t,
    index: t,
    mode: "default",
    type: "dataset"
  });
}
function p0(i, t, e) {
  return ei(i, {
    active: !1,
    dataIndex: t,
    parsed: void 0,
    raw: void 0,
    element: e,
    index: t,
    mode: "default",
    type: "data"
  });
}
function Ei(i, t) {
  const e = i.controller.index, s = i.vScale && i.vScale.axis;
  if (s) {
    t = t || i._parsed;
    for (const n of t) {
      const o = n._stacks;
      if (!o || o[s] === void 0 || o[s][e] === void 0)
        return;
      delete o[s][e], o[s]._visualValues !== void 0 && o[s]._visualValues[e] !== void 0 && delete o[s]._visualValues[e];
    }
  }
}
const sn = (i) => i === "reset" || i === "none", Bo = (i, t) => t ? i : Object.assign({}, i), g0 = (i, t, e) => i && !t.hidden && t._stacked && {
  keys: ia(e, !0),
  values: null
};
class Bn {
  static defaults = {};
  static datasetElementType = null;
  static dataElementType = null;
  constructor(t, e) {
    this.chart = t, this._ctx = t.ctx, this.index = e, this._cachedDataOpts = {}, this._cachedMeta = this.getMeta(), this._type = this._cachedMeta.type, this.options = void 0, this._parsing = !1, this._data = void 0, this._objectData = void 0, this._sharedOptions = void 0, this._drawStart = void 0, this._drawCount = void 0, this.enableOptionSharing = !1, this.supportsDecimation = !1, this.$context = void 0, this._syncList = [], this.datasetElementType = new.target.datasetElementType, this.dataElementType = new.target.dataElementType, this.initialize();
  }
  initialize() {
    const t = this._cachedMeta;
    this.configure(), this.linkScales(), t._stacked = tn(t.vScale, t), this.addElements(), this.options.fill && !this.chart.isPluginEnabled("filler") && console.warn("Tried to use the 'fill' option without the 'Filler' plugin enabled. Please import and register the 'Filler' plugin and make sure it is not disabled in the options");
  }
  updateIndex(t) {
    this.index !== t && Ei(this._cachedMeta), this.index = t;
  }
  linkScales() {
    const t = this.chart, e = this._cachedMeta, s = this.getDataset(), n = (x, b, k, T) => x === "x" ? b : x === "r" ? T : k, o = e.xAxisID = Ct(s.xAxisID, en(t, "x")), r = e.yAxisID = Ct(s.yAxisID, en(t, "y")), a = e.rAxisID = Ct(s.rAxisID, en(t, "r")), l = e.indexAxis, d = e.iAxisID = n(l, o, r, a), f = e.vAxisID = n(l, r, o, a);
    e.xScale = this.getScaleForId(o), e.yScale = this.getScaleForId(r), e.rScale = this.getScaleForId(a), e.iScale = this.getScaleForId(d), e.vScale = this.getScaleForId(f);
  }
  getDataset() {
    return this.chart.data.datasets[this.index];
  }
  getMeta() {
    return this.chart.getDatasetMeta(this.index);
  }
  getScaleForId(t) {
    return this.chart.scales[t];
  }
  _getOtherScale(t) {
    const e = this._cachedMeta;
    return t === e.iScale ? e.vScale : e.iScale;
  }
  reset() {
    this._update("reset");
  }
  _destroy() {
    const t = this._cachedMeta;
    this._data && mo(this._data, this), t._stacked && Ei(t);
  }
  _dataCheck() {
    const t = this.getDataset(), e = t.data || (t.data = []), s = this._data;
    if (Dt(e)) {
      const n = this._cachedMeta;
      this._data = c0(e, n);
    } else if (s !== e) {
      if (s) {
        mo(s, this);
        const n = this._cachedMeta;
        Ei(n), n._parsed = [];
      }
      e && Object.isExtensible(e) && Jl(e, this), this._syncList = [], this._data = e;
    }
  }
  addElements() {
    const t = this._cachedMeta;
    this._dataCheck(), this.datasetElementType && (t.dataset = new this.datasetElementType());
  }
  buildOrUpdateElements(t) {
    const e = this._cachedMeta, s = this.getDataset();
    let n = !1;
    this._dataCheck();
    const o = e._stacked;
    e._stacked = tn(e.vScale, e), e.stack !== s.stack && (n = !0, Ei(e), e.stack = s.stack), this._resyncElements(t), (n || o !== e._stacked) && (Eo(this, e._parsed), e._stacked = tn(e.vScale, e));
  }
  configure() {
    const t = this.chart.config, e = t.datasetScopeKeys(this._type), s = t.getOptionScopes(this.getDataset(), e, !0);
    this.options = t.createResolver(s, this.getContext()), this._parsing = this.options.parsing, this._cachedDataOpts = {};
  }
  parse(t, e) {
    const { _cachedMeta: s, _data: n } = this, { iScale: o, _stacked: r } = s, a = o.axis;
    let l = t === 0 && e === n.length ? !0 : s._sorted, d = t > 0 && s._parsed[t - 1], f, x, b;
    if (this._parsing === !1)
      s._parsed = n, s._sorted = !0, b = n;
    else {
      Wt(n[t]) ? b = this.parseArrayData(s, n, t, e) : Dt(n[t]) ? b = this.parseObjectData(s, n, t, e) : b = this.parsePrimitiveData(s, n, t, e);
      const k = () => x[a] === null || d && x[a] < d[a];
      for (f = 0; f < e; ++f)
        s._parsed[f + t] = x = b[f], l && (k() && (l = !1), d = x);
      s._sorted = l;
    }
    r && Eo(this, b);
  }
  parsePrimitiveData(t, e, s, n) {
    const { iScale: o, vScale: r } = t, a = o.axis, l = r.axis, d = o.getLabels(), f = o === r, x = new Array(n);
    let b, k, T;
    for (b = 0, k = n; b < k; ++b)
      T = b + s, x[b] = {
        [a]: f || o.parse(d[T], T),
        [l]: r.parse(e[T], T)
      };
    return x;
  }
  parseArrayData(t, e, s, n) {
    const { xScale: o, yScale: r } = t, a = new Array(n);
    let l, d, f, x;
    for (l = 0, d = n; l < d; ++l)
      f = l + s, x = e[f], a[l] = {
        x: o.parse(x[0], f),
        y: r.parse(x[1], f)
      };
    return a;
  }
  parseObjectData(t, e, s, n) {
    const { xScale: o, yScale: r } = t, { xAxisKey: a = "x", yAxisKey: l = "y" } = this._parsing, d = new Array(n);
    let f, x, b, k;
    for (f = 0, x = n; f < x; ++f)
      b = f + s, k = e[b], d[f] = {
        x: o.parse(Cs(k, a), b),
        y: r.parse(Cs(k, l), b)
      };
    return d;
  }
  getParsed(t) {
    return this._cachedMeta._parsed[t];
  }
  getDataElement(t) {
    return this._cachedMeta.data[t];
  }
  applyStack(t, e, s) {
    const n = this.chart, o = this._cachedMeta, r = e[t.axis], a = {
      keys: ia(n, !0),
      values: e._stacks[t.axis]._visualValues
    };
    return Lo(a, r, o.index, {
      mode: s
    });
  }
  updateRangeFromParsed(t, e, s, n) {
    const o = s[e.axis];
    let r = o === null ? NaN : o;
    const a = n && s._stacks[e.axis];
    n && a && (n.values = a, r = Lo(n, o, this._cachedMeta.index)), t.min = Math.min(t.min, r), t.max = Math.max(t.max, r);
  }
  getMinMax(t, e) {
    const s = this._cachedMeta, n = s._parsed, o = s._sorted && t === s.iScale, r = n.length, a = this._getOtherScale(t), l = g0(e, s, this.chart), d = {
      min: Number.POSITIVE_INFINITY,
      max: Number.NEGATIVE_INFINITY
    }, { min: f, max: x } = d0(a);
    let b, k;
    function T() {
      k = n[b];
      const C = k[a.axis];
      return !qt(k[t.axis]) || f > C || x < C;
    }
    for (b = 0; b < r && !(!T() && (this.updateRangeFromParsed(d, t, k, l), o)); ++b)
      ;
    if (o) {
      for (b = r - 1; b >= 0; --b)
        if (!T()) {
          this.updateRangeFromParsed(d, t, k, l);
          break;
        }
    }
    return d;
  }
  getAllParsedValues(t) {
    const e = this._cachedMeta._parsed, s = [];
    let n, o, r;
    for (n = 0, o = e.length; n < o; ++n)
      r = e[n][t.axis], qt(r) && s.push(r);
    return s;
  }
  getMaxOverflow() {
    return !1;
  }
  getLabelAndValue(t) {
    const e = this._cachedMeta, s = e.iScale, n = e.vScale, o = this.getParsed(t);
    return {
      label: s ? "" + s.getLabelForValue(o[s.axis]) : "",
      value: n ? "" + n.getLabelForValue(o[n.axis]) : ""
    };
  }
  _update(t) {
    const e = this._cachedMeta;
    this.update(t || "default"), e._clip = l0(Ct(this.options.clip, a0(e.xScale, e.yScale, this.getMaxOverflow())));
  }
  update(t) {
  }
  draw() {
    const t = this._ctx, e = this.chart, s = this._cachedMeta, n = s.data || [], o = e.chartArea, r = [], a = this._drawStart || 0, l = this._drawCount || n.length - a, d = this.options.drawActiveElementsOnTop;
    let f;
    for (s.dataset && s.dataset.draw(t, o, a, l), f = a; f < a + l; ++f) {
      const x = n[f];
      x.hidden || (x.active && d ? r.push(x) : x.draw(t, o));
    }
    for (f = 0; f < r.length; ++f)
      r[f].draw(t, o);
  }
  getStyle(t, e) {
    const s = e ? "active" : "default";
    return t === void 0 && this._cachedMeta.dataset ? this.resolveDatasetElementOptions(s) : this.resolveDataElementOptions(t || 0, s);
  }
  getContext(t, e, s) {
    const n = this.getDataset();
    let o;
    if (t >= 0 && t < this._cachedMeta.data.length) {
      const r = this._cachedMeta.data[t];
      o = r.$context || (r.$context = p0(this.getContext(), t, r)), o.parsed = this.getParsed(t), o.raw = n.data[t], o.index = o.dataIndex = t;
    } else
      o = this.$context || (this.$context = f0(this.chart.getContext(), this.index)), o.dataset = n, o.index = o.datasetIndex = this.index;
    return o.active = !!e, o.mode = s, o;
  }
  resolveDatasetElementOptions(t) {
    return this._resolveElementOptions(this.datasetElementType.id, t);
  }
  resolveDataElementOptions(t, e) {
    return this._resolveElementOptions(this.dataElementType.id, e, t);
  }
  _resolveElementOptions(t, e = "default", s) {
    const n = e === "active", o = this._cachedDataOpts, r = t + "-" + e, a = o[r], l = this.enableOptionSharing && Ds(s);
    if (a)
      return Bo(a, l);
    const d = this.chart.config, f = d.datasetElementScopeKeys(this._type, t), x = n ? [
      `${t}Hover`,
      "hover",
      t,
      ""
    ] : [
      t,
      ""
    ], b = d.getOptionScopes(this.getDataset(), f), k = Object.keys(Ht.elements[t]), T = () => this.getContext(s, n, e), C = d.resolveNamedOptions(b, k, T, x);
    return C.$shared && (C.$shared = l, o[r] = Object.freeze(Bo(C, l))), C;
  }
  _resolveAnimations(t, e, s) {
    const n = this.chart, o = this._cachedDataOpts, r = `animation-${e}`, a = o[r];
    if (a)
      return a;
    let l;
    if (n.options.animation !== !1) {
      const f = this.chart.config, x = f.datasetAnimationScopeKeys(this._type, e), b = f.getOptionScopes(this.getDataset(), x);
      l = f.createResolver(b, this.getContext(t, s, e));
    }
    const d = new ea(n, l && l.animations);
    return l && l._cacheable && (o[r] = Object.freeze(d)), d;
  }
  getSharedOptions(t) {
    if (t.$shared)
      return this._sharedOptions || (this._sharedOptions = Object.assign({}, t));
  }
  includeOptions(t, e) {
    return !e || sn(t) || this.chart._animationsDisabled;
  }
  _getSharedOptions(t, e) {
    const s = this.resolveDataElementOptions(t, e), n = this._sharedOptions, o = this.getSharedOptions(s), r = this.includeOptions(e, o) || o !== n;
    return this.updateSharedOptions(o, e, s), {
      sharedOptions: o,
      includeOptions: r
    };
  }
  updateElement(t, e, s, n) {
    sn(n) ? Object.assign(t, s) : this._resolveAnimations(e, n).update(t, s);
  }
  updateSharedOptions(t, e, s) {
    t && !sn(e) && this._resolveAnimations(void 0, e).update(t, s);
  }
  _setStyle(t, e, s, n) {
    t.active = n;
    const o = this.getStyle(e, n);
    this._resolveAnimations(e, s, n).update(t, {
      options: !n && this.getSharedOptions(o) || o
    });
  }
  removeHoverStyle(t, e, s) {
    this._setStyle(t, s, "active", !1);
  }
  setHoverStyle(t, e, s) {
    this._setStyle(t, s, "active", !0);
  }
  _removeDatasetHoverStyle() {
    const t = this._cachedMeta.dataset;
    t && this._setStyle(t, void 0, "active", !1);
  }
  _setDatasetHoverStyle() {
    const t = this._cachedMeta.dataset;
    t && this._setStyle(t, void 0, "active", !0);
  }
  _resyncElements(t) {
    const e = this._data, s = this._cachedMeta.data;
    for (const [a, l, d] of this._syncList)
      this[a](l, d);
    this._syncList = [];
    const n = s.length, o = e.length, r = Math.min(o, n);
    r && this.parse(0, r), o > n ? this._insertElements(n, o - n, t) : o < n && this._removeElements(o, n - o);
  }
  _insertElements(t, e, s = !0) {
    const n = this._cachedMeta, o = n.data, r = t + e;
    let a;
    const l = (d) => {
      for (d.length += e, a = d.length - 1; a >= r; a--)
        d[a] = d[a - e];
    };
    for (l(o), a = t; a < r; ++a)
      o[a] = new this.dataElementType();
    this._parsing && l(n._parsed), this.parse(t, e), s && this.updateElements(o, t, e, "reset");
  }
  updateElements(t, e, s, n) {
  }
  _removeElements(t, e) {
    const s = this._cachedMeta;
    if (this._parsing) {
      const n = s._parsed.splice(t, e);
      s._stacked && Ei(s, n);
    }
    s.data.splice(t, e);
  }
  _sync(t) {
    if (this._parsing)
      this._syncList.push(t);
    else {
      const [e, s, n] = t;
      this[e](s, n);
    }
    this.chart._dataChanges.push([
      this.index,
      ...t
    ]);
  }
  _onDataPush() {
    const t = arguments.length;
    this._sync([
      "_insertElements",
      this.getDataset().data.length - t,
      t
    ]);
  }
  _onDataPop() {
    this._sync([
      "_removeElements",
      this._cachedMeta.data.length - 1,
      1
    ]);
  }
  _onDataShift() {
    this._sync([
      "_removeElements",
      0,
      1
    ]);
  }
  _onDataSplice(t, e) {
    e && this._sync([
      "_removeElements",
      t,
      e
    ]);
    const s = arguments.length - 2;
    s && this._sync([
      "_insertElements",
      t,
      s
    ]);
  }
  _onDataUnshift() {
    this._sync([
      "_insertElements",
      0,
      arguments.length
    ]);
  }
}
class sa extends Bn {
  static id = "line";
  static defaults = {
    datasetElementType: "line",
    dataElementType: "point",
    showLine: !0,
    spanGaps: !1
  };
  static overrides = {
    scales: {
      _index_: {
        type: "category"
      },
      _value_: {
        type: "linear"
      }
    }
  };
  initialize() {
    this.enableOptionSharing = !0, this.supportsDecimation = !0, super.initialize();
  }
  update(t) {
    const e = this._cachedMeta, { dataset: s, data: n = [], _dataset: o } = e, r = this.chart._animationsDisabled;
    let { start: a, count: l } = zr(e, n, r);
    this._drawStart = a, this._drawCount = l, Fr(e) && (a = 0, l = n.length), s._chart = this.chart, s._datasetIndex = this.index, s._decimated = !!o._decimated, s.points = n;
    const d = this.resolveDatasetElementOptions(t);
    this.options.showLine || (d.borderWidth = 0), d.segment = this.options.segment, this.updateElement(s, void 0, {
      animated: !r,
      options: d
    }, t), this.updateElements(n, a, l, t);
  }
  updateElements(t, e, s, n) {
    const o = n === "reset", { iScale: r, vScale: a, _stacked: l, _dataset: d } = this._cachedMeta, { sharedOptions: f, includeOptions: x } = this._getSharedOptions(e, n), b = r.axis, k = a.axis, { spanGaps: T, segment: C } = this.options, A = vi(T) ? T : Number.POSITIVE_INFINITY, P = this.chart._animationsDisabled || o || n === "none", z = e + s, O = t.length;
    let W = e > 0 && this.getParsed(e - 1);
    for (let R = 0; R < O; ++R) {
      const Y = t[R], B = P ? Y : {};
      if (R < e || R >= z) {
        B.skip = !0;
        continue;
      }
      const H = this.getParsed(R), it = It(H[k]), ct = B[b] = r.getPixelForValue(H[b], R), X = B[k] = o || it ? a.getBasePixel() : a.getPixelForValue(l ? this.applyStack(a, H, l) : H[k], R);
      B.skip = isNaN(ct) || isNaN(X) || it, B.stop = R > 0 && Math.abs(H[b] - W[b]) > A, C && (B.parsed = H, B.raw = d.data[R]), x && (B.options = f || this.resolveDataElementOptions(R, Y.active ? "active" : n)), P || this.updateElement(Y, R, B, n), W = H;
    }
  }
  getMaxOverflow() {
    const t = this._cachedMeta, e = t.dataset, s = e.options && e.options.borderWidth || 0, n = t.data || [];
    if (!n.length)
      return s;
    const o = n[0].size(this.resolveDataElementOptions(0)), r = n[n.length - 1].size(this.resolveDataElementOptions(n.length - 1));
    return Math.max(s, o, r) / 2;
  }
  draw() {
    const t = this._cachedMeta;
    t.dataset.updateControlPoints(this.chart.chartArea, t.iScale.axis), super.draw();
  }
}
class m0 extends Bn {
  static id = "scatter";
  static defaults = {
    datasetElementType: !1,
    dataElementType: "point",
    showLine: !1,
    fill: !1
  };
  static overrides = {
    interaction: {
      mode: "point"
    },
    scales: {
      x: {
        type: "linear"
      },
      y: {
        type: "linear"
      }
    }
  };
  getLabelAndValue(t) {
    const e = this._cachedMeta, s = this.chart.data.labels || [], { xScale: n, yScale: o } = e, r = this.getParsed(t), a = n.getLabelForValue(r.x), l = o.getLabelForValue(r.y);
    return {
      label: s[t] || "",
      value: "(" + a + ", " + l + ")"
    };
  }
  update(t) {
    const e = this._cachedMeta, { data: s = [] } = e, n = this.chart._animationsDisabled;
    let { start: o, count: r } = zr(e, s, n);
    if (this._drawStart = o, this._drawCount = r, Fr(e) && (o = 0, r = s.length), this.options.showLine) {
      this.datasetElementType || this.addElements();
      const { dataset: a, _dataset: l } = e;
      a._chart = this.chart, a._datasetIndex = this.index, a._decimated = !!l._decimated, a.points = s;
      const d = this.resolveDatasetElementOptions(t);
      d.segment = this.options.segment, this.updateElement(a, void 0, {
        animated: !n,
        options: d
      }, t);
    } else this.datasetElementType && (delete e.dataset, this.datasetElementType = !1);
    this.updateElements(s, o, r, t);
  }
  addElements() {
    const { showLine: t } = this.options;
    !this.datasetElementType && t && (this.datasetElementType = this.chart.registry.getElement("line")), super.addElements();
  }
  updateElements(t, e, s, n) {
    const o = n === "reset", { iScale: r, vScale: a, _stacked: l, _dataset: d } = this._cachedMeta, f = this.resolveDataElementOptions(e, n), x = this.getSharedOptions(f), b = this.includeOptions(n, x), k = r.axis, T = a.axis, { spanGaps: C, segment: A } = this.options, P = vi(C) ? C : Number.POSITIVE_INFINITY, z = this.chart._animationsDisabled || o || n === "none";
    let O = e > 0 && this.getParsed(e - 1);
    for (let W = e; W < e + s; ++W) {
      const R = t[W], Y = this.getParsed(W), B = z ? R : {}, H = It(Y[T]), it = B[k] = r.getPixelForValue(Y[k], W), ct = B[T] = o || H ? a.getBasePixel() : a.getPixelForValue(l ? this.applyStack(a, Y, l) : Y[T], W);
      B.skip = isNaN(it) || isNaN(ct) || H, B.stop = W > 0 && Math.abs(Y[k] - O[k]) > P, A && (B.parsed = Y, B.raw = d.data[W]), b && (B.options = x || this.resolveDataElementOptions(W, R.active ? "active" : n)), z || this.updateElement(R, W, B, n), O = Y;
    }
    this.updateSharedOptions(x, n, f);
  }
  getMaxOverflow() {
    const t = this._cachedMeta, e = t.data || [];
    if (!this.options.showLine) {
      let a = 0;
      for (let l = e.length - 1; l >= 0; --l)
        a = Math.max(a, e[l].size(this.resolveDataElementOptions(l)) / 2);
      return a > 0 && a;
    }
    const s = t.dataset, n = s.options && s.options.borderWidth || 0;
    if (!e.length)
      return n;
    const o = e[0].size(this.resolveDataElementOptions(0)), r = e[e.length - 1].size(this.resolveDataElementOptions(e.length - 1));
    return Math.max(n, o, r) / 2;
  }
}
function Xe() {
  throw new Error("This method is not implemented: Check that a complete date adapter is provided.");
}
class In {
  /**
  * Override default date adapter methods.
  * Accepts type parameter to define options type.
  * @example
  * Chart._adapters._date.override<{myAdapterOption: string}>({
  *   init() {
  *     console.log(this.options.myAdapterOption);
  *   }
  * })
  */
  static override(t) {
    Object.assign(In.prototype, t);
  }
  options;
  constructor(t) {
    this.options = t || {};
  }
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  init() {
  }
  formats() {
    return Xe();
  }
  parse() {
    return Xe();
  }
  format() {
    return Xe();
  }
  add() {
    return Xe();
  }
  diff() {
    return Xe();
  }
  startOf() {
    return Xe();
  }
  endOf() {
    return Xe();
  }
}
var y0 = {
  _date: In
};
function x0(i, t, e, s) {
  const { controller: n, data: o, _sorted: r } = i, a = n._cachedMeta.iScale, l = i.dataset && i.dataset.options ? i.dataset.options.spanGaps : null;
  if (a && t === a.axis && t !== "r" && r && o.length) {
    const d = a._reversePixels ? ql : Je;
    if (s) {
      if (n._sharedOptions) {
        const f = o[0], x = typeof f.getRange == "function" && f.getRange(t);
        if (x) {
          const b = d(o, t, e - x), k = d(o, t, e + x);
          return {
            lo: b.lo,
            hi: k.hi
          };
        }
      }
    } else {
      const f = d(o, t, e);
      if (l) {
        const { vScale: x } = n._cachedMeta, { _parsed: b } = i, k = b.slice(0, f.lo + 1).reverse().findIndex((C) => !It(C[x.axis]));
        f.lo -= Math.max(0, k);
        const T = b.slice(f.hi).findIndex((C) => !It(C[x.axis]));
        f.hi += Math.max(0, T);
      }
      return f;
    }
  }
  return {
    lo: 0,
    hi: o.length - 1
  };
}
function Bs(i, t, e, s, n) {
  const o = i.getSortedVisibleDatasetMetas(), r = e[t];
  for (let a = 0, l = o.length; a < l; ++a) {
    const { index: d, data: f } = o[a], { lo: x, hi: b } = x0(o[a], t, r, n);
    for (let k = x; k <= b; ++k) {
      const T = f[k];
      T.skip || s(T, d, k);
    }
  }
}
function b0(i) {
  const t = i.indexOf("x") !== -1, e = i.indexOf("y") !== -1;
  return function(s, n) {
    const o = t ? Math.abs(s.x - n.x) : 0, r = e ? Math.abs(s.y - n.y) : 0;
    return Math.sqrt(Math.pow(o, 2) + Math.pow(r, 2));
  };
}
function nn(i, t, e, s, n) {
  const o = [];
  return !n && !i.isPointInArea(t) || Bs(i, e, t, function(a, l, d) {
    !n && !qi(a, i.chartArea, 0) || a.inRange(t.x, t.y, s) && o.push({
      element: a,
      datasetIndex: l,
      index: d
    });
  }, !0), o;
}
function _0(i, t, e, s) {
  let n = [];
  function o(r, a, l) {
    const { startAngle: d, endAngle: f } = r.getProps([
      "startAngle",
      "endAngle"
    ], s), { angle: x } = Ul(r, {
      x: t.x,
      y: t.y
    });
    Er(x, d, f) && n.push({
      element: r,
      datasetIndex: a,
      index: l
    });
  }
  return Bs(i, e, t, o), n;
}
function v0(i, t, e, s, n, o) {
  let r = [];
  const a = b0(e);
  let l = Number.POSITIVE_INFINITY;
  function d(f, x, b) {
    const k = f.inRange(t.x, t.y, n);
    if (s && !k)
      return;
    const T = f.getCenterPoint(n);
    if (!(!!o || i.isPointInArea(T)) && !k)
      return;
    const A = a(t, T);
    A < l ? (r = [
      {
        element: f,
        datasetIndex: x,
        index: b
      }
    ], l = A) : A === l && r.push({
      element: f,
      datasetIndex: x,
      index: b
    });
  }
  return Bs(i, e, t, d), r;
}
function on(i, t, e, s, n, o) {
  return !o && !i.isPointInArea(t) ? [] : e === "r" && !s ? _0(i, t, e, n) : v0(i, t, e, s, n, o);
}
function Io(i, t, e, s, n) {
  const o = [], r = e === "x" ? "inXRange" : "inYRange";
  let a = !1;
  return Bs(i, e, t, (l, d, f) => {
    l[r] && l[r](t[e], n) && (o.push({
      element: l,
      datasetIndex: d,
      index: f
    }), a = a || l.inRange(t.x, t.y, n));
  }), s && !a ? [] : o;
}
var w0 = {
  modes: {
    index(i, t, e, s) {
      const n = Ge(t, i), o = e.axis || "x", r = e.includeInvisible || !1, a = e.intersect ? nn(i, n, o, s, r) : on(i, n, o, !1, s, r), l = [];
      return a.length ? (i.getSortedVisibleDatasetMetas().forEach((d) => {
        const f = a[0].index, x = d.data[f];
        x && !x.skip && l.push({
          element: x,
          datasetIndex: d.index,
          index: f
        });
      }), l) : [];
    },
    dataset(i, t, e, s) {
      const n = Ge(t, i), o = e.axis || "xy", r = e.includeInvisible || !1;
      let a = e.intersect ? nn(i, n, o, s, r) : on(i, n, o, !1, s, r);
      if (a.length > 0) {
        const l = a[0].datasetIndex, d = i.getDatasetMeta(l).data;
        a = [];
        for (let f = 0; f < d.length; ++f)
          a.push({
            element: d[f],
            datasetIndex: l,
            index: f
          });
      }
      return a;
    },
    point(i, t, e, s) {
      const n = Ge(t, i), o = e.axis || "xy", r = e.includeInvisible || !1;
      return nn(i, n, o, s, r);
    },
    nearest(i, t, e, s) {
      const n = Ge(t, i), o = e.axis || "xy", r = e.includeInvisible || !1;
      return on(i, n, o, e.intersect, s, r);
    },
    x(i, t, e, s) {
      const n = Ge(t, i);
      return Io(i, n, "x", e.intersect, s);
    },
    y(i, t, e, s) {
      const n = Ge(t, i);
      return Io(i, n, "y", e.intersect, s);
    }
  }
};
const na = [
  "left",
  "top",
  "right",
  "bottom"
];
function Bi(i, t) {
  return i.filter((e) => e.pos === t);
}
function Ro(i, t) {
  return i.filter((e) => na.indexOf(e.pos) === -1 && e.box.axis === t);
}
function Ii(i, t) {
  return i.sort((e, s) => {
    const n = t ? s : e, o = t ? e : s;
    return n.weight === o.weight ? n.index - o.index : n.weight - o.weight;
  });
}
function k0(i) {
  const t = [];
  let e, s, n, o, r, a;
  for (e = 0, s = (i || []).length; e < s; ++e)
    n = i[e], { position: o, options: { stack: r, stackWeight: a = 1 } } = n, t.push({
      index: e,
      box: n,
      pos: o,
      horizontal: n.isHorizontal(),
      weight: n.weight,
      stack: r && o + r,
      stackWeight: a
    });
  return t;
}
function $0(i) {
  const t = {};
  for (const e of i) {
    const { stack: s, pos: n, stackWeight: o } = e;
    if (!s || !na.includes(n))
      continue;
    const r = t[s] || (t[s] = {
      count: 0,
      placed: 0,
      weight: 0,
      size: 0
    });
    r.count++, r.weight += o;
  }
  return t;
}
function M0(i, t) {
  const e = $0(i), { vBoxMaxWidth: s, hBoxMaxHeight: n } = t;
  let o, r, a;
  for (o = 0, r = i.length; o < r; ++o) {
    a = i[o];
    const { fullSize: l } = a.box, d = e[a.stack], f = d && a.stackWeight / d.weight;
    a.horizontal ? (a.width = f ? f * s : l && t.availableWidth, a.height = n) : (a.width = s, a.height = f ? f * n : l && t.availableHeight);
  }
  return e;
}
function S0(i) {
  const t = k0(i), e = Ii(t.filter((d) => d.box.fullSize), !0), s = Ii(Bi(t, "left"), !0), n = Ii(Bi(t, "right")), o = Ii(Bi(t, "top"), !0), r = Ii(Bi(t, "bottom")), a = Ro(t, "x"), l = Ro(t, "y");
  return {
    fullSize: e,
    leftAndTop: s.concat(o),
    rightAndBottom: n.concat(l).concat(r).concat(a),
    chartArea: Bi(t, "chartArea"),
    vertical: s.concat(n).concat(l),
    horizontal: o.concat(r).concat(a)
  };
}
function zo(i, t, e, s) {
  return Math.max(i[e], t[e]) + Math.max(i[s], t[s]);
}
function oa(i, t) {
  i.top = Math.max(i.top, t.top), i.left = Math.max(i.left, t.left), i.bottom = Math.max(i.bottom, t.bottom), i.right = Math.max(i.right, t.right);
}
function C0(i, t, e, s) {
  const { pos: n, box: o } = e, r = i.maxPadding;
  if (!Dt(n)) {
    e.size && (i[n] -= e.size);
    const x = s[e.stack] || {
      size: 0,
      count: 1
    };
    x.size = Math.max(x.size, e.horizontal ? o.height : o.width), e.size = x.size / x.count, i[n] += e.size;
  }
  o.getPadding && oa(r, o.getPadding());
  const a = Math.max(0, t.outerWidth - zo(r, i, "left", "right")), l = Math.max(0, t.outerHeight - zo(r, i, "top", "bottom")), d = a !== i.w, f = l !== i.h;
  return i.w = a, i.h = l, e.horizontal ? {
    same: d,
    other: f
  } : {
    same: f,
    other: d
  };
}
function D0(i) {
  const t = i.maxPadding;
  function e(s) {
    const n = Math.max(t[s] - i[s], 0);
    return i[s] += n, n;
  }
  i.y += e("top"), i.x += e("left"), e("right"), e("bottom");
}
function A0(i, t) {
  const e = t.maxPadding;
  function s(n) {
    const o = {
      left: 0,
      top: 0,
      right: 0,
      bottom: 0
    };
    return n.forEach((r) => {
      o[r] = Math.max(t[r], e[r]);
    }), o;
  }
  return s(i ? [
    "left",
    "right"
  ] : [
    "top",
    "bottom"
  ]);
}
function Hi(i, t, e, s) {
  const n = [];
  let o, r, a, l, d, f;
  for (o = 0, r = i.length, d = 0; o < r; ++o) {
    a = i[o], l = a.box, l.update(a.width || t.w, a.height || t.h, A0(a.horizontal, t));
    const { same: x, other: b } = C0(t, e, a, s);
    d |= x && n.length, f = f || b, l.fullSize || n.push(a);
  }
  return d && Hi(n, t, e, s) || f;
}
function ps(i, t, e, s, n) {
  i.top = e, i.left = t, i.right = t + s, i.bottom = e + n, i.width = s, i.height = n;
}
function Fo(i, t, e, s) {
  const n = e.padding;
  let { x: o, y: r } = t;
  for (const a of i) {
    const l = a.box, d = s[a.stack] || {
      placed: 0,
      weight: 1
    }, f = a.stackWeight / d.weight || 1;
    if (a.horizontal) {
      const x = t.w * f, b = d.size || l.height;
      Ds(d.start) && (r = d.start), l.fullSize ? ps(l, n.left, r, e.outerWidth - n.right - n.left, b) : ps(l, t.left + d.placed, r, x, b), d.start = r, d.placed += x, r = l.bottom;
    } else {
      const x = t.h * f, b = d.size || l.width;
      Ds(d.start) && (o = d.start), l.fullSize ? ps(l, o, n.top, b, e.outerHeight - n.bottom - n.top) : ps(l, o, t.top + d.placed, b, x), d.start = o, d.placed += x, o = l.right;
    }
  }
  t.x = o, t.y = r;
}
var ce = {
  addBox(i, t) {
    i.boxes || (i.boxes = []), t.fullSize = t.fullSize || !1, t.position = t.position || "top", t.weight = t.weight || 0, t._layers = t._layers || function() {
      return [
        {
          z: 0,
          draw(e) {
            t.draw(e);
          }
        }
      ];
    }, i.boxes.push(t);
  },
  removeBox(i, t) {
    const e = i.boxes ? i.boxes.indexOf(t) : -1;
    e !== -1 && i.boxes.splice(e, 1);
  },
  configure(i, t, e) {
    t.fullSize = e.fullSize, t.position = e.position, t.weight = e.weight;
  },
  update(i, t, e, s) {
    if (!i)
      return;
    const n = he(i.options.layout.padding), o = Math.max(t - n.width, 0), r = Math.max(e - n.height, 0), a = S0(i.boxes), l = a.vertical, d = a.horizontal;
    Et(i.boxes, (C) => {
      typeof C.beforeLayout == "function" && C.beforeLayout();
    });
    const f = l.reduce((C, A) => A.box.options && A.box.options.display === !1 ? C : C + 1, 0) || 1, x = Object.freeze({
      outerWidth: t,
      outerHeight: e,
      padding: n,
      availableWidth: o,
      availableHeight: r,
      vBoxMaxWidth: o / 2 / f,
      hBoxMaxHeight: r / 2
    }), b = Object.assign({}, n);
    oa(b, he(s));
    const k = Object.assign({
      maxPadding: b,
      w: o,
      h: r,
      x: n.left,
      y: n.top
    }, n), T = M0(l.concat(d), x);
    Hi(a.fullSize, k, x, T), Hi(l, k, x, T), Hi(d, k, x, T) && Hi(l, k, x, T), D0(k), Fo(a.leftAndTop, k, x, T), k.x += k.w, k.y += k.h, Fo(a.rightAndBottom, k, x, T), i.chartArea = {
      left: k.left,
      top: k.top,
      right: k.left + k.w,
      bottom: k.top + k.h,
      height: k.h,
      width: k.w
    }, Et(a.chartArea, (C) => {
      const A = C.box;
      Object.assign(A, i.chartArea), A.update(k.w, k.h, {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
      });
    });
  }
};
class ra {
  acquireContext(t, e) {
  }
  releaseContext(t) {
    return !1;
  }
  addEventListener(t, e, s) {
  }
  removeEventListener(t, e, s) {
  }
  getDevicePixelRatio() {
    return 1;
  }
  getMaximumSize(t, e, s, n) {
    return e = Math.max(0, e || t.width), s = s || t.height, {
      width: e,
      height: Math.max(0, n ? Math.floor(e / n) : s)
    };
  }
  isAttached(t) {
    return !0;
  }
  updateConfig(t) {
  }
}
class P0 extends ra {
  acquireContext(t) {
    return t && t.getContext && t.getContext("2d") || null;
  }
  updateConfig(t) {
    t.options.animation = !1;
  }
}
const vs = "$chartjs", T0 = {
  touchstart: "mousedown",
  touchmove: "mousemove",
  touchend: "mouseup",
  pointerenter: "mouseenter",
  pointerdown: "mousedown",
  pointermove: "mousemove",
  pointerup: "mouseup",
  pointerleave: "mouseout",
  pointerout: "mouseout"
}, Ho = (i) => i === null || i === "";
function L0(i, t) {
  const e = i.style, s = i.getAttribute("height"), n = i.getAttribute("width");
  if (i[vs] = {
    initial: {
      height: s,
      width: n,
      style: {
        display: e.display,
        height: e.height,
        width: e.width
      }
    }
  }, e.display = e.display || "block", e.boxSizing = e.boxSizing || "border-box", Ho(n)) {
    const o = So(i, "width");
    o !== void 0 && (i.width = o);
  }
  if (Ho(s))
    if (i.style.height === "")
      i.height = i.width / (t || 2);
    else {
      const o = So(i, "height");
      o !== void 0 && (i.height = o);
    }
  return i;
}
const aa = Vc ? {
  passive: !0
} : !1;
function O0(i, t, e) {
  i && i.addEventListener(t, e, aa);
}
function E0(i, t, e) {
  i && i.canvas && i.canvas.removeEventListener(t, e, aa);
}
function B0(i, t) {
  const e = T0[i.type] || i.type, { x: s, y: n } = Ge(i, t);
  return {
    type: e,
    chart: t,
    native: i,
    x: s !== void 0 ? s : null,
    y: n !== void 0 ? n : null
  };
}
function Ts(i, t) {
  for (const e of i)
    if (e === t || e.contains(t))
      return !0;
}
function I0(i, t, e) {
  const s = i.canvas, n = new MutationObserver((o) => {
    let r = !1;
    for (const a of o)
      r = r || Ts(a.addedNodes, s), r = r && !Ts(a.removedNodes, s);
    r && e();
  });
  return n.observe(document, {
    childList: !0,
    subtree: !0
  }), n;
}
function R0(i, t, e) {
  const s = i.canvas, n = new MutationObserver((o) => {
    let r = !1;
    for (const a of o)
      r = r || Ts(a.removedNodes, s), r = r && !Ts(a.addedNodes, s);
    r && e();
  });
  return n.observe(document, {
    childList: !0,
    subtree: !0
  }), n;
}
const Ji = /* @__PURE__ */ new Map();
let jo = 0;
function la() {
  const i = window.devicePixelRatio;
  i !== jo && (jo = i, Ji.forEach((t, e) => {
    e.currentDevicePixelRatio !== i && t();
  }));
}
function z0(i, t) {
  Ji.size || window.addEventListener("resize", la), Ji.set(i, t);
}
function F0(i) {
  Ji.delete(i), Ji.size || window.removeEventListener("resize", la);
}
function H0(i, t, e) {
  const s = i.canvas, n = s && En(s);
  if (!n)
    return;
  const o = Rr((a, l) => {
    const d = n.clientWidth;
    e(a, l), d < n.clientWidth && e();
  }, window), r = new ResizeObserver((a) => {
    const l = a[0], d = l.contentRect.width, f = l.contentRect.height;
    d === 0 && f === 0 || o(d, f);
  });
  return r.observe(n), z0(i, o), r;
}
function rn(i, t, e) {
  e && e.disconnect(), t === "resize" && F0(i);
}
function j0(i, t, e) {
  const s = i.canvas, n = Rr((o) => {
    i.ctx !== null && e(B0(o, i));
  }, i);
  return O0(s, t, n), n;
}
class N0 extends ra {
  acquireContext(t, e) {
    const s = t && t.getContext && t.getContext("2d");
    return s && s.canvas === t ? (L0(t, e), s) : null;
  }
  releaseContext(t) {
    const e = t.canvas;
    if (!e[vs])
      return !1;
    const s = e[vs].initial;
    [
      "height",
      "width"
    ].forEach((o) => {
      const r = s[o];
      It(r) ? e.removeAttribute(o) : e.setAttribute(o, r);
    });
    const n = s.style || {};
    return Object.keys(n).forEach((o) => {
      e.style[o] = n[o];
    }), e.width = e.width, delete e[vs], !0;
  }
  addEventListener(t, e, s) {
    this.removeEventListener(t, e);
    const n = t.$proxies || (t.$proxies = {}), r = {
      attach: I0,
      detach: R0,
      resize: H0
    }[e] || j0;
    n[e] = r(t, e, s);
  }
  removeEventListener(t, e) {
    const s = t.$proxies || (t.$proxies = {}), n = s[e];
    if (!n)
      return;
    ({
      attach: rn,
      detach: rn,
      resize: rn
    }[e] || E0)(t, e, n), s[e] = void 0;
  }
  getDevicePixelRatio() {
    return window.devicePixelRatio;
  }
  getMaximumSize(t, e, s, n) {
    return Wc(t, e, s, n);
  }
  isAttached(t) {
    const e = t && En(t);
    return !!(e && e.isConnected);
  }
}
function W0(i) {
  return !On() || typeof OffscreenCanvas < "u" && i instanceof OffscreenCanvas ? P0 : N0;
}
class ii {
  static defaults = {};
  static defaultRoutes = void 0;
  x;
  y;
  active = !1;
  options;
  $animations;
  tooltipPosition(t) {
    const { x: e, y: s } = this.getProps([
      "x",
      "y"
    ], t);
    return {
      x: e,
      y: s
    };
  }
  hasValue() {
    return vi(this.x) && vi(this.y);
  }
  getProps(t, e) {
    const s = this.$animations;
    if (!e || !s)
      return this;
    const n = {};
    return t.forEach((o) => {
      n[o] = s[o] && s[o].active() ? s[o]._to : this[o];
    }), n;
  }
}
function V0(i, t) {
  const e = i.options.ticks, s = Y0(i), n = Math.min(e.maxTicksLimit || s, s), o = e.major.enabled ? X0(t) : [], r = o.length, a = o[0], l = o[r - 1], d = [];
  if (r > n)
    return G0(t, d, o, r / n), d;
  const f = U0(o, t, n);
  if (r > 0) {
    let x, b;
    const k = r > 1 ? Math.round((l - a) / (r - 1)) : null;
    for (gs(t, d, f, It(k) ? 0 : a - k, a), x = 0, b = r - 1; x < b; x++)
      gs(t, d, f, o[x], o[x + 1]);
    return gs(t, d, f, l, It(k) ? t.length : l + k), d;
  }
  return gs(t, d, f), d;
}
function Y0(i) {
  const t = i.options.offset, e = i._tickSize(), s = i._length / e + (t ? 0 : 1), n = i._maxLength / e;
  return Math.floor(Math.min(s, n));
}
function U0(i, t, e) {
  const s = q0(i), n = t.length / e;
  if (!s)
    return Math.max(n, 1);
  const o = jl(s);
  for (let r = 0, a = o.length - 1; r < a; r++) {
    const l = o[r];
    if (l > n)
      return l;
  }
  return Math.max(n, 1);
}
function X0(i) {
  const t = [];
  let e, s;
  for (e = 0, s = i.length; e < s; e++)
    i[e].major && t.push(e);
  return t;
}
function G0(i, t, e, s) {
  let n = 0, o = e[0], r;
  for (s = Math.ceil(s), r = 0; r < i.length; r++)
    r === o && (t.push(i[r]), n++, o = e[n * s]);
}
function gs(i, t, e, s, n) {
  const o = Ct(s, 0), r = Math.min(Ct(n, i.length), i.length);
  let a = 0, l, d, f;
  for (e = Math.ceil(e), n && (l = n - s, e = l / Math.floor(l / e)), f = o; f < 0; )
    a++, f = Math.round(o + a * e);
  for (d = Math.max(o, 0); d < r; d++)
    d === f && (t.push(i[d]), a++, f = Math.round(o + a * e));
}
function q0(i) {
  const t = i.length;
  let e, s;
  if (t < 2)
    return !1;
  for (s = i[0], e = 1; e < t; ++e)
    if (i[e] - i[e - 1] !== s)
      return !1;
  return s;
}
const K0 = (i) => i === "left" ? "right" : i === "right" ? "left" : i, No = (i, t, e) => t === "top" || t === "left" ? i[t] + e : i[t] - e, Wo = (i, t) => Math.min(t || i, i);
function Vo(i, t) {
  const e = [], s = i.length / t, n = i.length;
  let o = 0;
  for (; o < n; o += s)
    e.push(i[Math.floor(o)]);
  return e;
}
function J0(i, t, e) {
  const s = i.ticks.length, n = Math.min(t, s - 1), o = i._startPixel, r = i._endPixel, a = 1e-6;
  let l = i.getPixelForTick(n), d;
  if (!(e && (s === 1 ? d = Math.max(l - o, r - l) : t === 0 ? d = (i.getPixelForTick(1) - l) / 2 : d = (l - i.getPixelForTick(n - 1)) / 2, l += n < t ? d : -d, l < o - a || l > r + a)))
    return l;
}
function Z0(i, t) {
  Et(i, (e) => {
    const s = e.gc, n = s.length / 2;
    let o;
    if (n > t) {
      for (o = 0; o < n; ++o)
        delete e.data[s[o]];
      s.splice(0, n);
    }
  });
}
function Ri(i) {
  return i.drawTicks ? i.tickLength : 0;
}
function Yo(i, t) {
  if (!i.display)
    return 0;
  const e = Gt(i.font, t), s = he(i.padding);
  return (Wt(i.text) ? i.text.length : 1) * e.lineHeight + s.height;
}
function Q0(i, t) {
  return ei(i, {
    scale: t,
    type: "scale"
  });
}
function th(i, t, e) {
  return ei(i, {
    tick: e,
    index: t,
    type: "tick"
  });
}
function eh(i, t, e) {
  let s = Dn(i);
  return (e && t !== "right" || !e && t === "right") && (s = K0(s)), s;
}
function ih(i, t, e, s) {
  const { top: n, left: o, bottom: r, right: a, chart: l } = i, { chartArea: d, scales: f } = l;
  let x = 0, b, k, T;
  const C = r - n, A = a - o;
  if (i.isHorizontal()) {
    if (k = Xt(s, o, a), Dt(e)) {
      const P = Object.keys(e)[0], z = e[P];
      T = f[P].getPixelForValue(z) + C - t;
    } else e === "center" ? T = (d.bottom + d.top) / 2 + C - t : T = No(i, e, t);
    b = a - o;
  } else {
    if (Dt(e)) {
      const P = Object.keys(e)[0], z = e[P];
      k = f[P].getPixelForValue(z) - A + t;
    } else e === "center" ? k = (d.left + d.right) / 2 - A + t : k = No(i, e, t);
    T = Xt(s, r, n), x = e === "left" ? -ue : ue;
  }
  return {
    titleX: k,
    titleY: T,
    maxWidth: b,
    rotation: x
  };
}
class Mi extends ii {
  constructor(t) {
    super(), this.id = t.id, this.type = t.type, this.options = void 0, this.ctx = t.ctx, this.chart = t.chart, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this._margins = {
      left: 0,
      right: 0,
      top: 0,
      bottom: 0
    }, this.maxWidth = void 0, this.maxHeight = void 0, this.paddingTop = void 0, this.paddingBottom = void 0, this.paddingLeft = void 0, this.paddingRight = void 0, this.axis = void 0, this.labelRotation = void 0, this.min = void 0, this.max = void 0, this._range = void 0, this.ticks = [], this._gridLineItems = null, this._labelItems = null, this._labelSizes = null, this._length = 0, this._maxLength = 0, this._longestTextCache = {}, this._startPixel = void 0, this._endPixel = void 0, this._reversePixels = !1, this._userMax = void 0, this._userMin = void 0, this._suggestedMax = void 0, this._suggestedMin = void 0, this._ticksLength = 0, this._borderValue = 0, this._cache = {}, this._dataLimitsCached = !1, this.$context = void 0;
  }
  init(t) {
    this.options = t.setContext(this.getContext()), this.axis = t.axis, this._userMin = this.parse(t.min), this._userMax = this.parse(t.max), this._suggestedMin = this.parse(t.suggestedMin), this._suggestedMax = this.parse(t.suggestedMax);
  }
  parse(t, e) {
    return t;
  }
  getUserBounds() {
    let { _userMin: t, _userMax: e, _suggestedMin: s, _suggestedMax: n } = this;
    return t = ge(t, Number.POSITIVE_INFINITY), e = ge(e, Number.NEGATIVE_INFINITY), s = ge(s, Number.POSITIVE_INFINITY), n = ge(n, Number.NEGATIVE_INFINITY), {
      min: ge(t, s),
      max: ge(e, n),
      minDefined: qt(t),
      maxDefined: qt(e)
    };
  }
  getMinMax(t) {
    let { min: e, max: s, minDefined: n, maxDefined: o } = this.getUserBounds(), r;
    if (n && o)
      return {
        min: e,
        max: s
      };
    const a = this.getMatchingVisibleMetas();
    for (let l = 0, d = a.length; l < d; ++l)
      r = a[l].controller.getMinMax(this, t), n || (e = Math.min(e, r.min)), o || (s = Math.max(s, r.max));
    return e = o && e > s ? s : e, s = n && e > s ? e : s, {
      min: ge(e, ge(s, e)),
      max: ge(s, ge(e, s))
    };
  }
  getPadding() {
    return {
      left: this.paddingLeft || 0,
      top: this.paddingTop || 0,
      right: this.paddingRight || 0,
      bottom: this.paddingBottom || 0
    };
  }
  getTicks() {
    return this.ticks;
  }
  getLabels() {
    const t = this.chart.data;
    return this.options.labels || (this.isHorizontal() ? t.xLabels : t.yLabels) || t.labels || [];
  }
  getLabelItems(t = this.chart.chartArea) {
    return this._labelItems || (this._labelItems = this._computeLabelItems(t));
  }
  beforeLayout() {
    this._cache = {}, this._dataLimitsCached = !1;
  }
  beforeUpdate() {
    Rt(this.options.beforeUpdate, [
      this
    ]);
  }
  update(t, e, s) {
    const { beginAtZero: n, grace: o, ticks: r } = this.options, a = r.sampleSize;
    this.beforeUpdate(), this.maxWidth = t, this.maxHeight = e, this._margins = s = Object.assign({
      left: 0,
      right: 0,
      top: 0,
      bottom: 0
    }, s), this.ticks = null, this._labelSizes = null, this._gridLineItems = null, this._labelItems = null, this.beforeSetDimensions(), this.setDimensions(), this.afterSetDimensions(), this._maxLength = this.isHorizontal() ? this.width + s.left + s.right : this.height + s.top + s.bottom, this._dataLimitsCached || (this.beforeDataLimits(), this.determineDataLimits(), this.afterDataLimits(), this._range = vc(this, o, n), this._dataLimitsCached = !0), this.beforeBuildTicks(), this.ticks = this.buildTicks() || [], this.afterBuildTicks();
    const l = a < this.ticks.length;
    this._convertTicksToLabels(l ? Vo(this.ticks, a) : this.ticks), this.configure(), this.beforeCalculateLabelRotation(), this.calculateLabelRotation(), this.afterCalculateLabelRotation(), r.display && (r.autoSkip || r.source === "auto") && (this.ticks = V0(this, this.ticks), this._labelSizes = null, this.afterAutoSkip()), l && this._convertTicksToLabels(this.ticks), this.beforeFit(), this.fit(), this.afterFit(), this.afterUpdate();
  }
  configure() {
    let t = this.options.reverse, e, s;
    this.isHorizontal() ? (e = this.left, s = this.right) : (e = this.top, s = this.bottom, t = !t), this._startPixel = e, this._endPixel = s, this._reversePixels = t, this._length = s - e, this._alignToPixels = this.options.alignToPixels;
  }
  afterUpdate() {
    Rt(this.options.afterUpdate, [
      this
    ]);
  }
  beforeSetDimensions() {
    Rt(this.options.beforeSetDimensions, [
      this
    ]);
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = 0, this.right = this.width) : (this.height = this.maxHeight, this.top = 0, this.bottom = this.height), this.paddingLeft = 0, this.paddingTop = 0, this.paddingRight = 0, this.paddingBottom = 0;
  }
  afterSetDimensions() {
    Rt(this.options.afterSetDimensions, [
      this
    ]);
  }
  _callHooks(t) {
    this.chart.notifyPlugins(t, this.getContext()), Rt(this.options[t], [
      this
    ]);
  }
  beforeDataLimits() {
    this._callHooks("beforeDataLimits");
  }
  determineDataLimits() {
  }
  afterDataLimits() {
    this._callHooks("afterDataLimits");
  }
  beforeBuildTicks() {
    this._callHooks("beforeBuildTicks");
  }
  buildTicks() {
    return [];
  }
  afterBuildTicks() {
    this._callHooks("afterBuildTicks");
  }
  beforeTickToLabelConversion() {
    Rt(this.options.beforeTickToLabelConversion, [
      this
    ]);
  }
  generateTickLabels(t) {
    const e = this.options.ticks;
    let s, n, o;
    for (s = 0, n = t.length; s < n; s++)
      o = t[s], o.label = Rt(e.callback, [
        o.value,
        s,
        t
      ], this);
  }
  afterTickToLabelConversion() {
    Rt(this.options.afterTickToLabelConversion, [
      this
    ]);
  }
  beforeCalculateLabelRotation() {
    Rt(this.options.beforeCalculateLabelRotation, [
      this
    ]);
  }
  calculateLabelRotation() {
    const t = this.options, e = t.ticks, s = Wo(this.ticks.length, t.ticks.maxTicksLimit), n = e.minRotation || 0, o = e.maxRotation;
    let r = n, a, l, d;
    if (!this._isVisible() || !e.display || n >= o || s <= 1 || !this.isHorizontal()) {
      this.labelRotation = n;
      return;
    }
    const f = this._getLabelSizes(), x = f.widest.width, b = f.highest.height, k = le(this.chart.width - x, 0, this.maxWidth);
    a = t.offset ? this.maxWidth / s : k / (s - 1), x + 6 > a && (a = k / (s - (t.offset ? 0.5 : 1)), l = this.maxHeight - Ri(t.grid) - e.padding - Yo(t.title, this.chart.options.font), d = Math.sqrt(x * x + b * b), r = Yl(Math.min(Math.asin(le((f.highest.height + 6) / a, -1, 1)), Math.asin(le(l / d, -1, 1)) - Math.asin(le(b / d, -1, 1)))), r = Math.max(n, Math.min(o, r))), this.labelRotation = r;
  }
  afterCalculateLabelRotation() {
    Rt(this.options.afterCalculateLabelRotation, [
      this
    ]);
  }
  afterAutoSkip() {
  }
  beforeFit() {
    Rt(this.options.beforeFit, [
      this
    ]);
  }
  fit() {
    const t = {
      width: 0,
      height: 0
    }, { chart: e, options: { ticks: s, title: n, grid: o } } = this, r = this._isVisible(), a = this.isHorizontal();
    if (r) {
      const l = Yo(n, e.options.font);
      if (a ? (t.width = this.maxWidth, t.height = Ri(o) + l) : (t.height = this.maxHeight, t.width = Ri(o) + l), s.display && this.ticks.length) {
        const { first: d, last: f, widest: x, highest: b } = this._getLabelSizes(), k = s.padding * 2, T = Ke(this.labelRotation), C = Math.cos(T), A = Math.sin(T);
        if (a) {
          const P = s.mirror ? 0 : A * x.width + C * b.height;
          t.height = Math.min(this.maxHeight, t.height + P + k);
        } else {
          const P = s.mirror ? 0 : C * x.width + A * b.height;
          t.width = Math.min(this.maxWidth, t.width + P + k);
        }
        this._calculatePadding(d, f, A, C);
      }
    }
    this._handleMargins(), a ? (this.width = this._length = e.width - this._margins.left - this._margins.right, this.height = t.height) : (this.width = t.width, this.height = this._length = e.height - this._margins.top - this._margins.bottom);
  }
  _calculatePadding(t, e, s, n) {
    const { ticks: { align: o, padding: r }, position: a } = this.options, l = this.labelRotation !== 0, d = a !== "top" && this.axis === "x";
    if (this.isHorizontal()) {
      const f = this.getPixelForTick(0) - this.left, x = this.right - this.getPixelForTick(this.ticks.length - 1);
      let b = 0, k = 0;
      l ? d ? (b = n * t.width, k = s * e.height) : (b = s * t.height, k = n * e.width) : o === "start" ? k = e.width : o === "end" ? b = t.width : o !== "inner" && (b = t.width / 2, k = e.width / 2), this.paddingLeft = Math.max((b - f + r) * this.width / (this.width - f), 0), this.paddingRight = Math.max((k - x + r) * this.width / (this.width - x), 0);
    } else {
      let f = e.height / 2, x = t.height / 2;
      o === "start" ? (f = 0, x = t.height) : o === "end" && (f = e.height, x = 0), this.paddingTop = f + r, this.paddingBottom = x + r;
    }
  }
  _handleMargins() {
    this._margins && (this._margins.left = Math.max(this.paddingLeft, this._margins.left), this._margins.top = Math.max(this.paddingTop, this._margins.top), this._margins.right = Math.max(this.paddingRight, this._margins.right), this._margins.bottom = Math.max(this.paddingBottom, this._margins.bottom));
  }
  afterFit() {
    Rt(this.options.afterFit, [
      this
    ]);
  }
  isHorizontal() {
    const { axis: t, position: e } = this.options;
    return e === "top" || e === "bottom" || t === "x";
  }
  isFullSize() {
    return this.options.fullSize;
  }
  _convertTicksToLabels(t) {
    this.beforeTickToLabelConversion(), this.generateTickLabels(t);
    let e, s;
    for (e = 0, s = t.length; e < s; e++)
      It(t[e].label) && (t.splice(e, 1), s--, e--);
    this.afterTickToLabelConversion();
  }
  _getLabelSizes() {
    let t = this._labelSizes;
    if (!t) {
      const e = this.options.ticks.sampleSize;
      let s = this.ticks;
      e < s.length && (s = Vo(s, e)), this._labelSizes = t = this._computeLabelSizes(s, s.length, this.options.ticks.maxTicksLimit);
    }
    return t;
  }
  _computeLabelSizes(t, e, s) {
    const { ctx: n, _longestTextCache: o } = this, r = [], a = [], l = Math.floor(e / Wo(e, s));
    let d = 0, f = 0, x, b, k, T, C, A, P, z, O, W, R;
    for (x = 0; x < e; x += l) {
      if (T = t[x].label, C = this._resolveTickFontOptions(x), n.font = A = C.string, P = o[A] = o[A] || {
        data: {},
        gc: []
      }, z = C.lineHeight, O = W = 0, !It(T) && !Wt(T))
        O = vo(n, P.data, P.gc, O, T), W = z;
      else if (Wt(T))
        for (b = 0, k = T.length; b < k; ++b)
          R = T[b], !It(R) && !Wt(R) && (O = vo(n, P.data, P.gc, O, R), W += z);
      r.push(O), a.push(W), d = Math.max(O, d), f = Math.max(W, f);
    }
    Z0(o, e);
    const Y = r.indexOf(d), B = a.indexOf(f), H = (it) => ({
      width: r[it] || 0,
      height: a[it] || 0
    });
    return {
      first: H(0),
      last: H(e - 1),
      widest: H(Y),
      highest: H(B),
      widths: r,
      heights: a
    };
  }
  getLabelForValue(t) {
    return t;
  }
  getPixelForValue(t, e) {
    return NaN;
  }
  getValueForPixel(t) {
  }
  getPixelForTick(t) {
    const e = this.ticks;
    return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t].value);
  }
  getPixelForDecimal(t) {
    this._reversePixels && (t = 1 - t);
    const e = this._startPixel + t * this._length;
    return Gl(this._alignToPixels ? Ue(this.chart, e, 0) : e);
  }
  getDecimalForPixel(t) {
    const e = (t - this._startPixel) / this._length;
    return this._reversePixels ? 1 - e : e;
  }
  getBasePixel() {
    return this.getPixelForValue(this.getBaseValue());
  }
  getBaseValue() {
    const { min: t, max: e } = this;
    return t < 0 && e < 0 ? e : t > 0 && e > 0 ? t : 0;
  }
  getContext(t) {
    const e = this.ticks || [];
    if (t >= 0 && t < e.length) {
      const s = e[t];
      return s.$context || (s.$context = th(this.getContext(), t, s));
    }
    return this.$context || (this.$context = Q0(this.chart.getContext(), this));
  }
  _tickSize() {
    const t = this.options.ticks, e = Ke(this.labelRotation), s = Math.abs(Math.cos(e)), n = Math.abs(Math.sin(e)), o = this._getLabelSizes(), r = t.autoSkipPadding || 0, a = o ? o.widest.width + r : 0, l = o ? o.highest.height + r : 0;
    return this.isHorizontal() ? l * s > a * n ? a / s : l / n : l * n < a * s ? l / s : a / n;
  }
  _isVisible() {
    const t = this.options.display;
    return t !== "auto" ? !!t : this.getMatchingVisibleMetas().length > 0;
  }
  _computeGridLineItems(t) {
    const e = this.axis, s = this.chart, n = this.options, { grid: o, position: r, border: a } = n, l = o.offset, d = this.isHorizontal(), x = this.ticks.length + (l ? 1 : 0), b = Ri(o), k = [], T = a.setContext(this.getContext()), C = T.display ? T.width : 0, A = C / 2, P = function(K) {
      return Ue(s, K, C);
    };
    let z, O, W, R, Y, B, H, it, ct, X, st, ft;
    if (r === "top")
      z = P(this.bottom), B = this.bottom - b, it = z - A, X = P(t.top) + A, ft = t.bottom;
    else if (r === "bottom")
      z = P(this.top), X = t.top, ft = P(t.bottom) - A, B = z + A, it = this.top + b;
    else if (r === "left")
      z = P(this.right), Y = this.right - b, H = z - A, ct = P(t.left) + A, st = t.right;
    else if (r === "right")
      z = P(this.left), ct = t.left, st = P(t.right) - A, Y = z + A, H = this.left + b;
    else if (e === "x") {
      if (r === "center")
        z = P((t.top + t.bottom) / 2 + 0.5);
      else if (Dt(r)) {
        const K = Object.keys(r)[0], ht = r[K];
        z = P(this.chart.scales[K].getPixelForValue(ht));
      }
      X = t.top, ft = t.bottom, B = z + A, it = B + b;
    } else if (e === "y") {
      if (r === "center")
        z = P((t.left + t.right) / 2);
      else if (Dt(r)) {
        const K = Object.keys(r)[0], ht = r[K];
        z = P(this.chart.scales[K].getPixelForValue(ht));
      }
      Y = z - A, H = Y - b, ct = t.left, st = t.right;
    }
    const Q = Ct(n.ticks.maxTicksLimit, x), G = Math.max(1, Math.ceil(x / Q));
    for (O = 0; O < x; O += G) {
      const K = this.getContext(O), ht = o.setContext(K), et = a.setContext(K), ut = ht.lineWidth, yt = ht.color, _ = et.dash || [], y = et.dashOffset, g = ht.tickWidth, w = ht.tickColor, D = ht.tickBorderDash || [], E = ht.tickBorderDashOffset;
      W = J0(this, O, l), W !== void 0 && (R = Ue(s, W, ut), d ? Y = H = ct = st = R : B = it = X = ft = R, k.push({
        tx1: Y,
        ty1: B,
        tx2: H,
        ty2: it,
        x1: ct,
        y1: X,
        x2: st,
        y2: ft,
        width: ut,
        color: yt,
        borderDash: _,
        borderDashOffset: y,
        tickWidth: g,
        tickColor: w,
        tickBorderDash: D,
        tickBorderDashOffset: E
      }));
    }
    return this._ticksLength = x, this._borderValue = z, k;
  }
  _computeLabelItems(t) {
    const e = this.axis, s = this.options, { position: n, ticks: o } = s, r = this.isHorizontal(), a = this.ticks, { align: l, crossAlign: d, padding: f, mirror: x } = o, b = Ri(s.grid), k = b + f, T = x ? -f : k, C = -Ke(this.labelRotation), A = [];
    let P, z, O, W, R, Y, B, H, it, ct, X, st, ft = "middle";
    if (n === "top")
      Y = this.bottom - T, B = this._getXAxisLabelAlignment();
    else if (n === "bottom")
      Y = this.top + T, B = this._getXAxisLabelAlignment();
    else if (n === "left") {
      const G = this._getYAxisLabelAlignment(b);
      B = G.textAlign, R = G.x;
    } else if (n === "right") {
      const G = this._getYAxisLabelAlignment(b);
      B = G.textAlign, R = G.x;
    } else if (e === "x") {
      if (n === "center")
        Y = (t.top + t.bottom) / 2 + k;
      else if (Dt(n)) {
        const G = Object.keys(n)[0], K = n[G];
        Y = this.chart.scales[G].getPixelForValue(K) + k;
      }
      B = this._getXAxisLabelAlignment();
    } else if (e === "y") {
      if (n === "center")
        R = (t.left + t.right) / 2 - k;
      else if (Dt(n)) {
        const G = Object.keys(n)[0], K = n[G];
        R = this.chart.scales[G].getPixelForValue(K);
      }
      B = this._getYAxisLabelAlignment(b).textAlign;
    }
    e === "y" && (l === "start" ? ft = "top" : l === "end" && (ft = "bottom"));
    const Q = this._getLabelSizes();
    for (P = 0, z = a.length; P < z; ++P) {
      O = a[P], W = O.label;
      const G = o.setContext(this.getContext(P));
      H = this.getPixelForTick(P) + o.labelOffset, it = this._resolveTickFontOptions(P), ct = it.lineHeight, X = Wt(W) ? W.length : 1;
      const K = X / 2, ht = G.color, et = G.textStrokeColor, ut = G.textStrokeWidth;
      let yt = B;
      r ? (R = H, B === "inner" && (P === z - 1 ? yt = this.options.reverse ? "left" : "right" : P === 0 ? yt = this.options.reverse ? "right" : "left" : yt = "center"), n === "top" ? d === "near" || C !== 0 ? st = -X * ct + ct / 2 : d === "center" ? st = -Q.highest.height / 2 - K * ct + ct : st = -Q.highest.height + ct / 2 : d === "near" || C !== 0 ? st = ct / 2 : d === "center" ? st = Q.highest.height / 2 - K * ct : st = Q.highest.height - X * ct, x && (st *= -1), C !== 0 && !G.showLabelBackdrop && (R += ct / 2 * Math.sin(C))) : (Y = H, st = (1 - X) * ct / 2);
      let _;
      if (G.showLabelBackdrop) {
        const y = he(G.backdropPadding), g = Q.heights[P], w = Q.widths[P];
        let D = st - y.top, E = 0 - y.left;
        switch (ft) {
          case "middle":
            D -= g / 2;
            break;
          case "bottom":
            D -= g;
            break;
        }
        switch (B) {
          case "center":
            E -= w / 2;
            break;
          case "right":
            E -= w;
            break;
          case "inner":
            P === z - 1 ? E -= w : P > 0 && (E -= w / 2);
            break;
        }
        _ = {
          left: E,
          top: D,
          width: w + y.width,
          height: g + y.height,
          color: G.backdropColor
        };
      }
      A.push({
        label: W,
        font: it,
        textOffset: st,
        options: {
          rotation: C,
          color: ht,
          strokeColor: et,
          strokeWidth: ut,
          textAlign: yt,
          textBaseline: ft,
          translation: [
            R,
            Y
          ],
          backdrop: _
        }
      });
    }
    return A;
  }
  _getXAxisLabelAlignment() {
    const { position: t, ticks: e } = this.options;
    if (-Ke(this.labelRotation))
      return t === "top" ? "left" : "right";
    let n = "center";
    return e.align === "start" ? n = "left" : e.align === "end" ? n = "right" : e.align === "inner" && (n = "inner"), n;
  }
  _getYAxisLabelAlignment(t) {
    const { position: e, ticks: { crossAlign: s, mirror: n, padding: o } } = this.options, r = this._getLabelSizes(), a = t + o, l = r.widest.width;
    let d, f;
    return e === "left" ? n ? (f = this.right + o, s === "near" ? d = "left" : s === "center" ? (d = "center", f += l / 2) : (d = "right", f += l)) : (f = this.right - a, s === "near" ? d = "right" : s === "center" ? (d = "center", f -= l / 2) : (d = "left", f = this.left)) : e === "right" ? n ? (f = this.left + o, s === "near" ? d = "right" : s === "center" ? (d = "center", f -= l / 2) : (d = "left", f -= l)) : (f = this.left + a, s === "near" ? d = "left" : s === "center" ? (d = "center", f += l / 2) : (d = "right", f = this.right)) : d = "right", {
      textAlign: d,
      x: f
    };
  }
  _computeLabelArea() {
    if (this.options.ticks.mirror)
      return;
    const t = this.chart, e = this.options.position;
    if (e === "left" || e === "right")
      return {
        top: 0,
        left: this.left,
        bottom: t.height,
        right: this.right
      };
    if (e === "top" || e === "bottom")
      return {
        top: this.top,
        left: 0,
        bottom: this.bottom,
        right: t.width
      };
  }
  drawBackground() {
    const { ctx: t, options: { backgroundColor: e }, left: s, top: n, width: o, height: r } = this;
    e && (t.save(), t.fillStyle = e, t.fillRect(s, n, o, r), t.restore());
  }
  getLineWidthForValue(t) {
    const e = this.options.grid;
    if (!this._isVisible() || !e.display)
      return 0;
    const n = this.ticks.findIndex((o) => o.value === t);
    return n >= 0 ? e.setContext(this.getContext(n)).lineWidth : 0;
  }
  drawGrid(t) {
    const e = this.options.grid, s = this.ctx, n = this._gridLineItems || (this._gridLineItems = this._computeGridLineItems(t));
    let o, r;
    const a = (l, d, f) => {
      !f.width || !f.color || (s.save(), s.lineWidth = f.width, s.strokeStyle = f.color, s.setLineDash(f.borderDash || []), s.lineDashOffset = f.borderDashOffset, s.beginPath(), s.moveTo(l.x, l.y), s.lineTo(d.x, d.y), s.stroke(), s.restore());
    };
    if (e.display)
      for (o = 0, r = n.length; o < r; ++o) {
        const l = n[o];
        e.drawOnChartArea && a({
          x: l.x1,
          y: l.y1
        }, {
          x: l.x2,
          y: l.y2
        }, l), e.drawTicks && a({
          x: l.tx1,
          y: l.ty1
        }, {
          x: l.tx2,
          y: l.ty2
        }, {
          color: l.tickColor,
          width: l.tickWidth,
          borderDash: l.tickBorderDash,
          borderDashOffset: l.tickBorderDashOffset
        });
      }
  }
  drawBorder() {
    const { chart: t, ctx: e, options: { border: s, grid: n } } = this, o = s.setContext(this.getContext()), r = s.display ? o.width : 0;
    if (!r)
      return;
    const a = n.setContext(this.getContext(0)).lineWidth, l = this._borderValue;
    let d, f, x, b;
    this.isHorizontal() ? (d = Ue(t, this.left, r) - r / 2, f = Ue(t, this.right, a) + a / 2, x = b = l) : (x = Ue(t, this.top, r) - r / 2, b = Ue(t, this.bottom, a) + a / 2, d = f = l), e.save(), e.lineWidth = o.width, e.strokeStyle = o.color, e.beginPath(), e.moveTo(d, x), e.lineTo(f, b), e.stroke(), e.restore();
  }
  drawLabels(t) {
    if (!this.options.ticks.display)
      return;
    const s = this.ctx, n = this._computeLabelArea();
    n && Ls(s, n);
    const o = this.getLabelItems(t);
    for (const r of o) {
      const a = r.options, l = r.font, d = r.label, f = r.textOffset;
      Ki(s, d, 0, f, l, a);
    }
    n && Os(s);
  }
  drawTitle() {
    const { ctx: t, options: { position: e, title: s, reverse: n } } = this;
    if (!s.display)
      return;
    const o = Gt(s.font), r = he(s.padding), a = s.align;
    let l = o.lineHeight / 2;
    e === "bottom" || e === "center" || Dt(e) ? (l += r.bottom, Wt(s.text) && (l += o.lineHeight * (s.text.length - 1))) : l += r.top;
    const { titleX: d, titleY: f, maxWidth: x, rotation: b } = ih(this, l, e, a);
    Ki(t, s.text, 0, 0, o, {
      color: s.color,
      maxWidth: x,
      rotation: b,
      textAlign: eh(a, e, n),
      textBaseline: "middle",
      translation: [
        d,
        f
      ]
    });
  }
  draw(t) {
    this._isVisible() && (this.drawBackground(), this.drawGrid(t), this.drawBorder(), this.drawTitle(), this.drawLabels(t));
  }
  _layers() {
    const t = this.options, e = t.ticks && t.ticks.z || 0, s = Ct(t.grid && t.grid.z, -1), n = Ct(t.border && t.border.z, 0);
    return !this._isVisible() || this.draw !== Mi.prototype.draw ? [
      {
        z: e,
        draw: (o) => {
          this.draw(o);
        }
      }
    ] : [
      {
        z: s,
        draw: (o) => {
          this.drawBackground(), this.drawGrid(o), this.drawTitle();
        }
      },
      {
        z: n,
        draw: () => {
          this.drawBorder();
        }
      },
      {
        z: e,
        draw: (o) => {
          this.drawLabels(o);
        }
      }
    ];
  }
  getMatchingVisibleMetas(t) {
    const e = this.chart.getSortedVisibleDatasetMetas(), s = this.axis + "AxisID", n = [];
    let o, r;
    for (o = 0, r = e.length; o < r; ++o) {
      const a = e[o];
      a[s] === this.id && (!t || a.type === t) && n.push(a);
    }
    return n;
  }
  _resolveTickFontOptions(t) {
    const e = this.options.ticks.setContext(this.getContext(t));
    return Gt(e.font);
  }
  _maxDigits() {
    const t = this._resolveTickFontOptions(0).lineHeight;
    return (this.isHorizontal() ? this.width : this.height) / t;
  }
}
class ms {
  constructor(t, e, s) {
    this.type = t, this.scope = e, this.override = s, this.items = /* @__PURE__ */ Object.create(null);
  }
  isForType(t) {
    return Object.prototype.isPrototypeOf.call(this.type.prototype, t.prototype);
  }
  register(t) {
    const e = Object.getPrototypeOf(t);
    let s;
    oh(e) && (s = this.register(e));
    const n = this.items, o = t.id, r = this.scope + "." + o;
    if (!o)
      throw new Error("class does not have id: " + t);
    return o in n || (n[o] = t, sh(t, r, s), this.override && Ht.override(t.id, t.overrides)), r;
  }
  get(t) {
    return this.items[t];
  }
  unregister(t) {
    const e = this.items, s = t.id, n = this.scope;
    s in e && delete e[s], n && s in Ht[n] && (delete Ht[n][s], this.override && delete Qe[s]);
  }
}
function sh(i, t, e) {
  const s = Gi(/* @__PURE__ */ Object.create(null), [
    e ? Ht.get(e) : {},
    Ht.get(t),
    i.defaults
  ]);
  Ht.set(t, s), i.defaultRoutes && nh(t, i.defaultRoutes), i.descriptors && Ht.describe(t, i.descriptors);
}
function nh(i, t) {
  Object.keys(t).forEach((e) => {
    const s = e.split("."), n = s.pop(), o = [
      i
    ].concat(s).join("."), r = t[e].split("."), a = r.pop(), l = r.join(".");
    Ht.route(o, n, l, a);
  });
}
function oh(i) {
  return "id" in i && "defaults" in i;
}
class rh {
  constructor() {
    this.controllers = new ms(Bn, "datasets", !0), this.elements = new ms(ii, "elements"), this.plugins = new ms(Object, "plugins"), this.scales = new ms(Mi, "scales"), this._typedRegistries = [
      this.controllers,
      this.scales,
      this.elements
    ];
  }
  add(...t) {
    this._each("register", t);
  }
  remove(...t) {
    this._each("unregister", t);
  }
  addControllers(...t) {
    this._each("register", t, this.controllers);
  }
  addElements(...t) {
    this._each("register", t, this.elements);
  }
  addPlugins(...t) {
    this._each("register", t, this.plugins);
  }
  addScales(...t) {
    this._each("register", t, this.scales);
  }
  getController(t) {
    return this._get(t, this.controllers, "controller");
  }
  getElement(t) {
    return this._get(t, this.elements, "element");
  }
  getPlugin(t) {
    return this._get(t, this.plugins, "plugin");
  }
  getScale(t) {
    return this._get(t, this.scales, "scale");
  }
  removeControllers(...t) {
    this._each("unregister", t, this.controllers);
  }
  removeElements(...t) {
    this._each("unregister", t, this.elements);
  }
  removePlugins(...t) {
    this._each("unregister", t, this.plugins);
  }
  removeScales(...t) {
    this._each("unregister", t, this.scales);
  }
  _each(t, e, s) {
    [
      ...e
    ].forEach((n) => {
      const o = s || this._getRegistryForType(n);
      s || o.isForType(n) || o === this.plugins && n.id ? this._exec(t, o, n) : Et(n, (r) => {
        const a = s || this._getRegistryForType(r);
        this._exec(t, a, r);
      });
    });
  }
  _exec(t, e, s) {
    const n = Sn(t);
    Rt(s["before" + n], [], s), e[t](s), Rt(s["after" + n], [], s);
  }
  _getRegistryForType(t) {
    for (let e = 0; e < this._typedRegistries.length; e++) {
      const s = this._typedRegistries[e];
      if (s.isForType(t))
        return s;
    }
    return this.plugins;
  }
  _get(t, e, s) {
    const n = e.get(t);
    if (n === void 0)
      throw new Error('"' + t + '" is not a registered ' + s + ".");
    return n;
  }
}
var ye = /* @__PURE__ */ new rh();
class ah {
  constructor() {
    this._init = void 0;
  }
  notify(t, e, s, n) {
    if (e === "beforeInit" && (this._init = this._createDescriptors(t, !0), this._notify(this._init, t, "install")), this._init === void 0)
      return;
    const o = n ? this._descriptors(t).filter(n) : this._descriptors(t), r = this._notify(o, t, e, s);
    return e === "afterDestroy" && (this._notify(o, t, "stop"), this._notify(this._init, t, "uninstall"), this._init = void 0), r;
  }
  _notify(t, e, s, n) {
    n = n || {};
    for (const o of t) {
      const r = o.plugin, a = r[s], l = [
        e,
        n,
        o.options
      ];
      if (Rt(a, l, r) === !1 && n.cancelable)
        return !1;
    }
    return !0;
  }
  invalidate() {
    It(this._cache) || (this._oldCache = this._cache, this._cache = void 0);
  }
  _descriptors(t) {
    if (this._cache)
      return this._cache;
    const e = this._cache = this._createDescriptors(t);
    return this._notifyStateChanges(t), e;
  }
  _createDescriptors(t, e) {
    const s = t && t.config, n = Ct(s.options && s.options.plugins, {}), o = lh(s);
    return n === !1 && !e ? [] : hh(t, o, n, e);
  }
  _notifyStateChanges(t) {
    const e = this._oldCache || [], s = this._cache, n = (o, r) => o.filter((a) => !r.some((l) => a.plugin.id === l.plugin.id));
    this._notify(n(e, s), t, "stop"), this._notify(n(s, e), t, "start");
  }
}
function lh(i) {
  const t = {}, e = [], s = Object.keys(ye.plugins.items);
  for (let o = 0; o < s.length; o++)
    e.push(ye.getPlugin(s[o]));
  const n = i.plugins || [];
  for (let o = 0; o < n.length; o++) {
    const r = n[o];
    e.indexOf(r) === -1 && (e.push(r), t[r.id] = !0);
  }
  return {
    plugins: e,
    localIds: t
  };
}
function ch(i, t) {
  return !t && i === !1 ? null : i === !0 ? {} : i;
}
function hh(i, { plugins: t, localIds: e }, s, n) {
  const o = [], r = i.getContext();
  for (const a of t) {
    const l = a.id, d = ch(s[l], n);
    d !== null && o.push({
      plugin: a,
      options: dh(i.config, {
        plugin: a,
        local: e[l]
      }, d, r)
    });
  }
  return o;
}
function dh(i, { plugin: t, local: e }, s, n) {
  const o = i.pluginScopeKeys(t), r = i.getOptionScopes(s, o);
  return e && t.defaults && r.push(t.defaults), i.createResolver(r, n, [
    ""
  ], {
    scriptable: !1,
    indexable: !1,
    allKeys: !0
  });
}
function xn(i, t) {
  const e = Ht.datasets[i] || {};
  return ((t.datasets || {})[i] || {}).indexAxis || t.indexAxis || e.indexAxis || "x";
}
function uh(i, t) {
  let e = i;
  return i === "_index_" ? e = t : i === "_value_" && (e = t === "x" ? "y" : "x"), e;
}
function fh(i, t) {
  return i === t ? "_index_" : "_value_";
}
function Uo(i) {
  if (i === "x" || i === "y" || i === "r")
    return i;
}
function ph(i) {
  if (i === "top" || i === "bottom")
    return "x";
  if (i === "left" || i === "right")
    return "y";
}
function bn(i, ...t) {
  if (Uo(i))
    return i;
  for (const e of t) {
    const s = e.axis || ph(e.position) || i.length > 1 && Uo(i[0].toLowerCase());
    if (s)
      return s;
  }
  throw new Error(`Cannot determine type of '${i}' axis. Please provide 'axis' or 'position' option.`);
}
function Xo(i, t, e) {
  if (e[t + "AxisID"] === i)
    return {
      axis: t
    };
}
function gh(i, t) {
  if (t.data && t.data.datasets) {
    const e = t.data.datasets.filter((s) => s.xAxisID === i || s.yAxisID === i);
    if (e.length)
      return Xo(i, "x", e[0]) || Xo(i, "y", e[0]);
  }
  return {};
}
function mh(i, t) {
  const e = Qe[i.type] || {
    scales: {}
  }, s = t.scales || {}, n = xn(i.type, t), o = /* @__PURE__ */ Object.create(null);
  return Object.keys(s).forEach((r) => {
    const a = s[r];
    if (!Dt(a))
      return console.error(`Invalid scale configuration for scale: ${r}`);
    if (a._proxy)
      return console.warn(`Ignoring resolver passed as options for scale: ${r}`);
    const l = bn(r, a, gh(r, i), Ht.scales[a.type]), d = fh(l, n), f = e.scales || {};
    o[r] = Ni(/* @__PURE__ */ Object.create(null), [
      {
        axis: l
      },
      a,
      f[l],
      f[d]
    ]);
  }), i.data.datasets.forEach((r) => {
    const a = r.type || i.type, l = r.indexAxis || xn(a, t), f = (Qe[a] || {}).scales || {};
    Object.keys(f).forEach((x) => {
      const b = uh(x, l), k = r[b + "AxisID"] || b;
      o[k] = o[k] || /* @__PURE__ */ Object.create(null), Ni(o[k], [
        {
          axis: b
        },
        s[k],
        f[x]
      ]);
    });
  }), Object.keys(o).forEach((r) => {
    const a = o[r];
    Ni(a, [
      Ht.scales[a.type],
      Ht.scale
    ]);
  }), o;
}
function ca(i) {
  const t = i.options || (i.options = {});
  t.plugins = Ct(t.plugins, {}), t.scales = mh(i, t);
}
function ha(i) {
  return i = i || {}, i.datasets = i.datasets || [], i.labels = i.labels || [], i;
}
function yh(i) {
  return i = i || {}, i.data = ha(i.data), ca(i), i;
}
const Go = /* @__PURE__ */ new Map(), da = /* @__PURE__ */ new Set();
function ys(i, t) {
  let e = Go.get(i);
  return e || (e = t(), Go.set(i, e), da.add(e)), e;
}
const zi = (i, t, e) => {
  const s = Cs(t, e);
  s !== void 0 && i.add(s);
};
class xh {
  constructor(t) {
    this._config = yh(t), this._scopeCache = /* @__PURE__ */ new Map(), this._resolverCache = /* @__PURE__ */ new Map();
  }
  get platform() {
    return this._config.platform;
  }
  get type() {
    return this._config.type;
  }
  set type(t) {
    this._config.type = t;
  }
  get data() {
    return this._config.data;
  }
  set data(t) {
    this._config.data = ha(t);
  }
  get options() {
    return this._config.options;
  }
  set options(t) {
    this._config.options = t;
  }
  get plugins() {
    return this._config.plugins;
  }
  update() {
    const t = this._config;
    this.clearCache(), ca(t);
  }
  clearCache() {
    this._scopeCache.clear(), this._resolverCache.clear();
  }
  datasetScopeKeys(t) {
    return ys(t, () => [
      [
        `datasets.${t}`,
        ""
      ]
    ]);
  }
  datasetAnimationScopeKeys(t, e) {
    return ys(`${t}.transition.${e}`, () => [
      [
        `datasets.${t}.transitions.${e}`,
        `transitions.${e}`
      ],
      [
        `datasets.${t}`,
        ""
      ]
    ]);
  }
  datasetElementScopeKeys(t, e) {
    return ys(`${t}-${e}`, () => [
      [
        `datasets.${t}.elements.${e}`,
        `datasets.${t}`,
        `elements.${e}`,
        ""
      ]
    ]);
  }
  pluginScopeKeys(t) {
    const e = t.id, s = this.type;
    return ys(`${s}-plugin-${e}`, () => [
      [
        `plugins.${e}`,
        ...t.additionalOptionScopes || []
      ]
    ]);
  }
  _cachedScopes(t, e) {
    const s = this._scopeCache;
    let n = s.get(t);
    return (!n || e) && (n = /* @__PURE__ */ new Map(), s.set(t, n)), n;
  }
  getOptionScopes(t, e, s) {
    const { options: n, type: o } = this, r = this._cachedScopes(t, s), a = r.get(e);
    if (a)
      return a;
    const l = /* @__PURE__ */ new Set();
    e.forEach((f) => {
      t && (l.add(t), f.forEach((x) => zi(l, t, x))), f.forEach((x) => zi(l, n, x)), f.forEach((x) => zi(l, Qe[o] || {}, x)), f.forEach((x) => zi(l, Ht, x)), f.forEach((x) => zi(l, gn, x));
    });
    const d = Array.from(l);
    return d.length === 0 && d.push(/* @__PURE__ */ Object.create(null)), da.has(e) && r.set(e, d), d;
  }
  chartOptionScopes() {
    const { options: t, type: e } = this;
    return [
      t,
      Qe[e] || {},
      Ht.datasets[e] || {},
      {
        type: e
      },
      Ht,
      gn
    ];
  }
  resolveNamedOptions(t, e, s, n = [
    ""
  ]) {
    const o = {
      $shared: !0
    }, { resolver: r, subPrefixes: a } = qo(this._resolverCache, t, n);
    let l = r;
    if (_h(r, e)) {
      o.$shared = !1, s = He(s) ? s() : s;
      const d = this.createResolver(t, s, a);
      l = wi(r, s, d);
    }
    for (const d of e)
      o[d] = l[d];
    return o;
  }
  createResolver(t, e, s = [
    ""
  ], n) {
    const { resolver: o } = qo(this._resolverCache, t, s);
    return Dt(e) ? wi(o, e, void 0, n) : o;
  }
}
function qo(i, t, e) {
  let s = i.get(t);
  s || (s = /* @__PURE__ */ new Map(), i.set(t, s));
  const n = e.join();
  let o = s.get(n);
  return o || (o = {
    resolver: Pn(t, e),
    subPrefixes: e.filter((a) => !a.toLowerCase().includes("hover"))
  }, s.set(n, o)), o;
}
const bh = (i) => Dt(i) && Object.getOwnPropertyNames(i).some((t) => He(i[t]));
function _h(i, t) {
  const { isScriptable: e, isIndexable: s } = Vr(i);
  for (const n of t) {
    const o = e(n), r = s(n), a = (r || o) && i[n];
    if (o && (He(a) || bh(a)) || r && Wt(a))
      return !0;
  }
  return !1;
}
var vh = "4.5.1";
const wh = [
  "top",
  "bottom",
  "left",
  "right",
  "chartArea"
];
function Ko(i, t) {
  return i === "top" || i === "bottom" || wh.indexOf(i) === -1 && t === "x";
}
function Jo(i, t) {
  return function(e, s) {
    return e[i] === s[i] ? e[t] - s[t] : e[i] - s[i];
  };
}
function Zo(i) {
  const t = i.chart, e = t.options.animation;
  t.notifyPlugins("afterRender"), Rt(e && e.onComplete, [
    i
  ], t);
}
function kh(i) {
  const t = i.chart, e = t.options.animation;
  Rt(e && e.onProgress, [
    i
  ], t);
}
function ua(i) {
  return On() && typeof i == "string" ? i = document.getElementById(i) : i && i.length && (i = i[0]), i && i.canvas && (i = i.canvas), i;
}
const ws = {}, Qo = (i) => {
  const t = ua(i);
  return Object.values(ws).filter((e) => e.canvas === t).pop();
};
function $h(i, t, e) {
  const s = Object.keys(i);
  for (const n of s) {
    const o = +n;
    if (o >= t) {
      const r = i[n];
      delete i[n], (e > 0 || o > t) && (i[o + e] = r);
    }
  }
}
function Mh(i, t, e, s) {
  return !e || i.type === "mouseout" ? null : s ? t : i;
}
let Is = class {
  static defaults = Ht;
  static instances = ws;
  static overrides = Qe;
  static registry = ye;
  static version = vh;
  static getChart = Qo;
  static register(...t) {
    ye.add(...t), tr();
  }
  static unregister(...t) {
    ye.remove(...t), tr();
  }
  constructor(t, e) {
    const s = this.config = new xh(e), n = ua(t), o = Qo(n);
    if (o)
      throw new Error("Canvas is already in use. Chart with ID '" + o.id + "' must be destroyed before the canvas with ID '" + o.canvas.id + "' can be reused.");
    const r = s.createResolver(s.chartOptionScopes(), this.getContext());
    this.platform = new (s.platform || W0(n))(), this.platform.updateConfig(s);
    const a = this.platform.acquireContext(n, r.aspectRatio), l = a && a.canvas, d = l && l.height, f = l && l.width;
    if (this.id = Ll(), this.ctx = a, this.canvas = l, this.width = f, this.height = d, this._options = r, this._aspectRatio = this.aspectRatio, this._layers = [], this._metasets = [], this._stacks = void 0, this.boxes = [], this.currentDevicePixelRatio = void 0, this.chartArea = void 0, this._active = [], this._lastEvent = void 0, this._listeners = {}, this._responsiveListeners = void 0, this._sortedMetasets = [], this.scales = {}, this._plugins = new ah(), this.$proxies = {}, this._hiddenIndices = {}, this.attached = !1, this._animationsDisabled = void 0, this.$context = void 0, this._doResize = Ql((x) => this.update(x), r.resizeDelay || 0), this._dataChanges = [], ws[this.id] = this, !a || !l) {
      console.error("Failed to create chart: can't acquire context from the given item");
      return;
    }
    $e.listen(this, "complete", Zo), $e.listen(this, "progress", kh), this._initialize(), this.attached && this.update();
  }
  get aspectRatio() {
    const { options: { aspectRatio: t, maintainAspectRatio: e }, width: s, height: n, _aspectRatio: o } = this;
    return It(t) ? e && o ? o : n ? s / n : null : t;
  }
  get data() {
    return this.config.data;
  }
  set data(t) {
    this.config.data = t;
  }
  get options() {
    return this._options;
  }
  set options(t) {
    this.config.options = t;
  }
  get registry() {
    return ye;
  }
  _initialize() {
    return this.notifyPlugins("beforeInit"), this.options.responsive ? this.resize() : Mo(this, this.options.devicePixelRatio), this.bindEvents(), this.notifyPlugins("afterInit"), this;
  }
  clear() {
    return wo(this.canvas, this.ctx), this;
  }
  stop() {
    return $e.stop(this), this;
  }
  resize(t, e) {
    $e.running(this) ? this._resizeBeforeDraw = {
      width: t,
      height: e
    } : this._resize(t, e);
  }
  _resize(t, e) {
    const s = this.options, n = this.canvas, o = s.maintainAspectRatio && this.aspectRatio, r = this.platform.getMaximumSize(n, t, e, o), a = s.devicePixelRatio || this.platform.getDevicePixelRatio(), l = this.width ? "resize" : "attach";
    this.width = r.width, this.height = r.height, this._aspectRatio = this.aspectRatio, Mo(this, a, !0) && (this.notifyPlugins("resize", {
      size: r
    }), Rt(s.onResize, [
      this,
      r
    ], this), this.attached && this._doResize(l) && this.render());
  }
  ensureScalesHaveIDs() {
    const e = this.options.scales || {};
    Et(e, (s, n) => {
      s.id = n;
    });
  }
  buildOrUpdateScales() {
    const t = this.options, e = t.scales, s = this.scales, n = Object.keys(s).reduce((r, a) => (r[a] = !1, r), {});
    let o = [];
    e && (o = o.concat(Object.keys(e).map((r) => {
      const a = e[r], l = bn(r, a), d = l === "r", f = l === "x";
      return {
        options: a,
        dposition: d ? "chartArea" : f ? "bottom" : "left",
        dtype: d ? "radialLinear" : f ? "category" : "linear"
      };
    }))), Et(o, (r) => {
      const a = r.options, l = a.id, d = bn(l, a), f = Ct(a.type, r.dtype);
      (a.position === void 0 || Ko(a.position, d) !== Ko(r.dposition)) && (a.position = r.dposition), n[l] = !0;
      let x = null;
      if (l in s && s[l].type === f)
        x = s[l];
      else {
        const b = ye.getScale(f);
        x = new b({
          id: l,
          type: f,
          ctx: this.ctx,
          chart: this
        }), s[x.id] = x;
      }
      x.init(a, t);
    }), Et(n, (r, a) => {
      r || delete s[a];
    }), Et(s, (r) => {
      ce.configure(this, r, r.options), ce.addBox(this, r);
    });
  }
  _updateMetasets() {
    const t = this._metasets, e = this.data.datasets.length, s = t.length;
    if (t.sort((n, o) => n.index - o.index), s > e) {
      for (let n = e; n < s; ++n)
        this._destroyDatasetMeta(n);
      t.splice(e, s - e);
    }
    this._sortedMetasets = t.slice(0).sort(Jo("order", "index"));
  }
  _removeUnreferencedMetasets() {
    const { _metasets: t, data: { datasets: e } } = this;
    t.length > e.length && delete this._stacks, t.forEach((s, n) => {
      e.filter((o) => o === s._dataset).length === 0 && this._destroyDatasetMeta(n);
    });
  }
  buildOrUpdateControllers() {
    const t = [], e = this.data.datasets;
    let s, n;
    for (this._removeUnreferencedMetasets(), s = 0, n = e.length; s < n; s++) {
      const o = e[s];
      let r = this.getDatasetMeta(s);
      const a = o.type || this.config.type;
      if (r.type && r.type !== a && (this._destroyDatasetMeta(s), r = this.getDatasetMeta(s)), r.type = a, r.indexAxis = o.indexAxis || xn(a, this.options), r.order = o.order || 0, r.index = s, r.label = "" + o.label, r.visible = this.isDatasetVisible(s), r.controller)
        r.controller.updateIndex(s), r.controller.linkScales();
      else {
        const l = ye.getController(a), { datasetElementType: d, dataElementType: f } = Ht.datasets[a];
        Object.assign(l, {
          dataElementType: ye.getElement(f),
          datasetElementType: d && ye.getElement(d)
        }), r.controller = new l(this, s), t.push(r.controller);
      }
    }
    return this._updateMetasets(), t;
  }
  _resetElements() {
    Et(this.data.datasets, (t, e) => {
      this.getDatasetMeta(e).controller.reset();
    }, this);
  }
  reset() {
    this._resetElements(), this.notifyPlugins("reset");
  }
  update(t) {
    const e = this.config;
    e.update();
    const s = this._options = e.createResolver(e.chartOptionScopes(), this.getContext()), n = this._animationsDisabled = !s.animation;
    if (this._updateScales(), this._checkEventBindings(), this._updateHiddenIndices(), this._plugins.invalidate(), this.notifyPlugins("beforeUpdate", {
      mode: t,
      cancelable: !0
    }) === !1)
      return;
    const o = this.buildOrUpdateControllers();
    this.notifyPlugins("beforeElementsUpdate");
    let r = 0;
    for (let d = 0, f = this.data.datasets.length; d < f; d++) {
      const { controller: x } = this.getDatasetMeta(d), b = !n && o.indexOf(x) === -1;
      x.buildOrUpdateElements(b), r = Math.max(+x.getMaxOverflow(), r);
    }
    r = this._minPadding = s.layout.autoPadding ? r : 0, this._updateLayout(r), n || Et(o, (d) => {
      d.reset();
    }), this._updateDatasets(t), this.notifyPlugins("afterUpdate", {
      mode: t
    }), this._layers.sort(Jo("z", "_idx"));
    const { _active: a, _lastEvent: l } = this;
    l ? this._eventHandler(l, !0) : a.length && this._updateHoverStyles(a, a, !0), this.render();
  }
  _updateScales() {
    Et(this.scales, (t) => {
      ce.removeBox(this, t);
    }), this.ensureScalesHaveIDs(), this.buildOrUpdateScales();
  }
  _checkEventBindings() {
    const t = this.options, e = new Set(Object.keys(this._listeners)), s = new Set(t.events);
    (!uo(e, s) || !!this._responsiveListeners !== t.responsive) && (this.unbindEvents(), this.bindEvents());
  }
  _updateHiddenIndices() {
    const { _hiddenIndices: t } = this, e = this._getUniformDataChanges() || [];
    for (const { method: s, start: n, count: o } of e) {
      const r = s === "_removeElements" ? -o : o;
      $h(t, n, r);
    }
  }
  _getUniformDataChanges() {
    const t = this._dataChanges;
    if (!t || !t.length)
      return;
    this._dataChanges = [];
    const e = this.data.datasets.length, s = (o) => new Set(t.filter((r) => r[0] === o).map((r, a) => a + "," + r.splice(1).join(","))), n = s(0);
    for (let o = 1; o < e; o++)
      if (!uo(n, s(o)))
        return;
    return Array.from(n).map((o) => o.split(",")).map((o) => ({
      method: o[1],
      start: +o[2],
      count: +o[3]
    }));
  }
  _updateLayout(t) {
    if (this.notifyPlugins("beforeLayout", {
      cancelable: !0
    }) === !1)
      return;
    ce.update(this, this.width, this.height, t);
    const e = this.chartArea, s = e.width <= 0 || e.height <= 0;
    this._layers = [], Et(this.boxes, (n) => {
      s && n.position === "chartArea" || (n.configure && n.configure(), this._layers.push(...n._layers()));
    }, this), this._layers.forEach((n, o) => {
      n._idx = o;
    }), this.notifyPlugins("afterLayout");
  }
  _updateDatasets(t) {
    if (this.notifyPlugins("beforeDatasetsUpdate", {
      mode: t,
      cancelable: !0
    }) !== !1) {
      for (let e = 0, s = this.data.datasets.length; e < s; ++e)
        this.getDatasetMeta(e).controller.configure();
      for (let e = 0, s = this.data.datasets.length; e < s; ++e)
        this._updateDataset(e, He(t) ? t({
          datasetIndex: e
        }) : t);
      this.notifyPlugins("afterDatasetsUpdate", {
        mode: t
      });
    }
  }
  _updateDataset(t, e) {
    const s = this.getDatasetMeta(t), n = {
      meta: s,
      index: t,
      mode: e,
      cancelable: !0
    };
    this.notifyPlugins("beforeDatasetUpdate", n) !== !1 && (s.controller._update(e), n.cancelable = !1, this.notifyPlugins("afterDatasetUpdate", n));
  }
  render() {
    this.notifyPlugins("beforeRender", {
      cancelable: !0
    }) !== !1 && ($e.has(this) ? this.attached && !$e.running(this) && $e.start(this) : (this.draw(), Zo({
      chart: this
    })));
  }
  draw() {
    let t;
    if (this._resizeBeforeDraw) {
      const { width: s, height: n } = this._resizeBeforeDraw;
      this._resizeBeforeDraw = null, this._resize(s, n);
    }
    if (this.clear(), this.width <= 0 || this.height <= 0 || this.notifyPlugins("beforeDraw", {
      cancelable: !0
    }) === !1)
      return;
    const e = this._layers;
    for (t = 0; t < e.length && e[t].z <= 0; ++t)
      e[t].draw(this.chartArea);
    for (this._drawDatasets(); t < e.length; ++t)
      e[t].draw(this.chartArea);
    this.notifyPlugins("afterDraw");
  }
  _getSortedDatasetMetas(t) {
    const e = this._sortedMetasets, s = [];
    let n, o;
    for (n = 0, o = e.length; n < o; ++n) {
      const r = e[n];
      (!t || r.visible) && s.push(r);
    }
    return s;
  }
  getSortedVisibleDatasetMetas() {
    return this._getSortedDatasetMetas(!0);
  }
  _drawDatasets() {
    if (this.notifyPlugins("beforeDatasetsDraw", {
      cancelable: !0
    }) === !1)
      return;
    const t = this.getSortedVisibleDatasetMetas();
    for (let e = t.length - 1; e >= 0; --e)
      this._drawDataset(t[e]);
    this.notifyPlugins("afterDatasetsDraw");
  }
  _drawDataset(t) {
    const e = this.ctx, s = {
      meta: t,
      index: t.index,
      cancelable: !0
    }, n = ta(this, t);
    this.notifyPlugins("beforeDatasetDraw", s) !== !1 && (n && Ls(e, n), t.controller.draw(), n && Os(e), s.cancelable = !1, this.notifyPlugins("afterDatasetDraw", s));
  }
  isPointInArea(t) {
    return qi(t, this.chartArea, this._minPadding);
  }
  getElementsAtEventForMode(t, e, s, n) {
    const o = w0.modes[e];
    return typeof o == "function" ? o(this, t, s, n) : [];
  }
  getDatasetMeta(t) {
    const e = this.data.datasets[t], s = this._metasets;
    let n = s.filter((o) => o && o._dataset === e).pop();
    return n || (n = {
      type: null,
      data: [],
      dataset: null,
      controller: null,
      hidden: null,
      xAxisID: null,
      yAxisID: null,
      order: e && e.order || 0,
      index: t,
      _dataset: e,
      _parsed: [],
      _sorted: !1
    }, s.push(n)), n;
  }
  getContext() {
    return this.$context || (this.$context = ei(null, {
      chart: this,
      type: "chart"
    }));
  }
  getVisibleDatasetCount() {
    return this.getSortedVisibleDatasetMetas().length;
  }
  isDatasetVisible(t) {
    const e = this.data.datasets[t];
    if (!e)
      return !1;
    const s = this.getDatasetMeta(t);
    return typeof s.hidden == "boolean" ? !s.hidden : !e.hidden;
  }
  setDatasetVisibility(t, e) {
    const s = this.getDatasetMeta(t);
    s.hidden = !e;
  }
  toggleDataVisibility(t) {
    this._hiddenIndices[t] = !this._hiddenIndices[t];
  }
  getDataVisibility(t) {
    return !this._hiddenIndices[t];
  }
  _updateVisibility(t, e, s) {
    const n = s ? "show" : "hide", o = this.getDatasetMeta(t), r = o.controller._resolveAnimations(void 0, n);
    Ds(e) ? (o.data[e].hidden = !s, this.update()) : (this.setDatasetVisibility(t, s), r.update(o, {
      visible: s
    }), this.update((a) => a.datasetIndex === t ? n : void 0));
  }
  hide(t, e) {
    this._updateVisibility(t, e, !1);
  }
  show(t, e) {
    this._updateVisibility(t, e, !0);
  }
  _destroyDatasetMeta(t) {
    const e = this._metasets[t];
    e && e.controller && e.controller._destroy(), delete this._metasets[t];
  }
  _stop() {
    let t, e;
    for (this.stop(), $e.remove(this), t = 0, e = this.data.datasets.length; t < e; ++t)
      this._destroyDatasetMeta(t);
  }
  destroy() {
    this.notifyPlugins("beforeDestroy");
    const { canvas: t, ctx: e } = this;
    this._stop(), this.config.clearCache(), t && (this.unbindEvents(), wo(t, e), this.platform.releaseContext(e), this.canvas = null, this.ctx = null), delete ws[this.id], this.notifyPlugins("afterDestroy");
  }
  toBase64Image(...t) {
    return this.canvas.toDataURL(...t);
  }
  bindEvents() {
    this.bindUserEvents(), this.options.responsive ? this.bindResponsiveEvents() : this.attached = !0;
  }
  bindUserEvents() {
    const t = this._listeners, e = this.platform, s = (o, r) => {
      e.addEventListener(this, o, r), t[o] = r;
    }, n = (o, r, a) => {
      o.offsetX = r, o.offsetY = a, this._eventHandler(o);
    };
    Et(this.options.events, (o) => s(o, n));
  }
  bindResponsiveEvents() {
    this._responsiveListeners || (this._responsiveListeners = {});
    const t = this._responsiveListeners, e = this.platform, s = (l, d) => {
      e.addEventListener(this, l, d), t[l] = d;
    }, n = (l, d) => {
      t[l] && (e.removeEventListener(this, l, d), delete t[l]);
    }, o = (l, d) => {
      this.canvas && this.resize(l, d);
    };
    let r;
    const a = () => {
      n("attach", a), this.attached = !0, this.resize(), s("resize", o), s("detach", r);
    };
    r = () => {
      this.attached = !1, n("resize", o), this._stop(), this._resize(0, 0), s("attach", a);
    }, e.isAttached(this.canvas) ? a() : r();
  }
  unbindEvents() {
    Et(this._listeners, (t, e) => {
      this.platform.removeEventListener(this, e, t);
    }), this._listeners = {}, Et(this._responsiveListeners, (t, e) => {
      this.platform.removeEventListener(this, e, t);
    }), this._responsiveListeners = void 0;
  }
  updateHoverStyle(t, e, s) {
    const n = s ? "set" : "remove";
    let o, r, a, l;
    for (e === "dataset" && (o = this.getDatasetMeta(t[0].datasetIndex), o.controller["_" + n + "DatasetHoverStyle"]()), a = 0, l = t.length; a < l; ++a) {
      r = t[a];
      const d = r && this.getDatasetMeta(r.datasetIndex).controller;
      d && d[n + "HoverStyle"](r.element, r.datasetIndex, r.index);
    }
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t) {
    const e = this._active || [], s = t.map(({ datasetIndex: o, index: r }) => {
      const a = this.getDatasetMeta(o);
      if (!a)
        throw new Error("No dataset found at index " + o);
      return {
        datasetIndex: o,
        element: a.data[r],
        index: r
      };
    });
    !Ms(s, e) && (this._active = s, this._lastEvent = null, this._updateHoverStyles(s, e));
  }
  notifyPlugins(t, e, s) {
    return this._plugins.notify(this, t, e, s);
  }
  isPluginEnabled(t) {
    return this._plugins._cache.filter((e) => e.plugin.id === t).length === 1;
  }
  _updateHoverStyles(t, e, s) {
    const n = this.options.hover, o = (l, d) => l.filter((f) => !d.some((x) => f.datasetIndex === x.datasetIndex && f.index === x.index)), r = o(e, t), a = s ? t : o(t, e);
    r.length && this.updateHoverStyle(r, n.mode, !1), a.length && n.mode && this.updateHoverStyle(a, n.mode, !0);
  }
  _eventHandler(t, e) {
    const s = {
      event: t,
      replay: e,
      cancelable: !0,
      inChartArea: this.isPointInArea(t)
    }, n = (r) => (r.options.events || this.options.events).includes(t.native.type);
    if (this.notifyPlugins("beforeEvent", s, n) === !1)
      return;
    const o = this._handleEvent(t, e, s.inChartArea);
    return s.cancelable = !1, this.notifyPlugins("afterEvent", s, n), (o || s.changed) && this.render(), this;
  }
  _handleEvent(t, e, s) {
    const { _active: n = [], options: o } = this, r = e, a = this._getActiveElements(t, n, s, r), l = zl(t), d = Mh(t, this._lastEvent, s, l);
    s && (this._lastEvent = null, Rt(o.onHover, [
      t,
      a,
      this
    ], this), l && Rt(o.onClick, [
      t,
      a,
      this
    ], this));
    const f = !Ms(a, n);
    return (f || e) && (this._active = a, this._updateHoverStyles(a, n, e)), this._lastEvent = d, f;
  }
  _getActiveElements(t, e, s, n) {
    if (t.type === "mouseout")
      return [];
    if (!s)
      return e;
    const o = this.options.hover;
    return this.getElementsAtEventForMode(t, o.mode, o, n);
  }
};
function tr() {
  return Et(Is.instances, (i) => i._plugins.invalidate());
}
function fa(i, t, e = t) {
  i.lineCap = Ct(e.borderCapStyle, t.borderCapStyle), i.setLineDash(Ct(e.borderDash, t.borderDash)), i.lineDashOffset = Ct(e.borderDashOffset, t.borderDashOffset), i.lineJoin = Ct(e.borderJoinStyle, t.borderJoinStyle), i.lineWidth = Ct(e.borderWidth, t.borderWidth), i.strokeStyle = Ct(e.borderColor, t.borderColor);
}
function Sh(i, t, e) {
  i.lineTo(e.x, e.y);
}
function Ch(i) {
  return i.stepped ? dc : i.tension || i.cubicInterpolationMode === "monotone" ? uc : Sh;
}
function pa(i, t, e = {}) {
  const s = i.length, { start: n = 0, end: o = s - 1 } = e, { start: r, end: a } = t, l = Math.max(n, r), d = Math.min(o, a), f = n < r && o < r || n > a && o > a;
  return {
    count: s,
    start: l,
    loop: t.loop,
    ilen: d < l && !f ? s + d - l : d - l
  };
}
function Dh(i, t, e, s) {
  const { points: n, options: o } = t, { count: r, start: a, loop: l, ilen: d } = pa(n, e, s), f = Ch(o);
  let { move: x = !0, reverse: b } = s || {}, k, T, C;
  for (k = 0; k <= d; ++k)
    T = n[(a + (b ? d - k : k)) % r], !T.skip && (x ? (i.moveTo(T.x, T.y), x = !1) : f(i, C, T, b, o.stepped), C = T);
  return l && (T = n[(a + (b ? d : 0)) % r], f(i, C, T, b, o.stepped)), !!l;
}
function Ah(i, t, e, s) {
  const n = t.points, { count: o, start: r, ilen: a } = pa(n, e, s), { move: l = !0, reverse: d } = s || {};
  let f = 0, x = 0, b, k, T, C, A, P;
  const z = (W) => (r + (d ? a - W : W)) % o, O = () => {
    C !== A && (i.lineTo(f, A), i.lineTo(f, C), i.lineTo(f, P));
  };
  for (l && (k = n[z(0)], i.moveTo(k.x, k.y)), b = 0; b <= a; ++b) {
    if (k = n[z(b)], k.skip)
      continue;
    const W = k.x, R = k.y, Y = W | 0;
    Y === T ? (R < C ? C = R : R > A && (A = R), f = (x * f + W) / ++x) : (O(), i.lineTo(W, R), T = Y, x = 0, C = A = R), P = R;
  }
  O();
}
function _n(i) {
  const t = i.options, e = t.borderDash && t.borderDash.length;
  return !i._decimated && !i._loop && !t.tension && t.cubicInterpolationMode !== "monotone" && !t.stepped && !e ? Ah : Dh;
}
function Ph(i) {
  return i.stepped ? Yc : i.tension || i.cubicInterpolationMode === "monotone" ? Uc : qe;
}
function Th(i, t, e, s) {
  let n = t._path;
  n || (n = t._path = new Path2D(), t.path(n, e, s) && n.closePath()), fa(i, t.options), i.stroke(n);
}
function Lh(i, t, e, s) {
  const { segments: n, options: o } = t, r = _n(t);
  for (const a of n)
    fa(i, o, a.style), i.beginPath(), r(i, t, a, {
      start: e,
      end: e + s - 1
    }) && i.closePath(), i.stroke();
}
const Oh = typeof Path2D == "function";
function Eh(i, t, e, s) {
  Oh && !t.options.segment ? Th(i, t, e, s) : Lh(i, t, e, s);
}
class Rs extends ii {
  static id = "line";
  static defaults = {
    borderCapStyle: "butt",
    borderDash: [],
    borderDashOffset: 0,
    borderJoinStyle: "miter",
    borderWidth: 3,
    capBezierPoints: !0,
    cubicInterpolationMode: "default",
    fill: !1,
    spanGaps: !1,
    stepped: !1,
    tension: 0
  };
  static defaultRoutes = {
    backgroundColor: "backgroundColor",
    borderColor: "borderColor"
  };
  static descriptors = {
    _scriptable: !0,
    _indexable: (t) => t !== "borderDash" && t !== "fill"
  };
  constructor(t) {
    super(), this.animated = !0, this.options = void 0, this._chart = void 0, this._loop = void 0, this._fullLoop = void 0, this._path = void 0, this._points = void 0, this._segments = void 0, this._decimated = !1, this._pointsUpdated = !1, this._datasetIndex = void 0, t && Object.assign(this, t);
  }
  updateControlPoints(t, e) {
    const s = this.options;
    if ((s.tension || s.cubicInterpolationMode === "monotone") && !s.stepped && !this._pointsUpdated) {
      const n = s.spanGaps ? this._loop : this._fullLoop;
      Rc(this._points, s, t, n, e), this._pointsUpdated = !0;
    }
  }
  set points(t) {
    this._points = t, delete this._segments, delete this._path, this._pointsUpdated = !1;
  }
  get points() {
    return this._points;
  }
  get segments() {
    return this._segments || (this._segments = Zc(this, this.options.segment));
  }
  first() {
    const t = this.segments, e = this.points;
    return t.length && e[t[0].start];
  }
  last() {
    const t = this.segments, e = this.points, s = t.length;
    return s && e[t[s - 1].end];
  }
  interpolate(t, e) {
    const s = this.options, n = t[e], o = this.points, r = Qr(this, {
      property: e,
      start: n,
      end: n
    });
    if (!r.length)
      return;
    const a = [], l = Ph(s);
    let d, f;
    for (d = 0, f = r.length; d < f; ++d) {
      const { start: x, end: b } = r[d], k = o[x], T = o[b];
      if (k === T) {
        a.push(k);
        continue;
      }
      const C = Math.abs((n - k[e]) / (T[e] - k[e])), A = l(k, T, C, s.stepped);
      A[e] = t[e], a.push(A);
    }
    return a.length === 1 ? a[0] : a;
  }
  pathSegment(t, e, s) {
    return _n(this)(t, this, e, s);
  }
  path(t, e, s) {
    const n = this.segments, o = _n(this);
    let r = this._loop;
    e = e || 0, s = s || this.points.length - e;
    for (const a of n)
      r &= o(t, this, a, {
        start: e,
        end: e + s - 1
      });
    return !!r;
  }
  draw(t, e, s, n) {
    const o = this.options || {};
    (this.points || []).length && o.borderWidth && (t.save(), Eh(t, this, s, n), t.restore()), this.animated && (this._pointsUpdated = !1, this._path = void 0);
  }
}
function er(i, t, e, s) {
  const n = i.options, { [e]: o } = i.getProps([
    e
  ], s);
  return Math.abs(t - o) < n.radius + n.hitRadius;
}
class Bh extends ii {
  static id = "point";
  parsed;
  skip;
  stop;
  /**
  * @type {any}
  */
  static defaults = {
    borderWidth: 1,
    hitRadius: 1,
    hoverBorderWidth: 1,
    hoverRadius: 4,
    pointStyle: "circle",
    radius: 3,
    rotation: 0
  };
  /**
  * @type {any}
  */
  static defaultRoutes = {
    backgroundColor: "backgroundColor",
    borderColor: "borderColor"
  };
  constructor(t) {
    super(), this.options = void 0, this.parsed = void 0, this.skip = void 0, this.stop = void 0, t && Object.assign(this, t);
  }
  inRange(t, e, s) {
    const n = this.options, { x: o, y: r } = this.getProps([
      "x",
      "y"
    ], s);
    return Math.pow(t - o, 2) + Math.pow(e - r, 2) < Math.pow(n.hitRadius + n.radius, 2);
  }
  inXRange(t, e) {
    return er(this, t, "x", e);
  }
  inYRange(t, e) {
    return er(this, t, "y", e);
  }
  getCenterPoint(t) {
    const { x: e, y: s } = this.getProps([
      "x",
      "y"
    ], t);
    return {
      x: e,
      y: s
    };
  }
  size(t) {
    t = t || this.options || {};
    let e = t.radius || 0;
    e = Math.max(e, e && t.hoverRadius || 0);
    const s = e && t.borderWidth || 0;
    return (e + s) * 2;
  }
  draw(t, e) {
    const s = this.options;
    this.skip || s.radius < 0.1 || !qi(this, e, this.size(s) / 2) || (t.strokeStyle = s.borderColor, t.lineWidth = s.borderWidth, t.fillStyle = s.backgroundColor, mn(t, s, this.x, this.y));
  }
  getRange() {
    const t = this.options || {};
    return t.radius + t.hitRadius;
  }
}
function Ih(i, t, e) {
  const s = i.segments, n = i.points, o = t.points, r = [];
  for (const a of s) {
    let { start: l, end: d } = a;
    d = zs(l, d, n);
    const f = vn(e, n[l], n[d], a.loop);
    if (!t.segments) {
      r.push({
        source: a,
        target: f,
        start: n[l],
        end: n[d]
      });
      continue;
    }
    const x = Qr(t, f);
    for (const b of x) {
      const k = vn(e, o[b.start], o[b.end], b.loop), T = Zr(a, n, k);
      for (const C of T)
        r.push({
          source: C,
          target: b,
          start: {
            [e]: ir(f, k, "start", Math.max)
          },
          end: {
            [e]: ir(f, k, "end", Math.min)
          }
        });
    }
  }
  return r;
}
function vn(i, t, e, s) {
  if (s)
    return;
  let n = t[i], o = e[i];
  return i === "angle" && (n = xe(n), o = xe(o)), {
    property: i,
    start: n,
    end: o
  };
}
function Rh(i, t) {
  const { x: e = null, y: s = null } = i || {}, n = t.points, o = [];
  return t.segments.forEach(({ start: r, end: a }) => {
    a = zs(r, a, n);
    const l = n[r], d = n[a];
    s !== null ? (o.push({
      x: l.x,
      y: s
    }), o.push({
      x: d.x,
      y: s
    })) : e !== null && (o.push({
      x: e,
      y: l.y
    }), o.push({
      x: e,
      y: d.y
    }));
  }), o;
}
function zs(i, t, e) {
  for (; t > i; t--) {
    const s = e[t];
    if (!isNaN(s.x) && !isNaN(s.y))
      break;
  }
  return t;
}
function ir(i, t, e, s) {
  return i && t ? s(i[e], t[e]) : i ? i[e] : t ? t[e] : 0;
}
function ga(i, t) {
  let e = [], s = !1;
  return Wt(i) ? (s = !0, e = i) : e = Rh(i, t), e.length ? new Rs({
    points: e,
    options: {
      tension: 0
    },
    _loop: s,
    _fullLoop: s
  }) : null;
}
function sr(i) {
  return i && i.fill !== !1;
}
function zh(i, t, e) {
  let n = i[t].fill;
  const o = [
    t
  ];
  let r;
  if (!e)
    return n;
  for (; n !== !1 && o.indexOf(n) === -1; ) {
    if (!qt(n))
      return n;
    if (r = i[n], !r)
      return !1;
    if (r.visible)
      return n;
    o.push(n), n = r.fill;
  }
  return !1;
}
function Fh(i, t, e) {
  const s = Wh(i);
  if (Dt(s))
    return isNaN(s.value) ? !1 : s;
  let n = parseFloat(s);
  return qt(n) && Math.floor(n) === n ? Hh(s[0], t, n, e) : [
    "origin",
    "start",
    "end",
    "stack",
    "shape"
  ].indexOf(s) >= 0 && s;
}
function Hh(i, t, e, s) {
  return (i === "-" || i === "+") && (e = t + e), e === t || e < 0 || e >= s ? !1 : e;
}
function jh(i, t) {
  let e = null;
  return i === "start" ? e = t.bottom : i === "end" ? e = t.top : Dt(i) ? e = t.getPixelForValue(i.value) : t.getBasePixel && (e = t.getBasePixel()), e;
}
function Nh(i, t, e) {
  let s;
  return i === "start" ? s = e : i === "end" ? s = t.options.reverse ? t.min : t.max : Dt(i) ? s = i.value : s = t.getBaseValue(), s;
}
function Wh(i) {
  const t = i.options, e = t.fill;
  let s = Ct(e && e.target, e);
  return s === void 0 && (s = !!t.backgroundColor), s === !1 || s === null ? !1 : s === !0 ? "origin" : s;
}
function Vh(i) {
  const { scale: t, index: e, line: s } = i, n = [], o = s.segments, r = s.points, a = Yh(t, e);
  a.push(ga({
    x: null,
    y: t.bottom
  }, s));
  for (let l = 0; l < o.length; l++) {
    const d = o[l];
    for (let f = d.start; f <= d.end; f++)
      Uh(n, r[f], a);
  }
  return new Rs({
    points: n,
    options: {}
  });
}
function Yh(i, t) {
  const e = [], s = i.getMatchingVisibleMetas("line");
  for (let n = 0; n < s.length; n++) {
    const o = s[n];
    if (o.index === t)
      break;
    o.hidden || e.unshift(o.dataset);
  }
  return e;
}
function Uh(i, t, e) {
  const s = [];
  for (let n = 0; n < e.length; n++) {
    const o = e[n], { first: r, last: a, point: l } = Xh(o, t, "x");
    if (!(!l || r && a)) {
      if (r)
        s.unshift(l);
      else if (i.push(l), !a)
        break;
    }
  }
  i.push(...s);
}
function Xh(i, t, e) {
  const s = i.interpolate(t, e);
  if (!s)
    return {};
  const n = s[e], o = i.segments, r = i.points;
  let a = !1, l = !1;
  for (let d = 0; d < o.length; d++) {
    const f = o[d], x = r[f.start][e], b = r[f.end][e];
    if (xi(n, x, b)) {
      a = n === x, l = n === b;
      break;
    }
  }
  return {
    first: a,
    last: l,
    point: s
  };
}
class ma {
  constructor(t) {
    this.x = t.x, this.y = t.y, this.radius = t.radius;
  }
  pathSegment(t, e, s) {
    const { x: n, y: o, radius: r } = this;
    return e = e || {
      start: 0,
      end: fe
    }, t.arc(n, o, r, e.end, e.start, !0), !s.bounds;
  }
  interpolate(t) {
    const { x: e, y: s, radius: n } = this, o = t.angle;
    return {
      x: e + Math.cos(o) * n,
      y: s + Math.sin(o) * n,
      angle: o
    };
  }
}
function Gh(i) {
  const { chart: t, fill: e, line: s } = i;
  if (qt(e))
    return qh(t, e);
  if (e === "stack")
    return Vh(i);
  if (e === "shape")
    return !0;
  const n = Kh(i);
  return n instanceof ma ? n : ga(n, s);
}
function qh(i, t) {
  const e = i.getDatasetMeta(t);
  return e && i.isDatasetVisible(t) ? e.dataset : null;
}
function Kh(i) {
  return (i.scale || {}).getPointPositionForValue ? Zh(i) : Jh(i);
}
function Jh(i) {
  const { scale: t = {}, fill: e } = i, s = jh(e, t);
  if (qt(s)) {
    const n = t.isHorizontal();
    return {
      x: n ? s : null,
      y: n ? null : s
    };
  }
  return null;
}
function Zh(i) {
  const { scale: t, fill: e } = i, s = t.options, n = t.getLabels().length, o = s.reverse ? t.max : t.min, r = Nh(e, t, o), a = [];
  if (s.grid.circular) {
    const l = t.getPointPositionForValue(0, o);
    return new ma({
      x: l.x,
      y: l.y,
      radius: t.getDistanceFromCenterForValue(r)
    });
  }
  for (let l = 0; l < n; ++l)
    a.push(t.getPointPositionForValue(l, r));
  return a;
}
function an(i, t, e) {
  const s = Gh(t), { chart: n, index: o, line: r, scale: a, axis: l } = t, d = r.options, f = d.fill, x = d.backgroundColor, { above: b = x, below: k = x } = f || {}, T = n.getDatasetMeta(o), C = ta(n, T);
  s && r.points.length && (Ls(i, e), Qh(i, {
    line: r,
    target: s,
    above: b,
    below: k,
    area: e,
    scale: a,
    axis: l,
    clip: C
  }), Os(i));
}
function Qh(i, t) {
  const { line: e, target: s, above: n, below: o, area: r, scale: a, clip: l } = t, d = e._loop ? "angle" : t.axis;
  i.save();
  let f = o;
  o !== n && (d === "x" ? (nr(i, s, r.top), ln(i, {
    line: e,
    target: s,
    color: n,
    scale: a,
    property: d,
    clip: l
  }), i.restore(), i.save(), nr(i, s, r.bottom)) : d === "y" && (or(i, s, r.left), ln(i, {
    line: e,
    target: s,
    color: o,
    scale: a,
    property: d,
    clip: l
  }), i.restore(), i.save(), or(i, s, r.right), f = n)), ln(i, {
    line: e,
    target: s,
    color: f,
    scale: a,
    property: d,
    clip: l
  }), i.restore();
}
function nr(i, t, e) {
  const { segments: s, points: n } = t;
  let o = !0, r = !1;
  i.beginPath();
  for (const a of s) {
    const { start: l, end: d } = a, f = n[l], x = n[zs(l, d, n)];
    o ? (i.moveTo(f.x, f.y), o = !1) : (i.lineTo(f.x, e), i.lineTo(f.x, f.y)), r = !!t.pathSegment(i, a, {
      move: r
    }), r ? i.closePath() : i.lineTo(x.x, e);
  }
  i.lineTo(t.first().x, e), i.closePath(), i.clip();
}
function or(i, t, e) {
  const { segments: s, points: n } = t;
  let o = !0, r = !1;
  i.beginPath();
  for (const a of s) {
    const { start: l, end: d } = a, f = n[l], x = n[zs(l, d, n)];
    o ? (i.moveTo(f.x, f.y), o = !1) : (i.lineTo(e, f.y), i.lineTo(f.x, f.y)), r = !!t.pathSegment(i, a, {
      move: r
    }), r ? i.closePath() : i.lineTo(e, x.y);
  }
  i.lineTo(e, t.first().y), i.closePath(), i.clip();
}
function ln(i, t) {
  const { line: e, target: s, property: n, color: o, scale: r, clip: a } = t, l = Ih(e, s, n);
  for (const { source: d, target: f, start: x, end: b } of l) {
    const { style: { backgroundColor: k = o } = {} } = d, T = s !== !0;
    i.save(), i.fillStyle = k, td(i, r, a, T && vn(n, x, b)), i.beginPath();
    const C = !!e.pathSegment(i, d);
    let A;
    if (T) {
      C ? i.closePath() : rr(i, s, b, n);
      const P = !!s.pathSegment(i, f, {
        move: C,
        reverse: !0
      });
      A = C && P, A || rr(i, s, x, n);
    }
    i.closePath(), i.fill(A ? "evenodd" : "nonzero"), i.restore();
  }
}
function td(i, t, e, s) {
  const n = t.chart.chartArea, { property: o, start: r, end: a } = s || {};
  if (o === "x" || o === "y") {
    let l, d, f, x;
    o === "x" ? (l = r, d = n.top, f = a, x = n.bottom) : (l = n.left, d = r, f = n.right, x = a), i.beginPath(), e && (l = Math.max(l, e.left), f = Math.min(f, e.right), d = Math.max(d, e.top), x = Math.min(x, e.bottom)), i.rect(l, d, f - l, x - d), i.clip();
  }
}
function rr(i, t, e, s) {
  const n = t.interpolate(e, s);
  n && i.lineTo(n.x, n.y);
}
var ed = {
  id: "filler",
  afterDatasetsUpdate(i, t, e) {
    const s = (i.data.datasets || []).length, n = [];
    let o, r, a, l;
    for (r = 0; r < s; ++r)
      o = i.getDatasetMeta(r), a = o.dataset, l = null, a && a.options && a instanceof Rs && (l = {
        visible: i.isDatasetVisible(r),
        index: r,
        fill: Fh(a, r, s),
        chart: i,
        axis: o.controller.options.indexAxis,
        scale: o.vScale,
        line: a
      }), o.$filler = l, n.push(l);
    for (r = 0; r < s; ++r)
      l = n[r], !(!l || l.fill === !1) && (l.fill = zh(n, r, e.propagate));
  },
  beforeDraw(i, t, e) {
    const s = e.drawTime === "beforeDraw", n = i.getSortedVisibleDatasetMetas(), o = i.chartArea;
    for (let r = n.length - 1; r >= 0; --r) {
      const a = n[r].$filler;
      a && (a.line.updateControlPoints(o, a.axis), s && a.fill && an(i.ctx, a, o));
    }
  },
  beforeDatasetsDraw(i, t, e) {
    if (e.drawTime !== "beforeDatasetsDraw")
      return;
    const s = i.getSortedVisibleDatasetMetas();
    for (let n = s.length - 1; n >= 0; --n) {
      const o = s[n].$filler;
      sr(o) && an(i.ctx, o, i.chartArea);
    }
  },
  beforeDatasetDraw(i, t, e) {
    const s = t.meta.$filler;
    !sr(s) || e.drawTime !== "beforeDatasetDraw" || an(i.ctx, s, i.chartArea);
  },
  defaults: {
    propagate: !0,
    drawTime: "beforeDatasetDraw"
  }
};
const ar = (i, t) => {
  let { boxHeight: e = t, boxWidth: s = t } = i;
  return i.usePointStyle && (e = Math.min(e, t), s = i.pointStyleWidth || Math.min(s, t)), {
    boxWidth: s,
    boxHeight: e,
    itemHeight: Math.max(t, e)
  };
}, id = (i, t) => i !== null && t !== null && i.datasetIndex === t.datasetIndex && i.index === t.index;
class lr extends ii {
  constructor(t) {
    super(), this._added = !1, this.legendHitBoxes = [], this._hoveredItem = null, this.doughnutMode = !1, this.chart = t.chart, this.options = t.options, this.ctx = t.ctx, this.legendItems = void 0, this.columnSizes = void 0, this.lineWidths = void 0, this.maxHeight = void 0, this.maxWidth = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.height = void 0, this.width = void 0, this._margins = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t, e, s) {
    this.maxWidth = t, this.maxHeight = e, this._margins = s, this.setDimensions(), this.buildLabels(), this.fit();
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = this._margins.left, this.right = this.width) : (this.height = this.maxHeight, this.top = this._margins.top, this.bottom = this.height);
  }
  buildLabels() {
    const t = this.options.labels || {};
    let e = Rt(t.generateLabels, [
      this.chart
    ], this) || [];
    t.filter && (e = e.filter((s) => t.filter(s, this.chart.data))), t.sort && (e = e.sort((s, n) => t.sort(s, n, this.chart.data))), this.options.reverse && e.reverse(), this.legendItems = e;
  }
  fit() {
    const { options: t, ctx: e } = this;
    if (!t.display) {
      this.width = this.height = 0;
      return;
    }
    const s = t.labels, n = Gt(s.font), o = n.size, r = this._computeTitleHeight(), { boxWidth: a, itemHeight: l } = ar(s, o);
    let d, f;
    e.font = n.string, this.isHorizontal() ? (d = this.maxWidth, f = this._fitRows(r, o, a, l) + 10) : (f = this.maxHeight, d = this._fitCols(r, n, a, l) + 10), this.width = Math.min(d, t.maxWidth || this.maxWidth), this.height = Math.min(f, t.maxHeight || this.maxHeight);
  }
  _fitRows(t, e, s, n) {
    const { ctx: o, maxWidth: r, options: { labels: { padding: a } } } = this, l = this.legendHitBoxes = [], d = this.lineWidths = [
      0
    ], f = n + a;
    let x = t;
    o.textAlign = "left", o.textBaseline = "middle";
    let b = -1, k = -f;
    return this.legendItems.forEach((T, C) => {
      const A = s + e / 2 + o.measureText(T.text).width;
      (C === 0 || d[d.length - 1] + A + 2 * a > r) && (x += f, d[d.length - (C > 0 ? 0 : 1)] = 0, k += f, b++), l[C] = {
        left: 0,
        top: k,
        row: b,
        width: A,
        height: n
      }, d[d.length - 1] += A + a;
    }), x;
  }
  _fitCols(t, e, s, n) {
    const { ctx: o, maxHeight: r, options: { labels: { padding: a } } } = this, l = this.legendHitBoxes = [], d = this.columnSizes = [], f = r - t;
    let x = a, b = 0, k = 0, T = 0, C = 0;
    return this.legendItems.forEach((A, P) => {
      const { itemWidth: z, itemHeight: O } = sd(s, e, o, A, n);
      P > 0 && k + O + 2 * a > f && (x += b + a, d.push({
        width: b,
        height: k
      }), T += b + a, C++, b = k = 0), l[P] = {
        left: T,
        top: k,
        col: C,
        width: z,
        height: O
      }, b = Math.max(b, z), k += O + a;
    }), x += b, d.push({
      width: b,
      height: k
    }), x;
  }
  adjustHitBoxes() {
    if (!this.options.display)
      return;
    const t = this._computeTitleHeight(), { legendHitBoxes: e, options: { align: s, labels: { padding: n }, rtl: o } } = this, r = bi(o, this.left, this.width);
    if (this.isHorizontal()) {
      let a = 0, l = Xt(s, this.left + n, this.right - this.lineWidths[a]);
      for (const d of e)
        a !== d.row && (a = d.row, l = Xt(s, this.left + n, this.right - this.lineWidths[a])), d.top += this.top + t + n, d.left = r.leftForLtr(r.x(l), d.width), l += d.width + n;
    } else {
      let a = 0, l = Xt(s, this.top + t + n, this.bottom - this.columnSizes[a].height);
      for (const d of e)
        d.col !== a && (a = d.col, l = Xt(s, this.top + t + n, this.bottom - this.columnSizes[a].height)), d.top = l, d.left += this.left + n, d.left = r.leftForLtr(r.x(d.left), d.width), l += d.height + n;
    }
  }
  isHorizontal() {
    return this.options.position === "top" || this.options.position === "bottom";
  }
  draw() {
    if (this.options.display) {
      const t = this.ctx;
      Ls(t, this), this._draw(), Os(t);
    }
  }
  _draw() {
    const { options: t, columnSizes: e, lineWidths: s, ctx: n } = this, { align: o, labels: r } = t, a = Ht.color, l = bi(t.rtl, this.left, this.width), d = Gt(r.font), { padding: f } = r, x = d.size, b = x / 2;
    let k;
    this.drawTitle(), n.textAlign = l.textAlign("left"), n.textBaseline = "middle", n.lineWidth = 0.5, n.font = d.string;
    const { boxWidth: T, boxHeight: C, itemHeight: A } = ar(r, x), P = function(Y, B, H) {
      if (isNaN(T) || T <= 0 || isNaN(C) || C < 0)
        return;
      n.save();
      const it = Ct(H.lineWidth, 1);
      if (n.fillStyle = Ct(H.fillStyle, a), n.lineCap = Ct(H.lineCap, "butt"), n.lineDashOffset = Ct(H.lineDashOffset, 0), n.lineJoin = Ct(H.lineJoin, "miter"), n.lineWidth = it, n.strokeStyle = Ct(H.strokeStyle, a), n.setLineDash(Ct(H.lineDash, [])), r.usePointStyle) {
        const ct = {
          radius: C * Math.SQRT2 / 2,
          pointStyle: H.pointStyle,
          rotation: H.rotation,
          borderWidth: it
        }, X = l.xPlus(Y, T / 2), st = B + b;
        Nr(n, ct, X, st, r.pointStyleWidth && T);
      } else {
        const ct = B + Math.max((x - C) / 2, 0), X = l.leftForLtr(Y, T), st = Ui(H.borderRadius);
        n.beginPath(), Object.values(st).some((ft) => ft !== 0) ? yn(n, {
          x: X,
          y: ct,
          w: T,
          h: C,
          radius: st
        }) : n.rect(X, ct, T, C), n.fill(), it !== 0 && n.stroke();
      }
      n.restore();
    }, z = function(Y, B, H) {
      Ki(n, H.text, Y, B + A / 2, d, {
        strikethrough: H.hidden,
        textAlign: l.textAlign(H.textAlign)
      });
    }, O = this.isHorizontal(), W = this._computeTitleHeight();
    O ? k = {
      x: Xt(o, this.left + f, this.right - s[0]),
      y: this.top + f + W,
      line: 0
    } : k = {
      x: this.left + f,
      y: Xt(o, this.top + W + f, this.bottom - e[0].height),
      line: 0
    }, qr(this.ctx, t.textDirection);
    const R = A + f;
    this.legendItems.forEach((Y, B) => {
      n.strokeStyle = Y.fontColor, n.fillStyle = Y.fontColor;
      const H = n.measureText(Y.text).width, it = l.textAlign(Y.textAlign || (Y.textAlign = r.textAlign)), ct = T + b + H;
      let X = k.x, st = k.y;
      l.setWidth(this.width), O ? B > 0 && X + ct + f > this.right && (st = k.y += R, k.line++, X = k.x = Xt(o, this.left + f, this.right - s[k.line])) : B > 0 && st + R > this.bottom && (X = k.x = X + e[k.line].width + f, k.line++, st = k.y = Xt(o, this.top + W + f, this.bottom - e[k.line].height));
      const ft = l.x(X);
      if (P(ft, st, Y), X = tc(it, X + T + b, O ? X + ct : this.right, t.rtl), z(l.x(X), st, Y), O)
        k.x += ct + f;
      else if (typeof Y.text != "string") {
        const Q = d.lineHeight;
        k.y += ya(Y, Q) + f;
      } else
        k.y += R;
    }), Kr(this.ctx, t.textDirection);
  }
  drawTitle() {
    const t = this.options, e = t.title, s = Gt(e.font), n = he(e.padding);
    if (!e.display)
      return;
    const o = bi(t.rtl, this.left, this.width), r = this.ctx, a = e.position, l = s.size / 2, d = n.top + l;
    let f, x = this.left, b = this.width;
    if (this.isHorizontal())
      b = Math.max(...this.lineWidths), f = this.top + d, x = Xt(t.align, x, this.right - b);
    else {
      const T = this.columnSizes.reduce((C, A) => Math.max(C, A.height), 0);
      f = d + Xt(t.align, this.top, this.bottom - T - t.labels.padding - this._computeTitleHeight());
    }
    const k = Xt(a, x, x + b);
    r.textAlign = o.textAlign(Dn(a)), r.textBaseline = "middle", r.strokeStyle = e.color, r.fillStyle = e.color, r.font = s.string, Ki(r, e.text, k, f, s);
  }
  _computeTitleHeight() {
    const t = this.options.title, e = Gt(t.font), s = he(t.padding);
    return t.display ? e.lineHeight + s.height : 0;
  }
  _getLegendItemAt(t, e) {
    let s, n, o;
    if (xi(t, this.left, this.right) && xi(e, this.top, this.bottom)) {
      for (o = this.legendHitBoxes, s = 0; s < o.length; ++s)
        if (n = o[s], xi(t, n.left, n.left + n.width) && xi(e, n.top, n.top + n.height))
          return this.legendItems[s];
    }
    return null;
  }
  handleEvent(t) {
    const e = this.options;
    if (!rd(t.type, e))
      return;
    const s = this._getLegendItemAt(t.x, t.y);
    if (t.type === "mousemove" || t.type === "mouseout") {
      const n = this._hoveredItem, o = id(n, s);
      n && !o && Rt(e.onLeave, [
        t,
        n,
        this
      ], this), this._hoveredItem = s, s && !o && Rt(e.onHover, [
        t,
        s,
        this
      ], this);
    } else s && Rt(e.onClick, [
      t,
      s,
      this
    ], this);
  }
}
function sd(i, t, e, s, n) {
  const o = nd(s, i, t, e), r = od(n, s, t.lineHeight);
  return {
    itemWidth: o,
    itemHeight: r
  };
}
function nd(i, t, e, s) {
  let n = i.text;
  return n && typeof n != "string" && (n = n.reduce((o, r) => o.length > r.length ? o : r)), t + e.size / 2 + s.measureText(n).width;
}
function od(i, t, e) {
  let s = i;
  return typeof t.text != "string" && (s = ya(t, e)), s;
}
function ya(i, t) {
  const e = i.text ? i.text.length : 0;
  return t * e;
}
function rd(i, t) {
  return !!((i === "mousemove" || i === "mouseout") && (t.onHover || t.onLeave) || t.onClick && (i === "click" || i === "mouseup"));
}
var ad = {
  id: "legend",
  _element: lr,
  start(i, t, e) {
    const s = i.legend = new lr({
      ctx: i.ctx,
      options: e,
      chart: i
    });
    ce.configure(i, s, e), ce.addBox(i, s);
  },
  stop(i) {
    ce.removeBox(i, i.legend), delete i.legend;
  },
  beforeUpdate(i, t, e) {
    const s = i.legend;
    ce.configure(i, s, e), s.options = e;
  },
  afterUpdate(i) {
    const t = i.legend;
    t.buildLabels(), t.adjustHitBoxes();
  },
  afterEvent(i, t) {
    t.replay || i.legend.handleEvent(t.event);
  },
  defaults: {
    display: !0,
    position: "top",
    align: "center",
    fullSize: !0,
    reverse: !1,
    weight: 1e3,
    onClick(i, t, e) {
      const s = t.datasetIndex, n = e.chart;
      n.isDatasetVisible(s) ? (n.hide(s), t.hidden = !0) : (n.show(s), t.hidden = !1);
    },
    onHover: null,
    onLeave: null,
    labels: {
      color: (i) => i.chart.options.color,
      boxWidth: 40,
      padding: 10,
      generateLabels(i) {
        const t = i.data.datasets, { labels: { usePointStyle: e, pointStyle: s, textAlign: n, color: o, useBorderRadius: r, borderRadius: a } } = i.legend.options;
        return i._getSortedDatasetMetas().map((l) => {
          const d = l.controller.getStyle(e ? 0 : void 0), f = he(d.borderWidth);
          return {
            text: t[l.index].label,
            fillStyle: d.backgroundColor,
            fontColor: o,
            hidden: !l.visible,
            lineCap: d.borderCapStyle,
            lineDash: d.borderDash,
            lineDashOffset: d.borderDashOffset,
            lineJoin: d.borderJoinStyle,
            lineWidth: (f.width + f.height) / 4,
            strokeStyle: d.borderColor,
            pointStyle: s || d.pointStyle,
            rotation: d.rotation,
            textAlign: n || d.textAlign,
            borderRadius: r && (a || d.borderRadius),
            datasetIndex: l.index
          };
        }, this);
      }
    },
    title: {
      color: (i) => i.chart.options.color,
      display: !1,
      position: "center",
      text: ""
    }
  },
  descriptors: {
    _scriptable: (i) => !i.startsWith("on"),
    labels: {
      _scriptable: (i) => ![
        "generateLabels",
        "filter",
        "sort"
      ].includes(i)
    }
  }
};
class xa extends ii {
  constructor(t) {
    super(), this.chart = t.chart, this.options = t.options, this.ctx = t.ctx, this._padding = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t, e) {
    const s = this.options;
    if (this.left = 0, this.top = 0, !s.display) {
      this.width = this.height = this.right = this.bottom = 0;
      return;
    }
    this.width = this.right = t, this.height = this.bottom = e;
    const n = Wt(s.text) ? s.text.length : 1;
    this._padding = he(s.padding);
    const o = n * Gt(s.font).lineHeight + this._padding.height;
    this.isHorizontal() ? this.height = o : this.width = o;
  }
  isHorizontal() {
    const t = this.options.position;
    return t === "top" || t === "bottom";
  }
  _drawArgs(t) {
    const { top: e, left: s, bottom: n, right: o, options: r } = this, a = r.align;
    let l = 0, d, f, x;
    return this.isHorizontal() ? (f = Xt(a, s, o), x = e + t, d = o - s) : (r.position === "left" ? (f = s + t, x = Xt(a, n, e), l = Vt * -0.5) : (f = o - t, x = Xt(a, e, n), l = Vt * 0.5), d = n - e), {
      titleX: f,
      titleY: x,
      maxWidth: d,
      rotation: l
    };
  }
  draw() {
    const t = this.ctx, e = this.options;
    if (!e.display)
      return;
    const s = Gt(e.font), o = s.lineHeight / 2 + this._padding.top, { titleX: r, titleY: a, maxWidth: l, rotation: d } = this._drawArgs(o);
    Ki(t, e.text, 0, 0, s, {
      color: e.color,
      maxWidth: l,
      rotation: d,
      textAlign: Dn(e.align),
      textBaseline: "middle",
      translation: [
        r,
        a
      ]
    });
  }
}
function ld(i, t) {
  const e = new xa({
    ctx: i.ctx,
    options: t,
    chart: i
  });
  ce.configure(i, e, t), ce.addBox(i, e), i.titleBlock = e;
}
var cd = {
  id: "title",
  _element: xa,
  start(i, t, e) {
    ld(i, e);
  },
  stop(i) {
    const t = i.titleBlock;
    ce.removeBox(i, t), delete i.titleBlock;
  },
  beforeUpdate(i, t, e) {
    const s = i.titleBlock;
    ce.configure(i, s, e), s.options = e;
  },
  defaults: {
    align: "center",
    display: !1,
    font: {
      weight: "bold"
    },
    fullSize: !0,
    padding: 10,
    position: "top",
    text: "",
    weight: 2e3
  },
  defaultRoutes: {
    color: "color"
  },
  descriptors: {
    _scriptable: !0,
    _indexable: !1
  }
};
const ji = {
  average(i) {
    if (!i.length)
      return !1;
    let t, e, s = /* @__PURE__ */ new Set(), n = 0, o = 0;
    for (t = 0, e = i.length; t < e; ++t) {
      const a = i[t].element;
      if (a && a.hasValue()) {
        const l = a.tooltipPosition();
        s.add(l.x), n += l.y, ++o;
      }
    }
    return o === 0 || s.size === 0 ? !1 : {
      x: [
        ...s
      ].reduce((a, l) => a + l) / s.size,
      y: n / o
    };
  },
  nearest(i, t) {
    if (!i.length)
      return !1;
    let e = t.x, s = t.y, n = Number.POSITIVE_INFINITY, o, r, a;
    for (o = 0, r = i.length; o < r; ++o) {
      const l = i[o].element;
      if (l && l.hasValue()) {
        const d = l.getCenterPoint(), f = pn(t, d);
        f < n && (n = f, a = l);
      }
    }
    if (a) {
      const l = a.tooltipPosition();
      e = l.x, s = l.y;
    }
    return {
      x: e,
      y: s
    };
  }
};
function me(i, t) {
  return t && (Wt(t) ? Array.prototype.push.apply(i, t) : i.push(t)), i;
}
function Me(i) {
  return (typeof i == "string" || i instanceof String) && i.indexOf(`
`) > -1 ? i.split(`
`) : i;
}
function hd(i, t) {
  const { element: e, datasetIndex: s, index: n } = t, o = i.getDatasetMeta(s).controller, { label: r, value: a } = o.getLabelAndValue(n);
  return {
    chart: i,
    label: r,
    parsed: o.getParsed(n),
    raw: i.data.datasets[s].data[n],
    formattedValue: a,
    dataset: o.getDataset(),
    dataIndex: n,
    datasetIndex: s,
    element: e
  };
}
function cr(i, t) {
  const e = i.chart.ctx, { body: s, footer: n, title: o } = i, { boxWidth: r, boxHeight: a } = t, l = Gt(t.bodyFont), d = Gt(t.titleFont), f = Gt(t.footerFont), x = o.length, b = n.length, k = s.length, T = he(t.padding);
  let C = T.height, A = 0, P = s.reduce((W, R) => W + R.before.length + R.lines.length + R.after.length, 0);
  if (P += i.beforeBody.length + i.afterBody.length, x && (C += x * d.lineHeight + (x - 1) * t.titleSpacing + t.titleMarginBottom), P) {
    const W = t.displayColors ? Math.max(a, l.lineHeight) : l.lineHeight;
    C += k * W + (P - k) * l.lineHeight + (P - 1) * t.bodySpacing;
  }
  b && (C += t.footerMarginTop + b * f.lineHeight + (b - 1) * t.footerSpacing);
  let z = 0;
  const O = function(W) {
    A = Math.max(A, e.measureText(W).width + z);
  };
  return e.save(), e.font = d.string, Et(i.title, O), e.font = l.string, Et(i.beforeBody.concat(i.afterBody), O), z = t.displayColors ? r + 2 + t.boxPadding : 0, Et(s, (W) => {
    Et(W.before, O), Et(W.lines, O), Et(W.after, O);
  }), z = 0, e.font = f.string, Et(i.footer, O), e.restore(), A += T.width, {
    width: A,
    height: C
  };
}
function dd(i, t) {
  const { y: e, height: s } = t;
  return e < s / 2 ? "top" : e > i.height - s / 2 ? "bottom" : "center";
}
function ud(i, t, e, s) {
  const { x: n, width: o } = s, r = e.caretSize + e.caretPadding;
  if (i === "left" && n + o + r > t.width || i === "right" && n - o - r < 0)
    return !0;
}
function fd(i, t, e, s) {
  const { x: n, width: o } = e, { width: r, chartArea: { left: a, right: l } } = i;
  let d = "center";
  return s === "center" ? d = n <= (a + l) / 2 ? "left" : "right" : n <= o / 2 ? d = "left" : n >= r - o / 2 && (d = "right"), ud(d, i, t, e) && (d = "center"), d;
}
function hr(i, t, e) {
  const s = e.yAlign || t.yAlign || dd(i, e);
  return {
    xAlign: e.xAlign || t.xAlign || fd(i, t, e, s),
    yAlign: s
  };
}
function pd(i, t) {
  let { x: e, width: s } = i;
  return t === "right" ? e -= s : t === "center" && (e -= s / 2), e;
}
function gd(i, t, e) {
  let { y: s, height: n } = i;
  return t === "top" ? s += e : t === "bottom" ? s -= n + e : s -= n / 2, s;
}
function dr(i, t, e, s) {
  const { caretSize: n, caretPadding: o, cornerRadius: r } = i, { xAlign: a, yAlign: l } = e, d = n + o, { topLeft: f, topRight: x, bottomLeft: b, bottomRight: k } = Ui(r);
  let T = pd(t, a);
  const C = gd(t, l, d);
  return l === "center" ? a === "left" ? T += d : a === "right" && (T -= d) : a === "left" ? T -= Math.max(f, b) + n : a === "right" && (T += Math.max(x, k) + n), {
    x: le(T, 0, s.width - t.width),
    y: le(C, 0, s.height - t.height)
  };
}
function xs(i, t, e) {
  const s = he(e.padding);
  return t === "center" ? i.x + i.width / 2 : t === "right" ? i.x + i.width - s.right : i.x + s.left;
}
function ur(i) {
  return me([], Me(i));
}
function md(i, t, e) {
  return ei(i, {
    tooltip: t,
    tooltipItems: e,
    type: "tooltip"
  });
}
function fr(i, t) {
  const e = t && t.dataset && t.dataset.tooltip && t.dataset.tooltip.callbacks;
  return e ? i.override(e) : i;
}
const ba = {
  beforeTitle: ke,
  title(i) {
    if (i.length > 0) {
      const t = i[0], e = t.chart.data.labels, s = e ? e.length : 0;
      if (this && this.options && this.options.mode === "dataset")
        return t.dataset.label || "";
      if (t.label)
        return t.label;
      if (s > 0 && t.dataIndex < s)
        return e[t.dataIndex];
    }
    return "";
  },
  afterTitle: ke,
  beforeBody: ke,
  beforeLabel: ke,
  label(i) {
    if (this && this.options && this.options.mode === "dataset")
      return i.label + ": " + i.formattedValue || i.formattedValue;
    let t = i.dataset.label || "";
    t && (t += ": ");
    const e = i.formattedValue;
    return It(e) || (t += e), t;
  },
  labelColor(i) {
    const e = i.chart.getDatasetMeta(i.datasetIndex).controller.getStyle(i.dataIndex);
    return {
      borderColor: e.borderColor,
      backgroundColor: e.backgroundColor,
      borderWidth: e.borderWidth,
      borderDash: e.borderDash,
      borderDashOffset: e.borderDashOffset,
      borderRadius: 0
    };
  },
  labelTextColor() {
    return this.options.bodyColor;
  },
  labelPointStyle(i) {
    const e = i.chart.getDatasetMeta(i.datasetIndex).controller.getStyle(i.dataIndex);
    return {
      pointStyle: e.pointStyle,
      rotation: e.rotation
    };
  },
  afterLabel: ke,
  afterBody: ke,
  beforeFooter: ke,
  footer: ke,
  afterFooter: ke
};
function Qt(i, t, e, s) {
  const n = i[t].call(e, s);
  return typeof n > "u" ? ba[t].call(e, s) : n;
}
class pr extends ii {
  static positioners = ji;
  constructor(t) {
    super(), this.opacity = 0, this._active = [], this._eventPosition = void 0, this._size = void 0, this._cachedAnimations = void 0, this._tooltipItems = [], this.$animations = void 0, this.$context = void 0, this.chart = t.chart, this.options = t.options, this.dataPoints = void 0, this.title = void 0, this.beforeBody = void 0, this.body = void 0, this.afterBody = void 0, this.footer = void 0, this.xAlign = void 0, this.yAlign = void 0, this.x = void 0, this.y = void 0, this.height = void 0, this.width = void 0, this.caretX = void 0, this.caretY = void 0, this.labelColors = void 0, this.labelPointStyles = void 0, this.labelTextColors = void 0;
  }
  initialize(t) {
    this.options = t, this._cachedAnimations = void 0, this.$context = void 0;
  }
  _resolveAnimations() {
    const t = this._cachedAnimations;
    if (t)
      return t;
    const e = this.chart, s = this.options.setContext(this.getContext()), n = s.enabled && e.options.animation && s.animations, o = new ea(this.chart, n);
    return n._cacheable && (this._cachedAnimations = Object.freeze(o)), o;
  }
  getContext() {
    return this.$context || (this.$context = md(this.chart.getContext(), this, this._tooltipItems));
  }
  getTitle(t, e) {
    const { callbacks: s } = e, n = Qt(s, "beforeTitle", this, t), o = Qt(s, "title", this, t), r = Qt(s, "afterTitle", this, t);
    let a = [];
    return a = me(a, Me(n)), a = me(a, Me(o)), a = me(a, Me(r)), a;
  }
  getBeforeBody(t, e) {
    return ur(Qt(e.callbacks, "beforeBody", this, t));
  }
  getBody(t, e) {
    const { callbacks: s } = e, n = [];
    return Et(t, (o) => {
      const r = {
        before: [],
        lines: [],
        after: []
      }, a = fr(s, o);
      me(r.before, Me(Qt(a, "beforeLabel", this, o))), me(r.lines, Qt(a, "label", this, o)), me(r.after, Me(Qt(a, "afterLabel", this, o))), n.push(r);
    }), n;
  }
  getAfterBody(t, e) {
    return ur(Qt(e.callbacks, "afterBody", this, t));
  }
  getFooter(t, e) {
    const { callbacks: s } = e, n = Qt(s, "beforeFooter", this, t), o = Qt(s, "footer", this, t), r = Qt(s, "afterFooter", this, t);
    let a = [];
    return a = me(a, Me(n)), a = me(a, Me(o)), a = me(a, Me(r)), a;
  }
  _createItems(t) {
    const e = this._active, s = this.chart.data, n = [], o = [], r = [];
    let a = [], l, d;
    for (l = 0, d = e.length; l < d; ++l)
      a.push(hd(this.chart, e[l]));
    return t.filter && (a = a.filter((f, x, b) => t.filter(f, x, b, s))), t.itemSort && (a = a.sort((f, x) => t.itemSort(f, x, s))), Et(a, (f) => {
      const x = fr(t.callbacks, f);
      n.push(Qt(x, "labelColor", this, f)), o.push(Qt(x, "labelPointStyle", this, f)), r.push(Qt(x, "labelTextColor", this, f));
    }), this.labelColors = n, this.labelPointStyles = o, this.labelTextColors = r, this.dataPoints = a, a;
  }
  update(t, e) {
    const s = this.options.setContext(this.getContext()), n = this._active;
    let o, r = [];
    if (!n.length)
      this.opacity !== 0 && (o = {
        opacity: 0
      });
    else {
      const a = ji[s.position].call(this, n, this._eventPosition);
      r = this._createItems(s), this.title = this.getTitle(r, s), this.beforeBody = this.getBeforeBody(r, s), this.body = this.getBody(r, s), this.afterBody = this.getAfterBody(r, s), this.footer = this.getFooter(r, s);
      const l = this._size = cr(this, s), d = Object.assign({}, a, l), f = hr(this.chart, s, d), x = dr(s, d, f, this.chart);
      this.xAlign = f.xAlign, this.yAlign = f.yAlign, o = {
        opacity: 1,
        x: x.x,
        y: x.y,
        width: l.width,
        height: l.height,
        caretX: a.x,
        caretY: a.y
      };
    }
    this._tooltipItems = r, this.$context = void 0, o && this._resolveAnimations().update(this, o), t && s.external && s.external.call(this, {
      chart: this.chart,
      tooltip: this,
      replay: e
    });
  }
  drawCaret(t, e, s, n) {
    const o = this.getCaretPosition(t, s, n);
    e.lineTo(o.x1, o.y1), e.lineTo(o.x2, o.y2), e.lineTo(o.x3, o.y3);
  }
  getCaretPosition(t, e, s) {
    const { xAlign: n, yAlign: o } = this, { caretSize: r, cornerRadius: a } = s, { topLeft: l, topRight: d, bottomLeft: f, bottomRight: x } = Ui(a), { x: b, y: k } = t, { width: T, height: C } = e;
    let A, P, z, O, W, R;
    return o === "center" ? (W = k + C / 2, n === "left" ? (A = b, P = A - r, O = W + r, R = W - r) : (A = b + T, P = A + r, O = W - r, R = W + r), z = A) : (n === "left" ? P = b + Math.max(l, f) + r : n === "right" ? P = b + T - Math.max(d, x) - r : P = this.caretX, o === "top" ? (O = k, W = O - r, A = P - r, z = P + r) : (O = k + C, W = O + r, A = P + r, z = P - r), R = O), {
      x1: A,
      x2: P,
      x3: z,
      y1: O,
      y2: W,
      y3: R
    };
  }
  drawTitle(t, e, s) {
    const n = this.title, o = n.length;
    let r, a, l;
    if (o) {
      const d = bi(s.rtl, this.x, this.width);
      for (t.x = xs(this, s.titleAlign, s), e.textAlign = d.textAlign(s.titleAlign), e.textBaseline = "middle", r = Gt(s.titleFont), a = s.titleSpacing, e.fillStyle = s.titleColor, e.font = r.string, l = 0; l < o; ++l)
        e.fillText(n[l], d.x(t.x), t.y + r.lineHeight / 2), t.y += r.lineHeight + a, l + 1 === o && (t.y += s.titleMarginBottom - a);
    }
  }
  _drawColorBox(t, e, s, n, o) {
    const r = this.labelColors[s], a = this.labelPointStyles[s], { boxHeight: l, boxWidth: d } = o, f = Gt(o.bodyFont), x = xs(this, "left", o), b = n.x(x), k = l < f.lineHeight ? (f.lineHeight - l) / 2 : 0, T = e.y + k;
    if (o.usePointStyle) {
      const C = {
        radius: Math.min(d, l) / 2,
        pointStyle: a.pointStyle,
        rotation: a.rotation,
        borderWidth: 1
      }, A = n.leftForLtr(b, d) + d / 2, P = T + l / 2;
      t.strokeStyle = o.multiKeyBackground, t.fillStyle = o.multiKeyBackground, mn(t, C, A, P), t.strokeStyle = r.borderColor, t.fillStyle = r.backgroundColor, mn(t, C, A, P);
    } else {
      t.lineWidth = Dt(r.borderWidth) ? Math.max(...Object.values(r.borderWidth)) : r.borderWidth || 1, t.strokeStyle = r.borderColor, t.setLineDash(r.borderDash || []), t.lineDashOffset = r.borderDashOffset || 0;
      const C = n.leftForLtr(b, d), A = n.leftForLtr(n.xPlus(b, 1), d - 2), P = Ui(r.borderRadius);
      Object.values(P).some((z) => z !== 0) ? (t.beginPath(), t.fillStyle = o.multiKeyBackground, yn(t, {
        x: C,
        y: T,
        w: d,
        h: l,
        radius: P
      }), t.fill(), t.stroke(), t.fillStyle = r.backgroundColor, t.beginPath(), yn(t, {
        x: A,
        y: T + 1,
        w: d - 2,
        h: l - 2,
        radius: P
      }), t.fill()) : (t.fillStyle = o.multiKeyBackground, t.fillRect(C, T, d, l), t.strokeRect(C, T, d, l), t.fillStyle = r.backgroundColor, t.fillRect(A, T + 1, d - 2, l - 2));
    }
    t.fillStyle = this.labelTextColors[s];
  }
  drawBody(t, e, s) {
    const { body: n } = this, { bodySpacing: o, bodyAlign: r, displayColors: a, boxHeight: l, boxWidth: d, boxPadding: f } = s, x = Gt(s.bodyFont);
    let b = x.lineHeight, k = 0;
    const T = bi(s.rtl, this.x, this.width), C = function(H) {
      e.fillText(H, T.x(t.x + k), t.y + b / 2), t.y += b + o;
    }, A = T.textAlign(r);
    let P, z, O, W, R, Y, B;
    for (e.textAlign = r, e.textBaseline = "middle", e.font = x.string, t.x = xs(this, A, s), e.fillStyle = s.bodyColor, Et(this.beforeBody, C), k = a && A !== "right" ? r === "center" ? d / 2 + f : d + 2 + f : 0, W = 0, Y = n.length; W < Y; ++W) {
      for (P = n[W], z = this.labelTextColors[W], e.fillStyle = z, Et(P.before, C), O = P.lines, a && O.length && (this._drawColorBox(e, t, W, T, s), b = Math.max(x.lineHeight, l)), R = 0, B = O.length; R < B; ++R)
        C(O[R]), b = x.lineHeight;
      Et(P.after, C);
    }
    k = 0, b = x.lineHeight, Et(this.afterBody, C), t.y -= o;
  }
  drawFooter(t, e, s) {
    const n = this.footer, o = n.length;
    let r, a;
    if (o) {
      const l = bi(s.rtl, this.x, this.width);
      for (t.x = xs(this, s.footerAlign, s), t.y += s.footerMarginTop, e.textAlign = l.textAlign(s.footerAlign), e.textBaseline = "middle", r = Gt(s.footerFont), e.fillStyle = s.footerColor, e.font = r.string, a = 0; a < o; ++a)
        e.fillText(n[a], l.x(t.x), t.y + r.lineHeight / 2), t.y += r.lineHeight + s.footerSpacing;
    }
  }
  drawBackground(t, e, s, n) {
    const { xAlign: o, yAlign: r } = this, { x: a, y: l } = t, { width: d, height: f } = s, { topLeft: x, topRight: b, bottomLeft: k, bottomRight: T } = Ui(n.cornerRadius);
    e.fillStyle = n.backgroundColor, e.strokeStyle = n.borderColor, e.lineWidth = n.borderWidth, e.beginPath(), e.moveTo(a + x, l), r === "top" && this.drawCaret(t, e, s, n), e.lineTo(a + d - b, l), e.quadraticCurveTo(a + d, l, a + d, l + b), r === "center" && o === "right" && this.drawCaret(t, e, s, n), e.lineTo(a + d, l + f - T), e.quadraticCurveTo(a + d, l + f, a + d - T, l + f), r === "bottom" && this.drawCaret(t, e, s, n), e.lineTo(a + k, l + f), e.quadraticCurveTo(a, l + f, a, l + f - k), r === "center" && o === "left" && this.drawCaret(t, e, s, n), e.lineTo(a, l + x), e.quadraticCurveTo(a, l, a + x, l), e.closePath(), e.fill(), n.borderWidth > 0 && e.stroke();
  }
  _updateAnimationTarget(t) {
    const e = this.chart, s = this.$animations, n = s && s.x, o = s && s.y;
    if (n || o) {
      const r = ji[t.position].call(this, this._active, this._eventPosition);
      if (!r)
        return;
      const a = this._size = cr(this, t), l = Object.assign({}, r, this._size), d = hr(e, t, l), f = dr(t, l, d, e);
      (n._to !== f.x || o._to !== f.y) && (this.xAlign = d.xAlign, this.yAlign = d.yAlign, this.width = a.width, this.height = a.height, this.caretX = r.x, this.caretY = r.y, this._resolveAnimations().update(this, f));
    }
  }
  _willRender() {
    return !!this.opacity;
  }
  draw(t) {
    const e = this.options.setContext(this.getContext());
    let s = this.opacity;
    if (!s)
      return;
    this._updateAnimationTarget(e);
    const n = {
      width: this.width,
      height: this.height
    }, o = {
      x: this.x,
      y: this.y
    };
    s = Math.abs(s) < 1e-3 ? 0 : s;
    const r = he(e.padding), a = this.title.length || this.beforeBody.length || this.body.length || this.afterBody.length || this.footer.length;
    e.enabled && a && (t.save(), t.globalAlpha = s, this.drawBackground(o, t, n, e), qr(t, e.textDirection), o.y += r.top, this.drawTitle(o, t, e), this.drawBody(o, t, e), this.drawFooter(o, t, e), Kr(t, e.textDirection), t.restore());
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t, e) {
    const s = this._active, n = t.map(({ datasetIndex: a, index: l }) => {
      const d = this.chart.getDatasetMeta(a);
      if (!d)
        throw new Error("Cannot find a dataset at index " + a);
      return {
        datasetIndex: a,
        element: d.data[l],
        index: l
      };
    }), o = !Ms(s, n), r = this._positionChanged(n, e);
    (o || r) && (this._active = n, this._eventPosition = e, this._ignoreReplayEvents = !0, this.update(!0));
  }
  handleEvent(t, e, s = !0) {
    if (e && this._ignoreReplayEvents)
      return !1;
    this._ignoreReplayEvents = !1;
    const n = this.options, o = this._active || [], r = this._getActiveElements(t, o, e, s), a = this._positionChanged(r, t), l = e || !Ms(r, o) || a;
    return l && (this._active = r, (n.enabled || n.external) && (this._eventPosition = {
      x: t.x,
      y: t.y
    }, this.update(!0, e))), l;
  }
  _getActiveElements(t, e, s, n) {
    const o = this.options;
    if (t.type === "mouseout")
      return [];
    if (!n)
      return e.filter((a) => this.chart.data.datasets[a.datasetIndex] && this.chart.getDatasetMeta(a.datasetIndex).controller.getParsed(a.index) !== void 0);
    const r = this.chart.getElementsAtEventForMode(t, o.mode, o, s);
    return o.reverse && r.reverse(), r;
  }
  _positionChanged(t, e) {
    const { caretX: s, caretY: n, options: o } = this, r = ji[o.position].call(this, t, e);
    return r !== !1 && (s !== r.x || n !== r.y);
  }
}
var yd = {
  id: "tooltip",
  _element: pr,
  positioners: ji,
  afterInit(i, t, e) {
    e && (i.tooltip = new pr({
      chart: i,
      options: e
    }));
  },
  beforeUpdate(i, t, e) {
    i.tooltip && i.tooltip.initialize(e);
  },
  reset(i, t, e) {
    i.tooltip && i.tooltip.initialize(e);
  },
  afterDraw(i) {
    const t = i.tooltip;
    if (t && t._willRender()) {
      const e = {
        tooltip: t
      };
      if (i.notifyPlugins("beforeTooltipDraw", {
        ...e,
        cancelable: !0
      }) === !1)
        return;
      t.draw(i.ctx), i.notifyPlugins("afterTooltipDraw", e);
    }
  },
  afterEvent(i, t) {
    if (i.tooltip) {
      const e = t.replay;
      i.tooltip.handleEvent(t.event, e, t.inChartArea) && (t.changed = !0);
    }
  },
  defaults: {
    enabled: !0,
    external: null,
    position: "average",
    backgroundColor: "rgba(0,0,0,0.8)",
    titleColor: "#fff",
    titleFont: {
      weight: "bold"
    },
    titleSpacing: 2,
    titleMarginBottom: 6,
    titleAlign: "left",
    bodyColor: "#fff",
    bodySpacing: 2,
    bodyFont: {},
    bodyAlign: "left",
    footerColor: "#fff",
    footerSpacing: 2,
    footerMarginTop: 6,
    footerFont: {
      weight: "bold"
    },
    footerAlign: "left",
    padding: 6,
    caretPadding: 2,
    caretSize: 5,
    cornerRadius: 6,
    boxHeight: (i, t) => t.bodyFont.size,
    boxWidth: (i, t) => t.bodyFont.size,
    multiKeyBackground: "#fff",
    displayColors: !0,
    boxPadding: 0,
    borderColor: "rgba(0,0,0,0)",
    borderWidth: 0,
    animation: {
      duration: 400,
      easing: "easeOutQuart"
    },
    animations: {
      numbers: {
        type: "number",
        properties: [
          "x",
          "y",
          "width",
          "height",
          "caretX",
          "caretY"
        ]
      },
      opacity: {
        easing: "linear",
        duration: 200
      }
    },
    callbacks: ba
  },
  defaultRoutes: {
    bodyFont: "font",
    footerFont: "font",
    titleFont: "font"
  },
  descriptors: {
    _scriptable: (i) => i !== "filter" && i !== "itemSort" && i !== "external",
    _indexable: !1,
    callbacks: {
      _scriptable: !1,
      _indexable: !1
    },
    animation: {
      _fallback: !1
    },
    animations: {
      _fallback: "animation"
    }
  },
  additionalOptionScopes: [
    "interaction"
  ]
};
const xd = (i, t, e, s) => (typeof t == "string" ? (e = i.push(t) - 1, s.unshift({
  index: e,
  label: t
})) : isNaN(t) && (e = null), e);
function bd(i, t, e, s) {
  const n = i.indexOf(t);
  if (n === -1)
    return xd(i, t, e, s);
  const o = i.lastIndexOf(t);
  return n !== o ? e : n;
}
const _d = (i, t) => i === null ? null : le(Math.round(i), 0, t);
function gr(i) {
  const t = this.getLabels();
  return i >= 0 && i < t.length ? t[i] : i;
}
class vd extends Mi {
  static id = "category";
  static defaults = {
    ticks: {
      callback: gr
    }
  };
  constructor(t) {
    super(t), this._startValue = void 0, this._valueRange = 0, this._addedLabels = [];
  }
  init(t) {
    const e = this._addedLabels;
    if (e.length) {
      const s = this.getLabels();
      for (const { index: n, label: o } of e)
        s[n] === o && s.splice(n, 1);
      this._addedLabels = [];
    }
    super.init(t);
  }
  parse(t, e) {
    if (It(t))
      return null;
    const s = this.getLabels();
    return e = isFinite(e) && s[e] === t ? e : bd(s, t, Ct(e, t), this._addedLabels), _d(e, s.length - 1);
  }
  determineDataLimits() {
    const { minDefined: t, maxDefined: e } = this.getUserBounds();
    let { min: s, max: n } = this.getMinMax(!0);
    this.options.bounds === "ticks" && (t || (s = 0), e || (n = this.getLabels().length - 1)), this.min = s, this.max = n;
  }
  buildTicks() {
    const t = this.min, e = this.max, s = this.options.offset, n = [];
    let o = this.getLabels();
    o = t === 0 && e === o.length - 1 ? o : o.slice(t, e + 1), this._valueRange = Math.max(o.length - (s ? 0 : 1), 1), this._startValue = this.min - (s ? 0.5 : 0);
    for (let r = t; r <= e; r++)
      n.push({
        value: r
      });
    return n;
  }
  getLabelForValue(t) {
    return gr.call(this, t);
  }
  configure() {
    super.configure(), this.isHorizontal() || (this._reversePixels = !this._reversePixels);
  }
  getPixelForValue(t) {
    return typeof t != "number" && (t = this.parse(t)), t === null ? NaN : this.getPixelForDecimal((t - this._startValue) / this._valueRange);
  }
  getPixelForTick(t) {
    const e = this.ticks;
    return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t].value);
  }
  getValueForPixel(t) {
    return Math.round(this._startValue + this.getDecimalForPixel(t) * this._valueRange);
  }
  getBasePixel() {
    return this.bottom;
  }
}
function wd(i, t) {
  const e = [], { bounds: n, step: o, min: r, max: a, precision: l, count: d, maxTicks: f, maxDigits: x, includeBounds: b } = i, k = o || 1, T = f - 1, { min: C, max: A } = t, P = !It(r), z = !It(a), O = !It(d), W = (A - C) / (x + 1);
  let R = po((A - C) / T / k) * k, Y, B, H, it;
  if (R < 1e-14 && !P && !z)
    return [
      {
        value: C
      },
      {
        value: A
      }
    ];
  it = Math.ceil(A / R) - Math.floor(C / R), it > T && (R = po(it * R / T / k) * k), It(l) || (Y = Math.pow(10, l), R = Math.ceil(R * Y) / Y), n === "ticks" ? (B = Math.floor(C / R) * R, H = Math.ceil(A / R) * R) : (B = C, H = A), P && z && o && Wl((a - r) / o, R / 1e3) ? (it = Math.round(Math.min((a - r) / R, f)), R = (a - r) / it, B = r, H = a) : O ? (B = P ? r : B, H = z ? a : H, it = d - 1, R = (H - B) / it) : (it = (H - B) / R, Wi(it, Math.round(it), R / 1e3) ? it = Math.round(it) : it = Math.ceil(it));
  const ct = Math.max(go(R), go(B));
  Y = Math.pow(10, It(l) ? ct : l), B = Math.round(B * Y) / Y, H = Math.round(H * Y) / Y;
  let X = 0;
  for (P && (b && B !== r ? (e.push({
    value: r
  }), B < r && X++, Wi(Math.round((B + X * R) * Y) / Y, r, mr(r, W, i)) && X++) : B < r && X++); X < it; ++X) {
    const st = Math.round((B + X * R) * Y) / Y;
    if (z && st > a)
      break;
    e.push({
      value: st
    });
  }
  return z && b && H !== a ? e.length && Wi(e[e.length - 1].value, a, mr(a, W, i)) ? e[e.length - 1].value = a : e.push({
    value: a
  }) : (!z || H === a) && e.push({
    value: H
  }), e;
}
function mr(i, t, { horizontal: e, minRotation: s }) {
  const n = Ke(s), o = (e ? Math.sin(n) : Math.cos(n)) || 1e-3, r = 0.75 * t * ("" + i).length;
  return Math.min(t / o, r);
}
class kd extends Mi {
  constructor(t) {
    super(t), this.start = void 0, this.end = void 0, this._startValue = void 0, this._endValue = void 0, this._valueRange = 0;
  }
  parse(t, e) {
    return It(t) || (typeof t == "number" || t instanceof Number) && !isFinite(+t) ? null : +t;
  }
  handleTickRangeOptions() {
    const { beginAtZero: t } = this.options, { minDefined: e, maxDefined: s } = this.getUserBounds();
    let { min: n, max: o } = this;
    const r = (l) => n = e ? n : l, a = (l) => o = s ? o : l;
    if (t) {
      const l = _i(n), d = _i(o);
      l < 0 && d < 0 ? a(0) : l > 0 && d > 0 && r(0);
    }
    if (n === o) {
      let l = o === 0 ? 1 : Math.abs(o * 0.05);
      a(o + l), t || r(n - l);
    }
    this.min = n, this.max = o;
  }
  getTickLimit() {
    const t = this.options.ticks;
    let { maxTicksLimit: e, stepSize: s } = t, n;
    return s ? (n = Math.ceil(this.max / s) - Math.floor(this.min / s) + 1, n > 1e3 && (console.warn(`scales.${this.id}.ticks.stepSize: ${s} would result generating up to ${n} ticks. Limiting to 1000.`), n = 1e3)) : (n = this.computeTickLimit(), e = e || 11), e && (n = Math.min(e, n)), n;
  }
  computeTickLimit() {
    return Number.POSITIVE_INFINITY;
  }
  buildTicks() {
    const t = this.options, e = t.ticks;
    let s = this.getTickLimit();
    s = Math.max(2, s);
    const n = {
      maxTicks: s,
      bounds: t.bounds,
      min: t.min,
      max: t.max,
      precision: e.precision,
      step: e.stepSize,
      count: e.count,
      maxDigits: this._maxDigits(),
      horizontal: this.isHorizontal(),
      minRotation: e.minRotation || 0,
      includeBounds: e.includeBounds !== !1
    }, o = this._range || this, r = wd(n, o);
    return t.bounds === "ticks" && Vl(r, this, "value"), t.reverse ? (r.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), r;
  }
  configure() {
    const t = this.ticks;
    let e = this.min, s = this.max;
    if (super.configure(), this.options.offset && t.length) {
      const n = (s - e) / Math.max(t.length - 1, 1) / 2;
      e -= n, s += n;
    }
    this._startValue = e, this._endValue = s, this._valueRange = s - e;
  }
  getLabelForValue(t) {
    return Hr(t, this.chart.options.locale, this.options.ticks.format);
  }
}
class $d extends kd {
  static id = "linear";
  static defaults = {
    ticks: {
      callback: jr.formatters.numeric
    }
  };
  determineDataLimits() {
    const { min: t, max: e } = this.getMinMax(!0);
    this.min = qt(t) ? t : 0, this.max = qt(e) ? e : 1, this.handleTickRangeOptions();
  }
  computeTickLimit() {
    const t = this.isHorizontal(), e = t ? this.width : this.height, s = Ke(this.options.ticks.minRotation), n = (t ? Math.sin(s) : Math.cos(s)) || 1e-3, o = this._resolveTickFontOptions(0);
    return Math.ceil(e / Math.min(40, o.lineHeight / n));
  }
  getPixelForValue(t) {
    return t === null ? NaN : this.getPixelForDecimal((t - this._startValue) / this._valueRange);
  }
  getValueForPixel(t) {
    return this._startValue + this.getDecimalForPixel(t) * this._valueRange;
  }
}
const Fs = {
  millisecond: {
    common: !0,
    size: 1,
    steps: 1e3
  },
  second: {
    common: !0,
    size: 1e3,
    steps: 60
  },
  minute: {
    common: !0,
    size: 6e4,
    steps: 60
  },
  hour: {
    common: !0,
    size: 36e5,
    steps: 24
  },
  day: {
    common: !0,
    size: 864e5,
    steps: 30
  },
  week: {
    common: !1,
    size: 6048e5,
    steps: 4
  },
  month: {
    common: !0,
    size: 2628e6,
    steps: 12
  },
  quarter: {
    common: !1,
    size: 7884e6,
    steps: 4
  },
  year: {
    common: !0,
    size: 3154e7
  }
}, te = /* @__PURE__ */ Object.keys(Fs);
function yr(i, t) {
  return i - t;
}
function xr(i, t) {
  if (It(t))
    return null;
  const e = i._adapter, { parser: s, round: n, isoWeekday: o } = i._parseOpts;
  let r = t;
  return typeof s == "function" && (r = s(r)), qt(r) || (r = typeof s == "string" ? e.parse(r, s) : e.parse(r)), r === null ? null : (n && (r = n === "week" && (vi(o) || o === !0) ? e.startOf(r, "isoWeek", o) : e.startOf(r, n)), +r);
}
function br(i, t, e, s) {
  const n = te.length;
  for (let o = te.indexOf(i); o < n - 1; ++o) {
    const r = Fs[te[o]], a = r.steps ? r.steps : Number.MAX_SAFE_INTEGER;
    if (r.common && Math.ceil((e - t) / (a * r.size)) <= s)
      return te[o];
  }
  return te[n - 1];
}
function Md(i, t, e, s, n) {
  for (let o = te.length - 1; o >= te.indexOf(e); o--) {
    const r = te[o];
    if (Fs[r].common && i._adapter.diff(n, s, r) >= t - 1)
      return r;
  }
  return te[e ? te.indexOf(e) : 0];
}
function Sd(i) {
  for (let t = te.indexOf(i) + 1, e = te.length; t < e; ++t)
    if (Fs[te[t]].common)
      return te[t];
}
function _r(i, t, e) {
  if (!e)
    i[t] = !0;
  else if (e.length) {
    const { lo: s, hi: n } = Cn(e, t), o = e[s] >= t ? e[s] : e[n];
    i[o] = !0;
  }
}
function Cd(i, t, e, s) {
  const n = i._adapter, o = +n.startOf(t[0].value, s), r = t[t.length - 1].value;
  let a, l;
  for (a = o; a <= r; a = +n.add(a, 1, s))
    l = e[a], l >= 0 && (t[l].major = !0);
  return t;
}
function vr(i, t, e) {
  const s = [], n = {}, o = t.length;
  let r, a;
  for (r = 0; r < o; ++r)
    a = t[r], n[a] = r, s.push({
      value: a,
      major: !1
    });
  return o === 0 || !e ? s : Cd(i, s, n, e);
}
class wr extends Mi {
  static id = "time";
  static defaults = {
    bounds: "data",
    adapters: {},
    time: {
      parser: !1,
      unit: !1,
      round: !1,
      isoWeekday: !1,
      minUnit: "millisecond",
      displayFormats: {}
    },
    ticks: {
      source: "auto",
      callback: !1,
      major: {
        enabled: !1
      }
    }
  };
  constructor(t) {
    super(t), this._cache = {
      data: [],
      labels: [],
      all: []
    }, this._unit = "day", this._majorUnit = void 0, this._offsets = {}, this._normalized = !1, this._parseOpts = void 0;
  }
  init(t, e = {}) {
    const s = t.time || (t.time = {}), n = this._adapter = new y0._date(t.adapters.date);
    n.init(e), Ni(s.displayFormats, n.formats()), this._parseOpts = {
      parser: s.parser,
      round: s.round,
      isoWeekday: s.isoWeekday
    }, super.init(t), this._normalized = e.normalized;
  }
  parse(t, e) {
    return t === void 0 ? null : xr(this, t);
  }
  beforeLayout() {
    super.beforeLayout(), this._cache = {
      data: [],
      labels: [],
      all: []
    };
  }
  determineDataLimits() {
    const t = this.options, e = this._adapter, s = t.time.unit || "day";
    let { min: n, max: o, minDefined: r, maxDefined: a } = this.getUserBounds();
    function l(d) {
      !r && !isNaN(d.min) && (n = Math.min(n, d.min)), !a && !isNaN(d.max) && (o = Math.max(o, d.max));
    }
    (!r || !a) && (l(this._getLabelBounds()), (t.bounds !== "ticks" || t.ticks.source !== "labels") && l(this.getMinMax(!1))), n = qt(n) && !isNaN(n) ? n : +e.startOf(Date.now(), s), o = qt(o) && !isNaN(o) ? o : +e.endOf(Date.now(), s) + 1, this.min = Math.min(n, o - 1), this.max = Math.max(n + 1, o);
  }
  _getLabelBounds() {
    const t = this.getLabelTimestamps();
    let e = Number.POSITIVE_INFINITY, s = Number.NEGATIVE_INFINITY;
    return t.length && (e = t[0], s = t[t.length - 1]), {
      min: e,
      max: s
    };
  }
  buildTicks() {
    const t = this.options, e = t.time, s = t.ticks, n = s.source === "labels" ? this.getLabelTimestamps() : this._generate();
    t.bounds === "ticks" && n.length && (this.min = this._userMin || n[0], this.max = this._userMax || n[n.length - 1]);
    const o = this.min, r = this.max, a = Kl(n, o, r);
    return this._unit = e.unit || (s.autoSkip ? br(e.minUnit, this.min, this.max, this._getLabelCapacity(o)) : Md(this, a.length, e.minUnit, this.min, this.max)), this._majorUnit = !s.major.enabled || this._unit === "year" ? void 0 : Sd(this._unit), this.initOffsets(n), t.reverse && a.reverse(), vr(this, a, this._majorUnit);
  }
  afterAutoSkip() {
    this.options.offsetAfterAutoskip && this.initOffsets(this.ticks.map((t) => +t.value));
  }
  initOffsets(t = []) {
    let e = 0, s = 0, n, o;
    this.options.offset && t.length && (n = this.getDecimalForValue(t[0]), t.length === 1 ? e = 1 - n : e = (this.getDecimalForValue(t[1]) - n) / 2, o = this.getDecimalForValue(t[t.length - 1]), t.length === 1 ? s = o : s = (o - this.getDecimalForValue(t[t.length - 2])) / 2);
    const r = t.length < 3 ? 0.5 : 0.25;
    e = le(e, 0, r), s = le(s, 0, r), this._offsets = {
      start: e,
      end: s,
      factor: 1 / (e + 1 + s)
    };
  }
  _generate() {
    const t = this._adapter, e = this.min, s = this.max, n = this.options, o = n.time, r = o.unit || br(o.minUnit, e, s, this._getLabelCapacity(e)), a = Ct(n.ticks.stepSize, 1), l = r === "week" ? o.isoWeekday : !1, d = vi(l) || l === !0, f = {};
    let x = e, b, k;
    if (d && (x = +t.startOf(x, "isoWeek", l)), x = +t.startOf(x, d ? "day" : r), t.diff(s, e, r) > 1e5 * a)
      throw new Error(e + " and " + s + " are too far apart with stepSize of " + a + " " + r);
    const T = n.ticks.source === "data" && this.getDataTimestamps();
    for (b = x, k = 0; b < s; b = +t.add(b, a, r), k++)
      _r(f, b, T);
    return (b === s || n.bounds === "ticks" || k === 1) && _r(f, b, T), Object.keys(f).sort(yr).map((C) => +C);
  }
  getLabelForValue(t) {
    const e = this._adapter, s = this.options.time;
    return s.tooltipFormat ? e.format(t, s.tooltipFormat) : e.format(t, s.displayFormats.datetime);
  }
  format(t, e) {
    const n = this.options.time.displayFormats, o = this._unit, r = e || n[o];
    return this._adapter.format(t, r);
  }
  _tickFormatFunction(t, e, s, n) {
    const o = this.options, r = o.ticks.callback;
    if (r)
      return Rt(r, [
        t,
        e,
        s
      ], this);
    const a = o.time.displayFormats, l = this._unit, d = this._majorUnit, f = l && a[l], x = d && a[d], b = s[e], k = d && x && b && b.major;
    return this._adapter.format(t, n || (k ? x : f));
  }
  generateTickLabels(t) {
    let e, s, n;
    for (e = 0, s = t.length; e < s; ++e)
      n = t[e], n.label = this._tickFormatFunction(n.value, e, t);
  }
  getDecimalForValue(t) {
    return t === null ? NaN : (t - this.min) / (this.max - this.min);
  }
  getPixelForValue(t) {
    const e = this._offsets, s = this.getDecimalForValue(t);
    return this.getPixelForDecimal((e.start + s) * e.factor);
  }
  getValueForPixel(t) {
    const e = this._offsets, s = this.getDecimalForPixel(t) / e.factor - e.end;
    return this.min + s * (this.max - this.min);
  }
  _getLabelSize(t) {
    const e = this.options.ticks, s = this.ctx.measureText(t).width, n = Ke(this.isHorizontal() ? e.maxRotation : e.minRotation), o = Math.cos(n), r = Math.sin(n), a = this._resolveTickFontOptions(0).size;
    return {
      w: s * o + a * r,
      h: s * r + a * o
    };
  }
  _getLabelCapacity(t) {
    const e = this.options.time, s = e.displayFormats, n = s[e.unit] || s.millisecond, o = this._tickFormatFunction(t, 0, vr(this, [
      t
    ], this._majorUnit), n), r = this._getLabelSize(o), a = Math.floor(this.isHorizontal() ? this.width / r.w : this.height / r.h) - 1;
    return a > 0 ? a : 1;
  }
  getDataTimestamps() {
    let t = this._cache.data || [], e, s;
    if (t.length)
      return t;
    const n = this.getMatchingVisibleMetas();
    if (this._normalized && n.length)
      return this._cache.data = n[0].controller.getAllParsedValues(this);
    for (e = 0, s = n.length; e < s; ++e)
      t = t.concat(n[e].controller.getAllParsedValues(this));
    return this._cache.data = this.normalize(t);
  }
  getLabelTimestamps() {
    const t = this._cache.labels || [];
    let e, s;
    if (t.length)
      return t;
    const n = this.getLabels();
    for (e = 0, s = n.length; e < s; ++e)
      t.push(xr(this, n[e]));
    return this._cache.labels = this._normalized ? t : this.normalize(t);
  }
  normalize(t) {
    return Zl(t.sort(yr));
  }
}
function bs(i, t, e) {
  let s = 0, n = i.length - 1, o, r, a, l;
  e ? (t >= i[s].pos && t <= i[n].pos && ({ lo: s, hi: n } = Je(i, "pos", t)), { pos: o, time: a } = i[s], { pos: r, time: l } = i[n]) : (t >= i[s].time && t <= i[n].time && ({ lo: s, hi: n } = Je(i, "time", t)), { time: o, pos: a } = i[s], { time: r, pos: l } = i[n]);
  const d = r - o;
  return d ? a + (l - a) * (t - o) / d : a;
}
class gu extends wr {
  static id = "timeseries";
  static defaults = wr.defaults;
  constructor(t) {
    super(t), this._table = [], this._minPos = void 0, this._tableRange = void 0;
  }
  initOffsets() {
    const t = this._getTimestampsForTable(), e = this._table = this.buildLookupTable(t);
    this._minPos = bs(e, this.min), this._tableRange = bs(e, this.max) - this._minPos, super.initOffsets(t);
  }
  buildLookupTable(t) {
    const { min: e, max: s } = this, n = [], o = [];
    let r, a, l, d, f;
    for (r = 0, a = t.length; r < a; ++r)
      d = t[r], d >= e && d <= s && n.push(d);
    if (n.length < 2)
      return [
        {
          time: e,
          pos: 0
        },
        {
          time: s,
          pos: 1
        }
      ];
    for (r = 0, a = n.length; r < a; ++r)
      f = n[r + 1], l = n[r - 1], d = n[r], Math.round((f + l) / 2) !== d && o.push({
        time: d,
        pos: r / (a - 1)
      });
    return o;
  }
  _generate() {
    const t = this.min, e = this.max;
    let s = super.getDataTimestamps();
    return (!s.includes(t) || !s.length) && s.splice(0, 0, t), (!s.includes(e) || s.length === 1) && s.push(e), s.sort((n, o) => n - o);
  }
  _getTimestampsForTable() {
    let t = this._cache.all || [];
    if (t.length)
      return t;
    const e = this.getDataTimestamps(), s = this.getLabelTimestamps();
    return e.length && s.length ? t = this.normalize(e.concat(s)) : t = e.length ? e : s, t = this._cache.all = t, t;
  }
  getDecimalForValue(t) {
    return (bs(this._table, t) - this._minPos) / this._tableRange;
  }
  getValueForPixel(t) {
    const e = this._offsets, s = this.getDecimalForPixel(t) / e.factor - e.end;
    return bs(this._table, s * this._tableRange + this._minPos, !0);
  }
}
const _a = {
  data: {
    type: Object,
    required: !0
  },
  options: {
    type: Object,
    default: () => ({})
  },
  plugins: {
    type: Array,
    default: () => []
  },
  datasetIdKey: {
    type: String,
    default: "label"
  },
  updateMode: {
    type: String,
    default: void 0
  }
}, Dd = {
  ariaLabel: {
    type: String
  },
  ariaDescribedby: {
    type: String
  }
}, Ad = {
  type: {
    type: String,
    required: !0
  },
  destroyDelay: {
    type: Number,
    default: 0
    // No delay by default
  },
  ..._a,
  ...Dd
}, Pd = Ea[0] === "2" ? (i, t) => Object.assign(i, {
  attrs: t
}) : (i, t) => Object.assign(i, t);
function yi(i) {
  return Sr(i) ? dn(i) : i;
}
function Td(i) {
  let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : i;
  return Sr(t) ? new Proxy(i, {}) : i;
}
function Ld(i, t) {
  const e = i.options;
  e && t && Object.assign(e, t);
}
function va(i, t) {
  i.labels = t;
}
function wa(i, t, e) {
  const s = [];
  i.datasets = t.map((n) => {
    const o = i.datasets.find((r) => r[e] === n[e]);
    return !o || !n.data || s.includes(o) ? {
      ...n
    } : (s.push(o), Object.assign(o, n), o);
  });
}
function Od(i, t) {
  const e = {
    labels: [],
    datasets: []
  };
  return va(e, i.labels), wa(e, i.datasets, t), e;
}
const Ed = De({
  props: Ad,
  setup(i, t) {
    let { expose: e, slots: s } = t;
    const n = Ce(null), o = Mr(null);
    e({
      chart: o
    });
    const r = () => {
      if (!n.value) return;
      const { type: d, data: f, options: x, plugins: b, datasetIdKey: k } = i, T = Od(f, k), C = Td(T, f);
      o.value = new Is(n.value, {
        type: d,
        data: C,
        options: {
          ...x
        },
        plugins: b
      });
    }, a = () => {
      const d = dn(o.value);
      d && (i.destroyDelay > 0 ? setTimeout(() => {
        d.destroy(), o.value = null;
      }, i.destroyDelay) : (d.destroy(), o.value = null));
    }, l = (d) => {
      d.update(i.updateMode);
    };
    return La(r), Zi(a), ee([
      () => i.options,
      () => i.data
    ], (d, f) => {
      let [x, b] = d, [k, T] = f;
      const C = dn(o.value);
      if (!C)
        return;
      let A = !1;
      if (x) {
        const P = yi(x), z = yi(k);
        P && P !== z && (Ld(C, P), A = !0);
      }
      if (b) {
        const P = yi(b.labels), z = yi(T.labels), O = yi(b.datasets), W = yi(T.datasets);
        P !== z && (va(C.config.data, P), A = !0), O && O !== W && (wa(C.config.data, O, i.datasetIdKey), A = !0);
      }
      A && Oa(() => {
        l(C);
      });
    }, {
      deep: !0
    }), () => hn("canvas", {
      role: "img",
      "aria-label": i.ariaLabel,
      "aria-describedby": i.ariaDescribedby,
      ref: n
    }, [
      hn("p", {}, [
        s.default ? s.default() : ""
      ])
    ]);
  }
});
function Bd(i, t) {
  return Is.register(t), De({
    props: _a,
    setup(e, s) {
      let { expose: n } = s;
      const o = Mr(null), r = (a) => {
        o.value = a?.chart;
      };
      return n({
        chart: o
      }), () => hn(Ed, Pd({
        ref: r
      }, {
        type: i,
        ...e
      }));
    }
  });
}
const Id = /* @__PURE__ */ Bd("line", sa);
var ks = { exports: {} }, Rd = ks.exports, kr;
function zd() {
  return kr || (kr = 1, (function(i, t) {
    (function(e, s) {
      i.exports = s();
    })(Rd, (function() {
      var e = 1e3, s = 6e4, n = 36e5, o = "millisecond", r = "second", a = "minute", l = "hour", d = "day", f = "week", x = "month", b = "quarter", k = "year", T = "date", C = "Invalid Date", A = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, P = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, z = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(Q) {
        var G = ["th", "st", "nd", "rd"], K = Q % 100;
        return "[" + Q + (G[(K - 20) % 10] || G[K] || G[0]) + "]";
      } }, O = function(Q, G, K) {
        var ht = String(Q);
        return !ht || ht.length >= G ? Q : "" + Array(G + 1 - ht.length).join(K) + Q;
      }, W = { s: O, z: function(Q) {
        var G = -Q.utcOffset(), K = Math.abs(G), ht = Math.floor(K / 60), et = K % 60;
        return (G <= 0 ? "+" : "-") + O(ht, 2, "0") + ":" + O(et, 2, "0");
      }, m: function Q(G, K) {
        if (G.date() < K.date()) return -Q(K, G);
        var ht = 12 * (K.year() - G.year()) + (K.month() - G.month()), et = G.clone().add(ht, x), ut = K - et < 0, yt = G.clone().add(ht + (ut ? -1 : 1), x);
        return +(-(ht + (K - et) / (ut ? et - yt : yt - et)) || 0);
      }, a: function(Q) {
        return Q < 0 ? Math.ceil(Q) || 0 : Math.floor(Q);
      }, p: function(Q) {
        return { M: x, y: k, w: f, d, D: T, h: l, m: a, s: r, ms: o, Q: b }[Q] || String(Q || "").toLowerCase().replace(/s$/, "");
      }, u: function(Q) {
        return Q === void 0;
      } }, R = "en", Y = {};
      Y[R] = z;
      var B = "$isDayjsObject", H = function(Q) {
        return Q instanceof st || !(!Q || !Q[B]);
      }, it = function Q(G, K, ht) {
        var et;
        if (!G) return R;
        if (typeof G == "string") {
          var ut = G.toLowerCase();
          Y[ut] && (et = ut), K && (Y[ut] = K, et = ut);
          var yt = G.split("-");
          if (!et && yt.length > 1) return Q(yt[0]);
        } else {
          var _ = G.name;
          Y[_] = G, et = _;
        }
        return !ht && et && (R = et), et || !ht && R;
      }, ct = function(Q, G) {
        if (H(Q)) return Q.clone();
        var K = typeof G == "object" ? G : {};
        return K.date = Q, K.args = arguments, new st(K);
      }, X = W;
      X.l = it, X.i = H, X.w = function(Q, G) {
        return ct(Q, { locale: G.$L, utc: G.$u, x: G.$x, $offset: G.$offset });
      };
      var st = (function() {
        function Q(K) {
          this.$L = it(K.locale, null, !0), this.parse(K), this.$x = this.$x || K.x || {}, this[B] = !0;
        }
        var G = Q.prototype;
        return G.parse = function(K) {
          this.$d = (function(ht) {
            var et = ht.date, ut = ht.utc;
            if (et === null) return /* @__PURE__ */ new Date(NaN);
            if (X.u(et)) return /* @__PURE__ */ new Date();
            if (et instanceof Date) return new Date(et);
            if (typeof et == "string" && !/Z$/i.test(et)) {
              var yt = et.match(A);
              if (yt) {
                var _ = yt[2] - 1 || 0, y = (yt[7] || "0").substring(0, 3);
                return ut ? new Date(Date.UTC(yt[1], _, yt[3] || 1, yt[4] || 0, yt[5] || 0, yt[6] || 0, y)) : new Date(yt[1], _, yt[3] || 1, yt[4] || 0, yt[5] || 0, yt[6] || 0, y);
              }
            }
            return new Date(et);
          })(K), this.init();
        }, G.init = function() {
          var K = this.$d;
          this.$y = K.getFullYear(), this.$M = K.getMonth(), this.$D = K.getDate(), this.$W = K.getDay(), this.$H = K.getHours(), this.$m = K.getMinutes(), this.$s = K.getSeconds(), this.$ms = K.getMilliseconds();
        }, G.$utils = function() {
          return X;
        }, G.isValid = function() {
          return this.$d.toString() !== C;
        }, G.isSame = function(K, ht) {
          var et = ct(K);
          return this.startOf(ht) <= et && et <= this.endOf(ht);
        }, G.isAfter = function(K, ht) {
          return ct(K) < this.startOf(ht);
        }, G.isBefore = function(K, ht) {
          return this.endOf(ht) < ct(K);
        }, G.$g = function(K, ht, et) {
          return X.u(K) ? this[ht] : this.set(et, K);
        }, G.unix = function() {
          return Math.floor(this.valueOf() / 1e3);
        }, G.valueOf = function() {
          return this.$d.getTime();
        }, G.startOf = function(K, ht) {
          var et = this, ut = !!X.u(ht) || ht, yt = X.p(K), _ = function(F, J) {
            var dt = X.w(et.$u ? Date.UTC(et.$y, J, F) : new Date(et.$y, J, F), et);
            return ut ? dt : dt.endOf(d);
          }, y = function(F, J) {
            return X.w(et.toDate()[F].apply(et.toDate("s"), (ut ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(J)), et);
          }, g = this.$W, w = this.$M, D = this.$D, E = "set" + (this.$u ? "UTC" : "");
          switch (yt) {
            case k:
              return ut ? _(1, 0) : _(31, 11);
            case x:
              return ut ? _(1, w) : _(0, w + 1);
            case f:
              var I = this.$locale().weekStart || 0, Z = (g < I ? g + 7 : g) - I;
              return _(ut ? D - Z : D + (6 - Z), w);
            case d:
            case T:
              return y(E + "Hours", 0);
            case l:
              return y(E + "Minutes", 1);
            case a:
              return y(E + "Seconds", 2);
            case r:
              return y(E + "Milliseconds", 3);
            default:
              return this.clone();
          }
        }, G.endOf = function(K) {
          return this.startOf(K, !1);
        }, G.$set = function(K, ht) {
          var et, ut = X.p(K), yt = "set" + (this.$u ? "UTC" : ""), _ = (et = {}, et[d] = yt + "Date", et[T] = yt + "Date", et[x] = yt + "Month", et[k] = yt + "FullYear", et[l] = yt + "Hours", et[a] = yt + "Minutes", et[r] = yt + "Seconds", et[o] = yt + "Milliseconds", et)[ut], y = ut === d ? this.$D + (ht - this.$W) : ht;
          if (ut === x || ut === k) {
            var g = this.clone().set(T, 1);
            g.$d[_](y), g.init(), this.$d = g.set(T, Math.min(this.$D, g.daysInMonth())).$d;
          } else _ && this.$d[_](y);
          return this.init(), this;
        }, G.set = function(K, ht) {
          return this.clone().$set(K, ht);
        }, G.get = function(K) {
          return this[X.p(K)]();
        }, G.add = function(K, ht) {
          var et, ut = this;
          K = Number(K);
          var yt = X.p(ht), _ = function(w) {
            var D = ct(ut);
            return X.w(D.date(D.date() + Math.round(w * K)), ut);
          };
          if (yt === x) return this.set(x, this.$M + K);
          if (yt === k) return this.set(k, this.$y + K);
          if (yt === d) return _(1);
          if (yt === f) return _(7);
          var y = (et = {}, et[a] = s, et[l] = n, et[r] = e, et)[yt] || 1, g = this.$d.getTime() + K * y;
          return X.w(g, this);
        }, G.subtract = function(K, ht) {
          return this.add(-1 * K, ht);
        }, G.format = function(K) {
          var ht = this, et = this.$locale();
          if (!this.isValid()) return et.invalidDate || C;
          var ut = K || "YYYY-MM-DDTHH:mm:ssZ", yt = X.z(this), _ = this.$H, y = this.$m, g = this.$M, w = et.weekdays, D = et.months, E = et.meridiem, I = function(J, dt, gt, _t) {
            return J && (J[dt] || J(ht, ut)) || gt[dt].slice(0, _t);
          }, Z = function(J) {
            return X.s(_ % 12 || 12, J, "0");
          }, F = E || function(J, dt, gt) {
            var _t = J < 12 ? "AM" : "PM";
            return gt ? _t.toLowerCase() : _t;
          };
          return ut.replace(P, (function(J, dt) {
            return dt || (function(gt) {
              switch (gt) {
                case "YY":
                  return String(ht.$y).slice(-2);
                case "YYYY":
                  return X.s(ht.$y, 4, "0");
                case "M":
                  return g + 1;
                case "MM":
                  return X.s(g + 1, 2, "0");
                case "MMM":
                  return I(et.monthsShort, g, D, 3);
                case "MMMM":
                  return I(D, g);
                case "D":
                  return ht.$D;
                case "DD":
                  return X.s(ht.$D, 2, "0");
                case "d":
                  return String(ht.$W);
                case "dd":
                  return I(et.weekdaysMin, ht.$W, w, 2);
                case "ddd":
                  return I(et.weekdaysShort, ht.$W, w, 3);
                case "dddd":
                  return w[ht.$W];
                case "H":
                  return String(_);
                case "HH":
                  return X.s(_, 2, "0");
                case "h":
                  return Z(1);
                case "hh":
                  return Z(2);
                case "a":
                  return F(_, y, !0);
                case "A":
                  return F(_, y, !1);
                case "m":
                  return String(y);
                case "mm":
                  return X.s(y, 2, "0");
                case "s":
                  return String(ht.$s);
                case "ss":
                  return X.s(ht.$s, 2, "0");
                case "SSS":
                  return X.s(ht.$ms, 3, "0");
                case "Z":
                  return yt;
              }
              return null;
            })(J) || yt.replace(":", "");
          }));
        }, G.utcOffset = function() {
          return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
        }, G.diff = function(K, ht, et) {
          var ut, yt = this, _ = X.p(ht), y = ct(K), g = (y.utcOffset() - this.utcOffset()) * s, w = this - y, D = function() {
            return X.m(yt, y);
          };
          switch (_) {
            case k:
              ut = D() / 12;
              break;
            case x:
              ut = D();
              break;
            case b:
              ut = D() / 3;
              break;
            case f:
              ut = (w - g) / 6048e5;
              break;
            case d:
              ut = (w - g) / 864e5;
              break;
            case l:
              ut = w / n;
              break;
            case a:
              ut = w / s;
              break;
            case r:
              ut = w / e;
              break;
            default:
              ut = w;
          }
          return et ? ut : X.a(ut);
        }, G.daysInMonth = function() {
          return this.endOf(x).$D;
        }, G.$locale = function() {
          return Y[this.$L];
        }, G.locale = function(K, ht) {
          if (!K) return this.$L;
          var et = this.clone(), ut = it(K, ht, !0);
          return ut && (et.$L = ut), et;
        }, G.clone = function() {
          return X.w(this.$d, this);
        }, G.toDate = function() {
          return new Date(this.valueOf());
        }, G.toJSON = function() {
          return this.isValid() ? this.toISOString() : null;
        }, G.toISOString = function() {
          return this.$d.toISOString();
        }, G.toString = function() {
          return this.$d.toUTCString();
        }, Q;
      })(), ft = st.prototype;
      return ct.prototype = ft, [["$ms", o], ["$s", r], ["$m", a], ["$H", l], ["$W", d], ["$M", x], ["$y", k], ["$D", T]].forEach((function(Q) {
        ft[Q[1]] = function(G) {
          return this.$g(G, Q[0], Q[1]);
        };
      })), ct.extend = function(Q, G) {
        return Q.$i || (Q(G, st, ct), Q.$i = !0), ct;
      }, ct.locale = it, ct.isDayjs = H, ct.unix = function(Q) {
        return ct(1e3 * Q);
      }, ct.en = Y[R], ct.Ls = Y, ct.p = {}, ct;
    }));
  })(ks)), ks.exports;
}
var Fd = zd();
const _s = /* @__PURE__ */ Dr(Fd), Hd = {
  key: 0,
  id: "city_pair"
}, jd = { class: "airport" }, Nd = { class: "icao" }, Wd = { class: "city" }, Vd = { class: "airport" }, Yd = { class: "icao" }, Ud = { class: "city" }, Xd = {
  key: 1,
  class: "loading"
}, Gd = {
  key: 2,
  class: "error"
}, qd = /* @__PURE__ */ De({
  __name: "CityPairWidget",
  setup(i) {
    const t = ti("tangramApi");
    if (!t)
      throw new Error("assert: tangram api not provided");
    const e = $i({
      loading: !1,
      error: null
    }), s = () => {
      mt.route.origin = null, mt.route.destination = null, e.error = null, e.loading = !1;
    }, n = async (o) => {
      if (!o) {
        s();
        return;
      }
      e.loading = !0, e.error = null;
      try {
        const r = await fetch(`/jet1090/route/${o.trim()}`);
        if (!r.ok)
          throw new Error(`API request failed with status ${r.status}`);
        const a = await r.json();
        if (!a || a.length === 0) {
          e.error = "No route information available";
          return;
        }
        const l = a[0];
        if (l.plausible === 0 || l.airport_codes === "unknown") {
          e.error = "No route found for this flight";
          return;
        }
        const [d, f] = l.airport_codes.split("-"), x = no(d), b = no(f);
        if (x.length > 0) {
          const k = x[0];
          mt.route.origin = {
            lat: k.lat,
            lon: k.lon,
            name: k.name,
            city: k.city,
            icao: k.icao
          };
        } else
          mt.route.origin = {
            lat: null,
            lon: null,
            name: d,
            city: d,
            icao: d
          };
        if (b.length > 0) {
          const k = b[0];
          mt.route.destination = {
            lat: k.lat,
            lon: k.lon,
            name: k.name,
            city: k.city,
            icao: k.icao
          };
        } else
          mt.route.destination = {
            lat: null,
            lon: null,
            name: f,
            city: f,
            icao: f
          };
      } catch (r) {
        e.error = `Error: ${r.message}`;
      } finally {
        e.loading = !1;
      }
    };
    return ee(
      () => t.state.activeEntity?.value?.id,
      (o) => {
        if (s(), o) {
          const r = t.state.activeEntity.value;
          if (r?.type === "jet1090_aircraft") {
            const a = r?.state?.callsign;
            a && n(a);
          }
        }
      },
      { immediate: !0 }
    ), (o, r) => _e(mt).route.origin && _e(mt).route.destination ? (ne(), ae("div", Hd, [
      Bt("div", jd, [
        Bt("span", Nd, Nt(_e(mt).route.origin.icao), 1),
        Bt("span", Wd, Nt(_e(mt).route.origin.city), 1)
      ]),
      Bt("div", Vd, [
        Bt("span", Yd, Nt(_e(mt).route.destination.icao), 1),
        Bt("span", Ud, Nt(_e(mt).route.destination.city), 1)
      ])
    ])) : e.loading ? (ne(), ae("div", Xd, "Loading route information...")) : e.error ? (ne(), ae("div", Gd, Nt(e.error), 1)) : be("", !0);
  }
}), Kd = /* @__PURE__ */ wn(qd, [["__scopeId", "data-v-de54609a"]]), Jd = { key: 0 }, Zd = {
  key: 0,
  id: "metadata"
}, Qd = {
  key: 0,
  id: "typecode"
}, tu = { id: "icao24" }, eu = {
  key: 1,
  id: "registration"
}, iu = { class: "chart-container" }, su = /* @__PURE__ */ De({
  __name: "AircraftInfoWidget",
  setup(i) {
    const t = {
      id: "corsair",
      defaults: { width: 1, color: "#FF4949", dash: [3, 3] },
      afterInit: (A) => {
        A.corsair = { x: 0, y: 0 };
      },
      afterEvent: (A, P) => {
        const { inChartArea: z } = P, { x: O, y: W } = P.event;
        A.corsair = { x: O, y: W, draw: z }, A.draw();
      },
      beforeDatasetsDraw: (A, P, z) => {
        const { ctx: O } = A, { top: W, bottom: R, left: Y, right: B } = A.chartArea;
        if (!A.corsair || !A.corsair.draw) return;
        const { x: H, y: it } = A.corsair;
        O.save(), O.beginPath(), O.lineWidth = z.width, O.strokeStyle = z.color, O.setLineDash(z.dash), O.moveTo(H, R), O.lineTo(H, W), O.moveTo(Y, it), O.lineTo(B, it), O.stroke(), O.restore();
      }
    };
    Is.register(
      vd,
      $d,
      Bh,
      Rs,
      sa,
      m0,
      cd,
      yd,
      ad,
      ed,
      t
    );
    const e = {
      tooltip: { backgroundColor: "#bab0ac", mode: "nearest", intersect: !1 },
      filler: { propagate: !0 },
      corsair: { color: "black" },
      legend: {
        display: !0,
        position: "top",
        labels: {
          font: { family: "B612", size: 10 },
          usePointStyle: !0,
          pointStyle: "line"
        }
      }
    }, s = {
      ticks: {
        font: { family: "B612", size: 9 },
        autoSkip: !0,
        maxTicksLimit: 7,
        maxRotation: 0,
        minRotation: 0,
        padding: 5
      },
      border: { width: 0 },
      grid: { display: !0, drawBorder: !1 }
    }, n = ti("tangramApi");
    if (!n) throw new Error("assert: tangram api not provided");
    const o = n.state.activeEntity, r = Fe(() => o.value?.state), a = Fe(() => r.value && Ya(r.value.icao24, r.value.registration)?.flag || ""), l = $i({
      selectedItem: "altitude",
      chartData: {},
      chartOptions: {}
    }), d = (A) => {
      l.selectedItem = A.target.value, f();
    }, f = () => {
      switch (l.selectedItem) {
        case "altitude":
          b();
          break;
        case "speed":
          k();
          break;
        case "vertical_rate":
          T();
          break;
        case "track":
          C();
          break;
        default:
          b();
      }
    }, x = () => mt.trajectory, b = () => {
      const A = x().filter((P) => P.altitude || P.selected_altitude);
      l.chartData = {
        labels: A.map((P) => _s.unix(P.timestamp).format("HH:mm")),
        datasets: [
          {
            label: "Barometric altitude",
            data: A.map((P) => P.altitude),
            borderColor: "#4c78a8",
            backgroundColor: "#9ecae9",
            borderWidth: 2,
            radius: 0,
            spanGaps: !0,
            fill: { target: "origin" }
          },
          {
            label: "Selected altitude",
            data: A.map((P) => P.selected_altitude),
            borderColor: "#f58518",
            borderWidth: 3,
            spanGaps: !0,
            pointRadius: 0.2
          }
        ]
      }, l.chartOptions = {
        plugins: e,
        scales: {
          y: {
            border: { width: 0 },
            min: 0,
            ticks: { font: { family: "B612", size: 9 } },
            grid: { display: !1, drawBorder: !1 }
          },
          x: s
        },
        responsive: !0,
        maintainAspectRatio: !1
      };
    }, k = () => {
      const A = x().filter(
        (P) => P.groundspeed || P.ias || P.tas || P.mach
      );
      l.chartData = {
        labels: A.map((P) => _s.unix(P.timestamp).format("HH:mm")),
        datasets: [
          {
            label: "Ground speed",
            data: A.map((P) => P.groundspeed),
            borderColor: "#4c78a8",
            borderWidth: 2,
            pointRadius: 0.01,
            spanGaps: !0,
            tension: 0.4,
            yAxisID: "kts"
          },
          {
            label: "IAS",
            data: A.map((P) => P.ias),
            borderColor: "#f58518",
            spanGaps: !0,
            borderWidth: 2,
            pointRadius: 0.2,
            tension: 0.4,
            yAxisID: "kts"
          },
          {
            label: "TAS",
            data: A.map((P) => P.tas),
            borderColor: "#54a24b",
            spanGaps: !0,
            borderWidth: 2,
            pointRadius: 0.2,
            tension: 0.4,
            yAxisID: "kts"
          },
          {
            label: "Mach",
            data: A.map((P) => P.mach),
            borderColor: "#b79a20",
            spanGaps: !0,
            borderWidth: 2,
            pointRadius: 0.2,
            tension: 0.4,
            yAxisID: "mach"
          }
        ]
      }, l.chartOptions = {
        plugins: e,
        interaction: { mode: "index", intersect: !1 },
        scales: {
          x: s,
          kts: {
            type: "linear",
            display: !0,
            position: "left",
            min: 0,
            ticks: { font: { family: "B612", size: 9 } },
            grid: { display: !1, drawBorder: !1 }
          },
          mach: {
            type: "linear",
            display: !0,
            position: "right",
            min: 0,
            max: 1,
            ticks: { font: { family: "B612", size: 9 } },
            grid: { drawOnChartArea: !1 }
          }
        },
        responsive: !0,
        maintainAspectRatio: !1
      };
    }, T = () => {
      const A = x().filter(
        (P) => P.vrate_barometric || P.vrate_inertial || P.vertical_rate
      );
      l.chartData = {
        labels: A.map((P) => _s.unix(P.timestamp).format("HH:mm")),
        datasets: [
          {
            label: "Vertical rate",
            data: A.map((P) => P.vertical_rate),
            borderColor: "#4c78a8",
            borderWidth: 1,
            pointRadius: 0.2,
            spanGaps: !0,
            tension: 0.4
          },
          {
            label: "Barometric",
            type: "scatter",
            data: A.map((P) => P.vrate_barometric),
            borderWidth: 0.5,
            pointRadius: 2,
            borderColor: "#f58518",
            backgroundColor: "#f58518"
          },
          {
            label: "Inertial",
            type: "scatter",
            data: A.map((P) => P.vrate_inertial),
            borderWidth: 0.5,
            pointRadius: 2,
            borderColor: "#54a24b",
            backgroundColor: "#54a24b"
          }
        ]
      }, l.chartOptions = {
        plugins: { ...e, legend: { display: !1 } },
        scales: {
          x: s,
          y: {
            border: { width: 0 },
            ticks: { font: { family: "B612", size: 9 } },
            grid: { display: !1, drawBorder: !1 }
          }
        },
        responsive: !0,
        maintainAspectRatio: !1
      };
    }, C = () => {
      const A = x().filter((P) => P.track || P.heading || P.roll);
      l.chartData = {
        labels: A.map((P) => _s.unix(P.timestamp).format("HH:mm")),
        datasets: [
          {
            label: "Track",
            data: A.map((P) => P.track),
            borderWidth: 2,
            borderColor: "#4c78a8",
            pointRadius: 0.2,
            spanGaps: !0,
            yAxisID: "bearing"
          },
          {
            label: "Magnetic heading",
            data: A.map((P) => P.heading),
            borderWidth: 2,
            borderColor: "#f58518",
            pointRadius: 0.2,
            spanGaps: !0,
            yAxisID: "bearing"
          },
          {
            label: "Roll angle",
            data: A.map((P) => P.roll),
            type: "scatter",
            borderWidth: 0.5,
            borderColor: "#54a24b",
            backgroundColor: "#54a24b",
            pointRadius: 1.5,
            yAxisID: "roll"
          }
        ]
      }, l.chartOptions = {
        plugins: e,
        interaction: { mode: "index", intersect: !1 },
        scales: {
          x: s,
          bearing: {
            type: "linear",
            display: !0,
            position: "left",
            min: 0,
            max: 360,
            ticks: { font: { family: "B612", size: 9 } },
            grid: { display: !1, drawBorder: !1 }
          },
          roll: {
            type: "linear",
            display: !0,
            position: "right",
            ticks: { font: { family: "B612", size: 9 } },
            grid: { drawOnChartArea: !1 }
          }
        },
        responsive: !0,
        maintainAspectRatio: !1
      };
    };
    return ee(() => mt.trajectory.length, f), ee(() => o.value?.id, f), (A, P) => _e(o) && _e(o).type === "jet1090_aircraft" ? (ne(), ae("div", Jd, [
      r.value ? (ne(), ae("div", Zd, [
        r.value.typecode ? (ne(), ae("span", Qd, Nt(r.value.typecode), 1)) : be("", !0),
        Bt("span", null, Nt(r.value.callsign), 1),
        Bt("span", tu, Nt(r.value.icao24), 1),
        P[2] || (P[2] = Bt("br", null, null, -1)),
        r.value.registration ? (ne(), ae("span", eu, " Registration: " + Nt(a.value) + " " + Nt(r.value.registration), 1)) : be("", !0),
        P[3] || (P[3] = Bt("br", null, null, -1))
      ])) : be("", !0),
      Ba(Kd),
      P[5] || (P[5] = Bt("h5", null, "Flight data", -1)),
      _e(mt).trajectory.length > 0 ? (ne(), ae("div", {
        key: 1,
        onClick: P[1] || (P[1] = Ia(() => {
        }, ["stop"]))
      }, [
        Ra(Bt("select", {
          id: "plot-select",
          "onUpdate:modelValue": P[0] || (P[0] = (z) => l.selectedItem = z),
          onChange: d
        }, [...P[4] || (P[4] = [
          Bt("option", { value: "altitude" }, "Altitude (in ft)", -1),
          Bt("option", { value: "speed" }, "Speed (in kts)", -1),
          Bt("option", { value: "vertical_rate" }, "Vertical rate (in ft/mn)", -1),
          Bt("option", { value: "track" }, "Directions", -1)
        ])], 544), [
          [za, l.selectedItem]
        ]),
        Bt("div", iu, [
          l.chartData.datasets ? (ne(), Fa(_e(Id), {
            key: 0,
            ref: "chart",
            class: "chart",
            data: l.chartData,
            options: l.chartOptions
          }, null, 8, ["data", "options"])) : be("", !0)
        ])
      ])) : be("", !0)
    ])) : be("", !0);
  }
}), nu = /* @__PURE__ */ wn(su, [["__scopeId", "data-v-8983b3a8"]]), ou = /* @__PURE__ */ De({
  __name: "AircraftTrailLayer",
  setup(i) {
    const t = ti("tangramApi");
    if (!t) throw new Error("assert: tangram api not provided");
    const e = Fe(() => t.state.activeEntity.value), s = Ce(null), n = () => {
      if (s.value && (s.value.dispose(), s.value = null), e.value?.type === "jet1090_aircraft" && mt.icao24 === e.value.id && mt.trajectory.length > 1) {
        const o = mt.trajectory.filter((a) => a.latitude != null && a.longitude != null).map((a) => [a.longitude, a.latitude]), r = new Cr({
          id: `trail-layer-${e.value.id}`,
          data: [{ path: o }],
          pickable: !1,
          widthScale: 1,
          widthMinPixels: 2,
          getPath: (a) => a.path,
          getColor: [128, 0, 128, 255],
          getWidth: 2
        });
        s.value = t.map.addLayer(r);
      }
    };
    return ee(() => mt.trajectory.length, n), ee(() => e.value?.id, n), Zi(() => {
      s.value?.dispose();
    }), () => {
    };
  }
}), ru = /* @__PURE__ */ De({
  __name: "RouteLayer",
  setup(i) {
    const t = ti("tangramApi");
    if (!t) throw new Error("assert: tangram api not provided");
    const e = Fe(() => t.state.activeEntity.value), s = Ce(null), n = Ce(null), o = Ce(null), r = Ce(null);
    ee(
      () => mt.icao24,
      () => {
        n.value = null, o.value = null, r.value = null;
      }
    ), ee(
      () => [
        mt.route.destination?.lat,
        mt.route.destination?.lon
      ],
      () => {
        o.value = null, r.value = null;
      }
    );
    const a = (x) => x * Math.PI / 180, l = (x) => x * 180 / Math.PI;
    function d(x, b, k = 40) {
      const T = a(x[1]), C = a(x[0]), A = a(b[1]), P = a(b[0]), z = 2 * Math.asin(
        Math.sqrt(
          Math.pow(Math.sin((T - A) / 2), 2) + Math.cos(T) * Math.cos(A) * Math.pow(Math.sin((C - P) / 2), 2)
        )
      );
      if (z < 1e-6) return [x, b];
      const O = [], W = Math.sin(z);
      for (let R = 0; R <= k; R++) {
        const Y = R / k, B = Math.sin((1 - Y) * z) / W, H = Math.sin(Y * z) / W, it = B * Math.cos(T) * Math.cos(C) + H * Math.cos(A) * Math.cos(P), ct = B * Math.cos(T) * Math.sin(C) + H * Math.cos(A) * Math.sin(P), X = B * Math.sin(T) + H * Math.sin(A), st = Math.atan2(X, Math.sqrt(it * it + ct * ct)), ft = Math.atan2(ct, it);
        O.push([l(ft), l(st)]);
      }
      return O;
    }
    return ee(
      () => [
        e.value?.state?.latitude,
        e.value?.state?.longitude,
        un.showRouteLines,
        mt.route.origin,
        mt.route.destination,
        mt.trajectory.length > 0 ? mt.trajectory[0].timestamp : 0
      ],
      () => {
        if (s.value && (s.value.dispose(), s.value = null), !un.showRouteLines) return;
        const x = e.value;
        if (x?.type === "jet1090_aircraft" && mt.icao24 === x.id) {
          const b = x.state;
          if (b.longitude == null || b.latitude == null) return;
          const k = [b.longitude, b.latitude], C = mt.trajectory.find((P) => P.latitude != null && P.longitude != null), A = [];
          if (mt.route.origin?.lat != null && mt.route.origin?.lon != null && C) {
            const P = `${mt.route.origin.lon},${mt.route.origin.lat}-${C.longitude},${C.latitude}`;
            n.value?.key !== P && (n.value = {
              key: P,
              path: d(
                [mt.route.origin.lon, mt.route.origin.lat],
                [C.longitude, C.latitude]
              )
            }), A.push({
              path: n.value.path,
              color: [128, 128, 128, 128]
            });
          }
          if (mt.route.destination?.lat != null && mt.route.destination?.lon != null) {
            r.value || (r.value = k);
            const P = `${r.value[0]},${r.value[1]}-${mt.route.destination.lon},${mt.route.destination.lat}`;
            o.value?.key !== P && (o.value = {
              key: P,
              path: d(r.value, [
                mt.route.destination.lon,
                mt.route.destination.lat
              ])
            }), A.push({
              path: o.value.path,
              color: [128, 128, 128, 128]
            }), A.push({
              path: [k, r.value],
              color: [128, 128, 128, 128]
            });
          }
          if (A.length > 0) {
            const P = new Cr({
              id: `route-layer-${x.id}`,
              data: A,
              pickable: !1,
              widthScale: 1,
              widthMinPixels: 2,
              getPath: (O) => O.path,
              getColor: (O) => O.color,
              getWidth: 2,
              extensions: [new Xa({ dash: !0 })],
              getDashArray: [10, 10],
              dashJustified: !0
            }), z = t.map.setLayer(P);
            s.value || (s.value = z);
          }
        }
      }
    ), Zi(() => {
      s.value?.dispose();
    }), () => {
    };
  }
}), au = /* @__PURE__ */ De({
  __name: "SensorsLayer",
  setup(i) {
    const t = ti("tangramApi");
    if (!t)
      throw new Error("assert: tangram api not provided");
    const e = Ce(null), s = $i({ x: 0, y: 0, object: null });
    return ee(
      () => t.map.isReady.value,
      (n) => {
        n && fetch("/jet1090/sensors").then((o) => {
          if (!o.ok) throw new Error("network response was not ok");
          return o.json();
        }).then((o) => {
          const r = Object.values(o).map((l) => ({
            position: [l?.reference?.longitude, l?.reference?.latitude],
            name: l.name,
            aircraft_count: l.aircraft_count
          })), a = new Ha({
            id: "sensors-layer",
            data: r.filter((l) => l.aircraft_count > 0),
            pickable: !0,
            stroked: !0,
            filled: !0,
            radiusMinPixels: 5,
            radiusMaxPixels: 20,
            lineWidthMinPixels: 1,
            getPosition: (l) => l.position,
            getFillColor: [51, 136, 255, 255],
            getLineColor: [255, 255, 255, 255],
            onHover: (l) => {
              l.object ? (s.object = l.object, s.x = l.x, s.y = l.y) : s.object = null;
            }
          });
          e.value && e.value.dispose(), e.value = t.map.addLayer(a);
        }).catch((o) => {
          console.error("failed to fetch or display sensor data:", o);
        });
      },
      { immediate: !0 }
    ), Zi(() => {
      e.value?.dispose();
    }), (n, o) => s.object ? (ne(), ae("div", {
      key: 0,
      class: "deck-tooltip",
      style: $r({ left: `${s.x}px`, top: `${s.y}px` })
    }, [
      Bt("b", null, Nt(s.object.name), 1),
      o[0] || (o[0] = Bt("br", null, null, -1)),
      cn(" " + Nt(s.object.aircraft_count) + " aircraft ", 1)
    ], 4)) : be("", !0);
  }
});
function mu(i) {
  (async () => (await Va("/rs1090_wasm_bg.wasm"), Ua()))(), i.ui.registerWidget("jet1090-count-widget", "TopBar", cl), i.ui.registerWidget("jet1090-aircraft-layer", "MapOverlay", sl), i.ui.registerWidget("jet1090-info-widget", "SideBar", nu), i.ui.registerWidget("jet1090-trail-layer", "MapOverlay", ou), i.ui.registerWidget("jet1090-route-layer", "MapOverlay", ru), i.ui.registerWidget("jet1090-sensors-layer", "MapOverlay", au), i.state.registerEntityType("jet1090_aircraft"), fetch("/jet1090/config").then((e) => e.json()).then((e) => {
    un.showRouteLines = e.show_route_lines;
  }).catch((e) => console.error("failed to fetch jet1090 config", e)), (async () => {
    try {
      const e = await i.realtime.ensureConnected();
      await lu(i, e);
    } catch (e) {
      console.error("failed initializing jet1090 realtime subscription", e);
    }
  })(), ee(
    () => i.state.activeEntity.value,
    async (e) => {
      if (e?.type === "jet1090_aircraft") {
        if (e.id !== mt.icao24) {
          mt.icao24 = e.id, mt.trajectory = [], mt.loading = !0, mt.error = null, mt.route.origin = null, mt.route.destination = null;
          try {
            const s = await fetch(`/jet1090/data/${e.id}`);
            if (!s.ok) throw new Error("Failed to fetch trajectory");
            const n = await s.json();
            mt.icao24 === e.id && (mt.trajectory = [...n, ...mt.trajectory]);
          } catch (s) {
            mt.icao24 === e.id && (mt.error = s.message);
          } finally {
            mt.icao24 === e.id && (mt.loading = !1);
          }
        }
      } else
        mt.icao24 = null, mt.trajectory = [], mt.route.origin = null, mt.route.destination = null;
    }
  );
  const t = () => {
    const e = i.realtime.getConnectionId();
    if (!e) return;
    const s = i.map.bounds.value;
    if (!s) return;
    const n = {
      connectionId: e,
      northEastLat: s.getNorthEast().lat,
      northEastLng: s.getNorthEast().lng,
      southWestLat: s.getSouthWest().lat,
      southWestLng: s.getSouthWest().lng,
      selectedEntityId: mt.icao24
    };
    i.realtime.publish("system:bound-box", n);
  };
  ee(i.map.bounds, t, { deep: !0 }), ee(() => mt.icao24, t);
}
async function lu(i, t) {
  const e = `streaming-${t}:new-jet1090-data`;
  try {
    await i.realtime.subscribe(
      e,
      (s) => {
        const n = s.aircraft.map((o) => ({
          id: o.icao24,
          type: "jet1090_aircraft",
          state: o
        }));
        if (i.state.replaceAllEntitiesByType("jet1090_aircraft", n), i.state.setTotalCount("jet1090_aircraft", s.count), mt.icao24) {
          const r = i.state.getEntitiesByType("jet1090_aircraft").value.get(mt.icao24);
          if (r && r.state && r.state.latitude && r.state.longitude) {
            const a = r.state, l = mt.trajectory[mt.trajectory.length - 1], d = a.lastseen / 1e6;
            (!l || Math.abs(l.timestamp - d) > 0.5) && mt.trajectory.push({
              ...a,
              timestamp: d
            });
          }
        }
      }
    ), await i.realtime.publish("system:join-streaming", { connectionId: t });
  } catch (s) {
    console.error(`failed to subscribe to ${e}`, s);
  }
}
export {
  mu as install
};
//# sourceMappingURL=index.js.map
