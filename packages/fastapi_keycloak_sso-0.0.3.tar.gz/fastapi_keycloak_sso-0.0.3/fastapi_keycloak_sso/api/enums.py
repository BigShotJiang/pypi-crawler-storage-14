from enum import Enum

class DetailType(str, Enum):
    id = 'id'
    detail = 'detail'