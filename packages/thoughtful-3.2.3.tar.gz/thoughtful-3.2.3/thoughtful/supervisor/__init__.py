# isort: skip_file due to the importance of the python parsing order of these
# modules

from thoughtful.supervisor.default_instances import *
