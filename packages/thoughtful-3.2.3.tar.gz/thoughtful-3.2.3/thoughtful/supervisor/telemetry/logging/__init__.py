"""OpenTelemetry logging utilities for the supervisor package."""

# Logging setup is handled by the main telemetry config module
