"""
Package collection for Thoughtful, built and maintained by Thoughtful.
"""

import warnings

from thoughtful.__version__ import __version__

__title__ = "thoughtful"

warnings.simplefilter("always", DeprecationWarning)
