"""Tests for Legacy libtmux API (to be deprecated)."""
