(windows)=

# Windows

- Exist inside {ref}`Sessions`
- Contain {ref}`Panes`
- Identified by `@`, e.g. `@313`

```{module} libtmux

```

```{eval-rst}
.. autoclass:: Window
    :members:
    :inherited-members:
    :private-members:
    :show-inheritance:
    :member-order: bysource
```
