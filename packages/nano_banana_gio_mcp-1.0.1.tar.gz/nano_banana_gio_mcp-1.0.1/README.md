# Nano Banana MCP

MCP server pour générer des images avec Gemini directement dans Claude Desktop.

## ✨ Features

- 🎨 Génération d'images avec Nano Banana flash (rapide, 1K) ou Pro (avancé, jusqu'à 4K)
- 🖼️ Support des images de référence (jusqu'à 14 images avec Pro)
- 📐 Ratios personnalisés : 1:1, 16:9, 9:16, 4:3, 21:9, etc.
- 🔍 Grounding avec Google Search pour des informations en temps réel
- ☁️ Upload automatique vers ImgBB pour utiliser vos propres images uploadées dans Claude

## 🚀 Installation

### 1. Configurer Claude Desktop

Ouvre ton fichier de configuration :
```bash
~/Library/Application Support/Claude/claude_desktop_config.json
```

Ajoute cette section dans `"mcpServers"` :
```json
{
  "mcpServers": {
    "nano-banana": {
      "command": "uvx",
      "args": ["nano-banana-gio-mcp"],
      "env": {
        "GEMINI_API_KEY": "TA_CLE_GEMINI_ICI"
      }
    }
  }
}
```

### 2. Obtenir une clé API Gemini

1. Va sur https://aistudio.google.com/apikey
2. Crée une clé API gratuite
3. Remplace `TA_CLE_GEMINI_ICI` par ta clé dans la config

### 3. Redémarre Claude Desktop

C'est tout ! `uvx` va automatiquement télécharger et installer le MCP au premier lancement.

## 📖 Utilisation

Dans Claude, tu peux maintenant :

### Génération simple
```
Génère-moi une image d'un chat astronaute en style cyberpunk
```

### Avec ratio personnalisé
```
Crée une image 16:9 d'un paysage de montagne au coucher de soleil
```

### Avec images de référence
```
[URL ou chemin depuis votre disque dur de l'image source]
Génère une nouvelle image dans le même style que ces références
```

### Avec recherche en temps réel
```
Crée une image réaliste de la dernière fusée SpaceX avec les informations actuelles
```

## 🔄 Mise à jour

Redémarre simplement Claude Desktop, `uvx` vérifiera automatiquement les mises à jour.

## ⚙️ Configuration avancée

### Modèles disponibles
- `flash` : Rapide, 1K max, jusqu'à 3 images de référence
- `pro` : Avancé, jusqu'à 4K, jusqu'à 14 images de référence

### Ratios disponibles
`1:1`, `2:3`, `3:2`, `3:4`, `4:3`, `4:5`, `5:4`, `9:16`, `16:9`, `21:9`

### Résolutions (Pro uniquement)
`1K`, `2K`, `4K`

## 📝 Notes

- Les images générées sont sauvegardées dans `~/Downloads/nano-banana-outputs/`
- Le modèle Pro utilise plus de crédits API mais offre une meilleure qualité
- Il est pour l'instant impossible d'upload une image de référence façon "classique" dans Claude. Pour que le MCP puisse utiliser vos images de références, vous devez renseigner son URL (si image sur internet) ou son chemin depuis votre disque dur.

## 🐛 Problèmes courants

### Le MCP ne démarre pas
- Vérifie que ta clé API Gemini est valide
- Assure-toi d'avoir `uv` installé : `curl -LsSf https://astral.sh/uv/install.sh | sh`

### Erreur de génération
- Vérifie tes crédits API
- Essaie avec le modèle `flash` si `pro` ne fonctionne pas

## 📄 Licence

MIT