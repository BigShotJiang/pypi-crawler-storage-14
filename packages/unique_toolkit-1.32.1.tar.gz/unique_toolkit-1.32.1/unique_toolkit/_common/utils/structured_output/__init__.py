# Structured output utilities package
