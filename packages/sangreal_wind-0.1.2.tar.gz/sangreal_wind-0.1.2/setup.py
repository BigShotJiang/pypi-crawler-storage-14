from setuptools import find_packages, setup

setup(
    name='sangreal_wind',
    version='0.1.2',
    description=(
        'Elegant and efficient Python library for wind financial data access with '
        'comprehensive abstraction layers and 100% forward compatibility'
    ),
    long_description=(
        'sangreal-wind is a refactored Python library that provides elegant and '
        'efficient access to wind financial data. Features include:\n\n'
        '- Complete refactoring with elegant abstraction layers\n'
        '- Zero code duplication across all API modules\n'
        '- 100% forward compatibility guarantee\n'
        '- Multi-level caching for optimal performance\n'
        '- Type-safe implementations with full type hints\n'
        '- Unified API design patterns\n'
        '- Comprehensive error handling and database compatibility\n\n'
        'The library provides access to stock universes, index data, '
        'industry classifications, return rates, and fund data through '
        'a clean, consistent API interface.'
    ),
    long_description_content_type='text/plain',
    keywords='wind financial data api stock index industry fund returns abstract-layer',

    install_requires=[
        'sangreal-db',
        'sangreal-calendar >= 0.0.36',
        'sqlalchemy >= 1.4.0',
        'attrs >= 21.0.0',
        'pandas >= 1.3.0',
        'numpy >= 1.21.0',
    ],

    python_requires='>=3.7',

    author='liubola',
    author_email='lby3523@gmail.com',
    maintainer='liubola',
    maintainer_email='lby3523@gmail.com',

    license='GNU General Public License v3.0',

    packages=find_packages(),
    platforms=["all"],
    url='https://github.com/liubola/sangreal-wind',
    project_urls={
        'Bug Reports': 'https://github.com/liubola/sangreal-wind/issues',
        'Source': 'https://github.com/liubola/sangreal-wind',
        'Documentation': 'https://github.com/liubola/sangreal-wind/blob/main/README.md',
    },

    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Operating System :: OS Independent',
        'Intended Audience :: Developers',
        'Intended Audience :: Financial and Insurance Industry',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Office/Business :: Financial',
        'Topic :: Office/Business :: Financial :: Investment',
        'Topic :: Scientific/Engineering :: Information Analysis',
        'Typing :: Typed',
    ],

    include_package_data=True,
    zip_safe=False,

    entry_points={
        'console_scripts': [
            # 可以添加命令行工具
        ],
    },

    extras_require={
        'dev': [
            'pytest >= 6.0.0',
            'pytest-cov >= 2.0.0',
            'black >= 21.0.0',
            'isort >= 5.0.0',
            'flake8 >= 3.8.0',
            'mypy >= 0.812',
        ],
        'docs': [
            'sphinx >= 4.0.0',
            'sphinx-rtd-theme >= 0.5.0',
        ],
        'performance': [
            'psutil >= 5.8.0',
            'memory-profiler >= 0.60.0',
        ],
    },
)
