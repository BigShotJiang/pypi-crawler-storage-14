# sangreal-wind
short_cut api for nwind
