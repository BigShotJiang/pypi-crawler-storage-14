from saiful_islam.speaker import Speaker


class Saiful(Speaker):
    name = "Saiful"