``nipoppy pipeline install``
============================

.. note::
   This command calls the :py:class:`nipoppy.workflows.pipeline_store.install.PipelineInstallWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.pipeline_catalog:pipeline_install
   :prog: nipoppy pipeline install
