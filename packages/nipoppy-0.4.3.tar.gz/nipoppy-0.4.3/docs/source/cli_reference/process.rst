``nipoppy process``
===================

.. note::
   This command calls the :py:class:`nipoppy.workflows.processing_runner.ProcessingRunner` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:process
   :prog: nipoppy process
