``nipoppy pipeline list``
=========================

.. note::
   This command calls the :py:class:`nipoppy.workflows.pipeline_store.list.PipelineListWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.pipeline_catalog:pipeline_list
   :prog: nipoppy pipeline list
