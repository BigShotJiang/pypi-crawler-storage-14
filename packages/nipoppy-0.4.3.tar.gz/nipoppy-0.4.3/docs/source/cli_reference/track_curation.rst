``nipoppy track-curation``
==========================

.. note::
   This command calls the :py:class:`nipoppy.workflows.track_curation.TrackCurationWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:track_curation
   :prog: nipoppy track-curation
