"""
tab4 - compatible with Python 2.0-3.14
"""

from .compat import PY2, PY3, text_type, binary_type

__version__ = "0.1.0"
__all__ = ['tab4']

from .core import tab4