"""
Совместимость между Python 2 и 3
"""

import sys

# Базовые типы
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

# Строки и Unicode
if PY2:
    text_type = unicode
    binary_type = str
    string_types = (str, unicode)
else:
    text_type = str
    binary_type = bytes
    string_types = (str,)

# Функции
if PY2:
    from itertools import imap as map, izip as zip
    range = xrange
else:
    map = map
    zip = zip
    range = range

# Импорты
try:
    from collections.abc import MutableMapping  # Python 3.3+
except ImportError:
    from collections import MutableMapping  # Python 2

try:
    from importlib import reload  # Python 3.4+
except ImportError:
    from imp import reload  # Python 2

# Утилиты
def to_bytes(s, encoding='utf-8'):
    if isinstance(s, text_type):
        return s.encode(encoding)
    return s

def to_text(s, encoding='utf-8'):
    if isinstance(s, binary_type):
        return s.decode(encoding)
    return s