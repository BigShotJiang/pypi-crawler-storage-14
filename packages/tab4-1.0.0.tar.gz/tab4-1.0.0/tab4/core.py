"""
Основная функциональность
"""

from .compat import PY2, map, string_types


def tab4(*args, **kwargs):
    """
    Замена табуляции на 4 пробела.
    Совместима с Python 2.0-3.14
    """
    is_tuple = kwargs.get('is_tuple', False)

    # Проверка аргументов
    if not args:
        if PY2:
            return [] if not is_tuple else ()
        else:
            return list() if not is_tuple else tuple()

    if len(args) == 1:
        arg = args[0]
        # Поддержка разных типов входных данных
        if isinstance(arg, string_types):
            return arg.replace('\t', '    ')
        elif hasattr(arg, '__iter__'):
            # Для итераторов используем совместимый map
            result = map(lambda s: s.replace('\t', '    ') if isinstance(s, string_types) else s, arg)
            # В Python 2 map возвращает list, в Python 3 - iterator
            if not PY2:
                result = list(result)
            if is_tuple:
                return tuple(result)
            return result
        else:
            return arg

    # Множественные аргументы
    output = map(lambda s: s.replace('\t', '    ') if isinstance(s, string_types) else s, args)
    if not PY2:
        output = list(output)

    if is_tuple:
        return tuple(output)
    return output