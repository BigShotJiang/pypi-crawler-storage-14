from setuptools import setup, find_packages
import sys

# Условные зависимости для разных версий Python
install_requires = []
if sys.version_info < (3, 0):
    install_requires.extend([
        'typing>=3.5.3; python_version < "3.5"',
        'futures>=3.0.5; python_version < "3.2"',
    ])

setup(
    name='tab4',
    version="1.0.0",
    packages=find_packages(),

    # Критически важные настройки для совместимости
    python_requires=">=2.6, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*",
    # Исключаем проблемные версии Python 3

    install_requires=install_requires,

    # Метаданные
    author_email='magilyas.doma.09@list.ru',
    author='Маг Ильяс DOMA (MagIlyasDOMA)',
    url="https://github.com/MagIlyasDOMA/tab4",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 2.6",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.4",
        "Programming Language :: Python :: 3.5",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
    ],
)