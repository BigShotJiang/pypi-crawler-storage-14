# pggo

A PLAN GRAPH for GOAL OPTIMIZATION (PGGO or "pogo")

## Usage

```python
plan: PlanGraph = PlanGraph(
    "NC",
    "congress",
    "testdata/NC_congress_root_map.csv",
    "testdata/NC_input_data.jsonl",
    "testdata/NC_graph.json",
)
```

See [PlanGraph Documentation](docs/PlanGraph.md) for more details.

## Installing the Package

To install the package:

```bash
pip install plangraph
```

The latest version of the package is 0.1.0.

Then in your code, either `import plangraph` or `from plangraph import ...`.

## Testing

Run automated tests with:

```bash
pytest
```

