"""
PLAN-LEVEL WRAPPERS FOR GOAL SEEKING BOUND TO A PLANGRAPH

These helpers are separated out from the PlanGraph class proper, because:
- Different people may want to use different metrics for their projects, and
- The same people may want to use different metrics for different goals.

These are simple wrappers over the metrics in `rdapy`.

"""

from typing import Dict, List

from rdapy import (
    est_seats,
    est_competitive_districts,
    calc_minority_metrics,
    calc_cut_score,
    calc_splitting_metrics,
)

from .pggo import PlanGraph

### PARTISAN WRAPPERS ###


def get_estimated_dem_seats(plan: PlanGraph) -> float:
    """Get estimated Democratic seats."""

    dem_shares = [
        plan.get_computed("dem_share")(d) for d in range(1, plan.num_districts + 1)
    ]

    return est_seats(dem_shares)


def get_estimated_competitive_districts(plan: PlanGraph) -> float:
    """Get estimated competitive districts."""

    dem_shares = [
        plan.get_computed("dem_share")(d) for d in range(1, plan.num_districts + 1)
    ]

    return est_competitive_districts(dem_shares)


def get_partisan_advantage(plan: PlanGraph) -> float:
    """
    Get partisan advantage (PA).

    PA = estimated_dem_seats - proportional_dem_seats
    Positive = R advantage, Negative = D advantage, Zero = proportional
    """

    pa = get_estimated_dem_seats(plan) - plan.proportional_dem_seats

    return pa


### MINORITY OPPORTUNITY WRAPPERS ###


def get_minority_metrics(plan: PlanGraph) -> Dict[str, float]:
    """Compute minority opportunity metrics using rdapy."""

    vap_keys = list(plan._fields["vap"].keys())
    total_vap_key = vap_keys[0]  # First key is total VAP

    district_vaps: Dict[str, List[int]] = plan.get_computed("district_vaps")()

    # # Thunk aggregates into the format that rda.calc_minority_opportunity expects
    by_district: List[Dict[str, float]] = list()
    for i in range(plan.num_districts):
        district_demos: Dict[str, float] = dict()
        for demo in vap_keys[1:]:  # Skip total VAP
            simple_demo: str = demo.split("_")[0].lower()
            district_demos[simple_demo] = (
                district_vaps[demo][i + 1] / district_vaps[total_vap_key][i + 1]
            )

        by_district.append(district_demos)

    minority_metrics: Dict[str, float] = calc_minority_metrics(
        plan.get("statewide_vap_demos")(), by_district, clip=False
    )

    return minority_metrics


def get_combined_minority_score(plan: PlanGraph) -> float:
    """Get combined minority representation score."""

    minority_metrics: Dict[str, float] = get_minority_metrics(plan)

    opportunity_districts: float = minority_metrics["opportunity_districts"]
    coalition_districts: float = minority_metrics["coalition_districts"]

    minority_score: float = opportunity_districts + 0.5 * coalition_districts

    return minority_score


### COMPACTNESS WRAPPERS ###


def get_cut_score(plan: PlanGraph) -> int:
    """
    Calculate the cut score using `rdapy`.

    Was `get_total_cut_score` in plan.py.
    """

    cut_score: int = calc_cut_score(plan.assignments, plan.precinct_graph)

    return cut_score


def get_compactness_metrics(plan: PlanGraph) -> Dict[str, float]:
    """Get average Reock & Polsby-Popper compactness scores."""

    by_district = plan.get_computed("district_compactness")()

    compactness_metrics: Dict[str, float] = {
        "reock": by_district["reock"][0],
        "polsby_popper": by_district["polsby_popper"][0],
    }

    return compactness_metrics


def get_district_compactness(plan: PlanGraph, district: int) -> float:
    """Get Polsby-Popper compactness score for a specific district."""

    by_district = plan.get_computed("district_compactness")()

    polby_popper: float = by_district["polsby_popper"][district]

    return polby_popper


### COUNTY-DISTRICT SPLITTING WRAPPERS ###


def get_counties_split(plan: PlanGraph) -> int:
    """Get the number of counties that are split."""

    # Counties split: number of counties split at least once
    n_counties: int = sum(
        1
        for districts in plan.get_computed("districts_by_county").values()
        if len(districts) > 1
    )

    return n_counties


def get_county_splits(plan: PlanGraph) -> int:
    """Get the number of county splits."""

    # Count splits: for each county in N districts, there are N-1 splits
    n_splits: int = sum(
        len(districts) - 1
        for districts in plan.get_computed("districts_by_county").values()
    )

    return n_splits


def get_splitting_metrics(plan: PlanGraph) -> Dict[str, float]:
    """Compute county & district splitting metrics using rdapy."""

    return calc_splitting_metrics(plan.get_computed("CxD").copy())


def get_combined_split_score(plan: PlanGraph) -> float:
    """Combine the county & district split scores"""

    splitting: Dict[str, float] = get_splitting_metrics(plan)

    return (splitting["county"] + splitting["district"]) / 2.0


### END ###
