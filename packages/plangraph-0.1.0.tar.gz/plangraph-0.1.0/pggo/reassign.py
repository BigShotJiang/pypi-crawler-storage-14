"""
INFORMATION FOR REASSIGNING PRECINCTS BETWEEN DISTRICTS
"""

from typing import List, NamedTuple


class Reassign(NamedTuple):
    """Info to reassign one precinct from its current district to another adjacent one."""

    geoid: str
    from_district: int
    to_district: int

    def __repr__(self) -> str:
        return f"{self.geoid}: {self.from_district} -> {self.to_district}"


class Reassignments:
    """One or more related precinct reassignments."""

    def __init__(self, reassignments: List[Reassign]):
        self.reassignments: List[Reassign] = reassignments


### END ###
