"""
PLAN GRAPH for GOAL OPTIMIZATION (PGGO or "pogo")
Redisticting plans represented as connected graphs with data-bearing nodes.
"""

from typing import Any, Dict, List, Set, Tuple

import copy
from collections import defaultdict
import networkx as nx

from rdapy import (
    load_data,
    load_graph,
    sorted_geoids,
    collect_metadata,
    County,
    District,
    OUT_OF_STATE,
    DatasetKey,
    get_dataset_keys,
    get_fields,
    #
    read_csv,
    #
    ParseGeoID,
    #
    wl_make_circle,
    calc_compactness_category,
)
from rdapy.aggregate import border_length, exterior


from .reassign import Reassign, Reassignments


class PlanGraph:
    """A redistricting plan represented as an adjacency graph including all node (precinct) data."""

    def __init__(
        self,
        xx: str,
        plan_type: str,
        plan_path: str,
        data_path: str,
        graph_path: str,
    ):
        self._load_plan(plan_path)
        self._load_state_data(xx, plan_type, data_path, graph_path)
        self._calc_state_statistics()
        self._initialize_aggregates()  # TODO - Just set a dirty flag instead?

        pass  # for a breakpoint

    # region: PRIVATE helpers #

    def _load_plan(self, plan_path: str) -> None:
        """Load a precinct-assignment file from a CSV. Cull the district ids."""

        self.assignments: Dict[str, int] = self._load_map(plan_path)
        self._districts: Set[int] = set(self.assignments.values())

    def _load_map(self, plan_path: str) -> Dict[str, int]:
        """Load a precinct-assignment file from a CSV."""

        plan_csv = read_csv(plan_path, [str, int])

        geoid_fields: List[str] = ["GEOID", "GEOID20", "GEOID30"]
        district_fields: List[str] = ["District", "DISTRICT"]

        keys: List[str] = list(plan_csv[0].keys())

        geoid_field: str = list(set(geoid_fields) & set(keys))[0]
        district_field: str = list(set(district_fields) & set(keys))[0]

        assignments: Dict[str, int] = {
            str(row[geoid_field]): int(row[district_field]) for row in plan_csv
        }

        return assignments

    def _load_state_data(
        self, xx: str, plan_type: str, data_path: str, graph_path: str
    ) -> None:
        """Load the state data, graph, and metadata"""

        data_map: Dict[str, Any]
        input_data: List[Dict[str, Any]]
        data_map, input_data = load_data(data_path)
        # Save this for compatibility with `rdapy` functions
        self.precinct_graph: Dict[str, List[str]] = load_graph(graph_path)

        geoids: List[str] = sorted_geoids(input_data)
        metadata: Dict[str, Any] = collect_metadata(
            xx,
            plan_type,
            geoids,
        )

        # Store metadata for scoring

        self.num_districts: int = metadata["D"]
        self.num_counties: int = metadata["C"]
        self._county_to_index: Dict[County, int] = metadata["county_to_index"]
        self._district_to_index: Dict[District, int] = metadata["district_to_index"]

        # Process the precinct data, dataset keys, and fields

        census_dataset: DatasetKey
        vap_dataset: DatasetKey
        cvap_dataset: DatasetKey
        election_datasets: List[DatasetKey]
        (
            census_dataset,
            vap_dataset,
            cvap_dataset,
            election_datasets,
            _,
        ) = get_dataset_keys(data_map)
        election_dataset: DatasetKey = election_datasets[0]

        # datasets: Dict[str, DatasetKey] = {
        #     "census": census_dataset,
        #     "vap": vap_dataset,
        #     "cvap": cvap_dataset,
        #     "election": election_dataset,
        # }

        census_fields: Dict[str, str] = {
            "total_pop": get_fields(data_map, "census", census_dataset)["total_pop"]
        }

        vap_fields: Dict[str, str] = dict()
        for simple_name, qualified_name in get_fields(
            data_map, "vap", vap_dataset
        ).items():
            vap_fields[simple_name] = qualified_name

        cvap_fields: Dict[str, str] = dict()
        for simple_name, qualified_name in get_fields(
            data_map, "cvap", cvap_dataset
        ).items():
            cvap_fields[simple_name] = qualified_name

        election_fields: Dict[str, str] = dict()
        for simple_name, qualified_name in get_fields(
            data_map, "election", election_dataset
        ).items():
            election_fields[simple_name] = qualified_name

        shape_fields: Dict[str, str] = {
            "center": "center",
            "area": "area",
            "arcs": "arcs",
            "exterior": "exterior",
        }

        self._fields: Dict[str, Dict[str, str]] = {
            "census": census_fields,
            "vap": vap_fields,
            "cvap": cvap_fields,
            "election": election_fields,
            "shape": shape_fields,
        }

        # TODO - Update this documentation
        # Make two graphs
        # - The main one with all the precinct data but without a surrounding border
        # - The other with a surrounding border and no precinct data (for compactness calculations)

        adjacencies: List[Tuple[str, str]] = self._make_adjacencies()
        data: List[Dict[str, Any]] = self._make_data(input_data, self._fields)
        self._shape_data_by_geoid: Dict[str, Any] = {
            p["geoid"]: {
                "area": p["area"],
                "arcs": p["arcs"],
                "exterior": p["exterior"],
            }
            for p in data
        }  # For thunking to `rdapy` compactness-related calculations

        self.graph: nx.Graph = self._make_graph(data, adjacencies)
        # TODO - Rationalize with self.precinct_graph. Can this be deleted?
        # self.graph_with_border: nx.Graph = self._make_graph_with_border()

        # TODO - Rationalize this with self.precinct_graph. I think this can be deleted.
        # Create graph_dict for compactness calculations (includes OUT_OF_STATE)
        # self.graph_dict: Dict[str, List[str]] = {
        #     node: list(self.graph_with_border.neighbors(node))
        #     for node in self.graph_with_border.nodes()
        # }

    def _make_data(
        self,
        input_data: List[Dict[str, Any]],
        fields: Dict[str, Dict[str, str]],
    ) -> List[Dict[str, Any]]:
        """Reduce the input data to only the specified fields by precinct geoid. Use simple, unqualified field names."""

        data: List[Dict[str, Any]] = list()
        for row in input_data:
            reduced: Dict[str, Any] = {"geoid": row["geoid"]}
            for dataset_type, dataset_fields in fields.items():
                for simple_name, qualified_name in dataset_fields.items():
                    assert (
                        qualified_name in row
                    ), f"Missing field {qualified_name} in row {row['geoid']}"
                    reduced[simple_name] = row[qualified_name]
            data.append(reduced)

        return data

    def _make_adjacencies(self) -> List[Tuple[str, str]]:
        """Convert a node/list adjacency graph to a list of node pairs, removing virtual border geos if present."""

        pairs: List[Tuple[str, str]] = [
            (node, neighbor)
            for node, neighbors in self.precinct_graph.items()
            for neighbor in neighbors
            if node < neighbor and node != OUT_OF_STATE and neighbor != OUT_OF_STATE
        ]

        return pairs

    def _make_graph(
        self, data: List[Dict[str, Any]], adjacencies: List[Tuple[str, str]]
    ) -> nx.Graph:
        """Fold precinct adjacency & data into a NetworkX graph."""

        nodes: List[Tuple] = []
        for i, precinct in enumerate(data):
            attrs: Dict[str, Any] = dict()
            attrs["assignment"] = self.assignments[precinct["geoid"]]
            attrs.update(precinct)
            node: Tuple = (precinct["geoid"], attrs)
            # node: Tuple = (i, attrs)
            nodes.append(node)

        edges: List[Tuple] = []
        for geoid1, geoid2 in adjacencies:
            edge: Tuple = (geoid1, geoid2) if geoid1 < geoid2 else (geoid2, geoid1)
            edges.append(edge)

        graph = nx.Graph()
        graph.add_nodes_from(nodes)
        graph.add_edges_from(edges)

        return graph

    def _make_graph_with_border(self) -> nx.Graph:
        """Make a NetworkX graph from adjacency data including OUT_OF_STATE node and edges."""

        G = nx.Graph()
        for node, neighbors in self.precinct_graph.items():
            for neighbor in neighbors:
                G.add_edge(node, neighbor)

        return G

    def _infer_district_graph(self) -> Dict[int, List[int]]:
        """Infer a district adjacency graph from the precinct adjacency graph and assignments."""

        district_graph: defaultdict[int, List[int]] = defaultdict(list)
        for precinct, district in self.assignments.items():
            neighbors: List[str] = self.precinct_graph[precinct]
            for neighbor in neighbors:
                if neighbor == OUT_OF_STATE:
                    continue

                assert (
                    neighbor in self.assignments
                ), f"Neighbor {neighbor} not in assignments!"
                neighbor_district: int = self.assignments[neighbor]

                if (
                    neighbor_district != district
                    and neighbor_district not in district_graph[district]
                ):
                    district_graph[district].append(neighbor_district)

        return district_graph

    def _calc_state_statistics(self) -> None:
        """Compute statewide statistics."""

        self.total_population: int = sum(
            [self.graph.nodes[geoid]["total_pop"] for geoid in self.graph.nodes()]
        )
        self.target_district_pop: int = int(self.total_population / self.num_districts)

        # Compute two-party vote share

        total_dem_votes = sum(
            [self.graph.nodes[geoid]["dem_votes"] for geoid in self.graph.nodes()]
        )
        total_rep_votes = sum(
            [self.graph.nodes[geoid]["rep_votes"] for geoid in self.graph.nodes()]
        )
        two_party_votes = total_dem_votes + total_rep_votes
        self.statewide_dem_share: float = (
            total_dem_votes / two_party_votes if two_party_votes > 0 else 0.0
        )
        self.proportional_dem_seats: int = round(
            self.statewide_dem_share * self.num_districts
        )

        # Compute statewide VAP demographics for minority metrics

        self.statewide_vap_demos: Dict[str, float] = {}
        total_vap = sum(
            [self.graph.nodes[geoid]["total_vap"] for geoid in self.graph.nodes()]
        )
        assert total_vap > 0, "No VAP data found in precincts!"

        for simple_name, _ in self._fields["vap"].items():
            if simple_name == "total_vap":
                continue
            demo_total = sum(
                [self.graph.nodes[geoid][simple_name] for geoid in self.graph.nodes()]
            )
            demo_key = simple_name.replace("_vap", "")
            self.statewide_vap_demos[demo_key] = demo_total / total_vap
        # CVAP

    def _initialize_aggregates(self) -> None:
        """Initialize by-district aggregates."""

        self._district_populations: Dict[int, int] = defaultdict(int)

        self._district_rep_votes: Dict[int, int] = defaultdict(int)
        self._district_dem_votes: Dict[int, int] = defaultdict(int)
        self._district_dem_shares: Dict[int, float] = defaultdict(float)

        # NOTE - This mimics high-volume offline scoring in that the aggregates are dict-based
        # but then have to be converted lists for the scoring functions. A potential optimization
        # opportunity would be to store these as lists directly.
        self._district_vaps: Dict[str, List[int]] = {
            demo: [0] * (self.num_districts + 1) for demo in self._fields["vap"]
        }
        # CVAP

        self._initialize_shape_aggregates()

        self._CxD: List[List[float]] = [
            [0.0] * self.num_counties for _ in range(self.num_districts)
        ]
        self._counties_by_district: Dict[int, Set[str]] = defaultdict(set)
        self._districts_by_county: Dict[str, Set[int]] = defaultdict(set)

        self._district_graph: Dict[int, List[int]] = {}

        self._aggregates_dirty = True

    def _initialize_shape_aggregates(self) -> None:
        self._district_shape_attributes: Dict[str, List[float]] = {
            "area": [0.0] * (self.num_districts + 1),
            "perimeter": [0.0] * (self.num_districts + 1),
            "diameter": [0.0] * (self.num_districts + 1),
        }  # The 0th element is a total for the state, if applicable
        self._district_exteriors: Dict[str, List[Any]] = {
            "exterior": [[] for _ in range(self.num_districts + 1)]
        }  # The 0th element is a total for the state, if applicable
        self._district_compactness: Dict[str, List[float]] = defaultdict(list)

    def _aggregate(self) -> None:
        """Aggregate data by district and state. Cache the results."""

        if not self._aggregates_dirty:
            return

        # Reset aggregates
        self._initialize_aggregates()

        # Aggregate data & shapes by district
        for geoid, district in self.assignments.items():
            pop: int = self.get_precinct(geoid, "total_pop", 0)

            self._district_populations[district] += pop

            self._district_dem_votes[district] += self.get_precinct(
                geoid, "dem_votes", 0
            )
            self._district_rep_votes[district] += self.get_precinct(
                geoid, "rep_votes", 0
            )

            for simple_name, _ in self._fields["vap"].items():
                demo_tot: int = self.get_precinct(geoid, simple_name, 0)
                self._district_vaps[simple_name][district] += demo_tot
                self._district_vaps[simple_name][0] += demo_tot  # statewide total
            # CVAP

            self._aggregate_shape_data(
                geoid,
                district,
                self._district_shape_attributes,
                self._district_exteriors,
            )

            county = ParseGeoID(geoid).county[2:]
            i = district - 1  # District 1 -> row 0, district 2 -> row 1, etc.
            j = self._county_to_index[county]
            self._CxD[i][j] += pop
            self._counties_by_district[district].add(county)
            self._districts_by_county[county].add(district)

        # Compute two-party vote share
        for district in self._districts:
            two_party_votes = (
                self._district_dem_votes[district] + self._district_rep_votes[district]
            )
            if two_party_votes > 0:
                self._district_dem_shares[district] = (
                    self._district_dem_votes[district] / two_party_votes
                )
            else:
                self._district_dem_shares[district] = 0.0

        # Calculate district diameters

        self._calc_district_diameter(
            self._district_shape_attributes, self._district_exteriors
        )
        self._district_compactness = calc_compactness_category(
            self._district_shape_attributes, self.num_districts
        )

        # TODO - Don't do this automatically?
        # Infer a district adjacency graph
        self._district_graph = self._infer_district_graph()

        self._aggregates_dirty = False

    def _aggregate_shape_data(
        self,
        geoid: str,
        district: int,
        by_district: Dict[str, List[float]],  # NOTE - updated
        by_district_temp: Dict[str, List[Any]],  # NOTE - updated
    ) -> None:
        """Aggregate shape data helper. Modelled on the version in `rdapy`. Thunking to helper functions there."""

        data_by_geoid: Dict[str, Any] = self._shape_data_by_geoid
        precinct = data_by_geoid[geoid]

        by_district["area"][district] += precinct["area"]
        by_district["area"][0] += precinct["area"]
        by_district["perimeter"][district] += border_length(
            geoid, district, self.assignments, data_by_geoid, self.precinct_graph
        )
        by_district_temp["exterior"][district].extend(
            exterior(
                geoid, district, self.assignments, data_by_geoid, self.precinct_graph
            )
        )

    def _calc_district_diameter(
        self,
        by_district: Dict[str, List[float]],  # NOTE - updated
        by_district_temp: Dict[str, List[Any]],
    ) -> None:
        """Calculate district diameters helper. Cloned from `rdapy`."""

        for i, ext in enumerate(by_district_temp["exterior"]):
            if i == 0:
                continue  # Skip the state total

            _, _, r = wl_make_circle(ext)
            diameter: float = 2 * r

            by_district["diameter"][i] = diameter

    # endregion

    # region: PUBLIC: SMART GETTERS - USE CACHED INFO, IF AVAILABLE; OTHERWISE FORCE RECOMPUTATION #

    def get(self, attr: str) -> Any:
        """Get a plan-level attribute."""

        assert attr in [
            "assignments",
            "graph",
            "num_counties",
            "num_districts",
            "proportional_dem_seats",
            "statewide_dem_share",
            "statewide_vap_demos",
            "target_district_pop",
            "total_population",
            "precinct_graph",
        ], f"Unknown plan attribute {attr}!"

        value: Any = getattr(self, attr)

        return value

    def get_precinct(self, geoid: str, attr: str, default: Any) -> Any:
        """Get the value of an attribute for a precinct node in the graph."""

        # TODO - Add a guard on the attr

        value: Any = self.graph.nodes[geoid].get(attr, default)

        return value

    def get_computed(self, name: str) -> Any:
        """
        Get a by-district aggregate. (Re)compute it, if necessary.

        NOTE - These should not be updated in place outside this class! Make a copy first, if needed.
        """

        assert name in [
            "district_populations",
            #
            "district_dem_votes",
            "district_rep_votes",
            "district_dem_shares",
            #
            "district_compactness",
            "district_shape_attributes",
            #
            "CxD",
            "counties_by_district",
            "districts_by_county",
            #
            "district_vaps",
            #
            "district_graph",
        ], f"Unknown aggregate {name}!"

        self._aggregate()

        attr_name: str = f"_{name}"
        value: Any = getattr(self, attr_name)

        return value

    # endregion

    # region: PUBLIC #

    def reassign(self, reassignments: Reassignments) -> None:
        """
        Update the given plan in place by reassigning some precincts to new districts.

        To save a version of a plan before updating it, use `plan.copy()` first.
        """

        for a in reassignments.reassignments:
            self.assignments[a.geoid] = a.to_district
            self.graph.nodes[a.geoid]["assignment"] = a.to_district

        self._aggregates_dirty = True

    def copy(self) -> "PlanGraph":
        return copy.deepcopy(self)

    # Miscellaneous helper methods

    def district_subgraph(self, district: int) -> nx.Graph:
        """Get the subgraph for a given district."""

        nodes_in_district = [
            n
            for n in self.graph.nodes()
            if self.graph.nodes[n].get("assignment") == district
        ]

        D: nx.Graph = self.graph.subgraph(nodes_in_district).copy()

        return D

    def connecting_precincts(self, S: nx.Graph, D: nx.Graph) -> List[str]:
        """
        Get the list of nodes in district subgraph S that are adjacent to any node in district subgraph D.

        Args:
            S (nx.Graph): The source district subgraph.
            D (nx.Graph): The destination district subgraph.
        """

        boundary_nodes: Set[str] = set()
        D_set: Set[str] = set(D)

        for node in S:
            for neighbor in self.graph.neighbors(node):
                if neighbor in D_set:
                    boundary_nodes.add(node)
                    break

        return list(boundary_nodes)

    # endregion


### END ###
