class GuardrailsError(Exception):
    """Raised when a guardrails error occurs."""

    pass
