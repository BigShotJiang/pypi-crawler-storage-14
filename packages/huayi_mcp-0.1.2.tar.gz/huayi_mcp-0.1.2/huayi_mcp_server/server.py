import asyncio
import logging
from typing import Annotated

import click
from mcp.server.fastmcp import Context, FastMCP
from mcp.server.session import ServerSession
from pydantic import BaseModel, Field, model_validator
from pydantic.fields import FieldInfo

logger = logging.getLogger(__name__)


class UserNumDetailOutput(BaseModel):
    user_id: str = Field(title="用户Id", description="用户标识 用户ID userId")
    user_phone: str = Field(title="用户手机号码", description="用户手机号码 可作为用户标识 userPhone")

    """会员自配送次数"""
    member_expire_num: int = Field(
        title="会员自配送次数",
        description="会员自配送次数",
        json_schema_extra={"x-display-name": "自配送次数"},
    )

    """其他自配送次数"""
    other_num: int = Field(title="其他自配送次数", description="其他自配送次数")


class ToolSet:

    def __init__(self, name: str, log_level: str):
        self.mcp = FastMCP(name=name)
        self.mcp.settings.log_level = log_level.upper()

        @self.mcp.tool()
        def simple_text() -> str:
            """Test simple text content response"""
            return "This is a simple text response for testing"

        @self.mcp.tool()
        async def tool_with_logging(ctx: Context[ServerSession, None]) -> str:
            """Test tool that emits log message during execution"""
            await ctx.info("Tool execution started")
            await asyncio.sleep(0.05)

            await ctx.info("Tool processing data")
            await asyncio.sleep(0.05)

            await ctx.info("Tool execution completed")

            return "Tool with logging executed successfully"

        @self.mcp.tool(
            name="查询给定用户自配送次数",
            title="查询给定用户自配送次数",
            description="查询给定用户自配送次数",
            structured_output=True,
        )
        async def get_user_num_detail(ctx: Context[ServerSession, None], user_identity: Annotated[str, Field(title="用户标识", description="用户标识, 可能是 userId 或 userPhone", default=None)]) -> UserNumDetailOutput:
            """查询给定用户自配送次数"""

            await ctx.info(f"get_user_num_detail's input: {user_identity}")
            return UserNumDetailOutput(
                user_id=user_identity,
                user_phone=user_identity,
                member_expire_num=512,
                other_num=10,
            )

    def run_on_stdio(self):
        self.mcp.run(transport="stdio")

    def run_on_streamable_http(self):
        self.mcp.run(transport="streamable-http")

    def run_on_sse(self):
        self.mcp.run(transport="sse")


@click.command()
@click.option(
    "--transport",
    default="stdio",
    help="MCP transport: stdio, streamable-http, sse",
)
@click.option(
    "--log-level",
    default="INFO",
    help="Log level: DEBUG, INFO, WARNING, ERROR",
)
def main(transport: str | None, log_level: str | None) -> int:
    """Run the MCP Server."""
    transport = transport if transport else "stdio"
    log_level = log_level if log_level else "INFO"

    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    logger.info(f"Starting MCP Server")

    toolset = ToolSet(name="Huayi MCP", log_level=log_level)
    host = toolset.mcp.settings.host
    port = toolset.mcp.settings.port
    streamable_http_path = toolset.mcp.settings.streamable_http_path
    sse_path = toolset.mcp.settings.sse_path

    try:
        if transport.lower() == "streamable-http":
            logger.info(f"StreamableHTTP endpoint will be: http://{host}:{port}{streamable_http_path}")
            toolset.run_on_streamable_http()

        if transport.lower() == "sse":
            logger.info(f"SSE endpoint will be: http://{host}:{port}{sse_path}")
            toolset.run_on_sse()

        if transport.lower() == "stdio":
            logger.info(f"MCP Server will run on Stdio")
            toolset.run_on_stdio()

    except KeyboardInterrupt:
        logger.info("received Ctrl-C, shutting down...")

    return 0


if __name__ == "__main__":
    main()
