"""
pandas-tibble: R-style DataFrame display for pandas using Rich

Brings R's tibble() output to Python with beautiful formatting,
type annotations, and rich terminal output.

Author: Casper Crause
License: MIT
"""

from .display import (
    tibble,
    glimpse,
    Tibble,
)

__version__ = "0.2.2"
__author__ = "Casper Crause"

__all__ = [
    'tibble',
    'glimpse',
    'Tibble',
    '__version__',
]
