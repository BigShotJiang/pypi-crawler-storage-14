"""
Display utilities for pandas-tibble
Provides R tibble-style DataFrame display with type annotations
"""
import pandas as pd
from io import StringIO
from rich.console import Console
from rich.table import Table


def _generate_tibble_display(df: pd.DataFrame, max_rows: int = 10, show_index: bool = False) -> str:
    """
    Generate tibble-style display as a string

    Args:
        df: DataFrame to display
        max_rows: Maximum number of rows to show (default: 10)
        show_index: Whether to show the index column (default: False)

    Returns:
        String representation of the tibble display
    """
    buffer = StringIO()
    console = Console(file=buffer, force_terminal=True, width=120)

    # Dimension header (R tibble style)
    dims = f"# A DataFrame: {len(df):,} × {len(df.columns)}"
    console.print(dims, style="bold green")
    console.print()

    # Create table
    table = Table(show_header=True, header_style="bold cyan", box=None)

    # Add index column if requested
    if show_index:
        table.add_column("Index\n<int>", style="dim")

    # Add data columns with type annotations
    for col in df.columns:
        dtype_short = _format_dtype(df[col].dtype, df[col])
        table.add_column(f"{col}\n<{dtype_short}>")

    # Add rows (limit to max_rows)
    display_df = df.head(max_rows)
    for idx, row in display_df.iterrows():
        row_values = []
        if show_index:
            row_values.append(str(idx))
        # Pass dtype information for each value
        for col in df.columns:
            dtype_str = _format_dtype(df[col].dtype, df[col])
            row_values.append(_format_value(row[col], dtype_str))
        table.add_row(*row_values)

    console.print(table)

    # Show truncation message
    if len(df) > max_rows:
        console.print(f"# ... with {len(df) - max_rows:,} more rows", style="dim")

    return buffer.getvalue()


def tibble(df: pd.DataFrame, max_rows: int = 10, show_index: bool = False) -> None:
    """
    Display DataFrame with R tibble-style type annotations

    Args:
        df: DataFrame to display
        max_rows: Maximum number of rows to show (default: 10)
        show_index: Whether to show the index column (default: False)
    """
    output = _generate_tibble_display(df, max_rows=max_rows, show_index=show_index)
    print(output, end='')


def glimpse(df: pd.DataFrame) -> None:
    """
    R-style glimpse of DataFrame
    Shows dimensions and first few values of each column

    Args:
        df: DataFrame to glimpse
    """
    console = Console()

    console.print(f"Rows: {len(df):,}", style="bold")
    console.print(f"Columns: {len(df.columns)}", style="bold")
    console.print()

    max_col_width = max(len(str(col)) for col in df.columns) if len(df.columns) > 0 else 0

    for col in df.columns:
        dtype = _format_dtype(df[col].dtype, df[col])
        sample_vals = df[col].head(3).tolist()
        sample_str = ", ".join([_format_value(v, dtype) for v in sample_vals])
        console.print(f"{col:<{max_col_width}}  [cyan]<{dtype:>10}>[/cyan]  {sample_str}...")


def _format_dtype(dtype, series=None) -> str:
    """
    Convert pandas dtype to R-style short type name

    Args:
        dtype: pandas dtype
        series: optional pandas Series to inspect actual values for date detection

    Returns:
        R-style type name (chr, int, dbl, date, datetime, etc.)
    """
    dtype_str = str(dtype)

    # Map common pandas dtypes to R-style names
    dtype_map = {
        'string': 'chr',
        'int64': 'int',
        'int32': 'int',
        'int16': 'int',
        'int8': 'int',
        'float64': 'dbl',
        'float32': 'dbl',
        'bool': 'lgl',
        'datetime64[ns]': 'datetime',
        'datetime64[ns, UTC]': 'datetime',
        'timedelta64[ns]': 'timedelta',
        'category': 'fctr'
    }

    # Check if it's in the map first
    if dtype_str in dtype_map:
        return dtype_map[dtype_str]

    # Special handling for 'object' dtype - could be string, date, or mixed
    if dtype_str == 'object' and series is not None:
        # Check first non-null value to determine type
        non_null = series.dropna()
        if len(non_null) > 0:
            first_val = non_null.iloc[0]

            # Check if it's a date object (not datetime)
            import datetime
            if isinstance(first_val, datetime.date) and not isinstance(first_val, datetime.datetime):
                return 'date'
            # Check if it's a datetime object
            elif isinstance(first_val, datetime.datetime):
                return 'datetime'

        # Default to chr for object dtype
        return 'chr'

    # For any other datetime-like dtype
    if 'datetime' in dtype_str.lower():
        return 'datetime'

    # Default fallback
    return dtype_map.get(dtype_str, dtype_str)


def _format_value(val, dtype_str: str = None) -> str:
    """
    Format value for display

    Args:
        val: Value to format
        dtype_str: Optional dtype string to determine formatting
    """
    if pd.isna(val):
        return "NA"
    elif isinstance(val, float):
        # Format floats with 2 decimal places
        return f"{val:.2f}"
    elif isinstance(val, pd.Timestamp):
        # If it's a datetime type, show full timestamp
        if dtype_str and dtype_str == 'datetime':
            return val.strftime('%Y-%m-%d %H:%M:%S')
        else:
            # For date type, show only date
            return val.strftime('%Y-%m-%d')
    else:
        import datetime
        # Handle date objects (not datetime)
        if isinstance(val, datetime.date) and not isinstance(val, datetime.datetime):
            return val.strftime('%Y-%m-%d')
        elif isinstance(val, datetime.datetime):
            # If dtype_str indicates datetime, show full timestamp
            if dtype_str and dtype_str == 'datetime':
                return val.strftime('%Y-%m-%d %H:%M:%S')
            else:
                return val.strftime('%Y-%m-%d')
        return str(val)


class Tibble(pd.DataFrame):
    """
    DataFrame subclass with automatic tibble-style display

    Preserves all pandas functionality while providing R-style tibble display
    when printing or displaying in REPL.

    Examples:
        >>> tbl = Tibble({'a': [1, 2, 3], 'b': [4, 5, 6]})
        >>> tbl  # Displays with tibble formatting
        >>> tbl.mean()  # All pandas methods work
        >>> tbl['c'] = tbl['a'] + tbl['b']  # Operations work as normal
    """

    # Store display configuration
    _metadata = ['_max_rows', '_show_index']

    def __init__(self, *args, max_rows: int = 10, show_index: bool = False, **kwargs):
        """
        Initialize Tibble

        Args:
            *args: Positional arguments passed to pd.DataFrame
            max_rows: Maximum rows to display (default: 10)
            show_index: Whether to show index column (default: False)
            **kwargs: Keyword arguments passed to pd.DataFrame
        """
        super().__init__(*args, **kwargs)
        self._max_rows = max_rows
        self._show_index = show_index

    @property
    def _constructor(self):
        """Ensures pandas operations return Tibble objects"""
        return Tibble

    def __repr__(self) -> str:
        """String representation for REPL display"""
        return _generate_tibble_display(self, max_rows=self._max_rows, show_index=self._show_index)

    def __str__(self) -> str:
        """String representation for print()"""
        return _generate_tibble_display(self, max_rows=self._max_rows, show_index=self._show_index)

    def _repr_html_(self):
        """
        Disable HTML representation in Jupyter/VS Code
        Return None to force use of __repr__ for consistent tibble-style display
        """
        return None
