# logging-loguru

<!-- ![Lines of code](https://img.shields.io/tokei/lines/github/ablaternae/py-logging-loguru) -->
[![Code size](https://img.shields.io/github/languages/code-size/ablaternae/py-logging-loguru)](https://github.com/ablaternae/py-logging-loguru/)
[![Downloads](https://img.shields.io/pypi/dm/logging-loguru)](https://pypi.org/project/logging-loguru)
[![Downloads](https://img.shields.io/pypi/dd/logging-loguru?label=&color=green)](https://pypi.org/project/logging-loguru)
[![Statistic](https://static.pepy.tech/personalized-badge/logging-loguru?period=total&units=NONE&left_color=GRAY&right_color=GREEN&left_text=total)](https://pepy.tech/projects/logging-loguru)
[![License](https://img.shields.io/github/license/ablaternae/py-logging-loguru)](https://github.com/ablaternae/py-logging-loguru/blob/trunk/LICENSE.md)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000.svg)](https://github.com/psf/black)
<hr>

Tiny script for integrating the Python's standard Logging output to the colorful logs by the Loguru library.<br>
RLY 3kb: 1 file, 1 class, 1 function


### API
```python
class InterceptHandler(logging.Handler):
    def __init__(self, logger=loguru.logger)
    def emit(self, record: logging.LogRecord) -> None

def adapt(logger=loguru.logger, log=logging, level=0)
```

### usage

#### default behavior
```python
# file.py begin

import logging
import loguru
import logging_loguru

logging_loguru.adapt()

import ...
...
```
catches `logging.Logger` **all log**'s messages and pipes them all to default `loguru.logger` handler

#### choose Logger
```python
log = logging.getLogger("example") # ex: "flask", "WSGI", "peewee" etc, see docs

logging_loguru.adapt(log=log)
```
catches _example_'s logger messages and pipes them to default `loguru.logger` handler

#### tune handler
```python
from loguru import logger as file_logger

LOG_FORMAT = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"

file_logger.add(
    "example.dev-{time}.log",
    colorize=False,
    compression="gz",
    format=LOG_FORMAT,
    level="DEBUG",
    retention="10 days",
    rotation="4 hours",
    enqueue=True,
)

log = logging.getLogger("example")

logging_loguru.adapt(logger=file_logger, log=log, level="INFO")
```

<br>
That's all, folks!

<hr>
<small>ps: yeah, script is very similar to https://github.com/MatthewScholefield/loguru-logging-intercept/, but how could it have been written differently?</small>
