####
##
#
#

__version__ = "0.4.6"


import logging

import loguru


class InterceptHandler(logging.Handler):

    def __init__(self, logger=loguru.logger):
        super().__init__()
        self.logger = logger

    def emit(self, record: logging.LogRecord) -> None:
        """
        получает объект LogRecord и передает его в loguru (нет)

        :param record: logging.LogRecord object
        :return: None
        """

        # уровень логирования
        level = getattr(record, "levelname", record.levelno)

        # читаем фреймы из стека для отображения места вызова стандратного логера
        frame, depth = logging.currentframe(), 2
        # метод currentframe отсутствует в документации, но он Return the frame object for the caller's stack frame

        # ищем глубину вызова
        while frame.f_code.co_filename in (__file__, logging.__file__):
            # выглядит как полный бред. но это так работает
            frame, depth = frame.f_back, depth + 1

        # без вызова .opt() при одиночном вызове .log() ошибается
        self.logger.opt(depth=depth, exception=record.exc_info).log(
            level,
            record.getMessage(),
            elapsed=record.relativeCreated,
            exception=record.exc_info,
            file=record.pathname,  # fullpath
            # file=record.filename,
            depth=depth,
            function=record.funcName,
            level=record.levelname,
            line=record.lineno,
            message=record.msg,
            module=record.module,
            name=None,  # calling __name__
            process=record.process,
            thread=record.thread,
            time=record.created,
        )


def adapt(logger=loguru.logger, log=logging, level=0):
    """добавляет loguru.logger в цепочку обработчиков стандартного логера

    в параметрах можно передать конкретные логеры
    иначе будут выбраны логеры базового (корневого) уровня

    :param logger: loguru.logger object (loguru._logger.Logger)
    :param log: logging | logging.Logger
    :param level: str|int starter Log LEVEL (DEBUG, INFO, etc)
    :return: None
    :raises TypeError:
    """

    if not isinstance(logger, type(loguru.logger)):
        raise TypeError("argument `logger` must be of type `loguru.logger`")
        return
    if (
        isinstance(log, type(logging))
        and hasattr(log, "getLogger")
        and isinstance(log.getLogger(), logging.getLoggerClass())
    ):
        logging.basicConfig(handlers=[InterceptHandler(logger)], level=level)
    elif isinstance(log, logging.getLoggerClass()):
        log.handlers.append(InterceptHandler(logger))
    else:
        raise TypeError("unknown type argument `log`")


__all__ = ("adapt", "InterceptHandler")
