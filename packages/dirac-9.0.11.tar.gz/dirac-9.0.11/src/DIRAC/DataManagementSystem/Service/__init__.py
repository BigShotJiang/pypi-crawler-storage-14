"""
   DIRAC.DataManagementSystem.Service package
"""
