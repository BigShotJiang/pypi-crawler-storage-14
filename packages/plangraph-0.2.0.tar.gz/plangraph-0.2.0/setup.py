from setuptools import setup, find_packages

setup(
    name="plangraph",
    version="0.2.0",
    description="A Plan Graph for Goal Optimization (PGGO or 'pogo')",
    url="https://github.com/alecramsay/pggo",
    author="alecramsay",
    author_email="a73cram5ay@gmail.com",
    license="MIT",
    packages=[
        "pggo",  # The name of the source directory in the repository
    ],
    install_requires=["rdapy", "networkx"],
    zip_safe=False,
)
