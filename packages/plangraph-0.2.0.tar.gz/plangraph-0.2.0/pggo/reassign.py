"""
DATA STRUCTURES FOR REPRESENTING REASSIGNMENTS OF PRECINCTS BETWEEN DISTRICTS
"""

from typing import List, NamedTuple, TypeAlias


# A set of precincts to reassign from one district to another ('spliced')
class Graft(NamedTuple):
    precincts: List[str]
    from_district: int
    to_district: int

    def __repr__(self) -> str:
        return f"[{self.from_district}, {self.to_district}, {self.precincts}]"


# A sequence of Grafts to be applied in order.
Generation: TypeAlias = List[Graft]

# A sequence of Generations to be applied in order.
History: TypeAlias = List[Generation | Graft]


### END ###
