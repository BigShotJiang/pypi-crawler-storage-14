Assignment 2 - Gruppo I processati
Group Members: Carpio Herreros Marco (matricola 899802), Cattaneo Francesco (matricola 900411)

Questa repository contiene la pipeline per l'applicazione Flask **Blog**.

# Descrizione app
Questa descrizione è presa direttamente dalla repository originale dell'app Python: https://github.com/yathishgowdaa/Blog
## FlaskApp

Simple Blog application with authentication and CRUD functionality using the Python Flask micro-framework where user can login post an article, edit the posted article and delete the article. User can read other articles posted by other users as well but not edit or delete.

### Installation

To use this template, your computer needs:

- [Python 2 or 3](https://python.org)
- [Pip Package Manager](https://pypi.python.org/pypi)

### Running the app

```bash
python app.py
```
# Struttura della pipeline
La pipeline è divisa negli *stages* elencati qua sotto.

## Build
Lo stage **Build** ha un solo job chiamato `build-job`. Questo job esegue le seguenti azioni:
- crea un ambiente virtuale di lavoro Python usando `venv`
- attiva l'ambiente virtuale di lavoro
- installa le dipendenze per l'applicazione elencate in `requirements.txt`

Questo job produce come artefatto l'ambiente di lavoro virtuale `venv`, che verrà poi utilizzato durante l'intera pipeline.

## Verify
L'obiettivo di questo stage è di controllare lo stile del codice, e per assicurarsi che il codice segua standard di qualità conformi. Usiamo due diversi job, che vengono eseguiti in parallelo, per effettuare questo controllo.

### prospector
Questo job si occupa di eseguire `Prospector`, uno strumento che controlla lo stile e formattazione, la qualità del codice, ed errori potenziali o di design.

Abbiamo configurato Prospector in modo che ignori le cartelle relative a `venv` e alla cache, poichè sporcano i risultati dell'analisi con dati non affini al nostro lavoro. La configurazione di Prospector è inserita all'interno del file `.prospector.yml`.

Questo job produce come artefatto il file `prospector-report.txt`; anche se questo conterrà errori, la pipeline continuerà ad andare poichè sono errori di stile che non appartengono a una parte di codice scritta da noi.

### bandit
Questo job si occupa di eseguire `Bandit`, uno strumento che cerca vulnerabilità di sicurezza nel codice. 

Abbiamo configurato Bandit in modo che ignori le cartelle relative a `venv` e alla cache, sempre per lo stesso motivo. La configurazione di Bandit è inserita all'interno del file `.bandit.yaml`.

Questo job produce come artefatto il file `bandit-report.html`; come nel job `prospector`, anche se verranno visualizzati degli errori, questi non verranno corretti poichè non appartengono a una parte di codice scritta da noi.

## Test
L'obiettivo di questo stage è di verificare il funzionamento corretto delle singole funzionalità CRUD dell'app. Sono state dunque verificate le seguenti funzionalità e nel seguente modo.

Per ogni test che richiede un articolo, abbiamo fatto in modo che la lunghezza del *body* fosse almeno di 30 caratteri, il minimo consentito dall'applicazione Flask.

### test_read_articles
Questa funzione testa la funzionalità Read dell'app. Innanzitutto, viene simulata una query al database in modo che restituisca una lista con un articolo fittizio. 
Quindi, viene effettuata una richiesta GET a `/articles`.
Verifichiamo che la risposta sia `200`, ovvero di successo, e che la pagina HTML contenga il titolo dell'articolo fittizio.

### test_create_article
Questa funzione testa la funzionalità Create dell'app.
Innanzitutto, viene simulato un login al database. Quindi, viene effettuata una richiesta POST a `/add_article`, e aggiungiamo un nuovo articolo al database. 
Verifichiamo che la risposta sia `200`, ovvero di successo, e che la funzione di inserimento nel database sia stata inviata.

### test_update_article
Questa funzione testa la funzionalità Update dell'app. 
Innanzitutto, viene simulata una query al database in modo che restituisca una lista con un articolo fittizio.
Quindi, simuliamo un login al database, ed effettuiamo una richiesta POST a `/edit_article/{article_id}`, per modificare i dati dell'articolo esistente.
Verifichiamo che la risposta sia `200`, ovvero di successo, e che la query SQL di aggiornamento del database sia stata inviata.

### test_delete_article
Questa funzione testa la funzionalità Delete dell'app.
Innanzitutto, simuliamo due risultati del database: prima, che restituisce l'articolo e poi che restituisca `None`, per simulare che non trova più l'articolo dopo l'eliminazione.
Viene simulato un login al database, e viene inviata una richiesta POST a `/delete_article/{article_id}`.
Quindi, verifichiamo che la risposta sia `200`, ovvero di successo, e che la query SQL per l'eliminazione dal database sia stata effettivamente inviata.

## Package
Nello stage Package, viene creato un pacchetto installabile dell'applicazione. 
Questo pacchetto viene creato secondo le specifiche che abbiamo inserito in `setup.py`. Questo file specifica dati del pacchetto (nome, versione, autori, etc), e le dipendenze necessarie.
In questa fase, vengono creati all'interno della cartella `dist/` due file:
- Un pacchetto sorgente che contiene il codice sorgente ed altri file necessari; i file che devono essere inclusi sono specificati nel file `MANIFEST.in`
- Un pacchetto `wheel` che contiene il codice pre-impacchettato

## Release
Nello stage Release, rendiamo disponibile il pacchetto sul Python Package Index (PyPI), per renderlo installabile tramite `pip`. Per farlo, abbiamo creato un account su PyPI, e inserito su GitLab come variabili segrete l'username e token di accesso per `twine`. 
Carichiamo ciò che è all'interno della cartella `dist/` tramite `twine`.

## Docs
Nello stage Docs, rendiamo disponibile la documentazione dell'applicazione al sito [GitLab Pages]{}. Questo viene effettuato tramite lo strumento `mkdocs`; lo stage crea un artefatto che contiene un sito web contenente tutta la documentazione.
Visto che volevamo aggiungere il README.md del progetto nella documentazione, ma `mkdocs` può aggiungere i file presenti soltanto nella cartella `docs/`, durante il job copiamo il file dalla root della repository alla cartella `docs/`, per poi essere aggiunto all'interno della documentazione.