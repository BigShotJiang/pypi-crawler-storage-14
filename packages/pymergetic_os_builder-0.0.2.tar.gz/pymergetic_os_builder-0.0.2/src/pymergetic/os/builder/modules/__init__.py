"""OS builder modules/plugins."""

from pathlib import Path
from typing import Protocol, Optional


class Module(Protocol):
    """Protocol for OS builder modules."""
    
    name: str
    description: str
    
    def install(self, chroot_dir: Path) -> None:
        """Install this module into the chroot."""
        ...
    
    def get_assets(self) -> Optional[Path]:
        """Return path to assets directory, or None."""
        ...

