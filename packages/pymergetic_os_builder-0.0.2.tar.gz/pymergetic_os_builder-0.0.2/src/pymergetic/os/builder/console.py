"""Console output utilities using Rich library.

This module provides a centralized console interface for all output operations
using the Rich library. It provides consistent styling, progress bars, tables,
and status messages throughout the OS builder.

Example:
    Print a status message:
        console.status("Installing packages...")
    
    Print success message:
        console.success("Build complete!")
    
    Create a progress bar:
        with console.progress() as progress:
            task = progress.add_task("Installing...", total=100)
"""

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

# Global console instance
console = Console()


def print_header(title: str, subtitle: str = None) -> None:
    """Print a formatted header with title and optional subtitle.
    
    Args:
        title: Main header title.
        subtitle: Optional subtitle text.
    """
    text = Text(title, style="bold bright_blue")
    if subtitle:
        text.append(f"\n{subtitle}", style="dim")
    console.print(Panel(text, box=box.ROUNDED, border_style="blue"))


def print_success(message: str) -> None:
    """Print a success message.
    
    Args:
        message: Success message to display.
    """
    console.print(f"[bold green]✓[/bold green] {message}")


def print_error(message: str) -> None:
    """Print an error message.
    
    Args:
        message: Error message to display.
    """
    console.print(f"[bold red]✗[/bold red] {message}")


def print_warning(message: str) -> None:
    """Print a warning message.
    
    Args:
        message: Warning message to display.
    """
    console.print(f"[bold yellow]⚠[/bold yellow] {message}")


def print_info(message: str) -> None:
    """Print an informational message.
    
    Args:
        message: Info message to display.
    """
    console.print(f"[cyan]ℹ[/cyan] {message}")


def print_step(step: str, message: str) -> None:
    """Print a build step message.
    
    Args:
        step: Step identifier (e.g., "CHECK", "BUILD", "ISO").
        message: Step description.
    """
    console.print(f"[bold cyan][{step}][/bold cyan] {message}")


def print_command(cmd: list[str]) -> None:
    """Print a command being executed.
    
    Args:
        cmd: Command and arguments as a list.
    """
    console.print(f"[dim]→[/dim] [yellow]{' '.join(cmd)}[/yellow]")


def create_progress() -> Progress:
    """Create a progress bar instance.
    
    Returns:
        Progress: Configured progress bar with spinner and task columns.
    
    Example:
        with create_progress() as progress:
            task = progress.add_task("Installing...", total=100)
            progress.update(task, advance=50)
    """
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    )


def create_info_table(title: str, data: dict[str, str]) -> Table:
    """Create a formatted information table.
    
    Args:
        title: Table title.
        data: Dictionary of key-value pairs to display.
    
    Returns:
        Table: Formatted Rich table.
    
    Example:
        table = create_info_table("Build Info", {
            "Release": "trixie",
            "Architecture": "amd64"
        })
        console.print(table)
    """
    table = Table(title=title, box=box.ROUNDED, show_header=False)
    table.add_column("Key", style="cyan", no_wrap=True)
    table.add_column("Value", style="bright_white")
    
    for key, value in data.items():
        table.add_row(key, value)
    
    return table

