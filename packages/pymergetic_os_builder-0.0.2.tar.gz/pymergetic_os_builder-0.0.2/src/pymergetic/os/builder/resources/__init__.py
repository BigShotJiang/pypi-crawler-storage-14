"""Resource files for OS builder."""

