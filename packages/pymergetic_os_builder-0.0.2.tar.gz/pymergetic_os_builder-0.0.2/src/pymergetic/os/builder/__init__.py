"""PymergeticOS Builder - Modular OS building system."""

from .__project__ import __version__, __package_name__
