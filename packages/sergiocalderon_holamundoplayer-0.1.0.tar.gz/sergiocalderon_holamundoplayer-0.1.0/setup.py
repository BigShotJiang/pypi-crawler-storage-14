import setuptools
from pathlib import Path


long_desc = Path("README.md").read_text("utf-8")
setuptools.setup(
    name="sergiocalderon-holamundoplayer",
    version="0.1.0",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(
        exclude=["mocks", "tests"]
    )
)
