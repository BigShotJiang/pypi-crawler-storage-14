# HolaMundoPlayer

HolaMundoPlayer es un paquete Python sencillo que provee una clase `Player` para demostrar
la estructura de un paquete y cómo usarlo desde PyPI. Es ideal como proyecto de ejemplo
para aprender a publicar paquetes en PyPI y cómo organizar un paquete Python mínimo.

**Características**
- **Reproductor simple**: clase `Player` con métodos `play` y `stop`.
- **Empaquetado**: listo para publicarse en PyPI (nombre del paquete usado en `setup.py`).

**Instalación**

Instala la última versión desde PyPI (paquete publicado como `sergiocalderon-holamundoplayer`):

```bash
pip install sergiocalderon-holamundoplayer
```

Si estás instalando desde el código fuente en este repositorio, usa:

```bash
pip install .
```

**Uso básico**

Ejemplo mínimo de uso importando la clase `Player`:

```python
from holamundoplayer.player import Player

player = Player()
player.play('ruta/a/mi/cancion.mp3')  # muestra 'reproduciendo cancion'
player.stop()
```

El módulo principal se encuentra en `holamundoplayer/player.py` y contiene la clase `Player`.

**Publicación en PyPI**

El paquete está configurado en `setup.py` con el nombre `sergiocalderon-holamundoplayer`.
Si quieres actualizar la versión publicada en PyPI, los pasos típicos son:

```bash
# aumentar la versión en setup.py
python -m build
python -m twine upload dist/*
```

Revisa la documentación oficial de PyPI y `twine` si no has publicado antes.

**Licencia y autor**

- **Autor**: Sergio Calderón
- **Licencia**: revisa el archivo `LICENSE` en este repositorio.

Si quieres que agregue más ejemplos (por ejemplo reproducir archivos reales, integración con audio), dímelo y lo expando.