"""Startup scripts distributed with the driver."""

