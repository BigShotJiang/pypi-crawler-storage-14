# -*- coding: utf-8 -*-
"""
Created on Sun May 26 01:14:16 2024

@author: XGKJ
"""
import socket
import os,re

def conv_ip(ip):
    ip_i = []
    data_buf = 0
    for i in range(len(ip)):
        
        if (ip[i] == '.' ):
            ip_i.append(data_buf)
            data_buf = 0
        elif i+1 == len(ip):
            data_buf = data_buf*10 + int(ip[i])
            ip_i.append(data_buf)
            data_buf = 0
        else:
            data_buf = data_buf*10 + int(ip[i])
    return ip_i

def get_ip():  
    result = os.popen('ipconfig')  
    res = result.read()  
    resultlist = re.findall('''(?<=以太网适配器 ).*?(?=:)''', res)  
    return resultlist 

def reboot():
    net_cmd = f"shutdown -r -f -t 0"
    os.system(net_cmd) 
def shutdown():
    net_cmd = f"shutdown -s -f -t 0"
    os.system(net_cmd) 
    
print('Version : V1.0-20250329')
# file_r = open('C:\systemq\startup\dev_sn.txt','r')
file_r = open('./dev_sn', 'r') #2025.11.27修改
sn = file_r.read()
print('sn : ',sn)
ip_list = get_ip()
net_name = f'"{ip_list[0]}"'
print('net name : ',net_name)
address_r = ('', 10130)



r_meg = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
r_meg.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
r_meg.settimeout(1)
r_meg.bind(address_r)

address_recv = []

print(' recv meg')


while True:

    try:
        data,address = r_meg.recvfrom(1024)
        ip_bufe = conv_ip(address[0])
        # ip_i = f'{ip_bufe[0]}.{ip_bufe[1]}.{ip_bufe[2]}.{255}'
        # print('接收数据：',data,address)
        ip_i = '255.255.255.255'
        if data == b'Who is XGM MDS24?':
            message = f'I am XGM MDS24! sn : {sn}'
            message = message.encode('utf-8')
            print(data,address)
            address = (ip_i, 10130)
            s_meg = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s_meg.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            s_meg.sendto(message, address)
            s_meg.close()
        elif data[:16] == b'set device ip : ':
            data_decode = data.decode('utf-8')
            start_index = data_decode.find(":") + 2
            end_index = data_decode.find(",", start_index)
            dev_sn = data_decode[start_index:end_index]
            #dev_sn = data_decode[16:24]
            print(data,address)
            if sn == dev_sn:
                #code_start_n = 25
                code_start_n = end_index + 1
                code_n = code_start_n
                c_n = 0
                dev_ip = [[],[],[]]
                for i in range(int(len(data_decode)-code_start_n)):
                    if data_decode[code_start_n+i] == ',':
                        dev_ip[c_n] = data_decode[code_n:code_start_n+i]
                        c_n += 1
                        code_n = code_start_n + i + 1

                net_cmd = f"netsh interface ip set address name={net_name} static {dev_ip[0]} {dev_ip[1]} {dev_ip[2]}"
                result = os.system(net_cmd)
                if result == 0:
                    print('set ip ok!')
                else:
                    print('set ip err!')
        elif data[:18] == b'shutdown device : ':
            data_decode = data.decode('utf-8')
            dev_sn = data_decode[18:]
            print(data,address)
            if sn == dev_sn:
                print('shutdown !!!',dev_sn)
                shutdown()

        elif data[:16] == b'reboot device : ':
            data_decode = data.decode('utf-8')
            dev_sn = data_decode[16:]
            print(data,address)
            if sn == dev_sn:
                print('reboot !!!',dev_sn)
                reboot()


    except:
        address_recv = 0
        ip_i = 0

print(address_recv)
print(' end')

# 关闭socket
r_meg.close()

