
from .mds24_driver import fpgadev as mds24

from .xgm_qa24_driver import fpgadev as qa24