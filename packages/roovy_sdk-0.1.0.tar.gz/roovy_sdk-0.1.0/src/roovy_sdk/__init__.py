"""Roovy SDK - Python SDK for generating WhatsApp Flows using LLMs."""

from roovy_sdk.client import RoovyClient
from roovy_sdk.schema import (
    WhatsAppFlow,
    Screen,
    SingleColumnLayout,
    Form,
    Component,
    DataSourceItem,
    validate_flow,
    # Text components
    TextHeading,
    TextSubheading,
    TextBody,
    TextCaption,
    # Input components
    TextInput,
    TextArea,
    Dropdown,
    RadioButtonsGroup,
    ChipsSelector,
    CheckboxGroup,
    OptIn,
    # Date/Media components
    CalendarPicker,
    DatePicker,
    PhotoPicker,
    DocumentPicker,
    Image,
    # Navigation components
    Footer,
    Button,
    EmbeddedLink,
    # Conditional components
    IfConditional,
    SwitchConditional,
    # Actions
    NavigateAction,
    CompleteAction,
    OpenUrlAction,
)

__version__ = "0.1.0"

__all__ = [
    # Main client
    "RoovyClient",
    # Core types
    "WhatsAppFlow",
    "Screen",
    "SingleColumnLayout",
    "Form",
    "Component",
    "DataSourceItem",
    "validate_flow",
    # Text components
    "TextHeading",
    "TextSubheading",
    "TextBody",
    "TextCaption",
    # Input components
    "TextInput",
    "TextArea",
    "Dropdown",
    "RadioButtonsGroup",
    "ChipsSelector",
    "CheckboxGroup",
    "OptIn",
    # Date/Media components
    "CalendarPicker",
    "DatePicker",
    "PhotoPicker",
    "DocumentPicker",
    "Image",
    # Navigation components
    "Footer",
    "Button",
    "EmbeddedLink",
    # Conditional components
    "IfConditional",
    "SwitchConditional",
    # Actions
    "NavigateAction",
    "CompleteAction",
    "OpenUrlAction",
]
