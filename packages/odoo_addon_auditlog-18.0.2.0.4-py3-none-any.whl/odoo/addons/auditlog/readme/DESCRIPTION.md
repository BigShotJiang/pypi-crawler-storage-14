This module allows the administrator to log user operations performed on
data models such as `create`, `read`, `write` and `delete`.
