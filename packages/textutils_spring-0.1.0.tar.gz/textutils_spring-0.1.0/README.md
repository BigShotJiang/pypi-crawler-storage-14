# textutils

Simple beginner-friendly text utilities package:
- Reverse strings
- Count characters and words
- Create URL-friendly slugs
- Convert strings to uppercase
