from .reverse import reverse_text
from .count import count_chars, count_words
from .slugify import slugify
from .uppercase import to_uppercase

__all__ = [
    "reverse_text",
    "count_chars",
    "count_words",
    "slugify",
    "to_uppercase"
]
