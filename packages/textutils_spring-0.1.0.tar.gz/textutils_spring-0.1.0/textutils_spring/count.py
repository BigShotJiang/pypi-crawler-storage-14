def count_chars(s: str) -> int:
    return len(s)

def count_words(s: str) -> int:
    return len(s.split())
