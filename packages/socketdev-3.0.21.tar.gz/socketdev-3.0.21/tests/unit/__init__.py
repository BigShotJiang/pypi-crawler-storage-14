# Unit tests for Socket SDK Python client
