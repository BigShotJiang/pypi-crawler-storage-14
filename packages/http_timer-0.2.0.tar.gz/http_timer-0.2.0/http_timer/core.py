"""Core timing functionality."""

import json as json_module
import socket
import ssl
import time
from dataclasses import dataclass, field
from http.client import HTTPConnection, HTTPSConnection, HTTPResponse
from urllib.parse import urlparse
from urllib.error import HTTPError


@dataclass
class TimingResult:
    """Result of a timed HTTP request."""

    total_ms: float
    status: int
    size_bytes: int
    headers: dict
    dns_ms: float = 0.0
    connect_ms: float = 0.0
    tls_ms: float = 0.0
    transfer_ms: float = 0.0

    def __str__(self):
        parts = [f"total={self.total_ms:.1f}ms"]
        if self.dns_ms > 0:
            parts.append(f"dns={self.dns_ms:.1f}ms")
        if self.connect_ms > 0:
            parts.append(f"connect={self.connect_ms:.1f}ms")
        if self.tls_ms > 0:
            parts.append(f"tls={self.tls_ms:.1f}ms")
        if self.transfer_ms > 0:
            parts.append(f"transfer={self.transfer_ms:.1f}ms")
        parts.append(f"status={self.status}")
        parts.append(f"size={self.size_bytes}B")
        return " | ".join(parts)


class _TimingCollector:
    """Collects timing data during request execution."""

    def __init__(self):
        self.dns_start = 0
        self.dns_end = 0
        self.connect_start = 0
        self.connect_end = 0
        self.tls_start = 0
        self.tls_end = 0
        self.transfer_start = 0
        self.transfer_end = 0

    @property
    def dns_ms(self):
        return (self.dns_end - self.dns_start) * 1000 if self.dns_end else 0

    @property
    def connect_ms(self):
        return (self.connect_end - self.connect_start) * 1000 if self.connect_end else 0

    @property
    def tls_ms(self):
        return (self.tls_end - self.tls_start) * 1000 if self.tls_end else 0

    @property
    def transfer_ms(self):
        return (self.transfer_end - self.transfer_start) * 1000 if self.transfer_end else 0


def _resolve_host(hostname, port, collector):
    """Resolve hostname and measure DNS time."""
    collector.dns_start = time.perf_counter()
    try:
        result = socket.getaddrinfo(hostname, port, socket.AF_UNSPEC, socket.SOCK_STREAM)
        collector.dns_end = time.perf_counter()
        return result[0] if result else None
    except socket.gaierror:
        collector.dns_end = time.perf_counter()
        raise


def _create_connection(address, timeout, collector):
    """Create socket connection and measure connect time."""
    family, socktype, proto, canonname, sockaddr = address

    collector.connect_start = time.perf_counter()
    sock = socket.socket(family, socktype, proto)
    sock.settimeout(timeout)
    sock.connect(sockaddr)
    collector.connect_end = time.perf_counter()

    return sock


def _wrap_tls(sock, hostname, collector):
    """Wrap socket with TLS and measure handshake time."""
    context = ssl.create_default_context()

    collector.tls_start = time.perf_counter()
    wrapped = context.wrap_socket(sock, server_hostname=hostname)
    collector.tls_end = time.perf_counter()

    return wrapped


def _timed_request(method, url, headers=None, json=None, data=None, timeout=30):
    """
    Execute a timed HTTP request with detailed timing breakdown.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE)
        url: Target URL
        headers: Optional dict of headers
        json: Optional dict to send as JSON body
        data: Optional bytes to send as body
        timeout: Request timeout in seconds (default: 30)

    Returns:
        Tuple of (response_body, TimingResult)
    """
    parsed = urlparse(url)
    is_https = parsed.scheme == "https"
    hostname = parsed.hostname
    port = parsed.port or (443 if is_https else 80)
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"

    req_headers = headers.copy() if headers else {}
    req_headers.setdefault("Host", hostname)
    req_headers.setdefault("User-Agent", "http-timer/0.2.0")
    req_headers.setdefault("Accept", "*/*")
    req_headers.setdefault("Connection", "close")

    body = None
    if json is not None:
        body = json_module.dumps(json).encode("utf-8")
        req_headers.setdefault("Content-Type", "application/json")
        req_headers["Content-Length"] = str(len(body))
    elif data is not None:
        body = data if isinstance(data, bytes) else data.encode("utf-8")
        req_headers["Content-Length"] = str(len(body))

    collector = _TimingCollector()
    start_total = time.perf_counter()

    try:
        # DNS resolution
        address = _resolve_host(hostname, port, collector)

        # TCP connection
        sock = _create_connection(address, timeout, collector)

        # TLS handshake (if HTTPS)
        if is_https:
            sock = _wrap_tls(sock, hostname, collector)

        # Send request
        request_line = f"{method} {path} HTTP/1.1\r\n"
        header_lines = "".join(f"{k}: {v}\r\n" for k, v in req_headers.items())
        request_bytes = (request_line + header_lines + "\r\n").encode("utf-8")

        sock.sendall(request_bytes)
        if body:
            sock.sendall(body)

        # Read response
        collector.transfer_start = time.perf_counter()

        # Read response using HTTPResponse for proper parsing
        response = HTTPResponse(sock)
        response.begin()

        response_body = response.read()
        collector.transfer_end = time.perf_counter()

        end_total = time.perf_counter()

        timing = TimingResult(
            total_ms=(end_total - start_total) * 1000,
            status=response.status,
            size_bytes=len(response_body),
            headers=dict(response.headers),
            dns_ms=collector.dns_ms,
            connect_ms=collector.connect_ms,
            tls_ms=collector.tls_ms,
            transfer_ms=collector.transfer_ms,
        )

        sock.close()
        return response_body, timing

    except Exception as e:
        end_total = time.perf_counter()

        # Try to extract status from exception if possible
        status = getattr(e, "code", 0) or getattr(e, "status", 0)

        timing = TimingResult(
            total_ms=(end_total - start_total) * 1000,
            status=status,
            size_bytes=0,
            headers={},
            dns_ms=collector.dns_ms,
            connect_ms=collector.connect_ms,
            tls_ms=collector.tls_ms,
            transfer_ms=collector.transfer_ms,
        )

        raise


def timed_get(url, headers=None, timeout=30):
    """
    Execute a timed GET request.

    Args:
        url: Target URL
        headers: Optional dict of headers
        timeout: Request timeout in seconds (default: 30)

    Returns:
        Tuple of (response_body, TimingResult)
    """
    return _timed_request("GET", url, headers=headers, timeout=timeout)


def timed_post(url, headers=None, json=None, data=None, timeout=30):
    """
    Execute a timed POST request.

    Args:
        url: Target URL
        headers: Optional dict of headers
        json: Optional dict to send as JSON body
        data: Optional bytes to send as body
        timeout: Request timeout in seconds (default: 30)

    Returns:
        Tuple of (response_body, TimingResult)
    """
    return _timed_request("POST", url, headers=headers, json=json, data=data, timeout=timeout)


def timed_put(url, headers=None, json=None, data=None, timeout=30):
    """
    Execute a timed PUT request.

    Args:
        url: Target URL
        headers: Optional dict of headers
        json: Optional dict to send as JSON body
        data: Optional bytes to send as body
        timeout: Request timeout in seconds (default: 30)

    Returns:
        Tuple of (response_body, TimingResult)
    """
    return _timed_request("PUT", url, headers=headers, json=json, data=data, timeout=timeout)


def timed_delete(url, headers=None, timeout=30):
    """
    Execute a timed DELETE request.

    Args:
        url: Target URL
        headers: Optional dict of headers
        timeout: Request timeout in seconds (default: 30)

    Returns:
        Tuple of (response_body, TimingResult)
    """
    return _timed_request("DELETE", url, headers=headers, timeout=timeout)
