"""A minimal, zero-dependency library for timing HTTP requests."""

from .core import timed_get, timed_post, timed_put, timed_delete, TimingResult

__version__ = "0.2.0"
__all__ = ["timed_get", "timed_post", "timed_put", "timed_delete", "TimingResult"]
