"""Basic tests for http-timer."""

import pytest
from http_timer import timed_get, timed_post, TimingResult


class TestTimedGet:
    def test_returns_tuple(self):
        body, timing = timed_get("https://httpbin.org/get")
        assert isinstance(body, bytes)
        assert isinstance(timing, TimingResult)

    def test_total_ms_positive(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert timing.total_ms > 0

    def test_status_code(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert timing.status == 200

    def test_size_bytes(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert timing.size_bytes > 0

    def test_headers_returned(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert isinstance(timing.headers, dict)
        assert len(timing.headers) > 0

    def test_custom_headers(self):
        body, _ = timed_get(
            "https://httpbin.org/headers",
            headers={"X-Custom-Header": "test-value"}
        )
        assert b"X-Custom-Header" in body


class TestTimedPost:
    def test_post_json(self):
        body, timing = timed_post(
            "https://httpbin.org/post",
            json={"name": "test", "value": 123}
        )
        assert timing.status == 200
        assert b'"name": "test"' in body

    def test_post_data(self):
        body, timing = timed_post(
            "https://httpbin.org/post",
            data=b"raw data here"
        )
        assert timing.status == 200


class TestErrorHandling:
    def test_404_status(self):
        _, timing = timed_get("https://httpbin.org/status/404")
        assert timing.status == 404
        assert timing.total_ms > 0

    def test_500_status(self):
        _, timing = timed_get("https://httpbin.org/status/500")
        assert timing.status == 500
        assert timing.total_ms > 0


class TestDetailedTiming:
    def test_dns_ms_positive(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert timing.dns_ms >= 0  # Can be 0 if cached

    def test_connect_ms_positive(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert timing.connect_ms > 0

    def test_tls_ms_positive_for_https(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert timing.tls_ms > 0

    def test_transfer_ms_positive(self):
        _, timing = timed_get("https://httpbin.org/get")
        assert timing.transfer_ms > 0

    def test_timing_breakdown_sums_correctly(self):
        _, timing = timed_get("https://httpbin.org/get")
        # Sum of parts should be <= total (some overhead expected)
        parts_sum = timing.dns_ms + timing.connect_ms + timing.tls_ms + timing.transfer_ms
        assert parts_sum <= timing.total_ms * 1.1  # Allow 10% margin

    def test_str_representation(self):
        _, timing = timed_get("https://httpbin.org/get")
        timing_str = str(timing)
        assert "total=" in timing_str
        assert "status=" in timing_str
        assert "size=" in timing_str
