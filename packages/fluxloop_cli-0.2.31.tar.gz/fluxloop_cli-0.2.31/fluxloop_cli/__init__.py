"""
FluxLoop CLI - Command-line interface for running agent simulations.
"""

__version__ = "0.2.31"

from .main import app

__all__ = ["app"]
