import os
import requests
import zipfile

def download_f_ide():
    url = "https://your-domain.com/download/FIDE.zip"
    file_name = "FIDE.zip"

    print("🔽 Downloading F Programming Language...")

    r = requests.get(url)
    with open(file_name, "wb") as f:
        f.write(r.content)

    print("📦 Extracting Files...")
    install_path = "C:/FIDE"

    with zipfile.ZipFile(file_name, "r") as zip_ref:
        zip_ref.extractall(install_path)

    print(f"✅ Installed Successfully at {install_path}")
