from .downloader import download_f_ide

def main():
    print("⚙️ Installing F Language...")
    download_f_ide()
