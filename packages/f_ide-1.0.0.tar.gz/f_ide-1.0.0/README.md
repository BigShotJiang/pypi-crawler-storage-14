# F IDE Installer

This package installs the **F Programming Language** on Windows.

## Installation

```
pip install f-ide
```

## Run installer

```
f-ide
```
