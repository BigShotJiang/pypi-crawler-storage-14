#!/usr/bin/env python
"""
radia_tetra_mesh.py - Volume-based tetrahedral mesh solver for Radia

This module provides a specialized solver for tetrahedral meshes with linear
magnetic materials and background fields. It uses surface-based field computation
to correctly handle interior face cancellation.

Key features:
- Surface extraction: Only external faces are used for field computation
- Interior faces automatically cancel (volume-based approach)
- Relaxation method for linear material problems
- Compatible with NGSolve/Netgen tetrahedral meshes

Author: Radia Development Team
Created: 2025-11-27
Version: 0.1.0

Example
-------
>>> from ngsolve import Mesh
>>> from netgen.occ import Box, OCCGeometry
>>> import radia as rad
>>> import radia_tetra_mesh as rtm
>>>
>>> rad.FldUnits('m')
>>> geo = OCCGeometry(Box((-0.5, -0.5, -0.5), (0.5, 0.5, 0.5)))
>>> mesh = Mesh(geo.GenerateMesh(maxh=0.2))
>>>
>>> # Solve with linear material in background field
>>> mu_0 = 4 * np.pi * 1e-7
>>> result = rtm.solve_linear_material(
...     mesh,
...     chi=99.0,  # mu_r - 1
...     background_B=[0, 0, mu_0 * 1.0],  # H0 = 1 A/m
...     precision=0.0001,
...     max_iter=10000
... )
"""

import numpy as np
import radia as rad
from ngsolve import VOL, ET


# Tetrahedral face topology (0-indexed vertices)
# v0, v1, v2, v3 are the 4 vertices of the tetrahedron
TETRA_FACE_VERTICES = [
    (0, 2, 1),  # Face 0: opposite to v3
    (0, 1, 3),  # Face 1: opposite to v2
    (1, 2, 3),  # Face 2: opposite to v0
    (2, 0, 3)   # Face 3: opposite to v1
]


def extract_surface_faces(mesh, material_filter=None, verbose=True):
    """
    Extract external surface faces from tetrahedral mesh.

    Interior faces (shared by two tetrahedra) are identified and excluded.
    Only external (boundary) faces are returned.

    Parameters
    ----------
    mesh : ngsolve.Mesh
        Input tetrahedral mesh from Netgen/NGSolve
    material_filter : str or list, optional
        Filter elements by material name(s)
    verbose : bool, default=True
        Print progress information

    Returns
    -------
    dict
        {
            'surface_faces': list of dict
                Each face: {
                    'vertices': [[x1,y1,z1], [x2,y2,z2], [x3,y3,z3]],
                    'normal': [nx, ny, nz],
                    'area': float,
                    'centroid': [cx, cy, cz],
                    'element_idx': int,  # Parent element index
                    'local_face_idx': int  # Face index within tetrahedron (0-3)
                }
            'elements': list of dict
                Each element: {
                    'vertices': [[x1,y1,z1], ..., [x4,y4,z4]],
                    'centroid': [cx, cy, cz],
                    'volume': float,
                    'surface_face_indices': list  # Indices into surface_faces
                }
            'interior_face_count': int
            'surface_face_count': int
        }
    """
    # Normalize material_filter
    if material_filter is None:
        allowed_materials = None
    elif isinstance(material_filter, str):
        allowed_materials = {material_filter}
    else:
        allowed_materials = set(material_filter)

    # First pass: collect all elements and their faces
    elements = []
    face_dict = {}  # Key: sorted vertex indices, Value: list of (element_idx, local_face_idx)

    for el_idx, el in enumerate(mesh.Elements(VOL)):
        if el.type != ET.TET:
            raise ValueError(f"Element {el_idx} is not tetrahedral (type={el.type})")

        if allowed_materials is not None:
            if el.mat not in allowed_materials:
                continue

        # Get vertex coordinates
        vert_node_ids = el.vertices
        vertices = []
        for v_node in vert_node_ids:
            v = mesh.vertices[v_node.nr]
            coord = v.point
            vertices.append([coord[0], coord[1], coord[2]])

        # Compute centroid
        centroid = [
            sum(v[0] for v in vertices) / 4.0,
            sum(v[1] for v in vertices) / 4.0,
            sum(v[2] for v in vertices) / 4.0
        ]

        # Compute volume (1/6 * |det([v1-v0, v2-v0, v3-v0])|)
        v0, v1, v2, v3 = [np.array(v) for v in vertices]
        vol = abs(np.dot(v1 - v0, np.cross(v2 - v0, v3 - v0))) / 6.0

        el_data = {
            'vertices': vertices,
            'centroid': centroid,
            'volume': vol,
            'vertex_indices': [v_node.nr for v_node in vert_node_ids],
            'surface_face_indices': []
        }
        elements.append(el_data)

        current_el_idx = len(elements) - 1

        # Process each face
        for local_face_idx, face_verts in enumerate(TETRA_FACE_VERTICES):
            # Get global vertex indices for this face
            global_verts = tuple(sorted([el_data['vertex_indices'][i] for i in face_verts]))

            if global_verts not in face_dict:
                face_dict[global_verts] = []
            face_dict[global_verts].append((current_el_idx, local_face_idx))

    # Second pass: identify surface faces (appear only once)
    surface_faces = []
    interior_face_count = 0

    for global_verts, occurrences in face_dict.items():
        if len(occurrences) == 1:
            # Surface face
            el_idx, local_face_idx = occurrences[0]
            el_data = elements[el_idx]

            # Get face vertex coordinates
            face_vert_indices = TETRA_FACE_VERTICES[local_face_idx]
            face_vertices = [el_data['vertices'][i] for i in face_vert_indices]

            # Compute face normal and area
            v0, v1, v2 = [np.array(v) for v in face_vertices]
            edge1 = v1 - v0
            edge2 = v2 - v0
            normal_vec = np.cross(edge1, edge2)
            area = np.linalg.norm(normal_vec) / 2.0

            if area > 1e-15:
                normal_unit = normal_vec / (2.0 * area)
            else:
                normal_unit = np.array([0.0, 0.0, 1.0])

            # Ensure normal points outward (away from element centroid)
            face_centroid = (v0 + v1 + v2) / 3.0
            el_centroid = np.array(el_data['centroid'])
            outward = face_centroid - el_centroid
            if np.dot(normal_unit, outward) < 0:
                normal_unit = -normal_unit

            face_data = {
                'vertices': face_vertices,
                'normal': normal_unit.tolist(),
                'area': area,
                'centroid': face_centroid.tolist(),
                'element_idx': el_idx,
                'local_face_idx': local_face_idx
            }

            face_idx = len(surface_faces)
            surface_faces.append(face_data)
            el_data['surface_face_indices'].append(face_idx)

        elif len(occurrences) == 2:
            # Interior face - skip
            interior_face_count += 1
        else:
            # Should not happen in valid mesh
            raise ValueError(f"Face with {len(occurrences)} occurrences (expected 1 or 2)")

    if verbose:
        print(f"[Surface Extraction]")
        print(f"  Total elements: {len(elements)}")
        print(f"  Total faces: {len(face_dict)}")
        print(f"  Surface faces: {len(surface_faces)}")
        print(f"  Interior faces: {interior_face_count} (excluded)")

    return {
        'surface_faces': surface_faces,
        'elements': elements,
        'interior_face_count': interior_face_count,
        'surface_face_count': len(surface_faces)
    }


def compute_h_field_from_surface_charge(obs_point, faces, magnetizations, element_map):
    """
    Compute H field at observation point from surface magnetic charges.

    The surface charge density on each face is sigma = M . n, where M is the
    magnetization of the parent element and n is the outward face normal.

    Parameters
    ----------
    obs_point : array-like
        Observation point [x, y, z]
    faces : list
        List of surface face dictionaries
    magnetizations : ndarray
        Magnetization vectors for each element, shape (n_elements, 3)
    element_map : list
        Maps face index to parent element index

    Returns
    -------
    ndarray
        H field vector [Hx, Hy, Hz] in A/m
    """
    obs = np.array(obs_point)
    H = np.zeros(3)

    for face_idx, face in enumerate(faces):
        el_idx = face['element_idx']
        M = magnetizations[el_idx]
        n = np.array(face['normal'])

        # Surface charge density: sigma = M . n
        sigma = np.dot(M, n)

        if abs(sigma) < 1e-20:
            continue

        # Face centroid
        face_center = np.array(face['centroid'])

        # Vector from face to observation point
        r_vec = obs - face_center
        r_mag = np.linalg.norm(r_vec)

        if r_mag < 1e-15:
            # Observation point at face centroid - use simplified formula
            # H_local = -sigma / 2 * n (for field inside material)
            continue

        # H = sigma * Area / (4 * pi * r^2) * r_hat
        # This is the monopole approximation for far field
        area = face['area']
        factor = sigma * area / (4.0 * np.pi * r_mag**3)
        H += factor * r_vec

    return H


def compute_interaction_matrix(mesh_data, verbose=True):
    """
    Compute interaction matrix for relaxation solver.

    The interaction matrix A[i,j] gives the H field at element i's centroid
    due to a unit magnetization in element j (through surface charges).

    For linear materials: H_total = A @ M + H_ext

    Parameters
    ----------
    mesh_data : dict
        Output from extract_surface_faces()
    verbose : bool, default=True
        Print progress

    Returns
    -------
    ndarray
        Interaction matrix, shape (3*n_elements, 3*n_elements)
        Organized as [Hx_0, Hy_0, Hz_0, Hx_1, Hy_1, Hz_1, ...]
    """
    elements = mesh_data['elements']
    faces = mesh_data['surface_faces']
    n_elements = len(elements)

    if verbose:
        print(f"[Interaction Matrix]")
        print(f"  Building {3*n_elements} x {3*n_elements} matrix...")

    # For each source element, set unit M in x, y, z directions
    # and compute H at all observation points
    A = np.zeros((3 * n_elements, 3 * n_elements))

    # Progress tracking
    total_ops = n_elements * 3
    progress_interval = max(1, total_ops // 10)

    for src_el in range(n_elements):
        for src_comp in range(3):  # Mx, My, Mz
            col_idx = 3 * src_el + src_comp

            # Unit magnetization in direction src_comp
            M_test = np.zeros((n_elements, 3))
            M_test[src_el, src_comp] = 1.0

            # Compute H at all element centroids
            for obs_el in range(n_elements):
                obs_point = elements[obs_el]['centroid']
                H = compute_h_field_from_surface_charge(obs_point, faces, M_test, None)

                for obs_comp in range(3):
                    row_idx = 3 * obs_el + obs_comp
                    A[row_idx, col_idx] = H[obs_comp]

            if verbose and (col_idx + 1) % progress_interval == 0:
                print(f"  Progress: {100*(col_idx+1)/total_ops:.0f}%")

    if verbose:
        print(f"  Matrix construction complete")

    return A


def solve_linear_material(mesh, chi, background_B, precision=0.0001, max_iter=10000,
                          material_filter=None, relax_param=0.5, verbose=True):
    """
    Solve for magnetization in linear magnetic material with background field.

    Uses relaxation method to solve: M = chi * H_total
    where H_total = H_background + H_demagnetizing(M)

    Parameters
    ----------
    mesh : ngsolve.Mesh
        Input tetrahedral mesh
    chi : float
        Magnetic susceptibility (chi = mu_r - 1)
    background_B : array-like
        Background magnetic field [Bx, By, Bz] in Tesla
    precision : float, default=0.0001
        Convergence precision (relative change in M)
    max_iter : int, default=10000
        Maximum iterations
    material_filter : str or list, optional
        Filter elements by material name
    relax_param : float, default=0.5
        Relaxation parameter (0 < relax_param <= 1)
        Smaller values = more stable but slower convergence
    verbose : bool, default=True
        Print progress information

    Returns
    -------
    dict
        {
            'magnetizations': ndarray, shape (n_elements, 3)
                Final magnetization vectors for each element
            'H_fields': ndarray, shape (n_elements, 3)
                H field at each element centroid
            'iterations': int
                Number of iterations performed
            'converged': bool
                Whether solution converged
            'mesh_data': dict
                Surface extraction data
            'final_residual': float
                Final relative residual
        }
    """
    mu_0 = 4.0 * np.pi * 1e-7

    # Convert background B to H
    B0 = np.array(background_B)
    H0 = B0 / mu_0

    if verbose:
        print("=" * 60)
        print("Volume-based Tetrahedral Mesh Solver")
        print("=" * 60)
        print(f"Parameters:")
        print(f"  chi = {chi} (mu_r = {chi + 1})")
        print(f"  Background H0 = {H0} A/m")
        print(f"  Precision = {precision}")
        print(f"  Max iterations = {max_iter}")
        print()

    # Extract surface faces
    mesh_data = extract_surface_faces(mesh, material_filter=material_filter, verbose=verbose)
    elements = mesh_data['elements']
    faces = mesh_data['surface_faces']
    n_elements = len(elements)

    if n_elements == 0:
        raise ValueError("No elements found in mesh")

    if verbose:
        print()

    # Compute interaction matrix
    A = compute_interaction_matrix(mesh_data, verbose=verbose)

    if verbose:
        print()
        print("[Relaxation Solver]")
        print(f"  Starting iteration...")

    # Initialize magnetizations to chi * H0
    M = np.zeros((n_elements, 3))
    for i in range(n_elements):
        M[i] = chi * H0

    # External field array (same for all elements)
    H_ext = np.tile(H0, n_elements)  # Shape: (3*n_elements,)

    # Relaxation iteration
    converged = False
    final_residual = np.inf

    for iteration in range(max_iter):
        # Flatten M for matrix multiplication
        M_flat = M.flatten()

        # Compute H_total = A @ M + H_ext
        H_demag = A @ M_flat
        H_total = H_demag + H_ext

        # Compute new M from material relation: M_new = chi * H_total
        M_new_flat = chi * H_total
        M_new = M_new_flat.reshape((n_elements, 3))

        # Apply relaxation
        M_update = (1.0 - relax_param) * M + relax_param * M_new

        # Check convergence
        dM = M_update - M
        residual = np.sqrt(np.sum(dM**2) / n_elements)
        M_norm = np.sqrt(np.sum(M**2) / n_elements)

        if M_norm > 1e-15:
            rel_residual = residual / M_norm
        else:
            rel_residual = residual

        M = M_update
        final_residual = rel_residual

        if verbose and (iteration + 1) % 100 == 0:
            print(f"    Iter {iteration+1}: residual = {rel_residual:.6e}")

        if rel_residual < precision:
            converged = True
            if verbose:
                print(f"    Converged at iteration {iteration+1}")
            break

    if not converged and verbose:
        print(f"    [WARNING] Did not converge after {max_iter} iterations")
        print(f"    Final residual: {final_residual:.6e}")

    # Compute final H fields
    H_fields = np.zeros((n_elements, 3))
    M_flat = M.flatten()
    H_demag = A @ M_flat
    for i in range(n_elements):
        H_fields[i] = H_demag[3*i:3*i+3] + H0

    if verbose:
        print()
        print("[Results]")
        # Average M and H
        M_avg = np.mean(M, axis=0)
        H_avg = np.mean(H_fields, axis=0)
        print(f"  Average M: ({M_avg[0]:.6f}, {M_avg[1]:.6f}, {M_avg[2]:.6f}) A/m")
        print(f"  Average H: ({H_avg[0]:.6f}, {H_avg[1]:.6f}, {H_avg[2]:.6f}) A/m")
        print(f"  H at center element: ({H_fields[0][0]:.6f}, {H_fields[0][1]:.6f}, {H_fields[0][2]:.6f}) A/m")

    return {
        'magnetizations': M,
        'H_fields': H_fields,
        'iterations': iteration + 1,
        'converged': converged,
        'mesh_data': mesh_data,
        'final_residual': final_residual,
        'elements': elements
    }


def evaluate_field(result, point, include_background=True):
    """
    Evaluate H field at arbitrary point using solved magnetization.

    Parameters
    ----------
    result : dict
        Output from solve_linear_material()
    point : array-like
        Evaluation point [x, y, z]
    include_background : bool, default=True
        Whether to include background field in result

    Returns
    -------
    ndarray
        H field vector [Hx, Hy, Hz] in A/m
    """
    mesh_data = result['mesh_data']
    faces = mesh_data['surface_faces']
    M = result['magnetizations']

    H = compute_h_field_from_surface_charge(point, faces, M, None)

    # Background field is implicit in the solved M, but for external evaluation
    # we need to add it back if requested
    # Actually, the H_fields already include background, so we don't need to do anything

    return H


def create_radia_container(result, apply_magnetization=True):
    """
    Create Radia container from solved result for field evaluation.

    Parameters
    ----------
    result : dict
        Output from solve_linear_material()
    apply_magnetization : bool, default=True
        If True, apply solved magnetizations to Radia objects

    Returns
    -------
    int
        Radia container object ID
    """
    from netgen_mesh_import import TETRA_FACES

    elements = result['elements']
    M = result['magnetizations']

    obj_ids = []
    for el_idx, el in enumerate(elements):
        vertices = el['vertices']
        mag = M[el_idx].tolist() if apply_magnetization else [0, 0, 0]

        obj_id = rad.ObjPolyhdr(vertices, TETRA_FACES, mag)
        obj_ids.append(obj_id)

    container = rad.ObjCnt(obj_ids)
    return container


# Convenience function for common use case
def solve_cube_in_field(cube_size, chi, H0_z, mesh_size=None, **kwargs):
    """
    Convenience function to solve a cube of linear material in uniform H field.

    Parameters
    ----------
    cube_size : float
        Full size of cube (centered at origin)
    chi : float
        Magnetic susceptibility (chi = mu_r - 1)
    H0_z : float
        z-component of background H field in A/m
    mesh_size : float, optional
        Maximum element size. Default: cube_size / 5
    **kwargs
        Additional arguments passed to solve_linear_material()

    Returns
    -------
    dict
        Result from solve_linear_material()
    """
    from ngsolve import Mesh
    from netgen.occ import Box, Pnt, OCCGeometry

    half = cube_size / 2.0
    if mesh_size is None:
        mesh_size = cube_size / 5.0

    mu_0 = 4.0 * np.pi * 1e-7
    B0 = [0, 0, mu_0 * H0_z]

    cube_geo = Box(Pnt(-half, -half, -half), Pnt(half, half, half))
    geo = OCCGeometry(cube_geo)
    ngmesh = geo.GenerateMesh(maxh=mesh_size)
    mesh = Mesh(ngmesh)

    return solve_linear_material(mesh, chi, B0, **kwargs)


if __name__ == "__main__":
    # Test with cube in uniform field (same as NGSolve reference)
    print("Testing volume-based tetrahedral solver")
    print("=" * 60)
    print()

    # Parameters matching NGSolve reference
    cube_size = 1.0  # 1m cube
    mu_r = 100
    chi = mu_r - 1.0
    H0 = 1.0  # A/m

    rad.FldUnits('m')

    result = solve_cube_in_field(
        cube_size=cube_size,
        chi=chi,
        H0_z=H0,
        mesh_size=0.25,
        precision=0.0001,
        max_iter=1000,
        relax_param=0.3  # Slower but more stable
    )

    print()
    print("=" * 60)
    print("Comparison with NGSolve reference:")
    print("=" * 60)
    print(f"NGSolve Hz_total at origin: 0.034702 A/m")

    # Find element closest to origin
    min_dist = np.inf
    center_el_idx = 0
    for i, el in enumerate(result['elements']):
        dist = np.linalg.norm(el['centroid'])
        if dist < min_dist:
            min_dist = dist
            center_el_idx = i

    Hz_center = result['H_fields'][center_el_idx][2]
    print(f"Our Hz at center element: {Hz_center:.6f} A/m")
    print(f"Difference: {abs(Hz_center - 0.034702):.6f} A/m")
    if Hz_center > 1e-6:
        print(f"Relative error: {abs(Hz_center - 0.034702) / 0.034702 * 100:.2f}%")
