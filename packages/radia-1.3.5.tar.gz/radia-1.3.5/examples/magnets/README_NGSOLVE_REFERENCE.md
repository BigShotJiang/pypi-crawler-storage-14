# NGSolve Reference Solutions for Radia Validation

This document explains how to generate high-accuracy NGSolve reference solutions for validating and debugging Radia's tetrahedral solver.

## Overview

The NGSolve reference solutions use **H-formulation with Kelvin transformation** to solve magnetostatic problems with high accuracy. The Kelvin transformation handles the infinite domain problem without truncation errors, making these solutions suitable as ground truth for Radia validation.

## Status

**Current Implementation**: The Kelvin transformation implementation is based on the sphere reference at `S:/NGSolve/NGSolve/2024_01_31_H-formulation/2025_11_22_H-formulation3D_dipole_with_Kelvin.py`. The original sphere script also shows some numerical issues with the Kelvin transformation coupling. The cube version inherits these issues.

**For Reference Documentation**: See `S:/NGSolve/NGSolve/2024_01_31_H-formulation/Kelvin_3d.md` for the complete mathematical theory of 3D Kelvin transformation in magnetostatics.

## Available Scripts

| Script | Geometry | Description |
|--------|----------|-------------|
| `cube_ngsolve_reference_with_Kelvin.py` | Cube | Cube in uniform external field with mu_r=100 |

## Key Features

### 1. H-Formulation with Perturbation Potential

The formulation solves for the perturbation potential phi where:
- Total field: **H_total = H_s + H_pert**
- H_s: Applied background field (uniform field)
- H_pert = -grad(phi): Perturbation due to magnetic material

### 2. Kelvin Transformation

The Kelvin transformation maps the infinite exterior domain (r > R) to a finite domain (r' < R):
- Interior domain: 0 < r < R (original coordinates)
- Exterior domain: 0 < r' < R (transformed coordinates)
- Mapping: r' = R^2/r

This eliminates truncation errors from finite boundary conditions.

### 3. Periodic Boundary Conditions

The interior and exterior domains are connected via periodic BC at r = R:
- Ensures continuity of tangential H field
- Proper handling of normal B field

## Usage

### Prerequisites

```bash
# NGSolve must be installed
pip install ngsolve
# or use conda
conda install -c ngsolve ngsolve
```

### Running the Script

```bash
cd S:\Radia\01_GitHub\examples\magnets
python cube_ngsolve_reference_with_Kelvin.py
```

### Output Files

| File | Description |
|------|-------------|
| `cube_ngsolve_reference_with_Kelvin_permeability.vtu` | VTK file with mu, H_s, phi_pert, H_pert |
| `cube_ngsolve_reference_with_Kelvin.png` | Visualization plots |

### VTK Field Contents

**cube_ngsolve_reference_with_Kelvin_permeability.vtu**:
- `mu`: Permeability distribution [H/m]
- `Hs`: Background field [A/m]
- `phi_pert`: Perturbation potential [A]
- `H_pert`: Perturbation field [A/m]

## Configurable Parameters

Edit the following parameters in `cube_ngsolve_reference_with_Kelvin.py`:

```python
cube_size = 0.5       # Cube half-size [m] (full cube is 2*cube_size)
kelvin_radius = 2.0   # Kelvin transformation radius [m]
maxh_fine = 0.15      # Fine mesh size [m]
maxh_coarse = 0.3     # Coarse mesh size for outer region [m]
mu_r = 100            # Relative permeability
```

## Comparing with Radia

### Step 1: Generate NGSolve Reference

```bash
python cube_ngsolve_reference_with_Kelvin.py
```

### Step 2: Run Radia Simulation

```python
import radia as rad
rad.FldUnits('m')  # IMPORTANT: Use meters for NGSolve compatibility

# Create cube with same dimensions
cube = rad.ObjRecMag([0, 0, 0], [1.0, 1.0, 1.0], [0, 0, 0])  # 1m cube

# Apply linear material (mu_r = 100)
mat = rad.MatLin(99.0)  # chi = mu_r - 1
rad.MatApl(cube, mat)

# Solve
rad.Solve(cube, 0.0001, 10000)

# Evaluate field at same points as NGSolve
H_radia = rad.Fld(cube, 'h', [0, 0, 0])  # Field at center
```

### Step 3: Compare Results

Load both VTK files in ParaView and compare:
1. Field values at center
2. Field profiles along axes
3. Field distribution in x-z plane

## Theoretical Background

### Problem Setup

A magnetic cube (mu_r = 100) is placed in a uniform external field H_0 = (0, 0, 1) A/m.

### Expected Behavior

- Inside cube: H field is reduced due to demagnetization
- Outside cube: Dipole-like perturbation field
- B = mu_r * mu_0 * H inside the material

### Demagnetization Factor

For a sphere, the analytical demagnetization factor is N = 1/3, giving:
```
H_inside = H_0 / (1 + (mu_r - 1) * N) = H_0 * 3 / (mu_r + 2)
```

For a cube, there is no analytical solution, hence the need for numerical reference.

## Troubleshooting

### Import Error: No module named 'ngsolve'

Install NGSolve:
```bash
pip install ngsolve
```

### Mesh Generation Fails

Try adjusting mesh parameters:
```python
maxh_fine = 0.2    # Increase if mesh fails
maxh_coarse = 0.4
```

### Solution Does Not Converge

Increase solver iterations:
```python
solvers.CG(..., maxsteps=20000)
```

## References

- [NGSolve Documentation](https://ngsolve.org/)
- [Kelvin Transformation in Magnetostatics](https://doi.org/10.1109/TMAG.2008.2002395)
- Original sphere implementation: `S:/NGSolve/NGSolve/2024_01_31_H-formulation/2025_11_22_H-formulation3D_dipole_with_Kelvin.py`

## Version History

| Date | Description |
|------|-------------|
| 2025-11-27 | Initial cube reference solution |
