"""
Radia hexahedral cube in uniform external field - comparison with NGSolve reference

This script solves the same problem as cube_ngsolve_reference_with_Kelvin.py:
- 1m x 1m x 1m cube of linear magnetic material (mu_r = 100)
- Uniform external field H_0 = (0, 0, 1) A/m in z-direction
- Computes H field inside and outside the cube

Usage:
    python cube_radia_comparison.py

Compares with NGSolve reference:
    - Hz_total at origin (NGSolve: 0.034702 A/m)
    - Hz_pert profiles along x and z axes
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../build/Release'))
import radia as rad
import numpy as np
import matplotlib.pyplot as plt

print("="*60)
print("Radia Cube in Uniform External Field")
print("="*60)

# Use meters to match NGSolve
rad.FldUnits('m')

# Parameters (same as NGSolve reference)
cube_half_size = 0.5  # Cube half-size [m] (full size = 1.0 m)
mu_r = 100            # Relative permeability
H0 = 1.0              # Background field magnitude [A/m]

print(f"\nParameters:")
print(f"  Cube size: {2*cube_half_size} m x {2*cube_half_size} m x {2*cube_half_size} m")
print(f"  Relative permeability: mu_r = {mu_r}")
print(f"  Background field: H_0 = (0, 0, {H0}) A/m")

# ============================================================
# Create Radia Model
# ============================================================
print("\nCreating Radia model...")

# Create hexahedral cube with zero initial magnetization
# For linear material in external field, start with M=0
cube = rad.ObjRecMag([0, 0, 0], [2*cube_half_size, 2*cube_half_size, 2*cube_half_size], [0, 0, 0])

# Apply linear material (chi = mu_r - 1)
mat = rad.MatLin(mu_r - 1.0)
rad.MatApl(cube, mat)

# Subdivide for better accuracy
n_subdiv = 5
rad.ObjDivMag(cube, [n_subdiv, n_subdiv, n_subdiv])

print(f"  Created cube with {n_subdiv}x{n_subdiv}x{n_subdiv} subdivisions")

# ============================================================
# Apply Background Field and Solve
# ============================================================
print("\nApplying background field and solving...")

# Set background field
# ObjBckg takes B in Tesla, not H in A/m
# B = mu_0 * H, where mu_0 = 4*pi*1e-7 H/m
mu_0 = 4 * np.pi * 1e-7
B0 = mu_0 * H0  # B0 in Tesla
print(f"  Background field: B_0 = {B0:.6e} T")

# Create background field source object
bckg = rad.ObjBckg([0, 0, B0])

# Create container with cube and background field
container = rad.ObjCnt([cube, bckg])

# Solve relaxation
precision = 0.0001
max_iter = 10000
result = rad.Solve(container, precision, max_iter)
print(f"  Relaxation result: {result}")

# ============================================================
# Evaluate Fields
# ============================================================
print("\nEvaluating fields...")

# Field at origin - use container to include background field
H_origin = rad.Fld(container, 'h', [0, 0, 0])
Hz_origin = H_origin[2]
Hz_pert_origin = Hz_origin - H0

print(f"\n  Field at origin:")
print(f"    H_total = ({H_origin[0]:.6f}, {H_origin[1]:.6f}, {H_origin[2]:.6f}) A/m")
print(f"    Hz_total = {Hz_origin:.6f} A/m")
print(f"    Hz_pert = {Hz_pert_origin:.6f} A/m")

# NGSolve reference values
Hz_total_ngsolve = 0.034702
Hz_pert_ngsolve = -0.965298
print(f"\n  NGSolve reference:")
print(f"    Hz_total = {Hz_total_ngsolve:.6f} A/m")
print(f"    Hz_pert = {Hz_pert_ngsolve:.6f} A/m")
print(f"    Difference: {abs(Hz_origin - Hz_total_ngsolve):.6f} A/m ({abs(Hz_origin - Hz_total_ngsolve)/Hz_total_ngsolve*100:.2f}%)")

# Field at (0.7, 0, 0) - in air outside cube
H_070 = rad.Fld(container, 'h', [0.7, 0, 0])
Hz_070 = H_070[2]
Hz_pert_070 = Hz_070 - H0
print(f"\n  Field at (0.7, 0, 0):")
print(f"    Hz_total = {Hz_070:.6f} A/m")
print(f"    Hz_pert = {Hz_pert_070:.6f} A/m")
print(f"    NGSolve reference: Hz_pert = -0.603546 A/m")

# ============================================================
# Compute Profiles
# ============================================================
print("\nComputing axis profiles...")

plot_range = 1.1
n_points = 111

# X-axis profile (y=0, z=0)
x_profile = np.linspace(-plot_range, plot_range, n_points)
Hz_radia_x = np.zeros(n_points)

for i, xval in enumerate(x_profile):
    try:
        H = rad.Fld(container, 'h', [xval, 0, 0])
        Hz_radia_x[i] = H[2] - H0  # Perturbation field
    except:
        Hz_radia_x[i] = np.nan

# Z-axis profile (x=0, y=0)
z_profile = np.linspace(-plot_range, plot_range, n_points)
Hz_radia_z = np.zeros(n_points)

for i, zval in enumerate(z_profile):
    try:
        H = rad.Fld(container, 'h', [0, 0, zval])
        Hz_radia_z[i] = H[2] - H0  # Perturbation field
    except:
        Hz_radia_z[i] = np.nan

# ============================================================
# Load NGSolve Reference Data (if available)
# ============================================================
print("\nLoading NGSolve reference data...")

# Try to load NGSolve profile data
ngsolve_data_file = os.path.join(os.path.dirname(__file__), 'cube_ngsolve_profiles.npz')
ngsolve_data_available = False

if os.path.exists(ngsolve_data_file):
    try:
        ngsolve_data = np.load(ngsolve_data_file)
        Hz_ngsolve_x = ngsolve_data['Hz_pert_x']
        Hz_ngsolve_z = ngsolve_data['Hz_pert_z']
        ngsolve_data_available = True
        print(f"  Loaded NGSolve profile data from: {ngsolve_data_file}")
    except Exception as e:
        print(f"  Error loading NGSolve data: {e}")
        Hz_ngsolve_x = np.zeros(n_points)
        Hz_ngsolve_z = np.zeros(n_points)
else:
    print(f"  NGSolve profile data not found: {ngsolve_data_file}")
    print(f"  Run cube_ngsolve_reference_with_Kelvin.py first to generate reference data.")
    Hz_ngsolve_x = np.zeros(n_points)
    Hz_ngsolve_z = np.zeros(n_points)

# ============================================================
# Visualization
# ============================================================
print("\nGenerating comparison plots...")

plt.rcParams['mathtext.rm'] = 'serif'
plt.rcParams['mathtext.it'] = 'serif:italic'
plt.rcParams['mathtext.bf'] = 'serif:bold'
plt.rcParams['mathtext.fontset'] = 'cm'

fig = plt.figure(figsize=(12, 5), dpi=150)

# X-axis profile
ax1 = plt.subplot(1, 2, 1)
ax1.plot(x_profile, Hz_radia_x, 'b-', linewidth=2, label='Radia')
if ngsolve_data_available:
    ax1.plot(x_profile, Hz_ngsolve_x, 'r-', linewidth=2, label='NGSolve')
ax1.axvline(-cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
ax1.axvline(cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
plt.setp(ax1.get_xticklabels(), fontname='Times New Roman', fontsize=10)
ax1.set_xlabel('${\\it x}$ (m)', fontname='Times New Roman', fontsize=10)
plt.setp(ax1.get_yticklabels(), fontname='Times New Roman', fontsize=10)
ax1.set_ylabel('$H_{z,\\mathrm{pert}}$ (A/m)', fontname='Times New Roman', fontsize=10)
ax1.set_title('X-axis Profile (y=0, z=0)', fontname='Times New Roman', fontsize=11)
ax1.minorticks_on()
ax1.tick_params(which='major', direction="in", top=True, right=True)
ax1.tick_params(which='minor', direction="in", top=True, right=True)
ax1.grid(axis='both', which='major', c='gainsboro', linestyle=':', linewidth=0.3)
ax1.legend(loc='best', fontsize=9, frameon=False)

# Z-axis profile
ax2 = plt.subplot(1, 2, 2)
ax2.plot(z_profile, Hz_radia_z, 'b-', linewidth=2, label='Radia')
if ngsolve_data_available:
    ax2.plot(z_profile, Hz_ngsolve_z, 'r-', linewidth=2, label='NGSolve')
ax2.axvline(-cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
ax2.axvline(cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
plt.setp(ax2.get_xticklabels(), fontname='Times New Roman', fontsize=10)
ax2.set_xlabel('${\\it z}$ (m)', fontname='Times New Roman', fontsize=10)
plt.setp(ax2.get_yticklabels(), fontname='Times New Roman', fontsize=10)
ax2.set_ylabel('$H_{z,\\mathrm{pert}}$ (A/m)', fontname='Times New Roman', fontsize=10)
ax2.set_title('Z-axis Profile (x=0, y=0)', fontname='Times New Roman', fontsize=11)
ax2.minorticks_on()
ax2.tick_params(which='major', direction="in", top=True, right=True)
ax2.tick_params(which='minor', direction="in", top=True, right=True)
ax2.grid(axis='both', which='major', c='gainsboro', linestyle=':', linewidth=0.3)
ax2.legend(loc='best', fontsize=9, frameon=False)

plt.tight_layout()

png_file = f"{os.path.splitext(__file__)[0]}.png"
plt.savefig(png_file, dpi=150, bbox_inches='tight')
print(f"  Plot saved to: {png_file}")

# Open the image
os.startfile(png_file)

# ============================================================
# Summary
# ============================================================
print("\n" + "="*60)
print("Summary")
print("="*60)
print(f"\nRadia result at origin:")
print(f"  Hz_total = {Hz_origin:.6f} A/m")
print(f"  Hz_pert = {Hz_pert_origin:.6f} A/m")
print(f"\nNGSolve reference at origin:")
print(f"  Hz_total = {Hz_total_ngsolve:.6f} A/m")
print(f"  Hz_pert = {Hz_pert_ngsolve:.6f} A/m")
print(f"\nDifference:")
print(f"  |Hz_total_Radia - Hz_total_NGSolve| = {abs(Hz_origin - Hz_total_ngsolve):.6f} A/m")
print(f"  Relative error: {abs(Hz_origin - Hz_total_ngsolve)/Hz_total_ngsolve*100:.2f}%")

print("\n" + "="*60)
print("Computation completed successfully")
print("="*60)
