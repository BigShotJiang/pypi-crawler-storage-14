"""
H-formulation for magnetostatics with perturbation potential - CUBE geometry
Geometry created internally using OCC
Updated: 2025-11-27

Based on: 2025_11_22_H-formulation3D_dipole_with_Kelvin.py (sphere version)
Modified: Sphere -> Cube geometry for Radia comparison

Key features:
- H-formulation with perturbation potential
- Kelvin transformation for infinite domain (eliminates truncation error)
- Periodic BC between interior (r<R) and exterior (r'>R) domains
- mu_r = 100 relative permeability (configurable)

Note: For cube geometry, no analytical solution exists.
This script provides numerical reference for Radia validation.

Usage:
    python cube_ngsolve_reference_with_Kelvin.py

Output:
    - cube_ngsolve_reference_with_Kelvin_permeability.vtu: VTK file with field distribution
    - cube_ngsolve_reference_with_Kelvin.png: Visualization plots
"""
import os, sys
from numpy import *
from ngsolve import *
import ngsolve

# Import OCC geometry
from netgen.occ import *

print("="*60)
print("H-formulation 3D - CUBE Geometry with Kelvin Transformation")
print("="*60)

# ============================================================
# Geometry Definition (OCC)
# ============================================================
print("\nCreating geometry...")

# Parameters
cube_half_size = 0.5  # Magnetic cube half-size [m] (full size = 1.0 m)
kelvin_radius = 1.0   # Kelvin transformation radius [m]
maxh_fine = 0.1       # Fine mesh size [m] (for magnetic cube and inner air)
plot_range = 1.1      # Plot range [m]

# ===== INTERIOR DOMAIN (center at origin) =====
# Magnetic BOX (changed from sphere)
mag_box = Box(Pnt(-cube_half_size, -cube_half_size, -cube_half_size),
              Pnt(cube_half_size, cube_half_size, cube_half_size))
mag_box.mat("magnetic")
mag_box.maxh = maxh_fine

# Offset for exterior domain (placed separately)
offset_x = 3.0  # Offset to place exterior domain away from interior

# Inner air domain (outside cube, inside kelvin_radius sphere)
inner_sphere = Sphere(Pnt(0, 0, 0), kelvin_radius)
inner_sphere.maxh = maxh_fine
inner_air = inner_sphere - mag_box
inner_air.mat("air_inner")

# ===== EXTERIOR DOMAIN (center at offset position) =====
# Outer boundary sphere (no cutoff sphere - solid domain)
outer_sphere = Sphere(Pnt(offset_x, 0, 0), kelvin_radius)
outer_sphere.maxh = maxh_fine
outer_sphere.mat("air_outer")

# GND vertex at center (represents r'=0, which maps to r=infinity)
vertex = Vertex(Pnt(offset_x, 0, 0))
vertex.name = "GND"

# Glue all domains
geo = Glue([inner_air, mag_box, outer_sphere, vertex])

# ===== NAME THE FACES AND EDGES =====
print("\nNaming faces and edges...")
print(f"  Number of faces: {len(geo.faces)}")

# Name the solids
geo.solids[0].name = "air_inner"
geo.solids[1].name = "magnetic"
geo.solids[2].name = "air_outer"

print("\nIdentifying periodic boundaries...")
# DEBUG: Print solid and face information
print(f"  Number of solids: {len(geo.solids)}")
for i, solid in enumerate(geo.solids):
    print(f"  Solid[{i}] ({solid.name}): {len(solid.faces)} faces")
    for j, face in enumerate(solid.faces):
        # Get face center, area, and bounding box
        try:
            center = face.center
            bbox = face.bounding_box
            bbox_size = (bbox[1][0] - bbox[0][0]) * (bbox[1][1] - bbox[0][1]) * (bbox[1][2] - bbox[0][2])
            # Approximate area from mass (assuming unit density)
            try:
                mass = face.mass
                print(f"    Face[{j}]: center=({center.x:.2f}, {center.y:.2f}, {center.z:.2f}), area={mass:.4f}, bbox_vol={bbox_size:.2f}")
            except:
                print(f"    Face[{j}]: center=({center.x:.2f}, {center.y:.2f}, {center.z:.2f}), bbox_vol={bbox_size:.2f}")
        except:
            print(f"    Face[{j}]: (cannot get info)")

# Identify periodic faces: inner domain outer face (r=R) <-> outer domain outer face (r'=R)
# Find air_inner and air_outer solids by name
air_inner_solid_idx = None
air_outer_solid_idx = None
for i, solid in enumerate(geo.solids):
    if solid.name == "air_inner":
        air_inner_solid_idx = i
    elif solid.name == "air_outer":
        air_outer_solid_idx = i

if air_inner_solid_idx is not None and air_outer_solid_idx is not None:
    # For air_inner: find the face with largest bounding box (outer sphere, r=R)
    air_inner_outer_face_idx = None
    max_bbox_size = 0
    for i, face in enumerate(geo.solids[air_inner_solid_idx].faces):
        try:
            bbox = face.bounding_box
            # bbox is a tuple: ((xmin, ymin, zmin), (xmax, ymax, zmax))
            bbox_size = (bbox[1][0] - bbox[0][0]) * (bbox[1][1] - bbox[0][1]) * (bbox[1][2] - bbox[0][2])
            print(f"  air_inner face[{i}]: bbox_size = {bbox_size:.2f}")
            if bbox_size > max_bbox_size:
                max_bbox_size = bbox_size
                air_inner_outer_face_idx = i
        except Exception as e:
            print(f"  air_inner face[{i}]: error getting bbox - {e}")

    # For air_outer: find the face with largest bounding box (should be only 1 face, but be safe)
    air_outer_outer_face_idx = None
    max_bbox_size = 0
    for i, face in enumerate(geo.solids[air_outer_solid_idx].faces):
        try:
            bbox = face.bounding_box
            # bbox is a tuple: ((xmin, ymin, zmin), (xmax, ymax, zmax))
            bbox_size = (bbox[1][0] - bbox[0][0]) * (bbox[1][1] - bbox[0][1]) * (bbox[1][2] - bbox[0][2])
            print(f"  air_outer face[{i}]: bbox_size = {bbox_size:.2f}")
            if bbox_size > max_bbox_size:
                max_bbox_size = bbox_size
                air_outer_outer_face_idx = i
        except Exception as e:
            print(f"  air_outer face[{i}]: error getting bbox - {e}")

    print(f"  Selected: air_inner_outer_face_idx = {air_inner_outer_face_idx}, air_outer_outer_face_idx = {air_outer_outer_face_idx}")

    if air_inner_outer_face_idx is not None and air_outer_outer_face_idx is not None:
        print(f"  Identifying: geo.solids[{air_inner_solid_idx}].faces[{air_inner_outer_face_idx}] (air_inner) <-> geo.solids[{air_outer_solid_idx}].faces[{air_outer_outer_face_idx}] (air_outer)")
        geo.solids[air_inner_solid_idx].faces[air_inner_outer_face_idx].Identify(geo.solids[air_outer_solid_idx].faces[air_outer_outer_face_idx], "periodic", IdentificationType.PERIODIC)
        print("  Periodic identification applied")
    else:
        print("  ERROR: Could not find faces!")
else:
    print("  ERROR: Could not find air_inner or air_outer solids!")

# ============================================================
# Mesh Generation
# ============================================================
print("\nGenerating mesh...")
mesh = Mesh(OCCGeometry(geo).GenerateMesh(maxh=maxh_fine, grading=0.7))

print(f"  Number of elements: {mesh.ne}")
print(f"  Number of vertices: {mesh.nv}")
print(f"  Materials: {mesh.GetMaterials()}")
print(f"  Boundaries: {mesh.GetBoundaries()}")

# Check mesh bounding box
try:
    # Sample points to find mesh extent
    test_points = [(0,0,0), (1,0,0), (2,0,0), (3,0,0), (4,0,0), (5,0,0), (6,0,0), (7,0,0)]
    print(f"\n  Testing mesh extent:")
    for pt in test_points:
        try:
            mesh(*pt)
            print(f"    {pt}: IN MESH")
        except:
            print(f"    {pt}: NOT IN MESH")
except Exception as e:
    print(f"  Error testing mesh: {e}")

# ============================================================
# Problem Setup with Periodic BC
# ============================================================
print("\nSetting up H-formulation with Periodic BC...")

# Create finite element space with Periodic BC and GND boundary
fes = H1(mesh, order=2, dirichlet="GND")
fes = Periodic(fes)  # Apply periodic boundary conditions

print(f"  Number of DOFs: {fes.ndof}")

mu0 = 4*pi*1e-7
u = fes.TrialFunction()
v = fes.TestFunction()

# Material properties
mu_r = 100  # Relative permeability

# For air_outer domain (cutoff_radius < r' < kelvin_radius):
# mu'(r') = (R^2/r'^2)*mu0 with metric-based Kelvin transformation
# Note: r' is measured from (offset_x, 0, 0)
r_prime_sq = (x-offset_x)**2 + y**2 + z**2
mu_outer = kelvin_radius**2/(r_prime_sq+1e-20)*mu0

mu_d = {"air_inner": 1*mu0, "air_outer": mu_outer, "magnetic": mu_r*mu0}
mu = CoefficientFunction([mu_d[mat] for mat in mesh.GetMaterials()])

# Background field: H_s = -grad(phi_s) (potential-based approach)
#
# Interior domain (r < R):
#   phi_s = -z  ->  H_s = -grad(phi_s) = (0, 0, 1)
#
# Exterior domain (r' < R, Kelvin transformed):
#   H_s = (0, 0, -(r'/R)^2)

# Detect which domain we're in based on material region
x_from_offset = x - offset_x
r_from_offset = sqrt(x_from_offset**2 + y**2 + z**2)
r_from_origin = sqrt(x**2 + y**2 + z**2)
is_exterior = IfPos(r_from_offset - r_from_origin, 0.0, 1.0)  # exterior if closer to offset

# Local coordinates in exterior domain (centered at offset)
x_local = x - offset_x
y_local = y
z_local = z

# Radial distance in exterior domain
r_exterior = sqrt(x_local**2 + y_local**2 + z_local**2)
r_safe = IfPos(r_exterior - 1e-10, r_exterior, 1e-10)

# Interior domain potential and field
phi_s_inner = -z
# H_s = -grad(phi_s) = (0, 0, 1)
Hx_inner = 0.0
Hy_inner = 0.0
Hz_inner = 1.0

# Exterior domain background field:
# Set H_s = (0, 0, -(r'/R)^2) in exterior domain
# r' is measured from exterior domain center
r_prime = sqrt(x_local**2 + y_local**2 + z_local**2)
Hs_x_outer = 0.0
Hs_y_outer = 0.0
Hs_z_outer = -(r_prime / kelvin_radius)**2

# Background field with domain switching
Hs_x = (1.0 - is_exterior) * Hx_inner + is_exterior * Hs_x_outer
Hs_y = (1.0 - is_exterior) * Hy_inner + is_exterior * Hs_y_outer
Hs_z = (1.0 - is_exterior) * Hz_inner + is_exterior * Hs_z_outer

Hs = CoefficientFunction((Hs_x, Hs_y, Hs_z))

print(f"  Background field:")
print(f"    Interior: phi_s = -z  ->  H_s = (0, 0, 1)")
print(f"    Exterior: H_s = (0, 0, -(r'/R)^2)")
print(f"  Relative permeability: mu_r = {mu_r}")
print(f"  GND vertex at exterior domain center (r'=0 -> r=infinity)")

# ============================================================
# Weak Form (Perturbation Potential Formulation)
# ============================================================
print("\nAssembling system...")

# Bilinear form: a(u,v) = integral (grad(v)) * (mu * grad(u)) dOmega
a = BilinearForm(fes)
a += mu*grad(u)*grad(v)*dx

# Linear form (PERTURBATION FORMULATION):
# Note: Kelvin + periodic BC does not require boundary term
#       Periodic BC automatically ensures continuity
f = LinearForm(fes)
f += mu*InnerProduct(grad(v), Hs)*dx  # Volume integral only

# Get normal vector (for potential future use)
n = specialcf.normal(mesh.dim)

a.Assemble()
f.Assemble()

print("  System assembled")

# ============================================================
# Solve
# ============================================================
print("\nSolving system...")

gfu = GridFunction(fes)
c = Preconditioner(a, type="local")

solvers.CG(sol=gfu.vec, rhs=f.vec, mat=a.mat, pre=c.mat, tol=1e-5, printrates=True, maxsteps=10000)

print("  Solution converged")

# ============================================================
# Post-processing
# ============================================================
print("\nPost-processing...")

# Create evaluation grids for x-z plane
x_arr = linspace(-plot_range, plot_range, 111)
z_arr = linspace(-plot_range, plot_range, 111)
[xx_xz, zz_xz] = meshgrid(x_arr, z_arr)

# Compute perturbation field: H_pert = -grad(phi)
H = -grad(gfu)

# X-Z plane (y=0) - for flux lines
Hx_xz = zeros((shape(xx_xz)))
Hz_xz = zeros((shape(xx_xz)))

for nz in range(len(z_arr)):
    for nx in range(len(x_arr)):
        r = sqrt(x_arr[nx]**2 + z_arr[nz]**2)
        if r < kelvin_radius - 0.01:  # Inside mesh domain
            try:
                mip = mesh(x_arr[nx], 0, z_arr[nz])
                Hx_xz[nz, nx] = H[0](mip)
                Hz_xz[nz, nx] = H[2](mip)
            except:
                Hx_xz[nz, nx] = nan
                Hz_xz[nz, nx] = nan
        else:
            Hx_xz[nz, nx] = nan
            Hz_xz[nz, nx] = nan

# Center potential at origin
center_value = gfu(mesh(0, 0, 0))
Hz_pert_origin = H[2](mesh(0, 0, 0))
Hz_total_origin = 1.0 + Hz_pert_origin  # H_total = H_s + H_pert

print(f"  Potential at origin: {center_value:.6e}")
print(f"  Field at origin: Hz_pert = {Hz_pert_origin:.6f} A/m")
print(f"  Total field at origin: Hz_total = {Hz_total_origin:.6f} A/m")

# Additional evaluation point: (0.7, 0, 0) in air_inner region
print(f"\n  Additional evaluation at (0.7, 0, 0) in air_inner:")
try:
    Hz_070 = H[2](mesh(0.7, 0, 0))
    Hz_total_070 = 1.0 + Hz_070
    print(f"    Hz_pert = {Hz_070:.6f} A/m")
    print(f"    Hz_total = {Hz_total_070:.6f} A/m")
except Exception as e:
    print(f"    Error evaluating at (0.7, 0, 0): {e}")

# ============================================================
# Evaluate Exterior Domain Field
# ============================================================
print("\nEvaluating exterior domain field...")

# Create grid for exterior domain centered at (offset_x, 0, 0)
x_ext = linspace(offset_x - plot_range, offset_x + plot_range, 111)
z_ext = linspace(-plot_range, plot_range, 111)
xx_ext, zz_ext = meshgrid(x_ext, z_ext)

# Evaluate H field in exterior domain
Hx_ext = zeros(shape(xx_ext))
Hz_ext = zeros(shape(xx_ext))

for nz in range(len(z_ext)):
    for nx in range(len(x_ext)):
        # Check if point is inside exterior domain (r' < R from offset center)
        r_from_offset_val = sqrt((x_ext[nx] - offset_x)**2 + z_ext[nz]**2)
        if r_from_offset_val < kelvin_radius - 0.05:  # Small margin to avoid boundary
            try:
                mip = mesh(x_ext[nx], 0, z_ext[nz])
                Hx_ext[nz, nx] = H[0](mip)
                Hz_ext[nz, nx] = H[2](mip)
            except:
                Hx_ext[nz, nx] = nan
                Hz_ext[nz, nx] = nan
        else:
            Hx_ext[nz, nx] = nan
            Hz_ext[nz, nx] = nan

# Compute B field for exterior domain
# In Kelvin-transformed exterior domain, mu' = (R/r')^2 * mu0
Bx_ext = zeros(shape(xx_ext))
Bz_ext = zeros(shape(xx_ext))

for nz in range(len(z_ext)):
    for nx in range(len(x_ext)):
        r_prime_val = sqrt((x_ext[nx] - offset_x)**2 + z_ext[nz]**2)
        if r_prime_val > 0.01:  # Avoid division by zero
            mu_ext_val = (kelvin_radius / r_prime_val)**2 * mu0
        else:
            mu_ext_val = mu0 * 1e6  # Large value near center
        Bx_ext[nz, nx] = mu_ext_val * Hx_ext[nz, nx]
        Bz_ext[nz, nx] = mu_ext_val * Hz_ext[nz, nx]

# ============================================================
# Profile Comparisons (No analytical solution for cube)
# ============================================================
print("\nComputing axis profiles (perturbation field Hz)...")

# Sample points along x-axis and z-axis
profile_range = linspace(-plot_range, plot_range, 111)

# X-axis profile (y=0, z=0)
x_profile = profile_range
Hz_pert_numerical_x = zeros(len(x_profile))

for i, xval in enumerate(x_profile):
    r = abs(xval)
    if r < kelvin_radius - 0.01:  # Inside mesh domain
        try:
            mip = mesh(xval, 0, 0)  # X-axis: (x, 0, 0)
            Hz_pert_numerical_x[i] = H[2](mip)  # Hz component
        except:
            Hz_pert_numerical_x[i] = nan
    else:
        Hz_pert_numerical_x[i] = nan

# Z-axis profile (x=0, y=0)
z_profile = profile_range
Hz_pert_numerical_z = zeros(len(z_profile))

for i, zval in enumerate(z_profile):
    r = abs(zval)
    if r < kelvin_radius - 0.01:  # Inside mesh domain
        try:
            mip = mesh(0, 0, zval)  # Z-axis: (0, 0, z)
            Hz_pert_numerical_z[i] = H[2](mip)  # Hz component
        except:
            Hz_pert_numerical_z[i] = nan
    else:
        Hz_pert_numerical_z[i] = nan

# ============================================================
# Output VTK file for permeability distribution
# ============================================================
print("\nSaving VTK output for permeability distribution...")

vtk_file = f"{os.path.splitext(__file__)[0]}_permeability"
vtk = VTKOutput(ma=mesh, coefs=[mu, Hs, gfu, H],
                names=["mu", "Hs", "phi_pert", "H_pert"],
                filename=vtk_file)
vtk.Do()
print(f"  VTK output saved to: {vtk_file}.vtu")

# ============================================================
# Visualization
# ============================================================
print("\nGenerating plots...")

import matplotlib
import matplotlib.pyplot as plt
matplotlib.rc('mathtext', **{'rm':'serif', 'it':'serif:italic',
                              'bf':'serif:bold', 'fontset':'cm'})

# Create figure with 2x2 subplots
# Row 1: Interior H_pert streamlines, Exterior H_pert streamlines
# Row 2: X-axis profile, Z-axis profile
fig = plt.figure(figsize=(12, 10), dpi=150)

# Row 1, Col 1: Interior H_pert field (NGSolve)
ax1 = plt.subplot(2, 2, 1)
strm1 = ax1.streamplot(xx_xz, zz_xz, Hx_xz, Hz_xz,
                       color='black', linewidth=1.0, density=1.5,
                       arrowsize=0.8, arrowstyle='->')
# Draw cube outline
rect1 = plt.Rectangle((-cube_half_size, -cube_half_size), 2*cube_half_size, 2*cube_half_size,
                      fill=True, facecolor='lightblue', alpha=0.3,
                      edgecolor='red', linewidth=2, label='Magnetic material')
ax1.add_patch(rect1)
kelvin_boundary1 = plt.Circle((0, 0), kelvin_radius, fill=False,
                              edgecolor='green', linewidth=1.5, linestyle='--', label='Kelvin boundary')
ax1.add_patch(kelvin_boundary1)
ax1.legend(loc='upper right', fontsize=8, frameon=False)
plt.setp(ax1.get_xticklabels(), fontname='Times New Roman', fontsize=10)
ax1.set_xlabel('${\\it x}$ (m)', fontname='Times New Roman', fontsize=10)
plt.setp(ax1.get_yticklabels(), fontname='Times New Roman', fontsize=10)
ax1.set_ylabel('${\\it z}$ (m)', fontname='Times New Roman', fontsize=10)
ax1.set_title('Interior: $\\mathbf{H}_{\\mathrm{pert}}$ (NGSolve)', fontname='Times New Roman', fontsize=11)
ax1.set_aspect('equal')
ax1.set_xlim(-plot_range, plot_range)
ax1.set_ylim(-plot_range, plot_range)
ax1.minorticks_on()
ax1.tick_params(which='major', direction="in", top=True, right=True)
ax1.tick_params(which='minor', direction="in", top=True, right=True)
ax1.grid(axis='both', which='major', c='gainsboro', linestyle=':', linewidth=0.3, alpha=0.5)

# Row 1, Col 2: Exterior H_pert field (NGSolve)
ax2 = plt.subplot(2, 2, 2)
strm2 = ax2.streamplot(xx_ext, zz_ext, Hx_ext, Hz_ext,
                       color='darkgreen', linewidth=1.0, density=1.5,
                       arrowsize=0.8, arrowstyle='->')
kelvin_boundary2 = plt.Circle((offset_x, 0), kelvin_radius, fill=False,
                              edgecolor='green', linewidth=1.5, linestyle='--', label='Kelvin boundary')
ax2.add_patch(kelvin_boundary2)
ax2.legend(loc='upper right', fontsize=8, frameon=False)
plt.setp(ax2.get_xticklabels(), fontname='Times New Roman', fontsize=10)
ax2.set_xlabel('${\\it x}$ (m)', fontname='Times New Roman', fontsize=10)
plt.setp(ax2.get_yticklabels(), fontname='Times New Roman', fontsize=10)
ax2.set_ylabel('${\\it z}$ (m)', fontname='Times New Roman', fontsize=10)
ax2.set_title('Exterior: $\\mathbf{H}_{\\mathrm{pert}}$ (NGSolve)', fontname='Times New Roman', fontsize=11)
ax2.set_aspect('equal')
ax2.set_xlim(offset_x - plot_range, offset_x + plot_range)
ax2.set_ylim(-plot_range, plot_range)
ax2.minorticks_on()
ax2.tick_params(which='major', direction="in", top=True, right=True)
ax2.tick_params(which='minor', direction="in", top=True, right=True)
ax2.grid(axis='both', which='major', c='gainsboro', linestyle=':', linewidth=0.3, alpha=0.5)

# Row 2, Col 1: X-axis profile
ax3 = plt.subplot(2, 2, 3)
ax3.plot(x_profile, Hz_pert_numerical_x, 'k-', linewidth=2, label='NGSolve')
ax3.axvline(-cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
ax3.axvline(cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
plt.setp(ax3.get_xticklabels(), fontname='Times New Roman', fontsize=10)
ax3.set_xlabel('${\\it x}$ (m)', fontname='Times New Roman', fontsize=10)
plt.setp(ax3.get_yticklabels(), fontname='Times New Roman', fontsize=10)
ax3.set_ylabel('$H_{z,\\mathrm{pert}}$ (A/m)', fontname='Times New Roman', fontsize=10)
ax3.set_title('X-axis Profile (y=0, z=0)', fontname='Times New Roman', fontsize=11)
ax3.minorticks_on()
ax3.tick_params(which='major', direction="in", top=True, right=True)
ax3.tick_params(which='minor', direction="in", top=True, right=True)
ax3.grid(axis='both', which='major', c='gainsboro', linestyle=':', linewidth=0.3)
ax3.grid(axis='both', which='minor', c='gainsboro', linestyle='--', linewidth=0.1)
ax3.legend(loc='best', fontsize=9, frameon=False)

# Row 2, Col 2: Z-axis profile
ax4 = plt.subplot(2, 2, 4)
ax4.plot(z_profile, Hz_pert_numerical_z, 'k-', linewidth=2, label='NGSolve')
ax4.axvline(-cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
ax4.axvline(cube_half_size, color='gray', linestyle=':', linewidth=1, alpha=0.7)
plt.setp(ax4.get_xticklabels(), fontname='Times New Roman', fontsize=10)
ax4.set_xlabel('${\\it z}$ (m)', fontname='Times New Roman', fontsize=10)
plt.setp(ax4.get_yticklabels(), fontname='Times New Roman', fontsize=10)
ax4.set_ylabel('$H_{z,\\mathrm{pert}}$ (A/m)', fontname='Times New Roman', fontsize=10)
ax4.set_title('Z-axis Profile (x=0, y=0)', fontname='Times New Roman', fontsize=11)
ax4.minorticks_on()
ax4.tick_params(which='major', direction="in", top=True, right=True)
ax4.tick_params(which='minor', direction="in", top=True, right=True)
ax4.grid(axis='both', which='major', c='gainsboro', linestyle=':', linewidth=0.3)
ax4.grid(axis='both', which='minor', c='gainsboro', linestyle='--', linewidth=0.1)
ax4.legend(loc='best', fontsize=9, frameon=False)

plt.tight_layout()

png_file = f"{os.path.splitext(__file__)[0]}.png"
plt.savefig(png_file, dpi=150, bbox_inches='tight')
print(f"  Plot saved to: {png_file}")

os.startfile(png_file)

print("\n" + "="*60)
print("Computation completed successfully")
print("="*60)
