# The version is updated automatically with bumpversion
# Do not update manually
__version__ = "0.12.1"