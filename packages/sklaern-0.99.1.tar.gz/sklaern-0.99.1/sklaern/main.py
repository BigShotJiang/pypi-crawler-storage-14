def help_scl():
    print('''
          
fuzzy_relation()
fuzzy_relation_run()
defuzzification()
defuzzification_run_lambda()
defuzzification_run_MOM()
defuzzification_run_COG()
genetic_algorithm()
genetic_algorithm_run()
distributive_parallel()
distributive_parallel_run()
ant_colony_optimization()
ant_colony_optimization_run()
particle_swarm_optimization()
particle_swarm_optimization_run()
grey_wolf_optimization()
grey_wolf_optimization_run()
crisp_partition()
crisp_partition_run()
perceptron()
perceptron_hebbs_run()
perceptron_delta_run()
ensemble()
ensemble_voting_run()
ensemble_bagging_run()
ensemble_boosting_run()
all()
help()
''')
    

def help():
    print('''

mnist1() --> Undercomplete auto encoder
mnist2() --> Denoising autoencoder
mnist3() --> Variational autoenccoder
mnist4() --> Ristricted Boltzman machine
mnist5() --> stacked RBM
mnist6() --> Deep Belief Network
mnist7() --> Deep boltzmann machine
mnist8() --> Convolutional Autoencoder for image compression
mnist9() --> Generative AI using CNN
mnist10() --> GAN
          
          
''')