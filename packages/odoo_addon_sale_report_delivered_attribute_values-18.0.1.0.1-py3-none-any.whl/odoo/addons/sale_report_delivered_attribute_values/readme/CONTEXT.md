This module was developed because we want to show Attribute Values on Sales from Delivery report.

It will be useful for you if want to analyize information of your Attribute Values.
