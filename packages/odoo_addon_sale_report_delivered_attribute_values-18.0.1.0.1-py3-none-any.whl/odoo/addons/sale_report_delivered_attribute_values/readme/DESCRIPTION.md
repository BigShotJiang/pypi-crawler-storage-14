This module extends the functionality of Sales from Delivery report to support view Attribute Values and to allow you to have a better view of Deliveries.
