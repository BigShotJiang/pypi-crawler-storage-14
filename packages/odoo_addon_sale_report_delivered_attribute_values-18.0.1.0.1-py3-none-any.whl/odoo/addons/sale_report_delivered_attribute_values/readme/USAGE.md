To use this module, you need to:

1. Go to Sales and create and send products with Attribute Values
2. Go to Sale Delivered Report
3. Check Attribute Values can be filtered and grouped
4. Check Attributes can be filtered
