from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionOnekeySolveRequest:
    regionID: str  # 资源池ID
    taskID: str  # 巡检任务ID
    inspectionItem: int  # 本参数表示巡检项，见巡检项查询接口返回。



@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionOnekeySolveResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorIntelligentInspectionOnekeySolveReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionOnekeySolveReturnObj:
    success: Optional[bool] = None  # 成功标识



