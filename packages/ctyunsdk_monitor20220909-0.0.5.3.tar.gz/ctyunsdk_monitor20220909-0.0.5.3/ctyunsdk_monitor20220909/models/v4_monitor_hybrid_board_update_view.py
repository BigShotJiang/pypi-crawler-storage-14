from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewRequest:
    viewID: str  # 监控视图ID
    view: 'V4MonitorHybridBoardUpdateViewRequestView'  # 新监控视图内容


@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewRequestView:
    name: str  # 监控大盘视图名称
    type: str  # 视图类型。取值范围:<br>timeSeries：折线图。<br>barChart：柱状图。<br>table：表格。<br>根据以上范围取值。
    datasource: 'V4MonitorHybridBoardUpdateViewRequestViewDatasource'  # 数据源
    fieldConfig: 'V4MonitorHybridBoardUpdateViewRequestViewFieldConfig'  # 字段配置
    targets: List['V4MonitorHybridBoardUpdateViewRequestViewTargets']
    description: Optional[str] = None  # 视图描述


@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewRequestViewDatasource:
    type: str  # 数据类型。取值范围:<br>prometheus<br>根据以上范围取值。
    namespace: str  # 指标仓库名称


@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewRequestViewFieldConfig:
    defaults: 'V4MonitorHybridBoardUpdateViewRequestViewFieldConfigDefaults'  # 默认配置


@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewRequestViewFieldConfigDefaults:
    unit: str  # 单位


@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewRequestViewTargets:
    expr: str  # prometheus表达式
    legendFormat: Optional[str] = None  # 图例格式化
    period: Optional[int] = None  # 周期



@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardUpdateViewReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardUpdateViewReturnObj:
    success: Optional[bool] = None  # 是否更新成功



