from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQueryEventAlarmRulesRequest:
    regionID: str  # 资源池ID
    service: Optional[str] = None  # 本参数表示服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    dimension: Optional[str] = None  # 本参数表示告警维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    status: Optional[int] = None  # 本参数表示告警规则启用状态。取值范围：<br>0：启用。<br>1：停用。<br>根据以上范围取值。
    alarmStatus: Optional[int] = None  # 本参数表示告警规则告警状态。取值范围：<br>0：正常。<br>1：正在告警。<br>根据以上范围取值。
    name: Optional[str] = None  # 规则名称
    projectID: Optional[str] = None  # 项目ID
    sort: Optional[str] = None  # 本参数表示排序条件，-表示降序。支持的排序字段：<br>updateTime：更新时间。<br>根据以上范围取值。
    pageNo: Optional[int] = None  # 页码，默认值1
    pageSize: Optional[int] = None  # 页大小，默认值20



@dataclass_json
@dataclass
class V4MonitorQueryEventAlarmRulesResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorQueryEventAlarmRulesReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorQueryEventAlarmRulesReturnObj:
    alarmRules: Optional[List[object]] = None  # 告警规则
    totalCount: Optional[int] = None  # 总记录数
    currentCount: Optional[int] = None  # 当前页记录数
    totalPage: Optional[int] = None  # 总页数



