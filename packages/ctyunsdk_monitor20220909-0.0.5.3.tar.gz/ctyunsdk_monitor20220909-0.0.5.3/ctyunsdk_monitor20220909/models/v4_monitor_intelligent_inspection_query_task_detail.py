from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskDetailRequest:
    regionID: str  # 资源池ID
    inspectionType: int  # 本参数表示巡检类型，见巡检项查询接口返回。
    taskID: str  # 巡检任务ID
    pageNo: Optional[int] = None  # 页码，默认为1
    pageSize: Optional[int] = None  # 页大小，默认为10，不超过100



@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskDetailResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorIntelligentInspectionQueryTaskDetailReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskDetailReturnObj:
    taskID: Optional[str] = None  # 巡检任务ID
    totalCount: Optional[int] = None  # 获取对象数据条数
    totalPage: Optional[int] = None  # 总页数
    currentCount: Optional[int] = None  # 当前页记录数
    taskDetailList: Optional[List['V4MonitorIntelligentInspectionQueryTaskDetailReturnObjTaskDetailList']] = None  # 巡检结果列表


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskDetailReturnObjTaskDetailList:
    productType: Optional[str] = None  # 本参数表示产品类型。取值范围：<br>vm：云主机。<br>根据以上范围取值。
    inspectionItem: Optional[int] = None  # 本参数表示巡检项。
    inspectionName: Optional[str] = None  # 本参数表示巡检项名称
    level: Optional[int] = None  # 本参数表示重要等级。取值范围：<br>1：低。<br>2：中。<br>3：高。<br>根据以上范围取值。
    anomalyID: Optional[str] = None  # 异常ID
    anomalyName: Optional[str] = None  # 异常名称



