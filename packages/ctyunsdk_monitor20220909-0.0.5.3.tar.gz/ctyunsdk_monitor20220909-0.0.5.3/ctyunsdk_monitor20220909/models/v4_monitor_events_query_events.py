from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorEventsQueryEventsRequest:
    regionID: str  # 资源池ID
    service: str  # 服务，见事件监控：查询服务维度接口返回。
    dimension: str  # 维度，见事件监控：查询服务维度接口返回。



@dataclass_json
@dataclass
class V4MonitorEventsQueryEventsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorEventsQueryEventsReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorEventsQueryEventsReturnObj:
    events: Optional[List[object]] = None  # 事件列表



