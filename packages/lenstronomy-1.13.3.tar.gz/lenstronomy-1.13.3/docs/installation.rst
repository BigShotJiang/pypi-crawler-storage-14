============
Installation
============

This page outlines how to install one of the officially distributed lenstronomy releases and its dependencies,
or install and test the latest development version.

From PyPI
---------

All lenstronomy releases are distributed through the Python Package Index (PyPI). To install the latest version use pip:

At the command line with pip::

    $ pip install lenstronomy

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv lenstronomy
    $ pip install lenstronomy

From conda-forge
----------------

All lenstronomy releases are also distributed for conda through the conda-forge channel. To install the latest version for your active conda environment::

    $ conda install -c conda-forge lenstronomy


You can also clone the github repository for development purposes.


Requirements
------------

Make sure the standard python libraries as specified in the `requirements <https://github.com/sibirrer/lenstronomy/blob/main/requirements.txt>`_.
The standard usage does not require all libraries to be installed, in particular the different posterior samplers are only required when being used.

In the following, a few specific cases are mentioned that may require special attention in the installation and settings, in particular when it comes
to MPI and HPC applications.


MPI
---
MPI support is provided for several sampling techniques for parallel computing. A specific version of the library schwimmbad is required
for the correct support of the moving of the likelihood elements from one processor to another with MPI. Pay attention ot the
`requirements <https://github.com/sibirrer/lenstronomy/blob/main/requirements.txt>`_.


NUMBA
-----
Just-in-time (jit) compilation with numba can provide significant speed-up for certain calculations.
There are specific settings for the settings provided as per default, but these may need to be adopted when running on a HPC cluster.
You can define your own configuration file in your $XDG_CONFIG_HOME/lenstronomy/config.yaml file. E.g. (check your system for the path)::

    $ ~/.conf/lenstronomy/config.yaml

following the format of the default configuration which is `here <https://github.com/sibirrer/lenstronomy/blob/main/lenstronomy/Conf/conf_default.yaml>`_.


FASTELL
-------
The fastell4py package, originally from Barkana (fastell), is required to run the PEMD (power-law elliptical mass distribution) lens model
and can be cloned from: `https://github.com/sibirrer/fastell4py <https://github.com/sibirrer/fastell4py>`_ (needs a fortran compiler).
We recommend using the EPL model as it is a pure python version of the same profile.

.. code-block:: bash

    $ sudo apt-get install gfortran
    $ git clone https://github.com/sibirrer/fastell4py.git <desired location>
    $ cd <desired location>
    $ python setup.py install --user


Check installation by running tests
-----------------------------------

You can check your installation with pytest::

    $ cd <lenstronomy_repo>
    $ py.test

Or you can run a partial test with::

    $ cd <lenstronomy_repo>
    $ py.test/test/test_LensModel/

You can also run the tests with tox in a virtual environment with::

    $ cd <lenstronomy_repo>
    $ tox

Note: tox might have trouble with the PyMultiNest installation and the cmake part of it.
