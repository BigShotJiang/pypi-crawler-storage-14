# Copyright (C) 2025 Yeeti
from .main import Spinner, spinner

__all__ = ['Spinner', 'spinner']
