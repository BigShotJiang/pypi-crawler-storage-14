"""MCP session wrappers - maintain exact same interface."""

from datetime import datetime
from typing import Dict, Any, List, Optional
from fastmcp import Client


class CombinedMCPSession:
    """
    Combined session wrapper for multi-server MCP setup.
    
    Routes tool calls to the appropriate MCP server based on
    tool availability.
    """
    
    def __init__(self, clients: Dict[str, Client], tool_map: Dict[str, Any]):
        self.clients = clients
        self.tool_map = tool_map
        self._tools = None
        self._server_sessions = {}
        self._build_combined_tools()
    
    def _build_combined_tools(self):
        """Build combined list of tools from all servers."""
        self._tools = []
        
        for server_name, client in self.clients.items():
            try:
                if hasattr(client, 'session'):
                    self._server_sessions[server_name] = client.session
                    
                    if hasattr(client.session, '_tools'):
                        server_tools = client.session._tools or []
                        self._tools.extend(server_tools)
            except Exception:
                pass
    
    def get_gemini_tools(self):
        """Get tools in Gemini-compatible format (list of session objects)."""
        return list(self._server_sessions.values())
    
    async def call_tool(self, name: str, arguments: Dict[str, Any]):
        """Route tool call to appropriate server."""
        target_session = None
        server_name = None
        
        for srv_name, client in self.clients.items():
            if hasattr(client, 'session'):
                session = client.session
                if hasattr(session, '_tools'):
                    tool_names = [t.name for t in (session._tools or [])]
                    if name in tool_names:
                        target_session = session
                        server_name = srv_name
                        break
        
        if not target_session:
            raise ValueError(f"Tool '{name}' not available")
        
        return await target_session.call_tool(name, arguments)


class UserMCPClient:
    """
    Per-user MCP client wrapper with JWT authentication.
    
    Manages multiple server connections for a single user with:
    - JWT token injection for authenticated servers
    - Connection health tracking
    - Request counting
    - Automatic session patching
    """
    
    def __init__(
        self,
        clients: Dict[str, Client],
        auth_token: Optional[str],
        permissions: list
    ):
        self.clients = clients
        self.auth_token = auth_token
        self.permissions = permissions
        self.created_at = datetime.now()
        self.last_used = datetime.now()
        self.request_count = 0
        self.tool_map = {}
        
        self._build_tool_map()
        self._patch_all_sessions()
    
    def _build_tool_map(self):
        """Build map of tools to servers."""
        for server_name, client in self.clients.items():
            try:
                if hasattr(client, 'session'):
                    self.tool_map[server_name] = client.session
            except Exception:
                pass
    
    def _patch_all_sessions(self):
        """Patch all sessions with JWT authentication."""
        from uniops_mcp_client.manager import MCPClientManager
        
        for server_name, client in self.clients.items():
            if hasattr(client, 'session'):
                config = MCPClientManager.get_server_config(server_name)
                if config and config.requires_auth:
                    self._patch_session(client.session)
    
    def _patch_session(self, session):
        """Patch single session for JWT auth."""
        if not self.auth_token:
            return
        
        from uniops_mcp_client import _pool
        
        original_call_tool = session.call_tool
        
        async def patched_call_tool(name: str, arguments: Dict[str, Any]):
            auth_arguments = {
                **arguments,
                "authorization": f"Bearer {self.auth_token}"
            }
            self.mark_used()
            return await original_call_tool(name, auth_arguments)
        
        session.call_tool = patched_call_tool
    
    def is_healthy(self) -> bool:
        """Check if client is still healthy."""
        from uniops_mcp_client import _pool
        return not _pool._is_client_stale(self.last_used, datetime.now())
    
    def mark_used(self):
        """Update last used timestamp."""
        self.last_used = datetime.now()
        self.request_count += 1
    
    @property
    def session(self):
        """Get combined session wrapper."""
        return CombinedMCPSession(self.clients, self.tool_map)
    
    def get_all_tools(self) -> List[Any]:
        """Get all tools from all servers."""
        all_tools = []
        for server_name, client in self.clients.items():
            try:
                if hasattr(client, 'session') and hasattr(client.session, '_tools'):
                    server_tools = client.session._tools or []
                    all_tools.extend(server_tools)
            except Exception:
                pass
        return all_tools