"""
UniOps MCP Client Manager

Multi-server MCP client management with:
- Per-user client pooling
- JWT-based authentication
- Health monitoring
- Automatic cleanup of idle connections
- Multi-server support (primary + secondary)

Usage:
    >>> from uniops_mcp_client import MCPClientManager
    >>> 
    >>> # Initialize manager
    >>> manager = MCPClientManager(
    ...     primary_url='http://localhost:8001/mcp',
    ...     reconnect_interval=30,
    ...     max_retries=5,
    ...     health_check_interval=300
    ... )
    >>> 
    >>> # Start background tasks
    >>> await manager.start_background_tasks()
    >>> 
    >>> # Get user client with permissions
    >>> client = await manager.get_user_client(
    ...     'user@example.com',
    ...     ['list_clusters', 'get_pods']
    ... )
"""

from uniops_mcp_client.manager import (
    MCPClientManager,
    MCPServerConfig,
)
from uniops_mcp_client.session import (
    UserMCPClient,
    CombinedMCPSession,
)

__version__ = "1.0.0"
__all__ = [
    "MCPClientManager",
    "MCPServerConfig",
    "UserMCPClient",
    "CombinedMCPSession",
]
