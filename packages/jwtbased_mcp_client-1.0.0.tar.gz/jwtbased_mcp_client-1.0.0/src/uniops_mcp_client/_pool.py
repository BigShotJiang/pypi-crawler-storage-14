"""Internal connection pooling logic with obfuscation."""

import asyncio as _aio
from datetime import datetime as _dt
from typing import Dict as _D, Any as _A, Optional as _O
from fastmcp import Client as _C
from fastmcp.client.transports import StreamableHttpTransport as _T


# Obfuscated timing constants
_IDLE_THRESH = 600  # 10 minutes
_HEALTH_TO = 10.0   # 10 seconds


async def _create_client(_url: str) -> _C:
    """Create and initialize MCP client."""
    _trans = _T(url=_url)
    _client = _C(_trans)
    await _client.__aenter__()
    return _client


async def _test_client(_client: _C, _timeout: float = _HEALTH_TO) -> bool:
    """Test if client is responsive."""
    try:
        await _aio.wait_for(_client.list_tools(), timeout=_timeout)
        return True
    except Exception:
        return False


async def _close_client(_client: _C):
    """Close client connection."""
    try:
        await _client.__aexit__(None, None, None)
    except Exception:
        pass


def _is_client_stale(_last_used: _dt, _now: _dt) -> bool:
    """Check if client has been idle too long."""
    _elapsed = (_now - _last_used).total_seconds()
    return _elapsed > _IDLE_THRESH


def _patch_client_for_auth(_client: _C, _token: str, _orig_call):
    """Patch client session to inject JWT token."""
    async def _authed_call(_name: str, _args: _D[str, _A]):
        _new_args = {**_args, "authorization": f"Bearer {_token}"}
        return await _orig_call(_name, _new_args)
    return _authed_call


class _ClientHealthTracker:
    """Track health status of MCP servers."""
    
    __slots__ = ('_health', '_last_check', '_failures')
    
    def __init__(self, _servers: list):
        self._health = {_s: False for _s in _servers}
        self._last_check = {_s: None for _s in _servers}
        self._failures = {_s: 0 for _s in _servers}
    
    def mark_healthy(self, _server: str):
        """Mark server as healthy."""
        self._health[_server] = True
        self._last_check[_server] = _dt.now()
        self._failures[_server] = 0
    
    def mark_unhealthy(self, _server: str):
        """Mark server as unhealthy."""
        self._health[_server] = False
        self._failures[_server] += 1
    
    def is_healthy(self, _server: str) -> bool:
        """Check if server is healthy."""
        return self._health.get(_server, False)
    
    def get_stats(self) -> _D:
        """Get health statistics."""
        return {
            'health': dict(self._health),
            'last_check': {k: v.isoformat() if v else None for k, v in self._last_check.items()},
            'failures': dict(self._failures)
        }