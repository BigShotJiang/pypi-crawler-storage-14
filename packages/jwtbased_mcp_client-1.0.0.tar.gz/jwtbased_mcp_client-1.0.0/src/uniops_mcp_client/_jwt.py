"""Internal JWT token creation helper."""

import os as _os
from datetime import datetime, timedelta
import jwt


def create_token(user_email: str, permissions: list) -> str:
    """Create JWT token with permissions."""
    secret = _os.getenv('JWT_SECRET_KEY')
    if not secret:
        raise ValueError("JWT_SECRET_KEY not set")
    
    algo = _os.getenv('JWT_ALGORITHM', 'HS256')
    exp_min = int(_os.getenv('JWT_ACCESS_TOKEN_EXPIRE_MINUTES', '30'))
    
    payload = {
        "sub": user_email,
        "email": user_email,
        "permissions": permissions,
        "type": "access",
        "exp": datetime.utcnow() + timedelta(minutes=exp_min),
        "iat": datetime.utcnow()
    }
    
    return jwt.encode(payload, secret, algorithm=algo)