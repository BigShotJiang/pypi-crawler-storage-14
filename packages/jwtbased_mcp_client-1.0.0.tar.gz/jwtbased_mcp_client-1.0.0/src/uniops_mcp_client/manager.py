"""MCP Client Manager - maintains exact same interface."""

import os as _os
import asyncio
from datetime import datetime
from typing import Optional, Dict, Any, List

from uniops_mcp_client import _pool
from uniops_mcp_client.session import UserMCPClient


class MCPServerConfig:
    """Configuration for an MCP server."""
    
    def __init__(self, name: str, url: str, requires_auth: bool = True):
        self.name = name
        self.url = url
        self.requires_auth = requires_auth


class MCPClientManager:
    """
    Multi-server MCP client manager with per-user pooling.
    
    Features:
    - Multiple MCP server support (primary + secondary)
    - Per-user client instances with JWT auth
    - Connection health monitoring
    - Automatic cleanup of idle connections
    - Background health checks
    
    Environment Variables:
        MCP_SERVER_URL: Primary MCP server URL (required)
        SITE247_MCP_ENABLED: Enable Site24x7 server (default: 'false')
        SITE247_MCP_URL: Site24x7 MCP server URL
        MCP_CLIENT_IDLE_TIMEOUT: Idle timeout in seconds (default: 600)
    """
    
    # Class-level server configurations
    _server_configs: Dict[str, MCPServerConfig] = {}
    
    def __init__(
        self,
        primary_url: str,
        reconnect_interval: int,
        max_retries: int,
        health_check_interval: int
    ):
        self.reconnect_interval = reconnect_interval
        self.max_retries = max_retries
        self.health_check_interval = health_check_interval
        
        # Initialize server configs
        self._server_configs['primary'] = MCPServerConfig(
            name='primary',
            url=primary_url,
            requires_auth=True
        )
        
        # Check for secondary server
        if _os.getenv('SITE247_MCP_ENABLED', 'false').lower() == 'true':
            site_url = _os.getenv('SITE247_MCP_URL')
            if site_url:
                self._server_configs['site247'] = MCPServerConfig(
                    name='site247',
                    url=site_url,
                    requires_auth=False
                )
        
        self.user_clients: Dict[str, UserMCPClient] = {}
        self.client_lock = asyncio.Lock()
        
        # Health tracking
        _servers = list(self._server_configs.keys())
        self._health_tracker = _pool._ClientHealthTracker(_servers)
        
        self.cleanup_task = None
        self.health_check_task = None
    
    @classmethod
    def get_server_config(cls, server_name: str) -> Optional[MCPServerConfig]:
        """Get server configuration by name."""
        return cls._server_configs.get(server_name)
    
    async def get_user_client(
        self,
        user_email: str,
        permissions: list,
        force_new: bool = False
    ) -> Optional[UserMCPClient]:
        """
        Get or create MCP client for user.
        
        Args:
            user_email: User's email address
            permissions: List of tool permissions
            force_new: Force create new client
            
        Returns:
            UserMCPClient instance or None if failed
        """
        async with self.client_lock:
            # Check existing client
            if user_email in self.user_clients and not force_new:
                user_client = self.user_clients[user_email]
                
                if user_client.is_healthy():
                    try:
                        first_client = next(iter(user_client.clients.values()))
                        await asyncio.wait_for(
                            first_client.list_tools(),
                            timeout=3.0
                        )
                        user_client.mark_used()
                        return user_client
                    except Exception:
                        await self._close_user_client(user_email)
            
            # Close existing if force_new
            if force_new and user_email in self.user_clients:
                await self._close_user_client(user_email)
            
            # Create new clients
            try:
                # Create JWT token (only for servers that need auth)
                from uniops_mcp_client._jwt import create_token
                auth_token = create_token(user_email, permissions)
                
                # Connect to all servers
                clients = {}
                connection_errors = []
                
                for server_name, server_config in self._server_configs.items():
                    try:
                        client = await _pool._create_client(server_config.url)
                        
                        # Verify connection
                        if await _pool._test_client(client):
                            clients[server_name] = client
                            self._health_tracker.mark_healthy(server_name)
                        else:
                            await _pool._close_client(client)
                            raise Exception("Health check failed")
                        
                    except Exception as e:
                        error_msg = f"Failed to connect to {server_name}: {e}"
                        connection_errors.append(error_msg)
                        self._health_tracker.mark_unhealthy(server_name)
                
                # Require at least one connection
                if not clients:
                    return None
                
                # Create user client
                user_client = UserMCPClient(clients, auth_token, permissions)
                self.user_clients[user_email] = user_client
                
                return user_client
                
            except Exception:
                return None
    
    async def _close_user_client(self, user_email: str):
        """Close user's MCP clients."""
        if user_email in self.user_clients:
            try:
                user_client = self.user_clients[user_email]
                
                for server_name, client in user_client.clients.items():
                    await _pool._close_client(client)
            except Exception:
                pass
            finally:
                del self.user_clients[user_email]
    
    async def refresh_user_client(
        self,
        user_email: str,
        permissions: list
    ) -> Optional[UserMCPClient]:
        """Refresh user client with updated permissions."""
        await self._close_user_client(user_email)
        return await self.get_user_client(user_email, permissions, force_new=True)
    
    async def start_background_tasks(self):
        """Start cleanup and health check tasks."""
        self.cleanup_task = asyncio.create_task(self._cleanup_idle_clients())
        self.health_check_task = asyncio.create_task(self._health_check_monitor())
    
    async def _cleanup_idle_clients(self):
        """Background task to cleanup idle clients."""
        while True:
            try:
                await asyncio.sleep(300)  # 5 minutes
                
                async with self.client_lock:
                    idle_users = [
                        email for email, client in self.user_clients.items()
                        if not client.is_healthy()
                    ]
                    
                    for user_email in idle_users:
                        await self._close_user_client(user_email)
                        
            except asyncio.CancelledError:
                break
            except Exception:
                pass
    
    async def _health_check_monitor(self):
        """Background health monitoring."""
        while True:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                for server_name, server_config in self._server_configs.items():
                    try:
                        client = await _pool._create_client(server_config.url)
                        
                        if await _pool._test_client(client):
                            self._health_tracker.mark_healthy(server_name)
                        else:
                            self._health_tracker.mark_unhealthy(server_name)
                        
                        await _pool._close_client(client)
                        
                    except Exception:
                        self._health_tracker.mark_unhealthy(server_name)
                
            except asyncio.CancelledError:
                break
            except Exception:
                pass
    
    async def get_client_stats(self) -> Dict:
        """Get statistics about active clients and server health."""
        async with self.client_lock:
            health_stats = self._health_tracker.get_stats()
            
            return {
                "active_clients": len(self.user_clients),
                "servers": {
                    name: {
                        "healthy": health_stats['health'][name],
                        "url": config.url,
                        "requires_auth": config.requires_auth,
                        "last_health_check": health_stats['last_check'][name],
                        "health_check_failures": health_stats['failures'][name]
                    }
                    for name, config in self._server_configs.items()
                },
                "clients": [
                    {
                        "user": email,
                        "created_at": client.created_at.isoformat(),
                        "last_used": client.last_used.isoformat(),
                        "request_count": client.request_count,
                        "permissions_count": len(client.permissions),
                        "connected_servers": list(client.clients.keys())
                    }
                    for email, client in self.user_clients.items()
                ]
            }
    
    async def close_all_clients(self):
        """Close all active clients."""
        async with self.client_lock:
            for user_email in list(self.user_clients.keys()):
                await self._close_user_client(user_email)
    
    async def disconnect(self):
        """Shutdown manager and cleanup resources."""
        if self.cleanup_task:
            self.cleanup_task.cancel()
            try:
                await self.cleanup_task
            except asyncio.CancelledError:
                pass
        
        if self.health_check_task:
            self.health_check_task.cancel()
            try:
                await self.health_check_task
            except asyncio.CancelledError:
                pass
        
        await self.close_all_clients()
    
    @property
    def connected(self) -> bool:
        """Check if at least one server is healthy."""
        health_stats = self._health_tracker.get_stats()
        return any(health_stats['health'].values())
    
    @property
    def is_reconnecting(self) -> bool:
        """Always False for new architecture."""
        return False
    
    @property
    def last_successful_connection(self) -> Optional[datetime]:
        """Get most recent successful health check."""
        health_stats = self._health_tracker.get_stats()
        valid_checks = [
            datetime.fromisoformat(ts)
            for ts in health_stats['last_check'].values()
            if ts
        ]
        return max(valid_checks) if valid_checks else None
    
    @property
    def connection_failures(self) -> int:
        """Get total connection failures across all servers."""
        health_stats = self._health_tracker.get_stats()
        return sum(health_stats['failures'].values())