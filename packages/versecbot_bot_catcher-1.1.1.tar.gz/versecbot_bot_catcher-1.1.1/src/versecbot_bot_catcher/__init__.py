from .plugin import BotCatcherPlugin

__all__ = [
    "BotCatcherPlugin",
]
