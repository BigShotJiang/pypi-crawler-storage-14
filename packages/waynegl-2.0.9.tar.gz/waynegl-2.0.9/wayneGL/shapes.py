# shapes.py
# Wayne Graphics - expanded shape classes for custom renderer

from wayneGL.core import Color, parse_color

class Shape:
    def __init__(self, color="black", visible=True):
        self._fill = parse_color(color)
        self.visible = visible

    def setFill(self, color):
        self._fill = parse_color(color)

    def draw(self, renderer):
        raise NotImplementedError


class Arc(Shape):
    def __init__(self, x, y, rx, ry, start_deg, end_deg, color="black"):
        super().__init__(color)
        self.x, self.y = x, y
        self.rx, self.ry = rx, ry
        self.start_deg, self.end_deg = start_deg, end_deg

    def draw(self, renderer):
        if not self.visible: return
        import math
        start = math.radians(self.start_deg)
        end = math.radians(self.end_deg)
        steps = max(12, int(abs(self.end_deg - self.start_deg)))
        for i in range(steps+1):
            t = start + (end-start)*i/steps
            x2 = self.x + int(self.rx*math.cos(t))
            y2 = self.y + int(self.ry*math.sin(t))
            renderer.draw_line(self.x, self.y, x2, y2, self._fill)


class Circle(Shape):
    def __init__(self, x, y, radius, color="black"):
        super().__init__(color)
        self.x, self.y = x, y
        self.radius = radius

    def draw(self, renderer):
        if self.visible:
            renderer.fill_circle(self.x, self.y, self.radius, self._fill)


class Polygon(Shape):
    def __init__(self, points, color="black"):
        super().__init__(color)
        self.points = list(points)

    def draw(self, renderer):
        if not self.visible or len(self.points) < 2: return
        for i in range(len(self.points)):
            x1,y1 = self.points[i]
            x2,y2 = self.points[(i+1)%len(self.points)]
            renderer.draw_line(x1,y1,x2,y2,self._fill)


class Rectangle(Shape):
    def __init__(self, x, y, width, height, color="black"):
        super().__init__(color)
        self.x,self.y = x,y
        self.width,self.height = width,height

    def draw(self, renderer):
        if self.visible:
            renderer.fill_rect(self.x,self.y,self.width,self.height,self._fill)


class Star(Shape):
    def __init__(self, x, y, radius, points=5, color="black"):
        super().__init__(color)
        self.x,self.y = x,y
        self.radius = radius
        self.points = points

    def draw(self, renderer):
        if not self.visible: return
        import math
        verts=[]
        for i in range(self.points*2):
            angle = math.pi*i/self.points
            r = self.radius if i%2==0 else self.radius//2
            verts.append((self.x+int(r*math.cos(angle)),
                          self.y+int(r*math.sin(angle))))
        for i in range(len(verts)):
            x1,y1=verts[i]
            x2,y2=verts[(i+1)%len(verts)]
            renderer.draw_line(x1,y1,x2,y2,self._fill)


class Line(Shape):
    def __init__(self, x1,y1,x2,y2,color="black"):
        super().__init__(color)
        self.x1,self.y1=x1,y1
        self.x2,self.y2=x2,y2

    def draw(self, renderer):
        if self.visible:
            renderer.draw_line(self.x1,self.y1,self.x2,self.y2,self._fill)


class Image(Shape):
    """Placeholder: draws a rectangle as image stand-in."""
    def __init__(self, x,y,width,height,color="black"):
        super().__init__(color)
        self.x,self.y=x,y
        self.width,self.height=width,height

    def draw(self, renderer):
        if self.visible:
            renderer.fill_rect(self.x,self.y,self.width,self.height,self._fill)


class Point(Shape):
    def __init__(self, x,y,color="black"):
        super().__init__(color)
        self.x,self.y=x,y

    def draw(self, renderer):
        if self.visible:
            renderer.draw_point(self.x,self.y,self._fill)