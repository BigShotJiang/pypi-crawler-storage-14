# core.py
# Wayne Graphics - custom renderer (no Tkinter canvas wrappers)
# Window + framebuffer + event loop + event bindings

import time
import threading
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple

try:
    import tkinter as tk
except ImportError as e:
    raise RuntimeError("WayneGraphics requires tkinter for the window shell.") from e


@dataclass
class Color:
    r: int
    g: int
    b: int

    def to_hex(self) -> str:
        # Convert to #RRGGBB for PhotoImage
        return f"#{self.r:02x}{self.g:02x}{self.b:02x}"

# Basic named colors (you can expand this)
NAMED_COLORS = {
    "black": Color(0, 0, 0),
    "white": Color(255, 255, 255),
    "red": Color(255, 0, 0),
    "green": Color(0, 255, 0),
    "blue": Color(0, 0, 255),
    "yellow": Color(255, 255, 0),
    "magenta": Color(255, 0, 255),
    "cyan": Color(0, 255, 255),
}


def parse_color(color: str | Tuple[int, int, int] | Color) -> Color:
    if isinstance(color, Color):
        return color
    if isinstance(color, tuple) and len(color) == 3:
        r, g, b = color
        return Color(int(r), int(g), int(b))
    if isinstance(color, str):
        c = NAMED_COLORS.get(color.lower())
        if c:
            return c
        # Try hex string like "#ff00aa"
        if color.startswith("#") and len(color) == 7:
            r = int(color[1:3], 16)
            g = int(color[3:5], 16)
            b = int(color[5:7], 16)
            return Color(r, g, b)
    # Fallback to black
    return NAMED_COLORS["black"]


class FrameBuffer:
    """
    A simple 2D framebuffer that stores per-pixel colors and can blit to a Tk PhotoImage.
    """

    def __init__(self, width: int, height: int, background: Color | None = None):
        self.width = width
        self.height = height
        self.background = background or NAMED_COLORS["white"]
        # Store as a flat list of hex strings for fast put() via PhotoImage
        self._pixels = [self.background.to_hex()] * (width * height)

    def clear(self, color: Color | None = None):
        c = (color or self.background).to_hex()
        self._pixels = [c] * (self.width * self.height)

    def set_pixel(self, x: int, y: int, color: Color):
        if 0 <= x < self.width and 0 <= y < self.height:
            self._pixels[y * self.width + x] = color.to_hex()

    def get_pixel(self, x: int, y: int) -> Color:
        if 0 <= x < self.width and 0 <= y < self.height:
            # Convert back from hex if needed; here we just return named color if matched
            hex_str = self._pixels[y * self.width + x]
            # Not decoding for speed; return black placeholder
            return NAMED_COLORS["black"]
        return NAMED_COLORS["black"]

    def blit_to(self, photo: tk.PhotoImage):
        """
        Push the whole framebuffer into the PhotoImage using put().
        For performance, we push rows as sequences to reduce overhead.
        """
        w, h = self.width, self.height
        # PhotoImage.put accepts a color string or a tuple/list of colors for a single row.
        # We'll update the entire image row by row.
        for y in range(h):
            row_start = y * w
            row_pixels = self._pixels[row_start:row_start + w]
            # Build a Tcl-compatible pixel row: a space-separated list of colors
            photo.put(" ".join(row_pixels), to=(0, y, w, y + 1))


class Renderer2D:
    """
    A minimal 2D renderer with basic primitives drawn into the FrameBuffer.
    """

    def __init__(self, fb: FrameBuffer):
        self.fb = fb

    # --- Primitives ---

    def draw_point(self, x: int, y: int, color: Color):
        self.fb.set_pixel(x, y, color)

    def draw_line(self, x0: int, y0: int, x1: int, y1: int, color: Color):
        # Bresenham's line algorithm
        dx = abs(x1 - x0)
        dy = -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            self.draw_point(x0, y0, color)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def fill_rect(self, x: int, y: int, w: int, h: int, color: Color):
        for yy in range(y, y + h):
            if 0 <= yy < self.fb.height:
                for xx in range(x, x + w):
                    if 0 <= xx < self.fb.width:
                        self.fb.set_pixel(xx, yy, color)

    def fill_circle(self, cx: int, cy: int, r: int, color: Color):
        # Midpoint circle fill (scanline)
        for y in range(-r, r + 1):
            row_y = cy + y
            if 0 <= row_y < self.fb.height:
                # Compute horizontal span for this y
                # x^2 + y^2 <= r^2 => x <= sqrt(r^2 - y^2)
                max_x = int((r*r - y*y) ** 0.5)
                for x in range(-max_x, max_x + 1):
                    col_x = cx + x
                    if 0 <= col_x < self.fb.width:
                        self.fb.set_pixel(col_x, row_y, color)

    def fill_ellipse(self, cx: int, cy: int, rx: int, ry: int, color: Color):
        # Ellipse equation: (x^2 / rx^2) + (y^2 / ry^2) <= 1
        rx2 = rx * rx
        ry2 = ry * ry
        for y in range(-ry, ry + 1):
            row_y = cy + y
            if 0 <= row_y < self.fb.height:
                max_x = int((rx * (1 - (y*y)/ry2)) ** 0.5)
                for x in range(-max_x, max_x + 1):
                    col_x = cx + x
                    if 0 <= col_x < self.fb.width:
                        self.fb.set_pixel(col_x, row_y, color)

    # You can add arc, polygon, text (bitmap font) here as needed.


class WayneGraphics:
    """
    Main window + renderer + event loop.
    Provides:
      - add(drawable): register a drawable object (must implement draw(renderer))
      - onMousePress(func(x, y)), onMouseRelease, onMouseMove
      - onKeyPress(func(char)), onKeyRelease
      - onStep(func, delay_ms): periodic callback
      - run(): starts the GUI loop and render thread
    """

    def __init__(self, width: int = 600, height: int = 400, title: str = "Wayne Graphics"):
        self.width = width
        self.height = height
        self.title = title

        # Tk window shell
        self.root = tk.Tk()
        self.root.title(self.title)

        # PhotoImage used as our display surface
        self.photo = tk.PhotoImage(width=self.width, height=self.height)
        self.label = tk.Label(self.root, image=self.photo)
        self.label.pack()

        # Double buffer: draw to back buffer, then blit to PhotoImage
        self.front = FrameBuffer(self.width, self.height)
        self.back = FrameBuffer(self.width, self.height)
        self.renderer = Renderer2D(self.back)

        # Drawables list (objects with draw(renderer))
        self._drawables: List[object] = []

        # Event handlers
        self._on_mouse_press: Optional[Callable[[int, int], None]] = None
        self._on_mouse_release: Optional[Callable[[int, int], None]] = None
        self._on_mouse_move: Optional[Callable[[int, int], None]] = None
        self._on_key_press: Optional[Callable[[str], None]] = None
        self._on_key_release: Optional[Callable[[str], None]] = None

        # Step/animation
        self._step_func: Optional[Callable[[], None]] = None
        self._step_delay_ms: int = 0
        self._running = False

        # Bind events to the label (the display surface)
        self._bind_events()

    # --- Public API ---

    def add(self, drawable: object):
        """
        Register a drawable that implements draw(renderer).
        """
        if hasattr(drawable, "draw") and callable(drawable.draw):
            self._drawables.append(drawable)
        else:
            raise TypeError("Drawable must implement a draw(renderer) method.")

    def remove(self, drawable: object):
        if drawable in self._drawables:
            self._drawables.remove(drawable)

    # Event registration
    def onMousePress(self, func: Callable[[int, int], None]):
        self._on_mouse_press = func

    def onMouseRelease(self, func: Callable[[int, int], None]):
        self._on_mouse_release = func

    def onMouseMove(self, func: Callable[[int, int], None]):
        self._on_mouse_move = func

    def onKeyPress(self, func: Callable[[str], None]):
        self._on_key_press = func

    def onKeyRelease(self, func: Callable[[str], None]):
        self._on_key_release = func

    def onStep(self, func: Callable[[], None], delay_ms: int = 16):
        self._step_func = func
        self._step_delay_ms = max(1, int(delay_ms))

    def run(self):
        """
        Start render loop and Tk main loop.
        """
        self._running = True
        # Kick off the periodic step timer if provided
        if self._step_func:
            self._schedule_step()

        # Start the render thread for smooth updates
        render_thread = threading.Thread(target=self._render_loop, daemon=True)
        render_thread.start()

        # Tk mainloop
        self.root.mainloop()
        self._running = False

    # --- Internal ---

    def _bind_events(self):
        # Mouse
        self.label.bind("<Button-1>", lambda e: self._on_mouse_press and self._on_mouse_press(e.x, e.y))
        self.label.bind("<ButtonRelease-1>", lambda e: self._on_mouse_release and self._on_mouse_release(e.x, e.y))
        self.label.bind("<Motion>", lambda e: self._on_mouse_move and self._on_mouse_move(e.x, e.y))
        # Keyboard (bind to root for focus)
        self.root.bind("<KeyPress>", lambda e: self._on_key_press and self._on_key_press(e.char))
        self.root.bind("<KeyRelease>", lambda e: self._on_key_release and self._on_key_release(e.char))

    def _schedule_step(self):
        if not self._running:
            return
        self.root.after(self._step_delay_ms, self._step_tick)

    def _step_tick(self):
        if self._step_func:
            try:
                self._step_func()
            except Exception as ex:
                print("onStep error:", ex)
        self._schedule_step()

    def _render_loop(self):
        """
        Continuous render loop:
          - clear back buffer
          - draw all drawables
          - blit back to PhotoImage
          - swap buffers
        """
        target_fps = 60
        frame_time = 1.0 / target_fps
        while self._running:
            start = time.time()

            # Clear back buffer
            self.back.clear()

            # Draw each drawable
            for drawable in list(self._drawables):
                try:
                    drawable.draw(self.renderer)
                except Exception as ex:
                    print("Draw error:", ex)

            # Blit to PhotoImage
            try:
                self.back.blit_to(self.photo)
            except Exception as ex:
                print("Blit error:", ex)

            # Swap buffers (not strictly necessary since we rebuild each frame)
            self.front, self.back = self.back, self.front
            self.renderer.fb = self.back  # renderer now draws into the (new) back

            # Cap frame rate
            elapsed = time.time() - start
            sleep_time = frame_time - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)