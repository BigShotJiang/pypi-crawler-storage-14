# widgets.py
# Wayne Graphics - basic interactive widgets built from shapes + events

from wayneGL.shapes import Rectangle, Text
from wayneGL.core import parse_color, Color

class Widget:
    """Base class for all widgets."""
    def __init__(self, x, y, width, height, color="lightgray"):
        self.x, self.y = x, y
        self.width, self.height = width, height
        self.color = parse_color(color)
        self.visible = True
        self._handlers = {}

    def on(self, event_name, handler):
        """Register a handler for widget-specific events (e.g., 'click')."""
        self._handlers[event_name] = handler

    def emit(self, event_name, *args, **kwargs):
        if event_name in self._handlers:
            self._handlers[event_name](*args, **kwargs)

    def contains(self, px, py):
        """Check if a point is inside the widget bounds."""
        return (self.x <= px <= self.x+self.width and
                self.y <= py <= self.y+self.height)

    def draw(self, renderer):
        if self.visible:
            renderer.fill_rect(self.x, self.y, self.width, self.height, self.color)


class Button(Widget):
    def __init__(self, x, y, width, height, label="Button", color="lightgray", text_color="black"):
        super().__init__(x, y, width, height, color)
        self.label = label
        self.text_color = parse_color(text_color)

    def draw(self, renderer):
        super().draw(renderer)
        # Draw label as block text
        Text(self.x+5, self.y+5, self.label, self.text_color).draw(renderer)

    def click(self, px, py):
        if self.contains(px, py):
            self.emit("click")


class Label(Widget):
    def __init__(self, x, y, text, text_color="black"):
        super().__init__(x, y, 0, 0, color="white")
        self.text = text
        self.text_color = parse_color(text_color)

    def draw(self, renderer):
        Text(self.x, self.y, self.text, self.text_color).draw(renderer)


class Slider(Widget):
    def __init__(self, x, y, width, min_val=0, max_val=100, value=0, color="lightgray", knob_color="blue"):
        super().__init__(x, y, width, 20, color)
        self.min_val, self.max_val = min_val, max_val
        self.value = value
        self.knob_color = parse_color(knob_color)

    def draw(self, renderer):
        # Draw track
        super().draw(renderer)
        # Draw knob position
        knob_x = self.x + int((self.value-self.min_val)/(self.max_val-self.min_val)*self.width)
        renderer.fill_rect(knob_x-5, self.y, 10, self.height, self.knob_color)

    def setValueFromPos(self, px):
        if self.contains(px, self.y):
            ratio = (px-self.x)/self.width
            self.value = self.min_val + ratio*(self.max_val-self.min_val)
            self.emit("change", self.value)