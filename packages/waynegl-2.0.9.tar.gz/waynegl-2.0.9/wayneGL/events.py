# events.py
# Wayne Graphics - event dispatcher for custom renderer

from typing import Callable, Dict, List, Any

class EventBus:
    """
    Minimal event bus to register and emit events by name.
    WayneGraphics can bridge its Tk bindings into this bus.
    """

    def __init__(self):
        self._handlers: Dict[str, List[Callable[..., Any]]] = {}

    # Registration
    def on(self, name: str, handler: Callable[..., Any]):
        """Register a handler for a given event name."""
        self._handlers.setdefault(name, []).append(handler)

    def off(self, name: str, handler: Callable[..., Any]):
        """Remove a handler for a given event name."""
        if name in self._handlers:
            try:
                self._handlers[name].remove(handler)
            except ValueError:
                pass

    def clear(self, name: str | None = None):
        """Clear handlers for one event or all events."""
        if name is None:
            self._handlers.clear()
        else:
            self._handlers.pop(name, None)

    # Emission
    def emit(self, name: str, *args, **kwargs):
        """Call all handlers registered for this event name."""
        for h in list(self._handlers.get(name, [])):
            try:
                h(*args, **kwargs)
            except Exception as ex:
                print(f"Event '{name}' handler error:", ex)


# Convenience wrappers to mirror WayneGraphics API
def onMousePress(bus: EventBus, func: Callable[[int, int], None]):
    bus.on("mouse_press", func)

def onMouseRelease(bus: EventBus, func: Callable[[int, int], None]):
    bus.on("mouse_release", func)

def onMouseMove(bus: EventBus, func: Callable[[int, int], None]):
    bus.on("mouse_move", func)

def onKeyPress(bus: EventBus, func: Callable[[str], None]):
    bus.on("key_press", func)

def onKeyRelease(bus: EventBus, func: Callable[[str], None]):
    bus.on("key_release", func)

def onStep(bus: EventBus, func: Callable[[], None]):
    bus.on("step", func)