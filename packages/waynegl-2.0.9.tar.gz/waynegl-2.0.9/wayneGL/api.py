import json
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

# Import your new shape classes
from wayneGL.shapes import Circle, Rectangle, Text

class Route:
    def __init__(self, app=None) -> None:
        self.routes = {}
        self.app = app

    def add(self, path: str, method: str, handler):
        key = (path.lower(), method.upper())
        self.routes[key] = handler

    def remove(self, path: str, method: str):
        key = (path.lower(), method.upper())
        if key in self.routes:
            del self.routes[key]

    def dispatch(self, path: str, method: str, request: dict):
        key = (path.lower(), method.upper())
        handler = self.routes.get(key)
        if not handler:
            return {"status": "error", "message": f"No route for {method} {path}"}
        try:
            return handler(request)
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ---------- Shape Routes ----------
    def register_shape_routes(self):
        def create_circle(req):
            x = int(req.get("x", 100))
            y = int(req.get("y", 100))
            r = int(req.get("radius", 50))
            color = req.get("color", "blue")
            if not self.app:
                return {"status": "error", "message": "No app available"}
            shape = Circle(x, y, r, color=color)
            self.app.add(shape)
            return {"status": "ok", "message": f"Circle at ({x},{y}) r={r}", "id": id(shape)}

        self.add("/circle", "POST", create_circle)
        self.add("/circle", "GET", create_circle)

        def create_rect(req):
            x = int(req.get("x", 50))
            y = int(req.get("y", 50))
            w = int(req.get("width", 100))
            h = int(req.get("height", 50))
            color = req.get("color", "red")
            if not self.app:
                return {"status": "error", "message": "No app available"}
            shape = Rectangle(x, y, w, h, color=color)
            self.app.add(shape)
            return {"status": "ok", "message": f"Rect at ({x},{y}) {w}x{h}", "id": id(shape)}

        self.add("/rect", "POST", create_rect)
        self.add("/rect", "GET", create_rect)

        def create_text(req):
            x = int(req.get("x", 200))
            y = int(req.get("y", 200))
            text = req.get("text", "Hello")
            color = req.get("color", "black")
            if not self.app:
                return {"status": "error", "message": "No app available"}
            shape = Text(x, y, text, color=color)
            self.app.add(shape)
            return {"status": "ok", "message": f"Text '{text}' at ({x},{y})", "id": id(shape)}

        self.add("/text", "POST", create_text)
        self.add("/text", "GET", create_text)

    # ---------- Root Route ----------
    def register_root(self):
        def root_message(req):
            return {"status": "ok", "message": "Wayne-API is running"}
        self.add("/", "GET", root_message)


# ---------- HTTP Server ----------
class APIServer(BaseHTTPRequestHandler):
    router: Route = None  # shared router instance

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8")
        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            self._send_json({"status": "error", "message": "Invalid JSON"}, 400)
            return

        result = self.router.dispatch(self.path, "POST", data)
        self._send_json(result)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        result = self.router.dispatch(parsed.path, "GET", params)
        self._send_json(result)


def run_server(router: Route, host="127.0.0.1", port=5000):
    APIServer.router = router
    server = HTTPServer((host, port), APIServer)
    print(f"Wayne-API running on http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down Wayne-API...")
        server.server_close()