# pyg_lib

A Python package library.

## Installation

```bash
pip install pyg_lib
```

## Usage

```python
from pyg_lib import hello

print(hello())
```

## License

MIT License

