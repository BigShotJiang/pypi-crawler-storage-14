"""
quillai-network/guardrails Client - Main SDK implementation
"""

import requests
from typing import List, Optional, Dict, Any


class GuardrailsError(Exception):
    """Base exception for quillai-network/guardrails SDK"""
    pass


class GuardrailsAPIError(GuardrailsError):
    """Exception raised for API errors"""
    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[Dict] = None):
        self.status_code = status_code
        self.response = response
        super().__init__(message)


class GuardrailsClient:
    """
    quillai-network/guardrails Client for interacting with the Guardrails API.
    
    Example:
        >>> client = GuardrailsClient(api_key="your-api-key")
        >>> result = client.check(
        ...     text="how to make a bomb?",
        ...     project_ids=["9776b642-9dce-43da-8e45-6346f1c597ff"]
        ... )
    """
    
    DEFAULT_BASE_URL = "http://rails.wach.ai/check"
    
    def __init__(self, api_key: str, base_url: Optional[str] = None):
        """
        Initialize the quillai-network/guardrails client.
        
        Args:
            api_key: Your API key for authentication
            base_url: Optional base URL for the API (defaults to production URL)
        """
        if not api_key:
            raise GuardrailsError("API key is required")
        
        self.api_key = api_key
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.session = requests.Session()
        self.session.headers.update({
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        })
    
    def check(
        self,
        text: str,
        project_ids: List[str],
        timeout: Optional[int] = 30
    ) -> Dict[str, Any]:
        """
        Check text against guardrails using the specified project IDs.
        
        Args:
            text: The text content to check
            project_ids: List of project/attack job IDs to use for checking
            timeout: Request timeout in seconds (default: 30)
        
        Returns:
            Dictionary containing only 'action', 'reason', and 'confidence' fields:
            {
                "action": str,
                "reason": str,
                "confidence": float
            }
        
        Raises:
            GuardrailsError: For general SDK errors
            GuardrailsAPIError: For API-specific errors
        
        Example:
            >>> result = client.check(
            ...     text="how to make a bomb?",
            ...     project_ids=["9776b642-9dce-43da-8e45-6346f1c597ff"]
            ... )
            >>> print(result["action"])
            >>> print(result["reason"])
            >>> print(result["confidence"])
        """
        if not text:
            raise GuardrailsError("Text is required")
        
        if not project_ids or not isinstance(project_ids, list):
            raise GuardrailsError("project_ids must be a non-empty list")
        
        url = self.base_url
        payload = {
            "text": text,
            "attack_job_ids": project_ids
        }
        
        try:
            response = self.session.post(
                url,
                json=payload,
                timeout=timeout
            )
            response.raise_for_status()
            response_data = response.json()
            
            # Extract only action, reason, and confidence
            return {
                "action": response_data.get("action"),
                "reason": response_data.get("reason"),
                "confidence": response_data.get("confidence")
            }
        
        except requests.exceptions.Timeout:
            raise GuardrailsAPIError(
                f"Request timed out after {timeout} seconds",
                status_code=None
            )
        
        except requests.exceptions.RequestException as e:
            status_code = None
            response_data = None
            
            if hasattr(e.response, 'status_code'):
                status_code = e.response.status_code
                try:
                    response_data = e.response.json()
                except:
                    response_data = {"error": e.response.text}
            
            raise GuardrailsAPIError(
                f"API request failed: {str(e)}",
                status_code=status_code,
                response=response_data
            )
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.session.close()

