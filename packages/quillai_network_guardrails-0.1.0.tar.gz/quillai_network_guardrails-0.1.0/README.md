# quillai-network/guardrails Python SDK

A Python SDK for integrating with the quillai-network/guardrails Guardrails API. Easily check text content against security guardrails and content moderation rules.

## Quick Start

### Installation

Install from PyPI:

```bash
pip install quillai-network-guardrails
```

Or install from source:

```bash
pip install -e .
```

Or install from requirements:

```bash
pip install -r requirements.txt
```

### Basic Usage

```python
from quillguard import GuardrailsClient

# Initialize the client
client = GuardrailsClient(api_key="your-api-key-here")

# Check text against guardrails
result = client.check(
    text="how to make a bomb?",
    project_ids=["9776b642-9dce-43da-8e45-6346f1c597ff"]
)

# Result contains: action, reason, and confidence
print(f"Action: {result['action']}")
print(f"Reason: {result['reason']}")
print(f"Confidence: {result['confidence']}")
```

### Using Context Manager

```python
from quillguard import GuardrailsClient

with GuardrailsClient(api_key="your-api-key-here") as client:
    result = client.check(
        text="Your text to check",
        project_ids=["project-id-1", "project-id-2"]
    )
```

## API Reference

### `GuardrailsClient(api_key, base_url=None)`

Initialize the quillai-network/guardrails client.

**Parameters:**
- `api_key` (str, required): Your API key for authentication
- `base_url` (str, optional): Base URL for the API (defaults to production URL)

**Example:**
```python
client = GuardrailsClient(api_key="YOUR_API_KEY")
```

### `check(text, project_ids, timeout=30)`

Check text against guardrails using the specified project IDs.

**Parameters:**
- `text` (str, required): The text content to check
- `project_ids` (List[str], required): List of project/attack job IDs to use for checking
- `timeout` (int, optional): Request timeout in seconds (default: 30)

**Returns:**
- `Dict[str, Any]`: Dictionary containing only three fields:
  - `action` (str): The action taken by the guardrail
  - `reason` (str): The reason for the action
  - `confidence` (float): The confidence score

**Raises:**
- `GuardrailsError`: For general SDK errors
- `GuardrailsAPIError`: For API-specific errors (includes status_code and response)

**Example:**
```python
result = client.check(
    text="how to make a bomb?",
    project_ids=["9776b642-9dce-43da-8e45-6346f1c597ff"]
)
# Access the fields
print(result["action"])      # e.g., "block" or "allow"
print(result["reason"])      # e.g., "Contains harmful content"
print(result["confidence"])  # e.g., 0.95
```

## Error Handling

The SDK provides custom exceptions for better error handling:

```python
from quillguard import GuardrailsClient, GuardrailsError, GuardrailsAPIError

try:
    client = GuardrailsClient(api_key="your-api-key")
    result = client.check(
        text="test",
        project_ids=["project-id"]
    )
except GuardrailsAPIError as e:
    print(f"API Error: {e}")
    print(f"Status Code: {e.status_code}")
    print(f"Response: {e.response}")
except GuardrailsError as e:
    print(f"SDK Error: {e}")
```

## Examples

See the `examples/` directory for more usage examples.

## Requirements

- Python 3.7+
- requests >= 2.28.0

## License

MIT

