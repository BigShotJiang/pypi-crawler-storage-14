"""CLI package for LFCS Practice Tool"""
