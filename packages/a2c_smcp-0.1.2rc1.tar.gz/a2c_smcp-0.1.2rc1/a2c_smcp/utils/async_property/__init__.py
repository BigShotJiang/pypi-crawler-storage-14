# -*- coding: utf-8 -*-
# filename: __init__.py.py
# @Time    : 2025/8/18 17:08
# @Author  : JQQ
# @Email   : jqq1716@gmail.com
# @Software: PyCharm
from .base import async_property

__all__ = ["async_property"]
