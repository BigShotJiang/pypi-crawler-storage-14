"""
文件名: __init__.py
作者: JQQ
创建日期: 2025/9/22
最后修改日期: 2025/9/22
版权: 2023 JQQ. All rights reserved.
依赖: None
描述:
  中文: e2e 测试包初始化文件。
  English: e2e tests package initializer.
"""
