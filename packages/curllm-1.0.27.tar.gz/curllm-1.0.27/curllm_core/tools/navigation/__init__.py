"""Navigation tools - page scrolling, pagination, category selection"""
