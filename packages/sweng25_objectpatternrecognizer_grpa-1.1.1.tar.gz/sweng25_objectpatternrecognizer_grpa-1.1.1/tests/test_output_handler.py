"""
test_output_handler.py

Unit tests for the OutputHandler class in the output_handler package.

These tests verify the integration of image display, logging, and text-to-speech functionality:
- Ensures that an OutputHandler instance can be created with the given configuration.
- Tests that the handle() method correctly logs new shapes and updates the log file.
- Verifies that multiple changes in detected shapes result in multiple log entries.
- Checks that duplicate detections are ignored by the internal _same_list_as_before() method.
- Confirms that the close() method properly shuts down services without errors.

All tests use temporary paths provided by pytest to avoid side effects and clean up after execution.
"""

import numpy as np
from sweng25_objectpatternrecognizer_grpa.output_handler.output_handler import (
    OutputHandler,
)


def test_outputhandler_can_be_created(tmp_path):
    """
    Test if an OutputHandler instance can be successfully created.

    Args:
        tmp_path (Path): Temporary path provided by pytest for file creation.
    """
    log_file = tmp_path / "output.csv"
    img_file = tmp_path / "img_output.png"
    config = {
        "output": {
            "image": {"show": False, "save": False, "path": str(img_file)},
            "log": {"enabled": True, "path": str(log_file)},
            "tts": {"enabled": False},
        }
    }
    handler = OutputHandler(config)
    assert handler is not None


def test_handle_new_shapes(tmp_path):
    """
    Test the handle() method for a single list of new shapes.

    Verifies that the log file is updated correctly when new shapes are handled.

    Args:
        tmp_path (Path): Temporary path provided by pytest for file creation.
    """
    log_file = tmp_path / "output.csv"
    img_file = tmp_path / "img_output.png"
    config = {
        "output": {
            "image": {"show": False, "save": False, "path": str(img_file)},
            "log": {"enabled": True, "path": str(log_file)},
            "tts": {"enabled": False},
        }
    }
    handler = OutputHandler(config)

    fake_frame = np.zeros((10, 10, 3), dtype=np.uint8)
    shapes = [["circle", "red"]]

    handler.handle(fake_frame, shapes)

    with open(log_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
    assert len(lines) == 1  # 1 shape


def test_handle_changed_shapes(tmp_path):
    """
    Test the handle() method for multiple changes in shape lists.

    Verifies that the log file contains entries for each distinct shape list.

    Args:
        tmp_path (Path): Temporary path provided by pytest for file creation.
    """
    log_file = tmp_path / "output.csv"
    img_file = tmp_path / "img_output.png"
    config = {
        "output": {
            "image": {"show": False, "save": False, "path": str(img_file)},
            "log": {"enabled": True, "path": str(log_file)},
            "tts": {"enabled": False},
        }
    }
    handler = OutputHandler(config)

    fake_frame = np.zeros((10, 10, 3), dtype=np.uint8)
    shapes1 = [["triangle", "green"]]
    shapes2 = [["rectangle", "red"]]

    handler.handle(fake_frame, shapes1)
    handler.handle(fake_frame, shapes2)

    with open(log_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
    assert len(lines) == 2  # 2 entries


def test_same_list_as_before(tmp_path):
    """
    Test the _same_list_as_before() internal method.

    Checks that the method returns True for the first call with a list and False for the next call
    with the same list, simulating change detection logic.

    Args:
        tmp_path (Path): Temporary path provided by pytest for file creation.
    """
    log_file = tmp_path / "output.csv"
    img_file = tmp_path / "img_output.png"
    config = {
        "output": {
            "image": {"show": False, "save": False, "path": str(img_file)},
            "log": {"enabled": True, "path": str(log_file)},
            "tts": {"enabled": False},
        }
    }
    handler = OutputHandler(config)
    shapes = [{"name": "circle", "color": "red"}]
    assert handler._same_list_as_before(shapes) is True
    assert handler._same_list_as_before(shapes) is False


def test_close_all(tmp_path):
    """
    Test that close() method of OutputHandler can be called without errors.

    Ensures that all resources (like log file handles) are properly closed.

    Args:
        tmp_path (Path): Temporary path provided by pytest for file creation.
    """
    log_file = tmp_path / "output.csv"
    img_file = tmp_path / "img_output.png"
    config = {
        "output": {
            "image": {"show": False, "save": False, "path": str(img_file)},
            "log": {"enabled": True, "path": str(log_file)},
            "tts": {"enabled": False},
        }
    }
    handler = OutputHandler(config)
    handler.close()
