"""Pytests for the argparser module."""

import pytest
from sweng25_objectpatternrecognizer_grpa.utils import ArgParser


# pylint: disable=redefined-outer-name
@pytest.fixture
def parser():
    """Fixture to provide a fresh ArgParser instance for each test."""
    return ArgParser().parser


def test_valid_config_path(tmp_path, parser):
    """Test that a valid config path is set correctly."""
    config_path = tmp_path / "test_config.json"
    config_path.touch()
    args = parser.parse_args(["--config_path", str(config_path)])
    assert args.config_path == str(config_path)


def test_invalid_config_path(parser, capsys):
    """Test invalid config path triggers an error."""
    with pytest.raises(SystemExit) as exit_info:
        parser.parse_args(["--config_path", "nonexisting.json"])
    captured = capsys.readouterr()
    assert exit_info.value.code == 2
    assert "does not exist" in str(captured.err)


def test_config_path_wrong_file_type(tmp_path, parser, capsys):
    """Test config file path with wrong file type triggers an error."""
    config_path = tmp_path / "test_config.png"
    config_path.touch()
    with pytest.raises(SystemExit) as exit_info:
        parser.parse_args(["--config_path", str(config_path)])
    captured = capsys.readouterr()
    assert exit_info.value.code == 2
    assert "must be one of" in str(captured.err)


def test_valid_image_path(tmp_path, parser):
    """Test that a valid image path is set correctly."""
    image_file = tmp_path / "test_image.jpg"
    image_file.touch()
    args = parser.parse_args(["--source", "image", "--image_path", str(image_file)])
    assert args.source == "image"
    assert args.image_path == str(image_file)
    assert args.headless is False


def test_invalid_image_path(parser, capsys):
    """Test invalid config path triggers an error."""
    with pytest.raises(SystemExit) as exit_info:
        parser.parse_args(["--source", "image", "--image_path", "nonexisting.png"])
    captured = capsys.readouterr()
    assert exit_info.value.code == 2
    assert "does not exist" in str(captured.err)


def test_image_path_wrong_file_type(tmp_path, parser, capsys):
    """Test image file path with wrong file type triggers an error."""
    image_path = tmp_path / "test_image.json"
    image_path.touch()
    with pytest.raises(SystemExit) as exit_info:
        parser.parse_args(["--image_path", str(image_path)])
    captured = capsys.readouterr()
    assert exit_info.value.code == 2
    assert "must be one of" in str(captured.err)


def test_valid_camera_index(parser):
    """Test that a valid camera index is set correctly."""
    args = parser.parse_args(
        ["--source", "camera", "--camera_index", "0", "--headless"]
    )
    assert args.source == "camera"
    assert args.camera_index == 0
    assert args.headless is True


def test_invalid_camera_index(parser, capsys):
    """Test that a invalid camera index triggers an error."""
    with pytest.raises(SystemExit) as exit_info:
        parser.parse_args(["--source", "camera", "--camera_index", "one"])
    captured = capsys.readouterr()
    assert exit_info.value.code == 2
    assert "invalid int value" in str(captured.err)


def test_invalid_source(parser, capsys):
    """Test parsing arguments with a invalid source triggers an error."""
    with pytest.raises(SystemExit) as exit_info:
        parser.parse_args(["--source", "video"])
    captured = capsys.readouterr()
    assert exit_info.value.code == 2
    assert "invalid choice" in str(captured.err)


def test_help_message(parser, capsys):
    """Test that help message can be printed without errors."""
    with pytest.raises(SystemExit):
        parser.parse_args(["--help"])
    captured = capsys.readouterr()
    assert "--config_path" in captured.out
    assert "--source" in captured.out
    assert "--image_path" in captured.out
    assert "--camera_index" in captured.out
    assert "--headless" in captured.out
