"""
test_log_service.py

Unit tests for the LogService class in the output_handler package.

These tests verify the logging functionality used to record detected shapes and colors:
- Ensures that the log file is correctly created and initialized with headers.
- Verifies that entries are properly written to the CSV file with accurate data.
- Confirms that shape filtering via the allowed_shapes parameter works as intended.
- Checks that logging is skipped when the service is disabled.
- Cleans up temporary test files after test execution to prevent side effects.
"""

import os
import csv
from sweng25_objectpatternrecognizer_grpa.output_handler.log_service import LogService


def test_log_file_creation():
    """
    Test funciton to check if file gets created
    """
    log_path = "test_output.csv"
    if os.path.exists(log_path):
        os.remove(log_path)


def test_write_entry(tmp_path):
    """
    Test function to write into csv-file and check for correct placement of log.
    """
    log_path = tmp_path / "test_output.csv"
    logger = LogService(log_path=str(log_path), enable=True)
    logger.clear_log()
    logger.write("square", "blue")

    with open(log_path, newline="") as log_file:
        reader = list(csv.reader(log_file))
        header = reader[0]
        row = reader[1]

    assert header == ["timestamp", "shape", "color"]
    assert row[1] == "square"
    assert row[2] == "blue"


def test_shapes_filter(tmp_path):
    """
    Test function that checks the ability to log only allowed shapes in case a filter will be needed.
    """
    if os.path.exists("test_output.csv"):
        os.remove("test_output.csv")
    log_path = tmp_path / "test_output.csv"
    logger = LogService(log_path=str(log_path), enable=True, allowed_shapes=["square"])
    logger.clear_log()
    logger.write("circle", "blue")
    logger.write("square", "yellow")

    with open(log_path, newline="") as log_file:
        reader = list(csv.reader(log_file))
        assert len(reader) == 2
        assert reader[1][1] == "square"


def test_logging_disabled(tmp_path):
    """
    Test that nothing is logged if enable=False.
    """
    log_path = tmp_path / "test_output.csv"
    if os.path.exists(log_path):
        os.remove(log_path)

    logger = LogService(log_path=str(log_path), enable=False)
    logger.write("square", "blue")

    assert not os.path.exists(log_path) or os.path.getsize(log_path) == 0


def test_cleanup():
    """
    Remove the test_output.csv file after testing.
    """
    test_file = "test_output.csv"
    if os.path.exists(test_file):
        os.remove(test_file)
