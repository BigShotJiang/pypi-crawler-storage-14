from unittest.mock import MagicMock, patch
import pytest
import cv2
import numpy as np
from sweng25_objectpatternrecognizer_grpa.gui.main_window import MainWindow
from sweng25_objectpatternrecognizer_grpa.gui.callbacks import MainFunctions
from sweng25_objectpatternrecognizer_grpa.config_service import ConfigService


@pytest.fixture
def main_window(monkeypatch):
    """Erstellt ein MainWindow-Objekt mit deaktiviertem mainloop."""
    monkeypatch.setattr("customtkinter.CTk.mainloop", lambda self: None)
    cfg_service = ConfigService(config_path="./sweng25_objectpatternrecognizer_grpa/config/config.json")
    cfg = cfg_service.get_config()
    window = MainWindow(cfg)
    return window


def test_initialization(main_window):
    """Testet, ob MainWindow korrekt initialisiert wurde."""
    assert isinstance(main_window._side_bar, object)
    assert callable(main_window._callbacks.on_close)
    assert main_window.title() == "Object Pattern Recognizer"


def test_set_callbacks_updates_sidebar(main_window):
    """Testet, ob set_callbacks die Sidebar korrekt aktualisiert."""
    mock_callbacks = MainFunctions(
        on_file_open=MagicMock(),
        on_stream_start=MagicMock(),
        on_settings_open=MagicMock(),
        on_save=MagicMock(),
        on_close=MagicMock(),
    )

    # Mock sidebar.set_callbacks
    main_window._side_bar.set_callbacks = MagicMock()

    main_window.set_callbacks(mock_callbacks)

    main_window._side_bar.set_callbacks.assert_called_once_with(mock_callbacks)
    assert main_window._callbacks is mock_callbacks


def test_update_frame(main_window):
    """Testet update_frame mit einem simulierten OpenCV-Frame."""
    # Dummy frame (rot, 640x480)
    frame = np.zeros((480, 640, 3), dtype=np.uint8)
    frame[:, :, 2] = 255

    # Simuliere Bildanzeige
    main_window._display_label.configure = MagicMock()

    main_window.update_frame(frame)

    main_window._display_label.configure.assert_called_once()
    args, kwargs = main_window._display_label.configure.call_args
    assert "image" in kwargs
    assert "text" in kwargs
    assert kwargs["text"] == ""


def test_exit_calls_on_close(main_window):
    """Testet, ob exit() den on_close Callback aufruft."""
    mock_close = MagicMock()
    main_window._callbacks.on_close = mock_close

    main_window.exit()

    mock_close.assert_called_once()


def test_run_starts_mainloop(monkeypatch):
    """Testet, ob run() die Tkinter-Mainloop aufruft."""
    called = {}

    def fake_mainloop(self):
        called["mainloop"] = True

    monkeypatch.setattr("customtkinter.CTk.mainloop", fake_mainloop)
    config_service = ConfigService(config_path="./sweng25_objectpatternrecognizer_grpa/config/config.json")
    cfg = config_service.get_config()
    window = MainWindow(cfg=cfg)
    window.run()

    assert called.get("mainloop", False)
