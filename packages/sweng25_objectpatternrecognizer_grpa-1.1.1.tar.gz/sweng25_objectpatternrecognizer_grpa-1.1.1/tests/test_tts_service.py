"""
test_tts_service.py

Unit tests for the TTSService class in the output_handler package.

These tests verify the text-to-speech functionality without actually playing audio:
- Ensures that the speak() method can be mocked to test call behavior.
- Avoids generating real audio files or playing sound during automated tests.

Uses unittest.mock.patch to simulate audio playback and confirm that speak() is
called with expected arguments.
"""

from unittest.mock import patch
from sweng25_objectpatternrecognizer_grpa.output_handler.tts_service import TTSService


def test_mocked_speak():
    """
    Test function to mock an audio output without actual playback.
    """
    tts = TTSService(lang="en")
    with patch.object(tts, "speak") as mock_speak:
        tts.speak("square", "blue")
        mock_speak.assert_called_once_with("square", "blue")
