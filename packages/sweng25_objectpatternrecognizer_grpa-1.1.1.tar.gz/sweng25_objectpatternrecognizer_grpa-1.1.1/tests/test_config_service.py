"""
Unit tests for the ConfigService class.

These tests verify:
- Successful loading and validation of a valid config
- Handling of missing or invalid config files
- Correct application of runtime overrides
- Proper writing of configuration back to file via save_config()
"""

import json
from pathlib import Path
import pytest
from sweng25_objectpatternrecognizer_grpa.config_service.config_service import (
    ConfigService
)


@pytest.fixture
def valid_config(tmp_path: Path) -> Path:
    """
    Create a temporary valid config.json file and corresponding schema.
    Returns:
        Path: Path to the generated config.json file.
    """
    schema_path = tmp_path / "config_schema.json"
    config_path = tmp_path / "config.json"

    # Write schema file (simplified version for test)
    schema = {
        "type": "object",
        "properties": {
            "source": {"type": "object"},
            "processing": {"type": "object"},
            "output": {"type": "object"}
        },
        "required": ["source", "processing", "output"]
    }
    schema_path.write_text(json.dumps(schema), encoding="utf-8")

    # Write valid config
    config = {
        "$schema": "config_schema.json",
        "source": {"type": "image", "camera_index": 0, "image_path": "test.png"},
        "processing": {
            "shapes": "all",
            "canny_threshold1": 50,
            "canny_threshold2": 150,
            "blur_kernel": [5, 5]
        },
        "output": {
            "image": {"enabled": True},
            "log": {"enabled": True, "path": "output.csv"},
            "tts": {"enabled": False, "language": "en", "audio_file": "temp.mp3"}
        }
    }
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    return config_path


def test_load_valid_config(valid_config: Path):
    """
    Test that a valid configuration file loads correctly.
    """
    service = ConfigService(config_path=valid_config)
    cfg = service.get_config()
    assert isinstance(cfg, dict)
    assert "source" in cfg
    assert cfg["source"]["type"] == "image"


def test_missing_config_file(tmp_path: Path):
    """
    Test that a missing configuration file raises a RuntimeError.
    """
    fake_config = tmp_path / "missing_config.json"
    with pytest.raises(RuntimeError, match="Configuration file not found"):
        ConfigService(config_path=fake_config)


def test_invalid_json_format(tmp_path: Path):
    """
    Test that an invalid JSON file raises a RuntimeError.
    """
    cfg = tmp_path / "config.json"
    schema = tmp_path / "config_schema.json"
    cfg.write_text("{ invalid json", encoding="utf-8")
    schema.write_text("{}", encoding="utf-8")

    with pytest.raises(RuntimeError, match="Invalid JSON format"):
        ConfigService(config_path=cfg)


def test_runtime_overrides(valid_config: Path):
    """
    Test that runtime overrides (source, image_path, camera_index)
    correctly overwrite values from the config file.
    """
    service = ConfigService(
        config_path=valid_config,
        source="camera",
        image_path="new_image.png",
        camera_index=2
    )
    cfg = service.get_config()
    assert cfg["source"]["type"] == "camera"
    assert cfg["source"]["image_path"] == "new_image.png"
    assert cfg["source"]["camera_index"] == 2


def test_save_config(valid_config: Path, tmp_path: Path):
    """
    Test that save_config() writes the updated configuration to disk.
    """
    service = ConfigService(config_path=valid_config)
    service.config["source"]["type"] = "camera"

    service.save_config()

    # Reopen the file and verify content
    new_data = json.loads(valid_config.read_text(encoding="utf-8"))
    assert new_data["source"]["type"] == "camera"


def test_validation_fails_on_invalid_config(tmp_path: Path):
    """
    Test that a config missing required fields fails validation.
    """
    schema_path = tmp_path / "config_schema.json"
    config_path = tmp_path / "config.json"

    schema = {
        "type": "object",
        "properties": {"source": {"type": "object"}},
        "required": ["source", "processing"]  # processing is required, will be missing
    }
    schema_path.write_text(json.dumps(schema), encoding="utf-8")

    invalid_config = {
        "$schema": "config_schema.json",
        "source": {"type": "camera"}
        # missing "processing"
    }
    config_path.write_text(json.dumps(invalid_config), encoding="utf-8")

    with pytest.raises(RuntimeError, match="Configuration validation failed"):
        ConfigService(config_path=config_path)
