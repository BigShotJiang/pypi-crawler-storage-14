"""Tests for image processing module."""

import cv2
import numpy as np
import pytest
from sweng25_objectpatternrecognizer_grpa.image_processing import ShapeDetector


# pylint: disable=redefined-outer-name
@pytest.fixture
def config_all() -> dict:
    """Example config for all shapes."""
    return {
        "processing": {
            "shapes": "all",
            "canny_threshold1": 50,
            "canny_threshold2": 150,
            "blur_kernel": [5, 5],
            "min_area": 1000,
            "max_area": 50000,
        }
    }


def create_image_with_shape(shape: str, color=(0, 0, 255)) -> np.ndarray:
    """Generates a testimage with one shape."""
    img = np.zeros((300, 300, 3), dtype=np.uint8)

    if shape == "rectangle":
        cv2.rectangle(img, (50, 100), (250, 200), color, -1)

    elif shape == "square":
        cv2.rectangle(img, (100, 100), (200, 200), color, -1)

    elif shape == "circle":
        cv2.circle(img, (150, 150), 50, color, -1)

    elif shape == "triangle":
        pts = np.array([[150, 50], [100, 200], [200, 200]], np.int32)
        cv2.drawContours(img, [pts], 0, color, -1)

    else:
        raise ValueError(f"Unknown shape: {shape}")

    return img


@pytest.mark.parametrize("shape_name", ["rectangle", "square", "circle", "triangle"])
def test_detect_shape(shape_name, config_all):
    """Test if the shape detector recognize a sample shape."""
    image = create_image_with_shape(shape_name)
    detector = ShapeDetector(config_all)

    output, detected = detector.detect(image)

    assert isinstance(output, np.ndarray)
    assert isinstance(detected, list)
    assert all(isinstance(x, list) and len(x) == 2 for x in detected)

    detected_names = [d[0].lower() for d in detected]
    assert any(
        shape_name in name for name in detected_names
    ), f"{shape_name} was not recognized."


def test_detect_empty_image(config_all):
    """No shape should be recognized if the image is empty."""
    image = np.zeros((300, 300, 3), dtype=np.uint8)
    detector = ShapeDetector(config_all)

    _, detected = detector.detect(image)

    assert not detected
