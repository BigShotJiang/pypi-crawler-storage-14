from unittest.mock import patch, MagicMock
import os
import pytest
import cv2
import numpy as np
from sweng25_objectpatternrecognizer_grpa.source_handler.source_handler import (
    SourceHandler as SH,
)


def dummypic():
    """
    Create a temporary image file as input picture file
    """
    cv2.imwrite("dummy_pic.png", np.zeros((10, 10, 3), dtype=np.uint8))
    return "dummy_pic.png"


def test_image_available():
    """
    Test function to check if an image exists.
    """
    temp_pic = dummypic()
    try:
        config = {"source": {"type": "image", "image_path": temp_pic}}

        handler = SH(config)
        handler.init_source()
        frame = handler.get_frame()

        assert frame is not None
        assert isinstance(frame, np.ndarray)
    finally:
        if os.path.exists(temp_pic):
            os.remove(temp_pic)


def test_wrong_image_path():
    """
    Test function to check if an invalid file path throws an error.
    """
    fake_path = "this_file_does_not_exist.png"

    config = {"source": {"type": "image", "image_path": fake_path}}

    with pytest.raises(FileNotFoundError, match="Image not found"):
        SH(config)

def test_camera_function_mocked():
    config = {"source": {"type": "camera", "camera_index": 0}}

    # Mock VideoCapture
    with patch.object(cv2, "VideoCapture") as mock_cap:
        mock_instance = MagicMock()
        mock_instance.isOpened.return_value = True
        mock_cap.return_value = mock_instance

        handler = SH(config)

        mock_cap.assert_called_once_with(0)
        assert handler.capture.isOpened()




def test_camera_function():
    """
    Test if the camera can be opened with a real index (0).
    Skips automatically if no camera is available.
    """
    # Check hardware availability BEFORE calling SourceHandler
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        pytest.skip("No camera connected, skipping real camera test.")
    cap.release()

    config = {"source": {"type": "camera", "camera_index": 0}}
    handler = SH(config)

    assert handler.capture.isOpened()


def test_camera_unavailable():
    """
    Test that initializing a camera with an invalid index raises RuntimeError.
    """
    config = {"source": {"type": "camera", "camera_index": 99}}  # intentionally invalid

    with pytest.raises(RuntimeError, match="Could not open camera at index 99"):
        SH(config)
