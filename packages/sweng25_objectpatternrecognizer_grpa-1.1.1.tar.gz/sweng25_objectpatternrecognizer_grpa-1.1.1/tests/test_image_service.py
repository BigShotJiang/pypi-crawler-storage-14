"""
test_image_service.py

Unit tests for the ImageService class in the output_handler package.

These tests verify the behavior of the image display and cleanup functionality:
- Ensures that the show() method correctly handles both enabled and disabled states.
- Confirms that no exceptions are raised when showing dummy frames.
- Verifies that close_all() can be called safely to close OpenCV windows.

Since these tests use dummy NumPy frames instead of actual images,
they do not require any real camera input or GUI interaction.
"""

import cv2
import numpy as np
from sweng25_objectpatternrecognizer_grpa.output_handler.image_service import (
    ImageService,
)


def test_saves_file_to_given_path(tmp_path):
    """ImageService should save an image to the correct path."""

    img = np.zeros((10, 10, 3), dtype=np.uint8)
    save_file = tmp_path / "output_img.png"

    service = ImageService(show=False, save=True, save_path=str(save_file))
    service.save(img)

    assert save_file.exists()


def test_saves_file_into_directory(tmp_path):
    """If save_path is a directory, ImageService should save output_img.png inside it."""

    img = np.zeros((10, 10, 3), dtype=np.uint8)
    save_dir = tmp_path

    service = ImageService(show=False, save=True, save_path=str(save_dir))
    service.save(img)

    expected_file = save_dir / "output_img.png"
    assert expected_file.exists()


def test_save_disabled(tmp_path):
    """save should not write a file if saving is disabled."""

    img = np.zeros((10, 10, 3), dtype=np.uint8)
    save_file = tmp_path / "output.png"

    service = ImageService(show=False, save=False, save_path=str(save_file))
    service.save(img)

    assert not save_file.exists()


def test_show_enabled(monkeypatch):
    """show should call cv2.imshow when enabled."""

    img = np.zeros((10, 10, 3), dtype=np.uint8)
    called = {"value": False}

    def fake_imshow(name, frame):
        called["value"] = True

    monkeypatch.setattr(cv2, "imshow", fake_imshow)

    service = ImageService(show=True, save=False)
    service.show(img)

    assert called["value"]


def test_show_disabled(monkeypatch):
    """show should not call cv2.imshow when disabled."""

    img = np.zeros((10, 10, 3), dtype=np.uint8)
    called = {"value": False}

    def fake_imshow(name, frame):
        called["value"] = True

    monkeypatch.setattr(cv2, "imshow", fake_imshow)

    service = ImageService(show=False, save=False)
    service.show(img)

    assert not called["value"]
