"""Module with a class for square shape detection in an image using OpenCV.

This module provides the 'Square' class, a subclass of 'Rectangle', which
implements detection logic specific to squares in images using OpenCV.

Classes
-------
Squares
    Detects square shapes in images by analyzing contours.
"""

import cv2
from .rectangle import Rectangle


class Square(Rectangle):
    """Class for square shape detection in an image using OpenCV.

    Subclass of 'Rectangle' representing a square. It implements the 'matches' method
    to determine whether a given contour corresponds to a square.

    Parameters
    ----------
    name : str
        The name of the shape, default: Square.
    """

    def __init__(self):
        super().__init__(name="Square")

    def matches(self, contour: cv2.typing.MatLike, approx: cv2.typing.MatLike) -> bool:
        if super().matches(contour, approx):
            rect = cv2.minAreaRect(contour)
            (w, h) = rect[1]
            aspect_ratio = max(w, h) / min(w, h)
            return 0.9 <= aspect_ratio <= 1.1
        return False
