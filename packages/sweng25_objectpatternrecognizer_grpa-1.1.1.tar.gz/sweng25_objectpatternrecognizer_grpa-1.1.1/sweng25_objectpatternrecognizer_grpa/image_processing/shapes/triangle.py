"""Module with a class for triangle shape detection in an image using OpenCV.

This module provides the 'Triangle' class, a subclass of 'Shape', which
implements detection logic specific to triangles in images using OpenCV.

Classes
-------
Triangle
    Detects triangular shapes in images by analyzing contours.
"""

import cv2
from .shape import Shape


class Triangle(Shape):
    """Class for triangle shape detection in an image using OpenCV.

    Subclass of 'Shape' representing a triangle. It implements the 'matches' method
    to determine whether a given contour corresponds to a triangle.

    Parameters
    ----------
    name : str
        The name of the shape, default: Triangle.
    """

    def __init__(self):
        super().__init__(name="Triangle")

    def matches(self, contour: cv2.typing.MatLike, approx: cv2.typing.MatLike) -> bool:
        return len(approx) == 3
