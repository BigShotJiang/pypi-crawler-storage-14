"""Module with a class for rectangle shape detection in an image using OpenCV.

This module provides the 'Rectangle' class, a subclass of 'Shape', which
implements detection logic specific to rectangles in images using OpenCV.

Classes
-------
Rectangles
    Detects rectangular shapes in images by analyzing contours.
"""

import cv2
from .shape import Shape


class Rectangle(Shape):
    """Class for rectangle shape detection in an image using OpenCV.

    Subclass of 'Shape' representing a rectangle. It implements the 'matches' method
    to determine whether a given contour corresponds to a rectangle.

    Parameters
    ----------
    name : str
        The name of the shape, default: Rectangle.
    """

    def __init__(self, name="Rectangle"):
        super().__init__(name)

    def matches(self, contour: cv2.typing.MatLike, approx: cv2.typing.MatLike) -> bool:
        return len(approx) == 4
