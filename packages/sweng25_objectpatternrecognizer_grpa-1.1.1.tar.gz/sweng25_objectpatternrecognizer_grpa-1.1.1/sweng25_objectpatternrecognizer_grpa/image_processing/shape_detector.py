"""Module providing a class for detecting and labeling geometric shapes in images using OpenCV.

Classes
-------
ShapeDetector
    Detects predefined geometric shapes in an image, identifies the color
    and draws the shapes with labels on the image.
"""

import cv2
from .shapes import Rectangle, Square, Triangle, Circle


class ShapeDetector:
    """Class to detect geometric shapes and their colors in images.

    This class uses Canny edge detection, contour approximation and color
    detection to identify shapes such as squares, rectangles, triangles, and
    circles. Detected shapes are labeled and drawn on the output image.

    Parameters
    ----------
    config : dict
        The processing part of the config file.

    Attributes
    ----------
    shapes : list of Shape, optional
        List of Shape instances to detect.
    canny_threshold1 : int, optional
        First threshold for the Canny edge detector.
    canny_threshold2 : int, optional
        Second threshold for the Canny edge detector.
    blur_kernel : tuple of int, optional
        Kernel size for Gaussian blur applied before edge detection.
    """

    def __init__(self, config: dict) -> None:
        proc_cfg = config.get("processing", {})
        self._shapes = (
            proc_cfg.get("shapes")
            if proc_cfg.get("shapes") != "all"
            else [Square(), Rectangle(), Triangle(), Circle()]
        )
        self._canny_threshold1 = proc_cfg.get("canny_threshold1")
        self._canny_threshold2 = proc_cfg.get("canny_threshold2")
        self._blur_kernel = proc_cfg.get("blur_kernel")
        self._min_area = proc_cfg.get("min_area")
        self._max_area = proc_cfg.get("max_area")

    def detect(self, image: cv2.typing.MatLike) -> tuple[cv2.typing.MatLike, list]:
        """Detect shapes and their colors in the given image.

        The method applies the following steps:
        - Convert the image to grayscale.
        - Apply Gaussian blur.
        - Detect edges using Canny edge detection.
        - Find contours from the edges.
        - Approximate each contour and check if it matches any of the predefined shapes.
        - Detect the color of the matched shape.
        - Draw the shape and label it on a copy of the original image.

        Parameters
        ----------
        image : cv2.typing.MatLike
            Input image in BGR color space.

        Returns
        -------
        output : cv2.typing.MatLike
            Copy of the input image with detected shapes drawn and labeled.
        detected_shapes : list of list
            List of detected shapes with their names and colors. Each element
            is a list: [shape_name, color].
        """
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, self._blur_kernel, 0)
        edges = cv2.Canny(blurred, self._canny_threshold1, self._canny_threshold2)
        contours, _ = cv2.findContours(
            edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        output = image.copy()
        detected_shapes = []

        for contour in contours:
            if self._min_area < cv2.contourArea(contour) < self._max_area:
                approx = cv2.approxPolyDP(
                    contour, 0.01 * cv2.arcLength(contour, True), True
                )
                for shape in self._shapes:
                    if shape.matches(contour, approx):
                        shape.detect_color(image, approx)
                        if shape.get_color() != "UNKNOWN":
                            shape.draw(output, approx)
                            detected_shapes.append(
                                [shape.get_name(), shape.get_color()]
                            )
                        break
        return output, detected_shapes
