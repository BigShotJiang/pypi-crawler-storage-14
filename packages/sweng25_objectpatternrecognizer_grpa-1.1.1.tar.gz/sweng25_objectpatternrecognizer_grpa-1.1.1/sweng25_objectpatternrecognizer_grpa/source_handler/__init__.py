"""
Source package for image acquisition.

Provides SourceHandler to manage camera or image file input for object
pattern recognition.
"""

from .source_handler import SourceHandler

__all__ = ["SourceHandler"]
