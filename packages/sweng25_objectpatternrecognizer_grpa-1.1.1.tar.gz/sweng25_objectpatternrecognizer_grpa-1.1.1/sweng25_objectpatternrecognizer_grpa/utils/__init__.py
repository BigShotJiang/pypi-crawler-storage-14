"""This package provides a class to parse comand line arguments."""

from .argparser import ArgParser

__all__ = ["ArgParser"]
