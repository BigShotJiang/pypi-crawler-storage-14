"""
config_service

Simple package for loading, validating and managing configuration files.
"""
from .config_service import ConfigService

__all__ = ["ConfigService"]
