"""
ConfigService module.

Provides loading, validation, and saving of the configuration file for
the SWENG25 Object Pattern Recognizer. Supports runtime overrides
for source type, image path, and camera index.
"""

import json
from typing import Any, Optional
from pathlib import Path
from jsonschema import validate, ValidationError


class ConfigService:
    """
    Handles loading, validating, accessing, and saving configuration data
    for the Object Pattern Recognizer project.

    Features:
    - Loads config.json from disk
    - Validates it against config_schema.json
    - Allows runtime overrides for source type, image path, or camera index
    - Can save modified configurations back to file
    """

    def __init__(
        self,
        config_path,
        source: Optional[str] = None,
        image_path: Optional[str] = None,
        camera_index: Optional[int] = None,
    ) -> None:
        """
        Initialize ConfigService by loading and validating configuration.

        Args:
            config_path (str): Path to config.json file.
            source (str, optional): Override for source type ("camera" or "image").
            image_path (str, optional): Override for source image path.
            camera_index (int, optional): Override for camera index.
        """
        self._config_path = Path(config_path)
        self.config = self._load_config()
        self._schema_path = self._get_schema_path()
        self._validate_config()

        # Apply runtime overrides (e.g., CLI or GUI parameters)
        if source:
            self.config["source"]["type"] = source
        if image_path:
            self.config["source"]["image_path"] = image_path
        if camera_index is not None:
            self.config["source"]["camera_index"] = camera_index

        self.save_config()

    def get_config(self) -> dict:
        """
        Return the loaded (and possibly modified) configuration as a dictionary.

        Returns:
            dict: Current configuration.
        """
        self.config = self._load_config()
        return self.config

    def _load_config(self) -> dict:
        """
        Load the JSON configuration file from disk.

        Raises:
            RuntimeError: If the file does not exist or cannot be read.

        Returns:
            dict: Parsed configuration dictionary.
        """
        if not self._config_path.exists():
            raise RuntimeError(f"Configuration file not found: {self._config_path}")

        try:
            with open(self._config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            raise RuntimeError(
                f"Invalid JSON format in {self._config_path}: {e}"
            ) from e
        except Exception as e:
            raise RuntimeError(f"Failed to load configuration: {e}") from e

    def save_config(self, new_config: dict[str, Any] | None = None) -> None:
        """
        Save the current configuration to disk, overwriting the existing file.

        Args:
            new_config (dict[str, Any], optional): New config that overwrites the existing file.

        Raises:
            RuntimeError: If the configuration cannot be written.
        """
        if new_config:
            self.config = new_config
            self._validate_config()
        try:
            with open(self._config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            raise RuntimeError(f"Failed to save configuration: {e}") from e

    # ----------------------------- INTERNAL HELPERS -----------------------------

    def _get_schema_path(self) -> Path:
        """
        Determine the JSON schema path based on the `$schema` reference inside the config file.
        This allows flexible paths (relative to config file).

        Returns:
            Path: Absolute path to schema file.
        """
        try:
            # Try to resolve relative path like "./config_schema.json"
            schema_path = self._config_path.parent / "config_schema.json"
            if not schema_path.exists():
                raise FileNotFoundError(f"Schema file not found: {schema_path}")
            return schema_path
        except Exception as e:
            raise RuntimeError(f"Failed to locate schema file: {e}") from e

    def _validate_config(self) -> None:
        """
        Validate the loaded configuration against its schema.

        Raises:
            RuntimeError: If validation fails.
        """
        try:
            with open(self._schema_path, "r", encoding="utf-8") as f:
                schema = json.load(f)
            validate(instance=self.config, schema=schema)
        except ValidationError as e:
            raise RuntimeError(f"Configuration validation failed: {e.message}") from e
        except Exception as e:
            raise RuntimeError(f"Error during configuration validation: {e}") from e
