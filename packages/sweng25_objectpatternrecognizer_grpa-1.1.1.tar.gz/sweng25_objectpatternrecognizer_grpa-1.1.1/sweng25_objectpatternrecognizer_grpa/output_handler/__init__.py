"""
Output package initializer.

This package provides the OutputHandler class, which coordinates the output
pipeline for object pattern recognition. It integrates image display, logging,
and optional text-to-speech feedback.

Modules:
- output_handler: Contains the OutputHandler class.

Exports:
- OutputHandler
"""

from .output_handler import OutputHandler

__all__ = ["OutputHandler"]
