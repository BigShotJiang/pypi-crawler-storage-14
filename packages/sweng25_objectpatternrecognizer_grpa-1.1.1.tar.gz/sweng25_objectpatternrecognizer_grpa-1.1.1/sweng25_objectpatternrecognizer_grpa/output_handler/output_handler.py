"""
output_handler.py

This module defines the OutputHandler class, which coordinates the output process
of the object pattern recognition pipeline. It manages image display, logging, and
optional text-to-speech feedback.

The OutputHandler integrates the following services:
- ImageService: Handles real-time visualization using OpenCV.
- LogService: Records detected shapes and colors into a CSV log file.
- TTSService: Provides optional spoken feedback for detected objects.
"""

import cv2
from .image_service import ImageService
from .log_service import LogService
from .tts_service import TTSService


class OutputHandler:
    """
    Handles the output of the object pattern recognition pipeline.

    Combine image display, logging and text-to-speech.
    Ensures that duplicate detections in consecutive frames are not repeatedly logged or spoken.
    """

    def __init__(self, config: dict) -> None:
        """
        Initialize OutputHandler with config options.

        Args:
            config (dict): Configuration dictionary following the structure:
                {
                    "output": {
                        "image": {"show": bool, "save": bool, "save_path": str},
                        "log": {"enabled": bool, "path": str},
                        "tts": {"enabled": bool, "language": str, "audio_file": str}
                    }
                }
        """
        output_cfg = config.get("output", {})

        image_cfg = output_cfg.get("image", {})
        log_cfg = output_cfg.get("log", {})
        tts_cfg = output_cfg.get("tts", {})

        self.image_service = ImageService(
            show=image_cfg.get("show", True),
            save=image_cfg.get("save", True),
            save_path=image_cfg.get("path", True),
        )
        self.log_service = LogService(
            log_path=log_cfg.get("path", "output.csv"),
            enable=log_cfg.get("enabled", True),
        )
        self.tts_service = TTSService(
            enable=tts_cfg.get("enabled", True),
            lang=tts_cfg.get("language", "en"),
        )

        self._last_detected_shapes: list[list[str]] = []

    def handle(
        self, frame: cv2.typing.MatLike, detected_shapes: list, img_show: bool = True
    ) -> None:
        """
        Process a frame and its detected shapes.

        Args:
            frame (cv2.typing.MatLike): Frame or image to display.
            detected_shapes (list): List of detected shapes.
            img_show (bool): Flag if the image should be shown or not.
        """
        if self._same_list_as_before(detected_shapes):
            for shape in detected_shapes:
                color = shape[1]
                shape_name = shape[0]
                self.log_service.write(shape_name, color)
                self.tts_service.speak(shape_name, color)

        if img_show:
            self.image_service.show(frame)

        self.image_service.save(frame)

    def close(self) -> None:
        """
        Close all services.
        """
        self.image_service.close_all()

    def _same_list_as_before(self, detected_shapes: list) -> bool:
        """
        Function to detect if shapes list differs from the previous frame.

        Args:
            detected_shapes (list): Current frame detections.

        Returns:
            bool: True if list has changed, False if not.
        """
        if detected_shapes == self._last_detected_shapes:
            return False
        self._last_detected_shapes = detected_shapes.copy()
        return True
