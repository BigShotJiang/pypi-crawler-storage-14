"""
log_service.py

This module provides the LogService class, which handles logging of detected shapes
and their colors into a CSV file. It supports enabling or disabling logging,
clearing the log file, and optional filtering to log only specific shapes.
"""

import os
import csv
from datetime import datetime
from typing import List, Optional


class LogService:
    """
    Logging service for shapes/colors detection.
    Stores entries in CSV format with optional filtering.
    """

    def __init__(
        self,
        log_path: str = "output.csv",
        enable: bool = True,
        allowed_shapes: Optional[List[str]] = None,
    ) -> None:
        """
        Initialize LogService.

        Args:
            log_path (str): Path to the CSV log file or to the folder of the log file.
            enable (bool): Flag if the log should be written or not.
            allowed_shapes (Optional[List[str]]): If provided, only these shapes will be logged.
        """
        self.enable = enable
        self.allowed_shapes = allowed_shapes

        if log_path.lower().endswith(".csv"):
            log_dir = os.path.dirname(log_path)
        else:
            log_dir = log_path
            log_path = os.path.join(log_path, "output.csv")
        os.makedirs(log_dir, exist_ok=True)
        self.log_path = log_path

    def write(self, shape: str, color: str) -> None:
        """
        Write a single entry to the CSV file, optionally filtered by allowed_shapes.

        Args:
            shape (str): Name of the detected shape.
            color (str): Color of the detected shape.
        """
        if not self.enable:
            return

        if self.allowed_shapes and shape not in self.allowed_shapes:
            return

        timestamp = datetime.now().isoformat(sep=" ", timespec="seconds")
        with open(self.log_path, mode="a", newline="", encoding="utf-8") as log_file:
            writer = csv.writer(log_file)
            writer.writerow([timestamp, shape, color])

    def clear_log(self) -> None:
        """
        Clears the log file and rewrites the header.
        """
        with open(self.log_path, mode="w", newline="", encoding="utf-8") as log_file:
            writer = csv.writer(log_file)
            writer.writerow(["timestamp", "shape", "color"])
