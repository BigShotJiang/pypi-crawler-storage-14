"""
log_service

Simple package for logging messages with configurable levels and output formatting.
"""

from .log_service import LogService

__all__ = ["LogService"]
