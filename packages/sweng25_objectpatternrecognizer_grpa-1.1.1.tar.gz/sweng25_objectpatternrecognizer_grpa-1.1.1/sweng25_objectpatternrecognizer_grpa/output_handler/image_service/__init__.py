"""
image_service

Simple package for displaying images and video frames using OpenCV
with optional visualization control.
"""

from .image_service import ImageService

__all__ = ["ImageService"]
