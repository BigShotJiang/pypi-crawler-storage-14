"""
image_service.py

This module provides the ImageService class, which handles image or video frame display
using OpenCV. It supports enabling or disabling visualization and provides methods
to show frames, save frames and close all OpenCV windows.
"""

import os
import cv2


class ImageService:
    """
    Service for displaying images or video frames using OpenCV.
    """

    def __init__(
        self,
        show: bool = True,
        save: bool = True,
        save_path: str = "./output",
    ) -> None:
        """
        Initialize ImageService.

        Args:
            show (bool): Enable for show image function.
            save (bool): Enable for save image function.
            save_path (str): Path to save the image.
        """
        self._show = show
        self._save = save

        if save_path.lower().endswith((".png", ".jpeg", ".jpg")):
            save_dir = os.path.dirname(save_path)
        else:
            save_dir = save_path
            save_path = os.path.join(save_path, "output_img.png")
        os.makedirs(save_dir, exist_ok=True)
        self._save_path = save_path

    def show(self, frame: cv2.typing.MatLike, window_name: str = "Output") -> None:
        """
        Display an image or video frame in a window if enabled.

        Args:
            frame (cv2.typing.MatLike): Image or frame to display.
            window_name (str): Name of the OpenCV window.
        """
        if not self._show:
            return

        cv2.imshow(window_name, frame)

    def save(self, frame: cv2.typing.MatLike):
        """
        Save an image if enabled.

        Args:
            frame (cv2.typing.MatLike): Image or frame to save.
        """
        if not self._save:
            return

        cv2.imwrite(self._save_path, frame)

    def close_all(self) -> None:
        """
        Close all OpenCV windows.
        """
        cv2.destroyAllWindows()
