"""
tts_service

Package to convert a text to a audio.
"""

from .tts_service import TTSService

__all__ = ["TTSService"]
