"""
tts_service.py

This module provides the TTSService class, which handles text-to-speech (TTS)
conversion for detected shapes and colors in the object pattern recognition system.

It uses the Google Text-to-Speech (gTTS) library to generate spoken audio feedback
from text, describing recognized objects such as their shape and color.

Features:
- Supports multiple languages through gTTS.
- Plays audio automatically.
- Can be disabled via configuration for silent operation (e.g., during testing).
"""

import os
import io
import threading
import queue
from gtts import gTTS  # type: ignore

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
import pygame


class TTSService:
    """
    A text-to-speech (TTS) handler that converts detected shapes and colors
    into spoken audio output using the Google Text-to-Speech (gTTS) library.
    """

    def __init__(self, enable=True, lang="en") -> None:
        """
        Initialize the TTS class.

        Arguments:
            enable (bool): Flag to enable or disable TTS functionality (default: True).
            lang (str): The language code for speech synthesis (default: "en").
        """
        self._enable = enable
        self._lang = lang

        pygame.mixer.init()
        self._queue: queue.Queue[str] = queue.Queue()

        self._worker = threading.Thread(target=self._speak_queue, daemon=True)
        self._worker.start()

        self._lock = threading.Lock()

    def speak(self, shape: str, color: str) -> None:
        """
        Convert detected shape and color information into spoken text.

        Arguments:
            shape (str): The name of the detected shape (for example, "circle").
            color (str): The name of the detected color (for example, "red").
        """
        if not self._enable:
            return

        text = f"Detected {shape} with color {color}"

        self._queue.put(text)

    def _speak_queue(self):
        """Worker thread that plays TTS messages sequentially."""
        while True:
            text = self._queue.get()

            if text is None:
                break
            try:
                tts = gTTS(text=text, lang=self._lang)
                mp3_fp = io.BytesIO()
                tts.write_to_fp(mp3_fp)
                mp3_fp.seek(0)

                with self._lock:
                    pygame.mixer.music.load(mp3_fp, "mp3")
                    pygame.mixer.music.play()

                while pygame.mixer.music.get_busy():
                    pygame.time.Clock().tick(10)

            except Exception:
                pass

            finally:
                self._queue.task_done()
