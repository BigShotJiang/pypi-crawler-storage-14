"""
dataclass for callback functions
"""

from dataclasses import dataclass
from typing import Callable, Dict, Any


@dataclass
class MainFunctions:
    """Container for all main GUI callback functions.

    Notes:
    - on_file_open: receives a path as string, called when user opens a file dialog.
    - on_stream_start: no args, called when starting live stream.
    - on_settings_open: receives a settings dict when settings window is opened.
    - on_save: receives a settings dict when settings are saved.
    - on_close: no args, called on application close.
    """

    on_file_open: Callable[[str], None]
    on_stream_start: Callable[[], None]
    on_settings_open: Callable[[], Dict[str, Any]]
    on_save: Callable[[Dict[str, Any]], None]
    on_close: Callable[[], None]
