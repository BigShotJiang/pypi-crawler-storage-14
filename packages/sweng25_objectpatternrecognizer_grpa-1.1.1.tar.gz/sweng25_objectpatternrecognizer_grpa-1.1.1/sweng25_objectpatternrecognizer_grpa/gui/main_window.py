"""
Main application window for the Object Pattern Recognizer.

This module defines the `MainWindow` class, which provides the primary
graphical user interface (GUI) for managing image or video input, displaying
content, and handling user interactions through the sidebar.

Examples
--------
To integrate this window into your own project, you must provide
callback functions using the `MainFunctions` interface.
This minimal example launches the GUI with functional callbacks for
testing and demonstration:

>>> from gui import MainWindow, MainFunctions
>>> from typing import Dict, Any

    def make_callbacks(window: "MainWindow"):
        def on_file_open(image_path: str) -> None:
            # put your code witch provides a frame: cv2.typing.MatLike
            window.update_frame(frame)

        def on_stream_start() -> None:
            # put your code witch provides continiously a frame: cv2.typing.MatLike
            window.update_frame(frame)

        def on_settings_open() -> dict:
            # code witch provides config dict with form: Dict[str: Any]
            return config

        def on_save(settings: dict[str, Any]) -> None:
            # code witch saves config

        def on_close() -> None:
            # put you code here witch needs to be run before closing
            window.quit()
            window.destroy()

        return MainFunctions(
            on_file_open=on_file_open,
            on_stream_start=on_stream_start,
            on_settings_open=on_settings_open,
            on_save=on_save,
            on_close=on_close,
        )

    gui = MainWindow()
    gui.set_callbacks(make_callbacks(gui))
    gui.run()
"""

import customtkinter as ctk  # type: ignore
from PIL import Image, ImageTk
import cv2
from .gui_elements import SideBar
from .callbacks import MainFunctions
from .gui_elements.error_window import ErrorWindow


class MainWindow(ctk.CTk):
    """
    Main application window.

    Provides the primary interface for interacting with the Object Pattern
    Recognizer, including image display, video streaming, and access to
    sidebar controls.
    """

    def __init__(self, cfg: dict) -> None:
        """Initialize the main application window and layout."""
        super().__init__()

        self._config = cfg

        self._callbacks = MainFunctions(
            on_file_open=lambda image_path: None,
            on_stream_start=lambda: None,
            on_settings_open=lambda: {},
            on_save=lambda settings: None,
            on_close=lambda: None,
        )

        # Window setup
        self.title("Object Pattern Recognizer")
        self.after(1, lambda: self.state("zoomed"))
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")
        self.protocol("WM_DELETE_WINDOW", self.exit)

        # Grid layout
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Main content frame
        self._main_frame = ctk.CTkFrame(self, corner_radius=10)
        self._main_frame.grid(row=0, column=1, sticky="nswe", padx=20, pady=20)
        self._main_frame.grid_rowconfigure(0, weight=1)
        self._main_frame.grid_columnconfigure(0, weight=1)

        # Placeholder for image or video stream
        self._display_label = ctk.CTkLabel(
            self._main_frame,
            text="This is where the image or video stream will appear.",
            font=ctk.CTkFont(size=16),
            justify="center",
        )
        self._display_label.pack(expand=True)

        # Sidebar with action buttons
        self._side_bar = SideBar(self, self._callbacks)

    def set_callbacks(self, callbacks: MainFunctions) -> None:
        """
        Set GUI callback functions and update sidebar references.

        Parameters
        ----------
        callbacks : MainFunctions
            Callback container providing bound functions for GUI events.
        """
        self._callbacks = callbacks
        if hasattr(self, "_side_bar") and getattr(self, "_side_bar") is not None:
            self._side_bar.set_callbacks(callbacks)

    def update_frame(self, frame: cv2.typing.MatLike) -> None:
        """
        Update the display with the next frame from the video stream or displays a static image.

        Continuously reads frames from the active camera stream,
        converts them to a Tkinter-compatible image, and displays
        them in the main label widget.
        """
        _img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        _img = Image.fromarray(_img_rgb)
        _img.thumbnail((800, 600))
        _tk_img = ImageTk.PhotoImage(_img)

        self._display_label.configure(image=_tk_img, text="")
        self._display_label.image = _tk_img

    def exit(self) -> None:
        """
        Perform cleanup and close the application.

        Calls the registered `on_close` callback before destroying
        the main window.
        """
        if callable(self._callbacks.on_close):
            self._callbacks.on_close()

    def run(self) -> None:
        """Start the main GUI event loop."""
        if self._config["source"]["type"] == "image":
            self._callbacks.on_file_open(self._config["source"]["image_path"])
        else:
            self._callbacks.on_stream_start()
        self.mainloop()

    def throw_error(
            self,
            message: str,
            title: str = "Error"
        ) -> None:
        """
        Display an error dialog with the specified message.

        Parameters
        ----------
        message : str
            The error message to display.
        title : str, optional
            The title of the error dialog, by default "Error".
        """
        ErrorWindow(self, message, title)
