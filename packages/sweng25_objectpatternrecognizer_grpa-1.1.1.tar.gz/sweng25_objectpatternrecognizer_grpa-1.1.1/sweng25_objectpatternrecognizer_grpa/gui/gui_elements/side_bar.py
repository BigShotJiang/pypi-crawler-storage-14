"""
Sidebar component for the main application window.

This module defines the `SideBar` class, which provides a
collection of GUI buttons for file loading, live stream control,
application exit, and settings management.
"""

import tkinter.filedialog as fd
import customtkinter as ctk  # type: ignore
from ..callbacks import MainFunctions
from ..gui_elements import SettingsWindow


class SideBar:
    """
    Sidebar for the main GUI window.

    Provides quick-access buttons for common user actions.
    """

    def __init__(self, master: ctk.CTk, callbacks: MainFunctions) -> None:
        """
        Initialize the sidebar and attach it to the main window.

        Parameters
        ----------
        master : ctk.CTk
            The parent window (typically a `MainWindow` instance).
        callbacks : MainFunctions
            Object holding callback functions for sidebar actions.
        """
        self.master = master
        self.callbacks = callbacks

        # create sidebar frame
        self.sidebar = ctk.CTkFrame(master, width=200, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nswe")

        # Title
        self.sidebar_label = ctk.CTkLabel(
            self.sidebar,
            text="Menü",
            font=ctk.CTkFont(size=20, weight="bold"),
        )
        self.sidebar_label.pack(pady=(20, 10))

        # Buttons
        self.btn_open = ctk.CTkButton(
            self.sidebar,
            text="📁 Datei öffnen",
            command=self.open_image,
        )
        self.btn_open.pack(pady=10, fill="x", padx=10)

        self.btn_stream = ctk.CTkButton(
            self.sidebar,
            text="📹 Livestream start/stop",
            command=lambda: self._safe_call(self.callbacks.on_stream_start),
        )
        self.btn_stream.pack(pady=10, fill="x", padx=10)

        self.sidebar_exit = ctk.CTkButton(
            self.sidebar,
            text="❌ Beenden",
            fg_color="red",
            command=lambda: self._safe_call(self.callbacks.on_close),
        )
        self.sidebar_exit.pack(side="bottom", pady=10, fill="x", padx=10)

        self.btn_settings = ctk.CTkButton(
            self.sidebar, text="⚙️ Einstellungen", command=self.open_settings
        )
        self.btn_settings.pack(side="bottom", pady=10, fill="x", padx=10)

    def set_callbacks(self, callbacks: MainFunctions) -> None:
        """
        Update sidebar callbacks and rebind button commands.

        Parameters
        ----------
        callbacks : MainFunctions
            Updated callback object with new function references.
        """
        self.callbacks = callbacks

        self.btn_open.configure(command=lambda: self._safe_call(self.open_image))
        self.btn_stream.configure(
            command=lambda: self._safe_call(self.callbacks.on_stream_start)
        )
        self.sidebar_exit.configure(
            command=lambda: self._safe_call(self.callbacks.on_close)
        )

    def open_image(self) -> None:
        """
        Opens a file dialog to select an image and calls `on_file_open` with the chosen path.

        Raises:
            FileNotFoundError: If no file is selected.
        """
        config = self.callbacks.on_settings_open()

        file_path = fd.askopenfilename(
            title="Bild auswählen",
            initialdir=config["source"].get("image_path", ""),
            filetypes=[("Images", "*.jpg *.png *.jpeg *.bmp *.tiff")],
        )

        if not file_path:
            raise FileNotFoundError("No file was selected in the file dialog.")

        self.callbacks.on_file_open(file_path)

    def open_settings(self) -> None:
        """
        Open the settings dialog.

        Opens a `SettingsWindow` instance owned by the main window.
        When the settings dialog saves, the configuration dictionary
        is forwarded to `callbacks.on_settings(settings)`.

        Returns
        -------
        None
        """
        config = self.callbacks.on_settings_open()

        def _on_save(settings):
            if hasattr(self.callbacks, "on_save") and callable(self.callbacks.on_save):
                try:
                    self.callbacks.on_save(settings)
                except TypeError as e:
                    self.master.throw_error(f"Fehler beim Speichern der Einstellungen: {e}")

        SettingsWindow(self.master, config=config, on_save=_on_save)

    def _safe_call(self, func, *args, **kwargs) -> None:
        """
        Safely call a callback function.

        Parameters
        ----------
        func : callable
            Function to be executed

        Returns
        -------
        None
        """
        if not callable(func):
            return

        try:
            func(*args, **kwargs)
        except (ValueError, TypeError) as e:
            self.master.throw_error(f"Fehler bei der Ausführung: {e}")
