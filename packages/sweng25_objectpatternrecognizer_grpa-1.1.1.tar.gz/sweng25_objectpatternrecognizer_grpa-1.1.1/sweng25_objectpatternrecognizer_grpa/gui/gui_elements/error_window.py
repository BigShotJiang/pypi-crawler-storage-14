"""Error dialog window module."""
import customtkinter as ctk  # type: ignore

class ErrorWindow(ctk.CTkToplevel):
    """Error dialog window."""
    def __init__(
            self, 
            master: ctk.CTk, 
            message: str, 
            title: str = "Error"
        ) -> None:
        super().__init__(master)

        super().__init__(master)
        self.title(title)
        self.geometry("350x180")
        self.resizable(False, False)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        self.transient(master)
        self.grab_set()
        self.focus()

        # Layout
        self.grid_columnconfigure(0, weight=1)

        # Message label
        self.label = ctk.CTkLabel(
            self,
            text=message,
            text_color="red",
            wraplength=300,
            justify="center",
            font=ctk.CTkFont(size=15, weight="bold")
        )
        self.label.grid(row=0, column=0, padx=20, pady=(25, 15))

        self.ok_button = ctk.CTkButton(
            self,
            text="OK",
            command=self._close,
            width=100
        )
        self.ok_button.grid(row=1, column=0, pady=(0, 20))

        self.update_idletasks()
        self._center(master)

    def _center(self, parent):
        """Center dialog over parent."""
        parent_x = parent.winfo_rootx()
        parent_y = parent.winfo_rooty()
        parent_w = parent.winfo_width()
        parent_h = parent.winfo_height()

        w = self.winfo_width()
        h = self.winfo_height()

        x = parent_x + (parent_w - w) // 2
        y = parent_y + (parent_h - h) // 2

        self.geometry(f"{w}x{h}+{x}+{y}")

    def _close(self):
        """Close the error window."""
        self.grab_release()
        self.destroy()
