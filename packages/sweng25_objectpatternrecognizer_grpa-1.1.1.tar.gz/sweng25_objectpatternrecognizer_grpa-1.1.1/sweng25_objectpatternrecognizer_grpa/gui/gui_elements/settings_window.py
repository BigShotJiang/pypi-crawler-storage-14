"""Settings window for configuring application parameters."""

import tkinter.filedialog as fd
from typing import Callable
import customtkinter as ctk  # type: ignore


class SettingsWindow(ctk.CTkToplevel):
    """
    Configuration settings window for the updated config schema.
    """

    def __init__(
        self, master: ctk.CTk, config: dict, on_save: Callable | None = None
    ) -> None:
        super().__init__(master)
        self.title("Einstellungen")
        self.geometry("540x900")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        self.on_save = on_save
        self.config_data = config

        self.transient(master)
        self.grab_set()
        self.focus()

        # Scrollable area
        scroll_frame = ctk.CTkScrollableFrame(self, label_text="")
        scroll_frame.pack(fill="both", expand=True, padx=10, pady=10)

        scroll_frame.grid_columnconfigure(0, weight=0)
        scroll_frame.grid_columnconfigure(1, weight=1)
        scroll_frame.grid_columnconfigure(2, weight=0)

        self._build_source_section(scroll_frame)
        self._build_processing_section(scroll_frame)
        self._build_output_section(scroll_frame)
        self._build_buttons(scroll_frame)

    # -------------------- UI SECTIONS --------------------

    def _build_source_section(self, master):
        row = 0
        ctk.CTkLabel(
            master,
            text="Eingabeeinstellungen",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).grid(row=row, column=0, padx=20, pady=(20, 5), sticky="w")

        # Source type
        row += 1
        ctk.CTkLabel(master, text="Typ").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        types = ["image", "camera"]
        current_type = self.config_data["source"].get("type", "image")
        self.option_source_type = ctk.CTkOptionMenu(master, values=types)
        self.option_source_type.set(current_type)
        self.option_source_type.grid(
            row=row, column=1, padx=(20, 5), pady=5, sticky="ew"
        )

        # Camera index
        row += 1
        ctk.CTkLabel(master, text="Kamera Index").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_camera_index = ctk.CTkEntry(master)
        self.entry_camera_index.insert(
            0, str(self.config_data["source"].get("camera_index", 0))
        )
        self.entry_camera_index.grid(
            row=row, column=1, padx=(20, 5), pady=5, sticky="ew"
        )

        # Image path (SOURCE)
        row += 1
        ctk.CTkLabel(master, text="Bildpfad").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_image_path = ctk.CTkEntry(master)
        self.entry_image_path.insert(
            0, self.config_data["source"].get("image_path", "")
        )
        self.entry_image_path.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        ctk.CTkButton(
            master,
            text="📁",
            width=36,
            command=lambda: self._browse_file(
                self.entry_image_path,
                [
                    ("Bilder", "*.png *.jpg *.jpeg *.bmp *.tiff"),
                    ("Alle Dateien", "*.*"),
                ],
            ),
        ).grid(row=row, column=2, padx=(0, 20), pady=5)

        self._next_row = row + 1

    def _build_processing_section(self, master):
        row = self._next_row
        ctk.CTkLabel(
            master,
            text="Verarbeitungseinstellungen",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).grid(row=row, column=0, padx=20, pady=(20, 5), sticky="w")

        # Shapes
        row += 1
        ctk.CTkLabel(master, text="Formen").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_shapes = ctk.CTkEntry(master)
        self.entry_shapes.insert(0, self.config_data["processing"].get("shapes", ""))
        self.entry_shapes.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        # Canny thresholds
        row += 1
        ctk.CTkLabel(master, text="Canny Schwelle 1").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_canny_t1 = ctk.CTkEntry(master)
        self.entry_canny_t1.insert(
            0, str(self.config_data["processing"].get("canny_threshold1", 50))
        )
        self.entry_canny_t1.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        row += 1
        ctk.CTkLabel(master, text="Canny Schwelle 2").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_canny_t2 = ctk.CTkEntry(master)
        self.entry_canny_t2.insert(
            0, str(self.config_data["processing"].get("canny_threshold2", 150))
        )
        self.entry_canny_t2.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        # Blur kernel
        row += 1
        ctk.CTkLabel(master, text="Blur Kernel").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        kernel = self.config_data["processing"].get("blur_kernel", [5, 5])
        self.entry_blur_kernel = ctk.CTkEntry(master)
        self.entry_blur_kernel.insert(0, ",".join(map(str, kernel)))
        self.entry_blur_kernel.grid(
            row=row, column=1, padx=(20, 5), pady=5, sticky="ew"
        )

        # min/max area
        row += 1
        ctk.CTkLabel(master, text="Min Area").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_min_area = ctk.CTkEntry(master)
        self.entry_min_area.insert(
            0, str(self.config_data["processing"].get("min_area", 1000))
        )
        self.entry_min_area.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        row += 1
        ctk.CTkLabel(master, text="Max Area").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_max_area = ctk.CTkEntry(master)
        self.entry_max_area.insert(
            0, str(self.config_data["processing"].get("max_area", 50000))
        )
        self.entry_max_area.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        self._next_row = row + 1

    def _build_output_section(self, master):
        row = self._next_row
        ctk.CTkLabel(
            master,
            text="Ausgabeeinstellungen",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).grid(row=row, column=0, padx=20, pady=(20, 5), sticky="w")

        # IMAGE OUTPUT SECTION
        row += 1
        ctk.CTkLabel(master, text="Bild anzeigen").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.switch_img_show = ctk.CTkSwitch(master)
        if self.config_data["output"]["image"].get("show", False):
            self.switch_img_show.select()
        self.switch_img_show.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="w")

        row += 1
        ctk.CTkLabel(master, text="Bild speichern").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.switch_img_save = ctk.CTkSwitch(master)
        if self.config_data["output"]["image"].get("save", False):
            self.switch_img_save.select()
        self.switch_img_save.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="w")

        # OUTPUT IMAGE PATH
        row += 1
        ctk.CTkLabel(master, text="Bild Ausgabepfad").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )

        self.entry_img_path = ctk.CTkEntry(master)
        self.entry_img_path.insert(
            0, self.config_data["output"]["image"].get("path", "")
        )
        self.entry_img_path.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        ctk.CTkButton(
            master,
            text="📁",
            width=36,
            command=lambda: self._browse_image_output_path(self.entry_img_path),
        ).grid(row=row, column=2, padx=(0, 20), pady=5)

        # ---------------- LOG OUTPUT ----------------
        row += 1
        ctk.CTkLabel(master, text="Log Ausgabe").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.switch_output_log = ctk.CTkSwitch(master)
        if self.config_data["output"]["log"].get("enabled", False):
            self.switch_output_log.select()
        self.switch_output_log.grid(
            row=row, column=1, padx=(20, 5), pady=5, sticky="ew"
        )

        row += 1
        ctk.CTkLabel(master, text="Log Pfad").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_log_path = ctk.CTkEntry(master)
        self.entry_log_path.insert(0, self.config_data["output"]["log"].get("path", ""))
        self.entry_log_path.grid(row=row, column=1, padx=(20, 5), pady=5, sticky="ew")

        ctk.CTkButton(
            master,
            text="📁",
            width=36,
            command=lambda: self._browse_log_output_path(self.entry_log_path),
        ).grid(row=row, column=2, padx=(0, 20), pady=5)

        # TTS
        row += 1
        ctk.CTkLabel(master, text="text-to-speach aktivieren").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.switch_output_tts = ctk.CTkSwitch(master)
        if self.config_data["output"]["tts"].get("enabled", False):
            self.switch_output_tts.select()
        self.switch_output_tts.grid(
            row=row, column=1, padx=(20, 5), pady=5, sticky="ew"
        )

        row += 1
        ctk.CTkLabel(master, text="text-to-speach Sprache").grid(
            row=row, column=0, padx=20, pady=5, sticky="w"
        )
        self.entry_tts_language = ctk.CTkEntry(master)
        self.entry_tts_language.insert(
            0, self.config_data["output"]["tts"].get("language", "")
        )
        self.entry_tts_language.grid(
            row=row, column=1, padx=(20, 5), pady=5, sticky="ew"
        )

        self._next_row = row + 1

    def _build_buttons(self, master):
        row = self._next_row
        ctk.CTkButton(master, text="💾 Speichern", command=self._save_settings).grid(
            row=row, column=0, columnspan=2, padx=20, pady=(20, 10), sticky="ew"
        )
        row += 1
        ctk.CTkButton(master, text="❌ Abbrechen", command=self.destroy).grid(
            row=row, column=0, columnspan=2, padx=20, pady=(0, 20), sticky="ew"
        )

    # -------------------- SAVE LOGIC --------------------

    def _save_settings(self):
        """Collect user inputs and build the updated config dictionary."""
        try:
            blur_kernel = [
                int(x.strip()) for x in self.entry_blur_kernel.get().split(",")
            ]
        except ValueError:
            self.master.throw_error("Ungültiger Blur Kernel!")
            return

        try:
            new_config = {
                "$schema": self.config_data.get("$schema", "config_schema.json"),
                "source": {
                    "type": self.option_source_type.get(),
                    "camera_index": int(self.entry_camera_index.get()),
                    "image_path": self.entry_image_path.get().strip(),
                },
                "processing": {
                    "shapes": self.entry_shapes.get().strip(),
                    "canny_threshold1": int(self.entry_canny_t1.get()),
                    "canny_threshold2": int(self.entry_canny_t2.get()),
                    "blur_kernel": blur_kernel,
                    "min_area": int(self.entry_min_area.get()),
                    "max_area": int(self.entry_max_area.get()),
                },
                "output": {
                    "image": {
                        "show": bool(self.switch_img_show.get()),
                        "save": bool(self.switch_img_save.get()),
                        "path": self.entry_img_path.get().strip(),
                    },
                    "log": {
                        "enabled": bool(self.switch_output_log.get()),
                        "path": self.entry_log_path.get().strip(),
                    },
                    "tts": {
                        "enabled": bool(self.switch_output_tts.get()),
                        "language": self.entry_tts_language.get().strip(),
                    },
                },
            }
        except ValueError as e:
            self.master.throw_error(f"Ungültige Eingabe: {e}")
            return

        if self.on_save:
            self.on_save(new_config)

        self.destroy()

    # -------------------- BROWSE HELPERS --------------------

    def _browse_file(self, entry_widget, filetypes):
        file_path = fd.askopenfilename(title="Datei auswählen", filetypes=filetypes)
        if file_path:
            entry_widget.delete(0, "end")
            entry_widget.insert(0, file_path)

    def _browse_image_output_path(self, entry_widget):
        """Folder selection + image filename handling."""
        folder = fd.askdirectory(title="Ordner auswählen")
        if not folder:
            return

        folder = folder.rstrip("/\\")
        current = entry_widget.get().strip()

        # Extract filename or set default
        if current and ("/" in current or "\\" in current):
            filename = current.split("/")[-1].split("\\")[-1]
            if "." not in filename:
                filename = "output_img.png"
        else:
            filename = "output_img.png"

        entry_widget.delete(0, "end")
        entry_widget.insert(0, folder + "/" + filename)

    def _browse_log_output_path(self, entry_widget):
        """Folder selection + CSV filename handling."""
        folder = fd.askdirectory(title="Ordner auswählen")
        if not folder:
            return

        folder = folder.rstrip("/\\")
        current = entry_widget.get().strip()

        # Extract filename or default
        if current and ("/" in current or "\\" in current):
            filename = current.split("/")[-1].split("\\")[-1]
            if "." not in filename:
                filename = "output.csv"
        else:
            filename = "output.csv"

        entry_widget.delete(0, "end")
        entry_widget.insert(0, folder + "/" + filename)
