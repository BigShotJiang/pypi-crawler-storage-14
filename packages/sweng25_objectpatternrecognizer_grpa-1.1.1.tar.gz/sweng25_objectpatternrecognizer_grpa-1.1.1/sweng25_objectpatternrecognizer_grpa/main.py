"""Main application module for real-time or file-based shape detection using OpenCV.

This module coordinates the following components:

- SourceHandler: Handles input sources such as camera streams or image files.
- ShapeDetector: Performs image processing and shape detection on frames.
- OutputHandler: Manages output operations (display, storage, logging, audio output).
- MainWindow: GUI window used when not running in headless mode.
- ConfigService: Loads, stores and provides configuration settings.
- ArgParser: Parses command-line arguments.

Depending on the mode (GUI or headless), the application opens a GUI or performs
the functions directly with the arguments given in the config file and the comand line.

Functions
---------
get_process_and_write_frame:
    Retrieves a frame, processes it and handles the output.
make_callbacks:
    Creates GUI callback functions.
main:
    Entry point used to start the application.
"""

from typing import Any
import cv2
from .config_service import ConfigService
from .source_handler import SourceHandler
from .image_processing import ShapeDetector
from .output_handler import OutputHandler
from .utils import ArgParser
from .gui import MainWindow, MainFunctions


def get_process_and_write_frame(
    source: SourceHandler,
    processor: ShapeDetector,
    output: OutputHandler,
    imshow: bool = True,
) -> cv2.typing.MatLike:
    """Retrieve, process and write a single frame.

    Parameters
    ----------
    source : SourceHandler
        Object managing the current input source (camera or image).
    processor : ShapeDetector
        Processing pipeline performing shape detection.
    output : OutputHandler
        Object that handles resulting frames and detection outputs.
    imshow : bool, optional
        Whether to display the frame using OpenCV (default: True).

    Returns
    -------
    cv2.typing.MatLike
        The processed output frame.
    """
    frame = source.get_frame()
    output_frame, detected = processor.detect(frame)
    output.handle(output_frame, detected, imshow)
    return output_frame


def make_callbacks(
    window: "MainWindow",
    source: SourceHandler,
    processor: ShapeDetector,
    output: OutputHandler,
    cfg_service: ConfigService,
) -> MainFunctions:
    """Create GUI callback functions for user interactions.

    Parameters
    ----------
    window : MainWindow
        The main GUI window.
    source : SourceHandler
        Object managing the current input source (camera or image).
    processor : ShapeDetector
        Processing pipeline performing shape detection.
    output : OutputHandler
        Object that handles resulting frames and detection outputs.
    cfg_service : ConfigService
        Object that manages configuration loading and saving.

    Returns
    -------
    MainFunctions
        Container object with bound callback functions.
    """
    stream_running = False

    def stop_stream() -> None:
        """Stop the active stream and release its resources."""
        nonlocal stream_running
        stream_running = False
        source.release()

    def on_file_open(image_path: str) -> None:
        """Open a still image and process it once.

        Parameters
        ----------
        image_path : str
            Path to the image file.
        """
        stop_stream()
        source.init_source("image", image_path)
        output_frame = get_process_and_write_frame(source, processor, output, False)
        window.update_frame(output_frame)

    def on_stream_start() -> None:
        """Start or stop continuous camera streaming.

        When activated, the GUI requests new frames every 33 ms (30 fps).
        """
        nonlocal stream_running

        def loop() -> None:
            """Loop callback for continuous streaming."""
            if not stream_running:
                return
            output_frame = get_process_and_write_frame(source, processor, output, False)
            window.update_frame(output_frame)
            window.after(33, loop)  # Repeat every 33ms -> 30fps

        if stream_running:
            stream_running = False  # stop the loop
        else:
            stream_running = True  # start the loop
            if source.capture is None:
                source.init_source("camera")
            loop()

    def on_settings_open() -> dict:
        """Open the settings panel.

        Returns
        -------
        dict
            The currently active configuration.
        """
        stop_stream()
        return cfg_service.get_config()

    def on_save(settings: dict[str, Any]) -> None:
        """Save updated settings and reinitialize components.

        Parameters
        ----------
        settings : dict[str, Any]
            Updated configuration values.
        """
        nonlocal source, processor, output
        try:
            cfg_service.save_config(settings)
        except RuntimeError as e:
            window.throw_error(f"Fehler beim Speichern der Konfiguration: {e}")
            return
        cfg = cfg_service.get_config()
        source = SourceHandler(cfg)
        processor = ShapeDetector(cfg)
        output = OutputHandler(cfg)

    def on_close() -> None:
        """Close the application and release all resources."""
        stop_stream()
        output.close()
        window.quit()
        window.destroy()

    return MainFunctions(
        on_file_open=on_file_open,
        on_stream_start=on_stream_start,
        on_settings_open=on_settings_open,
        on_save=on_save,
        on_close=on_close,
    )


def main(args=None) -> None:
    """Main entry point for the application.

    Parameters
    ----------
    args : list, optional
        Optional argument list for custom execution.
        If None, all parameters will be taken from the config file.

    Notes
    -----
    Two execution modes are supported:

    - Headless mode:
      Runs processing in the terminal without a GUI.

    - GUI mode:
      Opens an interactive window with user controls.
    """
    args = ArgParser().parse()

    cfg_service = ConfigService(
        args.config_path, args.source, args.image_path, args.camera_index
    )
    cfg = cfg_service.get_config()
    source = SourceHandler(cfg)
    processor = ShapeDetector(cfg)
    output = OutputHandler(cfg)

    if args.headless:
        # run without gui
        try:
            while True:
                get_process_and_write_frame(source, processor, output)

                if cfg["source"]["type"] == "image":
                    cv2.waitKey(0)
                    break
                if cv2.waitKey(1) == ord("q"):
                    break
        except KeyboardInterrupt:
            pass
        finally:
            source.release()
            output.close()

    else:
        # run with gui
        gui = MainWindow(cfg)
        gui.set_callbacks(make_callbacks(gui, source, processor, output, cfg_service))
        gui.run()
