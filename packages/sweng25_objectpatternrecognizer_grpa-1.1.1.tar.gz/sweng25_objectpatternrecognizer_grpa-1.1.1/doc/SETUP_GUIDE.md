# Installation

These instructions explain how to set up the environment and run the application.  
We recommend using **Visual Studio Code (VS Code)** as the development environment, since the steps below refer to its interface.

## Requirements

### Extensions
Make sure the following VS Code extensions are installed:
- **Mypy** – for static type checking  
- **Pylint** – for code linting and style checks  
- **Black Formatter** – for automatic code formatting  

To enable automatic formatting on save, open your VS Code settings and set:
```json
"editor.formatOnSave": true
```

---

## Setting Up the Virtual Environment

We use **venv**, which comes preinstalled with Python. This ensures compatibility across all systems.

Follow these steps to create and activate the virtual environment:

1. Open the project folder in VS Code.  
2. Open the integrated terminal (`Ctrl+`` or via *View > Terminal*).  
3. Run the following commands:

  ```bash
  python -m venv venv
  ```
  ```bash
  .\venv\Scripts\activate
  ```
  ```bash
  python -c "import tomllib, subprocess; deps = tomllib.load(open('pyproject.toml', 'rb'))['project']['dependencies']; subprocess.run(['pip', 'install', *deps])"
  ```

---

## Updating the Virtual Environment

If you install new packages (e.g., using `pip install package_name`), remember to update the `pyproject.toml` file so teammates can reproduce your environment.

```json
dependencies = [
    "numpy==2.2.6",
    "opencv-python==4.12.0.88",
    "pytest",
    ...
]
```

---

## Notes

- Make sure Python is added to your system PATH.  
- If you encounter issues activating the virtual environment on Windows, run PowerShell as an administrator and use:
  ```bash
  Set-ExecutionPolicy RemoteSigned
  ```
- For macOS/Linux, activate the environment with:
  ```bash
  source venv/bin/activate
  ```
