# Continious Integration Continius Deployment

## What is CICD

**Continuous Integration** (CI) and **Continuous Deployment (CD)** are modern DevOps practices that automate the process of building, testing, and deploying software.

- **Continuous Integration (CI)** ensures that code changes are automatically built and tested every time they are pushed to the repository. This helps to detect bugs early and maintain a stable main branch.

- **Continuous Deployment (CD)** automates the release process so that successful builds and tests can be deployed to production or a package registry (like **PyPI**) with minimal manual effort.

### Build Pipeline

A **build pipeline** defines the sequence of automated steps that are executed after a commit or pull request.
Typical stages include:

1. **Checkout Code** – Clone the repository.
2. **Install Dependencies** – Set up the Python environment.
3. **Run Tests** – Execute unit tests (e.g., with `pytest`).
4. **Build Package** – Generate a distributable version of the project (wheel or source package).
5. **Publish / Deploy** – Upload the package to PyPI or deploy to a server.

### PyPI

**PyPI (Python Package Index)** is the official repository for Python packages. It allows developers to distribute their code so that others can install it easily via `pip install <package-name>`.\
To publish packages securely, you typically use API tokens stored in CI secrets.

## GitHub Actions Workflow: CI & Deploy to PyPI (Trusted Publisher)

This GitHub Actions workflow automates testing and deployment of the package to **PyPI**.\
It runs automatically on **pull requests**, **tag pushes**, and **manual triggers**, ensuring high code quality and streamlined releases.

🔄 **Triggers** (``on``:)

```yaml
on:
  pull_request:
    branches: [ "main" ]
  push:
    tags:
      - 'v*'   # Runs only when a tag like v0.1.0 is pushed
  workflow_dispatch:  # Allows manual triggering
```

- **Pull requests** → run tests before merging into **main**.
- **Tag pushes** (e.g., ``v0.2.0``) → trigger build and deployment to PyPI.

- **Manual run** → allows developers to start the workflow manually from GitHub (deployment not possible).

---
🔐 **Permissions**

````yaml
permissions:
  contents: read
  id-token: write
````

The ``id-token: write`` permission is required for **Trusted Publisher authentication** with PyPI, eliminating the need for storing API tokens as secrets.

---
🧪 **Job**: ``test`` – **Run Tests**

This job ensures that the package builds and runs correctly before any deployment happens.

````yaml
jobs:
  test:
    name: Run Tests
    runs-on: ubuntu-latest
````

**Steps**:

1. **Checkout code**

````yaml
- uses: actions/checkout@v4
````

Downloads the repository to the runner.

2. **Set up Python environment**

````yaml
- uses: actions/setup-python@v5
  with:
    python-version: "3.11"
````

Uses Python 3.11.

1. **Install dependencies**

````yaml
- name: Install dependencies
  run: |
    python -m pip install --upgrade pip
    pip install .
````

Installs the package and all required dependencies from ``pyproject.toml``.

1. **Run tests**

````yaml
- name: Run tests
  run: pytest --maxfail=1 --disable-warnings -q
````

Executes all tests with **pytest**, failing early on errors and keeping logs clean.

---
🚀 **Job**: ``deploy`` – **Publish to PyPI**

This job runs only when a new version tag (e.g., ``v0.1.0``) is pushed.

````yaml
needs: test
if: startsWith(github.ref, 'refs/tags/v')
````

It depends on the successful completion of the ``test`` job.

**Steps:**

1. **Checkout code**

````yaml
- uses: actions/checkout@v4
````

2. **Set up Python**

````yaml
- uses: actions/setup-python@v5
  with:
    python-version: "3.11"
````

3. **Install build tools**

````yaml
- name: Install build tools
  run: |
    python -m pip install --upgrade pip
    pip install build setuptools_scm[toml]
````

Installs the required packaging tools for building your Python project.

4. **Build the package**

````yaml
- name: Build package
  run: python -m build
````

Creates a source distribution (.tar.gz) and a wheel (.whl) inside the dist/ folder.

5. **Publish to PyPI**

````yaml
- name: Publish to PyPI via Trusted Publisher
  uses: pypa/gh-action-pypi-publish@release/v1
  with:
    print-hash: true
````

Uses PyPI’s Trusted Publisher mechanism for secure deployment — no manual API tokens or passwords are needed.
It authenticates directly with PyPI via GitHub’s OpenID Connect (OIDC) system.

----
✅ Summary

- **Pull request:** Runs tests to ensure quality.
- **Tag push:** Builds and publishes automatically to PyPI.
- **Security:** Uses Trusted Publisher → no need for storing secrets.
- **Automation:** Minimal manual steps, fully reproducible builds.

## CI/CD Local Setup

### Running Tests with Pytest in VS Code

To efficiently run and debug tests locally using **VS Code**:

1. Open the **Command Palette** (`Ctrl+Shift+P` or `Cmd+Shift+P` on macOS).
2. Search for **“Python: Configure Tests”** → choose pytest as your test framework.
3. VS Code will automatically detect tests in files named like `test_*.py`.
4. Use the **Testing Panel** (flask icon) to run or debug tests individually or all at once.

### Build Package Locally

Before building, **commit all your changes** so you can restore it later.\
Update your ``pyproject.toml`` to:

```toml
[project]
name = "SWENG25_ObjectPatternRecognizer_GrpA"
version = "0.0.2"
description = "Objekterkennungsbibliothek für SWENG25"
authors = [
    { name = "Fabian Holzknecht", email = "fabian.holzknecht@bluewin.ch" },
    { name = "Sascha Zumstein", email = "sascha.zumstein@bluewin.ch" },
    { name = "Lenard Zimmermann", email = "lenard-z@outlook.com" }
]
readme = "README.md"
requires-python = ">=3.10"
dependencies = [
    "numpy==2.2.6",
    "opencv-python==4.12.0.88",
    "pytest"
]

[project.scripts]
sweng25-objectpatternrecognizer-grpa = "sweng25_objectpatternrecognizer_grpa.main:main"
```

Then build and install the package locally:

```bash
python -m build
```

you may have to install build first

```bash
pip install build
```

After testing the package locally, you can reset the branch and remove all build-related folders from your working directory.

### Test Build Pipeline Locally

To simulate your GitHub Actions CI pipeline locally:

#### Required Tools

- [Docker](https://www.docker.com/)
- [Nektos Act](https://nektosact.com/installation/index.html)

#### Setup Steps

1. Install **Docker**. (WSL installs itself, when not allready installed)
2. Move the act-folder with the act executable to:

    ````bash
    C:\Users\<YourName>\AppData\Local\Programs\
    ````

3. Add that folder to your **system environment variables (PATH)**.
4. In your repository root (where ``.github/workflows`` is located), run:

````bash
act
````

This will execute your GitHub Actions workflow locally in a Docker container, letting you test your CI/CD configuration before committing.

💡 **Tip**:\
To run only specific jobs or use a specific event trigger:

````bash
act -j build
act pull_request
````
