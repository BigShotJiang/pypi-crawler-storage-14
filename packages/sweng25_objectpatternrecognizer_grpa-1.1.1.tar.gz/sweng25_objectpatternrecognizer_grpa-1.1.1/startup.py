"""Startup script for launching the Object Pattern Recognizer application.

This module serves as a minimal entry point for the Object Pattern Recognizer.
It's intended to be used as the executable script to start the full
image-processing and pattern-recognition application.

Notes
-----
This file does not handle any command-line arguments or configuration
directly; all logic is delegated to the package's main() function.
"""

import sweng25_objectpatternrecognizer_grpa as opr

opr.main()
