def hello():
    return "Hello from account-manager-sdk!"