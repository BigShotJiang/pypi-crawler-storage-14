``fsl.data.bitmap``
===================

.. automodule:: fsl.data.bitmap
    :members:
    :undoc-members:
    :show-inheritance:
