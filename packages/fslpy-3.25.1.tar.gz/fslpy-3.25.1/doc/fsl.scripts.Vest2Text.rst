``fsl.scripts.Vest2Text``
=========================

.. automodule:: fsl.scripts.Vest2Text
    :members:
    :undoc-members:
    :show-inheritance:
