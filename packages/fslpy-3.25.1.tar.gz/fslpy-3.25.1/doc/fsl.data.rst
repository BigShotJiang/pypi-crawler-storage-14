``fsl.data``
============

.. toctree::
   :hidden:

   fsl.data.atlases
   fsl.data.bitmap
   fsl.data.cifti
   fsl.data.constants
   fsl.data.dicom
   fsl.data.dtifit
   fsl.data.featanalysis
   fsl.data.featdesign
   fsl.data.featimage
   fsl.data.fixlabels
   fsl.data.freesurfer
   fsl.data.gifti
   fsl.data.image
   fsl.data.imagewrapper
   fsl.data.melodicanalysis
   fsl.data.melodicimage
   fsl.data.mesh
   fsl.data.mghimage
   fsl.data.utils
   fsl.data.vest
   fsl.data.volumelabels
   fsl.data.vtk

.. automodule:: fsl.data
    :members:
    :undoc-members:
    :show-inheritance:
