``fsl.utils.filetree.parse``
============================

.. automodule:: fsl.utils.filetree.parse
    :members:
    :undoc-members:
    :show-inheritance:
