``fsl.utils.filetree``
======================

.. toctree::
   :hidden:

   fsl.utils.filetree.filetree
   fsl.utils.filetree.parse
   fsl.utils.filetree.query
   fsl.utils.filetree.utils

.. automodule:: fsl.utils.filetree
    :members:
    :undoc-members:
    :show-inheritance:
