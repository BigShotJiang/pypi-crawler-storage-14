``fsl.data.featimage``
======================

.. automodule:: fsl.data.featimage
    :members:
    :undoc-members:
    :show-inheritance:
