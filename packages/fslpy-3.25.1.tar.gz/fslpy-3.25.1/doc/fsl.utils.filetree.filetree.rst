``fsl.utils.filetree.filetree``
===============================

.. automodule:: fsl.utils.filetree.filetree
    :members:
    :undoc-members:
    :show-inheritance:
