``fsl.wrappers.bedpostx``
=========================

.. automodule:: fsl.wrappers.bedpostx
    :members:
    :undoc-members:
    :show-inheritance:
