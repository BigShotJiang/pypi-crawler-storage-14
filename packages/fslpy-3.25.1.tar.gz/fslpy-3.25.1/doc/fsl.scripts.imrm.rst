``fsl.scripts.imrm``
====================

.. automodule:: fsl.scripts.imrm
    :members:
    :undoc-members:
    :show-inheritance:
