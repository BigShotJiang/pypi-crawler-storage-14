``fsl.data.atlases``
====================

.. automodule:: fsl.data.atlases
    :members:
    :undoc-members:
    :show-inheritance:
