``fsl.utils.image``
===================

.. toctree::
   :hidden:

   fsl.utils.image.resample
   fsl.utils.image.roi

.. automodule:: fsl.utils.image
    :members:
    :undoc-members:
    :show-inheritance:
