``fsl.utils.image.roi``
=======================

.. automodule:: fsl.utils.image.roi
    :members:
    :undoc-members:
    :show-inheritance:
