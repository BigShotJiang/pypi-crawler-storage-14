``fsl.utils.image.resample``
============================

.. automodule:: fsl.utils.image.resample
    :members:
    :undoc-members:
    :show-inheritance:
