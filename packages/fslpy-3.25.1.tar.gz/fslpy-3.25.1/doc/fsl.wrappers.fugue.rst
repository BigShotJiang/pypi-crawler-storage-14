``fsl.wrappers.fugue``
======================

.. automodule:: fsl.wrappers.fugue
    :members:
    :undoc-members:
    :show-inheritance:
