``fsl.transform.fnirt``
=======================

.. automodule:: fsl.transform.fnirt
    :members:
    :undoc-members:
    :show-inheritance:
