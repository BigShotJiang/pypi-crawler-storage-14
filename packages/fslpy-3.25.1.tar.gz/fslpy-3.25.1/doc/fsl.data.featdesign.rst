``fsl.data.featdesign``
=======================

.. automodule:: fsl.data.featdesign
    :members:
    :undoc-members:
    :show-inheritance:
