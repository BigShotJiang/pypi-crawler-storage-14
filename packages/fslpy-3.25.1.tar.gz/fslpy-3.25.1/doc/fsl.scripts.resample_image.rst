``fsl.scripts.resample_image``
==============================

.. automodule:: fsl.scripts.resample_image
    :members:
    :undoc-members:
    :show-inheritance:
