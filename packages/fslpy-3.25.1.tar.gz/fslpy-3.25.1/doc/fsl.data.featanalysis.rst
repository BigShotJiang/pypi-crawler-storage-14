``fsl.data.featanalysis``
=========================

.. automodule:: fsl.data.featanalysis
    :members:
    :undoc-members:
    :show-inheritance:
