# auto_adpq

---

This repo aims at replicating [AdpQ: A Zero-shot Calibration Free Adaptive Post Training Quantization Method for LLMs](https://arxiv.org/abs/2405.13358) since no public repo seems to propose it

```
# Install the package

pip install -e .

# Install the build tools

pip install -e .[dev]
```