# pySigma_validators_sigmaHQ

![Tests](https://github.com/SigmaHQ/pySigma-validators-sigmaHQ/actions/workflows/test.yml/badge.svg)
![Coverage Badge](https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/frack113/b27ee1cbe964fb1a299cc20c3403f8c8/raw/pySigma-validators-sigmaHQ.json)
![Status](https://img.shields.io/badge/Status-pre--release-orange)

## 🌟 Purpose

Create all validators specific to the requirements of the SigmaHQ rules repository

## 🏗️ Validators

TBD

## 🧬 Data

All the data value are in the config.py

To use a local json version, you need to put them in a `validator_json` folder visible from the launch directory.

## 📜 Maintainer

This pipeline is currently maintained by:

* [François Hubaut (@frack113)](https://twitter.com/frack113)
* [Christian Burkard (@phantinuss)](https://twitter.com/phantinuss)
