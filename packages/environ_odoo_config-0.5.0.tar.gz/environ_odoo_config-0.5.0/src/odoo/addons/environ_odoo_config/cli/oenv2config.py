from environ_odoo_config import _cli, _odoo_command


class _OEnv2Config(_odoo_command.OdooCommand):
    """
    [Deprecated] alias of `generate_config`
    """

    # The attribute EnvironConfigGenerate (exactly the same of the current class name) is for old odoo version
    name = "oenv2config"

    # @property
    # def prog(self):
    #     return super().prog

    @property
    def parser(self):
        return _cli.get_odoo_cmd_parser()

    def run(self, cmdargs):
        return _cli.env_to_config(cmdargs)
