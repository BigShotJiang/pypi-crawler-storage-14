from environ_odoo_config import _cli, _odoo_command


class _GenerateConfig(_odoo_command.OdooCommand):
    """
    Generate an odoo config file from environ variable.
    """

    # The attribute EnvironConfigGenerate (exactly the same of the current class name) is for old odoo version
    name = "generate_config"

    # @property
    # def prog(self):
    #     return super().prog

    @property
    def parser(self):
        return _cli.get_odoo_cmd_parser()

    def run(self, cmdargs):
        return _cli.env_to_config(cmdargs)
