from unittest import TestCase
from src.environ_odoo_config.entrypoints import EntryPoints

class TestEntrypointMapper(TestCase):

    def test_load(self):
        self.assertTrue(EntryPoints.mappers)
        self.assertEqual(len(EntryPoints.extension), 3)
