nosetests atmos
