"""
Tests for async task utilities.
"""

import asyncio

import pytest

from notionalpha.utils.async_tasks import schedule_background_task


@pytest.mark.asyncio
async def test_schedule_background_task_uses_running_loop():
    """When an event loop is active, coroutines should run on it."""
    event = asyncio.Event()

    async def _task():
        event.set()

    schedule_background_task(_task())
    await asyncio.wait_for(event.wait(), timeout=1)


def test_schedule_background_task_without_loop(monkeypatch):
    """Without a running loop, the coroutine should run in a background thread."""
    events = []
    thread_kwargs = {}

    class FakeThread:
        def __init__(self, target, args=(), daemon=False):
            self._target = target
            self._args = args
            thread_kwargs['daemon'] = daemon
        def start(self):
            self._target(*self._args)

    monkeypatch.setattr('notionalpha.utils.async_tasks.threading.Thread', FakeThread)

    async def _task():
        events.append('done')

    schedule_background_task(_task())
    assert events == ['done']
    assert thread_kwargs.get('daemon') is True
