"""
Tests for NotionAlphaClient
"""

from unittest.mock import Mock, patch

import pytest
from notionalpha import NotionAlphaClient
from notionalpha.types import ConfigurationError


class TestNotionAlphaClient:
    """Test NotionAlphaClient initialization and configuration"""
    
    def test_init_with_valid_config(self):
        """Test client initialization with valid configuration"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            provider={'type': 'openai', 'provider_id': 'provider-123'}
        )
        
        assert client.org_id == 'org_test123'
        assert client.team_id == 'team-uuid-123'
        assert client.environment == 'production'
        assert client.provider['type'] == 'openai'
    
    def test_init_with_custom_environment(self):
        """Test client initialization with custom environment"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            environment='staging',
            provider={'type': 'openai', 'provider_id': 'provider-123'}
        )
        
        assert client.environment == 'staging'
    
    def test_init_with_feature_id(self):
        """Test client initialization with feature ID"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            feature_id='test-feature',
            provider={'type': 'openai', 'provider_id': 'provider-123'}
        )
        
        assert client.feature_id == 'test-feature'
    
    def test_init_missing_org_id(self):
        """Test client initialization fails without org_id"""
        with pytest.raises(ConfigurationError, match='org_id is required'):
            NotionAlphaClient(
                org_id='',
                team_id='team-uuid-123',
                provider={'type': 'openai', 'provider_id': 'provider-123'}
            )
    
    def test_init_missing_team_id(self):
        """Test client initialization fails without team_id"""
        with pytest.raises(ConfigurationError, match='team_id is required'):
            NotionAlphaClient(
                org_id='org_test123',
                team_id='',
                provider={'type': 'openai', 'provider_id': 'provider-123'}
            )
    
    def test_init_missing_provider(self):
        """Test client initialization fails without provider"""
        with pytest.raises(ConfigurationError, match='provider is required'):
            NotionAlphaClient(
                org_id='org_test123',
                team_id='team-uuid-123',
                provider=None
            )
    
    def test_init_unsupported_provider(self):
        """Test client initialization fails with unsupported provider"""
        with pytest.raises(ConfigurationError, match='Unsupported provider type'):
            NotionAlphaClient(
                org_id='org_test123',
                team_id='team-uuid-123',
                provider={'type': 'unsupported', 'provider_id': 'provider-123'}
            )
    
    def test_openai_provider_initialization(self):
        """Test OpenAI provider is initialized correctly"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            provider={'type': 'openai', 'provider_id': 'provider-123'}
        )
        
        assert hasattr(client, 'chat')
        assert client.chat is not None
    
    def test_anthropic_provider_initialization(self):
        """Test Anthropic provider is initialized correctly"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            provider={'type': 'anthropic', 'provider_id': 'provider-123'}
        )
        
        assert hasattr(client, 'messages')
        assert client.messages is not None
    
    def test_azure_ai_foundry_provider_initialization(self):
        """Test Azure AI Foundry provider is initialized correctly"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            provider={
                'type': 'azure-ai-foundry',
                'provider_id': 'provider-123',
                'deployment_name': 'gpt-4o-mini'
            }
        )

        assert hasattr(client, 'chat')
        assert client.chat is not None

    def test_azure_ai_foundry_provider_with_resource_name_legacy(self):
        """Test Azure AI Foundry provider with resource name (legacy format)"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            provider={
                'type': 'azure-ai-foundry',
                'provider_id': 'provider-123',
                'deployment_name': 'gpt-4o-mini',
                'resource_name': 'my-azure-resource'
            }
        )

        assert hasattr(client, 'chat')
        assert client.chat is not None

    def test_azure_ai_foundry_provider_with_ai_foundry_hostname(self):
        """Test Azure AI Foundry provider with AI Foundry hostname"""
        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            provider={
                'type': 'azure-ai-foundry',
                'provider_id': 'provider-123',
                'deployment_name': 'gpt-4o-mini',
                'resource_name': 'myproject.services.ai.azure.com'
            }
        )

        assert hasattr(client, 'chat')
        assert client.chat is not None

    @patch('notionalpha.providers.openai.SignalAnalyzer')
    @patch('notionalpha.providers.openai.OpenAI')
    def test_signal_enrichment_configuration_passed_to_provider(self, mock_openai_class, mock_signal_analyzer):
        """Signal enrichment config should be wired through to provider instances."""
        mock_openai_class.return_value = Mock()
        mock_signal_analyzer.return_value = Mock()

        client = NotionAlphaClient(
            org_id='org_test123',
            team_id='team-uuid-123',
            provider={'type': 'openai', 'provider_id': 'provider-123'},
            signal_enrichment={
                'enabled': True,
                'openai_api_key': 'test-key',
            },
            signal_capture_url='https://api.example.com/signals'
        )

        mock_signal_analyzer.assert_called_once_with({
            'enabled': True,
            'openai_api_key': 'test-key',
        })
        assert client._provider.signal_analyzer is mock_signal_analyzer.return_value
        assert client._provider.signal_capture_url == 'https://api.example.com/signals'
