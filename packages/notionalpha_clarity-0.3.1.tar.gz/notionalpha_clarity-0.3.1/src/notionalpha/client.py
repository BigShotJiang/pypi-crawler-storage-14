"""
NotionAlpha Clarity Client

Main client for interacting with NotionAlpha Clarity platform
"""

from typing import Any, Dict, List, Literal, Optional, Tuple
from datetime import datetime
import requests
import warnings

from .types import (
    ClarityConfig,
    ProviderConfig,
    OutcomePayload,
    ValueRealizationSummary,
    ForecastData,
    Recommendation,
    ConfigurationError,
    APIError,
    ProviderError,
)
from .signal_analyzer import SignalAnalyzerConfig


class NotionAlphaClient:
    """
    Main NotionAlpha Clarity client
    
    Example:
        >>> from notionalpha import NotionAlphaClient
        >>> 
        >>> clarity = NotionAlphaClient(
        ...     org_id='org_xxx',
        ...     team_id='team-uuid',
        ...     provider={'type': 'openai', 'provider_id': 'provider-uuid'}
        ... )
        >>> 
        >>> # Make LLM call (FinOps + Security automatic)
        >>> response, transaction_id = clarity.chat.completions.create(
        ...     model='gpt-4o-mini',
        ...     messages=[{'role': 'user', 'content': 'Help'}]
        ... )
        >>> 
        >>> # Track outcome (one line)
        >>> clarity.track_outcome(
        ...     transaction_id=transaction_id,
        ...     type='customer_support',
        ...     metadata={'time_saved_minutes': 15}
        ... )
    """
    
    def __init__(
        self,
        org_id: str,
        team_id: str,
        provider: ProviderConfig,
        environment: str = 'production',
        feature_id: Optional[str] = None,
        api_base_url: str = 'https://api.notionalpha.com',
        proxy_base_url: str = 'https://aiproxy.notionalpha.com',
        signal_enrichment: Optional[SignalAnalyzerConfig] = None,
        signal_capture_url: Optional[str] = None,
    ):
        """
        Initialize NotionAlpha Clarity client
        
        Args:
            org_id: Organization ID from NotionAlpha dashboard
            team_id: Team ID for cost attribution
            provider: Provider configuration
            environment: Environment name (default: 'production')
            feature_id: Optional feature ID for granular tracking
            api_base_url: Base URL for NotionAlpha API
            proxy_base_url: Base URL for NotionAlpha proxy
        """
        if not org_id:
            raise ConfigurationError('org_id is required')
        if not team_id:
            raise ConfigurationError('team_id is required')
        if not provider:
            raise ConfigurationError('provider is required')
        
        self.org_id = org_id
        self.team_id = team_id
        self.environment = environment
        self.feature_id = feature_id
        self.provider = provider
        self.api_base_url = api_base_url.rstrip('/')
        self.proxy_base_url = proxy_base_url.rstrip('/')
        self.signal_enrichment = signal_enrichment
        self.signal_capture_url = signal_capture_url
        
        # Initialize provider-specific client
        self._init_provider()
    
    def _init_provider(self) -> None:
        """Initialize provider-specific client"""
        provider_type = self.provider.get('type')

        try:
            if provider_type == 'openai':
                from .providers.openai import OpenAIProvider
                self._provider = OpenAIProvider(
                    provider_id=self.provider['provider_id'],
                    org_id=self.org_id,
                    team_id=self.team_id,
                    environment=self.environment,
                    feature_id=self.feature_id,
                    proxy_base_url=self.proxy_base_url,
                    signal_enrichment=self.signal_enrichment,
                    signal_capture_url=self.signal_capture_url,
                )
            elif provider_type == 'anthropic':
                from .providers.anthropic import AnthropicProvider
                self._provider = AnthropicProvider(
                    provider_id=self.provider['provider_id'],
                    org_id=self.org_id,
                    team_id=self.team_id,
                    environment=self.environment,
                    feature_id=self.feature_id,
                    proxy_base_url=self.proxy_base_url,
                    signal_enrichment=self.signal_enrichment,
                    signal_capture_url=self.signal_capture_url,
                )
            elif provider_type == 'azure-ai-foundry':
                from .providers.azure_ai_foundry import AzureAIFoundryProvider
                self._provider = AzureAIFoundryProvider(
                    provider_id=self.provider['provider_id'],
                    deployment_name=self.provider['deployment_name'],
                    org_id=self.org_id,
                    team_id=self.team_id,
                    environment=self.environment,
                    feature_id=self.feature_id,
                    proxy_base_url=self.proxy_base_url,
                    resource_name=self.provider.get('resource_name'),
                    project_name=self.provider.get('project_name'),
                    api_version=self.provider.get('api_version'),
                    model_type=self.provider.get('model_type'),
                    signal_enrichment=self.signal_enrichment,
                    signal_capture_url=self.signal_capture_url,
                )
            else:
                raise ConfigurationError(f'Unsupported provider type: {provider_type}')
        except ImportError as e:
            raise ConfigurationError(
                f'Failed to import provider {provider_type}. '
                f'Make sure the required SDK is installed: {str(e)}'
            )
    
    @property
    def chat(self):
        """Access chat completions (OpenAI/Azure OpenAI)"""
        if not hasattr(self._provider, 'chat'):
            raise ProviderError(f'Provider {self.provider["type"]} does not support chat completions')
        return self._provider.chat
    
    @property
    def messages(self):
        """Access messages (Anthropic)"""
        if not hasattr(self._provider, 'messages'):
            raise ProviderError(f'Provider {self.provider["type"]} does not support messages')
        return self._provider.messages
    
    def track_outcome(
        self,
        transaction_id: Optional[str] = None,
        type: str = 'custom',
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[datetime] = None,
    ) -> Dict[str, Any]:
        """
        Track a business outcome

        .. deprecated:: 0.3.0
            track_outcome() is deprecated and will be removed in v1.0.0.
            The Clarity SDK now captures signals automatically when you make LLM calls.
            See: https://docs.notionalpha.com/signals-migration

        Args:
            transaction_id: Transaction ID from LLM response (for exact matching)
            type: Outcome type (e.g., 'customer_support_ticket_resolved', 'code_generated')
            metadata: Outcome-specific metadata
            timestamp: Optional timestamp (defaults to now)

        Returns:
            API response with outcome ID and matching details

        Raises:
            APIError: If API request fails
        """
        warnings.warn(
            "track_outcome() is deprecated and will be removed in v1.0.0. "
            "The Clarity SDK now captures signals automatically when you make LLM calls. "
            "Migration guide: https://docs.notionalpha.com/signals-migration",
            DeprecationWarning,
            stacklevel=2
        )

        if metadata is None:
            metadata = {}
        
        payload = {
            'type': type,
            'metadata': metadata,
        }
        
        if transaction_id:
            payload['transactionId'] = transaction_id
        
        if timestamp:
            payload['timestamp'] = timestamp.isoformat()
        
        try:
            response = requests.post(
                f'{self.api_base_url}/api/v1/outcomes',
                headers={
                    'Content-Type': 'application/json',
                    'X-Org-ID': self.org_id,
                    'X-Team-ID': self.team_id,
                    'X-Environment': self.environment,
                },
                json=payload,
                timeout=30,
            )
            response.raise_for_status()
            return response.json()
        except requests.HTTPError as e:
            raise APIError(
                f'Failed to track outcome: {e.response.text}',
                e.response.status_code,
                e.response.json() if e.response.text else None
            )
        except requests.RequestException as e:
            raise APIError(f'Failed to track outcome: {str(e)}', 500)
    
    def get_value_realization(self) -> ValueRealizationSummary:
        """
        Get value realization summary
        
        Returns:
            Value realization summary with cost, value, ROI, etc.
        
        Raises:
            APIError: If API request fails
        """
        try:
            response = requests.get(
                f'{self.api_base_url}/api/v1/value/summary',
                headers={
                    'X-Org-ID': self.org_id,
                    'X-Team-ID': self.team_id,
                },
                timeout=30,
            )
            response.raise_for_status()
            return response.json()
        except requests.HTTPError as e:
            raise APIError(
                f'Failed to get value realization: {e.response.text}',
                e.response.status_code,
                e.response.json() if e.response.text else None
            )
        except requests.RequestException as e:
            raise APIError(f'Failed to get value realization: {str(e)}', 500)

    def get_forecast(
        self,
        horizon: int = 30,
        method: Literal['statistical', 'hybrid', 'llm'] = 'hybrid',
    ) -> ForecastData:
        """
        Get value forecast with predictions and insights

        Args:
            horizon: Forecast horizon in days (7, 14, or 30)
            method: Forecasting method ('statistical', 'hybrid', or 'llm')

        Returns:
            ForecastData with predictions for cost, value, and ROI

        Raises:
            APIError: If API request fails
        """
        try:
            # Fetch all three forecast types in sequence
            cost_response = requests.get(
                f'{self.api_base_url}/api/v1/forecasts/cost',
                headers={
                    'X-Org-ID': self.org_id,
                    'X-Team-ID': self.team_id,
                },
                params={'horizon': horizon, 'method': method},
                timeout=30,
            )
            cost_response.raise_for_status()
            cost_data = cost_response.json()

            value_response = requests.get(
                f'{self.api_base_url}/api/v1/forecasts/value',
                headers={
                    'X-Org-ID': self.org_id,
                    'X-Team-ID': self.team_id,
                },
                params={'horizon': horizon, 'method': method},
                timeout=30,
            )
            value_response.raise_for_status()
            value_data = value_response.json()

            roi_response = requests.get(
                f'{self.api_base_url}/api/v1/forecasts/roi',
                headers={
                    'X-Org-ID': self.org_id,
                    'X-Team-ID': self.team_id,
                },
                params={'horizon': horizon, 'method': method},
                timeout=30,
            )
            roi_response.raise_for_status()
            roi_data = roi_response.json()

            return {
                'horizon': horizon,
                'method': method,
                'predictions': {
                    'cost': cost_data.get('predictions', []),
                    'value': value_data.get('predictions', []),
                    'roi': roi_data.get('predictions', []),
                },
                'insights': cost_data.get('insights'),
                'confidence': cost_data.get('confidence', 0.0),
            }

        except requests.HTTPError as e:
            raise APIError(
                f'Failed to get forecast: {e.response.text}',
                e.response.status_code,
                e.response.json() if e.response.text else None
            )
        except requests.RequestException as e:
            raise APIError(f'Failed to get forecast: {str(e)}', 500)

    def get_recommendations(self) -> List[Recommendation]:
        """
        Get AI-generated optimization recommendations

        Returns:
            List of Recommendation objects with actionable insights

        Raises:
            APIError: If API request fails
        """
        try:
            response = requests.get(
                f'{self.api_base_url}/api/v1/value/recommendations',
                headers={
                    'X-Org-ID': self.org_id,
                    'X-Team-ID': self.team_id,
                },
                timeout=30,
            )
            response.raise_for_status()
            return response.json().get('recommendations', [])
        except requests.HTTPError as e:
            raise APIError(
                f'Failed to get recommendations: {e.response.text}',
                e.response.status_code,
                e.response.json() if e.response.text else None
            )
        except requests.RequestException as e:
            raise APIError(f'Failed to get recommendations: {str(e)}', 500)

    def update_recommendation(
        self,
        recommendation_id: str,
        status: Literal['in_progress', 'completed', 'rejected'],
    ) -> None:
        """
        Update recommendation status

        Args:
            recommendation_id: The ID of the recommendation to update
            status: New status ('in_progress', 'completed', or 'rejected')

        Raises:
            APIError: If API request fails
        """
        try:
            response = requests.put(
                f'{self.api_base_url}/api/v1/value/recommendations/{recommendation_id}',
                headers={
                    'Content-Type': 'application/json',
                    'X-Org-ID': self.org_id,
                    'X-Team-ID': self.team_id,
                },
                json={'status': status},
                timeout=30,
            )
            response.raise_for_status()
        except requests.HTTPError as e:
            raise APIError(
                f'Failed to update recommendation: {e.response.text}',
                e.response.status_code,
                e.response.json() if e.response.text else None
            )
        except requests.RequestException as e:
            raise APIError(f'Failed to update recommendation: {str(e)}', 500)
