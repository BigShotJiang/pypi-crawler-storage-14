"""
NotionAlpha Clarity SDK Types

Core type definitions for the Python SDK
"""

from typing import Any, Dict, List, Literal, Optional, TypedDict, Union
from datetime import datetime


class OpenAIProviderConfig(TypedDict):
    """OpenAI provider configuration"""
    type: Literal['openai']
    provider_id: str


class AnthropicProviderConfig(TypedDict):
    """Anthropic provider configuration"""
    type: Literal['anthropic']
    provider_id: str


class AzureAIFoundryProviderConfig(TypedDict, total=False):
    """
    Azure AI Foundry provider configuration

    Supports both Azure OpenAI models and serverless models (Llama, Mistral, etc.)
    """
    type: Literal['azure-ai-foundry']
    provider_id: str  # Required
    deployment_name: str  # Required - Azure deployment name or serverless model ID
    resource_name: Optional[str]  # Optional - Azure resource hostname
    project_name: Optional[str]  # Optional - AI Foundry project name
    api_version: Optional[str]  # Optional - Azure API version
    model_type: Optional[Literal['openai', 'serverless']]  # Optional - Model type


ProviderConfig = Union[OpenAIProviderConfig, AnthropicProviderConfig, AzureAIFoundryProviderConfig]


class ClarityConfig(TypedDict, total=False):
    """Configuration for NotionAlpha Clarity client"""
    org_id: str  # Required
    team_id: str  # Required
    environment: str  # Optional, default: 'production'
    feature_id: Optional[str]  # Optional
    provider: ProviderConfig  # Required
    api_base_url: str  # Optional, default: 'https://api.notionalpha.com'
    proxy_base_url: str  # Optional, default: 'https://aiproxy.notionalpha.com'


class ClarityLLMResponse(TypedDict):
    """Response from LLM call with transaction ID"""
    response: Any  # Original provider response
    transaction_id: str  # Transaction ID for linking outcomes
    cost: Optional[Dict[str, Any]]  # Cost information if available


OutcomeType = Literal[
    'customer_support_ticket_resolved',
    'code_generated',
    'content_created',
    'lead_qualified',
    'error_prevented',
    'time_saved',
    'quality_improvement',
    'revenue_generated',
    'cost_reduction'
]


class OutcomePayload(TypedDict, total=False):
    """Outcome tracking payload"""
    transaction_id: Optional[str]  # Transaction ID from LLM response
    type: Union[OutcomeType, str]  # Outcome type
    metadata: Dict[str, Any]  # Outcome metadata
    timestamp: Optional[datetime]  # Optional timestamp


class ValueRealizationSummary(TypedDict):
    """Value realization summary"""
    total_cost: float
    total_value: float
    roi: float
    outcome_count: int
    transaction_count: int
    period_start: str
    period_end: str


class EnrichmentMetadata(TypedDict, total=False):
    """Agent-aware enrichment metadata for signal analysis"""
    complexity_score: Optional[int]  # 1-10
    query_type: Optional[Literal['simple', 'moderate', 'complex']]
    retry_count: Optional[int]
    human_escalation_required: Optional[bool]
    outcome_quality: Optional[Literal['high', 'medium', 'low']]
    session_id: Optional[str]
    conversation_turns: Optional[int]
    captured_at: Optional[datetime]
    processing_time_ms: Optional[int]


class ForecastPrediction(TypedDict):
    """Single forecast prediction data point"""
    date: str
    value: float
    lower_bound: float
    upper_bound: float


class ForecastData(TypedDict):
    """Forecast response data"""
    horizon: int
    method: Literal['statistical', 'hybrid', 'llm']
    predictions: Dict[str, List[ForecastPrediction]]  # cost, value, roi
    insights: Optional[str]
    confidence: float


class Recommendation(TypedDict):
    """AI-generated optimization recommendation"""
    id: str
    type: Literal['model-optimization', 'caching', 'batching', 'use-case-alignment', 'deprecate']
    title: str
    description: str
    estimated_savings: float
    estimated_roi_improvement: float
    implementation_difficulty: int  # 1-5
    confidence_score: float
    reasoning: str
    tradeoffs: List[str]
    implementation_steps: List[str]
    status: Literal['pending', 'in_progress', 'completed', 'rejected']


# Error types
class ClarityError(Exception):
    """Base exception for Clarity SDK"""
    def __init__(
        self,
        message: str,
        code: str,
        status_code: Optional[int] = None,
        details: Optional[Any] = None
    ):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.details = details


class ConfigurationError(ClarityError):
    """Configuration error"""
    def __init__(self, message: str, details: Optional[Any] = None):
        super().__init__(message, 'CONFIGURATION_ERROR', None, details)


class APIError(ClarityError):
    """API error"""
    def __init__(
        self,
        message: str,
        status_code: int,
        details: Optional[Any] = None
    ):
        super().__init__(message, 'API_ERROR', status_code, details)


class ProviderError(ClarityError):
    """Provider error"""
    def __init__(self, message: str, details: Optional[Any] = None):
        super().__init__(message, 'PROVIDER_ERROR', None, details)

