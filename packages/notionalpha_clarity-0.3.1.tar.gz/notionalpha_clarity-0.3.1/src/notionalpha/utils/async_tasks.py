"""
Utilities for running async coroutines from synchronous code.
"""

import asyncio
import threading
from typing import Awaitable


def schedule_background_task(coro: Awaitable[None]) -> None:
    """
    Schedule a coroutine without requiring the caller to manage an event loop.

    - If a loop is running in the current thread, the coroutine is queued on it.
    - Otherwise, the coroutine runs in a dedicated background thread with its own loop.
    """
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(coro)
    except RuntimeError:
        thread = threading.Thread(target=_run_in_thread, args=(coro,), daemon=True)
        thread.start()


def _run_in_thread(coro: Awaitable[None]) -> None:
    """Execute the coroutine inside a brand-new event loop."""
    asyncio.run(coro)
