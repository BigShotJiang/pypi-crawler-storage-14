"""
Azure AI Foundry Provider Wrapper

Wraps Azure OpenAI SDK to route through NotionAlpha proxy
Automatically captures transaction IDs for outcome tracking
Captures signals with enrichment for agent intelligence (T198)

Supports:
- Azure OpenAI models (GPT-4, GPT-4o, etc.)
- Serverless models (Llama, Mistral, Cohere, Phi)
"""

import asyncio
from typing import Any, Dict, Literal, Optional, Tuple
from openai import AzureOpenAI
from openai.types.chat import ChatCompletion
import httpx

from ..types import ProviderError
from ..signal_analyzer import SignalAnalyzer, SignalAnalyzerConfig
from ..utils.async_tasks import schedule_background_task


class AzureAIFoundryProvider:
    """
    Azure AI Foundry provider wrapper

    Routes requests through NotionAlpha proxy for:
    - Automatic cost tracking (FinOps)
    - Security detection (threats, PII, etc.)
    - Transaction ID capture for outcome linking

    Supports both Azure OpenAI models and serverless models (Llama, Mistral, etc.)
    """

    def __init__(
        self,
        provider_id: str,
        deployment_name: str,
        org_id: str,
        team_id: str,
        environment: str,
        feature_id: Optional[str],
        proxy_base_url: str,
        resource_name: Optional[str] = None,
        project_name: Optional[str] = None,
        api_version: Optional[str] = None,
        model_type: Optional[Literal['openai', 'serverless']] = None,
        signal_enrichment: Optional[SignalAnalyzerConfig] = None,
        signal_capture_url: Optional[str] = None,
    ):
        self.provider_id = provider_id
        self.deployment_name = deployment_name
        self.org_id = org_id
        self.team_id = team_id
        self.environment = environment
        self.feature_id = feature_id
        self.proxy_base_url = proxy_base_url
        self.resource_name = resource_name
        self.project_name = project_name
        self.model_type = model_type or 'openai'

        # Initialize signal analyzer if enrichment configured (T198)
        self.signal_analyzer = SignalAnalyzer(signal_enrichment) if signal_enrichment else None

        # Signal capture URL defaults to backend API
        self.signal_capture_url = signal_capture_url or f'{proxy_base_url}/api/v1/signals'

        # Initialize Azure OpenAI client with NotionAlpha proxy
        default_headers = {
            'X-Org-ID': org_id,
            'X-Team-ID': team_id,
            'X-Environment': environment,
            'X-Azure-Deployment': deployment_name,
        }

        # Add resource name if provided (for AI Foundry support)
        if resource_name:
            default_headers['X-Azure-Resource'] = resource_name

        # Add project name if provided (for AI Foundry projects)
        if project_name:
            default_headers['X-Azure-Project'] = project_name

        if feature_id:
            default_headers['X-Feature-ID'] = feature_id

        # Add model type header for serverless routing
        if model_type:
            default_headers['X-Azure-Model-Type'] = model_type

        self.client = AzureOpenAI(
            azure_endpoint=f'{proxy_base_url}/v1/{provider_id}',
            api_key='dummy-key',  # Not used (credentials stored in NotionAlpha)
            api_version=api_version or '2024-12-01-preview',
            default_headers=default_headers,
        )

    async def _capture_signal(
        self,
        transaction_id: str,
        messages: list,
        model: str,
        response: ChatCompletion
    ) -> None:
        """
        Capture signal with enrichment (T198)
        Called after successful LLM completion
        """
        # Only capture if signal analyzer is configured
        if not self.signal_analyzer:
            return

        try:
            # Extract prompt and response content
            prompt = '\n'.join([
                f"{m.get('role', 'unknown')}: {m.get('content', '')}"
                for m in messages
            ])

            response_content = ''
            if response.choices and len(response.choices) > 0:
                choice = response.choices[0]
                if choice.message and choice.message.content:
                    response_content = choice.message.content

            # Analyze signal with enrichment
            analysis = await self.signal_analyzer.analyze({
                'prompt': prompt,
                'response': response_content,
                'model': model,
                'input_tokens': response.usage.prompt_tokens if response.usage else None,
                'output_tokens': response.usage.completion_tokens if response.usage else None,
                'processing_time_ms': None,  # Not available from Azure response
            })

            # POST signal to backend
            signal_payload = {
                'orgId': self.org_id,
                'teamId': self.team_id,
                'transactionId': transaction_id,
                'signalType': 'llm_completion',
                'contextClassification': analysis['context_classification'],
                'intentAnalysis': analysis['intent_analysis'],
                'complexityScore': analysis['complexity_score'],
                'estimatedValueCategory': analysis['estimated_value_category'],
                'queryType': analysis['query_type'],
                'promptLength': len(prompt),
                'responseLength': len(response_content),
                'featureId': self.feature_id,
                'metadata': {
                    'model': model,
                    'provider': 'azure_ai_foundry',
                    'deploymentName': self.deployment_name,
                    'resourceName': self.resource_name,
                    'projectName': self.project_name,
                    'modelType': self.model_type,
                    'environment': self.environment,
                },
            }

            async with httpx.AsyncClient() as client:
                await client.post(
                    self.signal_capture_url,
                    headers={'Content-Type': 'application/json'},
                    json=signal_payload,
                    timeout=10.0
                )

            # Silent failure - don't throw if signal capture fails
        except Exception as e:
            print(f'[Azure AI Foundry Provider] Signal capture failed: {e}')
            # Don't propagate error - signal capture is best-effort

    @property
    def chat(self):
        """Access chat completions interface"""
        return ChatCompletions(self.client, self)


class ChatCompletions:
    """Chat completions interface wrapper"""

    def __init__(self, client: AzureOpenAI, provider: 'AzureAIFoundryProvider'):
        self.client = client
        self.provider = provider

    @property
    def completions(self):
        """Access completions interface"""
        return Completions(self.client, self.provider)


class Completions:
    """Completions interface wrapper"""

    def __init__(self, client: AzureOpenAI, provider: 'AzureAIFoundryProvider'):
        self.client = client
        self.provider = provider

    def create(self, **kwargs: Any) -> Tuple[ChatCompletion, str]:
        """
        Create chat completion

        Args:
            **kwargs: Arguments to pass to Azure OpenAI chat.completions.create()

        Returns:
            Tuple of (response, transaction_id)

        Raises:
            ProviderError: If request fails

        Example:
            >>> response, transaction_id = clarity.chat.completions.create(
            ...     model='gpt-4o-mini',  # Azure deployment name or serverless model ID
            ...     messages=[{'role': 'user', 'content': 'Hello!'}]
            ... )
            >>>
            >>> # Use transactionId for outcome tracking
            >>> clarity.track_outcome(
            ...     transaction_id=transaction_id,
            ...     type='customer_support',
            ...     metadata={'time_saved_minutes': 15}
            ... )
        """
        try:
            # Make request through proxy and get raw response with headers
            raw_response = self.client.chat.completions.with_raw_response.create(**kwargs)

            # Extract transaction ID from NotionAlpha proxy response header
            transaction_id = (
                raw_response.headers.get('X-NotionAlpha-Transaction-Id') or
                raw_response.headers.get('x-notionalpha-transaction-id') or  # lowercase fallback
                'unknown'
            )

            # Parse the actual response object
            response = raw_response.parse()

            # Capture signal asynchronously (fire and forget)
            if self.provider.signal_analyzer:
                messages = kwargs.get('messages', [])
                model = kwargs.get('model', 'unknown')
                schedule_background_task(
                    self.provider._capture_signal(transaction_id, messages, model, response)
                )

            return response, transaction_id

        except Exception as e:
            raise ProviderError(f'Azure AI Foundry request failed: {str(e)}', details=str(e))
