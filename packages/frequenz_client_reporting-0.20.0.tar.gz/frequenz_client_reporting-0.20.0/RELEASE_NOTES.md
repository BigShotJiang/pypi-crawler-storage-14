# Frequenz Reporting API Client Release Notes

## Summary

> **Warning:** This client is compatible *only* with Reporting API `v1alpha10` or later.
> Using with services that use an older API version **will cause failures**.

## Upgrading

* Breaking change to reporting API v1alpha10.
* Switch to new `metrics` package from client-common.

## New Features

<!-- Here goes the main new features and examples or instructions on how to use them -->

## Bug Fixes

<!-- Here goes notable bug fixes that are worth a special mention or explanation -->
