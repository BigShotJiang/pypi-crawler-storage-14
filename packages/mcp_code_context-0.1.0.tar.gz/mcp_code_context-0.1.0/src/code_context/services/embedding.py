"""Embedding service for generating vector embeddings."""

from typing import List, Optional
import logging

logger = logging.getLogger(__name__)


class EmbeddingService:
    """Service for generating embeddings from text using various providers."""

    def __init__(
        self,
        provider: str = "openai",
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        vector_size: int = 1536,
    ):
        """Initialize embedding service.

        Args:
            provider: Embedding provider (openai, google)
            model: Model name (defaults based on provider)
            api_key: API key for the provider
            vector_size: Expected vector dimension
        """
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self.vector_size = vector_size
        self.client = None

        self._init_client()

    def _init_client(self):
        """Initialize embedding client with error handling."""
        try:
            if self.provider == "openai":
                from openai import OpenAI

                self.client = OpenAI(api_key=self.api_key)
                self.model = self.model or "text-embedding-3-small"
                logger.info(
                    f"Initialized OpenAI embedding client with model: {self.model}"
                )

            elif self.provider == "google":
                import google.generativeai as genai

                genai.configure(api_key=self.api_key)
                self.client = genai
                self.model = self.model or "models/embedding-001"
                logger.info(
                    f"Initialized Google embedding client with model: {self.model}"
                )

            else:
                # Fallback to OpenAI
                logger.warning(
                    f"Unknown embedding provider '{self.provider}', falling back to OpenAI"
                )
                from openai import OpenAI

                self.client = OpenAI(api_key=self.api_key)
                self.model = "text-embedding-3-small"
                logger.info(
                    f"Initialized OpenAI embedding client (fallback) with model: {self.model}"
                )

        except ImportError as e:
            error_msg = f"Failed to import embedding client library for '{self.provider}': {e}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

        except Exception as e:
            error_msg = (
                f"Failed to initialize embedding client for '{self.provider}'. "
                f"Please check your API key and configuration. Error: {e}"
            )
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

    def generate_embedding(self, text: str) -> List[float]:
        """Generate embedding vector for text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector with dimension matching self.vector_size
        """
        try:
            vector = None

            if self.provider == "openai":
                response = self.client.embeddings.create(
                    model=self.model, input=text
                )
                vector = response.data[0].embedding

            elif self.provider == "google":
                result = self.client.embed_content(
                    model=self.model, content=text, task_type="retrieval_query"
                )
                vector = result["embedding"]

            else:
                # Fallback: return zero vector with correct dimension
                logger.warning(
                    f"Using zero vector ({self.vector_size}D) as embedding fallback"
                )
                return [0.0] * self.vector_size

            # Validate vector dimension
            if vector is not None:
                actual_dim = len(vector)
                if actual_dim != self.vector_size:
                    logger.warning(
                        f"Vector dimension mismatch: got {actual_dim}D, expected {self.vector_size}D. "
                        f"Adjusting vector to match configured size."
                    )
                    # Pad or truncate to match expected dimension
                    if actual_dim < self.vector_size:
                        # Pad with zeros
                        vector = vector + [0.0] * (self.vector_size - actual_dim)
                    else:
                        # Truncate
                        vector = vector[: self.vector_size]

                return vector

        except Exception as e:
            logger.error(f"Failed to generate embedding: {e}")
            # Return zero vector as fallback
            return [0.0] * self.vector_size

    def batch_generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        # Simple implementation: generate one by one
        # Can be optimized for batch processing in the future
        return [self.generate_embedding(text) for text in texts]


def get_embedding_service() -> Optional[EmbeddingService]:
    """Get or create embedding service from config.

    Returns:
        EmbeddingService instance if config is available, None otherwise
    """
    try:
        from ..config import ConfigManager

        config_manager = ConfigManager()

        if not config_manager.config_exists():
            logger.warning("Config not found, cannot initialize embedding service")
            return None

        config = config_manager.load_config()
        logger.info(f"Loaded config: {config}")

        # Support both nested and flat config formats
        # Nested format: {"embedding": {"provider": "openai", ...}}
        # Flat format: {"embedding_provider": "openai", ...}
        embedding_config = config.get("embedding", {})
        logger.info(f"Embedding config (nested): {embedding_config}")

        if embedding_config:
            # Use nested config format
            provider = embedding_config.get("provider", "openai")
            model = embedding_config.get("model")
            api_key = embedding_config.get("api_key")
            logger.info(f"Using nested config format - provider: {provider}, model: {model}, api_key: {'***' if api_key else None}")
        else:
            # Try flat config format as fallback
            provider = config.get("embedding_provider", "openai")
            model = config.get("embedding_model")
            api_key = config.get("embedding_api_key")
            logger.info(f"Using flat config format - provider: {provider}, model: {model}, api_key: {'***' if api_key else None}")

        if not api_key or not model:
            logger.warning(f"Embedding config incomplete (missing api_key or model) - api_key: {bool(api_key)}, model: {model}")
            return None

        # Determine vector size based on model
        vector_size = 1536  # Default for text-embedding-3-small
        if model == "text-embedding-3-large":
            vector_size = 3072
        elif model == "models/embedding-001":  # Google
            vector_size = 768

        return EmbeddingService(
            provider=provider, model=model, api_key=api_key, vector_size=vector_size
        )

    except Exception as e:
        logger.error(f"Failed to create embedding service: {e}")
        return None
