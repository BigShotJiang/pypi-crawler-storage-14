"""Server manager for MCP server lifecycle management."""

import threading
import logging
import time
from typing import Optional, Callable
from datetime import datetime

logger = logging.getLogger(__name__)


class ServerManager:
    """Manages FastMCP server lifecycle and graceful shutdown."""

    def __init__(self, mcp_app):
        """Initialize server manager.

        Args:
            mcp_app: FastMCP application instance
        """
        self.mcp_app = mcp_app
        self.server_thread: Optional[threading.Thread] = None
        self.is_running = False
        self.start_time: Optional[datetime] = None
        self.shutdown_requested = False
        self.log_callback: Optional[Callable[[str], None]] = None

    def set_log_callback(self, callback: Callable[[str], None]):
        """Set callback for logging messages to UI.

        Args:
            callback: Function that takes a string message
        """
        self.log_callback = callback

    def _log(self, message: str):
        """Log message to both logger and UI callback."""
        logger.info(message)
        if self.log_callback:
            self.log_callback(message)

    def start_server(self):
        """Start MCP server in background thread."""
        if self.is_running:
            self._log("⚠️  Server already running")
            return

        def run_mcp():
            import sys
            import io

            try:
                self._log("🚀 Starting FastMCP server...")
                self.is_running = True
                self.start_time = datetime.now()

                # Save original stdout/stderr
                original_stdout = sys.stdout
                original_stderr = sys.stderr

                # Create real streams with buffer attribute for FastMCP
                # Use unbuffered binary streams
                sys.stdout = sys.__stdout__
                sys.stderr = sys.__stderr__

                # Run FastMCP server (blocking)
                self.mcp_app.run()

            except Exception as e:
                # Restore streams before logging
                sys.stdout = original_stdout
                sys.stderr = original_stderr
                self._log(f"❌ Server error: {e}")
                logger.error(f"Server error: {e}", exc_info=True)
            finally:
                # Restore original streams
                try:
                    sys.stdout = original_stdout
                    sys.stderr = original_stderr
                except:
                    pass
                self.is_running = False
                self._log("Server stopped")

        self.server_thread = threading.Thread(target=run_mcp, daemon=False)
        self.server_thread.start()

        # Wait a bit for server to start
        time.sleep(0.5)
        self._log("✅ MCP server started successfully")

    def get_uptime(self) -> str:
        """Get server uptime as formatted string.

        Returns:
            Uptime string like "00:05:23"
        """
        if not self.start_time:
            return "00:00:00"

        delta = datetime.now() - self.start_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def get_status(self) -> dict:
        """Get current server status.

        Returns:
            Dictionary with status information
        """
        return {
            "is_running": self.is_running,
            "uptime": self.get_uptime(),
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "shutdown_requested": self.shutdown_requested,
        }

    async def graceful_shutdown(self, progress_callback: Optional[Callable[[str], None]] = None):
        """Perform graceful server shutdown.

        Args:
            progress_callback: Optional callback for progress updates
        """
        if self.shutdown_requested:
            self._log("⚠️  Shutdown already in progress")
            return

        self.shutdown_requested = True

        def update_progress(step: int, total: int, message: str):
            """Update progress."""
            full_msg = f"🔄 Step {step}/{total}: {message}"
            self._log(full_msg)
            if progress_callback:
                progress_callback(full_msg)

        try:
            # Step 1: Stop accepting new requests (FastMCP handles this automatically)
            update_progress(1, 4, "Stopping MCP request handler")
            # FastMCP will stop accepting new requests when we exit the app

            # Step 2: Wait for pending requests (if any)
            update_progress(2, 4, "Waiting for pending requests")
            # Small delay to let any in-flight requests complete
            time.sleep(0.5)

            # Step 3: Sync Qdrant memory to disk
            update_progress(3, 4, "Syncing Qdrant memory to disk")
            try:
                from ..tools import close_db_manager
                close_db_manager()
            except Exception as e:
                self._log(f"⚠️  Error during database sync: {e}")
                logger.error(f"Database sync error: {e}", exc_info=True)

            # Step 4: Final cleanup
            update_progress(4, 4, "Closing connections")
            time.sleep(0.2)

            self._log("✅ Shutdown complete - Safe to exit")

        except Exception as e:
            self._log(f"❌ Error during shutdown: {e}")
            logger.error(f"Shutdown error: {e}", exc_info=True)
        finally:
            self.is_running = False
            self.shutdown_requested = False
