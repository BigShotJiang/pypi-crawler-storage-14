"""Interactive configuration wizard for code-context."""

from typing import Dict, Any
from rich.console import Console
from rich.panel import Panel

console = Console()


def run_config_wizard() -> Dict[str, Any]:
    """Run interactive configuration wizard

    Returns:
        Configuration dictionary with provider, model, api_key, etc.
    """
    try:
        import questionary
    except ImportError:
        console.print(
            "[red]Error: questionary not installed.[/red]\n"
            "Please install with: pip install questionary"
        )
        raise

    # Welcome message
    console.print(Panel.fit(
        "[bold cyan]🚀 Welcome to code-context![/bold cyan]\n\n"
        "Let's set up your configuration for AI-powered endpoint tracking.",
        title="Setup Wizard",
        border_style="cyan"
    ))

    # Step 1: Select LLM Provider
    console.print("\n[bold]Step 1: Select LLM Provider[/bold]")
    provider = questionary.select(
        "Choose your LLM provider:",
        choices=[
            questionary.Choice("OpenAI (GPT-5, GPT-5.1, GPT-4o)", value="openai"),
            questionary.Choice("Google Gemini (Gemini 2.5 series)", value="gemini"),
            questionary.Choice("DeepSeek (Chat, Reasoner)", value="deepseek"),
            questionary.Choice("Anthropic Claude (Sonnet 4.5, Opus 4.1)", value="claude"),
            questionary.Choice("Alibaba Qwen (Qwen3-Max, Qwen-Plus, Qwen-Flash)", value="qwen"),
        ],
        use_arrow_keys=True,
        use_shortcuts=True
    ).ask()

    # Step 2: Select Model
    console.print(f"\n[bold]Step 2: Select {provider.title()} Model[/bold]")
    model_choices = get_model_choices(provider)
    model = questionary.select(
        f"Choose your {provider.title()} model:",
        choices=model_choices,
        use_arrow_keys=True
    ).ask()

    # Step 3: Enter API Key
    console.print(f"\n[bold]Step 3: Enter API Key[/bold]")
    api_key = questionary.password(
        f"Enter your {provider.title()} API key:",
        validate=lambda x: len(x) > 10 or "API key seems too short (must be > 10 chars)"
    ).ask()

    # Optional: Advanced settings
    console.print("\n[dim]Using default embedding settings (OpenAI text-embedding-3-large, 1024 dimensions)[/dim]")

    config_data = {
        "llm_provider": provider,
        "llm_model": model,
        "llm_api_key": api_key,
        "embedding_provider": "openai",
        "embedding_model": "text-embedding-3-large",
        "embedding_dimensions": 1024,
    }

    console.print("\n[green]✅ Configuration complete![/green]")

    return config_data


def get_model_choices(provider: str):
    """Get model choices for a provider

    Args:
        provider: Provider name

    Returns:
        List of questionary.Choice objects
    """
    try:
        import questionary
    except ImportError:
        return []

    models = {
        "openai": [
            questionary.Choice(
                "gpt-5 (Flagship unified model with reasoning)",
                value="gpt-5"
            ),
            questionary.Choice(
                "gpt-5-mini (Recommended: Best balance)",
                value="gpt-5-mini"
            ),
            questionary.Choice(
                "gpt-5.1 (Latest with adaptive reasoning)",
                value="gpt-5.1"
            ),
            questionary.Choice(
                "gpt-5-nano (Fastest and most cost-effective)",
                value="gpt-5-nano"
            ),
            questionary.Choice(
                "gpt-4o (Legacy flagship)",
                value="gpt-4o"
            ),
            questionary.Choice(
                "gpt-4o-mini (Legacy, fast and cheap)",
                value="gpt-4o-mini"
            ),
        ],
        "gemini": [
            questionary.Choice(
                "gemini-2.5-flash (Recommended: Fast and stable)",
                value="gemini-2.5-flash"
            ),
            questionary.Choice(
                "gemini-2.5-pro (Most powerful with adaptive thinking)",
                value="gemini-2.5-pro"
            ),
            questionary.Choice(
                "gemini-2.5-flash-lite (Fastest and most cost-effective)",
                value="gemini-2.5-flash-lite"
            ),
            questionary.Choice(
                "gemini-2.0-flash-exp (Experimental preview)",
                value="gemini-2.0-flash-exp"
            ),
        ],
        "deepseek": [
            questionary.Choice(
                "deepseek-chat (Recommended: General conversation, upgraded to V3.1)",
                value="deepseek-chat"
            ),
            questionary.Choice(
                "deepseek-reasoner (Advanced reasoning and coding, R1 model)",
                value="deepseek-reasoner"
            ),
        ],
        "claude": [
            questionary.Choice(
                "claude-sonnet-4-5-20250929 (Recommended: Best coding model)",
                value="claude-sonnet-4-5-20250929"
            ),
            questionary.Choice(
                "claude-opus-4-1-20250805 (Most powerful reasoning)",
                value="claude-opus-4-1-20250805"
            ),
            questionary.Choice(
                "claude-haiku-4-5-20251015 (Fast and cost-effective)",
                value="claude-haiku-4-5-20251015"
            ),
        ],
        "qwen": [
            questionary.Choice(
                "qwen-plus (Recommended: Best balance)",
                value="qwen-plus"
            ),
            questionary.Choice(
                "qwen3-max (Most powerful, for complex tasks)",
                value="qwen3-max"
            ),
            questionary.Choice(
                "qwen-flash (Fastest and most cost-effective)",
                value="qwen-flash"
            ),
            questionary.Choice(
                "qwen-turbo (Older but stable version)",
                value="qwen-turbo"
            ),
        ]
    }

    return models.get(provider, [])
