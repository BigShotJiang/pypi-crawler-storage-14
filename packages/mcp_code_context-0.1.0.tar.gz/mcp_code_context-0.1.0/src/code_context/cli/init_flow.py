"""Initialization flow for code-context."""

from typing import Dict
from rich.console import Console

console = Console()


def confirm_initialization(estimate: Dict) -> bool:
    """Display summary and ask user to confirm initialization

    Args:
        estimate: Token estimation dictionary from TokenEstimator

    Returns:
        True if user confirms, False otherwise
    """
    try:
        import questionary
    except ImportError:
        console.print("[yellow]questionary not installed, defaulting to yes[/yellow]")
        return True

    from ..scanner.token_estimator import TokenEstimator

    console.print("\n" + "=" * 60)
    console.print("[bold cyan]📋 Initialization Summary[/bold cyan]")
    console.print("=" * 60 + "\n")

    # Display token estimate
    estimator = TokenEstimator()
    estimator.display_estimate(estimate, show_details=False)

    console.print("\n[cyan]ℹ️  What will happen:[/cyan]")
    console.print("  • File contents will be sent to your LLM API")
    console.print("  • Endpoint information will be extracted")
    console.print("  • Embeddings will be generated for semantic search")
    console.print("  • Results will be stored in local Qdrant database")

    console.print("\n[dim]Note: Check your LLM provider's pricing for token costs[/dim]")

    # Ask for confirmation
    return questionary.confirm(
        "\nProceed with initialization?",
        default=True
    ).ask()
