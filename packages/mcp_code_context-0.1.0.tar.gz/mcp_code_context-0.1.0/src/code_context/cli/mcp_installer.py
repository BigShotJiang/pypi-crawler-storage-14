"""MCP client installation wizard for code-context."""

import json
import subprocess
import sys
from pathlib import Path
from typing import Dict, Optional
from rich.console import Console
from rich.panel import Panel

console = Console()


class MCPInstaller:
    """Handles MCP client installation across different platforms."""

    PLATFORMS = {
        "claude_code": {
            "name": "Claude Code",
            "type": "cli",
            "description": "Anthropic's Claude Code (Recommended, SSE transport)",
        },
        "cursor": {
            "name": "Cursor",
            "type": "config_file",
            "description": "Cursor IDE",
            "config_path": "~/.cursor/mcp.json",
        },
        "antigravity": {
            "name": "Google Antigravity",
            "type": "config_file",
            "description": "Google's Antigravity IDE",
            "config_path": "~/.gemini/antigravity/mcp_config.json",
        },
        "windsurf": {
            "name": "Windsurf",
            "type": "config_file",
            "description": "Codeium Windsurf IDE",
            "config_path": "~/.codeium/windsurf/mcp_config.json",
        },
        "cline": {
            "name": "Cline (VS Code)",
            "type": "manual",
            "description": "Cline VS Code Extension (Manual setup required)",
        },
        "warp": {
            "name": "Warp Terminal",
            "type": "manual",
            "description": "Warp Terminal (Manual UI setup)",
        },
        "copilot_cli": {
            "name": "GitHub Copilot CLI",
            "type": "manual",
            "description": "GitHub Copilot CLI (Interactive setup)",
        },
        "vscode": {
            "name": "VS Code Copilot",
            "type": "manual",
            "description": "Visual Studio Code with GitHub Copilot",
        },
        "amp": {
            "name": "Amp",
            "type": "cli",
            "description": "Amp Editor",
        },
        "gemini_cli": {
            "name": "Gemini CLI",
            "type": "cli",
            "description": "Google Gemini CLI",
        },
        "codex": {
            "name": "Codex",
            "type": "cli",
            "description": "Codex IDE",
        },
        "factory_cli": {
            "name": "Factory CLI",
            "type": "cli",
            "description": "Factory CLI (droid)",
        },
    }

    def install(self, platform_key: str) -> bool:
        """Install for selected platform.

        Args:
            platform_key: Platform identifier

        Returns:
            True if installation succeeded
        """
        platform = self.PLATFORMS[platform_key]

        console.print(f"\n[bold cyan]Installing for {platform['name']}...[/bold cyan]\n")

        if platform["type"] == "cli":
            return self._install_cli(platform_key)
        elif platform["type"] == "config_file":
            return self._install_config_file(platform_key)
        elif platform["type"] == "manual":
            return self._show_manual_instructions(platform_key)

        return False

    def _install_cli(self, platform_key: str) -> bool:
        """Install using CLI command.

        Args:
            platform_key: Platform identifier

        Returns:
            True if installation succeeded
        """
        commands = {
            "claude_code": [
                "claude", "mcp", "add",
                "--transport", "sse",
                "code-context",
                "--scope", "user",
                "http://localhost:18765/sse"
            ],
            "amp": [
                "amp", "mcp", "add", "code-context",
                "--", "code-context", "server"
            ],
            "gemini_cli": [
                "gemini", "mcp", "add",
                "-s", "user",
                "code-context",
                "code-context", "server"
            ],
            "codex": [
                "codex", "mcp", "add", "code-context",
                "--", "code-context", "server"
            ],
            "factory_cli": [
                "droid", "mcp", "add", "code-context",
                "code-context server"
            ],
        }

        cmd = commands.get(platform_key)
        if not cmd:
            console.print("[yellow]⚠ No CLI command available for this platform[/yellow]")
            return False

        try:
            console.print(f"[dim]Executing: {' '.join(cmd)}[/dim]\n")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            if result.returncode == 0:
                console.print("[green]✓ Successfully installed![/green]")
                if result.stdout:
                    console.print(f"\n[dim]{result.stdout}[/dim]")
                return True
            else:
                console.print(f"[red]✗ Installation failed[/red]")
                if result.stderr:
                    console.print(f"[red]{result.stderr}[/red]")
                return False

        except FileNotFoundError:
            platform_name = self.PLATFORMS[platform_key]["name"]
            console.print(f"[red]✗ {platform_name} CLI not found in PATH[/red]")
            console.print(f"[yellow]Please install {platform_name} first, then try again[/yellow]")
            return False
        except subprocess.TimeoutExpired:
            console.print("[red]✗ Command timed out[/red]")
            return False
        except Exception as e:
            console.print(f"[red]✗ Unexpected error: {e}[/red]")
            return False

    def _install_config_file(self, platform_key: str) -> bool:
        """Install by modifying config file.

        Args:
            platform_key: Platform identifier

        Returns:
            True if installation succeeded
        """
        platform = self.PLATFORMS[platform_key]
        config_path = Path(platform["config_path"]).expanduser()

        # Configuration templates for each platform
        config_templates = {
            "cursor": {
                "code-context": {
                    "command": "code-context",
                    "args": ["server"],
                    "transport": "stdio"
                }
            },
            "antigravity": {
                "code-context": {
                    "command": "code-context",
                    "args": ["server"]
                }
            },
            "windsurf": {
                "code-context": {
                    "command": "code-context",
                    "args": ["server"]
                }
            },
        }

        template = config_templates.get(platform_key)
        if not template:
            console.print("[red]✗ No configuration template available[/red]")
            return False

        try:
            # Ensure parent directory exists
            config_path.parent.mkdir(parents=True, exist_ok=True)

            # Read existing configuration
            if config_path.exists():
                console.print(f"[cyan]Reading existing config: {config_path}[/cyan]")
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
            else:
                console.print(f"[cyan]Creating new config file: {config_path}[/cyan]")
                config = {"mcpServers": {}}

            # Ensure mcpServers key exists
            if "mcpServers" not in config:
                config["mcpServers"] = {}

            # Check if code-context already exists
            if "code-context" in config["mcpServers"]:
                console.print("[yellow]⚠ code-context already configured, updating...[/yellow]")

            # Add/update code-context configuration
            config["mcpServers"]["code-context"] = template["code-context"]

            # Write back configuration
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2)
                f.write('\n')  # Add trailing newline

            console.print(f"\n[green]✓ Configuration updated: {config_path}[/green]")
            console.print(f"[yellow]⚠  Please restart {platform['name']} to apply changes[/yellow]")
            return True

        except json.JSONDecodeError as e:
            console.print(f"[red]✗ Invalid JSON in config file: {e}[/red]")
            console.print(f"[yellow]Please fix the JSON syntax in {config_path}[/yellow]")
            return False
        except PermissionError:
            console.print(f"[red]✗ Permission denied: Cannot write to {config_path}[/red]")
            return False
        except Exception as e:
            console.print(f"[red]✗ Failed to update config: {e}[/red]")
            return False

    def _show_manual_instructions(self, platform_key: str) -> bool:
        """Show manual installation instructions.

        Args:
            platform_key: Platform identifier

        Returns:
            Always returns True (instructions displayed)
        """
        instructions = {
            "warp": """
[cyan]Manual Installation for Warp Terminal:[/cyan]

1. Open Warp Terminal
2. Go to Settings → AI → Manage MCP Servers
3. Click [bold]+ Add[/bold]
4. Choose [bold]"SSE Server (URL)"[/bold]
5. Fill in:
   • [bold]Name:[/bold] code-context
   • [bold]URL:[/bold] http://localhost:18765/sse
6. Click [bold]Save[/bold]

The server will start automatically when Warp needs it.

[dim]Note: Make sure to run 'code-context server' in a separate terminal first.[/dim]
""",
            "cline": """
[cyan]Manual Installation for Cline (VS Code):[/cyan]

1. Open VS Code with Cline extension installed
2. Open Cline settings: [bold]Cline → MCP Servers → Configure[/bold]
3. This will open [bold]cline_mcp_settings.json[/bold]
4. Add the following configuration:

[yellow]{
  "mcpServers": {
    "code-context": {
      "command": "code-context",
      "args": ["server"]
    }
  }
}[/yellow]

5. Save the file and restart VS Code

Alternatively, use the Cline UI to add a new MCP server with:
   • Command: code-context
   • Args: server
""",
            "copilot_cli": """
[cyan]Manual Installation for GitHub Copilot CLI:[/cyan]

1. Make sure Copilot CLI is installed: [bold]npm install -g @githubnext/copilot-cli[/bold]
2. Enter interactive mode: [bold]copilot[/bold]
3. Use the MCP management command: [bold]/mcp add[/bold]
4. Follow the interactive prompts to add:
   • Name: code-context
   • Command: code-context
   • Args: server

Alternatively, edit [bold]~/.copilot/mcp-config.json[/bold]:

[yellow]{
  "mcpServers": {
    "code-context": {
      "command": "code-context",
      "args": ["server"]
    }
  }
}[/yellow]
""",
            "vscode": """
[cyan]Manual Installation for VS Code with GitHub Copilot:[/cyan]

1. Open VS Code Settings (Cmd/Ctrl + ,)
2. Search for [bold]"MCP"[/bold] or [bold]"Model Context Protocol"[/bold]
3. Go to [bold]Copilot → Customization → MCP Servers[/bold]
4. Click [bold]Add MCP Server[/bold]
5. Configure:
   • Name: code-context
   • Command: code-context
   • Args: ["server"]
6. Save and reload VS Code

Or use the command palette:
   • Press Cmd/Ctrl + Shift + P
   • Search for [bold]"MCP: Add Server"[/bold]
""",
        }

        instruction_text = instructions.get(platform_key, "[yellow]No manual instructions available yet[/yellow]")

        console.print(Panel(
            instruction_text,
            title=f"[bold]{self.PLATFORMS[platform_key]['name']} Setup[/bold]",
            border_style="cyan"
        ))

        return True


def run_mcp_installer():
    """Run the MCP installation wizard."""
    try:
        import questionary
    except ImportError:
        console.print("[red]Error: questionary not installed.[/red]")
        console.print("Please install with: [bold]pip install questionary[/bold]")
        sys.exit(1)

    console.print(Panel.fit(
        "[bold cyan]🔌 MCP Client Installation Wizard[/bold cyan]\n\n"
        "Install code-context MCP server integration for your AI coding assistant.\n"
        "This will configure your chosen platform to use code-context tools.",
        title="MCP Installer",
        border_style="cyan"
    ))

    installer = MCPInstaller()

    # Build choice list grouped by type
    cli_platforms = []
    config_platforms = []
    manual_platforms = []

    for key, platform in installer.PLATFORMS.items():
        choice = questionary.Choice(
            f"{platform['name']} - {platform['description']}",
            value=key
        )
        if platform["type"] == "cli":
            cli_platforms.append(choice)
        elif platform["type"] == "config_file":
            config_platforms.append(choice)
        else:
            manual_platforms.append(choice)

    # Combine with separators
    all_choices = []
    if cli_platforms:
        all_choices.append(questionary.Separator("=== Automatic CLI Installation ==="))
        all_choices.extend(cli_platforms)
    if config_platforms:
        all_choices.append(questionary.Separator("=== Automatic Config File ==="))
        all_choices.extend(config_platforms)
    if manual_platforms:
        all_choices.append(questionary.Separator("=== Manual Setup (Instructions) ==="))
        all_choices.extend(manual_platforms)

    # Let user select platform
    console.print()
    platform_key = questionary.select(
        "Select your MCP client platform:",
        choices=all_choices,
        use_arrow_keys=True,
        use_shortcuts=True
    ).ask()

    if not platform_key:
        console.print("\n[yellow]Installation cancelled[/yellow]")
        return

    # Execute installation
    success = installer.install(platform_key)

    if success:
        console.print("\n[green bold]✓ Installation Complete![/green bold]\n")
        console.print("[cyan]Next steps:[/cyan]")
        console.print("1. Start the MCP server: [bold]code-context server[/bold]")
        console.print("2. Open your AI assistant and start using code-context tools!")
        console.print("\n[dim]Example: Ask your AI to 'scan /path/to/my/project for API endpoints'[/dim]")
    else:
        console.print("\n[yellow]Installation encountered issues. Please check the messages above.[/yellow]")
        console.print("\n[cyan]For manual setup instructions, see:[/cyan]")
        console.print("[bold]https://github.com/jieyefriic/code-context#mcp-client-installation[/bold]")
