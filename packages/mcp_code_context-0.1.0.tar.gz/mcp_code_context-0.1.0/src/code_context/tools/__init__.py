"""MCP tools for code-context."""

from typing import List, Dict, Any, Optional, Union
from pathlib import Path
import threading
import logging

from ..database import QdrantManager, Endpoint
from ..scanner.python import get_scanner
from ..config import get_config

logger = logging.getLogger(__name__)

# Global database manager
_db_manager: QdrantManager = None


def get_db_manager() -> QdrantManager:
    """Get or create global database manager.

    Uses :memory: mode for MCP server for better performance.
    """
    global _db_manager
    if _db_manager is None:
        _db_manager = QdrantManager(use_memory=True)
        logger.info("Initialized QdrantManager with :memory: mode for MCP server")
    return _db_manager


def close_db_manager() -> None:
    """Close and cleanup global database manager.

    This performs final sync to disk and closes all Qdrant connections.
    Should be called during graceful shutdown.
    """
    global _db_manager
    if _db_manager is not None:
        logger.info("Closing QdrantManager...")

        # Final sync if using memory mode
        if _db_manager.use_memory:
            logger.info("Performing final memory->disk sync...")
            # Already synced via write-through, but close connections

        # Close connections
        _db_manager.close()
        _db_manager = None
        logger.info("QdrantManager closed successfully")


def search_endpoint(name: str = None, route: str = None) -> List[Dict[str, Any]]:
    """Search for endpoints by name or route.

    Args:
        name: Endpoint name to search for
        route: Route to search for

    Returns:
        List of matching endpoints as dictionaries
    """
    db = get_db_manager()

    if name:
        endpoints = db.search_by_name(name)
    elif route:
        endpoints = db.search_by_route(route)
    else:
        endpoints = db.list_all_endpoints(limit=100)

    return [
        {
            "id": e.id,
            "name": e.name,
            "route": e.route,
            "method": e.method,
            "file_path": e.file_path,
            "description": e.description,
            "framework": e.framework,
            "language": e.language,
        }
        for e in endpoints
    ]


def add_endpoint(
    name: str,
    route: str,
    method: str,
    file_path: str,
    description: str = None,
    headers: Dict[str, Any] = None,
    parameters: Dict[str, Any] = None,
    request_body: Dict[str, Any] = None,
    response_code: int = None,
    response_type: str = None,
    response_format: Dict[str, Any] = None,
    framework: str = None,
    language: str = None,
) -> Dict[str, str]:
    """Add a new endpoint manually.

    Args:
        name: Name of the endpoint
        route: API route/path
        method: HTTP method
        file_path: Path to the source file
        description: Optional description
        headers: Optional headers specification
        parameters: Optional parameters specification
        request_body: Optional request body specification
        response_code: Optional response code
        response_type: Optional response content type
        response_format: Optional response format
        framework: Optional framework name
        language: Optional programming language

    Returns:
        Dictionary with the created endpoint ID
    """
    import uuid

    endpoint = Endpoint(
        id=str(uuid.uuid4()),
        name=name,
        route=route,
        method=method.upper(),
        file_path=file_path,
        description=description,
        headers=headers,
        parameters=parameters,
        request_body=request_body,
        response_code=response_code,
        response_type=response_type,
        response_format=response_format,
        framework=framework,
        language=language,
    )

    db = get_db_manager()
    endpoint_id = db.add_endpoint(endpoint)

    return {"id": endpoint_id, "message": f"Endpoint '{name}' added successfully"}


def scan_codebase(directory: str, language: str = "python") -> Dict[str, Any]:
    """Scan a codebase directory for API endpoints.

    Args:
        directory: Path to the directory to scan
        language: Programming language (default: python)

    Returns:
        Dictionary with scan results
    """
    scanner = get_scanner(language)
    if not scanner:
        return {
            "error": f"No scanner available for language: {language}",
            "endpoints_found": 0,
        }

    path = Path(directory)
    if not path.exists():
        return {"error": f"Directory not found: {directory}", "endpoints_found": 0}

    if not path.is_dir():
        return {"error": f"Path is not a directory: {directory}", "endpoints_found": 0}

    # Scan directory
    endpoints = scanner.scan_directory(path)

    # Add all found endpoints to database
    db = get_db_manager()
    added_count = 0

    for endpoint in endpoints:
        try:
            db.add_endpoint(endpoint)
            added_count += 1
        except Exception as e:
            print(f"Error adding endpoint {endpoint.name}: {e}")

    return {
        "message": f"Scan completed for {directory}",
        "endpoints_found": len(endpoints),
        "endpoints_added": added_count,
        "language": language,
    }


def update_endpoint(endpoint_id: str, **updates) -> Dict[str, str]:
    """Update an existing endpoint.

    Args:
        endpoint_id: ID of the endpoint to update
        **updates: Fields to update

    Returns:
        Dictionary with update status
    """
    db = get_db_manager()
    success = db.update_endpoint(endpoint_id, updates)

    if success:
        return {"message": f"Endpoint {endpoint_id} updated successfully"}
    else:
        return {"error": f"Endpoint {endpoint_id} not found"}


def delete_endpoint(endpoint_id: str) -> Dict[str, str]:
    """Delete an endpoint.

    Args:
        endpoint_id: ID of the endpoint to delete

    Returns:
        Dictionary with deletion status
    """
    db = get_db_manager()
    db.delete_endpoint(endpoint_id)

    return {"message": f"Endpoint {endpoint_id} deleted successfully"}


def list_endpoints(limit: int = 100) -> List[Dict[str, Any]]:
    """List all endpoints.

    Args:
        limit: Maximum number of endpoints to return

    Returns:
        List of all endpoints
    """
    db = get_db_manager()
    endpoints = db.list_all_endpoints(limit=limit)

    return [
        {
            "id": e.id,
            "name": e.name,
            "route": e.route,
            "method": e.method,
            "file_path": e.file_path,
            "description": e.description,
            "framework": e.framework,
            "language": e.language,
        }
        for e in endpoints
    ]


# ==================== Phase 1: Search Enhancement Tools ====================


def semantic_search_endpoints(query: str, limit: int = 10) -> Union[List[Dict[str, Any]], Dict[str, str]]:
    """Perform semantic search on endpoints using natural language queries.

    Args:
        query: Natural language query (e.g., "user authentication endpoints")
        limit: Maximum number of results to return

    Returns:
        List of matching endpoints with similarity scores, or error dict if service not configured
    """
    from ..services import EmbeddingService, get_embedding_service

    # Get embedding service
    embedding_service = get_embedding_service()
    if not embedding_service:
        logger.error("Embedding service not configured")
        return {"error": "Embedding service not configured. Please check your configuration and try again."}

    # Generate query embedding
    try:
        query_vector = embedding_service.generate_embedding(query)
    except Exception as e:
        logger.error(f"Failed to generate query embedding: {e}")
        return {"error": f"Failed to generate embedding: {str(e)}"}

    # Search using vector similarity
    db = get_db_manager()
    endpoints = db.semantic_search(query_vector=query_vector, limit=limit)

    return [
        {
            "id": e.id,
            "name": e.name,
            "route": e.route,
            "method": e.method,
            "file_path": e.file_path,
            "description": e.description,
            "framework": e.framework,
            "language": e.language,
        }
        for e in endpoints
    ]


def filter_endpoints(
    method: Optional[str] = None,
    framework: Optional[str] = None,
    language: Optional[str] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Filter endpoints by multiple conditions.

    Args:
        method: HTTP method to filter by (e.g., GET, POST)
        framework: Framework to filter by (e.g., FastAPI, Flask)
        language: Programming language to filter by (e.g., Python, Go)
        limit: Maximum number of results to return

    Returns:
        List of matching endpoints
    """
    db = get_db_manager()

    # Get all endpoints
    all_endpoints = db.list_all_endpoints(limit=limit)

    # Apply filters
    filtered = all_endpoints
    if method:
        filtered = [e for e in filtered if e.method.upper() == method.upper()]
    if framework:
        filtered = [e for e in filtered if e.framework and e.framework.lower() == framework.lower()]
    if language:
        filtered = [e for e in filtered if e.language and e.language.lower() == language.lower()]

    return [
        {
            "id": e.id,
            "name": e.name,
            "route": e.route,
            "method": e.method,
            "file_path": e.file_path,
            "description": e.description,
            "framework": e.framework,
            "language": e.language,
        }
        for e in filtered
    ]


def search_endpoints_by_keyword(keyword: str, limit: int = 50) -> List[Dict[str, Any]]:
    """Search endpoints by keyword across multiple fields (fuzzy search).

    Args:
        keyword: Keyword to search for in name, route, description
        limit: Maximum number of results to return

    Returns:
        List of matching endpoints
    """
    db = get_db_manager()

    # Get all endpoints
    all_endpoints = db.list_all_endpoints(limit=1000)

    # Search across name, route, and description
    keyword_lower = keyword.lower()
    matches = []

    for e in all_endpoints:
        # Check if keyword appears in name, route, or description
        if (
            (e.name and keyword_lower in e.name.lower())
            or (e.route and keyword_lower in e.route.lower())
            or (e.description and keyword_lower in e.description.lower())
        ):
            matches.append(e)

    # Limit results
    matches = matches[:limit]

    return [
        {
            "id": e.id,
            "name": e.name,
            "route": e.route,
            "method": e.method,
            "file_path": e.file_path,
            "description": e.description,
            "framework": e.framework,
            "language": e.language,
        }
        for e in matches
    ]


def get_endpoint_details(endpoint_id: str) -> Dict[str, Any]:
    """Get full details for a specific endpoint by ID.

    Args:
        endpoint_id: ID of the endpoint

    Returns:
        Full endpoint details including all fields
    """
    db = get_db_manager()
    endpoint = db.get_endpoint(endpoint_id)

    if not endpoint:
        return {"error": f"Endpoint {endpoint_id} not found"}

    # Return full endpoint data
    return {
        "id": endpoint.id,
        "name": endpoint.name,
        "route": endpoint.route,
        "method": endpoint.method,
        "file_path": endpoint.file_path,
        "description": endpoint.description,
        "headers": endpoint.headers,
        "parameters": endpoint.parameters,
        "request_body": endpoint.request_body,
        "response_code": endpoint.response_code,
        "response_type": endpoint.response_type,
        "response_format": endpoint.response_format,
        "framework": endpoint.framework,
        "language": endpoint.language,
    }


# ==================== Phase 2: Statistics and Analysis Tools ====================


def get_api_statistics() -> Dict[str, Any]:
    """Get comprehensive statistics about stored API endpoints.

    Returns:
        Dictionary with statistics including:
        - Total number of endpoints
        - Breakdown by HTTP method
        - Breakdown by framework
        - Breakdown by language
    """
    db = get_db_manager()

    # Get all endpoints
    all_endpoints = db.list_all_endpoints(limit=10000)

    # Calculate statistics
    total = len(all_endpoints)

    # Count by method
    methods = {}
    for e in all_endpoints:
        method = e.method.upper()
        methods[method] = methods.get(method, 0) + 1

    # Count by framework
    frameworks = {}
    for e in all_endpoints:
        if e.framework:
            frameworks[e.framework] = frameworks.get(e.framework, 0) + 1

    # Count by language
    languages = {}
    for e in all_endpoints:
        if e.language:
            languages[e.language] = languages.get(e.language, 0) + 1

    return {
        "total_endpoints": total,
        "by_method": methods,
        "by_framework": frameworks,
        "by_language": languages,
    }


def list_all_collections() -> List[str]:
    """List all available collections.

    Returns:
        List of collection names
    """
    db = get_db_manager()
    return db.list_all_collections()


def get_collection_info_tool(name: Optional[str] = None) -> Dict[str, Any]:
    """Get information about a specific collection.

    Args:
        name: Collection name (uses default if not provided)

    Returns:
        Dictionary with collection information (name, vector_size, distance, count)
    """
    db = get_db_manager()
    return db.get_collection_info(name=name)
