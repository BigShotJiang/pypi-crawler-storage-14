"""CLI entry point for code-context."""

import sys
import argparse

from .server import main as run_server
from .ui.app import CodeContextApp


def init_command(project_path: str = None):
    """Initialize code-context with wizard flow

    Args:
        project_path: Optional path to set as initial project (not used in new flow)
    """
    # Launch the app which starts with WelcomeScreen
    app = CodeContextApp()
    app.run()


def scan_command(project_path: str = None):
    """Scan a project for API endpoints

    Args:
        project_path: Optional path to project (handled by ProjectSelectScreen)
    """
    # Launch the app which starts with WelcomeScreen
    # User can configure and select project through the wizard
    app = CodeContextApp()
    if project_path:
        # If path provided, store it for ProjectSelectScreen to use
        app.project_path = project_path
    app.run()


def info_command():
    """Display current configuration."""
    from pathlib import Path
    import json

    config_path = Path.home() / ".code-context" / "config.json"

    if not config_path.exists():
        print("ℹ️  code-context Configuration")
        print("=" * 50)
        print("No configuration found.")
        print("\nRun 'code-context init' to configure.")
        return

    try:
        with open(config_path, 'r') as f:
            config = json.load(f)

        print("ℹ️  code-context Configuration")
        print("=" * 50)
        print(f"LLM Provider:       {config.get('llm_provider', 'N/A')}")
        print(f"LLM Model:          {config.get('llm_model', 'N/A')}")
        print(f"API Key:            {'*' * 20 if config.get('api_key') else 'Not set'}")
        print(f"Config file:        {config_path}")

    except (json.JSONDecodeError, IOError) as e:
        print(f"Error reading configuration: {e}")


def start_command(collection: str = "endpoints"):
    """Start interactive dashboard for browsing endpoints.

    Args:
        collection: Name of the collection to load
    """
    from textual.app import App
    from .ui.screens import DashboardScreen

    class DashboardApp(App):
        """Standalone app for the dashboard."""

        def on_mount(self) -> None:
            """Mount the dashboard screen."""
            self.push_screen(DashboardScreen(collection_name=collection))

    app = DashboardApp()
    app.run()


def server_command(port: int = 18765):
    """Run the MCP server.

    Args:
        port: Port to run the server on
    """
    run_server(port=port)


def server_logs_command(follow: bool = False):
    """View MCP server logs.

    Args:
        follow: If True, continuously tail the log file
    """
    from pathlib import Path

    log_file = Path.home() / ".code-context" / "server.log"

    if not log_file.exists():
        print("❌ No server log file found")
        print("   Start the server first with: code-context server")
        return

    if follow:
        # Tail -f mode
        print(f"📋 Tailing server logs from: {log_file}")
        print("   Press Ctrl+C to stop\n")
        import subprocess
        try:
            subprocess.run(["tail", "-f", str(log_file)])
        except KeyboardInterrupt:
            print("\n\n👋 Stopped tailing logs")
    else:
        # Show last 50 lines
        print(f"📋 Server logs (last 50 lines): {log_file}\n")
        with open(log_file, "r") as f:
            lines = f.readlines()
            for line in lines[-50:]:
                print(line, end="")


def server_stop_command():
    """Stop the running MCP server gracefully."""
    from pathlib import Path
    import os
    import signal
    import time

    pid_file = Path.home() / ".code-context" / "server.pid"

    if not pid_file.exists():
        print("❌ No running server found (PID file not found)")
        print("   The server may not be running")
        return

    try:
        with open(pid_file, "r") as f:
            pid = int(f.read().strip())

        print(f"🔄 Stopping MCP server (PID: {pid})...")

        # Send SIGTERM for graceful shutdown
        os.kill(pid, signal.SIGTERM)

        # Wait for process to exit
        print("   Waiting for graceful shutdown...")
        for i in range(10):
            time.sleep(0.5)
            try:
                # Check if process still exists
                os.kill(pid, 0)
            except OSError:
                # Process is gone
                print("✅ Server stopped successfully")
                if pid_file.exists():
                    pid_file.unlink()
                return

        # If still running after 5 seconds, force kill
        print("⚠️  Server not responding, forcing shutdown...")
        os.kill(pid, signal.SIGKILL)
        time.sleep(0.5)
        print("✅ Server force stopped")

        if pid_file.exists():
            pid_file.unlink()

    except ValueError:
        print("❌ Invalid PID file")
    except ProcessLookupError:
        print("❌ Process not found (may have already stopped)")
        if pid_file.exists():
            pid_file.unlink()
    except PermissionError:
        print("❌ Permission denied - cannot stop server")
    except Exception as e:
        print(f"❌ Error stopping server: {e}")


def install_mcp_command():
    """Install MCP client integration."""
    from .cli.mcp_installer import run_mcp_installer
    run_mcp_installer()


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="code-context: MCP server for managing API endpoints",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  code-context init              Initialize and configure
  code-context scan              Scan current project
  code-context scan /path/to/dir Scan specific directory
  code-context start             Open interactive dashboard
  code-context start --collection my_api  Browse specific collection
  code-context info              Show configuration
  code-context server            Run MCP server
        """
    )
    parser.add_argument("--version", action="version", version="%(prog)s 0.1.0")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # init command
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize and configure code-context with interactive wizard"
    )

    # scan command
    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan a project for API endpoints"
    )
    scan_parser.add_argument(
        "project_path",
        nargs="?",
        default=None,
        help="Path to project (optional, can be selected in wizard)"
    )

    # start command
    start_parser = subparsers.add_parser(
        "start",
        help="Start interactive dashboard for browsing endpoints"
    )
    start_parser.add_argument(
        "--collection",
        "-c",
        default="endpoints",
        help="Collection name to browse (default: endpoints)"
    )

    # info command
    subparsers.add_parser("info", help="Display current configuration")

    # server command
    server_parser = subparsers.add_parser("server", help="Run MCP server (usually called by Claude)")
    server_parser.add_argument(
        "--port", "-p",
        type=int,
        default=18765,
        help="Port to run the server on (default: 18765)"
    )

    # server-logs command
    logs_parser = subparsers.add_parser("server-logs", help="View MCP server logs")
    logs_parser.add_argument(
        "-f", "--follow",
        action="store_true",
        help="Continuously tail the log file"
    )

    # server-stop command
    subparsers.add_parser("server-stop", help="Stop the running MCP server gracefully")

    # install-mcp command
    subparsers.add_parser("install-mcp", help="Install MCP client integration for your AI coding assistant")

    args = parser.parse_args()

    try:
        if args.command == "init":
            init_command()
        elif args.command == "scan":
            scan_command(project_path=getattr(args, 'project_path', None))
        elif args.command == "start":
            start_command(collection=getattr(args, 'collection', 'endpoints'))
        elif args.command == "info":
            info_command()
        elif args.command == "server":
            server_command(port=getattr(args, 'port', 18765))
        elif args.command == "server-logs":
            server_logs_command(follow=getattr(args, 'follow', False))
        elif args.command == "server-stop":
            server_stop_command()
        elif args.command == "install-mcp":
            install_mcp_command()
        else:
            # Default: show help
            parser.print_help()
            sys.exit(1)

    except KeyboardInterrupt:
        print("\n⚠ Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
