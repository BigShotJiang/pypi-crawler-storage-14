"""
LLM API Client for code-context
Simplified version supporting multiple LLM providers
"""

from typing import Dict, Any, Optional
from google import genai as google_genai
from google.genai import types as google_genai_types


class LLMResponse:
    """Standardized response object for all LLM providers"""

    def __init__(self, content: str, provider: str, model: str,
                 usage: Optional[Dict] = None, metadata: Optional[Dict] = None,
                 raw_response: Optional[Dict] = None):
        self.content = content
        self.provider = provider
        self.model = model
        self.usage = usage or {}
        self.metadata = metadata or {}
        self.raw_response = raw_response or {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert response to dictionary"""
        return {
            "content": self.content,
            "provider": self.provider,
            "model": self.model,
            "usage": self.usage,
            "metadata": self.metadata
        }


def transform_payload_for_openai(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Transform payload for OpenAI API"""
    openai_payload = payload.copy()

    model = payload.get("model", "")

    # GPT-5 series and o-series use max_completion_tokens instead of max_tokens
    if model.startswith(("gpt-5", "o1", "o3", "o4")):
        if "max_tokens" in openai_payload:
            openai_payload["max_completion_tokens"] = openai_payload.pop("max_tokens")

        # GPT-5 (not 5.1), gpt-5-mini, gpt-5-nano don't support temperature
        # Only gpt-5.1 supports temperature
        if model.startswith("gpt-5") and not model.startswith("gpt-5.1"):
            # Remove unsupported parameters for gpt-5/gpt-5-mini/gpt-5-nano
            for param in ["temperature", "top_p"]:
                openai_payload.pop(param, None)

    return openai_payload


def transform_payload_for_deepseek(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Transform payload for DeepSeek API (OpenAI-compatible)"""
    return payload.copy()


def transform_payload_for_claude(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Transform payload for Claude API"""
    claude_payload = {
        "model": payload.get("model", "claude-3-haiku-20240307"),
        "messages": [],
        "max_tokens": payload.get("max_tokens", 1024),
        "temperature": payload.get("temperature", 0.7)
    }

    system_prompt = None
    messages = payload.get("messages", [])

    for message in messages:
        if message.get("role") == "system":
            system_prompt = message.get("content", "")
        else:
            claude_payload["messages"].append(message)

    if system_prompt:
        claude_payload["system"] = system_prompt

    for key in ["stream", "top_p", "top_k"]:
        if key in payload:
            claude_payload[key] = payload[key]

    return claude_payload


def transform_payload_for_qwen(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Transform payload for Qwen API"""
    qwen_payload = payload.copy()

    json_supported_models = {
        'qwen-max-latest',
        'qwen-plus',
        'qwen-turbo',
        'qwen-flash'
    }

    model = payload.get('model', '')

    if model in ['qwen-plus', 'qwen-flash']:
        enable_thinking = payload.get('thinking', payload.get('enable_thinking', False))
        has_json_format = payload.get('response_format', {}).get('type') == 'json_object'

        if enable_thinking and has_json_format:
            if 'response_format' in qwen_payload:
                del qwen_payload['response_format']
        elif has_json_format:
            qwen_payload['thinking'] = False
            qwen_payload['enable_thinking'] = False

    if 'response_format' in qwen_payload:
        if model not in json_supported_models:
            del qwen_payload['response_format']

    extra_body = {}

    if 'thinking' in payload or 'enable_thinking' in payload:
        enable_thinking = payload.get('thinking', payload.get('enable_thinking', False))
        extra_body['enable_thinking'] = enable_thinking

        if enable_thinking and 'thinking_budget' in payload:
            extra_body['thinking_budget'] = payload['thinking_budget']

    if extra_body:
        qwen_payload['extra_body'] = extra_body

    for key in ['thinking', 'enable_thinking', 'thinking_budget']:
        qwen_payload.pop(key, None)

    return qwen_payload


def transform_payload_for_gemini(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Transform payload for Gemini API"""
    gemini_payload = {
        "contents": [],
        "generation_config": {}
    }

    system_instruction = None
    user_messages = []
    for message in payload.get("messages", []):
        if message["role"] == "system":
            system_instruction = message["content"]
        else:
            user_messages.append(message)

    for message in user_messages:
        gemini_payload["contents"].append({
            "role": "user" if message["role"] == "user" else "model",
            "parts": [{"text": message["content"]}]
        })

    if system_instruction:
        gemini_payload["generation_config"]["system_instruction"] = system_instruction

    if "max_tokens" in payload:
        gemini_payload["generation_config"]["max_output_tokens"] = payload["max_tokens"]
    if "temperature" in payload:
        gemini_payload["generation_config"]["temperature"] = payload["temperature"]
    if "top_p" in payload:
        gemini_payload["generation_config"]["top_p"] = payload["top_p"]
    if "top_k" in payload:
        gemini_payload["generation_config"]["top_k"] = payload["top_k"]

    if "tools" in payload:
        gemini_payload["tools"] = payload["tools"]

    if payload.get("response_format", {}).get("type") == "json_object":
        gemini_payload["generation_config"]["response_mime_type"] = "application/json"

    if "gemini_response_schema" in payload:
        gemini_payload["generation_config"]["response_schema"] = payload["gemini_response_schema"]

    if payload.get("thinking"):
        gemini_payload["generation_config"]["thinking"] = True

    return gemini_payload


def make_openai_request(payload: Dict[str, Any], api_key: str, base_url: Optional[str] = None) -> Dict[str, Any]:
    """Make request using OpenAI client"""
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError("OpenAI library not installed. Please install with: pip install openai")

    client = OpenAI(api_key=api_key, base_url=base_url)

    try:
        response = client.chat.completions.create(**payload)
        return response.model_dump()
    except Exception as e:
        raise Exception(f"OpenAI API call failed: {e}")


def make_claude_request(payload: Dict[str, Any], api_key: str) -> Dict[str, Any]:
    """Make request using Claude client"""
    try:
        from anthropic import Anthropic
    except ImportError:
        raise ImportError("Anthropic library not installed. Please install with: pip install anthropic")

    client = Anthropic(api_key=api_key)

    try:
        response = client.messages.create(**payload)
        return {
            "id": response.id,
            "type": response.type,
            "role": response.role,
            "content": [{"type": "text", "text": response.content[0].text}],
            "model": response.model,
            "stop_reason": response.stop_reason,
            "usage": {
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens
            }
        }
    except Exception as e:
        raise Exception(f"Claude API call failed: {e}")


def make_qwen_request(payload: Dict[str, Any], api_key: str) -> Dict[str, Any]:
    """Make request using Qwen API"""
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError("OpenAI library not installed. Please install with: pip install openai")

    client = OpenAI(
        api_key=api_key,
        base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
    )

    try:
        response = client.chat.completions.create(**payload)
        return response.model_dump()
    except Exception as e:
        raise Exception(f"Qwen API call failed: {e}")


def make_gemini_request(payload: Dict[str, Any], api_key: str, model_name: str) -> any:
    """Make request using Gemini client"""
    if not google_genai or not google_genai_types:
        raise ImportError("Google GenAI library not installed. Please install with: pip install google-genai")

    client = google_genai.Client(api_key=api_key)

    request_kwargs = {
        "contents": payload.get("contents"),
    }
    if payload.get("tools"):
        request_kwargs["tools"] = payload.get("tools")

    generation_config_dict = payload.get("generation_config", {}).copy()

    if generation_config_dict:
        if generation_config_dict.pop("thinking", False):
            generation_config_dict["thinking_config"] = google_genai_types.ThinkingConfig(thinking_budget=1024)

        request_kwargs["config"] = google_genai_types.GenerateContentConfig(**generation_config_dict)

    try:
        response = client.models.generate_content(
            model=model_name,
            **request_kwargs
        )
        return response
    except Exception as e:
        raise Exception(f"Gemini API call failed: {e}")


def parse_openai_response(raw_response: Dict[str, Any]) -> LLMResponse:
    """Parse OpenAI/DeepSeek response"""
    content = raw_response["choices"][0]["message"]["content"]
    usage = {
        "input_tokens": raw_response["usage"]["prompt_tokens"],
        "output_tokens": raw_response["usage"]["completion_tokens"],
        "total_tokens": raw_response["usage"]["total_tokens"]
    }

    provider = "deepseek" if "deepseek" in raw_response["model"] else "openai"

    return LLMResponse(
        content=content,
        provider=provider,
        model=raw_response["model"],
        usage=usage,
        metadata={"finish_reason": raw_response["choices"][0]["finish_reason"]},
        raw_response=raw_response
    )


def parse_claude_response(raw_response: Dict[str, Any]) -> LLMResponse:
    """Parse Claude response"""
    content = raw_response["content"][0]["text"]
    usage = {
        "input_tokens": raw_response["usage"]["input_tokens"],
        "output_tokens": raw_response["usage"]["output_tokens"],
        "total_tokens": raw_response["usage"]["input_tokens"] + raw_response["usage"]["output_tokens"]
    }

    return LLMResponse(
        content=content,
        provider="claude",
        model=raw_response["model"],
        usage=usage,
        metadata={"stop_reason": raw_response["stop_reason"]},
        raw_response=raw_response
    )


def parse_qwen_response(raw_response: Dict[str, Any]) -> LLMResponse:
    """Parse Qwen response"""
    content = raw_response["choices"][0]["message"]["content"]
    usage = {
        "input_tokens": raw_response["usage"]["prompt_tokens"],
        "output_tokens": raw_response["usage"]["completion_tokens"],
        "total_tokens": raw_response["usage"]["total_tokens"]
    }

    return LLMResponse(
        content=content,
        provider="qwen",
        model=raw_response["model"],
        usage=usage,
        metadata={"finish_reason": raw_response["choices"][0]["finish_reason"]},
        raw_response=raw_response
    )


def parse_gemini_response(raw_response: any, model_name: str) -> LLMResponse:
    """Parse Gemini response"""
    usage_metadata = raw_response.usage_metadata

    usage = {}
    if usage_metadata:
        usage = {
            "input_tokens": usage_metadata.prompt_token_count,
            "output_tokens": usage_metadata.candidates_token_count,
            "total_tokens": usage_metadata.total_token_count
        }

    return LLMResponse(
        content=raw_response.text,
        provider="gemini",
        model=model_name,
        usage=usage,
        metadata={},
        raw_response=raw_response
    )


def send_llm_request(payload: Dict[str, Any], provider: str, api_key: str, **kwargs) -> LLMResponse:
    """
    Send request to specified LLM provider

    Args:
        payload: Request payload (OpenAI-style format)
        provider: Provider name ("openai", "deepseek", "claude", "gemini", "qwen")
        api_key: API key for the provider
        **kwargs: Additional provider-specific parameters

    Returns:
        LLMResponse object with standardized response
    """
    provider = provider.lower()

    provider_configs = {
        "openai": {
            "transform": transform_payload_for_openai,
            "request": make_openai_request,
            "parse": parse_openai_response,
            "params": {}
        },
        "deepseek": {
            "transform": transform_payload_for_deepseek,
            "request": make_openai_request,
            "parse": parse_openai_response,
            "params": {"base_url": kwargs.get("base_url", "https://api.deepseek.com")}
        },
        "claude": {
            "transform": transform_payload_for_claude,
            "request": make_claude_request,
            "parse": parse_claude_response,
            "params": {}
        },
        "gemini": {
            "transform": transform_payload_for_gemini,
            "request": make_gemini_request,
            "parse": parse_gemini_response,
            "params": {"model_name": payload.get("model", "gemini-2.0-flash-exp")}
        },
        "qwen": {
            "transform": transform_payload_for_qwen,
            "request": make_qwen_request,
            "parse": parse_qwen_response,
            "params": {}
        }
    }

    if provider not in provider_configs:
        raise ValueError(f"Unsupported provider: {provider}. Supported: {', '.join(provider_configs.keys())}")

    config = provider_configs[provider]

    # Transform payload
    transformed_payload = config["transform"](payload)

    # Make request
    request_func = config["request"]
    request_params = {"api_key": api_key, **config["params"]}
    raw_response = request_func(transformed_payload, **request_params)

    # Parse response
    parse_func = config["parse"]
    if provider == "gemini":
        parsed_response = parse_func(raw_response, model_name=request_params["model_name"])
    else:
        parsed_response = parse_func(raw_response)

    return parsed_response
