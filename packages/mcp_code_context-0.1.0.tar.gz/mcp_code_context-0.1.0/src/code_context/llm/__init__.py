"""LLM integration module for code-context."""

from .llm_client import send_llm_request, LLMResponse

__all__ = ["send_llm_request", "LLMResponse"]
