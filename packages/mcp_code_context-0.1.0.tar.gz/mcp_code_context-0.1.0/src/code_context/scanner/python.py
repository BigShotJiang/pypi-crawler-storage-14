"""Python FastAPI/Flask scanner."""

import re
import uuid
from pathlib import Path
from typing import List, Optional, Dict, Any
import ast

from . import BaseScanner
from ..database import Endpoint


class PythonScanner(BaseScanner):
    """Scanner for Python web frameworks (FastAPI, Flask, Django)."""

    # HTTP methods to look for
    HTTP_METHODS = ["get", "post", "put", "delete", "patch", "options", "head"]

    # Decorator patterns for different frameworks
    FASTAPI_PATTERN = re.compile(
        r'@(?:app|router)\.(get|post|put|delete|patch|options|head)\(["\']([^"\']+)["\']'
    )
    FLASK_PATTERN = re.compile(
        r'@(?:app|bp)\.(route)\(["\']([^"\']+)["\'].*methods\s*=\s*\[([^\]]+)\]'
    )

    def __init__(self):
        """Initialize Python scanner."""
        self.framework = None

    def can_handle(self, file_path: Path) -> bool:
        """Check if this is a Python file that might contain endpoints.

        Args:
            file_path: Path to check

        Returns:
            True if file is a Python file
        """
        if file_path.suffix != ".py":
            return False

        # Skip common non-endpoint files
        excluded_patterns = [
            "__pycache__",
            ".pyc",
            "test_",
            "_test.py",
            "conftest.py",
            "setup.py",
        ]

        for pattern in excluded_patterns:
            if pattern in str(file_path):
                return False

        return True

    def scan_file(self, file_path: Path) -> List[Endpoint]:
        """Scan a Python file for API endpoints.

        Args:
            file_path: Path to the Python file

        Returns:
            List of endpoints found
        """
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return []

        endpoints = []

        # Try FastAPI pattern
        endpoints.extend(self._scan_fastapi(content, file_path))

        # Try Flask pattern
        endpoints.extend(self._scan_flask(content, file_path))

        return endpoints

    def _scan_fastapi(self, content: str, file_path: Path) -> List[Endpoint]:
        """Scan for FastAPI endpoints.

        Args:
            content: File content
            file_path: Path to the file

        Returns:
            List of FastAPI endpoints
        """
        endpoints = []

        for match in self.FASTAPI_PATTERN.finditer(content):
            method = match.group(1).upper()
            route = match.group(2)

            # Try to extract function name and docstring
            func_name, description = self._extract_function_info(content, match.start())

            endpoint = Endpoint(
                id=str(uuid.uuid4()),
                name=func_name or f"{method}_{route.replace('/', '_')}",
                route=route,
                method=method,
                file_path=str(file_path),
                description=description,
                framework="FastAPI",
                language="Python",
            )
            endpoints.append(endpoint)

        return endpoints

    def _scan_flask(self, content: str, file_path: Path) -> List[Endpoint]:
        """Scan for Flask endpoints.

        Args:
            content: File content
            file_path: Path to the file

        Returns:
            List of Flask endpoints
        """
        endpoints = []

        for match in self.FLASK_PATTERN.finditer(content):
            route = match.group(2)
            methods_str = match.group(3)
            methods = [m.strip().strip('"\'') for m in methods_str.split(",")]

            func_name, description = self._extract_function_info(content, match.start())

            for method in methods:
                endpoint = Endpoint(
                    id=str(uuid.uuid4()),
                    name=func_name or f"{method}_{route.replace('/', '_')}",
                    route=route,
                    method=method.upper(),
                    file_path=str(file_path),
                    description=description,
                    framework="Flask",
                    language="Python",
                )
                endpoints.append(endpoint)

        return endpoints

    def _extract_function_info(
        self, content: str, decorator_pos: int
    ) -> tuple[Optional[str], Optional[str]]:
        """Extract function name and docstring after a decorator.

        Args:
            content: File content
            decorator_pos: Position of the decorator in content

        Returns:
            Tuple of (function_name, description)
        """
        # Find the function definition after the decorator
        func_pattern = re.compile(r"def\s+(\w+)\s*\(")
        match = func_pattern.search(content, decorator_pos)

        if not match:
            return None, None

        func_name = match.group(1)

        # Try to extract docstring
        try:
            # Find the function body start
            func_start = match.end()
            lines = content[func_start:].split("\n")

            # Look for docstring in first few lines
            for line in lines[:10]:
                if '"""' in line or "'''" in line:
                    # Simple docstring extraction (can be improved)
                    docstring = line.strip().strip('"""').strip("'''")
                    return func_name, docstring if docstring else None

        except Exception:
            pass

        return func_name, None


# Factory function to get appropriate scanner
def get_scanner(language: str) -> Optional[BaseScanner]:
    """Get scanner for a specific language.

    Args:
        language: Language name (e.g., 'python', 'go', 'rust')

    Returns:
        Scanner instance or None if not supported
    """
    scanners = {
        "python": PythonScanner,
        # Future: add more scanners here
        # "go": GoScanner,
        # "rust": RustScanner,
    }

    scanner_class = scanners.get(language.lower())
    return scanner_class() if scanner_class else None
