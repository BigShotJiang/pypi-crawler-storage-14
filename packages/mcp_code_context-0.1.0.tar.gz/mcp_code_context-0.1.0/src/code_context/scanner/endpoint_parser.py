"""Endpoint parsing for various web frameworks."""

import ast
import hashlib
import logging
from pathlib import Path
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class EndpointInfo:
    """Information about a single API endpoint"""
    file_path: str
    endpoint_id: str  # e.g., "POST /api/v1/auth/login"
    method: str  # GET, POST, PUT, DELETE, PATCH
    route: str  # /api/v1/auth/login
    function_name: str
    start_line: int
    end_line: int
    code: str
    char_length: int
    code_hash: str
    docstring: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)


class BaseEndpointParser:
    """Base class for framework-specific endpoint parsers"""

    def parse_file(self, file_path: Path, project_root: Path) -> List[EndpointInfo]:
        """Parse a file and extract endpoint information

        Args:
            file_path: Path to file to parse
            project_root: Project root for relative paths

        Returns:
            List of EndpointInfo objects
        """
        raise NotImplementedError("Subclasses must implement parse_file")

    def _calculate_hash(self, code: str) -> str:
        """Calculate MD5 hash of code

        Args:
            code: Source code string

        Returns:
            MD5 hash as hex string
        """
        return hashlib.md5(code.encode('utf-8')).hexdigest()

    def _get_relative_path(self, file_path: Path, project_root: Path) -> str:
        """Get relative path from project root

        Args:
            file_path: Absolute file path
            project_root: Project root path

        Returns:
            Relative path string
        """
        try:
            return str(file_path.relative_to(project_root))
        except ValueError:
            return str(file_path)


class FastAPIEndpointParser(BaseEndpointParser):
    """Parser for FastAPI endpoints"""

    ROUTE_DECORATORS = {
        'get': 'GET',
        'post': 'POST',
        'put': 'PUT',
        'delete': 'DELETE',
        'patch': 'PATCH',
        'head': 'HEAD',
        'options': 'OPTIONS',
    }

    def parse_file(self, file_path: Path, project_root: Path) -> List[EndpointInfo]:
        """Parse FastAPI file for endpoints

        Args:
            file_path: Path to Python file
            project_root: Project root

        Returns:
            List of endpoints found
        """
        logger.debug(f"Parsing file: {file_path}")
        endpoints = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                source_code = f.read()
            logger.debug(f"Read {len(source_code)} characters from {file_path}")

            # Parse AST
            tree = ast.parse(source_code)
            lines = source_code.splitlines()

            # Find router prefix from APIRouter definition
            router_prefix = self._find_router_prefix(tree)

            # Find all decorated functions (both sync and async)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    endpoint = self._extract_endpoint_from_function(
                        node, lines, file_path, project_root, router_prefix
                    )
                    if endpoint:
                        endpoints.append(endpoint)

        except Exception as e:
            # Log error but don't fail completely
            logger.error(f"Failed to parse {file_path}: {e}", exc_info=True)

        return endpoints

    def _find_router_prefix(self, tree: ast.AST) -> str:
        """Find router prefix from APIRouter definition

        Args:
            tree: AST tree

        Returns:
            Router prefix string (e.g., "/api/v1/auth")
        """
        for node in ast.walk(tree):
            # Look for: router = APIRouter(prefix="/api/v1/auth")
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == 'router':
                        if isinstance(node.value, ast.Call):
                            for keyword in node.value.keywords:
                                if keyword.arg == 'prefix':
                                    if isinstance(keyword.value, ast.Constant):
                                        return keyword.value.value
        return ""

    def _extract_endpoint_from_function(
        self,
        func_node: ast.FunctionDef,
        lines: List[str],
        file_path: Path,
        project_root: Path,
        router_prefix: str
    ) -> Optional[EndpointInfo]:
        """Extract endpoint info from decorated function

        Args:
            func_node: AST FunctionDef node
            lines: Source code lines
            file_path: File path
            project_root: Project root
            router_prefix: Router prefix (e.g., "/api/v1/auth")

        Returns:
            EndpointInfo or None if not an endpoint
        """
        # Check decorators
        for decorator in func_node.decorator_list:
            method, route = self._parse_decorator(decorator)
            if method and route:
                # Build full route
                full_route = router_prefix + route

                # Extract code (from first decorator to end of function)
                start_line = decorator.lineno
                end_line = func_node.end_lineno
                code = '\n'.join(lines[start_line - 1:end_line])

                # Extract docstring
                docstring = ast.get_docstring(func_node)

                # Build endpoint info
                endpoint = EndpointInfo(
                    file_path=self._get_relative_path(file_path, project_root),
                    endpoint_id=f"{method} {full_route}",
                    method=method,
                    route=full_route,
                    function_name=func_node.name,
                    start_line=start_line,
                    end_line=end_line,
                    code=code,
                    char_length=len(code),
                    code_hash=self._calculate_hash(code),
                    docstring=docstring
                )

                return endpoint

        return None

    def _parse_decorator(self, decorator: ast.expr) -> tuple[Optional[str], Optional[str]]:
        """Parse decorator to extract HTTP method and route

        Args:
            decorator: AST decorator expression

        Returns:
            Tuple of (method, route) or (None, None)
        """
        # Handle @router.get("/path") or @app.post("/path")
        if isinstance(decorator, ast.Call):
            if isinstance(decorator.func, ast.Attribute):
                decorator_name = decorator.func.attr
                method = self.ROUTE_DECORATORS.get(decorator_name.lower())

                if method and decorator.args:
                    # Extract route from first argument
                    if isinstance(decorator.args[0], ast.Constant):
                        route = decorator.args[0].value
                        return method, route

        return None, None


class GenericEndpointParser(BaseEndpointParser):
    """Generic fallback parser for unknown frameworks"""

    def parse_file(self, file_path: Path, project_root: Path) -> List[EndpointInfo]:
        """Generic parsing with simple heuristics

        Args:
            file_path: File to parse
            project_root: Project root

        Returns:
            List of endpoints (best effort)
        """
        # TODO: Implement basic heuristic-based parsing
        # For now, return empty list as fallback
        return []


class EndpointParser:
    """Main endpoint parser that delegates to framework-specific parsers"""

    def __init__(self, frameworks: List[str], presenter=None):
        """Initialize endpoint parser

        Args:
            frameworks: List of detected frameworks
            presenter: Optional ScannerPresenter for UI updates
        """
        self.frameworks = frameworks
        self.presenter = presenter
        self.parser = self._select_parser()

    def _select_parser(self) -> BaseEndpointParser:
        """Select appropriate parser based on detected frameworks

        Returns:
            Framework-specific parser instance
        """
        if "fastapi" in self.frameworks:
            return FastAPIEndpointParser()
        elif "flask" in self.frameworks:
            # TODO: Implement FlaskEndpointParser
            return GenericEndpointParser()
        elif "django" in self.frameworks:
            # TODO: Implement DjangoEndpointParser
            return GenericEndpointParser()
        else:
            return GenericEndpointParser()

    def parse_files(
        self,
        candidates: Dict[str, List[Path]],
        project_root: Path
    ) -> List[EndpointInfo]:
        """Parse all candidate files to extract endpoints

        Args:
            candidates: Dict of {language: [file_paths]}
            project_root: Project root path

        Returns:
            List of all endpoints found
        """
        total_files = sum(len(files) for files in candidates.values())
        logger.info(f"Starting endpoint parsing: {total_files} files to parse")
        logger.debug(f"Candidates by language: {', '.join(f'{lang}={len(files)}' for lang, files in candidates.items())}")

        # Notify UI that parsing is starting
        if self.presenter:
            self.presenter.start_endpoint_parsing()

        all_endpoints = []

        # Parse each file
        for language, files in candidates.items():
            logger.info(f"Parsing {len(files)} {language} files...")
            for file_path in files:
                logger.debug(f"Processing: {file_path}")
                endpoints = self.parser.parse_file(file_path, project_root)
                if endpoints:
                    logger.info(f"Found {len(endpoints)} endpoints in {file_path.name}")
                all_endpoints.extend(endpoints)

        logger.info(f"Endpoint parsing complete: found {len(all_endpoints)} total endpoints")

        # Notify UI that parsing is complete
        if self.presenter:
            self.presenter.complete_endpoint_parsing(len(all_endpoints))

        return all_endpoints
