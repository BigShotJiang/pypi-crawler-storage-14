"""LLM-powered file filtering for endpoint detection."""

from typing import List, Dict
from pathlib import Path
import json
from rich.console import Console

console = Console()


class LLMFileFilter:
    """Use LLM to intelligently filter files that likely contain API endpoints"""

    def __init__(self, llm_provider: str, llm_model: str, api_key: str, frameworks: List[str] = None, presenter=None):
        """Initialize LLM filter

        Args:
            llm_provider: LLM provider name
            llm_model: Model to use
            api_key: API key
            frameworks: List of detected frameworks (optional)
            presenter: Optional ScannerPresenter for UI updates
        """
        self.provider = llm_provider
        self.model = llm_model
        self.api_key = api_key
        self.frameworks = frameworks or []
        self.presenter = presenter

    def filter_candidate_files(
        self,
        files_by_language: Dict[str, List[Path]],
        project_root: Path
    ) -> Dict[str, List[Path]]:
        """Use LLM to identify files that likely contain endpoints

        Processes files in batches of 50 to avoid overwhelming the LLM.

        Args:
            files_by_language: Dictionary of {language: [file_paths]}
            project_root: Project root path for relative paths

        Returns:
            Filtered dictionary with only candidate files
        """
        BATCH_SIZE = 50
        candidates = {}

        # Notify UI that LLM filtering is starting
        if self.presenter:
            self.presenter.start_llm_filter()

        total_candidates_count = 0

        for language, files in files_by_language.items():
            if not files:
                continue

            # Split into batches
            batches = [files[i:i + BATCH_SIZE] for i in range(0, len(files), BATCH_SIZE)]
            language_candidates = []

            # Process each batch
            for batch_idx, batch in enumerate(batches, 1):

                # Get relative paths for this batch
                relative_paths = []
                for f in batch:
                    try:
                        rel_path = f.relative_to(project_root)
                        relative_paths.append(str(rel_path))
                    except ValueError:
                        relative_paths.append(str(f.name))

                # Build prompt
                prompt = self._build_filter_prompt(language, relative_paths)

                # Call LLM
                try:
                    response, result = self._call_llm(prompt)
                    candidate_paths = result.get("candidate_files", [])

                    # Map back to Path objects for this batch
                    batch_candidates = [
                        f for f in batch
                        if any(str(f).endswith(cp) or str(f.name) == cp for cp in candidate_paths)
                    ]

                    language_candidates.extend(batch_candidates)
                    total_candidates_count += len(batch_candidates)

                    # Update UI with batch progress
                    if self.presenter:
                        token_usage = response.usage or {}
                        self.presenter.update_llm_batch(
                            batch_idx,
                            len(batches),
                            total_candidates_count,  # Show total candidates found so far
                            token_usage
                        )

                except Exception as e:
                    continue

            # Store candidates for this language
            candidates[language] = language_candidates

        # Collect all candidate files
        all_candidates = []
        for lang_candidates in candidates.values():
            all_candidates.extend(lang_candidates)

        # Notify UI of completion
        if self.presenter:
            self.presenter.complete_llm_filter(len(all_candidates))
            self.presenter.update_candidate_files(all_candidates, project_root)

        return candidates

    def _build_filter_prompt(self, language: str, file_paths: List[str]) -> str:
        """Build LLM prompt for file filtering with strict criteria

        Args:
            language: Programming language
            file_paths: List of relative file paths

        Returns:
            Formatted prompt string
        """
        # Add framework hint if available
        framework_hint = ""
        if self.frameworks:
            framework_hint = f"\n**Detected frameworks**: {', '.join(self.frameworks)}"

        return f"""You are analyzing a {language} project to find files that contain API endpoint definitions.{framework_hint}

STRICT CRITERIA: Only include files if you are CONFIDENT they contain actual endpoint definitions.

API Endpoint types to look for:
- HTTP endpoints (GET, POST, PUT, DELETE, PATCH handlers)
- API route definitions (express.Router, FastAPI routes, Flask blueprints, etc.)
- REST API controllers/handlers
- GraphQL resolvers
- RPC service definitions (gRPC, etc.)
- WebSocket handlers

File paths in this batch ({len(file_paths)} total):
{chr(10).join(f"- {p}" for p in file_paths)}

Common patterns for endpoint files:
✅ INCLUDE files/directories named: route*, api*, controller*, handler*, endpoint*, *views.py, server.*, app.py, main.*
✅ INCLUDE files in: routes/, api/, controllers/, handlers/, views/, endpoints/

❌ EXCLUDE: test*, *_test.*, *.test.*, *.spec.*, config*, settings*, utils*, helpers*, model*, schema*
❌ EXCLUDE files in: tests/, __tests__/, spec/, migrations/, alembic/

IMPORTANT: Be STRICT. When in doubt, EXCLUDE the file.
Only return files you are confident contain endpoint definitions.

Return JSON format:
{{
    "candidate_files": ["path/to/file1.{self._get_extension(language)}", "path/to/file2.{self._get_extension(language)}"],
    "reasoning": "Brief explanation of selection criteria"
}}

If NO files match the strict criteria, return an empty list for candidate_files.
"""

    def _call_llm(self, prompt: str) -> tuple:
        """Call LLM API to analyze files

        Args:
            prompt: Analysis prompt

        Returns:
            Tuple of (LLMResponse object, parsed JSON dict)
        """
        from ..llm.llm_client import send_llm_request

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "You are a code structure analyzer. Return valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.1,
            "max_tokens": 2000
        }

        response = send_llm_request(
            payload=payload,
            provider=self.provider,
            api_key=self.api_key
        )

        try:
            parsed_result = json.loads(response.content)
            return response, parsed_result
        except json.JSONDecodeError as e:
            console.print(f"[red]Error parsing LLM response: {e}[/red]")
            console.print(f"[dim]Response: {response.content[:200]}...[/dim]")
            return response, {"candidate_files": [], "reasoning": "Failed to parse response"}

    def _get_extension(self, language: str) -> str:
        """Get file extension for language

        Args:
            language: Language name

        Returns:
            File extension (e.g., "py", "js")
        """
        ext_map = {
            "python": "py",
            "javascript": "js",
            "typescript": "ts",
            "go": "go",
            "rust": "rs",
            "java": "java",
            "ruby": "rb",
            "php": "php",
        }
        return ext_map.get(language, "txt")
