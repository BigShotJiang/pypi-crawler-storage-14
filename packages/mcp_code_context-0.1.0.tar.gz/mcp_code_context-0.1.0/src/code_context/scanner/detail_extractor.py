"""Endpoint detail extraction using LLM."""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass

from ..config import get_config

logger = logging.getLogger(__name__)


def extract_endpoint_code(file_path: str, start_line: int, end_line: int) -> str:
    """
    Extract code snippet from file by line range

    Args:
        file_path: Path to the Python file
        start_line: Starting line number (1-indexed)
        end_line: Ending line number (1-indexed, inclusive)

    Returns:
        Code snippet as string
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Convert to 0-indexed
    start_idx = start_line - 1
    end_idx = end_line  # end_line is inclusive, so no -1

    # Extract lines
    code_lines = lines[start_idx:end_idx]

    return ''.join(code_lines)


@dataclass
class EndpointDetail:
    """Detailed information about an endpoint"""
    endpoint_id: str
    description: str  # Top-level, for embedding
    embed: List[float]  # Embedding vector
    payload: Dict[str, Any]  # All detailed fields


class EndpointDetailExtractor:
    """Extract detailed information from endpoints using LLM"""

    EXTRACTION_PROMPT = """You are an API documentation expert. Analyze the following API endpoint code and extract detailed information.

**Endpoint Code:**
```python
{code}
```

**File Information:**
- Path: {file_path}
- Function: {function_name}
- Route: {method} {route}
- Line: {line_number}

Extract the following information in JSON format:

1. **description**: A clear, concise description of what this endpoint does (1-2 sentences, for embedding)
2. **summary**: A short title/name for this endpoint
3. **tags**: List of relevant tags/categories
4. **authentication**: Whether authentication is required and type
5. **authorization**: Required roles/permissions
6. **parameters**: All request parameters (path, query, body, headers)
7. **responses**: All possible responses with status codes and schemas
8. **business_logic**: Description of the business logic and workflow
9. **rate_limiting**: Rate limiting configuration if any
10. **error_handling**: How errors are handled
11. **examples**: Example request and response
12. **metadata**: Version, stability, deprecation status

Return ONLY a valid JSON object with this structure:
{{
  "description": "string",
  "summary": "string",
  "tags": ["string"],
  "authentication": {{
    "required": boolean,
    "type": "string or null"
  }},
  "authorization": {{
    "required": boolean,
    "roles": ["string"],
    "permissions": ["string"]
  }},
  "parameters": {{
    "path": [],
    "query": [],
    "body": {{}},
    "headers": {{}}
  }},
  "responses": {{}},
  "business_logic": {{
    "description": "string",
    "steps": ["string"],
    "dependencies": {{}}
  }},
  "rate_limiting": {{}},
  "error_handling": {{}},
  "examples": {{}},
  "metadata": {{
    "version": "string",
    "deprecated": boolean,
    "stability": "string"
  }}
}}

Be thorough and extract all available information from the code. Infer missing information based on code analysis."""

    def __init__(self, llm_provider: str, llm_model: str, api_key: str,
                 embedding_provider: str = None, embedding_model: str = None,
                 presenter=None, batch_size: int = 5):
        """Initialize detail extractor

        Args:
            llm_provider: LLM provider (openai, anthropic, google)
            llm_model: LLM model name
            api_key: API key
            embedding_provider: Embedding provider (default: same as llm_provider)
            embedding_model: Embedding model name
            presenter: Optional presenter for UI updates
            batch_size: Number of concurrent requests (default: 5)
        """
        self.llm_provider = llm_provider
        self.llm_model = llm_model
        self.api_key = api_key
        self.embedding_provider = embedding_provider or llm_provider
        self.embedding_model = embedding_model
        self.presenter = presenter
        self.batch_size = batch_size

        # Get vector size from config
        config = get_config()
        self.vector_size = config.vector_size

        # Initialize LLM client
        self._init_llm_client()

        # Initialize embedding client
        self._init_embedding_client()

    def _init_llm_client(self):
        """Initialize LLM client based on provider"""
        if self.llm_provider == "openai":
            from openai import OpenAI
            self.llm_client = OpenAI(api_key=self.api_key)
        elif self.llm_provider == "anthropic":
            from anthropic import Anthropic
            self.llm_client = Anthropic(api_key=self.api_key)
        elif self.llm_provider == "google":
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            self.llm_client = genai
        else:
            raise ValueError(f"Unsupported LLM provider: {self.llm_provider}")

    def _init_embedding_client(self):
        """Initialize embedding client with error handling"""
        try:
            if self.embedding_provider == "openai":
                from openai import OpenAI
                self.embedding_client = OpenAI(api_key=self.api_key)
                self.embedding_model = self.embedding_model or "text-embedding-3-small"
                logger.info(f"Initialized OpenAI embedding client with model: {self.embedding_model}")

            elif self.embedding_provider == "google":
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.embedding_client = genai
                self.embedding_model = self.embedding_model or "models/embedding-001"
                logger.info(f"Initialized Google embedding client with model: {self.embedding_model}")

            else:
                # Fallback to OpenAI
                logger.warning(f"Unknown embedding provider '{self.embedding_provider}', falling back to OpenAI")
                from openai import OpenAI
                self.embedding_client = OpenAI(api_key=self.api_key)
                self.embedding_model = "text-embedding-3-small"
                logger.info(f"Initialized OpenAI embedding client (fallback) with model: {self.embedding_model}")

        except ImportError as e:
            error_msg = f"Failed to import embedding client library for '{self.embedding_provider}': {e}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

        except Exception as e:
            error_msg = (
                f"Failed to initialize embedding client for '{self.embedding_provider}'. "
                f"Please check your API key and configuration. Error: {e}"
            )
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

    def extract_details(self, endpoints: List[Dict], project_root: Path):
        """Extract details from multiple endpoints with concurrency (generator)

        Args:
            endpoints: List of EndpointInfo objects
            project_root: Project root path

        Yields:
            Tuple of (EndpointDetail object, token usage dict) as they are completed
        """
        logger.info(f"Starting detail extraction for {len(endpoints)} endpoints")

        total = len(endpoints)

        # Process in batches with thread pool
        with ThreadPoolExecutor(max_workers=self.batch_size) as executor:
            # Submit all tasks
            future_to_endpoint = {
                executor.submit(self._extract_single_endpoint, ep, project_root): ep
                for ep in endpoints
            }

            # Process completed tasks and yield them
            completed = 0
            for future in as_completed(future_to_endpoint):
                endpoint = future_to_endpoint[future]
                completed += 1

                try:
                    detail, token_usage = future.result()
                    logger.info(f"Extracted details for {endpoint.endpoint_id} ({completed}/{total})")
                    yield detail, token_usage

                except Exception as e:
                    logger.error(f"Failed to extract {endpoint.endpoint_id}: {e}", exc_info=True)
                    # Don't yield on error, just skip

        logger.info(f"Detail extraction complete")

    def _extract_single_endpoint(self, endpoint, project_root: Path) -> tuple:
        """Extract details for a single endpoint

        Args:
            endpoint: EndpointInfo object
            project_root: Project root path

        Returns:
            Tuple of (EndpointDetail object, token usage dict)
        """
        # Extract code
        file_path = project_root / endpoint.file_path
        code = extract_endpoint_code(str(file_path), endpoint.start_line, endpoint.end_line)

        # Build prompt
        prompt = self.EXTRACTION_PROMPT.format(
            code=code,
            file_path=endpoint.file_path,
            function_name=endpoint.function_name,
            method=endpoint.method,
            route=endpoint.route,
            line_number=endpoint.start_line
        )

        # Call LLM
        payload_data, token_usage = self._call_llm(prompt)

        # Extract description for embedding
        description = payload_data.get("description", "")

        # Generate embedding
        embed_vector = self._generate_embedding(description)

        # Build full structure
        full_payload = {
            "path": endpoint.route,
            "method": endpoint.method,
            "file_path": endpoint.file_path,
            "function_name": endpoint.function_name,
            "line_number": endpoint.start_line,
            **payload_data
        }

        detail = EndpointDetail(
            endpoint_id=endpoint.endpoint_id,
            description=description,
            embed=embed_vector,
            payload=full_payload
        )

        return detail, token_usage

    def _call_llm(self, prompt: str) -> tuple:
        """Call LLM to extract information

        Args:
            prompt: Extraction prompt

        Returns:
            Tuple of (parsed JSON response, token usage dict)
        """
        try:
            from ..llm.llm_client import send_llm_request

            payload = {
                "model": self.llm_model,
                "messages": [{"role": "user", "content": prompt}],
                "response_format": {"type": "json_object"},
                "temperature": 0.1,
                "max_tokens": 4096
            }

            response = send_llm_request(
                payload=payload,
                provider=self.llm_provider,
                api_key=self.api_key
            )

            content = response.content

            # Parse JSON
            # Try to extract JSON from markdown code block if present
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                content = content.split("```")[1].split("```")[0].strip()

            parsed_data = json.loads(content)
            token_usage = response.usage or {
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0
            }

            return parsed_data, token_usage

        except Exception as e:
            logger.error(f"LLM call failed: {e}", exc_info=True)
            # Return minimal structure on error
            error_data = {
                "description": "Error extracting details",
                "summary": "Unknown",
                "tags": [],
                "authentication": {"required": False, "type": None},
                "authorization": {"required": False, "roles": [], "permissions": []},
                "parameters": {"path": [], "query": [], "body": {}, "headers": {}},
                "responses": {},
                "business_logic": {"description": "", "steps": [], "dependencies": {}},
                "rate_limiting": {},
                "error_handling": {},
                "examples": {},
                "metadata": {"version": "v1", "deprecated": False, "stability": "unknown"}
            }
            error_usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
            return error_data, error_usage

    def _generate_embedding(self, text: str) -> List[float]:
        """Generate embedding vector for text

        Args:
            text: Text to embed

        Returns:
            Embedding vector with dimension matching self.vector_size
        """
        try:
            vector = None

            if self.embedding_provider == "openai":
                response = self.embedding_client.embeddings.create(
                    model=self.embedding_model,
                    input=text
                )
                vector = response.data[0].embedding

            elif self.embedding_provider == "google":
                result = self.embedding_client.embed_content(
                    model=self.embedding_model,
                    content=text,
                    task_type="retrieval_document"
                )
                vector = result['embedding']

            else:
                # Fallback: return zero vector with correct dimension
                logger.warning(f"Using zero vector ({self.vector_size}D) as embedding fallback")
                return [0.0] * self.vector_size

            # Validate vector dimension
            if vector is not None:
                actual_dim = len(vector)
                if actual_dim != self.vector_size:
                    logger.warning(
                        f"Vector dimension mismatch: got {actual_dim}D, expected {self.vector_size}D. "
                        f"Adjusting vector to match configured size."
                    )
                    # Pad or truncate to match expected dimension
                    if actual_dim < self.vector_size:
                        # Pad with zeros
                        vector = vector + [0.0] * (self.vector_size - actual_dim)
                    else:
                        # Truncate
                        vector = vector[:self.vector_size]

                return vector

        except Exception as e:
            logger.error(f"Embedding generation failed: {e}", exc_info=True)

        # Fallback on any error
        return [0.0] * self.vector_size
