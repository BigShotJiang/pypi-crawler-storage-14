"""Token consumption estimator for LLM API calls."""

from pathlib import Path
from typing import List, Dict
from rich.table import Table
from rich.console import Console

console = Console()


class TokenEstimator:
    """Estimate token consumption for code analysis (no pricing)"""

    def estimate_tokens(self, candidate_files: Dict[str, List[Path]]) -> Dict:
        """Estimate token consumption for processing files

        Args:
            candidate_files: Dictionary of {language: [file_paths]}

        Returns:
            {
                "total_files": 10,
                "total_chars": 50000,
                "estimated_input_tokens": 12500,
                "estimated_output_tokens": 2500,
                "total_tokens": 15000,
                "file_details": [...]
            }
        """
        total_chars = 0
        total_files = 0
        file_details = []

        for language, files in candidate_files.items():
            for file_path in files:
                try:
                    content = file_path.read_text(encoding="utf-8")
                    char_count = len(content)
                    total_chars += char_count
                    total_files += 1

                    file_details.append({
                        "path": str(file_path.name),
                        "full_path": str(file_path),
                        "chars": char_count,
                        "estimated_tokens": char_count // 4
                    })
                except Exception as e:
                    console.print(f"[yellow]⚠️  Error reading {file_path}: {e}[/yellow]")

        # Token estimation: ~4 chars ≈ 1 token (average for English + code)
        estimated_input_tokens = total_chars // 4

        # Assume output is 20% of input (endpoint extraction is concise)
        estimated_output_tokens = estimated_input_tokens // 5

        total_tokens = estimated_input_tokens + estimated_output_tokens

        return {
            "total_files": total_files,
            "total_chars": total_chars,
            "estimated_input_tokens": estimated_input_tokens,
            "estimated_output_tokens": estimated_output_tokens,
            "total_tokens": total_tokens,
            "file_details": file_details
        }

    def display_estimate(self, estimate: Dict, show_details: bool = False):
        """Display token estimation in a nice table

        Args:
            estimate: Estimation dictionary from estimate_tokens()
            show_details: Whether to show per-file breakdown
        """
        # Main summary table
        table = Table(title="📊 Token Usage Estimate", show_header=False)
        table.add_column("Item", style="cyan", width=30)
        table.add_column("Value", style="green")

        table.add_row("Files to process", str(estimate["total_files"]))
        table.add_row("Total characters", f"{estimate['total_chars']:,}")
        table.add_row(
            "Estimated input tokens",
            f"[bold]{estimate['estimated_input_tokens']:,}[/bold]"
        )
        table.add_row(
            "Estimated output tokens",
            f"[bold]{estimate['estimated_output_tokens']:,}[/bold]"
        )
        table.add_row(
            "[bold yellow]Total tokens[/bold yellow]",
            f"[bold yellow]{estimate['total_tokens']:,}[/bold yellow]"
        )

        console.print(table)

        # Optional: show per-file breakdown
        if show_details and estimate.get("file_details"):
            console.print("\n[dim]Detailed breakdown:[/dim]")
            detail_table = Table(show_header=True, header_style="bold magenta")
            detail_table.add_column("File", style="dim", no_wrap=False)
            detail_table.add_column("Tokens", justify="right", style="cyan")

            # Show top 10 files by token count
            sorted_files = sorted(
                estimate["file_details"],
                key=lambda x: x["estimated_tokens"],
                reverse=True
            )

            for file_info in sorted_files[:10]:
                detail_table.add_row(
                    file_info["path"],
                    f"{file_info['estimated_tokens']:,}"
                )

            if len(sorted_files) > 10:
                detail_table.add_row(
                    f"[dim]... and {len(sorted_files) - 10} more files[/dim]",
                    "[dim]...[/dim]"
                )

            console.print(detail_table)
