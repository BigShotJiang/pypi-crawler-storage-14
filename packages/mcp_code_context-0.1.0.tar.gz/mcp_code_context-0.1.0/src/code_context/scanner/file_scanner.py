"""Project file scanner for code-context."""

from pathlib import Path
from typing import List, Dict
from rich.progress import track
from rich.console import Console
from rich.table import Table

console = Console()


class FileScanner:
    """Scan project directories for source code files"""

    # Patterns to exclude from scanning
    EXCLUDED_PATTERNS = [
        "**/node_modules/**",
        "**/.git/**",
        "**/venv/**",
        "**/env/**",
        "**/__pycache__/**",
        "**/dist/**",
        "**/build/**",
        "**/.next/**",
        "**/target/**",  # Rust
        "**/.venv/**",
        "**/vendor/**",  # Go/PHP
        "**/.gradle/**",
        "**/.idea/**",
        "**/.vscode/**",
        "**/out/**",
        "**/*.egg-info/**",
        # Additional virtual environment patterns
        "**/virtualenv/**",
        "**/.virtualenv/**",
        "**/python3.*/**",  # python3.11, python3.12, etc.
        "**/site-packages/**",  # Inside venv
        "**/lib/python*/**",  # Inside venv lib directory
        "**/Scripts/**",  # Windows venv
        "**/bin/python*",  # Unix venv
        "**/.tox/**",  # Tox test environments
        "**/.nox/**",  # Nox test environments
        "**/.pytest_cache/**",
        "**/.mypy_cache/**",
        "**/.ruff_cache/**",
        "**/htmlcov/**",  # Coverage reports
        "**/.coverage/**",
        "**/eggs/**",
        "**/.eggs/**",
        "**/parts/**",
        "**/sdist/**",
        "**/wheels/**",
        "**/*.pyc",
        "**/*.pyo",
        "**/*.pyd",
    ]

    # Language file extensions - only Python for now
    LANGUAGE_EXTENSIONS = {
        "python": [".py"],
    }

    def __init__(self, project_path: Path, max_file_size_kb: int = 500, presenter=None):
        """Initialize file scanner

        Args:
            project_path: Root directory to scan
            max_file_size_kb: Skip files larger than this (default 500KB)
            presenter: Optional ScannerPresenter for UI updates
        """
        self.project_path = Path(project_path)
        self.max_file_size_bytes = max_file_size_kb * 1024
        self.presenter = presenter

        if not self.project_path.exists():
            raise FileNotFoundError(f"Project path does not exist: {project_path}")

        if not self.project_path.is_dir():
            raise NotADirectoryError(f"Path is not a directory: {project_path}")

    def scan_project(self) -> Dict[str, List[Path]]:
        """Scan project and categorize files by language

        Returns:
            Dictionary mapping language to list of file paths
            e.g., {"python": [file1.py, file2.py], "go": [file1.go]}
        """
        # Notify UI that scan is starting
        if self.presenter:
            self.presenter.start_file_scan()

        files_by_language = {lang: [] for lang in self.LANGUAGE_EXTENSIONS.keys()}

        # Get all files
        all_files = list(self.project_path.rglob("*"))

        scanned_count = 0
        skipped_count = 0

        for file_path in all_files:
            # Skip directories
            if not file_path.is_file():
                continue

            # Skip excluded paths
            if self._is_excluded(file_path):
                skipped_count += 1
                continue

            # Skip oversized files
            try:
                file_size = file_path.stat().st_size
                if file_size > self.max_file_size_bytes:
                    skipped_count += 1
                    continue
            except Exception:
                continue

            # Categorize by language
            for lang, extensions in self.LANGUAGE_EXTENSIONS.items():
                if file_path.suffix in extensions:
                    files_by_language[lang].append(file_path)
                    scanned_count += 1
                    break

        # Remove empty language categories
        files_by_language = {lang: files for lang, files in files_by_language.items() if files}

        # Notify UI that scan is complete
        if self.presenter:
            self.presenter.complete_file_scan(scanned_count)

        return files_by_language

    def _is_excluded(self, file_path: Path) -> bool:
        """Check if file matches any exclusion pattern

        Args:
            file_path: Path to check

        Returns:
            True if file should be excluded
        """
        try:
            rel_path = file_path.relative_to(self.project_path)
        except ValueError:
            return True

        for pattern in self.EXCLUDED_PATTERNS:
            if rel_path.match(pattern):
                return True

        return False

    def preprocess_files(self, files: List[Path]) -> List[Path]:
        """Pre-filter files based on rules to exclude unlikely endpoint candidates

        Filters out:
        - Non-.py files
        - Test files (test_*, *_test.*, *.test.*, *.spec.*)
        - Config files (config.*, settings.*, constants.*, const.*)
        - Utils files (utils.*, util.*, helpers.*, helper.*, common.*, shared.*)
        - Migration files (*migration*, *migrate*, *schema*, alembic/, migrations/)
        - Setup/build files (setup.py, __init__.py without content)
        - Files inside venv/cache directories (double-check)

        Args:
            files: List of file paths to filter

        Returns:
            Filtered list of file paths
        """
        filtered = []
        excluded_count = 0

        for f in files:
            name_lower = f.name.lower()
            path_lower = str(f).lower()

            # Only keep .py files
            if not f.suffix == '.py':
                excluded_count += 1
                continue

            # Double-check: exclude if in venv-related paths
            if any(pattern in path_lower for pattern in [
                '/venv/', '/.venv/', '/env/', '/virtualenv/', '/.virtualenv/',
                '/site-packages/', '/lib/python', '/__pycache__/',
                '/.tox/', '/.nox/', '/.pytest_cache/', '/.mypy_cache/', '/.ruff_cache/'
            ]):
                excluded_count += 1
                continue

            # Filter test files
            if any(pattern in name_lower for pattern in [
                'test_', '_test.', '.test.', '.spec.', '_spec.'
            ]):
                excluded_count += 1
                continue

            # Filter config files
            if any(pattern in name_lower for pattern in [
                'config.', 'settings.', 'constants.', 'const.'
            ]):
                excluded_count += 1
                continue

            # Filter utils files
            if any(pattern in name_lower for pattern in [
                'utils.', 'util.', 'helpers.', 'helper.', 'common.', 'shared.'
            ]):
                excluded_count += 1
                continue

            # Filter migration files
            if any(pattern in path_lower for pattern in [
                'migration', 'migrate', 'schema', 'alembic', '/migrations/'
            ]):
                excluded_count += 1
                continue

            # Filter setup/build files
            if name_lower in ['setup.py', 'conftest.py']:
                excluded_count += 1
                continue

            # Filter empty __init__.py files (common in packages)
            if name_lower == '__init__.py':
                try:
                    if f.stat().st_size < 50:  # Less than 50 bytes, likely empty
                        excluded_count += 1
                        continue
                except Exception:
                    pass

            filtered.append(f)

        if excluded_count > 0:
            console.print(
                f"[dim]   Pre-filtered: excluded {excluded_count} files "
                f"(non-py/venv/tests/config/utils/migrations)[/dim]"
            )

        return filtered

    def _display_stats(self, files_by_language: Dict[str, List[Path]], scanned: int, skipped: int):
        """Display scan statistics

        Args:
            files_by_language: Categorized files
            scanned: Number of files scanned
            skipped: Number of files skipped
        """
        table = Table(title="Files Found")
        table.add_column("Language", style="cyan")
        table.add_column("Count", style="green", justify="right")

        total_found = 0
        for lang, files in files_by_language.items():
            if files:
                count = len(files)
                total_found += count
                table.add_row(lang.title(), str(count))

        if total_found > 0:
            console.print(table)

        console.print(f"\n[dim]Total: {scanned} files scanned, {skipped} skipped[/dim]")
