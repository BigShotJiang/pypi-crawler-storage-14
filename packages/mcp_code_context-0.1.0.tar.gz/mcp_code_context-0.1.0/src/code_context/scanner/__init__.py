"""Code scanner module for extracting API endpoints."""

from abc import ABC, abstractmethod
from typing import List
from pathlib import Path

from ..database import Endpoint


class BaseScanner(ABC):
    """Base class for code scanners."""

    @abstractmethod
    def scan_file(self, file_path: Path) -> List[Endpoint]:
        """Scan a single file for endpoints.

        Args:
            file_path: Path to the file to scan

        Returns:
            List of endpoints found in the file
        """
        pass

    @abstractmethod
    def can_handle(self, file_path: Path) -> bool:
        """Check if this scanner can handle the given file.

        Args:
            file_path: Path to check

        Returns:
            True if this scanner can handle the file
        """
        pass

    def scan_directory(self, directory: Path) -> List[Endpoint]:
        """Scan a directory recursively for endpoints.

        Args:
            directory: Directory to scan

        Returns:
            List of all endpoints found
        """
        endpoints = []
        for file_path in directory.rglob("*.py"):
            if self.can_handle(file_path):
                endpoints.extend(self.scan_file(file_path))
        return endpoints
