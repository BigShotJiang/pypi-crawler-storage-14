"""code-context: MCP server for managing API endpoints and code context."""

__version__ = "0.1.0"
__author__ = "Your Name"
__description__ = "MCP server for AI coding assistants to track API endpoints"

from .config import get_config, Config
from .database import QdrantManager, Endpoint

__all__ = ["get_config", "Config", "QdrantManager", "Endpoint"]
