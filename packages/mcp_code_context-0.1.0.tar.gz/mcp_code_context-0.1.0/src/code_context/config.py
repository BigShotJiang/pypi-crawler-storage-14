"""Configuration management for code-context."""

import os
import json
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from rich.console import Console

console = Console()


class Config(BaseSettings):
    """Application configuration."""

    model_config = SettingsConfigDict(
        env_prefix="CODE_CONTEXT_",
        env_file=str(Path.home() / ".code-context" / ".env"),  # 使用固定路径，不读取当前目录的 .env
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Storage paths
    data_dir: Path = Field(
        default_factory=lambda: Path.home() / ".code-context",
        description="Directory for storing data and database",
    )

    # Qdrant settings
    qdrant_path: Optional[Path] = Field(
        default=None,
        description="Path to Qdrant database (defaults to data_dir/db)",
    )
    qdrant_url: Optional[str] = Field(
        default=None,
        description="URL to remote Qdrant server (if using remote mode)",
    )
    qdrant_api_key: Optional[str] = Field(
        default=None,
        description="API key for remote Qdrant server",
    )

    # Collection settings
    collection_name: str = Field(
        default="endpoints",
        description="Name of the Qdrant collection for endpoints",
    )
    vector_size: int = Field(
        default=1536,
        description="Size of embedding vectors (OpenAI default: 1536)",
    )

    # LLM settings (to be configured later)
    llm_provider: Optional[str] = Field(
        default=None,
        description="LLM provider (openai, gemini, anthropic, etc.)",
    )
    llm_api_key: Optional[str] = Field(
        default=None,
        description="API key for LLM provider",
    )
    llm_model: Optional[str] = Field(
        default=None,
        description="Model name to use",
    )

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Ensure data directory exists
        self.data_dir.mkdir(parents=True, exist_ok=True)
        # Set default qdrant path if not specified
        if self.qdrant_path is None and self.qdrant_url is None:
            self.qdrant_path = self.data_dir / "db"

    @property
    def is_remote_qdrant(self) -> bool:
        """Check if using remote Qdrant server."""
        return self.qdrant_url is not None


# Global config instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get or create global config instance."""
    global _config
    if _config is None:
        _config = Config()
    return _config


def set_config(config: Config) -> None:
    """Set global config instance."""
    global _config
    _config = config


class ConfigManager:
    """Manage configuration file for code-context"""

    def __init__(self):
        """Initialize configuration manager"""
        self.config_dir = Path.home() / ".code-context"
        self.config_file = self.config_dir / "config.json"
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def save_config(self, config_data: Dict[str, Any]) -> None:
        """Save configuration to file

        Args:
            config_data: Configuration dictionary from init wizard
        """
        # Build full config structure
        full_config = {
            "version": "0.1.0",
            "llm": {
                "provider": config_data.get("llm_provider"),
                "model": config_data.get("llm_model"),
                "api_key": config_data.get("llm_api_key"),
                "base_url": config_data.get("base_url"),
            },
            "embedding": {
                "provider": config_data.get("embedding_provider", "openai"),
                "model": config_data.get("embedding_model", "text-embedding-3-small"),
                "api_key": config_data.get("embedding_api_key"),
            },
            "qdrant": {
                "mode": "local",
                "path": str(self.config_dir / "db"),
                "url": None,
                "api_key": None
            },
            "preferences": {
                "auto_scan_on_change": False,
                "max_file_size_kb": 500,
                "excluded_patterns": [
                    "**/node_modules/**",
                    "**/.git/**",
                    "**/venv/**",
                    "**/__pycache__/**",
                    "**/dist/**",
                    "**/build/**"
                ]
            },
            "projects": {},
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }

        # Write to file
        with open(self.config_file, 'w') as f:
            json.dump(full_config, f, indent=2)

        # Set restrictive permissions (user read/write only)
        self.config_file.chmod(0o600)

        console.print(f"\n[green]✅ Configuration saved to {self.config_file}[/green]")

    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file

        Returns:
            Configuration dictionary

        Raises:
            FileNotFoundError: If config file doesn't exist
        """
        if not self.config_file.exists():
            raise FileNotFoundError(
                f"Configuration not found at {self.config_file}\n"
                "Please run 'code-context init' first."
            )

        with open(self.config_file, 'r') as f:
            return json.load(f)

    def config_exists(self) -> bool:
        """Check if configuration file exists

        Returns:
            True if config exists
        """
        return self.config_file.exists()

    def update_project_info(self, project_path: str, info: Dict[str, Any]) -> None:
        """Update project information in config

        Args:
            project_path: Path to project
            info: Project information (language, last_scan, endpoint_count, etc.)
        """
        if not self.config_exists():
            return

        config = self.load_config()

        if "projects" not in config:
            config["projects"] = {}

        config["projects"][project_path] = {
            **info,
            "updated_at": datetime.now().isoformat()
        }
        config["updated_at"] = datetime.now().isoformat()

        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=2)

    def get_llm_config(self) -> Dict[str, str]:
        """Get LLM configuration

        Returns:
            Dictionary with provider, model, api_key
        """
        config = self.load_config()
        llm_config = config.get("llm", {})

        return {
            "provider": llm_config.get("provider"),
            "model": llm_config.get("model"),
            "api_key": llm_config.get("api_key"),
            "base_url": llm_config.get("base_url"),
        }
