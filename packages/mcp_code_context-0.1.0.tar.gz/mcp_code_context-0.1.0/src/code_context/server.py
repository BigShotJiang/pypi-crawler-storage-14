"""MCP Server for code-context using FastMCP 2.0."""

from typing import Optional, Dict, Any, List, Union
from fastmcp import FastMCP

from . import tools

# Create FastMCP server instance
mcp = FastMCP("code-context")


@mcp.tool()
def search_endpoint(
    name: Optional[str] = None,
    route: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Search for API endpoints by name or route. If no parameters provided, lists all endpoints.

    Args:
        name: Name of the endpoint to search for (exact match)
        route: Route/path of the endpoint to search for (exact match)

    Returns:
        List of matching endpoints with basic information
    """
    return tools.search_endpoint(name=name, route=route)


@mcp.tool()
def add_endpoint(
    name: str,
    route: str,
    method: str,
    file_path: str,
    description: Optional[str] = None,
    headers: Optional[Dict[str, Any]] = None,
    parameters: Optional[Dict[str, Any]] = None,
    request_body: Optional[Dict[str, Any]] = None,
    response_code: Optional[int] = None,
    response_type: Optional[str] = None,
    response_format: Optional[Dict[str, Any]] = None,
    framework: Optional[str] = None,
    language: Optional[str] = None,
) -> Dict[str, str]:
    """Manually add a new API endpoint to the database.

    Args:
        name: Name/identifier for the endpoint
        route: API route/path (e.g., /api/users/:id)
        method: HTTP method (GET, POST, PUT, DELETE, etc.)
        file_path: Path to the source code file
        description: Description of what this endpoint does
        headers: Required headers specification
        parameters: URL/query parameters specification
        request_body: Request body format
        response_code: Expected response code (e.g., 200, 201)
        response_type: Response content type (e.g., application/json)
        response_format: Response body format
        framework: Web framework name (e.g., FastAPI, Flask)
        language: Programming language (e.g., Python, Go)

    Returns:
        Dictionary with the created endpoint ID and success message
    """
    return tools.add_endpoint(
        name=name,
        route=route,
        method=method,
        file_path=file_path,
        description=description,
        headers=headers,
        parameters=parameters,
        request_body=request_body,
        response_code=response_code,
        response_type=response_type,
        response_format=response_format,
        framework=framework,
        language=language,
    )


@mcp.tool()
def scan_codebase(
    directory: str,
    language: str = "python"
) -> Dict[str, Any]:
    """Scan a directory for API endpoints automatically.

    Args:
        directory: Path to the directory to scan
        language: Programming language (default: python)

    Returns:
        Dictionary with scan results including endpoints found and added
    """
    return tools.scan_codebase(directory=directory, language=language)


@mcp.tool()
def update_endpoint(
    endpoint_id: str,
    name: Optional[str] = None,
    route: Optional[str] = None,
    method: Optional[str] = None,
    file_path: Optional[str] = None,
    description: Optional[str] = None,
    headers: Optional[Dict[str, Any]] = None,
    parameters: Optional[Dict[str, Any]] = None,
    request_body: Optional[Dict[str, Any]] = None,
    response_code: Optional[int] = None,
    response_type: Optional[str] = None,
    response_format: Optional[Dict[str, Any]] = None,
    framework: Optional[str] = None,
    language: Optional[str] = None,
) -> Dict[str, str]:
    """Update an existing endpoint.

    Args:
        endpoint_id: ID of the endpoint to update
        name: New name for the endpoint
        route: New route/path
        method: New HTTP method
        file_path: New file path
        description: New description
        headers: New headers specification
        parameters: New parameters specification
        request_body: New request body format
        response_code: New response code
        response_type: New response type
        response_format: New response format
        framework: New framework name
        language: New programming language

    Returns:
        Dictionary with update status
    """
    # Build updates dict from provided arguments
    updates = {}
    if name is not None:
        updates["name"] = name
    if route is not None:
        updates["route"] = route
    if method is not None:
        updates["method"] = method
    if file_path is not None:
        updates["file_path"] = file_path
    if description is not None:
        updates["description"] = description
    if headers is not None:
        updates["headers"] = headers
    if parameters is not None:
        updates["parameters"] = parameters
    if request_body is not None:
        updates["request_body"] = request_body
    if response_code is not None:
        updates["response_code"] = response_code
    if response_type is not None:
        updates["response_type"] = response_type
    if response_format is not None:
        updates["response_format"] = response_format
    if framework is not None:
        updates["framework"] = framework
    if language is not None:
        updates["language"] = language

    return tools.update_endpoint(endpoint_id=endpoint_id, **updates)


@mcp.tool()
def delete_endpoint(endpoint_id: str) -> Dict[str, str]:
    """Delete an endpoint from the database.

    Args:
        endpoint_id: ID of the endpoint to delete

    Returns:
        Dictionary with deletion status
    """
    return tools.delete_endpoint(endpoint_id=endpoint_id)


@mcp.tool()
def list_endpoints(limit: int = 100) -> List[Dict[str, Any]]:
    """List all stored endpoints.

    Args:
        limit: Maximum number of endpoints to return (default: 100)

    Returns:
        List of all endpoints with basic information
    """
    return tools.list_endpoints(limit=limit)


@mcp.tool()
def semantic_search_endpoints(
    query: str,
    limit: int = 10
) -> Union[List[Dict[str, Any]], Dict[str, str]]:
    """Perform semantic search on endpoints using natural language queries.

    Args:
        query: Natural language query (e.g., "user authentication endpoints")
        limit: Maximum number of results to return

    Returns:
        List of matching endpoints with similarity scores, or error dict if service not configured
    """
    return tools.semantic_search_endpoints(query=query, limit=limit)


@mcp.tool()
def filter_endpoints(
    method: Optional[str] = None,
    framework: Optional[str] = None,
    language: Optional[str] = None,
    limit: int = 100
) -> List[Dict[str, Any]]:
    """Filter endpoints by multiple conditions.

    Args:
        method: HTTP method to filter by (e.g., GET, POST)
        framework: Framework to filter by (e.g., FastAPI, Flask)
        language: Programming language to filter by (e.g., Python, Go)
        limit: Maximum number of results to return

    Returns:
        List of matching endpoints
    """
    return tools.filter_endpoints(
        method=method,
        framework=framework,
        language=language,
        limit=limit
    )


@mcp.tool()
def search_endpoints_by_keyword(
    keyword: str,
    limit: int = 50
) -> List[Dict[str, Any]]:
    """Search endpoints by keyword across multiple fields (fuzzy search).

    Args:
        keyword: Keyword to search for in name, route, description
        limit: Maximum number of results to return

    Returns:
        List of matching endpoints
    """
    return tools.search_endpoints_by_keyword(keyword=keyword, limit=limit)


@mcp.tool()
def get_endpoint_details(endpoint_id: str) -> Dict[str, Any]:
    """Get full details for a specific endpoint by ID.

    Args:
        endpoint_id: ID of the endpoint

    Returns:
        Full endpoint details including all fields
    """
    return tools.get_endpoint_details(endpoint_id=endpoint_id)


@mcp.tool()
def get_api_statistics() -> Dict[str, Any]:
    """Get comprehensive statistics about stored API endpoints.

    Returns:
        Dictionary with statistics including total count and breakdowns
    """
    return tools.get_api_statistics()


@mcp.tool()
def list_all_collections() -> List[str]:
    """List all available collections.

    Returns:
        List of collection names
    """
    return tools.list_all_collections()


@mcp.tool()
def get_collection_info(name: Optional[str] = None) -> Dict[str, Any]:
    """Get information about a specific collection.

    Args:
        name: Collection name (uses default if not provided)

    Returns:
        Dictionary with collection information (name, vector_size, distance, count)
    """
    return tools.get_collection_info_tool(name=name)


# Entry point for MCP server
def main(port: int = 18765):
    """Run the MCP server in SSE (HTTP) mode with logging.

    Args:
        port: Port to run the server on (default: 18765)
    """
    import signal
    import sys
    import logging
    from pathlib import Path

    # Setup logging to file
    log_dir = Path.home() / ".code-context"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "server.log"

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stderr),  # Also log to stderr for debugging
        ],
    )

    logger = logging.getLogger(__name__)

    # Check if server is already running (singleton check)
    pid_file = log_dir / "server.pid"
    if pid_file.exists():
        try:
            with open(pid_file, "r") as f:
                existing_pid = int(f.read().strip())

            # Check if process is still running
            import os
            os.kill(existing_pid, 0)  # This will raise OSError if process doesn't exist

            # Process exists - server already running
            logger.info(f"MCP server already running (PID: {existing_pid})")
            logger.info("Exiting to avoid duplicate instances")
            print(f"✓ MCP server already running (PID: {existing_pid})", file=sys.stderr)
            print(f"   To stop: code-context server-stop", file=sys.stderr)
            sys.exit(0)

        except (OSError, ValueError, ProcessLookupError):
            # Process doesn't exist or invalid PID - clean up stale PID file
            logger.info("Removing stale PID file")
            pid_file.unlink()

    # Write PID file for server-stop command
    with open(pid_file, "w") as f:
        import os
        f.write(str(os.getpid()))

    logger.info("=" * 60)
    logger.info("Code-Context MCP Server Starting (SSE Mode)")
    logger.info("=" * 60)
    logger.info(f"Log file: {log_file}")
    logger.info(f"PID: {os.getpid()}")
    logger.info(f"Port: {port}")
    logger.info(f"URL: http://localhost:{port}/sse")

    # Setup graceful shutdown
    shutdown_requested = False

    def signal_handler(signum, frame):
        """Handle shutdown signals gracefully."""
        nonlocal shutdown_requested
        if shutdown_requested:
            logger.warning("Force quit requested, exiting immediately...")
            sys.exit(1)

        shutdown_requested = True
        logger.info("Shutdown signal received, performing graceful shutdown...")
        logger.info("Step 1/4: Stopping MCP server")

        # Perform graceful shutdown
        try:
            logger.info("Step 2/4: Waiting for pending requests")
            import time
            time.sleep(0.5)

            logger.info("Step 3/4: Syncing Qdrant memory to disk")
            from .tools import close_db_manager
            close_db_manager()

            logger.info("Step 4/4: Cleanup complete")
            logger.info("✅ Graceful shutdown complete")

        except Exception as e:
            logger.error(f"Error during shutdown: {e}", exc_info=True)
        finally:
            # Remove PID file
            try:
                pid_file.unlink()
            except:
                pass
            sys.exit(0)

    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Load endpoints to memory
    try:
        from .tools import get_db_manager
        db = get_db_manager()
        endpoints = db.list_all_endpoints(limit=10000)
        logger.info(f"📊 Loaded {len(endpoints)} endpoints to memory")
    except Exception as e:
        logger.error(f"Failed to load endpoints: {e}", exc_info=True)

    # Print startup info to console
    print(f"🚀 Code-Context MCP Server", file=sys.stderr)
    print(f"   Port: {port}", file=sys.stderr)
    print(f"   URL: http://localhost:{port}/sse", file=sys.stderr)
    print(f"   Endpoints: {len(endpoints) if 'endpoints' in locals() else 'N/A'}", file=sys.stderr)
    print(f"   Logs: {log_file}", file=sys.stderr)
    print(f"", file=sys.stderr)
    print(f"   To stop: code-context server-stop", file=sys.stderr)
    print(f"   To view logs: code-context server-logs -f", file=sys.stderr)
    print(f"", file=sys.stderr)

    logger.info(f"🚀 FastMCP server ready - accepting SSE connections on port {port}")

    # Run FastMCP server in SSE mode (blocking)
    try:
        mcp.run(transport="sse", port=port)
    except KeyboardInterrupt:
        logger.info("KeyboardInterrupt caught, initiating shutdown...")
        signal_handler(signal.SIGINT, None)
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        raise
    finally:
        # Cleanup
        try:
            pid_file.unlink()
        except:
            pass


if __name__ == "__main__":
    main()
