"""Qdrant vector database manager."""

from typing import Optional, List, Dict, Any
from pathlib import Path
from dataclasses import dataclass, asdict
import uuid
import logging

from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance,
    VectorParams,
    PointStruct,
    Filter,
    FieldCondition,
    MatchValue,
)

from ..config import get_config

logger = logging.getLogger(__name__)


@dataclass
class Endpoint:
    """Endpoint data model."""

    id: str
    name: str
    route: str
    method: str
    file_path: str
    description: Optional[str] = None
    headers: Optional[Dict[str, Any]] = None
    parameters: Optional[Dict[str, Any]] = None
    request_body: Optional[Dict[str, Any]] = None
    response_code: Optional[int] = None
    response_type: Optional[str] = None
    response_format: Optional[Dict[str, Any]] = None
    framework: Optional[str] = None
    language: Optional[str] = None

    def to_payload(self) -> Dict[str, Any]:
        """Convert to Qdrant payload format."""
        return {k: v for k, v in asdict(self).items() if k != "id"}


class QdrantManager:
    """Manager for Qdrant vector database operations with optional memory mode."""

    def __init__(self, config=None, use_memory: bool = False):
        """Initialize Qdrant manager.

        Args:
            config: Optional config instance. If not provided, uses global config.
            use_memory: If True, uses :memory: mode for faster queries with write-through to disk
        """
        self.config = config or get_config()
        self.use_memory = use_memory
        self._disk_client: Optional[QdrantClient] = None
        self._memory_client: Optional[QdrantClient] = None

        # Initialize connection and ensure collection exists
        self._ensure_collection()

        # If using memory mode, load data from disk to memory
        if self.use_memory:
            self._load_from_disk()
            logger.info("QdrantManager initialized (:memory: mode with write-through)")
        else:
            logger.info("QdrantManager initialized (local file mode)")

    @property
    def disk_client(self) -> QdrantClient:
        """Get or create disk-based Qdrant client."""
        if self._disk_client is None:
            if self.config.is_remote_qdrant:
                self._disk_client = QdrantClient(
                    url=self.config.qdrant_url,
                    api_key=self.config.qdrant_api_key,
                )
            else:
                self._disk_client = QdrantClient(path=str(self.config.qdrant_path))
        return self._disk_client

    @property
    def memory_client(self) -> QdrantClient:
        """Get or create in-memory Qdrant client."""
        if self._memory_client is None:
            self._memory_client = QdrantClient(":memory:")
        return self._memory_client

    @property
    def client(self) -> QdrantClient:
        """Get the appropriate client (memory if enabled, otherwise disk)."""
        if self.use_memory:
            return self.memory_client
        return self.disk_client

    def _ensure_collection(self) -> None:
        """Ensure collection exists on both disk and memory (if applicable)."""
        # Ensure disk collection exists
        disk_collections = self.disk_client.get_collections().collections
        disk_collection_names = [c.name for c in disk_collections]

        if self.config.collection_name not in disk_collection_names:
            self.disk_client.create_collection(
                collection_name=self.config.collection_name,
                vectors_config=VectorParams(
                    size=self.config.vector_size,
                    distance=Distance.COSINE,
                ),
            )

        # If using memory mode, ensure memory collection exists
        if self.use_memory:
            memory_collections = self.memory_client.get_collections().collections
            memory_collection_names = [c.name for c in memory_collections]

            if self.config.collection_name not in memory_collection_names:
                self.memory_client.create_collection(
                    collection_name=self.config.collection_name,
                    vectors_config=VectorParams(
                        size=self.config.vector_size,
                        distance=Distance.COSINE,
                    ),
                )

    def _load_from_disk(self) -> None:
        """Load all data from disk to memory on startup."""
        try:
            # Get all points from disk
            offset = None
            batch_size = 100
            total_loaded = 0

            while True:
                result = self.disk_client.scroll(
                    collection_name=self.config.collection_name,
                    limit=batch_size,
                    offset=offset,
                    with_vectors=True,
                    with_payload=True,
                )

                points, next_offset = result

                if not points:
                    break

                # Convert to PointStruct for upsert
                point_structs = [
                    PointStruct(
                        id=point.id,
                        vector=point.vector,
                        payload=point.payload,
                    )
                    for point in points
                ]

                # Upsert to memory
                self.memory_client.upsert(
                    collection_name=self.config.collection_name,
                    points=point_structs,
                )

                total_loaded += len(points)
                offset = next_offset

                if next_offset is None:
                    break

            logger.info(f"Loaded {total_loaded} endpoints from disk to memory")

        except Exception as e:
            logger.error(f"Failed to load data from disk to memory: {e}")
            raise

    def _sync_to_disk(self, points: List[PointStruct] = None, delete_ids: List[str] = None) -> None:
        """Sync changes from memory to disk (write-through).

        Args:
            points: Points to upsert to disk (if any)
            delete_ids: Point IDs to delete from disk (if any)
        """
        if not self.use_memory:
            # No need to sync if not using memory mode
            return

        try:
            if points:
                self.disk_client.upsert(
                    collection_name=self.config.collection_name,
                    points=points,
                )
                logger.debug(f"Synced {len(points)} points to disk")

            if delete_ids:
                self.disk_client.delete(
                    collection_name=self.config.collection_name,
                    points_selector=delete_ids,
                )
                logger.debug(f"Synced deletion of {len(delete_ids)} points to disk")

        except Exception as e:
            logger.error(f"Failed to sync to disk: {e}")
            raise

    def add_endpoint(
        self, endpoint: Endpoint, vector: Optional[List[float]] = None
    ) -> str:
        """Add an endpoint to the database.

        Args:
            endpoint: Endpoint data
            vector: Optional embedding vector. If not provided, uses zero vector.

        Returns:
            ID of the added endpoint
        """
        if vector is None:
            # Placeholder: use zero vector until LLM integration is added
            vector = [0.0] * self.config.vector_size

        point = PointStruct(
            id=endpoint.id,
            vector=vector,
            payload=endpoint.to_payload(),
        )

        self.client.upsert(
            collection_name=self.config.collection_name,
            points=[point],
        )

        # Sync to disk if using memory mode
        self._sync_to_disk(points=[point])

        return endpoint.id

    def get_endpoint(self, endpoint_id: str) -> Optional[Endpoint]:
        """Get endpoint by ID.

        Args:
            endpoint_id: Endpoint ID

        Returns:
            Endpoint if found, None otherwise
        """
        results = self.client.retrieve(
            collection_name=self.config.collection_name,
            ids=[endpoint_id],
        )

        if not results:
            return None

        point = results[0]
        return Endpoint(id=str(point.id), **point.payload)

    def search_by_name(self, name: str) -> List[Endpoint]:
        """Search endpoints by exact name match.

        Args:
            name: Endpoint name to search for

        Returns:
            List of matching endpoints
        """
        results = self.client.scroll(
            collection_name=self.config.collection_name,
            scroll_filter=Filter(
                must=[FieldCondition(key="name", match=MatchValue(value=name))]
            ),
            limit=100,
        )

        endpoints = []
        for point in results[0]:
            endpoints.append(Endpoint(id=str(point.id), **point.payload))

        return endpoints

    def search_by_route(self, route: str) -> List[Endpoint]:
        """Search endpoints by route.

        Args:
            route: Route pattern to search for

        Returns:
            List of matching endpoints
        """
        results = self.client.scroll(
            collection_name=self.config.collection_name,
            scroll_filter=Filter(
                must=[FieldCondition(key="route", match=MatchValue(value=route))]
            ),
            limit=100,
        )

        endpoints = []
        for point in results[0]:
            endpoints.append(Endpoint(id=str(point.id), **point.payload))

        return endpoints

    def semantic_search(
        self, query_vector: List[float], limit: int = 10
    ) -> List[Endpoint]:
        """Semantic search using vector similarity.

        Args:
            query_vector: Query embedding vector
            limit: Maximum number of results

        Returns:
            List of similar endpoints
        """
        results = self.client.search(
            collection_name=self.config.collection_name,
            query_vector=query_vector,
            limit=limit,
        )

        endpoints = []
        for result in results:
            endpoints.append(Endpoint(id=str(result.id), **result.payload))

        return endpoints

    def update_endpoint(
        self, endpoint_id: str, updates: Dict[str, Any], vector: Optional[List[float]] = None
    ) -> bool:
        """Update an endpoint.

        Args:
            endpoint_id: ID of endpoint to update
            updates: Dictionary of fields to update
            vector: Optional new embedding vector

        Returns:
            True if successful, False if endpoint not found
        """
        # Get existing endpoint
        existing = self.get_endpoint(endpoint_id)
        if not existing:
            return False

        # Update fields
        payload = existing.to_payload()
        payload.update(updates)

        # Use existing vector if not provided
        if vector is None:
            vector = [0.0] * self.config.vector_size

        point = PointStruct(
            id=endpoint_id,
            vector=vector,
            payload=payload,
        )

        self.client.upsert(
            collection_name=self.config.collection_name,
            points=[point],
        )

        # Sync to disk if using memory mode
        self._sync_to_disk(points=[point])

        return True

    def delete_endpoint(self, endpoint_id: str) -> bool:
        """Delete an endpoint.

        Args:
            endpoint_id: ID of endpoint to delete

        Returns:
            True if successful
        """
        self.client.delete(
            collection_name=self.config.collection_name,
            points_selector=[endpoint_id],
        )

        # Sync to disk if using memory mode
        self._sync_to_disk(delete_ids=[endpoint_id])

        return True

    def list_all_endpoints(self, limit: int = 1000) -> List[Endpoint]:
        """List all endpoints.

        Args:
            limit: Maximum number of endpoints to return

        Returns:
            List of all endpoints
        """
        results = self.client.scroll(
            collection_name=self.config.collection_name,
            limit=limit,
        )

        endpoints = []
        for point in results[0]:
            endpoints.append(Endpoint(id=str(point.id), **point.payload))

        return endpoints

    # New methods for enhanced functionality

    def create_collection(
        self, name: str, vector_size: Optional[int] = None, distance: str = "COSINE"
    ) -> bool:
        """Create a new collection.

        Args:
            name: Collection name
            vector_size: Dimension of vectors (defaults to config.vector_size)
            distance: Distance metric ("COSINE", "EUCLID", "DOT")

        Returns:
            True if successful
        """
        distance_map = {
            "COSINE": Distance.COSINE,
            "EUCLID": Distance.EUCLID,
            "DOT": Distance.DOT,
        }

        # Use config vector size if not provided
        if vector_size is None:
            vector_size = self.config.vector_size

        self.client.create_collection(
            collection_name=name,
            vectors_config=VectorParams(
                size=vector_size,
                distance=distance_map.get(distance, Distance.COSINE),
            ),
        )

        logger.info(f"Collection '{name}' created successfully")
        return True

    def delete_collection(self, name: str) -> bool:
        """Delete a collection.

        Args:
            name: Collection name

        Returns:
            True if successful
        """
        self.client.delete_collection(collection_name=name)

        logger.info(f"Collection '{name}' deleted successfully")
        return True

    def get_collection_info(self, name: Optional[str] = None) -> Dict[str, Any]:
        """Get collection information.

        Args:
            name: Collection name (uses default if None)

        Returns:
            Dictionary with collection information
        """
        collection_name = name or self.config.collection_name

        info = self.client.get_collection(collection_name)
        count = self.client.count(collection_name)

        return {
            "name": collection_name,
            "vector_size": info.config.params.vectors.size,
            "distance": str(info.config.params.vectors.distance),
            "points_count": count.count,
        }

    def list_all_collections(self) -> List[str]:
        """List all collection names.

        Returns:
            List of collection names
        """
        collections = self.client.get_collections()
        return [col.name for col in collections.collections]

    def bulk_add_endpoints(
        self, endpoints: List[Endpoint], vectors: List[List[float]],
        collection_name: Optional[str] = None
    ) -> List[str]:
        """Bulk add endpoints (more efficient than individual adds).

        Args:
            endpoints: List of Endpoint objects
            vectors: List of embedding vectors (same length as endpoints)
            collection_name: Optional collection name to use (defaults to config)

        Returns:
            List of endpoint IDs

        Raises:
            ValueError: If endpoints and vectors lengths don't match
        """
        if len(endpoints) != len(vectors):
            raise ValueError(
                f"Endpoints ({len(endpoints)}) and vectors ({len(vectors)}) must have same length"
            )

        BATCH_SIZE = 100  # Qdrant recommended batch size
        endpoint_ids = []
        all_points = []  # Collect all points for final sync

        # Process in batches
        for i in range(0, len(endpoints), BATCH_SIZE):
            batch_endpoints = endpoints[i : i + BATCH_SIZE]
            batch_vectors = vectors[i : i + BATCH_SIZE]

            points = [
                PointStruct(
                    id=ep.id,
                    vector=vec,
                    payload=ep.to_payload(),
                )
                for ep, vec in zip(batch_endpoints, batch_vectors)
            ]

            self.client.upsert(
                collection_name=collection_name or self.config.collection_name,
                points=points,
            )

            batch_ids = [ep.id for ep in batch_endpoints]
            endpoint_ids.extend(batch_ids)
            all_points.extend(points)

            logger.debug(
                f"Batch {i // BATCH_SIZE + 1}: added {len(batch_ids)} endpoints"
            )

        # Sync all points to disk if using memory mode
        self._sync_to_disk(points=all_points)

        logger.info(f"Bulk add complete: {len(endpoint_ids)} endpoints added")
        return endpoint_ids

    def batch_delete_endpoints(self, endpoint_ids: List[str]) -> bool:
        """Delete multiple endpoints in batch.

        Args:
            endpoint_ids: List of endpoint IDs to delete

        Returns:
            True if successful
        """
        self.client.delete(
            collection_name=self.config.collection_name,
            points_selector=endpoint_ids,
        )

        # Sync to disk if using memory mode
        self._sync_to_disk(delete_ids=endpoint_ids)

        logger.info(f"Batch delete complete: {len(endpoint_ids)} endpoints deleted")
        return True

    def ping(self) -> bool:
        """Check if Qdrant is accessible.

        Returns:
            True if accessible, False otherwise
        """
        try:
            self.client.get_collections()
            return True
        except Exception as e:
            logger.error(f"Ping failed: {e}")
            return False

    def close(self) -> None:
        """Close client connections."""
        if self._disk_client:
            self._disk_client = None
        if self._memory_client:
            self._memory_client = None
        logger.info("Client connections closed")
