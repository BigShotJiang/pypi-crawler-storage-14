"""Project root detection and type identification."""

from pathlib import Path
from typing import Optional, Dict, List
from rich.console import Console

console = Console()


# Project marker files for different types
PROJECT_MARKERS = {
    "python": ["pyproject.toml", "setup.py", "requirements.txt", "Pipfile", "setup.cfg"],
    "javascript": ["package.json", "package-lock.json", "yarn.lock"],
    "typescript": ["tsconfig.json", "package.json"],
    "go": ["go.mod", "go.sum"],
    "rust": ["Cargo.toml", "Cargo.lock"],
    "java": ["pom.xml", "build.gradle", "build.gradle.kts"],
    "ruby": ["Gemfile", "Gemfile.lock"],
    "php": ["composer.json", "composer.lock"],
}

# Version control markers (highest priority)
VCS_MARKERS = [".git", ".hg", ".svn"]


def find_project_root(start_path: Optional[Path] = None, max_depth: int = 5) -> Path:
    """Automatically detect project root directory

    Searches upward from start_path for project marker files:
    - Version control directories (.git, etc.)
    - Language-specific manifest files (pyproject.toml, package.json, etc.)

    Args:
        start_path: Starting directory (default: current working directory)
        max_depth: Maximum number of parent directories to search

    Returns:
        Path to detected project root, or start_path if not found
    """
    if start_path is None:
        start_path = Path.cwd()

    current = start_path.resolve()

    # Collect all marker files to search for
    all_markers = VCS_MARKERS.copy()
    for markers in PROJECT_MARKERS.values():
        all_markers.extend(markers)

    # Search upward
    for _ in range(max_depth):
        # Check for version control first (highest priority)
        for vcs in VCS_MARKERS:
            if (current / vcs).exists():
                return current

        # Check for project markers
        for marker in all_markers:
            if (current / marker).exists():
                return current

        # Reached filesystem root
        if current.parent == current:
            break

        current = current.parent

    # No project root found, return original path
    return start_path


def detect_project_type(project_path: Path) -> Optional[str]:
    """Detect project type based on marker files

    Args:
        project_path: Path to project directory

    Returns:
        Project type string (e.g., "python", "javascript") or None
    """
    detected_types = []

    for lang, markers in PROJECT_MARKERS.items():
        for marker in markers:
            if (project_path / marker).exists():
                detected_types.append(lang)
                break

    # Return first detected type, or None
    return detected_types[0] if detected_types else None


def get_project_info(project_path: Path) -> Dict[str, any]:
    """Get comprehensive project information

    Args:
        project_path: Path to project directory

    Returns:
        Dictionary with project information
    """
    project_type = detect_project_type(project_path)

    # Count files
    all_files = list(project_path.rglob("*"))
    total_files = sum(1 for f in all_files if f.is_file())

    # Count source files by type
    source_counts = {}
    extensions = {
        "python": [".py"],
        "javascript": [".js", ".jsx"],
        "typescript": [".ts", ".tsx"],
        "go": [".go"],
        "rust": [".rs"],
        "java": [".java"],
    }

    for lang, exts in extensions.items():
        count = sum(1 for f in all_files if f.is_file() and f.suffix in exts)
        if count > 0:
            source_counts[lang] = count

    # Check for VCS
    has_vcs = None
    for vcs in VCS_MARKERS:
        if (project_path / vcs).exists():
            has_vcs = vcs.lstrip(".")
            break

    return {
        "path": str(project_path),
        "type": project_type,
        "total_files": total_files,
        "source_counts": source_counts,
        "vcs": has_vcs,
    }


def display_project_info(info: Dict[str, any]) -> None:
    """Display project information in a nice format

    Args:
        info: Project info dictionary from get_project_info()
    """
    from rich.table import Table

    console.print(f"\n[cyan]📍 Project: {info['path']}[/cyan]")

    details = []

    if info.get("type"):
        details.append(f"[dim]Type:[/dim] {info['type'].title()}")

    if info.get("vcs"):
        details.append(f"[dim]VCS:[/dim] {info['vcs']}")

    if info.get("total_files"):
        details.append(f"[dim]Total files:[/dim] {info['total_files']}")

    if info.get("source_counts"):
        source_summary = ", ".join(
            f"{count} {lang}" for lang, count in info["source_counts"].items()
        )
        details.append(f"[dim]Source files:[/dim] {source_summary}")

    for detail in details:
        console.print(f"   {detail}")

    console.print()
