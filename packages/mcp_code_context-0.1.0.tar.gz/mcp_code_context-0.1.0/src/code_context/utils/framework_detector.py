"""Backend framework detection for code-context."""

from pathlib import Path
from typing import List, Set
import json
import re
from rich.console import Console

console = Console()


class FrameworkDetector:
    """Detect backend frameworks used in a project"""

    # Python frameworks and their package names
    PYTHON_FRAMEWORKS = {
        "fastapi": ["fastapi"],
        "flask": ["flask"],
        "django": ["django"],
        "sanic": ["sanic"],
        "tornado": ["tornado"],
        "starlette": ["starlette"],
        "aiohttp": ["aiohttp"],
    }

    # JavaScript/TypeScript frameworks
    JS_FRAMEWORKS = {
        "express": ["express"],
        "koa": ["koa", "@koa/router"],
        "nestjs": ["@nestjs/core", "@nestjs/common"],
        "fastify": ["fastify"],
        "hapi": ["@hapi/hapi"],
    }

    def __init__(self, project_root: Path):
        """Initialize framework detector

        Args:
            project_root: Root directory of the project
        """
        self.project_root = Path(project_root)

    def detect_frameworks(self) -> List[str]:
        """Detect all backend frameworks used in the project

        Returns:
            List of detected framework names
        """
        frameworks: Set[str] = set()

        # Detect Python frameworks
        python_frameworks = self._detect_python_frameworks()
        frameworks.update(python_frameworks)

        # Detect JavaScript/TypeScript frameworks
        js_frameworks = self._detect_js_frameworks()
        frameworks.update(js_frameworks)

        return sorted(list(frameworks))

    def _detect_python_frameworks(self) -> Set[str]:
        """Detect Python frameworks from requirements files

        Returns:
            Set of detected Python framework names
        """
        frameworks = set()

        # Check requirements.txt
        req_file = self.project_root / "requirements.txt"
        if req_file.exists():
            content = req_file.read_text().lower()
            for framework, packages in self.PYTHON_FRAMEWORKS.items():
                if any(pkg in content for pkg in packages):
                    frameworks.add(framework)

        # Check pyproject.toml
        pyproject_file = self.project_root / "pyproject.toml"
        if pyproject_file.exists():
            content = pyproject_file.read_text().lower()
            for framework, packages in self.PYTHON_FRAMEWORKS.items():
                if any(pkg in content for pkg in packages):
                    frameworks.add(framework)

        # Check setup.py
        setup_file = self.project_root / "setup.py"
        if setup_file.exists():
            content = setup_file.read_text().lower()
            for framework, packages in self.PYTHON_FRAMEWORKS.items():
                if any(pkg in content for pkg in packages):
                    frameworks.add(framework)

        # Check Pipfile
        pipfile = self.project_root / "Pipfile"
        if pipfile.exists():
            content = pipfile.read_text().lower()
            for framework, packages in self.PYTHON_FRAMEWORKS.items():
                if any(pkg in content for pkg in packages):
                    frameworks.add(framework)

        return frameworks

    def _detect_js_frameworks(self) -> Set[str]:
        """Detect JavaScript/TypeScript frameworks from package.json

        Returns:
            Set of detected JS framework names
        """
        frameworks = set()

        package_json = self.project_root / "package.json"
        if not package_json.exists():
            return frameworks

        try:
            data = json.loads(package_json.read_text())

            # Combine dependencies and devDependencies
            all_deps = {}
            all_deps.update(data.get("dependencies", {}))
            all_deps.update(data.get("devDependencies", {}))

            # Check for frameworks
            for framework, packages in self.JS_FRAMEWORKS.items():
                if any(pkg in all_deps for pkg in packages):
                    frameworks.add(framework)

        except (json.JSONDecodeError, Exception) as e:
            console.print(f"[yellow]⚠️  Could not parse package.json: {e}[/yellow]")

        return frameworks

    def get_framework_info(self, framework: str) -> dict:
        """Get information about a specific framework

        Args:
            framework: Framework name

        Returns:
            Dictionary with framework information
        """
        framework_info = {
            "fastapi": {
                "language": "python",
                "decorator_patterns": ["@router.", "@app."],
                "endpoint_patterns": ["get", "post", "put", "delete", "patch"],
            },
            "flask": {
                "language": "python",
                "decorator_patterns": ["@app.route", "@blueprint.route"],
                "endpoint_patterns": ["route"],
            },
            "django": {
                "language": "python",
                "decorator_patterns": [],
                "endpoint_patterns": ["path", "url"],
                "special": "url_routing",  # Django uses URL routing files
            },
            "express": {
                "language": "javascript",
                "decorator_patterns": [],
                "endpoint_patterns": ["app.get", "app.post", "router.get", "router.post"],
            },
            "nestjs": {
                "language": "typescript",
                "decorator_patterns": ["@Get", "@Post", "@Put", "@Delete", "@Patch"],
                "endpoint_patterns": ["controller"],
            },
        }

        return framework_info.get(framework, {})
