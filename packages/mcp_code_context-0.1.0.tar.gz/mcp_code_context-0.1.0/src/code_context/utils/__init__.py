"""Utility functions for code-context."""

from .project_detector import find_project_root, detect_project_type
from .framework_detector import FrameworkDetector

__all__ = ["find_project_root", "detect_project_type", "FrameworkDetector"]
