"""Parsing screen for code-context - Simplified version."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal, ScrollableContainer
from textual.widgets import Static, Button, DataTable, ProgressBar
from textual.reactive import reactive
from pathlib import Path
from typing import Dict, List
import threading
import logging
import time

logger = logging.getLogger(__name__)


class ParsingScreen(Screen):
    """Parsing screen - automatically parses endpoints and shows results"""

    # Reactive properties for thread-safe updates
    parsing_status = reactive("")
    parsing_progress = reactive(0)
    stats_text = reactive("")
    extraction_status = reactive("")
    extraction_progress = reactive(0)

    CSS = """
    ParsingScreen {
        align: center middle;
    }

    #parsing-container {
        width: 90;
        height: auto;
        max-height: 50;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    #status-text {
        width: 100%;
        margin-bottom: 1;
    }

    #progress-bar {
        width: 100%;
        margin-bottom: 2;
    }

    #stats-panel {
        width: 100%;
        border: solid $success;
        padding: 1;
        margin-bottom: 2;
        min-height: 8;
    }

    #endpoints-panel {
        width: 100%;
        height: 25;
        border: solid $accent;
        padding: 1;
        margin-bottom: 2;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    Button {
        margin: 0 1;
    }

    DataTable {
        height: 100%;
    }
    """

    def __init__(self, scan_results: Dict = None):
        super().__init__()
        self.scan_results = scan_results or {}
        self.endpoints = []
        self.parsing_complete = False
        self.extraction_complete = False
        self.extracted_details = []

    def compose(self) -> ComposeResult:
        """Compose the parsing screen"""
        with Container(id="parsing-container"):
            yield Static("🔍 Parsing Endpoints", id="title", classes="bold")

            # Status text (reactive)
            yield Static("Parsing Endpoints...", id="status-text")

            # Progress bar
            yield ProgressBar(total=100, show_eta=False, id="progress-bar")

            # Stats panel (reactive)
            with Vertical(id="stats-panel"):
                yield Static("", id="stats-display")

            # Endpoints table
            with Vertical(id="endpoints-panel"):
                yield Static("Endpoints:", classes="bold")
                with ScrollableContainer():
                    yield DataTable(id="endpoints-table")

            # Action buttons
            with Horizontal(id="button-container"):
                yield Button("Extract Details", id="extract-details", variant="primary", disabled=True)
                yield Button("Re-scan Project", id="rescan", variant="default")
                yield Button("Exit", id="exit", variant="error")

    def on_mount(self) -> None:
        """Called when screen is mounted - start parsing automatically"""
        # Set up the endpoints table
        table = self.query_one("#endpoints-table", DataTable)
        table.add_columns("Method", "Route", "Function", "File", "Lines")

        # Initialize status
        self.parsing_status = "🔄 Initializing..."

        # Start parsing in background thread
        parsing_thread = threading.Thread(
            target=self._run_parsing_logic,
            daemon=True
        )
        parsing_thread.start()

    def watch_parsing_status(self, value: str) -> None:
        """Watch for parsing status changes"""
        try:
            status_widget = self.query_one("#status-text", Static)
            status_widget.update(value)
        except Exception:
            # Widget not yet mounted
            pass

    def watch_parsing_progress(self, value: int) -> None:
        """Watch for progress changes"""
        try:
            progress_bar = self.query_one("#progress-bar", ProgressBar)
            progress_bar.update(progress=value)
        except Exception:
            # Widget not yet mounted
            pass

    def watch_stats_text(self, value: str) -> None:
        """Watch for stats text changes"""
        try:
            logging.info(f"=== watch_stats_text called with value length: {len(value)} ===")
            logging.info(f"First 50 chars: {value[:50]}...")
            stats_display = self.query_one("#stats-display", Static)
            stats_display.update(value)
            logging.info("Stats display widget updated")
        except Exception as e:
            # Widget not yet mounted
            logging.info(f"Cannot update stats display yet: {e}")
            pass

    def watch_extraction_status(self, value: str) -> None:
        """Watch for extraction status changes"""
        if value:
            try:
                status_widget = self.query_one("#status-text", Static)
                status_widget.update(value)
            except Exception:
                # Widget not yet mounted
                pass

    def watch_extraction_progress(self, value: int) -> None:
        """Watch for extraction progress changes"""
        if self.extraction_status:  # Only update if extracting
            try:
                progress_bar = self.query_one("#progress-bar", ProgressBar)
                progress_bar.update(progress=value)
            except Exception:
                # Widget not yet mounted
                pass

    def _run_parsing_logic(self):
        """Run endpoint parsing in background thread"""
        try:
            logging.info("=== PARSING STARTED (parsing_v2.py) ===")
            logging.info("Using parsing_v2.py with reactive properties")

            # Get scan results
            candidates = self.scan_results.get("candidates", {})
            frameworks = self.scan_results.get("frameworks", [])
            project_path = Path(self.scan_results.get("project_path", "."))

            # Count total files
            total_files = sum(len(files) for files in candidates.values())
            logging.info(f"Parsing {total_files} files...")

            # Update status in main thread
            self.call_later(lambda: setattr(self, "parsing_status", f"🔄 Parsing {total_files} files..."))
            self.call_later(lambda: setattr(self, "parsing_progress", 0))

            # Import EndpointParser
            from ...scanner.endpoint_parser import EndpointParser

            # Create parser
            parser = EndpointParser(frameworks=frameworks)

            # Parse files
            current_file = 0
            all_endpoints = []

            for language, files in candidates.items():
                for file_path in files:
                    current_file += 1
                    logging.info(f"Parsing {file_path}...")

                    # Update progress in main thread
                    self.call_later(lambda c=current_file, t=total_files: setattr(self, "parsing_status", f"🔄 Parsing file {c}/{t}"))
                    self.call_later(lambda c=current_file, t=total_files: setattr(self, "parsing_progress", (c / t) * 100))

                    # Parse file
                    endpoints = parser.parser.parse_file(file_path, project_path)
                    all_endpoints.extend(endpoints)

                    # Add to table (use call_later to ensure main thread)
                    if endpoints:
                        self.call_later(self._add_endpoints_to_table, endpoints)

                    # Small delay to prevent UI freezing
                    time.sleep(0.01)

            # Store endpoints
            self.endpoints = all_endpoints
            logging.info(f"Parsing complete: found {len(all_endpoints)} endpoints")

            # Calculate statistics
            from collections import Counter
            method_counts = Counter(endpoint.method for endpoint in all_endpoints)
            total_endpoints = len(all_endpoints)

            # Create stats text
            stats = "✓ Parsing Complete\n\n"
            stats += f"Total Endpoints: {total_endpoints}\n"
            stats += f"Files Processed: {total_files}\n"

            if method_counts:
                stats += "\nBy Method:\n"
                for method in sorted(method_counts.keys()):
                    stats += f"  {method}: {method_counts[method]}\n"

            # Update UI through main thread
            self.call_later(self._update_parsing_complete, stats, total_files, total_endpoints)
            self.parsing_complete = True

            logging.info("=== PARSING COMPLETE ===")

        except Exception as e:
            logging.error(f"Parsing error: {e}", exc_info=True)
            self.call_later(lambda: setattr(self, "parsing_status", f"❌ Parsing failed: {str(e)}"))

    def _add_endpoints_to_table(self, endpoints: List):
        """Add endpoints to the table (called in main thread)"""
        table = self.query_one("#endpoints-table", DataTable)
        for endpoint in endpoints:
            table.add_row(
                endpoint.method,
                endpoint.route,
                endpoint.function_name,
                endpoint.file_path,
                f"{endpoint.start_line}-{endpoint.end_line}"
            )

    def _update_parsing_complete(self, stats: str, total_files: int, total_endpoints: int):
        """Update UI when parsing is complete (called in main thread)"""
        logging.info(f"=== _update_parsing_complete called (main thread) ===")
        logging.info(f"Stats text to display: {stats[:100]}...")  # First 100 chars

        # Update reactive properties in main thread
        self.parsing_status = "✓ Parsing Complete"
        self.parsing_progress = 100
        self.stats_text = stats

        logging.info(f"Set stats_text reactive property, length: {len(stats)}")

        # Enable extract button
        extract_button = self.query_one("#extract-details", Button)
        extract_button.disabled = False

        logging.info(f"Updated stats display with {total_endpoints} endpoints")

    def _enable_extract_button(self):
        """Enable extract button (called in main thread)"""
        extract_button = self.query_one("#extract-details", Button)
        extract_button.disabled = False

    def _update_extraction_start(self):
        """Initialize extraction UI (called in main thread)"""
        self.extraction_status = "🔄 Starting extraction..."
        self.extraction_progress = 0

    def _update_extraction_progress(self, current: int, total: int):
        """Update extraction progress (called in main thread)"""
        self.extraction_status = f"🔄 Extracting: {current}/{total}"
        self.extraction_progress = (current / total) * 100

    def _update_extraction_complete(self, success_count: int, total: int):
        """Update UI when extraction is complete (called in main thread)"""
        self.extraction_status = f"✓ Extraction Complete: {success_count}/{total} succeeded"
        self.extraction_progress = 100

        # Update stats
        stats = self.stats_text
        stats += f"\n\n✓ Extracted Details: {success_count}/{total}"
        self.stats_text = stats

    def _run_extraction_logic(self):
        """Run detail extraction in background thread"""
        try:
            logging.info("=== DETAIL EXTRACTION STARTED ===")

            # Update status in main thread
            self.call_later(self._update_extraction_start)

            # Get config
            config_path = Path.home() / ".code-context" / "config.json"
            try:
                with open(config_path, 'r') as f:
                    import json
                    config_data = json.load(f)
            except (IOError, json.JSONDecodeError):
                logging.error("Failed to load config for extraction")
                self.call_later(lambda: setattr(self, "extraction_status", "❌ Config load failed"))
                return

            # Get project root
            project_root = Path(self.scan_results.get("project_path", "."))

            # Import DetailExtractor
            from ...scanner.detail_extractor import EndpointDetailExtractor

            # Create extractor
            extractor = EndpointDetailExtractor(
                llm_provider=config_data.get("llm_provider"),
                llm_model=config_data.get("llm_model"),
                api_key=config_data.get("api_key"),
                presenter=None,
                batch_size=5
            )

            # Extract details
            total = len(self.endpoints)
            results = []

            for idx, detail in enumerate(extractor.extract_details(self.endpoints, project_root), 1):
                results.append(detail)

                # Update progress in main thread
                self.call_later(self._update_extraction_progress, idx, total)

                # Small delay to prevent UI freezing
                time.sleep(0.01)

            self.extracted_details = results

            # Update final status in main thread
            self.call_later(self._update_extraction_complete, len(results), total)

            logging.info(f"=== EXTRACTION COMPLETE: {len(self.extracted_details)} details ===")

        except Exception as e:
            logging.error(f"=== EXTRACTION ERROR ===", exc_info=True)
            self.call_later(lambda: setattr(self, "extraction_status", f"❌ Extraction failed: {str(e)}"))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        if button_id == "extract-details":
            # Disable button to prevent double-click
            event.button.disabled = True

            # Start extraction in background thread
            extraction_thread = threading.Thread(
                target=self._run_extraction_logic,
                daemon=True
            )
            extraction_thread.start()

        elif button_id == "rescan":
            # Go back to project selection
            self.app.switch_screen("project_select")
        elif button_id == "exit":
            self.app.exit()

    def call_later(self, func, *args):
        """Schedule a function to be called in the main thread"""
        self.app.call_from_thread(func, *args)