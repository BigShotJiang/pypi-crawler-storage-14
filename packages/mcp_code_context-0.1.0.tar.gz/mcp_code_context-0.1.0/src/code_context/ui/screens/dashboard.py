"""Interactive dashboard for browsing and managing API endpoints."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import Static, DataTable, Input, Button, Select, Tree, Footer
from textual.binding import Binding
from textual.message import Message
from rich.text import Text
from rich.syntax import Syntax
from typing import List, Optional
from pathlib import Path
import json
import logging

logger = logging.getLogger(__name__)


class FilterChanged(Message):
    """Message sent when a filter is changed."""

    def __init__(self, method: str):
        super().__init__()
        self.method = method


class StatsWidget(Static):
    """Widget to display endpoint statistics."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.total_endpoints = 0
        self.total_files = 0
        self.method_counts = {}
        self.collection_name = ""

    def render(self) -> Text:
        text = Text()
        text.append("📊 ", style="bold cyan")
        text.append(f"{self.collection_name}", style="bold magenta")
        text.append(" | ", style="dim")
        text.append(f"{self.total_endpoints} endpoints", style="green")
        text.append(" | ", style="dim")
        text.append(f"{self.total_files} files", style="green")

        if self.method_counts:
            text.append(" | ", style="dim")
            for method, count in sorted(self.method_counts.items()):
                color = {
                    "GET": "blue",
                    "POST": "green",
                    "PUT": "yellow",
                    "DELETE": "red",
                    "PATCH": "cyan"
                }.get(method, "white")
                text.append(f"{method}:{count} ", style=color)

        return text

    def update_stats(self, endpoints: List, collection: str):
        """Update statistics from endpoints list."""
        self.collection_name = collection
        self.total_endpoints = len(endpoints)
        self.total_files = len(set(ep.file_path for ep in endpoints))

        from collections import Counter
        self.method_counts = Counter(ep.method for ep in endpoints)
        self.refresh()


class FilterPanel(Vertical):
    """Panel for filtering endpoints."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.active_methods = set()
        self.all_methods = ["DELETE", "GET", "PATCH", "POST", "PUT"]  # Sorted list

    def compose(self) -> ComposeResult:
        """Compose filter panel with buttons."""
        yield Static("🎯 Filters\n", classes="filter-title")
        yield Static("HTTP Methods:", classes="filter-section")

        # Create a button for each method
        for method in self.all_methods:
            variant = "primary" if method in self.active_methods else "default"
            yield Button(
                f"☐ {method}",
                id=f"filter-{method}",
                classes="filter-button",
                variant=variant
            )

    def on_mount(self) -> None:
        """Update button labels on mount."""
        self._update_button_labels()

    def toggle_method(self, method: str):
        """Toggle a method filter."""
        if method in self.active_methods:
            self.active_methods.remove(method)
        else:
            self.active_methods.add(method)
        self._update_button_labels()

    def _update_button_labels(self):
        """Update button labels and variants based on active state."""
        for method in self.all_methods:
            try:
                button = self.query_one(f"#filter-{method}", Button)
                is_active = method in self.active_methods
                button.label = f"☑ {method}" if is_active else f"☐ {method}"
                button.variant = "primary" if is_active else "default"
            except Exception:
                # Button might not be mounted yet
                pass

    def get_active_methods(self) -> set:
        """Get currently active method filters."""
        return self.active_methods if self.active_methods else set(self.all_methods)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        # Extract method from button ID
        if event.button.id and event.button.id.startswith("filter-"):
            method = event.button.id.replace("filter-", "")
            self.toggle_method(method)
            # Notify parent to update filters
            self.post_message(FilterChanged(method))


class DetailView(Container):
    """Widget to display endpoint details using Tree."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_endpoint = None

    def compose(self) -> ComposeResult:
        """Compose the detail view."""
        yield Tree("Select an endpoint to view details", id="endpoint-detail-tree")

    def update_endpoint(self, endpoint):
        """Update displayed endpoint."""
        self.current_endpoint = endpoint
        self._build_endpoint_tree()

    def _build_endpoint_tree(self):
        """Build tree view from endpoint data."""
        tree = self.query_one("#endpoint-detail-tree", Tree)
        tree.clear()

        if not self.current_endpoint:
            tree.label = "Select an endpoint to view details"
            return

        ep = self.current_endpoint

        # Set root label
        method_emoji = {
            "GET": "🔵",
            "POST": "🟢",
            "PUT": "🟡",
            "DELETE": "🔴",
            "PATCH": "🔷"
        }.get(ep.method, "⚪")

        tree.label = f"{method_emoji} {ep.method} {ep.route}"
        tree.root.expand()

        # Build endpoint data dict
        endpoint_data = {
            "Basic Info": {
                "ID": ep.id,
                "Name": ep.name,
                "Route": ep.route,
                "Method": ep.method,
                "File": ep.file_path,
                "Framework": ep.framework or "N/A",
                "Language": ep.language or "N/A",
            }
        }

        if ep.description:
            endpoint_data["Description"] = ep.description

        if ep.parameters:
            endpoint_data["Parameters"] = ep.parameters

        if ep.response_format:
            endpoint_data["Response Format"] = ep.response_format

        # Add any other fields from the endpoint
        # Build the tree
        self._build_json_tree(tree.root, endpoint_data)

    def _build_json_tree(self, parent_node, data):
        """Recursively build tree from JSON data.

        Args:
            parent_node: Parent tree node
            data: Data to add (dict, list, or primitive)
        """
        if isinstance(data, dict):
            # Handle dictionary
            for key, value in data.items():
                if isinstance(value, dict):
                    # Nested dict - create expandable node
                    if value:  # Non-empty dict
                        node = parent_node.add(f"📁 {key}", expand=False)
                        self._build_json_tree(node, value)
                    else:
                        parent_node.add(f"📁 {key}: {{}}", allow_expand=False)

                elif isinstance(value, list):
                    # List - create expandable node
                    if value:  # Non-empty list
                        node = parent_node.add(f"📋 {key} [{len(value)} items]", expand=False)
                        self._build_json_tree(node, value)
                    else:
                        parent_node.add(f"📋 {key}: []", allow_expand=False)

                elif value is None:
                    # Null value
                    parent_node.add(f"🔹 {key}: null", allow_expand=False)

                elif isinstance(value, bool):
                    # Boolean value
                    parent_node.add(f"🔹 {key}: {str(value).lower()}", allow_expand=False)

                elif isinstance(value, (int, float)):
                    # Numeric value
                    parent_node.add(f"🔹 {key}: {value}", allow_expand=False)

                else:
                    # String or other value
                    # Truncate very long strings
                    str_value = str(value)
                    if len(str_value) > 100:
                        str_value = str_value[:100] + "..."
                    parent_node.add(f"🔹 {key}: \"{str_value}\"", allow_expand=False)

        elif isinstance(data, list):
            # Handle list
            for idx, item in enumerate(data):
                if isinstance(item, dict):
                    # Dict item in list
                    if item:
                        node = parent_node.add(f"[{idx}] 📁", expand=False)
                        self._build_json_tree(node, item)
                    else:
                        parent_node.add(f"[{idx}]: {{}}", allow_expand=False)

                elif isinstance(item, list):
                    # List item in list
                    if item:
                        node = parent_node.add(f"[{idx}] 📋 [{len(item)} items]", expand=False)
                        self._build_json_tree(node, item)
                    else:
                        parent_node.add(f"[{idx}]: []", allow_expand=False)

                else:
                    # Primitive item in list
                    str_value = str(item)
                    if len(str_value) > 100:
                        str_value = str_value[:100] + "..."
                    parent_node.add(f"[{idx}]: {str_value}", allow_expand=False)


class DashboardScreen(Screen):
    """Main dashboard screen for browsing endpoints."""

    CSS = """
    DashboardScreen {
        background: $surface;
    }

    #dashboard-container {
        width: 100%;
        height: 100%;
        padding: 0;
    }

    #stats-bar {
        width: 100%;
        height: 3;
        background: $primary-darken-1;
        padding: 1 2;
        dock: top;
    }

    #main-content {
        width: 100%;
        height: 1fr;
    }

    #left-panel {
        width: 20;
        height: 100%;
        border-right: solid $primary;
    }

    #search-box {
        width: 100%;
        padding: 1;
        border-bottom: solid $primary;
    }

    #filter-panel {
        width: 100%;
        height: 1fr;
        padding: 1;
    }

    .filter-title {
        text-align: center;
        margin-bottom: 1;
    }

    .filter-section {
        margin-top: 1;
        margin-bottom: 1;
    }

    .filter-button {
        width: 100%;
        margin-bottom: 1;
    }

    #middle-panel {
        width: 1fr;
        height: 100%;
        border-right: solid $primary;
    }

    #endpoints-table {
        width: 100%;
        height: 1fr;
    }

    #right-panel {
        width: 40;
        height: 100%;
    }

    #detail-view {
        width: 100%;
        height: 100%;
    }

    #endpoint-detail-tree {
        width: 100%;
        height: 100%;
    }

    #button-bar {
        width: 100%;
        height: 3;
        padding: 0 2;
        background: $panel;
        dock: bottom;
    }

    Button {
        margin: 0 1;
    }

    DataTable {
        height: 100%;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("s", "focus_search", "Search"),
        Binding("e", "export_json", "Export JSON"),
        Binding("m", "export_markdown", "Export MD"),
        Binding("?", "show_help", "Help"),
        Binding("r", "refresh", "Refresh"),
    ]

    def __init__(self, collection_name: str = "endpoints"):
        super().__init__()
        self.collection_name = collection_name
        self.all_endpoints = []
        self.filtered_endpoints = []
        self.current_endpoint = None

    def compose(self) -> ComposeResult:
        """Compose the dashboard layout."""
        with Container(id="dashboard-container"):
            # Stats bar (top)
            yield StatsWidget(id="stats-bar")

            # Main content area
            with Horizontal(id="main-content"):
                # Left panel: Search + Filters
                with Vertical(id="left-panel"):
                    with Container(id="search-box"):
                        yield Input(
                            placeholder="Search endpoints...",
                            id="search-input"
                        )
                    yield FilterPanel(id="filter-panel")

                # Middle panel: Endpoints table
                with Vertical(id="middle-panel"):
                    table = DataTable(id="endpoints-table", cursor_type="row")
                    table.add_columns("Method", "Route", "Name", "File")
                    yield table

                # Right panel: Detail view
                with Container(id="right-panel"):
                    yield DetailView(id="detail-view")

            # Button bar (bottom)
            with Horizontal(id="button-bar"):
                yield Button("Export JSON", id="export-json", variant="success")
                yield Button("Export MD", id="export-md", variant="primary")
                yield Button("Collections", id="collections", variant="default")
                yield Button("Help", id="help", variant="default")
                yield Footer()

    def on_mount(self) -> None:
        """Called when dashboard is mounted."""
        logger.info(f"Dashboard mounted for collection: {self.collection_name}")
        self._load_endpoints()

    def _load_endpoints(self):
        """Load endpoints from Qdrant database."""
        try:
            from ...database import QdrantManager

            db = QdrantManager(use_memory=False)

            # Check if collection exists
            collections = db.list_all_collections()
            if self.collection_name not in collections:
                self._show_error(f"Collection '{self.collection_name}' not found")
                return

            # Load all endpoints
            # Note: QdrantManager uses self.config.collection_name
            # TODO: Add collection switching support
            self.all_endpoints = db.list_all_endpoints(limit=1000)

            logger.info(f"Loaded {len(self.all_endpoints)} endpoints")

            # Initial filter (all)
            self.filtered_endpoints = self.all_endpoints

            # Update UI
            self._update_table()
            self._update_stats()

        except Exception as e:
            logger.error(f"Failed to load endpoints: {e}", exc_info=True)
            self._show_error(f"Failed to load endpoints: {str(e)}")

    def _update_table(self):
        """Update the endpoints table with filtered results."""
        table = self.query_one("#endpoints-table", DataTable)
        table.clear()

        for ep in self.filtered_endpoints:
            # Truncate long strings
            route = ep.route[:30] + "..." if len(ep.route) > 30 else ep.route
            name = ep.name[:20] + "..." if len(ep.name) > 20 else ep.name
            file_path = Path(ep.file_path).name

            table.add_row(
                ep.method,
                route,
                name,
                file_path,
                key=ep.id
            )

    def _update_stats(self):
        """Update statistics widget."""
        stats = self.query_one("#stats-bar", StatsWidget)
        stats.update_stats(self.filtered_endpoints, self.collection_name)

    def _show_error(self, message: str):
        """Show error message."""
        # TODO: Show proper error dialog
        logger.error(message)

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle search input changes."""
        if event.input.id == "search-input":
            self._apply_filters(event.value)

    def on_filter_changed(self, event: FilterChanged) -> None:
        """Handle filter changes from FilterPanel."""
        # Get current search query
        search_input = self.query_one("#search-input", Input)
        self._apply_filters(search_input.value)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle row selection in endpoints table."""
        if event.data_table.id == "endpoints-table":
            row_key = event.row_key

            # Find endpoint by ID
            endpoint = next((ep for ep in self.filtered_endpoints if ep.id == row_key), None)

            if endpoint:
                self.current_endpoint = endpoint
                detail_view = self.query_one("#detail-view", DetailView)
                detail_view.update_endpoint(endpoint)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id

        if button_id == "export-json":
            self.action_export_json()
        elif button_id == "export-md":
            self.action_export_markdown()
        elif button_id == "collections":
            self.action_manage_collections()
        elif button_id == "help":
            self.action_show_help()

    def _apply_filters(self, search_query: str = ""):
        """Apply search and method filters."""
        # Get active method filters
        filter_panel = self.query_one("#filter-panel", FilterPanel)
        active_methods = filter_panel.get_active_methods()

        # Filter by method
        filtered = [ep for ep in self.all_endpoints if ep.method in active_methods]

        # Filter by search query
        if search_query:
            query_lower = search_query.lower()
            filtered = [
                ep for ep in filtered
                if query_lower in ep.route.lower()
                or query_lower in ep.name.lower()
                or (ep.description and query_lower in ep.description.lower())
            ]

        self.filtered_endpoints = filtered
        self._update_table()
        self._update_stats()

    def action_focus_search(self):
        """Focus the search input."""
        self.query_one("#search-input", Input).focus()

    def action_export_json(self):
        """Export filtered endpoints to JSON."""
        try:
            output_file = Path.cwd() / f"{self.collection_name}_endpoints.json"

            data = []
            for ep in self.filtered_endpoints:
                data.append({
                    "method": ep.method,
                    "route": ep.route,
                    "name": ep.name,
                    "file_path": ep.file_path,
                    "description": ep.description,
                    "framework": ep.framework,
                    "language": ep.language,
                })

            with open(output_file, 'w') as f:
                json.dump(data, f, indent=2)

            logger.info(f"Exported {len(data)} endpoints to {output_file}")
            self.notify(f"✅ Exported to {output_file.name}")

        except Exception as e:
            logger.error(f"Export failed: {e}", exc_info=True)
            self.notify(f"❌ Export failed: {str(e)}", severity="error")

    def action_export_markdown(self):
        """Export filtered endpoints to Markdown."""
        try:
            output_file = Path.cwd() / f"{self.collection_name}_endpoints.md"

            with open(output_file, 'w') as f:
                f.write(f"# API Endpoints - {self.collection_name}\n\n")
                f.write(f"Total endpoints: {len(self.filtered_endpoints)}\n\n")

                # Group by method
                from collections import defaultdict
                by_method = defaultdict(list)
                for ep in self.filtered_endpoints:
                    by_method[ep.method].append(ep)

                for method in sorted(by_method.keys()):
                    endpoints = by_method[method]
                    f.write(f"## {method} ({len(endpoints)})\n\n")

                    for ep in endpoints:
                        f.write(f"### `{ep.route}`\n\n")
                        f.write(f"- **Name**: {ep.name}\n")
                        f.write(f"- **File**: `{ep.file_path}`\n")
                        if ep.description:
                            f.write(f"- **Description**: {ep.description}\n")
                        f.write("\n")

            logger.info(f"Exported {len(self.filtered_endpoints)} endpoints to {output_file}")
            self.notify(f"✅ Exported to {output_file.name}")

        except Exception as e:
            logger.error(f"Export failed: {e}", exc_info=True)
            self.notify(f"❌ Export failed: {str(e)}", severity="error")

    def action_manage_collections(self):
        """Open collection management dialog."""
        # TODO: Implement collection management
        self.notify("Collections management - Coming soon!")

    def action_show_help(self):
        """Show help dialog."""
        help_text = """
        **Keyboard Shortcuts:**
        - q: Quit
        - s: Focus search
        - e: Export JSON
        - m: Export Markdown
        - ?: Show help
        - r: Refresh

        **Features:**
        - Search: Type in search box to filter endpoints
        - Click rows to view details
        - Use filters to narrow down results
        """
        self.notify(help_text)

    def action_refresh(self):
        """Reload endpoints from database."""
        self._load_endpoints()
        self.notify("✅ Refreshed")

    def action_quit(self):
        """Quit the dashboard."""
        self.app.exit()
