"""Review screen for browsing extracted endpoint details."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal, ScrollableContainer
from textual.widgets import Static, Button, OptionList, Tree
from textual.widgets._option_list import Option
from pathlib import Path
from typing import List
import json
import logging

logger = logging.getLogger(__name__)


class ReviewDetailsScreen(Screen):
    """Screen for reviewing and browsing extracted endpoint details"""

    CSS = """
    ReviewDetailsScreen {
        align: center top;
        padding: 1 0;
    }

    #review-container {
        width: 90;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    #endpoint-list-section {
        width: 100%;
        height: 15;
        border: solid $accent;
        margin-bottom: 2;
        padding: 1;
    }

    #endpoint-options {
        width: 100%;
        height: 100%;
    }

    #detail-section {
        width: 100%;
        height: 25;
        border: solid $success;
        margin-bottom: 2;
        padding: 1;
    }

    #detail-tree {
        width: 100%;
        height: 100%;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    Button {
        margin: 0 1;
    }

    OptionList > .option--highlighted {
        background: $accent;
    }

    Tree {
        height: 100%;
    }
    """

    def __init__(self, extracted_details: List = None, project_path=None):
        super().__init__()
        self.extracted_details = extracted_details or []
        self.project_path = project_path
        self.selected_endpoint = None

    def compose(self) -> ComposeResult:
        """Compose the review screen"""
        with Container(id="review-container"):
            yield Static("📋 Review Extracted Endpoint Details", id="title", classes="bold")

            # Endpoint selection list (top section)
            with Vertical(id="endpoint-list-section"):
                yield Static(f"Endpoints ({len(self.extracted_details)}):", classes="bold")
                with ScrollableContainer():
                    yield OptionList(id="endpoint-options")

            # Detail display tree (bottom section)
            with Vertical(id="detail-section"):
                yield Static("Details:", classes="bold")
                with ScrollableContainer():
                    yield Tree("Select an endpoint to view details", id="detail-tree")

            # Action buttons
            with Horizontal(id="button-container"):
                yield Button("Save to Qdrant", id="save-qdrant", variant="success")
                yield Button("Export JSON", id="export", variant="primary")
                yield Button("Back to Extraction", id="back", variant="default")

    def on_mount(self) -> None:
        """Populate endpoint list when screen mounts"""
        logger.info(f"ReviewDetailsScreen mounted with {len(self.extracted_details)} endpoints")

        option_list = self.query_one("#endpoint-options", OptionList)

        # Add each endpoint as an option
        for idx, detail in enumerate(self.extracted_details):
            # Create display text: "METHOD /route"
            display_text = detail.endpoint_id
            option_list.add_option(Option(display_text, id=str(idx)))

        # Select first endpoint by default
        if self.extracted_details:
            option_list.highlighted = 0
            self._display_endpoint_detail(0)

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle endpoint selection from OptionList"""
        # Get selected index from option ID
        selected_idx = int(event.option.id)
        logger.info(f"Selected endpoint index: {selected_idx}")
        self._display_endpoint_detail(selected_idx)

    def _display_endpoint_detail(self, idx: int):
        """Display details for selected endpoint in tree view"""
        if 0 <= idx < len(self.extracted_details):
            detail = self.extracted_details[idx]
            self.selected_endpoint = detail

            logger.info(f"Displaying details for: {detail.endpoint_id}")

            # Update detail tree
            tree = self.query_one("#detail-tree", Tree)
            tree.clear()

            # Set root label to endpoint ID
            tree.label = f"📍 {detail.endpoint_id}"
            tree.root.expand()

            # Build tree from payload
            self._build_json_tree(tree.root, detail.payload)

    def _build_json_tree(self, parent_node, data):
        """Recursively build tree from JSON data

        Args:
            parent_node: Parent tree node
            data: Data to add (dict, list, or primitive)
        """
        if isinstance(data, dict):
            # Handle dictionary
            for key, value in data.items():
                if isinstance(value, dict):
                    # Nested dict - create expandable node
                    if value:  # Non-empty dict
                        node = parent_node.add(f"📁 {key}", expand=False)
                        self._build_json_tree(node, value)
                    else:
                        parent_node.add(f"📁 {key}: {{}}", allow_expand=False)

                elif isinstance(value, list):
                    # List - create expandable node
                    if value:  # Non-empty list
                        node = parent_node.add(f"📋 {key} [{len(value)} items]", expand=False)
                        self._build_json_tree(node, value)
                    else:
                        parent_node.add(f"📋 {key}: []", allow_expand=False)

                elif value is None:
                    # Null value
                    parent_node.add(f"🔹 {key}: null", allow_expand=False)

                elif isinstance(value, bool):
                    # Boolean value
                    parent_node.add(f"🔹 {key}: {str(value).lower()}", allow_expand=False)

                elif isinstance(value, (int, float)):
                    # Numeric value
                    parent_node.add(f"🔹 {key}: {value}", allow_expand=False)

                else:
                    # String or other value
                    # Truncate very long strings
                    str_value = str(value)
                    if len(str_value) > 100:
                        str_value = str_value[:100] + "..."
                    parent_node.add(f"🔹 {key}: \"{str_value}\"", allow_expand=False)

        elif isinstance(data, list):
            # Handle list
            for idx, item in enumerate(data):
                if isinstance(item, dict):
                    # Dict item in list
                    if item:
                        node = parent_node.add(f"[{idx}] 📁", expand=False)
                        self._build_json_tree(node, item)
                    else:
                        parent_node.add(f"[{idx}]: {{}}", allow_expand=False)

                elif isinstance(item, list):
                    # Nested list
                    if item:
                        node = parent_node.add(f"[{idx}] 📋 [{len(item)} items]", expand=False)
                        self._build_json_tree(node, item)
                    else:
                        parent_node.add(f"[{idx}]: []", allow_expand=False)

                elif item is None:
                    parent_node.add(f"[{idx}]: null", allow_expand=False)

                elif isinstance(item, bool):
                    parent_node.add(f"[{idx}]: {str(item).lower()}", allow_expand=False)

                elif isinstance(item, (int, float)):
                    parent_node.add(f"[{idx}]: {item}", allow_expand=False)

                else:
                    # String or other
                    str_value = str(item)
                    if len(str_value) > 100:
                        str_value = str_value[:100] + "..."
                    parent_node.add(f"[{idx}]: \"{str_value}\"", allow_expand=False)

        else:
            # Primitive value at root (shouldn't happen, but handle it)
            parent_node.add(str(data), allow_expand=False)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        logger.info(f"Button pressed: {button_id}")

        if button_id == "save-qdrant":
            # Navigate to Saving Screen
            try:
                from .saving import SavingScreen
                logger.info(f"Navigating to Saving Screen with {len(self.extracted_details)} details")
                saving_screen = SavingScreen(
                    extracted_details=self.extracted_details,
                    project_path=self.project_path
                )
                self.app.push_screen(saving_screen)
            except Exception as e:
                logger.error(f"Error navigating to Saving Screen: {e}", exc_info=True)

        elif button_id == "export":
            self._export_to_json()

        elif button_id == "back":
            # Go back to extraction screen
            self.app.pop_screen()

    def _export_to_json(self):
        """Export all extracted details to JSON file"""
        try:
            output_dir = Path.home() / ".code-context"
            output_dir.mkdir(exist_ok=True)
            output_path = output_dir / "extracted_details.json"

            # Convert to serializable format
            export_data = []
            for detail in self.extracted_details:
                export_data.append({
                    "endpoint_id": detail.endpoint_id,
                    "description": detail.description,
                    "payload": detail.payload,
                    # Don't export embedding vector (too large)
                })

            # Write to file
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)

            logger.info(f"Exported {len(export_data)} endpoints to {output_path}")

            # Show success message temporarily
            title = self.query_one("#title", Static)
            original_text = "📋 Review Extracted Endpoint Details"
            title.update(f"✓ Exported to {output_path}")

            # Reset title after 3 seconds
            self.set_timer(3, lambda: title.update(original_text))

        except Exception as e:
            logger.error(f"Failed to export JSON: {e}", exc_info=True)

            # Show error message
            title = self.query_one("#title", Static)
            title.update(f"❌ Export failed: {str(e)}")
            self.set_timer(3, lambda: title.update("📋 Review Extracted Endpoint Details"))
