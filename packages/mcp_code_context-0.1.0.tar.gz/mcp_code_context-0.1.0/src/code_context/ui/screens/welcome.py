"""Welcome screen for code-context."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Center
from textual.widgets import Static, Button, Label
from pathlib import Path
import json


class WelcomeScreen(Screen):
    """Welcome screen - entry point of the application"""

    CSS = """
    WelcomeScreen {
        align: center middle;
    }

    #welcome-container {
        width: 80;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 1;
    }

    #description {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
        color: $text-muted;
    }

    #status {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
        padding: 1;
        border: solid $accent;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
    }

    Button {
        margin: 1 2;
    }
    """

    def __init__(self):
        super().__init__()
        self.config_exists = self._check_config()

    def compose(self) -> ComposeResult:
        """Compose the welcome screen"""
        with Container(id="welcome-container"):
            yield Static("🚀 Code Context Scanner", id="title", classes="bold")
            yield Static(
                "Automatically discover and track API endpoints in your codebase",
                id="description"
            )

            # Status message
            if self.config_exists:
                status_text = "✓ Configuration found - Ready to scan"
                status_style = "green"
            else:
                status_text = "⚠ No configuration found - Please configure first"
                status_style = "yellow"

            yield Static(status_text, id="status", classes=status_style)

            # Action buttons
            with Center(id="button-container"):
                if self.config_exists:
                    yield Button("Start Scan", id="start-scan", variant="primary")
                    yield Button("Reconfigure", id="configure", variant="default")
                else:
                    yield Button("Configure", id="configure", variant="primary")

                yield Button("Quit", id="quit", variant="error")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        if button_id == "start-scan":
            # Navigate to project selection screen
            self.app.push_screen("project_select")
        elif button_id == "configure":
            # Navigate to configuration screen
            self.app.push_screen("config")
        elif button_id == "quit":
            self.app.exit()

    def _check_config(self) -> bool:
        """Check if configuration file exists

        Returns:
            True if config exists, False otherwise
        """
        config_path = Path.home() / ".code-context" / "config.json"

        if not config_path.exists():
            return False

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                # Verify it has required fields
                return all(key in config for key in ["llm_provider", "llm_model", "api_key"])
        except (json.JSONDecodeError, IOError):
            return False
