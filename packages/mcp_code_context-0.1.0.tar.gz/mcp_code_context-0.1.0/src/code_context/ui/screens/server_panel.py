"""Server panel for managing MCP server with graceful shutdown."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, Footer, RichLog
from textual.binding import Binding
from rich.text import Text
import logging

logger = logging.getLogger(__name__)


class StatusBar(Static):
    """Status bar showing server information."""

    def __init__(self, server_manager, **kwargs):
        super().__init__(**kwargs)
        self.server_manager = server_manager
        self.endpoints_count = 0

    def set_endpoints_count(self, count: int):
        """Update endpoints count."""
        self.endpoints_count = count
        self.refresh()

    def render(self) -> Text:
        """Render status bar."""
        text = Text()

        # Server status
        if self.server_manager.is_running:
            text.append("● ", style="bold green")
            text.append("Running", style="green")
        else:
            text.append("● ", style="bold red")
            text.append("Stopped", style="red")

        text.append(" | ", style="dim")

        # Uptime
        uptime = self.server_manager.get_uptime()
        text.append(f"⏱  Uptime: {uptime}", style="cyan")

        text.append(" | ", style="dim")

        # Endpoints count
        text.append(f"📊 Endpoints: {self.endpoints_count}", style="yellow")

        text.append(" | ", style="dim")

        # Qdrant mode
        text.append("💾 Qdrant: :memory: mode", style="magenta")

        return text


class ServerPanelScreen(Screen):
    """Server management panel with logs and graceful shutdown."""

    BINDINGS = [
        Binding("q", "quit_app", "Quit (use Shutdown button!)", priority=True),
    ]

    CSS = """
    ServerPanelScreen {
        layout: vertical;
    }

    #header {
        dock: top;
        height: auto;
        background: $boost;
        padding: 1;
    }

    #title {
        text-align: center;
        text-style: bold;
        color: $accent;
    }

    #status-bar {
        height: 1;
        background: $surface;
        padding: 0 1;
        margin-bottom: 1;
    }

    #log-container {
        height: 1fr;
        border: solid $primary;
        margin: 1 2;
    }

    #server-log {
        height: 100%;
    }

    #button-bar {
        dock: bottom;
        height: auto;
        padding: 1 2;
        background: $surface;
    }

    #button-bar Button {
        margin-right: 2;
    }

    #shutdown-btn {
        background: $error;
    }

    #shutdown-btn:hover {
        background: $error-darken-1;
    }
    """

    def __init__(self, server_manager, mcp_app, **kwargs):
        super().__init__(**kwargs)
        self.server_manager = server_manager
        self.mcp_app = mcp_app
        self.is_shutting_down = False

    def compose(self) -> ComposeResult:
        """Compose the server panel UI."""
        # Header
        with Container(id="header"):
            yield Static("🚀 Code-Context MCP Server", id="title")
            yield StatusBar(self.server_manager, id="status-bar")

        # Log container
        with Vertical(id="log-container"):
            yield RichLog(id="server-log", highlight=True, markup=True)

        # Button bar
        with Horizontal(id="button-bar"):
            yield Button("Shutdown Server", id="shutdown-btn", variant="error")
            yield Button("View Stats", id="stats-btn", variant="primary")
            yield Button("Help", id="help-btn", variant="default")
            yield Footer()

    def on_mount(self) -> None:
        """Initialize server panel."""
        # Get server log widget
        server_log = self.query_one("#server-log", RichLog)

        # Set log callback for server manager
        def log_to_ui(message: str):
            server_log.write(message)

        self.server_manager.set_log_callback(log_to_ui)

        # Start server
        self.server_manager.start_server()

        # Load endpoint count
        try:
            from ...tools import get_db_manager
            db = get_db_manager()
            endpoints = db.list_all_endpoints(limit=10000)
            status_bar = self.query_one("#status-bar", StatusBar)
            status_bar.set_endpoints_count(len(endpoints))
            server_log.write(f"📊 Loaded {len(endpoints)} endpoints to memory")
        except Exception as e:
            server_log.write(f"⚠️  Could not load endpoint count: {e}")

        # Update status bar periodically
        self.set_interval(1.0, self._update_status_bar)

        server_log.write("")
        server_log.write("[bold green]✅ Server panel ready[/bold green]")
        server_log.write("[dim]Use 'Shutdown Server' button to safely stop the server[/dim]")

    def _update_status_bar(self):
        """Update status bar with current information."""
        status_bar = self.query_one("#status-bar", StatusBar)
        status_bar.refresh()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id

        if button_id == "shutdown-btn":
            self._handle_shutdown()
        elif button_id == "stats-btn":
            self._show_stats()
        elif button_id == "help-btn":
            self._show_help()

    def _handle_shutdown(self):
        """Handle graceful shutdown."""
        if self.is_shutting_down:
            self.notify("⚠️ Shutdown already in progress", severity="warning")
            return

        self.is_shutting_down = True
        server_log = self.query_one("#server-log", RichLog)

        # Disable shutdown button
        shutdown_btn = self.query_one("#shutdown-btn", Button)
        shutdown_btn.disabled = True

        server_log.write("")
        server_log.write("[bold yellow]🔄 Initiating graceful shutdown...[/bold yellow]")

        # Run shutdown in background
        self.run_worker(self._shutdown_worker, exclusive=True)

    async def _shutdown_worker(self):
        """Worker to perform shutdown."""
        server_log = self.query_one("#server-log", RichLog)

        def progress_callback(message: str):
            server_log.write(message)

        # Perform graceful shutdown
        await self.server_manager.graceful_shutdown(progress_callback)

        # Wait a moment
        import asyncio
        await asyncio.sleep(1)

        # Exit the app
        server_log.write("")
        server_log.write("[bold green]👋 Goodbye![/bold green]")
        await asyncio.sleep(0.5)
        self.app.exit()

    def _show_stats(self):
        """Show server statistics."""
        server_log = self.query_one("#server-log", RichLog)

        try:
            from ...tools import get_api_statistics
            stats = get_api_statistics()

            server_log.write("")
            server_log.write("[bold cyan]📊 API Statistics[/bold cyan]")
            server_log.write(f"  Total Endpoints: {stats['total_endpoints']}")

            if stats['by_method']:
                server_log.write("  By Method:")
                for method, count in sorted(stats['by_method'].items()):
                    server_log.write(f"    {method}: {count}")

            if stats['by_framework']:
                server_log.write("  By Framework:")
                for framework, count in sorted(stats['by_framework'].items()):
                    server_log.write(f"    {framework}: {count}")

        except Exception as e:
            server_log.write(f"[red]❌ Error loading stats: {e}[/red]")

    def _show_help(self):
        """Show help information."""
        server_log = self.query_one("#server-log", RichLog)

        server_log.write("")
        server_log.write("[bold cyan]📖 Help[/bold cyan]")
        server_log.write("  • MCP server is running in the background")
        server_log.write("  • All MCP tool calls will appear in this log")
        server_log.write("  • Use 'Shutdown Server' button to safely stop")
        server_log.write("  • DO NOT use Ctrl+C - it may cause data loss!")
        server_log.write("")
        server_log.write("  Available tools: 13 MCP tools")
        server_log.write("    - search_endpoint, add_endpoint, update_endpoint")
        server_log.write("    - semantic_search_endpoints, filter_endpoints")
        server_log.write("    - get_api_statistics, list_collections")
        server_log.write("    - and more...")

    def action_quit_app(self):
        """Handle quit action (q key)."""
        server_log = self.query_one("#server-log", RichLog)
        server_log.write("")
        server_log.write("[bold red]⚠️  Please use 'Shutdown Server' button for safe shutdown![/bold red]")
        server_log.write("[dim]   Press 'q' again if you really want to force quit (not recommended)[/dim]")

        # If pressed twice in quick succession, force quit
        if hasattr(self, "_quit_pressed_time"):
            import time
            if time.time() - self._quit_pressed_time < 2:
                server_log.write("[red]⚠️  Force quitting without graceful shutdown...[/red]")
                self.app.exit()

        import time
        self._quit_pressed_time = time.time()
