"""Extraction details confirmation screen for code-context."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, ProgressBar
from rich.text import Text
from pathlib import Path
from typing import List, Dict, Any
import threading
import logging
import json

logger = logging.getLogger(__name__)


class ActualUsageWidget(Static):
    """Widget to display actual token usage during extraction"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.input_tokens = 0
        self.output_tokens = 0

    def render(self) -> Text:
        text = Text()
        text.append("Token Usage: ", style="cyan bold")
        text.append(f"Input: {self.input_tokens:,}", style="green")
        text.append(" | ", style="dim")
        text.append(f"Output: {self.output_tokens:,}", style="green")
        return text

    def update_tokens(self, input_tokens: int, output_tokens: int):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.refresh()


class ExtractionDetailsScreen(Screen):
    """Screen for confirming and running endpoint detail extraction"""

    CSS = """
    ExtractionDetailsScreen {
        align: center top;
        padding: 1 0;
    }

    #extraction-container {
        width: 90;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    #summary-panel {
        width: 100%;
        border: solid $accent;
        padding: 1;
        margin-bottom: 2;
        min-height: 6;
    }


    #config-panel {
        width: 100%;
        border: solid $success;
        padding: 1;
        margin-bottom: 2;
        min-height: 4;
    }

    #token-panel {
        width: 100%;
        border: solid $accent;
        padding: 1;
        margin-bottom: 2;
        height: 3;
        display: none;
    }

    #status-panel {
        width: 100%;
        margin-bottom: 1;
    }

    #progress-bar {
        width: 100%;
        margin-bottom: 2;
    }

    #results-panel {
        width: 100%;
        border: solid $success;
        padding: 1;
        margin-bottom: 2;
        min-height: 6;
        display: none;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    Button {
        margin: 0 1;
    }

    #review-details {
        display: none;
    }
    """

    def __init__(self, endpoints: List = None, project_path=None):
        super().__init__()
        self.endpoints = endpoints or []
        self.project_path = project_path
        self.extraction_in_progress = False
        self.extraction_complete = False
        self.extracted_details = []
        self.config_data = {}
        self.accumulated_tokens = {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0
        }

    def compose(self) -> ComposeResult:
        """Compose the extraction details screen"""
        with Container(id="extraction-container"):
            yield Static("🔍 Extract Endpoint Details", id="title", classes="bold")

            # Summary of what will be extracted
            with Vertical(id="summary-panel"):
                yield Static("", id="summary-text")

            # Configuration display
            with Vertical(id="config-panel"):
                yield Static("", id="config-text")

            # Token usage panel (hidden initially, shown during extraction)
            with Vertical(id="token-panel"):
                yield ActualUsageWidget(id="actual-usage")

            # Status and progress (hidden initially)
            with Vertical(id="status-panel"):
                yield Static("", id="status-text")
                yield ProgressBar(total=100, show_eta=False, id="progress-bar")

            # Results panel (hidden initially)
            with Vertical(id="results-panel"):
                yield Static("", id="results-text")

            # Action buttons
            with Horizontal(id="button-container"):
                yield Button("Start Extraction", id="start-extraction", variant="primary")
                yield Button("Review Details", id="review-details", variant="success")

    def on_mount(self) -> None:
        """Called when screen is mounted - load config and display info"""
        # Load configuration
        self._load_config()

        # Display summary
        self._update_summary()

        # Display config
        self._update_config()

        # Initially hide status panel
        status_panel = self.query_one("#status-panel", Vertical)
        status_panel.styles.display = "none"

        logging.info(f"ExtractionDetailsScreen mounted with {len(self.endpoints)} endpoints")

    def _load_config(self):
        """Load configuration from config file"""
        config_path = Path.home() / ".code-context" / "config.json"
        try:
            with open(config_path, 'r') as f:
                self.config_data = json.load(f)
                logging.info(f"Loaded config: provider={self.config_data.get('llm_provider')}, model={self.config_data.get('llm_model')}")
        except Exception as e:
            logging.error(f"Failed to load config: {e}")
            self.config_data = {
                "llm_provider": "unknown",
                "llm_model": "unknown"
            }

    def _update_summary(self):
        """Update summary panel with endpoint information"""
        summary_widget = self.query_one("#summary-text", Static)

        # Count endpoints by method
        from collections import Counter
        method_counts = Counter(endpoint.method for endpoint in self.endpoints)
        total_endpoints = len(self.endpoints)

        # Count unique files
        unique_files = len(set(endpoint.file_path for endpoint in self.endpoints))

        summary = f"📊 Endpoints to Extract:\n\n"
        summary += f"Total Endpoints: {total_endpoints}\n"
        summary += f"Unique Files: {unique_files}\n"

        if method_counts:
            summary += "\nBy Method:\n"
            for method in sorted(method_counts.keys()):
                summary += f"  {method}: {method_counts[method]}\n"

        summary_widget.update(summary)

    def _update_config(self):
        """Update config panel with current configuration"""
        config_widget = self.query_one("#config-text", Static)

        provider = self.config_data.get("llm_provider", "unknown")
        model = self.config_data.get("llm_model", "unknown")

        config = f"⚙️ Configuration:\n"
        config += f"  Provider: {provider}\n"
        config += f"  Model: {model}"

        config_widget.update(config)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        logging.info(f"Button pressed: {button_id}")

        if button_id == "start-extraction":
            if not self.extraction_in_progress and not self.extraction_complete:
                # Disable button to prevent double-clicks
                event.button.disabled = True
                event.button.label = "Extracting..."

                # Show status panel
                status_panel = self.query_one("#status-panel", Vertical)
                status_panel.styles.display = "block"

                # Show token usage panel
                token_panel = self.query_one("#token-panel", Vertical)
                token_panel.styles.display = "block"

                # Start extraction in background thread
                extraction_thread = threading.Thread(
                    target=self._run_extraction_logic,
                    daemon=True
                )
                extraction_thread.start()

        elif button_id == "review-details":
            # Navigate to review details screen
            if self.extracted_details:
                try:
                    from .review_details import ReviewDetailsScreen
                    logging.info(f"Navigating to review screen with {len(self.extracted_details)} details")
                    review_screen = ReviewDetailsScreen(
                        extracted_details=self.extracted_details,
                        project_path=self.project_path
                    )
                    self.app.push_screen(review_screen)
                except Exception as e:
                    logging.error(f"Error navigating to review screen: {e}", exc_info=True)
                    self._update_status(f"❌ Failed to open review screen: {str(e)}")

    def _run_extraction_logic(self):
        """Run detail extraction in background thread"""
        try:
            logging.info("=== DETAIL EXTRACTION STARTED ===")
            self.extraction_in_progress = True

            # Update status in main thread
            self.app.call_from_thread(self._update_status, "🔄 Starting extraction...")
            self.app.call_from_thread(self._update_progress, 0)

            # Import DetailExtractor
            from ...scanner.detail_extractor import EndpointDetailExtractor

            # Create extractor
            extractor = EndpointDetailExtractor(
                llm_provider=self.config_data.get("llm_provider"),
                llm_model=self.config_data.get("llm_model"),
                api_key=self.config_data.get("api_key"),
                presenter=None,
                batch_size=5
            )

            # Get project root (from first endpoint's path)
            if self.endpoints:
                first_file = Path(self.endpoints[0].file_path)
                # Find project root by looking for common project markers
                project_root = first_file.parent
                while project_root.parent != project_root:
                    if any((project_root / marker).exists() for marker in ['.git', 'setup.py', 'pyproject.toml', 'package.json']):
                        break
                    project_root = project_root.parent
            else:
                project_root = Path.cwd()

            logging.info(f"Using project root: {project_root}")

            # Extract details
            total = len(self.endpoints)
            results = []
            success_count = 0
            error_count = 0

            for idx, (detail, token_usage) in enumerate(extractor.extract_details(self.endpoints, project_root), 1):
                if detail:
                    results.append(detail)
                    success_count += 1

                    # Accumulate token usage
                    self.accumulated_tokens["input_tokens"] += token_usage.get("input_tokens", 0)
                    self.accumulated_tokens["output_tokens"] += token_usage.get("output_tokens", 0)
                    self.accumulated_tokens["total_tokens"] += token_usage.get("total_tokens", 0)

                    # Log the detailed information
                    logging.info(f"=== Extracted Detail {idx}/{total} ===")
                    logging.info(f"Endpoint ID: {detail.endpoint_id}")
                    logging.info(f"Description: {detail.description}")
                    logging.info(f"Embedding vector length: {len(detail.embed)}")
                    logging.info(f"Payload keys: {list(detail.payload.keys())}")
                    logging.info(f"Full payload: {json.dumps(detail.payload, indent=2, ensure_ascii=False)}")
                    logging.info(f"Token usage: {token_usage}")
                    logging.info("=" * 80)
                else:
                    error_count += 1

                # Update progress and token usage in main thread
                progress = (idx / total) * 100
                status = f"🔄 Extracting: {idx}/{total} (✓ {success_count}, ✗ {error_count})"
                self.app.call_from_thread(self._update_status, status)
                self.app.call_from_thread(self._update_progress, progress)
                self.app.call_from_thread(
                    self._update_token_usage,
                    self.accumulated_tokens["input_tokens"],
                    self.accumulated_tokens["output_tokens"]
                )

                logging.info(f"Processed {idx}/{total}: success={success_count}, errors={error_count}")

            self.extracted_details = results
            self.extraction_in_progress = False
            self.extraction_complete = True

            # Update final status in main thread
            self.app.call_from_thread(self._extraction_complete_update, success_count, error_count, total)

            logging.info(f"=== EXTRACTION COMPLETE: {success_count} succeeded, {error_count} failed ===")

        except Exception as e:
            logging.error(f"=== EXTRACTION ERROR ===", exc_info=True)
            self.extraction_in_progress = False
            self.app.call_from_thread(self._update_status, f"❌ Extraction failed: {str(e)}")

    def _update_status(self, text: str):
        """Update status text (called in main thread)"""
        try:
            status_widget = self.query_one("#status-text", Static)
            status_widget.update(text)
        except Exception as e:
            logging.error(f"Failed to update status: {e}")

    def _update_progress(self, value: float):
        """Update progress bar (called in main thread)"""
        try:
            progress_bar = self.query_one("#progress-bar", ProgressBar)
            progress_bar.update(progress=value)
        except Exception as e:
            logging.error(f"Failed to update progress: {e}")

    def _update_token_usage(self, input_tokens: int, output_tokens: int):
        """Update token usage display (called in main thread)"""
        try:
            token_widget = self.query_one("#actual-usage", ActualUsageWidget)
            token_widget.update_tokens(input_tokens, output_tokens)
        except Exception as e:
            logging.error(f"Failed to update token usage: {e}")

    def _extraction_complete_update(self, success_count: int, error_count: int, total: int):
        """Update UI when extraction is complete (called in main thread)"""
        try:
            # Update status
            self._update_status(f"✓ Extraction Complete: {success_count}/{total} succeeded")
            self._update_progress(100)

            # Show results panel
            results_panel = self.query_one("#results-panel", Vertical)
            results_panel.styles.display = "block"

            # Update results
            results_widget = self.query_one("#results-text", Static)
            results = f"✨ Extraction Results:\n\n"
            results += f"Successfully extracted: {success_count} endpoints\n"
            if error_count > 0:
                results += f"Failed: {error_count} endpoints\n"
            results += f"\nTotal details generated: {len(self.extracted_details)}\n"

            # Add token usage to results
            results += f"\n📊 Token Usage:\n"
            results += f"  Input:  {self.accumulated_tokens['input_tokens']:,} tokens\n"
            results += f"  Output: {self.accumulated_tokens['output_tokens']:,} tokens\n"
            results += f"  Total:  {self.accumulated_tokens['total_tokens']:,} tokens\n"

            if self.extracted_details:
                results += "\n✓ Details include descriptions, parameters, auth requirements,\n"
                results += "  responses, business logic, and usage examples."

            results_widget.update(results)

            # Update start button
            start_button = self.query_one("#start-extraction", Button)
            start_button.label = "✓ Extraction Complete"
            start_button.variant = "success"
            start_button.disabled = True

            # Show review button if we have extracted details
            if self.extracted_details:
                review_button = self.query_one("#review-details", Button)
                review_button.styles.display = "block"
                logging.info(f"Review button shown with {len(self.extracted_details)} details")

            logging.info("Extraction UI updated successfully")

        except Exception as e:
            logging.error(f"Error in extraction_complete_update: {e}", exc_info=True)