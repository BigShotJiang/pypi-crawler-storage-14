"""Parsing screen for code-context - Simple and working version."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal, ScrollableContainer
from textual.widgets import Static, Button, DataTable, ProgressBar
from pathlib import Path
from typing import Dict, List
import threading
import logging

logger = logging.getLogger(__name__)


class ParsingScreen(Screen):
    """Parsing screen - automatically parses endpoints and shows results"""

    CSS = """
    ParsingScreen {
        align: center top;
        padding: 1 0;
    }

    #parsing-container {
        width: 90;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    #status-text {
        width: 100%;
        margin-bottom: 1;
    }

    #progress-bar {
        width: 100%;
        margin-bottom: 2;
    }

    #stats-panel {
        width: 100%;
        border: solid $success;
        padding: 1;
        margin-bottom: 1;
        min-height: 6;
    }

    #endpoints-panel {
        width: 100%;
        height: 18;
        border: solid $accent;
        padding: 1;
        margin-bottom: 1;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    Button {
        margin: 0 1;
    }

    DataTable {
        height: 100%;
    }
    """

    def __init__(self, scan_results: Dict = None):
        super().__init__()
        self.scan_results = scan_results or {}
        self.endpoints = []
        self.parsing_complete = False
        self.project_path = None  # Will be set during parsing

    def compose(self) -> ComposeResult:
        """Compose the parsing screen"""
        with Container(id="parsing-container"):
            yield Static("🔍 Parsing Endpoints", id="title", classes="bold")
            yield Static("Initializing...", id="status-text")
            yield ProgressBar(total=100, show_eta=False, id="progress-bar")

            # Stats panel
            with Vertical(id="stats-panel"):
                yield Static("", id="stats-display")

            # Endpoints table
            with Vertical(id="endpoints-panel"):
                yield Static("Endpoints:", classes="bold")
                with ScrollableContainer():
                    yield DataTable(id="endpoints-table")

            # Action buttons
            with Horizontal(id="button-container"):
                yield Button("Extract Details", id="extract-details", variant="primary", disabled=True)
                yield Button("Re-scan Project", id="rescan", variant="default")
                yield Button("Exit", id="exit", variant="error")

    def on_mount(self) -> None:
        """Called when screen is mounted - start parsing automatically"""
        # Set up the endpoints table
        table = self.query_one("#endpoints-table", DataTable)
        table.add_columns("Method", "Route", "Function", "File", "Lines")

        # Start parsing in background thread
        parsing_thread = threading.Thread(
            target=self._run_parsing_logic,
            daemon=True
        )
        parsing_thread.start()

    def _run_parsing_logic(self):
        """Run endpoint parsing in background thread"""
        try:
            logging.info("=== PARSING STARTED (simple version) ===")

            # Get scan results
            candidates = self.scan_results.get("candidates", {})
            frameworks = self.scan_results.get("frameworks", [])
            project_path = Path(self.scan_results.get("project_path", "."))
            self.project_path = project_path  # Store for later use

            # Count total files
            total_files = sum(len(files) for files in candidates.values())
            logging.info(f"Parsing {total_files} files...")

            # Update status - use app.call_from_thread to update from main thread
            self.app.call_from_thread(self.update_status, f"🔄 Parsing {total_files} files...")

            # Import EndpointParser
            from ...scanner.endpoint_parser import EndpointParser

            # Create parser
            parser = EndpointParser(frameworks=frameworks)

            # Parse files
            current_file = 0
            all_endpoints = []

            for language, files in candidates.items():
                for file_path in files:
                    current_file += 1
                    logging.info(f"Parsing {file_path}...")

                    # Update progress
                    progress = (current_file / total_files) * 100
                    status = f"🔄 Parsing file {current_file}/{total_files}"
                    self.app.call_from_thread(self.update_status, status)
                    self.app.call_from_thread(self.update_progress, progress)

                    # Parse file
                    endpoints = parser.parser.parse_file(file_path, project_path)
                    all_endpoints.extend(endpoints)

                    # Add endpoints to table
                    if endpoints:
                        self.app.call_from_thread(self.add_endpoints_to_table, endpoints)

            # Store endpoints
            self.endpoints = all_endpoints
            logging.info(f"Parsing complete: found {len(all_endpoints)} endpoints")

            # Calculate statistics
            from collections import Counter
            method_counts = Counter(endpoint.method for endpoint in all_endpoints)
            total_endpoints = len(all_endpoints)

            logging.info(f"=== Stats Calculation ===")
            logging.info(f"Total endpoints: {total_endpoints}")
            logging.info(f"Method counts: {dict(method_counts)}")

            # Create stats text
            stats = "✓ Parsing Complete\n\n"
            stats += f"Total Endpoints: {total_endpoints}\n"
            stats += f"Files Processed: {total_files}\n"

            if method_counts:
                stats += "\nBy Method:\n"
                for method in sorted(method_counts.keys()):
                    count = method_counts[method]
                    stats += f"  {method}: {count}\n"
                    logging.info(f"  Adding to stats: {method}: {count}")

            logging.info(f"Final stats text length: {len(stats)} chars")
            logging.info(f"Stats preview: {stats[:200]}...")

            # Update UI
            self.app.call_from_thread(self.parsing_complete_update, stats)
            self.parsing_complete = True

            logging.info("=== PARSING COMPLETE ===")

        except Exception as e:
            logging.error(f"Parsing error: {e}", exc_info=True)
            self.app.call_from_thread(self.update_status, f"❌ Error: {str(e)}")

    def update_status(self, text: str):
        """Update status text (called in main thread)"""
        try:
            status_widget = self.query_one("#status-text", Static)
            status_widget.update(text)
            logging.info(f"Status updated: {text}")
        except Exception as e:
            logging.error(f"Failed to update status: {e}")

    def update_progress(self, value: float):
        """Update progress bar (called in main thread)"""
        try:
            progress_bar = self.query_one("#progress-bar", ProgressBar)
            progress_bar.update(progress=value)
        except Exception as e:
            logging.error(f"Failed to update progress: {e}")

    def add_endpoints_to_table(self, endpoints: List):
        """Add endpoints to table (called in main thread)"""
        table = self.query_one("#endpoints-table", DataTable)
        for endpoint in endpoints:
            table.add_row(
                endpoint.method,
                endpoint.route,
                endpoint.function_name,
                endpoint.file_path,
                f"{endpoint.start_line}-{endpoint.end_line}"
            )

    def parsing_complete_update(self, stats: str):
        """Update UI when parsing is complete (called in main thread)"""
        logging.info(f"=== parsing_complete_update called with stats: {stats[:100]}...")

        try:
            # Update status
            self.update_status("✓ Parsing Complete")
            self.update_progress(100)

            # Update stats display
            stats_display = self.query_one("#stats-display", Static)
            stats_display.update(stats)
            logging.info(f"Successfully updated stats display with {len(stats)} chars")

            # Enable extract button
            extract_button = self.query_one("#extract-details", Button)
            extract_button.disabled = False
            logging.info("Extract button enabled")

        except Exception as e:
            logging.error(f"Error in parsing_complete_update: {e}", exc_info=True)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        logging.info(f"Button pressed: {button_id}")

        if button_id == "extract-details":
            # Navigate to extraction details screen
            try:
                from .extraction_details import ExtractionDetailsScreen
                logging.info(f"Navigating to extraction screen with {len(self.endpoints)} endpoints")
                extraction_screen = ExtractionDetailsScreen(
                    endpoints=self.endpoints,
                    project_path=self.project_path
                )
                self.app.push_screen(extraction_screen)
            except Exception as e:
                logging.error(f"Error navigating to extraction screen: {e}", exc_info=True)
                self.update_status(f"❌ Failed to open extraction screen: {str(e)}")

        elif button_id == "rescan":
            try:
                self.app.switch_screen("project_select")
            except Exception as e:
                logging.error(f"Error switching to project_select: {e}", exc_info=True)

        elif button_id == "exit":
            self.app.exit()