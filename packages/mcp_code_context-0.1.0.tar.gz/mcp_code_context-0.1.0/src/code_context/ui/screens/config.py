"""Configuration screen for code-context."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, Input, Select, Label
from textual.validation import ValidationResult, Validator
from pathlib import Path
import json

# Model configurations from test_final_models.py
MODEL_CONFIGS = {
    "openai": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo"],
    "gemini": ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite", "gemini-2.0-flash-exp"],
    "deepseek": ["deepseek-chat", "deepseek-reasoner"],
    "qwen": ["qwen-plus", "qwen3-max", "qwen-flash", "qwen-turbo"],
}


class ConfigScreen(Screen):
    """Configuration screen for LLM settings"""

    CSS = """
    ConfigScreen {
        align: center middle;
    }

    #config-container {
        width: 80;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    .form-group {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    .form-label {
        width: 100%;
        margin-bottom: 1;
        color: $text;
    }

    Input {
        width: 100%;
        margin-bottom: 1;
    }

    Select {
        width: 100%;
        margin-bottom: 1;
    }

    #embedding-group {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    #message {
        width: 100%;
        text-align: center;
        margin: 1 0;
        padding: 1;
        height: 3;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 2;
    }

    Button {
        margin: 0 1;
    }
    """

    def __init__(self):
        super().__init__()
        self.config_data = self._load_existing_config()
        self.current_provider = self.config_data.get("llm_provider", "openai")

    def compose(self) -> ComposeResult:
        """Compose the configuration screen"""
        with Container(id="config-container"):
            yield Static("⚙️  LLM Configuration", id="title", classes="bold")

            # Provider selection
            with Vertical(classes="form-group"):
                yield Label("LLM Provider:", classes="form-label")
                yield Select(
                    [
                        ("OpenAI", "openai"),
                        ("Google Gemini", "gemini"),
                        ("DeepSeek", "deepseek"),
                        ("Qwen", "qwen"),
                    ],
                    id="provider-select",
                    value=self.config_data.get("llm_provider", "openai"),
                )

            # Model selection
            with Vertical(classes="form-group"):
                yield Label("Model Name:", classes="form-label")
                # Get models for current provider
                models = MODEL_CONFIGS.get(self.current_provider, [])
                model_options = [(model, model) for model in models]
                current_model = self.config_data.get("llm_model", models[0] if models else "")
                yield Select(
                    model_options,
                    id="model-select",
                    value=current_model if current_model in models else (models[0] if models else ""),
                )

            # API Key input
            with Vertical(classes="form-group"):
                yield Label("API Key:", classes="form-label")
                yield Input(
                    placeholder="Enter your API key",
                    id="api-key-input",
                    password=True,
                    value=self.config_data.get("api_key", ""),
                )

            # Embedding API Key input (conditional - only shown for non-OpenAI providers)
            with Vertical(id="embedding-group", classes="form-group"):
                yield Label("OpenAI API Key (for Embedding):", classes="form-label")
                yield Input(
                    placeholder="Enter OpenAI API key for text embeddings",
                    id="embedding-key-input",
                    password=True,
                    value=self.config_data.get("embedding_api_key", ""),
                )
                yield Static(
                    "💡 Required for generating embeddings (uses OpenAI text-embedding-3-large)",
                    classes="dim",
                )

            # Message area for feedback
            yield Static("", id="message")

            # Action buttons
            with Horizontal(id="button-container"):
                yield Button("Save & Continue", id="save", variant="primary")
                yield Button("Back", id="back", variant="default")

    def on_mount(self) -> None:
        """Called when screen is mounted - set initial embedding key visibility"""
        self._update_embedding_key_visibility(self.current_provider)

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select changes"""
        if event.select.id == "provider-select":
            # Provider changed, update model options
            new_provider = event.value
            self.current_provider = new_provider

            # Get new model options
            models = MODEL_CONFIGS.get(new_provider, [])
            model_select = self.query_one("#model-select", Select)

            # Update model select options
            model_options = [(model, model) for model in models]
            model_select.set_options(model_options)

            # Set first model as default
            if models:
                model_select.value = models[0]

            # Update embedding key visibility based on new provider
            self._update_embedding_key_visibility(new_provider)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        if button_id == "save":
            self._save_config()
        elif button_id == "back":
            self.app.pop_screen()

    def _update_embedding_key_visibility(self, provider: str) -> None:
        """Show or hide embedding key input based on provider

        Args:
            provider: LLM provider name
        """
        embedding_group = self.query_one("#embedding-group", Vertical)

        if provider == "openai":
            # Hide embedding key input for OpenAI (will reuse same API key)
            embedding_group.styles.display = "none"
        else:
            # Show embedding key input for non-OpenAI providers
            embedding_group.styles.display = "block"

    def _save_config(self) -> None:
        """Validate and save configuration"""
        # Get values from selects and inputs
        provider_select = self.query_one("#provider-select", Select)
        model_select = self.query_one("#model-select", Select)
        api_key_input = self.query_one("#api-key-input", Input)
        embedding_key_input = self.query_one("#embedding-key-input", Input)
        message_widget = self.query_one("#message", Static)

        provider = provider_select.value
        model = model_select.value
        api_key = api_key_input.value.strip()
        embedding_key = embedding_key_input.value.strip()

        # Validate
        if not model:
            message_widget.update("❌ Please select a model")
            message_widget.styles.color = "red"
            return

        if not api_key:
            message_widget.update("❌ Please enter an API key")
            message_widget.styles.color = "red"
            return

        # For non-OpenAI providers, validate embedding key
        if provider != "openai" and not embedding_key:
            message_widget.update("❌ Please enter OpenAI API key for embeddings")
            message_widget.styles.color = "red"
            return

        # Save to config file
        config_dir = Path.home() / ".code-context"
        config_dir.mkdir(exist_ok=True)
        config_path = config_dir / "config.json"

        # Prepare config data
        config = {
            "llm_provider": provider,
            "llm_model": model,
            "api_key": api_key,
        }

        # Add embedding key based on provider
        if provider == "openai":
            # For OpenAI, use the same API key for both LLM and embedding
            config["embedding_api_key"] = api_key
        else:
            # For other providers, use the separate embedding key
            config["embedding_api_key"] = embedding_key

        # Always specify embedding provider and model
        config["embedding_provider"] = "openai"
        config["embedding_model"] = "text-embedding-3-large"

        try:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)

            message_widget.update("✓ Configuration saved successfully!")
            message_widget.styles.color = "green"

            # Navigate to project selection after a brief moment
            self.set_timer(1.0, lambda: self.app.switch_screen("project_select"))

        except IOError as e:
            message_widget.update(f"❌ Failed to save config: {e}")
            message_widget.styles.color = "red"

    def _load_existing_config(self) -> dict:
        """Load existing configuration if available

        Returns:
            Configuration dictionary or empty dict
        """
        config_path = Path.home() / ".code-context" / "config.json"

        if not config_path.exists():
            return {}

        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
