"""Scanning screen for code-context."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, ProgressBar
from rich.text import Text
from typing import Dict, List
from pathlib import Path


class ProjectNameWidget(Static):
    """Widget to display project name"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.project_path = ""

    def render(self) -> Text:
        text = Text()
        text.append("Project: ", style="cyan")
        text.append(self.project_path if self.project_path else "...", style="bold")
        return text

    def update_path(self, path: str):
        self.project_path = path
        self.refresh()


class FrameworkWidget(Static):
    """Widget to display detected framework"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.frameworks = []

    def render(self) -> Text:
        text = Text()
        text.append("Framework: ", style="cyan")
        if self.frameworks:
            text.append(", ".join(self.frameworks), style="green bold")
        else:
            text.append("Generic", style="dim")
        return text

    def update_frameworks(self, frameworks: List[str]):
        self.frameworks = frameworks
        self.refresh()


class PreFilterWidget(Static):
    """Widget to display pre-filtering status"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.total_files = 0
        self.excluded_files = 0

    def render(self) -> Text:
        text = Text()
        text.append("Pre-filtering project: ", style="cyan")
        if self.total_files > 0:
            text.append(f"{self.total_files} files, {self.excluded_files} excluded", style="")
        else:
            text.append("...", style="dim")
        return text

    def update_status(self, total: int, excluded: int):
        self.total_files = total
        self.excluded_files = excluded
        self.refresh()


class CandidateListWidget(Static):
    """Widget to display candidate files"""

    MAX_DISPLAY = 10

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.files = []

    def render(self) -> Text:
        if not self.files:
            return Text("No candidates yet...", style="dim")

        text = Text()
        text.append(f"Candidate Files ({len(self.files)}):\n", style="cyan bold")

        display_files = self.files[:self.MAX_DISPLAY]
        for file_path in display_files:
            text.append("  • ", style="dim")
            text.append(file_path + "\n", style="")

        remaining = len(self.files) - self.MAX_DISPLAY
        if remaining > 0:
            text.append(f"  ... and {remaining} more", style="dim italic")

        return text

    def update_files(self, files: List[str]):
        self.files = files
        self.refresh()


class ActualUsageWidget(Static):
    """Widget to display actual token usage"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.input_tokens = 0
        self.output_tokens = 0

    def render(self) -> Text:
        text = Text()
        text.append("Actual Usage:\n", style="cyan bold")
        text.append(f"Input:  {self.input_tokens:,} tokens\n", style="green")
        text.append(f"Output: {self.output_tokens:,} tokens", style="green")
        return text

    def update_tokens(self, input_tokens: int, output_tokens: int):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.refresh()


class LLMProgressWidget(Static):
    """Widget to display LLM filtering progress"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_batch = 0
        self.total_batches = 0
        self.status = "pending"

    def render(self) -> Text:
        text = Text()

        if self.status == "pending":
            text.append("⏳ LLM Filtering: ", style="yellow")
            text.append("Waiting...", style="dim")
        elif self.status == "in_progress":
            text.append("🔄 LLM Filtering: ", style="cyan")
            if self.total_batches > 0:
                text.append(f"Batch {self.current_batch}/{self.total_batches}", style="")
        elif self.status == "completed":
            text.append("✓ LLM Filtering: ", style="green")
            text.append("Complete", style="green bold")

        return text

    def update_progress(self, current: int, total: int, status: str = "in_progress"):
        self.current_batch = current
        self.total_batches = total
        self.status = status
        self.refresh()


class ScanningScreen(Screen):
    """Scanning screen - shows real-time scan progress"""

    CSS = """
    ScanningScreen {
        align: center middle;
    }

    #scanning-container {
        width: 90;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    .info-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    #project-name {
        width: 70%;
        border: solid $accent;
        padding: 1;
    }

    #framework {
        width: 30%;
        border: solid $accent;
        padding: 1;
    }

    #prefilter-status {
        width: 100%;
        border: solid $accent;
        padding: 1;
        margin-bottom: 1;
    }

    #llm-panel {
        width: 100%;
        border: solid $accent;
        padding: 1;
        margin-bottom: 1;
    }

    #llm-progress {
        width: 100%;
        margin-bottom: 1;
    }

    #progress-bar {
        width: 100%;
        margin-bottom: 1;
    }

    .details-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    #candidate-list {
        width: 50%;
        border: solid $accent;
        padding: 1;
        height: 12;
    }

    #actual-usage {
        width: 50%;
        border: solid $accent;
        padding: 1;
    }

    Button {
        margin: 0 1;
    }

    #scan-complete-message {
        padding: 1;
        margin-bottom: 1;
        text-align: center;
        border: solid $success;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
    ]

    def __init__(self, project_path: str = ""):
        super().__init__()
        self.project_path = project_path
        self.scan_complete = False

    def compose(self) -> ComposeResult:
        """Compose the scanning screen"""
        with Container(id="scanning-container"):
            yield Static("🔍 Scanning Project", id="title", classes="bold")

            # Row 1: Project name | Framework
            with Horizontal(classes="info-row"):
                yield ProjectNameWidget(id="project-name")
                yield FrameworkWidget(id="framework")

            # Row 2: Pre-filter status
            yield PreFilterWidget(id="prefilter-status")

            # Row 3: LLM Filtering Panel
            with Vertical(id="llm-panel"):
                yield LLMProgressWidget(id="llm-progress")
                yield ProgressBar(total=100, show_eta=False, id="progress-bar")

                # Candidate list | Actual usage
                with Horizontal(classes="details-row"):
                    yield CandidateListWidget(id="candidate-list")
                    yield ActualUsageWidget(id="actual-usage")

    def on_mount(self) -> None:
        """Called when screen is mounted"""
        # Initialize project path
        project_name = self.query_one("#project-name", ProjectNameWidget)
        project_name.update_path(self.project_path)

    def update_project_info(self, path: str, frameworks: List[str]):
        """Update project information"""
        project_name = self.query_one("#project-name", ProjectNameWidget)
        project_name.update_path(path)

        framework = self.query_one("#framework", FrameworkWidget)
        framework.update_frameworks(frameworks)

    def update_step(self, step_id: str, status: str, details: str = ""):
        """Update a progress step"""
        if step_id == "prefilter":
            # Parse details like "214 files (excluded 30)"
            if "files" in details and "excluded" in details:
                import re
                match = re.search(r'(\d+) files.*excluded (\d+)', details)
                if match:
                    total = int(match.group(1))
                    excluded = int(match.group(2))
                    prefilter = self.query_one("#prefilter-status", PreFilterWidget)
                    prefilter.update_status(total, excluded)

    def update_llm_progress(self, batch_num: int, total_batches: int):
        """Update LLM filtering progress"""
        llm_progress = self.query_one("#llm-progress", LLMProgressWidget)
        llm_progress.update_progress(batch_num, total_batches, "in_progress")

        # Update progress bar
        if total_batches > 0:
            percentage = (batch_num / total_batches) * 100
            progress_bar = self.query_one("#progress-bar", ProgressBar)
            progress_bar.update(progress=percentage)

    def update_actual_usage(self, input_tokens: int, output_tokens: int):
        """Update actual token usage"""
        actual_usage = self.query_one("#actual-usage", ActualUsageWidget)
        actual_usage.update_tokens(input_tokens, output_tokens)

    def complete_llm_filtering(self):
        """Mark LLM filtering as completed"""
        llm_progress = self.query_one("#llm-progress", LLMProgressWidget)
        llm_progress.update_progress(0, 0, "completed")

        # Set progress bar to 100%
        progress_bar = self.query_one("#progress-bar", ProgressBar)
        progress_bar.update(progress=100)

    def add_candidate_files(self, files: List[str]):
        """Add candidate files to the list"""
        candidate_list = self.query_one("#candidate-list", CandidateListWidget)
        candidate_list.update_files(files)

    def mark_scan_complete(self):
        """Mark scan as complete and show completion UI"""
        self.scan_complete = True

        # Add completion message and button if not already present
        try:
            self.query_one("#scan-complete-message")
        except:
            container = self.query_one("#scanning-container", Container)
            container.mount(Static(
                "✓ Scan Complete! Candidate files identified.",
                id="scan-complete-message"
            ))
            container.mount(Container(
                Button("Parse Endpoints", id="parse-endpoints", variant="primary"),
                Button("Re-scan", id="rescan", variant="default"),
                id="button-container"
            ))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        if button_id == "parse-endpoints":
            self.app.push_screen("parsing")
        elif button_id == "rescan":
            self.app.switch_screen("project_select")
