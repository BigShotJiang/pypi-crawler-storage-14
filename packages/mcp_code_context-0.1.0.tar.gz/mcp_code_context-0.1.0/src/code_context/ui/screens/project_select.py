"""Project selection screen for code-context."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal, ScrollableContainer
from textual.widgets import Static, Button, Input, Label, DirectoryTree
from pathlib import Path
import os


class ProjectSelectScreen(Screen):
    """Project selection screen"""

    CSS = """
    ProjectSelectScreen {
        align: center middle;
    }

    #project-container {
        width: 90;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    .form-group {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    .form-label {
        width: 100%;
        margin-bottom: 1;
        color: $text;
    }

    Input {
        width: 100%;
        margin-bottom: 1;
    }

    #directory-tree-container {
        width: 100%;
        height: 12;
        border: solid $accent;
        margin-bottom: 1;
    }

    DirectoryTree {
        width: 100%;
        height: 100%;
    }

    #path-info {
        width: 100%;
        padding: 1;
        margin-bottom: 1;
        border: solid $accent;
        text-align: center;
    }

    #message {
        width: 100%;
        text-align: center;
        margin: 1 0;
        padding: 1;
        height: 3;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    Button {
        margin: 0 1;
    }
    """

    def __init__(self):
        super().__init__()
        self.selected_path = Path.cwd()

    def compose(self) -> ComposeResult:
        """Compose the project selection screen"""
        with Container(id="project-container"):
            yield Static("📁 Select Project Directory", id="title", classes="bold")

            # Current/manual path input
            with Vertical(classes="form-group"):
                yield Label("Project Path:", classes="form-label")
                yield Input(
                    placeholder="Enter project path or use directory tree below",
                    id="path-input",
                    value=str(self.selected_path),
                )

            # Directory tree for browsing
            with Vertical(classes="form-group"):
                yield Label("Or browse:", classes="form-label")
                with ScrollableContainer(id="directory-tree-container"):
                    yield DirectoryTree(str(Path.cwd()), id="directory-tree")

            # Selected path info
            yield Static(
                f"Selected: {self.selected_path}",
                id="path-info"
            )

            # Message area
            yield Static("", id="message")

            # Action buttons
            with Horizontal(id="button-container"):
                yield Button("Start Scan", id="start-scan", variant="primary")
                yield Button("Use Current Dir", id="use-current", variant="default")
                yield Button("Back", id="back", variant="default")

    def on_directory_tree_directory_selected(self, event: DirectoryTree.DirectorySelected) -> None:
        """Handle directory selection from tree"""
        self.selected_path = Path(event.path)

        # Update input and info
        path_input = self.query_one("#path-input", Input)
        path_info = self.query_one("#path-info", Static)

        path_input.value = str(self.selected_path)
        path_info.update(f"Selected: {self.selected_path}")

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle manual path input"""
        if event.input.id == "path-input":
            path_str = event.value.strip()
            if path_str:
                self.selected_path = Path(path_str).expanduser()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        if button_id == "start-scan":
            self._validate_and_start_scan()
        elif button_id == "use-current":
            self.selected_path = Path.cwd()
            path_input = self.query_one("#path-input", Input)
            path_info = self.query_one("#path-info", Static)
            path_input.value = str(self.selected_path)
            path_info.update(f"Selected: {self.selected_path}")
        elif button_id == "back":
            self.app.pop_screen()

    def _validate_and_start_scan(self) -> None:
        """Validate selected path and start scan"""
        message_widget = self.query_one("#message", Static)

        # Expand user path
        path = self.selected_path.expanduser().resolve()

        # Validate path
        if not path.exists():
            message_widget.update(f"❌ Path does not exist: {path}")
            message_widget.styles.color = "red"
            return

        if not path.is_dir():
            message_widget.update(f"❌ Path is not a directory: {path}")
            message_widget.styles.color = "red"
            return

        # Check if it's a code project (has some code files)
        code_extensions = {'.py', '.js', '.ts', '.go', '.rs', '.java', '.rb', '.php'}
        has_code = any(
            f.suffix in code_extensions
            for f in path.rglob('*')
            if f.is_file() and not any(part.startswith('.') for part in f.parts)
        )

        if not has_code:
            message_widget.update("⚠ Warning: No code files detected in this directory")
            message_widget.styles.color = "yellow"
            # Still allow proceeding
            self.set_timer(1.5, lambda: self._proceed_to_scan(path))
        else:
            message_widget.update(f"✓ Valid project directory")
            message_widget.styles.color = "green"
            self.set_timer(0.5, lambda: self._proceed_to_scan(path))

    def _proceed_to_scan(self, path: Path) -> None:
        """Proceed to scanning screen with selected path"""
        # Store the selected path in app for ScanningScreen to use
        self.app.project_path = str(path)
        self.app.switch_screen("scanning")
