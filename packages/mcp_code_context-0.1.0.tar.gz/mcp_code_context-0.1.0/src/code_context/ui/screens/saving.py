"""Saving screen for storing endpoints to Qdrant database."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, ProgressBar, Input
from pathlib import Path
from typing import List
import threading
import logging
import json
import re

logger = logging.getLogger(__name__)


def generate_default_collection_name(project_path: Path) -> str:
    """Generate a default collection name from project path."""
    if not project_path:
        return "endpoints"

    # Get the project folder name
    name = project_path.name

    # Replace invalid characters with underscore
    name = re.sub(r'[^a-zA-Z0-9_-]', '_', name)

    # Remove leading/trailing underscores
    name = name.strip('_-')

    # Ensure it's not empty
    if not name:
        name = "endpoints"

    # Convert to lowercase and limit length
    return name.lower()[:100]


def validate_collection_name(name: str) -> tuple[bool, str]:
    """Validate collection name according to Qdrant rules.

    Returns:
        (is_valid, error_message)
    """
    if not name:
        return False, "Collection name cannot be empty"

    if len(name) > 255:
        return False, "Collection name too long (max 255 characters)"

    if not re.match(r'^[a-zA-Z0-9_-]+$', name):
        return False, "Only letters, numbers, underscore, and hyphen allowed"

    if name.startswith('-') or name.startswith('_'):
        return False, "Name cannot start with - or _"

    return True, ""


class SavingScreen(Screen):
    """Screen for saving extracted endpoints to Qdrant database"""

    CSS = """
    SavingScreen {
        align: center top;
        padding: 1 0;
    }

    #saving-container {
        width: 90;
        height: auto;
        border: solid $primary;
        background: $surface;
        padding: 2;
    }

    #title {
        width: 100%;
        text-align: center;
        margin-bottom: 2;
    }

    #collection-panel {
        width: 100%;
        border: solid $primary;
        padding: 1;
        margin-bottom: 2;
        min-height: 4;
    }

    #collection-input {
        width: 100%;
        margin-top: 1;
    }

    #collection-error {
        color: $error;
        margin-top: 1;
        display: none;
    }

    #connection-panel {
        width: 100%;
        border: solid $success;
        padding: 1;
        margin-bottom: 2;
        min-height: 4;
    }

    #embedding-panel {
        width: 100%;
        border: solid $warning;
        padding: 1;
        margin-bottom: 2;
        min-height: 4;
    }

    #progress-panel {
        width: 100%;
        border: solid $primary;
        padding: 1;
        margin-bottom: 2;
        min-height: 4;
        display: none;
    }

    #results-panel {
        width: 100%;
        border: solid $success;
        padding: 1;
        margin-bottom: 2;
        min-height: 6;
        display: none;
    }

    #status-text {
        width: 100%;
        margin-bottom: 1;
    }

    #progress-bar {
        width: 100%;
        margin-bottom: 1;
    }

    #button-container {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    Button {
        margin: 0 1;
    }

    .success {
        color: $success;
    }

    .error {
        color: $error;
    }

    .dim {
        color: $text-muted;
    }
    """

    def __init__(self, extracted_details: List = None, project_path=None):
        super().__init__()
        self.extracted_details = extracted_details or []
        self.project_path = project_path
        self.connection_status = None
        self.embedding_config = None
        self.saving_in_progress = False
        self.saving_complete = False
        self.collection_name = None  # Will be set from input

    def compose(self) -> ComposeResult:
        """Compose the saving screen"""
        with Container(id="saving-container"):
            yield Static("💾 Save to Qdrant Database", id="title", classes="bold")

            # Collection name input panel
            with Vertical(id="collection-panel"):
                yield Static("📚 Collection Name", classes="bold")
                default_name = generate_default_collection_name(self.project_path)
                yield Input(
                    placeholder="Enter collection name",
                    value=default_name,
                    id="collection-input"
                )
                yield Static("", id="collection-error")

            # Connection status panel
            with Vertical(id="connection-panel"):
                yield Static("🔌 Connection Status", classes="bold")
                yield Static("", id="connection-text")

            # Embedding configuration panel
            with Vertical(id="embedding-panel"):
                yield Static("⚙️  Embedding Configuration", classes="bold")
                yield Static("", id="embedding-text")

            # Progress panel (hidden initially)
            with Vertical(id="progress-panel"):
                yield Static("📊 Saving Progress", classes="bold")
                yield Static("", id="status-text")
                yield ProgressBar(total=100, show_eta=False, id="progress-bar")

            # Results panel (hidden initially)
            with Vertical(id="results-panel"):
                yield Static("", id="results-text")

            # Action buttons
            with Horizontal(id="button-container"):
                yield Button("Start Saving", id="start-saving", variant="primary")
                yield Button("Back to Review", id="back", variant="default")

    def on_mount(self) -> None:
        """Called when screen is mounted - check connection and config"""
        logger.info(f"SavingScreen mounted with {len(self.extracted_details)} endpoints")

        # Load previous collection name for this project if exists
        self._load_previous_collection_name()

        # Set initial collection name from input
        collection_input = self.query_one("#collection-input", Input)
        self.collection_name = collection_input.value

        # Check Qdrant connection
        self._check_qdrant_connection()

        # Load embedding configuration
        self._load_embedding_config()

    def _load_previous_collection_name(self):
        """Load previously used collection name for this project."""
        try:
            if not self.project_path:
                return

            from ...config import ConfigManager
            config_mgr = ConfigManager()

            if not config_mgr.config_exists():
                return

            config = config_mgr.load_config()
            projects = config.get("projects", {})
            project_str = str(self.project_path)

            if project_str in projects:
                project_info = projects[project_str]
                saved_collection = project_info.get("collection_name")

                if saved_collection:
                    # Update the input field with saved collection name
                    collection_input = self.query_one("#collection-input", Input)
                    collection_input.value = saved_collection
                    logger.info(f"Loaded saved collection name: {saved_collection}")

        except Exception as e:
            logger.warning(f"Failed to load previous collection name: {e}")

    def _check_qdrant_connection(self):
        """Check Qdrant client connection and update UI"""
        try:
            from ...tools import get_db_manager
            from ...config import get_config

            # Get database manager
            db = get_db_manager()
            config = get_config()

            # Check if Qdrant is accessible
            is_healthy = db.ping()

            # Build connection status
            self.connection_status = {
                "status": "healthy" if is_healthy else "unhealthy",
                "mode": "local_file",
                "path": str(config.qdrant_path),
                "initialized": True
            }

            logger.info(f"Qdrant connection status: {self.connection_status}")

            # Update UI
            self._update_connection_display()

        except Exception as e:
            logger.error(f"Failed to check Qdrant connection: {e}", exc_info=True)
            self.connection_status = {
                "status": "unhealthy",
                "error": str(e),
                "initialized": False,
                "mode": "local_file"
            }
            self._update_connection_display()

    def _load_embedding_config(self):
        """Load embedding configuration from config file"""
        try:
            from ...config import ConfigManager

            config_mgr = ConfigManager()
            if not config_mgr.config_exists():
                self.embedding_config = {
                    "provider": "Not configured",
                    "model": "Not configured",
                    "api_key_masked": "N/A"
                }
            else:
                config = config_mgr.load_config()

                # Support both old flat format and new nested format
                # New format: config["embedding"]["provider"]
                # Old format: config["embedding_provider"]
                embedding = config.get("embedding", {})

                if embedding:
                    # New nested format
                    provider = embedding.get("provider", "openai")
                    model = embedding.get("model", "text-embedding-3-small")
                    api_key = embedding.get("api_key", "")
                else:
                    # Old flat format - fallback
                    provider = config.get("embedding_provider", "openai")
                    model = config.get("embedding_model", "text-embedding-3-small")
                    api_key = config.get("embedding_api_key", "")

                self.embedding_config = {
                    "provider": provider,
                    "model": model,
                    "api_key_masked": self._mask_api_key(api_key)
                }

            # Update UI
            self._update_embedding_display()

        except Exception as e:
            logger.error(f"Failed to load embedding config: {e}")
            self.embedding_config = {
                "provider": "Error loading config",
                "model": "Error loading config",
                "api_key_masked": "Error"
            }
            self._update_embedding_display()

    def _mask_api_key(self, api_key: str) -> str:
        """Mask API key for display"""
        if not api_key or len(api_key) < 8:
            return "Not set"
        return f"{api_key[:4]}...{api_key[-4:]}"

    def _update_connection_display(self):
        """Update connection status display"""
        connection_widget = self.query_one("#connection-text", Static)

        if not self.connection_status:
            connection_widget.update("Status: Unknown")
            return

        status = self.connection_status.get("status", "unknown")
        mode = self.connection_status.get("mode", "local_file")
        path = self.connection_status.get("path", "")

        if status == "healthy":
            text = f"[green]✓ Connected[/green]\n"
            text += f"Mode: {mode}\n"
            text += f"Path: {path}"
        elif status == "unhealthy":
            error = self.connection_status.get("error", "Unknown error")
            text = f"[red]✗ Connection Failed[/red]\n"
            text += f"Mode: {mode}\n"
            text += f"Error: {error}"
        else:
            text = f"Status: {status}"

        connection_widget.update(text)

    def _update_embedding_display(self):
        """Update embedding configuration display"""
        embedding_widget = self.query_one("#embedding-text", Static)

        if not self.embedding_config:
            embedding_widget.update("Configuration not loaded")
            return

        provider = self.embedding_config.get("provider", "Unknown")
        model = self.embedding_config.get("model", "Unknown")
        api_key = self.embedding_config.get("api_key_masked", "Not set")

        text = f"Provider: {provider}\n"
        text += f"Model: {model}\n"
        text += f"API Key: {api_key}"

        embedding_widget.update(text)

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input value changes"""
        if event.input.id == "collection-input":
            # Validate collection name
            is_valid, error_msg = validate_collection_name(event.value)

            error_widget = self.query_one("#collection-error", Static)

            if is_valid:
                self.collection_name = event.value
                error_widget.update("")
                error_widget.styles.display = "none"
            else:
                self.collection_name = None
                error_widget.update(f"❌ {error_msg}")
                error_widget.styles.display = "block"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id

        logger.info(f"Button pressed: {button_id}")

        if button_id == "start-saving":
            if not self.saving_in_progress and not self.saving_complete:
                # Check if collection name is valid
                if not self.collection_name:
                    self._update_status("❌ Cannot save: Invalid collection name", is_error=True)
                    return

                # Check if connection is healthy
                if not self.connection_status or self.connection_status.get("status") != "healthy":
                    # Show error message
                    self._update_status("❌ Cannot save: Connection not healthy", is_error=True)
                    return

                # Disable button
                event.button.disabled = True
                event.button.label = "Saving..."

                # Show progress panel
                progress_panel = self.query_one("#progress-panel", Vertical)
                progress_panel.styles.display = "block"

                # Start saving in background thread
                saving_thread = threading.Thread(
                    target=self._save_to_qdrant,
                    daemon=True
                )
                saving_thread.start()

        elif button_id == "back":
            # Go back to review screen
            self.app.pop_screen()

    def _save_to_qdrant(self):
        """Execute batch saving to Qdrant (runs in background thread)"""
        try:
            logger.info("=== SAVING TO QDRANT STARTED ===")
            self.saving_in_progress = True

            # Update status
            self.app.call_from_thread(self._update_status, "🔄 Preparing to save...")
            self.app.call_from_thread(self._update_progress, 0)

            # Import required modules
            from ...database import Endpoint
            from ...tools import get_db_manager

            # Get database manager
            db = get_db_manager()

            # Ensure collection exists
            self.app.call_from_thread(
                self._update_status,
                f"🔄 Checking collection '{self.collection_name}'..."
            )

            try:
                # Check if collection exists
                collections = db.list_all_collections()
                if self.collection_name not in collections:
                    # Create collection with custom name
                    db.create_collection(
                        name=self.collection_name,
                        vector_size=None  # Will use config default
                    )
                    logger.info(f"Created collection: {self.collection_name}")
                else:
                    logger.info(f"Using existing collection: {self.collection_name}")
            except Exception as e:
                logger.warning(f"Collection check/create warning: {e}")

            # Convert EndpointDetails to Endpoints and extract vectors
            self.app.call_from_thread(self._update_status, "🔄 Converting endpoints...")

            endpoints = []
            vectors = []

            for detail in self.extracted_details:
                # Convert EndpointDetail to Endpoint
                endpoint = self._convert_detail_to_endpoint(detail)
                endpoints.append(endpoint)
                vectors.append(detail.embed)

            # Bulk save
            total = len(endpoints)
            self.app.call_from_thread(
                self._update_status,
                f"🔄 Saving {total} endpoints..."
            )

            saved_ids = db.bulk_add_endpoints(
                endpoints, vectors, collection_name=self.collection_name
            )

            # Complete
            self.saving_in_progress = False
            self.saving_complete = True

            self.app.call_from_thread(self._update_progress, 100)
            self.app.call_from_thread(
                self._saving_complete_update,
                len(saved_ids),
                total
            )

            # Save the collection name for this project
            self._save_collection_mapping()

            logger.info(f"=== SAVING COMPLETE: {len(saved_ids)} endpoints saved to collection '{self.collection_name}' ===")

        except Exception as e:
            logger.error("=== SAVING ERROR ===", exc_info=True)
            self.saving_in_progress = False
            self.app.call_from_thread(
                self._update_status,
                f"❌ Save failed: {str(e)}",
                is_error=True
            )

    def _save_collection_mapping(self):
        """Save the collection name mapping for this project."""
        try:
            if not self.project_path or not self.collection_name:
                return

            from ...config import ConfigManager
            config_mgr = ConfigManager()

            # Prepare project info
            project_info = {
                "collection_name": self.collection_name,
                "endpoint_count": len(self.extracted_details),
                "last_saved": logger._core.handlers[0].formatter.datefmt if hasattr(logger, '_core') else None
            }

            # Save to config
            config_mgr.update_project_info(str(self.project_path), project_info)
            logger.info(f"Saved collection mapping: {self.project_path} -> {self.collection_name}")

        except Exception as e:
            logger.warning(f"Failed to save collection mapping: {e}")

    def _convert_detail_to_endpoint(self, detail) -> 'Endpoint':
        """Convert EndpointDetail to Endpoint model"""
        from ...database import Endpoint
        import uuid

        # Extract core fields from detail.payload
        payload = detail.payload

        return Endpoint(
            id=str(uuid.uuid4()),
            name=payload.get("function_name", "unknown"),
            route=payload.get("path", "/unknown"),
            method=payload.get("method", "GET"),
            file_path=payload.get("file_path", ""),
            description=detail.description,
            # Add other fields from payload as needed
            parameters=payload.get("parameters"),
            response_format=payload.get("responses"),
            framework="FastAPI",  # Default, can be extracted from payload
            language="python",  # Default
        )

    def _update_status(self, text: str, is_error: bool = False):
        """Update status text (called in main thread)"""
        try:
            status_widget = self.query_one("#status-text", Static)
            if is_error:
                status_widget.update(f"[red]{text}[/red]")
            else:
                status_widget.update(text)
        except Exception as e:
            logger.error(f"Failed to update status: {e}")

    def _update_progress(self, value: float):
        """Update progress bar (called in main thread)"""
        try:
            progress_bar = self.query_one("#progress-bar", ProgressBar)
            progress_bar.update(progress=value)
        except Exception as e:
            logger.error(f"Failed to update progress: {e}")

    def _saving_complete_update(self, saved_count: int, total_count: int):
        """Update UI when saving is complete (called in main thread)"""
        try:
            # Update status
            self._update_status(f"✓ Saving Complete: {saved_count}/{total_count} endpoints saved")
            self._update_progress(100)

            # Show results panel
            results_panel = self.query_one("#results-panel", Vertical)
            results_panel.styles.display = "block"

            # Update results
            results_widget = self.query_one("#results-text", Static)
            results = f"[green]✨ Success![/green]\n\n"
            results += f"Saved: {saved_count} endpoints\n"
            results += f"Total: {total_count} endpoints\n"
            results += f"\nAll endpoints have been stored in Qdrant database."

            results_widget.update(results)

            # Update start button
            start_button = self.query_one("#start-saving", Button)
            start_button.label = "✓ Saved"
            start_button.variant = "success"
            start_button.disabled = True

            logger.info("Saving UI updated successfully")

        except Exception as e:
            logger.error(f"Error in saving_complete_update: {e}", exc_info=True)
