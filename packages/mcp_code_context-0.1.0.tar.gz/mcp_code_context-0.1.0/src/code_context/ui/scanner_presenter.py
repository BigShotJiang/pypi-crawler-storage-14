"""Presenter layer to connect scanner logic with UI."""

from typing import Dict, List, Optional, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    from .scanner_ui import ScannerApp


class ScannerPresenter:
    """Adapter between scanner logic and Textual UI"""

    def __init__(self, app = None, screen = None):
        """Initialize presenter

        Args:
            app: Main App instance for call_from_thread
            screen: Screen instance to update (can be same as app)
        """
        self.app = app
        self.screen = screen or app
        self.candidate_files: List[str] = []
        self.accumulated_tokens = {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0
        }

    def set_app(self, app):
        """Set the Textual app instance"""
        self.app = app

    def update_project_info(self, path: Path, frameworks: List[str]):
        """Update project information

        Args:
            path: Project root path
            frameworks: Detected frameworks
        """
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_project_info,
                str(path),
                frameworks
            )

    def start_file_scan(self):
        """Mark file scanning as started"""
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "scan",
                "in_progress",
                "Scanning..."
            )

    def complete_file_scan(self, file_count: int):
        """Mark file scanning as completed

        Args:
            file_count: Number of files found
        """
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "scan",
                "completed",
                f"{file_count} files found"
            )

    def update_framework_detection(self, frameworks: List[str]):
        """Update framework detection step

        Args:
            frameworks: Detected frameworks
        """
        if self.app and self.screen:
            details = ", ".join(frameworks) if frameworks else "generic detection"
            self.app.call_from_thread(
                self.screen.update_step,
                "framework",
                "completed",
                details
            )

    def start_prefilter(self):
        """Mark pre-filtering as started"""
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "prefilter",
                "in_progress",
                "Filtering..."
            )

    def complete_prefilter(self, remaining_count: int, excluded_count: int):
        """Mark pre-filtering as completed

        Args:
            remaining_count: Files remaining after filter
            excluded_count: Files filtered out
        """
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "prefilter",
                "completed",
                f"{remaining_count} files (excluded {excluded_count})"
            )

    def start_llm_filter(self):
        """Mark LLM filtering as started"""
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_llm_progress,
                0,
                0
            )

    def update_llm_batch(self, batch_num: int, total_batches: int, candidates_found: int, tokens_used: Dict):
        """Update LLM filtering progress

        Args:
            batch_num: Current batch number
            total_batches: Total number of batches
            candidates_found: Number of candidates found in this batch
            tokens_used: Token usage dict with input/output/total
        """
        # Accumulate tokens
        self.accumulated_tokens["input_tokens"] += tokens_used.get("input_tokens", 0)
        self.accumulated_tokens["output_tokens"] += tokens_used.get("output_tokens", 0)
        self.accumulated_tokens["total_tokens"] += tokens_used.get("total_tokens", 0)

        if self.app and self.screen:
            # Update LLM progress and progress bar
            self.app.call_from_thread(
                self.screen.update_llm_progress,
                batch_num,
                total_batches
            )

            # Update actual token usage
            self.app.call_from_thread(
                self.screen.update_actual_usage,
                self.accumulated_tokens["input_tokens"],
                self.accumulated_tokens["output_tokens"]
            )

    def complete_llm_filter(self, total_candidates: int):
        """Mark LLM filtering as completed

        Args:
            total_candidates: Total candidates found
        """
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.complete_llm_filtering
            )

    def update_candidate_files(self, files: List[Path], project_root: Path):
        """Update the list of candidate files

        Args:
            files: List of candidate file paths
            project_root: Project root for relative paths
        """
        relative_files = []
        for f in files:
            try:
                relative_files.append(str(f.relative_to(project_root)))
            except ValueError:
                relative_files.append(f.name)

        self.candidate_files = relative_files

        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.add_candidate_files,
                relative_files
            )

    # Token estimation no longer displayed in UI
    # def update_token_estimation(self, estimation: Dict):
    #     """Update token estimation
    #
    #     Args:
    #         estimation: Token estimation dictionary
    #     """
    #     if self.app and self.screen:
    #         self.app.call_from_thread(
    #             self.screen.update_token_estimation,
    #             estimation
    #         )

    def start_endpoint_parsing(self):
        """Mark endpoint parsing as started"""
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "parse",
                "in_progress",
                "Parsing..."
            )

    def complete_endpoint_parsing(self, endpoint_count: int):
        """Mark endpoint parsing as completed

        Args:
            endpoint_count: Number of endpoints found
        """
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "parse",
                "completed",
                f"{endpoint_count} endpoints"
            )

    def start_detail_extraction(self):
        """Mark detail extraction as started"""
        if self.app and self.screen:
            try:
                self.app.call_from_thread(
                    self.screen.start_detail_extraction
                )
            except RuntimeError:
                # App may have been closed
                pass

    def update_extraction_progress(self, current: int, total: int):
        """Update detail extraction progress

        Args:
            current: Current endpoint being processed
            total: Total endpoints to process
        """
        if self.app and self.screen:
            try:
                self.app.call_from_thread(
                    self.screen.update_extraction_progress,
                    current,
                    total
                )
            except RuntimeError:
                # App may have been closed
                pass

    def complete_detail_extraction(self, success_count: int, fail_count: int):
        """Mark detail extraction as completed

        Args:
            success_count: Number of successfully extracted endpoints
            fail_count: Number of failed extractions
        """
        if self.app and self.screen:
            try:
                self.app.call_from_thread(
                    self.screen.complete_detail_extraction,
                    success_count,
                    fail_count
                )
            except RuntimeError:
                # App may have been closed
                pass

    def start_database_storage(self):
        """Mark database storage as started"""
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "store",
                "in_progress",
                "Storing..."
            )

    def complete_database_storage(self):
        """Mark database storage as completed"""
        if self.app and self.screen:
            self.app.call_from_thread(
                self.screen.update_step,
                "store",
                "completed",
                "Complete"
            )
