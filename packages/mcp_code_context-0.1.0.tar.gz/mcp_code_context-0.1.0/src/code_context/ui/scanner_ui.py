"""Textual UI for code-context scanner."""

from textual.app import App, ComposeResult
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Header, Footer, Static, Tree, DataTable, Label
from textual.reactive import reactive
from rich.table import Table
from rich.text import Text
from typing import Dict, List, Optional


class ProjectInfo(Static):
    """Widget to display project information"""

    def __init__(self):
        super().__init__()
        self.project_path = ""
        self.frameworks = []

    def render(self) -> Text:
        """Render project info"""
        text = Text()
        text.append("📍 Project: ", style="cyan")
        text.append(self.project_path, style="bold")

        if self.frameworks:
            text.append("\n")
            text.append("🔧 Frameworks: ", style="cyan")
            text.append(", ".join(self.frameworks), style="green bold")

        return text

    def update_info(self, path: str, frameworks: List[str]):
        """Update project information"""
        self.project_path = path
        self.frameworks = frameworks
        self.refresh()


class ProgressPanel(Static):
    """Widget to display scan progress"""

    def __init__(self):
        super().__init__()
        self.steps = {
            "scan": {"status": "pending", "label": "File Scanning", "details": ""},
            "framework": {"status": "pending", "label": "Framework Detection", "details": ""},
            "prefilter": {"status": "pending", "label": "Pre-filtering", "details": ""},
            "llm": {"status": "pending", "label": "LLM Filtering", "details": ""},
            "parse": {"status": "pending", "label": "Endpoint Parsing", "details": ""},
            "extract": {"status": "pending", "label": "Detail Extraction", "details": ""},
            "store": {"status": "pending", "label": "Database Storage", "details": ""},
        }

    def render(self) -> Table:
        """Render progress table"""
        table = Table.grid(padding=(0, 2))
        table.add_column(style="bold", width=3)
        table.add_column(width=20)
        table.add_column()

        for step_id, step_data in self.steps.items():
            status = step_data["status"]
            label = step_data["label"]
            details = step_data["details"]

            # Status icon
            if status == "completed":
                icon = "[green]✓[/green]"
            elif status == "in_progress":
                icon = "[yellow]~[/yellow]"
            else:  # pending
                icon = "[ ]"

            table.add_row(icon, label, details)

        return table

    def update_step(self, step_id: str, status: str, details: str = ""):
        """Update a specific step"""
        if step_id in self.steps:
            self.steps[step_id]["status"] = status
            self.steps[step_id]["details"] = details
            self.refresh()


class CandidateFilesTree(Static):
    """Widget to display candidate files as a tree"""

    MAX_DISPLAY = 15  # Maximum files to display

    def __init__(self):
        super().__init__()
        self.files = []

    def render(self) -> Text:
        """Render candidate files"""
        if not self.files:
            return Text("No candidates yet...", style="dim")

        text = Text()
        text.append(f"Candidate Files ({len(self.files)}):", style="cyan bold")
        text.append("\n")

        # Display up to MAX_DISPLAY files
        display_files = self.files[:self.MAX_DISPLAY]
        for file_path in display_files:
            text.append("  • ", style="dim")
            text.append(file_path, style="")
            text.append("\n")

        # Show "and X more" if there are more files
        remaining = len(self.files) - self.MAX_DISPLAY
        if remaining > 0:
            text.append(f"\n  ... and {remaining} more files", style="dim italic")

        return text

    def update_files(self, files: List[str]):
        """Update candidate files list"""
        self.files = files
        self.refresh()


class TokenEstimationTable(Static):
    """Widget to display token estimation"""

    def __init__(self):
        super().__init__()
        self.estimation = {}

    def render(self) -> Table:
        """Render token estimation table"""
        if not self.estimation:
            return Table()

        table = Table(title="Token Estimation", box=None)
        table.add_column("Language", style="cyan")
        table.add_column("Files", justify="right", style="blue")
        table.add_column("Input", justify="right", style="green")
        table.add_column("Output", justify="right", style="green")
        table.add_column("Total", justify="right", style="yellow bold")

        # Add rows for each language
        for lang, data in self.estimation.get("by_language", {}).items():
            table.add_row(
                lang.title(),
                str(data.get("file_count", 0)),
                f"{data.get('input_tokens', 0):,}",
                f"{data.get('output_tokens', 0):,}",
                f"{data.get('total_tokens', 0):,}",
            )

        # Add total row
        total = self.estimation.get("total", {})
        if total:
            table.add_section()
            table.add_row(
                "Total",
                str(total.get("total_files", 0)),
                f"{total.get('estimated_input_tokens', 0):,}",
                f"{total.get('estimated_output_tokens', 0):,}",
                f"{total.get('total_tokens', 0):,}",
                style="bold",
            )

        return table

    def update_estimation(self, estimation: Dict):
        """Update token estimation"""
        self.estimation = estimation
        self.refresh()


class ScannerApp(App):
    """Textual app for code-context scanner"""

    CSS = """
    Screen {
        align: center middle;
    }

    Container {
        width: 100%;
        height: auto;
        border: solid $primary;
        background: $surface;
    }

    #project-info {
        border: solid $accent;
        padding: 1;
        margin-bottom: 1;
    }

    #progress-panel {
        border: solid $accent;
        padding: 1;
        margin-bottom: 1;
        height: auto;
    }

    #candidates-panel {
        border: solid $accent;
        padding: 1;
        margin-bottom: 1;
        height: auto;
        max-height: 20;
        overflow-y: auto;
    }

    #tokens-panel {
        border: solid $accent;
        padding: 1;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("ctrl+c", "quit", "Quit"),
    ]

    def __init__(self, project_path: str = ""):
        super().__init__()
        self.project_path = project_path
        self.project_info_widget = ProjectInfo()
        self.progress_widget = ProgressPanel()
        self.candidates_widget = CandidateFilesTree()
        self.tokens_widget = TokenEstimationTable()

    def compose(self) -> ComposeResult:
        """Compose the UI"""
        yield Header(show_clock=False)

        with Container():
            yield self.project_info_widget
            yield self.progress_widget
            yield self.candidates_widget
            yield self.tokens_widget

        yield Footer()

    def on_mount(self) -> None:
        """Called when app is mounted"""
        self.title = "Code Context Scanner"
        self.project_info_widget.update_info(self.project_path, [])

    def update_project_info(self, path: str, frameworks: List[str]):
        """Update project information"""
        self.project_info_widget.update_info(path, frameworks)

    def update_step(self, step_id: str, status: str, details: str = ""):
        """Update a progress step"""
        self.progress_widget.update_step(step_id, status, details)

    def add_candidate_files(self, files: List[str]):
        """Add candidate files to the tree"""
        self.candidates_widget.update_files(files)

    def update_token_estimation(self, estimation: Dict):
        """Update token estimation"""
        self.tokens_widget.update_estimation(estimation)
