"""UI components for code-context dashboard."""
