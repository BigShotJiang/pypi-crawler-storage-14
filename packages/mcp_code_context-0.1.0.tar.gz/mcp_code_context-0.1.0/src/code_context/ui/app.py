"""Main Textual application for code-context."""

from textual.app import App
from textual.binding import Binding
from pathlib import Path
import threading
import json

from .screens import (
    WelcomeScreen,
    ConfigScreen,
    ProjectSelectScreen,
    ScanningScreen,
    ParsingScreen,
)
from .scanner_presenter import ScannerPresenter
from ..scanner.file_scanner import FileScanner
from ..scanner.llm_filter import LLMFileFilter
from ..scanner.token_estimator import TokenEstimator
from ..utils.framework_detector import FrameworkDetector


class CodeContextApp(App):
    """Main application for Code Context Scanner"""

    CSS = """
    Screen {
        background: $background;
    }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True),
    ]

    # Screen routing
    SCREENS = {
        "welcome": WelcomeScreen,
        "config": ConfigScreen,
        "project_select": ProjectSelectScreen,
        "parsing_placeholder": ParsingScreen,
    }

    def __init__(self):
        super().__init__()
        self.project_path = ""
        self.scan_results = {}
        self.presenter = None

    def on_mount(self) -> None:
        """Called when app starts"""
        # Start with welcome screen
        self.push_screen(WelcomeScreen())

    def push_screen(self, screen, callback=None):
        """Override to handle screen creation"""
        # Handle screen by name
        if isinstance(screen, str):
            screen_name = screen

            if screen_name == "scanning":
                # Create scanning screen with current project path
                screen_obj = ScanningScreen(project_path=self.project_path)
                super().push_screen(screen_obj, callback)

                # Start scan in background thread
                self._start_scan(screen_obj)
                return

            elif screen_name == "parsing":
                # Create parsing screen with scan results and start parsing
                # ParsingScreen is already imported at the top
                screen_obj = ParsingScreen(scan_results=self.scan_results)
                super().push_screen(screen_obj, callback)
                return

            elif screen_name in self.SCREENS:
                screen_class = self.SCREENS[screen_name]
                screen_obj = screen_class()
                super().push_screen(screen_obj, callback)
                return

        # Default behavior
        super().push_screen(screen, callback)

    def switch_screen(self, screen):
        """Override to handle screen switching"""
        # Pop all screens and push new one
        while len(self.screen_stack) > 1:
            self.pop_screen()

        self.push_screen(screen)

    def _start_scan(self, scanning_screen: ScanningScreen):
        """Start scan in background thread

        Args:
            scanning_screen: The ScanningScreen instance to update
        """
        # Create presenter with app (for call_from_thread) and screen (for methods)
        self.presenter = ScannerPresenter(app=self, screen=scanning_screen)

        # Load config
        config_path = Path.home() / ".code-context" / "config.json"
        try:
            with open(config_path, 'r') as f:
                config_data = json.load(f)
        except (IOError, json.JSONDecodeError):
            # Should not happen since we validated config earlier
            config_data = {}

        # Start scan thread
        scan_thread = threading.Thread(
            target=self._run_scan_logic,
            args=(self.project_path, config_data, scanning_screen),
            daemon=True
        )
        scan_thread.start()

    def _run_scan_logic(self, project_path: str, config_data: dict, scanning_screen: ScanningScreen):
        """Run the actual scan logic in background thread

        Args:
            project_path: Path to scan
            config_data: Configuration dictionary
            scanning_screen: ScanningScreen instance for updates
        """
        import logging
        logging.basicConfig(
            filename='/tmp/code-context-debug.log',
            level=logging.DEBUG,
            format='%(asctime)s - %(message)s'
        )

        try:
            logging.info("=== SCAN STARTED ===")
            logging.info(f"Project path: {project_path}")
            logging.info(f"Config: {config_data.get('llm_provider')}/{config_data.get('llm_model')}")

            # Resolve path
            resolved_path = Path(project_path).expanduser().resolve()
            logging.info(f"Resolved path: {resolved_path}")

            # Step 1: Detect frameworks
            logging.info("Step 1: Detecting frameworks...")
            detector = FrameworkDetector(resolved_path)
            frameworks = detector.detect_frameworks()
            logging.info(f"Found frameworks: {frameworks}")

            logging.info("Updating UI with project info...")
            self.presenter.update_project_info(resolved_path, frameworks)
            self.presenter.update_framework_detection(frameworks)
            logging.info("UI updated successfully")

            # Step 2: Scan files
            logging.info("Step 2: Scanning files...")
            scanner = FileScanner(resolved_path, presenter=self.presenter)
            files_by_language = scanner.scan_project()
            total_files = sum(len(files) for files in files_by_language.values())
            logging.info(f"Found {total_files} files")

            if not files_by_language:
                logging.warning("No files found!")
                return

            # Step 3: Pre-filter
            logging.info("Step 3: Pre-filtering...")
            self.presenter.start_prefilter()
            filtered_files = {}
            for lang, files in files_by_language.items():
                filtered_files[lang] = scanner.preprocess_files(files)

            # Remove empty language categories
            filtered_files = {lang: files for lang, files in filtered_files.items() if files}

            remaining = sum(len(files) for files in filtered_files.values())
            excluded = total_files - remaining
            logging.info(f"After prefilter: {remaining} files (excluded {excluded})")
            self.presenter.complete_prefilter(remaining, excluded)

            # Step 4: LLM filter
            logging.info("Step 4: LLM filtering...")
            llm_filter = LLMFileFilter(
                llm_provider=config_data.get("llm_provider"),
                llm_model=config_data.get("llm_model"),
                api_key=config_data.get("api_key"),
                frameworks=frameworks,
                presenter=self.presenter
            )
            candidates = llm_filter.filter_candidate_files(filtered_files, resolved_path)
            total_candidates = sum(len(files) for files in candidates.values())
            logging.info(f"LLM filter found {total_candidates} candidates")

            # Step 5: Token estimation (removed from UI, kept for internal use)
            logging.info("Step 5: Estimating tokens...")
            estimator = TokenEstimator()
            estimation = estimator.estimate_tokens(candidates)
            # No longer updating UI with estimation
            logging.info("Token estimation complete")

            # Store results (without endpoints - will be parsed in ParsingScreen)
            self.scan_results = {
                "project_path": str(resolved_path),
                "frameworks": frameworks,
                "total_files_scanned": total_files,
                "total_candidates": total_candidates,
                "candidates": candidates,
                "token_usage": self.presenter.accumulated_tokens,
                "estimation": estimation,
            }

            # Mark scan as complete
            logging.info("Marking scan as complete...")
            self.app.call_from_thread(scanning_screen.mark_scan_complete)
            logging.info("=== SCAN COMPLETE ===")

        except Exception as e:
            logging.error(f"=== SCAN ERROR ===", exc_info=True)

    def action_quit(self) -> None:
        """Quit the application"""
        self.exit()
