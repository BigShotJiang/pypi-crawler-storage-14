import sys

from play_launch.dump import main

sys.exit(main())
