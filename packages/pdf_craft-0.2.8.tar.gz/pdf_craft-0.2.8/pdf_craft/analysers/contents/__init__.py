from .type import Contents, Chapter
from .contents_extractor import extract_contents