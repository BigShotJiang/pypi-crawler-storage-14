from .generation import generate_chapters_with_footnotes
from .mark import samples, NumberStyle