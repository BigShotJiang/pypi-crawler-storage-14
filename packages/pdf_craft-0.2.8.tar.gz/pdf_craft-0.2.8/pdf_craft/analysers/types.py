from enum import auto, Enum

class CorrectionMode(Enum):
  NO = auto()
  ONCE = auto()
  DETAILED= auto()