import pathlib

# Get the directory where the static files are located
STATIC_DIR = pathlib.Path(__file__).parent / "static"
