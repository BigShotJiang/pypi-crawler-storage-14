from rustcore import PyAggregatedStats

__version__ = "0.3.2"
__all__ = ["PyAggregatedStats", "__version__"]
