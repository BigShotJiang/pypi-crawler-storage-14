"""Building Writer.

Note to developers:
Use this module to extend dragonfly's Building writer for new extensions.
(eg. adding `rad` to this module adds the method `Building.to.rad`)
"""
