
from .ignore_file_utils import should_ignore

__all__ = ["should_ignore"]
