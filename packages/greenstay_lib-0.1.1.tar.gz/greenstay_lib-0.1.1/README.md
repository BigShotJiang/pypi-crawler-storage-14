version = "0.1.1"

GreenStay packs a custom Python library built just for turning hotel usage stats into carbon numbers. This library is clean with the calculation and comes with good accuracy it is publicly available at pipy network so everybody can use this library for their project.

Export convenient top-level names. Only import small, safe items —
avoid importing heavy runtime code or side-effectful modules at import-time.