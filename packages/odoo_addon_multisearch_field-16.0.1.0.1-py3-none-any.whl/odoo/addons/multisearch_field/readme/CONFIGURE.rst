To configure the separator you must:

* be in dev_mode
* go to Settings / technical / system parameter
* search multi_search_separator
* add/rm the separator
* available separators must be set like this :  \|; for "|" and ";"
