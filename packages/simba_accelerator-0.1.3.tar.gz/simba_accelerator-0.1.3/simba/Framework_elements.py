from simba.Framework_objects import (
    chicane,
    s_chicane,
    r56_group,
    element_group,
)  # noqa F401

disallowed_keywords = [
    "allowedkeywords",
    "conversion_rules",
    "objectdefaults",
    "global_parameters",
    "objectname",
    "beam",
]
