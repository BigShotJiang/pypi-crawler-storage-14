m_e = 9.1093837015e-31
m_p = 1.67262192595e-27
speed_of_light = 299792458.0
e = 1.602176634e-19
elementary_charge = 1.602176634e-19
pi = 3.141592653589793
electron_mass = m_e
proton_mass = m_p
