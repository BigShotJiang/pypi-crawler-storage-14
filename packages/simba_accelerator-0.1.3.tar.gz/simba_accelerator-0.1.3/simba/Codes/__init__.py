"""
SIMBA Codes Module

This module converts the :class:`~simba.Framework_objects.frameworkLattice` class
and its elements into a format suitable for the code defined.
"""