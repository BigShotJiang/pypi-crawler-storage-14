simba.Codes.OPAL package
========================

Submodules
----------

simba.Codes.OPAL.OPAL module
----------------------------

.. automodule:: simba.Codes.OPAL.OPAL
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: simba.Codes.OPAL
   :members:
   :show-inheritance:
   :undoc-members:
