simba.Modules.Matrices package
==============================

Submodules
----------

simba.Modules.Matrices.elegant module
-------------------------------------

.. automodule:: simba.Modules.Matrices.elegant
   :members:
   :show-inheritance:
   :undoc-members:

simba.Modules.Matrices.hdf5 module
----------------------------------

.. automodule:: simba.Modules.Matrices.hdf5
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: simba.Modules.Matrices
   :members:
   :show-inheritance:
   :undoc-members:
