simba.Modules.optimisation package
==================================

Submodules
----------

simba.Modules.optimisation.constraints module
---------------------------------------------

.. automodule:: simba.Modules.optimisation.constraints
   :members:
   :show-inheritance:
   :undoc-members:

simba.Modules.optimisation.nelder\_mead module
----------------------------------------------

.. automodule:: simba.Modules.optimisation.nelder_mead
   :members:
   :show-inheritance:
   :undoc-members:

simba.Modules.optimisation.optimiser module
-------------------------------------------

.. automodule:: simba.Modules.optimisation.optimiser
   :members:
   :show-inheritance:
   :undoc-members:

simba.Modules.optimisation.xopt module
--------------------------------------

.. automodule:: simba.Modules.optimisation.xopt
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: simba.Modules.optimisation
   :members:
   :show-inheritance:
   :undoc-members:
