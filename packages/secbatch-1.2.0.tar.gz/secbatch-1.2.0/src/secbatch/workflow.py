import os
import paramiko
import time
import shutil
import gnupg
import base64
import json
from pathlib import Path
from colorama import Fore, Style

# --- Constants ---
# REMOTE_SECURE_DIR is now dynamically determined
JOB_INFO_FILENAME = ".secure_slurm_job_info.json"

def run_secure_workflow(
    host, user, ssh_key_file, input_dir, exec_command, job_script_content, job_name, output_dir, keep_local_temp,
    nodes, ntasks_per_node, time, mem, partition, qos, cpus_per_task=None, gpus_per_task=None, sbatch_options=None
):
    """
    Executes the full secure workflow.
    """
    local_paths = None # Initialize to None for finally block
    remote_paths = None # Initialize to None for finally block
    ssh_client = None # Initialize to None for finally block
    job_id = None # Initialize job_id for resume logic

    current_input_dir = Path(input_dir)
    job_info_path = _get_job_info_path(current_input_dir)
    job_info = _read_job_info(current_input_dir)
    
    # --- Resume/New Job Logic ---
    if job_info:
        print(f"{Fore.YELLOW}Found previous job information for input directory '{current_input_dir}'.")
        print(f"{Fore.CYAN}  Remote Job Directory: {job_info.get('remote_paths', {}).get('job_dir', 'N/A')}")
        if job_info.get('job_id'):
            print(f"{Fore.CYAN}  Slurm Job ID: {job_info.get('job_id')}")
        
        while True:
            choice = input("Do you want to (r)esume, (s)tart a new job, or (e)xit? [r/s/e]: ").lower()
            if choice == 'r':
                local_paths_str = job_info.get('local_paths')
                if local_paths_str:
                    local_paths = {k: Path(v) for k, v in local_paths_str.items()}
                
                remote_paths = job_info.get('remote_paths')
                job_id = job_info.get('job_id')
                print(Style.BRIGHT + "Resuming previous job...")
                break
            elif choice == 's':
                print(Style.BRIGHT + "Starting a new job. Deleting previous job info...")
                job_info_path.unlink(missing_ok=True)
                job_info = {} # Reset job_info
                break
            elif choice == 'e':
                print("Exiting.")
                return
            else:
                print(f"{Fore.YELLOW}Invalid choice. Please enter 'r', 's', or 'e'.")

    # --- 1. Prepare Local Env (only if starting new or local_paths not loaded) ---
    if not local_paths:
        try:
            local_paths = _prepare_local_env(current_input_dir, job_name)
            # Store local_paths in job_info file for persistence
            _write_job_info(current_input_dir, {'local_paths': {k: str(v) for k, v in local_paths.items()}})
            print(f"{Fore.GREEN}✓ Local environment prepared.")
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            print(f"{Fore.RED}Error during local preparation: {e}")
            return
        except Exception as e:
            print(f"{Fore.RED}An unexpected error occurred: {e}")
            return
    else:
        print(f"{Fore.GREEN}✓ Re-using local environment from previous run.")


    # --- 2. Connect and Execute Remote Workflow ---
    try:
        ssh_client = _create_ssh_client(host, user, ssh_key_file)
        print(f"{Fore.GREEN}✓ SSH connection established to {host}.")
        
        # Prepare remote env (only if starting new or remote_paths not loaded)
        if not remote_paths:
            remote_paths = _prepare_remote_env(ssh_client, job_name)
            # Store remote_paths in job_info file for persistence
            _write_job_info(current_input_dir, {'remote_paths': remote_paths})
            print(f"{Fore.GREEN}✓ Remote environment prepared.")
        else:
            print(f"{Fore.GREEN}✓ Re-using remote environment from previous run.")

        # Check if key file needs re-upload and upload it along with encrypted data
        sftp = ssh_client.open_sftp()
        key_exists_on_remote = False
        try:
            sftp.stat(remote_paths['key_file'])
            key_exists_on_remote = True
        except FileNotFoundError:
            key_exists_on_remote = False # File not found is expected if it's missing on remote
        finally:
            sftp.close()
        
        if not key_exists_on_remote:
            print(f"{Fore.CYAN}  - Key file missing on remote or new job. Uploading key and encrypted data...")
            _upload_files(ssh_client, local_paths, remote_paths)
            print(f"{Fore.GREEN}✓ Encrypted data and key uploaded.")
        else:
            sftp = ssh_client.open_sftp()
            try:
                sftp.stat(remote_paths['encrypted_zip_file'])
                encrypted_data_exists_on_remote = True
            except FileNotFoundError:
                encrypted_data_exists_on_remote = False
            finally:
                sftp.close()
            if not encrypted_data_exists_on_remote :
                print(f"{Fore.CYAN}  - Encrypted data missing on remote. Uploading encrypted data...")
                # Assuming _upload_files also uploads encrypted_zip_file
                _upload_files(ssh_client, local_paths, remote_paths)
                print(f"{Fore.GREEN}✓ Encrypted data uploaded.")
            else:
                print(f"{Fore.GREEN}✓ Encrypted data already on remote (assuming).")
        
        # Submit job (only if not already submitted)
        if not job_id:
            job_id = _submit_slurm_job(
                ssh_client, exec_command, job_script_content, remote_paths, job_name,
                nodes, ntasks_per_node, time, mem, partition, qos,
                cpus_per_task, gpus_per_task, sbatch_options
            )
            _write_job_info(current_input_dir, {'job_id': job_id}) # Store job_id
            print(f"{Fore.GREEN}✓ Submitted Slurm job with ID: {job_id}")
        else:
            print(f"{Fore.GREEN}✓ Slurm job {job_id} already submitted. Resuming monitoring.")

        _monitor_job(ssh_client, job_id)
        print(f"{Fore.GREEN}✓ Job completed.")
        
        _download_and_decrypt(ssh_client, local_paths, remote_paths, Path(output_dir))
        print(f"{Fore.GREEN}✓ Results downloaded and decrypted to '{output_dir}'.")

    except paramiko.AuthenticationException:
        print(f"{Fore.RED}Authentication failed. Please check your username and SSH key.")
    except paramiko.SSHException as e:
        print(f"{Fore.RED}SSH connection error: {e}")
    except Exception as e:
        print(f"{Fore.RED}An error occurred during the remote workflow: {e}")
    finally:
        # --- Clean up local temporary files ---
        if not keep_local_temp and local_paths and local_paths["temp_dir"].exists():
            print(Style.BRIGHT + "Cleaning up local temporary files...")
            shutil.rmtree(local_paths["temp_dir"])
            print(f"{Fore.GREEN}✓ Local cleanup complete.")
        elif keep_local_temp and local_paths and local_paths["temp_dir"].exists():
            print(f"{Fore.CYAN}  - Keeping local temporary directory: {local_paths['temp_dir']}")
        
        # --- Clean up remote job directory on headnode ---
        # Only cleanup if remote_paths was successfully created and a job was attempted/completed
        if ssh_client and remote_paths and remote_paths["job_dir"]:
            final_job_info = _read_job_info(current_input_dir) # Read fresh data
            # We clean up if a job was successfully submitted in this run.
            if final_job_info.get('job_id'):
                # Download slurm logs before cleaning up
                _download_slurm_logs(ssh_client, remote_paths, final_job_info.get('job_id'), Path(output_dir))

                print(Style.BRIGHT + "Cleaning up remote job directory on headnode...")
                _cleanup_remote_job_dir(ssh_client, remote_paths["job_dir"])
                print(f"{Fore.GREEN}✓ Remote cleanup complete.")
                # If we cleaned up remotely, we should clean up the job info file too, unless keep_local_temp is on
                if not keep_local_temp and job_info_path.exists():
                    job_info_path.unlink()
            else:
                # This happens if the run was aborted before job submission, or in a failed resume attempt.
                print(f"{Fore.YELLOW}Retaining remote job directory for inspection (no job submitted in this run).")
        
        # --- Close the SSH client at the very end ---
        if ssh_client:
            ssh_client.close()


def test_ssh_connection(host, user, ssh_key_file):
    """Tests the SSH connection to the remote host."""
    try:
        with _create_ssh_client(host, user, ssh_key_file):
            return True
    except Exception as e:
        print(f"{Fore.RED}Error: {e}")
        return False

def _get_job_info_path(input_dir: Path) -> Path:
    """Returns the path to the job info file within the input directory."""
    return input_dir / JOB_INFO_FILENAME

def _read_job_info(input_dir: Path) -> dict:
    """Reads job information from the local file."""
    job_info_path = _get_job_info_path(input_dir)
    if job_info_path.exists():
        try:
            with open(job_info_path, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"{Fore.YELLOW}Warning: Corrupted job info file at {job_info_path}. Starting new job.")
            job_info_path.unlink(missing_ok=True) # Delete corrupted file
    return {}

def _write_job_info(input_dir: Path, new_info: dict):
    """Writes or updates job information to the local file."""
    job_info_path = _get_job_info_path(input_dir)
    current_info = _read_job_info(input_dir)
    current_info.update(new_info)
    # Convert Path objects to strings for JSON serialization
    serializable_info = {k: str(v) if isinstance(v, Path) else v for k, v in current_info.items()}
    with open(job_info_path, 'w') as f:
        json.dump(serializable_info, f, indent=4)

def _prepare_local_env(input_dir: Path, job_name: str):
    """
    Creates a local temp dir, generates a key, zips and encrypts the input data.
    Returns a dictionary of important paths.
    """
    if not input_dir.is_dir():
        raise FileNotFoundError(f"Input directory not found: {input_dir}")

    # Create a temporary directory for this job
    temp_dir = Path(f"./.secure_slurm_temp_{job_name}")
    temp_dir.mkdir(exist_ok=True)
    print(f"{Fore.CYAN}  - Created local temp directory: {temp_dir}")

    # 1. Generate a secret key file
    key_file = temp_dir / f"{job_name}.key"
    print(f"{Fore.CYAN}  - Generating secret key: {key_file}")
    passphrase = base64.b64encode(os.urandom(32)).decode('utf-8')
    with open(key_file, "w") as f:
        f.write(passphrase)
    
    # 2. Compress the input data folder
    zip_file_base = temp_dir / "input"
    print(f"{Fore.CYAN}  - Compressing input data to: {zip_file_base}.zip")
    zip_file = shutil.make_archive(str(zip_file_base), 'zip', root_dir=str(input_dir))

    # 3. Encrypt the zip file
    gpg = gnupg.GPG()
    encrypted_zip_file = temp_dir / "input.zip.gpg"
    print(f"{Fore.CYAN}  - Encrypting data to: {encrypted_zip_file}")
    with open(zip_file, 'rb') as f:
        status = gpg.encrypt_file(
            f,
            recipients=None, # Symmetric encryption
            symmetric='AES256',
            passphrase=passphrase,
            output=str(encrypted_zip_file)
        )
    if not status.ok:
        raise Exception(f"GPG encryption failed: {status.stderr}")

    return {
        "temp_dir": temp_dir.resolve(),
        "key_file": key_file.resolve(),
        "passphrase": passphrase, # Passphrase needs to be stored as string
        "encrypted_zip_file": encrypted_zip_file.resolve()
    }


def _create_ssh_client(host, user, ssh_key_file):
    """
    Establishes an SSH connection, resolving host aliases from ~/.ssh/config
    and using default SSH key discovery if no specific key is provided.
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # --- SSH Config Resolution ---
    ssh_config_file = Path.home() / ".ssh" / "config"
    config = paramiko.SSHConfig()
    if ssh_config_file.exists():
        with open(ssh_config_file) as f:
            config.parse(f)

    host_config = config.lookup(host)

    hostname = host_config.get('hostname', host)
    # CLI user arg takes precedence over config file
    username = user or host_config.get('user')
    port = host_config.get('port', 22)
    
    # CLI key file arg takes precedence over config file
    key_filename = ssh_key_file or host_config.get('identityfile', [None])[0]

    connect_kwargs = {
        'hostname': hostname,
        'port': port,
        'username': username,
    }

    # Let paramiko handle default key discovery if no key is specified
    # by the user or in the ssh config.
    if key_filename:
        # Resolve tilde and environment variables in the path
        key_filename = str(Path(key_filename).expanduser())
        if not Path(key_filename).exists():
             raise FileNotFoundError(f"SSH key file not found: {key_filename}")
        connect_kwargs['key_filename'] = key_filename
        print(f"{Fore.CYAN}  - Using specific key: {key_filename}")
    else:
        print(f"{Fore.CYAN}  - No specific key provided. Using ssh-agent or default key paths.")

    if not connect_kwargs['username']:
        # If user is still not defined, paramiko will use the local username.
        print(f"{Fore.CYAN}  - No user specified, will use local username.")

    print(f"{Fore.CYAN}  - Connecting to {connect_kwargs['hostname']}:{connect_kwargs['port']} as {connect_kwargs.get('username') or 'current user'}")

    client.connect(**connect_kwargs, timeout=10)
    return client


def _prepare_remote_env(ssh: paramiko.SSHClient, job_name: str):
    """Creates the secure directories on the remote host."""
    # Get remote user's home directory
    stdin, stdout, stderr = ssh.exec_command("echo $HOME")
    remote_home = stdout.read().decode().strip()
    if not remote_home:
        raise Exception(f"Could not determine remote home directory: {stderr.read().decode()}")

    remote_secure_dir = f"{remote_home}/secure"
    remote_job_dir = f"{remote_secure_dir}/{job_name}-{int(time.time())}"
    
    print(f"{Fore.CYAN}  - Creating remote directory: {remote_job_dir}")
    stdin, stdout, stderr = ssh.exec_command(
        f"mkdir -p {remote_job_dir} && chmod 700 {remote_secure_dir} {remote_job_dir}"
    )
    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
        raise Exception(f"Error creating remote directory: {stderr.read().decode()}")

    return {
        "job_dir": remote_job_dir,
        "key_file": f"{remote_job_dir}/{Path(job_name).name}.key",
        "encrypted_zip_file": f"{remote_job_dir}/input.zip.gpg",
        "encrypted_output_file": f"{remote_job_dir}/output.zip.gpg",
        "slurm_script": f"{remote_job_dir}/job.sh",
        "slurm_output_log": f"{remote_job_dir}/slurm-%j.out",
        "slurm_error_log": f"{remote_job_dir}/slurm-%j.err",
        "encrypted_slurm_output_log": f"{remote_job_dir}/slurm-%j.out.gpg",
        "encrypted_slurm_error_log": f"{remote_job_dir}/slurm-%j.err.gpg",
    }


def _upload_files(ssh: paramiko.SSHClient, local_paths: dict, remote_paths: dict):
    """Uploads the key and encrypted data via SFTP."""
    sftp = ssh.open_sftp()
    try:
        # Upload key file
        local_key_file_path = local_paths["key_file"]
        print(f"{Fore.CYAN}  - Uploading {local_key_file_path} to {remote_paths['key_file']}")
        sftp.put(str(local_key_file_path), remote_paths['key_file'])
        
        # Set permissions on key file
        print(f"{Fore.CYAN}  - Setting permissions for remote key file")
        sftp.chmod(remote_paths["key_file"], 0o600)

        # Upload encrypted data
        local_encrypted_zip_file_path = local_paths["encrypted_zip_file"]
        print(f"{Fore.CYAN}  - Uploading {local_encrypted_zip_file_path} to {remote_paths['encrypted_zip_file']}")
        sftp.put(str(local_encrypted_zip_file_path), remote_paths["encrypted_zip_file"])
    finally:
        sftp.close()


def _submit_slurm_job(
    ssh: paramiko.SSHClient, exec_command: str, job_script_content: str, remote_paths: dict, job_name: str,
    nodes: int, ntasks_per_node: int, time_limit: str, mem: str, partition: str, qos: str,
    cpus_per_task: int, gpus_per_task: str, sbatch_options: str
):
    """Generates, uploads, and submits the Slurm batch script."""

    # Determine the job body
    job_body = job_script_content if job_script_content else exec_command
    if not job_body:
        raise ValueError("Either exec_command or job_script_content must be provided.")

    sbatch_lines = [
        f"#SBATCH --job-name={job_name}",
        f"#SBATCH --output={remote_paths['slurm_output_log']}",
        f"#SBATCH --error={remote_paths['slurm_error_log']}",
        f"#SBATCH --nodes={nodes or 1}",
        f"#SBATCH --ntasks-per-node={ntasks_per_node or 1}",
        f"#SBATCH --time={time_limit or '01:00:00'}",
        "#SBATCH --exclusive",
    ]

    if mem:
        sbatch_lines.append(f"#SBATCH --mem={mem}")
    if partition:
        sbatch_lines.append(f"#SBATCH --partition={partition}")
    if qos:
        sbatch_lines.append(f"#SBATCH --qos={qos}")
    if cpus_per_task:
        sbatch_lines.append(f"#SBATCH --cpus-per-task={cpus_per_task}")
    if gpus_per_task:
        sbatch_lines.append(f"#SBATCH --gpus-per-task={gpus_per_task}")
    if sbatch_options:
        sbatch_lines.append(f"#SBATCH {sbatch_options}")

    sbatch_header = "\n".join(sbatch_lines)
    
    slurm_script_content = f"""#!/bin/bash
{sbatch_header}

echo "Starting job on node $SLURM_NODELIST"

# Create a temporary directory on the compute node's local storage
TMPDIR=$(mktemp -d /dev/shm/tmp.{job_name}.XXXXXX)
trap "echo 'Cleaning up temporary directory $TMPDIR'; rm -rf $TMPDIR" EXIT
cd $TMPDIR

echo "Temporary directory: $TMPDIR"
echo "Decrypting data..."
gpg --batch --yes --passphrase-file {remote_paths['key_file']} -o input.zip -d {remote_paths['encrypted_zip_file']}
unzip input.zip
rm input.zip

echo "Running user command..."
# =============================================================================
{job_body}
# =============================================================================
echo "User command finished."

echo "Encrypting results..."
zip -o output.zip -r .
gpg -c --batch --yes --passphrase-file {remote_paths['key_file']} -o {remote_paths['encrypted_output_file']} output.zip

echo "Job finished successfully."
"""
    
    # Upload the script
    sftp = ssh.open_sftp()
    try:
        print(f"{Fore.CYAN}  - Uploading Slurm script to {remote_paths['slurm_script']}")
        with sftp.file(remote_paths['slurm_script'], 'w') as f:
            f.write(slurm_script_content)
        sftp.chmod(remote_paths['slurm_script'], 0o755)
    finally:
        sftp.close()

    # Submit the job
    print(Style.BRIGHT + f"{Fore.CYAN}  - Submitting job to Slurm...")
    stdin, stdout, stderr = ssh.exec_command(f"sbatch {remote_paths['slurm_script']}")
    exit_status = stdout.channel.recv_exit_status()
    
    stdout_str = stdout.read().decode()
    if exit_status != 0:
        raise Exception(f"Slurm job submission failed: {stderr.read().decode()}")

    # "Submitted batch job 12345" -> "12345"
    try:
        job_id = stdout_str.strip().split()[-1]
        return int(job_id)
    except (ValueError, IndexError):
        raise Exception(f"Could not parse job ID from sbatch output: {stdout_str}")

def _monitor_job(ssh: paramiko.SSHClient, job_id: int):
    """Polls `squeue` until the job is no longer in the queue."""
    print(f"{Fore.CYAN}  - Monitoring job {job_id}. This may take a while...")
    while True:
        stdin, stdout, stderr = ssh.exec_command(f"squeue -j {job_id} -h")
        exit_status = stdout.channel.recv_exit_status()
        if exit_status != 0:
            # If squeue fails, assume the job is done (it might have finished quickly)
            print(f"{Fore.YELLOW}  - `squeue` command failed, assuming job is complete.")
            break
        
        queue_status = stdout.read().decode().strip()
        if not queue_status:
            # Empty output means the job is no longer in the queue
            print(f"{Fore.CYAN}  - Job no longer in queue.")
            break
        
        print(f"{Fore.CYAN}  - Job status: {queue_status.split()[4]}")
        time.sleep(15) # Poll every 15 seconds


def _download_slurm_logs(ssh: paramiko.SSHClient, remote_paths: dict, job_id: int, output_dir: Path):
    """Downloads the slurm .out and .err files to the local output directory."""
    if not job_id:
        print(f"{Fore.YELLOW}  - No job ID, cannot download Slurm logs.")
        return

    print(Style.BRIGHT + "Downloading Slurm logs...")
    # Ensure output directory exists
    output_dir.mkdir(parents=True, exist_ok=True)

    sftp = ssh.open_sftp()
    try:
        # Construct file paths
        remote_out_log = remote_paths['slurm_output_log'].replace('%j', str(job_id))
        remote_err_log = remote_paths['slurm_error_log'].replace('%j', str(job_id))
        
        local_out_log = output_dir / f"slurm-{job_id}.out"
        local_err_log = output_dir / f"slurm-{job_id}.err"

        # Download .out file
        try:
            print(f"{Fore.CYAN}  - Downloading Slurm output log to {local_out_log}")
            sftp.get(remote_out_log, str(local_out_log))
        except FileNotFoundError:
            print(f"{Fore.YELLOW}  - Slurm output log not found on remote: {remote_out_log}")

        # Download .err file
        try:
            print(f"{Fore.CYAN}  - Downloading Slurm error log to {local_err_log}")
            sftp.get(remote_err_log, str(local_err_log))
        except FileNotFoundError:
            print(f"{Fore.YELLOW}  - Slurm error log not found on remote: {remote_err_log}")
        
        print(f"{Fore.GREEN}✓ Slurm logs downloaded.")

    except Exception as e:
        print(f"{Fore.RED}An error occurred during Slurm log download: {e}")
    finally:
        sftp.close()


def _download_and_decrypt(ssh: paramiko.SSHClient, local_paths: dict, remote_paths: dict, output_dir: Path):
    """Downloads, decrypts, and unzips the results."""
    
    # Create local output directory
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"{Fore.CYAN}  - Created output directory: {output_dir}")

    local_encrypted_output = local_paths["temp_dir"] / "output.zip.gpg"
    
    # Download the encrypted output file
    sftp = ssh.open_sftp()
    try:
        print(f"{Fore.CYAN}  - Downloading results from {remote_paths['encrypted_output_file']}")
        sftp.get(remote_paths['encrypted_output_file'], str(local_encrypted_output))
    except FileNotFoundError:
        print(f"{Fore.YELLOW}  - WARNING: Output file not found on remote: {remote_paths['encrypted_output_file']}")
        print(f"{Fore.YELLOW}  - This can happen if the job failed or produced no output file.")
        print(f"{Fore.YELLOW}  - Check the Slurm log file for details: {remote_paths['job_dir']}/slurm-*.out")
        return
    finally:
        sftp.close()

    # Decrypt the file
    gpg = gnupg.GPG()
    local_decrypted_zip = local_paths["temp_dir"] / "output.zip"
    print(f"{Fore.CYAN}  - Decrypting results to: {local_decrypted_zip}")
    with open(local_encrypted_output, 'rb') as f:
        status = gpg.decrypt_file(
            f,
            passphrase=local_paths['passphrase'],
            output=str(local_decrypted_zip)
        )
    
    if not status.ok:
        raise Exception(f"GPG decryption failed: {status.stderr}")


    # Unzip the results into the final output directory
    print(f"{Fore.CYAN}  - Unzipping results to: {output_dir}")
    shutil.unpack_archive(str(local_decrypted_zip), str(output_dir))

def _cleanup_remote_job_dir(ssh: paramiko.SSHClient, remote_job_dir: str):
    """Removes the remote job directory from the headnode."""
    try:
        stdin, stdout, stderr = ssh.exec_command(f"rm -rf {remote_job_dir}")
        exit_status = stdout.channel.recv_exit_status()
        if exit_status != 0:
            print(f"{Fore.YELLOW}  - Warning: Failed to clean up remote directory {remote_job_dir}: {stderr.read().decode()}")
    except Exception as e:
        print(f"{Fore.YELLOW}  - Warning: Error during remote cleanup of {remote_job_dir}: {e}")
