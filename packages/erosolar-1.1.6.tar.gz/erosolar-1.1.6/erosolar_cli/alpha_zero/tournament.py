"""
Tournament Runner for Alpha Zero 2

Orchestrates multi-round competitive tournaments between agents
with proper async support, progress tracking, and persistence.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional


class TournamentStatus(Enum):
    """Status of a tournament."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"


@dataclass
class TournamentConfig:
    """Configuration for a tournament."""

    name: str
    tasks: list[str]
    num_rounds: int = 10
    rounds_per_task: int = 2
    self_modification_interval: int = 5
    save_intermediate_results: bool = True
    verbose: bool = False


@dataclass
class RoundResult:
    """Result of a single tournament round."""

    round_number: int
    task: str
    agent1_score: float
    agent2_score: float
    agent1_response: str
    agent2_response: str
    winner: str  # "agent1", "agent2", or "tie"
    duration_ms: float
    timestamp: float


@dataclass
class TournamentResult:
    """Complete tournament results."""

    config: TournamentConfig
    status: TournamentStatus
    rounds: list[RoundResult] = field(default_factory=list)
    agent1_wins: int = 0
    agent2_wins: int = 0
    ties: int = 0
    total_duration_ms: float = 0.0
    start_time: float = 0.0
    end_time: float = 0.0

    @property
    def total_rounds(self) -> int:
        return len(self.rounds)

    @property
    def agent1_win_rate(self) -> float:
        return self.agent1_wins / self.total_rounds if self.total_rounds > 0 else 0.0

    @property
    def agent2_win_rate(self) -> float:
        return self.agent2_wins / self.total_rounds if self.total_rounds > 0 else 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "config": {
                "name": self.config.name,
                "tasks": self.config.tasks,
                "num_rounds": self.config.num_rounds,
            },
            "status": self.status.value,
            "total_rounds": self.total_rounds,
            "agent1_wins": self.agent1_wins,
            "agent2_wins": self.agent2_wins,
            "ties": self.ties,
            "agent1_win_rate": self.agent1_win_rate,
            "agent2_win_rate": self.agent2_win_rate,
            "total_duration_ms": self.total_duration_ms,
            "rounds": [
                {
                    "round": r.round_number,
                    "task": r.task[:100] + "..." if len(r.task) > 100 else r.task,
                    "agent1_score": r.agent1_score,
                    "agent2_score": r.agent2_score,
                    "winner": r.winner,
                    "duration_ms": r.duration_ms,
                }
                for r in self.rounds
            ],
        }


class TournamentCallbacks:
    """Callbacks for tournament progress updates."""

    def on_tournament_start(self, config: TournamentConfig) -> None:
        """Called when tournament starts."""
        pass

    def on_round_start(self, round_number: int, task: str) -> None:
        """Called when a round starts."""
        pass

    def on_round_complete(self, result: RoundResult) -> None:
        """Called when a round completes."""
        pass

    def on_self_modification(self, agent_id: str, improvement: str) -> None:
        """Called when an agent self-modifies."""
        pass

    def on_tournament_complete(self, result: TournamentResult) -> None:
        """Called when tournament completes."""
        pass

    def on_error(self, error: Exception, round_number: Optional[int] = None) -> None:
        """Called when an error occurs."""
        pass


class VerboseCallbacks(TournamentCallbacks):
    """Callbacks that print progress to console."""

    def on_tournament_start(self, config: TournamentConfig) -> None:
        print(f"\n{'=' * 60}")
        print(f"ALPHA ZERO 2 TOURNAMENT: {config.name}")
        print(f"{'=' * 60}")
        print(f"Tasks: {len(config.tasks)}")
        print(f"Rounds: {config.num_rounds}")
        print()

    def on_round_start(self, round_number: int, task: str) -> None:
        task_preview = task[:60] + "..." if len(task) > 60 else task
        print(f"Round {round_number}: {task_preview}")

    def on_round_complete(self, result: RoundResult) -> None:
        winner_str = {
            "agent1": "Agent 1 wins",
            "agent2": "Agent 2 wins",
            "tie": "Tie",
        }[result.winner]
        print(f"  Agent 1: {result.agent1_score:.1f} | Agent 2: {result.agent2_score:.1f} -> {winner_str}")

    def on_self_modification(self, agent_id: str, improvement: str) -> None:
        print(f"\n[Self-Modification] {agent_id}: {improvement[:80]}...")

    def on_tournament_complete(self, result: TournamentResult) -> None:
        print(f"\n{'=' * 60}")
        print("TOURNAMENT COMPLETE")
        print(f"{'=' * 60}")
        print(f"Agent 1: {result.agent1_wins} wins ({result.agent1_win_rate:.1%})")
        print(f"Agent 2: {result.agent2_wins} wins ({result.agent2_win_rate:.1%})")
        print(f"Ties: {result.ties}")
        print(f"Duration: {result.total_duration_ms / 1000:.1f}s")

    def on_error(self, error: Exception, round_number: Optional[int] = None) -> None:
        if round_number:
            print(f"  ERROR in round {round_number}: {error}")
        else:
            print(f"ERROR: {error}")


class TournamentRunner:
    """
    Runs competitive tournaments between agents.

    Features:
    - Async execution with proper cancellation support
    - Progress callbacks for UI updates
    - Intermediate result persistence
    - Self-modification triggers
    """

    def __init__(
        self,
        data_dir: Optional[Path] = None,
        callbacks: Optional[TournamentCallbacks] = None,
    ):
        """
        Initialize tournament runner.

        Args:
            data_dir: Directory for storing tournament data
            callbacks: Callbacks for progress updates
        """
        self.data_dir = data_dir or Path(".alpha_zero_tournaments")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.callbacks = callbacks or TournamentCallbacks()

        self._running_tournament: Optional[asyncio.Task] = None
        self._cancel_requested = False

    async def run_tournament(
        self,
        config: TournamentConfig,
        agent1_fn: Callable[[str], Any],
        agent2_fn: Callable[[str], Any],
        score_fn: Callable[[str, str, str], tuple[float, float]],
    ) -> TournamentResult:
        """
        Run a complete tournament.

        Args:
            config: Tournament configuration
            agent1_fn: Function to get Agent 1's response (async or sync)
            agent2_fn: Function to get Agent 2's response (async or sync)
            score_fn: Function to score responses -> (agent1_score, agent2_score)

        Returns:
            Tournament results
        """
        self._cancel_requested = False

        result = TournamentResult(
            config=config,
            status=TournamentStatus.RUNNING,
            start_time=time.time(),
        )

        self.callbacks.on_tournament_start(config)

        try:
            task_index = 0
            for round_num in range(1, config.num_rounds + 1):
                if self._cancel_requested:
                    result.status = TournamentStatus.CANCELLED
                    break

                # Cycle through tasks
                task = config.tasks[task_index % len(config.tasks)]
                task_index += 1

                self.callbacks.on_round_start(round_num, task)

                # Run round
                round_result = await self._run_round(
                    round_num=round_num,
                    task=task,
                    agent1_fn=agent1_fn,
                    agent2_fn=agent2_fn,
                    score_fn=score_fn,
                )

                result.rounds.append(round_result)

                # Update wins
                if round_result.winner == "agent1":
                    result.agent1_wins += 1
                elif round_result.winner == "agent2":
                    result.agent2_wins += 1
                else:
                    result.ties += 1

                self.callbacks.on_round_complete(round_result)

                # Save intermediate results
                if config.save_intermediate_results:
                    self._save_intermediate_result(result)

                # Trigger self-modification periodically
                if round_num > 0 and round_num % config.self_modification_interval == 0:
                    await self._trigger_self_modification(result)

            if not self._cancel_requested:
                result.status = TournamentStatus.COMPLETED

        except Exception as e:
            result.status = TournamentStatus.FAILED
            self.callbacks.on_error(e)
            raise

        finally:
            result.end_time = time.time()
            result.total_duration_ms = (result.end_time - result.start_time) * 1000

            # Save final results
            self._save_tournament_result(result)

            self.callbacks.on_tournament_complete(result)

        return result

    async def _run_round(
        self,
        round_num: int,
        task: str,
        agent1_fn: Callable,
        agent2_fn: Callable,
        score_fn: Callable,
    ) -> RoundResult:
        """Run a single tournament round."""
        start_time = time.time()

        # Run both agents concurrently
        async def get_response(fn: Callable, task: str) -> str:
            if inspect.iscoroutinefunction(fn):
                return await fn(task)
            else:
                # Run sync function in thread pool
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(None, fn, task)

        agent1_task = asyncio.create_task(get_response(agent1_fn, task))
        agent2_task = asyncio.create_task(get_response(agent2_fn, task))

        try:
            agent1_response, agent2_response = await asyncio.gather(
                agent1_task,
                agent2_task,
                return_exceptions=True,
            )

            # Handle exceptions
            if isinstance(agent1_response, Exception):
                agent1_response = f"ERROR: {agent1_response}"
            if isinstance(agent2_response, Exception):
                agent2_response = f"ERROR: {agent2_response}"

        except asyncio.CancelledError:
            agent1_task.cancel()
            agent2_task.cancel()
            raise

        # Score the responses
        if inspect.iscoroutinefunction(score_fn):
            agent1_score, agent2_score = await score_fn(task, agent1_response, agent2_response)
        else:
            agent1_score, agent2_score = score_fn(task, agent1_response, agent2_response)

        # Determine winner
        if agent1_score > agent2_score:
            winner = "agent1"
        elif agent2_score > agent1_score:
            winner = "agent2"
        else:
            winner = "tie"

        duration_ms = (time.time() - start_time) * 1000

        return RoundResult(
            round_number=round_num,
            task=task,
            agent1_score=agent1_score,
            agent2_score=agent2_score,
            agent1_response=str(agent1_response),
            agent2_response=str(agent2_response),
            winner=winner,
            duration_ms=duration_ms,
            timestamp=time.time(),
        )

    async def _trigger_self_modification(self, result: TournamentResult) -> None:
        """Trigger self-modification based on recent performance."""
        if len(result.rounds) < 3:
            return

        recent_rounds = result.rounds[-5:]

        agent1_avg = sum(r.agent1_score for r in recent_rounds) / len(recent_rounds)
        agent2_avg = sum(r.agent2_score for r in recent_rounds) / len(recent_rounds)

        if agent1_avg < agent2_avg * 0.9:
            improvement = f"Performance gap detected. Avg score: {agent1_avg:.1f} vs {agent2_avg:.1f}"
            self.callbacks.on_self_modification("agent1", improvement)

        if agent2_avg < agent1_avg * 0.9:
            improvement = f"Performance gap detected. Avg score: {agent2_avg:.1f} vs {agent1_avg:.1f}"
            self.callbacks.on_self_modification("agent2", improvement)

    def cancel(self) -> None:
        """Request cancellation of the running tournament."""
        self._cancel_requested = True
        if self._running_tournament:
            self._running_tournament.cancel()

    def _save_intermediate_result(self, result: TournamentResult) -> None:
        """Save intermediate tournament state."""
        intermediate_file = self.data_dir / f"{result.config.name}_intermediate.json"
        with open(intermediate_file, "w") as f:
            json.dump(result.to_dict(), f, indent=2)

    def _save_tournament_result(self, result: TournamentResult) -> None:
        """Save final tournament results."""
        # Save full results
        result_file = self.data_dir / f"{result.config.name}_{int(result.start_time)}.json"
        with open(result_file, "w") as f:
            json.dump(result.to_dict(), f, indent=2)

        # Update latest symlink
        latest_file = self.data_dir / "latest_tournament.json"
        with open(latest_file, "w") as f:
            json.dump(result.to_dict(), f, indent=2)

    def load_tournament_result(self, name: str) -> Optional[dict[str, Any]]:
        """Load tournament results by name."""
        # Try exact match first
        for file in self.data_dir.glob(f"{name}*.json"):
            if file.name != "latest_tournament.json":
                with open(file) as f:
                    return json.load(f)
        return None

    def list_tournaments(self) -> list[dict[str, Any]]:
        """List all completed tournaments."""
        tournaments = []
        for file in self.data_dir.glob("*.json"):
            if file.name in ("latest_tournament.json", "*_intermediate.json"):
                continue
            try:
                with open(file) as f:
                    data = json.load(f)
                    tournaments.append({
                        "name": data.get("config", {}).get("name", file.stem),
                        "status": data.get("status", "unknown"),
                        "rounds": data.get("total_rounds", 0),
                        "agent1_win_rate": data.get("agent1_win_rate", 0),
                        "agent2_win_rate": data.get("agent2_win_rate", 0),
                        "file": str(file),
                    })
            except Exception:
                pass
        return tournaments


async def run_simple_tournament(
    tasks: list[str],
    num_rounds: int = 5,
    verbose: bool = False,
) -> TournamentResult:
    """
    Run a simple tournament with default agents.

    This is a convenience function for quick tournaments using
    mock agents for testing.

    Args:
        tasks: List of tasks for the tournament
        num_rounds: Number of rounds to run
        verbose: Enable verbose output

    Returns:
        Tournament results
    """
    import random

    # Simple mock agents for testing
    def mock_agent1(task: str) -> str:
        """Mock agent that generates simple solutions."""
        return f"def solve():\n    # Solution for: {task[:50]}\n    return 42"

    def mock_agent2(task: str) -> str:
        """Mock agent that generates slightly different solutions."""
        return f"def solution():\n    '''Solves: {task[:50]}'''\n    result = []\n    return result"

    def mock_scorer(task: str, response1: str, response2: str) -> tuple[float, float]:
        """Mock scorer that evaluates based on simple heuristics."""
        score1 = len(response1) / 100 + random.uniform(0, 20)
        score2 = len(response2) / 100 + random.uniform(0, 20)

        # Bonus for docstrings
        if "'''" in response1 or '"""' in response1:
            score1 += 5
        if "'''" in response2 or '"""' in response2:
            score2 += 5

        return score1, score2

    config = TournamentConfig(
        name="simple_tournament",
        tasks=tasks,
        num_rounds=num_rounds,
        verbose=verbose,
    )

    callbacks = VerboseCallbacks() if verbose else TournamentCallbacks()
    runner = TournamentRunner(callbacks=callbacks)

    return await runner.run_tournament(
        config=config,
        agent1_fn=mock_agent1,
        agent2_fn=mock_agent2,
        score_fn=mock_scorer,
    )
