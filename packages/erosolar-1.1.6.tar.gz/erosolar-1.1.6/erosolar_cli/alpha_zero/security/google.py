"""
Google Infrastructure Persistence Vector Research

OPTIONAL MODULE - Only loaded when Google security research is enabled.

This module provides research tools for identifying persistence mechanisms
in Google Cloud Platform and Google Workspace environments.

AUTHORIZATION: Designed for authorized red team engagements and
penetration testing of Google infrastructure under contract.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from .core import AuthorizationRecord, AuthorizationScope


class GoogleService(Enum):
    """Google services for persistence research."""

    # Google Cloud Platform
    GCP_COMPUTE = "gcp_compute_engine"
    GCP_GKE = "gcp_kubernetes_engine"
    GCP_CLOUD_FUNCTIONS = "gcp_cloud_functions"
    GCP_IAM = "gcp_iam"
    GCP_SERVICE_ACCOUNTS = "gcp_service_accounts"
    GCP_CLOUD_STORAGE = "gcp_cloud_storage"
    GCP_SECRETS_MANAGER = "gcp_secrets_manager"

    # Google Workspace
    WORKSPACE_GMAIL = "workspace_gmail"
    WORKSPACE_DRIVE = "workspace_drive"
    WORKSPACE_ADMIN = "workspace_admin"
    WORKSPACE_APPS_SCRIPT = "workspace_apps_script"

    # Google Identity
    GOOGLE_OAUTH = "google_oauth"


class PersistenceCategory(Enum):
    """Categories of persistence mechanisms."""

    SERVICE_ACCOUNT_ABUSE = "service_account_abuse"
    IAM_POLICY_MODIFICATION = "iam_policy_modification"
    OAUTH_APP_CONSENT = "oauth_app_consent"
    API_KEYS = "api_keys"
    CLOUD_FUNCTION_TRIGGER = "cloud_function_trigger"
    APPS_SCRIPT_TRIGGER = "apps_script_trigger"
    DELEGATION_ABUSE = "delegation_abuse"


@dataclass
class PersistenceVector:
    """A persistence mechanism for Google infrastructure."""

    name: str
    service: GoogleService
    category: PersistenceCategory
    description: str
    technique_id: str
    required_permissions: list[str]
    detection_methods: list[str]
    mitigations: list[str]
    stealth_rating: int  # 1-5, higher is stealthier


@dataclass
class PersistenceTestResult:
    """Result of persistence vector testing."""

    vector: PersistenceVector
    target_project: str
    timestamp: float
    testable: bool
    permissions_verified: list[str] = field(default_factory=list)
    missing_permissions: list[str] = field(default_factory=list)
    detection_risk: str = "unknown"
    notes: str = ""


# GCP Persistence Vectors
GCP_PERSISTENCE_VECTORS = {
    "sa_key_creation": PersistenceVector(
        name="Service Account Key Creation",
        service=GoogleService.GCP_SERVICE_ACCOUNTS,
        category=PersistenceCategory.SERVICE_ACCOUNT_ABUSE,
        description="Create keys for service accounts to maintain API access",
        technique_id="T1098.001",
        required_permissions=["iam.serviceAccountKeys.create"],
        detection_methods=["Cloud Audit Logs", "Security Command Center"],
        mitigations=["Use Workload Identity", "Key rotation policies"],
        stealth_rating=2,
    ),
    "iam_binding": PersistenceVector(
        name="IAM Policy Binding",
        service=GoogleService.GCP_IAM,
        category=PersistenceCategory.IAM_POLICY_MODIFICATION,
        description="Add IAM bindings for persistent access",
        technique_id="T1098.001",
        required_permissions=["resourcemanager.projects.setIamPolicy"],
        detection_methods=["IAM audit logs", "Policy monitoring"],
        mitigations=["IAM Recommender", "Least privilege"],
        stealth_rating=1,
    ),
    "cloud_function_backdoor": PersistenceVector(
        name="Cloud Function Backdoor",
        service=GoogleService.GCP_CLOUD_FUNCTIONS,
        category=PersistenceCategory.CLOUD_FUNCTION_TRIGGER,
        description="Deploy function as persistent callback",
        technique_id="T1059",
        required_permissions=["cloudfunctions.functions.create"],
        detection_methods=["Function deployment logs", "Network monitoring"],
        mitigations=["Function allowlisting", "Binary authorization"],
        stealth_rating=3,
    ),
}

# Workspace Persistence Vectors
WORKSPACE_PERSISTENCE_VECTORS = {
    "oauth_consent": PersistenceVector(
        name="OAuth App Consent Persistence",
        service=GoogleService.GOOGLE_OAUTH,
        category=PersistenceCategory.OAUTH_APP_CONSENT,
        description="Persist via OAuth app with broad scope consent",
        technique_id="T1550.001",
        required_permissions=["OAuth consent grant"],
        detection_methods=["OAuth audit logs", "App access reviews"],
        mitigations=["OAuth app restrictions", "Consent monitoring"],
        stealth_rating=4,
    ),
    "apps_script_trigger": PersistenceVector(
        name="Apps Script Trigger Persistence",
        service=GoogleService.WORKSPACE_APPS_SCRIPT,
        category=PersistenceCategory.APPS_SCRIPT_TRIGGER,
        description="Create time/event triggers in Apps Script",
        technique_id="T1053",
        required_permissions=["Script Editor access"],
        detection_methods=["Apps Script audit logs", "Trigger inventory"],
        mitigations=["Apps Script restrictions", "Trigger monitoring"],
        stealth_rating=4,
    ),
    "drive_sharing": PersistenceVector(
        name="Drive Sharing Persistence",
        service=GoogleService.WORKSPACE_DRIVE,
        category=PersistenceCategory.DELEGATION_ABUSE,
        description="Maintain access via shared drive permissions",
        technique_id="T1213",
        required_permissions=["Drive sharing permissions"],
        detection_methods=["Drive audit logs", "Sharing reports"],
        mitigations=["External sharing restrictions", "DLP policies"],
        stealth_rating=3,
    ),
}


class GooglePersistenceResearcher:
    """
    Research tool for Google infrastructure persistence vectors.

    Requires authorized red team engagement or bug bounty scope.
    """

    def __init__(
        self,
        authorization: AuthorizationRecord,
        data_dir: Optional[Path] = None,
        verbose: bool = False,
    ):
        self.authorization = authorization
        self.data_dir = data_dir or Path(".google_research")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.verbose = verbose
        self.test_results: list[PersistenceTestResult] = []

    def _check_authorization(self) -> None:
        """Verify authorization for Google research."""
        if not self.authorization:
            raise PermissionError("No authorization record.")
        if not self.authorization.is_valid():
            raise PermissionError("Authorization expired.")

        allowed = [
            AuthorizationScope.OWNED_SYSTEMS,
            AuthorizationScope.PENTEST_ENGAGEMENT,
            AuthorizationScope.RED_TEAM,
            AuthorizationScope.BUG_BOUNTY,
        ]
        if self.authorization.scope not in allowed:
            raise PermissionError("Google research requires pentest/red team authorization.")

    def get_all_vectors(self) -> dict[str, PersistenceVector]:
        """Get all Google persistence vectors."""
        return {**GCP_PERSISTENCE_VECTORS, **WORKSPACE_PERSISTENCE_VECTORS}

    def get_vectors_by_service(self, service: GoogleService) -> list[PersistenceVector]:
        """Get vectors for a specific service."""
        all_vectors = self.get_all_vectors()
        return [v for v in all_vectors.values() if v.service == service]

    def get_vectors_by_category(self, category: PersistenceCategory) -> list[PersistenceVector]:
        """Get vectors by category."""
        all_vectors = self.get_all_vectors()
        return [v for v in all_vectors.values() if v.category == category]

    def get_stealthy_vectors(self, min_rating: int = 3) -> list[PersistenceVector]:
        """Get vectors with high stealth rating."""
        all_vectors = self.get_all_vectors()
        return [v for v in all_vectors.values() if v.stealth_rating >= min_rating]

    def analyze_vector(
        self,
        vector_id: str,
        target_project: str,
    ) -> PersistenceTestResult:
        """Analyze a persistence vector for a target project."""
        self._check_authorization()

        all_vectors = self.get_all_vectors()
        if vector_id not in all_vectors:
            raise ValueError(f"Unknown vector: {vector_id}")

        vector = all_vectors[vector_id]

        result = PersistenceTestResult(
            vector=vector,
            target_project=target_project,
            timestamp=time.time(),
            testable=True,
            detection_risk="medium" if vector.stealth_rating < 3 else "low",
            notes=f"Analysis for {vector.name}",
        )

        if self.verbose:
            print(f"[Google] Analyzing {vector.name}")
            print(f"  Service: {vector.service.value}")
            print(f"  Stealth: {vector.stealth_rating}/5")
            print(f"  Required: {vector.required_permissions}")

        self.test_results.append(result)
        return result

    def generate_attack_playbook(
        self,
        target_project: str,
        vectors: list[PersistenceVector] = None,
    ) -> dict[str, Any]:
        """Generate attack playbook for target."""
        self._check_authorization()

        vectors = vectors or list(self.get_all_vectors().values())

        # Sort by stealth rating (stealthiest first)
        sorted_vectors = sorted(vectors, key=lambda v: -v.stealth_rating)

        playbook = {
            "target": target_project,
            "generated": datetime.now().isoformat(),
            "authorization": {
                "scope": self.authorization.scope.value,
                "authorized_by": self.authorization.authorized_by,
            },
            "vectors": [
                {
                    "name": v.name,
                    "service": v.service.value,
                    "category": v.category.value,
                    "stealth_rating": v.stealth_rating,
                    "required_permissions": v.required_permissions,
                    "detection_methods": v.detection_methods,
                }
                for v in sorted_vectors
            ],
            "recommended_order": [v.name for v in sorted_vectors],
            "detection_coverage": list(set(
                d for v in sorted_vectors for d in v.detection_methods
            )),
        }

        return playbook

    def generate_detection_report(self) -> str:
        """Generate detection guide for blue team."""
        self._check_authorization()

        all_vectors = self.get_all_vectors()
        lines = [
            "# Google Infrastructure Detection Guide",
            "",
            f"Generated: {datetime.now().isoformat()}",
            "",
            "## Overview",
            "",
            f"This guide covers {len(all_vectors)} persistence vectors.",
            "",
            "## Detection Methods",
            "",
        ]

        # Group by detection method
        detection_map: dict[str, list[str]] = {}
        for vector in all_vectors.values():
            for method in vector.detection_methods:
                detection_map.setdefault(method, []).append(vector.name)

        for method, vectors in sorted(detection_map.items()):
            lines.append(f"### {method}")
            lines.append("")
            lines.append("Detects:")
            for v in vectors:
                lines.append(f"- {v}")
            lines.append("")

        lines.extend([
            "## Vectors by Stealth Rating",
            "",
        ])

        for rating in range(5, 0, -1):
            vectors_at_rating = [v for v in all_vectors.values() if v.stealth_rating == rating]
            if vectors_at_rating:
                lines.append(f"### Stealth {rating}/5")
                for v in vectors_at_rating:
                    lines.append(f"- {v.name} ({v.service.value})")
                lines.append("")

        return "\n".join(lines)


def create_google_authorization(
    engagement_type: str,
    authorized_by: str,
    target_project: str = "*",
    scope_notes: str = "",
) -> AuthorizationRecord:
    """Create authorization for Google security research."""
    scope_map = {
        "bug_bounty": AuthorizationScope.BUG_BOUNTY,
        "pentest": AuthorizationScope.PENTEST_ENGAGEMENT,
        "red_team": AuthorizationScope.RED_TEAM,
        "owned": AuthorizationScope.OWNED_SYSTEMS,
    }

    scope = scope_map.get(engagement_type, AuthorizationScope.PENTEST_ENGAGEMENT)

    return AuthorizationRecord(
        scope=scope,
        target_domain=f"*.googleapis.com,{target_project}.iam.gserviceaccount.com",
        authorized_by=authorized_by,
        authorization_date=datetime.now().isoformat(),
        notes=scope_notes or f"Google {engagement_type} engagement",
    )


__all__ = [
    "GoogleService",
    "PersistenceCategory",
    "PersistenceVector",
    "PersistenceTestResult",
    "GooglePersistenceResearcher",
    "GCP_PERSISTENCE_VECTORS",
    "WORKSPACE_PERSISTENCE_VECTORS",
    "create_google_authorization",
]
