"""UI module for terminal display with Rich formatting."""

from .display import Display, display

__all__ = ["Display", "display"]
