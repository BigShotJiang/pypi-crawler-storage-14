"""
Placeholder tool display helpers to mirror the TypeScript UI surface.
"""

from __future__ import annotations


def format_tool_call(name: str, args: dict | None = None) -> str:
    """Format a tool call for display."""
    return f"[tool] {name} {args or {}}"


def format_tool_result(name: str, output: str) -> str:
    """Format a tool result for display."""
    return f"[tool result] {name}: {output}"
