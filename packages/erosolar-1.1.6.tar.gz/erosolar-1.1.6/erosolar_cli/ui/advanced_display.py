"""
Advanced Display System - Sophisticated UI/UX for Python CLI.

Features:
- Gradient effects and color transitions
- Advanced animations and spinners
- Sophisticated progress indicators
- Intelligent theming system
"""

from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass
from enum import Enum
from typing import List, Tuple, Optional, Iterator

from rich.console import Console
from rich.text import Text
from rich.style import Style
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.live import Live
from rich.layout import Layout
from rich.panel import Panel
from rich.columns import Columns


class ColorPalette(Enum):
    """Sophisticated color palettes."""

    AURORA = {
        "primary": (64, 224, 208),      # Turquoise
        "secondary": (147, 112, 219),    # Medium purple
        "accent": (255, 182, 193),       # Light pink
        "highlight": (255, 218, 185),    # Peach puff
        "warning": (255, 160, 122),      # Light salmon
        "error": (219, 112, 147),        # Pale violet red
        "success": (152, 251, 152),      # Pale green
        "info": (176, 196, 222),         # Light steel blue
    }

    NEON = {
        "primary": (0, 255, 255),        # Cyan
        "secondary": (255, 0, 255),      # Magenta
        "accent": (0, 255, 128),         # Spring green
        "highlight": (255, 255, 0),      # Yellow
        "warning": (255, 127, 0),        # Orange
        "error": (255, 0, 127),          # Rose
        "success": (0, 255, 127),        # Mint
        "info": (127, 127, 255),         # Periwinkle
    }

    MATRIX = {
        "primary": (0, 255, 0),          # Pure green
        "secondary": (0, 192, 0),        # Dark green
        "accent": (128, 255, 128),       # Light green
        "highlight": (192, 255, 192),    # Pale green
        "warning": (255, 255, 0),        # Yellow
        "error": (255, 64, 64),          # Light red
        "success": (0, 255, 128),        # Spring green
        "info": (0, 192, 255),           # Sky blue
    }

    SUNSET = {
        "primary": (255, 94, 77),        # Sunset orange
        "secondary": (255, 154, 0),      # Deep orange
        "accent": (255, 206, 84),        # Sunflower
        "highlight": (237, 117, 57),     # Burnt orange
        "warning": (255, 196, 0),        # Gold
        "error": (220, 53, 69),          # Crimson
        "success": (95, 189, 102),       # Emerald
        "info": (91, 192, 222),          # Sky blue
    }

    MIDNIGHT = {
        "primary": (100, 149, 237),      # Cornflower blue
        "secondary": (72, 61, 139),      # Dark slate blue
        "accent": (123, 104, 238),       # Medium slate blue
        "highlight": (147, 112, 219),    # Medium purple
        "warning": (255, 215, 0),        # Gold
        "error": (220, 20, 60),          # Crimson
        "success": (50, 205, 50),        # Lime green
        "info": (135, 206, 250),         # Light sky blue
    }


class GradientEffect:
    """Create sophisticated gradient effects."""

    @staticmethod
    def linear_gradient(
        text: str,
        start_color: Tuple[int, int, int],
        end_color: Tuple[int, int, int]
    ) -> Text:
        """Create a linear gradient between two colors."""
        result = Text()
        length = len(text)

        if length == 0:
            return result

        for i, char in enumerate(text):
            if char == ' ':
                result.append(char)
                continue

            # Calculate interpolation ratio
            ratio = i / max(1, length - 1)

            # Interpolate RGB values
            r = int(start_color[0] + (end_color[0] - start_color[0]) * ratio)
            g = int(start_color[1] + (end_color[1] - start_color[1]) * ratio)
            b = int(start_color[2] + (end_color[2] - start_color[2]) * ratio)

            result.append(char, style=f"rgb({r},{g},{b})")

        return result

    @staticmethod
    def rainbow_gradient(text: str) -> Text:
        """Create a rainbow gradient effect."""
        result = Text()
        length = len(text)

        if length == 0:
            return result

        for i, char in enumerate(text):
            if char == ' ':
                result.append(char)
                continue

            # Calculate hue based on position
            hue = (i * 360) // max(1, length)
            # Convert HSV to RGB (simplified, assuming S=1, V=1)
            h = hue / 60
            c = 1.0
            x = c * (1 - abs((h % 2) - 1))

            if h < 1:
                r, g, b = c, x, 0
            elif h < 2:
                r, g, b = x, c, 0
            elif h < 3:
                r, g, b = 0, c, x
            elif h < 4:
                r, g, b = 0, x, c
            elif h < 5:
                r, g, b = x, 0, c
            else:
                r, g, b = c, 0, x

            r, g, b = int(r * 255), int(g * 255), int(b * 255)
            result.append(char, style=f"rgb({r},{g},{b})")

        return result

    @staticmethod
    def pulse_gradient(
        text: str,
        color: Tuple[int, int, int],
        intensity: float = 0.5
    ) -> Text:
        """Create a pulsing gradient effect (bright to dim)."""
        result = Text()
        length = len(text)

        if length == 0:
            return result

        midpoint = length / 2

        for i, char in enumerate(text):
            if char == ' ':
                result.append(char)
                continue

            # Calculate distance from center
            distance = abs(i - midpoint) / max(1, midpoint)
            brightness = 1 - (distance * intensity)

            # Apply brightness to color
            r = int(color[0] * brightness)
            g = int(color[1] * brightness)
            b = int(color[2] * brightness)

            result.append(char, style=f"rgb({r},{g},{b})")

        return result

    @staticmethod
    def wave_gradient(
        text: str,
        primary: Tuple[int, int, int],
        secondary: Tuple[int, int, int],
        frequency: float = 0.5
    ) -> Text:
        """Create a wave-like gradient effect."""
        result = Text()

        for i, char in enumerate(text):
            if char == ' ':
                result.append(char)
                continue

            # Calculate wave position
            wave = (math.sin(i * frequency) + 1) / 2

            # Interpolate between colors
            r = int(primary[0] * wave + secondary[0] * (1 - wave))
            g = int(primary[1] * wave + secondary[1] * (1 - wave))
            b = int(primary[2] * wave + secondary[2] * (1 - wave))

            result.append(char, style=f"rgb({r},{g},{b})")

        return result


class AdvancedSymbols:
    """Sophisticated symbols and icons."""

    # Status indicators
    STATUS = {
        "running": "◉",
        "pending": "◯",
        "success": "✦",
        "error": "✗",
        "warning": "⚡",
        "info": "◈",
        "thinking": "◐",
        "complete": "◆",
    }

    # Tool operation symbols
    TOOLS = {
        "read": "📖",
        "write": "✏️",
        "edit": "✂️",
        "search": "🔍",
        "execute": "⚡",
        "web": "🌐",
        "task": "🎯",
        "glob": "📁",
    }

    # Progress indicators
    PROGRESS = {
        "empty": "░",
        "quarter": "▒",
        "half": "▓",
        "full": "█",
    }

    # Decorative elements
    DECORATIVE = {
        "star": "✦",
        "diamond": "◆",
        "circle": "◉",
        "square": "▣",
        "triangle": "▲",
        "hexagon": "⬡",
        "sparkle": "✨",
        "lightning": "⚡",
    }

    # Box drawing
    BOX = {
        "top_left": "╭",
        "top_right": "╮",
        "bottom_left": "╰",
        "bottom_right": "╯",
        "horizontal": "─",
        "vertical": "│",
        "cross": "┼",
        "tee": "├",
    }


class AnimationFrames:
    """Sophisticated animation frame generators."""

    @staticmethod
    def quantum_spinner() -> List[str]:
        """Quantum-style spinner frames."""
        return ["◐", "◓", "◑", "◒", "⟳", "⟲", "⌛", "⏳", "⧗", "⧖"]

    @staticmethod
    def elegant_dots() -> List[str]:
        """Elegant rotating dots."""
        return [
            "⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷",
            "⣿", "⣯", "⣟", "⡿", "⢿", "⣻", "⣽", "⣾"
        ]

    @staticmethod
    def orbital() -> List[str]:
        """Orbital spinner frames."""
        return ["◴", "◷", "◶", "◵", "◸", "◹", "◺", "◿"]

    @staticmethod
    def pulse() -> List[str]:
        """Pulsing dot frames."""
        return ["⬤", "◉", "◎", "○", "◎", "◉"]

    @staticmethod
    def wave() -> List[str]:
        """Wave animation frames."""
        return [
            "▁▂▃", "▂▃▄", "▃▄▅", "▄▅▆", "▅▆▇", "▆▇█", "▇█▇", "█▇▆",
            "▇▆▅", "▆▅▄", "▅▄▃", "▄▃▂", "▃▂▁", "▂▁▂"
        ]

    @staticmethod
    def helix() -> List[str]:
        """DNA helix-style spinner."""
        return ["⠁", "⠂", "⠄", "⡀", "⢀", "⠠", "⠐", "⠈"]

    @staticmethod
    def matrix() -> List[str]:
        """Matrix rain effect frames."""
        chars = "ｦｱｳｴｵｶｷｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾒﾓﾔﾕﾗﾘﾜ012345789:・."
        return list(chars)


class TextEffects:
    """Sophisticated text effects."""

    @staticmethod
    def glitch_effect(text: str, intensity: float = 0.1) -> Text:
        """Apply glitch effect to text."""
        glitch_chars = "░▒▓█▀▄▌▐│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌"
        result = Text()

        for char in text:
            if random.random() < intensity and char != ' ':
                glitch_char = random.choice(glitch_chars)
                result.append(glitch_char, style="rgb(255,0,255)")
            else:
                result.append(char)

        return result

    @staticmethod
    def neon_glow(text: str, color: Tuple[int, int, int]) -> Text:
        """Apply neon glow effect."""
        r, g, b = color
        bright_r = min(255, int(r * 1.5))
        bright_g = min(255, int(g * 1.5))
        bright_b = min(255, int(b * 1.5))

        result = Text(f" {text} ")
        result.stylize(f"bold rgb({bright_r},{bright_g},{bright_b}) on rgb({r//3},{g//3},{b//3})")
        return result

    @staticmethod
    def matrix_rain(text: str) -> Text:
        """Apply matrix rain effect."""
        result = Text()

        for char in text:
            if char == ' ':
                result.append(char)
            else:
                brightness = random.random()
                green = int(255 * brightness)
                result.append(char, style=f"rgb(0,{green},0)")

        return result

    @staticmethod
    def holographic(text: str, time_offset: float = 0) -> Text:
        """Apply holographic shimmer effect."""
        result = Text()

        for i, char in enumerate(text):
            if char == ' ':
                result.append(char)
            else:
                # Create time-based hue shift
                hue = int(((i * 20) + (time_offset * 50)) % 360)
                h = hue / 60
                c = 1.0
                x = c * (1 - abs((h % 2) - 1))

                if h < 1:
                    r, g, b = c, x, 0
                elif h < 2:
                    r, g, b = x, c, 0
                elif h < 3:
                    r, g, b = 0, c, x
                elif h < 4:
                    r, g, b = 0, x, c
                elif h < 5:
                    r, g, b = x, 0, c
                else:
                    r, g, b = c, 0, x

                r, g, b = int(r * 255), int(g * 255), int(b * 255)
                result.append(char, style=f"rgb({r},{g},{b})")

        return result


class AdvancedDisplay:
    """Advanced display system with sophisticated UI/UX features."""

    def __init__(self, console: Optional[Console] = None):
        """Initialize advanced display."""
        self.console = console or Console(
            force_terminal=True,
            highlight=False,
        )
        self.current_palette = ColorPalette.AURORA.value
        self.animation_frame = 0
        self.spinner_live: Optional[Live] = None

    def _rgb_style(self, color_key: str) -> str:
        """Convert palette color to RGB style string."""
        color = self.current_palette.get(color_key, (128, 128, 128))
        if isinstance(color, tuple) and len(color) == 3:
            return f"rgb({color[0]},{color[1]},{color[2]})"
        return "rgb(128,128,128)"

    def set_palette(self, palette: ColorPalette):
        """Set the color palette."""
        self.current_palette = palette.value

    def show_header(self, title: str, subtitle: Optional[str] = None):
        """Display a sophisticated header with gradient."""
        # Create gradient title
        gradient_title = GradientEffect.wave_gradient(
            title.upper(),
            self.current_palette["primary"],
            self.current_palette["secondary"]
        )

        # Create panel with gradient border
        header_content = gradient_title
        if subtitle:
            subtitle_text = Text(subtitle, style=self._rgb_style("accent"))
            header_content = Text.from_markup(f"{gradient_title}\n{subtitle_text}")

        panel = Panel(
            header_content,
            border_style=self._rgb_style("primary"),
            padding=(1, 2),
            expand=False
        )

        self.console.print(panel)

    def show_progress_bar(
        self,
        progress: float,
        description: str = "",
        total: int = 100,
        show_percentage: bool = True
    ):
        """Display a sophisticated progress bar with gradient."""
        # Create custom progress bar
        with Progress(
            SpinnerColumn(spinner_name="dots"),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(
                style=self._rgb_style("success"),
                complete_style=self._rgb_style("primary"),
                finished_style=self._rgb_style("highlight")
            ),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%") if show_percentage else "",
            TimeElapsedColumn(),
            console=self.console,
            transient=True
        ) as progress_bar:
            task = progress_bar.add_task(description, total=total)
            progress_bar.update(task, completed=int(progress * total))

    def show_spinner(self, message: str, spinner_type: str = "quantum"):
        """Show advanced spinner with message."""
        if self.spinner_live:
            self.spinner_live.stop()

        # Get spinner frames
        frame_generators = {
            "quantum": AnimationFrames.quantum_spinner,
            "elegant": AnimationFrames.elegant_dots,
            "orbital": AnimationFrames.orbital,
            "pulse": AnimationFrames.pulse,
            "wave": AnimationFrames.wave,
            "helix": AnimationFrames.helix,
            "matrix": AnimationFrames.matrix,
        }

        frames = frame_generators.get(spinner_type, AnimationFrames.quantum_spinner)()

        # Create animated spinner
        def get_frame():
            frame = frames[self.animation_frame % len(frames)]
            self.animation_frame += 1
            return GradientEffect.pulse_gradient(
                frame,
                self.current_palette["primary"],
                0.7
            )

        spinner_text = Text()
        spinner_text.append(get_frame())
        spinner_text.append(f" {message}", style=self._rgb_style("info"))

        self.spinner_live = Live(spinner_text, console=self.console, transient=True)
        self.spinner_live.start()

    def stop_spinner(self):
        """Stop the current spinner."""
        if self.spinner_live:
            self.spinner_live.stop()
            self.spinner_live = None

    def show_tool_call(self, tool_name: str, args: dict):
        """Display tool call with sophisticated formatting."""
        # Create gradient tool name
        tool_text = GradientEffect.wave_gradient(
            tool_name,
            self.current_palette["primary"],
            self.current_palette["secondary"]
        )

        # Format arguments with smart truncation
        arg_parts = []
        for key, value in list(args.items())[:2]:  # Show max 2 args
            value_str = str(value)
            if len(value_str) > 50:
                value_str = value_str[:47] + "..."
            arg_parts.append(f"{key}={value_str!r}")

        args_text = ", ".join(arg_parts)
        if len(args) > 2:
            args_text += ", ..."

        # Create sophisticated symbol
        symbol = AdvancedSymbols.STATUS["running"]
        symbol_text = GradientEffect.pulse_gradient(
            symbol,
            self.current_palette["primary"],
            0.8
        )

        # Combine and display
        full_text = Text()
        full_text.append(symbol_text)
        full_text.append(" ")
        full_text.append(tool_text)
        full_text.append(f"({args_text})", style=self._rgb_style("accent"))

        self.console.print(full_text)

    def show_tool_result(self, tool_name: str, result: str, success: bool = True):
        """Display tool result with sophisticated formatting."""
        # Choose symbol and color based on success
        if success:
            symbol = AdvancedSymbols.STATUS["success"]
            color = self.current_palette["success"]
        else:
            symbol = AdvancedSymbols.STATUS["error"]
            color = self.current_palette["error"]

        symbol_text = GradientEffect.pulse_gradient("⎿", color, 0.5)

        # Format result with smart truncation
        lines = result.split("\n")
        if len(lines) > 10:
            lines = lines[:10]
            lines.append(f"... +{len(result.split('\n')) - 10} more lines")

        # Display result
        for i, line in enumerate(lines):
            if i == 0:
                result_text = Text()
                result_text.append("  ")
                result_text.append(symbol_text)
                result_text.append(f" {line}", style=f"rgb({color[0]},{color[1]},{color[2]})")
                self.console.print(result_text)
            else:
                self.console.print(f"    {line}", style=f"dim rgb({color[0]},{color[1]},{color[2]})")

    def show_separator(self, style: str = "gradient"):
        """Display a sophisticated separator."""
        width = self.console.width

        if style == "gradient":
            separator = "─" * width
            sep_text = GradientEffect.linear_gradient(
                separator,
                self.current_palette["primary"],
                self.current_palette["secondary"]
            )
        elif style == "wave":
            separator = "~" * width
            sep_text = GradientEffect.wave_gradient(
                separator,
                self.current_palette["primary"],
                self.current_palette["secondary"],
                0.3
            )
        elif style == "dots":
            separator = "• " * (width // 2)
            sep_text = Text(separator, style=self._rgb_style("accent"))
        elif style == "stars":
            separator = "✦ " * (width // 2)
            sep_text = GradientEffect.rainbow_gradient(separator)
        else:
            sep_text = Text("─" * width, style=self._rgb_style("primary"))

        self.console.print(sep_text)

    def show_code_block(self, code: str, language: str = "python"):
        """Display code with sophisticated syntax highlighting."""
        from rich.syntax import Syntax

        # Create syntax object with custom theme
        syntax = Syntax(
            code,
            language,
            theme="monokai",
            line_numbers=True,
            word_wrap=False,
            background_color="default"
        )

        # Wrap in a panel with gradient border
        panel = Panel(
            syntax,
            border_style=self._rgb_style("primary"),
            title=f"[{language}]",
            title_align="left",
            padding=(0, 1)
        )

        self.console.print(panel)

    def create_dashboard(self, metrics: dict):
        """Create a sophisticated metrics dashboard."""
        # Create layout
        layout = Layout()
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="body"),
            Layout(name="footer", size=3)
        )

        # Header with gradient
        header_text = GradientEffect.wave_gradient(
            "METRICS DASHBOARD",
            self.current_palette["primary"],
            self.current_palette["secondary"]
        )
        layout["header"].update(Panel(header_text, border_style=self._rgb_style("primary")))

        # Body with metrics
        table = Table(show_header=True, header_style=self._rgb_style("highlight"))
        table.add_column("Metric", style=self._rgb_style("info"))
        table.add_column("Value", justify="right", style=self._rgb_style("success"))
        table.add_column("Status", justify="center")

        for key, value in metrics.items():
            status_symbol = AdvancedSymbols.STATUS["success"] if value.get("ok", True) else AdvancedSymbols.STATUS["warning"]
            table.add_row(
                key,
                str(value.get("value", "N/A")),
                status_symbol
            )

        layout["body"].update(Panel(table, border_style=self._rgb_style("secondary")))

        # Footer with time
        footer_text = Text(f"Last Updated: {time.strftime('%Y-%m-%d %H:%M:%S')}", style=self._rgb_style("accent"))
        layout["footer"].update(Panel(footer_text, border_style=self._rgb_style("primary")))

        self.console.print(layout)

    def animate_text(self, text: str, effect: str = "typewriter", delay: float = 0.05):
        """Animate text display with various effects."""
        if effect == "typewriter":
            displayed = ""
            with Live("", console=self.console, refresh_per_second=20) as live:
                for char in text:
                    displayed += char
                    cursor = "▊" if len(displayed) < len(text) else ""
                    live.update(Text(displayed + cursor, style=self._rgb_style("primary")))
                    time.sleep(delay)
        elif effect == "fade":
            with Live("", console=self.console, refresh_per_second=20) as live:
                for intensity in range(0, 11):
                    brightness = intensity / 10
                    r = int(self.current_palette["primary"][0] * brightness)
                    g = int(self.current_palette["primary"][1] * brightness)
                    b = int(self.current_palette["primary"][2] * brightness)
                    live.update(Text(text, style=f"rgb({r},{g},{b})"))
                    time.sleep(delay)
        elif effect == "glitch":
            with Live("", console=self.console, refresh_per_second=20) as live:
                for _ in range(10):
                    glitched = TextEffects.glitch_effect(text, intensity=0.2)
                    live.update(glitched)
                    time.sleep(delay)
                live.update(Text(text, style=self._rgb_style("primary")))
        else:
            self.console.print(text)