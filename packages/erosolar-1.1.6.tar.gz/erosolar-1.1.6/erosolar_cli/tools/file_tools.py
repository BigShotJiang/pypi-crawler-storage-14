"""
File operation tools for reading, writing, listing, and searching files.
"""

from __future__ import annotations

import glob as glob_module
import os
from pathlib import Path
from typing import Any

from ..core.tool_runtime import ToolDefinition
from ..core.types import (
    JSONSchemaArray,
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
)
from .diff_utils import build_diff_segments, format_diff_lines


def create_file_tools(working_dir: str) -> list[ToolDefinition]:
    """
    Create file operation tools.

    Args:
        working_dir: Working directory for resolving relative paths

    Returns:
        List of file tool definitions
    """
    working_path = Path(working_dir).resolve()

    # Read File Tool
    async def read_file_handler(args: dict[str, Any]) -> str:
        try:
            path_arg = args.get("path", "")
            if not path_arg or not isinstance(path_arg, str):
                return "Error: path must be a non-empty string."

            file_path = _resolve_path(working_path, path_arg)

            if not file_path.exists():
                return f"Error: File not found: {file_path}"

            if not file_path.is_file():
                return f"Error: Path is not a file: {file_path}"

            content = file_path.read_text(encoding="utf-8")
            return f"File: {file_path}\n\n{content}"

        except Exception as error:
            return f"Error reading file: {error}"

    # Write File Tool
    async def write_file_handler(args: dict[str, Any]) -> str:
        try:
            path_arg = args.get("path", "")
            if not path_arg or not isinstance(path_arg, str):
                return "Error: path must be a non-empty string."

            content = args.get("content", "")
            if not isinstance(content, str):
                content = str(content)

            file_path = _resolve_path(working_path, path_arg)

            # Create parent directories if needed
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Check if file exists and get previous content for diff
            file_previously_existed = file_path.exists()
            previous_content = file_path.read_text(encoding="utf-8") if file_previously_existed else ""

            # Write new content
            file_path.write_text(content, encoding="utf-8")

            # Generate diff
            diff_segments = build_diff_segments(previous_content, content)

            return _build_write_summary(file_path, diff_segments, working_path, file_previously_existed)

        except Exception as error:
            return f"Error writing file: {error}"

    # List Files Tool
    async def list_files_handler(args: dict[str, Any]) -> str:
        try:
            path_arg = args.get("path")
            recursive = args.get("recursive", False)

            if path_arg:
                if not isinstance(path_arg, str):
                    return "Error: path must be a string."
                dir_path = _resolve_path(working_path, path_arg)
            else:
                dir_path = working_path

            if not dir_path.exists():
                return f"Error: Directory not found: {dir_path}"

            if not dir_path.is_dir():
                return f"Error: Path is not a directory: {dir_path}"

            max_depth = 5 if recursive else 1
            files = _list_files_recursive(dir_path, max_depth, working_path)

            return f"Directory: {dir_path}\n\n{chr(10).join(files)}"

        except Exception as error:
            return f"Error listing files: {error}"

    # Search Files Tool
    async def search_files_handler(args: dict[str, Any]) -> str:
        try:
            pattern = args.get("pattern", "")
            if not pattern or not isinstance(pattern, str):
                return "Error: pattern must be a non-empty string."

            path_arg = args.get("path")
            if path_arg:
                if not isinstance(path_arg, str):
                    return "Error: path must be a string."
                search_path = _resolve_path(working_path, path_arg)
            else:
                search_path = working_path

            if not search_path.exists():
                return f"Error: Directory not found: {search_path}"

            # Use glob to find matching files
            results = _search_files_glob(search_path, pattern)

            if not results:
                return f"No files found matching pattern: {pattern}"

            # Format results as relative paths
            relative_results = []
            for result_path in results:
                try:
                    rel_path = result_path.relative_to(working_path)
                    relative_results.append(str(rel_path))
                except ValueError:
                    relative_results.append(str(result_path))

            return f"Found {len(results)} files:\n\n{chr(10).join(relative_results)}"

        except Exception as error:
            return f"Error searching files: {error}"

    return [
        ToolDefinition(
            name="read_file",
            description="Read the contents of a file at the specified path",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "path": JSONSchemaString(type="string",
                        description="The file path (relative to working directory or absolute)",
                        min_length=1,
                    )
                },
                required=["path"],
                additional_properties=False,
            ),
            handler=read_file_handler,
            cacheable=True,
        ),
        ToolDefinition(
            name="write_file",
            description="Write content to a file at the specified path (creates directories if needed)",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "path": JSONSchemaString(type="string",
                        description="The file path (relative to working directory or absolute)",
                        min_length=1,
                    ),
                    "content": JSONSchemaString(type="string",
                        description="The content to write to the file",
                    ),
                },
                required=["path", "content"],
                additional_properties=False,
            ),
            handler=write_file_handler,
        ),
        ToolDefinition(
            name="list_files",
            description="List files and directories at the specified path",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "path": JSONSchemaString(type="string",
                        description="The directory path (defaults to current working directory)",
                        min_length=1,
                    ),
                    "recursive": JSONSchemaBoolean(type="boolean",
                        description="Whether to list files recursively",
                    ),
                },
                additional_properties=False,
            ),
            handler=list_files_handler,
        ),
        ToolDefinition(
            name="search_files",
            description='Search for files matching a pattern (supports glob patterns like "*.ts", "src/**/*.js")',
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "pattern": JSONSchemaString(type="string",
                        description='The search pattern (e.g., "*.ts", "src/**/*.js")',
                        min_length=1,
                    ),
                    "path": JSONSchemaString(type="string",
                        description="The directory to search in (defaults to current working directory)",
                        min_length=1,
                    ),
                },
                required=["pattern"],
                additional_properties=False,
            ),
            handler=search_files_handler,
        ),
    ]


def _resolve_path(working_dir: Path, path: str) -> Path:
    """Resolve a path relative to working directory."""
    path_str = path.strip()
    if os.path.isabs(path_str):
        return Path(path_str)
    return (working_dir / path_str).resolve()


def _list_files_recursive(
    directory: Path,
    max_depth: int,
    base_dir: Path,
    current_depth: int = 0,
) -> list[str]:
    """
    List files recursively up to max depth.

    Args:
        directory: Directory to list
        max_depth: Maximum depth to recurse
        base_dir: Base directory for relative paths
        current_depth: Current recursion depth

    Returns:
        List of file/directory paths
    """
    if current_depth >= max_depth:
        return []

    results: list[str] = []

    try:
        entries = sorted(directory.iterdir(), key=lambda p: (not p.is_dir(), p.name))

        for entry in entries:
            # Skip hidden files/directories
            if entry.name.startswith("."):
                continue

            # Get relative path
            try:
                rel_path = entry.relative_to(base_dir)
            except ValueError:
                rel_path = entry

            # Format entry
            if entry.is_dir():
                results.append(f"{rel_path}/")
                # Recurse into directory
                if current_depth + 1 < max_depth:
                    sub_results = _list_files_recursive(entry, max_depth, base_dir, current_depth + 1)
                    results.extend(sub_results)
            else:
                results.append(str(rel_path))

    except PermissionError:
        results.append(f"[Permission denied: {directory}]")

    return results


def _search_files_glob(search_path: Path, pattern: str) -> list[Path]:
    """
    Search for files matching glob pattern.

    Args:
        search_path: Directory to search in
        pattern: Glob pattern

    Returns:
        List of matching file paths
    """
    results: list[Path] = []

    # Handle recursive patterns
    if "**" in pattern:
        # Recursive glob
        glob_pattern = str(search_path / pattern)
        matches = glob_module.glob(glob_pattern, recursive=True)
        results = [Path(m) for m in matches if os.path.isfile(m)]
    else:
        # Non-recursive glob
        glob_pattern = str(search_path / pattern)
        matches = glob_module.glob(glob_pattern)
        results = [Path(m) for m in matches if os.path.isfile(m)]

    return sorted(results)


def _build_write_summary(
    file_path: Path,
    diff_segments: list,
    working_dir: Path,
    file_previously_existed: bool,
) -> str:
    """
    Build summary message for file write operation.

    Args:
        file_path: Path to written file
        diff_segments: Diff segments
        working_dir: Working directory
        file_previously_existed: Whether file existed before write

    Returns:
        Summary message
    """
    # Get relative path for display
    try:
        display_path = file_path.relative_to(working_dir)
    except ValueError:
        display_path = file_path

    # Count changes
    added_lines = sum(1 for seg in diff_segments if seg.type == "added")
    removed_lines = sum(1 for seg in diff_segments if seg.type == "removed")

    # Format diff
    diff_lines = format_diff_lines(diff_segments)
    if diff_lines:
        diff_block = "```diff\n" + "\n".join(diff_lines) + "\n```"
    else:
        diff_block = "(No visual diff - whitespace or formatting changes only)"

    # Build message
    if file_previously_existed:
        action = "Updated"
    else:
        action = "Created"

    return "\n".join(
        [
            f"✓ {action} {display_path}",
            f"Lines changed: +{added_lines} / -{removed_lines}",
            "",
            "Diff preview:",
            diff_block,
        ]
    )
