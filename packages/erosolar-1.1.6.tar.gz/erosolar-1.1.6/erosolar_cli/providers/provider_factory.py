"""
Unified Provider Factory

Creates LLM providers using the unified schema configuration.
Automatically selects providers and models based on task requirements.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import os
from typing import Optional, Protocol, Any, Dict, List, AsyncIterator
from dataclasses import dataclass

from ..core.unified_provider import (
    get_provider,
    get_providers,
    get_defaults,
    create_unified_provider,
    validate_provider_env,
    is_openai_compatible,
    UnifiedProviderConfig,
    UnifiedProviderInstance,
    ProviderCapability,
)


# ============================================================================
# Provider Protocol
# ============================================================================

class LLMProvider(Protocol):
    """Protocol that all LLM providers must implement."""

    @property
    def id(self) -> str:
        """Provider identifier."""
        ...

    @property
    def model(self) -> str:
        """Model identifier."""
        ...

    async def generate(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Generate a response."""
        ...

    async def generate_stream(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        """Generate a streaming response."""
        ...


# ============================================================================
# Provider Options
# ============================================================================

@dataclass
class ProviderOptions:
    """Common options for all providers."""
    api_key: Optional[str] = None
    model: Optional[str] = None
    max_tokens: int = 4096
    temperature: float = 0.0
    base_url: Optional[str] = None
    timeout: int = 120


# ============================================================================
# Provider Factory
# ============================================================================

def create_provider(
    provider: str,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    max_tokens: int = 4096,
    temperature: float = 0.0,
    **kwargs,
) -> LLMProvider:
    """
    Create an LLM provider using the unified schema.

    Args:
        provider: Provider ID from unified schema
        model: Model identifier (uses schema default if not specified)
        api_key: API key (uses environment variable if not specified)
        max_tokens: Maximum tokens for response
        temperature: Sampling temperature
        **kwargs: Additional provider-specific options

    Returns:
        LLMProvider instance

    Raises:
        ValueError: If provider is not supported or API key is missing
    """
    provider_lower = provider.lower()

    # Get provider config from unified schema
    config = get_provider(provider_lower)
    if not config:
        supported = get_supported_providers()
        raise ValueError(
            f'Provider "{provider}" is not supported. '
            f"Supported providers: {', '.join(supported)}"
        )

    # Validate environment
    valid, missing = validate_provider_env(provider_lower)
    if not valid and not api_key:
        raise ValueError(
            f"Missing environment variables for {provider}: {', '.join(missing)}. "
            f"Set these environment variables or pass api_key parameter."
        )

    # Determine model
    selected_model = model or config.default_model

    # Get API key from environment if not provided
    if not api_key and config.env_vars.get("apiKey"):
        api_key = os.environ.get(config.env_vars["apiKey"])

    # Get base URL
    base_url = config.base_url
    if config.env_vars.get("baseUrl"):
        base_url = os.environ.get(config.env_vars["baseUrl"], base_url)

    # Create provider instance based on type
    if provider_lower == "anthropic":
        return _create_anthropic_provider(
            api_key=api_key,
            model=selected_model,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs,
        )
    elif provider_lower == "openai":
        return _create_openai_provider(
            api_key=api_key,
            model=selected_model,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs,
        )
    elif provider_lower == "google":
        return _create_google_provider(
            api_key=api_key,
            model=selected_model,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs,
        )
    elif config.openai_compatible:
        # Use OpenAI-compatible adapter for DeepSeek, xAI, Ollama, etc.
        return _create_openai_compatible_provider(
            provider_id=provider_lower,
            api_key=api_key,
            model=selected_model,
            base_url=base_url,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs,
        )
    else:
        raise ValueError(f"No implementation available for provider: {provider}")


def _create_anthropic_provider(
    api_key: str,
    model: str,
    max_tokens: int,
    temperature: float,
    **kwargs,
) -> LLMProvider:
    """Create Anthropic provider."""
    from .anthropic_provider import AnthropicProvider, AnthropicProviderOptions

    options = AnthropicProviderOptions(
        api_key=api_key,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        **kwargs,
    )
    return AnthropicProvider(options)


def _create_openai_provider(
    api_key: str,
    model: str,
    max_tokens: int,
    temperature: float,
    **kwargs,
) -> LLMProvider:
    """Create OpenAI provider."""
    from .openai_provider import OpenAIProvider, OpenAIProviderOptions

    options = OpenAIProviderOptions(
        api_key=api_key,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return OpenAIProvider(options)


def _create_google_provider(
    api_key: str,
    model: str,
    max_tokens: int,
    temperature: float,
    **kwargs,
) -> LLMProvider:
    """Create Google provider."""
    from .google_provider import GoogleProvider, GoogleProviderOptions

    options = GoogleProviderOptions(
        api_key=api_key,
        model=model,
        max_output_tokens=max_tokens,
        temperature=temperature,
    )
    return GoogleProvider(options)


def _create_openai_compatible_provider(
    provider_id: str,
    api_key: Optional[str],
    model: str,
    base_url: Optional[str],
    max_tokens: int,
    temperature: float,
    **kwargs,
) -> LLMProvider:
    """Create OpenAI-compatible provider (DeepSeek, xAI, Ollama, etc.)."""
    from .openai_compatible import OpenAICompatibleProvider, OpenAICompatibleOptions

    options = OpenAICompatibleOptions(
        provider_id=provider_id,
        api_key=api_key,
        model=model,
        base_url=base_url,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return OpenAICompatibleProvider(options)


# ============================================================================
# Schema-Based Queries
# ============================================================================

def get_default_model(provider: str) -> str:
    """
    Get default model for a provider from unified schema.

    Args:
        provider: Provider ID

    Returns:
        Default model identifier
    """
    config = get_provider(provider.lower())
    if config:
        return config.default_model
    return ""


def get_supported_providers() -> List[str]:
    """
    Get list of supported provider IDs from unified schema.

    Returns:
        List of provider IDs
    """
    return [p.id for p in get_providers()]


def get_configured_providers() -> List[str]:
    """
    Get list of providers with valid configuration.

    Returns:
        List of configured provider IDs
    """
    return [
        p.id for p in get_providers()
        if validate_provider_env(p.id)[0]
    ]


def get_provider_info(provider: str) -> Optional[UnifiedProviderConfig]:
    """
    Get provider configuration from unified schema.

    Args:
        provider: Provider ID

    Returns:
        Provider configuration or None
    """
    return get_provider(provider.lower())


def get_models_for_provider(provider: str) -> List[str]:
    """
    Get available models for a provider.

    Args:
        provider: Provider ID

    Returns:
        List of model identifiers
    """
    config = get_provider(provider.lower())
    if config:
        return config.models
    return []


def provider_supports_capability(provider: str, capability: str) -> bool:
    """
    Check if a provider supports a specific capability.

    Args:
        provider: Provider ID
        capability: Capability name (chat, reasoning, tools, streaming, etc.)

    Returns:
        True if provider supports the capability
    """
    config = get_provider(provider.lower())
    if not config:
        return False

    try:
        cap = ProviderCapability(capability)
        return cap in config.capabilities
    except ValueError:
        return False
