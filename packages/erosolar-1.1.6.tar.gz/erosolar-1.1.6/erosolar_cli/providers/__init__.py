"""
Unified Provider System

All LLM providers are managed through the unified schema.
This module provides the unified interface for all providers.

Supported Providers:
- Anthropic (Claude)
- OpenAI (GPT)
- Google (Gemini)
- DeepSeek (via OpenAI-compatible)
- xAI Grok (via OpenAI-compatible)
- Ollama (via OpenAI-compatible)
- Groq (via OpenAI-compatible)
- Together AI (via OpenAI-compatible)
- Fireworks AI (via OpenAI-compatible)
- Mistral AI (via OpenAI-compatible)

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

# Core provider factory using unified schema
from .provider_factory import (
    create_provider,
    get_default_model,
    get_supported_providers,
    get_configured_providers,
    get_provider_info,
    get_models_for_provider,
    provider_supports_capability,
    LLMProvider,
    ProviderOptions,
)

# OpenAI-compatible provider (handles DeepSeek, xAI, Ollama, Groq, etc.)
from .openai_compatible import (
    OpenAICompatibleProvider,
    OpenAICompatibleOptions,
)

# Native provider implementations
from .anthropic_provider import AnthropicProvider, AnthropicProviderOptions
from .openai_provider import OpenAIProvider, OpenAIProviderOptions
from .google_provider import GoogleProvider, GoogleProviderOptions

__all__ = [
    # Unified factory
    "create_provider",
    "get_default_model",
    "get_supported_providers",
    "get_configured_providers",
    "get_provider_info",
    "get_models_for_provider",
    "provider_supports_capability",
    "LLMProvider",
    "ProviderOptions",

    # Unified OpenAI-compatible provider
    "OpenAICompatibleProvider",
    "OpenAICompatibleOptions",

    # Native providers
    "AnthropicProvider",
    "AnthropicProviderOptions",
    "OpenAIProvider",
    "OpenAIProviderOptions",
    "GoogleProvider",
    "GoogleProviderOptions",
]
