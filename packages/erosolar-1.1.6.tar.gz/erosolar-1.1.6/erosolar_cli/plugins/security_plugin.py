"""
Security Plugin - Authorized Security Research Tools

Provides security research capabilities for authorized engagements:
- Vulnerability scanning
- Attack surface analysis
- Security posture assessment
- Compliance checking

This plugin is OPTIONAL and REQUIRES AUTHORIZATION.
Only enable for legitimate security research, penetration testing,
or bug bounty programs with proper authorization.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core.tool_runtime import ToolDefinition, ToolSuite
from ..core.types import JSONSchemaObject
from . import Plugin, PluginCategory, PluginMetadata, register_plugin


@dataclass
class SecurityConfig:
    """Configuration for security plugin."""
    authorization_type: str = "none"  # none, bug_bounty, pentest, red_team
    authorized_by: str = ""
    target_scope: List[str] = None
    verbose: bool = False

    def __post_init__(self):
        if self.target_scope is None:
            self.target_scope = []


@register_plugin
class SecurityPlugin(Plugin):
    """Security Research Tools (requires authorization)."""

    metadata = PluginMetadata(
        id="security",
        name="Security Research",
        version="1.0.0",
        description="Authorized security research and vulnerability assessment tools",
        category=PluginCategory.SECURITY,
        author="Erosolar Team",
        requires_auth=True,  # Important: requires authorization
        dependencies=["alpha_zero"],
        cli_commands=["security recon", "security scan", "security report"],
    )

    def __init__(self, working_dir: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(working_dir, config)
        raw_config = config or {}
        self.sec_config = SecurityConfig(
            authorization_type=raw_config.get("authorization_type", "none"),
            authorized_by=raw_config.get("authorized_by", ""),
            target_scope=raw_config.get("target_scope", []),
            verbose=raw_config.get("verbose", False),
        )

    def on_load(self) -> None:
        """Verify authorization before loading."""
        if self.sec_config.authorization_type == "none":
            # Plugin loaded but tools will check authorization
            pass

    def _check_authorization(self, target: str) -> bool:
        """Check if operation is authorized."""
        if self.sec_config.authorization_type == "none":
            return False

        if not self.sec_config.authorized_by:
            return False

        # Check target scope
        if self.sec_config.target_scope:
            return any(
                target.endswith(scope) or target == scope
                for scope in self.sec_config.target_scope
            )

        return True

    def get_tool_suites(self) -> List[ToolSuite]:
        """Return security tool suites."""
        return [
            self._create_scanning_suite(),
            self._create_analysis_suite(),
        ]

    def _create_scanning_suite(self) -> ToolSuite:
        """Create security scanning tools."""
        tools = []

        async def dependency_audit(
            file_path: str = "requirements.txt",
        ) -> Dict[str, Any]:
            """Audit dependencies for known vulnerabilities."""
            full_path = Path(self.working_dir) / file_path

            if not full_path.exists():
                # Try pyproject.toml
                pyproject = Path(self.working_dir) / "pyproject.toml"
                if pyproject.exists():
                    file_path = "pyproject.toml"
                    full_path = pyproject
                else:
                    return {"error": f"Dependency file not found: {file_path}"}

            content = full_path.read_text()
            dependencies = []
            vulnerabilities = []

            if file_path.endswith('.txt'):
                # Parse requirements.txt
                for line in content.split('\n'):
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # Parse package==version or package>=version
                        parts = line.replace('>=', '==').replace('<=', '==').split('==')
                        pkg = parts[0].strip()
                        version = parts[1].strip() if len(parts) > 1 else "any"
                        dependencies.append({"package": pkg, "version": version})

            # Simulated vulnerability check (in real implementation, use PyPI advisory DB)
            known_vulnerable = {
                "requests": ["2.25.0", "2.25.1"],  # Example
                "urllib3": ["1.26.0", "1.26.1", "1.26.2"],
                "pyyaml": ["5.3", "5.3.1"],
            }

            for dep in dependencies:
                pkg = dep["package"].lower()
                ver = dep["version"]
                if pkg in known_vulnerable and ver in known_vulnerable[pkg]:
                    vulnerabilities.append({
                        "package": pkg,
                        "version": ver,
                        "severity": "medium",
                        "recommendation": f"Upgrade {pkg} to latest version",
                    })

            return {
                "file": file_path,
                "total_dependencies": len(dependencies),
                "vulnerabilities_found": len(vulnerabilities),
                "vulnerabilities": vulnerabilities,
                "status": "clean" if not vulnerabilities else "vulnerable",
            }

        tools.append(ToolDefinition(
            name="dependency_audit",
            description="Audit project dependencies for known vulnerabilities",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "file_path": {
                        "type": "string",
                        "default": "requirements.txt",
                        "description": "Path to dependency file",
                    }
                },
            ),
            handler=dependency_audit,
        ))

        async def code_security_scan(
            file_path: str,
        ) -> Dict[str, Any]:
            """Scan code for security issues."""
            import ast
            import re

            full_path = Path(self.working_dir) / file_path
            if not full_path.exists():
                return {"error": f"File not found: {file_path}"}

            code = full_path.read_text()
            issues = []

            # Pattern-based checks
            patterns = [
                (r'eval\s*\(', "EVAL_USAGE", "high", "Use of eval() can lead to code injection"),
                (r'exec\s*\(', "EXEC_USAGE", "high", "Use of exec() can lead to code injection"),
                (r'subprocess\..*shell\s*=\s*True', "SHELL_INJECTION", "high", "Shell=True can lead to command injection"),
                (r'password\s*=\s*["\'][^"\']+["\']', "HARDCODED_SECRET", "critical", "Hardcoded password detected"),
                (r'api[_-]?key\s*=\s*["\'][^"\']+["\']', "HARDCODED_SECRET", "critical", "Hardcoded API key detected"),
                (r'pickle\.loads?\s*\(', "INSECURE_DESERIALIZATION", "high", "Pickle can execute arbitrary code"),
                (r'yaml\.load\s*\([^)]*\)', "INSECURE_YAML", "medium", "Use yaml.safe_load() instead"),
                (r'\.format\s*\(.*request', "FORMAT_STRING", "medium", "Potential format string vulnerability"),
                (r'SELECT.*\%s', "SQL_INJECTION", "high", "Potential SQL injection with string formatting"),
                (r'innerHTML\s*=', "XSS_RISK", "medium", "innerHTML can lead to XSS"),
            ]

            for pattern, issue_type, severity, message in patterns:
                for match in re.finditer(pattern, code, re.IGNORECASE):
                    line_num = code[:match.start()].count('\n') + 1
                    issues.append({
                        "type": issue_type,
                        "severity": severity,
                        "line": line_num,
                        "message": message,
                        "snippet": code[match.start():match.end()][:50],
                    })

            # AST-based checks
            try:
                tree = ast.parse(code)
                for node in ast.walk(tree):
                    # Check for assert statements (removed in -O mode)
                    if isinstance(node, ast.Assert):
                        issues.append({
                            "type": "ASSERT_SECURITY",
                            "severity": "low",
                            "line": node.lineno,
                            "message": "Assert statements are removed with -O flag",
                        })
            except SyntaxError:
                pass

            # Sort by severity
            severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
            issues.sort(key=lambda x: severity_order.get(x["severity"], 4))

            return {
                "file": file_path,
                "issues_found": len(issues),
                "critical": len([i for i in issues if i["severity"] == "critical"]),
                "high": len([i for i in issues if i["severity"] == "high"]),
                "medium": len([i for i in issues if i["severity"] == "medium"]),
                "low": len([i for i in issues if i["severity"] == "low"]),
                "issues": issues[:30],  # Limit output
            }

        tools.append(ToolDefinition(
            name="code_security_scan",
            description="Scan code for security vulnerabilities and issues",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to scan",
                    }
                },
                required=["file_path"],
            ),
            handler=code_security_scan,
        ))

        return ToolSuite(
            id="plugin.security.scanning",
            name="Security Scanning",
            description="Scan code and dependencies for security issues",
            tools=tools,
        )

    def _create_analysis_suite(self) -> ToolSuite:
        """Create security analysis tools."""
        tools = []

        async def analyze_attack_surface(
            directory: str = ".",
        ) -> Dict[str, Any]:
            """Analyze the attack surface of a project."""
            root = Path(self.working_dir) / directory

            if not root.exists():
                return {"error": f"Directory not found: {directory}"}

            attack_surface = {
                "entry_points": [],
                "external_dependencies": [],
                "sensitive_files": [],
                "exposed_endpoints": [],
            }

            # Find entry points
            for pattern in ["main.py", "__main__.py", "app.py", "server.py", "wsgi.py", "asgi.py"]:
                for match in root.rglob(pattern):
                    attack_surface["entry_points"].append(str(match.relative_to(root)))

            # Find dependency files
            for pattern in ["requirements*.txt", "pyproject.toml", "setup.py", "Pipfile"]:
                for match in root.rglob(pattern):
                    attack_surface["external_dependencies"].append(str(match.relative_to(root)))

            # Find potentially sensitive files
            sensitive_patterns = [".env*", "*.pem", "*.key", "config*.json", "secrets*"]
            for pattern in sensitive_patterns:
                for match in root.rglob(pattern):
                    attack_surface["sensitive_files"].append(str(match.relative_to(root)))

            # Find potential API endpoints (Flask/FastAPI patterns)
            endpoint_patterns = [
                (r'@app\.(?:route|get|post|put|delete)\s*\([\'"]([^\'"]+)', "route"),
                (r'@router\.(?:get|post|put|delete)\s*\([\'"]([^\'"]+)', "router"),
            ]

            import re
            for py_file in root.rglob("*.py"):
                try:
                    content = py_file.read_text()
                    for pattern, source in endpoint_patterns:
                        for match in re.finditer(pattern, content):
                            attack_surface["exposed_endpoints"].append({
                                "file": str(py_file.relative_to(root)),
                                "endpoint": match.group(1),
                            })
                except Exception:
                    pass

            return {
                "directory": directory,
                "entry_points": len(attack_surface["entry_points"]),
                "external_dependencies": len(attack_surface["external_dependencies"]),
                "sensitive_files": len(attack_surface["sensitive_files"]),
                "exposed_endpoints": len(attack_surface["exposed_endpoints"]),
                "details": attack_surface,
            }

        tools.append(ToolDefinition(
            name="analyze_attack_surface",
            description="Analyze the attack surface of a project",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "directory": {
                        "type": "string",
                        "default": ".",
                        "description": "Directory to analyze",
                    }
                },
            ),
            handler=analyze_attack_surface,
        ))

        return ToolSuite(
            id="plugin.security.analysis",
            name="Security Analysis",
            description="Analyze project security posture and attack surface",
            tools=tools,
        )
