"""
Unified Plugin System

Plugin architecture integrated with the unified schema-driven tool runtime.
All plugins register tools through the unified system.

Principal Investigator: Bo Shang
Framework: erosolar-cli

Core Philosophy:
- UNIFIED: All tools flow through unified_tool_runtime
- CORE: Essential coding tools (always available via unified schema)
- PLUGINS: Optional features that extend the unified runtime

Plugin Types:
- CODING: Enhanced coding capabilities (code analysis, refactoring)
- RL: Reinforcement learning (Alpha Zero 2)
- SECURITY: Security research tools
- DEV: Developer productivity tools
"""

from __future__ import annotations

import importlib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Type

# Import unified runtime components
from ..core.unified_tool_runtime import (
    UnifiedToolRuntime,
    UnifiedToolRuntimeConfig,
    UnifiedToolDefinition,
    UnifiedToolSuite,
    ToolExecutionContext,
    create_full_tool_runtime,
)

# Import version management
from ..core.version_manager import (
    SemanticVersion,
    VersionManager,
    PluginVersion,
    PluginDependency,
    VersionConstraint,
    SelfUpgradeManager,
    get_cli_version,
)
from ..core.unified.version import VersionManagerConfig

# Legacy import for backward compatibility
try:
    from ..core.tool_runtime import ToolSuite, ToolDefinition
except ImportError:
    # Define minimal compatibility types
    @dataclass
    class ToolDefinition:
        name: str
        description: str
        parameters: Any
        handler: Callable

    @dataclass
    class ToolSuite:
        id: str
        description: str
        tools: List[ToolDefinition]
        name: Optional[str] = None


class PluginCategory(Enum):
    """Categories of plugins."""
    CODING = "coding"           # Code analysis, generation, refactoring
    RL = "rl"                   # Reinforcement learning, self-improvement
    SECURITY = "security"       # Security research (requires auth)
    DEV = "dev"                 # Developer productivity
    INTEGRATION = "integration" # External service integrations


@dataclass
class PluginMetadata:
    """Metadata for a plugin with semantic versioning support."""
    id: str
    name: str
    version: str
    description: str
    category: PluginCategory
    author: str = "Erosolar Team"
    requires_auth: bool = False
    dependencies: List[str] = field(default_factory=list)
    cli_commands: List[str] = field(default_factory=list)
    min_cli_version: Optional[str] = None
    max_cli_version: Optional[str] = None
    changelog: str = ""

    @property
    def semantic_version(self) -> SemanticVersion:
        """Parse version as SemanticVersion."""
        return SemanticVersion.parse(self.version)

    def to_plugin_version(self) -> PluginVersion:
        """Convert to PluginVersion for version management."""
        dependencies = []
        for dep_str in self.dependencies:
            try:
                dep = PluginDependency.parse(dep_str)
                dependencies.append(dep)
            except ValueError:
                pass

        return PluginVersion(
            plugin_id=self.id,
            version=self.semantic_version,
            dependencies=dependencies,
            min_cli_version=(
                SemanticVersion.parse(self.min_cli_version)
                if self.min_cli_version else None
            ),
            max_cli_version=(
                SemanticVersion.parse(self.max_cli_version)
                if self.max_cli_version else None
            ),
            changelog=self.changelog,
        )

    def is_compatible_with_cli(self) -> Tuple[bool, List[str]]:
        """Check if plugin is compatible with current CLI version."""
        cli_version = get_cli_version()
        issues = []

        if self.min_cli_version:
            min_ver = SemanticVersion.parse(self.min_cli_version)
            if cli_version < min_ver:
                issues.append(
                    f"Requires CLI >= {self.min_cli_version}, "
                    f"but {cli_version} is installed"
                )

        if self.max_cli_version:
            max_ver = SemanticVersion.parse(self.max_cli_version)
            if cli_version > max_ver:
                issues.append(
                    f"Requires CLI <= {self.max_cli_version}, "
                    f"but {cli_version} is installed"
                )

        return len(issues) == 0, issues


class Plugin(ABC):
    """Base class for all plugins."""

    metadata: PluginMetadata

    def __init__(self, working_dir: str, config: Optional[Dict[str, Any]] = None):
        self.working_dir = working_dir
        self.config = config or {}
        self._enabled = True

    @abstractmethod
    def get_tool_suites(self) -> List[ToolSuite]:
        """Return tool suites provided by this plugin (legacy interface)."""
        pass

    def get_unified_tools(self) -> List[UnifiedToolDefinition]:
        """Return tools as unified tool definitions."""
        tools = []
        for suite in self.get_tool_suites():
            for tool in suite.tools:
                unified_tool = UnifiedToolDefinition(
                    id=f"{self.metadata.id}.{tool.name}",
                    name=tool.name,
                    description=tool.description,
                    category=f"plugin.{self.metadata.id}",
                    cacheable=False,
                    requires_auth=self.metadata.requires_auth,
                    parameters=_convert_parameters(tool.parameters),
                    handler=_wrap_async_handler(tool.handler),
                )
                tools.append(unified_tool)
        return tools

    def register_with_runtime(self, runtime: UnifiedToolRuntime) -> None:
        """Register plugin tools with a unified runtime."""
        for tool in self.get_unified_tools():
            runtime.register_tool(tool)

    def on_load(self) -> None:
        """Called when plugin is loaded. Override for initialization."""
        pass

    def on_unload(self) -> None:
        """Called when plugin is unloaded. Override for cleanup."""
        pass

    @property
    def enabled(self) -> bool:
        return self._enabled

    def enable(self) -> None:
        self._enabled = True

    def disable(self) -> None:
        self._enabled = False


def _convert_parameters(params: Any) -> Dict[str, Any]:
    """Convert tool parameters to dict format."""
    if hasattr(params, '__dict__'):
        result = {
            "type": getattr(params, "type", "object"),
        }
        if hasattr(params, "properties"):
            props = params.properties
            result["properties"] = {
                k: _convert_parameters(v) if hasattr(v, '__dict__') else v
                for k, v in (props.items() if isinstance(props, dict) else {})
            }
        if hasattr(params, "required"):
            result["required"] = list(params.required) if params.required else []
        return result
    return params if isinstance(params, dict) else {}


def _wrap_async_handler(handler: Callable) -> Callable:
    """Wrap async handler for synchronous execution."""
    import asyncio
    import inspect

    def sync_handler(args: Dict[str, Any], context: ToolExecutionContext) -> str:
        try:
            # Determine if handler is async
            if inspect.iscoroutinefunction(handler):
                try:
                    loop = asyncio.get_running_loop()
                    # Already in async context - use thread
                    import concurrent.futures
                    with concurrent.futures.ThreadPoolExecutor() as executor:
                        future = executor.submit(asyncio.run, handler(**args))
                        result = future.result()
                except RuntimeError:
                    # No running loop
                    result = asyncio.run(handler(**args))
            else:
                result = handler(args)

            return str(result) if result else ""
        except Exception as e:
            return f"Error: {str(e)}"

    return sync_handler


class PluginRegistry:
    """Registry for managing plugins with unified runtime integration and versioning."""

    _instance: Optional['PluginRegistry'] = None

    def __new__(cls) -> 'PluginRegistry':
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._plugins = {}
            cls._instance._loaded = {}
            cls._instance._version_manager = VersionManager(VersionManagerConfig(current_version="1.1.3"))
        return cls._instance

    @property
    def version_manager(self) -> VersionManager:
        """Get the version manager instance."""
        return self._version_manager

    def register(self, plugin_class: Type[Plugin]) -> None:
        """Register a plugin class."""
        metadata = plugin_class.metadata
        self._plugins[metadata.id] = plugin_class

    def unregister(self, plugin_id: str) -> None:
        """Unregister a plugin."""
        if plugin_id in self._loaded:
            self._loaded[plugin_id].on_unload()
            del self._loaded[plugin_id]
        if plugin_id in self._plugins:
            del self._plugins[plugin_id]

    def load(
        self,
        plugin_id: str,
        working_dir: str,
        config: Optional[Dict[str, Any]] = None,
        check_compatibility: bool = True,
    ) -> Optional[Plugin]:
        """
        Load and instantiate a plugin.

        Args:
            plugin_id: Plugin identifier
            working_dir: Working directory for plugin
            config: Optional plugin configuration
            check_compatibility: Whether to check CLI compatibility

        Returns:
            Loaded plugin instance or None if not found/incompatible
        """
        if plugin_id in self._loaded:
            return self._loaded[plugin_id]

        if plugin_id not in self._plugins:
            return None

        plugin_class = self._plugins[plugin_id]
        metadata = plugin_class.metadata

        # Check compatibility with CLI version
        if check_compatibility:
            compatible, issues = metadata.is_compatible_with_cli()
            if not compatible:
                print(f"Warning: Plugin {plugin_id} compatibility issues:")
                for issue in issues:
                    print(f"  - {issue}")
                return None

        # Check dependencies
        for dep_str in metadata.dependencies:
            try:
                dep = PluginDependency.parse(dep_str)
                if dep.plugin_id not in self._loaded and dep.plugin_id not in self._plugins:
                    if not dep.optional:
                        print(f"Warning: Plugin {plugin_id} requires {dep.plugin_id}")
                        return None
            except ValueError:
                pass

        plugin = plugin_class(working_dir, config)
        plugin.on_load()
        self._loaded[plugin_id] = plugin

        # Track installed version
        self._version_manager.set_installed_version(metadata.to_plugin_version())

        return plugin

    def unload(self, plugin_id: str) -> bool:
        """Unload a plugin instance."""
        if plugin_id not in self._loaded:
            return False

        self._loaded[plugin_id].on_unload()
        del self._loaded[plugin_id]
        return True

    def get_loaded(self, plugin_id: str) -> Optional[Plugin]:
        """Get a loaded plugin instance."""
        return self._loaded.get(plugin_id)

    def list_available(self) -> List[PluginMetadata]:
        """List all registered plugins."""
        return [cls.metadata for cls in self._plugins.values()]

    def list_loaded(self) -> List[str]:
        """List IDs of loaded plugins."""
        return list(self._loaded.keys())

    def get_plugin_version(self, plugin_id: str) -> Optional[str]:
        """Get the version of an installed plugin."""
        if plugin_id in self._plugins:
            return self._plugins[plugin_id].metadata.version
        return None

    def check_plugin_updates(self) -> Dict[str, Tuple[str, str]]:
        """
        Check for available plugin updates.

        Returns:
            Dictionary of plugin_id -> (current_version, available_version)
        """
        # This would typically query a remote registry
        # For now, return empty dict
        return {}

    def get_cli_version(self) -> str:
        """Get the current CLI version."""
        return str(get_cli_version())

    def list_by_category(self, category: PluginCategory) -> List[PluginMetadata]:
        """List plugins in a specific category."""
        return [
            cls.metadata for cls in self._plugins.values()
            if cls.metadata.category == category
        ]

    def get_all_tool_suites(self, working_dir: str) -> List[ToolSuite]:
        """Get tool suites from all loaded and enabled plugins (legacy)."""
        suites = []
        for plugin in self._loaded.values():
            if plugin.enabled:
                suites.extend(plugin.get_tool_suites())
        return suites

    def register_all_with_runtime(
        self,
        runtime: UnifiedToolRuntime,
        plugin_ids: Optional[List[str]] = None,
    ) -> None:
        """Register tools from all loaded plugins with unified runtime."""
        plugins_to_register = plugin_ids or list(self._loaded.keys())
        for plugin_id in plugins_to_register:
            plugin = self._loaded.get(plugin_id)
            if plugin and plugin.enabled:
                plugin.register_with_runtime(runtime)


# Global registry instance
registry = PluginRegistry()


def register_plugin(plugin_class: Type[Plugin]) -> Type[Plugin]:
    """Decorator to register a plugin class."""
    registry.register(plugin_class)
    return plugin_class


def load_builtin_plugins() -> None:
    """Load all built-in plugins (but don't instantiate them)."""
    # Import plugin modules to trigger registration
    try:
        from . import alpha_zero_plugin
    except ImportError:
        pass

    try:
        from . import security_plugin
    except ImportError:
        pass

    try:
        from . import coding_plugin
    except ImportError:
        pass


# ============================================================================
# Unified Runtime Integration
# ============================================================================

def create_runtime_with_plugins(
    working_dir: str,
    enabled_plugins: Optional[List[str]] = None,
    plugin_config: Optional[Dict[str, Dict[str, Any]]] = None,
    enable_caching: bool = True,
) -> UnifiedToolRuntime:
    """
    Create a unified tool runtime with plugins registered.

    Args:
        working_dir: Working directory for tools
        enabled_plugins: List of plugin IDs to enable
        plugin_config: Configuration for each plugin
        enable_caching: Enable tool result caching

    Returns:
        UnifiedToolRuntime with core tools and plugin tools registered
    """
    runtime = create_full_tool_runtime(
        working_dir=working_dir,
        enable_caching=enable_caching,
    )

    if enabled_plugins:
        load_builtin_plugins()
        config = plugin_config or {}

        for plugin_id in enabled_plugins:
            plugin = registry.load(plugin_id, working_dir, config.get(plugin_id))
            if plugin:
                plugin.register_with_runtime(runtime)

    return runtime


# ============================================================================
# Legacy Compatibility
# ============================================================================

def get_core_tool_suites(working_dir: str) -> List[ToolSuite]:
    """
    Get core tool suites (legacy compatibility).

    For new code, use create_runtime_with_plugins() instead.
    """
    from ..tools import bash_tools, edit_tools, file_tools, glob_tools, grep_tools

    root = str(Path(working_dir).resolve())

    return [
        ToolSuite(
            id="core.filesystem",
            name="Filesystem",
            description="Read, write, list, and search files",
            tools=file_tools.create_file_tools(root),
        ),
        ToolSuite(
            id="core.edit",
            name="Editing",
            description="Surgical string replacement in files",
            tools=edit_tools.create_edit_tools(root),
        ),
        ToolSuite(
            id="core.bash",
            name="Bash",
            description="Safe shell command execution",
            tools=bash_tools.create_bash_tools(root),
        ),
        ToolSuite(
            id="core.glob",
            name="Glob",
            description="Fast pattern-based file matching",
            tools=glob_tools.create_glob_tools(root),
        ),
        ToolSuite(
            id="core.grep",
            name="Grep",
            description="Powerful regex content search",
            tools=grep_tools.create_grep_tools(root),
        ),
    ]


def get_enabled_tool_suites(
    working_dir: str,
    enabled_plugins: Optional[List[str]] = None,
    plugin_config: Optional[Dict[str, Dict[str, Any]]] = None,
) -> List[ToolSuite]:
    """
    Get tool suites from core + enabled plugins (legacy).

    For new code, use create_runtime_with_plugins() instead.
    """
    suites = get_core_tool_suites(working_dir)

    if enabled_plugins:
        load_builtin_plugins()
        config = plugin_config or {}

        for plugin_id in enabled_plugins:
            plugin = registry.load(plugin_id, working_dir, config.get(plugin_id))
            if plugin:
                suites.extend(plugin.get_tool_suites())

    return suites


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Core types
    "Plugin",
    "PluginMetadata",
    "PluginCategory",
    "PluginRegistry",

    # Registry
    "registry",
    "register_plugin",
    "load_builtin_plugins",

    # Unified runtime integration
    "create_runtime_with_plugins",

    # Version management
    "SemanticVersion",
    "VersionManager",
    "PluginVersion",
    "PluginDependency",
    "SelfUpgradeManager",
    "get_cli_version",

    # Legacy compatibility
    "get_core_tool_suites",
    "get_enabled_tool_suites",
]
