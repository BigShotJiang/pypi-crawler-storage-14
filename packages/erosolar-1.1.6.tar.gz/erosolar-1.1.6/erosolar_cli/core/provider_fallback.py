"""
Provider Fallback System

Automatically switches to alternative providers when one fails.
Maintains provider health scores and intelligent selection.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ProviderHealth(Enum):
    """Health status of a provider."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"


@dataclass
class ProviderMetrics:
    """Track provider performance and reliability."""

    provider_name: str
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    avg_response_time_ms: float = 0.0
    last_failure_time: Optional[float] = None
    consecutive_failures: int = 0
    health_status: ProviderHealth = ProviderHealth.HEALTHY
    response_times: list[float] = field(default_factory=list)

    def success_rate(self) -> float:
        """Calculate success rate."""
        if self.total_requests == 0:
            return 1.0
        return self.successful_requests / self.total_requests

    def update_success(self, response_time_ms: float) -> None:
        """Record successful request."""
        self.total_requests += 1
        self.successful_requests += 1
        self.consecutive_failures = 0
        self.response_times.append(response_time_ms)

        # Keep only last 100 response times
        if len(self.response_times) > 100:
            self.response_times = self.response_times[-100:]

        # Update average
        self.avg_response_time_ms = sum(self.response_times) / len(self.response_times)

        # Update health status
        if self.success_rate() >= 0.95:
            self.health_status = ProviderHealth.HEALTHY
        elif self.success_rate() >= 0.7:
            self.health_status = ProviderHealth.DEGRADED

    def update_failure(self) -> None:
        """Record failed request."""
        self.total_requests += 1
        self.failed_requests += 1
        self.consecutive_failures += 1
        self.last_failure_time = time.time()

        # Update health status
        if self.consecutive_failures >= 3:
            self.health_status = ProviderHealth.UNAVAILABLE
        elif self.success_rate() < 0.7:
            self.health_status = ProviderHealth.DEGRADED

    def is_available(self) -> bool:
        """Check if provider is available for use."""
        if self.health_status == ProviderHealth.UNAVAILABLE:
            # Check if cooldown period has passed (5 minutes)
            if self.last_failure_time:
                cooldown_seconds = 300  # 5 minutes
                if time.time() - self.last_failure_time > cooldown_seconds:
                    self.health_status = ProviderHealth.DEGRADED
                    self.consecutive_failures = 0
                    return True
            return False
        return True


@dataclass
class ProviderConfig:
    """Configuration for a provider."""

    name: str
    priority: int  # Lower number = higher priority
    capabilities: set[str] = field(default_factory=set)
    supported_models: list[str] = field(default_factory=list)
    enabled: bool = True


class ProviderFallbackManager:
    """Manages automatic fallback between providers."""

    def __init__(self):
        """Initialize provider fallback manager."""
        self.metrics: dict[str, ProviderMetrics] = {}
        self.configs: dict[str, ProviderConfig] = {}
        self._initialize_default_configs()

    def _initialize_default_configs(self) -> None:
        """Initialize default provider configurations."""
        default_configs = [
            ProviderConfig(
                name="anthropic",
                priority=1,
                capabilities={"streaming", "tool_calling", "vision"},
                supported_models=["claude-3-opus", "claude-3-sonnet", "claude-3-haiku"],
            ),
            ProviderConfig(
                name="openai",
                priority=2,
                capabilities={"streaming", "tool_calling", "vision"},
                supported_models=["gpt-4", "gpt-3.5-turbo", "gpt-4-vision"],
            ),
            ProviderConfig(
                name="google",
                priority=3,
                capabilities={"streaming", "tool_calling", "vision"},
                supported_models=["gemini-pro", "gemini-pro-vision"],
            ),
            ProviderConfig(
                name="deepseek",
                priority=4,
                capabilities={"streaming", "tool_calling"},
                supported_models=["deepseek-chat", "deepseek-coder"],
            ),
        ]

        for config in default_configs:
            self.configs[config.name] = config
            self.metrics[config.name] = ProviderMetrics(provider_name=config.name)

    def register_provider(self, config: ProviderConfig) -> None:
        """Register a new provider."""
        self.configs[config.name] = config
        if config.name not in self.metrics:
            self.metrics[config.name] = ProviderMetrics(provider_name=config.name)

    def record_success(self, provider_name: str, response_time_ms: float) -> None:
        """Record successful provider request."""
        if provider_name in self.metrics:
            self.metrics[provider_name].update_success(response_time_ms)

    def record_failure(self, provider_name: str) -> None:
        """Record failed provider request."""
        if provider_name in self.metrics:
            self.metrics[provider_name].update_failure()

    def get_best_provider(
        self,
        required_capabilities: Optional[set[str]] = None,
        exclude_providers: Optional[set[str]] = None,
    ) -> Optional[str]:
        """
        Get the best available provider based on health and priority.

        Args:
            required_capabilities: Set of required capabilities
            exclude_providers: Set of provider names to exclude

        Returns:
            Provider name or None if no suitable provider found
        """
        exclude_providers = exclude_providers or set()
        required_capabilities = required_capabilities or set()

        # Filter providers
        candidates = []
        for name, config in self.configs.items():
            if not config.enabled:
                continue
            if name in exclude_providers:
                continue
            if required_capabilities and not required_capabilities.issubset(config.capabilities):
                continue

            metrics = self.metrics.get(name)
            if metrics and not metrics.is_available():
                continue

            candidates.append((name, config, metrics))

        if not candidates:
            return None

        # Sort by: health status, then priority, then success rate
        def sort_key(item):
            name, config, metrics = item
            if not metrics:
                return (2, config.priority, 0.0)  # Unknown health

            health_score = {
                ProviderHealth.HEALTHY: 0,
                ProviderHealth.DEGRADED: 1,
                ProviderHealth.UNAVAILABLE: 2,
            }[metrics.health_status]

            return (health_score, config.priority, -metrics.success_rate())

        candidates.sort(key=sort_key)
        return candidates[0][0]

    def get_fallback_providers(
        self,
        current_provider: str,
        required_capabilities: Optional[set[str]] = None,
        max_count: int = 3,
    ) -> list[str]:
        """
        Get list of fallback providers.

        Args:
            current_provider: Current failing provider
            required_capabilities: Set of required capabilities
            max_count: Maximum number of fallbacks to return

        Returns:
            List of provider names
        """
        fallbacks = []
        exclude = {current_provider}

        for _ in range(max_count):
            provider = self.get_best_provider(
                required_capabilities=required_capabilities, exclude_providers=exclude
            )
            if provider:
                fallbacks.append(provider)
                exclude.add(provider)
            else:
                break

        return fallbacks

    def get_provider_status(self) -> dict[str, Any]:
        """Get status of all providers."""
        status = {}
        for name, metrics in self.metrics.items():
            config = self.configs.get(name)
            status[name] = {
                "enabled": config.enabled if config else False,
                "health": metrics.health_status.value,
                "success_rate": metrics.success_rate(),
                "avg_response_time_ms": metrics.avg_response_time_ms,
                "total_requests": metrics.total_requests,
                "consecutive_failures": metrics.consecutive_failures,
                "is_available": metrics.is_available(),
            }
        return status

    def reset_provider(self, provider_name: str) -> None:
        """Reset provider metrics (useful for retrying after cooldown)."""
        if provider_name in self.metrics:
            self.metrics[provider_name] = ProviderMetrics(provider_name=provider_name)


# Global fallback manager instance
_global_fallback_manager: Optional[ProviderFallbackManager] = None


def get_fallback_manager() -> ProviderFallbackManager:
    """Get global provider fallback manager."""
    global _global_fallback_manager
    if _global_fallback_manager is None:
        _global_fallback_manager = ProviderFallbackManager()
    return _global_fallback_manager


def set_fallback_manager(manager: ProviderFallbackManager) -> None:
    """Set global provider fallback manager."""
    global _global_fallback_manager
    _global_fallback_manager = manager
