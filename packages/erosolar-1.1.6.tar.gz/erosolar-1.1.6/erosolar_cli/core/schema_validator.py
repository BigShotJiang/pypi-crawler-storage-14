"""
Schema validation for tool arguments.
Validates tool call arguments against JSON schema definitions.
"""

from __future__ import annotations

from typing import Any

from .types import JSONSchemaArray, JSONSchemaObject, JSONSchemaProperty


class ToolArgumentValidationError(Exception):
    """Exception raised when tool arguments fail validation."""

    def __init__(self, tool_name: str, issues: list[str]):
        message = format_message(tool_name, issues)
        super().__init__(message)
        self.tool_name = tool_name
        self.issues = issues


def validate_tool_arguments(
    tool_name: str,
    schema: JSONSchemaObject | None,
    args: dict[str, Any],
) -> None:
    """
    Validate tool arguments against JSON schema.

    Args:
        tool_name: Name of the tool being validated
        schema: JSON schema definition for the tool
        args: Arguments to validate

    Raises:
        ToolArgumentValidationError: If validation fails
    """
    if not schema or schema.type != "object":
        return

    errors: list[str] = []
    properties = schema.properties or {}
    required = schema.required or []

    # Check required properties
    for property_name in required:
        if not has_argument(args, property_name):
            errors.append(f'Missing required property "{property_name}".')

    # Validate each provided argument
    for key, value in args.items():
        definition = properties.get(key)
        if not definition:
            if schema.additional_properties is False:
                errors.append(f'Property "{key}" is not allowed.')
            continue
        validate_schema_property(definition, value, key, errors)

    if errors:
        raise ToolArgumentValidationError(tool_name, errors)


def validate_schema_property(
    definition: JSONSchemaProperty,
    value: Any,
    path: str,
    errors: list[str],
) -> None:
    """
    Validate a single property against its schema definition.

    Args:
        definition: Schema definition for the property
        value: Value to validate
        path: Property path (for error messages)
        errors: List to accumulate errors
    """
    if definition.type == "string":
        if not isinstance(value, str):
            errors.append(f'Argument "{path}" must be a string.')
            return
        if hasattr(definition, "enum") and definition.enum and value not in definition.enum:
            enum_values = ", ".join(f'"{v}"' for v in definition.enum)
            errors.append(f'Argument "{path}" must be one of: {enum_values}.')
        if hasattr(definition, "min_length") and definition.min_length is not None:
            if len(value) < definition.min_length:
                plural = "" if definition.min_length == 1 else "s"
                errors.append(f'Argument "{path}" must be at least {definition.min_length} character{plural} long.')

    elif definition.type == "number":
        if not isinstance(value, (int, float)) or (isinstance(value, float) and value != value):  # Check for NaN
            errors.append(f'Argument "{path}" must be a number.')

    elif definition.type == "boolean":
        if not isinstance(value, bool):
            errors.append(f'Argument "{path}" must be a boolean.')

    elif definition.type == "array":
        if not isinstance(value, list):
            errors.append(f'Argument "{path}" must be an array.')
            return
        validate_array_items(definition, value, path, errors)


def validate_array_items(
    definition: JSONSchemaArray,
    value: list[Any],
    path: str,
    errors: list[str],
) -> None:
    """
    Validate array items against their schema.

    Args:
        definition: Array schema definition
        value: List of values to validate
        path: Property path (for error messages)
        errors: List to accumulate errors
    """
    if not definition.items:
        return

    for index, entry in enumerate(value):
        validate_schema_property(definition.items, entry, f"{path}[{index}]", errors)


def has_argument(args: dict[str, Any], key: str) -> bool:
    """
    Check if an argument exists and is not None/undefined.

    Args:
        args: Arguments dictionary
        key: Key to check

    Returns:
        True if argument exists and is not None
    """
    if key not in args:
        return False
    value = args[key]
    return value is not None


def format_message(tool_name: str, issues: list[str]) -> str:
    """
    Format validation error message.

    Args:
        tool_name: Name of the tool
        issues: List of validation issues

    Returns:
        Formatted error message
    """
    detail = " ".join(issues)
    return f'Invalid arguments for "{tool_name}": {detail}'
