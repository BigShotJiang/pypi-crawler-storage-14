"""
Tool Runtime - Manages tool registration, execution, caching, and validation.

Responsibilities:
- Register and manage tool suites
- Execute tool calls with validation
- Cache idempotent tool results
- Observe tool execution lifecycle
- Truncate tool outputs using context manager
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

from .context_manager import ContextManager
from .schema_validator import ToolArgumentValidationError, validate_tool_arguments
from .types import (
    JSONSchemaBoolean,
    JSONSchemaObject,
    JSONSchemaString,
    ProviderToolDefinition,
    ToolCallRequest,
)


# Type alias for tool handler function
ToolHandler = Callable[[dict[str, Any]], Awaitable[str] | str]


@dataclass
class ToolExecutionContext:
    """Context information for tool execution."""

    profile_name: str
    provider: str
    model: str
    workspace_context: Optional[str] = None


class ToolRuntimeObserver(ABC):
    """Observer interface for tool runtime events."""

    def on_tool_start(self, call: ToolCallRequest) -> None:
        """Called when a tool execution starts."""
        pass

    def on_tool_result(self, call: ToolCallRequest, output: str) -> None:
        """Called when a tool execution completes successfully."""
        pass

    def on_tool_error(self, call: ToolCallRequest, error: str) -> None:
        """Called when a tool execution fails."""
        pass

    def on_cache_hit(self, call: ToolCallRequest) -> None:
        """Called when a tool result is retrieved from cache."""
        pass


@dataclass
class ToolRuntimeOptions:
    """Options for tool runtime configuration."""

    observer: Optional[ToolRuntimeObserver] = None
    context_manager: Optional[ContextManager] = None
    enable_cache: bool = True
    cache_ttl_ms: int = 5 * 60 * 1000  # 5 minutes default
    default_timeout_seconds: int = 120  # 2 minutes default timeout
    network_timeout_seconds: int = 30  # 30 seconds for network operations


@dataclass
class ToolDefinition:
    """Definition of a tool that can be executed."""

    name: str
    description: str
    handler: ToolHandler
    parameters: Optional[JSONSchemaObject] = None
    cacheable: bool = False  # Whether results can be cached


@dataclass
class ToolSuite:
    """A collection of related tools."""

    id: str
    tools: list[ToolDefinition]
    description: Optional[str] = None
    name: Optional[str] = None  # Human-friendly display name


@dataclass
class ToolRecord:
    """Internal record of a registered tool."""

    suite_id: str
    definition: ToolDefinition


@dataclass
class CacheEntry:
    """Cache entry for tool results."""

    result: str
    timestamp: float


# Idempotent tools that can be safely cached
CACHEABLE_TOOLS = {
    "Read",
    "read_file",
    "Glob",
    "glob_search",
    "Grep",
    "grep_search",
    "find_definition",
    "analyze_code_quality",
    "extract_exports",
}


class ToolRuntime:
    """Runtime for managing and executing tools."""

    def __init__(
        self,
        base_tools: Optional[list[ToolDefinition]] = None,
        options: Optional[ToolRuntimeOptions] = None,
    ):
        """
        Initialize tool runtime.

        Args:
            base_tools: Initial tools to register
            options: Runtime configuration options
        """
        self.registry: dict[str, ToolRecord] = {}
        self.registration_order: list[str] = []
        self.cache: dict[str, CacheEntry] = {}

        if options is None:
            options = ToolRuntimeOptions()

        self.observer = options.observer
        self.context_manager = options.context_manager
        self.enable_cache = options.enable_cache
        self.cache_ttl_ms = options.cache_ttl_ms
        self.default_timeout_seconds = options.default_timeout_seconds
        self.network_timeout_seconds = options.network_timeout_seconds

        if base_tools:
            self.register_suite(
                ToolSuite(
                    id="runtime.core",
                    description="Core runtime metadata tools",
                    tools=base_tools,
                )
            )

    def register_suite(self, suite: ToolSuite) -> None:
        """
        Register a suite of tools.

        Args:
            suite: Tool suite to register

        Raises:
            ValueError: If suite ID is blank or tool names are duplicate
        """
        if not suite.id or not suite.id.strip():
            raise ValueError("Tool suite id cannot be blank.")

        # Unregister existing suite with same ID
        self.unregister_suite(suite.id)

        # Register all tools in the suite
        for definition in suite.tools:
            self._add_tool(definition, suite.id)

    def unregister_suite(self, suite_id: str) -> None:
        """
        Unregister all tools from a suite.

        Args:
            suite_id: ID of suite to unregister
        """
        if not suite_id or not suite_id.strip():
            return

        # Remove all tools from this suite
        names_to_remove = [name for name, record in self.registry.items() if record.suite_id == suite_id]

        for name in names_to_remove:
            del self.registry[name]
            self._remove_from_order(name)

    def list_provider_tools(self) -> list[ProviderToolDefinition]:
        """
        List all registered tools in provider format.

        Returns:
            List of provider tool definitions
        """
        tools = []
        for name in self.registration_order:
            record = self.registry.get(name)
            if not record:
                continue

            tool = ProviderToolDefinition(
                name=record.definition.name,
                description=record.definition.description,
            )
            if record.definition.parameters:
                tool.parameters = record.definition.parameters

            tools.append(tool)

        return tools

    async def execute(self, call: ToolCallRequest) -> str:
        """
        Execute a tool call.

        Args:
            call: Tool call request

        Returns:
            Tool execution result as string
        """
        record = self.registry.get(call.name)
        if not record:
            message = f'Tool "{call.name}" is not available.'
            if self.observer:
                self.observer.on_tool_error(call, message)
            return message

        # Check if tool is cacheable
        is_cacheable = record.definition.cacheable or call.name in CACHEABLE_TOOLS

        # Try to get from cache
        if self.enable_cache and is_cacheable:
            cache_key = self._get_cache_key(call)
            cached = self.cache.get(cache_key)

            if cached and (time.time() * 1000 - cached.timestamp) < self.cache_ttl_ms:
                if self.observer:
                    self.observer.on_cache_hit(call)
                    self.observer.on_tool_result(call, cached.result)
                return cached.result

        # Notify observer of tool start
        if self.observer:
            self.observer.on_tool_start(call)

        try:
            # Normalize and validate arguments
            args = normalize_tool_arguments(call.arguments)
            validate_tool_arguments(record.definition.name, record.definition.parameters, args)

            # Determine appropriate timeout based on tool type
            is_network_tool = self._is_network_tool(call.name)
            timeout = self.network_timeout_seconds if is_network_tool else self.default_timeout_seconds

            # Execute the tool handler with timeout
            result = record.definition.handler(args)
            if isinstance(result, Awaitable):
                try:
                    result = await asyncio.wait_for(result, timeout=timeout)
                except asyncio.TimeoutError:
                    timeout_msg = self._build_timeout_message(call.name, timeout, is_network_tool)
                    if self.observer:
                        self.observer.on_tool_error(call, timeout_msg)
                    return timeout_msg

            # Convert result to string
            output = result if isinstance(result, str) else json.dumps(result, indent=2)

            # Truncate output if context manager is available
            if self.context_manager:
                truncated = self.context_manager.truncate_tool_output(output, call.name)
                if truncated.was_truncated:
                    output = truncated.content
                    # Log truncation for debugging
                    if os.environ.get("DEBUG_CONTEXT"):
                        print(
                            f"[Context Manager] Truncated {call.name} output: "
                            f"{truncated.original_length} -> {truncated.truncated_length} chars"
                        )

            # Cache the result if cacheable
            if self.enable_cache and is_cacheable:
                cache_key = self._get_cache_key(call)
                self.cache[cache_key] = CacheEntry(
                    result=output,
                    timestamp=time.time() * 1000,
                )

            # Notify observer of success
            if self.observer:
                self.observer.on_tool_result(call, output)

            return output

        except ToolArgumentValidationError as error:
            formatted = str(error)
            if self.observer:
                self.observer.on_tool_error(call, formatted)
            return formatted

        except Exception as error:
            message = str(error) if isinstance(error, Exception) else str(error)
            formatted = self._build_error_message(call.name, message, error)
            if self.observer:
                self.observer.on_tool_error(call, formatted)
            return formatted

    def _get_cache_key(self, call: ToolCallRequest) -> str:
        """Generate cache key for a tool call."""
        return f"{call.name}:{json.dumps(call.arguments, sort_keys=True)}"

    def clear_cache(self) -> None:
        """Clear all cached tool results."""
        self.cache.clear()

    def get_cache_stats(self) -> dict[str, int]:
        """
        Get cache statistics.

        Returns:
            Dictionary with 'size' (total bytes) and 'entries' (count)
        """
        total_size = sum(len(entry.result) for entry in self.cache.values())
        return {
            "size": total_size,
            "entries": len(self.cache),
        }

    def _build_error_message(self, tool_name: str, error_msg: str, exception: Exception) -> str:
        """
        Build an intelligent error message with recovery suggestions.

        Args:
            tool_name: Name of the tool that failed
            error_msg: Original error message
            exception: The exception that was raised

        Returns:
            Formatted error message with context and recovery suggestions
        """
        msg = f'Failed to run "{tool_name}": {error_msg}\n\n'

        # Detect common error patterns and provide specific guidance
        error_lower = error_msg.lower()

        if 'connection' in error_lower or 'refused' in error_lower or 'unreachable' in error_lower:
            msg += "**Connection Error**\n"
            msg += "- Target may be offline or unreachable\n"
            msg += "- Check network connectivity and firewall rules\n"
            msg += "- Verify target address/port is correct\n"
            msg += "- Try alternative targets or endpoints\n\n"
            msg += "**AI should:** Try a different target or verify connectivity with simpler tools (ping, curl)."

        elif 'permission' in error_lower or 'denied' in error_lower or 'forbidden' in error_lower:
            msg += "**Permission Error**\n"
            msg += "- Insufficient permissions to access resource\n"
            msg += "- May require authentication or elevated privileges\n"
            msg += "- Check file/directory permissions\n"
            msg += "- Verify API keys or credentials are valid\n\n"
            msg += "**AI should:** Check if authentication is needed, or try operations that don't require elevated permissions."

        elif 'not found' in error_lower or 'does not exist' in error_lower or '404' in error_msg:
            msg += "**Resource Not Found**\n"
            msg += "- Target resource, file, or endpoint doesn't exist\n"
            msg += "- Path or URL may be incorrect\n"
            msg += "- Resource may have been moved or deleted\n\n"
            msg += "**AI should:** Verify the path/URL is correct, search for the resource in alternative locations."

        elif 'syntax' in error_lower or 'invalid' in error_lower or 'malformed' in error_lower:
            msg += "**Invalid Input**\n"
            msg += "- Parameters or arguments have incorrect format\n"
            msg += "- Check syntax of commands or queries\n"
            msg += "- Verify data types and structure\n\n"
            msg += "**AI should:** Review and correct the tool arguments, try simpler or alternative syntax."

        elif 'memory' in error_lower or 'space' in error_lower or 'disk' in error_lower:
            msg += "**Resource Exhaustion**\n"
            msg += "- Insufficient memory or disk space\n"
            msg += "- Operation may be too large for available resources\n\n"
            msg += "**AI should:** Break down into smaller operations, or clean up temporary files/caches."

        elif 'rate limit' in error_lower or 'too many' in error_lower or '429' in error_msg:
            msg += "**Rate Limit Exceeded**\n"
            msg += "- API or service is rate-limiting requests\n"
            msg += "- Too many requests in short time period\n\n"
            msg += "**AI should:** Wait before retrying, reduce request frequency, or use alternative endpoints."

        else:
            msg += "**General Error**\n"
            msg += "- Review error details above\n"
            msg += "- Check tool documentation for usage\n"
            msg += "- Try alternative approaches\n\n"
            msg += "**AI should:** Analyze error details, try alternative tools or approaches to achieve the goal."

        return msg

    def _is_network_tool(self, tool_name: str) -> bool:
        """
        Determine if a tool involves network operations.

        Network tools include:
        - HTTP/web requests (fetch, curl, etc.)
        - DNS lookups
        - Port scanning
        - API calls
        - Git operations (remote)
        - Package installations
        """
        network_keywords = {
            'fetch', 'http', 'url', 'web', 'api', 'request', 'curl', 'wget',
            'dns', 'ping', 'scan', 'port', 'network', 'socket',
            'git', 'clone', 'pull', 'push', 'remote',
            'install', 'download', 'npm', 'pip', 'apt',
            'sql_injection', 'xss', 'exploit', 'vulnerability',
        }
        tool_lower = tool_name.lower()
        return any(keyword in tool_lower for keyword in network_keywords)

    def _build_timeout_message(self, tool_name: str, timeout: int, is_network: bool) -> str:
        """
        Build an intelligent timeout error message with recovery suggestions.

        Args:
            tool_name: Name of the tool that timed out
            timeout: Timeout value in seconds
            is_network: Whether this is a network operation

        Returns:
            Formatted error message with recovery suggestions
        """
        msg = f'Tool "{tool_name}" timed out after {timeout} seconds.\n\n'

        if is_network:
            msg += "**Network Timeout Detected**\n\n"
            msg += "Possible causes:\n"
            msg += "- Target host is unreachable or slow to respond\n"
            msg += "- Firewall or network filtering blocking access\n"
            msg += "- DNS resolution issues\n"
            msg += "- Target may be rate-limiting requests\n\n"
            msg += "**Recommended actions:**\n"
            msg += "1. Verify target host is reachable (try ping/curl manually)\n"
            msg += "2. Check if target requires authentication or specific headers\n"
            msg += "3. Try a different target or endpoint\n"
            msg += "4. Increase timeout if target is known to be slow\n"
            msg += "5. Check network connectivity and DNS resolution\n"
        else:
            msg += "**Operation Timeout**\n\n"
            msg += "Possible causes:\n"
            msg += "- Operation processing large amounts of data\n"
            msg += "- System resource constraints (CPU, memory, disk I/O)\n"
            msg += "- Infinite loop or deadlock in operation\n\n"
            msg += "**Recommended actions:**\n"
            msg += "1. Try with smaller input/scope\n"
            msg += "2. Check system resources (CPU, memory, disk space)\n"
            msg += "3. Verify operation parameters are correct\n"
            msg += "4. Break task into smaller subtasks\n"

        msg += "\n**AI should:** Continue with alternative approaches or break down the task into smaller steps."
        return msg

    def _add_tool(self, definition: ToolDefinition, suite_id: str) -> None:
        """Add a tool to the registry."""
        if not definition.name or not definition.name.strip():
            raise ValueError(f'Tool names cannot be blank (suite "{suite_id}").')

        if definition.name in self.registry:
            owner = self.registry[definition.name].suite_id
            raise ValueError(f'Tool "{definition.name}" already registered by suite "{owner}".')

        self.registry[definition.name] = ToolRecord(
            suite_id=suite_id,
            definition=definition,
        )
        self.registration_order.append(definition.name)

    def _remove_from_order(self, name: str) -> None:
        """Remove a tool name from registration order."""
        if name in self.registration_order:
            self.registration_order.remove(name)


def create_default_tool_runtime(
    context: ToolExecutionContext,
    tool_suites: Optional[list[ToolSuite]] = None,
    options: Optional[ToolRuntimeOptions] = None,
) -> ToolRuntime:
    """
    Create a default tool runtime with core tools.

    Args:
        context: Execution context
        tool_suites: Additional tool suites to register
        options: Runtime options

    Returns:
        Configured ToolRuntime instance
    """
    runtime = ToolRuntime(
        base_tools=[
            build_context_snapshot_tool(context.workspace_context),
            build_capabilities_tool(context),
            build_profile_inspector_tool(context),
        ],
        options=options,
    )

    # Register additional tool suites
    if tool_suites:
        for suite in tool_suites:
            runtime.register_suite(suite)

    return runtime


def build_context_snapshot_tool(workspace_context: Optional[str]) -> ToolDefinition:
    """Build tool for retrieving workspace context snapshot."""

    def handler(args: dict[str, Any]) -> str:
        if not workspace_context or not workspace_context.strip():
            return "Workspace context is unavailable."

        # CRITICAL: Return only summary to prevent context duplication
        # Full context is already in system prompt
        lines = workspace_context.strip().split("\n")
        total_lines = len(lines)

        # Return just first 20 lines + summary
        preview = "\n".join(lines[:20])
        summary = "\n".join(
            [
                preview,
                "",
                f"[Workspace context: {total_lines} total lines]",
                "[Full context already available in system prompt - use Read/Glob tools for specific files]",
            ]
        )

        format_type = args.get("format", "plain")
        if format_type == "markdown":
            return f"```text\n{summary}\n```"
        return summary

    return ToolDefinition(
        name="context_snapshot",
        description="Returns a summary of the repository context. NOTE: Full context is already in your system prompt - only use this if you need to refresh or verify the context.",
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "format": JSONSchemaString(
                    type="string",
                    description='Use "plain" for raw text or "markdown" for a fenced block.',
                )
            },
        ),
        handler=handler,
    )


def build_capabilities_tool(context: ToolExecutionContext) -> ToolDefinition:
    """Build tool for describing agent capabilities."""

    def handler(args: dict[str, Any]) -> str:
        audience = args.get("audience", "model")
        adjective = "Operator facing" if audience == "developer" else "Model facing"
        return "\n".join(
            [
                f"{adjective} capabilities summary:",
                "- Full file system access (read, write, list, search).",
                "- Bash command execution for running scripts and tools.",
                "- Advanced code search and pattern matching.",
                "- Deterministic workspace context snapshot appended to the system prompt.",
                "- Tool invocations are logged in realtime for transparency.",
                f"- Active provider: {context.provider} ({context.model}).",
            ]
        )

    return ToolDefinition(
        name="capabilities_overview",
        description="Summarizes the agent runtime capabilities including available tools and features.",
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "audience": JSONSchemaString(
                    type="string",
                    description="Tailors the tone of the description.",
                )
            },
        ),
        handler=handler,
    )


def build_profile_inspector_tool(context: ToolExecutionContext) -> ToolDefinition:
    """Build tool for inspecting active profile configuration."""

    def handler(args: dict[str, Any]) -> str:
        include_workspace = args.get("includeWorkspaceContext", False)
        payload = {
            "profile": context.profile_name,
            "provider": context.provider,
            "model": context.model,
            "workspaceContext": context.workspace_context if include_workspace else None,
        }
        return json.dumps(payload, indent=2)

    return ToolDefinition(
        name="profile_details",
        description="Returns the configuration of the active CLI profile.",
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "includeWorkspaceContext": JSONSchemaBoolean(
                    type="boolean",
                    description="Set true to append the workspace context snapshot if available.",
                )
            },
            additional_properties=False,
        ),
        handler=handler,
    )


def normalize_tool_arguments(value: Any) -> dict[str, Any]:
    """
    Normalize tool arguments to a dictionary.

    Args:
        value: Arguments value (dict, string, or other)

    Returns:
        Normalized dictionary
    """
    if isinstance(value, dict):
        return value

    if isinstance(value, str):
        trimmed = value.strip()
        if not trimmed:
            return {}
        try:
            parsed = json.loads(trimmed)
            return parsed if isinstance(parsed, dict) else {}
        except (json.JSONDecodeError, ValueError):
            return {}

    return {}
