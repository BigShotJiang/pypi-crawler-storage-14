"""
Unified Capability System

All capabilities are now managed through the unified tool runtime.
This module provides the bridge between the unified schema and capability suites.

Architecture:
- UNIFIED: Schema-driven tools from unified_tool_runtime
- CORE: Essential coding tools (filesystem, edit, bash, glob, grep)
- PLUGINS: Optional features loaded on demand

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from ..core.unified_tool_runtime import (
    UnifiedToolRuntime,
    UnifiedToolRuntimeConfig,
    UnifiedToolDefinition,
    UnifiedToolSuite,
    ToolExecutionContext,
    create_full_tool_runtime,
    register_core_tools,
    CORE_TOOL_HANDLERS,
)
from ..core.unified_provider import (
    get_tools,
    get_tools_by_category,
    get_tool_categories,
    get_tools_for_task,
    ToolConfig,
)


# ============================================================================
# Capability Suite (Bridge to Unified Runtime)
# ============================================================================

class CapabilitySuite:
    """
    A capability suite that wraps unified tools.

    Provides a consistent interface for accessing tools while
    leveraging the unified schema for tool definitions.
    """

    def __init__(
        self,
        suite_id: str,
        name: str,
        description: str,
        category: str,
        runtime: UnifiedToolRuntime,
    ):
        self.id = suite_id
        self.name = name
        self.description = description
        self.category = category
        self._runtime = runtime

    @property
    def tools(self) -> List[UnifiedToolDefinition]:
        """Get all tools in this suite."""
        return self._runtime.get_tools_by_category(self.category)

    def execute(self, tool_id: str, args: Dict[str, Any]) -> str:
        """Execute a tool in this suite."""
        result = self._runtime.execute(tool_id, args)
        if result.success:
            return result.result or ""
        return f"Error: {result.error}"


# ============================================================================
# Unified Capability Builder
# ============================================================================

def build_unified_capabilities(
    working_dir: str,
    enabled_categories: Optional[List[str]] = None,
    auth_context: Optional[str] = None,
) -> UnifiedToolRuntime:
    """
    Build a unified tool runtime with all capabilities.

    Args:
        working_dir: Working directory for file operations
        enabled_categories: List of category IDs to enable (None = all)
        auth_context: Authorization context for secure tools

    Returns:
        Fully configured UnifiedToolRuntime
    """
    return create_full_tool_runtime(
        working_dir=working_dir,
        enable_caching=True,
        auth_context=auth_context,
        enabled_categories=enabled_categories,
    )


def build_capability_suites(
    working_dir: str,
    enable_plugins: Optional[List[str]] = None,
) -> UnifiedToolRuntime:
    """
    Build capability runtime including plugins.

    Args:
        working_dir: Working directory for file operations
        enable_plugins: List of plugin IDs to enable

    Returns:
        UnifiedToolRuntime with all capabilities
    """
    runtime = build_unified_capabilities(working_dir)

    # Load plugins if requested
    if enable_plugins:
        from ..plugins import registry, load_builtin_plugins

        load_builtin_plugins()

        for plugin_id in enable_plugins:
            plugin = registry.load(plugin_id, working_dir)
            if plugin:
                # Register plugin tools with the runtime
                for tool_suite in plugin.get_tool_suites():
                    unified_suite = UnifiedToolSuite(
                        id=tool_suite.id,
                        name=tool_suite.name or tool_suite.id,
                        description=tool_suite.description or "",
                        category=f"plugin.{plugin_id}",
                        tools=[],
                    )

                    for tool in tool_suite.tools:
                        unified_tool = UnifiedToolDefinition(
                            id=f"{plugin_id}.{tool.name}",
                            name=tool.name,
                            description=tool.description,
                            category=f"plugin.{plugin_id}",
                            cacheable=False,
                            requires_auth=False,
                            parameters=_convert_parameters(tool.parameters),
                            handler=_wrap_async_handler(tool.handler),
                        )
                        unified_suite.tools.append(unified_tool)

                    runtime.register_suite(unified_suite)

    return runtime


def _convert_parameters(params: Any) -> Dict[str, Any]:
    """Convert tool parameters to dict format."""
    if hasattr(params, '__dict__'):
        return {
            "type": getattr(params, "type", "object"),
            "properties": getattr(params, "properties", {}),
            "required": getattr(params, "required", []),
        }
    return params if isinstance(params, dict) else {}


def _wrap_async_handler(handler: Callable) -> Callable:
    """Wrap async handler for synchronous execution."""
    import asyncio

    def sync_handler(args: Dict[str, Any], context: ToolExecutionContext) -> str:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Create a new loop in a thread
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(asyncio.run, handler(args))
                    result = future.result()
            else:
                result = loop.run_until_complete(handler(args))
            return str(result) if result else ""
        except Exception as e:
            return f"Error: {str(e)}"

    return sync_handler


# ============================================================================
# Category-Based Suite Builders
# ============================================================================

def get_filesystem_suite(runtime: UnifiedToolRuntime) -> CapabilitySuite:
    """Get filesystem capability suite."""
    return CapabilitySuite(
        suite_id="core.filesystem",
        name="Filesystem",
        description="Read, write, and manage files",
        category="filesystem",
        runtime=runtime,
    )


def get_edit_suite(runtime: UnifiedToolRuntime) -> CapabilitySuite:
    """Get editing capability suite."""
    return CapabilitySuite(
        suite_id="core.edit",
        name="Editing",
        description="Surgical string replacement in files",
        category="filesystem",
        runtime=runtime,
    )


def get_shell_suite(runtime: UnifiedToolRuntime) -> CapabilitySuite:
    """Get shell capability suite."""
    return CapabilitySuite(
        suite_id="core.shell",
        name="Shell",
        description="Safe shell command execution",
        category="shell",
        runtime=runtime,
    )


def get_search_suite(runtime: UnifiedToolRuntime) -> CapabilitySuite:
    """Get search capability suite."""
    return CapabilitySuite(
        suite_id="core.search",
        name="Search",
        description="File and content search tools",
        category="search",
        runtime=runtime,
    )


# ============================================================================
# Task-Based Suite Builders
# ============================================================================

def get_coding_tools(runtime: UnifiedToolRuntime) -> List[UnifiedToolDefinition]:
    """Get tools for coding tasks."""
    return runtime.get_tools_for_task("coding")


def get_analysis_tools(runtime: UnifiedToolRuntime) -> List[UnifiedToolDefinition]:
    """Get tools for analysis tasks."""
    return runtime.get_tools_for_task("analysis")


def get_testing_tools(runtime: UnifiedToolRuntime) -> List[UnifiedToolDefinition]:
    """Get tools for testing tasks."""
    return runtime.get_tools_for_task("testing")


# ============================================================================
# Legacy Compatibility
# ============================================================================

# Legacy ToolSuite type for backward compatibility
try:
    from ..core.tool_runtime import ToolSuite, ToolDefinition
except ImportError:
    # Define minimal compatibility types
    from dataclasses import dataclass
    from typing import List as ListType

    @dataclass
    class ToolDefinition:
        name: str
        description: str
        parameters: Any
        handler: Callable

    @dataclass
    class ToolSuite:
        id: str
        description: str
        tools: ListType[ToolDefinition]
        name: Optional[str] = None


def build_core_suites(working_dir: str) -> List[ToolSuite]:
    """
    Build core capability suites (legacy compatibility).

    For new code, use build_unified_capabilities() instead.
    """
    from ..tools import bash_tools, edit_tools, file_tools, glob_tools, grep_tools

    root = str(Path(working_dir).resolve())

    return [
        ToolSuite(
            id="core.filesystem",
            name="Filesystem",
            description="Read, write, list, and search files",
            tools=file_tools.create_file_tools(root),
        ),
        ToolSuite(
            id="core.edit",
            name="Editing",
            description="Surgical string replacement in files",
            tools=edit_tools.create_edit_tools(root),
        ),
        ToolSuite(
            id="core.bash",
            name="Bash",
            description="Safe shell command execution",
            tools=bash_tools.create_bash_tools(root),
        ),
        ToolSuite(
            id="core.glob",
            name="Glob",
            description="Fast pattern-based file matching",
            tools=glob_tools.create_glob_tools(root),
        ),
        ToolSuite(
            id="core.grep",
            name="Grep",
            description="Powerful regex content search",
            tools=grep_tools.create_grep_tools(root),
        ),
    ]


def build_legacy_capability_suites(working_dir: str) -> List[ToolSuite]:
    """
    Build all capability suites with legacy modules.

    DEPRECATED: Use build_unified_capabilities() instead.
    """
    return build_core_suites(working_dir)


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Unified system
    "build_unified_capabilities",
    "build_capability_suites",
    "CapabilitySuite",

    # Category suites
    "get_filesystem_suite",
    "get_edit_suite",
    "get_shell_suite",
    "get_search_suite",

    # Task-based tools
    "get_coding_tools",
    "get_analysis_tools",
    "get_testing_tools",

    # Legacy compatibility
    "build_core_suites",
    "build_legacy_capability_suites",
]
