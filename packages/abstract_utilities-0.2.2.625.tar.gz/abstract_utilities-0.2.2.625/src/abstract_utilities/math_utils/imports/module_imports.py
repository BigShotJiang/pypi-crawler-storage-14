from ...type_utils import det_bool_T,is_number
