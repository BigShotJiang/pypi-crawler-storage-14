To configure this module, you need to:

#. Go to *Expenses > Configuration > Reminder Definition*.
#. Set reminder definition.
#. Specify the time period for the set due date clearing advance. This field is Terms Due Date has default 30 days and it will compute due date by today + Terms Due Date, when you Post Journal Entries on expense sheet.
#. Specify other fields (if any)
