This module allow company to send overdue advance reminders to the employee.
it sends a reminder for an expense advance when it has past it's *Due Date*
An overdue reminder for a employee always include all the overdue advance an amount of that employee.

The module supports a clever expense reimbursement reminder counter mechanism:

* the reminder counter is a property of an expense advance,
* the reminder counter of each overdue expense advance is incremented every time when you sending a reminder by email / letter.
* in an email template, you can configure at *Settings > Technical > Email > Email Templates > Name 'Advance: Overdue Reminder'*
