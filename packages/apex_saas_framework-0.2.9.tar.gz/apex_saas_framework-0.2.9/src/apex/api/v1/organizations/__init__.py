"""Organizations API routes."""

from apex.api.v1.organizations.router import router

__all__ = ["router"]

