# Core Developers
----------
- [@sepandhaghighi](http://github.com/sepandhaghighi)


# Other Contributors
----------
- [Gemini](https://gemini.google.com) ++

++ Graphic designer

