"""
downloader.py — VPS download-only helpers for yt-dlp (no transcoding here).

Goal:
- Prefer exact 1080p H.264 (avc1) + AAC in MP4 (no re-encode).
- If that doesn't exist, still grab exact 1080p in ANY codec/container (VP9/AV1/WebM/MKV/MP4).
- Only if 1080p truly doesn't exist do we fall back to best <= requested resolution.
- Audio-only (mp3) supported.

This keeps 1080p whenever possible; iOS/macOS compatibility is handled by the app server
(transcode step) if the final file isn't Apple-safe MP4.

Env:
- YTPDL_VENV               (default: /opt/yt-dlp-mullvad/venv)
- YTPDL_MULLVAD_LOCATION   (default: "us")
- YTPDL_USER_AGENT         (override UA)
- YTPDL_AUDIO_LANG         (preferred audio language, e.g. "en")
- YTPDL_ACCEPT_LANGUAGE    (HTTP Accept-Language header)
"""

from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import time
import json
from typing import Optional, List

# =========================
# Config / constants
# =========================
VENV_PATH = os.environ.get("YTPDL_VENV", "/opt/yt-dlp-mullvad/venv")
YTDLP_BIN = os.path.join(VENV_PATH, "bin", "yt-dlp")
MULLVAD_LOCATION = os.environ.get("YTPDL_MULLVAD_LOCATION", "us")
ENGLISH_LOCATIONS = ["us", "gb", "ca", "au"]

MODERN_UA = os.environ.get(
    "YTPDL_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36",
)

# Preferred audio language + HTTP Accept-Language
PREFERRED_AUDIO_LANG = (os.environ.get("YTPDL_AUDIO_LANG", "en") or "").strip().lower()
ACCEPT_LANGUAGE = os.environ.get("YTPDL_ACCEPT_LANGUAGE", "en-US,en;q=0.9")


def _alang_filter() -> str:
    """
    Format-selection fragment for preferred audio language.

    Returns:
        When YTPDL_AUDIO_LANG is set (e.g. "en" or "en-US"), returns a
        prefix match filter like "[language^=en]" so we match codes such
        as "en", "en-US", "en-GB", "eng", etc. If no preference is set,
        returns "".
    """
    if not PREFERRED_AUDIO_LANG:
        return ""
    # Use just the base language ("en" from "en-US") for prefix matching.
    base = PREFERRED_AUDIO_LANG.split("-")[0].lower()
    return f"[language^={base}]"


def _mullvad_present() -> bool:
    return shutil.which("mullvad") is not None


def _run_argv(argv: List[str], check: bool = True) -> str:
    proc = subprocess.run(argv, capture_output=True, text=True)
    if check and proc.returncode != 0:
        raise RuntimeError(f"Command failed: {shlex.join(argv)}\n{proc.stderr}")
    return proc.stdout


def manual_login(account_number: str) -> None:
    if not _mullvad_present():
        raise RuntimeError("Mullvad CLI not found; install it first.")
    _run_argv(["mullvad", "account", "login", account_number])


def validate_environment() -> None:
    if not os.path.exists(YTDLP_BIN):
        raise RuntimeError(f"yt-dlp not found at {YTDLP_BIN}; check venv setup.")
    if not _mullvad_present():
        raise RuntimeError("Mullvad CLI not found; install it and log in.")


def _mullvad_connect() -> None:
    _run_argv(["mullvad", "relay", "set", "location", MULLVAD_LOCATION])
    _run_argv(["mullvad", "connect"])
    time.sleep(5)  # Wait for connection
    status = _run_argv(["mullvad", "status"]).strip()
    if "Connected" not in status:
        raise RuntimeError(f"Mullvad connection failed: {status}")


def _extract_downloaded_filename(output: str) -> Optional[str]:
    for line in output.splitlines():
        if "[download] Destination:" in line:
            return line.split("Destination:")[-1].strip()
    return None


def _try_fmt(
    url: str,
    out_tpl: str,
    fmt: str,
    sort: str,
    merge_to_mp4: bool,
) -> Optional[str]:
    argv = [
        YTDLP_BIN,
        "--format",
        fmt,
        "--format-sort",
        sort,
        "--user-agent",
        MODERN_UA,
        "--add-header",
        f"Accept-Language:{ACCEPT_LANGUAGE}",
        "--extractor-args",
        "youtube:lang=en;player_client=web",
        "--audio-multistreams",
        "--output",
        out_tpl,
        url,
    ]
    if merge_to_mp4:
        argv.extend(["--postprocessor-args", "-f mp4"])
    try:
        out = _run_argv(argv)
        path = _extract_downloaded_filename(out)
        if path and os.path.exists(path):
            return path
    except RuntimeError:
        pass
    return None


def download_video(
    url: str,
    resolution: Optional[str] = None,
    extension: Optional[str] = None,
) -> Optional[str]:
    if _mullvad_present():
        # Check if logged in
        status = _run_argv(["mullvad", "account", "get"], check=False)
        if "No account set" in status or "not logged in" in status.lower():
            raise RuntimeError("Mullvad is not logged in; run manual_login first.")

    out_dir = "/root"  # Or use a temp dir
    alang = _alang_filter()

    for loc in ENGLISH_LOCATIONS:
        os.environ["YTPDL_MULLVAD_LOCATION"] = loc
        try:
            if _mullvad_present():
                _mullvad_connect()

            if extension == "mp3":
                out_tpl = os.path.join(out_dir, "%(title)s.%(ext)s")
                argv = [
                    YTDLP_BIN,
                    "--format",
                    "ba[language^=en]/ba[language=eng]/ba",  # Flexible English, then any (fallback)
                    "--user-agent",
                    MODERN_UA,
                    "--add-header",
                    f"Accept-Language:{ACCEPT_LANGUAGE}",
                    "--extractor-args",
                    "youtube:lang=en;player_client=web",
                    "--audio-multistreams",
                    "--extract-audio",
                    "--audio-format",
                    "mp3",
                    "--output",
                    out_tpl,
                    url,
                ]
                out = _run_argv(argv)
                path = _extract_downloaded_filename(out)
                if not path or not os.path.exists(path):
                    raise RuntimeError("Audio download finished but file not found.")
                # Post-check (allow 'und' for untagged original)
                ffprobe_out = _run_argv(["ffprobe", "-v", "quiet", "-print_format", "json", "-show_streams", path])
                streams = json.loads(ffprobe_out)
                audio_streams = [s for s in streams.get('streams', []) if s['codec_type'] == 'audio']
                lang = audio_streams[0]['tags'].get('language', 'und').lower() if audio_streams and 'tags' in audio_streams[0] else 'und'
                if not (lang.startswith('en') or lang == 'und'):
                    os.remove(path)
                    raise RuntimeError("Downloaded audio is not in English; possible dub detected.")
                return os.path.abspath(path)

            # ---------- Video ----------
            cap = int(resolution or 1080)
            out_tpl = os.path.join(out_dir, "%(title)s.%(ext)s")

            # A) EXACT 1080p, H.264 (avc1) + AAC in MP4, preferring English audio.
            fmt_h264_1080 = (
                "bv*[height=1080][vcodec~='^(?:avc1|h264)'][ext=mp4]"
                "+ba[language^=en][acodec~='^mp4a'][ext=m4a]/"
                "bv*[height=1080][vcodec~='^(?:avc1|h264)'][ext=mp4]"
                "+ba[language=eng][acodec~='^mp4a'][ext=m4a]/"
                "b[height=1080][vcodec~='^(?:avc1|h264)'][ext=mp4]"
            )
            sort_h264_1080 = "codec:h264,res,fps,br,filesize"
            path = _try_fmt(url, out_tpl, fmt_h264_1080, sort_h264_1080, merge_to_mp4=True)
            if path:
                # Post-check
                ffprobe_out = _run_argv(["ffprobe", "-v", "quiet", "-print_format", "json", "-show_streams", path])
                streams = json.loads(ffprobe_out)
                audio_streams = [s for s in streams.get('streams', []) if s['codec_type'] == 'audio']
                lang = audio_streams[0]['tags'].get('language', 'und').lower() if audio_streams and 'tags' in audio_streams[0] else 'und'
                if not (lang.startswith('en') or lang == 'und'):
                    os.remove(path)
                    raise RuntimeError("Downloaded audio is not in English; possible dub detected.")
                return os.path.abspath(path)

            # B) EXACT 1080p, ANY codec/container, prefer English audio if separate.
            fmt_any_1080 = (
                f"bv*[height=1080]+ba[language^=en]/"
                f"bv*[height=1080]+ba[language=eng]/"
                "b[height=1080]"
            )
            sort_any_1080 = "res,fps,br,filesize"
            path = _try_fmt(url, out_tpl, fmt_any_1080, sort_any_1080, merge_to_mp4=False)
            if path:
                # Post-check
                ffprobe_out = _run_argv(["ffprobe", "-v", "quiet", "-print_format", "json", "-show_streams", path])
                streams = json.loads(ffprobe_out)
                audio_streams = [s for s in streams.get('streams', []) if s['codec_type'] == 'audio']
                lang = audio_streams[0]['tags'].get('language', 'und').lower() if audio_streams and 'tags' in audio_streams[0] else 'und'
                if not (lang.startswith('en') or lang == 'und'):
                    os.remove(path)
                    raise RuntimeError("Downloaded audio is not in English; possible dub detected.")
                return os.path.abspath(path)

            # C) If 1080p truly not present, take best <= cap, preferring English audio.
            fmt_best_upto = (
                f"bv*[height<={cap}]+ba[language^=en]/"
                f"bv*[height<={cap}]+ba[language=eng]/"
                f"b[height<={cap}]"
            )
            sort_best_upto = "res,fps,br,filesize"
            path = _try_fmt(url, out_tpl, fmt_best_upto, sort_best_upto, merge_to_mp4=False)
            if not path or not os.path.exists(path):
                raise RuntimeError("Video download finished but file not found.")
            # Post-check
            ffprobe_out = _run_argv(["ffprobe", "-v", "quiet", "-print_format", "json", "-show_streams", path])
            streams = json.loads(ffprobe_out)
            audio_streams = [s for s in streams.get('streams', []) if s['codec_type'] == 'audio']
            lang = audio_streams[0]['tags'].get('language', 'und').lower() if audio_streams and 'tags' in audio_streams[0] else 'und'
            if not (lang.startswith('en') or lang == 'und'):
                os.remove(path)
                raise RuntimeError("Downloaded audio is not in English; possible dub detected.")
            return os.path.abspath(path)

        except RuntimeError as e:
            if _mullvad_present():
                _run_argv(["mullvad", "disconnect"], check=False)
            if "dub detected" not in str(e):
                continue  # Retry next location
            else:
                raise  # No retry for dub error
        finally:
            if _mullvad_present():
                _run_argv(["mullvad", "disconnect"], check=False)

    return None