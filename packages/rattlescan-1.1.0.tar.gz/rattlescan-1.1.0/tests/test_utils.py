import os
import tempfile
from rattlescan import cli


def test_calculate_file_hashes_and_entropy():
    data = b"a" * 1024  # low-entropy data
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(data)
        tmp.flush()
        fname = tmp.name

    try:
        hashes = cli.calculate_file_hashes(fname)
        assert 'MD5' in hashes and 'SHA-1' in hashes and 'SHA-256' in hashes
        entropy = cli.analyze_file_entropy(fname)
        assert 'Entropy' in entropy
        # Low or medium entropy are both acceptable for this test
        assert (
            'Low entropy' in entropy['Analysis']
            or 'Medium entropy' in entropy['Analysis']
        )
    finally:
        os.remove(fname)
