# RATTLESCAN

**Forensic metadata analysis and secure file cleaning tool for the command line.**

A fast CLI tool to inspect, analyze, and clean file metadata. Works on Windows, macOS, and Linux.

## Installation

```bash
pip install rattlescan

## With optional TUI (interactive menu): ##
pip install rattlescan[ui]
```

## Usage

```bash
## Analyze a file ##
rattlescan photo.jpg

## Analyze and prompt for cleaning ##
rattlescan document.pdf --clean

## Analyze with custom output path ##
rattlescan image.png --clean --output cleaned_image.png

## Secure wipe (destructive!) ##
rattlescan sensitive.pdf --wipe -y

## Scan only, no interactive menu ##
rattlescan file.txt --no-interactive

## Check version ##
rattlescan --version
```

## Features

- **Cryptographic hashes**: MD5, SHA-1, SHA-256
- **File type detection**: MIME type identification and extension validation
- **Entropy analysis**: Detect encrypted or compressed content
- **EXIF extraction**: GPS, camera info, timestamps from images
- **PDF metadata**: Author, title, creation date, page count
- **Audio/video tags**: ID3, duration, bitrate, sample rate
- **Metadata cleaning**: Strip EXIF, PDF info, audio tags
- **Secure wipe**: DOD 5220.22-M 3-pass overwrite

## Dependencies

- `python-magic` - File type detection
- `Pillow` - Image/EXIF handling
- `PyPDF2` - PDF metadata
- `mutagen` - Audio/video metadata
- `pytermgui` *(optional)* - Enhanced interactive UI

## License

MIT