"""Rattlescan - Forensic metadata analysis and secure file cleaning tool."""

import os
import sys
import stat
import hashlib
import shutil
import argparse
import math
from datetime import datetime
from collections import OrderedDict
from pathlib import Path
from typing import Optional, Tuple, Dict, Any

try:
    import magic

    MAGIC_AVAILABLE = True
except Exception:
    MAGIC_AVAILABLE = False

__version__ = "1.1.0"

# Constants
HASH_BUFFER_SIZE = 65536
ENTROPY_SAMPLE_SIZE = 1024 * 1024
SECONDS_PER_DAY = 86400
DEFAULT_WIPE_PASSES = 3

# Supported file extensions by category
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tiff", ".bmp", ".gif"}
PDF_EXTENSIONS = {".pdf"}
AUDIO_EXTENSIONS = {".mp3", ".flac", ".ogg", ".m4a", ".wav"}
VIDEO_EXTENSIONS = {".mp4", ".avi", ".mkv"}
MEDIA_EXTENSIONS = AUDIO_EXTENSIONS | VIDEO_EXTENSIONS

# MIME type to expected extensions mapping
MIME_EXTENSION_MAP = {
    "image/jpeg": [".jpg", ".jpeg"],
    "image/png": [".png"],
    "application/pdf": [".pdf"],
    "text/plain": [".txt"],
    "application/zip": [".zip"],
}

try:
    from PIL import Image
    from PIL.ExifTags import TAGS, GPSTAGS

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import PyPDF2

    PYPDF2_AVAILABLE = True
except ImportError:
    PYPDF2_AVAILABLE = False

try:
    import mutagen

    MUTAGEN_AVAILABLE = True
except ImportError:
    MUTAGEN_AVAILABLE = False

try:
    import pytermgui as ptg

    PTG_AVAILABLE = True
except ImportError:
    PTG_AVAILABLE = False


def calculate_file_hashes(filepath: str, buffer_size: int = HASH_BUFFER_SIZE) -> Dict[str, str]:
    """Calculate MD5, SHA-1, and SHA-256 hashes for a file.

    Args:
        filepath: Path to the file to hash.
        buffer_size: Size of chunks to read at a time.

    Returns:
        OrderedDict with hash algorithm names as keys and hex digests as values.
    """
    hashes: OrderedDict[str, str] = OrderedDict()
    # usedforsecurity=False avoids FIPS warnings; these are for identification, not crypto
    md5 = hashlib.md5(usedforsecurity=False)
    sha1 = hashlib.sha1(usedforsecurity=False)
    sha256 = hashlib.sha256(usedforsecurity=False)
    try:
        with open(filepath, "rb") as f:
            while data := f.read(buffer_size):
                md5.update(data)
                sha1.update(data)
                sha256.update(data)
        hashes["MD5"] = md5.hexdigest()
        hashes["SHA-1"] = sha1.hexdigest()
        hashes["SHA-256"] = sha256.hexdigest()
    except (OSError, IOError) as e:
        hashes["Error"] = f"Could not calculate hashes: {e}"
    return hashes


def get_file_type_info(filepath: str) -> Dict[str, str]:
    """Detect file type using libmagic and validate extension matches content.

    Args:
        filepath: Path to the file to analyze.

    Returns:
        OrderedDict with MIME type, description, and any warnings.
    """
    info: OrderedDict[str, str] = OrderedDict()
    try:
        if not MAGIC_AVAILABLE:
            raise ImportError("python-magic not available")
        mime = magic.Magic(mime=True)
        mime_type = mime.from_file(filepath)
        info["MIME Type"] = mime_type
        info["File Type Description"] = magic.Magic().from_file(filepath)
        ext = Path(filepath).suffix.lower()
        if mime_type in MIME_EXTENSION_MAP and ext not in MIME_EXTENSION_MAP[mime_type]:
            key = "⚠ Extension Mismatch" if ext else "⚠ No Extension"
            info[key] = f"File is {mime_type} but has {ext or 'no'} extension"
    except ImportError:
        info["Note"] = "python-magic not installed. Install with: pip install python-magic"
    except (OSError, IOError) as e:
        info["Error"] = str(e)
    return info


def human_readable_size(size: float) -> str:
    """Convert bytes to human-readable string (KB, MB, GB, etc.)."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"


def mode_to_string(mode: int) -> str:
    """Convert file mode bits to rwx permission string (e.g., 'rwxr-xr-x')."""
    perms = []
    for flags in [
        (stat.S_IRUSR, stat.S_IWUSR, stat.S_IXUSR),
        (stat.S_IRGRP, stat.S_IWGRP, stat.S_IXGRP),
        (stat.S_IROTH, stat.S_IWOTH, stat.S_IXOTH),
    ]:
        perms.append("r" if mode & flags[0] else "-")
        perms.append("w" if mode & flags[1] else "-")
        perms.append("x" if mode & flags[2] else "-")
    return "".join(perms)


def get_file_system_metadata(filepath: str) -> Dict[str, Any]:
    """Extract filesystem metadata including timestamps, permissions, and size.

    Args:
        filepath: Path to the file to analyze.

    Returns:
        OrderedDict with filesystem metadata.
    """
    s = os.stat(filepath)
    meta: OrderedDict[str, Any] = OrderedDict()
    meta["Filename"] = Path(filepath).name
    meta["Full Path"] = os.path.abspath(filepath)
    meta["File Size"] = f"{s.st_size:,} bytes ({human_readable_size(s.st_size)})"
    meta["Permissions (Octal)"] = oct(s.st_mode)[-4:]
    meta["Permissions (String)"] = mode_to_string(s.st_mode)
    meta["Inode Number"] = s.st_ino
    meta["Device ID"] = s.st_dev
    meta["Hard Links"] = s.st_nlink

    if hasattr(s, "st_uid"):
        meta["User ID"] = s.st_uid
    if hasattr(s, "st_gid"):
        meta["Group ID"] = s.st_gid

    def format_timestamp(ts: float) -> str:
        dt_str = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        return f"{dt_str} (Unix: {int(ts)})"

    meta["Birth Time"] = format_timestamp(s.st_birthtime) if hasattr(s, "st_birthtime") else "N/A"
    meta["Last Modified (mtime)"] = format_timestamp(s.st_mtime)
    meta["Last Accessed (atime)"] = format_timestamp(s.st_atime)
    meta["Metadata Changed (ctime)"] = format_timestamp(s.st_ctime)

    now = datetime.now().timestamp()
    meta["Age (days)"] = f"{(now - s.st_mtime) / SECONDS_PER_DAY:.2f}"

    if abs(s.st_mtime - s.st_atime) < 1:
        meta["⚠ Timestamp Note"] = "Access and modification times are nearly identical"
    if s.st_mtime > now:
        meta["⚠ Future Timestamp"] = "Modification time is in the future!"

    return meta


def get_image_exif_metadata(filepath: str) -> Optional[Dict[str, Any]]:
    """Extract EXIF metadata from image files.

    Args:
        filepath: Path to the image file.

    Returns:
        OrderedDict with EXIF data, or None if not an image.
    """
    if not PIL_AVAILABLE:
        return {"Note": "Pillow library not installed. Cannot extract EXIF metadata."}
    exif: OrderedDict[str, Any] = OrderedDict()
    try:
        with Image.open(filepath) as img:
            exif["Image Format"], exif["Image Mode"], exif["Image Size"] = (
                img.format,
                img.mode,
                f"{img.size[0]} x {img.size[1]} pixels",
            )
            if not hasattr(img, "_getexif") or img._getexif() is None:
                exif["EXIF Status"] = "No EXIF data found"
                return exif
            for tid, val in img._getexif().items():
                tag = TAGS.get(tid, tid)
                if tag == "GPSInfo":
                    exif["GPS Data"] = str({GPSTAGS.get(gtid, gtid): gval for gtid, gval in val.items()})
                    continue
                if isinstance(val, bytes):
                    val = f"<Binary Data, {len(val)} bytes>" if len(val) > 100 else val.decode("utf-8", errors="ignore")
                elif isinstance(val, str) and len(val) > 100:
                    val = val[:100] + "..."
                exif[tag] = val
            return exif
    except IOError:
        return None
    except Exception as e:
        return {"Error": f"EXIF extraction error: {e}"}


def get_pdf_metadata(filepath: str) -> Dict[str, Any]:
    """Extract metadata from PDF files.

    Args:
        filepath: Path to the PDF file.

    Returns:
        OrderedDict with PDF metadata (title, author, pages, etc.).
    """
    if not PYPDF2_AVAILABLE:
        return {"Note": "PyPDF2 not installed. Install with: pip install PyPDF2"}
    meta: OrderedDict[str, Any] = OrderedDict()
    try:
        with open(filepath, "rb") as f:
            pdf = PyPDF2.PdfReader(f)
            meta["Number of Pages"] = len(pdf.pages)
            meta["Encrypted"] = pdf.is_encrypted
            if pdf.metadata:
                meta.update({k.lstrip("/"): v for k, v in pdf.metadata.items()})
    except Exception as e:
        meta["Error"] = f"PDF extraction error: {e}"
    return meta


def get_audio_video_metadata(filepath: str) -> Dict[str, Any]:
    """Extract metadata from audio/video files using mutagen.

    Args:
        filepath: Path to the media file.

    Returns:
        OrderedDict with duration, bitrate, sample rate, and tags.
    """
    if not MUTAGEN_AVAILABLE:
        return {"Note": "mutagen not installed. Install with: pip install mutagen"}
    meta: OrderedDict[str, Any] = OrderedDict()
    try:
        audio = mutagen.File(filepath)
        if audio is None:
            return {"Note": "Not a recognized audio/video file"}
        if hasattr(audio.info, "length"):
            meta["Duration"] = f"{audio.info.length:.2f} seconds"
        if hasattr(audio.info, "bitrate"):
            meta["Bitrate"] = f"{audio.info.bitrate // 1000} kbps"
        if hasattr(audio.info, "sample_rate"):
            meta["Sample Rate"] = f"{audio.info.sample_rate} Hz"
        if hasattr(audio.info, "channels"):
            meta["Channels"] = audio.info.channels
        if audio.tags:
            meta.update({str(k): str(v) for k, v in audio.tags.items()})
    except Exception as e:
        meta["Error"] = f"Audio/video extraction error: {e}"
    return meta


def analyze_file_entropy(filepath: str, sample_size: int = ENTROPY_SAMPLE_SIZE) -> Dict[str, str]:
    """Calculate Shannon entropy of file contents.

    High entropy (>7.5) suggests encryption/compression.
    Low entropy (<4.0) suggests plain text or repetitive data.

    Args:
        filepath: Path to the file to analyze.
        sample_size: Maximum bytes to read for analysis.

    Returns:
        OrderedDict with entropy value and analysis.
    """
    try:
        with open(filepath, "rb") as f:
            data = f.read(sample_size)
        if len(data) == 0:
            return {"Entropy": "N/A (empty file)"}
        freq = [0] * 256
        for byte in data:
            freq[byte] += 1

        entropy = -sum((count / len(data)) * math.log2(count / len(data)) for count in freq if count > 0)

        result: OrderedDict[str, str] = OrderedDict()
        result["Entropy"] = f"{entropy:.4f} bits/byte"

        if entropy > 7.5:
            result["Analysis"] = "High entropy - possibly encrypted or compressed"
        elif entropy < 4.0:
            result["Analysis"] = "Low entropy - likely plain text or repetitive data"
        else:
            result["Analysis"] = "Medium entropy - typical binary data"

        return result
    except (OSError, IOError) as e:
        return {"Error": f"Entropy calculation error: {e}"}


def clean_image_metadata(filepath: str, output_path: Optional[str] = None) -> Tuple[bool, str]:
    """Remove EXIF and other metadata from image files.

    Args:
        filepath: Path to the source image.
        output_path: Where to save cleaned image. If None, overwrites original.

    Returns:
        Tuple of (success: bool, message: str).
    """
    if not PIL_AVAILABLE:
        return False, "Pillow library not available"
    try:
        output = output_path or filepath
        with Image.open(filepath) as img:
            # Create new image without metadata
            clean_img = Image.new(img.mode, img.size)
            clean_img.putdata(list(img.getdata()))
            # If overwriting, save to temp first to avoid corruption
            if output == filepath:
                temp_path = filepath + ".tmp"
                clean_img.save(temp_path)
                os.replace(temp_path, filepath)
            else:
                clean_img.save(output)
        return True, f"Metadata cleaned: {output}"
    except (OSError, IOError) as e:
        return False, f"Error cleaning image metadata: {e}"


def clean_pdf_metadata(filepath: str, output_path: Optional[str] = None) -> Tuple[bool, str]:
    """Remove metadata from PDF files.

    Args:
        filepath: Path to the source PDF.
        output_path: Where to save cleaned PDF. If None, creates .cleaned.pdf.

    Returns:
        Tuple of (success: bool, message: str).
    """
    if not PYPDF2_AVAILABLE:
        return False, "PyPDF2 library not available"
    try:
        output = output_path or filepath + ".cleaned.pdf"
        with open(filepath, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            writer = PyPDF2.PdfWriter()
            for page in reader.pages:
                writer.add_page(page)
            with open(output, "wb") as out:
                writer.write(out)
        return True, f"Cleaned PDF saved to: {output}"
    except (OSError, IOError) as e:
        return False, f"Error cleaning PDF metadata: {e}"


def clean_audio_metadata(filepath: str, output_path: Optional[str] = None) -> Tuple[bool, str]:
    """Remove ID3 and other tags from audio files.

    Args:
        filepath: Path to the source audio file.
        output_path: Where to save cleaned file. If None, creates .cleaned copy.

    Returns:
        Tuple of (success: bool, message: str).
    """
    if not MUTAGEN_AVAILABLE:
        return False, "mutagen library not available"
    try:
        output = output_path or filepath + ".cleaned" + Path(filepath).suffix
        shutil.copy2(filepath, output)
        audio = mutagen.File(output)
        if audio and audio.tags:
            audio.delete()
            audio.save()
            return True, f"Cleaned audio saved to: {output}"
        return True, "No metadata tags found to remove"
    except (OSError, IOError) as e:
        return False, f"Error cleaning audio metadata: {e}"


def secure_wipe_file(filepath: str, passes: int = DEFAULT_WIPE_PASSES) -> Tuple[bool, str]:
    """Securely wipe a file using DOD 5220.22-M standard.

    Overwrites file with random data, then 0xFF, then random again,
    before deleting. Note: May not be effective on SSDs, flash storage,
    or filesystems with journaling/copy-on-write.

    Args:
        filepath: Path to the file to wipe.
        passes: Number of overwrite passes (default 3).

    Returns:
        Tuple of (success: bool, message: str).
    """
    try:
        size = os.path.getsize(filepath)
        with open(filepath, "r+b") as f:
            for i in range(passes):
                f.seek(0)
                # Alternate: random, 0xFF, random (DOD 5220.22-M pattern)
                if i == 1:
                    f.write(bytes([0xFF] * size))
                else:
                    f.write(os.urandom(size))
                f.flush()
                os.fsync(f.fileno())
        os.remove(filepath)
        return True, f"File securely wiped with {passes} passes"
    except (OSError, IOError) as e:
        return False, f"Error during secure wipe: {e}"


def interactive_clean_menu_ptg(fp):
    with ptg.WindowManager() as manager:
        result = {"action": "skip"}

        def on_clean_copy(_):
            result["action"] = "clean_copy"
            manager.stop()

        def on_clean_overwrite(_):
            result["action"] = "clean_overwrite"
            manager.stop()

        def on_secure_wipe(_):
            result["action"] = "secure_wipe"
            manager.stop()

        def on_skip(_):
            result["action"] = "skip"
            manager.stop()

        window = ptg.Window(
            "[bold 210]Metadata Cleaning & Secure Wipe Options[/]",
            "",
            ptg.Button("Clean metadata (create cleaned copy)", onclick=on_clean_copy),
            ptg.Button(
                "[yellow]Clean metadata (overwrite original) ⚠[/]",
                onclick=on_clean_overwrite,
            ),
            ptg.Button(
                "[red]Secure wipe file (DOD 5220.22-M, 3-pass) ⚠⚠[/]",
                onclick=on_secure_wipe,
            ),
            "",
            ptg.Button("Skip cleaning", onclick=on_skip),
            width=60,
        )

        window.center()
        manager.add(window)
        manager.run()

        return result["action"]


def interactive_clean_menu_fallback(fp):
    print("\n" + "=" * 70)
    print("  METADATA CLEANING & SECURE WIPE OPTIONS")
    print("=" * 70)
    print("\n[1] Clean metadata (create cleaned copy)")
    print("[2] Clean metadata (overwrite original) ⚠")
    print("[3] Secure wipe file (DOD 5220.22-M, 3-pass) ⚠⚠")
    print("[4] Skip cleaning\n")
    choice = input("Select option [1-4]: ").strip()
    if choice == "1":
        return "clean_copy"
    elif choice == "2":
        confirm = input("\n⚠  WARNING: This will overwrite the original file. Continue? (yes/no): ").strip().lower()
        if confirm == "yes":
            return "clean_overwrite"
        else:
            print("Operation cancelled.")
            return "skip"
    elif choice == "3":
        confirm = input("\n⚠⚠  DANGER: This will PERMANENTLY DELETE the file. Type 'DELETE' to confirm: ").strip()
        if confirm == "DELETE":
            return "secure_wipe"
        else:
            print("Operation cancelled.")
            return "skip"
    return "skip"


def interactive_clean_menu(fp):
    if PTG_AVAILABLE:
        return interactive_clean_menu_ptg(fp)
    else:
        return interactive_clean_menu_fallback(fp)


def perform_cleaning(filepath: str, action: str, output_path: Optional[str] = None) -> bool:
    """Execute the selected cleaning or wiping action.

    Args:
        filepath: Path to the file to clean/wipe.
        action: One of 'clean_copy', 'clean_overwrite', 'secure_wipe', 'skip'.
        output_path: Custom output path (overrides default behavior).

    Returns:
        True if operation succeeded, False otherwise.
    """
    if action == "skip":
        return True

    ext = Path(filepath).suffix.lower()
    print("\n" + "=" * 70)

    if action == "secure_wipe":
        print("  PERFORMING SECURE WIPE")
        print("=" * 70)
        print("\nWiping file with DOD 5220.22-M standard (3 passes)...")
        success, msg = secure_wipe_file(filepath)
        if success:
            print(f"\n✓ {msg}")
            print("✓ File has been permanently deleted")
        else:
            print(f"\n✗ {msg}")
        print("=" * 70)
        return success

    elif action in ["clean_copy", "clean_overwrite"]:
        print("  CLEANING METADATA")
        print("=" * 70)

        # Determine output path
        if output_path:
            out = output_path
        elif action == "clean_copy":
            out = str(Path(filepath).with_suffix("")) + ".cleaned" + ext
        else:
            out = None  # None means overwrite original

        success, msg = False, "Unsupported file type"

        if ext in IMAGE_EXTENSIONS:
            success, msg = clean_image_metadata(filepath, out)
        elif ext in PDF_EXTENSIONS:
            if action == "clean_overwrite":
                temp = filepath + ".temp.pdf"
                success, msg = clean_pdf_metadata(filepath, temp)
                if success:
                    os.replace(temp, filepath)
                    msg = "PDF metadata cleaned (original overwritten)"
            else:
                success, msg = clean_pdf_metadata(filepath, out)
        elif ext in AUDIO_EXTENSIONS:
            success, msg = clean_audio_metadata(filepath, out)
        else:
            print(f"\n⚠  Metadata cleaning not supported for {ext} files")
            print("=" * 70)
            return False

        if success:
            print(f"\n✓ {msg}")
        else:
            print(f"\n✗ {msg}")
        print("=" * 70)
        return success

    return False


def print_metadata(metadata: Optional[Dict[str, Any]], title: str, use_color: bool = True) -> None:
    """Pretty-print a metadata dictionary with aligned keys.

    Args:
        metadata: Dictionary of metadata to display.
        title: Section title to display.
        use_color: Whether to use ANSI colors for warnings.
    """
    if not metadata:
        return
    print("=" * 70)
    print(f"  {title.upper()}")
    print("=" * 70)
    max_key_len = max(len(str(k)) for k in metadata.keys())
    for key, value in metadata.items():
        display_value = str(value).replace("\n", " ")
        key_str = str(key).ljust(max_key_len)
        if "⚠" in str(key) and use_color:
            print(f"\033[93m{key_str} : {display_value}\033[0m")
        else:
            print(f"{key_str} : {display_value}")
    print()


def main(argv=None) -> int:
    """Main entry point for rattlescan CLI.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    parser = argparse.ArgumentParser(
        prog="rattlescan",
        description="Forensic metadata analysis and secure file cleaning tool.",
        epilog="Examples: rattlescan photo.jpg | rattlescan doc.pdf --clean",
    )
    parser.add_argument("file", help="Path to the file to analyze")
    parser.add_argument("--version", "-V", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--clean", action="store_true", help="Prompt for metadata cleaning after scan")
    parser.add_argument("--wipe", action="store_true", help="Prompt for secure file wiping after scan")
    parser.add_argument("--output", "-o", metavar="PATH", help="Output path for cleaned file")
    parser.add_argument(
        "--no-interactive",
        action="store_true",
        help="Skip interactive menu (scan only)",
    )
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help='Assume "yes" for destructive confirmations',
    )
    args = parser.parse_args(argv)

    filepath = args.file
    use_color = not args.no_color

    if not os.path.exists(filepath):
        print(f"Error: File not found: {filepath}")
        return 1

    if not os.path.isfile(filepath):
        print(f"Error: Not a file: {filepath}")
        return 1

    # Print header
    print("\n" + "=" * 70)
    print("  FORENSIC METADATA ANALYSIS")
    print(f"  File: {os.path.basename(filepath)}")
    print(f"  Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70 + "\n")

    # Core analysis
    print_metadata(get_file_type_info(filepath), "File Type Identification", use_color)
    print("Calculating file hashes...")
    print_metadata(calculate_file_hashes(filepath), "Cryptographic Hashes", use_color)
    print_metadata(get_file_system_metadata(filepath), "File System Metadata", use_color)
    print_metadata(analyze_file_entropy(filepath), "Entropy Analysis", use_color)

    # File-type specific metadata
    ext = Path(filepath).suffix.lower()
    if ext in IMAGE_EXTENSIONS and PIL_AVAILABLE:
        if exif := get_image_exif_metadata(filepath):
            print_metadata(exif, "Image Metadata (EXIF)", use_color)
    elif ext in PDF_EXTENSIONS:
        print_metadata(get_pdf_metadata(filepath), "PDF Metadata", use_color)
    elif ext in MEDIA_EXTENSIONS:
        print_metadata(get_audio_video_metadata(filepath), "Audio/Video Metadata", use_color)

    print("=" * 70)
    print("  ANALYSIS COMPLETE")
    print("=" * 70 + "\n")

    # Handle mutually exclusive flags
    if args.clean and args.wipe:
        print("Error: --clean and --wipe cannot be used together.")
        return 2

    # Skip interactive menu if requested
    if args.no_interactive:
        return 0

    # Handle --wipe flag
    if args.wipe:
        if args.yes:
            success = perform_cleaning(filepath, "secure_wipe")
            return 0 if success else 1
        else:
            action = interactive_clean_menu(filepath)
            if action == "secure_wipe":
                success = perform_cleaning(filepath, "secure_wipe")
                return 0 if success else 1
        return 0

    # Handle --clean flag
    if args.clean:
        action = interactive_clean_menu(filepath)
        if action != "skip":
            success = perform_cleaning(filepath, action, args.output)
            return 0 if success else 1
        return 0

    # Default: show interactive menu
    action = interactive_clean_menu(filepath)
    if action and action != "skip":
        success = perform_cleaning(filepath, action, args.output)
        return 0 if success else 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
