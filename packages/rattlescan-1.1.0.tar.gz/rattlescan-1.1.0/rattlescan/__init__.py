"""Rattlescan - Forensic metadata analysis and secure file cleaning tool."""

__version__ = "1.1.0"
__author__ = "DSiENT"
__email__ = "w.caskey7@gmail.com"
