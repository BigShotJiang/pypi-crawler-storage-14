from setuptools import setup, find_packages

setup(
    name="mudra_sdk_test_1",
    version="0.1.8",  
    packages=find_packages(include=['mudra_sdk', 'mudra_sdk.*']),
    install_requires=[],
    include_package_data=True,
    author="Foad Khoury",
    description="Mudra SDK",
    python_requires=">=3.7",
)