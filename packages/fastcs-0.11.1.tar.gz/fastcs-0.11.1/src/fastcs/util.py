ONCE = float("inf")
"""Sentinel value to call a ``scan`` or io ``update`` method once on start up"""
