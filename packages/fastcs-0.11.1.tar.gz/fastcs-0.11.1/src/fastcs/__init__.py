"""Top level API.

.. data:: __version__
    :type: str

    Version number as calculated by https://github.com/pypa/setuptools_scm
"""

from ._version import __version__ as __version__
from .control_system import FastCS as FastCS
from .launch import launch as launch
from .util import ONCE as ONCE
