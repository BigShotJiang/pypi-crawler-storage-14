from fastcs.controllers import Controller


class TemperatureController(Controller):
    pass
