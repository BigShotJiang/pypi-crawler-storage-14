from setuptools import setup, find_packages

setup(
    name="verge_auth",
    version="1.1.0",
    packages=find_packages(),
    install_requires=[
        "fastapi",
        "httpx",
        "python-dotenv",
    ],
)
