:mod:`samplerate.exceptions` -- Sample rate exceptions
======================================================
.. module:: samplerate.exceptions

.. autoclass:: ResamplingError
    :members:
    :undoc-members: