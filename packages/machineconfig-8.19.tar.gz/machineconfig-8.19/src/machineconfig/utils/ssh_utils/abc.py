

MACHINECONFIG_VERSION = "machineconfig>=8.19"
DEFAULT_PICKLE_SUBDIR = "tmp_results/tmp_scripts/ssh"

