"""exceptions"""


class DataNotFoundError(Exception):
    """Data Not Found Error"""

    pass
