def test_bardata_import():
    """Test bardata import"""
    import bardata
    assert bardata

