# create_color.py

# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

from pathlib import Path
from copy import deepcopy
from .palettes_homologous import palette_homologous, homologous_color_rule
from .palettes_triadic import palette_triadic, triadic_color_rule
from .palettes_tetradic import palette_tetradic, tetradic_color_rule

# -------------------------
# Element Families
# -------------------------
BLOCK_ELEMENTS = {
    "standard": ["div", "section", "article", "main", "aside", "button", "form", "ul", "li"],
    "header": ["header", "nav"],
    "footer": ["footer"]
}

HEADING_ELEMENTS = ["h1", "h2", "h3", "h4", "h5", "h6"]
TEXT_ELEMENTS = ["p", "span", "a", "label", "strong", "em"]
VOID_ELEMENTS = ["img", "input", "hr", "meta", "link", "source", "embed",
                 "param", "track", "wbr", "area", "base", "col", "br"]
MEDIA_ELEMENTS = ["video", "audio", "picture", "object"]

# --- ABSTRACT RULE KEY MAPPING TO REAL HTML TAGS ---
# Maps the abstract keys used in the color rules (e.g., "HEADER") to concrete HTML tags.
FAMILY_MAP = {
    "BODY": ["body"],
    "STANDARD": BLOCK_ELEMENTS["standard"], 
    "HEADER": BLOCK_ELEMENTS["header"],
    "FOOTER": BLOCK_ELEMENTS["footer"],
}

# --- DEFAULT TAG RULES FOR NON-BLOCK ELEMENTS ---
# Used to assign default colors to text elements based on semantic role (e.g., text/heading).
DEFAULT_TAG_MAP = {
    "HEADING": HEADING_ELEMENTS, 
    "TEXT": TEXT_ELEMENTS,
    "MEDIA_VOID": MEDIA_ELEMENTS + VOID_ELEMENTS
}

# -------------------------
# CreateColor Class
# -------------------------
class CreateColor:
    """
    Applies colors to an existing style.css based on a chosen palette and rule.
    It resolves semantic color roles and only fills color properties for existing selectors.
    """

    PALETTES = {
        "homologous": palette_homologous,
        "triadic": palette_triadic,
        "tetradic": palette_tetradic,
    }

    RULES = {
        "homologous": homologous_color_rule,
        "triadic": triadic_color_rule,
        "tetradic": tetradic_color_rule,
    }

    def __init__(self, family="homologous", color_name=None):
        if family not in self.PALETTES:
            raise ValueError(f"family '{family}' not supported")
        if color_name is None or color_name not in self.PALETTES[family]:
            raise ValueError(f"color_name '{color_name}' not found in {family} palette")

        self.family = family
        self.color_name = color_name
        # Selected color set (e.g., all reds)
        self.palette_colors = self.PALETTES[family][color_name] 
        # Full palette access (e.g., for 'white' or 'black' references)
        self.full_palette = self.PALETTES[family] 
        self.rule = deepcopy(self.RULES[family])
        
        self.css_path = Path("style.css")

        if not self.css_path.exists():
            raise FileNotFoundError(f"⚠ style.css not found at: {self.css_path}")

        self.css_content = self.css_path.read_text()
        # Generate the flat map of {tag: {bg, text}} rules immediately
        self.flat_rules = self._get_rules_flat() 
        self._apply_colors()


    # -----------------------------------------
    # Rule Resolution Methods
    # -----------------------------------------
    def _resolve_color(self, role_str):
        """
        Interprets semantic color strings like 'principal' or 'white.secondary'.
        Returns the resolved hexadecimal color code or None if not found.
        
        Requires the rule structure to use 'bg_role' and 'text_role' keys 
        instead of direct 'bg' and 'text' hex codes.
        """
        if not role_str:
            return None
        
        if "." in role_str:
            # External reference: "palette_name.role" (e.g., "white.principal")
            p_name, c_role = role_str.split(".")
            if p_name in self.full_palette:
                return self.full_palette[p_name].get(c_role, None) 
            return None 
        else:
            # Local reference: "role" (e.g., "principal" from the selected color_name)
            return self.palette_colors.get(role_str, None)


    def _get_rules_flat(self):
        """
        Converts the hierarchical rule into a flat dictionary of {html_tag: {bg: color, text: color}}.
        Ensures all key HTML tags have a rule, even if default.
        """
        flat_rules = {} 
        r_body = self.rule.get("body", {})

        # 1. Rule for the <body> tag
        flat_rules["body"] = {
            "bg": self._resolve_color(r_body.get("bg_role")),
            "text": self._resolve_color(r_body.get("text_role"))
        }

        # 2. Apply explicit structural rules (HEADER, FOOTER, STANDARD)
        children = r_body.get("children", {})
        
        for abstract_key, child_rule in children.items():
            if abstract_key in FAMILY_MAP:
                bg = self._resolve_color(child_rule.get("bg_role"))
                text = self._resolve_color(child_rule.get("text_role"))
                
                real_tags = FAMILY_MAP[abstract_key]
                
                # Apply the rule to all mapped concrete tags
                for tag in real_tags:
                    # Overwrite existing if colors are defined
                    if bg or text:
                        flat_rules[tag] = {"bg": bg, "text": text}
        
        # 3. Apply default text rules for non-block elements (H1-H6, P, etc.)
        
        # HEADING_ELEMENTS (Typically 'principal' text color)
        default_heading_color = self._resolve_color("principal")
        for tag in DEFAULT_TAG_MAP["HEADING"]:
            if tag not in flat_rules:
                flat_rules[tag] = {"bg": None, "text": default_heading_color}
                
        # TEXT_ELEMENTS (Typically 'secondary' text color)
        default_text_color = self._resolve_color("secondary")
        for tag in DEFAULT_TAG_MAP["TEXT"]:
            if tag not in flat_rules:
                flat_rules[tag] = {"bg": None, "text": default_text_color}
                
        # MEDIA/VOID elements get secondary color by default, if needed
        for tag in DEFAULT_TAG_MAP["MEDIA_VOID"]:
            if tag not in flat_rules:
                flat_rules[tag] = {"bg": None, "text": default_text_color}
                
        return flat_rules


    # -----------------------------------------
    # Main function to apply colors to CSS
    # -----------------------------------------
    # -----------------------------------------
    # Main function to apply colors to CSS
    def _apply_colors(self):
        
        final_lines = []
        is_in_selector = False
        current_tag = None
        
        for line in self.css_content.splitlines():
            stripped = line.strip()
            
            # 1. Detect Selector Start
            if stripped.endswith("{"):
                selector_str = stripped[:-1].strip()
                final_lines.append(line)
                
                # --- LOGIC FOR RULE LOOKUP AND CONTRAST CONTROL ---
                rules = None
                apply_bg = True # Flag para aplicar background
                selector_parts = selector_str.split()
                
                if len(selector_parts) == 1 and selector_str.startswith("#"):
                    # Caso 1: Selector ID Puro (e.g., #main)
                    # Lo tratamos como un bloque STANDARD ('div') y aplicamos colores completos.
                    rules = self.flat_rules.get("div") 
                    
                elif len(selector_parts) > 1 and selector_str.startswith("#"):
                    # Caso 2: Selector de Cascada con ID (e.g., #papa > div, #papa p)
                    # El padre ya tiene background. El hijo SÓLO necesita color de texto contrastante.
                    apply_bg = False # NO aplicar background al hijo en cascada.
                    
                    # Usar la etiqueta del último elemento en el selector (el objetivo).
                    last_part = selector_parts[-1]
                    # Limpiar la etiqueta de clases, ID y pseudo-selectores
                    parts = last_part.split(".")[0].split("#")[0]
                    clean_tag = parts.split(":")[0] 
                    
                    rules = self.flat_rules.get(clean_tag)
                    
                else:
                    # Caso 3: Selector Simple (tag, .class, etc.)
                    last_part = selector_parts[-1]
                    parts = last_part.split(".")[0].split("#")[0]
                    clean_tag = parts.split(":")[0] 
                    rules = self.flat_rules.get(clean_tag)
                
                # --- END LOGIC ---

                if rules:
                    bg = rules.get("bg")
                    text = rules.get("text")
                    
                    css_props = []
                    # Aplicar background SÓLO si apply_bg es True
                    if bg and apply_bg: 
                        css_props.append(f"background: {bg};") 
                    
                    # Aplicar color de texto siempre si está definido
                    if text:
                        css_props.append(f"color: {text};")
                        
                    if css_props:
                        is_in_selector = True
                        current_tag = clean_tag
                        
                        # Inyectar las propiedades justo después de la llave de apertura
                        indent = line.find(stripped) 
                        
                        for prop in css_props:
                            final_lines.append(f"{' ' * (indent + 4)}{prop}") 
                        
                continue 

            # 2. Inside a Selector Block
            if is_in_selector:
                if stripped.startswith("}"):
                    is_in_selector = False
                    current_tag = None
                    final_lines.append(line)
                    continue 
                
                if "/* styles here */" in line:
                    # Quitar el placeholder de CSSRegistry
                    continue
                
                final_lines.append(line)
                
            # 3. Outside any Selector Block (Normal Line)
            else:
                final_lines.append(line)

        self.css_path.write_text("\n".join(final_lines))
        print(f"🎨 Colors applied using {self.family} palette and base color '{self.color_name}'.")