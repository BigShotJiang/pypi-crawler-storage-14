# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.


# palettes_tetradic.py



# Paleta de colores tetrádicos
palette_tetradic = {
    # REDS
    "red_pure":    {"principal": "#FF0000", "secondary": "#00FF00", "tertiary": "#0000FF", "quaternary": "#FFFF00"},
    "red_dark":    {"principal": "#990000", "secondary": "#009900", "tertiary": "#000099", "quaternary": "#999900"},
    "red_pink":    {"principal": "#FF66CC", "secondary": "#66FF99", "tertiary": "#9966FF", "quaternary": "#FFCC66"},
    "coral":       {"principal": "#FF7F50", "secondary": "#50FF7F", "tertiary": "#7F50FF", "quaternary": "#FFFF50"},
    "tomato":      {"principal": "#FF6347", "secondary": "#47FF63", "tertiary": "#6347FF", "quaternary": "#FFFF63"},

    # BLUES
    "blue_pure":   {"principal": "#0000FF", "secondary": "#FF0000", "tertiary": "#00FF00", "quaternary": "#FFFF00"},
    "blue_medium": {"principal": "#0000CC", "secondary": "#CC0000", "tertiary": "#00CC00", "quaternary": "#CCCC00"},
    "aqua":        {"principal": "#00FFFF", "secondary": "#FF00FF", "tertiary": "#FFFF00", "quaternary": "#00FF00"},
    "cyan":        {"principal": "#00CED1", "secondary": "#D100CD", "tertiary": "#CDCD00", "quaternary": "#00D1CD"},
    "sky_blue":    {"principal": "#87CEEB", "secondary": "#EB87CE", "tertiary": "#CEEB87", "quaternary": "#EBCF87"},

    # GREENS
    "green_pure":  {"principal": "#00FF00", "secondary": "#0000FF", "tertiary": "#FF0000", "quaternary": "#FFFF00"},
    "green_light": {"principal": "#90EE90", "secondary": "#9090EE", "tertiary": "#EE9090", "quaternary": "#EEEE90"},
    "green_dark":  {"principal": "#006400", "secondary": "#000064", "tertiary": "#640000", "quaternary": "#646400"},
    "lime":        {"principal": "#32CD32", "secondary": "#3131CD", "tertiary": "#CD3131", "quaternary": "#CDCD31"},
    "sea_green":   {"principal": "#2E8B57", "secondary": "#562E8A", "tertiary": "#8A572E", "quaternary": "#8A8A2E"},

    # YELLOWS
    "yellow":      {"principal": "#FFFF00", "secondary": "#FF0000", "tertiary": "#00FF00", "quaternary": "#0000FF"},
    "golden":      {"principal": "#FFD700", "secondary": "#00FFD7", "tertiary": "#D600FF", "quaternary": "#FF6D00"},
    "light_yellow":{"principal": "#FFFFE0", "secondary": "#E0FFFF", "tertiary": "#FEE0FF", "quaternary": "#FFE0FE"},
    "lemon":       {"principal": "#FFF44F", "secondary": "#4FFEF4", "tertiary": "#F34FFE", "quaternary": "#F4FF4F"},

    # ORANGES
    "orange":      {"principal": "#FFA500", "secondary": "#00FFA5", "tertiary": "#A400FF", "quaternary": "#FF00A4"},
    "dark_orange": {"principal": "#FF8C00", "secondary": "#00FF8C", "tertiary": "#8B00FF", "quaternary": "#FF008B"},
    "peach":       {"principal": "#FFE5B4", "secondary": "#B4FFE5", "tertiary": "#E4B4FF", "quaternary": "#FFB4E4"},
    "tangerine":   {"principal": "#F28500", "secondary": "#00F285", "tertiary": "#8400F2", "quaternary": "#F20084"},

    # VIOLETS
    "violet":      {"principal": "#8A2BE2", "secondary": "#E2892B", "tertiary": "#2BE289", "quaternary": "#89E22B"},
    "lilac":       {"principal": "#C8A2C8", "secondary": "#C7C8A1", "tertiary": "#A1C7C8", "quaternary": "#A2C8A1"},
    "purple":      {"principal": "#800080", "secondary": "#7F8000", "tertiary": "#007F80", "quaternary": "#808000"},
    "orchid":      {"principal": "#DA70D6", "secondary": "#D6DA6F", "tertiary": "#6FD6DA", "quaternary": "#DA6FDA"},

    # NEUTRALS
    "white":       {"principal": "#FFFFFF", "secondary": "#FFFFFF", "tertiary": "#FFFFFF", "quaternary": "#FFFFFF"},
    "black":       {"principal": "#000000", "secondary": "#000000", "tertiary": "#000000", "quaternary": "#000000"},
    "light_gray":  {"principal": "#D3D3D3", "secondary": "#D3D3D3", "tertiary": "#D3D3D3", "quaternary": "#D3D3D3"},
    "dark_gray":   {"principal": "#A9A9A9", "secondary": "#A9A9A9", "tertiary": "#A9A9A9", "quaternary": "#A9A9A9"},
    "beige":       {"principal": "#F5F5DC", "secondary": "#F5F5DC", "tertiary": "#F5F5DC", "quaternary": "#F5F5DC"},
    "silver":      {"principal": "#C0C0C0", "secondary": "#C0C0C0", "tertiary": "#C0C0C0", "quaternary": "#C0C0C0"},
}
# tetradic_color_rule actualizado para usar familias en mayúsculas
# Utiliza los cuatro colores de forma balanceada. El 'quaternary' se reserva para acentos.
tetradic_color_rule = {
    "body": {
        "bg_role": "white.principal", 
        "text_role": "black.principal",
        "children": {
            # 1. HEADER (Usa el color dominante 'principal')
            "HEADER": {
                "bg_role": "principal", 
                "text_role": "white.principal",
                "children": {
                    # Hijos inmediatos (ej: nav links) usan el color de acento 'quaternary'
                    "*": {
                        "bg_role": "quaternary",
                        "text_role": "black.principal"
                    }
                }
            },
            
            # 2. FOOTER (Usa el color 'secondary' para distinguirse del header)
            "FOOTER": {
                "bg_role": "secondary",
                "text_role": "white.principal",
                "children": {
                    # Hijos usan el color 'tertiary'
                    "*": {
                        "bg_role": "tertiary",
                        "text_role": "white.principal"
                    }
                }
            },
            
            # 3. STANDARD (Contenido principal. Blanco base.)
            "STANDARD": {
                "bg_role": "white.principal",
                "text_role": "black.principal",
                "children": {
                    # ARTICLE (Usa el color 'tertiary' para bloques de contenido)
                    "ARTICLE": {
                        "bg_role": "tertiary",
                        "text_role": "black.principal",
                        "children": {
                            # Botones y elementos de acción (usa el color de acento 'quaternary')
                            "button": {
                                "bg_role": "quaternary",
                                "text_role": "black.principal"
                            },
                            # Comodín para otros hijos dentro del artículo
                            "*": {
                                "bg_role": "white.secondary",
                                "text_role": "black.principal"
                            }
                        }
                    },
                    
                    # Comodín para otros bloques hijos (divs, sections)
                    "*": {
                        "bg_role": "light_gray.principal", # Gris claro para un contraste sutil
                        "text_role": "black.principal"
                    }
                }
            }
        }
    }
}


# ----------------------------------------------------
# FUNCIONES DE UTILIDAD CORREGIDAS
# ----------------------------------------------------

def get_color_for_tag(tag_path: list, base_color_name: str = "red_pure", rule=None):
    """
    Devuelve un dict {'bg': hex_color, 'text': hex_color} para cualquier tag_path.
    Resuelve los roles semánticos (bg_role, text_role) usando la paleta tetradic.

    - tag_path: lista de tags desde 'body' hasta el tag objetivo, ej: ['body', 'main', 'section', 'p']
    - base_color_name: El grupo de paleta elegido por el usuario (ej: "blue_pure").
    - rule: La regla a usar (por defecto usa tetradic_color_rule).
    """
    from copy import deepcopy
    if rule is None:
        rule = deepcopy(tetradic_color_rule)

    current = rule
    bg_role, text_role = None, None

    for i, tag in enumerate(tag_path):
        # 1. Buscamos el tag exacto
        if "children" in current and tag in current["children"]:
            current = current["children"][tag]
        # 2. Si no es el tag exacto, usamos el comodín "*" (si existe)
        elif "children" in current and "*" in current["children"]:
            current = current["children"]["*"]
        else:
            break

        # Actualizamos los roles semánticos si están definidos en este nivel
        bg_role = current.get("bg_role", bg_role)
        text_role = current.get("text_role", text_role)

    # --------------------------------------------------
    # LÓGICA DE RESOLUCIÓN DE COLOR
    # --------------------------------------------------
    
    current_colors = palette_tetradic.get(base_color_name)
    
    # Función local para resolver un rol semántico a un hex code
    def _local_resolve(role_str, current_colors):
        if not role_str: return None
        
        if "." in role_str:
            # Referencia externa (ej: "white.principal")
            p_name, c_role = role_str.split(".")
            # Busca en la paleta externa (ej: 'white' dentro de palette_tetradic)
            return palette_tetradic.get(p_name, {}).get(c_role, None)
        else:
            # Referencia local (ej: "principal", "quaternary"). Busca en la paleta base del usuario.
            return current_colors.get(role_str, None)

    # Si no se encontró el color base, usamos blanco/negro como fallback
    if not current_colors:
        resolved_bg = "#FFFFFF"
        resolved_text = "#000000"
    else:
        resolved_bg = _local_resolve(bg_role, current_colors)
        resolved_text = _local_resolve(text_role, current_colors)

    # Fallback si no se definió ningún rol, usar blanco/negro
    resolved_bg = resolved_bg or palette_tetradic["white"]["principal"]
    resolved_text = resolved_text or palette_tetradic["black"]["principal"]

    return {"bg": resolved_bg, "text": resolved_text}
