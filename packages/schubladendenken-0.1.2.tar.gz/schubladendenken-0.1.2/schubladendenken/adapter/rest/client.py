
from importlib.resources import files

from jinja2 import Template

from schubladendenken.core.label import Label
from schubladendenken.core.subject import Subject

class APIClient:
    def __init__(
            self,
            template: str = "image_review.html",
            root: str = "",
            custom_css: set[str] | None = None
    ):
        self._custom_css: set[str] = custom_css or set()
        self._root: str = root
        self._template: Template = Template(
            files("schubladendenken").joinpath("adapter", "rest", "templates", template).read_text(encoding="utf-8")
        )

    @property
    def root_path(self) -> str:
        return self._root

    def serve(self, subject: Subject, label: Label):
        return self._template.render(subject=subject, label=label, custom_css=self._custom_css, root=self._root)


