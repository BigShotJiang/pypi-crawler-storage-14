"""
Sufi AI - Unlimited Free LLM Chat
"""

__version__ = "1.0.1"

import requests

_API_KEY = "SufiLLM-33990wAGjPP6PpdPm2iApi"
_BASE_URL = "https://sufi-api-llm.vercel.app"

def chat(prompt, model="sufi-o1-fast"):
    try:
        response = requests.post(
            f"{_BASE_URL}/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}]
            },
            timeout=30
        )
        
        if response.status_code != 200:
            return f"Error: API call failed ({response.status_code})"
        
        return response.json()["choices"][0]["message"]["content"]
    
    except Exception as e:
        return f"Error: {str(e)}"

class Models:
    FAST = "sufi-o1-fast"
    PRO = "sufi-o1-pro"
    MINI = "sufi-mini"

__all__ = ['chat', 'Models']