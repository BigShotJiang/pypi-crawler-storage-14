from riocli.model.base import Model as Model
