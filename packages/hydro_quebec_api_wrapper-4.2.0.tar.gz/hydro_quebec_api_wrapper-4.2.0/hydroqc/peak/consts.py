"""Constants module for peaks."""

DEFAULT_PRE_HEAT_DURATION = 180
