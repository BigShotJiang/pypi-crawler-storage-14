"""Interactive quiz implementations covering vocab, kanji, and audio modes."""
