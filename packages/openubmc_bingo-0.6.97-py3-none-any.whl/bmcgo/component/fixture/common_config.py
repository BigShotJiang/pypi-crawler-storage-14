#!/usr/bin/env python3
# coding: utf-8
# Copyright (c) 2024 Huawei Technologies Co., Ltd.
# openUBMC is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
class CommonConfig:
    PROJECT_PATH = '/opt/code/BMCITFramework'
    BMC_TEST_DB_NAME = 'network_adapter_y'
    BMC_TEST_DB_PATH = f'{PROJECT_PATH}/bmc_test_db/'

    DBUS_META_JSON_PATH = f'{BMC_TEST_DB_PATH}/dbus_dump_bmc.json'
    GENERATED_STUBS_PATH = f'{PROJECT_PATH}/src/generated_stubs'
    METADATA_DIR = f'{BMC_TEST_DB_PATH}/{BMC_TEST_DB_NAME}/metadata'
    # 新增：公共桩目录
    DBUS_META_FILE_NAME = 'dbus_dump_bmc.json'
    DBUS_MOCK_DATA_FILE_NAME = 'mock_data.json'
    DBUS_SIGNAL_FILE_NAME = 'dbus_signal.json'
    TEST_DATA_FILE = 'test_data.json'
    DEFAULT_DBUS_ADDRESS = 'unix:path=/tmp/dbus-DF0jG0TVDB,guid=be15f429f8d74a50841548f368b7a6b2'

    # 组件自定义打桩目录（使用前设置）
    dbus_default_mock_path = f'{BMC_TEST_DB_PATH}/{BMC_TEST_DB_NAME}/mock_data'
