import json
import csv
import os
import unicodedata

# 读取idiom.json文件
def read_json_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

# 移除拼音中的声调
def remove_pinyin_tones(pinyin_str):
    # 将带声调的拼音转换为不带声调的
    normalized = unicodedata.normalize('NFKD', pinyin_str)
    return ''.join([c for c in normalized if not unicodedata.combining(c)])

# 计算额外字段（不包括next_count）
def calculate_basic_fields(idiom):
    word = idiom.get('word', '')
    pinyin = idiom.get('pinyin', '')
    
    # 计算首字和末字
    head_word = word[0] if word else ''
    end_word = word[-1] if word else ''
    
    # 计算首字拼音和末字拼音
    pinyin_list = pinyin.split()
    head_pinyin = pinyin_list[0] if pinyin_list else ''
    end_pinyin = pinyin_list[-1] if pinyin_list else ''
    
    # 计算首字拼音无音调版本和末字拼音无音调版本
    head_pinyin_without_tone = remove_pinyin_tones(head_pinyin) if head_pinyin else ''
    end_pinyin_without_tone = remove_pinyin_tones(end_pinyin) if end_pinyin else ''
    
    # 计算首字组合和末字组合
    head_combi = f"('{head_word}', '{head_pinyin}')"
    end_combi = f"('{end_word}', '{end_pinyin}')"
    
    # 计算拼音字母（空格分隔，不带声调）
    letter_list = [remove_pinyin_tones(p) for p in pinyin_list]
    letter = ' '.join(letter_list) if letter_list else ''
    
    return {
        'head_pinyin': head_pinyin,
        'end_pinyin': end_pinyin,
        'head_pinyin_without_tone': head_pinyin_without_tone,
        'end_pinyin_without_tone': end_pinyin_without_tone,
        'head_word': head_word,
        'end_word': end_word,
        'head_combi': head_combi,
        'end_combi': end_combi,
        'letter': letter
    }

# 统计每个首字拼音出现的次数（基于拼音匹配）
def count_head_pinyin_frequency(idioms_with_fields):
    frequency = {}
    for idiom_data in idioms_with_fields:
        head_pinyin = idiom_data['basic_fields']['head_pinyin']
        if head_pinyin:
            frequency[head_pinyin] = frequency.get(head_pinyin, 0) + 1
    return frequency

# 统计每个首字拼音（无音调）出现的次数（基于无音调拼音匹配）
def count_head_pinyin_without_tone_frequency(idioms_with_fields):
    frequency = {}
    for idiom_data in idioms_with_fields:
        head_pinyin_without_tone = idiom_data['basic_fields']['head_pinyin_without_tone']
        if head_pinyin_without_tone:
            frequency[head_pinyin_without_tone] = frequency.get(head_pinyin_without_tone, 0) + 1
    return frequency

# 将JSON数据转换为CSV
def convert_json_to_csv(json_file_path, csv_output_path):
    # 读取JSON数据
    idioms = read_json_file(json_file_path)
    
    # 定义CSV字段名（匹配原始文件的字段顺序，添加新字段）
    fieldnames = [
        '',  # 空字段（对应CSV中的第一列）
        'abbreviation',
        'derivation',
        'example',
        'explanation',
        'pinyin',
        'word',
        'head_pinyin',
        'end_pinyin',
        'head_pinyin_without_tone',
        'end_pinyin_without_tone',
        'head_word',
        'end_word',
        'head_combi',
        'end_combi',
        'next_count',
        'next_count_without_tone',
        'letter'
    ]
    
    # 计算所有成语的基本字段
    idioms_with_fields = []
    for idiom in idioms:
        basic_fields = calculate_basic_fields(idiom)
        idioms_with_fields.append({
            'original': idiom,
            'basic_fields': basic_fields
        })
    
    # 统计每个首字拼音出现的次数（有声调）
    head_pinyin_frequency = count_head_pinyin_frequency(idioms_with_fields)
    
    # 统计每个首字拼音（无音调）出现的次数
    head_pinyin_without_tone_frequency = count_head_pinyin_without_tone_frequency(idioms_with_fields)
    
    # 确保输出目录存在
    os.makedirs(os.path.dirname(csv_output_path), exist_ok=True)
    
    # 写入CSV文件
    with open(csv_output_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        # 写入表头
        writer.writeheader()
        
        # 写入数据行
        for i, idiom_data in enumerate(idioms_with_fields, start=1):
            idiom = idiom_data['original']
            basic_fields = idiom_data['basic_fields']
            
            # 计算next_count：统计有多少个成语的首字拼音与当前成语的末字拼音相同（基于拼音匹配，有声调）
            end_pinyin = basic_fields['end_pinyin']
            next_count = head_pinyin_frequency.get(end_pinyin, 0)
            
            # 计算next_count_without_tone：统计有多少个成语的首字拼音（无音调）与当前成语的末字拼音（无音调）相同（基于无音调拼音匹配）
            end_pinyin_without_tone = basic_fields['end_pinyin_without_tone']
            next_count_without_tone = head_pinyin_without_tone_frequency.get(end_pinyin_without_tone, 0)
            
            # 构建CSV行数据
            row = {
                '': i,  # 序号
                'abbreviation': idiom.get('abbreviation', ''),
                'derivation': idiom.get('derivation', ''),
                'example': idiom.get('example', ''),
                'explanation': idiom.get('explanation', ''),
                'pinyin': idiom.get('pinyin', ''),
                'word': idiom.get('word', ''),
                'next_count': next_count,
                'next_count_without_tone': next_count_without_tone,
                **basic_fields  # 合并基本字段
            }
            
            writer.writerow(row)
    
    print(f"转换完成！CSV文件已保存到: {csv_output_path}")

# 主函数
def main():
    current_dir = os.path.abspath(os.path.dirname(__file__))
    json_file_path = os.path.join(current_dir, 'idiom.json')
    csv_output_path = os.path.join(current_dir, 'idiom.csv')
    
    # 转换JSON到CSV
    convert_json_to_csv(json_file_path, csv_output_path)

if __name__ == "__main__":
    main()