# LinkBay-Roles

**Version**: 0.1.0  
**License**: Proprietary  
**Python**: 3.8+

Layer di autorizzazione per l'ecosistema LinkBay: combina RBAC e ABAC in chiave multi-tenant, con protocolli estendibili, servizi async e guard per FastAPI. Pensato per integrarsi con `LinkBay-Auth`, `LinkBay-Audit`, `LinkBay-Billing` e gli altri moduli della piattaforma.

## Principali capacita

- RBAC multi-tenant con gerarchie di ruolo (`staff < manager < admin < owner`) e wildcard permission (`orders:*`, `*`).
- ABAC e policy engine con condizioni su attributi utente, contesto richiesta, finestre temporali e priorita.
- Protocoli `UserDirectory`, `RolesProvider`, `PoliciesProvider`, `AuditLogger` per integrazioni storage agnostiche.
- Servizi `UserService`, `RoleService`, `PermissionService`, `PolicyEngine` con hook di audit opzionali.
- Guard FastAPI (`require_permission`, `require_role`, `require_policy`) e router REST (`create_roles_router`) pronti all'uso.
- Eventi di audit per ogni cambio ruolo o permesso, integrabili con LinkBay-Audit.

## Indice

- [Requisiti](#requisiti)
- [Architettura e componenti](#architettura-e-componenti)
- [Modello di autorizzazione](#modello-di-autorizzazione)
- [Quick start](#quick-start)
- [Ricette d'uso](#ricette-duso)
- [FastAPI integration](#fastapi-integration)
- [Security & audit](#security--audit)
- [FAQ](#faq)
- [Troubleshooting](#troubleshooting)
- [Supporto e licenza](#supporto-e-licenza)

## Requisiti

| Requisito | Dettagli |
| --- | --- |
| Python | 3.8 o superiore |
| Dipendenze core | `pydantic>=2.0.0` |
| Extra opzionali | `linkbay-roles[fastapi]` abilita guard e router |
| Storage suggeriti | PostgreSQL + JSONB, MongoDB, DynamoDB, qualsiasi KV o document store |
| Ecosistema | Usa `LinkBay-Auth` per identity, `LinkBay-Audit` per logging, `LinkBay-Org` per gerarchie |

## Architettura e componenti

La libreria espone solo protocolli, cosi puoi scegliere storage e identity provider senza lock-in:

- `UserDirectory`: CRUD utenti, assegnazione ruoli, filtri per attributi custom e rimozione isolata per tenant.
- `RolesProvider`: CRUD ruoli e permessi, gestione wildcard, grant diretti utente, numeri di livello tramite `ROLE_HIERARCHY`.
- `PoliciesProvider`: policy ABAC con `subject_type` (user/role), effetto allow/deny, priorita e condizioni serializzate.
- `AuditLogger`: integrazione verso LinkBay-Audit o qualsiasi event sink per tenere traccia delle decisioni di autorizzazione.

I servizi applicativi incapsulano la logica:

- `UserService`: onboarding utenti, aggiornamenti, attribuzione e revoca ruoli.
- `RoleService`: gestione ruoli, permessi e gerarchie; usa `DEFAULT_ROLE_PERMISSIONS` come preset.
- `PermissionService`: verifica permessi con supporto wildcard, grant diretti e audit automatico.
- `PolicyEngine`: valuta policy ABAC combinando condizioni su attributi e contesto runtime.

## Modello di autorizzazione

- **Tenant-first**: ogni API richiede `tenant_id`; un utente puo avere ruoli differenti su tenant diversi senza interferenze.
- **RBAC**: ruoli gerarchici (guest, customer, staff, manager, admin, owner) con permessi predefiniti, estendibili via API.
- **Direct grants**: aggiungi permessi puntuali a un utente per eccezioni operative senza creare ruoli ad hoc.
- **ABAC**: policy allow/deny valutate in ordine di priorita; ogni policy usa condizioni su attributi (`department`, `plan`), time range, liste o espressioni Python sandboxed.
- **Audit trail**: ogni assegnazione ruolo, grant permesso e valutazione policy puo essere loggata tramite `AuditLogger`.

## Quick start

### 1. Implementa gli adapter

```python
from linkbay_roles import UserDirectory, RolesProvider, PoliciesProvider

class PostgresRolesProvider(RolesProvider):
    async def create_role(self, tenant_id: str, role_data: dict) -> dict:
        row = await db.fetchrow(
            """
            INSERT INTO roles (tenant_id, name, label, level, permissions)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
            """,
            tenant_id,
            role_data["name"],
            role_data.get("label"),
            role_data.get("level", 0),
            role_data.get("default_permissions", []),
        )
        return dict(row)
    # implementa gli altri metodi: get_role, list_roles, grant_permission_to_role, ...
```

### 2. Istanzia i servizi

```python
from linkbay_roles import UserService, RoleService, PermissionService, PolicyEngine
from linkbay_roles.constants import DEFAULT_ROLE_PERMISSIONS, ROLE_HIERARCHY

user_directory = PostgresUserDirectory(db)
roles_provider = PostgresRolesProvider(db)
policies_provider = PostgresPoliciesProvider(db)
audit_logger = LinkBayAuditLogger(client=audit_client)

user_service = UserService(user_directory, audit_logger=audit_logger)
role_service = RoleService(roles_provider, audit_logger=audit_logger)
permission_service = PermissionService(roles_provider, user_directory, audit_logger=audit_logger)
policy_engine = PolicyEngine(policies_provider, user_directory, audit_logger=audit_logger)
```

### 3. Assegna ruoli, crea policy e controlla permessi

```python
from linkbay_roles import RoleCreate, UserCreate, PolicyCreate, PolicyCondition

await role_service.create_role(
    tenant_id="tenant_123",
    role_data=RoleCreate(
        name="manager",
        label="Store Manager",
        level=ROLE_HIERARCHY["manager"],
        default_permissions=["orders:view", "orders:edit", "users:view"],
    ),
)

user = await user_service.create_user(
    tenant_id="tenant_123",
    user_data=UserCreate(
        email="lisa@example.com",
        name="Lisa",
        roles=["manager"],
        attributes={"department": "sales", "region": "emea"},
    ),
)

await permission_service.grant_permission_to_user(
    tenant_id="tenant_123",
    user_id=user.id,
    permission_code="reports:download",
)

policy = await policy_engine.create_policy(
    tenant_id="tenant_123",
    policy_data=PolicyCreate(
        subject_type="role",
        subject_id="manager",
        action="orders:approve",
        resource="orders",
        effect="allow",
        priority=100,
        conditions=[
            PolicyCondition(type="attribute_match", field="department", operator="eq", value="sales"),
            PolicyCondition(type="time_range", value={"start": "08:00", "end": "20:00"}),
        ],
    ),
)

check = await permission_service.check_permission(
    tenant_id="tenant_123",
    user_id=user.id,
    action="orders:edit",
)
assert check.allowed is True
```

## Ricette d'uso

- **Customer support impersonation**: usa un grant diretto `accounts:impersonate` limitato nel tempo e loggalo su LinkBay-Audit.
- **Tenant admin bootstrap**: al provisioning crea il ruolo `owner` e assegna `*` all'utente che ha sottoscritto il tenant.
- **Regional policy**: blocca accesso a risorse fuori regione con policy `deny` prioritaria basata sull'attributo `region`.
- **Maintenance mode**: inserisci una policy `deny` con condizione su `context["maintenance"]` per bloccare operazioni critiche durante gli upgrade.

## FastAPI integration

```python
from fastapi import Depends, FastAPI
from linkbay_roles import create_roles_router, PermissionService
from linkbay_roles.guards import require_permission, get_current_user, get_tenant_id

app = FastAPI()

roles_router = create_roles_router(
    user_service_dep=Depends(lambda: user_service),
    role_service_dep=Depends(lambda: role_service),
    permission_service_dep=Depends(lambda: permission_service),
    policy_engine_dep=Depends(lambda: policy_engine),
    tenant_id_dep=Depends(get_tenant_id),
    current_user_dep=Depends(get_current_user),
)

app.include_router(roles_router, prefix="/api/roles")

@app.get("/api/{tenant_id}/orders")
@require_permission("orders:view")
async def list_orders(
    tenant_id: str,
    user_id: str = Depends(get_current_user),
    permission_service: PermissionService = Depends(lambda: permission_service),
):
    return await orders_repo.list_orders(tenant_id)
```

## Security & audit

- Collega `AuditLogger` a `LinkBay-Audit` per registrare creazioni, grant, revoche e valutazioni policy.
- Proteggi tabelle ruoli e permessi con cifratura a riposo e controlli RLS per isolare i tenant.
- Abilita alert quando vengono concessi permessi `*` o ruoli di livello alto tramite integrazione con LinkBay-Notifications.
- Proteggi gli endpoint fiscalmente sensibili di LinkBay-Billing vincolandoli a `require_permission("billing:issue_invoice")` o policy ABAC.

## FAQ

**Come gestisco ruoli globali o system?**  
Crea un tenant speciale (per esempio `system`) e usa `PermissionScope.SYSTEM`; gli utenti possono avere ruoli multipli tra tenant differenti.

**Come faccio a usare JWT invece degli header X-User-ID/X-Tenant-ID?**  
Sostituisci `get_current_user` e `get_tenant_id` in `guards.py` con dependency custom che estraggono i claim dal token.

**Come risolvo conflitti tra RBAC e ABAC?**  
Esegui i controlli RBAC con `require_permission` e usa `require_policy` per le decisioni context-based; imposta priorita nelle policy in modo che i `deny` critici abbiano precedenza.

## Troubleshooting

- **403 inatteso**: verifica che la route fornisca `tenant_id`, `user_id` e `permission_service` alla guard, altrimenti viene restituito 500.
- **Policy ignorata**: assicurati che `context` includa i campi richiesti (per esempio `department`, `current_time`) e che la policy sia `active=True`.
- **FastAPI non installato**: aggiungi gli extra con `pip install linkbay-roles[fastapi]`.

## Supporto e licenza

- Supporto: quagliara.alessio@gmail.com  
- Repository: https://github.com/AlessioQuagliara/LinkBay-Py  
- Issue tracker: apri ticket nella cartella `LinkBay-Roles`
- Licenza: Proprietary (c) 2025 Alessio Quagliara

> Questa libreria non sostituisce una revisione legale o compliance. Confrontati con il tuo team sicurezza prima della messa in produzione.
