"""
Custom exceptions for roles and permissions.
"""


class RolesError(Exception):
    """Base exception for roles system."""
    pass


class UserNotFoundError(RolesError):
    """User not found."""
    def __init__(self, tenant_id: str, user_id: str):
        self.tenant_id = tenant_id
        self.user_id = user_id
        super().__init__(f"User {user_id} not found in tenant {tenant_id}")


class RoleNotFoundError(RolesError):
    """Role not found."""
    def __init__(self, tenant_id: str, role_id: str):
        self.tenant_id = tenant_id
        self.role_id = role_id
        super().__init__(f"Role {role_id} not found in tenant {tenant_id}")


class PermissionNotFoundError(RolesError):
    """Permission not found."""
    def __init__(self, tenant_id: str, permission_code: str):
        self.tenant_id = tenant_id
        self.permission_code = permission_code
        super().__init__(f"Permission {permission_code} not found in tenant {tenant_id}")


class PolicyNotFoundError(RolesError):
    """Policy not found."""
    def __init__(self, tenant_id: str, policy_id: str):
        self.tenant_id = tenant_id
        self.policy_id = policy_id
        super().__init__(f"Policy {policy_id} not found in tenant {tenant_id}")


class PermissionDeniedError(RolesError):
    """Permission denied for user action."""
    def __init__(
        self,
        user_id: str,
        action: str,
        resource: str = None,
        reason: str = None,
    ):
        self.user_id = user_id
        self.action = action
        self.resource = resource
        self.reason = reason
        
        message = f"Permission denied for user {user_id} to perform {action}"
        if resource:
            message += f" on resource {resource}"
        if reason:
            message += f": {reason}"
        
        super().__init__(message)


class InvalidRoleHierarchyError(RolesError):
    """Invalid role hierarchy configuration."""
    def __init__(self, message: str):
        super().__init__(f"Invalid role hierarchy: {message}")


class DuplicateRoleError(RolesError):
    """Role already exists."""
    def __init__(self, tenant_id: str, role_name: str):
        self.tenant_id = tenant_id
        self.role_name = role_name
        super().__init__(f"Role {role_name} already exists in tenant {tenant_id}")


class InvalidPolicyError(RolesError):
    """Invalid policy definition."""
    def __init__(self, message: str):
        super().__init__(f"Invalid policy: {message}")
