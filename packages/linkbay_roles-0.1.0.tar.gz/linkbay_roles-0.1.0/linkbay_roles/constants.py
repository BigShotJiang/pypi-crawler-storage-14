"""
Constants and enumerations for roles and permissions.
"""

from enum import Enum


class PermissionScope(str, Enum):
    """Permission scope levels."""
    TENANT = "tenant"
    SYSTEM = "system"
    GLOBAL = "global"
    RESOURCE = "resource"


class PolicyEffect(str, Enum):
    """Policy evaluation effect."""
    ALLOW = "allow"
    DENY = "deny"


class AuditAction(str, Enum):
    """Audit event types."""
    USER_CREATED = "user_created"
    USER_UPDATED = "user_updated"
    USER_DELETED = "user_deleted"
    ROLE_ASSIGNED = "role_assigned"
    ROLE_REMOVED = "role_removed"
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_REVOKED = "permission_revoked"
    PERMISSION_CHECKED = "permission_checked"
    PERMISSION_DENIED = "permission_denied"
    POLICY_CREATED = "policy_created"
    POLICY_UPDATED = "policy_updated"
    POLICY_DELETED = "policy_deleted"
    POLICY_EVALUATED = "policy_evaluated"


class DefaultRole(str, Enum):
    """Default role names for common SaaS patterns."""
    OWNER = "owner"
    ADMIN = "admin"
    MANAGER = "manager"
    STAFF = "staff"
    CUSTOMER = "customer"
    GUEST = "guest"
    AGENCY = "agency"
    DEVELOPER = "developer"


class SystemPermission(str, Enum):
    """System-level permissions."""
    # User management
    USERS_VIEW = "users:view"
    USERS_CREATE = "users:create"
    USERS_EDIT = "users:edit"
    USERS_DELETE = "users:delete"
    
    # Role management
    ROLES_VIEW = "roles:view"
    ROLES_CREATE = "roles:create"
    ROLES_EDIT = "roles:edit"
    ROLES_DELETE = "roles:delete"
    ROLES_ASSIGN = "roles:assign"
    
    # Permission management
    PERMISSIONS_VIEW = "permissions:view"
    PERMISSIONS_GRANT = "permissions:grant"
    PERMISSIONS_REVOKE = "permissions:revoke"
    
    # Policy management
    POLICIES_VIEW = "policies:view"
    POLICIES_CREATE = "policies:create"
    POLICIES_EDIT = "policies:edit"
    POLICIES_DELETE = "policies:delete"
    
    # Resource permissions (examples)
    ORDERS_VIEW = "orders:view"
    ORDERS_CREATE = "orders:create"
    ORDERS_EDIT = "orders:edit"
    ORDERS_DELETE = "orders:delete"
    
    PRODUCTS_VIEW = "products:view"
    PRODUCTS_CREATE = "products:create"
    PRODUCTS_EDIT = "products:edit"
    PRODUCTS_DELETE = "products:delete"
    
    # Wildcard
    ALL = "*"


# Role hierarchy levels (higher = more permissions)
ROLE_HIERARCHY = {
    DefaultRole.GUEST.value: 0,
    DefaultRole.CUSTOMER.value: 10,
    DefaultRole.STAFF.value: 20,
    DefaultRole.MANAGER.value: 30,
    DefaultRole.DEVELOPER.value: 35,
    DefaultRole.ADMIN.value: 40,
    DefaultRole.AGENCY.value: 45,
    DefaultRole.OWNER.value: 50,
}


# Default permissions for each role
DEFAULT_ROLE_PERMISSIONS = {
    DefaultRole.GUEST.value: [],
    DefaultRole.CUSTOMER.value: [
        SystemPermission.ORDERS_VIEW.value,
        SystemPermission.PRODUCTS_VIEW.value,
    ],
    DefaultRole.STAFF.value: [
        SystemPermission.USERS_VIEW.value,
        SystemPermission.ORDERS_VIEW.value,
        SystemPermission.ORDERS_EDIT.value,
        SystemPermission.PRODUCTS_VIEW.value,
    ],
    DefaultRole.MANAGER.value: [
        SystemPermission.USERS_VIEW.value,
        SystemPermission.USERS_EDIT.value,
        SystemPermission.ORDERS_VIEW.value,
        SystemPermission.ORDERS_CREATE.value,
        SystemPermission.ORDERS_EDIT.value,
        SystemPermission.PRODUCTS_VIEW.value,
        SystemPermission.PRODUCTS_EDIT.value,
        SystemPermission.ROLES_VIEW.value,
    ],
    DefaultRole.ADMIN.value: [
        SystemPermission.USERS_VIEW.value,
        SystemPermission.USERS_CREATE.value,
        SystemPermission.USERS_EDIT.value,
        SystemPermission.USERS_DELETE.value,
        SystemPermission.ROLES_VIEW.value,
        SystemPermission.ROLES_ASSIGN.value,
        SystemPermission.ORDERS_VIEW.value,
        SystemPermission.ORDERS_CREATE.value,
        SystemPermission.ORDERS_EDIT.value,
        SystemPermission.ORDERS_DELETE.value,
        SystemPermission.PRODUCTS_VIEW.value,
        SystemPermission.PRODUCTS_CREATE.value,
        SystemPermission.PRODUCTS_EDIT.value,
        SystemPermission.PRODUCTS_DELETE.value,
    ],
    DefaultRole.OWNER.value: [SystemPermission.ALL.value],
    DefaultRole.AGENCY.value: [SystemPermission.ALL.value],
}
