"""
LinkBay-Roles: Protocol-based, database-agnostic roles and permissions framework.

Multi-tenant RBAC/ABAC system for SaaS applications.
"""

__version__ = "0.1.0"

# Constants and Enums
from .constants import (
    PermissionScope,
    PolicyEffect,
    AuditAction,
    DefaultRole,
    SystemPermission,
)

# Exceptions
from .exceptions import (
    RolesError,
    UserNotFoundError,
    RoleNotFoundError,
    PermissionNotFoundError,
    PolicyNotFoundError,
    PermissionDeniedError,
    InvalidRoleHierarchyError,
    DuplicateRoleError,
    InvalidPolicyError,
)

# Protocols
from .protocols import (
    UserDirectory,
    RolesProvider,
    PoliciesProvider,
    AuditLogger,
)

# Schemas
from .schemas import (
    UserDTO,
    UserCreate,
    UserUpdate,
    UserResponse,
    RoleDTO,
    RoleCreate,
    RoleUpdate,
    RoleResponse,
    PermissionDTO,
    PermissionCreate,
    PermissionResponse,
    PolicyDTO,
    PolicyCreate,
    PolicyUpdate,
    PolicyResponse,
    PolicyCondition,
    PermissionCheck,
    PermissionCheckResult,
    RoleAssignment,
    PermissionGrant,
    AuditEntry,
)

# Services
from .services.user_service import UserService
from .services.role_service import RoleService
from .services.permission_service import PermissionService
from .services.policy_engine import PolicyEngine

# Guards
from .guards import (
    require_permission,
    require_role,
    require_policy,
    require_any_permission,
    require_all_permissions,
    get_current_user,
    get_tenant_id,
)

# Router
from .router import create_roles_router

__all__ = [
    # Version
    "__version__",
    # Constants
    "PermissionScope",
    "PolicyEffect",
    "AuditAction",
    "DefaultRole",
    "SystemPermission",
    # Exceptions
    "RolesError",
    "UserNotFoundError",
    "RoleNotFoundError",
    "PermissionNotFoundError",
    "PolicyNotFoundError",
    "PermissionDeniedError",
    "InvalidRoleHierarchyError",
    "DuplicateRoleError",
    "InvalidPolicyError",
    # Protocols
    "UserDirectory",
    "RolesProvider",
    "PoliciesProvider",
    "AuditLogger",
    # Schemas
    "UserDTO",
    "UserCreate",
    "UserUpdate",
    "UserResponse",
    "RoleDTO",
    "RoleCreate",
    "RoleUpdate",
    "RoleResponse",
    "PermissionDTO",
    "PermissionCreate",
    "PermissionResponse",
    "PolicyDTO",
    "PolicyCreate",
    "PolicyUpdate",
    "PolicyResponse",
    "PolicyCondition",
    "PermissionCheck",
    "PermissionCheckResult",
    "RoleAssignment",
    "PermissionGrant",
    "AuditEntry",
    # Services
    "UserService",
    "RoleService",
    "PermissionService",
    "PolicyEngine",
    # Guards
    "require_permission",
    "require_role",
    "require_policy",
    "require_any_permission",
    "require_all_permissions",
    "get_current_user",
    "get_tenant_id",
    # Router
    "create_roles_router",
]
