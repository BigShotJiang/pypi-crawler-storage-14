"""Permission checking service."""

from typing import Dict, Any, List, Optional
import re

from ..protocols import RolesProvider, UserDirectory, AuditLogger
from ..schemas import PermissionCheck, PermissionCheckResult
from ..exceptions import PermissionDeniedError, UserNotFoundError
from ..constants import AuditAction


class PermissionService:
    """
    Permission checking and enforcement service.
    
    Handles permission evaluation with wildcard support.
    """
    
    def __init__(
        self,
        roles_provider: RolesProvider,
        user_directory: UserDirectory,
        audit_logger: Optional[AuditLogger] = None,
    ):
        self.roles_provider = roles_provider
        self.user_directory = user_directory
        self.audit_logger = audit_logger
    
    async def check_permission(
        self,
        tenant_id: str,
        user_id: str,
        action: str,
        resource: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> PermissionCheckResult:
        """
        Check if user has permission.
        
        Example:
            result = await service.check_permission(
                tenant_id="tenant_123",
                user_id="user_456",
                action="orders:edit",
                resource="order_789",
            )
            
            if result.allowed:
                # Allow action
                pass
        """
        user = await self.user_directory.get_user(tenant_id, user_id)
        if not user:
            raise UserNotFoundError(tenant_id, user_id)
        
        user_permissions = await self.roles_provider.get_user_permissions(tenant_id, user_id)
        
        allowed = self._matches_permission(action, user_permissions)
        
        result = PermissionCheckResult(
            allowed=allowed,
            user_permissions=user_permissions,
            reason=None if allowed else f"User lacks permission for action: {action}",
        )
        
        if self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.PERMISSION_CHECKED.value if allowed else AuditAction.PERMISSION_DENIED.value,
                user_id=user_id,
                resource_type="permission",
                resource_id=action,
                details={"resource": resource, "allowed": allowed},
                success=allowed,
            )
        
        return result
    
    async def grant_permission_to_user(
        self,
        tenant_id: str,
        user_id: str,
        permission_code: str,
    ) -> bool:
        """
        Grant permission directly to user (override).
        
        Example:
            await service.grant_permission_to_user(
                tenant_id="tenant_123",
                user_id="user_456",
                permission_code="orders:delete",
            )
        """
        result = await self.roles_provider.grant_permission_to_user(
            tenant_id, user_id, permission_code
        )
        
        if result and self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.PERMISSION_GRANTED.value,
                user_id="system",
                resource_type="user",
                resource_id=user_id,
                details={"permission": permission_code, "type": "direct"},
            )
        
        return result
    
    async def revoke_permission_from_user(
        self,
        tenant_id: str,
        user_id: str,
        permission_code: str,
    ) -> bool:
        """Revoke permission from user."""
        result = await self.roles_provider.revoke_permission_from_user(
            tenant_id, user_id, permission_code
        )
        
        if result and self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.PERMISSION_REVOKED.value,
                user_id="system",
                resource_type="user",
                resource_id=user_id,
                details={"permission": permission_code, "type": "direct"},
            )
        
        return result
    
    async def require_permission(
        self,
        tenant_id: str,
        user_id: str,
        action: str,
        resource: Optional[str] = None,
    ) -> None:
        """
        Require permission or raise exception.
        
        Example:
            await service.require_permission(
                tenant_id="tenant_123",
                user_id="user_456",
                action="orders:delete",
                resource="order_789",
            )
        """
        result = await self.check_permission(tenant_id, user_id, action, resource)
        
        if not result.allowed:
            raise PermissionDeniedError(user_id, action, resource, result.reason)
    
    async def has_any_permission(
        self,
        tenant_id: str,
        user_id: str,
        actions: List[str],
    ) -> bool:
        """Check if user has any of the permissions."""
        user_permissions = await self.roles_provider.get_user_permissions(tenant_id, user_id)
        
        for action in actions:
            if self._matches_permission(action, user_permissions):
                return True
        
        return False
    
    async def has_all_permissions(
        self,
        tenant_id: str,
        user_id: str,
        actions: List[str],
    ) -> bool:
        """Check if user has all permissions."""
        user_permissions = await self.roles_provider.get_user_permissions(tenant_id, user_id)
        
        for action in actions:
            if not self._matches_permission(action, user_permissions):
                return False
        
        return True
    
    def _matches_permission(
        self,
        required: str,
        granted: List[str],
    ) -> bool:
        """
        Check if required permission matches any granted permission.
        
        Supports wildcards:
        - "*" matches everything
        - "orders:*" matches "orders:view", "orders:edit", etc.
        """
        if "*" in granted:
            return True
        
        if required in granted:
            return True
        
        for perm in granted:
            if "*" in perm:
                pattern = perm.replace("*", ".*")
                if re.match(f"^{pattern}$", required):
                    return True
        
        return False
