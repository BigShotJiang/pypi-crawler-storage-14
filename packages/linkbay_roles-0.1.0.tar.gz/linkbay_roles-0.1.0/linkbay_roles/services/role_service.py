"""Role management service."""

from typing import Dict, Any, List, Optional
from datetime import datetime

from ..protocols import RolesProvider, AuditLogger
from ..schemas import RoleCreate, RoleUpdate, RoleResponse, PermissionCreate, PermissionResponse
from ..exceptions import RoleNotFoundError, DuplicateRoleError
from ..constants import AuditAction, ROLE_HIERARCHY


class RoleService:
    """
    Role management service.
    
    Handles role CRUD, permissions, and hierarchy.
    """
    
    def __init__(
        self,
        roles_provider: RolesProvider,
        audit_logger: Optional[AuditLogger] = None,
    ):
        self.roles_provider = roles_provider
        self.audit_logger = audit_logger
    
    async def create_role(
        self,
        tenant_id: str,
        role_data: RoleCreate,
    ) -> RoleResponse:
        """
        Create new role.
        
        Example:
            role = await service.create_role(
                tenant_id="tenant_123",
                role_data=RoleCreate(
                    name="manager",
                    label="Manager",
                    level=30,
                    description="Department manager role",
                    default_permissions=["orders:view", "orders:edit"],
                ),
            )
        """
        existing = await self.roles_provider.get_role_by_name(tenant_id, role_data.name)
        if existing:
            raise DuplicateRoleError(tenant_id, role_data.name)
        
        role_dict = {
            **role_data.model_dump(),
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
        
        created = await self.roles_provider.create_role(tenant_id, role_dict)
        
        if self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action="role_created",
                user_id="system",
                resource_type="role",
                resource_id=created["id"],
                details={"name": created["name"]},
            )
        
        return RoleResponse(**created)
    
    async def get_role(
        self,
        tenant_id: str,
        role_id: str,
    ) -> RoleResponse:
        """Get role by ID."""
        role = await self.roles_provider.get_role(tenant_id, role_id)
        
        if not role:
            raise RoleNotFoundError(tenant_id, role_id)
        
        return RoleResponse(**role)
    
    async def get_role_by_name(
        self,
        tenant_id: str,
        role_name: str,
    ) -> Optional[RoleResponse]:
        """Get role by name."""
        role = await self.roles_provider.get_role_by_name(tenant_id, role_name)
        
        if not role:
            return None
        
        return RoleResponse(**role)
    
    async def update_role(
        self,
        tenant_id: str,
        role_id: str,
        updates: RoleUpdate,
    ) -> RoleResponse:
        """Update role."""
        update_dict = updates.model_dump(exclude_unset=True)
        update_dict["updated_at"] = datetime.utcnow()
        
        updated = await self.roles_provider.update_role(tenant_id, role_id, update_dict)
        
        return RoleResponse(**updated)
    
    async def delete_role(
        self,
        tenant_id: str,
        role_id: str,
    ) -> bool:
        """Delete role."""
        return await self.roles_provider.delete_role(tenant_id, role_id)
    
    async def list_roles(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
    ) -> List[RoleResponse]:
        """List roles."""
        roles = await self.roles_provider.list_roles(tenant_id, skip, limit)
        return [RoleResponse(**r) for r in roles]
    
    async def create_permission(
        self,
        tenant_id: str,
        permission_data: PermissionCreate,
    ) -> PermissionResponse:
        """Create permission."""
        perm_dict = {
            **permission_data.model_dump(),
            "created_at": datetime.utcnow(),
        }
        
        created = await self.roles_provider.create_permission(tenant_id, perm_dict)
        
        return PermissionResponse(**created)
    
    async def list_permissions(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
    ) -> List[PermissionResponse]:
        """List permissions."""
        perms = await self.roles_provider.list_permissions(tenant_id, skip, limit)
        return [PermissionResponse(**p) for p in perms]
    
    async def grant_permission_to_role(
        self,
        tenant_id: str,
        role_name: str,
        permission_code: str,
    ) -> bool:
        """Grant permission to role."""
        result = await self.roles_provider.grant_permission_to_role(
            tenant_id, role_name, permission_code
        )
        
        if result and self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.PERMISSION_GRANTED.value,
                user_id="system",
                resource_type="role",
                resource_id=role_name,
                details={"permission": permission_code},
            )
        
        return result
    
    async def revoke_permission_from_role(
        self,
        tenant_id: str,
        role_name: str,
        permission_code: str,
    ) -> bool:
        """Revoke permission from role."""
        result = await self.roles_provider.revoke_permission_from_role(
            tenant_id, role_name, permission_code
        )
        
        if result and self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.PERMISSION_REVOKED.value,
                user_id="system",
                resource_type="role",
                resource_id=role_name,
                details={"permission": permission_code},
            )
        
        return result
    
    def compare_role_levels(
        self,
        role1: str,
        role2: str,
    ) -> int:
        """
        Compare role levels.
        
        Returns:
            -1 if role1 < role2
            0 if role1 == role2
            1 if role1 > role2
        """
        level1 = ROLE_HIERARCHY.get(role1, 0)
        level2 = ROLE_HIERARCHY.get(role2, 0)
        
        if level1 < level2:
            return -1
        elif level1 > level2:
            return 1
        else:
            return 0
