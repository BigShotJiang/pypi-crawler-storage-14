"""User management service."""

from typing import Dict, Any, List, Optional
from datetime import datetime

from ..protocols import UserDirectory, AuditLogger
from ..schemas import UserCreate, UserUpdate, UserResponse
from ..exceptions import UserNotFoundError
from ..constants import AuditAction


class UserService:
    """
    User management service.
    
    Handles user CRUD and role assignments.
    """
    
    def __init__(
        self,
        user_directory: UserDirectory,
        audit_logger: Optional[AuditLogger] = None,
    ):
        self.user_directory = user_directory
        self.audit_logger = audit_logger
    
    async def create_user(
        self,
        tenant_id: str,
        user_data: UserCreate,
    ) -> UserResponse:
        """
        Create new user.
        
        Example:
            user = await service.create_user(
                tenant_id="tenant_123",
                user_data=UserCreate(
                    email="john@example.com",
                    name="John Doe",
                    roles=["staff"],
                    active=True,
                ),
            )
        """
        user_dict = {
            **user_data.model_dump(),
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
        
        created = await self.user_directory.create_user(tenant_id, user_dict)
        
        if self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.USER_CREATED.value,
                user_id=created["id"],
                resource_type="user",
                resource_id=created["id"],
                details={"email": created["email"]},
            )
        
        return UserResponse(**created)
    
    async def get_user(
        self,
        tenant_id: str,
        user_id: str,
    ) -> UserResponse:
        """Get user by ID."""
        user = await self.user_directory.get_user(tenant_id, user_id)
        
        if not user:
            raise UserNotFoundError(tenant_id, user_id)
        
        return UserResponse(**user)
    
    async def get_user_by_email(
        self,
        tenant_id: str,
        email: str,
    ) -> Optional[UserResponse]:
        """Get user by email."""
        user = await self.user_directory.get_user_by_email(tenant_id, email)
        
        if not user:
            return None
        
        return UserResponse(**user)
    
    async def update_user(
        self,
        tenant_id: str,
        user_id: str,
        updates: UserUpdate,
    ) -> UserResponse:
        """Update user."""
        update_dict = updates.model_dump(exclude_unset=True)
        update_dict["updated_at"] = datetime.utcnow()
        
        updated = await self.user_directory.update_user(tenant_id, user_id, update_dict)
        
        if self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.USER_UPDATED.value,
                user_id=user_id,
                resource_type="user",
                resource_id=user_id,
                details=update_dict,
            )
        
        return UserResponse(**updated)
    
    async def delete_user(
        self,
        tenant_id: str,
        user_id: str,
    ) -> bool:
        """Delete user."""
        result = await self.user_directory.delete_user(tenant_id, user_id)
        
        if result and self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.USER_DELETED.value,
                user_id=user_id,
                resource_type="user",
                resource_id=user_id,
            )
        
        return result
    
    async def list_users(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[UserResponse]:
        """List users."""
        users = await self.user_directory.list_users(tenant_id, skip, limit, filters)
        return [UserResponse(**u) for u in users]
    
    async def assign_role(
        self,
        tenant_id: str,
        user_id: str,
        role_name: str,
    ) -> UserResponse:
        """
        Assign role to user.
        
        Example:
            user = await service.assign_role(
                tenant_id="tenant_123",
                user_id="user_456",
                role_name="manager",
            )
        """
        updated = await self.user_directory.assign_role(tenant_id, user_id, role_name)
        
        if self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.ROLE_ASSIGNED.value,
                user_id=user_id,
                resource_type="user",
                resource_id=user_id,
                details={"role": role_name},
            )
        
        return UserResponse(**updated)
    
    async def remove_role(
        self,
        tenant_id: str,
        user_id: str,
        role_name: str,
    ) -> UserResponse:
        """Remove role from user."""
        updated = await self.user_directory.remove_role(tenant_id, user_id, role_name)
        
        if self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.ROLE_REMOVED.value,
                user_id=user_id,
                resource_type="user",
                resource_id=user_id,
                details={"role": role_name},
            )
        
        return UserResponse(**updated)
    
    async def list_users_by_role(
        self,
        tenant_id: str,
        role_name: str,
    ) -> List[UserResponse]:
        """List users with specific role."""
        users = await self.user_directory.list_users_by_role(tenant_id, role_name)
        return [UserResponse(**u) for u in users]
    
    async def list_users_by_attribute(
        self,
        tenant_id: str,
        attribute_key: str,
        attribute_value: Any,
    ) -> List[UserResponse]:
        """List users by custom attribute."""
        users = await self.user_directory.list_users_by_attribute(
            tenant_id, attribute_key, attribute_value
        )
        return [UserResponse(**u) for u in users]
