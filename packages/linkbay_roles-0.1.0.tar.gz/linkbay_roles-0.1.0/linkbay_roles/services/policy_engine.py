"""Policy evaluation engine for ABAC."""

from typing import Dict, Any, List, Optional
from datetime import datetime, time

from ..protocols import PoliciesProvider, UserDirectory, AuditLogger
from ..schemas import PolicyCreate, PolicyUpdate, PolicyResponse, PolicyCondition
from ..exceptions import InvalidPolicyError
from ..constants import PolicyEffect, AuditAction


class PolicyEngine:
    """
    Policy-based access control engine (ABAC).
    
    Evaluates policies with conditions for fine-grained access control.
    """
    
    def __init__(
        self,
        policies_provider: PoliciesProvider,
        user_directory: UserDirectory,
        audit_logger: Optional[AuditLogger] = None,
    ):
        self.policies_provider = policies_provider
        self.user_directory = user_directory
        self.audit_logger = audit_logger
    
    async def create_policy(
        self,
        tenant_id: str,
        policy_data: PolicyCreate,
    ) -> PolicyResponse:
        """
        Create new policy.
        
        Example:
            policy = await engine.create_policy(
                tenant_id="tenant_123",
                policy_data=PolicyCreate(
                    subject_type="user",
                    subject_id="user_456",
                    action="orders:manage",
                    resource="orders",
                    effect="allow",
                    conditions=[
                        PolicyCondition(
                            type="time_range",
                            field="current_time",
                            operator="between",
                            value={"start": "09:00", "end": "17:00"},
                        )
                    ],
                ),
            )
        """
        policy_dict = {
            **policy_data.model_dump(),
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
        
        created = await self.policies_provider.create_policy(tenant_id, policy_dict)
        
        if self.audit_logger:
            await self.audit_logger.log_event(
                tenant_id=tenant_id,
                action=AuditAction.POLICY_CREATED.value,
                user_id="system",
                resource_type="policy",
                resource_id=created["id"],
                details={"subject": created["subject_id"], "action": created["action"]},
            )
        
        return PolicyResponse(**created)
    
    async def update_policy(
        self,
        tenant_id: str,
        policy_id: str,
        updates: PolicyUpdate,
    ) -> PolicyResponse:
        """Update policy."""
        update_dict = updates.model_dump(exclude_unset=True)
        update_dict["updated_at"] = datetime.utcnow()
        
        updated = await self.policies_provider.update_policy(tenant_id, policy_id, update_dict)
        
        return PolicyResponse(**updated)
    
    async def delete_policy(
        self,
        tenant_id: str,
        policy_id: str,
    ) -> bool:
        """Delete policy."""
        return await self.policies_provider.delete_policy(tenant_id, policy_id)
    
    async def list_policies(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[PolicyResponse]:
        """List policies."""
        policies = await self.policies_provider.list_policies(tenant_id, skip, limit, filters)
        return [PolicyResponse(**p) for p in policies]
    
    async def evaluate_policies(
        self,
        tenant_id: str,
        user_id: str,
        action: str,
        resource: str,
        context: Dict[str, Any],
    ) -> bool:
        """
        Evaluate policies for user action.
        
        Example:
            allowed = await engine.evaluate_policies(
                tenant_id="tenant_123",
                user_id="user_456",
                action="orders:manage",
                resource="orders",
                context={
                    "current_time": datetime.utcnow(),
                    "user_department": "sales",
                },
            )
        """
        user = await self.user_directory.get_user(tenant_id, user_id)
        if not user:
            return False
        
        user_policies = await self.policies_provider.get_policies_for_subject(
            tenant_id, "user", user_id
        )
        
        role_policies = []
        for role in user.get("roles", []):
            role_policies.extend(
                await self.policies_provider.get_policies_for_subject(
                    tenant_id, "role", role
                )
            )
        
        all_policies = user_policies + role_policies
        
        matching_policies = [
            p for p in all_policies
            if p.get("action") == action and p.get("resource") == resource and p.get("active", True)
        ]
        
        matching_policies.sort(key=lambda p: p.get("priority", 0), reverse=True)
        
        for policy in matching_policies:
            conditions = policy.get("conditions", [])
            
            if self._evaluate_conditions(conditions, context):
                effect = policy.get("effect", PolicyEffect.ALLOW.value)
                
                if self.audit_logger:
                    await self.audit_logger.log_event(
                        tenant_id=tenant_id,
                        action=AuditAction.POLICY_EVALUATED.value,
                        user_id=user_id,
                        resource_type="policy",
                        resource_id=policy["id"],
                        details={
                            "action": action,
                            "resource": resource,
                            "effect": effect,
                        },
                    )
                
                return effect == PolicyEffect.ALLOW.value
        
        return False
    
    def _evaluate_conditions(
        self,
        conditions: List[Dict[str, Any]],
        context: Dict[str, Any],
    ) -> bool:
        """Evaluate policy conditions against context."""
        if not conditions:
            return True
        
        for condition in conditions:
            if not self._evaluate_condition(condition, context):
                return False
        
        return True
    
    def _evaluate_condition(
        self,
        condition: Dict[str, Any],
        context: Dict[str, Any],
    ) -> bool:
        """Evaluate single condition."""
        condition_type = condition.get("type")
        
        if condition_type == "time_range":
            return self._evaluate_time_range(condition, context)
        elif condition_type == "attribute_match":
            return self._evaluate_attribute_match(condition, context)
        elif condition_type == "in_list":
            return self._evaluate_in_list(condition, context)
        elif condition_type == "expression":
            return self._evaluate_expression(condition, context)
        
        return True
    
    def _evaluate_time_range(
        self,
        condition: Dict[str, Any],
        context: Dict[str, Any],
    ) -> bool:
        """
        Evaluate time range condition.
        
        Example condition:
            {
                "type": "time_range",
                "value": {"start": "09:00", "end": "17:00"}
            }
        """
        current_time = context.get("current_time", datetime.utcnow())
        if isinstance(current_time, datetime):
            current_time = current_time.time()
        
        time_range = condition.get("value", {})
        start_str = time_range.get("start")
        end_str = time_range.get("end")
        
        if not start_str or not end_str:
            return True
        
        start_time = datetime.strptime(start_str, "%H:%M").time()
        end_time = datetime.strptime(end_str, "%H:%M").time()
        
        return start_time <= current_time <= end_time
    
    def _evaluate_attribute_match(
        self,
        condition: Dict[str, Any],
        context: Dict[str, Any],
    ) -> bool:
        """
        Evaluate attribute match condition.
        
        Example:
            {
                "type": "attribute_match",
                "field": "department",
                "operator": "eq",
                "value": "sales"
            }
        """
        field = condition.get("field")
        operator = condition.get("operator", "eq")
        expected = condition.get("value")
        
        actual = context.get(field)
        
        if operator == "eq":
            return actual == expected
        elif operator == "ne":
            return actual != expected
        elif operator == "in":
            return actual in expected if isinstance(expected, list) else False
        elif operator == "gt":
            return actual > expected
        elif operator == "lt":
            return actual < expected
        
        return False
    
    def _evaluate_in_list(
        self,
        condition: Dict[str, Any],
        context: Dict[str, Any],
    ) -> bool:
        """Evaluate in-list condition."""
        field = condition.get("field")
        allowed_values = condition.get("value", [])
        
        actual = context.get(field)
        
        return actual in allowed_values
    
    def _evaluate_expression(
        self,
        condition: Dict[str, Any],
        context: Dict[str, Any],
    ) -> bool:
        """Evaluate Python expression condition (use with caution)."""
        expression = condition.get("expression")
        
        if not expression:
            return True
        
        try:
            return eval(expression, {"__builtins__": {}}, context)
        except Exception:
            return False
