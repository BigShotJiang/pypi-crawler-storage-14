"""FastAPI guards and dependency injection."""

from typing import Callable, List, Optional
from functools import wraps

from fastapi import Depends, HTTPException, status, Request

from .services.permission_service import PermissionService
from .services.policy_engine import PolicyEngine
from .exceptions import PermissionDeniedError, UserNotFoundError


async def get_current_user(request: Request) -> str:
    """
    Extract current user ID from request.
    
    Override this dependency to extract from JWT or session.
    """
    user_id = request.headers.get("X-User-ID")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not authenticated",
        )
    return user_id


async def get_tenant_id(request: Request) -> str:
    """
    Extract tenant ID from request.
    
    Override this dependency to extract from JWT, path, or header.
    """
    tenant_id = request.headers.get("X-Tenant-ID")
    if not tenant_id:
        tenant_id = request.path_params.get("tenant_id")
    
    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tenant ID required",
        )
    return tenant_id


def require_permission(
    permission: str,
    resource: Optional[str] = None,
):
    """
    Decorator to require permission for endpoint.
    
    Example:
        @app.get("/orders")
        @require_permission("orders:view")
        async def list_orders(
            tenant_id: str = Depends(get_tenant_id),
            user_id: str = Depends(get_current_user),
        ):
            return []
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            tenant_id = kwargs.get("tenant_id")
            user_id = kwargs.get("user_id")
            permission_service = kwargs.get("permission_service")
            
            if not all([tenant_id, user_id, permission_service]):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Missing required dependencies for permission check",
                )
            
            try:
                await permission_service.require_permission(
                    tenant_id, user_id, permission, resource
                )
            except PermissionDeniedError as e:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=str(e),
                )
            except UserNotFoundError as e:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=str(e),
                )
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def require_role(role_name: str):
    """
    Decorator to require role for endpoint.
    
    Example:
        @app.post("/admin/settings")
        @require_role("admin")
        async def update_settings(...):
            pass
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            tenant_id = kwargs.get("tenant_id")
            user_id = kwargs.get("user_id")
            user_directory = kwargs.get("user_directory")
            
            if not all([tenant_id, user_id, user_directory]):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Missing required dependencies for role check",
                )
            
            user = await user_directory.get_user(tenant_id, user_id)
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"User {user_id} not found",
                )
            
            if role_name not in user.get("roles", []):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"User requires role: {role_name}",
                )
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def require_any_permission(permissions: List[str]):
    """
    Decorator to require any of the permissions.
    
    Example:
        @app.get("/reports")
        @require_any_permission(["reports:view", "admin:*"])
        async def get_reports(...):
            pass
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            tenant_id = kwargs.get("tenant_id")
            user_id = kwargs.get("user_id")
            permission_service = kwargs.get("permission_service")
            
            if not all([tenant_id, user_id, permission_service]):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Missing required dependencies",
                )
            
            has_permission = await permission_service.has_any_permission(
                tenant_id, user_id, permissions
            )
            
            if not has_permission:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"User requires one of: {', '.join(permissions)}",
                )
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def require_all_permissions(permissions: List[str]):
    """Decorator to require all permissions."""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            tenant_id = kwargs.get("tenant_id")
            user_id = kwargs.get("user_id")
            permission_service = kwargs.get("permission_service")
            
            if not all([tenant_id, user_id, permission_service]):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Missing required dependencies",
                )
            
            has_permission = await permission_service.has_all_permissions(
                tenant_id, user_id, permissions
            )
            
            if not has_permission:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"User requires all of: {', '.join(permissions)}",
                )
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def require_policy(
    action: str,
    resource: str,
    context_keys: Optional[List[str]] = None,
):
    """
    Decorator to require policy evaluation.
    
    Example:
        @app.post("/orders/{order_id}/manage")
        @require_policy("orders:manage", "orders", context_keys=["current_time"])
        async def manage_order(
            order_id: str,
            tenant_id: str = Depends(get_tenant_id),
            user_id: str = Depends(get_current_user),
        ):
            pass
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            tenant_id = kwargs.get("tenant_id")
            user_id = kwargs.get("user_id")
            policy_engine = kwargs.get("policy_engine")
            
            if not all([tenant_id, user_id, policy_engine]):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Missing required dependencies",
                )
            
            context = {}
            if context_keys:
                for key in context_keys:
                    if key in kwargs:
                        context[key] = kwargs[key]
            
            allowed = await policy_engine.evaluate_policies(
                tenant_id, user_id, action, resource, context
            )
            
            if not allowed:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Policy denied action {action} on {resource}",
                )
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator
