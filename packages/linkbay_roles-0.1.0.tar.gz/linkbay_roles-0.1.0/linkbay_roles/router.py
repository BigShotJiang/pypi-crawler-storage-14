"""FastAPI router for roles and permissions management."""

from typing import List, Optional
from fastapi import APIRouter, Depends, Query, Path

from .services.user_service import UserService
from .services.role_service import RoleService
from .services.permission_service import PermissionService
from .services.policy_engine import PolicyEngine
from .schemas import (
    UserCreate, UserUpdate, UserResponse,
    RoleCreate, RoleUpdate, RoleResponse,
    PermissionCreate, PermissionResponse,
    PolicyCreate, PolicyUpdate, PolicyResponse,
    RoleAssignment, PermissionGrant,
    PermissionCheck, PermissionCheckResult,
)
from .guards import get_tenant_id, get_current_user


def create_roles_router(
    user_service_dep,
    role_service_dep,
    permission_service_dep,
    policy_engine_dep=None,
    tenant_id_dep=None,
    current_user_dep=None,
) -> APIRouter:
    """
    Create FastAPI router for roles and permissions.
    
    Args:
        user_service_dep: Dependency for UserService
        role_service_dep: Dependency for RoleService
        permission_service_dep: Dependency for PermissionService
        policy_engine_dep: Optional dependency for PolicyEngine
        tenant_id_dep: Dependency for tenant_id extraction
        current_user_dep: Dependency for current user extraction
    
    Returns:
        Configured APIRouter
    
    Example:
        from linkbay_roles import create_roles_router, UserService
        
        async def get_user_service():
            user_directory = MyUserDirectory()
            return UserService(user_directory)
        
        async def get_tenant_id():
            return "tenant_123"
        
        router = create_roles_router(
            user_service_dep=Depends(get_user_service),
            tenant_id_dep=Depends(get_tenant_id),
        )
        
        app.include_router(router, prefix="/api/roles")
    """
    if tenant_id_dep is None:
        tenant_id_dep = Depends(get_tenant_id)
    if current_user_dep is None:
        current_user_dep = Depends(get_current_user)
    
    router = APIRouter(tags=["roles"])
    
    # User endpoints
    @router.post("/{tenant_id}/users", response_model=UserResponse, status_code=201)
    async def create_user(
        user_data: UserCreate,
        tenant_id: str = Path(...),
        user_service: UserService = user_service_dep,
    ):
        """Create new user."""
        return await user_service.create_user(tenant_id, user_data)
    
    @router.get("/{tenant_id}/users/{user_id}", response_model=UserResponse)
    async def get_user(
        user_id: str,
        tenant_id: str = Path(...),
        user_service: UserService = user_service_dep,
    ):
        """Get user by ID."""
        return await user_service.get_user(tenant_id, user_id)
    
    @router.patch("/{tenant_id}/users/{user_id}", response_model=UserResponse)
    async def update_user(
        user_id: str,
        updates: UserUpdate,
        tenant_id: str = Path(...),
        user_service: UserService = user_service_dep,
    ):
        """Update user."""
        return await user_service.update_user(tenant_id, user_id, updates)
    
    @router.delete("/{tenant_id}/users/{user_id}")
    async def delete_user(
        user_id: str,
        tenant_id: str = Path(...),
        user_service: UserService = user_service_dep,
    ):
        """Delete user."""
        success = await user_service.delete_user(tenant_id, user_id)
        return {"success": success}
    
    @router.get("/{tenant_id}/users", response_model=List[UserResponse])
    async def list_users(
        tenant_id: str = Path(...),
        skip: int = Query(0, ge=0),
        limit: int = Query(100, ge=1, le=500),
        user_service: UserService = user_service_dep,
    ):
        """List users."""
        return await user_service.list_users(tenant_id, skip, limit)
    
    @router.post("/{tenant_id}/users/{user_id}/roles", response_model=UserResponse)
    async def assign_role(
        user_id: str,
        assignment: RoleAssignment,
        tenant_id: str = Path(...),
        user_service: UserService = user_service_dep,
    ):
        """Assign role to user."""
        return await user_service.assign_role(tenant_id, user_id, assignment.role_name)
    
    @router.delete("/{tenant_id}/users/{user_id}/roles/{role_name}", response_model=UserResponse)
    async def remove_role(
        user_id: str,
        role_name: str,
        tenant_id: str = Path(...),
        user_service: UserService = user_service_dep,
    ):
        """Remove role from user."""
        return await user_service.remove_role(tenant_id, user_id, role_name)
    
    # Role endpoints
    @router.post("/{tenant_id}/roles", response_model=RoleResponse, status_code=201)
    async def create_role(
        role_data: RoleCreate,
        tenant_id: str = Path(...),
        role_service: RoleService = role_service_dep,
    ):
        """Create new role."""
        return await role_service.create_role(tenant_id, role_data)
    
    @router.get("/{tenant_id}/roles/{role_id}", response_model=RoleResponse)
    async def get_role(
        role_id: str,
        tenant_id: str = Path(...),
        role_service: RoleService = role_service_dep,
    ):
        """Get role by ID."""
        return await role_service.get_role(tenant_id, role_id)
    
    @router.get("/{tenant_id}/roles", response_model=List[RoleResponse])
    async def list_roles(
        tenant_id: str = Path(...),
        skip: int = Query(0, ge=0),
        limit: int = Query(100, ge=1, le=500),
        role_service: RoleService = role_service_dep,
    ):
        """List roles."""
        return await role_service.list_roles(tenant_id, skip, limit)
    
    # Permission endpoints
    @router.post("/{tenant_id}/permissions", response_model=PermissionResponse, status_code=201)
    async def create_permission(
        permission_data: PermissionCreate,
        tenant_id: str = Path(...),
        role_service: RoleService = role_service_dep,
    ):
        """Create permission."""
        return await role_service.create_permission(tenant_id, permission_data)
    
    @router.get("/{tenant_id}/permissions", response_model=List[PermissionResponse])
    async def list_permissions(
        tenant_id: str = Path(...),
        skip: int = Query(0, ge=0),
        limit: int = Query(100, ge=1, le=500),
        role_service: RoleService = role_service_dep,
    ):
        """List permissions."""
        return await role_service.list_permissions(tenant_id, skip, limit)
    
    @router.post("/{tenant_id}/roles/{role_name}/permissions")
    async def grant_permission_to_role(
        role_name: str,
        grant: PermissionGrant,
        tenant_id: str = Path(...),
        role_service: RoleService = role_service_dep,
    ):
        """Grant permission to role."""
        success = await role_service.grant_permission_to_role(
            tenant_id, role_name, grant.permission_code
        )
        return {"success": success}
    
    @router.delete("/{tenant_id}/roles/{role_name}/permissions/{permission_code}")
    async def revoke_permission_from_role(
        role_name: str,
        permission_code: str,
        tenant_id: str = Path(...),
        role_service: RoleService = role_service_dep,
    ):
        """Revoke permission from role."""
        success = await role_service.revoke_permission_from_role(
            tenant_id, role_name, permission_code
        )
        return {"success": success}
    
    @router.post("/{tenant_id}/users/{user_id}/permissions")
    async def grant_permission_to_user(
        user_id: str,
        grant: PermissionGrant,
        tenant_id: str = Path(...),
        permission_service: PermissionService = permission_service_dep,
    ):
        """Grant permission directly to user."""
        success = await permission_service.grant_permission_to_user(
            tenant_id, user_id, grant.permission_code
        )
        return {"success": success}
    
    @router.post("/{tenant_id}/permissions/check", response_model=PermissionCheckResult)
    async def check_permission(
        check: PermissionCheck,
        tenant_id: str = Path(...),
        permission_service: PermissionService = permission_service_dep,
    ):
        """Check if user has permission."""
        return await permission_service.check_permission(
            tenant_id, check.user_id, check.action, check.resource, check.context
        )
    
    # Policy endpoints (if policy engine provided)
    if policy_engine_dep:
        @router.post("/{tenant_id}/policies", response_model=PolicyResponse, status_code=201)
        async def create_policy(
            policy_data: PolicyCreate,
            tenant_id: str = Path(...),
            policy_engine: PolicyEngine = policy_engine_dep,
        ):
            """Create policy."""
            return await policy_engine.create_policy(tenant_id, policy_data)
        
        @router.get("/{tenant_id}/policies", response_model=List[PolicyResponse])
        async def list_policies(
            tenant_id: str = Path(...),
            skip: int = Query(0, ge=0),
            limit: int = Query(100, ge=1, le=500),
            policy_engine: PolicyEngine = policy_engine_dep,
        ):
            """List policies."""
            return await policy_engine.list_policies(tenant_id, skip, limit)
        
        @router.patch("/{tenant_id}/policies/{policy_id}", response_model=PolicyResponse)
        async def update_policy(
            policy_id: str,
            updates: PolicyUpdate,
            tenant_id: str = Path(...),
            policy_engine: PolicyEngine = policy_engine_dep,
        ):
            """Update policy."""
            return await policy_engine.update_policy(tenant_id, policy_id, updates)
        
        @router.delete("/{tenant_id}/policies/{policy_id}")
        async def delete_policy(
            policy_id: str,
            tenant_id: str = Path(...),
            policy_engine: PolicyEngine = policy_engine_dep,
        ):
            """Delete policy."""
            success = await policy_engine.delete_policy(tenant_id, policy_id)
            return {"success": success}
    
    return router
