"""
Protocol interfaces for roles and permissions system.
"""

from typing import Protocol, Dict, Any, List, Optional
from datetime import datetime


class UserDirectory(Protocol):
    """
    Protocol for user storage and retrieval.
    
    All implementations must be multi-tenant aware.
    """
    
    async def create_user(
        self,
        tenant_id: str,
        user_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create new user."""
        ...
    
    async def get_user(
        self,
        tenant_id: str,
        user_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get user by ID."""
        ...
    
    async def get_user_by_email(
        self,
        tenant_id: str,
        email: str,
    ) -> Optional[Dict[str, Any]]:
        """Get user by email."""
        ...
    
    async def update_user(
        self,
        tenant_id: str,
        user_id: str,
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update user."""
        ...
    
    async def delete_user(
        self,
        tenant_id: str,
        user_id: str,
    ) -> bool:
        """Delete user."""
        ...
    
    async def list_users(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """List users with filters."""
        ...
    
    async def list_users_by_role(
        self,
        tenant_id: str,
        role_name: str,
    ) -> List[Dict[str, Any]]:
        """List users with specific role."""
        ...
    
    async def list_users_by_attribute(
        self,
        tenant_id: str,
        attribute_key: str,
        attribute_value: Any,
    ) -> List[Dict[str, Any]]:
        """List users by custom attribute."""
        ...
    
    async def assign_role(
        self,
        tenant_id: str,
        user_id: str,
        role_name: str,
    ) -> Dict[str, Any]:
        """Assign role to user."""
        ...
    
    async def remove_role(
        self,
        tenant_id: str,
        user_id: str,
        role_name: str,
    ) -> Dict[str, Any]:
        """Remove role from user."""
        ...


class RolesProvider(Protocol):
    """
    Protocol for role and permission management.
    """
    
    async def create_role(
        self,
        tenant_id: str,
        role_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create new role."""
        ...
    
    async def get_role(
        self,
        tenant_id: str,
        role_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get role by ID."""
        ...
    
    async def get_role_by_name(
        self,
        tenant_id: str,
        role_name: str,
    ) -> Optional[Dict[str, Any]]:
        """Get role by name."""
        ...
    
    async def update_role(
        self,
        tenant_id: str,
        role_id: str,
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update role."""
        ...
    
    async def delete_role(
        self,
        tenant_id: str,
        role_id: str,
    ) -> bool:
        """Delete role."""
        ...
    
    async def list_roles(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """List roles."""
        ...
    
    async def create_permission(
        self,
        tenant_id: str,
        permission_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create permission."""
        ...
    
    async def get_permission(
        self,
        tenant_id: str,
        permission_code: str,
    ) -> Optional[Dict[str, Any]]:
        """Get permission by code."""
        ...
    
    async def list_permissions(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """List permissions."""
        ...
    
    async def grant_permission_to_role(
        self,
        tenant_id: str,
        role_name: str,
        permission_code: str,
    ) -> bool:
        """Grant permission to role."""
        ...
    
    async def revoke_permission_from_role(
        self,
        tenant_id: str,
        role_name: str,
        permission_code: str,
    ) -> bool:
        """Revoke permission from role."""
        ...
    
    async def grant_permission_to_user(
        self,
        tenant_id: str,
        user_id: str,
        permission_code: str,
    ) -> bool:
        """Grant permission directly to user (override)."""
        ...
    
    async def revoke_permission_from_user(
        self,
        tenant_id: str,
        user_id: str,
        permission_code: str,
    ) -> bool:
        """Revoke permission from user."""
        ...
    
    async def get_user_permissions(
        self,
        tenant_id: str,
        user_id: str,
    ) -> List[str]:
        """Get all permissions for user (role + direct)."""
        ...
    
    async def get_role_permissions(
        self,
        tenant_id: str,
        role_name: str,
    ) -> List[str]:
        """Get permissions for role."""
        ...


class PoliciesProvider(Protocol):
    """
    Protocol for policy-based access control (ABAC).
    """
    
    async def create_policy(
        self,
        tenant_id: str,
        policy_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create policy."""
        ...
    
    async def get_policy(
        self,
        tenant_id: str,
        policy_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get policy by ID."""
        ...
    
    async def update_policy(
        self,
        tenant_id: str,
        policy_id: str,
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update policy."""
        ...
    
    async def delete_policy(
        self,
        tenant_id: str,
        policy_id: str,
    ) -> bool:
        """Delete policy."""
        ...
    
    async def list_policies(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """List policies."""
        ...
    
    async def get_policies_for_subject(
        self,
        tenant_id: str,
        subject_type: str,
        subject_id: str,
    ) -> List[Dict[str, Any]]:
        """Get policies for subject (user or role)."""
        ...
    
    async def evaluate_policy(
        self,
        tenant_id: str,
        policy_id: str,
        context: Dict[str, Any],
    ) -> bool:
        """Evaluate policy against context."""
        ...


class AuditLogger(Protocol):
    """
    Protocol for audit logging.
    """
    
    async def log_event(
        self,
        tenant_id: str,
        action: str,
        user_id: str,
        resource_type: str,
        resource_id: str,
        details: Optional[Dict[str, Any]] = None,
        success: bool = True,
    ) -> None:
        """Log audit event."""
        ...
    
    async def get_audit_logs(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Retrieve audit logs."""
        ...
