"""Pydantic schemas for roles and permissions."""

from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, EmailStr


class UserDTO(BaseModel):
    """User data transfer object."""
    id: str
    tenant_id: str
    email: EmailStr
    name: str
    roles: List[str] = Field(default_factory=list)
    active: bool = True
    attributes: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class UserCreate(BaseModel):
    """Create user request."""
    email: EmailStr
    name: str
    roles: List[str] = Field(default_factory=list)
    active: bool = True
    attributes: Dict[str, Any] = Field(default_factory=dict)


class UserUpdate(BaseModel):
    """Update user request."""
    email: Optional[EmailStr] = None
    name: Optional[str] = None
    active: Optional[bool] = None
    attributes: Optional[Dict[str, Any]] = None


class UserResponse(UserDTO):
    """User response."""
    pass


class RoleDTO(BaseModel):
    """Role data transfer object."""
    id: str
    tenant_id: str
    name: str
    label: str
    level: int = 0
    description: Optional[str] = None
    default_permissions: List[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


class RoleCreate(BaseModel):
    """Create role request."""
    name: str
    label: str
    level: int = 0
    description: Optional[str] = None
    default_permissions: List[str] = Field(default_factory=list)


class RoleUpdate(BaseModel):
    """Update role request."""
    label: Optional[str] = None
    level: Optional[int] = None
    description: Optional[str] = None
    default_permissions: Optional[List[str]] = None


class RoleResponse(RoleDTO):
    """Role response."""
    pass


class PermissionDTO(BaseModel):
    """Permission data transfer object."""
    id: str
    code: str
    label: str
    description: Optional[str] = None
    scope: str = "tenant"
    resource: Optional[str] = None
    created_at: datetime


class PermissionCreate(BaseModel):
    """Create permission request."""
    code: str
    label: str
    description: Optional[str] = None
    scope: str = "tenant"
    resource: Optional[str] = None


class PermissionResponse(PermissionDTO):
    """Permission response."""
    pass


class PolicyCondition(BaseModel):
    """Policy condition for ABAC."""
    type: str
    field: Optional[str] = None
    operator: Optional[str] = None
    value: Optional[Any] = None
    expression: Optional[str] = None


class PolicyDTO(BaseModel):
    """Policy data transfer object."""
    id: str
    tenant_id: str
    subject_type: str
    subject_id: str
    action: str
    resource: str
    effect: str = "allow"
    conditions: List[PolicyCondition] = Field(default_factory=list)
    priority: int = 0
    active: bool = True
    created_at: datetime
    updated_at: datetime


class PolicyCreate(BaseModel):
    """Create policy request."""
    subject_type: str
    subject_id: str
    action: str
    resource: str
    effect: str = "allow"
    conditions: List[PolicyCondition] = Field(default_factory=list)
    priority: int = 0
    active: bool = True


class PolicyUpdate(BaseModel):
    """Update policy request."""
    effect: Optional[str] = None
    conditions: Optional[List[PolicyCondition]] = None
    priority: Optional[int] = None
    active: Optional[bool] = None


class PolicyResponse(PolicyDTO):
    """Policy response."""
    pass


class PermissionCheck(BaseModel):
    """Permission check request."""
    user_id: str
    action: str
    resource: Optional[str] = None
    context: Dict[str, Any] = Field(default_factory=dict)


class PermissionCheckResult(BaseModel):
    """Permission check result."""
    allowed: bool
    reason: Optional[str] = None
    matched_policies: List[str] = Field(default_factory=list)
    user_permissions: List[str] = Field(default_factory=list)


class RoleAssignment(BaseModel):
    """Role assignment."""
    user_id: str
    role_name: str


class PermissionGrant(BaseModel):
    """Permission grant."""
    target_type: str
    target_id: str
    permission_code: str


class AuditEntry(BaseModel):
    """Audit log entry."""
    id: str
    tenant_id: str
    action: str
    user_id: str
    resource_type: str
    resource_id: str
    details: Dict[str, Any] = Field(default_factory=dict)
    success: bool
    timestamp: datetime
