## Authors

- Angira Tripathi <angira.tripathi@am-flow.com>
- Sander Koelstra <sander.koelstra@am-flow.com>

### django-rest-hooks

drf-Hooks is a fork a Django REST Hooks. The original authors were:

#### Development Lead

- Bryan Helmig <bryan@zapier.com>

#### Patches and Suggestions

- [Bryan Helmig](https://github.com/bryanhelmig)
- [Arnaud Limbourg](https://github.com/arnaudlimbourg)
- [tdruez](https://github.com/tdruez)
- [Maina Nick](https://github.com/mainanick)
- Jonathan Moss
- [Erik Wickstrom](https://github.com/erikcw)
- [Yaroslav Klyuyev](https://github.com/imposeren)
