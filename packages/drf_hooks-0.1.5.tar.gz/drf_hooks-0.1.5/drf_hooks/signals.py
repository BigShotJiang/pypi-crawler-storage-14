from django.dispatch import Signal

hook_event = Signal()
raw_hook_event = Signal()
