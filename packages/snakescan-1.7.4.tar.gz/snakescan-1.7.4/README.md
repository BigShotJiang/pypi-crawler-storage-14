# SnakeScan
![PyPI version](https://badge.fury.io/py/SnakeScan.svg)
![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Requires-python](https://img.shields.io/badge/requires--python-3.7+-black)
![Status](https://img.shields.io/badge/Version-in%20Beta-black)
![Platforms](https://img.shields.io/badge/Platforms-macOS%20%7C%20Linux%20%7C%20Windows-blue)

## Help with using the library 
- -l  need internet to view public ip you device
- -t threading port search
- -s single search ports
- -i information about host
- -help in host /-help port in host
- -check [host] scan subnet in ip
- exit in host or port off script

### Watcher commands
 ```
 Watcher.start() - Starts checking ports
 Watcher.stop() - Stops port checking
 ```
 ### Watcher
 ```
 from SnakeScan import Watcher
 watcher = Watcher("localhost",53,2)
 watcher.start()
 ```
 ### Help with attributes
```
-P:
snake -p 80,443 #Scanning specific ports
snake -p 80,3437,8080,20-30,79-443 #Scanning individual ports and ranges. If you use ranges, then one port from the beginning is not be taken into account. For example:80-443 then it will start with 81-443, so you need to enter it from 79-443, then it will be taken into account 
snake -p 80,3437,10-0,20-10,443-79 #You can enter ranges the other way around: 80-443,443-80 but the first value will start one port higher
-H:
#Displays a list of attribute usages
snake -h
snake -help
-SP:
-sp:snake -sp #Uses selected pre-selected range and uses for scanning ProcessPoolExecutor
-V:
snake -v #Shows the library version
-GS:
snake www.google.com -gs #Get a certificate from the official website. If you don't enter the hostname, you'll get this error [Errno 111] Connection refused
-T:
snake -t #Uses threads for port scanning
-CH:
snake -ch #Scans the subnet for others IP
-L:
snake -l #Shows your public internet IP address. Internet connection required for use
-I:
snake www.google.com -i #Shows information about the IP address.Can receive information from IPV4 and IPV6

#Update in 1.7.4
    - Added more standart ports to fast scan