from dataclasses import dataclass
import pytest

from schemas_hf.base import DatasetSchema
from schemas_hf.registry import SchemaRegistry


@dataclass
class DummyItem(DatasetSchema):
    DATASET_NAME = "dummy/dataset"

    text: str
    label: int


def test_registry_register_and_get():
    registry = SchemaRegistry()
    registry.register(DummyItem)

    retrieved = registry.get("dummy/dataset")
    assert retrieved is DummyItem
    assert registry.list_names() == ["dummy/dataset"]


def test_registry_duplicate_name_raises():
    registry = SchemaRegistry()
    registry.register(DummyItem)

    with pytest.raises(ValueError):
        registry.register(DummyItem)


def test_schema_from_example_roundtrip():
    item = DummyItem.from_example({"text": "hello", "label": 1})
    assert item.to_dict() == {"text": "hello", "label": 1}

    with pytest.raises(KeyError):
        DummyItem.from_example({"text": "missing"})
