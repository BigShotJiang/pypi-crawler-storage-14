import importlib

def test_package_version():
    mod = importlib.import_module("schemas_hf")
    assert mod.__version__ == "0.1.0"
