import textwrap

from schemas_hf.codegen import SchemaRenderer
from schemas_hf.base import DatasetSchema


def test_renderer_produces_dataclass_source():
    renderer = SchemaRenderer(dataset_id="owner/name", config_name=None)
    dataset_info = {
        "features": {
            "text": {"_type": "Value", "dtype": "string"},
            "label": {"_type": "ClassLabel", "names": ["World", "Sports", "Business", "Sci/Tech"]},
        }
    }

    source = renderer.render(dataset_info)
    assert "OwnerNameRecord" in source
    namespace = {
        "DatasetSchema": DatasetSchema,
        "register_schema": lambda cls: cls,
    }
    exec(source, namespace)
    schema_cls = namespace["OwnerNameRecord"]
    example = {"text": "hello", "label": 0}
    item = schema_cls.from_example(example)
    assert item.text == "hello"
    assert item.label == 0
