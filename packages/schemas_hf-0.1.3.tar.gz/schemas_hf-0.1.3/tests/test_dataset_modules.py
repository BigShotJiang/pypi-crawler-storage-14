import importlib
import inspect
from pathlib import Path

import pytest

from schemas_hf.base import DatasetSchema


DATASET_DIR = Path(__file__).resolve().parents[1] / "src" / "schemas_hf" / "datasets"
MODULES = sorted(
    [
        f"schemas_hf.datasets.{path.stem}"
        for path in DATASET_DIR.glob("*.py")
        if path.stem != "__init__"
    ]
)


@pytest.mark.parametrize("module_name", MODULES)
def test_dataset_module_defines_schema(module_name):
    module = importlib.import_module(module_name)
    schemas = [
        obj
        for _, obj in inspect.getmembers(module, inspect.isclass)
        if issubclass(obj, DatasetSchema) and obj is not DatasetSchema
    ]
    assert schemas, f"No DatasetSchema subclass found in {module_name}"
    dataset_cls = schemas[0]
    assert hasattr(dataset_cls, "DATASET_NAME")
