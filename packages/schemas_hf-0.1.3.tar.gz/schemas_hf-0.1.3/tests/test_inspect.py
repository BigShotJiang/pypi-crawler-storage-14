from types import SimpleNamespace

from schemas_hf import inspect


class DummySplit:
    def __init__(self, count):
        self.num_examples = count
        self.dataset_size = 100 * count


class DummyInfo:
    description = "Sample dataset."
    homepage = "https://example.com"
    license = "Apache-2.0"
    citation = "citation"
    features = SimpleNamespace(
        to_dict=lambda: {"text": {"_type": "Value", "dtype": "string"}}
    )
    splits = {"train": DummySplit(10), "test": DummySplit(5)}
    dataset_size = 1500
    download_size = 800


class DummyBuilder:
    info = DummyInfo
    builder_configs = {"default": object(), "alt": object()}


def test_describe_dataset(monkeypatch):
    monkeypatch.setattr(
        inspect, "_load_builder", lambda dataset_id, config_name: DummyBuilder()
    )

    details = inspect.describe_dataset("dataset", None)

    assert details.dataset_id == "dataset"
    assert details.features["text"]["dtype"] == "string"
    assert details.splits["train"]["num_examples"] == 10
    assert details.builder_configs == ["alt", "default"]
    summary = inspect.summarize_feature({"_type": "Value", "dtype": "int32"})
    assert summary == "int32"
