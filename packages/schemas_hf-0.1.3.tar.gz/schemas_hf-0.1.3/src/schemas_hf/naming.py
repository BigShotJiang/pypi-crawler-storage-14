from __future__ import annotations


def slugify(value: str) -> str:
    cleaned = []
    for ch in value.lower():
        cleaned.append(ch if ch.isalnum() else "_")
    slug = "".join(cleaned)
    while "__" in slug:
        slug = slug.replace("__", "_")
    return slug.strip("_") or "dataset"


def module_name(dataset_id: str, config_name: str | None) -> str:
    parts = dataset_id.split("/", 1)
    segments = parts if len(parts) > 1 else [parts[0]]
    if config_name:
        segments.append(config_name)
    return "__".join(slugify(segment) for segment in segments)


def module_filename(dataset_id: str, config_name: str | None) -> str:
    return f"{module_name(dataset_id, config_name)}.py"


def schema_key(dataset_id: str, config_name: str | None) -> str:
    return f"{dataset_id}:{config_name}" if config_name else dataset_id
