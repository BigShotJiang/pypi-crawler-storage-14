from __future__ import annotations

"""
Static knowledge about multi-part HF datasets that should be treated as a
bundle when generating schemas.

This is intentionally tiny and opinionated: it only covers cases where we
know that a “primary” metadata table needs one or more companion datasets
to represent the full object graph (e.g. raw EEG files hosted separately).

Keys are base dataset ids *without* config, values are lists of companion
dataset ids that may or may not exist yet on HF.
"""

DATASET_BUNDLES: dict[str, list[str]] = {
    # DMT Brains EEG:
    # - uwunion/dmt-brains-conditions : subject/condition metadata +
    #   file paths and scales.
    # - uwunion/dmt-brains-signals    : windowed EEG signals (numeric) with
    #   subject/condition keys pointing back to the conditions table.
    #
    # When a user runs:
    #   hfschema download uwunion/dmt-brains-conditions
    # we will opportunistically also download metadata and generate schema
    # modules for uwunion/dmt-brains-signals, if it exists and is
    # accessible under the current HF token.
    "uwunion/dmt-brains-conditions": ["uwunion/dmt-brains-signals"],

    # VCTK speech corpus:
    # - uwunion/vctk-utterances : utterance-level dataset with an Audio()
    #   column plus text/duration/etc.
    # - uwunion/vctk-speakers   : speaker-level metadata with age/gender/accent.
    #
    # When a user runs:
    #   hfschema download uwunion/vctk-utterances
    # we will try to also download metadata and generate schemas for
    # uwunion/vctk-speakers if present.
    "uwunion/vctk-utterances": ["uwunion/vctk-speakers"],

    # CMU motion capture:
    # - uwunion/cmu-mocap      : motion-level metadata (one row per BVH file)
    #   with columns like subject_id, motion_id, description, category,
    #   num_frames, duration_sec, fps, num_channels, and a string field
    #   (e.g. hf_path) pointing at the corresponding BVH file within a raw
    #   HF repo.
    # - uwunion/cmu-mocap-raw  : HF dataset repo used as storage for the
    #   actual .bvh files (accessed via hf_hub_download). This may or may
    #   not expose a tabular view; we treat it as an optional companion.
    #
    # For now, `download` will opportunistically try to touch
    # uwunion/cmu-mocap-raw; if it is a plain file repo without a datasets
    # view, it will simply be skipped.
    "uwunion/cmu-mocap": ["uwunion/cmu-mocap-raw"],
}
