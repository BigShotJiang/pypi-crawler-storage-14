# Auto-generated via load_dataset_builder

from dataclasses import dataclass
from typing import ClassVar, Literal, Optional

from schemas_hf.base import DatasetSchema
from schemas_hf.registry import register_schema


@register_schema
@dataclass
class ImdbRecord(DatasetSchema):
    DATASET_NAME: ClassVar[str] = "imdb"
    CONFIG_NAME: ClassVar[Optional[str]] = None
    text: str
    label: Literal[0, 1]
