from dataclasses import dataclass
from typing import ClassVar, Optional

from schemas_hf.base import DatasetSchema
from schemas_hf.registry import register_schema


@register_schema
@dataclass
class UwunionDmtBrainsConditionsRecord(DatasetSchema):
    DATASET_NAME: ClassVar[str] = "uwunion/dmt-brains-conditions"
    CONFIG_NAME: ClassVar[Optional[str]] = None
    subject_id: str
    condition: str
    filename: str
    file_format: str
    file_size_mb: float
    relative_path: str
    has_all_conditions: bool
    has_scales_data: bool
    found_conditions_str: str
    missing_conditions_str: str
    dataset_name: str
    modality: str
    paradigm: str
    drug: str
