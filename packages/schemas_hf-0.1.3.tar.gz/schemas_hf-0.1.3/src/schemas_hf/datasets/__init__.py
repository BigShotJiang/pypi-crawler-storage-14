"""Auto-generated dataset schemas live here."""

__all__: list[str] = []
