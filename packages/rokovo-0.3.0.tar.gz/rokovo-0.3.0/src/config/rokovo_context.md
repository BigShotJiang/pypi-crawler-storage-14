# <Project name> project description

The <Project name> is a <project type> that <a brief description with any details you think can be helpful>

## Important file(s)

- `file.ext`: <description>

>[!NOTE]
> You can add a pattern of files. for example `*_controller.ext`.

>[!NOTE]
> Make sure you explain the project structure here too.

## Keywords

- <keyword>
- <keyword>
- <keyword>

>[!NOTE]
> You explain them as well here.

## Questions examples

- Q1
- Q2
- Q3
...

>[!NOTE]
> Some example question that your users may already ask.
