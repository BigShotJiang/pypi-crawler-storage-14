"""ProWeb Templates - Jinja2 bilan osonlashtirilgan"""

from jinja2 import Environment, FileSystemLoader, select_autoescape
from fastapi.responses import HTMLResponse
from typing import Dict, Any, Optional
import os


class TemplateEngine:
    """
    Jinja2 Template Engine - Django-style
    
    Misol:
        templates = TemplateEngine("templates")
        html = await templates.render("index.html", ism="Ali")
    """
    
    def __init__(self, template_dir: str = "templates"):
        """Template engine ni ishga tushirish"""
        self.template_dir = template_dir
        
        # Jinja2 Environment
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        
        # Custom filterlar qo'shish
        self._add_custom_filters()
    
    def _add_custom_filters(self):
        """O'zbekcha custom filterlar"""
        
        @self.env.filter('sana_formati')
        def sana_formati(value, format='%d.%m.%Y'):
            """Sanani formatlash"""
            if value:
                return value.strftime(format)
            return ''
        
        @self.env.filter('vaqt_formati')
        def vaqt_formati(value, format='%H:%M'):
            """Vaqtni formatlash"""
            if value:
                return value.strftime(format)
            return ''
        
        @self.env.filter('raqam_formati')
        def raqam_formati(value, decimals=2):
            """Raqamni formatlash"""
            if isinstance(value, (int, float)):
                return f"{value:,.{decimals}f}".replace(',', ' ')
            return value
        
        @self.env.filter('qisqartirish')
        def qisqartirish(text, length=100, suffix='...'):
            """Matnni qisqartirish"""
            if len(text) <= length:
                return text
            return text[:length].rsplit(' ', 1)[0] + suffix
        
        @self.env.filter('bosh_harf')
        def bosh_harf(text):
            """Bosh harfni katta qilish"""
            return text.capitalize() if text else ''
        
        @self.env.filter('hammasi_katta')
        def hammasi_katta(text):
            """Barcha harflarni katta qilish"""
            return text.upper() if text else ''
        
        @self.env.filter('hammasi_kichik')
        def hammasi_kichik(text):
            """Barcha harflarni kichik qilish"""
            return text.lower() if text else ''
    
    def render(self, template_name: str, **context) -> str:
        """Template ni render qilish"""
        template = self.env.get_template(template_name)
        return template.render(**context)
    
    async def render_async(self, template_name: str, **context) -> str:
        """Template ni asinxron render qilish"""
        return self.render(template_name, **context)
    
    def add_filter(self, name: str, func):
        """Custom filter qo'shish"""
        self.env.filters[name] = func
    
    def add_global(self, name: str, value: Any):
        """Global o'zgaruvchi qo'shish"""
        self.env.globals[name] = value


# Global template engine instance
_template_engine: Optional[TemplateEngine] = None


def init_templates(template_dir: str = "templates"):
    """Template engine ni ishga tushirish"""
    global _template_engine
    _template_engine = TemplateEngine(template_dir)
    return _template_engine


def get_template_engine() -> TemplateEngine:
    """Template engine ni olish"""
    global _template_engine
    if _template_engine is None:
        _template_engine = TemplateEngine()
    return _template_engine


async def render_template(
    template_name: str,
    **context
) -> HTMLResponse:
    """
    Template ni render qilib HTMLResponse qaytarish
    
    Misol:
        @app.get("/")
        async def index():
            return await render_template("index.html", 
                                        ism="Ali",
                                        yosh=25)
    """
    engine = get_template_engine()
    html_content = await engine.render_async(template_name, **context)
    return HTMLResponse(content=html_content)


# Django-style template tags (misol)
class TemplateTag:
    """Custom template tags uchun base class"""
    
    def __init__(self, env: Environment):
        self.env = env
    
    def register(self, name: str):
        """Tag ni ro'yxatdan o'tkazish"""
        pass


# Misol: {% load static %} tag
def static(path: str) -> str:
    """Static file URL"""
    return f"/static/{path}"