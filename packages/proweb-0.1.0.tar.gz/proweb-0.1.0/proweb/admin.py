"""ProWeb Admin Panel - Django-style avtomatik admin"""

from typing import List, Dict, Any, Optional, Type
from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from tortoise import Model
from datetime import datetime


class ModelAdmin:
    """
    Model uchun Admin konfiguratsiyasi
    
    Misol:
        class FoydalanuvchiAdmin(ModelAdmin):
            list_display = ['id', 'ism', 'email', 'yaratilgan']
            list_filter = ['faol']
            search_fields = ['ism', 'email']
            ordering = ['-id']
        
        admin_site.register(Foydalanuvchi, FoydalanuvchiAdmin)
    """
    
    # Ro'yxatda ko'rsatiladigan ustunlar
    list_display: List[str] = ['id']
    
    # Filtrlash uchun fieldlar
    list_filter: List[str] = []
    
    # Qidiruv fieldlari
    search_fields: List[str] = []
    
    # Tartiblash
    ordering: List[str] = ['-id']
    
    # Sahifadagi obyektlar soni
    list_per_page: int = 50
    
    # O'zgartirib bo'lmaydigan fieldlar
    readonly_fields: List[str] = []
    
    # Fieldset (guruhlash)
    fieldsets: Optional[List[tuple]] = None
    
    # Inline modellar
    inlines: List[Any] = []
    
    def __init__(self, model: Type[Model]):
        self.model = model
        self.model_name = model.__name__.lower()
    
    async def get_queryset(self, request: Request):
        """Queryset olish"""
        return await self.model.all()
    
    async def get_object(self, object_id: int):
        """Bitta obyekt olish"""
        return await self.model.get(id=object_id)
    
    def get_list_display(self):
        """Ko'rsatiladigan ustunlarni olish"""
        return self.list_display or ['id']
    
    def get_search_fields(self):
        """Qidiruv fieldlarini olish"""
        return self.search_fields
    
    def has_add_permission(self, request: Request) -> bool:
        """Qo'shish huquqi"""
        return True
    
    def has_change_permission(self, request: Request) -> bool:
        """O'zgartirish huquqi"""
        return True
    
    def has_delete_permission(self, request: Request) -> bool:
        """O'chirish huquqi"""
        return True


class AdminSite:
    """
    Admin panel asosiy klassi
    
    Misol:
        admin_site = AdminSite()
        admin_site.register(Foydalanuvchi, FoydalanuvchiAdmin)
    """
    
    def __init__(self, name: str = "ProWeb Admin"):
        self.name = name
        self._registry: Dict[Type[Model], ModelAdmin] = {}
        self.router = APIRouter(prefix="/admin", tags=["Admin"])
        self._setup_routes()
    
    def register(
        self,
        model: Type[Model],
        admin_class: Optional[Type[ModelAdmin]] = None
    ):
        """
        Modelni admin panelga ro'yxatdan o'tkazish
        
        Args:
            model: Tortoise Model klassi
            admin_class: ModelAdmin klassi (ixtiyoriy)
        """
        if admin_class is None:
            admin_class = ModelAdmin
        
        self._registry[model] = admin_class(model)
    
    def _setup_routes(self):
        """Admin panel routelarini sozlash"""
        
        @self.router.get("/", response_class=HTMLResponse)
        async def admin_index(request: Request):
            """Admin bosh sahifa"""
            html = self._render_index()
            return HTMLResponse(content=html)
        
        @self.router.get("/{model_name}/", response_class=HTMLResponse)
        async def model_list(request: Request, model_name: str):
            """Model ro'yxati"""
            admin = self._get_admin(model_name)
            objects = await admin.get_queryset(request)
            html = self._render_list(admin, objects)
            return HTMLResponse(content=html)
        
        @self.router.get("/{model_name}/qoshish/", response_class=HTMLResponse)
        async def model_add(request: Request, model_name: str):
            """Yangi obyekt qo'shish"""
            admin = self._get_admin(model_name)
            html = self._render_form(admin, None, is_add=True)
            return HTMLResponse(content=html)
        
        @self.router.post("/{model_name}/qoshish/")
        async def model_add_post(request: Request, model_name: str):
            """Yangi obyekt saqlash"""
            admin = self._get_admin(model_name)
            form_data = await request.form()
            
            # Obyekt yaratish
            obj_data = {k: v for k, v in form_data.items()}
            obj = await admin.model.create(**obj_data)
            
            return RedirectResponse(
                url=f"/admin/{model_name}/",
                status_code=303
            )
        
        @self.router.get("/{model_name}/{object_id}/", response_class=HTMLResponse)
        async def model_change(request: Request, model_name: str, object_id: int):
            """Obyektni o'zgartirish"""
            admin = self._get_admin(model_name)
            obj = await admin.get_object(object_id)
            html = self._render_form(admin, obj, is_add=False)
            return HTMLResponse(content=html)
        
        @self.router.post("/{model_name}/{object_id}/")
        async def model_change_post(
            request: Request,
            model_name: str,
            object_id: int
        ):
            """Obyektni saqlash"""
            admin = self._get_admin(model_name)
            obj = await admin.get_object(object_id)
            form_data = await request.form()
            
            # Obyektni yangilash
            for field, value in form_data.items():
                setattr(obj, field, value)
            await obj.save()
            
            return RedirectResponse(
                url=f"/admin/{model_name}/",
                status_code=303
            )
        
        @self.router.post("/{model_name}/{object_id}/ochirish/")
        async def model_delete(
            request: Request,
            model_name: str,
            object_id: int
        ):
            """Obyektni o'chirish"""
            admin = self._get_admin(model_name)
            obj = await admin.get_object(object_id)
            await obj.delete()
            
            return RedirectResponse(
                url=f"/admin/{model_name}/",
                status_code=303
            )
    
    def _get_admin(self, model_name: str) -> ModelAdmin:
        """Model adminni olish"""
        for model, admin in self._registry.items():
            if model.__name__.lower() == model_name:
                return admin
        raise HTTPException(status_code=404, detail="Model topilmadi")
    
    def _render_index(self) -> str:
        """Admin index sahifasini render qilish"""
        models_html = ""
        for model, admin in self._registry.items():
            model_name = model.__name__
            models_html += f'''
            <div class="admin-model">
                <h3>{model_name}</h3>
                <a href="/admin/{model_name.lower()}/">Ko'rish</a>
                <a href="/admin/{model_name.lower()}/qoshish/">Qo'shish</a>
            </div>
            '''
        
        return f'''
        <!DOCTYPE html>
        <html lang="uz">
        <head>
            <meta charset="UTF-8">
            <title>{self.name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1 {{ color: #417690; }}
                .admin-model {{ 
                    background: #f9f9f9; 
                    padding: 15px; 
                    margin: 10px 0;
                    border-radius: 5px;
                }}
                .admin-model a {{ 
                    margin-right: 10px; 
                    color: #417690;
                    text-decoration: none;
                }}
            </style>
        </head>
        <body>
            <h1>{self.name}</h1>
            <div class="models-list">
                {models_html}
            </div>
        </body>
        </html>
        '''
    
    def _render_list(self, admin: ModelAdmin, objects: List) -> str:
        """Ro'yxat sahifasini render qilish"""
        model_name = admin.model.__name__
        
        # Jadval sarlavhalari
        headers = "".join(
            f"<th>{field}</th>" 
            for field in admin.get_list_display()
        )
        
        # Jadval qatorlari
        rows = ""
        for obj in objects:
            cells = "".join(
                f"<td>{getattr(obj, field, '')}</td>"
                for field in admin.get_list_display()
            )
            rows += f'''
            <tr>
                {cells}
                <td>
                    <a href="/admin/{model_name.lower()}/{obj.id}/">Tahrirlash</a>
                </td>
            </tr>
            '''
        
        return f'''
        <!DOCTYPE html>
        <html lang="uz">
        <head>
            <meta charset="UTF-8">
            <title>{model_name} - Admin</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                table {{ width: 100%; border-collapse: collapse; }}
                th, td {{ padding: 10px; text-align: left; border: 1px solid #ddd; }}
                th {{ background: #417690; color: white; }}
                a {{ color: #417690; text-decoration: none; }}
            </style>
        </head>
        <body>
            <h1>{model_name} ro'yxati</h1>
            <a href="/admin/{model_name.lower()}/qoshish/">➕ Yangi qo'shish</a>
            <table>
                <thead>
                    <tr>{headers}<th>Amallar</th></tr>
                </thead>
                <tbody>{rows}</tbody>
            </table>
        </body>
        </html>
        '''
    
    def _render_form(
        self,
        admin: ModelAdmin,
        obj: Optional[Model],
        is_add: bool
    ) -> str:
        """Forma sahifasini render qilish"""
        model_name = admin.model.__name__
        title = "Yangi qo'shish" if is_add else "Tahrirlash"
        
        # Form fieldlar (soddalashtirilgan)
        form_fields = ""
        for field_name in admin.model._meta.fields_map.keys():
            if field_name not in ['id'] + admin.readonly_fields:
                value = getattr(obj, field_name, '') if obj else ''
                form_fields += f'''
                <div class="form-group">
                    <label>{field_name}:</label>
                    <input type="text" name="{field_name}" value="{value}">
                </div>
                '''
        
        action = f"/admin/{model_name.lower()}/qoshish/" if is_add else f"/admin/{model_name.lower()}/{obj.id}/"
        
        return f'''
        <!DOCTYPE html>
        <html lang="uz">
        <head>
            <meta charset="UTF-8">
            <title>{title} - {model_name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .form-group {{ margin: 15px 0; }}
                label {{ display: block; font-weight: bold; }}
                input {{ width: 100%; padding: 8px; }}
                button {{ 
                    background: #417690; 
                    color: white; 
                    padding: 10px 20px;
                    border: none;
                    cursor: pointer;
                }}
            </style>
        </head>
        <body>
            <h1>{title}: {model_name}</h1>
            <form method="POST" action="{action}">
                {form_fields}
                <button type="submit">Saqlash</button>
            </form>
        </body>
        </html>
        '''


# Global admin site
admin_site = AdminSite()