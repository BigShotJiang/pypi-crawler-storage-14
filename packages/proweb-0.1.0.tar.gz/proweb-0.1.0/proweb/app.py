"""ProWeb asosiy klass - Flask-style kodlash bilan FastAPI"""

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from tortoise import Tortoise
from typing import Callable, Optional, Any, Dict, List
import os
from pathlib import Path

from .templates import TemplateEngine
from .config import Settings


class ProWeb:
    """
    ProWeb asosiy klass - Flask-style kodlash uslubi
    
    Misol:
        app = ProWeb(__name__)
        
        @app.route('/')
        async def index():
            return {"xabar": "Salom Dunyo!"}
    """
    
    def __init__(
        self,
        import_name: str,
        static_folder: str = "static",
        template_folder: str = "templates",
        **kwargs
    ):
        self.import_name = import_name
        self.root_path = self._get_root_path(import_name)
        
        # FastAPI instance yaratish
        self.app = FastAPI(
            title=kwargs.get('title', 'ProWeb Ilova'),
            description=kwargs.get('description', 'ProWeb bilan yaratilgan'),
            version=kwargs.get('version', '1.0.0'),
        )
        
        # Sozlamalar
        self.settings = Settings()
        
        # Template engine
        self.template_folder = os.path.join(self.root_path, template_folder)
        self.templates = TemplateEngine(self.template_folder)
        
        # Static files
        static_path = os.path.join(self.root_path, static_folder)
        if os.path.exists(static_path):
            self.app.mount("/static", StaticFiles(directory=static_path), name="static")
        
        # CORS
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # Request context
        @self.app.middleware("http")
        async def add_request_context(request: Request, call_next):
            request.state.app = self
            response = await call_next(request)
            return response
        
        # Startup va shutdown events
        @self.app.on_event("startup")
        async def startup():
            await self.init_db()
        
        @self.app.on_event("shutdown")
        async def shutdown():
            await Tortoise.close_connections()
    
    def _get_root_path(self, import_name: str) -> str:
        """Root path aniqlash"""
        mod = __import__(import_name, fromlist=[''])
        return os.path.dirname(os.path.abspath(mod.__file__))
    
    async def init_db(self):
        """Ma'lumotlar bazasini ishga tushirish"""
        await Tortoise.init(
            db_url=self.settings.DATABASE_URL,
            modules={'models': self.settings.MODELS_MODULES}
        )
        await Tortoise.generate_schemas()
    
    def route(
        self,
        path: str,
        methods: List[str] = ["GET"],
        **kwargs
    ):
        """
        Flask-style route dekorator
        
        Misol:
            @app.route('/foydalanuvchilar', methods=['GET', 'POST'])
            async def foydalanuvchilar():
                return {"data": "..."}
        """
        def decorator(func: Callable) -> Callable:
            # FastAPI route qo'shish
            for method in methods:
                if method == "GET":
                    self.app.get(path, **kwargs)(func)
                elif method == "POST":
                    self.app.post(path, **kwargs)(func)
                elif method == "PUT":
                    self.app.put(path, **kwargs)(func)
                elif method == "DELETE":
                    self.app.delete(path, **kwargs)(func)
                elif method == "PATCH":
                    self.app.patch(path, **kwargs)(func)
            return func
        return decorator
    
    def get(self, path: str, **kwargs):
        """GET so'rov uchun qisqa dekorator"""
        return self.route(path, methods=["GET"], **kwargs)
    
    def post(self, path: str, **kwargs):
        """POST so'rov uchun qisqa dekorator"""
        return self.route(path, methods=["POST"], **kwargs)
    
    def put(self, path: str, **kwargs):
        """PUT so'rov uchun qisqa dekorator"""
        return self.route(path, methods=["PUT"], **kwargs)
    
    def delete(self, path: str, **kwargs):
        """DELETE so'rov uchun qisqa dekorator"""
        return self.route(path, methods=["DELETE"], **kwargs)
    
    def render_template(self, template_name: str, **context):
        """Template render qilish (Jinja2)"""
        return self.templates.render(template_name, **context)
    
    def run(
        self,
        host: str = "127.0.0.1",
        port: int = 8000,
        reload: bool = True,
        **kwargs
    ):
        """Serverni ishga tushirish"""
        import uvicorn
        uvicorn.run(
            self.app,
            host=host,
            port=port,
            reload=reload,
            **kwargs
        )
    
    def include_router(self, router, prefix: str = "", tags: List[str] = None):
        """Router qo'shish (modullar uchun)"""
        self.app.include_router(router, prefix=prefix, tags=tags or [])


# Global app instance (ixtiyoriy)
current_app: Optional[ProWeb] = None