"""
ProWeb - O'zbekcha To'liq Asinxron Web Framework
FastAPI + Tortoise ORM + Flask-style coding + Django-style features
"""

__version__ = "0.1.0"
__author__ = "ProWeb Team"

from .app import ProWeb
from .orm import Model, fields
from .routing import route, get, post, put, delete
from .templates import render_template
from .admin import admin_site

__all__ = [
    "ProWeb",
    "Model",
    "fields",
    "route",
    "get",
    "post",
    "put",
    "delete",
    "render_template",
    "admin_site",
]