"""ProWeb sozlamalari - Django-style settings"""

from pydantic_settings import BaseSettings
from typing import List, Optional
import os


class Settings(BaseSettings):
    """
    ProWeb asosiy sozlamalari
    
    .env fayldan o'qiladi yoki environment variablelardan
    """
    
    # Asosiy sozlamalar
    DEBUG: bool = True
    SECRET_KEY: str = "o'zgartiring-bu-maxfiy-kalit"
    
    # Ma'lumotlar bazasi
    DATABASE_URL: str = "sqlite://db.sqlite3"
    
    # PostgreSQL misoli:
    # DATABASE_URL: str = "postgres://user:pass@localhost:5432/dbname"
    
    # MySQL misoli:
    # DATABASE_URL: str = "mysql://user:pass@localhost:3306/dbname"
    
    # ORM sozlamalari
    MODELS_MODULES: List[str] = ["apps.models"]
    GENERATE_SCHEMAS: bool = True
    
    # Server sozlamalari
    HOST: str = "127.0.0.1"
    PORT: int = 8000
    RELOAD: bool = True
    
    # CORS
    ALLOWED_ORIGINS: List[str] = ["*"]
    
    # Static va Media
    STATIC_URL: str = "/static/"
    STATIC_ROOT: str = "static"
    MEDIA_URL: str = "/media/"
    MEDIA_ROOT: str = "media"
    
    # Templates
    TEMPLATES_DIR: str = "templates"
    
    # Admin panel
    ADMIN_PREFIX: str = "/admin"
    ADMIN_TITLE: str = "ProWeb Admin Panel"
    
    # Xavfsizlik
    ALLOWED_HOSTS: List[str] = ["*"]
    
    # Email sozlamalari (ixtiyoriy)
    EMAIL_HOST: Optional[str] = None
    EMAIL_PORT: Optional[int] = 587
    EMAIL_USER: Optional[str] = None
    EMAIL_PASSWORD: Optional[str] = None
    EMAIL_USE_TLS: bool = True
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: Optional[str] = "proweb.log"
    
    # Tillar
    DEFAULT_LANGUAGE: str = "uz"
    LANGUAGES: List[str] = ["uz", "ru", "en"]
    
    # Vaqt zonasi
    TIMEZONE: str = "Asia/Tashkent"
    
    # Sessiya
    SESSION_SECRET_KEY: str = "session-maxfiy-kalit"
    SESSION_MAX_AGE: int = 3600 * 24 * 7  # 7 kun
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Sozlamalarni yuklash
def get_settings() -> Settings:
    """Sozlamalarni olish"""
    return Settings()


# Tortoise ORM konfiguratsiyasi
def get_tortoise_config(settings: Settings) -> dict:
    """
    Tortoise ORM uchun konfiguratsiya
    """
    return {
        "connections": {
            "default": settings.DATABASE_URL
        },
        "apps": {
            "models": {
                "models": settings.MODELS_MODULES + ["aerich.models"],
                "default_connection": "default",
            }
        },
        "use_tz": True,
        "timezone": settings.TIMEZONE,
    }


# Aerich (migration tool) konfiguratsiyasi
TORTOISE_ORM = {
    "connections": {"default": os.getenv("DATABASE_URL", "sqlite://db.sqlite3")},
    "apps": {
        "models": {
            "models": ["apps.models", "aerich.models"],
            "default_connection": "default",
        },
    },
}