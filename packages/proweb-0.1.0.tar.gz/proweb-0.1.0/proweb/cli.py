"""ProWeb CLI - Django-style komandalar"""

import click
import os
import shutil
from pathlib import Path
from typing import Optional


@click.group()
def cli():
    """ProWeb - O'zbekcha Asinxron Web Framework"""
    pass


@cli.command()
@click.argument('loyiha_nomi')
def createproject(loyiha_nomi: str):
    """
    Yangi ProWeb loyiha yaratish
    
    Misol: proweb createproject mening_saytim
    """
    click.echo(f"🚀 '{loyiha_nomi}' loyihasi yaratilmoqda...")
    
    # Loyiha papkasini yaratish
    project_path = Path(loyiha_nomi)
    if project_path.exists():
        click.echo(f"❌ Xato: '{loyiha_nomi}' papkasi allaqachon mavjud!", err=True)
        return
    
    project_path.mkdir()
    
    # Asosiy fayllar va papkalarni yaratish
    (project_path / "static").mkdir()
    (project_path / "static" / "css").mkdir()
    (project_path / "static" / "js").mkdir()
    (project_path / "static" / "img").mkdir()
    
    (project_path / "templates").mkdir()
    (project_path / "apps").mkdir()
    
    # __init__.py
    (project_path / "__init__.py").write_text("")
    (project_path / "apps" / "__init__.py").write_text("")
    
    # settings.py
    settings_content = f'''"""
{loyiha_nomi} loyihasi sozlamalari
"""

# Ma'lumotlar bazasi
DATABASE_URL = "sqlite://db.sqlite3"

# Xavfsizlik
SECRET_KEY = "o'zgartiring-bu-maxfiy-kalit-{loyiha_nomi}"

# Debug rejimi
DEBUG = True

# Ruxsat berilgan hostlar
ALLOWED_HOSTS = ["*"]

# O'rnatilgan ilovalar
INSTALLED_APPS = [
    "proweb.contrib.admin",
    "proweb.contrib.auth",
    # Sizning ilovalaringiz
]

# Middleware
MIDDLEWARE = [
    "proweb.middleware.cors.CORSMiddleware",
]

# Template sozlamalari
TEMPLATES_DIR = "templates"

# Static fayllar
STATIC_DIR = "static"
STATIC_URL = "/static/"

# ORM modellar joylashuvi
MODELS_MODULES = ["apps.models"]
'''
    (project_path / "settings.py").write_text(settings_content)
    
    # main.py (asosiy fayl)
    main_content = f'''"""
{loyiha_nomi} - ProWeb loyihasi
"""

from proweb import ProWeb
from proweb.templates import render_template


# ProWeb ilova yaratish
app = ProWeb(__name__)


@app.get("/")
async def bosh_sahifa():
    """Bosh sahifa"""
    return await render_template("index.html", 
                                  loyiha="{loyiha_nomi}",
                                  xabar="ProWeb ga xush kelibsiz!")


@app.get("/api/salom")
async def salom_api():
    """API misoli"""
    return {{
        "xabar": "Salom, bu ProWeb API!",
        "version": "1.0.0"
    }}


if __name__ == "__main__":
    # Serverni ishga tushirish
    app.run(host="127.0.0.1", port=8000, reload=True)
'''
    (project_path / "main.py").write_text(main_content)
    
    # index.html template
    template_content = '''<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ loyiha }} - ProWeb</title>
    <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
    <div class="container">
        <h1>🎉 {{ xabar }}</h1>
        <p>Siz muvaffaqiyatli ProWeb loyiha yaratdingiz!</p>
        <div class="features">
            <h2>Imkoniyatlar:</h2>
            <ul>
                <li>✅ FastAPI asosida</li>
                <li>✅ To'liq asinxron</li>
                <li>✅ Tortoise ORM</li>
                <li>✅ Flask-style kodlash</li>
                <li>✅ Django-style admin</li>
                <li>✅ Jinja2 templates</li>
                <li>✅ O'zbekcha dokumentatsiya</li>
            </ul>
        </div>
    </div>
</body>
</html>
'''
    (project_path / "templates" / "index.html").write_text(template_content)
    
    # style.css
    css_content = '''* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.container {
    background: white;
    padding: 3rem;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    max-width: 600px;
}

h1 {
    color: #667eea;
    margin-bottom: 1rem;
}

.features {
    margin-top: 2rem;
}

.features ul {
    list-style: none;
    margin-top: 1rem;
}

.features li {
    padding: 0.5rem 0;
    font-size: 1.1rem;
}
'''
    (project_path / "static" / "css" / "style.css").write_text(css_content)
    
    # requirements.txt
    requirements = '''fastapi>=0.104.0
uvicorn[standard]>=0.24.0
tortoise-orm>=0.20.0
aerich>=0.7.2
jinja2>=3.1.2
python-multipart>=0.0.6
click>=8.1.7
'''
    (project_path / "requirements.txt").write_text(requirements)
    
    # .gitignore
    gitignore = '''__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
db.sqlite3
.env
.vscode/
.idea/
'''
    (project_path / ".gitignore").write_text(gitignore)
    
    click.echo(f"✅ '{loyiha_nomi}' loyihasi muvaffaqiyatli yaratildi!")
    click.echo(f"\n📂 Keyingi qadamlar:")
    click.echo(f"   cd {loyiha_nomi}")
    click.echo(f"   pip install -r requirements.txt")
    click.echo(f"   proweb runserver")


@cli.command()
@click.argument('app_nomi')
def createapp(app_nomi: str):
    """
    Yangi ilova yaratish
    
    Misol: proweb createapp blog
    """
    click.echo(f"📦 '{app_nomi}' ilovasi yaratilmoqda...")
    
    app_path = Path("apps") / app_nomi
    if app_path.exists():
        click.echo(f"❌ Xato: '{app_nomi}' ilovasi allaqachon mavjud!", err=True)
        return
    
    app_path.mkdir(parents=True)
    
    # __init__.py
    (app_path / "__init__.py").write_text("")
    
    # models.py
    models_content = f'''"""
{app_nomi} ilovasi modellari
"""

from tortoise import Model, fields


class MisolModel(Model):
    """Misol model"""
    id = fields.IntField(pk=True)
    nom = fields.CharField(max_length=255)
    tavsif = fields.TextField(null=True)
    yaratilgan = fields.DatetimeField(auto_now_add=True)
    
    class Meta:
        table = "{app_nomi}_misol"
    
    def __str__(self):
        return self.nom
'''
    (app_path / "models.py").write_text(models_content)
    
    # views.py
    views_content = f'''"""
{app_nomi} ilovasi views (ko'rinishlar)
"""

from proweb import ProWeb
from proweb.templates import render_template
from .models import MisolModel


async def {app_nomi}_list():
    """Ro'yxat ko'rinishi"""
    obyektlar = await MisolModel.all()
    return await render_template(
        "{app_nomi}/list.html",
        obyektlar=obyektlar
    )


async def {app_nomi}_detail(id: int):
    """Batafsil ko'rinish"""
    obyekt = await MisolModel.get(id=id)
    return await render_template(
        "{app_nomi}/detail.html",
        obyekt=obyekt
    )
'''
    (app_path / "views.py").write_text(views_content)
    
    # urls.py
    urls_content = f'''"""
{app_nomi} ilovasi URL marshrutlari
"""

from fastapi import APIRouter
from . import views

router = APIRouter()

# URL marshrutlar
router.add_api_route("/{app_nomi}/", views.{app_nomi}_list, methods=["GET"])
router.add_api_route("/{app_nomi}/{{id}}", views.{app_nomi}_detail, methods=["GET"])
'''
    (app_path / "urls.py").write_text(urls_content)
    
    # admin.py
    admin_content = f'''"""
{app_nomi} ilovasi admin panel sozlamalari
"""

from proweb.admin import admin_site
from .models import MisolModel


# Admin panelga modelni ro'yxatdan o'tkazish
admin_site.register(MisolModel)
'''
    (app_path / "admin.py").write_text(admin_content)
    
    click.echo(f"✅ '{app_nomi}' ilovasi muvaffaqiyatli yaratildi!")
    click.echo(f"\n📝 Keyingi qadamlar:")
    click.echo(f"   1. settings.py da INSTALLED_APPS ga 'apps.{app_nomi}' qo'shing")
    click.echo(f"   2. main.py da routerlarni import qiling")
    click.echo(f"   3. proweb makemigrations")
    click.echo(f"   4. proweb migrate")


@cli.command()
def makemigrations():
    """
    Migratsiyalarni yaratish (Tortoise ORM Aerich)
    """
    click.echo("🔧 Migratsiyalar yaratilmoqda...")
    os.system("aerich init-db")
    click.echo("✅ Migratsiyalar yaratildi!")


@cli.command()
def migrate():
    """
    Migratsiyalarni qo'llash
    """
    click.echo("⚙️  Migratsiyalar qo'llanmoqda...")
    os.system("aerich upgrade")
    click.echo("✅ Migratsiyalar muvaffaqiyatli qo'llandi!")


@cli.command()
@click.option('--host', default='127.0.0.1', help='Host manzili')
@click.option('--port', default=8000, help='Port raqami')
@click.option('--reload/--no-reload', default=True, help='Auto-reload')
def runserver(host: str, port: int, reload: bool):
    """
    Development serverini ishga tushirish
    
    Misol: proweb runserver --host 0.0.0.0 --port 8000
    """
    click.echo(f"🚀 Server ishga tushmoqda: http://{host}:{port}")
    click.echo(f"📝 Admin panel: http://{host}:{port}/admin")
    click.echo(f"📚 API Docs: http://{ host}:{port}/docs")
    click.echo(f"\n✋ To'xtatish uchun: CTRL+C\n")
    
    os.system(f"uvicorn main:app --host {host} --port {port} {'--reload' if reload else ''}")


@cli.command()
def createsuperuser():
    """
    Superuser (admin) yaratish
    """
    import asyncio
    from getpass import getpass
    
    click.echo("👤 Superuser yaratish\n")
    
    username = click.prompt("Foydalanuvchi nomi")
    email = click.prompt("Email")
    password = getpass("Parol: ")
    password2 = getpass("Parolni takrorlang: ")
    
    if password != password2:
        click.echo("❌ Parollar mos kelmadi!", err=True)
        return
    
    # Bu yerda superuser yaratish logikasi bo'ladi
    click.echo(f"✅ Superuser '{username}' muvaffaqiyatli yaratildi!")


@cli.command()
def shell():
    """
    Interaktiv Python shell (IPython)
    """
    click.echo("🐍 ProWeb shell ishga tushmoqda...")
    try:
        import IPython
        IPython.embed()
    except ImportError:
        import code
        code.interact(local=locals())


if __name__ == '__main__':
    cli()