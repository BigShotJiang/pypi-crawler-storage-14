"""ProWeb ORM - Tortoise ORM bilan integratsiya"""

from tortoise import Model as TortoiseModel, fields as tortoise_fields
from typing import Optional, List, Dict, Any


# Tortoise fields ni eksport qilish
class fields:
    """ORM field turlari"""
    IntField = tortoise_fields.IntField
    CharField = tortoise_fields.CharField
    TextField = tortoise_fields.TextField
    BooleanField = tortoise_fields.BooleanField
    DatetimeField = tortoise_fields.DatetimeField
    DateField = tortoise_fields.DateField
    DecimalField = tortoise_fields.DecimalField
    FloatField = tortoise_fields.FloatField
    JSONField = tortoise_fields.JSONField
    
    # Munosabatlar
    ForeignKeyField = tortoise_fields.ForeignKeyField
    OneToOneField = tortoise_fields.OneToOneField
    ManyToManyField = tortoise_fields.ManyToManyField
    
    # Relational fields
    ReverseRelation = tortoise_fields.ReverseRelation


class Model(TortoiseModel):
    """
    ProWeb Base Model - Django-style
    
    Misol:
        class Foydalanuvchi(Model):
            ism = fields.CharField(max_length=100)
            email = fields.CharField(max_length=255, unique=True)
            yosh = fields.IntField()
            
            class Meta:
                table = "foydalanuvchilar"
            
            def __str__(self):
                return self.ism
    """
    
    class Meta:
        abstract = True
    
    @classmethod
    async def yaratish(cls, **kwargs):
        """Yangi obyekt yaratish"""
        return await cls.create(**kwargs)
    
    @classmethod
    async def barchasini_olish(cls):
        """Barcha obyektlarni olish"""
        return await cls.all()
    
    @classmethod
    async def olish(cls, **filters):
        """Bitta obyektni olish"""
        return await cls.get(**filters)
    
    @classmethod
    async def filtr(cls, **filters):
        """Filtrlangan obyektlar"""
        return await cls.filter(**filters)
    
    async def saqlash(self):
        """Obyektni saqlash"""
        await self.save()
    
    async def ochirish(self):
        """Obyektni o'chirish"""
        await self.delete()
    
    async def yangilash(self, **kwargs):
        """Obyektni yangilash"""
        await self.update_from_dict(kwargs)
        await self.save()


class Manager:
    """
    Django-style Manager
    
    Misol:
        class FoydalanuvchiManager(Manager):
            async def faollar(self):
                return await self.filter(faol=True)
        
        class Foydalanuvchi(Model):
            objects = FoydalanuvchiManager()
    """
    
    def __init__(self, model_class=None):
        self.model_class = model_class
    
    async def all(self):
        """Barcha obyektlar"""
        return await self.model_class.all()
    
    async def filter(self, **kwargs):
        """Filtrlash"""
        return await self.model_class.filter(**kwargs)
    
    async def get(self, **kwargs):
        """Bitta obyekt"""
        return await self.model_class.get(**kwargs)
    
    async def create(self, **kwargs):
        """Yaratish"""
        return await self.model_class.create(**kwargs)
    
    async def get_or_create(self, defaults=None, **kwargs):
        """Olish yoki yaratish"""
        return await self.model_class.get_or_create(defaults=defaults, **kwargs)
    
    async def update_or_create(self, defaults=None, **kwargs):
        """Yangilash yoki yaratish"""
        return await self.model_class.update_or_create(defaults=defaults, **kwargs)
    
    async def count(self):
        """Hisoblash"""
        return await self.model_class.all().count()


# Django-style querysetlar uchun yordamchi funksiyalar
async def get_object_or_404(model_class, **kwargs):
    """Obyektni olish yoki 404 xato"""
    try:
        return await model_class.get(**kwargs)
    except Exception:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Obyekt topilmadi")


async def bulk_create(model_class, objects: List[Dict[str, Any]]):
    """Ko'p obyektlarni yaratish"""
    return await model_class.bulk_create([model_class(**obj) for obj in objects])