"""
ProWeb - O'zbekcha To'liq Asinxron Web Framework
"""

from setuptools import setup, find_packages

with open("README_UZ.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="proweb",
    version="0.1.0",
    author="ProWeb Team",
    author_email="info@proweb.uz",
    description="O'zbekcha to'liq asinxron web framework - FastAPI + Tortoise ORM + Flask-style",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/proweb/proweb",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "fastapi>=0.104.0",
        "uvicorn[standard]>=0.24.0",
        "tortoise-orm>=0.20.0",
        "aerich>=0.7.2",
        "jinja2>=3.1.2",
        "python-multipart>=0.0.6",
        "click>=8.1.7",
        "pydantic>=2.0.0",
        "pydantic-settings>=2.0.0",
    ],
    extras_require={
        "postgresql": ["asyncpg>=0.28.0"],
        "mysql": ["aiomysql>=0.2.0"],
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.7.0",
            "flake8>=6.1.0",
            "mypy>=1.5.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "proweb=proweb.cli:cli",
        ],
    },
    include_package_data=True,
    package_data={
        "proweb": [
            "templates/**/*.html",
            "static/**/*",
        ],
    },
    keywords="web framework fastapi tortoise-orm async uzbek o'zbek asinxron",
    project_urls={
        "Documentation": "https://proweb.uz/docs",
        "Source": "https://github.com/proweb/proweb",
        "Bug Reports": "https://github.com/proweb/proweb/issues",
    },
)