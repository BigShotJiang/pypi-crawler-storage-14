def hello():
    print("Hello 1337!")
