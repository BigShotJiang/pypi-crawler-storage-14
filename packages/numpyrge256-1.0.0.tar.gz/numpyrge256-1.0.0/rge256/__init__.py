from .rge256 import RGE256

__all__ = ["RGE256"]
