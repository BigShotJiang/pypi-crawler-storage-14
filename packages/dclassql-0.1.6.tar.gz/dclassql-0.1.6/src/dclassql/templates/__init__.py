# Package marker for template resources.
