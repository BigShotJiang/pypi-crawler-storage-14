# Doubao MCP Server

MCP server that exposes tools for creating and querying Doubao generation tasks via the
`doubao-seedance-1-0-pro-250528` model.

## Prerequisites

- Python 3.10+
- Conda environment `doubao-mcp` (or any environment with the dependencies installed)
- Doubao Ark API key exported as `ARK_API_KEY`

## Installation

```powershell
conda activate doubao-mcp
pip install -e .
```

## Running the server

1. Set the API key before launching:

   ```powershell
   $env:ARK_API_KEY = "<your_api_key>"
   ```

2. Start the MCP server (stdio):

   ```powershell
   doubao-mcp-server
   ```

   or run the module directly:

   ```powershell
   python -m doubao_mcp.server
   ```

## Tool reference

### `create_viceo`

| Parameter | Type | Description |
| --------- | ---- | ----------- |
| `text`    | str  | Required text prompt describing the video storyline. |
| `ratio`   | str? | Optional ratio (for example `16:9`). |
| `resolution` | str? | Optional resolution such as `720p` or `1080p`. |
| `duration` | int? | Optional duration in seconds. |
| `frames_per_second` | int? | Optional frame rate. |
| `seed` | int? | Optional deterministic seed. |

Returns a structured payload containing the task `id`, the exact request JSON (only documented fields are sent), the raw Doubao response, plus `formatted_request`/`formatted_response` strings for easy viewing.

### `get_video_result`

| Parameter | Type | Description |
| --------- | ---- | ----------- |
| `task_id` | str  | Doubao task id returned by `create_viceo`. |

Returns both the raw JSON payload from `GET https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks/<task_id>` and a `formatted_response` string.
