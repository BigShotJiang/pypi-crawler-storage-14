# -*- coding: utf-8 -*-
"""Static JSON entities used by the Doubao MCP server."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any, Dict, Optional

CREATE_VIDEO_REQUEST_JSON: Dict[str, Any] = {
    "model": "doubao-seedance-1-0-pro-250528",
    "content": [
        {
            "type": "text",
            "text": "多个镜头。一名侦探进入一间光线昏暗的房间。他检查桌上的线索，手里拿起桌上的某个物品。镜头转向他正在思索。 --ratio 16:9",
        }
    ],
}
"""Example JSON payload for 创建 Doubao 生成任务的 POST 请求."""

CREATE_VIDEO_RESPONSE_JSON: Dict[str, str] = {
    "id": "cgt-2025******-****",
}
"""Example JSON response returned after 创建任务."""

VIDEO_TASK_RESULT_JSON: Dict[str, Any] = {
    "id": "cgt-2025******-****",
    "model": "doubao-seedance-1-0-pro-250528",
    "status": "succeeded",
    "content": {
        "video_url": "https://ark-content-generation-cn-beijing.tos-cn-beijing.volces.com/doubao-seedance-1-0-pro/****",
    },
    "seed": 10,
    "resolution": "720p",
    "ratio": "16:9",
    "duration": 5,
    "framespersecond": 24,
    "usage": {
        "completion_tokens": 108900,
        "total_tokens": 108900,
    },
    "created_at": 1743414619,
    "updated_at": 1743414673,
}
"""Example JSON returned by 查询任务接口."""


def format_json(data: Any) -> str:
    """Return pretty JSON string with UTF-8 characters preserved."""

    return json.dumps(data, ensure_ascii=False, indent=2, sort_keys=False)


def build_create_video_payload(
    text: str,
    model_name: str,
    extra_params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Return a payload dict matching CREATE_VIDEO_REQUEST_JSON with updated content."""

    payload = deepcopy(CREATE_VIDEO_REQUEST_JSON)
    payload["model"] = model_name
    payload["content"][0]["text"] = text.strip()

    if extra_params:
        for key, value in extra_params.items():
            if value is None:
                continue
            payload[key] = value

    return payload


def build_create_video_response(
    task_id: str,
    payload: Dict[str, Any],
    raw_response: Dict[str, Any],
) -> Dict[str, Any]:
    """Return a formatted response payload for the create call."""

    response = deepcopy(CREATE_VIDEO_RESPONSE_JSON)
    response["id"] = task_id

    return {
        "id": task_id,
        "request": payload,
        "response": raw_response,
        "formatted_request": format_json(payload),
        "formatted_response": format_json(raw_response),
        "template": response,
    }


def build_video_task_result(data: Dict[str, Any]) -> Dict[str, Any]:
    """Return structured + formatted video task data plus waiting hint."""

    status = str(data.get("status", "")).lower()
    waiting = status in {"running", "pending", "queued"}
    result: Dict[str, Any] = {
        "response": data,
        "formatted_response": format_json(data),
        "status": status or "unknown",
        "waiting": waiting,
    }

    if waiting:
        result[
            "message"
        ] = "Doubao 仍在生成视频，可稍等几秒后继续调用 get_video_result 查询最新状态。"

    return result
