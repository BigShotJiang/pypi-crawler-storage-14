# -*- coding: utf-8 -*-
"""Doubao MCP package."""

from typing import Any

from .entities import (
    CREATE_VIDEO_REQUEST_JSON,
    CREATE_VIDEO_RESPONSE_JSON,
    VIDEO_TASK_RESULT_JSON,
    build_create_video_payload,
    build_create_video_response,
    build_video_task_result,
    format_json,
)

__all__ = [
    "CREATE_VIDEO_REQUEST_JSON",
    "CREATE_VIDEO_RESPONSE_JSON",
    "VIDEO_TASK_RESULT_JSON",
    "build_create_video_payload",
    "build_create_video_response",
    "build_video_task_result",
    "format_json",
    "app",
    "create_viceo",
    "get_video_result",
    "run",
]


def __getattr__(name: str) -> Any:
    if name in {"app", "create_viceo", "get_video_result", "run"}:
        from .server import app, create_viceo, get_video_result, run

        return {
            "app": app,
            "create_viceo": create_viceo,
            "get_video_result": get_video_result,
            "run": run,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
