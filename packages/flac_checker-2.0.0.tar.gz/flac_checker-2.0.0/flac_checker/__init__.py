"""FLAC Checker - Detect fake FLAC files by analyzing frequency spectrum."""

__version__ = "2.0.0"

