"""Core audio analysis functions for detecting fake FLAC files."""

import numpy as np
from scipy.fftpack import rfft
from scipy.signal import savgol_filter
from scipy.signal.windows import hann
import soundfile as sf
from typing import Tuple, Optional


def smooth_spectrum(spectrum: np.ndarray, window_length: int | None = None) -> np.ndarray:
    """
    Smooth the frequency spectrum using Savitzky-Golay filter.
    
    This preserves features better than simple moving average while reducing noise.
    Falls back to moving average if window is too small for Savitzky-Golay.
    
    Args:
        spectrum: Frequency spectrum to smooth
        window_length: Window size for smoothing (default: len(spectrum) // 100)
    
    Returns:
        Smoothed spectrum
    """
    if window_length is None:
        window_length = max(11, len(spectrum) // 100)
    
    # Savitzky-Golay requires window_length to be odd and less than array size
    if window_length % 2 == 0:
        window_length += 1
    if window_length >= len(spectrum):
        window_length = len(spectrum) - 1
        if window_length % 2 == 0:
            window_length -= 1
    
    # Use Savitzky-Golay if possible (better smoothing)
    if window_length >= 5:
        try:
            return savgol_filter(spectrum, window_length, 2)
        except Exception:
            # Fallback to moving average if Savitzky-Golay fails
            pass
    
    # Fallback to moving average
    window = np.ones(int(window_length)) / float(window_length)
    r = np.convolve(spectrum, window, 'valid')
    # Pad to maintain length
    pad = (len(spectrum) - len(r)) // 2
    return np.pad(r, (pad, len(spectrum) - len(r) - pad), mode='edge')


def find_cutoff(
    spectrum_db: np.ndarray,
    dx: float,
    diff_db: float,
    limit_db: float
) -> int:
    """
    Find the frequency cutoff point in the spectrum.
    
    Scans backwards from high frequencies to detect sharp drops characteristic
    of MP3 low-pass filtering.
    
    Args:
        spectrum_db: Frequency spectrum in dB
        dx: Step size for comparison (in frequency bins)
        diff_db: Minimum dB difference to consider a cutoff (in dB)
        limit_db: Maximum dB difference for relative magnitude check (in dB)
    
    Returns:
        Frequency bin index where cutoff occurs, or full spectrum if no cutoff found
    """
    # Remove any NaN or Inf values for processing
    valid_mask = ~(np.isnan(spectrum_db) | np.isinf(spectrum_db))
    if not np.any(valid_mask):
        return len(spectrum_db)
    
    # Find the last valid index (highest frequency with valid data)
    last_valid_idx = len(spectrum_db) - 1
    while last_valid_idx >= 0 and not valid_mask[last_valid_idx]:
        last_valid_idx -= 1
    if last_valid_idx < 0:
        return len(spectrum_db)
    
    last_valid_db = spectrum_db[last_valid_idx]
    
    # Scan backwards from high frequencies to find cutoff
    for i in range(1, int(len(spectrum_db) - dx)):
        idx = len(spectrum_db) - i
        if idx < 0 or idx >= len(spectrum_db) or not valid_mask[idx]:
            continue
        
        current_db = spectrum_db[idx]
        
        # Check if current magnitude is too high relative to last valid (indicates noise/artifacts)
        if current_db - last_valid_db > limit_db:
            break
        
        # Check for significant drop (cutoff indicator)
        prev_idx = int(idx - dx)
        if prev_idx >= 0 and prev_idx < len(spectrum_db) and valid_mask[prev_idx]:
            prev_db = spectrum_db[prev_idx]
            db_drop = prev_db - current_db
            if db_drop > diff_db:
                # Found a significant drop, this is likely the cutoff
                return max(0, idx - dx)
    
    return len(spectrum_db)


def analyze_audio_segment(
    audio: np.ndarray,
    freq: int,
    channel: int,
    start_second: float,
    duration: int = 30
) -> int:
    """
    Analyze a specific segment of audio for frequency cutoff.
    
    Args:
        audio: Audio data array (samples x channels)
        freq: Sample rate
        channel: Channel index to analyze
        start_second: Starting second in the audio
        duration: Number of seconds to analyze (default 30)
    
    Returns:
        Score (0-100) representing percentage of spectrum before cutoff
    """
    samples = len(audio[:, 0])
    total_seconds = samples / freq
    
    # Calculate start and end sample indices
    start_sample = int(start_second * freq)
    end_sample = int(min(start_sample + duration * freq, samples))
    actual_duration = (end_sample - start_sample) / freq
    
    if actual_duration < 1:
        # Segment too short, return 100 (assume authentic if we can't analyze)
        return 100
    
    # Extract segment
    audio_segment = audio[start_sample:end_sample, channel]
    
    # Process segment
    seconds_to_analyze = int(actual_duration)
    spectrum = np.zeros(freq)
    
    # Run over the seconds in this segment
    for t in range(0, seconds_to_analyze - 1):
        # Apply hanning window
        window = hann(freq)
        audio_second = audio_segment[t * freq:(t + 1) * freq] * window
        # Do FFT to add second to frequency spectrum
        spectrum += abs(rfft(audio_second))
    
    # Calculate average of the spectrum
    spectrum /= seconds_to_analyze
    # Convert to dB scale
    spectrum = np.maximum(spectrum, np.finfo(np.float64).eps)
    spectrum_db = 20 * np.log10(spectrum)
    # Smooth frequency spectrum
    spectrum = smooth_spectrum(spectrum_db, window_length=max(11, freq // 100))
    # Find cutoff in frequency spectrum
    cutoff = find_cutoff(spectrum, freq / 50, 2.5, 1.0)
    # Calculate percentage
    out = int(round((cutoff * 100) / freq))
    # Ensure we return at least 1 if a cutoff was found
    if cutoff < freq and out == 0:
        out = 1
    return out


def analyze_audio_file(
    file_path: str,
    channel: int = 0,
    sample_duration: int = 30,
    use_multiple_samples: bool = True
) -> Tuple[int, Optional[str]]:
    """
    Analyze an audio file for fake FLAC detection.
    
    Args:
        file_path: Path to audio file
        channel: Channel index to analyze (default 0)
        sample_duration: Duration of each sample in seconds (default 30)
        use_multiple_samples: If True, analyze multiple segments for longer files
    
    Returns:
        Tuple of (score, error_message)
        Score: 0-100 (100 = authentic, lower = more likely fake)
        Error: None if successful, error message string if failed
    """
    try:
        # Read audio file
        audio, freq = sf.read(file_path)
        
        # Ensure audio is 2D (channels x samples) even for mono
        if audio.ndim == 1:
            audio = audio.reshape(-1, 1)
        
        samples = len(audio[:, 0])
        total_seconds = samples / freq
        
        if not use_multiple_samples or total_seconds < (sample_duration * 3):
            # File too short for multiple samples, or single sample requested
            # Analyze first sample_duration seconds
            score = analyze_audio_segment(audio, freq, channel, 0, sample_duration)
            return (score, None)
        
        # Determine sample locations: 1/3 and 2/3 through the file
        sample1_start = total_seconds / 3
        sample2_start = 2 * total_seconds / 3
        
        # Ensure we have at least sample_duration seconds available from each start point
        if sample1_start + sample_duration > total_seconds:
            sample1_start = max(0, total_seconds - sample_duration)
        if sample2_start + sample_duration > total_seconds:
            sample2_start = max(0, total_seconds - sample_duration)
        
        # Analyze both segments
        result1 = analyze_audio_segment(audio, freq, channel, sample1_start, sample_duration)
        result2 = analyze_audio_segment(audio, freq, channel, sample2_start, sample_duration)
        
        # Return minimum score (if any segment shows fake, the file is fake)
        score = min(result1, result2)
        return (score, None)
        
    except Exception as e:
        return (0, str(e))

