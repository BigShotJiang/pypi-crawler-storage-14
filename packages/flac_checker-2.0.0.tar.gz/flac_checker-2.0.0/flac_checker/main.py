"""Main CLI entry point for flac-checker."""

import os
import sys
from pathlib import Path
from typing import List, Tuple, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from multiprocessing import cpu_count

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

from flac_checker.analyzer import analyze_audio_file

app = typer.Typer(
    name="flac-checker",
    help="Detect fake FLAC files (transcoded from lossy formats) by analyzing frequency spectrum",
    add_completion=False,
)
console = Console()


def find_audio_files(directory: Path, extensions: List[str] = None) -> List[Path]:
    """
    Recursively find all audio files in the directory.
    
    Args:
        directory: Root directory to search
        extensions: List of file extensions to include (default: ['.flac', '.wav'])
    
    Returns:
        List of file paths
    """
    if extensions is None:
        extensions = ['.flac', '.wav']
    
    audio_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if any(file.lower().endswith(ext.lower()) for ext in extensions):
                audio_files.append(Path(root) / file)
    
    return sorted(audio_files)


def process_file(
    file_path: Path,
    channel: int,
    sample_duration: int,
    use_multiple_samples: bool
) -> Tuple[Path, int, Optional[str]]:
    """
    Process a single audio file.
    
    Returns:
        Tuple of (file_path, score, error_message)
    """
    score, error = analyze_audio_file(
        str(file_path),
        channel=channel,
        sample_duration=sample_duration,
        use_multiple_samples=use_multiple_samples
    )
    return (file_path, score, error)


@app.command()
def check(
    directory: Path = typer.Argument(..., help="Directory containing audio files to check"),
    only_fake: bool = typer.Option(
        False,
        "--only-fake",
        "-f",
        help="Only print files that are likely fake (score < 100)"
    ),
    sample_duration: int = typer.Option(
        30,
        "--sample-duration",
        "-d",
        help="Duration of each sample in seconds (default: 30)"
    ),
    single_sample: bool = typer.Option(
        False,
        "--single-sample",
        "-s",
        help="Only analyze first sample (don't use multiple samples for long files)"
    ),
    channel: int = typer.Option(
        0,
        "--channel",
        "-c",
        help="Audio channel to analyze (0=left, 1=right, default: 0)"
    ),
    jobs: int = typer.Option(
        None,
        "--jobs",
        "-j",
        help=f"Number of parallel workers (default: number of CPU cores, {cpu_count()})"
    ),
    extensions: str = typer.Option(
        ".flac,.wav",
        "--extensions",
        "-e",
        help="Comma-separated list of file extensions to process (default: .flac,.wav)"
    ),
) -> None:
    """
    Check audio files in a directory for fake FLAC detection.
    
    Recursively scans the directory for audio files and analyzes their frequency
    spectrum to detect signs of lossy compression (e.g., MP3 transcoding).
    
    Output format: file_path:score
    
    Score interpretation:
    - 100: Likely authentic lossless audio
    - 90-99: Probably authentic
    - 70-89: Might be transcoded
    - 50-69: Likely fake
    - 1-49: Definitely fake (heavily filtered)
    """
    if not directory.exists():
        console.print(f"[red]Error: Directory '{directory}' does not exist[/red]")
        raise typer.Exit(1)
    
    if not directory.is_dir():
        console.print(f"[red]Error: '{directory}' is not a directory[/red]")
        raise typer.Exit(1)
    
    # Parse extensions
    ext_list = [ext.strip() for ext in extensions.split(',') if ext.strip()]
    if not ext_list:
        console.print("[red]Error: No valid extensions specified[/red]")
        raise typer.Exit(1)
    
    # Find audio files
    console.print(f"[cyan]Scanning {directory} for audio files...[/cyan]")
    audio_files = find_audio_files(directory, ext_list)
    
    if not audio_files:
        console.print(f"[yellow]No audio files found in {directory}[/yellow]")
        raise typer.Exit(0)
    
    console.print(f"[green]Found {len(audio_files)} audio files[/green]")
    
    # Determine number of parallel workers
    num_jobs = jobs if jobs else cpu_count()
    console.print(f"[cyan]Processing with {num_jobs} parallel workers...[/cyan]")
    
    # Process files with progress bar
    results = []
    use_multiple_samples = not single_sample
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("({task.completed}/{task.total})"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Processing files...", total=len(audio_files))
        
        with ThreadPoolExecutor(max_workers=num_jobs) as executor:
            # Submit all tasks
            future_to_file = {
                executor.submit(
                    process_file,
                    file_path,
                    channel,
                    sample_duration,
                    use_multiple_samples
                ): file_path
                for file_path in audio_files
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_file):
                file_path, score, error = future.result()
                results.append((file_path, score, error))
                progress.update(task, advance=1)
    
    # Sort results by file path for consistent output
    results.sort(key=lambda x: str(x[0]))
    
    # Print results
    for file_path, score, error in results:
        if error:
            # Print error but continue
            console.print(f"[red]{file_path}:ERROR ({error})[/red]", file=sys.stderr)
            continue
        
        # Filter based on only_fake flag
        if only_fake and score == 100:
            continue
        
        # Print result to stdout (user can pipe to file)
        print(f"{file_path}:{score}")


if __name__ == "__main__":
    import sys
    app()

