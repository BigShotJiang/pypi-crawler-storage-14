# src/neural_crispr/__init__.py

__version__ = "0.0.1"

def hello():
    print("Neural-CRISPR: Official implementation coming soon.")