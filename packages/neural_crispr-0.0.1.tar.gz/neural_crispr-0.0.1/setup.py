from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="neural-crispr",
    version="0.0.1",    
    author="Neural-CRISPR Team",
    author_email="team@neural.crispr.com",
    url="https://github.com/neural.crispr/__",
    description="CRISPR",
    long_description=long_description,
    long_description_content_type="text/markdown",
        packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.12",
)