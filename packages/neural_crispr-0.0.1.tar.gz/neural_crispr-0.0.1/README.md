# Neural-CRISPR
🚧 **Under Active Development** 🚧

## Overview
Neural-CRISPR is a package.

## Installation
```bash
pip install neural-crispr
```

Maintained by the Neural-CRISPR Team.