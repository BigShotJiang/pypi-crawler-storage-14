"""Tests for the semantic search module."""
