=======
History
=======

0.0.1 (2023-05-30)
------------------

* First release on PyPI.
