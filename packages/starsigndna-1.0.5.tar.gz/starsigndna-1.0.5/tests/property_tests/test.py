import hypothesis

def test():
    assert True
