from pathlib import Path
import mimetypes
from openai import OpenAI
from ..utils.common import encode_image, check_file_size, parse_result, THRESHOLD_K2_SWITCH, THRESHOLD_LONG_CONTEXT

def handler(api_key, model, prompt, file_path=None, analyze_file=False, base_url=None, auto_switch_model=True, json_mode=False, **kwargs):
    target_url = base_url if base_url else "[https://api.moonshot.cn/v1](https://api.moonshot.cn/v1)"
    client = OpenAI(api_key=api_key, base_url=target_url)
    
    final_messages = []
    uploaded_file_id = None
    file_content_len = 0
    
    # 系统提示词注入 JSON 约束
    sys_prompt = "You are a helpful assistant."
    if json_mode:
        sys_prompt = "You are a Data Extraction Engine. Output ONLY valid JSON."

    try:
        if analyze_file and file_path:
            if not file_path: return {"error": "缺少 file_path"}
            file_obj = Path(file_path)
            mime_type, _ = mimetypes.guess_type(file_obj.name.lower())
            if not mime_type: mime_type = "application/octet-stream"

            if mime_type.startswith("image"):
                base64_img = encode_image(file_path)
                final_messages = [{"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{base64_img}"}}]}]
                file_content_len = 1000 
            else:
                check_file_size(file_path)
                uploaded_file = client.files.create(file=open(file_obj, "rb"), purpose="file-extract")
                uploaded_file_id = uploaded_file.id
                file_content = client.files.content(file_id=uploaded_file.id).text
                file_content_len = len(file_content)
                final_messages = [
                    {"role": "system", "content": sys_prompt},
                    {"role": "system", "content": f"---FILE START---\n{file_content}\n---FILE END---"},
                    {"role": "user", "content": prompt}
                ]
        else:
            final_messages = [
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": prompt}
            ]
            file_content_len = len(prompt)

        # 智能升级
        if auto_switch_model and file_content_len > 0:
            if file_content_len > THRESHOLD_K2_SWITCH and model != "kimi-k2-0905-preview": model = "kimi-k2-0905-preview"
            elif file_content_len > THRESHOLD_LONG_CONTEXT and "8k" in model: model = "moonshot-v1-128k"
            elif file_content_len > THRESHOLD_LONG_CONTEXT and "32k" in model: model = "moonshot-v1-128k"

        completion = client.chat.completions.create(model=model, messages=final_messages, temperature=0.1, **kwargs)
        
        # Token 统计
        if completion.usage:
            u = completion.usage
            print(f"💰 [Kimi Token] In: {u.prompt_tokens} | Out: {u.completion_tokens}")

        return parse_result(completion.choices[0].message.content, force_json=json_mode)
    except Exception as e: return {"error": f"Kimi Error: {str(e)}"}
    finally:
        if uploaded_file_id:
            try: client.files.delete(uploaded_file_id)
            except: pass