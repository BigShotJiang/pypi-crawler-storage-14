from pathlib import Path
import mimetypes
from openai import OpenAI
from ..utils.common import encode_image, parse_result

def handler(api_key, model, prompt, file_path=None, analyze_file=False, base_url=None, json_mode=False, **kwargs):
    target_url = base_url if base_url else "[https://api.openai.com/v1](https://api.openai.com/v1)"
    client = OpenAI(api_key=api_key, base_url=target_url)
    
    messages = []
    
    sys_content = "You are a helpful assistant."
    # 部分兼容接口支持 response_format={"type": "json_object"}，但也可能不支持
    # 保险起见，我们主要靠 Prompt 约束
    if json_mode:
        sys_content += " Output ONLY JSON."
    
    try:
        if analyze_file and file_path:
            if not file_path: return {"error": "缺少 file_path"}
            file_obj = Path(file_path)
            mime_type, _ = mimetypes.guess_type(file_obj.name.lower())
            if not mime_type: mime_type = "application/octet-stream"

            if mime_type.startswith("image"):
                base64_img = encode_image(file_path)
                messages = [
                    {"role": "system", "content": sys_content},
                    {"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{base64_img}"}}]}
                ]
            else:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f: content = f.read()
                    messages = [
                        {"role": "system", "content": sys_content},
                        {"role": "user", "content": f"File Content:\n{content}\n\nTask: {prompt}"}
                    ]
                except: return {"error": "通用 OpenAI 接口暂不支持二进制文件(PDF等)"}
        else:
            messages = [
                {"role": "system", "content": sys_content},
                {"role": "user", "content": prompt}
            ]

        completion = client.chat.completions.create(model=model, messages=messages, temperature=0.1, **kwargs)
        
        if completion.usage:
            u = completion.usage
            print(f"💰 [OpenAI Token] In: {u.prompt_tokens} | Out: {u.completion_tokens}")

        return parse_result(completion.choices[0].message.content, force_json=json_mode)
    except Exception as e: return {"error": f"OpenAI Error: {str(e)}"}