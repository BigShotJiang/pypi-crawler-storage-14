import os
import yaml

def load_config(config_path=None):
    """
    加载顺序: 默认 -> YAML -> 环境变量
    """
    config = {
        "default_vendor": "kimi",
        "concurrency": 5,
        "default_prompt": "Extract content",
        "delete_temp_on_success": False,
        "system": {"max_retries": 3},
        "vendors": {}
    }

    paths_to_try = []
    if config_path: paths_to_try.append(config_path)
    paths_to_try.append(os.path.expanduser("~/.aibatch/config.yaml"))
    paths_to_try.append("config.yaml")

    for p in paths_to_try:
        if os.path.exists(p):
            # print(f"⚙️ Loaded config: {p}") 
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    yaml_conf = yaml.safe_load(f)
                    if yaml_conf: config.update(yaml_conf)
                break 
            except Exception as e:
                print(f"⚠️ Config load failed: {e}")

    # 环境变量覆盖
    for v in ["kimi", "qwen", "gemini", "openai"]:
        env_key = f"AIBATCH_{v.upper()}_API_KEY"
        val = os.getenv(env_key)
        if val:
            if v not in config["vendors"]: config["vendors"][v] = {}
            config["vendors"][v]["api_key"] = val

    return config

def get_vendor_config(config, vendor_name):
    return config.get("vendors", {}).get(vendor_name, {})