import argparse
import asyncio
import json
import os
import glob
from .config import load_config, get_vendor_config
from .main import smart_process
from .core.manager import BaseBatchManager

def main():
    parser = argparse.ArgumentParser(description="AIB (AI Bridge) CLI Tool")
    
    parser.add_argument("-i", "--input", help="Input file/path (Optional for chat)")
    parser.add_argument("-p", "--prompt", help="Prompt text")
    parser.add_argument("-c", "--config", help="Config file path")
    parser.add_argument("-v", "--vendor", help="Vendor (kimi, qwen, gemini, openai)")
    parser.add_argument("-m", "--model", help="Model name")
    parser.add_argument("-j", "--json", action="store_true", help="Force JSON output mode")
    parser.add_argument("-r", "--resume", action="store_true", help="Resume from log")
    parser.add_argument("--mode", choices=["realtime", "offline"], default="realtime", help="Processing mode")
    parser.add_argument("--check-batch", action="store_true", help="Check status of active batch jobs")
    
    # 高级参数
    parser.add_argument("-k", "--api-key", help="API Key override")
    parser.add_argument("-u", "--base-url", help="Base URL override")

    args = parser.parse_args()

    # 1. 加载配置
    cfg = load_config(args.config)
    
    # 0. 检查 Batch 状态
    if args.check_batch:
        asyncio.run(BaseBatchManager.check_all_jobs(cfg))
        return
    
    # 2. 确定厂商
    vendor = args.vendor or cfg.get("default_vendor")
    vendor_cfg = get_vendor_config(cfg, vendor)
    
    # 3. 参数合并
    api_key = args.api_key or vendor_cfg.get("api_key")
    model = args.model or vendor_cfg.get("model")
    base_url = args.base_url or vendor_cfg.get("base_url")
    prompt = args.prompt or cfg.get("default_prompt")
    
    # 系统参数
    sys_cfg = cfg.get("system", {})
    concurrency = cfg.get("concurrency", 5)
    max_retries = sys_cfg.get("max_retries", 3)
    
    if not api_key:
        print(f"❌ Error: No API Key found for {vendor}")
        return
        
    if not prompt:
        print("❌ Error: Prompt is required")
        return

    # 4. 解析输入文件
    files = None
    if args.input:
        if "*" in args.input:
            files = glob.glob(args.input)
        elif os.path.isdir(args.input):
            files = [os.path.join(args.input, f) for f in os.listdir(args.input) if os.path.isfile(os.path.join(args.input, f))]
        else:
            if os.path.exists(args.input):
                files = [args.input]
            else:
                # 可能是单纯的聊天，input 只是个占位？不，CLI如果不传input通常意味着纯聊
                print(f"⚠️ File not found: {args.input}")
                return

    # 信息展示
    mode_info = "Chat Mode" if not files else f"Batch Mode ({len(files)} files)"
    print(f"🔥 AIB Start: {vendor} | {model} | {mode_info}")

    # 5. 运行
    try:
        res = asyncio.run(smart_process(
            input_target=files, # 列表 或 None
            vendor=vendor,
            api_key=api_key,
            model=model,
            base_url=base_url,
            prompt=prompt,
            json_mode=args.json,
            mode=args.mode,
            resume=args.resume,
            concurrency=concurrency,
            delete_temp_on_success=cfg.get("delete_temp_on_success", False),
            max_retries=max_retries
        ))
        
        # 输出结果
        if isinstance(res, (dict, list)):
            print(json.dumps(res, ensure_ascii=False, indent=2))
        else:
            print(res)

    except Exception as e:
        print(f"💥 Error: {str(e)}")

if __name__ == "__main__":
    main()