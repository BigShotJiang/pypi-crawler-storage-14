# PyPI 公開手順

この文書では、enecoq-data-fetcher を PyPI に公開する手順を説明します。

## 前提条件

1. PyPI アカウントを持っていること
   - アカウント作成: https://pypi.org/account/register/
   - テスト用: https://test.pypi.org/account/register/

2. API トークンを取得していること
   - PyPI: https://pypi.org/manage/account/token/
   - TestPyPI: https://test.pypi.org/manage/account/token/

## 手順

### 1. パッケージのビルド

```bash
# 依存関係のインストール
uv sync

# パッケージのビルド
uv build
```

これにより `dist/` ディレクトリに以下のファイルが生成されます：
- `enecoq_data_fetcher-1.0.0-py3-none-any.whl`
- `enecoq_data_fetcher-1.0.0.tar.gz`

### 2. TestPyPI へのアップロード（推奨）

本番環境にアップロードする前に、TestPyPI で動作確認することを推奨します。

```bash
# twine のインストール（初回のみ）
uv pip install twine

# TestPyPI へアップロード
uv run twine upload --repository testpypi dist/*
```

プロンプトが表示されたら：
- Username: `__token__`
- Password: TestPyPI の API トークン（`pypi-` で始まる文字列）

### 3. TestPyPI からのインストールテスト

```bash
# 新しい環境でテスト
uv pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ enecoq-data-fetcher

# 動作確認
enecoq-fetch --help
```

注: `--extra-index-url` は依存パッケージ（playwright, click）を本番 PyPI から取得するために必要です。

### 4. PyPI へのアップロード

TestPyPI で問題がなければ、本番環境にアップロードします。

```bash
# PyPI へアップロード
uv run twine upload dist/*
```

プロンプトが表示されたら：
- Username: `__token__`
- Password: PyPI の API トークン（`pypi-` で始まる文字列）

### 5. PyPI からのインストール確認

```bash
# 新しい環境でインストール
uv pip install enecoq-data-fetcher

# 動作確認
enecoq-fetch --help
```

## API トークンの設定（オプション）

毎回トークンを入力するのを避けるため、`~/.pypirc` ファイルに設定できます：

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_PYPI_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TESTPYPI_TOKEN_HERE
```

注意: このファイルには機密情報が含まれるため、適切なパーミッション（600）を設定してください：

```bash
chmod 600 ~/.pypirc
```

## バージョンアップ時の手順

1. `src/enecoq_data_fetcher/__init__.py` の `__version__` を更新
2. 変更をコミット
3. Git タグを作成

```bash
# バージョンを更新（例: 1.0.1）
# src/enecoq_data_fetcher/__init__.py の __version__ を編集

# コミット
git add src/enecoq_data_fetcher/__init__.py
git commit -m "chore: bump version to 1.0.1"

# タグを作成
git tag v1.0.1
git push origin main
git push origin v1.0.1
```

4. 古いビルドファイルを削除

```bash
rm -rf dist/
```

5. 再ビルドとアップロード

```bash
uv build
uv run twine upload dist/*
```

## トラブルシューティング

### エラー: "File already exists"

同じバージョンを再アップロードすることはできません。バージョン番号を上げてください。

### エラー: "Invalid or non-existent authentication information"

API トークンが正しいか確認してください。トークンは `pypi-` で始まる必要があります。

### エラー: "The user 'username' isn't allowed to upload to project 'enecoq-data-fetcher'"

初回アップロード時は、プロジェクト名が利用可能か確認してください。既に他のユーザーが使用している場合は、別の名前を選択する必要があります。

## 参考リンク

- PyPI: https://pypi.org/
- TestPyPI: https://test.pypi.org/
- Twine ドキュメント: https://twine.readthedocs.io/
- Python Packaging User Guide: https://packaging.python.org/
