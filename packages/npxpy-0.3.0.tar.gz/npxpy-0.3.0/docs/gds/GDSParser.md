# npxpy.gds.GDSParser


####::: npxpy.gds.GDSParser