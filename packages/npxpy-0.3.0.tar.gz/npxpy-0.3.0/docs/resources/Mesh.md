# npxpy.resources.Mesh


####::: npxpy.resources.Mesh