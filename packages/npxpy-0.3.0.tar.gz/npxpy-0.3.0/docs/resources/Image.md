# npxpy.resources.Image


####::: npxpy.resources.Image