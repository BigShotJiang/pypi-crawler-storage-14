# npxpy.nodes.structures.Structure


####::: npxpy.nodes.structures.Structure