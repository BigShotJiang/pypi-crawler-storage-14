# npxpy.nodes.structures.Lens


####::: npxpy.nodes.structures.Lens