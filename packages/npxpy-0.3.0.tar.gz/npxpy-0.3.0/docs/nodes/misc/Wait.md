# npxpy.nodes.misc.Wait


####::: npxpy.nodes.misc.Wait