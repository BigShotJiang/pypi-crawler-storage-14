# Copyright (c) 2020-2023 by Phase Advanced Sensor Systems Corp.


class XtalXException(Exception):
    pass
