"""
Analytical test functions for optimization.
"""

from .analytical import rosenbrock

__all__ = ["rosenbrock"]
