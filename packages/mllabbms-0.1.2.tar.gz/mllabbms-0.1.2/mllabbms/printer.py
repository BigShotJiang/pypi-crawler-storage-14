"""Helpers for rendering lab programs to stdout."""

from __future__ import annotations

from typing import Iterable, List

from .labs import LabProgram, get_lab_programs

_SECTION_LINE = "=" * 80


def format_lab(program: LabProgram, index: int) -> str:
    """Return a printable representation of a single lab."""

    parts: List[str] = [
        _SECTION_LINE,
        f"Lab {index}: {program.title}",
        _SECTION_LINE,
    ]
    if program.summary:
        parts.append(program.summary.strip())
        parts.append("")
    parts.append(program.content)
    parts.append("")
    return "\n".join(parts)


def print_all_labs(programs: Iterable[LabProgram] | None = None) -> None:
    """Print every lab to stdout."""

    labs = list(programs) if programs is not None else get_lab_programs()
    for idx, lab in enumerate(labs, start=1):
        print(format_lab(lab, idx))

