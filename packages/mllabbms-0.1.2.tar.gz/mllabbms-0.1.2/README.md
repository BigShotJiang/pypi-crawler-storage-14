# mllabbms

Publishable Python package that bundles all “ML Lab” programs and offers a
single command to print them in order.

## Installation

```bash
python3 -m pip install mllabbms
```

To test changes locally before publishing, run the same command inside the repo
root. Pip will build the wheel/sdist and install the package into the active
environment.

## Usage

The package exposes a console script named `mllabbms`.

```bash
# list all labs with their titles and short summaries
mllabbms --list

# print a single lab (1-based index from --list)
mllabbms --lab 3

# print every program in order
mllabbms
```

You can also call the helpers directly from Python:

```python
from mllabbms import print_all_labs, get_lab_programs

print_all_labs()
first = get_lab_programs()[0]
print(first.title)
```

## Publishing workflow

1. Install the packaging tools:
   ```bash
   python3 -m pip install --upgrade build twine
   ```
2. Build the artifacts from the repository root:
   ```bash
   python3 -m build
   ```
   The wheel and sdist will be placed inside `dist/`.
3. Set up PyPI credentials:
   - Create a PyPI account at https://pypi.org/account/register/
   - Generate an API token at https://pypi.org/manage/account/token/
   - Use environment variables to authenticate:
     ```bash
     export TWINE_USERNAME=__token__
     export TWINE_PASSWORD=pypi-<your-token-here>
     ```
4. Upload to TestPyPI first (optional, for testing):
   ```bash
   python3 -m twine upload dist/* -r testpypi
   ```
5. Upload to PyPI:
   ```bash
   python3 -m twine upload dist/*
   ```
4. Users can now `pip install mllabbms` and run the CLI.

Remember to bump `version` in `setup.py` before each release.

