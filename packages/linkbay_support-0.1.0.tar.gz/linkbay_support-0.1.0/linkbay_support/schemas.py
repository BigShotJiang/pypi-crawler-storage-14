"""
Pydantic schemas for support system.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


# Ticket schemas

class AttachmentInfo(BaseModel):
    """Attachment reference."""
    
    filename: str
    url: str
    content_type: Optional[str] = None
    size: Optional[int] = None


class MessageCreate(BaseModel):
    """Create message in ticket."""
    
    content: str
    message_type: str = "customer_message"
    author_id: str
    attachments: List[AttachmentInfo] = Field(default_factory=list)
    is_internal: bool = False


class MessageResponse(BaseModel):
    """Message response."""
    
    id: str
    ticket_id: str
    content: str
    message_type: str
    author_id: str
    author_name: Optional[str] = None
    attachments: List[AttachmentInfo] = Field(default_factory=list)
    is_internal: bool
    created_at: datetime


class TicketCreate(BaseModel):
    """Create ticket request."""
    
    subject: str = Field(min_length=1, max_length=500)
    description: str
    priority: str = "medium"
    category: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    customer_id: str
    customer_email: str
    initial_message: Optional[MessageCreate] = None
    metadata: Optional[Dict[str, Any]] = None


class TicketUpdate(BaseModel):
    """Update ticket fields."""
    
    status: Optional[str] = None
    priority: Optional[str] = None
    assigned_agent_id: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class TicketResponse(BaseModel):
    """Ticket response with all data."""
    
    id: str
    tenant_id: str
    ticket_number: str
    subject: str
    description: str
    status: str
    priority: str
    category: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    customer_id: str
    customer_email: str
    assigned_agent_id: Optional[str] = None
    assigned_agent_name: Optional[str] = None
    sla_due_at: Optional[datetime] = None
    sla_status: str = "no_sla"
    created_at: datetime
    updated_at: datetime
    closed_at: Optional[datetime] = None
    first_response_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None


class TicketListResponse(BaseModel):
    """List tickets response."""
    
    tickets: List[TicketResponse]
    total: int
    skip: int
    limit: int


# Knowledge Base schemas

class CategoryCreate(BaseModel):
    """Create KB category."""
    
    name: str
    slug: str
    description: Optional[str] = None
    parent_id: Optional[str] = None
    icon: Optional[str] = None
    sort_order: int = 0


class CategoryResponse(BaseModel):
    """KB category response."""
    
    id: str
    tenant_id: str
    name: str
    slug: str
    description: Optional[str] = None
    parent_id: Optional[str] = None
    icon: Optional[str] = None
    sort_order: int
    article_count: int = 0


class ArticleCreate(BaseModel):
    """Create KB article."""
    
    title: str = Field(min_length=1, max_length=500)
    slug: str
    content: str
    excerpt: Optional[str] = None
    category_id: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    visibility: str = "public"
    language: str = "en"
    is_featured: bool = False
    metadata: Optional[Dict[str, Any]] = None


class ArticleUpdate(BaseModel):
    """Update article fields."""
    
    title: Optional[str] = None
    slug: Optional[str] = None
    content: Optional[str] = None
    excerpt: Optional[str] = None
    category_id: Optional[str] = None
    tags: Optional[List[str]] = None
    visibility: Optional[str] = None
    is_featured: Optional[bool] = None
    metadata: Optional[Dict[str, Any]] = None


class ArticleResponse(BaseModel):
    """Article response."""
    
    id: str
    tenant_id: str
    title: str
    slug: str
    content: str
    excerpt: Optional[str] = None
    category_id: Optional[str] = None
    category_name: Optional[str] = None
    tags: List[str]
    visibility: str
    language: str
    is_featured: bool
    view_count: int = 0
    helpful_count: int = 0
    metadata: Optional[Dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime
    published_at: Optional[datetime] = None


class ArticleListResponse(BaseModel):
    """List articles response."""
    
    articles: List[ArticleResponse]
    total: int
    skip: int
    limit: int


class ArticleSearchRequest(BaseModel):
    """Search articles request."""
    
    query: str
    category_id: Optional[str] = None
    tags: Optional[List[str]] = None
    visibility: Optional[str] = None
    language: Optional[str] = None
    limit: int = 10


class ArticleSearchResponse(BaseModel):
    """Search results."""
    
    articles: List[ArticleResponse]
    total: int
    query: str


class TicketSuggestion(BaseModel):
    """Suggested KB articles for ticket."""
    
    ticket_id: str
    suggested_articles: List[ArticleResponse]
    confidence_scores: List[float]


# Automation schemas

class SLAConfig(BaseModel):
    """SLA configuration."""
    
    priority: str
    response_time_minutes: int
    resolution_time_minutes: int
    business_hours_only: bool = False


class AutomationRule(BaseModel):
    """Automation rule definition."""
    
    id: str
    tenant_id: str
    name: str
    trigger: str
    conditions: Dict[str, Any]
    actions: List[Dict[str, Any]]
    is_active: bool = True


# Reporting schemas

class TicketStats(BaseModel):
    """Ticket statistics."""
    
    tenant_id: str
    period_start: datetime
    period_end: datetime
    total_tickets: int
    by_status: Dict[str, int]
    by_priority: Dict[str, int]
    by_category: Dict[str, int]
    avg_response_time_minutes: Optional[float] = None
    avg_resolution_time_minutes: Optional[float] = None
    generated_at: datetime


class SLAReport(BaseModel):
    """SLA compliance report."""
    
    tenant_id: str
    period_start: datetime
    period_end: datetime
    total_tickets: int
    within_sla: int
    breached: int
    compliance_rate: float
    by_priority: Dict[str, Dict[str, int]]
    generated_at: datetime


class AgentPerformance(BaseModel):
    """Agent performance metrics."""
    
    agent_id: str
    agent_name: str
    tickets_assigned: int
    tickets_resolved: int
    avg_response_time_minutes: Optional[float] = None
    avg_resolution_time_minutes: Optional[float] = None
    customer_satisfaction: Optional[float] = None
