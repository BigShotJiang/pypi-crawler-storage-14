"""
Custom exceptions for support system.
"""


class SupportError(Exception):
    """Base exception for support system."""
    
    pass


class TicketNotFoundError(SupportError):
    """Ticket not found in storage."""
    
    def __init__(self, tenant_id: str, ticket_id: str):
        self.tenant_id = tenant_id
        self.ticket_id = ticket_id
        super().__init__(
            f"Ticket {ticket_id} not found for tenant {tenant_id}"
        )


class ArticleNotFoundError(SupportError):
    """Knowledge base article not found."""
    
    def __init__(self, tenant_id: str, article_id: str):
        self.tenant_id = tenant_id
        self.article_id = article_id
        super().__init__(
            f"Article {article_id} not found for tenant {tenant_id}"
        )


class InvalidAssignmentError(SupportError):
    """Invalid agent assignment."""
    
    def __init__(self, message: str):
        super().__init__(f"Invalid assignment: {message}")


class SLAViolationError(SupportError):
    """SLA has been violated."""
    
    def __init__(self, ticket_id: str, sla_type: str):
        self.ticket_id = ticket_id
        self.sla_type = sla_type
        super().__init__(
            f"SLA violation for ticket {ticket_id}: {sla_type}"
        )


class PermissionDeniedError(SupportError):
    """User does not have permission."""
    
    def __init__(self, user_id: str, action: str):
        self.user_id = user_id
        self.action = action
        super().__init__(
            f"User {user_id} does not have permission for: {action}"
        )


class MessageDeliveryError(SupportError):
    """Failed to deliver message/notification."""
    
    def __init__(self, channel: str, message: str):
        self.channel = channel
        super().__init__(f"Message delivery failed via {channel}: {message}")


class InvalidTicketStateError(SupportError):
    """Invalid ticket state transition."""
    
    def __init__(self, current_status: str, new_status: str):
        super().__init__(
            f"Invalid state transition from {current_status} to {new_status}"
        )
