"""
Constants and enums for support system.
"""

from enum import Enum


class TicketStatus(str, Enum):
    """Ticket lifecycle status."""
    
    OPEN = "open"
    PROCESSING = "processing"
    WAITING = "waiting"  # Waiting for customer response
    RESOLVED = "resolved"
    CLOSED = "closed"
    ESCALATED = "escalated"


class TicketPriority(str, Enum):
    """Ticket priority levels."""
    
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"
    CRITICAL = "critical"


class MessageType(str, Enum):
    """Message types in ticket thread."""
    
    CUSTOMER_MESSAGE = "customer_message"
    AGENT_REPLY = "agent_reply"
    INTERNAL_NOTE = "internal_note"  # Not visible to customer
    SYSTEM_MESSAGE = "system_message"  # Auto-generated
    STATUS_CHANGE = "status_change"


class SLAStatus(str, Enum):
    """SLA compliance status."""
    
    WITHIN_SLA = "within_sla"
    AT_RISK = "at_risk"  # 80% of time elapsed
    BREACHED = "breached"
    NO_SLA = "no_sla"


class ArticleVisibility(str, Enum):
    """Knowledge base article visibility."""
    
    PUBLIC = "public"  # Visible to all customers
    AUTHENTICATED = "authenticated"  # Only logged-in customers
    INTERNAL = "internal"  # Only agents/staff
    DRAFT = "draft"  # Not published


class AutomationTrigger(str, Enum):
    """Automation rule triggers."""
    
    TICKET_CREATED = "ticket_created"
    TICKET_UPDATED = "ticket_updated"
    MESSAGE_RECEIVED = "message_received"
    SLA_AT_RISK = "sla_at_risk"
    SLA_BREACHED = "sla_breached"
    STATUS_CHANGED = "status_changed"
    AGENT_ASSIGNED = "agent_assigned"
    TICKET_IDLE = "ticket_idle"  # No activity for X hours


class NotificationChannel(str, Enum):
    """Notification delivery channels."""
    
    EMAIL = "email"
    WEBSOCKET = "websocket"
    PUSH = "push"
    SMS = "sms"
    WEBHOOK = "webhook"


# SLA response time targets (in minutes)
SLA_RESPONSE_TIMES = {
    TicketPriority.LOW: 1440,  # 24 hours
    TicketPriority.MEDIUM: 480,  # 8 hours
    TicketPriority.HIGH: 240,  # 4 hours
    TicketPriority.URGENT: 60,  # 1 hour
    TicketPriority.CRITICAL: 15,  # 15 minutes
}

# SLA resolution time targets (in minutes)
SLA_RESOLUTION_TIMES = {
    TicketPriority.LOW: 10080,  # 7 days
    TicketPriority.MEDIUM: 2880,  # 2 days
    TicketPriority.HIGH: 1440,  # 1 day
    TicketPriority.URGENT: 480,  # 8 hours
    TicketPriority.CRITICAL: 240,  # 4 hours
}

# Auto-close ticket after X days of waiting
AUTO_CLOSE_DAYS = 7

# SLA at-risk threshold (percentage)
SLA_AT_RISK_THRESHOLD = 0.8  # 80% of time elapsed
