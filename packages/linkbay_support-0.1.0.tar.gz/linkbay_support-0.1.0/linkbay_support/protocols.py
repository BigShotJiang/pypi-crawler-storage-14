"""
Protocol definitions for support system.

All protocols are database-agnostic and provider-agnostic.
"""

from typing import Protocol, Dict, Any, List, Optional
from datetime import datetime


class TicketStorage(Protocol):
    """
    Protocol for ticket data persistence.
    
    User implements with their database.
    """
    
    async def create_ticket(
        self,
        tenant_id: str,
        data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create new ticket."""
        ...
    
    async def get_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get ticket by ID."""
        ...
    
    async def update_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update ticket fields."""
        ...
    
    async def list_tickets(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """List tickets with filters."""
        ...
    
    async def add_message(
        self,
        tenant_id: str,
        ticket_id: str,
        message_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Add message to ticket thread."""
        ...
    
    async def get_messages(
        self,
        tenant_id: str,
        ticket_id: str,
    ) -> List[Dict[str, Any]]:
        """Get all messages for ticket."""
        ...
    
    async def get_tickets_by_sla_status(
        self,
        tenant_id: str,
        sla_status: str,
    ) -> List[Dict[str, Any]]:
        """Get tickets by SLA status."""
        ...


class KBStorage(Protocol):
    """
    Protocol for knowledge base storage.
    """
    
    async def create_article(
        self,
        tenant_id: str,
        data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create new article."""
        ...
    
    async def get_article(
        self,
        tenant_id: str,
        article_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get article by ID."""
        ...
    
    async def get_article_by_slug(
        self,
        tenant_id: str,
        slug: str,
    ) -> Optional[Dict[str, Any]]:
        """Get article by slug."""
        ...
    
    async def update_article(
        self,
        tenant_id: str,
        article_id: str,
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update article."""
        ...
    
    async def list_articles(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """List articles with filters."""
        ...
    
    async def search_articles(
        self,
        tenant_id: str,
        query: str,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Full-text search articles."""
        ...


class MessageProvider(Protocol):
    """
    Protocol for message delivery.
    
    User implements with email, WebSocket, push, etc.
    """
    
    async def send_message(
        self,
        tenant_id: str,
        channel: str,
        recipient: str,
        subject: str,
        body: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Send message via channel."""
        ...


class NotificationProvider(Protocol):
    """
    Protocol for sending notifications.
    """
    
    async def notify(
        self,
        tenant_id: str,
        user_id: str,
        event_type: str,
        data: Dict[str, Any],
        channels: List[str],
    ) -> Dict[str, Any]:
        """Send notification to user."""
        ...


class UserDirectory(Protocol):
    """
    Protocol for fetching user/agent information.
    """
    
    async def get_user(
        self,
        tenant_id: str,
        user_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get user details."""
        ...
    
    async def get_assignable_agents(
        self,
        tenant_id: str,
    ) -> List[Dict[str, Any]]:
        """Get list of agents who can be assigned tickets."""
        ...


class SLAPolicy(Protocol):
    """
    Protocol for SLA policy management.
    """
    
    async def get_sla_config(
        self,
        tenant_id: str,
        priority: str,
    ) -> Dict[str, Any]:
        """
        Get SLA configuration for priority.
        
        Returns dict with: response_time_minutes, resolution_time_minutes
        """
        ...
    
    async def calculate_due_date(
        self,
        tenant_id: str,
        priority: str,
        created_at: datetime,
    ) -> datetime:
        """Calculate SLA due date."""
        ...
