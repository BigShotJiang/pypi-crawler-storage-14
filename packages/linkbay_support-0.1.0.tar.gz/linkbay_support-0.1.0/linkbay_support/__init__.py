"""
LinkBay Support - Protocol-based helpdesk and knowledge base library.

Multi-tenant support system for SaaS applications.
Database-agnostic, modular, extensible.
"""

__version__ = "0.1.0"

# Constants
from .constants import (
    TicketStatus,
    TicketPriority,
    MessageType,
    SLAStatus,
    ArticleVisibility,
)

# Exceptions
from .exceptions import (
    SupportError,
    TicketNotFoundError,
    ArticleNotFoundError,
    InvalidAssignmentError,
    SLAViolationError,
    PermissionDeniedError,
)

# Protocols
from .protocols import (
    TicketStorage,
    KBStorage,
    MessageProvider,
    NotificationProvider,
    UserDirectory,
    SLAPolicy,
)

# Schemas
from .schemas import (
    # Tickets
    TicketCreate,
    TicketUpdate,
    TicketResponse,
    TicketListResponse,
    MessageCreate,
    MessageResponse,
    AttachmentInfo,
    # Knowledge Base
    ArticleCreate,
    ArticleUpdate,
    ArticleResponse,
    ArticleListResponse,
    CategoryCreate,
    CategoryResponse,
    ArticleSearchRequest,
    ArticleSearchResponse,
    # Automation
    SLAConfig,
    AutomationRule,
    TicketSuggestion,
    # Reporting
    TicketStats,
    SLAReport,
    AgentPerformance,
)

# Services
from .services import (
    TicketManager,
    KBManager,
    AutomationEngine,
    ReportingService,
)

# Routers
from .router import create_support_router, create_kb_router

__all__ = [
    # Version
    "__version__",
    # Constants
    "TicketStatus",
    "TicketPriority",
    "MessageType",
    "SLAStatus",
    "ArticleVisibility",
    # Exceptions
    "SupportError",
    "TicketNotFoundError",
    "ArticleNotFoundError",
    "InvalidAssignmentError",
    "SLAViolationError",
    "PermissionDeniedError",
    # Protocols
    "TicketStorage",
    "KBStorage",
    "MessageProvider",
    "NotificationProvider",
    "UserDirectory",
    "SLAPolicy",
    # Schemas
    "TicketCreate",
    "TicketUpdate",
    "TicketResponse",
    "TicketListResponse",
    "MessageCreate",
    "MessageResponse",
    "AttachmentInfo",
    "ArticleCreate",
    "ArticleUpdate",
    "ArticleResponse",
    "ArticleListResponse",
    "CategoryCreate",
    "CategoryResponse",
    "ArticleSearchRequest",
    "ArticleSearchResponse",
    "SLAConfig",
    "AutomationRule",
    "TicketSuggestion",
    "TicketStats",
    "SLAReport",
    "AgentPerformance",
    # Services
    "TicketManager",
    "KBManager",
    "AutomationEngine",
    "ReportingService",
    # Routers
    "create_support_router",
    "create_kb_router",
]
