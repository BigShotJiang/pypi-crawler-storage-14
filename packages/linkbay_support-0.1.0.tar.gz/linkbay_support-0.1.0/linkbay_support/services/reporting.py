"""
Reporting service for support metrics.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from ..protocols import TicketStorage
from ..schemas import TicketStats, SLAReport, AgentPerformance
from ..constants import TicketStatus, SLAStatus


class ReportingService:
    """
    Reporting service for support metrics.
    
    Generates ticket stats, SLA compliance, agent performance.
    """
    
    def __init__(self, storage: TicketStorage):
        """
        Initialize reporting service.
        
        Args:
            storage: Ticket storage implementation
        """
        self.storage = storage
    
    async def generate_ticket_stats(
        self,
        tenant_id: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> TicketStats:
        """Generate ticket statistics."""
        filters = {}
        
        if start_date:
            filters["created_at_gte"] = start_date
        if end_date:
            filters["created_at_lte"] = end_date
        
        tickets = await self.storage.list_tickets(tenant_id, 0, 10000, filters)
        
        total_tickets = len(tickets)
        
        # By status
        by_status = {}
        for status in TicketStatus:
            by_status[status.value] = len([
                t for t in tickets if t["status"] == status.value
            ])
        
        # By priority
        by_priority = {}
        priorities = ["low", "medium", "high", "urgent", "critical"]
        for priority in priorities:
            by_priority[priority] = len([
                t for t in tickets if t.get("priority") == priority
            ])
        
        # By category
        by_category = {}
        for ticket in tickets:
            category = ticket.get("category", "uncategorized")
            by_category[category] = by_category.get(category, 0) + 1
        
        # Average times
        response_times = [
            (t["first_response_at"] - t["created_at"]).total_seconds() / 60
            for t in tickets
            if t.get("first_response_at")
        ]
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        resolution_times = [
            (t["resolved_at"] - t["created_at"]).total_seconds() / 60
            for t in tickets
            if t.get("resolved_at")
        ]
        avg_resolution_time = sum(resolution_times) / len(resolution_times) if resolution_times else 0
        
        return TicketStats(
            total_tickets=total_tickets,
            by_status=by_status,
            by_priority=by_priority,
            by_category=by_category,
            avg_response_time_minutes=avg_response_time,
            avg_resolution_time_minutes=avg_resolution_time,
            period_start=start_date,
            period_end=end_date,
        )
    
    async def generate_sla_report(
        self,
        tenant_id: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> SLAReport:
        """Generate SLA compliance report."""
        filters = {}
        
        if start_date:
            filters["created_at_gte"] = start_date
        if end_date:
            filters["created_at_lte"] = end_date
        
        tickets = await self.storage.list_tickets(tenant_id, 0, 10000, filters)
        
        tickets_with_sla = [t for t in tickets if t.get("sla_due_at")]
        
        within_sla = len([
            t for t in tickets_with_sla
            if t.get("sla_status") == SLAStatus.WITHIN_SLA.value
        ])
        
        breached = len([
            t for t in tickets_with_sla
            if t.get("sla_status") == SLAStatus.BREACHED.value
        ])
        
        at_risk = len([
            t for t in tickets_with_sla
            if t.get("sla_status") == SLAStatus.AT_RISK.value
        ])
        
        compliance_rate = (within_sla / len(tickets_with_sla)) * 100 if tickets_with_sla else 0
        
        # By priority
        by_priority = {}
        priorities = ["low", "medium", "high", "urgent", "critical"]
        for priority in priorities:
            priority_tickets = [t for t in tickets_with_sla if t.get("priority") == priority]
            priority_within = len([
                t for t in priority_tickets
                if t.get("sla_status") == SLAStatus.WITHIN_SLA.value
            ])
            priority_rate = (priority_within / len(priority_tickets)) * 100 if priority_tickets else 0
            by_priority[priority] = priority_rate
        
        return SLAReport(
            total_tickets=len(tickets_with_sla),
            within_sla=within_sla,
            breached=breached,
            at_risk=at_risk,
            compliance_rate=compliance_rate,
            by_priority=by_priority,
            period_start=start_date,
            period_end=end_date,
        )
    
    async def generate_agent_performance(
        self,
        tenant_id: str,
        agent_id: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> AgentPerformance:
        """Generate agent performance metrics."""
        filters = {"assigned_agent_id": agent_id}
        
        if start_date:
            filters["created_at_gte"] = start_date
        if end_date:
            filters["created_at_lte"] = end_date
        
        tickets = await self.storage.list_tickets(tenant_id, 0, 10000, filters)
        
        tickets_assigned = len(tickets)
        tickets_resolved = len([
            t for t in tickets
            if t["status"] in [TicketStatus.RESOLVED.value, TicketStatus.CLOSED.value]
        ])
        
        # Average times
        response_times = [
            (t["first_response_at"] - t["created_at"]).total_seconds() / 60
            for t in tickets
            if t.get("first_response_at")
        ]
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        resolution_times = [
            (t["resolved_at"] - t["created_at"]).total_seconds() / 60
            for t in tickets
            if t.get("resolved_at")
        ]
        avg_resolution_time = sum(resolution_times) / len(resolution_times) if resolution_times else 0
        
        return AgentPerformance(
            agent_id=agent_id,
            tickets_assigned=tickets_assigned,
            tickets_resolved=tickets_resolved,
            avg_response_time_minutes=avg_response_time,
            avg_resolution_time_minutes=avg_resolution_time,
            period_start=start_date,
            period_end=end_date,
        )
