"""
Ticket management service.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from ..protocols import (
    TicketStorage,
    MessageProvider,
    NotificationProvider,
    UserDirectory,
    SLAPolicy,
)
from ..schemas import (
    TicketCreate,
    TicketUpdate,
    TicketResponse,
    MessageCreate,
    MessageResponse,
)
from ..constants import TicketStatus, SLAStatus, MessageType
from ..exceptions import TicketNotFoundError, InvalidAssignmentError


class TicketManager:
    """
    Core service for ticket management.
    
    Handles ticket CRUD, assignment, messaging, SLA tracking.
    """
    
    def __init__(
        self,
        storage: TicketStorage,
        message_provider: Optional[MessageProvider] = None,
        notification_provider: Optional[NotificationProvider] = None,
        user_directory: Optional[UserDirectory] = None,
        sla_policy: Optional[SLAPolicy] = None,
    ):
        """
        Initialize ticket manager.
        
        Args:
            storage: Ticket storage implementation
            message_provider: Message delivery provider
            notification_provider: Notification provider
            user_directory: User/agent directory
            sla_policy: SLA policy provider
        """
        self.storage = storage
        self.message_provider = message_provider
        self.notification_provider = notification_provider
        self.user_directory = user_directory
        self.sla_policy = sla_policy
    
    async def create_ticket(
        self,
        tenant_id: str,
        ticket_data: TicketCreate,
    ) -> TicketResponse:
        """
        Create new ticket.
        
        Example:
            ```python
            ticket = await manager.create_ticket(
                tenant_id="agency123",
                ticket_data=TicketCreate(
                    subject="Cannot login to dashboard",
                    description="I get error 500 when trying to login.",
                    priority="high",
                    category="technical",
                    customer_id="cust_123",
                    customer_email="customer@example.com",
                    initial_message=MessageCreate(
                        content="Here are the error details...",
                        author_id="cust_123",
                    ),
                ),
            )
            ```
        """
        # Generate ticket number
        ticket_number = await self._generate_ticket_number(tenant_id)
        
        # Calculate SLA due date
        sla_due_at = None
        if self.sla_policy:
            sla_due_at = await self.sla_policy.calculate_due_date(
                tenant_id,
                ticket_data.priority,
                datetime.utcnow(),
            )
        
        # Prepare ticket data
        ticket_dict = {
            "ticket_number": ticket_number,
            "subject": ticket_data.subject,
            "description": ticket_data.description,
            "status": TicketStatus.OPEN.value,
            "priority": ticket_data.priority,
            "category": ticket_data.category,
            "tags": ticket_data.tags,
            "customer_id": ticket_data.customer_id,
            "customer_email": ticket_data.customer_email,
            "assigned_agent_id": None,
            "sla_due_at": sla_due_at,
            "sla_status": SLAStatus.WITHIN_SLA.value if sla_due_at else SLAStatus.NO_SLA.value,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "metadata": ticket_data.metadata or {},
        }
        
        # Create ticket
        created = await self.storage.create_ticket(tenant_id, ticket_dict)
        
        # Add initial message if provided
        if ticket_data.initial_message:
            await self.add_message(
                tenant_id,
                created["id"],
                ticket_data.initial_message,
            )
        
        # Notify agents of new ticket
        if self.notification_provider:
            await self._notify_new_ticket(tenant_id, created)
        
        return TicketResponse(**created)
    
    async def get_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
    ) -> TicketResponse:
        """Get ticket by ID."""
        ticket = await self.storage.get_ticket(tenant_id, ticket_id)
        
        if not ticket:
            raise TicketNotFoundError(tenant_id, ticket_id)
        
        return TicketResponse(**ticket)
    
    async def update_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
        updates: TicketUpdate,
    ) -> TicketResponse:
        """Update ticket fields."""
        ticket = await self.get_ticket(tenant_id, ticket_id)
        
        update_dict = updates.model_dump(exclude_unset=True)
        update_dict["updated_at"] = datetime.utcnow()
        
        # Track status change
        if "status" in update_dict and update_dict["status"] != ticket.status:
            if update_dict["status"] == TicketStatus.RESOLVED.value:
                update_dict["resolved_at"] = datetime.utcnow()
            elif update_dict["status"] == TicketStatus.CLOSED.value:
                update_dict["closed_at"] = datetime.utcnow()
        
        updated = await self.storage.update_ticket(tenant_id, ticket_id, update_dict)
        return TicketResponse(**updated)
    
    async def list_tickets(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[TicketResponse]:
        """List tickets with filters."""
        tickets = await self.storage.list_tickets(
            tenant_id, skip, limit, filters
        )
        return [TicketResponse(**t) for t in tickets]
    
    async def assign_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
        agent_id: str,
    ) -> TicketResponse:
        """
        Assign ticket to agent.
        
        Example:
            ```python
            ticket = await manager.assign_ticket(
                tenant_id="agency123",
                ticket_id="tkt_001",
                agent_id="agent_456",
            )
            ```
        """
        # Verify agent exists
        if self.user_directory:
            agent = await self.user_directory.get_user(tenant_id, agent_id)
            if not agent:
                raise InvalidAssignmentError(f"Agent {agent_id} not found")
        
        updates = {
            "assigned_agent_id": agent_id,
            "status": TicketStatus.PROCESSING.value,
            "updated_at": datetime.utcnow(),
        }
        
        updated = await self.storage.update_ticket(tenant_id, ticket_id, updates)
        
        # Notify agent
        if self.notification_provider:
            await self.notification_provider.notify(
                tenant_id,
                agent_id,
                "ticket_assigned",
                {"ticket_id": ticket_id},
                ["email", "websocket"],
            )
        
        return TicketResponse(**updated)
    
    async def claim_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
        agent_id: str,
    ) -> TicketResponse:
        """Agent claims unassigned ticket."""
        ticket = await self.get_ticket(tenant_id, ticket_id)
        
        if ticket.assigned_agent_id:
            raise InvalidAssignmentError("Ticket already assigned")
        
        return await self.assign_ticket(tenant_id, ticket_id, agent_id)
    
    async def escalate_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
        escalate_to_agent_id: str,
        reason: Optional[str] = None,
    ) -> TicketResponse:
        """
        Escalate ticket to another agent.
        
        Example:
            ```python
            ticket = await manager.escalate_ticket(
                tenant_id="agency123",
                ticket_id="tkt_001",
                escalate_to_agent_id="senior_agent_789",
                reason="Requires senior technical expertise",
            )
            ```
        """
        updates = {
            "assigned_agent_id": escalate_to_agent_id,
            "status": TicketStatus.ESCALATED.value,
            "priority": "high",  # Bump priority on escalation
            "updated_at": datetime.utcnow(),
            "metadata": {
                "escalation_reason": reason,
                "escalated_at": datetime.utcnow().isoformat(),
            },
        }
        
        updated = await self.storage.update_ticket(tenant_id, ticket_id, updates)
        
        # Add system message
        await self.add_message(
            tenant_id,
            ticket_id,
            MessageCreate(
                content=f"Ticket escalated. Reason: {reason}",
                message_type=MessageType.SYSTEM_MESSAGE.value,
                author_id="system",
            ),
        )
        
        return TicketResponse(**updated)
    
    async def add_message(
        self,
        tenant_id: str,
        ticket_id: str,
        message_data: MessageCreate,
    ) -> MessageResponse:
        """
        Add message to ticket thread.
        
        Example:
            ```python
            message = await manager.add_message(
                tenant_id="agency123",
                ticket_id="tkt_001",
                message_data=MessageCreate(
                    content="I have checked the logs and found the issue.",
                    message_type="agent_reply",
                    author_id="agent_456",
                ),
            )
            ```
        """
        message_dict = {
            **message_data.model_dump(),
            "ticket_id": ticket_id,
            "created_at": datetime.utcnow(),
        }
        
        created = await self.storage.add_message(tenant_id, ticket_id, message_dict)
        
        # Track first response time
        ticket = await self.get_ticket(tenant_id, ticket_id)
        if not ticket.first_response_at and message_data.message_type == MessageType.AGENT_REPLY.value:
            await self.storage.update_ticket(
                tenant_id,
                ticket_id,
                {"first_response_at": datetime.utcnow()},
            )
        
        # Send notification
        if self.message_provider and not message_data.is_internal:
            recipient = ticket.customer_email if message_data.message_type == MessageType.AGENT_REPLY.value else None
            if recipient:
                await self.message_provider.send_message(
                    tenant_id,
                    "email",
                    recipient,
                    f"Update on ticket {ticket.ticket_number}",
                    message_data.content,
                )
        
        return MessageResponse(**created)
    
    async def close_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
        resolution_notes: Optional[str] = None,
    ) -> TicketResponse:
        """Close resolved ticket."""
        updates = {
            "status": TicketStatus.CLOSED.value,
            "closed_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
        
        if resolution_notes:
            await self.add_message(
                tenant_id,
                ticket_id,
                MessageCreate(
                    content=resolution_notes,
                    message_type=MessageType.SYSTEM_MESSAGE.value,
                    author_id="system",
                ),
            )
        
        updated = await self.storage.update_ticket(tenant_id, ticket_id, updates)
        return TicketResponse(**updated)
    
    async def _generate_ticket_number(self, tenant_id: str) -> str:
        """Generate unique ticket number."""
        import uuid
        return f"TKT-{uuid.uuid4().hex[:8].upper()}"
    
    async def _notify_new_ticket(
        self,
        tenant_id: str,
        ticket: Dict[str, Any],
    ):
        """Notify agents of new ticket."""
        if not self.user_directory:
            return
        
        agents = await self.user_directory.get_assignable_agents(tenant_id)
        
        for agent in agents:
            await self.notification_provider.notify(
                tenant_id,
                agent["id"],
                "new_ticket",
                {"ticket_id": ticket["id"], "subject": ticket["subject"]},
                ["email"],
            )
