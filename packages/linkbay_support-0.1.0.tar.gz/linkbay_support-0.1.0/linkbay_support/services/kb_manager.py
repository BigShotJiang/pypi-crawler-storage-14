"""
Knowledge Base management service.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
from ..protocols import KBStorage
from ..schemas import (
    ArticleCreate,
    ArticleUpdate,
    ArticleResponse,
    ArticleSearchRequest,
    ArticleSearchResponse,
    TicketSuggestion,
)
from ..exceptions import ArticleNotFoundError


class KBManager:
    """
    Knowledge base management service.
    
    Handles articles, categories, search, and ticket suggestions.
    """
    
    def __init__(self, storage: KBStorage):
        """
        Initialize KB manager.
        
        Args:
            storage: KB storage implementation
        """
        self.storage = storage
    
    async def create_article(
        self,
        tenant_id: str,
        article_data: ArticleCreate,
    ) -> ArticleResponse:
        """Create new article."""
        article_dict = {
            **article_data.model_dump(),
            "view_count": 0,
            "helpful_count": 0,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
        
        if article_data.visibility == "public":
            article_dict["published_at"] = datetime.utcnow()
        
        created = await self.storage.create_article(tenant_id, article_dict)
        return ArticleResponse(**created)
    
    async def get_article(
        self,
        tenant_id: str,
        article_id: str,
        increment_views: bool = True,
    ) -> ArticleResponse:
        """Get article by ID."""
        article = await self.storage.get_article(tenant_id, article_id)
        
        if not article:
            raise ArticleNotFoundError(tenant_id, article_id)
        
        if increment_views:
            await self.storage.update_article(
                tenant_id,
                article_id,
                {"view_count": article.get("view_count", 0) + 1},
            )
            article["view_count"] += 1
        
        return ArticleResponse(**article)
    
    async def get_article_by_slug(
        self,
        tenant_id: str,
        slug: str,
    ) -> Optional[ArticleResponse]:
        """Get article by slug."""
        article = await self.storage.get_article_by_slug(tenant_id, slug)
        
        if not article:
            return None
        
        return ArticleResponse(**article)
    
    async def update_article(
        self,
        tenant_id: str,
        article_id: str,
        updates: ArticleUpdate,
    ) -> ArticleResponse:
        """Update article."""
        update_dict = updates.model_dump(exclude_unset=True)
        update_dict["updated_at"] = datetime.utcnow()
        
        if "visibility" in update_dict and update_dict["visibility"] == "public":
            update_dict["published_at"] = datetime.utcnow()
        
        updated = await self.storage.update_article(tenant_id, article_id, update_dict)
        return ArticleResponse(**updated)
    
    async def list_articles(
        self,
        tenant_id: str,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[ArticleResponse]:
        """List articles with filters."""
        articles = await self.storage.list_articles(
            tenant_id, skip, limit, filters
        )
        return [ArticleResponse(**a) for a in articles]
    
    async def search_articles(
        self,
        tenant_id: str,
        search: ArticleSearchRequest,
    ) -> ArticleSearchResponse:
        """Search articles with full-text and filters."""
        results = await self.storage.search_articles(
            tenant_id,
            search.query,
            search.model_dump(exclude={"query"}),
        )
        
        return ArticleSearchResponse(
            results=[ArticleResponse(**r) for r in results],
            total=len(results),
        )
    
    async def suggest_articles_for_ticket(
        self,
        tenant_id: str,
        ticket_id: str,
        ticket_subject: str,
        ticket_description: str,
        max_suggestions: int = 5,
    ) -> TicketSuggestion:
        """
        Suggest relevant articles for ticket.
        
        Uses ticket subject and description for semantic search.
        """
        query = f"{ticket_subject} {ticket_description}"
        
        results = await self.storage.search_articles(
            tenant_id,
            query,
            {"visibility": "public", "limit": max_suggestions},
        )
        
        suggestions = [ArticleResponse(**r) for r in results]
        
        # Simple confidence scoring based on order
        confidence_scores = [1.0 - (i * 0.15) for i in range(len(suggestions))]
        
        return TicketSuggestion(
            ticket_id=ticket_id,
            suggested_articles=suggestions,
            confidence_scores=confidence_scores,
        )
    
    async def record_helpful_vote(
        self,
        tenant_id: str,
        article_id: str,
        is_helpful: bool,
    ):
        """Record helpful/not helpful vote."""
        article = await self.get_article(tenant_id, article_id, increment_views=False)
        
        if is_helpful:
            await self.storage.update_article(
                tenant_id,
                article_id,
                {"helpful_count": article.helpful_count + 1},
            )
