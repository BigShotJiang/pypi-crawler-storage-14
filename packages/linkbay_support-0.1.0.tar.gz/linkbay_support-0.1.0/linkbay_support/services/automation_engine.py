"""
Automation and workflow engine.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from ..protocols import TicketStorage, SLAPolicy
from ..schemas import AutomationRule
from ..constants import TicketStatus, SLAStatus, AutomationTrigger, AUTO_CLOSE_DAYS


class AutomationEngine:
    """
    Automation engine for support workflows.
    
    Handles rule evaluation, SLA monitoring, auto-escalation, auto-close.
    """
    
    def __init__(
        self,
        storage: TicketStorage,
        sla_policy: Optional[SLAPolicy] = None,
    ):
        """
        Initialize automation engine.
        
        Args:
            storage: Ticket storage implementation
            sla_policy: SLA policy provider
        """
        self.storage = storage
        self.sla_policy = sla_policy
        self.rules: List[AutomationRule] = []
    
    def add_rule(self, rule: AutomationRule):
        """Add automation rule."""
        self.rules.append(rule)
    
    def remove_rule(self, rule_id: str):
        """Remove automation rule."""
        self.rules = [r for r in self.rules if r.rule_id != rule_id]
    
    async def evaluate_trigger(
        self,
        tenant_id: str,
        trigger: str,
        ticket: Dict[str, Any],
    ):
        """
        Evaluate rules for trigger event.
        
        Args:
            tenant_id: Tenant identifier
            trigger: Trigger event type
            ticket: Ticket data
        """
        matching_rules = [
            r for r in self.rules
            if r.trigger == trigger and r.is_active
        ]
        
        for rule in matching_rules:
            if self._check_conditions(ticket, rule.conditions):
                await self._execute_actions(tenant_id, ticket, rule.actions)
    
    def _check_conditions(
        self,
        ticket: Dict[str, Any],
        conditions: Dict[str, Any],
    ) -> bool:
        """Check if ticket matches rule conditions."""
        for field, expected_value in conditions.items():
            ticket_value = ticket.get(field)
            
            if isinstance(expected_value, list):
                if ticket_value not in expected_value:
                    return False
            elif ticket_value != expected_value:
                return False
        
        return True
    
    async def _execute_actions(
        self,
        tenant_id: str,
        ticket: Dict[str, Any],
        actions: List[Dict[str, Any]],
    ):
        """Execute automation actions."""
        for action in actions:
            action_type = action.get("action")
            
            if action_type == "assign":
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {"assigned_agent_id": action.get("agent_id")},
                )
            
            elif action_type == "escalate":
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {
                        "status": TicketStatus.ESCALATED.value,
                        "priority": action.get("priority", "high"),
                    },
                )
            
            elif action_type == "close":
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {
                        "status": TicketStatus.CLOSED.value,
                        "closed_at": datetime.utcnow(),
                    },
                )
            
            elif action_type == "update_priority":
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {"priority": action.get("priority")},
                )
    
    async def check_sla_status(self, tenant_id: str):
        """
        Check SLA status for all tickets.
        
        Identifies at-risk and breached tickets.
        """
        if not self.sla_policy:
            return
        
        tickets = await self.storage.get_tickets_by_sla_status(
            tenant_id,
            SLAStatus.WITHIN_SLA.value,
        )
        
        now = datetime.utcnow()
        
        for ticket in tickets:
            sla_due_at = ticket.get("sla_due_at")
            if not sla_due_at:
                continue
            
            time_remaining = (sla_due_at - now).total_seconds() / 60
            sla_config = await self.sla_policy.get_sla_config(
                tenant_id,
                ticket["priority"],
            )
            
            total_time = sla_config.get("response_time_minutes", 0)
            threshold_time = total_time * 0.2  # 20% remaining
            
            if time_remaining <= 0:
                # Breached
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {"sla_status": SLAStatus.BREACHED.value},
                )
                await self.evaluate_trigger(
                    tenant_id,
                    AutomationTrigger.SLA_BREACHED.value,
                    ticket,
                )
            
            elif time_remaining <= threshold_time:
                # At risk
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {"sla_status": SLAStatus.AT_RISK.value},
                )
                await self.evaluate_trigger(
                    tenant_id,
                    AutomationTrigger.SLA_AT_RISK.value,
                    ticket,
                )
    
    async def auto_escalate_breached_tickets(self, tenant_id: str):
        """Auto-escalate breached SLA tickets."""
        tickets = await self.storage.get_tickets_by_sla_status(
            tenant_id,
            SLAStatus.BREACHED.value,
        )
        
        for ticket in tickets:
            if ticket["status"] != TicketStatus.ESCALATED.value:
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {
                        "status": TicketStatus.ESCALATED.value,
                        "priority": "urgent",
                    },
                )
    
    async def auto_close_idle_tickets(self, tenant_id: str):
        """Auto-close resolved tickets idle for configured days."""
        cutoff_date = datetime.utcnow() - timedelta(days=AUTO_CLOSE_DAYS)
        
        tickets = await self.storage.list_tickets(
            tenant_id,
            0,
            1000,
            {"status": TicketStatus.RESOLVED.value},
        )
        
        for ticket in tickets:
            resolved_at = ticket.get("resolved_at")
            if resolved_at and resolved_at < cutoff_date:
                await self.storage.update_ticket(
                    tenant_id,
                    ticket["id"],
                    {
                        "status": TicketStatus.CLOSED.value,
                        "closed_at": datetime.utcnow(),
                    },
                )
