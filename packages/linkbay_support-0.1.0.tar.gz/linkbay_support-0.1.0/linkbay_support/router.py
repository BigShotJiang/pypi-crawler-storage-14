"""
FastAPI routers for support and knowledge base.
"""

from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import datetime

from .services.ticket_manager import TicketManager
from .services.kb_manager import KBManager
from .services.automation_engine import AutomationEngine
from .services.reporting import ReportingService
from .schemas import (
    TicketCreate,
    TicketUpdate,
    TicketResponse,
    TicketListResponse,
    MessageCreate,
    MessageResponse,
    ArticleCreate,
    ArticleUpdate,
    ArticleResponse,
    ArticleListResponse,
    ArticleSearchRequest,
    ArticleSearchResponse,
    TicketStats,
    SLAReport,
    AgentPerformance,
)


def create_support_router(
    ticket_manager_dep,
    automation_engine_dep=None,
    reporting_service_dep=None,
    tenant_id_dep=None,
) -> APIRouter:
    """
    Create FastAPI router for support tickets.
    
    Args:
        ticket_manager_dep: Dependency for TicketManager
        automation_engine_dep: Optional dependency for AutomationEngine
        reporting_service_dep: Optional dependency for ReportingService
        tenant_id_dep: Dependency for extracting tenant_id (e.g., from JWT)
    
    Returns:
        Configured APIRouter
    
    Example:
        ```python
        from linkbay_support import create_support_router, TicketManager
        from linkbay_support.protocols import TicketStorage
        
        async def get_ticket_manager():
            storage = MyTicketStorage()
            return TicketManager(storage)
        
        async def get_tenant_id():
            return "agency123"
        
        router = create_support_router(
            ticket_manager_dep=Depends(get_ticket_manager),
            tenant_id_dep=Depends(get_tenant_id),
        )
        
        app.include_router(router, prefix="/api/support")
        ```
    """
    router = APIRouter(tags=["support"])
    
    @router.post("/tickets", response_model=TicketResponse, status_code=201)
    async def create_ticket(
        ticket_data: TicketCreate,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Create new support ticket."""
        return await ticket_manager.create_ticket(tenant_id, ticket_data)
    
    @router.get("/tickets/{ticket_id}", response_model=TicketResponse)
    async def get_ticket(
        ticket_id: str,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Get ticket by ID."""
        return await ticket_manager.get_ticket(tenant_id, ticket_id)
    
    @router.patch("/tickets/{ticket_id}", response_model=TicketResponse)
    async def update_ticket(
        ticket_id: str,
        updates: TicketUpdate,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Update ticket."""
        return await ticket_manager.update_ticket(tenant_id, ticket_id, updates)
    
    @router.get("/tickets", response_model=List[TicketResponse])
    async def list_tickets(
        skip: int = Query(0, ge=0),
        limit: int = Query(100, ge=1, le=500),
        status: Optional[str] = None,
        priority: Optional[str] = None,
        assigned_agent_id: Optional[str] = None,
        customer_id: Optional[str] = None,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """List tickets with filters."""
        filters = {}
        if status:
            filters["status"] = status
        if priority:
            filters["priority"] = priority
        if assigned_agent_id:
            filters["assigned_agent_id"] = assigned_agent_id
        if customer_id:
            filters["customer_id"] = customer_id
        
        return await ticket_manager.list_tickets(tenant_id, skip, limit, filters)
    
    @router.post("/tickets/{ticket_id}/messages", response_model=MessageResponse, status_code=201)
    async def add_message(
        ticket_id: str,
        message_data: MessageCreate,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Add message to ticket."""
        return await ticket_manager.add_message(tenant_id, ticket_id, message_data)
    
    @router.post("/tickets/{ticket_id}/claim", response_model=TicketResponse)
    async def claim_ticket(
        ticket_id: str,
        agent_id: str,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Agent claims ticket."""
        return await ticket_manager.claim_ticket(tenant_id, ticket_id, agent_id)
    
    @router.post("/tickets/{ticket_id}/assign", response_model=TicketResponse)
    async def assign_ticket(
        ticket_id: str,
        agent_id: str,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Assign ticket to agent."""
        return await ticket_manager.assign_ticket(tenant_id, ticket_id, agent_id)
    
    @router.post("/tickets/{ticket_id}/escalate", response_model=TicketResponse)
    async def escalate_ticket(
        ticket_id: str,
        escalate_to_agent_id: str,
        reason: Optional[str] = None,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Escalate ticket."""
        return await ticket_manager.escalate_ticket(
            tenant_id, ticket_id, escalate_to_agent_id, reason
        )
    
    @router.post("/tickets/{ticket_id}/close", response_model=TicketResponse)
    async def close_ticket(
        ticket_id: str,
        resolution_notes: Optional[str] = None,
        ticket_manager: TicketManager = ticket_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Close ticket."""
        return await ticket_manager.close_ticket(tenant_id, ticket_id, resolution_notes)
    
    # Reporting endpoints (if reporting service provided)
    if reporting_service_dep:
        @router.get("/reports/stats", response_model=TicketStats)
        async def get_ticket_stats(
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None,
            reporting: ReportingService = reporting_service_dep,
            tenant_id: str = tenant_id_dep,
        ):
            """Get ticket statistics."""
            return await reporting.generate_ticket_stats(tenant_id, start_date, end_date)
        
        @router.get("/reports/sla", response_model=SLAReport)
        async def get_sla_report(
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None,
            reporting: ReportingService = reporting_service_dep,
            tenant_id: str = tenant_id_dep,
        ):
            """Get SLA compliance report."""
            return await reporting.generate_sla_report(tenant_id, start_date, end_date)
        
        @router.get("/reports/agents/{agent_id}", response_model=AgentPerformance)
        async def get_agent_performance(
            agent_id: str,
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None,
            reporting: ReportingService = reporting_service_dep,
            tenant_id: str = tenant_id_dep,
        ):
            """Get agent performance metrics."""
            return await reporting.generate_agent_performance(
                tenant_id, agent_id, start_date, end_date
            )
    
    return router


def create_kb_router(
    kb_manager_dep,
    tenant_id_dep=None,
) -> APIRouter:
    """
    Create FastAPI router for knowledge base.
    
    Args:
        kb_manager_dep: Dependency for KBManager
        tenant_id_dep: Dependency for extracting tenant_id
    
    Returns:
        Configured APIRouter
    
    Example:
        ```python
        from linkbay_support import create_kb_router, KBManager
        
        async def get_kb_manager():
            storage = MyKBStorage()
            return KBManager(storage)
        
        async def get_tenant_id():
            return "agency123"
        
        router = create_kb_router(
            kb_manager_dep=Depends(get_kb_manager),
            tenant_id_dep=Depends(get_tenant_id),
        )
        
        app.include_router(router, prefix="/api/kb")
        ```
    """
    router = APIRouter(tags=["knowledge-base"])
    
    @router.post("/articles", response_model=ArticleResponse, status_code=201)
    async def create_article(
        article_data: ArticleCreate,
        kb_manager: KBManager = kb_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Create new article."""
        return await kb_manager.create_article(tenant_id, article_data)
    
    @router.get("/articles/{article_id}", response_model=ArticleResponse)
    async def get_article(
        article_id: str,
        kb_manager: KBManager = kb_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Get article by ID."""
        return await kb_manager.get_article(tenant_id, article_id)
    
    @router.get("/articles/slug/{slug}", response_model=ArticleResponse)
    async def get_article_by_slug(
        slug: str,
        kb_manager: KBManager = kb_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Get article by slug."""
        article = await kb_manager.get_article_by_slug(tenant_id, slug)
        if not article:
            raise HTTPException(status_code=404, detail="Article not found")
        return article
    
    @router.patch("/articles/{article_id}", response_model=ArticleResponse)
    async def update_article(
        article_id: str,
        updates: ArticleUpdate,
        kb_manager: KBManager = kb_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Update article."""
        return await kb_manager.update_article(tenant_id, article_id, updates)
    
    @router.get("/articles", response_model=List[ArticleResponse])
    async def list_articles(
        skip: int = Query(0, ge=0),
        limit: int = Query(100, ge=1, le=500),
        category_id: Optional[str] = None,
        visibility: Optional[str] = None,
        is_featured: Optional[bool] = None,
        kb_manager: KBManager = kb_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """List articles with filters."""
        filters = {}
        if category_id:
            filters["category_id"] = category_id
        if visibility:
            filters["visibility"] = visibility
        if is_featured is not None:
            filters["is_featured"] = is_featured
        
        return await kb_manager.list_articles(tenant_id, skip, limit, filters)
    
    @router.post("/articles/search", response_model=ArticleSearchResponse)
    async def search_articles(
        search_request: ArticleSearchRequest,
        kb_manager: KBManager = kb_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Search articles."""
        return await kb_manager.search_articles(tenant_id, search_request)
    
    @router.post("/articles/{article_id}/helpful")
    async def record_helpful_vote(
        article_id: str,
        is_helpful: bool,
        kb_manager: KBManager = kb_manager_dep,
        tenant_id: str = tenant_id_dep,
    ):
        """Record helpful vote."""
        await kb_manager.record_helpful_vote(tenant_id, article_id, is_helpful)
        return {"status": "recorded"}
    
    return router
