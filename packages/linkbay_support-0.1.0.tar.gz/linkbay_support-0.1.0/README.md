# LinkBay-Support

Protocol-based, database-agnostic support and helpdesk system for multi-tenant SaaS applications.

**Version**: 0.1.0  
**License**: Proprietary  
**Python**: 3.8+

---

## Table of Contents

- [Features](#features)
- [Architecture Overview](#architecture-overview)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Multi-Channel and Automation Examples](#multi-channel-and-automation-examples)
- [Security and Multi-Tenant Considerations](#security-and-multi-tenant-considerations)
- [Scalability and Messaging](#scalability-and-messaging)
- [LinkBay Ecosystem](#linkbay-ecosystem)
- [Support and License](#support-and-license)

---

## Features

- **Ticket lifecycle**: Create, assign, claim, escalate, resolve, and close with full SLA tracking.
- **Knowledge base**: Multi-category articles, full-text search, and suggestion hooks.
- **Automation engine**: Rule-based workflows for SLA breaches, idle ticket auto-close, priority updates, and escalations.
- **Reporting**: Ticket stats, SLA compliance, and agent performance metrics via dedicated service.
- **Multi-channel messaging**: Email, webhooks, push, SMS, or custom channels through adapter protocols.
- **Tenant isolation**: Every API requires `tenant_id`, ensuring hard data boundaries.
- **Protocol-driven**: Storage, messaging, notifications, directory, and SLA providers are pluggable to fit your stack.

---

## Architecture Overview

Top-level components align around clear protocols and services:

```
Client / Channel
      |
      v
TicketManager ----> TicketStorage (your DB)
      |                |
      |                +--> ReportingService (analytics queries)
      |
      +--> MessageProvider (email/chat)
      +--> NotificationProvider (agent alerts)
      +--> AutomationEngine <-> SLAPolicy
      +--> KBManager ----> KBStorage (articles/search)
```

### Protocols
- `TicketStorage`: Persists tickets, messages, SLA markers, and metadata.
- `KBStorage`: Handles article CRUD, taxonomy, and search operations.
- `MessageProvider`: Delivers outbound replies over email, chat, or SMS.
- `NotificationProvider`: Notifies agents and stakeholders about events.
- `UserDirectory`: Fetches agent/customer context for assignments and routing.
- `SLAPolicy`: Supplies SLA thresholds and calculates due dates per priority or tenant plan.

### Services
- `TicketManager`: Core ticket CRUD, assignments, messaging, SLA updates.
- `KBManager`: Article creation, update, search, and categorization.
- `AutomationEngine`: Evaluates rules on triggers (`ticket_created`, `sla_breached`, `ticket_idle`, etc.).
- `ReportingService`: Aggregates metrics for dashboards and exports.

Routers (`create_support_router`, `create_kb_router`) expose FastAPI endpoints that sit atop these services.

---

## Installation

```bash
pip install linkbay-support
```

Optional extras:

```bash
pip install linkbay-support[fastapi]   # Router and dependency helpers
pip install linkbay-support[ai]        # Semantic KB search (pgvector, numpy)
pip install linkbay-support[dev]       # Test and lint toolchain
pip install linkbay-support[all]       # Everything above
```

Install from repository:

```bash
pip install git+https://github.com/AlessioQuagliara/LinkBay-Py@main#subdirectory=LinkBay-Support
```

---

## Quick Start

### 1. Implement storage adapters

```python
from typing import Any, Dict, Optional
from linkbay_support.protocols import TicketStorage, KBStorage

class PostgresTicketStorage(TicketStorage):
    async def create_ticket(self, tenant_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        row = await db.fetchrow("""INSERT INTO support_tickets (...) VALUES (...) RETURNING *""")
        return dict(row)

    async def get_ticket(self, tenant_id: str, ticket_id: str) -> Optional[Dict[str, Any]]:
        row = await db.fetchrow("""SELECT * FROM support_tickets WHERE tenant_id=$1 AND id=$2""", tenant_id, ticket_id)
        return dict(row) if row else None

    # Implement list_tickets, update_ticket, add_message, etc.

class PostgresKBStorage(KBStorage):
    async def create_article(self, tenant_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        row = await db.fetchrow("""INSERT INTO support_articles (...) VALUES (...) RETURNING *""")
        return dict(row)

    # Implement get_article, list_articles, search_articles, etc.
```

### 2. Wire services

```python
from linkbay_support import TicketManager, KBManager, AutomationEngine, ReportingService

ticket_storage = PostgresTicketStorage()
kb_storage = PostgresKBStorage()

ticket_manager = TicketManager(storage=ticket_storage)
kb_manager = KBManager(storage=kb_storage)
automation_engine = AutomationEngine(storage=ticket_storage)
reporting = ReportingService(storage=ticket_storage)
```

### 3. Run a ticket lifecycle

```python
from linkbay_support.schemas import TicketCreate, TicketUpdate, MessageCreate

ticket = await ticket_manager.create_ticket(
    tenant_id="agency123",
    ticket_data=TicketCreate(
        subject="Cannot access dashboard",
        description="Getting 500 error when trying to login",
        priority="high",
        category="technical",
        customer_id="cust_456",
        customer_email="customer@example.com",
        initial_message=MessageCreate(
            content="Error logs attached",
            author_id="cust_456",
        ),
    ),
)

await ticket_manager.claim_ticket(
    tenant_id="agency123",
    ticket_id=ticket.id,
    agent_id="agent_789",
)

await ticket_manager.add_message(
    tenant_id="agency123",
    ticket_id=ticket.id,
    message_data=MessageCreate(
        content="Issue reproduced. Rolling out fix.",
        message_type="agent_reply",
        author_id="agent_789",
    ),
)

await ticket_manager.update_ticket(
    tenant_id="agency123",
    ticket_id=ticket.id,
    updates=TicketUpdate(status="resolved"),
)

await ticket_manager.close_ticket(
    tenant_id="agency123",
    ticket_id=ticket.id,
    resolution_notes="Server configuration updated and tested",
)
```

### 4. Publish knowledge base content

```python
from linkbay_support.schemas import ArticleCreate

article = await kb_manager.create_article(
    tenant_id="agency123",
    article_data=ArticleCreate(
        title="How to reset your password",
        slug="reset-password",
        content="Step-by-step guide...",
        visibility="public",
        is_featured=True,
    ),
)
```

### 5. Automate SLA workflows

```python
from linkbay_support.schemas import AutomationRule

automation_engine.add_rule(
    AutomationRule(
        rule_id="escalate_breach",
        trigger="sla_breached",
        conditions={"priority": ["high", "critical"]},
        actions=[{"action": "escalate", "priority": "urgent"}],
        is_active=True,
    )
)

await automation_engine.check_sla_status(tenant_id="agency123")
```

### 6. Expose APIs with FastAPI

```python
from fastapi import Depends, FastAPI
from linkbay_support import create_support_router, TicketManager

app = FastAPI()

async def get_ticket_manager() -> TicketManager:
    return ticket_manager

async def get_tenant_id() -> str:
    return "agency123"

support_router = create_support_router(
    ticket_manager_dep=Depends(get_ticket_manager),
    tenant_id_dep=Depends(get_tenant_id),
)

app.include_router(support_router, prefix="/api/support")
```

---

## Multi-Channel and Automation Examples

- **Inbound email to ticket**: Implement `MessageProvider` with your email gateway. When an email arrives, convert it to `TicketCreate` and call `ticket_manager.create_ticket`. Store the raw payload in metadata for compliance.
- **KB suggestion on ticket creation**: After `create_ticket`, call `kb_manager.search_articles` with the subject to suggest relevant content and add it via `MessageCreate(message_type="suggestion")`.
- **Daily reporting**: Use `reporting.generate_ticket_stats` and `reporting.generate_sla_report` to feed dashboards or export CSVs for operations teams.
- **Automation triggers**: Wire cron or event bus to invoke `automation_engine.evaluate_trigger` on `ticket_created`, `ticket_updated`, or `check_sla_status` for proactive alerts.

---

## Security and Multi-Tenant Considerations

- **Access control**: Guard API endpoints with `linkbay-roles` permissions (`support:agent`, `support:admin`). Combine RBAC with tenant-level scopes to prevent cross-tenant access.
- **Data segregation**: Namespace all storage keys by tenant (`support_tickets_{tenant_id}` tables/collections) and enforce row-level security in relational databases.
- **PII hygiene**: Use `TicketUpdate` to redact sensitive fields and configure retention via `LinkBay-Settings` (auto-delete closed tickets after N days to meet GDPR/CPRA requirements).
- **Audit trail**: Emit ticket lifecycle events to `LinkBay-Audit` for traceability (who viewed, who escalated, breach timestamps).
- **Multi-brand tenants**: Extend metadata with `brand_id` or `channel_id` and enforce filters in `TicketStorage.list_tickets` to keep brand support teams isolated.
- **Attachment scanning**: Pair file uploads with `LinkBay-Storage` and run virus scanning before allowing agent download.

---

## Scalability and Messaging

- **Async delivery**: Offload `MessageProvider.send_message` to a queue (Celery, AWS SQS, or LinkBay-Notifications) to avoid blocking API threads.
- **WebSocket/chat**: Implement a channel-specific provider that publishes events to your socket hub. Use ticket metadata to broadcast only to permitted agents.
- **SLA computation**: Cache SLA policies per tenant to avoid repetitive external calls during `check_sla_status` runs.
- **Analytics volume**: `ReportingService` may fetch large datasets; combine with LinkBay-Analytics or materialized views for heavy tenants.

---

## LinkBay Ecosystem

- **LinkBay-Roles**: Apply permission guards to support routers and automate agent onboarding.
- **LinkBay-Notifications**: Drive multichannel alerts (email, push, SMS) from `NotificationProvider` implementations.
- **LinkBay-Audit**: Record lifecycle events for compliance and incident response.
- **LinkBay-Settings**: Store tenant preferences (SLA policies, auto-close windows, channel enablement) and hydrate adapters at runtime.
- **LinkBay-Storage**: Handle secure attachment storage, presigned URLs, and virus scanning workflows.

---

## Support and License

- Issues: https://github.com/AlessioQuagliara/LinkBay-Py/issues/new?labels=linkbay-support
- Email: quagliara.alessio@gmail.com
- License: Proprietary (c) 2025 Alessio Quagliara. All rights reserved.

Contribuisci, apri una issue o raccontaci come stai usando la libreria 🧡
