"""
Pushtunes - A library for syncing music between different services

This package provides clients and utilities for working with various music services.
"""

# from .models.album import Album
# from .clients.subsonic import SubsonicClient
# from .services.music_service import MusicService
# from .services.spotify import SpotifyService
# from .services.ytm import YTMService
# from .sources.base import MusicSource
# from .sources.subsonic import SubsonicSource
# from .sources.csv import CSVSource
#
#
# __version__ = "1.1.0"
# __all__ = [
#     "SubsonicClient",
#     "MusicService",
#     "MusicSource",
#     "Album",
#     "SpotifyService",
#     "YTMService",
#     "SubsonicSource",
#     "CSVSource",
# ]
