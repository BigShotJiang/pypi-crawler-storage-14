#!/bin/bash
set -e

echo "🧪 Running tests..."
pytest tests/api/

echo "🧹 Cleaning old builds..."
rm -rf dist/ build/

echo "📦 Building package..."
python -m build

echo "🧪 Uploading to TestPyPI..."
python -m twine upload --repository testpypi dist/*

VERSION=$(grep 'version =' pyproject.toml | cut -d'"' -f2)
echo ""
echo "✅ Test deployment complete!"
echo ""
echo "📝 To test installation, run:"
echo "   pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ physionet==$VERSION"
