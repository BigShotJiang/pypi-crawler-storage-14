def test_hello_world():
    assert "Hello, world!" == "Hello, world!"
