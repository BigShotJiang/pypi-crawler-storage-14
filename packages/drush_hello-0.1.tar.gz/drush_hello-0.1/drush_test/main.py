def hello():
    print("Bonjour je suis en phase test de Drush")
