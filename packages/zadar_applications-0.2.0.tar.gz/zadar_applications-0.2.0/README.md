# zadar_applications

A pip-installable package providing the generated Python ROS1 message classes
for Zadar radar sensors.

Includes the following message types:

- `RosZadarCluster`
- `RosZadarClusters`
- `RosZadarTrack`
- `RosZadarTracks`
- `RosZadarImu`
- `RosZadarOdometry`

These are the generated `genpy` message modules, packaged normally so they can be
installed with:

```bash
pip install zadar_applications
