"""
zadar_applications

Provides pip-installable ROS1 message types for Zadar radar systems.
"""

__all__ = ["msgs"]
__version__ = "0.2.0"
