export const baseUrlToBaseUrlName = {
  'https://benchmark-s-6d17010be8a25023a9eab0a688d29c05.staging.langgraph.app': 's',
  'https://benchmark-m-fd2e770a72f55324b6c59f2664a56d32.staging.langgraph.app': 'm',
  'https://benchmark-l-d655833b3cba5fc8a703c95f20045831.staging.langgraph.app': 'l',
  'https://benchmark-dr-s-2799835ad04b501a95044223ae72ced7.staging.langgraph.app': 'dr-s',
  'https://benchmark-dr-m-ec079ea9f20e5655ab35a4ebc1a0ade8.staging.langgraph.app': 'dr-m',
  'https://benchmark-dr-l-e996bbdcfbf15c9e8f547ab74fae93d2.staging.langgraph.app': 'dr-l'
};
