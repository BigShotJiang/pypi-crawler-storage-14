from __future__ import annotations

from typing import Optional, Dict
from pydantic import BaseModel, Field


class EntitlementAssignment(BaseModel):
    """
    Represents an assignment (allocation) of an Entitlement to a Person (optionally scoped to an Organization).
    """
    id: Optional[str] = Field(None, description="Canonical assignment id (UUID preferred)")
    entitlement_id: Optional[str] = Field(None, description="Canonical entitlement id")
    person_id: Optional[str] = Field(None, description="Canonical person id")
    organization_id: Optional[str] = Field(None, description="Optional organization id")
    amount: Optional[float] = Field(None, description="Numeric amount assigned")
    units: Optional[str] = Field(None, description="Units (e.g., 'USD', 'hours', 'credits')")
    assigned_at: Optional[str] = Field(None, description="ISO-8601 assignment timestamp")
    effective_from: Optional[str] = Field(None, description="ISO-8601 effective start")
    effective_to: Optional[str] = Field(None, description="ISO-8601 effective end")
    consumed_amount: Optional[float] = Field(0.0, description="Amount consumed so far")
    status: Optional[str] = Field(None, description="Assignment status, e.g. 'active', 'revoked', 'expired'")
    metadata: Optional[Dict[str, object]] = Field(None, description="Provider-specific metadata")
