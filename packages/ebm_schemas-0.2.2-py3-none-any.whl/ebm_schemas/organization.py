from __future__ import annotations

from typing import Optional, Dict
from pydantic import BaseModel, Field


class Organization(BaseModel):
    """
    Canonical Organization / Employer model.
    """
    id: Optional[str] = Field(None, description="Canonical organization id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-specific organization id")
    name: Optional[str] = Field(None, description="Organization name")
    domain: Optional[str] = Field(None, description="Primary domain or identifier")
    parent_organization_id: Optional[str] = Field(None, description="Optional parent organization id")
    metadata: Optional[Dict[str, object]] = Field(None, description="Provider-specific metadata")
