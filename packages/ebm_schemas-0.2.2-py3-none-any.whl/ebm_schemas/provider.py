from __future__ import annotations

from typing import Optional, Dict
from pydantic import BaseModel, AnyUrl, Field


class Provider(BaseModel):
    """
    Canonical Provider representation.

    Represents the external system that sends events or provides data (CASE, LTI, OneRoster, UKG, etc.).
    Keep credentials/secrets out of this model; store secrets in a secure secrets manager and only reference
    provider by id here.
    """
    id: Optional[str] = Field(None, description="Internal canonical provider id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-assigned id")
    name: Optional[str] = Field(None, description="Human-friendly provider name")
    type: Optional[str] = Field(None, description="Provider type/adapter (e.g., 'lti', 'oneroster', 'ukg', 'case')")
    webhook_url: Optional[AnyUrl] = Field(None, description="Optional callback/webhook URL for provider")
    metadata: Optional[Dict[str, object]] = Field(None, description="Provider-specific metadata blob")
