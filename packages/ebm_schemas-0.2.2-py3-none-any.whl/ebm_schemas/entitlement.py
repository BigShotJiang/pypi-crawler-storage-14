from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class Entitlement(BaseModel):
    """
    Canonical Entitlement representation.
    Represents a benefit or allowance (monetary or non-monetary).
    """
    id: Optional[str] = Field(None, description="Entitlement id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-specific entitlement id")
    type: Optional[str] = Field(None, description="Entitlement type (e.g., 'credit', 'discount', 'seat')")
    amount: Optional[float] = Field(None, description="Numeric amount or value (if applicable)")
    units: Optional[str] = Field(None, description="Units for amount, e.g., 'USD', 'hours', 'credits'")
    effective_from: Optional[str] = Field(None, description="ISO-8601 effective start")
    effective_to: Optional[str] = Field(None, description="ISO-8601 effective end")
    metadata: Optional[dict] = Field(None, description="Provider-specific metadata")
