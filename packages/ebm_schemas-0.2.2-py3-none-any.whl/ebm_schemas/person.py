from __future__ import annotations

from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field


class Person(BaseModel):
    """
    Canonical Person representation.

    Fields kept intentionally conservative for Phase‑0. Add optional fields as needed,
    but prefer adding new optional keys instead of renaming/removing existing ones.
    """
    id: Optional[str] = Field(None, description="Internal canonical person id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-specific person id (if any)")
    given_name: Optional[str] = Field(None, description="First name / given name")
    middle_name: Optional[str] = Field(None, description="Middle name(s)")
    family_name: Optional[str] = Field(None, description="Last name / family name")
    email: Optional[EmailStr] = Field(None, description="Primary contact email")
    phone: Optional[str] = Field(None, description="Primary contact phone number (E.164 encouraged)")
    date_of_birth: Optional[str] = Field(None, description="ISO-8601 date of birth, e.g. '1990-01-02'")
    affiliations: Optional[List[str]] = Field(None, description="Optional list of affiliations/organizations")
    metadata: Optional[dict] = Field(None, description="Provider-specific metadata blob")
