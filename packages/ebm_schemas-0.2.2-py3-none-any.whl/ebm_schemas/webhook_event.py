from __future__ import annotations

from typing import Optional, Dict, Any
from pydantic import BaseModel, Field


class WebhookEvent(BaseModel):
    """
    Canonical webhook envelope that wraps provider payloads.
    This separates envelope metadata from the typed payload (Person/Course/etc).
    """
    idempotency_key: Optional[str] = Field(None, description="Client-provided idempotency key (X-Idempotency-Key)")
    provider_id: Optional[str] = Field(None, description="Canonical provider id (source)")
    event: str = Field(..., description="Event name, e.g. 'person.created', 'enrollment.updated'")
    received_at: Optional[str] = Field(None, description="ISO-8601 when the webhook was received")
    payload_schema: Optional[str] = Field(None, description="Optional pointer to the payload schema name (for routing/validation)")
    raw_payload: Optional[str] = Field(None, description="Raw JSON payload as string (used for audit)")
    signature: Optional[str] = Field(None, description="Signature header value as received from provider, if present")
    headers: Optional[Dict[str, Any]] = Field(None, description="Selected headers captured for audit (do not include secrets)")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Provider-specific metadata")
