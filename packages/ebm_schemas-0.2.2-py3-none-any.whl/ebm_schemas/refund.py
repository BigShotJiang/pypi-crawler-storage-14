from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class Refund(BaseModel):
    """
    Canonical Refund representation.
    """
    id: Optional[str] = Field(None, description="Refund id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-specific refund id")
    amount: Optional[float] = Field(None, description="Monetary amount of refund")
    currency: Optional[str] = Field("USD", description="Currency code (ISO 4217)")
    reason: Optional[str] = Field(None, description="Optional human-readable reason")
    created_at: Optional[str] = Field(None, description="ISO-8601 created timestamp")
    processed_at: Optional[str] = Field(None, description="ISO-8601 processed timestamp")
    metadata: Optional[dict] = Field(None, description="Provider-specific metadata")
