from __future__ import annotations

from typing import Optional, Dict
from pydantic import BaseModel, Field


class Enrollment(BaseModel):
    """
    Canonical Enrollment/Registration linking a Person to a Course.
    """
    id: Optional[str] = Field(None, description="Canonical enrollment id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-specific enrollment id")
    person_id: Optional[str] = Field(None, description="Canonical person id")
    course_id: Optional[str] = Field(None, description="Canonical course id")
    status: Optional[str] = Field(None, description="Enrollment status, e.g. 'active', 'completed', 'withdrawn'")
    enrolled_at: Optional[str] = Field(None, description="ISO-8601 enrollment timestamp")
    withdrawn_at: Optional[str] = Field(None, description="ISO-8601 withdrawal timestamp (if any)")
    grade: Optional[str] = Field(None, description="Optional grade or progress marker")
    metadata: Optional[Dict[str, object]] = Field(None, description="Provider-specific metadata")
