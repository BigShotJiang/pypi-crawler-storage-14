from __future__ import annotations

from typing import Optional, Dict
from pydantic import BaseModel, Field


class Transaction(BaseModel):
    """
    Lightweight transaction/payment record used for charges/refunds and reconciliations.
    """
    id: Optional[str] = Field(None, description="Canonical transaction id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider or gateway transaction id")
    person_id: Optional[str] = Field(None, description="Canonical person id associated with this transaction")
    amount: Optional[float] = Field(None, description="Monetary amount")
    currency: Optional[str] = Field("USD", description="Currency code (ISO 4217)")
    type: Optional[str] = Field(None, description="Transaction type, e.g. 'charge', 'refund', 'payout'")
    status: Optional[str] = Field(None, description="Transaction status, e.g. 'pending', 'posted', 'failed'")
    created_at: Optional[str] = Field(None, description="ISO-8601 creation timestamp")
    processed_at: Optional[str] = Field(None, description="ISO-8601 processed timestamp")
    provider_transaction_id: Optional[str] = Field(None, description="Provider/gateway transaction id")
    metadata: Optional[Dict[str, object]] = Field(None, description="Provider-specific metadata")
