from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class Course(BaseModel):
    """
    Canonical Course representation.
    """
    id: Optional[str] = Field(None, description="Internal canonical course id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-specific course id")
    title: Optional[str] = Field(None, description="Course title")
    code: Optional[str] = Field(None, description="Course code (if provided by partner)")
    description: Optional[str] = Field(None, description="Short course description")
    provider: Optional[str] = Field(None, description="Providing organization or institution")
    starts_at: Optional[str] = Field(None, description="ISO-8601 start date/time")
    ends_at: Optional[str] = Field(None, description="ISO-8601 end date/time")
    metadata: Optional[dict] = Field(None, description="Provider-specific metadata")
