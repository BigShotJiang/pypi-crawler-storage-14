from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class Milestone(BaseModel):
    """
    Canonical Milestone representation (e.g., course completion step, module completion).
    """
    id: Optional[str] = Field(None, description="Milestone id (UUID preferred)")
    external_id: Optional[str] = Field(None, description="Provider-specific milestone id")
    name: Optional[str] = Field(None, description="Human friendly name of milestone")
    due_at: Optional[str] = Field(None, description="ISO-8601 due date/time")
    completed_at: Optional[str] = Field(None, description="ISO-8601 completion timestamp")
    status: Optional[str] = Field(None, description="Status (e.g., pending, completed, failed)")
    metadata: Optional[dict] = Field(None, description="Provider-specific metadata")
