from album.argument_parsing import main


def startup():
    main()


if __name__ == "__main__":
    startup()
