from .weighted_distribution import weighted_distribution

__all__ = ["weighted_distribution"]
