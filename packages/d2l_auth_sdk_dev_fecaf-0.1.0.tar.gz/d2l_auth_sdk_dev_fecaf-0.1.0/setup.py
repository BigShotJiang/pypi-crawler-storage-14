import setuptools

# Lê o conteúdo do README.md para a descrição longa do pacote
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="d2l-auth-sdk-dev-fecaf",
    version="0.1.0",
    author="arthursouza", 
    author_email="arthur.souza@fecaf.com.br",
    description="Um SDK Python robusto e simples para gerenciar autenticação OAuth2 com a API do Brightspace (D2L).",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/dev-fecaf/d2l-auth-sdk",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        'requests',
        'python-dotenv',
        'PyJWT'
    ],
)
