from .d2l_auth import D2lAuthManager

__version__ = "0.1.0"