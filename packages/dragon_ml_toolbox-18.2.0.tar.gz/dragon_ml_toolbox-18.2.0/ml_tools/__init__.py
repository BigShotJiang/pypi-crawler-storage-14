from ._core._schema import FeatureSchema
