#!/usr/bin/env python
"""
Setup script for nnunetv2_cam.
"""

from setuptools import setup

setup()