# qsg/app/dashboard/dashboard.py

from __future__ import annotations

import dash_bootstrap_components as dbc
from dash import dcc, html

from qsg.app.dashboard.components.banner import BannerComponent
from qsg.app.dashboard.components.controls_kpi import ControlsComponent, KpiStrip
from qsg.app.dashboard.components.pie_chart import PieChartComponent
from qsg.app.dashboard.components.table import TableComponent

from qsg.app.dashboard.html import PageLayout
from qsg.app.dashboard.config import AppConfig
from qsg.app.dashboard.services.logs import LogLinker, register_log_routes
from qsg.app.dashboard.services.store import StoreService
from qsg.app.dashboard.library import get_import_warnings


class DashboardHost:
    """
    Wires together the Dash layout and back-end services for the dashboard.
    """

    def __init__(self, app, cfg: AppConfig):
        self.app = app
        self.cfg = cfg

        # Back-end services
        self.store = StoreService(
            cfg.store_backend,
            cfg.store_path,
            cfg.owner.name,
            cfg.default_mode or "live",
        )
        self.log_linker = LogLinker(cfg.log_root)

        # Components
        self.banner = BannerComponent()
        self.controls = ControlsComponent()
        self.kpis = KpiStrip(cfg.max_kpi_width)
        self.pies = PieChartComponent()
        self.table = TableComponent(self.log_linker, cfg.clipboard_fallback_open)

        # Any non-fatal import warnings from dataset / feature libraries
        self.import_warnings = get_import_warnings()

        # Log routes
        register_log_routes(app.server, self.log_linker)

        tabs = dcc.Tabs(
            id="main-tabs",
            value="all",
            children=[
                dcc.Tab(
                    label="All",
                    value="all",
                    style={"width": "20%", "textAlign": "center"},
                    selected_style={"width": "20%", "textAlign": "center"},
                ),
                dcc.Tab(
                    label="Data",
                    value="data",
                    style={"width": "20%", "textAlign": "center"},
                    selected_style={"width": "20%", "textAlign": "center"},
                ),
                dcc.Tab(
                    label="Features",
                    value="features",
                    style={"width": "20%", "textAlign": "center"},
                    selected_style={"width": "20%", "textAlign": "center"},
                ),
                dcc.Tab(
                    label="Alphas",
                    value="alphas",
                    style={"width": "20%", "textAlign": "center"},
                    selected_style={"width": "20%", "textAlign": "center"},
                ),
                dcc.Tab(
                    label="Strategies",
                    value="strategies",
                    style={"width": "20%", "textAlign": "center"},
                    selected_style={"width": "20%", "textAlign": "center"},
                ),
            ],
            className="mb-2",
        )

        page_layout = PageLayout(cfg, self.controls, self.kpis, self.pies)

        self.layout = html.Div(
            [
                dcc.Location(id="url", refresh=False),
                # NOTE: this is where we now pass the warnings
                self.banner.render(cfg.app_title, self.import_warnings),
                tabs,
                page_layout.build(),
                dcc.Store(id="table-page", data=0),
            ],
            className="app-root",
        )