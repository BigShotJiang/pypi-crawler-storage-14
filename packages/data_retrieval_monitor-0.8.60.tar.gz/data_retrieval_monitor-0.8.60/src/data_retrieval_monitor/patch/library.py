# qsg/app/dashboard/library.py

from __future__ import annotations

import json
import os
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from qsg.app.dashboard.constants import DATA_STAGES, TAB_IDS, status_order_for_tab
from qsg.app.dashboard.config import AppConfig
from qsg.app.dashboard.utils import utc_now_iso


# ---------------------------------------------------------------------
# Chunk helpers
# ---------------------------------------------------------------------


def _mk_chunks(
    statuses: List[str],
    base_dir: Path,
    dataset: str,
    bucket: str,
    k: int,
) -> List[dict]:
    """
    Create k synthetic chunks for (dataset, bucket), each with:
      - status
      - sid    : short human id
      - proc   : "process" URL (for the log linker)
      - log    : path to a tiny local log file
    """
    chunks: List[dict] = []
    for j in range(k):
        s = random.choice(statuses)
        log_dir = base_dir / dataset / bucket
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"{dataset}_{bucket}_{j}.log"
        log_path.write_text(
            f"{dataset} [{bucket}] chunk {j} status={s}\n",
            encoding="utf-8",
        )
        chunks.append(
            {
                "status": s,
                "sid": f"{bucket[:1].upper()}{j}",
                "proc": f"https://example.com/proc/{dataset}/{bucket}/{j}",
                "log": str(log_path),
            }
        )
    return chunks


def _maybe_save(save_dir: Optional[Path], fname: str, payload: dict) -> None:
    """
    Optionally store a JSON payload to disk (useful for debugging seed data).
    """
    if not save_dir:
        return
    save_dir.mkdir(parents=True, exist_ok=True)
    (save_dir / fname).write_text(
        json.dumps(payload, indent=2, sort_keys=True),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------
# Per-owner, per-tab payload builders
# ---------------------------------------------------------------------


def make_data_payload_for_owner(
    cfg: AppConfig,
    owner: str,
    num_items: int = 12,
) -> Tuple[List[dict], dict]:
    """
    Build synthetic DATA tab payload for one owner.

    Each item corresponds to a single dataset + stage, so the store will
    accumulate per-dataset, per-stage leaves as normal.
    """
    random.seed(hash(("data", owner)) & 0xFFFFFFFF)
    log_root = Path(cfg.log_root)
    items: List[dict] = []

    statuses = status_order_for_tab("data")
    owner_norm = (owner or cfg.owner.name).strip()

    for i in range(num_items):
        dataset_name = f"{owner_norm}-data-{i:03d}"
        # Create one row per stage for this dataset
        for stage in DATA_STAGES:
            k = random.randint(1, 4)
            chunks = _mk_chunks(statuses, log_root, dataset_name, stage, k)
            item = {
                "owner": owner_norm,
                "mode": "live",
                "dataset": dataset_name,
                "stage": stage,
                "status": random.choice(statuses),
                "counts": {},
                "chunks": chunks,
            }
            items.append(item)

    meta = {
        "env": cfg.environment_label,
        "ingested_at": utc_now_iso(),
    }
    return items, meta


def make_features_payload_for_owner(
    cfg: AppConfig,
    owner: str,
    num_items: int = 12,
) -> Tuple[List[dict], dict]:
    """
    Synthetic FEATURES tab payload: each 'dataset' is really a feature name.
    """
    random.seed(hash(("features", owner)) & 0xFFFFFFFF)
    log_root = Path(cfg.log_root)
    items: List[dict] = []

    statuses = status_order_for_tab("features")
    owner_norm = (owner or cfg.owner.name).strip()

    for i in range(num_items):
        fname = f"{owner_norm}-feature-{i:03d}"
        k = random.randint(1, 4)
        chunks = _mk_chunks(statuses, log_root, fname, "status", k)
        items.append(
            {
                "owner": owner_norm,
                "mode": "live",
                "dataset": fname,
                "stage": "status",
                "status": random.choice(statuses),
                "counts": {},
                "chunks": chunks,
            }
        )

    meta = {
        "env": cfg.environment_label,
        "ingested_at": utc_now_iso(),
    }
    return items, meta


def make_alphas_payload_for_owner(
    cfg: AppConfig,
    owner: str,
    num_items: int = 12,
) -> Tuple[List[dict], dict]:
    """
    Synthetic ALPHAS tab payload.
    """
    random.seed(hash(("alphas", owner)) & 0xFFFFFFFF)
    log_root = Path(cfg.log_root)
    items: List[dict] = []

    statuses = status_order_for_tab("alphas")
    owner_norm = (owner or cfg.owner.name).strip()

    for i in range(num_items):
        aname = f"{owner_norm}-alpha-{i:03d}"
        k = random.randint(1, 4)
        chunks = _mk_chunks(statuses, log_root, aname, "status", k)
        items.append(
            {
                "owner": owner_norm,
                "mode": "live",
                "dataset": aname,
                "stage": "status",
                "status": random.choice(statuses),
                "counts": {},
                "chunks": chunks,
            }
        )

    meta = {
        "env": cfg.environment_label,
        "ingested_at": utc_now_iso(),
    }
    return items, meta


def make_strategies_payload_for_owner(
    cfg: AppConfig,
    owner: str,
    num_items: int = 12,
) -> Tuple[List[dict], dict]:
    """
    Synthetic STRATEGIES tab payload.
    """
    random.seed(hash(("strategies", owner)) & 0xFFFFFFFF)
    log_root = Path(cfg.log_root)
    items: List[dict] = []

    statuses = status_order_for_tab("strategies")
    owner_norm = (owner or cfg.owner.name).strip()

    for i in range(num_items):
        sname = f"{owner_norm}-strategy-{i:03d}"
        k = random.randint(1, 4)
        chunks = _mk_chunks(statuses, log_root, sname, "status", k)
        items.append(
            {
                "owner": owner_norm,
                "mode": "live",
                "dataset": sname,
                "stage": "status",
                "status": random.choice(statuses),
                "counts": {},
                "chunks": chunks,
            }
        )

    meta = {
        "env": cfg.environment_label,
        "ingested_at": utc_now_iso(),
    }
    return items, meta


# ---------------------------------------------------------------------
# Combine per-owner payloads
# ---------------------------------------------------------------------


def make_payload_for_owner(
    cfg: AppConfig,
    owner: str,
    tabs: Optional[List[str]] = None,
    num_items: int = 12,
    save_dir: Optional[Path] = None,
) -> Dict[str, dict]:
    """
    Build snapshot+meta for the requested tabs for a single owner.

    Returned dict shape:
        {
          "tabs": {
             "data": {"snapshot": [...], "meta": {...}},
             "features": {...},
             ...
          }
        }
    """
    if tabs is None:
        tabs = list(TAB_IDS)

    tabs = [t for t in tabs if t in TAB_IDS]
    pack: Dict[str, dict] = {"tabs": {}}

    for t in tabs:
        if t == "data":
            items, meta = make_data_payload_for_owner(cfg, owner, num_items)
        elif t == "features":
            items, meta = make_features_payload_for_owner(cfg, owner, num_items)
        elif t == "alphas":
            items, meta = make_alphas_payload_for_owner(cfg, owner, num_items)
        else:
            items, meta = make_strategies_payload_for_owner(cfg, owner, num_items)

        pack["tabs"][t] = {"snapshot": items, "meta": meta}
        _maybe_save(save_dir, f"{owner}-{t}.json", {"snapshot": items, "meta": meta})

    return pack


def make_multi_owner_payload(
    cfg: AppConfig,
    owners: Optional[List[str]] = None,
    tabs: Optional[List[str]] = None,
    num_items: int = 12,
    save_dir: Optional[Path] = None,
) -> Dict[str, dict]:
    """
    Combine payloads across multiple owners for the given tabs.

    This is the shape that seed_all_tabs() expects.
    """
    if tabs is None:
        tabs = list(TAB_IDS)
    tabs = [t for t in tabs if t in TAB_IDS]

    if owners is None:
        # default synthetic owners
        owners = ["KHDNG", "KDMQ", "LDEM"]

    owner_labels = [o.strip() for o in owners]

    out: Dict[str, dict] = {"tabs": {}}

    for t in tabs:
        all_items: List[dict] = []
        meta = {
            "env": cfg.environment_label,
            "ingested_at": utc_now_iso(),
            "owner_labels": owner_labels,
        }
        for owner in owners:
            owner_pack = make_payload_for_owner(
                cfg, owner, tabs=[t], num_items=num_items, save_dir=save_dir
            )
            part = owner_pack["tabs"][t]
            all_items.extend(part.get("snapshot") or [])
        out["tabs"][t] = {"snapshot": all_items, "meta": meta}
        _maybe_save(save_dir, f"ALL-{t}.json", out["tabs"][t])

    return out


# ---------------------------------------------------------------------
# Seeder used by create_app()
# ---------------------------------------------------------------------


def seed_all_tabs(host, num_per_tab: int = 12) -> None:
    """
    Called by app.py on startup to populate the in-memory store with
    synthetic data for all tabs and several owners.

    Respects SEED_OWNERS env var if set, e.g.:
        export SEED_OWNERS="KHDNG,KDMQ,LDEM"
    """
    cfg: AppConfig = host.cfg  # DashboardHost stores cfg here

    cfg_owners = os.getenv("SEED_OWNERS") or ""
    if cfg_owners.strip():
        owners = [s.strip() for s in cfg_owners.split(",") if s.strip()]
    else:
        owners = ["KHDNG", "KDMQ", "LDEM"]

    combined = make_multi_owner_payload(
        cfg,
        owners=owners,
        tabs=list(TAB_IDS),
        num_items=num_per_tab,
        save_dir=None,
    )

    for t in TAB_IDS:
        tab_payload = combined["tabs"].get(t) or {"snapshot": [], "meta": {}}
        items = tab_payload.get("snapshot") or []
        meta = dict(tab_payload.get("meta") or {})
        host.store.apply_snapshot_with_meta_tab(t, items, meta)