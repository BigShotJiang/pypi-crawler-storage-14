from flask import request

@app.server.after_request
def add_security_headers(response):
    # Ensure charset=utf-8
    if response.mimetype == "text/html":
        response.headers["Content-Type"] = "text/html; charset=utf-8"

    # Cache control:
    # - HTML: no-store (so the main page always refreshes)
    # - Static assets: long cache with immutable
    if response.mimetype and response.mimetype.startswith("text/html"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    else:
        # static / other: let browser cache aggressively
        response.headers.setdefault(
            "Cache-Control",
            "public, max-age=31536000, immutable",
        )

    # Security headers
    response.headers["X-Content-Type-Options"] = "nosniff"

    # Use CSP frame-ancestors instead of X-Frame-Options
    csp = response.headers.get("Content-Security-Policy", "")
    if "frame-ancestors" not in csp:
        # basic example; tune for your deployment
        extra = "frame-ancestors 'none';"
        response.headers["Content-Security-Policy"] = (csp + " " + extra).strip()

    # Remove or simplify legacy / noisy headers
    for h in ("X-XSS-Protection", "X-Frame-Options", "Expires"):
        response.headers.pop(h, None)

    # Optional: simplify Server header
    if "Server" in response.headers:
        response.headers["Server"] = "dash-server"

    return response