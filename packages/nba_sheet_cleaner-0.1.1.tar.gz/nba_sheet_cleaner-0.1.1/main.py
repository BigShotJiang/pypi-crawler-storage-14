
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable, List, Optional

import pandas as pd
from openpyxl.styles import Alignment, Border, Font
from openpyxl.utils import get_column_letter

BASE_DIR = Path(__file__).parent
SUPPORTED_EXTENSIONS = {".xls", ".xlsx", ".xlsm"}

KEEP_COLUMNS = ["Name", "Team", "p", "3", "r", "a", "s", "b"]
NUMERIC_COLUMNS = ["p", "3", "r", "a", "s", "b"]
PRA_COMPONENTS = ["p", "r", "a"]
PRA_COLUMN = "PRA"
NAME_COLUMN_WIDTH = len("Giannis Antetokounmpo") + 2


def _ensure_numeric(df: pd.DataFrame, columns: Iterable[str]) -> None:
    for column in columns:
        df[column] = pd.to_numeric(df[column], errors="coerce").fillna(0)


def _ensure_string_column(df: pd.DataFrame, column: str) -> None:
    df[column] = df[column].fillna("").astype(str)


def _read_excel(sheet_path: Path) -> pd.DataFrame:
    engine = "openpyxl" if sheet_path.suffix.lower() in {".xlsx", ".xlsm"} else None
    try:
        return pd.read_excel(sheet_path, engine=engine)
    except ImportError as exc:  # pragma: no cover - dependency specific
        missing = "openpyxl" if engine == "openpyxl" else "xlrd"
        raise RuntimeError(
            f"Reading {sheet_path.name} requires the optional dependency '{missing}'. "
            f"Install it with 'pip install {missing}'."
        ) from exc


def process_sheet(sheet_path: Path, output_dir: Path) -> Optional[Path]:
    df = _read_excel(sheet_path)

    missing_columns = [column for column in KEEP_COLUMNS if column not in df.columns]
    if missing_columns:
        missing_str = ", ".join(missing_columns)
        print(f"Skipping {sheet_path.name}: missing required columns [{missing_str}]")
        return None

    df = df[KEEP_COLUMNS].copy()
    _ensure_string_column(df, "Name")
    _ensure_string_column(df, "Team")
    _ensure_numeric(df, NUMERIC_COLUMNS)

    pra_values = df[PRA_COMPONENTS].sum(axis=1)
    p_index = df.columns.get_loc("p")
    df.insert(p_index, PRA_COLUMN, pra_values)

    zero_mask = (df[PRA_COLUMN] == 0) | (df["p"] == 0)
    df = df.loc[~zero_mask].copy()

    df.sort_values(by=["Team", PRA_COLUMN], ascending=[True, False], inplace=True)

    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{sheet_path.stem}_cleaned{sheet_path.suffix}"
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
        worksheet = writer.sheets["Sheet1"]
        worksheet.column_dimensions["A"].width = NAME_COLUMN_WIDTH

        header_alignment = Alignment(horizontal="left")
        header_font = Font(bold=True)
        no_border = Border()
        for cell in worksheet[1]:
            cell.font = header_font
            cell.alignment = header_alignment
            cell.border = no_border

        pra_col_idx = df.columns.get_loc(PRA_COLUMN) + 1
        pra_column_letter = get_column_letter(pra_col_idx)
        pra_font = Font(bold=True)
        for row_idx in range(1, worksheet.max_row + 1):
            worksheet[f"{pra_column_letter}{row_idx}"].font = pra_font

    return output_path


def list_excel_files(directory: Path) -> List[Path]:
    return sorted(
        file
        for file in directory.glob("**/*")
        if (
            file.is_file()
            and file.suffix.lower() in SUPPORTED_EXTENSIONS
            and not file.stem.endswith("_cleaned")
        )
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Clean NBA projection sheets.")
    parser.add_argument(
        "path",
        nargs="?",
        help="Optional directory or Excel file to process instead of the default location.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.path:
        target_path = Path(args.path).expanduser()
    else:
        sheets_dir = Path.cwd() / "sheets"
        target_path = sheets_dir if sheets_dir.exists() else Path.cwd()

    if not target_path.exists():
        print(f"Provided path {target_path} does not exist.")
        return

    if target_path.is_file():
        if (
            target_path.suffix.lower() not in SUPPORTED_EXTENSIONS
            or target_path.stem.endswith("_cleaned")
        ):
            print(
                "Provided file must be an Excel file that does not already end with '_cleaned'."
            )
            return
        excel_files = [target_path]
        output_dir = target_path.parent / "sheets_cleaned"
    else:
        excel_files = list_excel_files(target_path)
        output_dir = target_path / "sheets_cleaned"

    if not excel_files:
        print(f"No Excel files found in {target_path}")
        return

    print(f"Processing {len(excel_files)} files...")
    for file_path in excel_files:
        output_path = process_sheet(file_path, output_dir)
        if output_path:
            try:
                relative_path = output_path.relative_to(BASE_DIR)
            except ValueError:
                relative_path = output_path
            print(f"Saved cleaned sheet to {relative_path}")


if __name__ == "__main__":
    main()
