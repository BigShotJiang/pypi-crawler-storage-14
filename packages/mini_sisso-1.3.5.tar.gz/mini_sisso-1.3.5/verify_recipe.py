import numpy as np
import pandas as pd
from mini_sisso.model import MiniSisso, RUST_AVAILABLE
print(f"RUST_AVAILABLE: {RUST_AVAILABLE}")
from mini_sisso.recipe import FeatureRecipe

# Create dummy data
np.random.seed(42)
X = pd.DataFrame({'a': np.random.rand(10), 'b': np.random.rand(10)})
# y = 2*a + sin(b)
y = X['a'] * 2 + np.sin(X['b'])

# Fit model
# Use rust backend (default if available)
ms = MiniSisso(n_expansion=1, operators=['+', 'sin'], so_method='exhaustive', selection_params={'n_term': 2, 'n_sis_features': 20})
ms.fit(X, y)

# Check if recipes are populated
print("Recipes:", ms.best_model_recipes_)
if ms.best_model_recipes_:
    print("First recipe:", ms.best_model_recipes_[0])
    print("Type:", type(ms.best_model_recipes_[0]))
    # Check if it is FeatureRecipe
    if isinstance(ms.best_model_recipes_[0], FeatureRecipe):
        print("Verification Successful! Recipe is FeatureRecipe object.")
    else:
        print(f"Verification Failed! Recipe is {type(ms.best_model_recipes_[0])}")
else:
    print("No recipes found.")
