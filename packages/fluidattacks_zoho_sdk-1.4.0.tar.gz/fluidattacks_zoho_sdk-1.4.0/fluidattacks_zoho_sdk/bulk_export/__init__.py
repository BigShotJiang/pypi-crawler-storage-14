from __future__ import annotations

from dataclasses import dataclass

from fluidattacks_zoho_sdk._http_client import ClientFactory, HttpJsonClient
from fluidattacks_zoho_sdk.auth import Credentials
from fluidattacks_zoho_sdk.ids import OrgId

from . import _client
from .core import BulkClient, BulkEndpoint, FileName, ModuleName


def _from_client(client: HttpJsonClient) -> BulkClient:
    return BulkClient(
        lambda t, m, i: _client.create_bulk_export(client, t, m, i),
        lambda token, obj: _client.get_status_bulk_export(client, token, obj),
        lambda t, b, f: _client.download_bulk(client, t, b, f),
        lambda t, m, e, f: _client.fetch_bulk(client, t, m, e, f),
    )


@dataclass(frozen=True)
class BulkApiFactory:
    @staticmethod
    def new(creds: Credentials, org_id: OrgId) -> BulkClient:
        return _from_client(ClientFactory.new(creds, org_id))


__all__ = ["BulkApiFactory", "BulkClient", "BulkEndpoint", "FileName", "ModuleName"]
