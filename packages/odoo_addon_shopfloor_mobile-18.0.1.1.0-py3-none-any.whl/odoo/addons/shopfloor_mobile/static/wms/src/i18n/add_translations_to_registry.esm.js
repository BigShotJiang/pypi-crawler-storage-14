import {translation_registry} from "/shopfloor_mobile_base/static/src/services/translation_registry.esm.js";

translation_registry.load("fr-FR", "/shopfloor_mobile/static/wms/src/i18n/fr.json");
translation_registry.load("en-US", "/shopfloor_mobile/static/wms/src/i18n/en.json");
