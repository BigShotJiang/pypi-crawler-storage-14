# Zez: The Zero-Effort Visualization Kit for Python



**Zez** (pronounced "Zez") is a lightweight, zero-effort wrapper around **Matplotlib** and **Pandas**, designed to make generating common, high-quality data visualizations quick and painless. If you need a standard Bar, Pie, Line, Scatter, or Histogram instantly, **Zez** handles all the setup, labeling, and basic formatting for you.

---

## 🚀 Key Features

* **Zero Boilerplate:** Quickly generate common charts with minimal code.
* **Built on Standards:** Leveraging the power and flexibility of Matplotlib.
* **Clean Defaults:** Provides sensible defaults for titles, labels, colors, and annotations.
* **Easy Output:** Built-in helper to effortlessly save charts to disk or display them.

---

## 💾 Installation

Since this is a custom package, you would typically install it via a **Git repository** or a private index if it's not on PyPI yet.

### Prerequisites

You need **Python 3.6+** and the core libraries:

* `pandas`
* `matplotlib`
* `numpy`

### Via PyPI (Once published)

```bash
pip install zez

```

### How to Import
Use this to import Zez on your code:

```python
import zez

```

## 📚 Usage Examples

```python

import zez

chart = zez.chart

chart.Bar(
    chart_title='Project Status: Q4 Completion Rate',
    alignment='horizontal',
    categories_in_order=['Project Alpha', 'Project Beta', 'Project Gamma'],
    amounts_in_order=[95, 80, 55],
    category_label='Project Name',
    amount_label='Completion (%)',
    colors_in_order=['green', 'blue', 'orange']
)

# 2. Pie Chart Example: Budget Allocation
# ----------------------------------------------------------------------
chart.Pie(
    chart_title='Department Budget Allocation',
    amounts_in_order=[45000, 30000, 15000, 10000],
    categories_in_order=['Marketing', 'Development', 'Admin', 'Support'],
    colors_in_order=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'],
    split=[0, 0.1, 0, 0], # Explode the Development slice
    save_as='budget_pie.png',
    show=False
)

# 3. Line Chart Example: Stock Price Trend (Multiple Lines)
# ----------------------------------------------------------------------
x_days = list(range(1, 11))
stock_a = [50, 52, 51, 55, 60, 58, 62, 65, 64, 70]
stock_b = [40, 41, 45, 43, 48, 50, 53, 52, 55, 59]

line_data = [
    {'y_data': stock_a, 'line_color': 'green', 'marker_style': 'o'},
    {'y_data': stock_b, 'line_color': 'red', 'marker_style': 'x'}
]

chart.Line(
    chart_title='Stock Price Comparison Over 10 Days',
    x_data=x_days,
    y_data_sets=line_data,
    data_labels=['Stock A', 'Stock B'],
    x_label='Trading Day',
    y_label='Price ($)',
)

# 4. Scatter Plot Example: Correlation
# ----------------------------------------------------------------------
x_hours = [1, 2, 3, 4, 5, 6, 7, 8]
y_score = [55, 60, 68, 75, 80, 85, 90, 95]

chart.Scatter(
    chart_title='Study Hours vs. Exam Score',
    x_data=x_hours,
    y_data=y_score,
    x_label='Hours Studied',
    y_label='Exam Score',
    marker_color='purple',
    marker_style='D', # Diamond marker
    marker_size=150,
    save_as='score_correlation.jpg'
)

print("\n--- ZEZ Demonstrations Finished ---")

```