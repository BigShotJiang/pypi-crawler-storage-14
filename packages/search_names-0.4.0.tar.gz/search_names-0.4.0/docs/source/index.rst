.. search-names documentation master file, created by
   sphinx-quickstart on Sat Jan  2 22:26:48 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to search-names's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   search_names

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
