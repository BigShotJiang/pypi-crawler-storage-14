"""
OpenAI-Compatible Provider

A unified provider for all OpenAI-compatible APIs including:
- DeepSeek
- xAI (Grok)
- Ollama
- Groq
- Together AI
- Fireworks AI
- Mistral AI

Principal Investigator: Bo Shang
Framework: erosolar-cli

Includes hardened error handling with retry logic for:
- Network failures (premature close, connection reset)
- Stream errors (gunzip, decompression failures)
- Rate limiting with exponential backoff
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
from typing import Any, Dict, List, Optional, AsyncIterator
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# ============================================================================
# Error Recovery Constants
# ============================================================================

TRANSIENT_ERROR_PATTERNS = [
    "premature close",
    "premature end",
    "premature eof",
    "unexpected end",
    "unexpected eof",
    "aborted",
    "fetcherror",
    "fetch error",
    "invalid response body",
    "incomplete read",
    "gunzip",
    "gzip",
    "decompress",
    "zlib",
    "econnreset",
    "econnrefused",
    "enotfound",
    "epipe",
    "socket",
    "network",
    "timeout",
    "timed out",
    "rate limit",
    "rate_limit",
    "429",
    "500",
    "502",
    "503",
    "504",
    "remotedisconnected",
    "remoteprotocolerror",
    "readtimeout",
    "connecttimeout",
]


def _is_transient_error(error: Exception) -> bool:
    """Check if an error is transient and should be retried."""
    message = str(error).lower()
    error_type = type(error).__name__.lower()
    all_text = f"{message} {error_type}"

    if any(pattern in all_text for pattern in TRANSIENT_ERROR_PATTERNS):
        return True

    # Check for common network error base classes
    error_bases = [base.__name__.lower() for base in type(error).__mro__]
    network_bases = ["connectionerror", "timeouterror", "oserror", "ioerror", "httpstatuserror"]
    if any(base in error_bases for base in network_bases):
        return True

    # Check for httpx-specific errors
    if "httpx" in error_type or "http" in error_type:
        status_code = getattr(error, "status_code", None)
        if status_code and status_code >= 500:
            return True

    # Check cause chain
    cause = getattr(error, "__cause__", None) or getattr(error, "__context__", None)
    if cause and isinstance(cause, Exception):
        return _is_transient_error(cause)

    return False


def _get_backoff_delay(attempt: int, base_delay: float = 1.0, max_delay: float = 30.0) -> float:
    """Calculate exponential backoff delay with jitter."""
    delay = min(base_delay * (2 ** attempt), max_delay)
    jitter = delay * 0.1 * random.random()
    return delay + jitter


async def _execute_with_retry(
    operation,
    operation_name: str,
    max_retries: int = 3,
    provider_id: str = "openai_compatible",
):
    """Execute an async operation with retry logic for transient errors."""
    last_error: Optional[Exception] = None

    for attempt in range(max_retries + 1):
        try:
            return await operation()
        except Exception as e:
            last_error = e

            if _is_transient_error(e) and attempt < max_retries:
                delay = _get_backoff_delay(attempt)
                logger.warning(
                    f"[{provider_id}] {operation_name} failed (attempt {attempt + 1}/{max_retries + 1}): "
                    f"{e}. Retrying in {delay:.1f}s..."
                )
                await asyncio.sleep(delay)
                continue

            raise

    raise last_error  # type: ignore

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False


def _safe_parse_arguments(arguments: Any, context: str = "") -> dict:
    """
    Safely parse tool call arguments, handling malformed JSON gracefully.

    Args:
        arguments: Raw arguments (str, dict, or other)
        context: Description of where parsing is happening (for logging)

    Returns:
        Parsed dict, or empty dict if parsing fails
    """
    if isinstance(arguments, dict):
        return arguments
    if not isinstance(arguments, str):
        return {}

    if not arguments.strip():
        return {}

    try:
        parsed = json.loads(arguments)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse tool arguments{' in ' + context if context else ''}: {e}")
        # Try to salvage partial JSON by attempting common fixes
        try:
            fixed = arguments.rstrip()
            if not fixed.endswith('}'):
                fixed += '}'
            parsed = json.loads(fixed)
            logger.info(f"Recovered partial JSON by adding closing brace")
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            pass

        # Return empty dict as fallback
        return {}


@dataclass
class OpenAICompatibleOptions:
    """Options for OpenAI-compatible providers."""
    provider_id: str
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    max_tokens: int = 4096
    temperature: float = 0.0
    timeout: int = 120


class OpenAICompatibleProvider:
    """
    A unified provider for OpenAI-compatible APIs.

    Works with any API that follows the OpenAI chat completions format.
    """

    def __init__(self, options: OpenAICompatibleOptions):
        if not HAS_HTTPX:
            raise ImportError("httpx is required for OpenAI-compatible providers. Install with: pip install httpx")

        self.options = options
        self._id = options.provider_id
        self._model = options.model
        self._base_url = options.base_url or "https://api.openai.com/v1"
        self._api_key = options.api_key
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def id(self) -> str:
        """Provider identifier."""
        return self._id

    @property
    def model(self) -> str:
        """Model identifier."""
        return self._model

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None:
            headers = {"Content-Type": "application/json"}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"

            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=headers,
                timeout=self.options.timeout,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _convert_messages(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Convert messages to OpenAI format."""
        converted = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "tool":
                converted.append({
                    "role": "tool",
                    "tool_call_id": msg.get("tool_call_id", ""),
                    "content": content,
                })
            elif role == "assistant" and msg.get("tool_calls"):
                converted.append({
                    "role": "assistant",
                    "content": content or None,
                    "tool_calls": [
                        {
                            "id": tc.get("id", ""),
                            "type": "function",
                            "function": {
                                "name": tc.get("name", ""),
                                "arguments": json.dumps(tc.get("arguments", {})),
                            },
                        }
                        for tc in msg["tool_calls"]
                    ],
                })
            else:
                converted.append({
                    "role": role,
                    "content": content,
                })

        return converted

    def _convert_tools(self, tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Convert tools to OpenAI format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.get("name", ""),
                    "description": tool.get("description", ""),
                    "parameters": tool.get("parameters", {}),
                },
            }
            for tool in tools
        ]

    async def generate(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Generate a response with retry logic.

        Args:
            messages: Conversation messages
            tools: Optional tool definitions

        Returns:
            Response with content and/or tool calls
        """
        async def _do_generate():
            client = self._get_client()

            payload: Dict[str, Any] = {
                "model": self._model,
                "messages": self._convert_messages(messages),
                "max_tokens": self.options.max_tokens,
                "temperature": self.options.temperature,
            }

            if tools:
                payload["tools"] = self._convert_tools(tools)

            response = await client.post("/chat/completions", json=payload)
            response.raise_for_status()
            data = response.json()

            choice = data.get("choices", [{}])[0]
            message = choice.get("message", {})
            usage = data.get("usage", {})

            result: Dict[str, Any] = {
                "usage": {
                    "input_tokens": usage.get("prompt_tokens", 0),
                    "output_tokens": usage.get("completion_tokens", 0),
                },
            }

            if message.get("tool_calls"):
                result["type"] = "tool_calls"
                # Safely parse tool calls with error recovery
                tool_calls = []
                for tc in message["tool_calls"]:
                    try:
                        tool_calls.append({
                            "id": tc.get("id", ""),
                            "name": tc.get("function", {}).get("name", ""),
                            "arguments": _safe_parse_arguments(tc.get("function", {}).get("arguments", "{}"), "openai_compatible"),
                        })
                    except Exception as e:
                        logger.warning(f"[{self._id}] Failed to parse tool call, skipping: {e}")
                result["tool_calls"] = tool_calls
                if message.get("content"):
                    result["content"] = message["content"]
            else:
                result["type"] = "message"
                result["content"] = message.get("content", "")

            return result

        return await _execute_with_retry(_do_generate, "generate", max_retries=3, provider_id=self._id)

    async def generate_stream(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Generate a streaming response.

        Args:
            messages: Conversation messages
            tools: Optional tool definitions

        Yields:
            Stream chunks with content deltas or tool calls
        """
        client = self._get_client()

        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": self._convert_messages(messages),
            "max_tokens": self.options.max_tokens,
            "temperature": self.options.temperature,
            "stream": True,
        }

        if tools:
            payload["tools"] = self._convert_tools(tools)

        async with client.stream("POST", "/chat/completions", json=payload) as response:
            response.raise_for_status()

            async for line in response.aiter_lines():
                if not line or not line.startswith("data: "):
                    continue

                data_str = line[6:]  # Remove "data: " prefix
                if data_str == "[DONE]":
                    break

                try:
                    data = json.loads(data_str)
                    choice = data.get("choices", [{}])[0]
                    delta = choice.get("delta", {})

                    if delta.get("content"):
                        yield {
                            "type": "content",
                            "content": delta["content"],
                        }
                    elif delta.get("tool_calls"):
                        for tc in delta["tool_calls"]:
                            yield {
                                "type": "tool_call",
                                "index": tc.get("index", 0),
                                "id": tc.get("id"),
                                "name": tc.get("function", {}).get("name"),
                                "arguments": tc.get("function", {}).get("arguments"),
                            }

                except json.JSONDecodeError:
                    continue
