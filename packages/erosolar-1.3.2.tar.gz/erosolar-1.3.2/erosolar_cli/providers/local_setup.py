"""
Automated Local LLM Setup

Handles automatic installation, configuration, and management of local LLMs.
Supports:
- Installing Ollama (automatic)
- Downloading models (automatic)
- Starting/stopping servers
- Health checks and monitoring

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional, Tuple
import aiohttp


@dataclass
class SetupProgress:
    """Progress update for setup operations."""
    step: str
    progress: float  # 0.0 to 1.0
    message: str
    is_error: bool = False


# Recommended models by use case
RECOMMENDED_MODELS = {
    "coding": [
        ("qwen2.5-coder:32b", "Qwen 32B - Best open-source coding model"),
        ("qwen2.5-coder:14b", "Qwen 14B coding model"),
        ("qwen2.5-coder:7b", "Qwen 7B - Fast coding"),
        ("deepseek-coder-v2:16b", "DeepSeek Coder V2 16B"),
        ("deepseek-coder:33b", "DeepSeek Coder 33B"),
        ("deepseek-coder:6.7b", "DeepSeek Coder 6.7B - Lightweight"),
        ("codellama:70b", "Meta CodeLlama 70B"),
        ("codellama:34b", "Meta CodeLlama 34B"),
        ("codellama:7b", "Meta CodeLlama 7B"),
    ],
    "general": [
        ("qwen2.5:72b", "Qwen 2.5 72B - Alibaba's flagship"),
        ("qwen2.5:32b", "Qwen 2.5 32B"),
        ("qwen2.5:14b", "Qwen 2.5 14B"),
        ("qwen2.5:7b", "Qwen 2.5 7B"),
        ("llama3.1:70b", "Meta Llama 3.1 70B"),
        ("llama3.1:8b", "Meta Llama 3.1 8B - Balanced"),
        ("deepseek-v2.5", "DeepSeek V2.5 - 236B MoE"),
        ("deepseek-llm:67b", "DeepSeek LLM 67B"),
        ("yi:34b", "Yi 34B - 01.AI's model"),
        ("mistral-large", "Mistral Large"),
        ("mixtral:8x22b", "Mixtral 8x22B MoE"),
    ],
    "chinese": [
        ("qwen2.5:72b", "Qwen 2.5 72B - Best for Chinese"),
        ("qwen2.5:32b", "Qwen 2.5 32B"),
        ("yi:34b", "Yi 34B - 01.AI"),
        ("deepseek-llm:67b", "DeepSeek 67B"),
        ("glm4:9b", "GLM-4 9B - Zhipu AI"),
    ],
    "reasoning": [
        ("deepseek-r1:70b", "DeepSeek R1 70B - Reasoning model"),
        ("deepseek-r1:32b", "DeepSeek R1 32B"),
        ("deepseek-r1:14b", "DeepSeek R1 14B"),
        ("deepseek-r1:7b", "DeepSeek R1 7B"),
        ("qwq:32b", "QwQ 32B - Qwen's reasoning model"),
    ],
    "small": [
        ("llama3.2:3b", "Llama 3.2 3B - Fast"),
        ("qwen2.5:3b", "Qwen 2.5 3B"),
        ("phi3:mini", "Microsoft Phi-3 Mini"),
        ("gemma2:2b", "Google Gemma 2 2B"),
        ("deepseek-coder:1.3b", "DeepSeek Coder 1.3B"),
    ],
    "large": [
        ("qwen2.5:72b", "Qwen 72B - needs 48GB+ VRAM"),
        ("llama3.1:70b", "Llama 70B - needs 48GB+ VRAM"),
        ("deepseek-v2.5", "DeepSeek V2.5 236B MoE"),
        ("mixtral:8x22b", "Mixtral 8x22B MoE"),
        ("codellama:70b", "CodeLlama 70B"),
        ("deepseek-coder:33b", "DeepSeek Coder 33B"),
        ("yi:34b", "Yi 34B"),
    ],
}


def get_system_info() -> dict:
    """Get system information for setup decisions."""
    import psutil

    info = {
        "os": platform.system().lower(),
        "arch": platform.machine().lower(),
        "ram_gb": psutil.virtual_memory().total / (1024**3),
        "cpu_count": psutil.cpu_count(),
    }

    # Check for GPU
    info["has_nvidia"] = shutil.which("nvidia-smi") is not None
    info["has_metal"] = info["os"] == "darwin" and info["arch"] == "arm64"

    return info


def recommend_model(system_info: dict, use_case: str = "coding") -> Tuple[str, str]:
    """
    Recommend a model based on system specs and use case.

    Args:
        system_info: System information dict
        use_case: One of "coding", "general", "reasoning", "chinese", "small", "large"

    Returns:
        Tuple of (model_name, reason)
    """
    ram = system_info.get("ram_gb", 8)
    has_gpu = system_info.get("has_nvidia") or system_info.get("has_metal")

    # For coding tasks (default)
    if use_case == "coding":
        if ram >= 64 and has_gpu:
            return "qwen2.5-coder:32b", "High-end system - Qwen 32B Coder (best coding model)"
        elif ram >= 48:
            return "deepseek-coder:33b", "Strong system - DeepSeek Coder 33B"
        elif ram >= 32:
            return "qwen2.5-coder:14b", "Good system - Qwen 14B Coder"
        elif ram >= 16:
            return "qwen2.5-coder:7b", "Moderate system - Qwen 7B Coder"
        elif ram >= 8:
            return "deepseek-coder:6.7b", "Standard system - DeepSeek Coder 6.7B"
        else:
            return "deepseek-coder:1.3b", "Limited RAM - DeepSeek Coder 1.3B"

    elif use_case == "reasoning":
        if ram >= 64 and has_gpu:
            return "deepseek-r1:70b", "High-end - DeepSeek R1 70B reasoning"
        elif ram >= 48:
            return "deepseek-r1:32b", "Strong system - DeepSeek R1 32B"
        elif ram >= 32:
            return "qwq:32b", "Good system - QwQ 32B reasoning"
        elif ram >= 16:
            return "deepseek-r1:14b", "Moderate - DeepSeek R1 14B"
        else:
            return "deepseek-r1:7b", "Limited - DeepSeek R1 7B"

    elif use_case == "chinese":
        if ram >= 64:
            return "qwen2.5:72b", "High-end - Qwen 72B (best for Chinese)"
        elif ram >= 48:
            return "qwen2.5:32b", "Strong - Qwen 32B"
        elif ram >= 32:
            return "yi:34b", "Good - Yi 34B"
        elif ram >= 16:
            return "qwen2.5:14b", "Moderate - Qwen 14B"
        else:
            return "qwen2.5:7b", "Standard - Qwen 7B"

    elif use_case == "large":
        if ram >= 96:
            return "qwen2.5:72b", "Enterprise - Qwen 72B flagship"
        elif ram >= 64:
            return "llama3.1:70b", "High-end - Llama 3.1 70B"
        elif ram >= 48:
            return "mixtral:8x22b", "Strong - Mixtral 8x22B MoE"
        else:
            return "yi:34b", "Yi 34B (minimum for large models)"

    elif use_case == "small":
        if ram >= 8:
            return "llama3.2:3b", "Fast and capable - Llama 3.2 3B"
        else:
            return "phi3:mini", "Ultra-lightweight - Phi-3 Mini"

    # General/default
    else:
        if ram >= 64 and has_gpu:
            return "qwen2.5:72b", "High-end system - Qwen 72B"
        elif ram >= 48:
            return "llama3.1:70b", "Strong system - Llama 3.1 70B"
        elif ram >= 32:
            return "qwen2.5:32b", "Good system - Qwen 32B"
        elif ram >= 16:
            return "llama3.1:8b", "Standard system - Llama 3.1 8B"
        elif ram >= 8:
            return "qwen2.5:7b", "Moderate - Qwen 7B"
        else:
            return "llama3.2:3b", "Limited RAM - Llama 3.2 3B"


async def check_ollama_installed() -> Tuple[bool, Optional[str]]:
    """Check if Ollama is installed and get version."""
    ollama_path = shutil.which("ollama")
    if not ollama_path:
        return False, None

    try:
        result = subprocess.run(
            ["ollama", "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            return True, version
    except Exception:
        pass

    return True, "unknown"


async def check_ollama_running() -> bool:
    """Check if Ollama server is running."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "http://localhost:11434/api/tags",
                timeout=aiohttp.ClientTimeout(total=2)
            ) as resp:
                return resp.status == 200
    except Exception:
        return False


async def install_ollama(progress_callback: Optional[Callable[[SetupProgress], None]] = None) -> bool:
    """
    Install Ollama automatically.

    Args:
        progress_callback: Optional callback for progress updates

    Returns:
        True if installation successful
    """
    def report(step: str, prog: float, msg: str, error: bool = False):
        if progress_callback:
            progress_callback(SetupProgress(step, prog, msg, error))

    system = platform.system().lower()

    report("install", 0.1, "Checking system...")

    if system == "darwin":  # macOS
        report("install", 0.2, "Downloading Ollama for macOS...")

        # Check if brew is available
        if shutil.which("brew"):
            try:
                result = subprocess.run(
                    ["brew", "install", "ollama"],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if result.returncode == 0:
                    report("install", 1.0, "Ollama installed via Homebrew")
                    return True
            except Exception as e:
                report("install", 0.3, f"Homebrew install failed: {e}, trying direct download...")

        # Direct download for macOS
        try:
            result = subprocess.run(
                ["curl", "-fsSL", "https://ollama.com/install.sh", "-o", "/tmp/ollama_install.sh"],
                capture_output=True,
                timeout=60
            )
            if result.returncode == 0:
                report("install", 0.5, "Running installer...")
                result = subprocess.run(
                    ["sh", "/tmp/ollama_install.sh"],
                    capture_output=True,
                    timeout=300
                )
                if result.returncode == 0:
                    report("install", 1.0, "Ollama installed successfully")
                    return True
        except Exception as e:
            report("install", 0.0, f"Installation failed: {e}", error=True)
            return False

    elif system == "linux":
        report("install", 0.2, "Installing Ollama on Linux...")

        try:
            # Use the official install script
            result = subprocess.run(
                ["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"],
                capture_output=True,
                text=True,
                timeout=300
            )
            if result.returncode == 0:
                report("install", 1.0, "Ollama installed successfully")
                return True
            else:
                report("install", 0.0, f"Installation failed: {result.stderr}", error=True)
                return False
        except Exception as e:
            report("install", 0.0, f"Installation failed: {e}", error=True)
            return False

    elif system == "windows":
        report("install", 0.0, "Windows: Please download Ollama from https://ollama.com/download", error=True)
        return False

    return False


async def start_ollama_server(progress_callback: Optional[Callable[[SetupProgress], None]] = None) -> bool:
    """Start Ollama server if not running."""
    def report(step: str, prog: float, msg: str, error: bool = False):
        if progress_callback:
            progress_callback(SetupProgress(step, prog, msg, error))

    if await check_ollama_running():
        report("start", 1.0, "Ollama server already running")
        return True

    report("start", 0.2, "Starting Ollama server...")

    try:
        # Start ollama serve in background
        process = subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )

        # Wait for server to be ready
        for i in range(30):
            await asyncio.sleep(0.5)
            if await check_ollama_running():
                report("start", 1.0, "Ollama server started")
                return True
            report("start", 0.2 + (i * 0.02), f"Waiting for server... ({i+1}s)")

        report("start", 0.0, "Server failed to start in time", error=True)
        return False

    except Exception as e:
        report("start", 0.0, f"Failed to start server: {e}", error=True)
        return False


async def download_model(
    model_name: str,
    progress_callback: Optional[Callable[[SetupProgress], None]] = None
) -> bool:
    """
    Download a model using Ollama.

    Args:
        model_name: Model name (e.g., "llama3.1:8b")
        progress_callback: Optional callback for progress updates

    Returns:
        True if download successful
    """
    def report(step: str, prog: float, msg: str, error: bool = False):
        if progress_callback:
            progress_callback(SetupProgress(step, prog, msg, error))

    report("download", 0.1, f"Pulling {model_name}...")

    try:
        process = subprocess.Popen(
            ["ollama", "pull", model_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )

        # Parse progress from output
        for line in iter(process.stdout.readline, ""):
            line = line.strip()
            if line:
                # Try to parse percentage from ollama output
                if "%" in line:
                    try:
                        pct = float(line.split("%")[0].split()[-1]) / 100
                        report("download", 0.1 + pct * 0.8, line)
                    except (ValueError, IndexError):
                        report("download", 0.5, line)
                else:
                    report("download", 0.5, line)

        process.wait()

        if process.returncode == 0:
            report("download", 1.0, f"Model {model_name} downloaded successfully")
            return True
        else:
            report("download", 0.0, f"Download failed with code {process.returncode}", error=True)
            return False

    except Exception as e:
        report("download", 0.0, f"Download failed: {e}", error=True)
        return False


async def list_local_models() -> List[str]:
    """List models available locally."""
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")[1:]  # Skip header
            models = []
            for line in lines:
                if line.strip():
                    model_name = line.split()[0]
                    models.append(model_name)
            return models
    except Exception:
        pass
    return []


async def full_setup(
    model: Optional[str] = None,
    auto_select: bool = True,
    progress_callback: Optional[Callable[[SetupProgress], None]] = None
) -> Tuple[bool, str]:
    """
    Perform full automatic setup of local LLM.

    Args:
        model: Specific model to install, or None for auto-select
        auto_select: If True and model is None, auto-select based on system
        progress_callback: Optional callback for progress updates

    Returns:
        Tuple of (success, message)
    """
    def report(step: str, prog: float, msg: str, error: bool = False):
        if progress_callback:
            progress_callback(SetupProgress(step, prog, msg, error))

    report("setup", 0.0, "Starting automatic local LLM setup...")

    # Step 1: Check/install Ollama
    report("setup", 0.1, "Checking Ollama installation...")
    installed, version = await check_ollama_installed()

    if not installed:
        report("setup", 0.15, "Ollama not found, installing...")
        if not await install_ollama(progress_callback):
            return False, "Failed to install Ollama"
    else:
        report("setup", 0.2, f"Ollama {version} found")

    # Step 2: Start server if needed
    report("setup", 0.3, "Checking Ollama server...")
    if not await start_ollama_server(progress_callback):
        return False, "Failed to start Ollama server"

    # Step 3: Select model
    if model is None and auto_select:
        system_info = get_system_info()
        model, reason = recommend_model(system_info)
        report("setup", 0.4, f"Auto-selected model: {model} ({reason})")

    if model is None:
        model = "llama3.1:8b"  # Fallback default

    # Step 4: Check if model is already downloaded
    existing_models = await list_local_models()
    if model in existing_models or model.split(":")[0] in [m.split(":")[0] for m in existing_models]:
        report("setup", 0.9, f"Model {model} already available")
    else:
        # Download model
        report("setup", 0.5, f"Downloading model {model}...")
        if not await download_model(model, progress_callback):
            return False, f"Failed to download model {model}"

    report("setup", 1.0, f"Setup complete! Using {model}")
    return True, f"Local LLM ready: {model}\nUse '/provider ollama' to switch"


def get_setup_status() -> dict:
    """Get current setup status."""
    status = {
        "ollama_installed": False,
        "ollama_version": None,
        "ollama_running": False,
        "models": [],
        "system": get_system_info(),
    }

    try:
        # Check installation
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        installed, version = loop.run_until_complete(check_ollama_installed())
        status["ollama_installed"] = installed
        status["ollama_version"] = version

        if installed:
            status["ollama_running"] = loop.run_until_complete(check_ollama_running())
            if status["ollama_running"]:
                status["models"] = loop.run_until_complete(list_local_models())

        loop.close()
    except Exception:
        pass

    return status


def format_setup_status(status: dict) -> str:
    """Format setup status for display."""
    lines = ["\n╔══════════════════════════════════════════════════════════════╗"]
    lines.append("║              LOCAL LLM STATUS                                ║")
    lines.append("╠══════════════════════════════════════════════════════════════╣")

    # System info
    sys_info = status.get("system", {})
    ram = sys_info.get("ram_gb", 0)
    gpu = "NVIDIA GPU" if sys_info.get("has_nvidia") else ("Apple Silicon" if sys_info.get("has_metal") else "CPU only")
    lines.append(f"║  System: {ram:.0f}GB RAM, {gpu:<38}║")

    # Ollama status
    if status["ollama_installed"]:
        version = status.get("ollama_version", "unknown")
        lines.append(f"║  Ollama: ✓ Installed (v{version}){' '*(37-len(str(version)))}║")

        if status["ollama_running"]:
            lines.append("║  Server: ✓ Running                                           ║")
        else:
            lines.append("║  Server: ○ Not running                                       ║")

        models = status.get("models", [])
        if models:
            lines.append(f"║  Models: {len(models)} downloaded{' '*(40-len(str(len(models))))}║")
            for m in models[:5]:
                lines.append(f"║    • {m:<54}║")
            if len(models) > 5:
                lines.append(f"║    ... and {len(models)-5} more{' '*(43-len(str(len(models)-5)))}║")
        else:
            lines.append("║  Models: None downloaded                                     ║")
    else:
        lines.append("║  Ollama: ○ Not installed                                     ║")
        lines.append("║                                                              ║")
        lines.append("║  Run '/local install' to set up automatically               ║")

    lines.append("╚══════════════════════════════════════════════════════════════╝")
    return "\n".join(lines)
