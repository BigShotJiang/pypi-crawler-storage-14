"""
Local/Air-Gapped Provider Support

Enables running erosolar with local LLM servers for:
- Complete privacy (no data leaves your network)
- Air-gapped environments (no internet required)
- Custom model deployments

Supported local providers:
- Ollama: Easy-to-use local LLM runner
- LM Studio: GUI-based local model serving
- vLLM: High-throughput production serving
- TGI: HuggingFace Text Generation Inference
- llama.cpp: Lightweight CPU/GPU inference
- LocalAI: OpenAI-compatible local server
- Custom: Any OpenAI-compatible endpoint

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import aiohttp


@dataclass
class LocalProviderStatus:
    """Status of a local provider."""
    provider_id: str
    label: str
    base_url: str
    is_running: bool
    available_models: List[str]
    error: Optional[str] = None


# Default ports for local providers
LOCAL_PROVIDER_PORTS = {
    "ollama": 11434,
    "lmstudio": 1234,
    "vllm": 8000,
    "tgi": 8080,
    "llamacpp": 8080,
    "localai": 8080,
}

# Default base URLs
LOCAL_PROVIDER_URLS = {
    "ollama": "http://localhost:11434/v1",
    "lmstudio": "http://localhost:1234/v1",
    "vllm": "http://localhost:8000/v1",
    "tgi": "http://localhost:8080/v1",
    "llamacpp": "http://localhost:8080/v1",
    "localai": "http://localhost:8080/v1",
}


def get_local_provider_url(provider_id: str) -> str:
    """Get the base URL for a local provider."""
    # Check for environment variable override
    env_map = {
        "ollama": "OLLAMA_BASE_URL",
        "lmstudio": "LMSTUDIO_BASE_URL",
        "vllm": "VLLM_BASE_URL",
        "tgi": "TGI_BASE_URL",
        "llamacpp": "LLAMACPP_BASE_URL",
        "localai": "LOCALAI_BASE_URL",
        "custom": "CUSTOM_LLM_BASE_URL",
    }

    env_var = env_map.get(provider_id)
    if env_var:
        custom_url = os.environ.get(env_var)
        if custom_url:
            return custom_url

    return LOCAL_PROVIDER_URLS.get(provider_id, "http://localhost:8000/v1")


async def check_local_provider(provider_id: str, timeout: float = 2.0) -> LocalProviderStatus:
    """
    Check if a local provider is running and accessible.

    Args:
        provider_id: Provider identifier (ollama, lmstudio, vllm, etc.)
        timeout: Connection timeout in seconds

    Returns:
        LocalProviderStatus with availability info
    """
    base_url = get_local_provider_url(provider_id)

    labels = {
        "ollama": "Ollama",
        "lmstudio": "LM Studio",
        "vllm": "vLLM",
        "tgi": "TGI",
        "llamacpp": "llama.cpp",
        "localai": "LocalAI",
        "custom": "Custom",
    }

    status = LocalProviderStatus(
        provider_id=provider_id,
        label=labels.get(provider_id, provider_id),
        base_url=base_url,
        is_running=False,
        available_models=[],
    )

    try:
        async with aiohttp.ClientSession() as session:
            # Try to list models (OpenAI-compatible endpoint)
            models_url = f"{base_url}/models"
            async with session.get(
                models_url,
                timeout=aiohttp.ClientTimeout(total=timeout)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    status.is_running = True

                    # Extract model IDs
                    models = data.get("data", [])
                    if isinstance(models, list):
                        for m in models:
                            if isinstance(m, dict):
                                model_id = m.get("id", "")
                                if model_id:
                                    status.available_models.append(model_id)
                            elif isinstance(m, str):
                                status.available_models.append(m)
                else:
                    status.error = f"HTTP {resp.status}"

    except asyncio.TimeoutError:
        status.error = "Connection timeout"
    except aiohttp.ClientConnectorError:
        status.error = "Not running"
    except Exception as e:
        status.error = str(e)

    return status


async def scan_local_providers() -> List[LocalProviderStatus]:
    """
    Scan all local providers and return their status.

    Returns:
        List of LocalProviderStatus for each provider
    """
    providers = ["ollama", "lmstudio", "vllm", "tgi", "llamacpp", "localai"]

    # Check custom if configured
    if os.environ.get("CUSTOM_LLM_BASE_URL"):
        providers.append("custom")

    # Check all providers concurrently
    tasks = [check_local_provider(pid) for pid in providers]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    statuses = []
    for result in results:
        if isinstance(result, LocalProviderStatus):
            statuses.append(result)

    return statuses


def get_running_local_providers() -> List[str]:
    """
    Synchronously get list of running local providers.

    Returns:
        List of provider IDs that are currently running
    """
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Already in async context, can't run sync
            return []
        statuses = asyncio.run(scan_local_providers())
        return [s.provider_id for s in statuses if s.is_running]
    except Exception:
        return []


def format_local_setup_guide() -> str:
    """Generate a setup guide for local providers."""
    return """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    LOCAL LLM SETUP GUIDE                                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  OLLAMA (Recommended for beginners)                                          ║
║  ─────────────────────────────────────                                       ║
║  1. Install: curl -fsSL https://ollama.com/install.sh | sh                   ║
║  2. Pull model: ollama pull llama3.1:8b                                      ║
║  3. Start server: ollama serve                                               ║
║  4. Use: /provider ollama                                                    ║
║                                                                              ║
║  LM STUDIO (GUI-based, easiest)                                              ║
║  ─────────────────────────────────                                           ║
║  1. Download: https://lmstudio.ai                                            ║
║  2. Download a model in the app                                              ║
║  3. Start local server (Settings → Local Server)                             ║
║  4. Use: /provider lmstudio                                                  ║
║                                                                              ║
║  vLLM (Production, high-throughput)                                          ║
║  ──────────────────────────────────                                          ║
║  pip install vllm                                                            ║
║  python -m vllm.entrypoints.openai.api_server \\                              ║
║      --model meta-llama/Llama-3.1-8B-Instruct                                ║
║  Use: /provider vllm                                                         ║
║                                                                              ║
║  llama.cpp (Lightweight, CPU-friendly)                                       ║
║  ──────────────────────────────────────                                      ║
║  1. Build: https://github.com/ggerganov/llama.cpp                            ║
║  2. Download GGUF model                                                      ║
║  3. Run: ./llama-server -m model.gguf --port 8080                            ║
║  4. Use: /provider llamacpp                                                  ║
║                                                                              ║
║  CUSTOM ENDPOINT                                                             ║
║  ────────────────                                                            ║
║  Set environment variables:                                                  ║
║    export CUSTOM_LLM_BASE_URL=http://your-server:8000/v1                     ║
║    export CUSTOM_LLM_API_KEY=your-key  # if needed                           ║
║  Use: /provider custom                                                       ║
║                                                                              ║
║  AIR-GAPPED DEPLOYMENT                                                       ║
║  ─────────────────────                                                       ║
║  For completely offline use:                                                 ║
║  1. Download models on a connected machine                                   ║
║  2. Transfer to air-gapped system                                            ║
║  3. Run Ollama/LM Studio/llama.cpp locally                                   ║
║  4. No API keys or internet needed!                                          ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""


def format_local_status(statuses: List[LocalProviderStatus]) -> str:
    """Format local provider status for display."""
    lines = ["\nLocal LLM Providers:"]
    lines.append("=" * 50)

    running = [s for s in statuses if s.is_running]
    not_running = [s for s in statuses if not s.is_running]

    if running:
        lines.append("\n✓ Running:")
        for s in running:
            model_info = f" ({len(s.available_models)} models)" if s.available_models else ""
            lines.append(f"  • {s.label}: {s.base_url}{model_info}")
            if s.available_models[:3]:
                models_str = ", ".join(s.available_models[:3])
                if len(s.available_models) > 3:
                    models_str += f", +{len(s.available_models) - 3} more"
                lines.append(f"    Models: {models_str}")
    else:
        lines.append("\n⚠ No local providers running")

    if not_running:
        lines.append("\n○ Not running:")
        for s in not_running:
            lines.append(f"  • {s.label}: {s.error or 'Not detected'}")

    lines.append("\nTip: Use /local setup for installation guide")

    return "\n".join(lines)
