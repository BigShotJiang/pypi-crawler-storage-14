"""
Google Gemini provider with tool calling support.

Implements the same interface as other providers so it can be swapped via provider_factory.

Includes hardened error handling with retry logic for:
- Network failures (premature close, connection reset)
- Stream errors (gunzip, decompression failures)
- Rate limiting with exponential backoff
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
from dataclasses import dataclass
from typing import Any, Optional

import google.generativeai as genai

logger = logging.getLogger(__name__)

# ============================================================================
# Error Recovery Constants
# ============================================================================

TRANSIENT_ERROR_PATTERNS = [
    "premature close",
    "premature end",
    "premature eof",
    "unexpected end",
    "unexpected eof",
    "aborted",
    "fetcherror",
    "fetch error",
    "invalid response body",
    "incomplete read",
    "gunzip",
    "gzip",
    "decompress",
    "zlib",
    "econnreset",
    "econnrefused",
    "enotfound",
    "epipe",
    "socket",
    "network",
    "timeout",
    "timed out",
    "rate limit",
    "rate_limit",
    "429",
    "500",
    "502",
    "503",
    "504",
    "resource exhausted",
    "quota",
    "remotedisconnected",
    "remoteprotocolerror",
]


def _is_transient_error(error: Exception) -> bool:
    """Check if an error is transient and should be retried."""
    message = str(error).lower()
    error_type = type(error).__name__.lower()
    all_text = f"{message} {error_type}"

    if any(pattern in all_text for pattern in TRANSIENT_ERROR_PATTERNS):
        return True

    # Check for common network error base classes
    error_bases = [base.__name__.lower() for base in type(error).__mro__]
    network_bases = ["connectionerror", "timeouterror", "oserror", "ioerror", "googleapierror"]
    if any(base in error_bases for base in network_bases):
        return True

    # Check cause chain
    cause = getattr(error, "__cause__", None) or getattr(error, "__context__", None)
    if cause and isinstance(cause, Exception):
        return _is_transient_error(cause)

    return False


def _get_backoff_delay(attempt: int, base_delay: float = 1.0, max_delay: float = 30.0) -> float:
    """Calculate exponential backoff delay with jitter."""
    delay = min(base_delay * (2 ** attempt), max_delay)
    jitter = delay * 0.1 * random.random()
    return delay + jitter


async def _execute_with_retry(
    operation,
    operation_name: str,
    max_retries: int = 3,
    provider_id: str = "google",
):
    """Execute an async operation with retry logic for transient errors."""
    last_error: Optional[Exception] = None

    for attempt in range(max_retries + 1):
        try:
            return await operation()
        except Exception as e:
            last_error = e

            if _is_transient_error(e) and attempt < max_retries:
                delay = _get_backoff_delay(attempt)
                logger.warning(
                    f"[{provider_id}] {operation_name} failed (attempt {attempt + 1}/{max_retries + 1}): "
                    f"{e}. Retrying in {delay:.1f}s..."
                )
                await asyncio.sleep(delay)
                continue

            raise

    raise last_error  # type: ignore

from ..core.types import (
    AssistantMessage,
    ConversationMessage,
    LLMProvider,
    ProviderMessageResponse,
    ProviderResponse,
    ProviderToolCallsResponse,
    ProviderToolDefinition,
    ProviderUsage,
    SystemMessage,
    ToolCallRequest,
    ToolMessage,
    UserMessage,
)


@dataclass
class GoogleProviderOptions:
    """Options for Google Gemini provider."""

    api_key: str
    model: str
    temperature: float = 0.0
    max_output_tokens: Optional[int] = None


class GoogleProvider(LLMProvider):
    """Google Gemini provider with tool calling support."""

    def __init__(self, options: GoogleProviderOptions):
        super().__init__("google", options.model)
        genai.configure(api_key=options.api_key)
        self.temperature = options.temperature
        self.max_output_tokens = options.max_output_tokens

    async def generate(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderResponse:
        """Generate a response using Gemini with retry logic."""
        async def _do_generate():
            mapped = _map_conversation(messages)

            generation_config: dict[str, Any] = {}
            if self.temperature is not None:
                generation_config["temperature"] = self.temperature
            if self.max_output_tokens is not None:
                generation_config["max_output_tokens"] = self.max_output_tokens

            tool_defs = _map_tools(tools)
            model = genai.GenerativeModel(model_name=self.model, tools=tool_defs or None)

            response = await model.generate_content_async(
                contents=mapped["contents"] or _empty_user_content(),
                system_instruction=mapped.get("system"),
                generation_config=generation_config or None,
            )

            usage = _map_usage(getattr(response, "usage_metadata", None))

            # Safely extract tool calls with error recovery
            try:
                tool_calls = _extract_tool_calls(response)
            except Exception as e:
                logger.warning(f"[google] Failed to extract tool calls, recovering: {e}")
                tool_calls = []

            content = (getattr(response, "text", None) or "").strip()

            if tool_calls:
                return ProviderToolCallsResponse(
                    type="tool_calls",
                    tool_calls=tool_calls,
                    content=content,
                    usage=usage,
                )

            return ProviderMessageResponse(
                type="message",
                content=content,
                usage=usage,
            )

        return await _execute_with_retry(_do_generate, "generate", max_retries=3, provider_id="google")

    def get_capabilities(self):
        return {
            "streaming": False,
            "tool_calling": True,
            "vision": "vision" in self.model.lower(),
            "function_calling": True,
            "max_tokens": self.max_output_tokens,
            "supported_modalities": ["text"],
        }


def _map_conversation(messages: list[ConversationMessage]) -> dict[str, Any]:
    contents: list[dict[str, Any]] = []
    system_parts: list[str] = []

    for message in messages:
        if isinstance(message, SystemMessage):
            if message.content.strip():
                system_parts.append(message.content.strip())
        elif isinstance(message, UserMessage):
            contents.append({"role": "user", "parts": [{"text": message.content}]})
        elif isinstance(message, AssistantMessage):
            parts: list[dict[str, Any]] = []
            if message.content:
                parts.append({"text": message.content})
            if message.tool_calls:
                for call in message.tool_calls:
                    parts.append(
                        {
                            "function_call": {
                                "id": call.id or None,
                                "name": call.name,
                                "args": call.arguments or {},
                            }
                        }
                    )
            contents.append({"role": "model", "parts": parts or [{"text": ""}]})
        elif isinstance(message, ToolMessage):
            # Tool responses are fed back as functionResponse parts
            if not message.tool_call_id:
                continue
            parts = [
                {
                    "function_response": {
                        "name": getattr(message, "name", None) or "tool",
                        "response": _safe_json(message.content),
                        "id": message.tool_call_id,
                    }
                }
            ]
            contents.append({"role": "user", "parts": parts})

    return {
        "contents": contents,
        "system": "\n\n".join(system_parts) if system_parts else None,
    }


def _map_tools(tools: list[ProviderToolDefinition]) -> list[dict[str, Any]]:
    if not tools:
        return []

    declarations = []
    for tool in tools:
        parameters = tool.parameters.model_dump(by_alias=True, exclude_none=True) if tool.parameters else {"type": "object", "properties": {}}
        declarations.append(
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": parameters,
            }
        )

    return [{"function_declarations": declarations}]


def _extract_tool_calls(response: Any) -> list[ToolCallRequest]:
    tool_calls: list[ToolCallRequest] = []

    candidates = getattr(response, "candidates", None) or []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        parts = getattr(content, "parts", None) or []
        for part in parts:
            function_call = None
            if hasattr(part, "function_call"):
                function_call = getattr(part, "function_call")
            elif hasattr(part, "functionCall"):
                function_call = getattr(part, "functionCall")
            elif isinstance(part, dict):
                function_call = part.get("function_call") or part.get("functionCall")

            if not function_call:
                continue

            if isinstance(function_call, dict):
                name = function_call.get("name")
                arguments = function_call.get("args")
                call_id = function_call.get("id")
            else:
                name = getattr(function_call, "name", None)
                arguments = getattr(function_call, "args", None)
                call_id = getattr(function_call, "id", None)

            if not name:
                continue

            tool_calls.append(
                ToolCallRequest(
                    id=str(call_id or name),
                    name=str(name),
                    arguments=_to_record(arguments),
                )
            )

    return tool_calls


def _map_usage(metadata: Any) -> Optional[ProviderUsage]:
    if not metadata:
        return None

    return ProviderUsage(
        input_tokens=getattr(metadata, "prompt_token_count", None),
        output_tokens=getattr(metadata, "candidates_token_count", None),
        total_tokens=getattr(metadata, "total_token_count", None),
    )


def _safe_json(content: str) -> dict[str, Any]:
    """Safely parse JSON content, wrapping in output dict if not valid JSON."""
    text = content.strip() if isinstance(content, str) else ""
    if not text:
        return {"output": ""}

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError as e:
        logger.debug(f"Content is not valid JSON (wrapping in output): {e}")
    return {"output": text}


def _to_record(value: Any) -> dict[str, Any]:
    """Convert value to dictionary, handling malformed JSON gracefully."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        trimmed = value.strip()
        if not trimmed:
            return {}
        try:
            parsed = json.loads(trimmed)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse tool arguments as JSON: {e}")
            # Try to salvage partial JSON
            try:
                fixed = trimmed.rstrip()
                if not fixed.endswith('}'):
                    fixed += '}'
                parsed = json.loads(fixed)
                return parsed if isinstance(parsed, dict) else {}
            except json.JSONDecodeError:
                pass
            return {}
    return {}


def _empty_user_content() -> list[dict[str, Any]]:
    return [{"role": "user", "parts": [{"text": ""}]}]
