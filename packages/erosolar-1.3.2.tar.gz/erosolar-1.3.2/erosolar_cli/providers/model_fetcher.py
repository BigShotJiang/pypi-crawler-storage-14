"""
Dynamic Model Fetcher

Fetches latest available models from provider APIs.
Caches results to avoid repeated network calls.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import os
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional
import asyncio

# Cache configuration
CACHE_FILE = Path.home() / ".erosolar" / "model_cache.json"
CACHE_TTL_SECONDS = 3600  # 1 hour


@dataclass
class ModelCache:
    """Cache for fetched models."""
    models: Dict[str, List[str]] = field(default_factory=dict)
    timestamps: Dict[str, float] = field(default_factory=dict)
    latest: Dict[str, str] = field(default_factory=dict)


_model_cache: Optional[ModelCache] = None


def _load_cache() -> ModelCache:
    """Load model cache from disk."""
    global _model_cache
    if _model_cache:
        return _model_cache

    try:
        if CACHE_FILE.exists():
            data = json.loads(CACHE_FILE.read_text())
            _model_cache = ModelCache(
                models=data.get("models", {}),
                timestamps=data.get("timestamps", {}),
                latest=data.get("latest", {}),
            )
        else:
            _model_cache = ModelCache()
    except Exception:
        _model_cache = ModelCache()

    return _model_cache


def _save_cache(cache: ModelCache) -> None:
    """Save model cache to disk."""
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(json.dumps({
            "models": cache.models,
            "timestamps": cache.timestamps,
            "latest": cache.latest,
        }, indent=2))
    except Exception:
        pass  # Silently ignore cache save errors


def _is_cache_valid(provider: str, cache: ModelCache) -> bool:
    """Check if cache is still valid for a provider."""
    if provider not in cache.timestamps:
        return False
    return (time.time() - cache.timestamps[provider]) < CACHE_TTL_SECONDS


async def fetch_openai_models(api_key: str) -> tuple[List[str], str]:
    """
    Fetch available models from OpenAI API.

    Returns:
        Tuple of (list of models, latest model ID)
    """
    import aiohttp

    async with aiohttp.ClientSession() as session:
        headers = {"Authorization": f"Bearer {api_key}"}
        async with session.get(
            "https://api.openai.com/v1/models",
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status != 200:
                return [], ""

            data = await resp.json()
            models = data.get("data", [])

            # Filter and sort models
            gpt_models = []
            for m in models:
                model_id = m.get("id", "")
                # Include GPT models
                if model_id.startswith(("gpt-", "o1-", "o3-")):
                    gpt_models.append(model_id)

            # Define model ranking for latest selection
            def model_priority(model_id: str) -> int:
                priorities = {
                    "gpt-5.1-codex-max": 100,
                    "gpt-5.1-codex": 95,
                    "gpt-5.1": 90,
                    "o3-mini": 88,
                    "o1-pro": 85,
                    "o1": 82,
                    "o1-mini": 80,
                    "gpt-4.1": 75,
                    "gpt-4o": 70,
                    "gpt-4-turbo": 65,
                    "gpt-4o-mini": 60,
                    "gpt-4": 55,
                    "gpt-3.5-turbo": 30,
                }
                for prefix, priority in priorities.items():
                    if model_id.startswith(prefix):
                        return priority
                return 0

            gpt_models.sort(key=model_priority, reverse=True)
            latest = gpt_models[0] if gpt_models else "gpt-4o"

            return gpt_models, latest


async def fetch_deepseek_models(api_key: str) -> tuple[List[str], str]:
    """
    Fetch available models from DeepSeek API.

    DeepSeek-V3.2-Exp is the latest as of 2025/09/29.
    deepseek-chat = non-thinking mode of V3.2-Exp
    deepseek-reasoner = thinking mode of V3.2-Exp

    Returns:
        Tuple of (list of models, latest model ID)
    """
    import aiohttp

    # DeepSeek models endpoint
    async with aiohttp.ClientSession() as session:
        headers = {"Authorization": f"Bearer {api_key}"}
        async with session.get(
            "https://api.deepseek.com/models",
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                models = []
                for m in data.get("data", []):
                    model_id = m.get("id", "")
                    if model_id:
                        models.append(model_id)

                # DeepSeek-V3.2-Exp is latest (exposed as deepseek-chat for non-thinking)
                # For reasoning tasks, deepseek-reasoner is the thinking mode
                # Priority: deepseek-reasoner (for reasoning) > deepseek-chat (for general)
                def model_priority(model_id: str) -> int:
                    priorities = {
                        "deepseek-reasoner": 100,  # V3.2-Exp thinking mode
                        "deepseek-chat": 95,       # V3.2-Exp non-thinking mode
                    }
                    return priorities.get(model_id, 0)

                models.sort(key=model_priority, reverse=True)
                # Default to deepseek-chat (V3.2-Exp) as it's best for general use
                latest = "deepseek-chat"
                return models if models else ["deepseek-chat", "deepseek-reasoner"], latest

    # Fallback to known models
    return ["deepseek-chat", "deepseek-reasoner"], "deepseek-chat"


async def fetch_qwen_models(api_key: str) -> tuple[List[str], str]:
    """
    Fetch available models from Qwen/DashScope API.

    Returns:
        Tuple of (list of models, latest model ID)
    """
    import aiohttp

    # DashScope models endpoint
    async with aiohttp.ClientSession() as session:
        headers = {"Authorization": f"Bearer {api_key}"}
        async with session.get(
            "https://dashscope.aliyuncs.com/compatible-mode/v1/models",
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                models = []
                for m in data.get("data", []):
                    model_id = m.get("id", "")
                    if model_id and "qwen" in model_id.lower():
                        models.append(model_id)

                # Qwen model priorities (latest first)
                def model_priority(model_id: str) -> int:
                    priorities = {
                        "qwen-max": 100,
                        "qwen-plus": 90,
                        "qwen-turbo": 80,
                        "qwen2.5-72b": 95,
                        "qwen2.5-32b": 85,
                        "qwen2.5-14b": 75,
                        "qwen2.5-7b": 65,
                    }
                    for prefix, priority in priorities.items():
                        if prefix in model_id.lower():
                            return priority
                    return 0

                models.sort(key=model_priority, reverse=True)
                latest = models[0] if models else "qwen-max"
                return models, latest

    # Fallback
    return ["qwen-max", "qwen-plus", "qwen-turbo"], "qwen-max"


async def fetch_mistral_models(api_key: str) -> tuple[List[str], str]:
    """
    Fetch available models from Mistral API.

    Returns:
        Tuple of (list of models, latest model ID)
    """
    import aiohttp

    async with aiohttp.ClientSession() as session:
        headers = {"Authorization": f"Bearer {api_key}"}
        async with session.get(
            "https://api.mistral.ai/v1/models",
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                models = []
                for m in data.get("data", []):
                    model_id = m.get("id", "")
                    if model_id:
                        models.append(model_id)

                # Mistral priorities
                def model_priority(model_id: str) -> int:
                    if "large" in model_id.lower():
                        return 100
                    if "medium" in model_id.lower():
                        return 80
                    if "small" in model_id.lower():
                        return 60
                    if "codestral" in model_id.lower():
                        return 90
                    return 0

                models.sort(key=model_priority, reverse=True)
                latest = models[0] if models else "mistral-large-latest"
                return models, latest

    return ["mistral-large-latest", "mistral-medium-latest", "codestral-latest"], "mistral-large-latest"


async def fetch_groq_models(api_key: str) -> tuple[List[str], str]:
    """
    Fetch available models from Groq API.

    Returns:
        Tuple of (list of models, latest model ID)
    """
    import aiohttp

    async with aiohttp.ClientSession() as session:
        headers = {"Authorization": f"Bearer {api_key}"}
        async with session.get(
            "https://api.groq.com/openai/v1/models",
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                models = []
                for m in data.get("data", []):
                    model_id = m.get("id", "")
                    if model_id:
                        models.append(model_id)

                # Groq priorities (larger = better generally)
                def model_priority(model_id: str) -> int:
                    if "70b" in model_id.lower():
                        return 100
                    if "8x7b" in model_id.lower():
                        return 90
                    if "8b" in model_id.lower():
                        return 70
                    return 50

                models.sort(key=model_priority, reverse=True)
                latest = models[0] if models else "llama-3.3-70b-versatile"
                return models, latest

    return ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"], "llama-3.3-70b-versatile"


async def fetch_anthropic_models(api_key: str) -> tuple[List[str], str]:
    """
    Fetch available models from Anthropic API.

    Note: Anthropic doesn't have a public models endpoint,
    so we use known models with latest at the top.
    """
    # Anthropic models (newest first)
    models = [
        "claude-sonnet-4-5-20250929",
        "claude-opus-4-20250514",
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
        "claude-3-opus-20240229",
        "claude-3-sonnet-20240229",
        "claude-3-haiku-20240307",
    ]
    latest = models[0]  # claude-sonnet-4-5 is latest
    return models, latest


async def fetch_google_models(api_key: str) -> tuple[List[str], str]:
    """
    Fetch available models from Google AI API.
    """
    import aiohttp

    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}",
            timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status != 200:
                # Return defaults
                return ["gemini-2.0-flash-exp", "gemini-1.5-pro"], "gemini-2.0-flash-exp"

            data = await resp.json()
            models = []
            for m in data.get("models", []):
                name = m.get("name", "")
                # Extract model ID from name like "models/gemini-1.5-pro"
                if "/" in name:
                    model_id = name.split("/")[-1]
                    if "gemini" in model_id:
                        models.append(model_id)

            # Sort by version (2.0 > 1.5 > 1.0)
            def model_priority(model_id: str) -> int:
                if "2.0" in model_id:
                    return 100
                if "1.5" in model_id:
                    return 50
                return 0

            models.sort(key=model_priority, reverse=True)
            latest = models[0] if models else "gemini-2.0-flash-exp"

            return models, latest


async def fetch_models_for_provider(provider: str) -> tuple[List[str], str]:
    """
    Fetch models for a specific provider from their API.

    Auto-detects the latest available models.

    Args:
        provider: Provider ID (openai, anthropic, google, deepseek, etc.)

    Returns:
        Tuple of (list of models, latest/recommended model)
    """
    cache = _load_cache()

    # Check cache first
    if _is_cache_valid(provider, cache):
        return cache.models.get(provider, []), cache.latest.get(provider, "")

    # Fetch from API
    provider_lower = provider.lower()

    try:
        models, latest = [], ""

        if provider_lower == "openai":
            api_key = os.environ.get("OPENAI_API_KEY", "")
            if api_key:
                models, latest = await fetch_openai_models(api_key)

        elif provider_lower == "anthropic":
            api_key = os.environ.get("ANTHROPIC_API_KEY", "")
            if api_key:
                models, latest = await fetch_anthropic_models(api_key)

        elif provider_lower == "google":
            api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY", "")
            if api_key:
                models, latest = await fetch_google_models(api_key)

        elif provider_lower == "deepseek":
            api_key = os.environ.get("DEEPSEEK_API_KEY", "")
            if api_key:
                models, latest = await fetch_deepseek_models(api_key)

        elif provider_lower == "qwen":
            api_key = os.environ.get("DASHSCOPE_API_KEY", "")
            if api_key:
                models, latest = await fetch_qwen_models(api_key)

        elif provider_lower == "mistral":
            api_key = os.environ.get("MISTRAL_API_KEY", "")
            if api_key:
                models, latest = await fetch_mistral_models(api_key)

        elif provider_lower == "groq":
            api_key = os.environ.get("GROQ_API_KEY", "")
            if api_key:
                models, latest = await fetch_groq_models(api_key)

        elif provider_lower == "xai":
            api_key = os.environ.get("XAI_API_KEY", "")
            if api_key:
                # xAI uses OpenAI-compatible API
                models = ["grok-2", "grok-2-mini", "grok-beta"]
                latest = "grok-2"

        # Cache results if we got any
        if models:
            cache.models[provider] = models
            cache.latest[provider] = latest
            cache.timestamps[provider] = time.time()
            _save_cache(cache)
            return models, latest

    except Exception:
        pass  # Fall through to defaults

    # Return defaults from cache or hardcoded
    return cache.models.get(provider, []), cache.latest.get(provider, "")


def get_latest_model_sync(provider: str) -> str:
    """
    Synchronous wrapper to get latest model for a provider.
    Uses cache if available, otherwise returns hardcoded latest.

    Args:
        provider: Provider ID

    Returns:
        Latest model ID for the provider
    """
    cache = _load_cache()

    # Check cache first
    if provider in cache.latest and _is_cache_valid(provider, cache):
        return cache.latest[provider]

    # Return hardcoded latest models (best available as of 2025)
    # These are used when no cache exists or API fetch hasn't run
    latest_models = {
        "openai": "gpt-4o",  # Will try to find gpt-5.1-codex-max via API
        "anthropic": "claude-sonnet-4-5-20250929",
        "google": "gemini-2.0-flash-exp",
        "deepseek": "deepseek-chat",
        "ollama": "llama3.1:8b",
        "xai": "grok-2",
        # Major providers
        "qwen": "qwen-max",
        "mistral": "mistral-large-latest",
        "groq": "llama-3.3-70b-versatile",
        "together": "meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo",
        "cohere": "command-r-plus",
        "perplexity": "llama-3.1-sonar-large-128k-online",
        "fireworks": "accounts/fireworks/models/llama-v3p1-405b-instruct",
        "zhipu": "glm-4-plus",
        "moonshot": "moonshot-v1-128k",
        "cerebras": "llama3.1-70b",
    }

    return latest_models.get(provider.lower(), "")


async def update_model_cache_async() -> Dict[str, str]:
    """
    Update model cache for all configured providers.

    PERF: Uses asyncio.gather with return_exceptions=True to fetch all providers
    in parallel. No single slow/failed provider blocks the others.

    Returns:
        Dict mapping provider -> latest model
    """
    from .provider_factory import get_configured_providers

    results = {}
    providers = get_configured_providers()

    if not providers:
        return results

    # PERF: Fetch all providers in parallel using asyncio.gather
    async def fetch_with_provider(provider: str) -> tuple[str, List[str], str]:
        """Fetch models for a provider, returning (provider, models, latest)."""
        try:
            models, latest = await fetch_models_for_provider(provider)
            return (provider, models, latest)
        except Exception:
            return (provider, [], "")

    # Execute all fetches in parallel
    fetch_tasks = [fetch_with_provider(p) for p in providers]
    all_results = await asyncio.gather(*fetch_tasks, return_exceptions=True)

    # Process results
    for result in all_results:
        if isinstance(result, Exception):
            continue  # Skip failed fetches
        provider, models, latest = result
        if latest:
            results[provider] = latest

    return results


def update_model_cache() -> Dict[str, str]:
    """
    Synchronous wrapper to update model cache.
    """
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Create new task in existing loop
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, update_model_cache_async())
                return future.result(timeout=15)
        else:
            return asyncio.run(update_model_cache_async())
    except Exception:
        return {}
