"""
Anthropic Claude provider with streaming, tool calling, and rate limiting.

Includes hardened error handling with retry logic for:
- Network failures (premature close, connection reset)
- Stream errors (gunzip, decompression failures)
- Rate limiting with exponential backoff
- Transient server errors (500, 502, 503, 504, 529)
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
from dataclasses import dataclass
from typing import Any, AsyncIterator, Optional

from anthropic import Anthropic, AsyncAnthropic, RateLimitError, APIError

logger = logging.getLogger(__name__)

# ============================================================================
# Error Recovery Constants
# ============================================================================

TRANSIENT_ERROR_PATTERNS = [
    "premature close",
    "premature end",
    "premature eof",
    "unexpected end",
    "unexpected eof",
    "aborted",
    "fetcherror",
    "fetch error",
    "invalid response body",
    "incomplete read",
    "gunzip",
    "gzip",
    "decompress",
    "zlib",
    "econnreset",
    "econnrefused",
    "enotfound",
    "epipe",
    "socket",
    "network",
    "timeout",
    "timed out",
    "500",
    "502",
    "503",
    "504",
    "529",  # Anthropic overloaded
    "overloaded",
    "remotedisconnected",
    "remoteprotocolerror",
]


def _is_transient_error(error: Exception) -> bool:
    """Check if an error is transient and should be retried."""
    message = str(error).lower()
    error_type = type(error).__name__.lower()
    all_text = f"{message} {error_type}"

    if any(pattern in all_text for pattern in TRANSIENT_ERROR_PATTERNS):
        return True

    # Check for 5xx status codes
    if isinstance(error, APIError):
        status = getattr(error, "status_code", None) or getattr(error, "status", None)
        if status and 500 <= status < 600:
            return True
        # Anthropic overloaded (529)
        if status == 529:
            return True

    # Check for common network error base classes
    error_bases = [base.__name__.lower() for base in type(error).__mro__]
    network_bases = ["connectionerror", "timeouterror", "oserror", "ioerror"]
    if any(base in error_bases for base in network_bases):
        return True

    # Check cause chain
    cause = getattr(error, "__cause__", None) or getattr(error, "__context__", None)
    if cause and isinstance(cause, Exception):
        return _is_transient_error(cause)

    return False


def _get_backoff_delay(attempt: int, base_delay: float = 1.0, max_delay: float = 30.0) -> float:
    """Calculate exponential backoff delay with jitter."""
    delay = min(base_delay * (2 ** attempt), max_delay)
    jitter = delay * 0.1 * random.random()
    return delay + jitter
from anthropic.types import (
    ContentBlock,
    Message,
    MessageStreamEvent,
    TextBlock,
    ToolUseBlock,
)

from ..core.types import (
    AssistantMessage,
    ConversationMessage,
    LLMProvider,
    ProviderMessageResponse,
    ProviderResponse,
    ProviderToolCallsResponse,
    ProviderToolDefinition,
    ProviderUsage,
    StreamChunk,
    SystemMessage,
    ToolCallRequest,
    ToolMessage,
    UserMessage,
)


DEFAULT_RATE_LIMIT_RETRIES = 4
DEFAULT_RATE_LIMIT_INITIAL_DELAY_MS = 1500
MIN_RATE_LIMIT_DELAY_MS = 750
MAX_RATE_LIMIT_DELAY_MS = 40000


@dataclass
class AnthropicProviderOptions:
    """Options for Anthropic provider."""

    api_key: str
    model: str
    max_tokens: int = 2048
    temperature: float = 0.0
    rate_limit_max_retries: int = DEFAULT_RATE_LIMIT_RETRIES
    rate_limit_initial_delay_ms: int = DEFAULT_RATE_LIMIT_INITIAL_DELAY_MS
    enable_prompt_caching: bool = True


class AnthropicProvider(LLMProvider):
    """Anthropic Claude provider with streaming and tool calling support."""

    def __init__(self, options: AnthropicProviderOptions):
        """Initialize Anthropic provider."""
        super().__init__("anthropic", options.model)
        self.client = AsyncAnthropic(api_key=options.api_key)
        self.sync_client = Anthropic(api_key=options.api_key)
        self.max_tokens = options.max_tokens
        self.temperature = options.temperature
        self.rate_limit_max_retries = max(0, options.rate_limit_max_retries)
        self.rate_limit_initial_delay_ms = max(MIN_RATE_LIMIT_DELAY_MS, options.rate_limit_initial_delay_ms)
        self.enable_prompt_caching = options.enable_prompt_caching

    async def generate(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderResponse:
        """Generate a response from Claude."""
        system, chat = _convert_conversation(messages, self.enable_prompt_caching)

        # Build request parameters
        params: dict[str, Any] = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "messages": chat,
        }

        if system:
            params["system"] = system

        if tools:
            params["tools"] = [_map_tool(tool) for tool in tools]

        # Execute with rate limit retries
        response = await self._execute_with_retries(lambda: self.client.messages.create(**params))

        # Extract usage
        usage = _map_usage(response.usage) if response.usage else None

        # Extract tool calls
        tool_calls = [
            ToolCallRequest(
                id=block.id,
                name=block.name,
                arguments=_to_record(block.input),
            )
            for block in response.content
            if isinstance(block, ToolUseBlock)
        ]

        # Extract text content
        text_content = "\n".join(
            block.text for block in response.content if isinstance(block, TextBlock) and hasattr(block, "text")
        ).strip()

        if tool_calls:
            return ProviderToolCallsResponse(
                type="tool_calls",
                tool_calls=tool_calls,
                content=text_content,
                usage=usage,
            )

        return ProviderMessageResponse(
            type="message",
            content=text_content,
            usage=usage,
        )

    async def generate_stream(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> AsyncIterator[StreamChunk]:
        """Generate a streaming response from Claude."""
        system, chat = _convert_conversation(messages, self.enable_prompt_caching)

        # Build request parameters
        params: dict[str, Any] = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "messages": chat,
        }

        if system:
            params["system"] = system

        if tools:
            params["tools"] = [_map_tool(tool) for tool in tools]

        # Stream response
        async with self.client.messages.stream(**params) as stream:
            current_tool_call: Optional[dict[str, Any]] = None
            current_tool_call_input = ""
            tool_call_id = ""

            async for event in stream:
                # Handle different event types
                if event.type == "content_block_start":
                    content_block = event.content_block
                    if hasattr(content_block, "type") and content_block.type == "tool_use":
                        tool_call_id = content_block.id
                        current_tool_call = {
                            "id": content_block.id,
                            "name": content_block.name,
                            "arguments": {},
                        }
                        current_tool_call_input = ""

                elif event.type == "content_block_delta":
                    delta = event.delta
                    if hasattr(delta, "type"):
                        if delta.type == "text_delta" and hasattr(delta, "text"):
                            yield StreamChunk(
                                type="content",
                                content=delta.text,
                            )
                        elif delta.type == "input_json_delta" and current_tool_call:
                            if hasattr(delta, "partial_json") and delta.partial_json:
                                current_tool_call_input += delta.partial_json

                elif event.type == "content_block_stop":
                    if current_tool_call and tool_call_id:
                        if current_tool_call_input.strip():
                            try:
                                current_tool_call["arguments"] = json.loads(current_tool_call_input)
                            except json.JSONDecodeError as e:
                                logger.warning(f"Failed to parse tool arguments in stream: {e}")
                                current_tool_call["arguments"] = {}

                        yield StreamChunk(
                            type="tool_call",
                            tool_call=ToolCallRequest(**current_tool_call),
                        )
                        current_tool_call = None
                        current_tool_call_input = ""
                        tool_call_id = ""

                elif event.type == "message_stop":
                    final_message = await stream.get_final_message()
                    usage = _map_usage(final_message.usage) if final_message.usage else None
                    if usage:
                        yield StreamChunk(
                            type="usage",
                            usage=usage,
                        )
                    yield StreamChunk(type="done")

    def get_capabilities(self):
        """Get provider capabilities."""
        return {
            "streaming": True,
            "tool_calling": True,
            "vision": "sonnet" in self.model or "opus" in self.model,
            "function_calling": True,
            "max_tokens": self.max_tokens,
            "supported_modalities": ["text", "image"],
        }

    async def _execute_with_retries(self, operation):
        """Execute operation with rate limit and transient error retries."""
        rate_limit_retries = 0
        transient_retries = 0
        delay_ms = self.rate_limit_initial_delay_ms
        max_transient_retries = 3

        while True:
            try:
                return await operation()
            except RateLimitError as error:
                if rate_limit_retries >= self.rate_limit_max_retries:
                    raise _build_rate_limit_failure_error(error, rate_limit_retries)

                # Determine retry delay
                wait_ms = _determine_retry_delay(None, delay_ms)
                logger.warning(
                    f"[anthropic] Rate limited (attempt {rate_limit_retries + 1}/{self.rate_limit_max_retries + 1}). "
                    f"Retrying in {wait_ms}ms..."
                )
                await asyncio.sleep(wait_ms / 1000.0)

                rate_limit_retries += 1
                delay_ms = min(delay_ms * 2, MAX_RATE_LIMIT_DELAY_MS)

            except Exception as error:
                # Check if it's a rate limit error (status 429)
                status = getattr(error, "status", None) or getattr(error, "status_code", None)
                if status == 429:
                    if rate_limit_retries >= self.rate_limit_max_retries:
                        raise _build_rate_limit_failure_error(error, rate_limit_retries)

                    wait_ms = _determine_retry_delay(None, delay_ms)
                    logger.warning(
                        f"[anthropic] Rate limited (attempt {rate_limit_retries + 1}/{self.rate_limit_max_retries + 1}). "
                        f"Retrying in {wait_ms}ms..."
                    )
                    await asyncio.sleep(wait_ms / 1000.0)

                    rate_limit_retries += 1
                    delay_ms = min(delay_ms * 2, MAX_RATE_LIMIT_DELAY_MS)

                # Check if it's a transient error
                elif _is_transient_error(error):
                    if transient_retries >= max_transient_retries:
                        raise Exception(
                            f"Transient error after {transient_retries + 1} attempts: {error}"
                        ) from error

                    wait_s = _get_backoff_delay(transient_retries)
                    logger.warning(
                        f"[anthropic] Transient error (attempt {transient_retries + 1}/{max_transient_retries + 1}): "
                        f"{error}. Retrying in {wait_s:.1f}s..."
                    )
                    await asyncio.sleep(wait_s)
                    transient_retries += 1

                else:
                    raise


def _convert_conversation(
    messages: list[ConversationMessage], enable_prompt_caching: bool = False
) -> tuple[Optional[str], list[dict[str, Any]]]:
    """
    Convert conversation messages to Anthropic format.

    Args:
        messages: Conversation messages
        enable_prompt_caching: Whether to enable prompt caching

    Returns:
        Tuple of (system_prompt, chat_messages)
    """
    system_prompts: list[str] = []
    chat: list[dict[str, Any]] = []

    for message in messages:
        if isinstance(message, SystemMessage):
            system_prompts.append(message.content)

        elif isinstance(message, UserMessage):
            chat.append({"role": "user", "content": [{"type": "text", "text": message.content}]})

        elif isinstance(message, AssistantMessage):
            content_blocks: list[dict[str, Any]] = []

            if message.content.strip():
                content_blocks.append({"type": "text", "text": message.content})

            if message.tool_calls:
                for call in message.tool_calls:
                    content_blocks.append(
                        {
                            "type": "tool_use",
                            "id": call.id,
                            "name": call.name,
                            "input": call.arguments,
                        }
                    )

            # Anthropic requires non-empty content blocks
            # If no content, use a minimal placeholder that won't cause API errors
            if not content_blocks:
                content_blocks = [{"type": "text", "text": " "}]
            chat.append(
                {
                    "role": "assistant",
                    "content": content_blocks,
                }
            )

        elif isinstance(message, ToolMessage):
            block = {
                "type": "tool_result",
                "tool_use_id": message.tool_call_id,
                "content": [{"type": "text", "text": message.content}],
            }
            chat.append({"role": "user", "content": [block]})

    # Add cache control breakpoints for cost optimization
    if enable_prompt_caching and len(chat) > 2:
        cache_breakpoint = min(2, len(chat) - 1)
        for i in range(cache_breakpoint):
            message = chat[i]
            if message["role"] == "user" and isinstance(message["content"], list):
                last_content = message["content"][-1]
                if "text" in last_content:
                    last_content["cache_control"] = {"type": "ephemeral"}

    system = "\n\n".join(system_prompts) if system_prompts else None
    return system, chat


def _map_tool(definition: ProviderToolDefinition) -> dict[str, Any]:
    """Map tool definition to Anthropic format."""
    return {
        "name": definition.name,
        "description": definition.description,
        "input_schema": definition.parameters.model_dump(by_alias=True, exclude_none=True) if definition.parameters else {"type": "object", "properties": {}},
    }


def _to_record(value: Any) -> dict[str, Any]:
    """Convert value to dictionary, handling malformed JSON gracefully."""
    if isinstance(value, dict):
        return value

    if isinstance(value, str):
        trimmed = value.strip()
        if not trimmed:
            return {}
        try:
            parsed = json.loads(trimmed)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse tool input as JSON: {e}")
            # Try to salvage partial JSON
            try:
                fixed = trimmed.rstrip()
                if not fixed.endswith('}'):
                    fixed += '}'
                parsed = json.loads(fixed)
                return parsed if isinstance(parsed, dict) else {}
            except json.JSONDecodeError:
                pass
            return {}

    return {}


def _map_usage(usage: Any) -> Optional[ProviderUsage]:
    """Map usage statistics to ProviderUsage."""
    if not usage:
        return None

    input_tokens = getattr(usage, "input_tokens", None)
    output_tokens = getattr(usage, "output_tokens", None)

    total = None
    if isinstance(input_tokens, int) and isinstance(output_tokens, int):
        total = input_tokens + output_tokens

    return ProviderUsage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total,
    )


def _determine_retry_delay(headers: Any, fallback_ms: int) -> int:
    """Determine retry delay with jitter."""
    # Add jitter to prevent thundering herd
    jitter = fallback_ms * 0.25
    randomized = fallback_ms + (random.random() * (2 * jitter) - jitter)
    return _clamp(round(randomized), MIN_RATE_LIMIT_DELAY_MS, MAX_RATE_LIMIT_DELAY_MS)


def _clamp(value: int, min_val: int, max_val: int) -> int:
    """Clamp value between min and max."""
    return max(min_val, min(max_val, value))


def _build_rate_limit_failure_error(error: Exception, retries: int) -> Exception:
    """Build rate limit failure error message."""
    base_message = "Anthropic rejected the request because the per-minute token rate limit was exceeded."
    retry_details = f" Waited and retried {retries} time{'s' if retries != 1 else ''} without success." if retries > 0 else ""
    advisory = (
        " Reduce the prompt size or wait for usage to reset before trying again. "
        "See https://docs.claude.com/en/api/rate-limits for quota guidance."
    )
    original = f"\nOriginal message: {str(error)}" if str(error) else ""

    return Exception(f"{base_message}{retry_details}{advisory}{original}")
