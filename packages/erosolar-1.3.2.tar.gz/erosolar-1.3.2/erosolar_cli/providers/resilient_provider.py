"""
Resilient Provider Wrapper

Adds rate limiting, exponential backoff retry, and circuit breaker
patterns to any LLM provider for maximum reliability and performance.

PERF: Provider-agnostic wrapper that prevents rate limit errors and
automatically recovers from transient failures.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional, Protocol, Union

from ..utils.async_utils import RateLimiter, retry_with_backoff


# ============================================================================
# Types
# ============================================================================

class LLMProviderProtocol(Protocol):
    """Protocol for LLM providers."""

    async def generate(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
    ) -> Any:
        """Generate a response."""
        ...

    async def generate_stream(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
    ) -> AsyncIterator[Any]:
        """Generate a streaming response."""
        ...


@dataclass
class ResilientProviderConfig:
    """Configuration for resilient provider wrapper."""
    max_requests_per_minute: int = 50
    max_retries: int = 4
    base_delay_ms: int = 1000
    max_delay_ms: int = 32000
    enable_circuit_breaker: bool = True
    circuit_breaker_threshold: int = 5
    circuit_breaker_reset_ms: int = 60000


@dataclass
class CircuitBreakerState:
    """State for circuit breaker pattern."""
    failures: int = 0
    last_failure: float = 0
    is_open: bool = False


@dataclass
class ResilientProviderStats:
    """Statistics for resilient provider."""
    total_requests: int = 0
    rate_limit_hits: int = 0
    retries: int = 0
    circuit_breaker_trips: int = 0


# ============================================================================
# Rate Limit Error Detection
# ============================================================================

RATE_LIMIT_PATTERNS = [
    "rate limit",
    "rate_limit",
    "ratelimit",
    "too many requests",
    "429",
    "quota exceeded",
    "request limit",
    "throttled",
    "overloaded",
    "capacity",
]

TRANSIENT_ERROR_PATTERNS = [
    "timeout",
    "timed out",
    "network",
    "connection",
    "econnrefused",
    "econnreset",
    "enotfound",
    "epipe",
    "econnaborted",
    "ehostunreach",
    "enetunreach",
    "socket",
    "temporarily unavailable",
    "502",
    "503",
    "504",
    "bad gateway",
    "service unavailable",
    "gateway timeout",
    "internal server error",
    "500",
    # Stream and fetch errors
    "premature close",
    "premature end",
    "premature eof",
    "unexpected end",
    "unexpected eof",
    "stream",
    "aborted",
    "fetcherror",
    "fetch error",
    "invalid response body",
    "response body",
    "incomplete read",
    "chunked encoding",
    "content-encoding",
    "transfer-encoding",
    "decompression",
    "decompress",
    "gunzip",
    "gzip",
    "zlib",
    "deflate",
    # httpx/aiohttp specific
    "readtimeout",
    "connecttimeout",
    "pooltimeout",
    "remotedisconnected",
    "remoteprotocolerror",
    "localprotocolerror",
    "readererror",
    "writeerror",
    # SSL/TLS errors
    "ssl",
    "tls",
    "certificate",
    "handshake",
]


def is_rate_limit_error(error: Exception) -> bool:
    """Check if error is a rate limit error."""
    message = str(error).lower()
    error_type = type(error).__name__.lower()
    return any(pattern in message or pattern in error_type for pattern in RATE_LIMIT_PATTERNS)


def is_transient_error(error: Exception) -> bool:
    """
    Check if error is a transient/retryable error.

    Checks:
    - Error message content
    - Error type/class name
    - Cause chain for nested errors
    """
    message = str(error).lower()
    error_type = type(error).__name__.lower()

    # Check message and error type
    all_text = f"{message} {error_type}"
    if any(pattern in all_text for pattern in TRANSIENT_ERROR_PATTERNS):
        return True

    # Check for common network error base classes
    error_bases = [base.__name__.lower() for base in type(error).__mro__]
    network_bases = ["connectionerror", "timeouterror", "oserror", "ioerror"]
    if any(base in error_bases for base in network_bases):
        return True

    # Check cause chain (Python 3 exception chaining)
    cause = getattr(error, "__cause__", None) or getattr(error, "__context__", None)
    if cause and isinstance(cause, Exception):
        return is_transient_error(cause)

    return False


def should_retry(error: Exception) -> bool:
    """Check if error should trigger a retry."""
    return is_rate_limit_error(error) or is_transient_error(error)


# ============================================================================
# Resilient Provider Implementation
# ============================================================================

class ResilientProvider:
    """
    Wraps any LLM provider with rate limiting and retry logic.

    Features:
    - Token bucket rate limiting
    - Exponential backoff retry for rate limits and transient errors
    - Circuit breaker pattern to prevent cascade failures
    - Provider-specific configuration presets
    """

    def __init__(
        self,
        provider: Any,
        config: Optional[ResilientProviderConfig] = None,
    ):
        self.provider = provider
        self.config = config or ResilientProviderConfig()

        # Rate limiter
        self._rate_limiter = RateLimiter(
            max_requests=self.config.max_requests_per_minute,
            window_seconds=60,
        )

        # Circuit breaker state
        self._circuit_breaker = CircuitBreakerState()

        # Statistics
        self._stats = ResilientProviderStats()

    def _check_circuit_breaker(self) -> None:
        """Check and potentially reset circuit breaker."""
        if not self.config.enable_circuit_breaker:
            return

        if self._circuit_breaker.is_open:
            elapsed = (time.time() - self._circuit_breaker.last_failure) * 1000
            if elapsed >= self.config.circuit_breaker_reset_ms:
                # Half-open: allow one request through
                self._circuit_breaker.is_open = False
                self._circuit_breaker.failures = self._circuit_breaker.failures // 2
            else:
                remaining_ms = self.config.circuit_breaker_reset_ms - elapsed
                raise Exception(
                    f"Circuit breaker is open. Too many failures ({self._circuit_breaker.failures}). "
                    f"Retry in {int(remaining_ms / 1000)}s."
                )

    def _record_failure(self, error: Optional[Exception] = None) -> None:
        """Record a failure for circuit breaker."""
        if not self.config.enable_circuit_breaker:
            return

        self._circuit_breaker.failures += 1
        self._circuit_breaker.last_failure = time.time()

        if self._circuit_breaker.failures >= self.config.circuit_breaker_threshold:
            self._circuit_breaker.is_open = True
            self._stats.circuit_breaker_trips += 1

    def _record_success(self) -> None:
        """Record a success to reset circuit breaker."""
        if self.config.enable_circuit_breaker and self._circuit_breaker.failures > 0:
            self._circuit_breaker.failures = max(0, self._circuit_breaker.failures - 1)

    async def generate(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
    ) -> Any:
        """Generate a response with resilience."""
        self._stats.total_requests += 1

        # Check circuit breaker
        self._check_circuit_breaker()

        # Acquire rate limit token
        await self._rate_limiter.acquire()

        # Retry logic
        last_error: Optional[Exception] = None
        for attempt in range(self.config.max_retries + 1):
            try:
                result = await self.provider.generate(messages, tools)
                self._record_success()
                return result

            except Exception as e:
                last_error = e

                if attempt < self.config.max_retries and should_retry(e):
                    self._stats.retries += 1
                    if is_rate_limit_error(e):
                        self._stats.rate_limit_hits += 1

                    # Exponential backoff
                    delay_ms = min(
                        self.config.base_delay_ms * (2 ** attempt),
                        self.config.max_delay_ms,
                    )
                    await asyncio.sleep(delay_ms / 1000)
                    continue

                self._record_failure(e)
                raise

        self._record_failure(last_error)
        if last_error:
            raise last_error
        raise Exception("Max retries exceeded")

    async def generate_stream(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
    ) -> AsyncIterator[Any]:
        """
        Generate a streaming response with resilience.

        Note: Retry logic is limited for streaming - we can only retry
        before the stream starts, not mid-stream.
        """
        # Check if provider supports streaming
        if not hasattr(self.provider, "generate_stream"):
            # Fall back to non-streaming
            result = await self.generate(messages, tools)
            yield result
            return

        self._stats.total_requests += 1

        # Check circuit breaker
        self._check_circuit_breaker()

        # Acquire rate limit token
        await self._rate_limiter.acquire()

        # Retry logic
        last_error: Optional[Exception] = None
        for attempt in range(self.config.max_retries + 1):
            try:
                async for chunk in self.provider.generate_stream(messages, tools):
                    yield chunk
                self._record_success()
                return

            except Exception as e:
                last_error = e

                if attempt < self.config.max_retries and should_retry(e):
                    self._stats.retries += 1
                    if is_rate_limit_error(e):
                        self._stats.rate_limit_hits += 1

                    # Exponential backoff
                    delay_ms = min(
                        self.config.base_delay_ms * (2 ** attempt),
                        self.config.max_delay_ms,
                    )
                    await asyncio.sleep(delay_ms / 1000)
                    continue

                self._record_failure(e)
                raise

        self._record_failure(last_error)
        if last_error:
            raise last_error
        raise Exception("Max retries exceeded")

    def get_stats(self) -> Dict[str, Any]:
        """Get resilience statistics."""
        return {
            "total_requests": self._stats.total_requests,
            "rate_limit_hits": self._stats.rate_limit_hits,
            "retries": self._stats.retries,
            "circuit_breaker_trips": self._stats.circuit_breaker_trips,
            "circuit_breaker_open": self._circuit_breaker.is_open,
            "available_tokens": self._rate_limiter.available_tokens,
        }

    def reset_stats(self) -> None:
        """Reset statistics."""
        self._stats = ResilientProviderStats()


# ============================================================================
# Factory Functions
# ============================================================================

def with_resilience(
    provider: Any,
    config: Optional[ResilientProviderConfig] = None,
) -> ResilientProvider:
    """Wrap any provider with resilience features."""
    return ResilientProvider(provider, config)


# Provider-specific recommended configurations
PROVIDER_RESILIENCE_CONFIGS: Dict[str, ResilientProviderConfig] = {
    "anthropic": ResilientProviderConfig(
        max_requests_per_minute=50,
        max_retries=4,
        base_delay_ms=1500,
        max_delay_ms=40000,
    ),
    "openai": ResilientProviderConfig(
        max_requests_per_minute=60,
        max_retries=3,
        base_delay_ms=1000,
        max_delay_ms=30000,
    ),
    "google": ResilientProviderConfig(
        max_requests_per_minute=60,
        max_retries=3,
        base_delay_ms=1000,
        max_delay_ms=30000,
    ),
    "deepseek": ResilientProviderConfig(
        max_requests_per_minute=30,
        max_retries=5,  # More retries for DeepSeek's connection issues
        base_delay_ms=2000,
        max_delay_ms=60000,  # Longer max delay
        enable_circuit_breaker=True,
        circuit_breaker_threshold=5,
        circuit_breaker_reset_ms=120000,  # 2 minutes reset
    ),
    "xai": ResilientProviderConfig(
        max_requests_per_minute=40,
        max_retries=3,
        base_delay_ms=1500,
        max_delay_ms=35000,
    ),
    "ollama": ResilientProviderConfig(
        max_requests_per_minute=100,
        max_retries=2,
        base_delay_ms=500,
        max_delay_ms=10000,
        enable_circuit_breaker=False,  # Local, less likely to need circuit breaker
    ),
}


def with_provider_resilience(
    provider: Any,
    provider_id: str,
    overrides: Optional[Dict[str, Any]] = None,
) -> ResilientProvider:
    """Wrap a provider with resilience using provider-specific defaults."""
    base_config = PROVIDER_RESILIENCE_CONFIGS.get(provider_id.lower())

    if base_config:
        # Apply overrides if provided
        if overrides:
            config_dict = {
                "max_requests_per_minute": base_config.max_requests_per_minute,
                "max_retries": base_config.max_retries,
                "base_delay_ms": base_config.base_delay_ms,
                "max_delay_ms": base_config.max_delay_ms,
                "enable_circuit_breaker": base_config.enable_circuit_breaker,
                "circuit_breaker_threshold": base_config.circuit_breaker_threshold,
                "circuit_breaker_reset_ms": base_config.circuit_breaker_reset_ms,
            }
            config_dict.update(overrides)
            config = ResilientProviderConfig(**config_dict)
        else:
            config = base_config
    else:
        config = ResilientProviderConfig(**(overrides or {}))

    return ResilientProvider(provider, config)
