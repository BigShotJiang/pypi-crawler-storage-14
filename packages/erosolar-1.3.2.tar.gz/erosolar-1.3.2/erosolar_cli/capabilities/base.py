"""
Base capability module for placeholder suites.
"""
from __future__ import annotations

from ..core.tool_runtime import ToolSuite


def create_placeholder_suite(suite_id: str, name: str) -> ToolSuite:
    """Create a placeholder tool suite."""
    return ToolSuite(
        id=suite_id,
        description=f"Placeholder suite for {name}",
        tools=[],
    )