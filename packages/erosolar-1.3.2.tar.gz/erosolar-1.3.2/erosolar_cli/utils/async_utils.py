"""
Async Utilities Module

Production-ready async patterns for rate limiting, throttling,
concurrency control, and caching with TTL.

Principal Investigator: Bo Shang
Framework: erosolar-py
"""

from __future__ import annotations

import asyncio
import functools
import time
from dataclasses import dataclass, field
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    TypeVar,
    Union,
)

# ============================================================================
# Types
# ============================================================================

T = TypeVar("T")
K = TypeVar("K")
V = TypeVar("V")
R = TypeVar("R")


@dataclass
class RateLimiterConfig:
    max_requests: int
    window_ms: float


@dataclass
class ThrottleConfig:
    interval_ms: float
    leading: bool = True
    trailing: bool = True


@dataclass
class CacheConfig:
    ttl_ms: float
    max_size: Optional[int] = None


@dataclass
class ConcurrencyConfig:
    max_concurrent: int
    timeout: Optional[float] = None


@dataclass
class CacheEntry(Generic[V]):
    value: V
    expires_at: float


# ============================================================================
# Rate Limiter (Token Bucket)
# ============================================================================


class RateLimiter:
    """Token bucket rate limiter for controlling request rates."""

    def __init__(
        self,
        config: Optional[RateLimiterConfig] = None,
        *,
        max_requests: Optional[int] = None,
        window_seconds: Optional[float] = None,
    ):
        """
        Initialize rate limiter.

        Can be initialized either with a RateLimiterConfig or with keyword arguments.

        Args:
            config: RateLimiterConfig instance
            max_requests: Maximum requests per window (alternative to config)
            window_seconds: Window duration in seconds (alternative to config)
        """
        if config:
            self._max_tokens = config.max_requests
            window_ms = config.window_ms
        elif max_requests is not None and window_seconds is not None:
            self._max_tokens = max_requests
            window_ms = window_seconds * 1000
        else:
            raise ValueError("Must provide either config or max_requests and window_seconds")

        self._tokens = float(self._max_tokens)
        self._refill_rate = self._max_tokens / window_ms
        self._last_refill = time.time() * 1000

    def _refill(self) -> None:
        now = time.time() * 1000
        elapsed = now - self._last_refill
        tokens_to_add = elapsed * self._refill_rate
        self._tokens = min(self._max_tokens, self._tokens + tokens_to_add)
        self._last_refill = now

    async def acquire(self) -> None:
        """Acquire a token, waiting if necessary."""
        self._refill()

        if self._tokens >= 1:
            self._tokens -= 1
            return

        # Wait for a token to become available
        wait_time = (1 - self._tokens) / self._refill_rate
        await asyncio.sleep(wait_time / 1000)  # Convert to seconds
        self._refill()
        self._tokens -= 1

    def try_acquire(self) -> bool:
        """Try to acquire a token without waiting."""
        self._refill()
        if self._tokens >= 1:
            self._tokens -= 1
            return True
        return False

    @property
    def available_tokens(self) -> int:
        self._refill()
        return int(self._tokens)


# ============================================================================
# Throttle & Debounce
# ============================================================================


def throttle(
    fn: Callable[..., T],
    config: ThrottleConfig,
) -> Callable[..., Optional[T]]:
    """Throttle function calls to at most once per interval."""
    last_call = 0.0
    last_result: Optional[T] = None
    pending_call: Optional[asyncio.TimerHandle] = None
    pending_args: Optional[tuple] = None
    pending_kwargs: Optional[dict] = None

    interval_s = config.interval_ms / 1000

    def throttled(*args: Any, **kwargs: Any) -> Optional[T]:
        nonlocal last_call, last_result, pending_call, pending_args, pending_kwargs

        now = time.time()
        elapsed = now - last_call

        if elapsed >= interval_s:
            if config.leading or last_call != 0:
                last_call = now
                last_result = fn(*args, **kwargs)
                return last_result

        if config.trailing:
            pending_args = args
            pending_kwargs = kwargs

            if pending_call is None:

                def trailing_call() -> None:
                    nonlocal last_call, last_result, pending_call, pending_args, pending_kwargs
                    if pending_args is not None:
                        last_call = time.time()
                        last_result = fn(*pending_args, **(pending_kwargs or {}))
                        pending_args = None
                        pending_kwargs = None
                    pending_call = None

                loop = asyncio.get_event_loop()
                pending_call = loop.call_later(interval_s - elapsed, trailing_call)

        return last_result

    return throttled


def debounce(
    fn: Callable[..., T],
    delay_ms: float,
) -> Callable[..., None]:
    """Debounce function calls, only executing after delay with no new calls."""
    pending_call: Optional[asyncio.TimerHandle] = None

    delay_s = delay_ms / 1000

    def debounced(*args: Any, **kwargs: Any) -> None:
        nonlocal pending_call

        if pending_call is not None:
            pending_call.cancel()

        loop = asyncio.get_event_loop()
        pending_call = loop.call_later(delay_s, lambda: fn(*args, **kwargs))

    return debounced


# ============================================================================
# TTL Cache
# ============================================================================


class TTLCache(Generic[K, V]):
    """Cache with time-to-live expiration and optional size limit."""

    def __init__(self, config: CacheConfig):
        self._cache: Dict[K, CacheEntry[V]] = {}
        self._ttl_ms = config.ttl_ms
        self._max_size = config.max_size

    def get(self, key: K) -> Optional[V]:
        entry = self._cache.get(key)
        if entry is None:
            return None

        if time.time() * 1000 > entry.expires_at:
            del self._cache[key]
            return None

        return entry.value

    def set(self, key: K, value: V, ttl_ms: Optional[float] = None) -> None:
        # Evict oldest if at capacity
        if (
            self._max_size is not None
            and len(self._cache) >= self._max_size
            and key not in self._cache
        ):
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]

        self._cache[key] = CacheEntry(
            value=value,
            expires_at=time.time() * 1000 + (ttl_ms or self._ttl_ms),
        )

    def has(self, key: K) -> bool:
        return self.get(key) is not None

    def delete(self, key: K) -> bool:
        if key in self._cache:
            del self._cache[key]
            return True
        return False

    def clear(self) -> None:
        self._cache.clear()

    @property
    def size(self) -> int:
        self._prune()
        return len(self._cache)

    def _prune(self) -> None:
        now = time.time() * 1000
        keys_to_delete = [k for k, v in self._cache.items() if now > v.expires_at]
        for key in keys_to_delete:
            del self._cache[key]


# ============================================================================
# Memoize with TTL
# ============================================================================


def memoize(
    ttl_ms: float,
    max_size: Optional[int] = None,
    key_fn: Optional[Callable[..., str]] = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator to memoize function results with TTL."""

    def decorator(fn: Callable[..., T]) -> Callable[..., T]:
        cache: TTLCache[str, T] = TTLCache(CacheConfig(ttl_ms=ttl_ms, max_size=max_size))

        @functools.wraps(fn)
        def memoized(*args: Any, **kwargs: Any) -> T:
            if key_fn:
                key = key_fn(*args, **kwargs)
            else:
                key = str((args, tuple(sorted(kwargs.items()))))

            cached = cache.get(key)
            if cached is not None:
                return cached

            result = fn(*args, **kwargs)
            cache.set(key, result)
            return result

        return memoized

    return decorator


# ============================================================================
# Concurrency Pool
# ============================================================================


class ConcurrencyPool:
    """Limit concurrent execution of async functions."""

    def __init__(self, config: ConcurrencyConfig):
        self._semaphore = asyncio.Semaphore(config.max_concurrent)
        self._timeout = config.timeout
        self._pending = 0
        self._active = 0

    async def run(self, fn: Callable[[], Awaitable[T]]) -> T:
        """Run function with concurrency limit."""
        self._pending += 1
        try:
            async with self._semaphore:
                self._pending -= 1
                self._active += 1
                try:
                    if self._timeout:
                        return await with_timeout(fn(), self._timeout)
                    return await fn()
                finally:
                    self._active -= 1
        except Exception:
            self._pending -= 1
            raise

    @property
    def pending(self) -> int:
        return self._pending

    @property
    def active(self) -> int:
        return self._active


# ============================================================================
# Parallel Map with Concurrency Limit
# ============================================================================


async def parallel_map(
    items: List[T],
    fn: Callable[[T, int], Awaitable[R]],
    concurrency: int = 5,
) -> List[R]:
    """Map items through async function with concurrency limit."""
    pool = ConcurrencyPool(ConcurrencyConfig(max_concurrent=concurrency))
    return await asyncio.gather(
        *[pool.run(lambda i=i, idx=idx: fn(i, idx)) for idx, i in enumerate(items)]
    )


# ============================================================================
# Utility Functions
# ============================================================================


async def sleep(ms: float) -> None:
    """Sleep for specified milliseconds."""
    await asyncio.sleep(ms / 1000)


async def with_timeout(
    coro: Awaitable[T],
    timeout_ms: float,
    error_message: str = "Operation timed out",
) -> T:
    """Execute coroutine with timeout."""
    try:
        return await asyncio.wait_for(coro, timeout=timeout_ms / 1000)
    except asyncio.TimeoutError:
        raise TimeoutError(error_message) from None


async def retry(
    fn: Callable[[], Awaitable[T]],
    max_retries: int = 3,
    base_delay_ms: float = 1000,
    max_delay_ms: float = 30000,
    backoff_multiplier: float = 2,
    should_retry: Optional[Callable[[Exception], bool]] = None,
) -> T:
    """Retry async function with exponential backoff."""
    last_error: Optional[Exception] = None

    for attempt in range(max_retries + 1):
        try:
            return await fn()
        except Exception as e:
            last_error = e

            if attempt == max_retries:
                raise

            if should_retry and not should_retry(e):
                raise

            delay = min(
                base_delay_ms * (backoff_multiplier**attempt),
                max_delay_ms,
            )
            await sleep(delay)

    raise last_error or RuntimeError("Retry failed unexpectedly")


# Alias for retry function
retry_with_backoff = retry


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Types
    "RateLimiterConfig",
    "ThrottleConfig",
    "CacheConfig",
    "ConcurrencyConfig",
    "CacheEntry",
    # Classes
    "RateLimiter",
    "TTLCache",
    "ConcurrencyPool",
    # Functions
    "throttle",
    "debounce",
    "memoize",
    "parallel_map",
    "sleep",
    "with_timeout",
    "retry",
    "retry_with_backoff",
]
