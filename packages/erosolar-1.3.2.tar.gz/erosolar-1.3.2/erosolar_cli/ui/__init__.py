"""UI module for terminal display with Rich formatting."""

from .display import Display
from .unified import UnifiedUILayer, unified_ui

# Backwards-compatible export so existing imports continue to work.
display = unified_ui

__all__ = ["Display", "UnifiedUILayer", "unified_ui", "display"]
