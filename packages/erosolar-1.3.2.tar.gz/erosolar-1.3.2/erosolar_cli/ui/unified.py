"""
Unified UI Layer for the Python CLI.

Provides a single façade over the display system with lightweight telemetry
tracking so both the TypeScript and Python CLIs follow the same unified UI
contract.
"""

from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Any, Dict, Optional

from .display import Display, display as base_display


@dataclass
class TelemetrySnapshot:
    """Snapshot of UI telemetry data."""

    events: list[dict[str, Any]]
    timers: dict[str, float]
    errors: list[str]


class UnifiedUILayer:
    """
    Unified UI façade for the Python CLI.

    Delegates rendering to the shared Display instance while keeping concise
    telemetry about UI activity for diagnostics and parity with the TS layer.
    """

    def __init__(self, display: Display = base_display, enable_telemetry: bool = True) -> None:
        self.display = display
        self.enable_telemetry = enable_telemetry
        self._events: list[dict[str, Any]] = []
        self._errors: list[str] = []
        self._timers: dict[str, float] = {}

    def __getattr__(self, name: str):
        # Delegate unknown attributes to the underlying display for compatibility.
        return getattr(self.display, name)

    def record_event(self, event: str, data: Optional[dict[str, Any]] = None) -> None:
        if not self.enable_telemetry:
            return
        self._events.append({"event": event, "data": data or {}, "timestamp": perf_counter()})

    def record_error(self, error: Exception | str) -> None:
        message = str(error)
        self._errors.append(message)
        self.record_event("ui.error", {"message": message})

    def telemetry_snapshot(self) -> TelemetrySnapshot:
        return TelemetrySnapshot(
            events=list(self._events),
            timers=dict(self._timers),
            errors=list(self._errors),
        )

    def start_processing(self, message: str = "Working on your request") -> None:
        self.record_event("processing.start", {"message": message})
        self.display.show_thinking(message)

    def end_processing(self, message: str = "Ready for prompts") -> None:
        self.record_event("processing.end", {"message": message})
        self.display.stop_thinking()
        self.display.show_info(message)

    def tool_started(self, name: str, args: Optional[Dict[str, Any]] = None) -> None:
        self.record_event("tool.start", {"tool": name, "args": args or {}})
        self.display.show_tool_call(name, args or {})

    def tool_finished(self, name: str, output: str, success: bool = True) -> None:
        self.record_event("tool.complete", {"tool": name, "success": success})
        self.display.show_tool_result(name, output, success=success)

    def tool_failed(self, name: str, error: Exception | str) -> None:
        self.record_error(error)
        self.display.show_tool_result(name, str(error), success=False)

    def mark_start(self, name: str) -> None:
        if not self.enable_telemetry:
            return
        self._timers[name] = perf_counter()

    def mark_end(self, name: str) -> Optional[float]:
        if not self.enable_telemetry:
            return None
        start = self._timers.pop(name, None)
        if start is None:
            return None
        duration = perf_counter() - start
        self.record_event("timer", {"name": name, "duration": duration})
        return duration


unified_ui = UnifiedUILayer()
