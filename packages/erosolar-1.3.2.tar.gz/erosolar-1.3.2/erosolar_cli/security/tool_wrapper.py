"""
Tool Security Wrapper

Wraps tool execution with active stack security validation.
Ensures all operations are scoped to the active stack only.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

from typing import Any, Callable, Coroutine, Dict, Optional

from .active_security import active_stack_security
from .types import SecuritySeverity, SecurityValidationResult


class SecurityError(Exception):
    """Security validation error."""

    def __init__(self, message: str, validation_result: SecurityValidationResult) -> None:
        super().__init__(message)
        self.validation_result = validation_result


class ToolSecurityWrapper:
    """
    Tool security wrapper.

    Wraps tool execution with security validation to ensure
    all operations are within the active stack scope.
    """

    def __init__(
        self,
        tool_executor: Optional[Callable[[str, Dict[str, Any]], Coroutine[Any, Any, Any]]] = None,
    ) -> None:
        """
        Initialize tool security wrapper.

        Args:
            tool_executor: Optional tool execution function
        """
        self._tool_executor = tool_executor

    async def execute_tool(
        self,
        tool_name: str,
        args: Dict[str, Any],
    ) -> Any:
        """
        Execute a tool with security validation.

        Args:
            tool_name: Name of the tool
            args: Tool arguments

        Returns:
            Tool execution result

        Raises:
            SecurityError: If validation fails
        """
        # Validate the tool operation
        validation = self.validate_tool_operation(tool_name, args)
        if not validation.allowed:
            raise SecurityError(
                f"Tool execution blocked: {validation.reason}",
                validation,
            )

        # Execute the tool
        return await self._execute_tool_internal(tool_name, args)

    def validate_tool_operation(
        self,
        tool_name: str,
        args: Dict[str, Any],
    ) -> SecurityValidationResult:
        """
        Validate tool operation based on tool type and arguments.

        Args:
            tool_name: Name of the tool
            args: Tool arguments

        Returns:
            Security validation result
        """
        # File operations
        if tool_name in ("read_file", "Edit", "list_files", "search_files"):
            return self._validate_file_operation(tool_name, args)

        # Command execution
        if tool_name in ("execute_bash", "execute_bash_stream"):
            return self._validate_command_execution(args)

        # Network operations
        if tool_name in ("WebFetch", "WebExtract", "WebSearch"):
            return self._validate_network_operation(tool_name, args)

        # For unknown tools, apply generic validation
        return self._validate_generic_operation(args)

    def get_security_log(self):
        """Get security log from active stack security."""
        return active_stack_security.get_security_log()

    def clear_security_log(self):
        """Clear security log."""
        active_stack_security.clear_security_log()

    def _validate_file_operation(
        self,
        tool_name: str,
        args: Dict[str, Any],
    ) -> SecurityValidationResult:
        """Validate file operations."""
        path = args.get("path") or args.get("file_path")
        if not path:
            return SecurityValidationResult(
                allowed=False,
                reason="Missing file path",
                severity=SecuritySeverity.MEDIUM,
            )

        operation = "write" if tool_name == "Edit" else "read"
        return active_stack_security.validate_file_operation(path, operation)

    def _validate_command_execution(
        self,
        args: Dict[str, Any],
    ) -> SecurityValidationResult:
        """Validate command execution."""
        command = args.get("command")
        if not command:
            return SecurityValidationResult(
                allowed=False,
                reason="Missing command",
                severity=SecuritySeverity.MEDIUM,
            )

        return active_stack_security.validate_command_execution(command)

    def _validate_network_operation(
        self,
        tool_name: str,
        args: Dict[str, Any],
    ) -> SecurityValidationResult:
        """Validate network operations."""
        target: Optional[str] = None

        if tool_name in ("WebFetch", "WebExtract"):
            target = args.get("url")
        elif tool_name == "WebSearch":
            target = args.get("query")

        if not target:
            return SecurityValidationResult(
                allowed=False,
                reason="Missing target/query",
                severity=SecuritySeverity.MEDIUM,
            )

        operation_map = {
            "WebFetch": "fetch",
            "WebExtract": "extract",
            "WebSearch": "search",
        }
        operation = operation_map.get(tool_name, "fetch")
        return active_stack_security.validate_network_operation(target, operation)

    def _validate_generic_operation(
        self,
        args: Dict[str, Any],
    ) -> SecurityValidationResult:
        """Validate generic operations."""
        # Check for any file paths in arguments
        for key, value in args.items():
            if isinstance(value, str) and "/" in value:
                path_validation = active_stack_security.validate_file_operation(
                    value, "read"
                )
                if not path_validation.allowed:
                    return SecurityValidationResult(
                        allowed=False,
                        reason=f"Invalid file path in argument '{key}': {path_validation.reason}",
                        severity=path_validation.severity,
                        details=path_validation.details,
                    )

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    async def _execute_tool_internal(
        self,
        tool_name: str,
        args: Dict[str, Any],
    ) -> Any:
        """
        Internal tool execution.

        Args:
            tool_name: Name of the tool
            args: Tool arguments

        Returns:
            Tool execution result
        """
        if self._tool_executor:
            return await self._tool_executor(tool_name, args)

        # Placeholder implementation
        return {"success": True, "tool": tool_name, "args": args}


def create_secure_tool_runtime(
    tool_executor: Optional[Callable[[str, Dict[str, Any]], Coroutine[Any, Any, Any]]] = None,
) -> ToolSecurityWrapper:
    """
    Create a secure tool runtime wrapper.

    Args:
        tool_executor: Optional tool execution function

    Returns:
        ToolSecurityWrapper instance
    """
    return ToolSecurityWrapper(tool_executor)


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "ToolSecurityWrapper",
    "SecurityError",
    "create_secure_tool_runtime",
]
