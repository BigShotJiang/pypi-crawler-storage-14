"""
Security Types for Erosolar CLI

Defines security-related types, enums, and data classes.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional


# ============================================================================
# Enums
# ============================================================================

class AuthorizationScope(str, Enum):
    """Authorization scope types."""
    BUG_BOUNTY = "bug_bounty"
    PENTEST = "pentest"
    RED_TEAM = "red_team"
    CTF = "ctf"
    EDUCATIONAL = "educational"


class SecuritySeverity(str, Enum):
    """Security severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AuthorizationStatus(str, Enum):
    """Authorization status values."""
    AUTHORIZED = "authorized"
    PENDING = "pending"
    REVOKED = "revoked"


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class AuthorizationRecord:
    """Authorization record for security research."""
    authorization_type: str
    target_domain: str
    authorized_by: str
    scope_limitations: List[str]
    out_of_scope: List[str]
    authorization_date: str
    authorization_id: str
    status: AuthorizationStatus = AuthorizationStatus.AUTHORIZED
    expiration_date: Optional[str] = None


@dataclass
class SecurityValidationResult:
    """Result of security validation."""
    allowed: bool
    severity: SecuritySeverity
    reason: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


@dataclass
class SecurityEvent:
    """Security event log entry."""
    type: str
    severity: SecuritySeverity
    operation: str
    timestamp: datetime
    reason: str
    file_path: Optional[str] = None
    target: Optional[str] = None
    command: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


@dataclass
class VulnerabilityFinding:
    """Vulnerability finding from assessment."""
    id: str
    title: str
    severity: SecuritySeverity
    description: str
    affected_component: str
    remediation: str
    cvss_score: Optional[float] = None
    cve_id: Optional[str] = None
    discovered_at: datetime = field(default_factory=datetime.now)


@dataclass
class ReconResult:
    """Reconnaissance result."""
    target: str
    scan_type: str
    findings: List[Dict[str, Any]]
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ScopeValidationRequest:
    """Request for scope validation."""
    activity: str
    target: str


@dataclass
class ScopeValidationResult:
    """Result of scope validation."""
    activity: str
    target: str
    valid: bool
    scope_check: str
    reason: Optional[str] = None


# ============================================================================
# Configuration Types
# ============================================================================

@dataclass
class AllowedScopes:
    """Allowed scope configuration."""
    cwd: bool = True
    node_projects: bool = True
    git_repos: bool = True
    temp_dirs: bool = True


@dataclass
class BlockedOperations:
    """Blocked operations configuration."""
    system_files: bool = True
    unauthorized_networking: bool = True
    out_of_scope_files: bool = True
    privileged_ops: bool = True


@dataclass
class ValidationConfig:
    """Validation configuration."""
    workspace_context: bool = True
    path_validation: bool = True
    pattern_detection: bool = True
    security_logging: bool = True


@dataclass
class ActiveStackSecurityConfig:
    """Active stack security configuration."""
    enabled: bool = True
    allowed_scopes: AllowedScopes = field(default_factory=AllowedScopes)
    blocked_operations: BlockedOperations = field(default_factory=BlockedOperations)
    validation: ValidationConfig = field(default_factory=ValidationConfig)


@dataclass
class SecurityIntegrationConfig:
    """Security integration configuration."""
    enabled: bool = True
    logging: bool = True
    block_unauthorized: bool = True


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Enums
    "AuthorizationScope",
    "SecuritySeverity",
    "AuthorizationStatus",
    # Data Classes
    "AuthorizationRecord",
    "SecurityValidationResult",
    "SecurityEvent",
    "VulnerabilityFinding",
    "ReconResult",
    "ScopeValidationRequest",
    "ScopeValidationResult",
    # Configuration Types
    "AllowedScopes",
    "BlockedOperations",
    "ValidationConfig",
    "ActiveStackSecurityConfig",
    "SecurityIntegrationConfig",
]
