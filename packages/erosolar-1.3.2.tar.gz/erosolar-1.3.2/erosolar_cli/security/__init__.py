"""
Security Framework for Erosolar CLI

Provides comprehensive security validation, authorization management,
and tool execution wrapping for safe operations.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from .types import (
    AuthorizationScope,
    AuthorizationStatus,
    SecuritySeverity,
    AuthorizationRecord,
    SecurityValidationResult,
    SecurityEvent,
    VulnerabilityFinding,
    ReconResult,
    ScopeValidationRequest,
    ScopeValidationResult,
    ActiveStackSecurityConfig,
    SecurityIntegrationConfig,
)
from .active_security import ActiveStackSecurity, active_stack_security
from .tool_wrapper import ToolSecurityWrapper, SecurityError, create_secure_tool_runtime
from .authorization import SecurityAuthorizationEngine
from .integration import (
    SecurityIntegration,
    security_integration,
    initialize_security_integration,
    initialize_security,
    get_security_status,
)

__all__ = [
    # Types & Enums
    "AuthorizationScope",
    "AuthorizationStatus",
    "SecuritySeverity",
    "AuthorizationRecord",
    "SecurityValidationResult",
    "SecurityEvent",
    "VulnerabilityFinding",
    "ReconResult",
    "ScopeValidationRequest",
    "ScopeValidationResult",
    "ActiveStackSecurityConfig",
    "SecurityIntegrationConfig",
    # Classes
    "ActiveStackSecurity",
    "ToolSecurityWrapper",
    "SecurityError",
    "SecurityAuthorizationEngine",
    "SecurityIntegration",
    # Singletons
    "active_stack_security",
    "security_integration",
    # Functions
    "create_secure_tool_runtime",
    "initialize_security_integration",
    "initialize_security",
    "get_security_status",
]
