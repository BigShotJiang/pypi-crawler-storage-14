"""
Security Integration Module

Integrates active stack security with the Erosolar CLI tool runtime.
Provides hooks for security validation and monitoring.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from .active_security import active_stack_security
from .tool_wrapper import ToolSecurityWrapper, create_secure_tool_runtime
from .types import SecurityEvent, SecurityIntegrationConfig, SecuritySeverity


class SecurityIntegration:
    """
    Security Integration.

    Integrates active stack security with the existing Erosolar CLI tool runtime.
    """

    def __init__(self, config: Optional[SecurityIntegrationConfig] = None) -> None:
        """
        Initialize security integration.

        Args:
            config: Security integration configuration
        """
        self._config = config or SecurityIntegrationConfig()
        self._secure_tool_runtime: Optional[ToolSecurityWrapper] = None
        self._event_handlers: Dict[str, Callable[[SecurityEvent], None]] = {}

    @property
    def config(self) -> SecurityIntegrationConfig:
        """Get current configuration."""
        return self._config

    def initialize(self) -> None:
        """Initialize security integration."""
        if not self._config.enabled:
            return

        self._secure_tool_runtime = create_secure_tool_runtime()

    def get_secure_tool_runtime(self) -> Optional[ToolSecurityWrapper]:
        """Get secure tool runtime."""
        return self._secure_tool_runtime

    async def execute_tool(
        self,
        tool_name: str,
        args: Dict[str, Any],
    ) -> Any:
        """
        Execute tool with security validation.

        Args:
            tool_name: Name of the tool
            args: Tool arguments

        Returns:
            Tool execution result

        Raises:
            RuntimeError: If security integration not initialized
        """
        if not self._secure_tool_runtime:
            raise RuntimeError("Security integration not initialized")

        return await self._secure_tool_runtime.execute_tool(tool_name, args)

    def get_security_status(self) -> Dict[str, Any]:
        """
        Get security status.

        Returns:
            Security status dictionary
        """
        security_log = active_stack_security.get_security_log()

        return {
            "enabled": self._config.enabled,
            "logging": self._config.logging,
            "blocked_operations": len(security_log),
            "last_event": security_log[-1] if security_log else None,
            "summary": {
                "total_events": len(security_log),
                "critical_events": sum(
                    1 for e in security_log if e.severity == SecuritySeverity.CRITICAL
                ),
                "high_events": sum(
                    1 for e in security_log if e.severity == SecuritySeverity.HIGH
                ),
                "medium_events": sum(
                    1 for e in security_log if e.severity == SecuritySeverity.MEDIUM
                ),
            },
        }

    def clear_security_log(self) -> None:
        """Clear security log."""
        active_stack_security.clear_security_log()

    def generate_security_report(self) -> str:
        """
        Generate security report.

        Returns:
            Formatted security report string
        """
        status = self.get_security_status()
        last_event = status.get("last_event")

        report_lines = [
            "Erosolar CLI Security Report",
            "================================",
            f"Status: {'ENABLED' if status['enabled'] else 'DISABLED'}",
            f"Security Logging: {'ENABLED' if status['logging'] else 'DISABLED'}",
            f"Blocked Operations: {status['blocked_operations']}",
            "",
            "Security Events Summary:",
            f"  Total Events: {status['summary']['total_events']}",
            f"  Critical: {status['summary']['critical_events']}",
            f"  High: {status['summary']['high_events']}",
            f"  Medium: {status['summary']['medium_events']}",
            "",
            "Active Stack Security Rules:",
            "  - File operations restricted to current workspace",
            "  - System file access blocked",
            "  - Dangerous commands blocked",
            "  - Unauthorized networking blocked",
            "  - Suspicious patterns detected and logged",
            "",
            "Scope Validation:",
            "  - Current working directory only",
            "  - No external file system access",
            "  - No system directory access",
            "  - No privileged operations",
        ]

        if last_event:
            report_lines.extend([
                "",
                "Last Security Event:",
                f"  Type: {last_event.type}",
                f"  Severity: {last_event.severity.value}",
                f"  Operation: {last_event.operation}",
                f"  Reason: {last_event.reason}",
            ])
            if last_event.file_path:
                report_lines.append(f"  File: {last_event.file_path}")

        return "\n".join(report_lines)

    def register_event_handler(
        self,
        event_type: str,
        handler: Callable[[SecurityEvent], None],
    ) -> None:
        """
        Register an event handler.

        Args:
            event_type: Type of event to handle
            handler: Handler function
        """
        self._event_handlers[event_type] = handler

    def unregister_event_handler(self, event_type: str) -> None:
        """
        Unregister an event handler.

        Args:
            event_type: Type of event to unregister
        """
        self._event_handlers.pop(event_type, None)


# Global singleton instance
security_integration = SecurityIntegration()


def initialize_security_integration() -> None:
    """Initialize global security integration."""
    security_integration.initialize()


async def get_security_status() -> Dict[str, Any]:
    """Get security status from global integration."""
    return security_integration.get_security_status()


def initialize_security() -> None:
    """Initialize security module."""
    initialize_security_integration()


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "SecurityIntegration",
    "security_integration",
    "initialize_security_integration",
    "initialize_security",
    "get_security_status",
]
