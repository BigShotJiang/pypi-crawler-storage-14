"""
Security Authorization Engine

Manages authorization and scope validation for security research activities.
Ensures all security testing is properly authorized and within defined scope.

Principal Investigator: Bo Shang
Framework: erosolar-cli

LEGAL NOTICE:
All security research must be properly authorized and scoped.
Unauthorized security testing is illegal and unethical.
"""

from __future__ import annotations

import random
import string
import time
from typing import Dict, List, Optional

from .types import (
    AuthorizationRecord,
    AuthorizationScope,
    AuthorizationStatus,
    ScopeValidationRequest,
    ScopeValidationResult,
)


class SecurityAuthorizationEngine:
    """
    Security Authorization Engine.

    Manages authorization and scope validation for security research activities.
    """

    # Destructive activity keywords
    DESTRUCTIVE_KEYWORDS = [
        "delete", "drop", "remove", "truncate", "wipe", "erase",
        "destroy", "overwrite", "format", "shutdown", "reboot",
    ]

    def __init__(self) -> None:
        """Initialize authorization engine."""
        self._authorizations: Dict[str, AuthorizationRecord] = {}

    async def create_authorization(
        self,
        authorization_type: AuthorizationScope,
        target_domain: str,
        authorized_by: str,
        scope_limitations: Optional[List[str]] = None,
        out_of_scope: Optional[List[str]] = None,
        expiration_date: Optional[str] = None,
    ) -> AuthorizationRecord:
        """
        Create security research authorization.

        Args:
            authorization_type: Type of authorization
            target_domain: Target domain for research
            authorized_by: Who authorized the research
            scope_limitations: Limitations on scope
            out_of_scope: Activities that are out of scope
            expiration_date: When authorization expires

        Returns:
            Authorization record
        """
        from datetime import datetime

        authorization = AuthorizationRecord(
            authorization_type=authorization_type.value,
            target_domain=target_domain,
            authorized_by=authorized_by,
            scope_limitations=scope_limitations or [],
            out_of_scope=out_of_scope or [],
            authorization_date=datetime.now().isoformat(),
            expiration_date=expiration_date,
            status=AuthorizationStatus.AUTHORIZED,
            authorization_id=self._generate_authorization_id(),
        )

        self._authorizations[authorization.authorization_id] = authorization
        return authorization

    async def validate_scope(
        self,
        request: ScopeValidationRequest,
    ) -> ScopeValidationResult:
        """
        Validate if an activity is within authorized scope.

        Args:
            request: Scope validation request

        Returns:
            Scope validation result
        """
        from datetime import datetime

        # Find relevant authorization
        authorization = self._find_relevant_authorization(request.target)

        if not authorization:
            return ScopeValidationResult(
                activity=request.activity,
                target=request.target,
                valid=False,
                reason="No authorization found for target",
                scope_check="Manual validation required - no authorization record found",
            )

        # Check if authorization is still valid
        if authorization.expiration_date:
            expiration = datetime.fromisoformat(authorization.expiration_date)
            if expiration < datetime.now():
                return ScopeValidationResult(
                    activity=request.activity,
                    target=request.target,
                    valid=False,
                    reason="Authorization has expired",
                    scope_check="Authorization expired - renew authorization before proceeding",
                )

        # Check if activity is explicitly out of scope
        if self._is_activity_out_of_scope(request.activity, authorization.out_of_scope):
            return ScopeValidationResult(
                activity=request.activity,
                target=request.target,
                valid=False,
                reason="Activity is explicitly out of scope",
                scope_check="Activity prohibited - explicitly listed as out of scope",
            )

        # Check scope limitations
        scope_violation = self._check_scope_limitations(
            request.activity, authorization.scope_limitations
        )
        if scope_violation:
            return ScopeValidationResult(
                activity=request.activity,
                target=request.target,
                valid=False,
                reason=scope_violation,
                scope_check="Scope limitation violation - review authorization scope",
            )

        return ScopeValidationResult(
            activity=request.activity,
            target=request.target,
            valid=True,
            scope_check="Activity appears to be within authorized scope - proceed with caution",
        )

    def get_authorization(self, authorization_id: str) -> Optional[AuthorizationRecord]:
        """
        Get authorization by ID.

        Args:
            authorization_id: Authorization ID

        Returns:
            Authorization record or None
        """
        return self._authorizations.get(authorization_id)

    def list_authorizations(self) -> List[AuthorizationRecord]:
        """
        List all authorizations.

        Returns:
            List of authorization records
        """
        return list(self._authorizations.values())

    def revoke_authorization(self, authorization_id: str) -> bool:
        """
        Revoke authorization.

        Args:
            authorization_id: Authorization ID

        Returns:
            True if revoked, False if not found
        """
        authorization = self._authorizations.get(authorization_id)
        if authorization:
            authorization.status = AuthorizationStatus.REVOKED
            return True
        return False

    def _generate_authorization_id(self) -> str:
        """Generate unique authorization ID."""
        timestamp = int(time.time() * 1000)
        random_suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=9))
        return f"auth_{timestamp}_{random_suffix}"

    def _find_relevant_authorization(self, target: str) -> Optional[AuthorizationRecord]:
        """Find relevant authorization for target."""
        for authorization in self._authorizations.values():
            if authorization.status != AuthorizationStatus.AUTHORIZED:
                continue

            # Simple domain matching
            if (target in authorization.target_domain or
                authorization.target_domain in target or
                authorization.target_domain == "*"):
                return authorization

        return None

    def _is_activity_out_of_scope(
        self,
        activity: str,
        out_of_scope: List[str],
    ) -> bool:
        """Check if activity is out of scope."""
        activity_lower = activity.lower()
        for scope in out_of_scope:
            scope_lower = scope.lower()
            if activity_lower in scope_lower or scope_lower in activity_lower:
                return True
        return False

    def _check_scope_limitations(
        self,
        activity: str,
        scope_limitations: List[str],
    ) -> Optional[str]:
        """Check scope limitations."""
        activity_lower = activity.lower()

        for limitation in scope_limitations:
            limitation_lower = limitation.lower()

            # Check for common limitation patterns
            if "read-only" in limitation_lower and "write" in activity_lower:
                return "Write operations prohibited in read-only scope"

            if "non-destructive" in limitation_lower and self._is_destructive_activity(activity_lower):
                return "Destructive activities prohibited in non-destructive scope"

            if "production" in limitation_lower and "staging" in activity_lower:
                return "Staging environment activities prohibited in production-only scope"

        return None

    def _is_destructive_activity(self, activity: str) -> bool:
        """Check if activity is potentially destructive."""
        return any(keyword in activity for keyword in self.DESTRUCTIVE_KEYWORDS)


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "SecurityAuthorizationEngine",
]
