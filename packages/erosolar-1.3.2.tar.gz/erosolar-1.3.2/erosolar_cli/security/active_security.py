"""
Active Stack Security Module

Ensures Erosolar CLI only operates on the active stack and nothing else.
Implements strict security rules to prevent vulnerabilities and unauthorized operations.

Principal Investigator: Bo Shang
Framework: erosolar-cli

DISCLAIMER: This software is provided for security testing and defensive purposes only.
Users are solely responsible for ensuring their use complies with applicable laws.
"""

from __future__ import annotations

import os
import re
from datetime import datetime
from pathlib import Path
from typing import List, Literal, Optional, Pattern, Tuple

from .types import (
    ActiveStackSecurityConfig,
    SecurityEvent,
    SecuritySeverity,
    SecurityValidationResult,
)


class ActiveStackSecurity:
    """
    Active stack security implementation.

    Ensures all operations are scoped to the active stack only,
    with comprehensive security validation and logging.
    """

    # System directories that should never be accessed
    SYSTEM_DIRS = ["/etc", "/var", "/usr", "/bin", "/sbin", "/lib", "/sys", "/proc"]

    # System files that should never be accessed
    SYSTEM_FILES = [
        "/etc/passwd", "/etc/shadow", "/etc/hosts", "/etc/resolv.conf",
        "/etc/ssh/ssh_config", "/etc/ssh/sshd_config",
        "/var/log/", "/var/spool/", "/var/mail/",
        "/usr/bin/", "/usr/sbin/", "/usr/lib/",
    ]

    # Suspicious file patterns
    SUSPICIOUS_PATTERNS: List[Tuple[Pattern, SecuritySeverity, str]] = [
        (re.compile(r"\.(pem|key|env|secret|config)$", re.IGNORECASE),
         SecuritySeverity.HIGH, "Sensitive file extension"),
        (re.compile(r"(password|secret|token|api[_-]?key)", re.IGNORECASE),
         SecuritySeverity.MEDIUM, "Potential credential file"),
        (re.compile(r"\.(bashrc|bash_profile|zshrc|profile)$"),
         SecuritySeverity.MEDIUM, "Shell configuration file"),
        (re.compile(r"\.(git|ssh)/config$"),
         SecuritySeverity.MEDIUM, "Git/SSH configuration"),
    ]

    # Dangerous command patterns
    DANGEROUS_COMMANDS: List[Tuple[Pattern, SecuritySeverity, str]] = [
        (re.compile(r"rm\s+-rf"), SecuritySeverity.CRITICAL, "Recursive force delete"),
        (re.compile(r"chmod\s+[0-7]{3,4}\s+"), SecuritySeverity.HIGH, "File permission modification"),
        (re.compile(r"chown\s+\S+\s+"), SecuritySeverity.HIGH, "File ownership change"),
        (re.compile(r"dd\s+if=.*of="), SecuritySeverity.CRITICAL, "Disk cloning/destruction"),
        (re.compile(r"mkfs\."), SecuritySeverity.CRITICAL, "Filesystem creation"),
        (re.compile(r"fdisk\s+"), SecuritySeverity.CRITICAL, "Partition manipulation"),
        (re.compile(r"mount\s+"), SecuritySeverity.HIGH, "Filesystem mounting"),
        (re.compile(r"umount\s+"), SecuritySeverity.HIGH, "Filesystem unmounting"),
        (re.compile(r"passwd\s+"), SecuritySeverity.HIGH, "Password change"),
        (re.compile(r"useradd\s+"), SecuritySeverity.HIGH, "User creation"),
        (re.compile(r"userdel\s+"), SecuritySeverity.HIGH, "User deletion"),
    ]

    # Localhost patterns
    LOCALHOST_PATTERNS = ["localhost", "127.0.0.1", "::1", "0.0.0.0"]

    # Suspicious domains
    SUSPICIOUS_DOMAINS = ["malicious.com", "evil.org", "hacker.net"]

    def __init__(self, config: Optional[ActiveStackSecurityConfig] = None) -> None:
        """
        Initialize active stack security.

        Args:
            config: Security configuration
        """
        self._config = config or ActiveStackSecurityConfig()
        self._security_log: List[SecurityEvent] = []
        self._max_log_size = 1000

    @property
    def config(self) -> ActiveStackSecurityConfig:
        """Get current configuration."""
        return self._config

    def validate_file_operation(
        self,
        file_path: str,
        operation: Literal["read", "write", "delete"],
    ) -> SecurityValidationResult:
        """
        Validate a file operation.

        Args:
            file_path: Path to the file
            operation: Type of operation

        Returns:
            Security validation result
        """
        if not self._config.enabled:
            return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

        normalized_path = self._resolve_path(file_path)
        cwd = os.getcwd()

        # Check if path is within allowed scopes
        scope_check = self._validate_path_scope(normalized_path, cwd)
        if not scope_check.allowed:
            self._log_security_event(SecurityEvent(
                type="file_operation_blocked",
                severity=SecuritySeverity.HIGH,
                operation=operation,
                file_path=normalized_path,
                reason=scope_check.reason or "Unknown reason",
                timestamp=datetime.now(),
            ))
            return scope_check

        # Check for suspicious patterns
        pattern_check = self._detect_suspicious_patterns(normalized_path)
        if not pattern_check.allowed:
            self._log_security_event(SecurityEvent(
                type="suspicious_pattern_detected",
                severity=pattern_check.severity,
                operation=operation,
                file_path=normalized_path,
                reason=pattern_check.reason or "Unknown reason",
                timestamp=datetime.now(),
            ))
            return pattern_check

        # Check for system file protection
        system_check = self._validate_system_file_protection(normalized_path)
        if not system_check.allowed:
            self._log_security_event(SecurityEvent(
                type="system_file_protection",
                severity=system_check.severity,
                operation=operation,
                file_path=normalized_path,
                reason=system_check.reason or "Unknown reason",
                timestamp=datetime.now(),
            ))
            return system_check

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def validate_network_operation(
        self,
        target: str,
        operation: Literal["fetch", "search", "extract"],
    ) -> SecurityValidationResult:
        """
        Validate a network operation.

        Args:
            target: Target URL or domain
            operation: Type of operation

        Returns:
            Security validation result
        """
        if not self._config.enabled:
            return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

        # Check for localhost operations (allowed for development)
        if self._is_localhost(target):
            return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

        # Check for suspicious domains
        domain_check = self._validate_domain(target)
        if not domain_check.allowed:
            self._log_security_event(SecurityEvent(
                type="network_operation_blocked",
                severity=domain_check.severity,
                operation=operation,
                target=target,
                reason=domain_check.reason or "Unknown reason",
                timestamp=datetime.now(),
            ))
            return domain_check

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def validate_command_execution(self, command: str) -> SecurityValidationResult:
        """
        Validate a command execution.

        Args:
            command: Command to execute

        Returns:
            Security validation result
        """
        if not self._config.enabled:
            return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

        # Check for dangerous commands
        command_check = self._validate_command_safety(command)
        if not command_check.allowed:
            self._log_security_event(SecurityEvent(
                type="dangerous_command_blocked",
                severity=command_check.severity,
                operation="execute",
                command=command,
                reason=command_check.reason or "Unknown reason",
                timestamp=datetime.now(),
            ))
            return command_check

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def get_security_log(self) -> List[SecurityEvent]:
        """Get the security log."""
        return list(self._security_log)

    def clear_security_log(self) -> None:
        """Clear the security log."""
        self._security_log = []

    def _validate_path_scope(self, file_path: str, cwd: str) -> SecurityValidationResult:
        """Validate path is within allowed scope."""
        # Check if path is within current working directory
        if not file_path.startswith(cwd):
            return SecurityValidationResult(
                allowed=False,
                reason="File operation outside current working directory",
                severity=SecuritySeverity.HIGH,
                details={"file_path": file_path, "cwd": cwd},
            )

        # Check for node_modules protection
        if "node_modules" in file_path and f"{cwd}/node_modules" not in file_path:
            return SecurityValidationResult(
                allowed=False,
                reason="Access to external node_modules directory",
                severity=SecuritySeverity.HIGH,
                details={"file_path": file_path, "cwd": cwd},
            )

        # Check for system directory protection
        for sys_dir in self.SYSTEM_DIRS:
            if file_path.startswith(sys_dir):
                return SecurityValidationResult(
                    allowed=False,
                    reason="Access to system directory",
                    severity=SecuritySeverity.CRITICAL,
                    details={"file_path": file_path, "system_dir": sys_dir},
                )

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def _detect_suspicious_patterns(self, file_path: str) -> SecurityValidationResult:
        """Detect suspicious patterns in file path."""
        for pattern, severity, reason in self.SUSPICIOUS_PATTERNS:
            if pattern.search(file_path):
                return SecurityValidationResult(
                    allowed=False,
                    reason=f"{reason} detected",
                    severity=severity,
                    details={"file_path": file_path, "pattern": pattern.pattern},
                )

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def _validate_system_file_protection(self, file_path: str) -> SecurityValidationResult:
        """Validate system file protection."""
        for sys_file in self.SYSTEM_FILES:
            if file_path.startswith(sys_file):
                return SecurityValidationResult(
                    allowed=False,
                    reason="Access to system file",
                    severity=SecuritySeverity.CRITICAL,
                    details={"file_path": file_path, "system_file": sys_file},
                )

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def _is_localhost(self, target: str) -> bool:
        """Check if target is localhost."""
        return any(pattern in target for pattern in self.LOCALHOST_PATTERNS)

    def _validate_domain(self, target: str) -> SecurityValidationResult:
        """Validate domain is not suspicious."""
        for domain in self.SUSPICIOUS_DOMAINS:
            if domain in target:
                return SecurityValidationResult(
                    allowed=False,
                    reason="Suspicious domain detected",
                    severity=SecuritySeverity.HIGH,
                    details={"target": target, "domain": domain},
                )

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def _validate_command_safety(self, command: str) -> SecurityValidationResult:
        """Validate command is safe to execute."""
        for pattern, severity, reason in self.DANGEROUS_COMMANDS:
            if pattern.search(command):
                return SecurityValidationResult(
                    allowed=False,
                    reason=f"{reason} command detected",
                    severity=severity,
                    details={"command": command, "pattern": pattern.pattern},
                )

        return SecurityValidationResult(allowed=True, severity=SecuritySeverity.LOW)

    def _log_security_event(self, event: SecurityEvent) -> None:
        """Log a security event."""
        if not self._config.validation.security_logging:
            return

        self._security_log.append(event)

        # Keep log size manageable
        if len(self._security_log) > self._max_log_size:
            self._security_log = self._security_log[-self._max_log_size // 2:]

    def _resolve_path(self, file_path: str) -> str:
        """Resolve file path to absolute path."""
        if file_path.startswith("/"):
            return file_path
        return str(Path(os.getcwd()) / file_path)


# Global singleton instance
active_stack_security = ActiveStackSecurity()


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "ActiveStackSecurity",
    "active_stack_security",
]
