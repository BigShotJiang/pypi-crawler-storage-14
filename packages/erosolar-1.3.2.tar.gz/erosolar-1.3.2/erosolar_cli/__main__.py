"""
Erosolar CLI - Main entry point.

A full-featured AI coding assistant with file operations, code editing,
bash execution, pattern matching, and content search capabilities.

@license MIT
@author Bo Shang
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer

from .config import resolve_profile
from .core.agent import AgentOptions, AgentRuntime
from .core.context_manager import create_default_context_manager
from .core.tool_runtime import ToolExecutionContext, ToolSuite, create_default_tool_runtime
from .providers.provider_factory import create_provider
from .shell.interactive import launch_interactive_shell
from .runtime.session_store import (
    SaveSessionOptions,
    delete_session as delete_session_snapshot,
    list_sessions as list_saved_sessions,
    load_session_by_id,
    save_session_snapshot,
)
from .tools import bash_tools, edit_tools, file_tools, glob_tools, grep_tools
from .ui.unified import unified_ui as display
from .workspace import build_workspace_context, WorkspaceCaptureOptions

app = typer.Typer(
    name="erosolar",
    help="Erosolar CLI - AI coding assistant with tool access",
    add_completion=False,
)


@app.callback(invoke_without_command=True)
def callback(
    ctx: typer.Context,
    provider: str = typer.Option("auto", "--provider", "-p", help="LLM provider (auto, anthropic, openai, google)"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use (overrides provider default)"),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Working directory for file operations"),
    interactive: bool = typer.Option(True, "--interactive", "-i", help="Start interactive REPL shell (default: True)"),
    session_id: Optional[str] = typer.Option(None, "--session-id", help="Resume or save to a session id"),
    save_session: bool = typer.Option(False, "--save-session/--no-save-session", help="Persist the conversation to session history"),
    session_title: Optional[str] = typer.Option(None, "--session-title", help="Optional title when saving a session"),
    # Plugin flags
    enable_alpha_zero: bool = typer.Option(False, "--alpha-zero/--no-alpha-zero", help="Enable Alpha Zero 2 RL framework"),
    enable_coding: bool = typer.Option(False, "--coding/--no-coding", help="Enable enhanced coding tools"),
    enable_security: bool = typer.Option(False, "--security/--no-security", help="Enable security research tools (requires auth)"),
    enable_all_plugins: bool = typer.Option(False, "--all-plugins", help="Enable all optional plugins"),
) -> None:
    """
    Erosolar CLI - AI coding assistant with tool access.

    Launches an interactive REPL shell by default. Provide a prompt for single-command mode.

    CORE TOOLS (always available):
    - File operations (read, write, list)
    - Code editing (surgical string replacement)
    - Bash commands (with safety validation)
    - Glob (pattern matching)
    - Grep (content search)

    OPTIONAL PLUGINS:
    - --alpha-zero: Competitive RL for code optimization
    - --coding: Enhanced code analysis and refactoring
    - --security: Security research tools (requires authorization)

    Examples:
        erosolar                                    # Launch interactive shell (default)
        erosolar "List all Python files"           # Single command mode
        erosolar --alpha-zero                      # Interactive with Alpha Zero 2
        erosolar --all-plugins                     # Interactive with all plugins
    """
    # If a subcommand was invoked, let it handle everything
    if ctx.invoked_subcommand is not None:
        return

    # No subcommand and no prompt - launch interactive shell
    # Build list of enabled plugins
    enabled_plugins = []
    if enable_all_plugins or enable_alpha_zero:
        enabled_plugins.append("alpha_zero")
    if enable_all_plugins or enable_coding:
        enabled_plugins.append("coding")
    if enable_all_plugins or enable_security:
        enabled_plugins.append("security")

    # Launch interactive shell by default
    _run_main(
        None, provider, model, workspace, interactive,
        session_id, save_session, session_title, enabled_plugins
    )


@app.command("chat")
def chat_command(
    prompt: str = typer.Argument(..., help="User prompt to send to the AI assistant"),
    provider: str = typer.Option("auto", "--provider", "-p", help="LLM provider (auto, anthropic, openai, google)"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use (overrides provider default)"),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Working directory for file operations"),
    session_id: Optional[str] = typer.Option(None, "--session-id", help="Resume or save to a session id"),
    save_session: bool = typer.Option(False, "--save-session/--no-save-session", help="Persist the conversation to session history"),
    session_title: Optional[str] = typer.Option(None, "--session-title", help="Optional title when saving a session"),
    enable_alpha_zero: bool = typer.Option(False, "--alpha-zero/--no-alpha-zero", help="Enable Alpha Zero 2 RL framework"),
    enable_coding: bool = typer.Option(False, "--coding/--no-coding", help="Enable enhanced coding tools"),
    enable_security: bool = typer.Option(False, "--security/--no-security", help="Enable security research tools (requires auth)"),
    enable_all_plugins: bool = typer.Option(False, "--all-plugins", help="Enable all optional plugins"),
) -> None:
    """Send a single prompt to the AI assistant."""
    enabled_plugins = []
    if enable_all_plugins or enable_alpha_zero:
        enabled_plugins.append("alpha_zero")
    if enable_all_plugins or enable_coding:
        enabled_plugins.append("coding")
    if enable_all_plugins or enable_security:
        enabled_plugins.append("security")

    _run_main(
        prompt, provider, model, workspace, False,  # interactive=False for single command
        session_id, save_session, session_title, enabled_plugins
    )


def _run_main(
    prompt: Optional[str],
    provider: str,
    model: Optional[str],
    workspace: Optional[str],
    interactive: bool,
    session_id: Optional[str],
    save_session: bool,
    session_title: Optional[str],
    enabled_plugins: Optional[list] = None,
) -> None:
    """Execute the main CLI logic."""
    from typing import List
    enabled_plugins = enabled_plugins or []

    # Resolve working directory
    working_dir = Path(workspace).resolve() if workspace else Path.cwd()
    if not working_dir.exists():
        display.show_error(f"Workspace directory does not exist: {working_dir}")
        raise typer.Exit(1)

    # Show enabled plugins
    if enabled_plugins:
        display.show_info(f"Enabled plugins: {', '.join(enabled_plugins)}")

    # Launch interactive shell when no prompt is provided (default behavior)
    # or when --interactive/-i flag is explicitly set
    if not prompt or interactive:
        try:
            asyncio.run(launch_interactive_shell(
                working_dir=str(working_dir),
                profile="default",
                provider=provider,  # Pass through - auto-detection handled by resolve_profile
                model=model,
                session_id=session_id,
                session_title=session_title,
                autosave=save_session or bool(session_id),
                enabled_plugins=enabled_plugins,
            ))
        except KeyboardInterrupt:
            display.show_info("\nGoodbye!")
            raise typer.Exit(0)
        except Exception as error:
            display.show_error(f"{error}")
            raise typer.Exit(1)
        return

    # Run async main for single command
    try:
        asyncio.run(_async_main(
            prompt,
            provider,
            model,
            str(working_dir),
            session_id=session_id,
            save_session=save_session,
            session_title=session_title,
        ))
    except KeyboardInterrupt:
        display.show_warning("\n\nInterrupted by user")
        raise typer.Exit(130)
    except Exception as error:
        display.show_error(f"{error}")
        raise typer.Exit(1)


async def _async_main(
    prompt: str,
    provider_name: str,
    model: Optional[str],
    working_dir: str,
    session_id: Optional[str],
    save_session: bool,
    session_title: Optional[str],
) -> None:
    """
    Async main function that sets up and runs the agent.

    Args:
        prompt: User prompt
        provider_name: Provider name (anthropic, openai)
        model: Optional model override
        working_dir: Working directory for file operations
    """
    # Build workspace context
    workspace_context = build_workspace_context(
        working_dir,
        WorkspaceCaptureOptions(
            tree_depth=1,
            max_entries=30,
            doc_excerpt_limit=200,
        ),
    )

    # Resolve profile configuration
    try:
        profile = resolve_profile(
            name="default",
            workspace_context=workspace_context,
            provider_override=provider_name,  # Pass through - auto-detection handled by resolve_profile
            model_override=model,
        )
    except ValueError as error:
        display.show_error(str(error))
        raise typer.Exit(1)

    # Show welcome banner
    display.show_welcome(
        profile_label=profile.label,
        profile_name=profile.name,
        model=profile.model,
        provider=profile.provider,
        working_dir=working_dir,
        version="1.3.1",
    )

    # Create provider
    try:
        provider = create_provider(
            profile.provider,
            profile.model,
            max_tokens=profile.max_tokens,
            temperature=profile.temperature,
        )
    except ValueError as error:
        display.show_error(str(error))
        raise typer.Exit(1)

    # Create execution context
    context = ToolExecutionContext(
        profile_name=profile.name,
        provider=profile.provider,
        model=profile.model,
    )

    # Create context manager and tool runtime
    context_manager = create_default_context_manager()
    tool_runtime = create_default_tool_runtime(context)

    # Register all tool suites
    tool_runtime.register_suite(
        ToolSuite(
            id="file-ops",
            description="Read, write, list, and search files",
            tools=file_tools.create_file_tools(working_dir),
        )
    )

    tool_runtime.register_suite(
        ToolSuite(
            id="edit-ops",
            description="Surgical string replacement in files",
            tools=edit_tools.create_edit_tools(working_dir),
        )
    )

    tool_runtime.register_suite(
        ToolSuite(
            id="bash-ops",
            description="Execute bash commands with safety validation",
            tools=bash_tools.create_bash_tools(working_dir),
        )
    )

    tool_runtime.register_suite(
        ToolSuite(
            id="glob-ops",
            description="Fast file pattern matching",
            tools=glob_tools.create_glob_tools(working_dir),
        )
    )

    tool_runtime.register_suite(
        ToolSuite(
            id="grep-ops",
            description="Powerful regex content search",
            tools=grep_tools.create_grep_tools(working_dir),
        )
    )

    # Create agent runtime
    agent = AgentRuntime(
        AgentOptions(
            provider=provider,
            tool_runtime=tool_runtime,
            system_prompt=profile.system_prompt,
            context_manager=context_manager,
        )
    )

    # Optionally resume a saved session
    loaded_history = None
    if session_id:
        stored = load_session_by_id(session_id)
        if stored:
            loaded_history = stored.messages
            display.show_info(f"Resumed session {session_id} ({stored.title})")
        else:
            display.show_warning(f"No session found for id '{session_id}', starting a new conversation.")

    if loaded_history:
        agent.load_history(loaded_history)

    # Show user prompt
    display.show_action(f"Prompt: {prompt}", status="info")

    # Show thinking indicator
    display.show_thinking("✨ Erosolaring...")

    try:
        response = await agent.send(prompt)

        # Stop thinking
        display.stop_thinking()

        # Display response
        display.show_assistant_message(response)

        if save_session or session_id:
            summary = save_session_snapshot(
                SaveSessionOptions(
                    id=session_id,
                    title=session_title,
                    profile=profile.name,
                    provider=profile.provider,
                    model=profile.model,
                    workspace_root=working_dir,
                    messages=agent.get_history(),
                )
            )
            display.show_info(f"Session saved: {summary.id} — {summary.title}")
    except Exception as error:
        display.stop_thinking()
        display.show_error(f"Failed to get response: {error}")
        raise


@app.command("version")
def show_version_command(
    full: bool = typer.Option(False, "--full", "-f", help="Show full version details"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show CLI version information."""
    import json
    from .core.version_manager import (
        VersionManager, get_cli_version, get_component_versions, get_tool_versions
    )
    from .plugins import registry, load_builtin_plugins

    cli_version = get_cli_version()

    if json_output:
        components = get_component_versions()
        tools = get_tool_versions()
        payload = {
            "cliVersion": str(cli_version),
            "components": {
                k: {
                    "version": str(v.version),
                    "description": v.description,
                    "status": v.status,
                    "upgradeable": v.upgradeable,
                    "dependencies": v.dependencies,
                }
                for k, v in components.items()
            },
            "tools": {
                k: {"version": str(v.version), "status": v.status}
                for k, v in tools.items()
            },
        }

        # Add plugins
        load_builtin_plugins()
        plugins = registry.list_available()
        payload["plugins"] = {
            p.id: {
                "version": p.version,
                "description": p.description,
                "category": p.category.value,
            }
            for p in plugins
        }

        display.show_info(json.dumps(payload, indent=2))
        return

    display.show_info(f"erosolar version {cli_version}")
    display.show_info("")
    display.show_info("Unified AI Agent Framework")
    display.show_info("Author: Bo Shang")
    display.show_info("")

    if full:
        # Show component versions
        components = get_component_versions()
        if components:
            display.show_info("Components:")
            display.show_info("-" * 40)
            for comp_id, comp in components.items():
                deps = f" (deps: {', '.join(comp.dependencies)})" if comp.dependencies else ""
                display.show_info(f"  {comp_id}: v{comp.version} [{comp.status}]{deps}")
            display.show_info("")

        # Show tool versions
        tools = get_tool_versions()
        if tools:
            stable = [t for t in tools.values() if t.status == "stable"]
            beta = [t for t in tools.values() if t.status == "beta"]
            alpha = [t for t in tools.values() if t.status == "alpha"]

            display.show_info("Tools:")
            display.show_info("-" * 40)
            if stable:
                display.show_info("  Stable:")
                for t in stable:
                    display.show_info(f"    {t.tool_id}: v{t.version}")
            if beta:
                display.show_info("  Beta:")
                for t in beta:
                    display.show_info(f"    {t.tool_id}: v{t.version}")
            if alpha:
                display.show_info("  Alpha:")
                for t in alpha:
                    display.show_info(f"    {t.tool_id}: v{t.version}")
            display.show_info("")

        # Show plugins
        load_builtin_plugins()
        plugins = registry.list_available()
        if plugins:
            display.show_info("Plugins:")
            display.show_info("-" * 40)
            for p in plugins:
                compat, _ = p.is_compatible_with_cli()
                status = "✓" if compat else "✗"
                display.show_info(f"  {status} {p.id}: v{p.version} [{p.category.value}]")


@app.command("sessions")
def list_sessions_command(
    profile: Optional[str] = typer.Option(None, "--profile", "-p", help="Filter saved sessions by profile"),
) -> None:
    """List saved session snapshots."""
    summaries = list_saved_sessions(profile)
    if not summaries:
        display.show_info("No saved sessions found.")
        return

    for summary in summaries:
        workspace = f" [{summary.workspace_root}]" if summary.workspace_root else ""
        display.show_info(
            f"{summary.id}  {summary.updated_at}  {summary.title} "
            f"({summary.provider}/{summary.model}, messages={summary.message_count}){workspace}"
        )


@app.command("delete-session")
def delete_session_command(
    session_id: str = typer.Argument(..., help="Session id to delete"),
) -> None:
    """Delete a saved session snapshot."""
    if delete_session_snapshot(session_id):
        display.show_info(f"Deleted session {session_id}")
    else:
        display.show_warning(f"No session found for id '{session_id}'")


# Alpha Zero 2 subcommands
alpha_zero_app = typer.Typer(
    name="alpha-zero",
    help="Alpha Zero 2 - Competitive multi-agent RL for code optimization",
    add_completion=False,
)
app.add_typer(alpha_zero_app, name="alpha-zero")


@alpha_zero_app.command("tournament")
def run_alpha_zero_tournament(
    tasks_file: Optional[Path] = typer.Option(None, "--tasks", "-t", exists=True, help="JSON file with task prompts"),
    task: Optional[str] = typer.Option(None, "--task", help="Single task prompt for quick tournament"),
    rounds: int = typer.Option(5, "--rounds", "-r", help="Number of competition rounds"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose logging"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
    workspace: Optional[Path] = typer.Option(None, "--workspace", "-w", help="Working directory for tournament data"),
) -> None:
    """Run an Alpha Zero 2 competitive tournament between two agents."""
    import json as json_lib

    # Resolve tasks
    task_prompts: list[str] = []
    if tasks_file:
        with open(tasks_file) as f:
            data = json_lib.load(f)
            task_prompts = data.get("tasks", data) if isinstance(data, dict) else data
    elif task:
        task_prompts = [task]
    else:
        # Default code optimization tasks
        task_prompts = [
            "Write a function to find all prime numbers up to n using the Sieve of Eratosthenes",
            "Implement a function to merge two sorted lists efficiently",
            "Write a binary search function with proper edge case handling",
            "Implement a function to detect cycles in a linked list",
            "Write a function to find the longest common subsequence of two strings",
        ]

    working_dir = Path(workspace).resolve() if workspace else Path.cwd()

    display.show_action("Alpha Zero 2 Tournament", status="info")
    display.show_info(f"Tasks: {len(task_prompts)}")
    display.show_info(f"Rounds: {rounds}")
    display.show_info("")

    async def run():
        from .capabilities.alpha_zero import create_capability_suite
        suite = create_capability_suite(str(working_dir))

        # Find and call the tournament tool
        for tool in suite.tools:
            if tool.name == "alpha_zero_tournament":
                result = await tool.handler(
                    task_prompts=task_prompts,
                    num_rounds=rounds,
                    verbose=verbose,
                )
                return result
        return {"error": "Tournament tool not found"}

    try:
        display.show_thinking("Running tournament...")
        result = asyncio.run(run())
        display.stop_thinking()

        if json_output:
            display.show_info(json_lib.dumps(result, indent=2))
        else:
            display.show_info("")
            display.show_info("=" * 50)
            display.show_info("TOURNAMENT RESULTS")
            display.show_info("=" * 50)
            display.show_info(f"Total Rounds: {result.get('total_rounds', 0)}")
            display.show_info(f"Agent 1 Wins: {result.get('agent1_wins', 0)} ({result.get('agent1_win_rate', 0):.1%})")
            display.show_info(f"Agent 2 Wins: {result.get('agent2_wins', 0)} ({result.get('agent2_win_rate', 0):.1%})")
            display.show_info("")

            for r in result.get("rounds", []):
                winner = r.get("winner", "tie")
                icon = "=" if winner == "tie" else ("1" if winner == "agent1" else "2")
                display.show_info(
                    f"  Round {r['round']}: Agent1={r['agent1_score']:.1f} vs Agent2={r['agent2_score']:.1f} [{icon}]"
                )

    except Exception as e:
        display.stop_thinking()
        display.show_error(f"Tournament failed: {e}")
        raise typer.Exit(code=1)


@alpha_zero_app.command("evaluate")
def evaluate_code_command(
    code_file: Optional[Path] = typer.Argument(None, exists=True, help="Python file to evaluate"),
    code: Optional[str] = typer.Option(None, "--code", "-c", help="Inline code to evaluate"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """Evaluate code quality using Alpha Zero 2 metrics."""
    import json as json_lib

    if code_file:
        code_content = code_file.read_text()
    elif code:
        code_content = code
    else:
        display.show_error("Either a code file or --code must be provided")
        raise typer.Exit(code=1)

    async def run():
        from .capabilities.alpha_zero import create_capability_suite
        suite = create_capability_suite(".")

        for tool in suite.tools:
            if tool.name == "alpha_zero_evaluate":
                return await tool.handler(code=code_content)
        return {"error": "Evaluate tool not found"}

    try:
        display.show_thinking("Evaluating code...")
        result = asyncio.run(run())
        display.stop_thinking()

        if json_output:
            # Remove summary for JSON output (it's formatted text)
            output = {k: v for k, v in result.items() if k != "summary"}
            display.show_info(json_lib.dumps(output, indent=2))
        else:
            display.show_info(result.get("summary", ""))

    except Exception as e:
        display.stop_thinking()
        display.show_error(f"Evaluation failed: {e}")
        raise typer.Exit(code=1)


@alpha_zero_app.command("history")
def show_competition_history(
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """Show historical competition data from previous tournaments."""
    import json as json_lib

    async def run():
        from .capabilities.alpha_zero import create_capability_suite
        suite = create_capability_suite(".")

        for tool in suite.tools:
            if tool.name == "alpha_zero_history":
                return await tool.handler()
        return {"error": "History tool not found"}

    try:
        result = asyncio.run(run())

        if json_output:
            display.show_info(json_lib.dumps(result, indent=2))
        elif not result.get("has_history"):
            display.show_info(result.get("message", "No competition history found"))
        else:
            display.show_info("Competition History")
            display.show_info("=" * 40)
            display.show_info(f"Total Rounds: {result.get('total_rounds', 0)}")
            display.show_info(f"Agent 1 Win Rate: {result.get('agent1_win_rate', 0):.1%}")
            display.show_info(f"Agent 2 Win Rate: {result.get('agent2_win_rate', 0):.1%}")

    except Exception as e:
        display.show_error(f"Failed to load history: {e}")
        raise typer.Exit(code=1)


# Providers subcommands
providers_app = typer.Typer(
    name="providers",
    help="Unified AI provider management",
    add_completion=False,
)
app.add_typer(providers_app, name="providers")


@providers_app.command("list")
def list_providers_command(
    configured: bool = typer.Option(False, "--configured", "-c", help="Only show configured providers"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List available AI providers."""
    import json as json_lib
    from .providers import get_supported_providers, get_configured_providers, get_provider_info

    if configured:
        provider_ids = get_configured_providers()
    else:
        provider_ids = get_supported_providers()

    if json_output:
        providers_info = []
        for pid in provider_ids:
            config = get_provider_info(pid)
            if config:
                providers_info.append({
                    "id": config.id,
                    "label": config.label,
                    "default_model": config.default_model,
                    "openai_compatible": config.openai_compatible,
                })
        display.show_info(json_lib.dumps(providers_info, indent=2))
    else:
        configured_list = get_configured_providers()
        display.show_info("Available Providers:")
        display.show_info("-" * 50)
        for pid in provider_ids:
            config = get_provider_info(pid)
            if config:
                status = " [configured]" if pid in configured_list else ""
                display.show_info(f"  {config.id}: {config.label}{status}")
                display.show_info(f"    Default model: {config.default_model}")


@providers_app.command("detect")
def detect_providers_command(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Detect configured providers and show auto-selected default."""
    import json as json_lib
    from .providers import get_configured_providers, auto_select_provider

    try:
        auto_provider = auto_select_provider("auto")
    except ValueError:
        auto_provider = None

    configured = get_configured_providers()

    if json_output:
        display.show_info(json_lib.dumps({
            "configured_providers": configured,
            "auto_selected": auto_provider,
        }, indent=2))
    else:
        display.show_info("Provider Detection Results")
        display.show_info("=" * 50)
        display.show_info(f"Auto-selected provider: {auto_provider or '(none)'}")
        display.show_info("")
        display.show_info("Configured providers:")
        if configured:
            for pid in configured:
                marker = " ← selected" if pid == auto_provider else ""
                display.show_info(f"  ✓ {pid}{marker}")
        else:
            display.show_info("  (none)")
        display.show_info("")
        display.show_info("To configure a provider, set its API key environment variable:")
        display.show_info("  OPENAI_API_KEY, DEEPSEEK_API_KEY, GEMINI_API_KEY, etc.")


# Security Research subcommands
security_app = typer.Typer(
    name="security",
    help="Alpha Zero 2 Security Research - Authorized offensive testing tools",
    add_completion=False,
)
app.add_typer(security_app, name="security")


@security_app.command("recon")
def run_reconnaissance(
    target: str = typer.Argument(..., help="Target domain to scan"),
    auth_type: str = typer.Option("bug_bounty", "--auth", "-a", help="Authorization type (bug_bounty, pentest, red_team)"),
    auth_by: str = typer.Option("", "--authorized-by", "-b", help="Who authorized the testing"),
    active: bool = typer.Option(False, "--active", help="Perform active reconnaissance (requires stronger auth)"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """Run reconnaissance on an authorized target."""
    import json as json_lib

    if not auth_by:
        display.show_error("--authorized-by is required for security testing")
        raise typer.Exit(code=1)

    async def run():
        from .alpha_zero import (
            OffensiveResearchEngine,
            AuthorizationRecord,
            AuthorizationScope,
        )

        scope_map = {
            "bug_bounty": AuthorizationScope.BUG_BOUNTY,
            "pentest": AuthorizationScope.PENTEST_ENGAGEMENT,
            "red_team": AuthorizationScope.RED_TEAM,
            "owned": AuthorizationScope.OWNED_SYSTEMS,
        }

        auth = AuthorizationRecord(
            scope=scope_map.get(auth_type, AuthorizationScope.BUG_BOUNTY),
            target_domain=target,
            authorized_by=auth_by,
            authorization_date=__import__("datetime").datetime.now().isoformat(),
        )

        engine = OffensiveResearchEngine(authorization=auth, verbose=True)

        if active:
            return await engine.active_recon(target)
        return await engine.passive_recon(target)

    try:
        display.show_action(f"Reconnaissance: {target}", status="info")
        display.show_info(f"Authorization: {auth_type} by {auth_by}")
        display.show_thinking("Scanning...")

        result = asyncio.run(run())
        display.stop_thinking()

        if json_output:
            data = {
                "target": result.target,
                "dns_records": result.dns_records,
                "open_ports": result.open_ports,
                "technologies": result.technologies,
                "potential_vectors": result.potential_vectors,
            }
            display.show_info(json_lib.dumps(data, indent=2))
        else:
            display.show_info(f"\nTarget: {result.target}")
            if result.dns_records:
                display.show_info(f"DNS Records: {result.dns_records}")
            if result.open_ports:
                display.show_info(f"Open Ports: {result.open_ports}")
            if result.technologies:
                display.show_info("Technologies:")
                for tech in result.technologies:
                    display.show_info(f"  - {tech}")
            if result.potential_vectors:
                display.show_info("Potential Vectors:")
                for vec in result.potential_vectors:
                    display.show_info(f"  - {vec}")

    except PermissionError as e:
        display.stop_thinking()
        display.show_error(f"Authorization error: {e}")
        raise typer.Exit(code=1)
    except Exception as e:
        display.stop_thinking()
        display.show_error(f"Recon failed: {e}")
        raise typer.Exit(code=1)


@security_app.command("google-vectors")
def show_google_persistence_vectors(
    service: Optional[str] = typer.Option(None, "--service", "-s", help="Filter by service (gcp_iam, gcp_compute, etc.)"),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Filter by category (service_account_abuse, etc.)"),
    stealth: int = typer.Option(0, "--stealth", help="Minimum stealth rating (1-5)"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """List Google infrastructure persistence vectors for red team research."""
    import json as json_lib
    from .alpha_zero import (
        GCP_PERSISTENCE_VECTORS,
        WORKSPACE_PERSISTENCE_VECTORS,
        GoogleService,
        PersistenceCategory,
    )

    all_vectors = {**GCP_PERSISTENCE_VECTORS, **WORKSPACE_PERSISTENCE_VECTORS}
    vectors = list(all_vectors.values())

    # Filter by service
    if service:
        try:
            svc = GoogleService(service)
            vectors = [v for v in vectors if v.service == svc]
        except ValueError:
            display.show_error(f"Unknown service: {service}")
            display.show_info(f"Available: {[s.value for s in GoogleService]}")
            raise typer.Exit(code=1)

    # Filter by category
    if category:
        try:
            cat = PersistenceCategory(category)
            vectors = [v for v in vectors if v.category == cat]
        except ValueError:
            display.show_error(f"Unknown category: {category}")
            display.show_info(f"Available: {[c.value for c in PersistenceCategory]}")
            raise typer.Exit(code=1)

    # Filter by stealth
    if stealth > 0:
        vectors = [v for v in vectors if v.stealth_rating >= stealth]

    if json_output:
        data = [
            {
                "name": v.name,
                "service": v.service.value,
                "category": v.category.value,
                "technique_id": v.technique_id,
                "stealth_rating": v.stealth_rating,
                "required_permissions": v.required_permissions,
                "detection_methods": v.detection_methods,
            }
            for v in vectors
        ]
        display.show_info(json_lib.dumps(data, indent=2))
    else:
        display.show_info(f"Google Persistence Vectors ({len(vectors)} found)")
        display.show_info("=" * 60)

        for v in sorted(vectors, key=lambda x: (-x.stealth_rating, x.name)):
            display.show_info(f"\n[{v.technique_id}] {v.name}")
            display.show_info(f"  Service: {v.service.value}")
            display.show_info(f"  Category: {v.category.value}")
            display.show_info(f"  Stealth: {'★' * v.stealth_rating}{'☆' * (5 - v.stealth_rating)}")
            display.show_info(f"  Permissions: {', '.join(v.required_permissions[:2])}")


@security_app.command("google-playbook")
def generate_google_playbook(
    project: str = typer.Argument(..., help="Target GCP project ID"),
    auth_by: str = typer.Option(..., "--authorized-by", "-b", help="Who authorized the testing"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    stealth_min: int = typer.Option(3, "--stealth", help="Minimum stealth rating for vectors"),
) -> None:
    """Generate a Google red team attack playbook."""
    import json as json_lib
    from .alpha_zero import (
        GooglePersistenceResearcher,
        create_google_authorization,
    )

    auth = create_google_authorization(
        engagement_type="red_team",
        authorized_by=auth_by,
        scope_notes=f"Red team engagement for project: {project}",
    )

    researcher = GooglePersistenceResearcher(authorization=auth, verbose=True)

    # Get stealthy vectors
    vectors = researcher.get_stealthy_vectors(min_rating=stealth_min)

    display.show_info(f"Generating playbook for {project}")
    display.show_info(f"Vectors: {len(vectors)} (stealth >= {stealth_min})")

    playbook = researcher.generate_attack_playbook(project, vectors)

    if output:
        with open(output, "w") as f:
            json.dump(playbook, f, indent=2)
        display.show_info(f"Playbook saved to: {output}")
    else:
        display.show_info("\n" + "=" * 60)
        display.show_info("ATTACK PLAYBOOK")
        display.show_info("=" * 60)
        display.show_info(f"Target: {playbook['target']}")
        display.show_info(f"Generated: {playbook['generated']}")

        display.show_info("\nRecommended Order (stealth-first):")
        for i, name in enumerate(playbook["recommended_order"][:10], 1):
            display.show_info(f"  {i}. {name}")

        display.show_info(f"\nDetection Coverage: {len(playbook['detection_coverage'])} methods")


@security_app.command("google-detection-report")
def generate_detection_report(
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output markdown file"),
    auth_by: str = typer.Option("Security Team", "--authorized-by", "-b", help="Report author"),
) -> None:
    """Generate detection guide for Google persistence vectors (blue team)."""
    from .alpha_zero import (
        GooglePersistenceResearcher,
        create_google_authorization,
    )

    auth = create_google_authorization(
        engagement_type="red_team",
        authorized_by=auth_by,
    )

    researcher = GooglePersistenceResearcher(authorization=auth, verbose=False)
    report = researcher.generate_detection_report()

    if output:
        with open(output, "w") as f:
            f.write(report)
        display.show_info(f"Detection report saved to: {output}")
    else:
        display.show_info(report)


@security_app.command("attack-vectors")
def list_attack_vectors(
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Filter by category"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """List available attack vectors for simulation."""
    import json as json_lib
    from .alpha_zero import ATTACK_VECTORS, AttackCategory

    vectors = list(ATTACK_VECTORS.values())

    if category:
        try:
            cat = AttackCategory(category)
            vectors = [v for v in vectors if v.category == cat]
        except ValueError:
            display.show_error(f"Unknown category: {category}")
            display.show_info(f"Available: {[c.value for c in AttackCategory]}")
            raise typer.Exit(code=1)

    if json_output:
        data = [
            {
                "name": v.name,
                "category": v.category.value,
                "phase": v.phase.value,
                "technique_id": v.technique_id,
            }
            for v in vectors
        ]
        display.show_info(json_lib.dumps(data, indent=2))
    else:
        display.show_info(f"Attack Vectors ({len(vectors)} available)")
        display.show_info("=" * 50)

        for v in vectors:
            display.show_info(f"\n[{v.technique_id}] {v.name}")
            display.show_info(f"  Category: {v.category.value}")
            display.show_info(f"  Phase: {v.phase.value}")
            display.show_info(f"  Mitigations: {', '.join(v.mitigations[:2])}")


@app.command("mission")
def execute_mission_command(
    mission_file: Path = typer.Argument(..., exists=True, dir_okay=False, help="Path to mission profile .md file"),
    workspace: Optional[Path] = typer.Option(None, "--workspace", "-w", help="Working directory for mission execution"),
    validate_only: bool = typer.Option(False, "--validate", help="Only validate the mission file without executing"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """Execute or validate a mission profile from a markdown file."""
    import json as json_lib
    from .capabilities.mission_orchestration import MissionParser, MissionOrchestrator

    try:
        # Parse mission file
        mission = MissionParser.parse_mission_file(str(mission_file))

        if validate_only:
            validation = {
                "valid": True,
                "mission_name": mission.name,
                "mission_type": mission.mission_type,
                "classification": mission.classification,
                "objectives_count": len(mission.objectives),
                "tasks_count": len(mission.tasks),
                "phases": list(set(t.phase.value for t in mission.tasks)),
            }

            if json_output:
                display.show_info(json_lib.dumps(validation, indent=2))
            else:
                display.show_info(f"✓ Mission file is valid")
                display.show_info(f"  Name: {mission.name}")
                display.show_info(f"  Type: {mission.mission_type}")
                display.show_info(f"  Classification: {mission.classification}")
                display.show_info(f"  Objectives: {len(mission.objectives)}")
                display.show_info(f"  Tasks: {len(mission.tasks)}")
                display.show_info(f"  Phases: {', '.join(validation['phases'])}")
            return

        # Execute mission
        display.show_action(f"Starting mission: {mission.name}", status="info")
        display.show_info(f"Classification: {mission.classification}")
        display.show_info(f"Description: {mission.description}")
        display.show_info("")

        orchestrator = MissionOrchestrator(mission)
        report = orchestrator.execute_mission()

        if json_output:
            display.show_info(json_lib.dumps(report, indent=2))
        else:
            display.show_info("\n" + "="*60)
            display.show_info("MISSION EXECUTION REPORT")
            display.show_info("="*60)
            display.show_info(f"Mission: {report['mission_name']}")
            display.show_info(f"Status: {'SUCCESS' if report['success'] else 'FAILED'}")
            display.show_info(f"Duration: {report['duration_seconds']:.1f} seconds")
            display.show_info(f"\nTasks: {report['tasks']['completed']}/{report['tasks']['total']} completed")
            display.show_info(f"Success Rate: {report['tasks']['success_rate']}")

            display.show_info("\nObjectives:")
            for obj in report['objectives']:
                status = "✓" if obj['completed'] else "✗"
                req = " (REQUIRED)" if obj['required'] else ""
                display.show_info(f"  {status} {obj['name']}{req} - {obj['progress']}")

            if report['discovered_assets']:
                display.show_info(f"\nDiscovered Assets: {len(report['discovered_assets'])}")

            display.show_info("")

    except Exception as e:
        display.show_error(f"Error: {str(e)}")
        raise typer.Exit(code=1)


def main() -> None:
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
