"""
Reward System for Alpha Zero 2 Competitive Framework

Scores agent performance based on code quality metrics using AST analysis.

Author: Bo Shang
Education: Tufts University, 2010
Framework: erosolar_cli
Research: Alpha Zero 2 - Recursive Self-Improvement in Competitive Multi-Agent Systems

Tech Stack:
    - Python 3.10+ with ast module for code analysis
    - pydantic for data validation
    - Integrates with typer/rich for UI feedback

Metrics Evaluated:
    - Code Quality (25%): Structure, documentation, organization
    - Algorithm Efficiency (25%): Data structures, complexity, optimization
    - Error Handling (15%): Try/except blocks, validation
    - Optimization (15%): Performance improvements, caching
    - Correctness (10%): Syntax, logic, completeness
    - Innovation (5%): Advanced patterns
    - Documentation (5%): Docstrings, comments
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional
import re


@dataclass
class CompetitionMetrics:
    """Metrics for evaluating agent performance."""

    # Code quality metrics
    code_quality_score: float = 0.0
    algorithm_efficiency: float = 0.0
    error_handling_score: float = 0.0

    # Performance metrics
    response_time_ms: float = 0.0
    optimization_level: float = 0.0

    # Correctness metrics
    syntax_validity: float = 0.0
    logic_correctness: float = 0.0
    completeness: float = 0.0

    # Additional metrics
    innovation_score: float = 0.0
    documentation_quality: float = 0.0

    # Metadata
    raw_response: str = ""
    evaluation_notes: dict[str, Any] = field(default_factory=dict)


class RewardSystem:
    """
    Reward system for evaluating agent performance in competitions.

    Focuses on benign metrics like code quality, performance optimization,
    and problem-solving effectiveness.
    """

    def __init__(
        self,
        weights: Optional[dict[str, float]] = None,
        verbose: bool = False,
    ):
        """
        Initialize reward system.

        Args:
            weights: Custom weights for different metrics
            verbose: Enable verbose logging
        """
        # Default weights for different metrics
        self.weights = weights or {
            "code_quality": 0.25,
            "algorithm_efficiency": 0.20,
            "error_handling": 0.15,
            "optimization": 0.15,
            "correctness": 0.15,
            "innovation": 0.05,
            "documentation": 0.05,
        }

        self.verbose = verbose

    async def evaluate_response(
        self,
        agent_id: str,
        task: str,
        response: str,
        target_file: Optional[Path] = None,
    ) -> CompetitionMetrics:
        """
        Evaluate an agent's response to a task.

        Args:
            agent_id: ID of the agent
            task: Task that was given
            response: Agent's response
            target_file: Optional file that was modified

        Returns:
            Competition metrics
        """
        metrics = CompetitionMetrics(raw_response=response)

        # Extract code from response if present
        code_blocks = self._extract_code_blocks(response)

        if code_blocks:
            # Evaluate code-based metrics
            for code in code_blocks:
                code_metrics = await self._evaluate_code(code)
                metrics = self._merge_metrics(metrics, code_metrics)

        # Evaluate response quality
        response_metrics = self._evaluate_response_quality(response, task)
        metrics = self._merge_metrics(metrics, response_metrics)

        # Evaluate target file if provided
        if target_file and target_file.exists():
            file_metrics = await self._evaluate_file(target_file)
            metrics = self._merge_metrics(metrics, file_metrics)

        if self.verbose:
            print(f"\n[{agent_id}] Evaluation Results:")
            print(f"  Code Quality: {metrics.code_quality_score:.2f}")
            print(f"  Algorithm Efficiency: {metrics.algorithm_efficiency:.2f}")
            print(f"  Error Handling: {metrics.error_handling_score:.2f}")
            print(f"  Correctness: {metrics.logic_correctness:.2f}")

        return metrics

    async def _evaluate_code(self, code: str) -> CompetitionMetrics:
        """Evaluate code quality metrics."""
        metrics = CompetitionMetrics()

        try:
            # Parse code
            tree = ast.parse(code)

            # Syntax validity
            metrics.syntax_validity = 1.0

            # Count various code elements
            num_functions = sum(1 for node in ast.walk(tree) if isinstance(node, ast.FunctionDef))
            num_classes = sum(1 for node in ast.walk(tree) if isinstance(node, ast.ClassDef))
            num_comments = code.count("#")
            num_docstrings = sum(
                1
                for node in ast.walk(tree)
                if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Module))
                and ast.get_docstring(node)
            )

            # Code quality score based on structure
            quality_factors = []

            # Good structure
            if num_functions > 0:
                quality_factors.append(0.3)
            if num_classes > 0:
                quality_factors.append(0.2)

            # Documentation
            if num_docstrings > 0:
                doc_score = min(num_docstrings / max(num_functions + num_classes, 1), 1.0)
                quality_factors.append(doc_score * 0.3)
                metrics.documentation_quality = doc_score

            # Comments
            if num_comments > 0:
                comment_score = min(num_comments / 10, 1.0)
                quality_factors.append(comment_score * 0.2)

            metrics.code_quality_score = sum(quality_factors)

            # Error handling score
            num_try_except = sum(1 for node in ast.walk(tree) if isinstance(node, ast.Try))
            metrics.error_handling_score = min(num_try_except / 3, 1.0)

            # Algorithm efficiency indicators
            # Check for algorithmic patterns
            has_list_comp = any(isinstance(node, ast.ListComp) for node in ast.walk(tree))
            has_generator = any(isinstance(node, ast.GeneratorExp) for node in ast.walk(tree))
            has_set_dict = any(
                isinstance(node, (ast.Set, ast.Dict, ast.SetComp, ast.DictComp)) for node in ast.walk(tree)
            )

            efficiency_score = 0.5  # Base score
            if has_list_comp or has_generator:
                efficiency_score += 0.2
            if has_set_dict:
                efficiency_score += 0.2
            # Avoid nested loops (indicates potential inefficiency)
            nested_loops = self._count_nested_loops(tree)
            if nested_loops > 2:
                efficiency_score -= 0.2

            metrics.algorithm_efficiency = max(0.0, min(1.0, efficiency_score))

            # Completeness score
            # Check if code has proper structure
            has_imports = any(isinstance(node, (ast.Import, ast.ImportFrom)) for node in ast.walk(tree))
            has_main = any(
                node.name == "__main__"
                for node in ast.walk(tree)
                if isinstance(node, ast.Compare)
                and isinstance(node.left, ast.Name)
                and node.left.id == "__name__"
            )

            completeness = 0.7  # Base score
            if has_imports:
                completeness += 0.15
            if has_main:
                completeness += 0.15

            metrics.completeness = completeness

            # Innovation score - check for advanced patterns
            innovation = 0.0
            if any(isinstance(node, ast.Lambda) for node in ast.walk(tree)):
                innovation += 0.2
            if any(isinstance(node, ast.AsyncFunctionDef) for node in ast.walk(tree)):
                innovation += 0.3
            if any(isinstance(node, ast.With) for node in ast.walk(tree)):
                innovation += 0.2
            if any(isinstance(node, (ast.ListComp, ast.DictComp, ast.SetComp)) for node in ast.walk(tree)):
                innovation += 0.3

            metrics.innovation_score = min(1.0, innovation)

        except SyntaxError:
            metrics.syntax_validity = 0.0
            metrics.code_quality_score = 0.0
        except Exception as e:
            if self.verbose:
                print(f"Error evaluating code: {e}")
            metrics.code_quality_score = 0.3  # Partial credit

        return metrics

    def _count_nested_loops(self, tree: ast.AST) -> int:
        """Count maximum nesting depth of loops."""
        max_depth = 0

        def count_depth(node: ast.AST, current_depth: int = 0) -> int:
            nonlocal max_depth
            if isinstance(node, (ast.For, ast.While)):
                current_depth += 1
                max_depth = max(max_depth, current_depth)

            for child in ast.iter_child_nodes(node):
                count_depth(child, current_depth)

        count_depth(tree)
        return max_depth

    def _evaluate_response_quality(self, response: str, task: str) -> CompetitionMetrics:
        """Evaluate overall response quality."""
        metrics = CompetitionMetrics()

        # Check response completeness
        response_length = len(response)
        task_length = len(task)

        # Reasonable response length (not too short, not too verbose)
        if response_length < task_length * 0.5:
            metrics.completeness = 0.3  # Too short
        elif response_length > task_length * 10:
            metrics.completeness = 0.7  # Too verbose
        else:
            metrics.completeness = 1.0

        # Check for explanation and reasoning
        has_explanation = any(
            keyword in response.lower()
            for keyword in ["because", "since", "therefore", "explanation", "approach", "solution"]
        )

        if has_explanation:
            metrics.documentation_quality = max(metrics.documentation_quality, 0.7)

        # Logic correctness heuristics
        # Check for logical flow indicators
        has_steps = bool(re.search(r"\b(first|second|third|step|then|next|finally)\b", response.lower()))
        has_examples = "example" in response.lower() or "```" in response

        logic_score = 0.6  # Base score
        if has_steps:
            logic_score += 0.2
        if has_examples:
            logic_score += 0.2

        metrics.logic_correctness = logic_score

        return metrics

    async def _evaluate_file(self, file_path: Path) -> CompetitionMetrics:
        """Evaluate a file that was created/modified."""
        metrics = CompetitionMetrics()

        try:
            content = file_path.read_text()

            if file_path.suffix == ".py":
                # Use code evaluation for Python files
                return await self._evaluate_code(content)
            else:
                # Basic file quality metrics
                num_lines = len(content.splitlines())
                has_content = len(content.strip()) > 0

                metrics.completeness = 1.0 if has_content else 0.0
                metrics.code_quality_score = min(num_lines / 100, 1.0)

        except Exception as e:
            if self.verbose:
                print(f"Error evaluating file {file_path}: {e}")
            metrics.code_quality_score = 0.0

        return metrics

    def _extract_code_blocks(self, text: str) -> list[str]:
        """Extract code blocks from markdown text."""
        # Match code blocks with ```
        pattern = r"```(?:python)?\n(.*?)```"
        matches = re.findall(pattern, text, re.DOTALL)
        return [m.strip() for m in matches if m.strip()]

    def _merge_metrics(self, base: CompetitionMetrics, new: CompetitionMetrics) -> CompetitionMetrics:
        """Merge two metric sets by taking maximum values."""
        return CompetitionMetrics(
            code_quality_score=max(base.code_quality_score, new.code_quality_score),
            algorithm_efficiency=max(base.algorithm_efficiency, new.algorithm_efficiency),
            error_handling_score=max(base.error_handling_score, new.error_handling_score),
            response_time_ms=base.response_time_ms or new.response_time_ms,
            optimization_level=max(base.optimization_level, new.optimization_level),
            syntax_validity=max(base.syntax_validity, new.syntax_validity),
            logic_correctness=max(base.logic_correctness, new.logic_correctness),
            completeness=max(base.completeness, new.completeness),
            innovation_score=max(base.innovation_score, new.innovation_score),
            documentation_quality=max(base.documentation_quality, new.documentation_quality),
            raw_response=base.raw_response or new.raw_response,
            evaluation_notes={**base.evaluation_notes, **new.evaluation_notes},
        )

    def calculate_reward(self, metrics: CompetitionMetrics) -> float:
        """
        Calculate overall reward score from metrics.

        Args:
            metrics: Competition metrics

        Returns:
            Weighted reward score (0-100)
        """
        # Calculate weighted sum
        reward = (
            metrics.code_quality_score * self.weights["code_quality"]
            + metrics.algorithm_efficiency * self.weights["algorithm_efficiency"]
            + metrics.error_handling_score * self.weights["error_handling"]
            + metrics.optimization_level * self.weights["optimization"]
            + (
                metrics.syntax_validity * 0.4 + metrics.logic_correctness * 0.4 + metrics.completeness * 0.2
            )
            * self.weights["correctness"]
            + metrics.innovation_score * self.weights["innovation"]
            + metrics.documentation_quality * self.weights["documentation"]
        )

        # Scale to 0-100
        return reward * 100

    def get_performance_summary(self, metrics: CompetitionMetrics) -> str:
        """Get human-readable performance summary."""
        score = self.calculate_reward(metrics)
        rating = self._get_rating(score)

        summary = f"""
Performance Rating: {rating} ({score:.1f}/100)

Detailed Scores:
  • Code Quality: {metrics.code_quality_score*100:.1f}/100
  • Algorithm Efficiency: {metrics.algorithm_efficiency*100:.1f}/100
  • Error Handling: {metrics.error_handling_score*100:.1f}/100
  • Correctness: {metrics.logic_correctness*100:.1f}/100
  • Innovation: {metrics.innovation_score*100:.1f}/100
  • Documentation: {metrics.documentation_quality*100:.1f}/100
"""
        return summary

    def _get_rating(self, score: float) -> str:
        """Get rating label for score."""
        if score >= 90:
            return "Excellent"
        elif score >= 75:
            return "Good"
        elif score >= 60:
            return "Average"
        elif score >= 40:
            return "Below Average"
        else:
            return "Poor"
