"""
Security Research Module for Alpha Zero 2

A modular security research framework with optional provider-specific extensions.
All capabilities require explicit authorization.

LEGAL NOTICE:
These tools are intended for:
- Authorized penetration testing engagements
- Bug bounty programs with explicit scope
- CTF competitions and security training
- Red team exercises with written authorization
- Security research on systems you own or have permission to test

Structure:
- core: Base authorization and reconnaissance (always available)
- simulation: Attack simulation framework (always available)
- google: Google Cloud/Workspace persistence research (optional)

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# Core security components (always available)
from .core import (
    AuthorizationScope,
    AuthorizationRecord,
    ReconResult,
    VulnerabilityFinding,
    SecurityResearchEngine,
    create_bug_bounty_authorization,
    create_pentest_authorization,
    create_ctf_authorization,
)

from .simulation import (
    AttackSimulator,
    AttackVector,
    AttackCategory,
    AttackPhase,
    AttackSimulationResult,
    PayloadGenerator,
    ATTACK_VECTORS,
)

# Optional Google-specific module (loaded on demand)
_google_module = None


def is_google_enabled() -> bool:
    """Check if Google security research module is available."""
    global _google_module
    if _google_module is not None:
        return True
    try:
        from . import google as _gm
        _google_module = _gm
        return True
    except ImportError:
        return False


def get_google_module():
    """Get the Google security research module (lazy load)."""
    global _google_module
    if _google_module is None:
        if not is_google_enabled():
            raise ImportError(
                "Google security research module not available. "
                "Install with: pip install erosolar[google-security]"
            )
    return _google_module


# Convenience re-exports for Google module (lazy)
def GooglePersistenceResearcher(*args, **kwargs):
    """Create a Google persistence researcher (lazy load)."""
    mod = get_google_module()
    return mod.GooglePersistenceResearcher(*args, **kwargs)


def create_google_authorization(*args, **kwargs):
    """Create Google authorization (lazy load)."""
    mod = get_google_module()
    return mod.create_google_authorization(*args, **kwargs)


__version__ = "1.0.0"
__all__ = [
    # Core
    "AuthorizationScope",
    "AuthorizationRecord",
    "ReconResult",
    "VulnerabilityFinding",
    "SecurityResearchEngine",
    "create_bug_bounty_authorization",
    "create_pentest_authorization",
    "create_ctf_authorization",
    # Simulation
    "AttackSimulator",
    "AttackVector",
    "AttackCategory",
    "AttackPhase",
    "AttackSimulationResult",
    "PayloadGenerator",
    "ATTACK_VECTORS",
    # Google (optional)
    "is_google_enabled",
    "get_google_module",
    "GooglePersistenceResearcher",
    "create_google_authorization",
]
