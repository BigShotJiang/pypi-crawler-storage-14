"""
AI-Powered Error Analysis and Auto-Fix System

Analyzes build, test, and tool errors using pattern matching and AI reasoning
to automatically fix common issues, following Claude Code's approach.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import re
import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple


class ErrorType(Enum):
    """Categories of errors for targeted fixing."""
    BUILD_ERROR = "build_error"
    TEST_FAILURE = "test_failure"
    TYPE_ERROR = "type_error"
    LINT_ERROR = "lint_error"
    IMPORT_ERROR = "import_error"
    SYNTAX_ERROR = "syntax_error"
    FILE_NOT_FOUND = "file_not_found"
    PERMISSION_ERROR = "permission_error"
    EDIT_CONFLICT = "edit_conflict"
    NEWLINE_IN_STRING = "newline_in_string"
    UNKNOWN = "unknown"


@dataclass
class ErrorLocation:
    """Location of an error in source code."""
    file_path: str
    line_number: Optional[int] = None
    column: Optional[int] = None
    context_before: List[str] = field(default_factory=list)
    context_after: List[str] = field(default_factory=list)


@dataclass
class ErrorFix:
    """A proposed fix for an error."""
    description: str
    file_path: str
    old_content: str
    new_content: str
    confidence: float  # 0.0 to 1.0
    auto_applicable: bool = True
    requires_confirmation: bool = False


@dataclass
class ParsedError:
    """A parsed and analyzed error."""
    error_type: ErrorType
    message: str
    raw_output: str
    locations: List[ErrorLocation] = field(default_factory=list)
    suggested_fixes: List[ErrorFix] = field(default_factory=list)
    related_errors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Error Patterns for Different Build Systems
# =============================================================================

# TypeScript/JavaScript patterns
TS_ERROR_PATTERNS = {
    "type_error": re.compile(
        r"(?P<file>[^\s:]+\.tsx?):(?P<line>\d+):(?P<col>\d+)\s*-\s*error\s+TS(?P<code>\d+):\s*(?P<msg>.+)",
        re.MULTILINE
    ),
    "module_not_found": re.compile(
        r"Cannot find module '(?P<module>[^']+)'",
        re.MULTILINE
    ),
    "property_missing": re.compile(
        r"Property '(?P<prop>[^']+)' does not exist on type '(?P<type>[^']+)'",
        re.MULTILINE
    ),
    "type_mismatch": re.compile(
        r"Type '(?P<actual>[^']+)' is not assignable to type '(?P<expected>[^']+)'",
        re.MULTILINE
    ),
    "unused_variable": re.compile(
        r"'(?P<var>[^']+)' is declared but (?:its value is )?never (?:used|read)",
        re.MULTILINE
    ),
}

# Python patterns
PYTHON_ERROR_PATTERNS = {
    "syntax_error": re.compile(
        r'File "(?P<file>[^"]+)", line (?P<line>\d+).*\n.*SyntaxError:\s*(?P<msg>.+)',
        re.MULTILINE
    ),
    "import_error": re.compile(
        r'(?:ModuleNotFoundError|ImportError):\s*(?:No module named\s*)?[\'"]?(?P<module>[^\'"]+)[\'"]?',
        re.MULTILINE
    ),
    "type_error": re.compile(
        r'TypeError:\s*(?P<msg>.+)',
        re.MULTILINE
    ),
    "name_error": re.compile(
        r"NameError:\s*name\s*['\"](?P<name>[^'\"]+)['\"].*not defined",
        re.MULTILINE
    ),
    "attribute_error": re.compile(
        r"AttributeError:\s*['\"]?(?P<obj>[^'\"]+)['\"]?\s*(?:object\s*)?has no attribute\s*['\"](?P<attr>[^'\"]+)['\"]",
        re.MULTILINE
    ),
}

# npm/Node.js patterns
NPM_ERROR_PATTERNS = {
    "script_error": re.compile(
        r"npm ERR!\s+script\s+(?P<script>\S+)\s*failed",
        re.MULTILINE | re.IGNORECASE
    ),
    "dependency_missing": re.compile(
        r"(?:Cannot find|Module not found).*['\"](?P<dep>[^'\"]+)['\"]",
        re.MULTILINE
    ),
    "peer_dependency": re.compile(
        r"peer dep missing:\s*(?P<peer>[^,]+)",
        re.MULTILINE
    ),
}

# Edit tool patterns
EDIT_PATTERNS = {
    "newlines_in_string": re.compile(
        r"(?:newlines?\s+detected|contains?\s+newlines?).*old_string",
        re.IGNORECASE
    ),
    "string_not_found": re.compile(
        r"old_string\s+not\s+found|exact\s+text\s+must\s+match",
        re.IGNORECASE
    ),
    "multiple_occurrences": re.compile(
        r"appears?\s+(\d+)\s+times?\s+in\s+the\s+file",
        re.IGNORECASE
    ),
}


class AIErrorFixer:
    """
    AI-powered error analyzer and fixer.

    Parses build/test output, identifies errors, and suggests/applies fixes
    following Claude Code's approach of understanding errors and fixing them.
    """

    def __init__(
        self,
        working_dir: str = ".",
        verbose: bool = False,
        auto_fix_enabled: bool = True,
        max_auto_fixes: int = 10,
    ):
        """
        Initialize the AI error fixer.

        Args:
            working_dir: Working directory for file operations
            verbose: Enable verbose output
            auto_fix_enabled: Enable automatic application of fixes
            max_auto_fixes: Maximum auto-fixes to apply in one run
        """
        self.working_dir = Path(working_dir).resolve()
        self.verbose = verbose
        self.auto_fix_enabled = auto_fix_enabled
        self.max_auto_fixes = max_auto_fixes
        self._fix_history: List[ErrorFix] = []

    def analyze_output(self, output: str, command: Optional[str] = None) -> List[ParsedError]:
        """
        Analyze command output for errors.

        Args:
            output: The raw output from a command (build, test, etc.)
            command: Optional command that was run

        Returns:
            List of parsed errors with suggested fixes
        """
        errors: List[ParsedError] = []

        # Detect what type of output this is
        output_type = self._detect_output_type(output, command)

        if output_type == "typescript":
            errors.extend(self._parse_typescript_errors(output))
        elif output_type == "python":
            errors.extend(self._parse_python_errors(output))
        elif output_type == "npm":
            errors.extend(self._parse_npm_errors(output))
        elif output_type == "edit":
            errors.extend(self._parse_edit_errors(output))
        else:
            # Generic error parsing
            errors.extend(self._parse_generic_errors(output))

        # Generate fixes for each error
        for error in errors:
            error.suggested_fixes = self._generate_fixes(error)

        return errors

    def apply_fixes(
        self,
        errors: List[ParsedError],
        max_fixes: Optional[int] = None,
        require_confirmation: bool = False,
    ) -> Tuple[int, List[str]]:
        """
        Apply fixes for the given errors.

        Args:
            errors: List of parsed errors
            max_fixes: Maximum fixes to apply (defaults to max_auto_fixes)
            require_confirmation: Whether to require confirmation for each fix

        Returns:
            Tuple of (fixes_applied, list of fix descriptions)
        """
        if not self.auto_fix_enabled:
            return 0, []

        max_fixes = max_fixes or self.max_auto_fixes
        fixes_applied = 0
        descriptions = []

        for error in errors:
            if fixes_applied >= max_fixes:
                break

            for fix in error.suggested_fixes:
                if fixes_applied >= max_fixes:
                    break

                if not fix.auto_applicable:
                    continue

                if require_confirmation and fix.requires_confirmation:
                    # Skip fixes that need confirmation when we're auto-fixing
                    continue

                success, desc = self._apply_single_fix(fix)
                if success:
                    fixes_applied += 1
                    descriptions.append(desc)
                    self._fix_history.append(fix)

        return fixes_applied, descriptions

    def get_fix_suggestions(self, errors: List[ParsedError]) -> str:
        """
        Get a formatted string of fix suggestions for display.

        Args:
            errors: List of parsed errors

        Returns:
            Formatted string with fix suggestions
        """
        if not errors:
            return "No errors found."

        lines = ["Error Analysis and Fix Suggestions:", "=" * 50, ""]

        for i, error in enumerate(errors, 1):
            lines.append(f"{i}. [{error.error_type.value}] {error.message[:100]}")

            if error.locations:
                loc = error.locations[0]
                lines.append(f"   Location: {loc.file_path}:{loc.line_number or '?'}")

            if error.suggested_fixes:
                lines.append("   Suggested fixes:")
                for j, fix in enumerate(error.suggested_fixes, 1):
                    confidence = f"({fix.confidence:.0%} confidence)"
                    auto = "[auto-fix]" if fix.auto_applicable else "[manual]"
                    lines.append(f"     {j}. {fix.description} {confidence} {auto}")
            else:
                lines.append("   No automatic fix available")

            lines.append("")

        return "\n".join(lines)

    # =========================================================================
    # Private Methods - Output Type Detection
    # =========================================================================

    def _detect_output_type(self, output: str, command: Optional[str]) -> str:
        """Detect the type of output based on content and command."""
        output_lower = output.lower()
        command_lower = (command or "").lower()

        # Check command first
        if "tsc" in command_lower or "typescript" in command_lower:
            return "typescript"
        if "npm" in command_lower or "yarn" in command_lower:
            if "run build" in command_lower:
                return "typescript"  # Likely TypeScript build
            return "npm"
        if "python" in command_lower or "pytest" in command_lower:
            return "python"
        if "edit" in command_lower:
            return "edit"

        # Check output content
        if "error ts" in output_lower or ".tsx:" in output_lower or ".ts:" in output_lower:
            return "typescript"
        if "syntaxerror:" in output_lower or "typeerror:" in output_lower:
            if "file \"" in output_lower:
                return "python"
        if "npm err!" in output_lower:
            return "npm"
        if "newlines" in output_lower and "old_string" in output_lower:
            return "edit"

        return "generic"

    # =========================================================================
    # Private Methods - TypeScript Parsing
    # =========================================================================

    def _parse_typescript_errors(self, output: str) -> List[ParsedError]:
        """Parse TypeScript/tsc errors."""
        errors: List[ParsedError] = []

        for match in TS_ERROR_PATTERNS["type_error"].finditer(output):
            file_path = match.group("file")
            line = int(match.group("line"))
            col = int(match.group("col"))
            code = match.group("code")
            msg = match.group("msg")

            error = ParsedError(
                error_type=ErrorType.TYPE_ERROR,
                message=f"TS{code}: {msg}",
                raw_output=match.group(0),
                locations=[ErrorLocation(
                    file_path=file_path,
                    line_number=line,
                    column=col,
                )],
                metadata={"ts_code": code},
            )

            # Add context from file if it exists
            self._add_file_context(error.locations[0])
            errors.append(error)

        return errors

    # =========================================================================
    # Private Methods - Python Parsing
    # =========================================================================

    def _parse_python_errors(self, output: str) -> List[ParsedError]:
        """Parse Python errors."""
        errors: List[ParsedError] = []

        # Syntax errors
        for match in PYTHON_ERROR_PATTERNS["syntax_error"].finditer(output):
            error = ParsedError(
                error_type=ErrorType.SYNTAX_ERROR,
                message=match.group("msg"),
                raw_output=match.group(0),
                locations=[ErrorLocation(
                    file_path=match.group("file"),
                    line_number=int(match.group("line")),
                )],
            )
            self._add_file_context(error.locations[0])
            errors.append(error)

        # Import errors
        for match in PYTHON_ERROR_PATTERNS["import_error"].finditer(output):
            error = ParsedError(
                error_type=ErrorType.IMPORT_ERROR,
                message=f"Module not found: {match.group('module')}",
                raw_output=match.group(0),
                metadata={"missing_module": match.group("module")},
            )
            errors.append(error)

        return errors

    # =========================================================================
    # Private Methods - npm/Node Parsing
    # =========================================================================

    def _parse_npm_errors(self, output: str) -> List[ParsedError]:
        """Parse npm/Node.js errors."""
        errors: List[ParsedError] = []

        # Missing dependencies
        for match in NPM_ERROR_PATTERNS["dependency_missing"].finditer(output):
            error = ParsedError(
                error_type=ErrorType.IMPORT_ERROR,
                message=f"Missing dependency: {match.group('dep')}",
                raw_output=match.group(0),
                metadata={"missing_dep": match.group("dep")},
            )
            errors.append(error)

        return errors

    # =========================================================================
    # Private Methods - Edit Tool Parsing
    # =========================================================================

    def _parse_edit_errors(self, output: str) -> List[ParsedError]:
        """Parse Edit tool errors."""
        errors: List[ParsedError] = []

        # Newlines in old_string
        if EDIT_PATTERNS["newlines_in_string"].search(output):
            error = ParsedError(
                error_type=ErrorType.NEWLINE_IN_STRING,
                message="Edit failed: old_string contains newlines which should be properly escaped or the string should be on a single line",
                raw_output=output,
                metadata={
                    "suggestion": "Use \\n for newlines in JSON, or provide the exact text including literal newline characters",
                },
            )
            errors.append(error)

        # String not found
        if EDIT_PATTERNS["string_not_found"].search(output):
            error = ParsedError(
                error_type=ErrorType.EDIT_CONFLICT,
                message="Edit failed: old_string not found in file - the exact text including whitespace must match",
                raw_output=output,
            )
            errors.append(error)

        # Multiple occurrences
        match = EDIT_PATTERNS["multiple_occurrences"].search(output)
        if match:
            count = match.group(1)
            error = ParsedError(
                error_type=ErrorType.EDIT_CONFLICT,
                message=f"Edit failed: old_string appears {count} times - provide more context or use replace_all",
                raw_output=output,
                metadata={"occurrence_count": int(count)},
            )
            errors.append(error)

        return errors

    # =========================================================================
    # Private Methods - Generic Parsing
    # =========================================================================

    def _parse_generic_errors(self, output: str) -> List[ParsedError]:
        """Parse generic error output."""
        errors: List[ParsedError] = []

        # Look for common error indicators
        error_lines = []
        for line in output.split("\n"):
            line_lower = line.lower()
            if any(indicator in line_lower for indicator in ["error:", "failed:", "exception:", "fatal:"]):
                error_lines.append(line.strip())

        if error_lines:
            error = ParsedError(
                error_type=ErrorType.UNKNOWN,
                message=error_lines[0][:200],
                raw_output="\n".join(error_lines[:5]),
                related_errors=error_lines[1:5],
            )
            errors.append(error)

        return errors

    # =========================================================================
    # Private Methods - Fix Generation
    # =========================================================================

    def _generate_fixes(self, error: ParsedError) -> List[ErrorFix]:
        """Generate fix suggestions for an error."""
        fixes: List[ErrorFix] = []

        if error.error_type == ErrorType.TYPE_ERROR:
            fixes.extend(self._generate_typescript_fixes(error))
        elif error.error_type == ErrorType.IMPORT_ERROR:
            fixes.extend(self._generate_import_fixes(error))
        elif error.error_type == ErrorType.NEWLINE_IN_STRING:
            fixes.extend(self._generate_newline_fixes(error))
        elif error.error_type == ErrorType.EDIT_CONFLICT:
            fixes.extend(self._generate_edit_conflict_fixes(error))

        return fixes

    def _generate_typescript_fixes(self, error: ParsedError) -> List[ErrorFix]:
        """Generate fixes for TypeScript errors."""
        fixes: List[ErrorFix] = []
        ts_code = error.metadata.get("ts_code", "")

        if not error.locations:
            return fixes

        loc = error.locations[0]

        # TS2304: Cannot find name
        if ts_code == "2304":
            name_match = re.search(r"Cannot find name '([^']+)'", error.message)
            if name_match:
                missing_name = name_match.group(1)
                # Suggest adding import
                fixes.append(ErrorFix(
                    description=f"Add import for '{missing_name}'",
                    file_path=loc.file_path,
                    old_content="",  # Will be determined when applying
                    new_content=f"import {{ {missing_name} }} from './{missing_name}';",
                    confidence=0.6,
                    auto_applicable=False,  # Need to determine correct import path
                ))

        # TS2322: Type mismatch
        if ts_code == "2322":
            type_match = re.search(r"Type '([^']+)' is not assignable to type '([^']+)'", error.message)
            if type_match:
                actual_type = type_match.group(1)
                expected_type = type_match.group(2)
                fixes.append(ErrorFix(
                    description=f"Cast to {expected_type} or fix the type mismatch",
                    file_path=loc.file_path,
                    old_content="",
                    new_content="",
                    confidence=0.5,
                    auto_applicable=False,
                ))

        # TS6133: Unused variable
        if ts_code == "6133":
            var_match = re.search(r"'([^']+)' is declared but", error.message)
            if var_match:
                var_name = var_match.group(1)
                fixes.append(ErrorFix(
                    description=f"Prefix '{var_name}' with underscore to indicate it's intentionally unused",
                    file_path=loc.file_path,
                    old_content=var_name,
                    new_content=f"_{var_name}",
                    confidence=0.8,
                    auto_applicable=True,
                ))

        return fixes

    def _generate_import_fixes(self, error: ParsedError) -> List[ErrorFix]:
        """Generate fixes for import errors."""
        fixes: List[ErrorFix] = []

        missing_module = error.metadata.get("missing_module") or error.metadata.get("missing_dep")
        if missing_module:
            # Suggest npm install
            fixes.append(ErrorFix(
                description=f"Install missing dependency: npm install {missing_module}",
                file_path="package.json",
                old_content="",
                new_content="",
                confidence=0.9,
                auto_applicable=False,  # Don't auto-install packages
                requires_confirmation=True,
            ))

        return fixes

    def _generate_newline_fixes(self, error: ParsedError) -> List[ErrorFix]:
        """Generate fixes for newline-in-string errors."""
        fixes: List[ErrorFix] = []

        fixes.append(ErrorFix(
            description="Escape newlines properly in the old_string parameter using literal \\n",
            file_path="",
            old_content="",
            new_content="",
            confidence=0.9,
            auto_applicable=False,
            requires_confirmation=False,
        ))

        fixes.append(ErrorFix(
            description="Use a smaller context string that doesn't span multiple lines",
            file_path="",
            old_content="",
            new_content="",
            confidence=0.8,
            auto_applicable=False,
        ))

        return fixes

    def _generate_edit_conflict_fixes(self, error: ParsedError) -> List[ErrorFix]:
        """Generate fixes for edit conflict errors."""
        fixes: List[ErrorFix] = []

        occurrence_count = error.metadata.get("occurrence_count")
        if occurrence_count:
            fixes.append(ErrorFix(
                description=f"Use replace_all: true to replace all {occurrence_count} occurrences",
                file_path="",
                old_content="",
                new_content="",
                confidence=0.7,
                auto_applicable=False,
            ))
            fixes.append(ErrorFix(
                description="Add more surrounding context to make the string unique",
                file_path="",
                old_content="",
                new_content="",
                confidence=0.9,
                auto_applicable=False,
            ))
        else:
            fixes.append(ErrorFix(
                description="Read the file first to get the exact text including all whitespace",
                file_path="",
                old_content="",
                new_content="",
                confidence=0.95,
                auto_applicable=False,
            ))

        return fixes

    # =========================================================================
    # Private Methods - Fix Application
    # =========================================================================

    def _apply_single_fix(self, fix: ErrorFix) -> Tuple[bool, str]:
        """Apply a single fix."""
        if not fix.file_path or not fix.old_content or not fix.new_content:
            return False, f"Cannot apply fix: {fix.description}"

        try:
            file_path = self.working_dir / fix.file_path
            if not file_path.exists():
                return False, f"File not found: {fix.file_path}"

            content = file_path.read_text(encoding="utf-8")

            if fix.old_content not in content:
                return False, f"Original content not found in {fix.file_path}"

            new_content = content.replace(fix.old_content, fix.new_content, 1)
            file_path.write_text(new_content, encoding="utf-8")

            return True, f"Applied: {fix.description}"

        except Exception as e:
            return False, f"Error applying fix: {e}"

    def _add_file_context(self, location: ErrorLocation, context_lines: int = 3) -> None:
        """Add file context to an error location."""
        try:
            file_path = self.working_dir / location.file_path
            if not file_path.exists():
                return

            lines = file_path.read_text(encoding="utf-8").splitlines()
            line_idx = (location.line_number or 1) - 1

            start = max(0, line_idx - context_lines)
            end = min(len(lines), line_idx + context_lines + 1)

            location.context_before = lines[start:line_idx]
            location.context_after = lines[line_idx + 1:end]

        except Exception:
            pass


# =============================================================================
# Factory Functions
# =============================================================================

def create_error_fixer(
    working_dir: str = ".",
    auto_fix: bool = True,
    verbose: bool = False,
) -> AIErrorFixer:
    """Create an AI error fixer instance."""
    return AIErrorFixer(
        working_dir=working_dir,
        auto_fix_enabled=auto_fix,
        verbose=verbose,
    )


def analyze_and_fix_output(
    output: str,
    command: Optional[str] = None,
    working_dir: str = ".",
    auto_fix: bool = True,
) -> Tuple[List[ParsedError], int, List[str]]:
    """
    Convenience function to analyze output and apply fixes.

    Args:
        output: Command output to analyze
        command: Optional command that produced the output
        working_dir: Working directory
        auto_fix: Whether to automatically apply fixes

    Returns:
        Tuple of (errors, fixes_applied, fix_descriptions)
    """
    fixer = create_error_fixer(working_dir=working_dir, auto_fix=auto_fix)
    errors = fixer.analyze_output(output, command)

    if auto_fix and errors:
        fixes_applied, descriptions = fixer.apply_fixes(errors)
        return errors, fixes_applied, descriptions

    return errors, 0, []
