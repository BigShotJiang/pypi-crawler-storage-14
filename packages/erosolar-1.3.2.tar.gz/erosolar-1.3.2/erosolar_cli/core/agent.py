"""
Agent Runtime - Orchestrates conversation loops with LLM providers.

Responsibilities:
- Manage conversation message history
- Execute LLM generation (streaming and non-streaming)
- Resolve tool calls in parallel
- Apply context management and pruning
- Emit callbacks for UI updates
"""

from __future__ import annotations

import asyncio
import copy
import os
import time
from abc import ABC
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Optional

from .context_manager import ContextManager
from .tool_runtime import ToolRuntime
from .types import (
    AssistantMessage,
    ConversationMessage,
    LLMProvider,
    ProviderToolDefinition,
    ProviderUsage,
    SystemMessage,
    ToolCallRequest,
    ToolMessage,
    UserMessage,
)

# Import display for tool call UI
try:
    from ..ui.unified import unified_ui as ui_display
except ImportError:
    ui_display = None


@dataclass
class AssistantMessageMetadata:
    """Metadata for assistant messages."""

    is_final: bool
    elapsed_ms: Optional[float] = None
    usage: Optional[ProviderUsage] = None
    context_stats: Optional[dict[str, Any]] = None


class AgentCallbacks(ABC):
    """Callbacks for agent runtime events."""

    def on_assistant_message(self, content: str, metadata: AssistantMessageMetadata) -> None:
        """Called when assistant produces a message."""
        pass

    def on_stream_chunk(self, chunk: str) -> None:
        """Called when a streaming chunk is received."""
        pass

    def on_context_pruned(self, removed_count: int, stats: dict[str, Any]) -> None:
        """Called when context is pruned."""
        pass


@dataclass
class AgentOptions:
    """Options for agent runtime configuration."""

    provider: LLMProvider
    tool_runtime: ToolRuntime
    system_prompt: str
    callbacks: Optional[AgentCallbacks] = None
    context_manager: Optional[ContextManager] = None


@dataclass
class ActiveRun:
    """Tracking information for an active run."""

    started_at: float


class AgentRuntime:
    """Runtime for orchestrating agent conversations with LLM."""

    def __init__(self, options: AgentOptions):
        """
        Initialize agent runtime.

        Args:
            options: Configuration options
        """
        self.provider = options.provider
        self.tool_runtime = options.tool_runtime
        self.callbacks = options.callbacks
        self.context_manager = options.context_manager

        self.messages: list[ConversationMessage] = []
        self.active_run: Optional[ActiveRun] = None

        # Initialize with system prompt
        trimmed_prompt = options.system_prompt.strip()
        self.base_system_prompt = trimmed_prompt if trimmed_prompt else None

        if trimmed_prompt:
            self.messages.append(SystemMessage(role="system", content=trimmed_prompt))

    async def send(self, text: str, use_streaming: bool = False) -> str:
        """
        Send a user message and get response.

        Args:
            text: User message text
            use_streaming: Whether to use streaming mode

        Returns:
            Final assistant response
        """
        prompt = text.strip()
        if not prompt:
            return ""

        # Add user message
        self.messages.append(UserMessage(role="user", content=prompt))

        # Track run timing
        run = ActiveRun(started_at=time.time())
        self.active_run = run

        try:
            # Check if provider supports streaming
            if use_streaming and hasattr(self.provider, "generate_stream"):
                return await self._process_conversation_streaming()
            return await self._process_conversation()
        finally:
            if self.active_run == run:
                self.active_run = None

    async def _process_conversation(self) -> str:
        """Process conversation in non-streaming mode."""
        while True:
            # Prune messages if approaching context limit (BEFORE generation)
            await self._prune_messages_if_needed()

            # Generate response
            response = await self.provider.generate(self.messages, self._provider_tools)
            usage = response.usage
            context_stats = self._get_context_stats()

            # Handle tool calls
            if response.type == "tool_calls":
                narration = response.content.strip() if response.content else ""
                if narration:
                    self._emit_assistant_message(
                        narration,
                        AssistantMessageMetadata(is_final=False, usage=usage, context_stats=context_stats),
                    )

                # Create assistant message with tool calls
                assistant_message = AssistantMessage(
                    role="assistant",
                    content=response.content or "",
                    tool_calls=response.tool_calls,
                )
                self.messages.append(assistant_message)

                # Execute tool calls
                await self._resolve_tool_calls(response.tool_calls)
                continue

            # Final message
            reply = response.content.strip() if response.content else ""
            if reply:
                self._emit_assistant_message(
                    reply,
                    AssistantMessageMetadata(is_final=True, usage=usage, context_stats=context_stats),
                )

            self.messages.append(AssistantMessage(role="assistant", content=reply))
            return reply

    async def _process_conversation_streaming(self) -> str:
        """Process conversation in streaming mode."""
        if not hasattr(self.provider, "generate_stream"):
            return await self._process_conversation()

        while True:
            # Prune messages if approaching context limit (BEFORE generation)
            await self._prune_messages_if_needed()

            full_content = ""
            tool_calls: list[ToolCallRequest] = []
            usage: Optional[ProviderUsage] = None

            # Stream response
            stream = self.provider.generate_stream(self.messages, self._provider_tools)

            async for chunk in stream:
                if chunk.type == "content" and chunk.content:
                    full_content += chunk.content
                    if self.callbacks:
                        self.callbacks.on_stream_chunk(chunk.content)
                elif chunk.type == "tool_call" and chunk.tool_call:
                    tool_calls.append(chunk.tool_call)
                elif chunk.type == "usage" and chunk.usage:
                    usage = chunk.usage

            context_stats = self._get_context_stats()

            # Check if we got tool calls
            if tool_calls:
                narration = full_content.strip()
                if narration:
                    self._emit_assistant_message(
                        narration,
                        AssistantMessageMetadata(is_final=False, usage=usage, context_stats=context_stats),
                    )

                assistant_message = AssistantMessage(
                    role="assistant",
                    content=full_content,
                    tool_calls=tool_calls,
                )
                self.messages.append(assistant_message)

                # Execute tool calls
                await self._resolve_tool_calls(tool_calls)
                continue

            # Final message
            reply = full_content.strip()
            if reply:
                self._emit_assistant_message(
                    reply,
                    AssistantMessageMetadata(is_final=True, usage=usage, context_stats=context_stats),
                )

            self.messages.append(AssistantMessage(role="assistant", content=reply))
            return reply

    async def _resolve_tool_calls(self, tool_calls: list[ToolCallRequest]) -> None:
        """
        Execute tool calls in parallel.

        Args:
            tool_calls: List of tool calls to execute
        """
        # Stop any active spinner before showing tool calls
        # The spinner can interfere with tool call display
        # Don't add newline since tool calls follow immediately
        if ui_display:
            ui_display.stop_thinking(add_newline=False)

        # Show tool calls in Claude Code style if UI is available
        if ui_display:
            for call in tool_calls:
                ui_display.show_tool_call(call.name, call.arguments or {})

        # Execute all tool calls in parallel for better performance
        tasks = [self.tool_runtime.execute(call) for call in tool_calls]
        outputs = await asyncio.gather(*tasks)

        # Add results to messages and show in UI
        for call, output in zip(tool_calls, outputs):
            # Add to conversation history
            self.messages.append(
                ToolMessage(
                    role="tool",
                    name=call.name,
                    tool_call_id=call.id,
                    content=output,
                )
            )

            # Show result in UI if available
            if ui_display:
                success = not (output and ("Error" in output or "error" in output))
                ui_display.show_tool_result(call.name, output, success=success)

        # Restart spinner for next LLM call with intelligent status
        if ui_display:
            ui_display.show_thinking(phase="generating")

    @property
    def _provider_tools(self) -> list[ProviderToolDefinition]:
        """Get list of tools for provider."""
        return self.tool_runtime.list_provider_tools()

    def _emit_assistant_message(self, content: str, metadata: AssistantMessageMetadata) -> None:
        """
        Emit assistant message callback.

        Args:
            content: Message content
            metadata: Message metadata
        """
        if not content:
            return

        # Calculate elapsed time
        if self.active_run:
            elapsed_ms = (time.time() - self.active_run.started_at) * 1000
            metadata.elapsed_ms = elapsed_ms

        if self.callbacks:
            self.callbacks.on_assistant_message(content, metadata)

    def get_history(self) -> list[ConversationMessage]:
        """
        Get conversation history.

        Returns:
            Cloned list of messages
        """
        return [_clone_message(msg) for msg in self.messages]

    def load_history(self, history: list[ConversationMessage]) -> None:
        """
        Load conversation history.

        Args:
            history: List of messages to load
        """
        self.messages.clear()

        if not history:
            if self.base_system_prompt:
                self.messages.append(SystemMessage(role="system", content=self.base_system_prompt))
            return

        for message in history:
            self.messages.append(_clone_message(message))

    def clear_history(self) -> None:
        """Clear conversation history."""
        self.messages.clear()

        if self.base_system_prompt:
            self.messages.append(SystemMessage(role="system", content=self.base_system_prompt))

    async def _prune_messages_if_needed(self) -> None:
        """
        Prune messages if approaching context limit.

        This runs BEFORE each generation to ensure we stay within budget.
        If LLM summarization is available, it will create intelligent summaries
        instead of just removing old messages.
        """
        if not self.context_manager:
            return

        if self.context_manager.is_approaching_limit(self.messages):
            # Try LLM-based summarization first (preserves context better)
            result = await self.context_manager.prune_messages_with_summary(self.messages)

            if result.removed > 0:
                # Replace messages with pruned/summarized version
                self.messages.clear()
                self.messages.extend(result.pruned)

                # Notify callback with enriched stats
                stats = self.context_manager.get_stats(self.messages)
                enriched_stats = {
                    "total_tokens": stats.total_tokens,
                    "percentage": stats.percentage,
                    "is_over_limit": stats.is_over_limit,
                    "is_approaching_limit": stats.is_approaching_limit,
                    "summarized": result.summarized,
                    "method": "llm-summary" if result.summarized else "simple-prune",
                }

                if self.callbacks:
                    self.callbacks.on_context_pruned(result.removed, enriched_stats)

                # Debug logging
                if os.environ.get("DEBUG_CONTEXT"):
                    method = "Summarized" if result.summarized else "Pruned"
                    print(
                        f"[Context Manager] {method} {result.removed} messages. "
                        f"Tokens: {stats.total_tokens} ({stats.percentage}%)"
                    )

    def _get_context_stats(self) -> Optional[dict[str, Any]]:
        """
        Get current context statistics.

        Returns:
            Context stats dictionary or None
        """
        if not self.context_manager:
            return None

        stats = self.context_manager.get_stats(self.messages)
        return {
            "total_tokens": stats.total_tokens,
            "percentage": stats.percentage,
            "is_over_limit": stats.is_over_limit,
            "is_approaching_limit": stats.is_approaching_limit,
        }

    def get_context_manager(self) -> Optional[ContextManager]:
        """
        Get context manager instance.

        Returns:
            Context manager or None
        """
        return self.context_manager


def _clone_message(message: ConversationMessage) -> ConversationMessage:
    """
    Clone a message to prevent mutations.

    Args:
        message: Message to clone

    Returns:
        Cloned message
    """
    if isinstance(message, AssistantMessage):
        clone = AssistantMessage(
            role="assistant",
            content=message.content,
        )
        if message.tool_calls:
            clone.tool_calls = [_clone_tool_call(call) for call in message.tool_calls]
        return clone

    elif isinstance(message, ToolMessage):
        return ToolMessage(
            role="tool",
            name=message.name,
            content=message.content,
            tool_call_id=message.tool_call_id,
        )

    elif isinstance(message, SystemMessage):
        return SystemMessage(role="system", content=message.content)

    else:  # UserMessage or default
        return UserMessage(role="user", content=message.content)


def _clone_tool_call(call: ToolCallRequest) -> ToolCallRequest:
    """
    Clone a tool call request.

    Args:
        call: Tool call to clone

    Returns:
        Cloned tool call
    """
    return ToolCallRequest(
        id=call.id,
        name=call.name,
        arguments=copy.deepcopy(call.arguments),
    )
