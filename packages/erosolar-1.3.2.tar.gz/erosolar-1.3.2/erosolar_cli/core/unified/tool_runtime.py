"""
Unified Tool Runtime

Core tool execution engine with caching, validation, and lifecycle management.
Combines the best features from both TypeScript and Python implementations.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

import asyncio
import hashlib
import json
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set

from .types import (
    ProviderToolDefinition,
    ToolCallRequest,
    ToolCallResult,
    ToolDefinition,
    ToolRecord,
    ToolSuite,
)
from .schema import ToolArgumentValidationError, validate_tool_arguments


# ============================================================================
# Constants
# ============================================================================

CACHEABLE_TOOLS: Set[str] = {
    "Read", "read", "read_file",
    "Glob", "glob", "glob_search",
    "Grep", "grep", "grep_search",
    "WebSearch", "web_search",
    "WebFetch", "web_fetch",
    "find_definition",
    "analyze_code_quality",
    "analyze_complexity",
    "find_dependencies",
}


# ============================================================================
# Configuration
# ============================================================================

@dataclass
class ToolRuntimeConfig:
    """Configuration for the tool runtime."""
    enable_cache: bool = True
    cache_ttl_ms: int = 5 * 60 * 1000  # 5 minutes
    max_cache_size: int = 1000
    default_timeout_ms: int = 120_000  # 2 minutes
    network_timeout_ms: int = 30_000  # 30 seconds
    max_output_length: int = 100_000  # 100k chars
    verbose: bool = False


@dataclass
class CacheEntry:
    """A cache entry for tool results."""
    output: str
    timestamp: float
    ttl: int
    hit_count: int = 0


# ============================================================================
# Observer Interface
# ============================================================================

class ToolRuntimeObserver(ABC):
    """Observer interface for tool lifecycle events."""

    def on_tool_start(self, call: ToolCallRequest) -> None:
        """Called when tool execution starts."""
        pass

    def on_tool_result(self, call: ToolCallRequest, result: ToolCallResult) -> None:
        """Called when tool execution completes."""
        pass

    def on_tool_error(self, call: ToolCallRequest, error: Exception) -> None:
        """Called when tool execution fails."""
        pass

    def on_cache_hit(self, call: ToolCallRequest, entry: CacheEntry) -> None:
        """Called when a cache hit occurs."""
        pass

    def on_cache_miss(self, call: ToolCallRequest) -> None:
        """Called when a cache miss occurs."""
        pass

    def on_validation_error(self, call: ToolCallRequest, error: ToolArgumentValidationError) -> None:
        """Called when argument validation fails."""
        pass

    def on_tool_warning(self, call: ToolCallRequest, warning: str) -> None:
        """Called when a tool execution has pre-flight warnings."""
        pass


# ============================================================================
# Tool Runtime
# ============================================================================

class ToolRuntime:
    """
    Unified Tool Runtime.

    Manages tool registration, execution, caching, and validation.
    """

    def __init__(self, config: Optional[ToolRuntimeConfig] = None):
        self.config = config or ToolRuntimeConfig()
        self._registry: Dict[str, ToolRecord] = {}
        self._cache: Dict[str, CacheEntry] = {}
        self._observers: List[ToolRuntimeObserver] = []
        self._stats = {
            "total_calls": 0,
            "cache_hits": 0,
            "errors": 0,
            "total_time_ms": 0,
        }

    # =========================================================================
    # Registration
    # =========================================================================

    def register_suite(self, suite: ToolSuite) -> None:
        """Register a tool suite."""
        for tool in suite.tools:
            self.register_tool(tool, suite.name)

        if self.config.verbose:
            print(f"[ToolRuntime] Registered suite: {suite.name} ({len(suite.tools)} tools)")

    def register_tool(self, tool: ToolDefinition, suite_name: str = "default") -> None:
        """Register a single tool."""
        record = ToolRecord(
            definition=tool,
            suite=suite_name,
            enabled=True,
            execution_count=0,
        )

        self._registry[tool.name] = record

        # Also register lowercase for case-insensitive lookup
        if tool.name != tool.name.lower():
            self._registry[tool.name.lower()] = record

    def unregister_tool(self, name: str) -> bool:
        """Unregister a tool."""
        record = self._registry.get(name)
        if not record:
            return False

        del self._registry[name]
        if name.lower() in self._registry:
            del self._registry[name.lower()]
        return True

    def get_tool(self, name: str) -> Optional[ToolRecord]:
        """Get a tool by name."""
        return self._registry.get(name) or self._registry.get(name.lower())

    def has_tool(self, name: str) -> bool:
        """Check if a tool exists."""
        return name in self._registry or name.lower() in self._registry

    def set_tool_enabled(self, name: str, enabled: bool) -> bool:
        """Enable or disable a tool."""
        record = self.get_tool(name)
        if not record:
            return False
        record.enabled = enabled
        return True

    # =========================================================================
    # Execution
    # =========================================================================

    async def execute(self, call: ToolCallRequest) -> ToolCallResult:
        """Execute a tool call."""
        start_time = time.time() * 1000
        self._stats["total_calls"] += 1

        # Look up tool
        record = self.get_tool(call.name)
        if not record:
            return self._create_error_result(call, start_time, f"Unknown tool: {call.name}")

        if not record.enabled:
            return self._create_error_result(call, start_time, f"Tool is disabled: {call.name}")

        tool = record.definition

        # Notify observers
        self._notify_observers("on_tool_start", call)

        # Check cache
        if self.config.enable_cache and self._is_cacheable(tool):
            cache_key = self._get_cache_key(call)
            cached = self._cache.get(cache_key)

            if cached and not self._is_cache_expired(cached):
                cached.hit_count += 1
                self._stats["cache_hits"] += 1
                self._notify_observers("on_cache_hit", call, cached)

                return ToolCallResult(
                    tool_call_id=call.id,
                    output=cached.output,
                    success=True,
                    cached=True,
                    duration_ms=time.time() * 1000 - start_time,
                )

            self._notify_observers("on_cache_miss", call)

        # Validate arguments
        try:
            validate_tool_arguments(call.name, tool.parameters, call.arguments)
        except ToolArgumentValidationError as e:
            self._notify_observers("on_validation_error", call, e)
            return self._create_error_result(call, start_time, str(e))

        # Execute tool
        try:
            output = await self._execute_with_timeout(tool, call.arguments)
            truncated_output = self._truncate_output(output, call.name)
            duration_ms = time.time() * 1000 - start_time

            # Update stats
            record.execution_count += 1
            record.last_executed = time.time()
            self._stats["total_time_ms"] += duration_ms

            # Cache result if cacheable
            if self.config.enable_cache and self._is_cacheable(tool):
                self._cache_result(call, truncated_output)

            result = ToolCallResult(
                tool_call_id=call.id,
                output=truncated_output,
                success=True,
                cached=False,
                duration_ms=duration_ms,
            )

            self._notify_observers("on_tool_result", call, result)
            return result

        except Exception as e:
            self._stats["errors"] += 1
            self._notify_observers("on_tool_error", call, e)
            return self._create_error_result(call, start_time, str(e))

    async def _execute_with_timeout(
        self,
        tool: ToolDefinition,
        args: Dict[str, Any]
    ) -> str:
        """Execute with timeout."""
        timeout_sec = self.config.default_timeout_ms / 1000

        try:
            result = tool.execute(args)
            if asyncio.iscoroutine(result):
                result = await asyncio.wait_for(result, timeout=timeout_sec)
            return result
        except asyncio.TimeoutError:
            raise TimeoutError(f"Tool execution timed out after {self.config.default_timeout_ms}ms")

    def _create_error_result(
        self,
        call: ToolCallRequest,
        start_time: float,
        error: str
    ) -> ToolCallResult:
        """Create an error result."""
        return ToolCallResult(
            tool_call_id=call.id,
            output=f"Error: {error}",
            success=False,
            cached=False,
            duration_ms=time.time() * 1000 - start_time,
            error=error,
        )

    # =========================================================================
    # Caching
    # =========================================================================

    def _is_cacheable(self, tool: ToolDefinition) -> bool:
        """Check if a tool's results can be cached."""
        if tool.cacheable is not None:
            return tool.cacheable
        return tool.name in CACHEABLE_TOOLS

    def _get_cache_key(self, call: ToolCallRequest) -> str:
        """Generate cache key for a tool call."""
        args_str = json.dumps(call.arguments, sort_keys=True)
        return f"{call.name}:{args_str}"

    def _is_cache_expired(self, entry: CacheEntry) -> bool:
        """Check if a cache entry has expired."""
        return (time.time() * 1000 - entry.timestamp) > entry.ttl

    def _cache_result(self, call: ToolCallRequest, output: str) -> None:
        """Cache a result."""
        # Enforce max cache size
        if len(self._cache) >= self.config.max_cache_size:
            self._evict_oldest_entries(int(self.config.max_cache_size * 0.2))

        cache_key = self._get_cache_key(call)
        self._cache[cache_key] = CacheEntry(
            output=output,
            timestamp=time.time() * 1000,
            ttl=self.config.cache_ttl_ms,
            hit_count=0,
        )

    def _evict_oldest_entries(self, count: int) -> None:
        """Evict oldest cache entries."""
        entries = sorted(self._cache.items(), key=lambda x: x[1].timestamp)

        for i in range(min(count, len(entries))):
            del self._cache[entries[i][0]]

    def clear_cache(self) -> None:
        """Clear all cache entries."""
        self._cache.clear()

    def clear_expired_cache(self) -> int:
        """Clear expired cache entries."""
        cleared = 0
        keys_to_delete = []

        for key, entry in self._cache.items():
            if self._is_cache_expired(entry):
                keys_to_delete.append(key)

        for key in keys_to_delete:
            del self._cache[key]
            cleared += 1

        return cleared

    # =========================================================================
    # Output Handling
    # =========================================================================

    def _truncate_output(self, output: str, tool_name: str) -> str:
        """
        Truncate output if too long.

        PERF: Uses efficient slicing - O(1) for length check, O(n) for truncation only when needed.
        Tool-specific strategies maximize useful content retention.
        """
        max_length = self.config.max_output_length
        output_len = len(output)

        # Fast path: no truncation needed
        if output_len <= max_length:
            return output

        truncated_count = output_len - max_length
        tool_lower = tool_name.lower()

        # For file reads, keep head and tail for better context
        if "read" in tool_lower or tool_lower in ("glob", "grep"):
            # Keep 70% head, 30% tail (minus notice overhead)
            notice_len = 50
            usable_len = max_length - notice_len
            head_size = int(usable_len * 0.7)
            tail_size = usable_len - head_size
            return (
                output[:head_size] +
                f"\n\n... [truncated {truncated_count} characters] ...\n\n" +
                output[-tail_size:]
            )

        # For bash/command output, keep more of the tail (errors usually at end)
        if "bash" in tool_lower or tool_lower == "execute":
            notice_len = 50
            usable_len = max_length - notice_len
            tail_size = int(usable_len * 0.8)
            head_size = usable_len - tail_size
            return (
                output[:head_size] +
                f"\n\n... [truncated {truncated_count} characters] ...\n\n" +
                output[-tail_size:]
            )

        # Default: keep head only (fastest)
        return output[:max_length - 50] + f"\n... [truncated {truncated_count} characters]"

    # =========================================================================
    # Observers
    # =========================================================================

    def add_observer(self, observer: ToolRuntimeObserver) -> None:
        """Add an observer."""
        self._observers.append(observer)

    def remove_observer(self, observer: ToolRuntimeObserver) -> bool:
        """Remove an observer."""
        if observer in self._observers:
            self._observers.remove(observer)
            return True
        return False

    def _notify_observers(self, event: str, *args) -> None:
        """Notify observers of an event."""
        for observer in self._observers:
            handler = getattr(observer, event, None)
            if handler:
                try:
                    handler(*args)
                except Exception as e:
                    if self.config.verbose:
                        print(f"[ToolRuntime] Observer error: {e}")

    # =========================================================================
    # Provider Integration
    # =========================================================================

    def list_provider_tools(self) -> List[ProviderToolDefinition]:
        """Get tools in provider format."""
        tools: List[ProviderToolDefinition] = []
        seen: Set[str] = set()

        for name, record in self._registry.items():
            if not record.enabled or record.definition.name in seen:
                continue
            seen.add(record.definition.name)

            tool = record.definition
            tools.append(ProviderToolDefinition(
                type="function",
                function={
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            ))

        return tools

    def get_tools_by_category(self, category: str) -> List[ToolRecord]:
        """Get tools for a specific category."""
        tools: List[ToolRecord] = []
        seen: Set[str] = set()

        for record in self._registry.values():
            if (
                record.definition.category == category and
                record.enabled and
                record.definition.name not in seen
            ):
                seen.add(record.definition.name)
                tools.append(record)

        return tools

    # =========================================================================
    # Statistics
    # =========================================================================

    def get_stats(self) -> Dict[str, Any]:
        """Get execution statistics."""
        total_calls = self._stats["total_calls"]
        return {
            "total_calls": total_calls,
            "cache_hits": self._stats["cache_hits"],
            "cache_hit_rate": self._stats["cache_hits"] / total_calls if total_calls > 0 else 0,
            "errors": self._stats["errors"],
            "error_rate": self._stats["errors"] / total_calls if total_calls > 0 else 0,
            "avg_execution_time_ms": self._stats["total_time_ms"] / total_calls if total_calls > 0 else 0,
            "registered_tools": len(set(r.definition.name for r in self._registry.values())),
            "cache_size": len(self._cache),
        }

    def reset_stats(self) -> None:
        """Reset statistics."""
        self._stats = {
            "total_calls": 0,
            "cache_hits": 0,
            "errors": 0,
            "total_time_ms": 0,
        }

    def get_tool_execution_counts(self) -> Dict[str, int]:
        """Get tool execution counts."""
        counts: Dict[str, int] = {}
        seen: Set[str] = set()

        for record in self._registry.values():
            if record.definition.name not in seen:
                seen.add(record.definition.name)
                counts[record.definition.name] = record.execution_count

        return counts


# ============================================================================
# Factory Functions
# ============================================================================

def create_tool_runtime(config: Optional[ToolRuntimeConfig] = None) -> ToolRuntime:
    """Create a tool runtime with default configuration."""
    return ToolRuntime(config)


def create_tool_suite(
    name: str,
    version: str,
    tools: List[ToolDefinition],
    description: Optional[str] = None
) -> ToolSuite:
    """Create a tool suite from definitions."""
    return ToolSuite(
        name=name,
        version=version,
        tools=tools,
        description=description,
    )
