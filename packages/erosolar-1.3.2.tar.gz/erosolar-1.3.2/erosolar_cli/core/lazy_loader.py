"""
Lazy Loading System for Erosolar CLI

Optimizes performance by deferring expensive operations until needed.
This prevents slow startup times for simple commands.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, Generic, Optional, TypeVar

T = TypeVar("T")


@dataclass
class LazyLoaderStats:
    """Statistics for a lazy loader."""
    name: str
    is_loaded: bool
    is_loading: bool
    load_count: int
    last_load_time: float


class LazyLoader(Generic[T]):
    """
    Lazy loader for expensive operations.

    Defers loading until the value is actually needed, and caches
    the result for subsequent accesses. Supports async loading
    with configurable timeout.
    """

    def __init__(
        self,
        name: str,
        loader: Callable[[], Awaitable[T]],
        timeout_ms: int = 30000,
        on_load: Optional[Callable[[T], None]] = None,
        on_error: Optional[Callable[[Exception], None]] = None,
    ):
        """
        Initialize lazy loader.

        Args:
            name: Identifier for this loader
            loader: Async function to load the value
            timeout_ms: Timeout in milliseconds (default 30s)
            on_load: Optional callback when loading succeeds
            on_error: Optional callback when loading fails
        """
        self._name = name
        self._loader = loader
        self._timeout_ms = timeout_ms
        self._on_load = on_load
        self._on_error = on_error

        self._value: Optional[T] = None
        self._loading = False
        self._load_task: Optional[asyncio.Task[T]] = None
        self._last_load_time: float = 0
        self._load_count: int = 0

    async def get(self) -> T:
        """Get the value, loading it if necessary."""
        # Return cached value if available
        if self._value is not None:
            return self._value

        # Return existing load task if loading
        if self._load_task is not None:
            return await self._load_task

        # Start loading
        self._loading = True
        self._load_task = asyncio.create_task(self._load_with_timeout())

        try:
            self._value = await self._load_task
            self._load_count += 1
            self._last_load_time = time.time()

            if self._on_load:
                self._on_load(self._value)

            return self._value
        except Exception as e:
            if self._on_error:
                self._on_error(e)
            raise
        finally:
            self._loading = False
            self._load_task = None

    def is_loaded(self) -> bool:
        """Check if the value is loaded."""
        return self._value is not None

    def is_loading(self) -> bool:
        """Check if currently loading."""
        return self._loading

    def get_cached(self) -> Optional[T]:
        """Get the cached value without loading."""
        return self._value

    async def reload(self) -> T:
        """Force reload the value."""
        self._value = None
        self._load_task = None
        return await self.get()

    def clear(self) -> None:
        """Clear the cached value."""
        self._value = None
        self._load_task = None
        self._loading = False

    def get_stats(self) -> LazyLoaderStats:
        """Get loader statistics."""
        return LazyLoaderStats(
            name=self._name,
            is_loaded=self.is_loaded(),
            is_loading=self.is_loading(),
            load_count=self._load_count,
            last_load_time=self._last_load_time,
        )

    async def _load_with_timeout(self) -> T:
        """Load with timeout."""
        try:
            return await asyncio.wait_for(
                self._loader(),
                timeout=self._timeout_ms / 1000,
            )
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"LazyLoader timeout: {self._name} took longer than {self._timeout_ms}ms"
            )


class LazyLoaderRegistry:
    """
    Global lazy loader registry.

    Singleton that manages all lazy loaders in the application.
    """

    _instance: Optional["LazyLoaderRegistry"] = None

    def __init__(self) -> None:
        self._loaders: Dict[str, LazyLoader[Any]] = {}

    @classmethod
    def get_instance(cls) -> "LazyLoaderRegistry":
        """Get the singleton instance."""
        if cls._instance is None:
            cls._instance = LazyLoaderRegistry()
        return cls._instance

    def register(self, name: str, loader: LazyLoader[Any]) -> None:
        """Register a lazy loader."""
        self._loaders[name] = loader

    def get(self, name: str) -> Optional[LazyLoader[Any]]:
        """Get a lazy loader by name."""
        return self._loaders.get(name)

    def get_stats(self) -> Dict[str, LazyLoaderStats]:
        """Get all loader statistics."""
        return {name: loader.get_stats() for name, loader in self._loaders.items()}

    async def preload(self, names: list[str]) -> None:
        """Preload specific loaders in parallel."""
        tasks = []
        for name in names:
            loader = self._loaders.get(name)
            if loader:
                tasks.append(loader.get())

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    def clear_all(self) -> None:
        """Clear all loaders."""
        for loader in self._loaders.values():
            loader.clear()


def create_lazy_loader(
    name: str,
    loader: Callable[[], Awaitable[T]],
    timeout_ms: int = 30000,
    on_load: Optional[Callable[[T], None]] = None,
    on_error: Optional[Callable[[Exception], None]] = None,
) -> LazyLoader[T]:
    """Convenience function to create a lazy loader."""
    return LazyLoader(
        name=name,
        loader=loader,
        timeout_ms=timeout_ms,
        on_load=on_load,
        on_error=on_error,
    )


# ============================================================================
# Pre-configured Lazy Loaders for Erosolar Components
# ============================================================================

class ErosolarLazyLoaders:
    """Pre-configured lazy loaders for common Erosolar components."""

    @staticmethod
    def tools() -> LazyLoader[Dict[str, Any]]:
        """Create lazy loader for tool capabilities."""
        async def load_tools() -> Dict[str, Any]:
            from ..tooling import get_all_tools
            return {"tools": get_all_tools()}

        return create_lazy_loader(
            name="tools",
            loader=load_tools,
            timeout_ms=10000,
        )

    @staticmethod
    def providers() -> LazyLoader[Dict[str, Any]]:
        """Create lazy loader for AI providers."""
        async def load_providers() -> Dict[str, Any]:
            from ..providers.provider_factory import get_configured_providers
            return {"providers": get_configured_providers()}

        return create_lazy_loader(
            name="providers",
            loader=load_providers,
            timeout_ms=15000,
        )

    @staticmethod
    def workspace(root: Optional[str] = None) -> LazyLoader[Dict[str, Any]]:
        """Create lazy loader for workspace context."""
        import os

        async def load_workspace() -> Dict[str, Any]:
            from ..workspace import build_workspace_context
            return build_workspace_context(root or os.getcwd())

        return create_lazy_loader(
            name="workspace",
            loader=load_workspace,
            timeout_ms=5000,
        )

    @staticmethod
    def profiles() -> LazyLoader[list[str]]:
        """Create lazy loader for agent profiles."""
        async def load_profiles() -> list[str]:
            from ..config import PROFILES
            return list(PROFILES.keys())

        return create_lazy_loader(
            name="profiles",
            loader=load_profiles,
            timeout_ms=3000,
        )


def initialize_lazy_loaders() -> None:
    """Initialize the global lazy loader registry with common components."""
    registry = LazyLoaderRegistry.get_instance()

    # Register common loaders
    registry.register("tools", ErosolarLazyLoaders.tools())
    registry.register("providers", ErosolarLazyLoaders.providers())
    registry.register("workspace", ErosolarLazyLoaders.workspace())
    registry.register("profiles", ErosolarLazyLoaders.profiles())


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "LazyLoader",
    "LazyLoaderRegistry",
    "LazyLoaderStats",
    "create_lazy_loader",
    "ErosolarLazyLoaders",
    "initialize_lazy_loaders",
]
