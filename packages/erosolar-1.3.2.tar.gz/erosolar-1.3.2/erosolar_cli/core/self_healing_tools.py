"""
Self-Healing Tool Execution

Automatically detects and fixes common tool execution errors.
Provides intelligent parameter validation and correction.
"""

from __future__ import annotations

import json
from typing import Any, Callable, Optional

from .types import ProviderToolDefinition


class ToolExecutionError(Exception):
    """Error during tool execution."""

    def __init__(self, tool_name: str, error: Exception, arguments: dict[str, Any]):
        self.tool_name = tool_name
        self.original_error = error
        self.arguments = arguments
        super().__init__(f"Tool '{tool_name}' failed: {error}")


class SelfHealingToolExecutor:
    """Executes tools with automatic error recovery and fixing."""

    def __init__(self, enable_auto_fix: bool = True):
        """
        Initialize self-healing tool executor.

        Args:
            enable_auto_fix: Enable automatic fixing of tool arguments
        """
        self.enable_auto_fix = enable_auto_fix
        self.fix_attempts: dict[str, int] = {}

    async def execute_tool(
        self,
        tool_name: str,
        tool_function: Callable,
        arguments: dict[str, Any],
        tool_definition: Optional[ProviderToolDefinition] = None,
    ) -> Any:
        """
        Execute tool with automatic error recovery.

        Args:
            tool_name: Name of the tool
            tool_function: Function to execute
            arguments: Tool arguments
            tool_definition: Optional tool definition for validation

        Returns:
            Tool execution result

        Raises:
            ToolExecutionError if execution fails after fixes
        """
        # Try initial execution
        try:
            return await self._execute_with_validation(
                tool_function, arguments, tool_definition
            )
        except Exception as e:
            if not self.enable_auto_fix:
                raise ToolExecutionError(tool_name, e, arguments)

            # Try to fix and retry
            fixed_arguments = self._attempt_fix(tool_name, e, arguments, tool_definition)
            if fixed_arguments is None:
                raise ToolExecutionError(tool_name, e, arguments)

            # Retry with fixed arguments
            try:
                return await self._execute_with_validation(
                    tool_function, fixed_arguments, tool_definition
                )
            except Exception as retry_error:
                raise ToolExecutionError(tool_name, retry_error, fixed_arguments)

    async def _execute_with_validation(
        self,
        tool_function: Callable,
        arguments: dict[str, Any],
        tool_definition: Optional[ProviderToolDefinition],
    ) -> Any:
        """Execute with parameter validation."""
        # Validate arguments if definition is provided
        if tool_definition and tool_definition.parameters:
            validated_args = self._validate_and_coerce_arguments(
                arguments, tool_definition.parameters
            )
        else:
            validated_args = arguments

        # Execute tool
        if asyncio.iscoroutinefunction(tool_function):
            return await tool_function(**validated_args)
        else:
            return tool_function(**validated_args)

    def _validate_and_coerce_arguments(
        self, arguments: dict[str, Any], schema: Any
    ) -> dict[str, Any]:
        """Validate and coerce arguments to match schema."""
        if not hasattr(schema, "properties"):
            return arguments

        coerced = {}
        properties = schema.properties or {}

        for key, value in arguments.items():
            if key not in properties:
                # Extra parameter - include it anyway
                coerced[key] = value
                continue

            prop_schema = properties[key]
            prop_type = prop_schema.get("type") if isinstance(prop_schema, dict) else None

            # Type coercion
            if prop_type == "string" and not isinstance(value, str):
                coerced[key] = str(value)
            elif prop_type == "number" and not isinstance(value, (int, float)):
                try:
                    coerced[key] = float(value)
                except (ValueError, TypeError):
                    coerced[key] = value
            elif prop_type == "integer" and not isinstance(value, int):
                try:
                    coerced[key] = int(value)
                except (ValueError, TypeError):
                    coerced[key] = value
            elif prop_type == "boolean" and not isinstance(value, bool):
                if isinstance(value, str):
                    coerced[key] = value.lower() in ("true", "yes", "1")
                else:
                    coerced[key] = bool(value)
            else:
                coerced[key] = value

        # Add default values for missing required parameters
        if hasattr(schema, "required"):
            for required_key in schema.required or []:
                if required_key not in coerced:
                    # Try to add sensible default
                    prop_schema = properties.get(required_key, {})
                    if isinstance(prop_schema, dict):
                        prop_type = prop_schema.get("type")
                        if prop_type == "string":
                            coerced[required_key] = ""
                        elif prop_type == "number":
                            coerced[required_key] = 0.0
                        elif prop_type == "integer":
                            coerced[required_key] = 0
                        elif prop_type == "boolean":
                            coerced[required_key] = False
                        elif prop_type == "array":
                            coerced[required_key] = []
                        elif prop_type == "object":
                            coerced[required_key] = {}

        return coerced

    def _attempt_fix(
        self,
        tool_name: str,
        error: Exception,
        arguments: dict[str, Any],
        tool_definition: Optional[ProviderToolDefinition],
    ) -> Optional[dict[str, Any]]:
        """
        Attempt to fix arguments based on error.

        Returns:
            Fixed arguments or None if cannot fix
        """
        error_str = str(error).lower()

        # Track fix attempts to avoid infinite loops
        fix_key = f"{tool_name}:{type(error).__name__}"
        self.fix_attempts[fix_key] = self.fix_attempts.get(fix_key, 0) + 1
        if self.fix_attempts[fix_key] > 3:
            return None

        # Fix missing required parameter
        if "missing" in error_str and "required" in error_str:
            return self._fix_missing_parameter(arguments, error_str, tool_definition)

        # Fix type mismatch
        if "type" in error_str or "expected" in error_str:
            return self._fix_type_mismatch(arguments, error_str, tool_definition)

        # Fix JSON parsing error
        if "json" in error_str or "parse" in error_str:
            return self._fix_json_arguments(arguments)

        # Fix invalid value
        if "invalid" in error_str:
            return self._fix_invalid_value(arguments, error_str, tool_definition)

        return None

    def _fix_missing_parameter(
        self,
        arguments: dict[str, Any],
        error_str: str,
        tool_definition: Optional[ProviderToolDefinition],
    ) -> dict[str, Any]:
        """Fix missing required parameter."""
        fixed = arguments.copy()

        # Try to extract parameter name from error
        import re

        match = re.search(r"(?:parameter|argument|field)[:\s]+['\"]?(\w+)", error_str)
        if match:
            param_name = match.group(1)
            if param_name not in fixed:
                # Add with default value
                fixed[param_name] = ""

        # Use schema to add missing required parameters
        if tool_definition and tool_definition.parameters:
            schema = tool_definition.parameters
            if hasattr(schema, "required"):
                for required in schema.required or []:
                    if required not in fixed:
                        properties = getattr(schema, "properties", {})
                        prop = properties.get(required, {})
                        prop_type = (
                            prop.get("type") if isinstance(prop, dict) else None
                        )

                        if prop_type == "string":
                            fixed[required] = ""
                        elif prop_type == "number":
                            fixed[required] = 0.0
                        elif prop_type == "integer":
                            fixed[required] = 0
                        elif prop_type == "boolean":
                            fixed[required] = False
                        elif prop_type == "array":
                            fixed[required] = []
                        else:
                            fixed[required] = None

        return fixed

    def _fix_type_mismatch(
        self,
        arguments: dict[str, Any],
        error_str: str,
        tool_definition: Optional[ProviderToolDefinition],
    ) -> dict[str, Any]:
        """Fix type mismatch in parameters."""
        fixed = arguments.copy()

        # Use schema to coerce types
        if tool_definition and tool_definition.parameters:
            return self._validate_and_coerce_arguments(fixed, tool_definition.parameters)

        return fixed

    def _fix_json_arguments(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Fix JSON parsing issues in arguments."""
        fixed = {}

        for key, value in arguments.items():
            if isinstance(value, str):
                # Try to parse as JSON
                try:
                    parsed = json.loads(value)
                    fixed[key] = parsed
                except json.JSONDecodeError:
                    fixed[key] = value
            else:
                fixed[key] = value

        return fixed

    def _fix_invalid_value(
        self,
        arguments: dict[str, Any],
        error_str: str,
        tool_definition: Optional[ProviderToolDefinition],
    ) -> dict[str, Any]:
        """Fix invalid parameter values."""
        fixed = arguments.copy()

        # Remove None values
        fixed = {k: v for k, v in fixed.items() if v is not None}

        # Remove empty strings for non-string parameters
        if tool_definition and tool_definition.parameters:
            schema = tool_definition.parameters
            if hasattr(schema, "properties"):
                properties = schema.properties or {}
                for key, value in list(fixed.items()):
                    if value == "" and key in properties:
                        prop = properties[key]
                        prop_type = (
                            prop.get("type") if isinstance(prop, dict) else None
                        )
                        if prop_type != "string":
                            fixed.pop(key, None)

        return fixed

    def reset_fix_attempts(self) -> None:
        """Reset fix attempt counters."""
        self.fix_attempts.clear()


import asyncio

# Global self-healing executor
_global_executor: Optional[SelfHealingToolExecutor] = None


def get_self_healing_executor() -> SelfHealingToolExecutor:
    """Get global self-healing tool executor."""
    global _global_executor
    if _global_executor is None:
        _global_executor = SelfHealingToolExecutor()
    return _global_executor


def set_self_healing_executor(executor: SelfHealingToolExecutor) -> None:
    """Set global self-healing tool executor."""
    global _global_executor
    _global_executor = executor
