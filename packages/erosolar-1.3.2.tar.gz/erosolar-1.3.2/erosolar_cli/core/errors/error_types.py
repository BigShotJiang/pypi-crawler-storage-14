"""
Structured error types for better error handling and reporting.

Includes API key error detection matching TypeScript apiKeyErrors.ts functionality.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union


# ============================================================================
# API Key Error Detection (matches TypeScript apiKeyErrors.ts)
# ============================================================================

# Auth-related keywords for error detection
AUTH_KEYWORDS = [
    "api key",
    "apikey",
    "api-key",
    "authentication",
    "unauthorized",
    "permission_denied",
    "permission denied",
    "forbidden",
    "invalid_api_key",
    "invalid api key",
    "access_denied",
    "access denied",
    "not authorized",
    "credentials",
    "entitlement",
    "subscription",
]


@dataclass
class ApiKeyErrorInfo:
    """Information about an API key error."""
    error_type: str  # 'missing' or 'invalid'
    provider: Optional[str] = None
    message: Optional[str] = None


def detect_api_key_error(error: Any, provider: Optional[str] = None) -> Optional[ApiKeyErrorInfo]:
    """
    Detect if an error is related to API key issues.

    Args:
        error: The exception or error object
        provider: Optional provider ID for context

    Returns:
        ApiKeyErrorInfo if this is an API key error, None otherwise
    """
    if _is_unauthorized_error(error):
        return ApiKeyErrorInfo(
            error_type="invalid",
            provider=provider or _extract_provider_from_error(error),
            message=_extract_error_message(error),
        )
    return None


def _is_unauthorized_error(error: Any) -> bool:
    """Check if error indicates unauthorized/authentication issue."""
    # Check HTTP status codes
    status = _extract_status(error)
    if status in (401, 403):
        return True

    # Check structured error payload
    payload = _extract_structured_error(error)
    if payload:
        # Check type and code fields
        normalized_type = _normalize(payload.get("type")) or _normalize(payload.get("code"))
        if normalized_type and _contains_auth_keyword(normalized_type):
            return True

        # Check status field (e.g., "PERMISSION_DENIED")
        if payload.get("status") and _contains_auth_keyword(_normalize(payload.get("status"))):
            return True

        # Check reason field (e.g., "forbidden")
        if payload.get("reason") and _contains_auth_keyword(_normalize(payload.get("reason"))):
            return True

        # Check message field
        if payload.get("message") and _contains_auth_keyword(_normalize(payload.get("message"))):
            return True

    # Check error message directly
    message = _normalize(_extract_error_message(error))
    if message and _contains_auth_keyword(message):
        return True

    return False


def _extract_status(error: Any) -> Optional[int]:
    """Extract HTTP status code from error."""
    if not error:
        return None

    # Direct status attribute
    if hasattr(error, "status"):
        status = error.status
        if isinstance(status, int):
            return status

    # status_code attribute (common in HTTP libraries)
    if hasattr(error, "status_code"):
        status_code = error.status_code
        if isinstance(status_code, int):
            return status_code

    # Response object with status
    if hasattr(error, "response"):
        response = error.response
        if hasattr(response, "status"):
            return response.status if isinstance(response.status, int) else None
        if hasattr(response, "status_code"):
            return response.status_code if isinstance(response.status_code, int) else None

    return None


def _extract_structured_error(error: Any) -> Optional[Dict[str, Any]]:
    """Extract structured error info (handles nested Gemini-style errors)."""
    if not error:
        return None

    result: Dict[str, Any] = {}

    # Handle nested error.error structure (common in Google/Gemini errors)
    if hasattr(error, "error"):
        nested = error.error
        if isinstance(nested, dict):
            result["type"] = nested.get("type")
            result["code"] = str(nested.get("code", "")) if nested.get("code") else None
            result["message"] = nested.get("message")
            result["status"] = nested.get("status")
            # Extract reason from nested errors array (Gemini format)
            reason = nested.get("reason")
            if not reason:
                errors_list = nested.get("errors", [])
                if errors_list and isinstance(errors_list, list) and len(errors_list) > 0:
                    first_error = errors_list[0]
                    if isinstance(first_error, dict):
                        reason = first_error.get("reason")
            result["reason"] = reason
            return result

    # Handle dict-like errors
    if isinstance(error, dict):
        if "error" in error and isinstance(error["error"], dict):
            nested = error["error"]
            result["type"] = nested.get("type")
            result["code"] = str(nested.get("code", "")) if nested.get("code") else None
            result["message"] = nested.get("message")
            result["status"] = nested.get("status")
            reason = nested.get("reason")
            if not reason:
                errors_list = nested.get("errors", [])
                if errors_list and isinstance(errors_list, list) and len(errors_list) > 0:
                    first_error = errors_list[0]
                    if isinstance(first_error, dict):
                        reason = first_error.get("reason")
            result["reason"] = reason
            return result

        # Direct status/reason on error dict
        if error.get("status") or error.get("reason") or error.get("code"):
            return {
                "status": error.get("status"),
                "reason": error.get("reason"),
                "code": str(error.get("code", "")) if error.get("code") else None,
                "message": error.get("message"),
            }

    # Handle object attributes
    if hasattr(error, "status") or hasattr(error, "reason") or hasattr(error, "code"):
        return {
            "status": getattr(error, "status", None),
            "reason": getattr(error, "reason", None),
            "code": str(getattr(error, "code", "")) if hasattr(error, "code") else None,
            "message": getattr(error, "message", None),
        }

    return None


def _extract_provider_from_error(error: Any) -> Optional[str]:
    """Extract provider ID from error if present."""
    if hasattr(error, "provider"):
        provider = error.provider
        if isinstance(provider, str) and provider.strip():
            return provider.strip()
    return None


def _extract_error_message(error: Any) -> str:
    """Extract error message from various error types."""
    if isinstance(error, str):
        return error

    if isinstance(error, Exception):
        return str(error)

    if error:
        # Try structured error first
        payload = _extract_structured_error(error)
        if payload and payload.get("message"):
            return payload["message"]

        # Try message attribute
        if hasattr(error, "message"):
            msg = error.message
            if isinstance(msg, str):
                return msg

        # Try dict access
        if isinstance(error, dict) and "message" in error:
            return str(error["message"])

    return ""


def _contains_auth_keyword(value: Optional[str]) -> bool:
    """Check if value contains any auth-related keyword."""
    if not value:
        return False
    return any(keyword in value for keyword in AUTH_KEYWORDS)


def _normalize(value: Optional[Union[str, int]]) -> Optional[str]:
    """Normalize value to lowercase string."""
    if value is None:
        return None
    return str(value).lower()


# ============================================================================
# Base Structured Errors
# ============================================================================

@dataclass
class StructuredError:
    """Base class for structured errors."""

    code: str
    message: str
    details: Optional[dict[str, str]] = None
    suggestion: Optional[str] = None

    def to_display_string(self) -> str:
        """Format error for display to user."""
        lines = [f"Error [{self.code}]: {self.message}"]

        if self.details:
            lines.append("\nDetails:")
            for key, value in self.details.items():
                lines.append(f"  {key}: {value}")

        if self.suggestion:
            lines.append(f"\nSuggestion: {self.suggestion}")

        return "\n".join(lines)


class DangerousOperationError(Exception):
    """Raised when a dangerous operation is attempted."""

    def __init__(self, operation: str, reason: str, safe_alternative: Optional[str] = None):
        self.operation = operation
        self.reason = reason
        self.safe_alternative = safe_alternative

        message = f"Dangerous operation blocked: {reason}\nCommand: {operation}"
        if safe_alternative:
            message += f"\nSafe alternative: {safe_alternative}"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="DANGEROUS_OPERATION",
            message=self.reason,
            details={"command": self.operation},
            suggestion=self.safe_alternative,
        )


class BlockedOperationError(Exception):
    """Raised when an operation is blocked by policy."""

    def __init__(self, operation: str, policy: str, allowed_alternatives: Optional[list[str]] = None):
        self.operation = operation
        self.policy = policy
        self.allowed_alternatives = allowed_alternatives

        message = f"Operation blocked by policy: {policy}\nCommand: {operation}"
        if allowed_alternatives:
            message += f"\nAllowed alternatives: {', '.join(allowed_alternatives)}"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="BLOCKED_OPERATION",
            message=self.policy,
            details={"command": self.operation},
            suggestion=self.allowed_alternatives[0] if self.allowed_alternatives else None,
        )


class ContextOverflowError(Exception):
    """Raised when context size exceeds limits."""

    def __init__(self, actual: int, limit: int, unit: str, is_recoverable: bool = False):
        self.actual = actual
        self.limit = limit
        self.unit = unit
        self.is_recoverable = is_recoverable

        message = f"Context overflow: {actual} {unit} exceeds limit of {limit} {unit}"
        if is_recoverable:
            message += " (recoverable with truncation)"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="CONTEXT_OVERFLOW",
            message=f"Context size exceeds {self.limit} {self.unit}",
            details={"actual": str(self.actual), "limit": str(self.limit), "unit": self.unit},
            suggestion="Reduce context size or enable auto-truncation" if self.is_recoverable else None,
        )


class ResourceLimitError(Exception):
    """Raised when a resource limit is exceeded."""

    def __init__(self, resource: str, actual: int, limit: int, is_recoverable: bool = False):
        self.resource = resource
        self.actual = actual
        self.limit = limit
        self.is_recoverable = is_recoverable

        message = f"Resource limit exceeded: {resource}\nLimit: {limit}, Actual: {actual}"
        if is_recoverable:
            message += " (recoverable)"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="RESOURCE_LIMIT",
            message=f"{self.resource} limit exceeded",
            details={"limit": str(self.limit), "actual": str(self.actual)},
            suggestion=f"Reduce {self.resource} usage to below {self.limit}",
        )


class ValidationError(Exception):
    """Raised when validation fails."""

    def __init__(self, field: str, value: any, requirement: str, example: str):
        self.field = field
        self.value = value
        self.requirement = requirement
        self.example = example

        message = f"Validation failed for {field}: {requirement}\nReceived: {value}\nExample: {example}"
        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="VALIDATION_ERROR",
            message=f"{self.field}: {self.requirement}",
            details={"received": str(self.value)},
            suggestion=f"Use format: {self.example}",
        )


def to_structured_error(error: Exception) -> StructuredError:
    """
    Convert exception to structured error.

    Args:
        error: Exception to convert

    Returns:
        StructuredError instance
    """
    if hasattr(error, "to_structured"):
        return error.to_structured()

    # Generic error
    return StructuredError(
        code="GENERIC_ERROR",
        message=str(error),
    )
