"""
Secret Store for Erosolar CLI

Manages API keys and secrets with persistent storage.
Secrets are stored in ~/.erosolar/secrets.json and synced
with environment variables.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Literal, Optional

# ============================================================================
# Types
# ============================================================================

SecretName = Literal[
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "DEEPSEEK_API_KEY",
    "XAI_API_KEY",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
    "BRAVE_SEARCH_API_KEY",
    "SERPAPI_API_KEY",
    "TAVILY_API_KEY",
    "SMTP_USER",
    "SMTP_PASSWORD",
    "SMTP_PROVIDER",
    "SMTP_FROM_NAME",
    "SMTP_HOST",
    "SMTP_PORT",
]


@dataclass
class SecretDefinition:
    """Definition of a secret/API key."""
    id: str
    label: str
    description: str
    env_var: str
    providers: List[str]


# ============================================================================
# Secret Definitions
# ============================================================================

SECRET_DEFINITIONS: List[SecretDefinition] = [
    SecretDefinition(
        id="OPENAI_API_KEY",
        label="OpenAI API Key",
        description="Required to run OpenAI GPT models.",
        env_var="OPENAI_API_KEY",
        providers=["openai"],
    ),
    SecretDefinition(
        id="ANTHROPIC_API_KEY",
        label="Anthropic API Key",
        description="Required to run Anthropic Claude models.",
        env_var="ANTHROPIC_API_KEY",
        providers=["anthropic"],
    ),
    SecretDefinition(
        id="DEEPSEEK_API_KEY",
        label="DeepSeek API Key",
        description="Required to run DeepSeek Reasoner or Chat models.",
        env_var="DEEPSEEK_API_KEY",
        providers=["deepseek"],
    ),
    SecretDefinition(
        id="XAI_API_KEY",
        label="xAI API Key",
        description="Required to run Grok models from xAI.",
        env_var="XAI_API_KEY",
        providers=["xai"],
    ),
    SecretDefinition(
        id="GEMINI_API_KEY",
        label="Google Gemini API Key",
        description="Required to run Gemini models.",
        env_var="GEMINI_API_KEY",
        providers=["google"],
    ),
    SecretDefinition(
        id="GOOGLE_API_KEY",
        label="Google API Key (alias)",
        description="Alias for Gemini API key.",
        env_var="GOOGLE_API_KEY",
        providers=["google"],
    ),
    SecretDefinition(
        id="BRAVE_SEARCH_API_KEY",
        label="Brave Search API Key",
        description="Optional: unlock WebSearch using the Brave Search API.",
        env_var="BRAVE_SEARCH_API_KEY",
        providers=[],
    ),
    SecretDefinition(
        id="SERPAPI_API_KEY",
        label="SerpAPI Key",
        description="Optional: fallback WebSearch provider via SerpAPI.",
        env_var="SERPAPI_API_KEY",
        providers=[],
    ),
    SecretDefinition(
        id="TAVILY_API_KEY",
        label="Tavily API Key",
        description="Recommended: Primary WebSearch and WebExtract provider.",
        env_var="TAVILY_API_KEY",
        providers=[],
    ),
    SecretDefinition(
        id="SMTP_USER",
        label="Email Address",
        description="Your email address for sending emails.",
        env_var="SMTP_USER",
        providers=[],
    ),
    SecretDefinition(
        id="SMTP_PASSWORD",
        label="Email App Password",
        description="App password for your email (NOT your regular password).",
        env_var="SMTP_PASSWORD",
        providers=[],
    ),
    SecretDefinition(
        id="SMTP_PROVIDER",
        label="Email Provider",
        description="Email provider: gmail, outlook, yahoo, icloud, zoho.",
        env_var="SMTP_PROVIDER",
        providers=[],
    ),
    SecretDefinition(
        id="SMTP_FROM_NAME",
        label="Email Display Name",
        description="Optional: Display name shown in sent emails.",
        env_var="SMTP_FROM_NAME",
        providers=[],
    ),
    SecretDefinition(
        id="SMTP_HOST",
        label="Custom SMTP Host",
        description="Optional: Custom SMTP server hostname.",
        env_var="SMTP_HOST",
        providers=[],
    ),
    SecretDefinition(
        id="SMTP_PORT",
        label="Custom SMTP Port",
        description="Optional: Custom SMTP port (default: 587).",
        env_var="SMTP_PORT",
        providers=[],
    ),
]


# ============================================================================
# Paths
# ============================================================================

def _get_secret_dir() -> Path:
    """Get the secrets directory path."""
    env_home = os.environ.get("EROSOLAR_HOME")
    if env_home:
        return Path(env_home).resolve()
    return Path.home() / ".erosolar"


def _get_secret_file() -> Path:
    """Get the secrets file path."""
    return _get_secret_dir() / "secrets.json"


# ============================================================================
# Error Class
# ============================================================================

class MissingSecretError(Exception):
    """Raised when a required secret is not configured."""

    def __init__(self, secret: SecretDefinition):
        self.secret = secret
        super().__init__(f"{secret.label} is not configured.")


# ============================================================================
# Secret Store Functions
# ============================================================================

def list_secret_definitions() -> List[SecretDefinition]:
    """List all secret definitions."""
    return list(SECRET_DEFINITIONS)


def get_secret_value(secret_id: str) -> Optional[str]:
    """
    Get a secret value.

    Checks environment variables first, then falls back to stored secrets.

    Args:
        secret_id: The secret identifier (e.g., 'OPENAI_API_KEY')

    Returns:
        The secret value or None if not found
    """
    # Check environment variable first
    env_value = _sanitize(os.environ.get(secret_id))
    if env_value:
        return env_value

    # Check stored secrets
    store = _read_secret_store()
    stored_value = _sanitize(store.get(secret_id))
    if stored_value:
        # Sync to environment
        os.environ[secret_id] = stored_value
        return stored_value

    return None


def set_secret_value(secret_id: str, value: str) -> None:
    """
    Set a secret value.

    Stores the secret and syncs to environment.

    Args:
        secret_id: The secret identifier
        value: The secret value

    Raises:
        ValueError: If value is blank
    """
    clean_value = _sanitize(value)
    if not clean_value:
        raise ValueError("Secret value cannot be blank.")

    store = _read_secret_store()
    store[secret_id] = clean_value
    _write_secret_store(store)
    os.environ[secret_id] = clean_value


def delete_secret(secret_id: str) -> bool:
    """
    Delete a secret.

    Args:
        secret_id: The secret identifier

    Returns:
        True if deleted, False if not found
    """
    store = _read_secret_store()
    if secret_id in store:
        del store[secret_id]
        _write_secret_store(store)
        if secret_id in os.environ:
            del os.environ[secret_id]
        return True
    return False


def mask_secret(value: str) -> str:
    """
    Mask a secret value for display.

    Shows only last 4 characters.

    Args:
        value: The secret value

    Returns:
        Masked string (e.g., '****abcd')
    """
    if not value:
        return ""
    if len(value) <= 4:
        return "*" * len(value)
    suffix = value[-4:]
    prefix = "*" * max(0, len(value) - 4)
    return f"{prefix}{suffix}"


def ensure_secret_for_provider(provider: str) -> str:
    """
    Ensure a secret exists for a provider.

    Args:
        provider: The provider ID

    Returns:
        The secret value

    Raises:
        MissingSecretError: If secret is not configured
    """
    definition = get_secret_definition_for_provider(provider)
    if not definition:
        raise ValueError(f"No secret configuration for provider '{provider}'.")

    value = get_secret_value(definition.id)
    if not value:
        raise MissingSecretError(definition)

    os.environ[definition.env_var] = value
    return value


def get_secret_definition_for_provider(provider: str) -> Optional[SecretDefinition]:
    """
    Get the secret definition for a provider.

    Args:
        provider: The provider ID

    Returns:
        SecretDefinition or None
    """
    for secret in SECRET_DEFINITIONS:
        if provider in secret.providers:
            return secret
    return None


def get_configured_secrets() -> Dict[str, bool]:
    """
    Get which secrets are configured.

    Returns:
        Dict mapping secret ID to configured status
    """
    return {
        secret.id: get_secret_value(secret.id) is not None
        for secret in SECRET_DEFINITIONS
    }


def sync_secrets_to_env() -> None:
    """
    Sync all stored secrets to environment variables.

    Call this at startup to ensure all stored secrets are available.
    """
    store = _read_secret_store()
    for secret_id, value in store.items():
        clean_value = _sanitize(value)
        if clean_value and secret_id not in os.environ:
            os.environ[secret_id] = clean_value


# ============================================================================
# Internal Functions
# ============================================================================

def _read_secret_store() -> Dict[str, str]:
    """Read the secret store from disk."""
    secret_file = _get_secret_file()
    if not secret_file.exists():
        return {}

    try:
        content = secret_file.read_text(encoding="utf-8")
        parsed = json.loads(content)
        if isinstance(parsed, dict):
            return {k: v for k, v in parsed.items() if isinstance(v, str)}
    except (json.JSONDecodeError, OSError):
        pass

    return {}


def _write_secret_store(store: Dict[str, str]) -> None:
    """Write the secret store to disk."""
    secret_file = _get_secret_file()
    secret_file.parent.mkdir(parents=True, exist_ok=True)

    content = json.dumps(store, indent=2)
    secret_file.write_text(f"{content}\n", encoding="utf-8")


def _sanitize(value: Optional[str]) -> Optional[str]:
    """Sanitize a secret value."""
    if not isinstance(value, str):
        return None
    trimmed = value.strip()
    return trimmed if trimmed else None


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "SecretName",
    "SecretDefinition",
    "MissingSecretError",
    "list_secret_definitions",
    "get_secret_value",
    "set_secret_value",
    "delete_secret",
    "mask_secret",
    "ensure_secret_for_provider",
    "get_secret_definition_for_provider",
    "get_configured_secrets",
    "sync_secrets_to_env",
]
