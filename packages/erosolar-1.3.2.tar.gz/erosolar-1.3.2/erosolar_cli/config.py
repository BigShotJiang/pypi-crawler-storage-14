from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, List, Optional

DEFAULT_PROFILE = "default"


@dataclass(frozen=True)
class ProfileBlueprint:
  name: str
  label: str
  description: str
  default_provider: str
  default_model: str
  system_prompt_template: str
  temperature: float
  max_tokens: int


@dataclass(frozen=True)
class ResolvedProfile:
  name: str
  label: str
  provider: str
  model: str
  system_prompt: str
  temperature: float
  max_tokens: int
  model_locked: bool
  provider_locked: bool


# Built-in profiles
BUILTIN_PROFILES: Dict[str, ProfileBlueprint] = {
    "default": ProfileBlueprint(
        name="default",
        label="Default Assistant",
        description="General-purpose coding assistant",
        default_provider="auto",  # Auto-detect first available provider
        default_model="",  # Use provider's default model
        temperature=0.0,
        max_tokens=2048,
        system_prompt_template="""You are a helpful AI coding assistant with access to powerful file and command execution tools.

INTELLIGENT ERROR HANDLING - CRITICAL:
When tools fail/timeout, intelligently analyze and adapt:

TIMEOUT HANDLING:
- Network (30s): Target unreachable/DNS issues → Try alt targets, verify with ping/curl
- Operation (120s): Large data/resource limits → Break into smaller tasks, reduce scope

ERROR RECOVERY BY TYPE:
- Connection: Try different endpoints, verify with simpler tools
- Permission: Check auth needs, try without elevated privileges
- Not found (404): Verify path, search alternative locations
- Invalid input: Review arguments, try simpler syntax
- Resource exhaustion: Break into smaller ops, clean caches
- Rate limit (429): Wait before retry, reduce frequency

MANDATORY BEHAVIOR:
✓ READ error messages carefully
✓ IDENTIFY error type
✓ CHOOSE intelligent alternative approach
✓ CONTINUE toward goal with different methods
✓ TRY at least 2-3 alternatives before giving up
✓ NEVER repeat same failing operation without changes
✓ FOLLOW "**AI should:**" guidance in error messages

DECISION TREE:
Tool fails → Analyze error → Select recovery strategy → Try alternative → If fails → Try another (2-3 attempts) → Explain attempts and suggest next steps""",
    ),
    "fast": ProfileBlueprint(
        name="fast",
        label="Fast Assistant",
        description="Quick responses with smaller models",
        default_provider="auto",  # Auto-detect first available provider
        default_model="",  # Use provider's default model
        temperature=0.0,
        max_tokens=2048,
        system_prompt_template="You are a helpful AI coding assistant. Provide concise, focused responses.",
    ),
    "creative": ProfileBlueprint(
        name="creative",
        label="Creative Assistant",
        description="Creative coding with higher temperature",
        default_provider="auto",  # Auto-detect first available provider
        default_model="",  # Use provider's default model
        temperature=0.7,
        max_tokens=2048,
        system_prompt_template="You are a creative AI coding assistant. Think outside the box and explore innovative solutions.",
    ),
}


def resolve_profile(
    name: Optional[str] = None,
    workspace_context: Optional[str] = None,
    provider_override: Optional[str] = None,
    model_override: Optional[str] = None,
) -> ResolvedProfile:
    """
    Resolve a profile with environment overrides.

    Args:
        name: Profile name (defaults to EROSOLAR_PROFILE env var or "default")
        workspace_context: Optional workspace context to inject
        provider_override: Optional provider override (from CLI)
        model_override: Optional model override (from CLI)

    Returns:
        Resolved profile configuration
    """
    from .providers.provider_factory import auto_select_provider, get_default_model
    from .core.user_preferences import get_user_default_model, get_user_default_provider

    desired = (name or os.getenv("EROSOLAR_PROFILE") or DEFAULT_PROFILE).strip()
    blueprint = _get_profile(desired)

    env_prefix = _env_prefix(blueprint.name)
    model_env = os.getenv(f"{env_prefix}_MODEL")
    provider_env = os.getenv(f"{env_prefix}_PROVIDER")
    system_prompt_override = os.getenv(f"{env_prefix}_SYSTEM_PROMPT")

    # Priority: CLI > env var > user preference > profile default
    # Use auto_select_provider to find available provider
    user_provider = get_user_default_provider()
    raw_provider = provider_override or (provider_env.strip() if provider_env else None) or user_provider or blueprint.default_provider
    provider = auto_select_provider(raw_provider)

    # Get model - priority: CLI > env var > user preference > provider default
    user_model = get_user_default_model(provider)
    raw_model = model_override or (model_env.strip() if model_env else None) or user_model or blueprint.default_model
    model = raw_model if raw_model else get_default_model(provider)

    system_prompt = system_prompt_override.strip() if system_prompt_override else blueprint.system_prompt_template

    context_block = (
        f"\n\nWorkspace context (auto-detected):\n{workspace_context.strip()}"
        if workspace_context and workspace_context.strip()
        else ""
    )

    return ResolvedProfile(
        name=blueprint.name,
        label=blueprint.label,
        provider=provider,
        model=model,
        system_prompt=f"{system_prompt.strip()}{context_block}",
        temperature=blueprint.temperature,
        max_tokens=blueprint.max_tokens,
        model_locked=bool(model_override or model_env),
        provider_locked=bool(provider_override or provider_env),
    )


def list_profiles() -> List[str]:
    """List all available profile names."""
    return list(BUILTIN_PROFILES.keys())


def get_profile_info(name: str) -> ProfileBlueprint:
    """
    Get profile information.

    Args:
        name: Profile name

    Returns:
        Profile blueprint

    Raises:
        ValueError: If profile not found
    """
    return _get_profile(name)


def _get_profile(name: str) -> ProfileBlueprint:
    """Internal helper to get profile by name."""
    key = name.lower()
    if key in BUILTIN_PROFILES:
        return BUILTIN_PROFILES[key]

    # Try exact match
    for profile in BUILTIN_PROFILES.values():
        if profile.name.lower() == key:
            return profile

    available = ", ".join(sorted(BUILTIN_PROFILES.keys()))
    raise ValueError(f"Unknown profile '{name}'. Available: {available}")


def _env_prefix(profile: str) -> str:
    """Convert profile name to environment variable prefix."""
    return "".join(ch if ch.isalnum() else "_" for ch in profile.upper())
