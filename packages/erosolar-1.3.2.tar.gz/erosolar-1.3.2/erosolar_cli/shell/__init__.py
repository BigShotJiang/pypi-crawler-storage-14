"""
Shell Utilities for Erosolar CLI

Provides interactive shell, task completion detection, bracketed paste handling,
and other shell-related utilities.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from .interactive import InteractiveShell, launch_interactive_shell
from .task_completion import (
    ToolActivity,
    CompletionSignals,
    CompletionAnalysis,
    TaskCompletionDetector,
    get_task_completion_detector,
    reset_task_completion_detector,
    READ_ONLY_TOOLS,
    WRITE_TOOLS,
)
from .bracketed_paste import (
    BracketedPasteResult,
    MultiLinePasteState,
    BracketedPasteManager,
)

__all__ = [
    # Interactive Shell
    "InteractiveShell",
    "launch_interactive_shell",
    # Task Completion
    "ToolActivity",
    "CompletionSignals",
    "CompletionAnalysis",
    "TaskCompletionDetector",
    "get_task_completion_detector",
    "reset_task_completion_detector",
    "READ_ONLY_TOOLS",
    "WRITE_TOOLS",
    # Bracketed Paste
    "BracketedPasteResult",
    "MultiLinePasteState",
    "BracketedPasteManager",
]
