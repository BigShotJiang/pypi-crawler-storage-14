"""
Bracketed Paste Manager

Handles terminal paste operations with bracketed paste mode support.
Distinguishes pasted text from typed input and handles multi-line pastes.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple


# ============================================================================
# Types
# ============================================================================

@dataclass
class BracketedPasteResult:
    """Result from processing paste input."""
    handled: bool
    result: Optional[str] = None
    is_pending: bool = False
    line_count: int = 0
    preview: Optional[str] = None


@dataclass
class MultiLinePasteState:
    """State of a multi-line paste operation."""
    content: str
    line_count: int
    first_line_preview: str
    last_line_preview: str


# ============================================================================
# Bracketed Paste Manager
# ============================================================================

class BracketedPasteManager:
    """
    Bracketed paste manager for handling terminal paste operations.

    Handles the bracketed paste mode in terminals, which allows
    pasted text to be distinguished from typed input.
    """

    START_MARKER = "\x1b[200~"
    END_MARKER = "\x1b[201~"
    PASTE_THRESHOLD_MS = 50

    # Robustness limits
    MAX_PASTE_SIZE = 10_000_000  # 10MB max paste
    MAX_BUFFER_LINES = 100_000  # Max lines in buffer
    MAX_LINE_LENGTH = 1_000_000  # Max chars per line

    def __init__(self, enabled: bool = True) -> None:
        self._enabled = enabled
        self._in_paste = False
        self._paste_buffer: List[str] = []

        # Multi-line tracking without bracketed paste
        self._multi_line_buffer: List[str] = []
        self._multi_line_mode = False
        self._last_input_time = 0.0

        # Raw paste capture
        self._raw_paste_buffer = ""
        self._on_raw_paste_complete: Optional[Callable[[str], None]] = None
        self._capturing_raw = False
        self._is_disposed = False

    @property
    def enabled(self) -> bool:
        """Check if bracketed paste is enabled."""
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        """Set bracketed paste enabled state."""
        self._enabled = value

    def _sanitize_data(self, data: str) -> str:
        """Sanitize input data for safety."""
        if not isinstance(data, str):
            return ""

        # Truncate extremely long inputs
        if len(data) > self.MAX_PASTE_SIZE:
            data = data[:self.MAX_PASTE_SIZE]

        return data

    def process_raw_data(self, data: str) -> Tuple[bool, Optional[str]]:
        """
        Process raw data from stdin before readline handles it.

        Args:
            data: Raw input data

        Returns:
            Tuple of (consumed, pass_through) where consumed indicates if
            data was handled and pass_through is content to pass to readline
        """
        if not self._enabled or self._is_disposed:
            return (False, None)

        # Sanitize input
        data = self._sanitize_data(data)
        if not data:
            return (False, None)

        start_idx = data.find(self.START_MARKER)
        end_idx = data.find(self.END_MARKER)

        # Case 1: Not in paste mode and no start marker - pass through
        if not self._capturing_raw and start_idx == -1:
            return (False, None)

        # Case 2: Found start marker - begin capturing
        if not self._capturing_raw and start_idx != -1:
            self._capturing_raw = True
            before_start = data[:start_idx]
            after_start = data[start_idx + len(self.START_MARKER):]

            # Check if end marker is in same chunk
            end_in_after = after_start.find(self.END_MARKER)
            if end_in_after != -1:
                # Complete paste in single chunk
                paste_content = after_start[:end_in_after]
                after_end = after_start[end_in_after + len(self.END_MARKER):]
                self._capturing_raw = False
                self._raw_paste_buffer = ""

                # Emit the complete paste (with error handling)
                if self._on_raw_paste_complete:
                    try:
                        self._on_raw_paste_complete(paste_content)
                    except Exception:
                        pass  # Don't let callback errors break paste handling

                # Return any content before/after markers to be passed through
                pass_through = before_start + after_end
                return (True, pass_through if pass_through else None)

            # Start marker found but no end marker yet
            self._raw_paste_buffer = after_start
            return (True, before_start if before_start else None)

        # Case 3: Currently capturing and found end marker
        if self._capturing_raw and end_idx != -1:
            before_end = data[:end_idx]
            after_end = data[end_idx + len(self.END_MARKER):]

            paste_content = self._raw_paste_buffer + before_end
            self._capturing_raw = False
            self._raw_paste_buffer = ""

            # Check size limit
            if len(paste_content) > self.MAX_PASTE_SIZE:
                paste_content = paste_content[:self.MAX_PASTE_SIZE]

            # Emit the complete paste (with error handling)
            if self._on_raw_paste_complete:
                try:
                    self._on_raw_paste_complete(paste_content)
                except Exception:
                    pass  # Don't let callback errors break paste handling

            return (True, after_end if after_end else None)

        # Case 4: Currently capturing, no end marker - accumulate
        if self._capturing_raw:
            # Check buffer size limit
            if len(self._raw_paste_buffer) + len(data) > self.MAX_PASTE_SIZE:
                # Buffer overflow - truncate and complete
                remaining = self.MAX_PASTE_SIZE - len(self._raw_paste_buffer)
                self._raw_paste_buffer += data[:remaining]
                self._capturing_raw = False

                if self._on_raw_paste_complete:
                    try:
                        self._on_raw_paste_complete(self._raw_paste_buffer)
                    except Exception:
                        pass

                self._raw_paste_buffer = ""
                return (True, data[remaining:] if remaining < len(data) else None)

            self._raw_paste_buffer += data
            return (True, None)

        return (False, None)

    def set_raw_paste_callback(self, callback: Callable[[str], None]) -> None:
        """Set callback for when a complete paste is captured."""
        self._on_raw_paste_complete = callback

    def is_capturing_raw(self) -> bool:
        """Check if currently capturing raw paste data."""
        return self._capturing_raw

    def get_raw_buffer_line_count(self) -> int:
        """Get current raw buffer line count."""
        if not self._raw_paste_buffer:
            return 0
        return len(self._raw_paste_buffer.split("\n"))

    def get_raw_buffer_preview(self) -> str:
        """Get preview of raw buffer content."""
        if not self._raw_paste_buffer:
            return ""
        lines = self._raw_paste_buffer.split("\n")
        return self._get_preview(lines)

    def process(self, input_text: str) -> BracketedPasteResult:
        """
        Process input text, handling bracketed paste sequences.

        Args:
            input_text: Input string to process

        Returns:
            BracketedPasteResult with handled status and content
        """
        if not self._enabled:
            return self._process_without_bracketed(input_text)

        # If we're already in a paste, look for end marker
        if self._in_paste:
            end_idx = input_text.find(self.END_MARKER)

            if end_idx != -1:
                # End of paste found
                before_end = input_text[:end_idx]
                after_end = input_text[end_idx + len(self.END_MARKER):]

                self._paste_buffer.append(before_end)
                result = "\n".join(self._paste_buffer)
                line_count = len(self._paste_buffer)
                preview = self._get_preview(self._paste_buffer)

                # Reset state
                self._in_paste = False
                self._paste_buffer = []

                # If there's text after the end marker, process it
                if after_end:
                    after_result = self.process(after_end)
                    if after_result.handled and after_result.result is not None:
                        return BracketedPasteResult(
                            handled=True,
                            result=result + after_result.result,
                            line_count=line_count,
                            preview=preview,
                        )
                    return BracketedPasteResult(
                        handled=True,
                        result=result + after_end,
                        line_count=line_count,
                        preview=preview,
                    )

                return BracketedPasteResult(
                    handled=True,
                    result=result,
                    line_count=line_count,
                    preview=preview,
                )
            else:
                # Still in paste, no end marker found
                self._paste_buffer.append(input_text)
                return BracketedPasteResult(
                    handled=True,
                    is_pending=True,
                    line_count=len(self._paste_buffer),
                    preview=self._get_preview(self._paste_buffer),
                )

        # Not in paste, look for start marker
        start_idx = input_text.find(self.START_MARKER)

        if start_idx != -1:
            # Start of paste found
            before_start = input_text[:start_idx]
            after_start = input_text[start_idx + len(self.START_MARKER):]

            # Start paste mode
            self._in_paste = True
            self._paste_buffer = []

            # Process the text after the start marker
            if after_start:
                after_result = self.process(after_start)
                if after_result.handled and after_result.result is not None:
                    return BracketedPasteResult(
                        handled=True,
                        result=before_start + after_result.result,
                        line_count=after_result.line_count,
                        preview=after_result.preview,
                    )
                # Still pending
                return BracketedPasteResult(
                    handled=True,
                    result=before_start,
                    is_pending=self._in_paste,
                    line_count=len(self._paste_buffer),
                    preview=self._get_preview(self._paste_buffer),
                )

            return BracketedPasteResult(
                handled=True,
                result=before_start,
                is_pending=True,
                line_count=0,
            )

        # No paste markers found
        return BracketedPasteResult(handled=False)

    def _process_without_bracketed(self, input_text: str) -> BracketedPasteResult:
        """
        Process input when bracketed paste is not enabled.

        Uses timing heuristics to detect rapid multi-line input.
        """
        now = time.time()
        time_since_last = now - self._last_input_time
        self._last_input_time = now

        # Check if this looks like part of a rapid paste
        if time_since_last < (self.PASTE_THRESHOLD_MS / 1000) and len(self._multi_line_buffer) > 0:
            # Continue accumulating
            self._multi_line_buffer.append(input_text)
            self._multi_line_mode = True
            return BracketedPasteResult(
                handled=True,
                is_pending=True,
                line_count=len(self._multi_line_buffer),
                preview=self._get_preview(self._multi_line_buffer),
            )

        # If we were in multi-line mode and there's a pause, finalize
        if self._multi_line_mode and len(self._multi_line_buffer) > 0:
            self._multi_line_buffer.append(input_text)
            result = "\n".join(self._multi_line_buffer)
            line_count = len(self._multi_line_buffer)
            preview = self._get_preview(self._multi_line_buffer)

            self._multi_line_buffer = []
            self._multi_line_mode = False

            return BracketedPasteResult(
                handled=True,
                result=result,
                line_count=line_count,
                preview=preview,
            )

        # Check for embedded newlines (indicates paste)
        if "\n" in input_text:
            lines = input_text.split("\n")
            return BracketedPasteResult(
                handled=True,
                result=input_text,
                line_count=len(lines),
                preview=self._get_preview(lines),
            )

        # Start tracking for potential multi-line paste
        self._multi_line_buffer = [input_text]

        return BracketedPasteResult(handled=False)

    def _get_preview(self, lines: List[str]) -> str:
        """Generate a preview string for multi-line content."""
        if not lines:
            return ""

        first_line = lines[0] if lines else ""
        truncated_first = first_line[:47] + "..." if len(first_line) > 50 else first_line

        if len(lines) == 1:
            return truncated_first

        return f"{truncated_first} [+{len(lines) - 1} more lines]"

    def get_multi_line_state(self) -> Optional[MultiLinePasteState]:
        """Get current multi-line state for display purposes."""
        buffer = self._paste_buffer if self._in_paste else (
            self._multi_line_buffer if self._multi_line_mode else None
        )

        if not buffer:
            return None

        first_line = buffer[0] if buffer else ""
        last_line = buffer[-1] if buffer else ""

        return MultiLinePasteState(
            content="\n".join(buffer),
            line_count=len(buffer),
            first_line_preview=first_line[:37] + "..." if len(first_line) > 40 else first_line,
            last_line_preview=last_line[:37] + "..." if len(last_line) > 40 else last_line,
        )

    @staticmethod
    def format_collapsed_block(content: str, max_preview_length: int = 60) -> str:
        """Format a multi-line paste as a collapsed block for display."""
        lines = content.split("\n")
        if len(lines) <= 1:
            return content

        first_line = lines[0].strip() if lines else ""
        truncated_first = first_line[:max_preview_length - 3] + "..." if len(first_line) > max_preview_length else first_line

        return f"{truncated_first} [{len(lines)} lines]"

    def is_in_paste(self) -> bool:
        """Check if currently processing a paste."""
        return self._in_paste or self._multi_line_mode

    def get_paste_buffer(self) -> List[str]:
        """Get the current paste buffer."""
        return list(self._paste_buffer) if self._in_paste else list(self._multi_line_buffer)

    def finalize(self) -> Optional[str]:
        """Finalize any pending multi-line input."""
        if self._multi_line_mode and len(self._multi_line_buffer) > 1:
            result = "\n".join(self._multi_line_buffer)
            self._multi_line_buffer = []
            self._multi_line_mode = False
            return result
        return None

    def reset(self) -> None:
        """Reset the paste state."""
        self._in_paste = False
        self._paste_buffer = []
        self._multi_line_mode = False
        self._multi_line_buffer = []
        self._raw_paste_buffer = ""
        self._capturing_raw = False

    def dispose(self) -> None:
        """Dispose and cleanup resources."""
        self._is_disposed = True
        self.reset()
        self._on_raw_paste_complete = None

    def is_active(self) -> bool:
        """Check if manager is active and not disposed."""
        return not self._is_disposed and self._enabled


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "BracketedPasteResult",
    "MultiLinePasteState",
    "BracketedPasteManager",
]
