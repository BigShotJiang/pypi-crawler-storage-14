"""
Intelligent Task Completion Detector

Provides robust detection of whether a continuous task is truly complete,
rather than just pattern-matching keywords like "done" in responses.

Key features:
- Multi-signal analysis (tool usage, response content, state changes)
- AI verification round before final completion
- Confidence scoring
- Work-in-progress detection

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import List, Optional, Set


# ============================================================================
# Types
# ============================================================================

@dataclass
class ToolActivity:
    """Tool activity record."""
    tool_name: str
    timestamp: float
    success: bool
    has_output: bool


@dataclass
class CompletionSignals:
    """Completion signal indicators."""
    # Response content signals
    has_explicit_completion_statement: bool = False
    has_incomplete_work_indicators: bool = False
    has_pending_action_indicators: bool = False
    has_error_indicators: bool = False
    has_follow_up_questions: bool = False

    # Activity signals
    tools_used_in_last_response: int = 0
    last_tool_was_read_only: bool = False
    consecutive_responses_without_tools: int = 0
    has_recent_file_writes: bool = False
    has_recent_commits: bool = False

    # Context signals
    todo_items_pending: int = 0
    todo_items_completed: int = 0
    mentions_future_work: bool = False

    # Calculated confidence (0-1)
    completion_confidence: float = 0.0


@dataclass
class CompletionAnalysis:
    """Analysis result for task completion."""
    is_complete: bool
    confidence: float
    signals: CompletionSignals
    reason: str
    should_verify: bool
    verification_prompt: Optional[str] = None


# ============================================================================
# Patterns
# ============================================================================

# Keywords that strongly indicate task completion
STRONG_COMPLETION_PATTERNS = [
    re.compile(r"^(all\s+)?tasks?\s+(are\s+)?(now\s+)?(complete|done|finished)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^(i('ve|'m|\s+have|\s+am)\s+)?(successfully\s+)?(completed?|finished|done)\s+(all|the|with|everything)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^everything\s+(is\s+)?(now\s+)?(complete|done|finished)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^the\s+requested?\s+(task|work|changes?)\s+(is|are|has been)\s+(complete|done|finished)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^i\s+have\s+(now\s+)?(successfully\s+)?(completed?|finished|done)\s+(all|the|everything)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"no\s+(more|further)\s+(tasks?|work|actions?|changes?)\s+(are\s+)?(needed|required|necessary)", re.IGNORECASE | re.MULTILINE),
]

# Keywords that indicate work is still in progress
INCOMPLETE_WORK_PATTERNS = [
    re.compile(r"\b(next|then|now\s+I('ll|\s+will)|let\s+me|I('ll|\s+will)|going\s+to|about\s+to)\b", re.IGNORECASE),
    re.compile(r"\b(continue|continuing|proceed|proceeding|working\s+on)\b", re.IGNORECASE),
    re.compile(r"\b(TODO|FIXME|WIP|in\s+progress)\b", re.IGNORECASE),
    re.compile(r"\b(still\s+need|remaining|left\s+to\s+do|more\s+to\s+do)\b", re.IGNORECASE),
    re.compile(r"\b(step\s+\d+|phase\s+\d+|iteration\s+\d+)\b", re.IGNORECASE),
    re.compile(r"\b(haven'?t\s+(yet|finished)|not\s+yet\s+(done|complete|finished))\b", re.IGNORECASE),
]

# Keywords that indicate pending actions
PENDING_ACTION_PATTERNS = [
    re.compile(r"\b(need\s+to|should|must|have\s+to|requires?)\b", re.IGNORECASE),
    re.compile(r"\b(waiting|pending|queued)\b", re.IGNORECASE),
    re.compile(r"\b(before\s+I\s+can|after\s+that|once\s+that)\b", re.IGNORECASE),
    re.compile(r"\b(running|executing|processing)\b", re.IGNORECASE),
]

# Keywords that indicate errors or issues
ERROR_PATTERNS = [
    re.compile(r"\b(error|failed|failure|exception|issue|problem|bug)\b", re.IGNORECASE),
    re.compile(r"\b(can'?t|cannot|couldn'?t|unable\s+to)\b", re.IGNORECASE),
    re.compile(r"\b(fix|fixing|resolve|resolving|debug|debugging)\b", re.IGNORECASE),
]

# Keywords that indicate follow-up questions
FOLLOWUP_QUESTION_PATTERNS = [
    re.compile(r"\b(would\s+you\s+like|do\s+you\s+want|shall\s+I|should\s+I)\b", re.IGNORECASE),
    re.compile(r"\b(let\s+me\s+know|please\s+(confirm|tell|let))\b", re.IGNORECASE),
    re.compile(r"\?$", re.MULTILINE),
]

# Keywords that indicate future work
FUTURE_WORK_PATTERNS = [
    re.compile(r"\b(could\s+also|might\s+want\s+to|consider|recommend)\b", re.IGNORECASE),
    re.compile(r"\b(future|later|eventually|when\s+you\s+have\s+time)\b", re.IGNORECASE),
    re.compile(r"\b(improvement|enhancement|optimization)\b", re.IGNORECASE),
]

# Read-only tool names
READ_ONLY_TOOLS: Set[str] = {
    "read_file",
    "Read",
    "list_dir",
    "list_files",
    "search_text",
    "grep",
    "Grep",
    "glob",
    "Glob",
    "git_status",
    "git_log",
    "git_diff",
}

# Write/action tool names
WRITE_TOOLS: Set[str] = {
    "edit_file",
    "Edit",
    "bash",
    "Bash",
    "execute_command",
    "git_commit",
    "git_push",
    "NotebookEdit",
}


# ============================================================================
# Task Completion Detector
# ============================================================================

class TaskCompletionDetector:
    """
    Intelligent task completion detector.

    Uses multi-signal analysis to determine if a task is truly complete.
    """

    def __init__(self) -> None:
        self._tool_history: List[ToolActivity] = []
        self._response_history: List[str] = []
        self._last_tool_names: List[str] = []
        self._consecutive_no_tools = 0
        self._todo_stats = {"pending": 0, "completed": 0}

    def reset(self) -> None:
        """Reset the detector state for a new task."""
        self._tool_history = []
        self._response_history = []
        self._last_tool_names = []
        self._consecutive_no_tools = 0
        self._todo_stats = {"pending": 0, "completed": 0}

    def record_tool_call(self, tool_name: str, success: bool, has_output: bool) -> None:
        """Record a tool call."""
        self._tool_history.append(ToolActivity(
            tool_name=tool_name,
            timestamp=time.time(),
            success=success,
            has_output=has_output,
        ))
        self._last_tool_names.append(tool_name)

        # Keep only recent history
        if len(self._tool_history) > 100:
            self._tool_history = self._tool_history[-100:]
        if len(self._last_tool_names) > 20:
            self._last_tool_names = self._last_tool_names[-20:]

    def record_response(self, response: str, tools_used: List[str]) -> None:
        """Record a response (call after each AI response)."""
        self._response_history.append(response)

        if len(tools_used) == 0:
            self._consecutive_no_tools += 1
        else:
            self._consecutive_no_tools = 0
            self._last_tool_names = tools_used

        # Keep only recent history
        if len(self._response_history) > 20:
            self._response_history = self._response_history[-20:]

    def update_todo_stats(self, pending: int, completed: int) -> None:
        """Update todo statistics."""
        self._todo_stats = {"pending": pending, "completed": completed}

    def analyze_completion(self, current_response: str, tools_used_this_round: List[str]) -> CompletionAnalysis:
        """Analyze the current state and determine if the task is complete."""
        self.record_response(current_response, tools_used_this_round)

        signals = self._gather_signals(current_response, tools_used_this_round)
        confidence = self._calculate_confidence(signals)
        signals.completion_confidence = confidence

        # Determine completion status
        is_complete = False
        reason = ""
        should_verify = False
        verification_prompt: Optional[str] = None

        # High confidence completion
        if confidence >= 0.85 and signals.has_explicit_completion_statement and not signals.has_incomplete_work_indicators:
            is_complete = True
            reason = "High confidence explicit completion statement with no incomplete work indicators"

        # Medium confidence - needs verification
        elif confidence >= 0.6 and signals.has_explicit_completion_statement:
            should_verify = True
            reason = "Medium confidence completion - AI verification recommended"
            verification_prompt = self._generate_verification_prompt(signals)

        # Low confidence - likely not complete
        elif confidence < 0.4:
            is_complete = False
            reason = self._get_low_confidence_reason(signals)

        # Ambiguous case - check for stagnation
        elif self._consecutive_no_tools >= 3 and not signals.has_incomplete_work_indicators:
            should_verify = True
            reason = "No tool activity for multiple rounds - verification needed"
            verification_prompt = self._generate_stagnation_verification_prompt()

        # Default: not complete
        else:
            is_complete = False
            reason = "Active work indicators detected or low completion confidence"

        return CompletionAnalysis(
            is_complete=is_complete,
            confidence=confidence,
            signals=signals,
            reason=reason,
            should_verify=should_verify,
            verification_prompt=verification_prompt,
        )

    def _gather_signals(self, response: str, tools_used: List[str]) -> CompletionSignals:
        """Gather all completion signals from the current state."""
        has_explicit_completion_statement = any(p.search(response) for p in STRONG_COMPLETION_PATTERNS)
        has_incomplete_work_indicators = any(p.search(response) for p in INCOMPLETE_WORK_PATTERNS)
        has_pending_action_indicators = any(p.search(response) for p in PENDING_ACTION_PATTERNS)
        has_error_indicators = any(p.search(response) for p in ERROR_PATTERNS)
        has_follow_up_questions = any(p.search(response) for p in FOLLOWUP_QUESTION_PATTERNS)
        mentions_future_work = any(p.search(response) for p in FUTURE_WORK_PATTERNS)

        last_tool_was_read_only = len(tools_used) > 0 and all(t in READ_ONLY_TOOLS for t in tools_used)

        now = time.time()
        recent_tools = [t for t in self._tool_history if now - t.timestamp < 60]
        has_recent_file_writes = any(
            t.tool_name in ("edit_file", "Edit")
            for t in recent_tools
        )
        has_recent_commits = (
            any(t.tool_name in ("bash", "Bash") for t in recent_tools) and
            any("git commit" in r or "committed" in r for r in self._response_history)
        )

        return CompletionSignals(
            has_explicit_completion_statement=has_explicit_completion_statement,
            has_incomplete_work_indicators=has_incomplete_work_indicators,
            has_pending_action_indicators=has_pending_action_indicators,
            has_error_indicators=has_error_indicators,
            has_follow_up_questions=has_follow_up_questions,
            tools_used_in_last_response=len(tools_used),
            last_tool_was_read_only=last_tool_was_read_only,
            consecutive_responses_without_tools=self._consecutive_no_tools,
            has_recent_file_writes=has_recent_file_writes,
            has_recent_commits=has_recent_commits,
            todo_items_pending=self._todo_stats["pending"],
            todo_items_completed=self._todo_stats["completed"],
            mentions_future_work=mentions_future_work,
            completion_confidence=0.0,  # Will be calculated
        )

    def _calculate_confidence(self, signals: CompletionSignals) -> float:
        """Calculate confidence score for task completion."""
        score = 0.5  # Start at neutral

        # Strong positive signals
        if signals.has_explicit_completion_statement:
            score += 0.25
        if signals.has_recent_commits:
            score += 0.1
        if signals.todo_items_pending == 0 and signals.todo_items_completed > 0:
            score += 0.15

        # Strong negative signals
        if signals.has_incomplete_work_indicators:
            score -= 0.3
        if signals.has_pending_action_indicators:
            score -= 0.2
        if signals.has_error_indicators:
            score -= 0.25
        if signals.todo_items_pending > 0:
            score -= 0.15

        # Moderate signals
        if signals.tools_used_in_last_response > 0 and not signals.last_tool_was_read_only:
            score -= 0.1
        if signals.consecutive_responses_without_tools >= 2:
            score += 0.1
        if signals.has_follow_up_questions:
            score -= 0.1
        if signals.mentions_future_work and signals.has_explicit_completion_statement:
            score += 0.05

        # Clamp to 0-1 range
        return max(0.0, min(1.0, score))

    def _generate_verification_prompt(self, signals: CompletionSignals) -> str:
        """Generate a verification prompt to ask the AI if the task is truly complete."""
        concerns: List[str] = []

        if signals.todo_items_pending > 0:
            concerns.append(f"there are {signals.todo_items_pending} todo items still pending")
        if signals.has_follow_up_questions:
            concerns.append("you asked follow-up questions")
        if signals.mentions_future_work:
            concerns.append("you mentioned potential future improvements")

        concerns_text = f"However, {' and '.join(concerns)}. " if concerns else ""

        return f"""You indicated the task might be complete. {concerns_text}Please confirm:

1. Have ALL the originally requested changes been implemented?
2. Are there any remaining errors or issues that need to be fixed?
3. Is there anything else you need to do to fully complete this task?

If everything is truly done, respond with exactly: "TASK_FULLY_COMPLETE"
If there's more work to do, describe what remains."""

    def _generate_stagnation_verification_prompt(self) -> str:
        """Generate a verification prompt for stagnation cases."""
        return """I notice you haven't used any tools for several responses. Let me check:

1. Is the task complete? If so, summarize what was accomplished.
2. Are you blocked on something? If so, what do you need?
3. Is there more work to do? If so, please continue.

If everything is done, respond with exactly: "TASK_FULLY_COMPLETE"
Otherwise, please continue with the next action."""

    def _get_low_confidence_reason(self, signals: CompletionSignals) -> str:
        """Get a human-readable reason for low confidence."""
        reasons: List[str] = []

        if signals.has_incomplete_work_indicators:
            reasons.append("incomplete work indicators detected")
        if signals.has_pending_action_indicators:
            reasons.append("pending action indicators found")
        if signals.has_error_indicators:
            reasons.append("error indicators present")
        if signals.tools_used_in_last_response > 0 and not signals.last_tool_was_read_only:
            reasons.append("write operations performed")
        if signals.todo_items_pending > 0:
            reasons.append(f"{signals.todo_items_pending} todo items still pending")

        return ", ".join(reasons) if reasons else "no clear completion signals"

    def is_verification_confirmed(self, verification_response: str) -> bool:
        """Check if a verification response confirms completion."""
        if "TASK_FULLY_COMPLETE" in verification_response:
            return True
        pattern = re.compile(r"^(yes|confirmed?|all\s+done|everything\s+(is\s+)?complete)", re.IGNORECASE | re.MULTILINE)
        return bool(pattern.search(verification_response.strip()))


# ============================================================================
# Singleton Instance
# ============================================================================

_detector_instance: Optional[TaskCompletionDetector] = None


def get_task_completion_detector() -> TaskCompletionDetector:
    """Get the singleton task completion detector."""
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = TaskCompletionDetector()
    return _detector_instance


def reset_task_completion_detector() -> None:
    """Reset the task completion detector."""
    global _detector_instance
    if _detector_instance:
        _detector_instance.reset()


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "ToolActivity",
    "CompletionSignals",
    "CompletionAnalysis",
    "TaskCompletionDetector",
    "get_task_completion_detector",
    "reset_task_completion_detector",
    "READ_ONLY_TOOLS",
    "WRITE_TOOLS",
]
