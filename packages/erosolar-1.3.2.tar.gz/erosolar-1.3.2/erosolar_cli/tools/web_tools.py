"""
Web Tools for Erosolar CLI

Provides WebFetch, WebExtract, and WebSearch capabilities.
Supports multiple search providers: Tavily (recommended), Brave Search, and SerpAPI.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import html
import json
import re
import ssl
from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional, Protocol
from urllib.parse import urlparse

import aiohttp

from ..core.secret_store import get_secret_value
from ..core.tool_runtime import ToolDefinition
from ..core.types import JSONSchemaArray, JSONSchemaObject, JSONSchemaString


# ============================================================================
# Constants
# ============================================================================

MAX_FETCH_SIZE = 5 * 1024 * 1024  # 5MB


# ============================================================================
# Types
# ============================================================================

@dataclass
class WebSearchResult:
    """Web search result."""
    title: str
    url: str
    snippet: str
    source: Optional[str] = None
    published: Optional[str] = None
    score: Optional[float] = None


@dataclass
class SearchParams:
    """Search parameters."""
    query: str
    allowed_domains: List[str]
    blocked_domains: List[str]
    max_results: int = 6


class SearchProvider(Protocol):
    """Search provider protocol."""
    id: Literal["tavily", "brave", "serpapi"]
    label: str

    async def search(self, params: SearchParams) -> List[WebSearchResult]:
        """Perform search."""
        ...


# ============================================================================
# Search Providers
# ============================================================================

async def perform_tavily_search(params: SearchParams, api_key: str) -> List[WebSearchResult]:
    """Perform search using Tavily API."""
    body: Dict[str, Any] = {
        "api_key": api_key,
        "query": params.query,
        "search_depth": "advanced",
        "include_answer": True,
        "include_raw_content": False,
        "max_results": min(params.max_results * 2, 10),
    }
    if params.allowed_domains:
        body["include_domains"] = params.allowed_domains
    if params.blocked_domains:
        body["exclude_domains"] = params.blocked_domains

    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(
            "https://api.tavily.com/search",
            json=body,
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise RuntimeError(f"Tavily Search returned HTTP {response.status}: {error_text}")

            payload = await response.json()
            results = payload.get("results", [])

            mapped = []
            for entry in results:
                if not entry.get("url"):
                    continue
                mapped.append(WebSearchResult(
                    title=entry.get("title") or entry.get("url"),
                    url=entry["url"],
                    snippet=entry.get("content", ""),
                    source=safe_hostname(entry["url"]),
                    published=entry.get("published_date"),
                    score=entry.get("score"),
                ))

            return mapped[:params.max_results]


async def perform_brave_search(params: SearchParams, api_key: str) -> List[WebSearchResult]:
    """Perform search using Brave Search API."""
    from urllib.parse import quote_plus

    url = f"https://api.search.brave.com/res/v1/web/search?q={quote_plus(params.query)}&count={min(params.max_results * 2, 20)}"

    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(
            url,
            headers={
                "Accept": "application/json",
                "X-Subscription-Token": api_key,
            },
        ) as response:
            if response.status != 200:
                raise RuntimeError(f"Brave Search returned HTTP {response.status}")

            payload = await response.json()
            entries = payload.get("web", {}).get("results", [])

            mapped = []
            for entry in entries:
                if not entry.get("url"):
                    continue
                mapped.append(WebSearchResult(
                    title=entry.get("title") or entry.get("url"),
                    url=entry["url"],
                    snippet=entry.get("description") or entry.get("snippet", ""),
                    source=entry.get("profile", {}).get("name") or entry.get("source") or safe_hostname(entry["url"]),
                    published=entry.get("publishedDate") or entry.get("subtype"),
                ))

            filtered = apply_domain_filters(mapped, params.allowed_domains, params.blocked_domains)
            return filtered[:params.max_results]


async def perform_serpapi_search(params: SearchParams, api_key: str) -> List[WebSearchResult]:
    """Perform search using SerpAPI."""
    from urllib.parse import quote_plus

    url = (
        f"https://serpapi.com/search.json"
        f"?engine=google"
        f"&q={quote_plus(params.query)}"
        f"&num={min(params.max_results * 2, 10)}"
        f"&api_key={api_key}"
    )

    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url) as response:
            if response.status != 200:
                raise RuntimeError(f"SerpAPI returned HTTP {response.status}")

            payload = await response.json()
            entries = payload.get("organic_results", [])

            mapped = []
            for entry in entries:
                link = entry.get("link")
                if not link:
                    continue
                snippet_words = entry.get("snippet_highlighted_words", [])
                snippet = entry.get("snippet") or (" ".join(snippet_words) if snippet_words else "")
                mapped.append(WebSearchResult(
                    title=entry.get("title") or link,
                    url=link,
                    snippet=snippet,
                    source=entry.get("source") or entry.get("display_link") or entry.get("displayed_link") or safe_hostname(link),
                    published=entry.get("date") or entry.get("snippet_date"),
                ))

            filtered = apply_domain_filters(mapped, params.allowed_domains, params.blocked_domains)
            return filtered[:params.max_results]


# ============================================================================
# Helper Functions
# ============================================================================

def safe_hostname(raw: Optional[str]) -> Optional[str]:
    """Extract hostname from URL safely."""
    if not raw:
        return None
    try:
        parsed = urlparse(raw)
        return parsed.hostname.lower() if parsed.hostname else None
    except Exception:
        return None


def parse_domain_list(value: Any) -> List[str]:
    """Parse domain list from arguments."""
    if not isinstance(value, list):
        return []
    return [
        entry.strip().lower()
        for entry in value
        if isinstance(entry, str) and entry.strip()
    ]


def apply_domain_filters(
    results: List[WebSearchResult],
    allowed_domains: List[str],
    blocked_domains: List[str],
) -> List[WebSearchResult]:
    """Apply domain filtering to search results."""
    normalized_allowed = [d[1:] if d.startswith(".") else d for d in allowed_domains]
    normalized_blocked = [d[1:] if d.startswith(".") else d for d in blocked_domains]

    filtered = []
    for result in results:
        hostname = safe_hostname(result.url)
        if not hostname:
            continue

        if normalized_allowed:
            if not any(hostname == d or hostname.endswith(f".{d}") for d in normalized_allowed):
                continue

        if any(hostname == d or hostname.endswith(f".{d}") for d in normalized_blocked):
            continue

        filtered.append(result)

    return filtered


def format_search_results(
    query: str,
    results: List[WebSearchResult],
    provider_label: str,
    allowed: List[str],
    blocked: List[str],
) -> str:
    """Format search results for display."""
    lines = [f'Web Search Results for "{query}" ({provider_label})', ""]

    for i, result in enumerate(results):
        lines.append(f"{i + 1}. {result.title or result.url}")
        lines.append(result.url)
        if result.snippet:
            lines.append(f"   {result.snippet}")

        meta = []
        if result.source:
            meta.append(f"source: {result.source}")
        if result.published:
            meta.append(f"published: {result.published}")
        if meta:
            lines.append(f"   ({' · '.join(meta)})")
        lines.append("")

    lines.append(format_filter_summary(allowed, blocked, provider_label))
    return "\n".join(lines).strip()


def format_filter_summary(
    allowed: List[str],
    blocked: List[str],
    provider_label: Optional[str] = None,
) -> str:
    """Format filter summary."""
    segments = []
    if allowed:
        segments.append(f"allowed: {', '.join(allowed)}")
    if blocked:
        segments.append(f"blocked: {', '.join(blocked)}")
    if not segments:
        segments.append("none")
    if provider_label:
        segments.append(f"provider: {provider_label}")
    return f"Filters: {' | '.join(segments)}"


def resolve_search_provider(
) -> Optional[tuple[str, str, Any]]:
    """Resolve which search provider to use."""
    import os

    # Tavily is preferred
    tavily_key = get_secret_value("TAVILY_API_KEY") or os.environ.get("TAVILY_API_KEY", "").strip()
    if tavily_key:
        return ("tavily", "Tavily Search", tavily_key)

    brave_key = get_secret_value("BRAVE_SEARCH_API_KEY") or os.environ.get("BRAVE_SEARCH_API_KEY", "").strip()
    if brave_key:
        return ("brave", "Brave Search", brave_key)

    serp_key = get_secret_value("SERPAPI_API_KEY") or os.environ.get("SERPAPI_API_KEY", "").strip()
    if serp_key:
        return ("serpapi", "SerpAPI (Google)", serp_key)

    return None


async def fetch_url(url: str) -> str:
    """Fetch content from URL."""
    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(
            url,
            headers={"User-Agent": "Mozilla/5.0 (compatible; ErosolarBot/1.0)"},
            allow_redirects=True,
        ) as response:
            if response.status != 200:
                raise RuntimeError(f"HTTP {response.status}: {response.reason}")

            content = await response.read()
            content_length = len(content)
            if content_length > MAX_FETCH_SIZE:
                raise RuntimeError(
                    f"Response too large (>{MAX_FETCH_SIZE / 1024 / 1024:.0f}MB). "
                    "Content truncated for memory safety."
                )

            # Try to decode as text
            charset = response.charset or "utf-8"
            try:
                return content.decode(charset)
            except UnicodeDecodeError:
                return content.decode("utf-8", errors="replace")


def html_to_markdown(html_content: str) -> str:
    """Convert HTML to basic markdown."""
    text = html_content

    # Remove script and style tags
    text = re.sub(r"<script\b[^<]*(?:(?!</script>)<[^<]*)*</script>", "", text, flags=re.IGNORECASE)
    text = re.sub(r"<style\b[^<]*(?:(?!</style>)<[^<]*)*</style>", "", text, flags=re.IGNORECASE)

    # Convert common HTML tags
    text = re.sub(r"<h1[^>]*>(.*?)</h1>", r"# \1\n\n", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<h2[^>]*>(.*?)</h2>", r"## \1\n\n", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<h3[^>]*>(.*?)</h3>", r"### \1\n\n", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<p[^>]*>(.*?)</p>", r"\1\n\n", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<strong[^>]*>(.*?)</strong>", r"**\1**", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<b[^>]*>(.*?)</b>", r"**\1**", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<em[^>]*>(.*?)</em>", r"*\1*", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<i[^>]*>(.*?)</i>", r"*\1*", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<code[^>]*>(.*?)</code>", r"`\1`", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', r"[\2](\1)", text, flags=re.IGNORECASE | re.DOTALL)

    # Remove remaining HTML tags
    text = re.sub(r"<[^>]+>", "", text)

    # Decode HTML entities
    text = html.unescape(text)

    # Clean up excessive newlines
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


# ============================================================================
# Tool Definitions
# ============================================================================

def create_web_tools() -> List[ToolDefinition]:
    """Create web tools."""
    import os

    async def web_fetch_handler(args: Dict[str, Any]) -> str:
        url = args.get("url")
        prompt = args.get("prompt")

        if not url or not prompt:
            return "Error: url and prompt parameters are required."

        try:
            # Upgrade HTTP to HTTPS
            target_url = url.replace("http://", "https://") if url.startswith("http://") else url

            content = await fetch_url(target_url)
            markdown = html_to_markdown(content)

            truncated = markdown[:5000]
            suffix = "\n\n... (content truncated)" if len(markdown) > 5000 else ""

            return f"""Fetched content from {target_url}

Prompt: {prompt}

Content (first 5000 characters):
{truncated}{suffix}

Summary: This is the content fetched from the URL. In a full implementation, this would be processed by a small LLM to answer the specific prompt."""

        except Exception as error:
            return f"Error fetching URL: {error}"

    async def web_extract_handler(args: Dict[str, Any]) -> str:
        urls = args.get("urls")

        if not urls or not isinstance(urls, list) or len(urls) == 0:
            return "Error: urls parameter is required and must be a non-empty array."

        if len(urls) > 20:
            return "Error: Maximum 20 URLs allowed per request."

        tavily_key = get_secret_value("TAVILY_API_KEY") or os.environ.get("TAVILY_API_KEY", "").strip()
        if not tavily_key:
            return "\n".join([
                "WebExtract requires TAVILY_API_KEY to be set.",
                "Get your API key at: https://tavily.com",
                "Use /secrets to configure this value.",
                "",
                "Falling back to WebFetch for basic extraction is available as an alternative.",
            ])

        try:
            timeout = aiohttp.ClientTimeout(total=60)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    "https://api.tavily.com/extract",
                    json={
                        "api_key": tavily_key,
                        "urls": urls,
                    },
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise RuntimeError(f"Tavily Extract returned HTTP {response.status}: {error_text}")

                    payload = await response.json()
                    results = payload.get("results", [])
                    failed_urls = payload.get("failed_results", [])

                    if len(results) == 0 and len(failed_urls) == len(urls):
                        return f"Failed to extract content from all {len(urls)} URLs. This may be due to access restrictions or invalid URLs."

                    output = f"Extracted content from {len(results)}/{len(urls)} URLs:\n\n"

                    for result in results:
                        output += f"--- {result.get('url', 'Unknown')} ---\n"
                        raw_content = result.get("raw_content")
                        if raw_content:
                            content = raw_content[:10000] + "\n\n... (content truncated)" if len(raw_content) > 10000 else raw_content
                            output += f"{content}\n\n"
                        else:
                            output += "(No content extracted)\n\n"

                    if failed_urls:
                        output += f"\nFailed URLs ({len(failed_urls)}):\n"
                        for failed in failed_urls:
                            output += f"- {failed.get('url', 'Unknown')}: {failed.get('error', 'Unknown error')}\n"

                    return output.strip()

        except Exception as error:
            return f"Error extracting content: {error}"

    async def web_search_handler(args: Dict[str, Any]) -> str:
        query = args.get("query", "").strip() if isinstance(args.get("query"), str) else ""
        allowed = parse_domain_list(args.get("allowed_domains"))
        blocked = parse_domain_list(args.get("blocked_domains"))

        if not query:
            return "Error: query parameter is required."

        try:
            provider = resolve_search_provider()
            if not provider:
                return "\n".join([
                    "WebSearch requires TAVILY_API_KEY (recommended), BRAVE_SEARCH_API_KEY, or SERPAPI_API_KEY.",
                    "Run /secrets (or set the environment variables directly) to configure an API key.",
                    "",
                    "Get your Tavily API key at: https://tavily.com (recommended)",
                    "Get your Brave Search API key at: https://brave.com/search/api/",
                    "Get your SerpAPI key at: https://serpapi.com/",
                ])

            provider_id, provider_label, api_key = provider
            params = SearchParams(
                query=query,
                allowed_domains=allowed,
                blocked_domains=blocked,
                max_results=6,
            )

            if provider_id == "tavily":
                results = await perform_tavily_search(params, api_key)
            elif provider_id == "brave":
                results = await perform_brave_search(params, api_key)
            else:
                results = await perform_serpapi_search(params, api_key)

            if not results:
                return f'No web results found for "{query}" {format_filter_summary(allowed, blocked)}.'

            return format_search_results(query, results, provider_label, allowed, blocked)

        except Exception as error:
            return f"Error performing web search: {error}"

    return [
        ToolDefinition(
            name="WebFetch",
            description="""- Fetches content from a specified URL and processes it using an AI model
- Takes a URL and a prompt as input
- Fetches the URL content, converts HTML to markdown
- Processes the content with the prompt using a small, fast model
- Returns the model's response about the content
- Use this tool when you need to retrieve and analyze web content

Usage notes:
  - IMPORTANT: If TAVILY_API_KEY is set, use WebExtract instead for better content extraction
  - The URL must be a fully-formed valid URL
  - HTTP URLs will be automatically upgraded to HTTPS
  - The prompt should describe what information you want to extract from the page
  - This tool is read-only and does not modify any files
  - Results may be summarized if the content is very large
  - Includes a self-cleaning 15-minute cache for faster responses when repeatedly accessing the same URL
  - When a URL redirects to a different host, the tool will inform you and provide the redirect URL in a special format. You should then make a new WebFetch request with the redirect URL to fetch the content.""",
            parameters=JSONSchemaObject(
                properties={
                    "url": JSONSchemaString(description="The URL to fetch content from"),
                    "prompt": JSONSchemaString(description="The prompt to run on the fetched content"),
                },
                required=["url", "prompt"],
            ),
            handler=web_fetch_handler,
        ),
        ToolDefinition(
            name="WebExtract",
            description="""- Extracts clean, structured content from one or more URLs using Tavily Extract API
- Superior to WebFetch for content extraction when TAVILY_API_KEY is available
- Returns raw text content optimized for LLM consumption
- Supports batch extraction of up to 20 URLs in a single call

Usage notes:
  - Requires TAVILY_API_KEY environment variable
  - Best for extracting article content, documentation, blog posts
  - Returns clean text without HTML artifacts
  - More reliable than basic HTML parsing for complex pages
  - Use for deep content extraction when you need full page text""",
            parameters=JSONSchemaObject(
                properties={
                    "urls": JSONSchemaArray(
                        items=JSONSchemaString(description="URL to extract"),
                        description="Array of URLs to extract content from (max 20)",
                    ),
                },
                required=["urls"],
            ),
            handler=web_extract_handler,
        ),
        ToolDefinition(
            name="WebSearch",
            description="""- Allows Claude to search the web and use the results to inform responses
- Provides up-to-date information for current events and recent data
- Returns search result information formatted as search result blocks
- Use this tool for accessing information beyond Claude's knowledge cutoff
- Searches are performed automatically within a single API call

Usage notes:
  - Domain filtering is supported to include or block specific websites
  - Web search is only available in the US
  - Account for "Today's date" in <env>. For example, if <env> says "Today's date: 2025-07-01", and the user wants the latest docs, do not use 2024 in the search query. Use 2025.""",
            parameters=JSONSchemaObject(
                properties={
                    "query": JSONSchemaString(description="The search query to use"),
                    "allowed_domains": JSONSchemaArray(
                        items=JSONSchemaString(description="Domain to allow"),
                        description="Only include search results from these domains",
                    ),
                    "blocked_domains": JSONSchemaArray(
                        items=JSONSchemaString(description="Domain to block"),
                        description="Never include search results from these domains",
                    ),
                },
                required=["query"],
            ),
            handler=web_search_handler,
        ),
    ]


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "create_web_tools",
    "WebSearchResult",
    "SearchParams",
    "fetch_url",
    "html_to_markdown",
]
