"""
Build and Test Tools with AI-Powered Error Fixing

Provides run_build, run_tests, and related tools that can automatically
analyze errors and suggest fixes, following Claude Code's approach.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..core.tool_runtime import ToolDefinition
from ..core.types import (
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
)
from ..core.ai_error_fixer import (
    AIErrorFixer,
    ParsedError,
    ErrorType,
    analyze_and_fix_output,
)


def create_build_tools(working_dir: str) -> list[ToolDefinition]:
    """
    Create build and test tools with AI error fixing support.

    Args:
        working_dir: Working directory for command execution

    Returns:
        List of build/test tool definitions
    """
    working_path = Path(working_dir).resolve()
    error_fixer = AIErrorFixer(working_dir=str(working_path), auto_fix_enabled=True)

    async def run_build_handler(args: dict[str, Any]) -> str:
        """Run project build with AI error analysis."""
        try:
            # Detect project type and determine build command
            build_cmd = args.get("command")
            if not build_cmd:
                build_cmd = _detect_build_command(working_path)

            if not build_cmd:
                return "Error: Could not detect build system. Please specify a build command."

            timeout = args.get("timeout", 120000)  # 2 minutes default
            timeout_seconds = timeout / 1000.0

            start_time = time.time()

            # Execute build
            result, stdout, stderr = await _execute_command(
                build_cmd, working_path, timeout_seconds
            )

            elapsed_ms = (time.time() - start_time) * 1000
            output = _combine_output(stdout, stderr)

            # Check if build succeeded
            if result == 0:
                return _format_success_result(
                    "Build succeeded",
                    output,
                    elapsed_ms,
                )

            # Build failed - analyze errors and suggest fixes
            errors = error_fixer.analyze_output(output, build_cmd)

            # Format error analysis
            error_report = _format_error_report(errors, output, elapsed_ms)

            # Add AI suggestions
            if errors:
                suggestions = error_fixer.get_fix_suggestions(errors)
                error_report += f"\n\n{suggestions}"

            return error_report

        except asyncio.TimeoutError:
            return f"Error: Build timed out after {timeout}ms"
        except Exception as error:
            return f"Error running build: {error}"

    async def run_tests_handler(args: dict[str, Any]) -> str:
        """Run project tests with AI error analysis."""
        try:
            # Detect project type and determine test command
            test_cmd = args.get("command")
            if not test_cmd:
                test_cmd = _detect_test_command(working_path)

            if not test_cmd:
                return "Error: Could not detect test framework. Please specify a test command."

            timeout = args.get("timeout", 300000)  # 5 minutes default
            timeout_seconds = timeout / 1000.0

            start_time = time.time()

            # Execute tests
            result, stdout, stderr = await _execute_command(
                test_cmd, working_path, timeout_seconds
            )

            elapsed_ms = (time.time() - start_time) * 1000
            output = _combine_output(stdout, stderr)

            # Parse test results
            test_summary = _parse_test_output(output)

            # Check if tests passed
            if result == 0:
                return _format_test_success(test_summary, output, elapsed_ms)

            # Tests failed - analyze errors
            errors = error_fixer.analyze_output(output, test_cmd)

            # Format error analysis
            error_report = _format_test_failure(test_summary, errors, output, elapsed_ms)

            # Add AI suggestions
            if errors:
                suggestions = error_fixer.get_fix_suggestions(errors)
                error_report += f"\n\n{suggestions}"

            return error_report

        except asyncio.TimeoutError:
            return f"Error: Tests timed out after {timeout}ms"
        except Exception as error:
            return f"Error running tests: {error}"

    async def check_package_info_handler(args: dict[str, Any]) -> str:
        """Get package/project information."""
        try:
            detail_level = args.get("detail", "basic")

            info_parts = []

            # Check for package.json (Node.js)
            package_json = working_path / "package.json"
            if package_json.exists():
                try:
                    data = json.loads(package_json.read_text())
                    info_parts.append(f"Node.js Project: {data.get('name', 'unknown')}")
                    info_parts.append(f"  Version: {data.get('version', 'unknown')}")

                    if detail_level == "full":
                        if "scripts" in data:
                            info_parts.append("  Scripts:")
                            for name, cmd in data["scripts"].items():
                                info_parts.append(f"    {name}: {cmd}")
                        if "dependencies" in data:
                            info_parts.append(f"  Dependencies: {len(data['dependencies'])}")
                        if "devDependencies" in data:
                            info_parts.append(f"  Dev Dependencies: {len(data['devDependencies'])}")
                except Exception:
                    pass

            # Check for pyproject.toml (Python)
            pyproject = working_path / "pyproject.toml"
            if pyproject.exists():
                try:
                    content = pyproject.read_text()
                    # Basic parsing
                    if "name" in content:
                        import re
                        name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
                        version_match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                        if name_match:
                            info_parts.append(f"Python Project: {name_match.group(1)}")
                        if version_match:
                            info_parts.append(f"  Version: {version_match.group(1)}")
                except Exception:
                    pass

            # Check for Cargo.toml (Rust)
            cargo_toml = working_path / "Cargo.toml"
            if cargo_toml.exists():
                try:
                    content = cargo_toml.read_text()
                    import re
                    name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
                    version_match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                    if name_match:
                        info_parts.append(f"Rust Project: {name_match.group(1)}")
                    if version_match:
                        info_parts.append(f"  Version: {version_match.group(1)}")
                except Exception:
                    pass

            if not info_parts:
                return "Could not detect project type or no project manifest found."

            return "\n".join(info_parts)

        except Exception as error:
            return f"Error getting package info: {error}"

    return [
        ToolDefinition(
            name="run_build",
            description="Run the project build command with AI-powered error analysis. Automatically detects the build system (npm, make, cargo, etc.) and provides intelligent error fixes.",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "command": JSONSchemaString(type="string",
                        description="Build command to run (auto-detected if not specified)",
                    ),
                    "timeout": JSONSchemaNumber(type="number",
                        description="Timeout in milliseconds (default: 120000 = 2 minutes)",
                    ),
                },
                additional_properties=False,
            ),
            handler=run_build_handler,
        ),
        ToolDefinition(
            name="run_tests",
            description="Run project tests with AI-powered failure analysis. Automatically detects the test framework and provides intelligent suggestions for fixing failing tests.",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "command": JSONSchemaString(type="string",
                        description="Test command to run (auto-detected if not specified)",
                    ),
                    "timeout": JSONSchemaNumber(type="number",
                        description="Timeout in milliseconds (default: 300000 = 5 minutes)",
                    ),
                },
                additional_properties=False,
            ),
            handler=run_tests_handler,
        ),
        ToolDefinition(
            name="check_package_info",
            description="Get information about the project (name, version, scripts, dependencies).",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "detail": JSONSchemaString(type="string",
                        description="Detail level: 'basic' or 'full' (default: basic)",
                    ),
                },
                additional_properties=False,
            ),
            handler=check_package_info_handler,
        ),
    ]


# =============================================================================
# Helper Functions
# =============================================================================

def _detect_build_command(working_path: Path) -> Optional[str]:
    """Detect the appropriate build command for the project."""
    # Check for package.json (Node.js)
    package_json = working_path / "package.json"
    if package_json.exists():
        try:
            data = json.loads(package_json.read_text())
            scripts = data.get("scripts", {})

            # Priority order for build scripts
            for script in ["build", "compile", "tsc"]:
                if script in scripts:
                    return f"npm run {script}"

            # Check if typescript is configured
            if (working_path / "tsconfig.json").exists():
                return "npx tsc"

            return "npm run build"
        except Exception:
            return "npm run build"

    # Check for Makefile
    if (working_path / "Makefile").exists():
        return "make"

    # Check for Cargo.toml (Rust)
    if (working_path / "Cargo.toml").exists():
        return "cargo build"

    # Check for pyproject.toml (Python)
    if (working_path / "pyproject.toml").exists():
        return "python -m build"

    # Check for setup.py (Python legacy)
    if (working_path / "setup.py").exists():
        return "python setup.py build"

    return None


def _detect_test_command(working_path: Path) -> Optional[str]:
    """Detect the appropriate test command for the project."""
    # Check for package.json (Node.js)
    package_json = working_path / "package.json"
    if package_json.exists():
        try:
            data = json.loads(package_json.read_text())
            scripts = data.get("scripts", {})

            # Priority order for test scripts
            for script in ["test", "test:unit", "jest", "vitest", "mocha"]:
                if script in scripts:
                    return f"npm run {script}"

            return "npm test"
        except Exception:
            return "npm test"

    # Check for pytest (Python)
    if (working_path / "pytest.ini").exists() or (working_path / "pyproject.toml").exists():
        return "pytest"

    # Check for Cargo.toml (Rust)
    if (working_path / "Cargo.toml").exists():
        return "cargo test"

    return None


async def _execute_command(
    command: str,
    working_path: Path,
    timeout_seconds: float,
) -> Tuple[int, str, str]:
    """Execute a command and return (exit_code, stdout, stderr)."""
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"

    process = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(working_path),
        env=env,
    )

    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            process.communicate(),
            timeout=timeout_seconds,
        )

        stdout = stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else ""
        stderr = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""

        return process.returncode or 0, stdout, stderr

    except asyncio.TimeoutError:
        process.kill()
        await process.wait()
        raise


def _combine_output(stdout: str, stderr: str) -> str:
    """Combine stdout and stderr into a single output string."""
    parts = []
    if stdout.strip():
        parts.append(stdout.strip())
    if stderr.strip():
        parts.append(f"stderr:\n{stderr.strip()}")
    return "\n\n".join(parts) if parts else ""


def _format_success_result(message: str, output: str, elapsed_ms: float) -> str:
    """Format a success result."""
    lines = [
        f"✓ {message}",
        f"",
        f"[Performance] took {elapsed_ms:.2f}ms",
    ]

    if output:
        # Truncate long output
        if len(output) > 2000:
            output = output[:2000] + f"\n... [{len(output) - 2000} more characters]"
        lines.append("")
        lines.append(output)

    return "\n".join(lines)


def _format_error_report(
    errors: List[ParsedError],
    output: str,
    elapsed_ms: float,
) -> str:
    """Format an error report for build failures."""
    lines = [
        f"✗ Build failed",
        f"",
        f"[Performance] took {elapsed_ms:.2f}ms",
        f"",
        f"═══ ERRORS DETECTED ({len(errors)}) ═══",
    ]

    for i, error in enumerate(errors[:10], 1):  # Limit to first 10 errors
        lines.append(f"")
        lines.append(f"{i}. [{error.error_type.value}] {error.message[:200]}")

        if error.locations:
            loc = error.locations[0]
            lines.append(f"   Location: {loc.file_path}:{loc.line_number or '?'}")

    if len(errors) > 10:
        lines.append(f"")
        lines.append(f"... and {len(errors) - 10} more errors")

    return "\n".join(lines)


def _parse_test_output(output: str) -> Dict[str, Any]:
    """Parse test output to extract summary."""
    summary = {
        "passed": 0,
        "failed": 0,
        "skipped": 0,
        "total": 0,
    }

    import re

    # npm/jest style: "Tests: 5 passed, 2 failed"
    jest_match = re.search(r"Tests?:\s*(\d+)\s*passed", output, re.IGNORECASE)
    if jest_match:
        summary["passed"] = int(jest_match.group(1))

    jest_fail = re.search(r"Tests?:\s*(\d+)\s*failed", output, re.IGNORECASE)
    if jest_fail:
        summary["failed"] = int(jest_fail.group(1))

    # pytest style: "5 passed, 2 failed"
    pytest_match = re.search(r"(\d+)\s*passed", output, re.IGNORECASE)
    if pytest_match:
        summary["passed"] = int(pytest_match.group(1))

    pytest_fail = re.search(r"(\d+)\s*failed", output, re.IGNORECASE)
    if pytest_fail:
        summary["failed"] = int(pytest_fail.group(1))

    summary["total"] = summary["passed"] + summary["failed"] + summary["skipped"]

    return summary


def _format_test_success(
    summary: Dict[str, Any],
    output: str,
    elapsed_ms: float,
) -> str:
    """Format test success result."""
    lines = [
        f"✓ Tests passed",
        f"  {summary['passed']} passed",
    ]

    if summary.get("skipped"):
        lines.append(f"  {summary['skipped']} skipped")

    lines.append("")
    lines.append(f"[Performance] took {elapsed_ms:.2f}ms")

    return "\n".join(lines)


def _format_test_failure(
    summary: Dict[str, Any],
    errors: List[ParsedError],
    output: str,
    elapsed_ms: float,
) -> str:
    """Format test failure result."""
    lines = [
        f"✗ Tests failed",
        f"  {summary['passed']} passed, {summary['failed']} failed",
    ]

    if summary.get("skipped"):
        lines.append(f"  {summary['skipped']} skipped")

    lines.append("")
    lines.append(f"[Performance] took {elapsed_ms:.2f}ms")

    if errors:
        lines.append("")
        lines.append(f"═══ FAILURES DETECTED ({len(errors)}) ═══")

        for i, error in enumerate(errors[:5], 1):  # First 5 failures
            lines.append("")
            lines.append(f"{i}. {error.message[:200]}")
            if error.locations:
                loc = error.locations[0]
                lines.append(f"   Location: {loc.file_path}:{loc.line_number or '?'}")

    return "\n".join(lines)
