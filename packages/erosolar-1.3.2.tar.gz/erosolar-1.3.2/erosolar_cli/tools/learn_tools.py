"""
Learn Tools - Codebase exploration and learning tools for understanding codebases.

These tools enable deep codebase exploration without requiring external API calls
for the core analysis. The AI can use these tools to build a comprehensive
understanding of any codebase's architecture, patterns, and conventions.

Features:
- Codebase structure analysis
- Pattern detection and learning
- Architecture understanding
- File relationship mapping
- Topic-based exploration
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from ..core.tool_runtime import ToolDefinition
from ..core.types import JSONSchemaBoolean, JSONSchemaNumber, JSONSchemaObject, JSONSchemaString


# =====================================================
# Types and Dataclasses
# =====================================================


@dataclass
class LanguageBreakdown:
    language: str
    extension: str
    file_count: int
    percentage: float


@dataclass
class DirectoryNode:
    name: str
    path: str
    type: str  # 'file' or 'directory'
    children: list["DirectoryNode"] = field(default_factory=list)
    size: Optional[int] = None
    language: Optional[str] = None


@dataclass
class DetectedPattern:
    name: str
    type: str  # 'architectural', 'design', 'naming', 'structural'
    description: str
    evidence: list[str] = field(default_factory=list)
    confidence: str = "medium"  # 'high', 'medium', 'low'


@dataclass
class ComponentInfo:
    name: str
    type: str
    path: str
    responsibilities: list[str] = field(default_factory=list)


@dataclass
class ArchitectureInsights:
    type: str
    layers: list[str] = field(default_factory=list)
    components: list[ComponentInfo] = field(default_factory=list)
    data_flow: list[str] = field(default_factory=list)


@dataclass
class ConfigFileInfo:
    name: str
    path: str
    type: str
    purpose: str


@dataclass
class DependencyInfo:
    package_manager: Optional[str] = None
    dependencies: list[str] = field(default_factory=list)
    dev_dependencies: list[str] = field(default_factory=list)
    has_dependency_file: bool = False


@dataclass
class CodebaseAnalysis:
    root_dir: str
    total_files: int
    total_directories: int
    languages: list[LanguageBreakdown] = field(default_factory=list)
    structure: Optional[DirectoryNode] = None
    patterns: list[DetectedPattern] = field(default_factory=list)
    architecture: Optional[ArchitectureInsights] = None
    entry_points: list[str] = field(default_factory=list)
    config_files: list[ConfigFileInfo] = field(default_factory=list)
    dependencies: Optional[DependencyInfo] = None


@dataclass
class ImportInfo:
    source: str
    specifiers: list[str] = field(default_factory=list)
    is_relative: bool = False
    resolved_path: Optional[str] = None


@dataclass
class ExportInfo:
    name: str
    type: str  # 'default', 'named', 'type', 'interface', 'class', 'function'


@dataclass
class FunctionSummary:
    name: str
    line: int
    parameters: list[str] = field(default_factory=list)
    return_type: Optional[str] = None
    is_async: bool = False
    is_exported: bool = False
    complexity: int = 1
    purpose: Optional[str] = None


@dataclass
class ClassSummary:
    name: str
    line: int
    methods: list[str] = field(default_factory=list)
    properties: list[str] = field(default_factory=list)
    extends: Optional[str] = None
    implements: list[str] = field(default_factory=list)
    is_exported: bool = False


@dataclass
class FileRelationship:
    target_file: str
    type: str  # 'imports', 'imported-by', 'extends', 'implements', 'uses'
    symbols: list[str] = field(default_factory=list)


@dataclass
class ComplexityMetrics:
    cyclomatic_complexity: int
    cognitive_complexity: int
    maintainability_index: int
    lines_of_code: int
    lines_of_comments: int


@dataclass
class FileAnalysis:
    path: str
    language: str
    size: int
    line_count: int
    purpose: str
    imports: list[ImportInfo] = field(default_factory=list)
    exports: list[ExportInfo] = field(default_factory=list)
    functions: list[FunctionSummary] = field(default_factory=list)
    classes: list[ClassSummary] = field(default_factory=list)
    patterns: list[str] = field(default_factory=list)
    relationships: list[FileRelationship] = field(default_factory=list)
    complexity: Optional[ComplexityMetrics] = None


@dataclass
class RelevantFile:
    path: str
    relevance: int
    snippets: list[str] = field(default_factory=list)


@dataclass
class TopicPattern:
    name: str
    occurrences: int
    locations: list[str] = field(default_factory=list)


@dataclass
class CodeExample:
    file: str
    line: int
    code: str
    explanation: str


@dataclass
class TopicAnalysis:
    topic: str
    relevant_files: list[RelevantFile] = field(default_factory=list)
    patterns: list[TopicPattern] = field(default_factory=list)
    examples: list[CodeExample] = field(default_factory=list)
    summary: str = ""


# =====================================================
# Constants
# =====================================================

IGNORED_DIRS = {
    "node_modules",
    ".git",
    ".svn",
    ".hg",
    "dist",
    "build",
    "out",
    ".next",
    ".nuxt",
    ".output",
    "coverage",
    ".nyc_output",
    ".cache",
    ".turbo",
    ".vercel",
    ".netlify",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "venv",
    ".venv",
    "env",
    ".env",
    "target",
    "vendor",
    ".idea",
    ".vscode",
}

LANGUAGE_MAP = {
    ".ts": "TypeScript",
    ".tsx": "TypeScript React",
    ".js": "JavaScript",
    ".jsx": "JavaScript React",
    ".mjs": "JavaScript (ESM)",
    ".cjs": "JavaScript (CJS)",
    ".py": "Python",
    ".pyw": "Python",
    ".pyi": "Python Stub",
    ".rs": "Rust",
    ".go": "Go",
    ".java": "Java",
    ".kt": "Kotlin",
    ".kts": "Kotlin Script",
    ".scala": "Scala",
    ".rb": "Ruby",
    ".php": "PHP",
    ".cs": "C#",
    ".fs": "F#",
    ".cpp": "C++",
    ".cc": "C++",
    ".cxx": "C++",
    ".c": "C",
    ".h": "C/C++ Header",
    ".hpp": "C++ Header",
    ".swift": "Swift",
    ".m": "Objective-C",
    ".mm": "Objective-C++",
    ".vue": "Vue",
    ".svelte": "Svelte",
    ".elm": "Elm",
    ".ex": "Elixir",
    ".exs": "Elixir Script",
    ".erl": "Erlang",
    ".hs": "Haskell",
    ".ml": "OCaml",
    ".mli": "OCaml Interface",
    ".lua": "Lua",
    ".pl": "Perl",
    ".pm": "Perl Module",
    ".sh": "Shell",
    ".bash": "Bash",
    ".zsh": "Zsh",
    ".fish": "Fish",
    ".ps1": "PowerShell",
    ".sql": "SQL",
    ".json": "JSON",
    ".yaml": "YAML",
    ".yml": "YAML",
    ".toml": "TOML",
    ".xml": "XML",
    ".md": "Markdown",
    ".mdx": "MDX",
    ".html": "HTML",
    ".htm": "HTML",
    ".css": "CSS",
    ".scss": "SCSS",
    ".sass": "Sass",
    ".less": "Less",
    ".styl": "Stylus",
}

CONFIG_FILES = {
    "package.json": {"type": "npm", "purpose": "Node.js package configuration and dependencies"},
    "tsconfig.json": {"type": "typescript", "purpose": "TypeScript compiler configuration"},
    "pyproject.toml": {"type": "python", "purpose": "Python project configuration (PEP 517/518)"},
    "setup.py": {"type": "python", "purpose": "Python package setup (legacy)"},
    "requirements.txt": {"type": "python", "purpose": "Python dependencies"},
    "Cargo.toml": {"type": "rust", "purpose": "Rust package manifest"},
    "go.mod": {"type": "go", "purpose": "Go module definition"},
    "pom.xml": {"type": "maven", "purpose": "Maven project configuration"},
    "build.gradle": {"type": "gradle", "purpose": "Gradle build configuration"},
    "build.gradle.kts": {"type": "gradle", "purpose": "Gradle Kotlin build configuration"},
    "Gemfile": {"type": "ruby", "purpose": "Ruby dependencies (Bundler)"},
    "composer.json": {"type": "php", "purpose": "PHP Composer dependencies"},
    ".eslintrc.json": {"type": "linting", "purpose": "ESLint configuration"},
    ".eslintrc.js": {"type": "linting", "purpose": "ESLint configuration"},
    ".prettierrc": {"type": "formatting", "purpose": "Prettier configuration"},
    "prettier.config.js": {"type": "formatting", "purpose": "Prettier configuration"},
    ".gitignore": {"type": "git", "purpose": "Git ignore patterns"},
    ".dockerignore": {"type": "docker", "purpose": "Docker ignore patterns"},
    "Dockerfile": {"type": "docker", "purpose": "Docker image definition"},
    "docker-compose.yml": {"type": "docker", "purpose": "Docker Compose services"},
    "docker-compose.yaml": {"type": "docker", "purpose": "Docker Compose services"},
    "Makefile": {"type": "build", "purpose": "Make build automation"},
    ".env.example": {"type": "config", "purpose": "Environment variable template"},
    "jest.config.js": {"type": "testing", "purpose": "Jest test configuration"},
    "vitest.config.ts": {"type": "testing", "purpose": "Vitest test configuration"},
    "webpack.config.js": {"type": "bundler", "purpose": "Webpack bundler configuration"},
    "vite.config.ts": {"type": "bundler", "purpose": "Vite build tool configuration"},
    "rollup.config.js": {"type": "bundler", "purpose": "Rollup bundler configuration"},
    "next.config.js": {"type": "framework", "purpose": "Next.js configuration"},
    "nuxt.config.ts": {"type": "framework", "purpose": "Nuxt.js configuration"},
    "tailwind.config.js": {"type": "css", "purpose": "Tailwind CSS configuration"},
    ".gitlab-ci.yml": {"type": "ci", "purpose": "GitLab CI/CD configuration"},
    "Jenkinsfile": {"type": "ci", "purpose": "Jenkins pipeline definition"},
}

ARCHITECTURE_PATTERNS = [
    {
        "name": "MVC (Model-View-Controller)",
        "indicators": ["models", "views", "controllers", "routes"],
        "type": "architectural",
    },
    {
        "name": "Clean Architecture",
        "indicators": ["domain", "application", "infrastructure", "presentation", "entities", "use-cases", "usecases"],
        "type": "architectural",
    },
    {
        "name": "Hexagonal Architecture",
        "indicators": ["ports", "adapters", "domain", "application"],
        "type": "architectural",
    },
    {
        "name": "Feature-based Structure",
        "indicators": ["features", "modules"],
        "type": "structural",
    },
    {
        "name": "Component-based",
        "indicators": ["components", "shared", "common"],
        "type": "structural",
    },
    {
        "name": "Layered Architecture",
        "indicators": ["api", "services", "repositories", "data", "business"],
        "type": "architectural",
    },
    {
        "name": "Microservices",
        "indicators": ["services", "gateway", "docker-compose"],
        "type": "architectural",
    },
    {
        "name": "Monorepo",
        "indicators": ["packages", "apps", "libs", "workspace"],
        "type": "structural",
    },
    {
        "name": "Plugin Architecture",
        "indicators": ["plugins", "extensions", "addons"],
        "type": "architectural",
    },
    {
        "name": "Event-Driven",
        "indicators": ["events", "handlers", "listeners", "subscribers", "publishers"],
        "type": "architectural",
    },
]


# =====================================================
# Tool Creation
# =====================================================


def create_learn_tools(working_dir: str) -> list[ToolDefinition]:
    """
    Create learn tools for codebase exploration.

    Args:
        working_dir: Working directory for analysis

    Returns:
        List of learn tool definitions
    """
    return [
        _create_learn_codebase_tool(working_dir),
        _create_learn_file_tool(working_dir),
        _create_learn_topic_tool(working_dir),
        _create_learn_summary_tool(working_dir),
    ]


# =====================================================
# learn_codebase Tool
# =====================================================


def _create_learn_codebase_tool(working_dir: str) -> ToolDefinition:
    working_path = Path(working_dir).resolve()

    async def handler(args: dict[str, Any]) -> str:
        try:
            depth = args.get("depth", 5)
            if not isinstance(depth, int):
                depth = 5

            include_hidden = args.get("includeHidden", False) is True
            focus_path = args.get("focusPath")

            if focus_path:
                target_dir = _resolve_path(working_path, focus_path)
            else:
                target_dir = working_path

            if not target_dir.exists():
                return f"Error: Directory not found: {target_dir}"

            analysis = _analyze_codebase(target_dir, working_path, depth, include_hidden)
            return _format_codebase_analysis(analysis)

        except Exception as error:
            return f"Error analyzing codebase: {error}"

    return ToolDefinition(
        name="learn_codebase",
        description="""Analyze and learn the entire codebase structure, architecture, patterns, and conventions.
This tool provides a comprehensive overview of the project without requiring external API calls.
Use this to understand:
- Project structure and organization
- Primary programming languages used
- Architectural patterns detected
- Configuration and build setup
- Entry points and key files
- Dependencies and package management""",
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "depth": JSONSchemaNumber(type="number", description="Maximum directory depth to analyze (default: 5)"),
                "includeHidden": JSONSchemaBoolean(
                    type="boolean", description="Include hidden files/directories in analysis (default: false)"
                ),
                "focusPath": JSONSchemaString(
                    type="string", description="Focus analysis on a specific subdirectory"
                ),
            },
            additional_properties=False,
        ),
        handler=handler,
        cacheable=True,
    )


# =====================================================
# learn_file Tool
# =====================================================


def _create_learn_file_tool(working_dir: str) -> ToolDefinition:
    working_path = Path(working_dir).resolve()

    async def handler(args: dict[str, Any]) -> str:
        try:
            path = args.get("path")
            if not path or not isinstance(path, str):
                return "Error: path must be a non-empty string"

            file_path = _resolve_path(working_path, path)
            include_relationships = args.get("includeRelationships", True) is not False

            if not file_path.exists():
                return f"Error: File not found: {file_path}"

            if file_path.is_dir():
                return f"Error: Path is a directory, not a file: {file_path}"

            analysis = _analyze_file(file_path, working_path, include_relationships)
            return _format_file_analysis(analysis)

        except Exception as error:
            return f"Error analyzing file: {error}"

    return ToolDefinition(
        name="learn_file",
        description="""Deep-learn a specific file's purpose, structure, patterns, and relationships.
This tool provides detailed analysis of a single file including:
- File purpose and responsibilities
- Imports and dependencies
- Exports and public interface
- Functions and classes with their purposes
- Complexity metrics
- Relationships to other files""",
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "path": JSONSchemaString(type="string", description="Path to the file to analyze"),
                "includeRelationships": JSONSchemaBoolean(
                    type="boolean", description="Analyze relationships to other files (default: true)"
                ),
            },
            required=["path"],
            additional_properties=False,
        ),
        handler=handler,
        cacheable=True,
    )


# =====================================================
# learn_topic Tool
# =====================================================


def _create_learn_topic_tool(working_dir: str) -> ToolDefinition:
    working_path = Path(working_dir).resolve()

    async def handler(args: dict[str, Any]) -> str:
        try:
            topic = args.get("topic")
            if not topic or not isinstance(topic, str) or not topic.strip():
                return "Error: topic must be a non-empty string"

            max_files = args.get("maxFiles", 10)
            if not isinstance(max_files, int):
                max_files = 10

            max_examples = args.get("maxExamples", 5)
            if not isinstance(max_examples, int):
                max_examples = 5

            analysis = _analyze_topic(working_path, topic.strip(), max_files, max_examples)
            return _format_topic_analysis(analysis)

        except Exception as error:
            return f"Error analyzing topic: {error}"

    return ToolDefinition(
        name="learn_topic",
        description="""Learn about a specific topic, pattern, or concept within the codebase.
Use this to understand how specific patterns are implemented, such as:
- Authentication/authorization patterns
- Error handling conventions
- Data validation approaches
- API design patterns
- State management
- Testing patterns
- Any custom pattern or convention""",
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "topic": JSONSchemaString(
                    type="string",
                    description='The topic or pattern to learn about (e.g., "authentication", "error handling", "api routes")',
                ),
                "maxFiles": JSONSchemaNumber(
                    type="number", description="Maximum number of relevant files to analyze (default: 10)"
                ),
                "maxExamples": JSONSchemaNumber(
                    type="number", description="Maximum number of code examples to include (default: 5)"
                ),
            },
            required=["topic"],
            additional_properties=False,
        ),
        handler=handler,
        cacheable=True,
    )


# =====================================================
# learn_summary Tool
# =====================================================


def _create_learn_summary_tool(working_dir: str) -> ToolDefinition:
    working_path = Path(working_dir).resolve()

    async def handler(args: dict[str, Any]) -> str:
        try:
            format_type = args.get("format", "markdown")
            focus = args.get("focus")

            analysis = _analyze_codebase(working_path, working_path, 4, False)
            return _format_learning_summary(analysis, format_type, focus)

        except Exception as error:
            return f"Error generating learning summary: {error}"

    return ToolDefinition(
        name="learn_summary",
        description="""Generate a learning summary for the codebase suitable for onboarding.
This creates a comprehensive summary including:
- Quick start guide
- Key concepts and terminology
- Architecture overview
- Important files and their purposes
- Common patterns and conventions
- Development workflow suggestions""",
        parameters=JSONSchemaObject(
            type="object",
            properties={
                "format": JSONSchemaString(
                    type="string",
                    description='Output format: "markdown" (default) or "text"',
                    enum=["markdown", "text"],
                ),
                "focus": JSONSchemaString(
                    type="string", description='Focus area for the summary (e.g., "frontend", "backend", "api")'
                ),
            },
            additional_properties=False,
        ),
        handler=handler,
        cacheable=True,
    )


# =====================================================
# Analysis Functions
# =====================================================


def _resolve_path(working_dir: Path, path: str) -> Path:
    """Resolve a path relative to working directory."""
    path_str = path.strip()
    if os.path.isabs(path_str):
        return Path(path_str)
    return (working_dir / path_str).resolve()


def _analyze_codebase(
    target_dir: Path, working_dir: Path, max_depth: int, include_hidden: bool
) -> CodebaseAnalysis:
    """Analyze the codebase structure."""
    files: list[dict[str, Any]] = []
    directories: list[str] = []
    config_files: list[ConfigFileInfo] = []

    # Build directory tree
    structure = _build_directory_tree(
        target_dir, working_dir, 0, max_depth, include_hidden, files, directories, config_files
    )

    # Calculate language breakdown
    language_counts: dict[str, dict[str, Any]] = {}
    for file_info in files:
        lang = LANGUAGE_MAP.get(file_info["ext"], "Other")
        if lang not in language_counts:
            language_counts[lang] = {"ext": file_info["ext"], "count": 0}
        language_counts[lang]["count"] += 1

    total_files = len(files)
    languages = [
        LanguageBreakdown(
            language=lang,
            extension=data["ext"],
            file_count=data["count"],
            percentage=(data["count"] / total_files * 100) if total_files > 0 else 0,
        )
        for lang, data in sorted(language_counts.items(), key=lambda x: x[1]["count"], reverse=True)
    ]

    # Detect patterns
    dir_names = [Path(d).name.lower() for d in directories]
    file_paths = [f["path"] for f in files]
    patterns = _detect_patterns(dir_names, file_paths)

    # Build architecture insights
    architecture = _build_architecture_insights(patterns, dir_names, target_dir, working_dir)

    # Find entry points
    entry_points = _find_entry_points(file_paths, config_files)

    # Analyze dependencies
    dependencies = _analyze_dependencies(target_dir)

    try:
        rel_root = str(target_dir.relative_to(working_dir))
    except ValueError:
        rel_root = str(target_dir)

    return CodebaseAnalysis(
        root_dir=rel_root or ".",
        total_files=total_files,
        total_directories=len(directories),
        languages=languages,
        structure=structure,
        patterns=patterns,
        architecture=architecture,
        entry_points=entry_points,
        config_files=config_files,
        dependencies=dependencies,
    )


def _build_directory_tree(
    directory: Path,
    working_dir: Path,
    depth: int,
    max_depth: int,
    include_hidden: bool,
    files: list[dict[str, Any]],
    directories: list[str],
    config_files: list[ConfigFileInfo],
) -> DirectoryNode:
    """Build a directory tree structure."""
    name = directory.name or str(directory)
    try:
        rel_path = str(directory.relative_to(working_dir))
    except ValueError:
        rel_path = str(directory)

    node = DirectoryNode(name=name, path=rel_path or ".", type="directory", children=[])

    if depth >= max_depth:
        return node

    try:
        entries = sorted(directory.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))

        for entry in entries:
            # Skip hidden files/dirs if not requested
            if not include_hidden and entry.name.startswith("."):
                continue

            # Skip ignored directories
            if entry.name in IGNORED_DIRS:
                continue

            try:
                entry_rel_path = str(entry.relative_to(working_dir))
            except ValueError:
                entry_rel_path = str(entry)

            if entry.is_dir():
                directories.append(str(entry))
                child_node = _build_directory_tree(
                    entry, working_dir, depth + 1, max_depth, include_hidden, files, directories, config_files
                )
                node.children.append(child_node)
            elif entry.is_file():
                try:
                    stat = entry.stat()
                    ext = entry.suffix.lower()
                    language = LANGUAGE_MAP.get(ext)

                    files.append({"path": entry_rel_path, "ext": ext, "size": stat.st_size})

                    # Check if it's a config file
                    if entry.name in CONFIG_FILES:
                        config_info = CONFIG_FILES[entry.name]
                        config_files.append(
                            ConfigFileInfo(
                                name=entry.name,
                                path=entry_rel_path,
                                type=config_info["type"],
                                purpose=config_info["purpose"],
                            )
                        )

                    node.children.append(
                        DirectoryNode(
                            name=entry.name,
                            path=entry_rel_path,
                            type="file",
                            size=stat.st_size,
                            language=language,
                        )
                    )
                except (PermissionError, OSError):
                    pass

    except (PermissionError, OSError):
        pass

    return node


def _detect_patterns(dir_names: list[str], file_paths: list[str]) -> list[DetectedPattern]:
    """Detect architectural and structural patterns."""
    patterns: list[DetectedPattern] = []
    dir_name_set = set(dir_names)
    file_paths_lower = [p.lower() for p in file_paths]

    for pattern in ARCHITECTURE_PATTERNS:
        matches = [ind for ind in pattern["indicators"] if ind in dir_name_set]
        if len(matches) >= 2 or (len(matches) >= 1 and len(pattern["indicators"]) <= 2):
            confidence = "high" if len(matches) >= 3 else "medium" if len(matches) >= 2 else "low"
            patterns.append(
                DetectedPattern(
                    name=pattern["name"],
                    type=pattern["type"],
                    description=f'Detected {pattern["name"]} pattern based on directory structure',
                    evidence=[f'Found "{m}" directory' for m in matches],
                    confidence=confidence,
                )
            )

    # Detect naming conventions
    has_kebab = any(re.search(r"[a-z]+-[a-z]+", Path(p).name) for p in file_paths_lower)
    has_camel = any(re.search(r"[a-z]+[A-Z][a-z]+", Path(p).name) for p in file_paths)
    has_pascal = any(re.search(r"^[A-Z][a-z]+[A-Z]", Path(p).name) for p in file_paths)
    has_snake = any(re.search(r"[a-z]+_[a-z]+", Path(p).name) for p in file_paths_lower)

    naming_conventions = []
    if has_kebab:
        naming_conventions.append("kebab-case")
    if has_camel:
        naming_conventions.append("camelCase")
    if has_pascal:
        naming_conventions.append("PascalCase")
    if has_snake:
        naming_conventions.append("snake_case")

    if naming_conventions:
        patterns.append(
            DetectedPattern(
                name="File Naming Convention",
                type="naming",
                description=f'Uses {", ".join(naming_conventions)} naming convention(s)',
                evidence=[f"Detected {n} pattern in filenames" for n in naming_conventions],
                confidence="medium",
            )
        )

    # Detect test patterns
    has_test_dir = any(d in dir_name_set for d in ["test", "tests", "__tests__"])
    has_spec_files = any(".spec." in p or ".test." in p for p in file_paths_lower)
    if has_test_dir or has_spec_files:
        patterns.append(
            DetectedPattern(
                name="Testing Structure",
                type="structural",
                description="Uses dedicated test directory" if has_test_dir else "Uses co-located test files (.spec/.test)",
                evidence=["Found test/tests/__tests__ directory"]
                if has_test_dir
                else ["Found .spec or .test files alongside source"],
                confidence="high",
            )
        )

    return patterns


def _build_architecture_insights(
    patterns: list[DetectedPattern], dir_names: list[str], target_dir: Path, working_dir: Path
) -> ArchitectureInsights:
    """Build architecture insights from detected patterns."""
    arch_pattern = next((p for p in patterns if p.type == "architectural"), None)
    arch_type = arch_pattern.name if arch_pattern else "Custom/Unknown"

    layers = []
    layer_dirs = ["api", "routes", "controllers", "services", "models", "views", "components", "utils", "lib", "core"]
    for layer in layer_dirs:
        if layer in dir_names:
            layers.append(layer)

    components: list[ComponentInfo] = []
    try:
        for entry in target_dir.iterdir():
            if entry.is_dir() and entry.name not in IGNORED_DIRS and not entry.name.startswith("."):
                try:
                    rel_path = str(entry.relative_to(working_dir))
                except ValueError:
                    rel_path = str(entry)
                components.append(
                    ComponentInfo(
                        name=entry.name,
                        type=_infer_component_type(entry.name),
                        path=rel_path,
                        responsibilities=_infer_responsibilities(entry.name),
                    )
                )
    except (PermissionError, OSError):
        pass

    data_flow = _infer_data_flow(layers, arch_type)

    return ArchitectureInsights(type=arch_type, layers=layers, components=components, data_flow=data_flow)


def _infer_component_type(name: str) -> str:
    """Infer component type from directory name."""
    lower = name.lower()
    if lower in ["api", "routes", "controllers", "handlers"]:
        return "API Layer"
    if lower in ["services", "business", "domain"]:
        return "Business Logic"
    if lower in ["models", "entities", "schemas"]:
        return "Data Models"
    if lower in ["views", "pages", "screens"]:
        return "Presentation"
    if lower in ["components", "ui"]:
        return "UI Components"
    if lower in ["utils", "helpers", "lib", "common", "shared"]:
        return "Utilities"
    if lower in ["config", "configs", "settings"]:
        return "Configuration"
    if lower in ["test", "tests", "__tests__", "spec"]:
        return "Testing"
    if lower in ["types", "interfaces", "contracts"]:
        return "Type Definitions"
    if lower in ["middleware", "middlewares"]:
        return "Middleware"
    if lower in ["plugins", "extensions", "addons"]:
        return "Extensions"
    return "Module"


def _infer_responsibilities(name: str) -> list[str]:
    """Infer responsibilities from directory name."""
    lower = name.lower()
    if lower in ["api", "routes"]:
        return ["HTTP request handling", "Route definitions", "Request/response processing"]
    if lower == "controllers":
        return ["Request handling", "Input validation", "Response formatting"]
    if lower == "services":
        return ["Business logic", "Data orchestration", "External integrations"]
    if lower == "models":
        return ["Data structures", "Database schemas", "Data validation"]
    if lower in ["views", "pages"]:
        return ["UI rendering", "Page composition", "Layout management"]
    if lower == "components":
        return ["Reusable UI elements", "Component logic", "State management"]
    if lower in ["utils", "helpers"]:
        return ["Utility functions", "Common helpers", "Shared logic"]
    return ["Module functionality"]


def _infer_data_flow(layers: list[str], arch_type: str) -> list[str]:
    """Infer data flow from architecture type."""
    if "MVC" in arch_type:
        return ["Request → Controller → Model → View → Response"]
    if "Clean" in arch_type:
        return [
            "External → Controllers → Use Cases → Entities",
            "Entities → Use Cases → Presenters → External",
        ]
    if "Layered" in arch_type:
        return ["API → Services → Repositories → Database"]
    if layers:
        return [f'Request → {" → ".join(layers)} → Response']
    return ["Standard request/response flow"]


def _find_entry_points(file_paths: list[str], config_files: list[ConfigFileInfo]) -> list[str]:
    """Find potential entry points."""
    entry_points = []
    entry_patterns = [
        "index.ts",
        "index.js",
        "main.ts",
        "main.js",
        "app.ts",
        "app.js",
        "server.ts",
        "server.js",
        "cli.ts",
        "cli.js",
        "__main__.py",
        "main.py",
        "app.py",
        "manage.py",
        "main.go",
        "main.rs",
        "lib.rs",
    ]

    for pattern in entry_patterns:
        match = next(
            (
                p
                for p in file_paths
                if Path(p).name == pattern or p.endswith(f"/src/{pattern}") or p.endswith(f"/bin/{pattern}")
            ),
            None,
        )
        if match:
            entry_points.append(match)

    pkg_json = next((c for c in config_files if c.name == "package.json"), None)
    if pkg_json:
        entry_points.append(f'{pkg_json.path} (see "main" or "bin" fields)')

    return list(set(entry_points))


def _analyze_dependencies(directory: Path) -> DependencyInfo:
    """Analyze project dependencies."""
    result = DependencyInfo()

    # Check package.json
    pkg_path = directory / "package.json"
    if pkg_path.exists():
        try:
            with open(pkg_path) as f:
                pkg = json.load(f)
            result.package_manager = "npm"
            result.has_dependency_file = True
            result.dependencies = list(pkg.get("dependencies", {}).keys())[:20]
            result.dev_dependencies = list(pkg.get("devDependencies", {}).keys())[:20]
        except (json.JSONDecodeError, OSError):
            pass

    # Check pyproject.toml
    pyproject_path = directory / "pyproject.toml"
    if pyproject_path.exists():
        result.package_manager = result.package_manager or "pip"
        result.has_dependency_file = True
        try:
            with open(pyproject_path) as f:
                content = f.read()
            dep_match = re.search(r"dependencies\s*=\s*\[([\s\S]*?)\]", content)
            if dep_match:
                deps = re.findall(r'"([^"]+)"', dep_match.group(1))
                result.dependencies = [d.split("<")[0].split(">")[0].split("=")[0].split("!")[0].strip() for d in deps][
                    :20
                ]
        except OSError:
            pass

    # Check Cargo.toml
    if (directory / "Cargo.toml").exists():
        result.package_manager = "cargo"
        result.has_dependency_file = True

    # Check go.mod
    if (directory / "go.mod").exists():
        result.package_manager = "go modules"
        result.has_dependency_file = True

    return result


def _analyze_file(file_path: Path, working_dir: Path, include_relationships: bool) -> FileAnalysis:
    """Analyze a single file."""
    content = file_path.read_text(errors="ignore")
    lines = content.split("\n")
    ext = file_path.suffix.lower()
    language = LANGUAGE_MAP.get(ext, "Unknown")

    try:
        rel_path = str(file_path.relative_to(working_dir))
    except ValueError:
        rel_path = str(file_path)

    imports = _extract_imports(content, ext)
    exports = _extract_exports(content, ext)
    functions = _extract_functions(content, ext)
    classes = _extract_classes(content, ext)
    patterns = _detect_code_patterns(content, ext)
    complexity = _calculate_complexity(content)
    purpose = _infer_file_purpose(file_path.name, content, imports, exports, functions, classes)

    relationships: list[FileRelationship] = []
    if include_relationships:
        for imp in imports:
            if imp.is_relative:
                relationships.append(
                    FileRelationship(
                        target_file=imp.resolved_path or imp.source, type="imports", symbols=imp.specifiers
                    )
                )

    return FileAnalysis(
        path=rel_path,
        language=language,
        size=len(content),
        line_count=len(lines),
        purpose=purpose,
        imports=imports,
        exports=exports,
        functions=functions,
        classes=classes,
        patterns=patterns,
        relationships=relationships,
        complexity=complexity,
    )


def _extract_imports(content: str, ext: str) -> list[ImportInfo]:
    """Extract import statements from file content."""
    imports: list[ImportInfo] = []

    if ext in [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"]:
        # ES6 imports
        import_regex = re.compile(
            r'import\s+(?:(\*\s+as\s+\w+)|(\{[^}]+\})|(\w+)(?:\s*,\s*\{([^}]+)\})?)\s+from\s+[\'"]([^\'"]+)[\'"]'
        )
        for match in import_regex.finditer(content):
            source = match.group(5) or ""
            specifiers: list[str] = []

            if match.group(1):
                specifiers = [match.group(1).strip()]
            elif match.group(2):
                specifiers = [s.strip() for s in match.group(2).replace("{", "").replace("}", "").split(",") if s.strip()]
            elif match.group(3):
                specifiers = [match.group(3)]
                if match.group(4):
                    specifiers.extend([s.strip() for s in match.group(4).split(",") if s.strip()])

            imports.append(
                ImportInfo(source=source, specifiers=specifiers, is_relative=source.startswith(".") or source.startswith("/"))
            )

        # CommonJS requires
        require_regex = re.compile(r'(?:const|let|var)\s+(?:(\{[^}]+\})|(\w+))\s*=\s*require\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)')
        for match in require_regex.finditer(content):
            source = match.group(3) or ""
            specifiers = []

            if match.group(1):
                specifiers = [s.strip() for s in match.group(1).replace("{", "").replace("}", "").split(",") if s.strip()]
            elif match.group(2):
                specifiers = [match.group(2)]

            imports.append(
                ImportInfo(source=source, specifiers=specifiers, is_relative=source.startswith(".") or source.startswith("/"))
            )

    elif ext == ".py":
        # Python from imports
        from_import_regex = re.compile(r"from\s+([^\s]+)\s+import\s+(.+)")
        for match in from_import_regex.finditer(content):
            source = match.group(1) or ""
            specifiers = [s.strip().split(" as ")[0].strip() for s in (match.group(2) or "").split(",") if s.strip()]
            imports.append(ImportInfo(source=source, specifiers=specifiers, is_relative=source.startswith(".")))

        # Python direct imports
        import_regex = re.compile(r"^import\s+([^\s,]+(?:\s*,\s*[^\s,]+)*)", re.MULTILINE)
        for match in import_regex.finditer(content):
            modules = [s.strip().split(" as ")[0].strip() for s in (match.group(1) or "").split(",")]
            for mod in modules:
                if mod:
                    imports.append(ImportInfo(source=mod, specifiers=[mod], is_relative=mod.startswith(".")))

    return imports


def _extract_exports(content: str, ext: str) -> list[ExportInfo]:
    """Extract export statements from file content."""
    exports: list[ExportInfo] = []

    if ext in [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"]:
        # Export default
        default_match = re.search(r"export\s+default\s+(?:class|function)?\s*(\w+)?", content)
        if default_match:
            exports.append(ExportInfo(name=default_match.group(1) or "default", type="default"))

        # Named exports
        named_regex = re.compile(r"export\s+(?:const|let|var|function|class|interface|type|enum)\s+(\w+)")
        for match in named_regex.finditer(content):
            name = match.group(1) or ""
            line_content = content[: match.start()].split("\n")[-1] + content[match.start() : match.end()]

            exp_type = "named"
            if "interface" in line_content:
                exp_type = "interface"
            elif "type" in line_content:
                exp_type = "type"
            elif "class" in line_content:
                exp_type = "class"
            elif "function" in line_content:
                exp_type = "function"

            exports.append(ExportInfo(name=name, type=exp_type))

    elif ext == ".py":
        # Python __all__
        all_match = re.search(r"__all__\s*=\s*\[([\s\S]*?)\]", content)
        if all_match:
            names = re.findall(r"['\"]([^'\"]+)['\"]", all_match.group(1))
            for name in names:
                exports.append(ExportInfo(name=name, type="named"))

        # Public functions/classes
        def_regex = re.compile(r"^(?:def|class)\s+([a-zA-Z][a-zA-Z0-9_]*)", re.MULTILINE)
        for match in def_regex.finditer(content):
            name = match.group(1) or ""
            if not name.startswith("_"):
                line_content = content[: match.end()].split("\n")[-1]
                exports.append(ExportInfo(name=name, type="class" if line_content.startswith("class") else "function"))

    return exports


def _extract_functions(content: str, ext: str) -> list[FunctionSummary]:
    """Extract function definitions from file content."""
    functions: list[FunctionSummary] = []

    if ext in [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"]:
        # Regular functions
        func_regex = re.compile(r"(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)(?:\s*:\s*([^{]+))?\s*\{")
        for match in func_regex.finditer(content):
            name = match.group(1) or ""
            params = [p.strip().split(":")[0].strip() for p in (match.group(2) or "").split(",") if p.strip()]
            return_type = (match.group(3) or "").strip() or None
            line = content[: match.start()].count("\n") + 1
            is_async = "async" in content[max(0, match.start() - 20) : match.start()]
            is_exported = "export" in content[max(0, match.start() - 20) : match.start()]

            functions.append(
                FunctionSummary(
                    name=name,
                    line=line,
                    parameters=params,
                    return_type=return_type,
                    is_async=is_async,
                    is_exported=is_exported,
                    complexity=1,
                )
            )

        # Arrow functions
        arrow_regex = re.compile(
            r"(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\(?([^)=]*)\)?(?:\s*:\s*([^=]+))?\s*=>"
        )
        for match in arrow_regex.finditer(content):
            name = match.group(1) or ""
            params = [p.strip().split(":")[0].strip() for p in (match.group(2) or "").split(",") if p.strip()]
            return_type = (match.group(3) or "").strip() or None
            line = content[: match.start()].count("\n") + 1
            is_async = "async" in content[match.start() : match.start() + 50]
            is_exported = "export" in content[max(0, match.start() - 20) : match.start()]

            functions.append(
                FunctionSummary(
                    name=name,
                    line=line,
                    parameters=params,
                    return_type=return_type,
                    is_async=is_async,
                    is_exported=is_exported,
                    complexity=1,
                )
            )

    elif ext == ".py":
        def_regex = re.compile(r"(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)(?:\s*->\s*([^:]+))?\s*:")
        for match in def_regex.finditer(content):
            name = match.group(1) or ""
            params = [
                p.strip().split(":")[0].split("=")[0].strip()
                for p in (match.group(2) or "").split(",")
                if p.strip() and p.strip() not in ["self", "cls"]
            ]
            return_type = (match.group(3) or "").strip() or None
            line = content[: match.start()].count("\n") + 1
            is_async = "async" in content[max(0, match.start() - 10) : match.start()]

            functions.append(
                FunctionSummary(
                    name=name,
                    line=line,
                    parameters=params,
                    return_type=return_type,
                    is_async=is_async,
                    is_exported=not name.startswith("_"),
                    complexity=1,
                )
            )

    return functions


def _extract_classes(content: str, ext: str) -> list[ClassSummary]:
    """Extract class definitions from file content."""
    classes: list[ClassSummary] = []

    if ext in [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"]:
        class_regex = re.compile(
            r"(?:export\s+)?class\s+(\w+)(?:\s+extends\s+(\w+))?(?:\s+implements\s+([^{]+))?\s*\{"
        )
        for match in class_regex.finditer(content):
            name = match.group(1) or ""
            line = content[: match.start()].count("\n") + 1
            extends_class = match.group(2)
            implements_list = [s.strip() for s in (match.group(3) or "").split(",") if s.strip()] or None
            is_exported = "export" in content[max(0, match.start() - 20) : match.start()]

            classes.append(
                ClassSummary(
                    name=name,
                    line=line,
                    methods=[],
                    properties=[],
                    extends=extends_class,
                    implements=implements_list or [],
                    is_exported=is_exported,
                )
            )

    elif ext == ".py":
        class_regex = re.compile(r"class\s+(\w+)(?:\s*\(([^)]*)\))?\s*:")
        for match in class_regex.finditer(content):
            name = match.group(1) or ""
            line = content[: match.start()].count("\n") + 1
            parent_classes = [s.strip() for s in (match.group(2) or "").split(",") if s.strip()]

            classes.append(
                ClassSummary(
                    name=name,
                    line=line,
                    methods=[],
                    properties=[],
                    extends=parent_classes[0] if parent_classes else None,
                    implements=parent_classes[1:] if len(parent_classes) > 1 else [],
                    is_exported=not name.startswith("_"),
                )
            )

    return classes


def _detect_code_patterns(content: str, ext: str) -> list[str]:
    """Detect coding patterns in file content."""
    patterns: list[str] = []

    if re.search(r"async\s+function|async\s+\(|await\s+", content):
        patterns.append("Async/Await")
    if re.search(r"Promise\.all|Promise\.race|Promise\.allSettled", content):
        patterns.append("Promise Combinators")
    if re.search(r"try\s*\{[\s\S]*?\}\s*catch", content):
        patterns.append("Try-Catch Error Handling")
    if re.search(r"\.(map|filter|reduce)\s*\(", content):
        patterns.append("Functional Array Methods")
    if re.search(r"Object\.freeze|Object\.seal|readonly\s+", content):
        patterns.append("Immutability")
    if re.search(r"interface\s+\w+|type\s+\w+\s*=", content):
        patterns.append("TypeScript Types")
    if re.search(r"\bclass\s+\w+", content):
        patterns.append("Object-Oriented")
    if re.search(r"export\s+default|export\s+\{|module\.exports", content):
        patterns.append("Module Pattern")
    if re.search(r"\.test\(|\.spec\.|describe\s*\(|it\s*\(|expect\s*\(", content):
        patterns.append("Testing")
    if re.search(r"console\.(log|error|warn|debug)", content):
        patterns.append("Console Logging")
    if re.search(r"@decorator|@\w+\s*\(|@\w+\s*\n", content):
        patterns.append("Decorators")
    if re.search(r"useEffect|useState|useCallback|useMemo", content):
        patterns.append("React Hooks")
    if re.search(r"createSlice|createReducer|createAction", content):
        patterns.append("Redux Toolkit")

    return patterns


def _calculate_complexity(content: str) -> ComplexityMetrics:
    """Calculate complexity metrics for file content."""
    lines = content.split("\n")
    lines_of_code = len([l for l in lines if l.strip() and not l.strip().startswith("//")])
    lines_of_comments = len([l for l in lines if l.strip().startswith("//")])

    # Simple cyclomatic complexity estimation
    cyclomatic = 1
    control_flow_patterns = re.findall(r"\bif\b|\belse\b|\bfor\b|\bwhile\b|\bcase\b|\bcatch\b|\?\s*:", content)
    cyclomatic += len(control_flow_patterns)

    # Cognitive complexity (simplified)
    cognitive = cyclomatic
    nested_patterns = re.findall(r"\{\s*\{|\bif\b.*\bif\b", content)
    cognitive += len(nested_patterns) * 2

    # Maintainability index (simplified, 0-100 scale)
    import math

    maintainability = 171 - 5.2 * math.log(lines_of_code + 1) - 0.23 * cyclomatic - 16.2 * math.log(
        lines_of_code / (lines_of_comments + 1) + 1
    )
    maintainability = max(0, min(100, maintainability))

    return ComplexityMetrics(
        cyclomatic_complexity=cyclomatic,
        cognitive_complexity=cognitive,
        maintainability_index=round(maintainability),
        lines_of_code=lines_of_code,
        lines_of_comments=lines_of_comments,
    )


def _infer_file_purpose(
    filename: str,
    content: str,
    imports: list[ImportInfo],
    exports: list[ExportInfo],
    functions: list[FunctionSummary],
    classes: list[ClassSummary],
) -> str:
    """Infer the purpose of a file from its name and content."""
    lower = filename.lower()

    if "test" in lower or "spec" in lower:
        return "Test file for unit/integration testing"
    if lower in ["index.ts", "index.js"]:
        return "Module entry point and public API exports"
    if "config" in lower:
        return "Configuration settings and constants"
    if "type" in lower or "interface" in lower:
        return "Type definitions and interfaces"
    if "util" in lower or "helper" in lower:
        return "Utility functions and helpers"
    if "hook" in lower:
        return "Custom React hooks"
    if "context" in lower:
        return "React context provider"
    if "store" in lower or "reducer" in lower:
        return "State management"
    if "service" in lower:
        return "Business logic and service layer"
    if "api" in lower or "client" in lower:
        return "API client and HTTP requests"
    if "route" in lower:
        return "Route definitions and handlers"
    if "middleware" in lower:
        return "Middleware functions"
    if "model" in lower or "entity" in lower:
        return "Data models and entities"
    if "schema" in lower:
        return "Schema definitions and validation"
    if "component" in lower:
        return "UI component"

    if classes and not functions:
        return f'Class definitions: {", ".join(c.name for c in classes)}'
    if functions and not classes:
        exported_funcs = [f for f in functions if f.is_exported]
        if exported_funcs:
            names = ", ".join(f.name for f in exported_funcs[:3])
            suffix = "..." if len(exported_funcs) > 3 else ""
            return f"Function library: {names}{suffix}"
    if exports:
        names = ", ".join(e.name for e in exports[:3])
        suffix = "..." if len(exports) > 3 else ""
        return f"Module exporting: {names}{suffix}"

    return "General module"


def _analyze_topic(working_dir: Path, topic: str, max_files: int, max_examples: int) -> TopicAnalysis:
    """Analyze a specific topic across the codebase."""
    topic_lower = topic.lower()
    relevant_files: list[RelevantFile] = []
    patterns: dict[str, dict[str, Any]] = {}
    examples: list[CodeExample] = []

    keywords = _generate_topic_keywords(topic_lower)
    all_files = _collect_all_files(working_dir, 4)

    for file_path in all_files:
        try:
            content = file_path.read_text(errors="ignore")
            lines = content.split("\n")
            try:
                rel_path = str(file_path.relative_to(working_dir))
            except ValueError:
                rel_path = str(file_path)

            relevance = 0
            snippets: list[str] = []

            for keyword in keywords:
                regex = re.compile(keyword, re.IGNORECASE)
                matches = regex.findall(content)
                if matches:
                    relevance += len(matches)

                    for i, line in enumerate(lines):
                        if len(snippets) >= 3:
                            break
                        if keyword.lower() in line.lower():
                            snippet = "\n".join(lines[max(0, i - 1) : min(len(lines), i + 3)])
                            if snippet not in snippets:
                                snippets.append(snippet)

                                pattern_name = _identify_pattern(line, keyword)
                                if pattern_name:
                                    if pattern_name not in patterns:
                                        patterns[pattern_name] = {"count": 0, "locations": []}
                                    patterns[pattern_name]["count"] += 1
                                    if rel_path not in patterns[pattern_name]["locations"]:
                                        patterns[pattern_name]["locations"].append(rel_path)

                                if len(examples) < max_examples:
                                    examples.append(
                                        CodeExample(
                                            file=rel_path, line=i + 1, code=snippet, explanation=f"Example of {topic} usage"
                                        )
                                    )

            if relevance > 0:
                relevant_files.append(RelevantFile(path=rel_path, relevance=relevance, snippets=snippets))

        except (PermissionError, OSError):
            continue

    relevant_files.sort(key=lambda x: x.relevance, reverse=True)
    top_files = relevant_files[:max_files]

    topic_patterns = [
        TopicPattern(name=name, occurrences=data["count"], locations=data["locations"])
        for name, data in sorted(patterns.items(), key=lambda x: x[1]["count"], reverse=True)
    ]

    summary = _generate_topic_summary(topic, top_files, topic_patterns, examples)

    return TopicAnalysis(
        topic=topic,
        relevant_files=top_files,
        patterns=topic_patterns,
        examples=examples[:max_examples],
        summary=summary,
    )


def _generate_topic_keywords(topic: str) -> list[str]:
    """Generate search keywords for a topic."""
    keywords = [topic]

    related_keywords = {
        "auth": ["authentication", "authorize", "login", "logout", "session", "token", "jwt", "oauth", "passport"],
        "error": ["error", "exception", "catch", "throw", "try", "finally", "fail", "handle"],
        "api": ["api", "route", "endpoint", "handler", "request", "response", "http", "rest", "graphql"],
        "test": ["test", "spec", "describe", "it", "expect", "mock", "jest", "vitest", "pytest"],
        "database": ["database", "db", "sql", "query", "model", "schema", "migration", "orm", "prisma", "mongoose"],
        "validation": ["validate", "validation", "schema", "zod", "yup", "joi", "check", "verify"],
        "state": ["state", "store", "reducer", "action", "dispatch", "context", "redux", "zustand", "recoil"],
        "cache": ["cache", "memoize", "memo", "redis", "memcached", "ttl", "invalidate"],
        "logging": ["log", "logger", "logging", "debug", "trace", "info", "warn", "error", "console"],
        "config": ["config", "configuration", "settings", "env", "environment", "options"],
    }

    for key, related in related_keywords.items():
        if key in topic:
            keywords.extend(related)

    return list(set(keywords))


def _identify_pattern(line: str, keyword: str) -> Optional[str]:
    """Identify a coding pattern from a line of code."""
    lower = line.lower()

    if "try" in lower and "catch" in lower:
        return "Try-Catch Pattern"
    if "async" in lower and "await" in lower:
        return "Async/Await Pattern"
    if "export" in lower and "default" in lower:
        return "Default Export"
    if "import" in lower and "from" in lower:
        return "ES6 Import"
    if "class" in lower and "extends" in lower:
        return "Class Inheritance"
    if "interface" in lower or "type" in lower:
        return "Type Definition"
    if re.search(r"\.(map|filter|reduce)\s*\(", lower):
        return "Functional Methods"
    if "usestate" in lower or "useeffect" in lower:
        return "React Hooks"
    if "describe" in lower and "it" in lower:
        return "Test Structure"

    return None


def _generate_topic_summary(
    topic: str, files: list[RelevantFile], patterns: list[TopicPattern], examples: list[CodeExample]
) -> str:
    """Generate a summary for topic analysis."""
    parts = [f'Analysis of "{topic}" in this codebase:\n']

    if not files:
        parts.append(f'No files found directly related to "{topic}". Consider searching for related terms.')
    else:
        parts.append(f"Found {len(files)} relevant file(s).")

        if patterns:
            parts.append("\nDetected patterns:")
            for pattern in patterns[:5]:
                parts.append(f"- {pattern.name}: {pattern.occurrences} occurrence(s)")

        if examples:
            parts.append(f"\n{len(examples)} code example(s) available.")

        parts.append("\nMost relevant files:")
        for file in files[:5]:
            parts.append(f"- {file.path} (relevance: {file.relevance})")

    return "\n".join(parts)


def _collect_all_files(directory: Path, max_depth: int, depth: int = 0) -> list[Path]:
    """Collect all source files in directory."""
    files: list[Path] = []

    if depth >= max_depth:
        return files

    try:
        for entry in directory.iterdir():
            if entry.name.startswith(".") or entry.name in IGNORED_DIRS:
                continue

            if entry.is_dir():
                files.extend(_collect_all_files(entry, max_depth, depth + 1))
            elif entry.is_file():
                ext = entry.suffix.lower()
                if ext in LANGUAGE_MAP:
                    files.append(entry)
    except (PermissionError, OSError):
        pass

    return files


# =====================================================
# Formatting Functions
# =====================================================


def _format_codebase_analysis(analysis: CodebaseAnalysis) -> str:
    """Format codebase analysis as readable output."""
    output = [f"# Codebase Analysis: {analysis.root_dir}", ""]

    output.append("## Overview")
    output.append(f"- Total files: {analysis.total_files}")
    output.append(f"- Total directories: {analysis.total_directories}")
    output.append("")

    output.append("## Languages")
    for lang in analysis.languages[:10]:
        output.append(f"- {lang.language}: {lang.file_count} files ({lang.percentage:.1f}%)")
    output.append("")

    if analysis.architecture:
        output.append("## Architecture")
        output.append(f"- Type: {analysis.architecture.type}")
        if analysis.architecture.layers:
            output.append(f"- Layers: {', '.join(analysis.architecture.layers)}")
        if analysis.architecture.data_flow:
            output.append("- Data Flow:")
            for flow in analysis.architecture.data_flow:
                output.append(f"  - {flow}")
        output.append("")

    if analysis.patterns:
        output.append("## Detected Patterns")
        for pattern in analysis.patterns:
            output.append(f"- **{pattern.name}** ({pattern.confidence} confidence)")
            output.append(f"  {pattern.description}")
        output.append("")

    if analysis.architecture and analysis.architecture.components:
        output.append("## Key Components")
        for comp in analysis.architecture.components[:15]:
            output.append(f"- **{comp.name}** ({comp.type}): {comp.path}")
            if comp.responsibilities:
                output.append(f"  Responsibilities: {', '.join(comp.responsibilities)}")
        output.append("")

    if analysis.entry_points:
        output.append("## Entry Points")
        for entry in analysis.entry_points:
            output.append(f"- {entry}")
        output.append("")

    if analysis.config_files:
        output.append("## Configuration Files")
        for config in analysis.config_files[:10]:
            output.append(f"- **{config.name}** ({config.type}): {config.purpose}")
        output.append("")

    if analysis.dependencies and analysis.dependencies.has_dependency_file:
        output.append("## Dependencies")
        output.append(f"- Package Manager: {analysis.dependencies.package_manager or 'Unknown'}")
        if analysis.dependencies.dependencies:
            deps = ", ".join(analysis.dependencies.dependencies[:10])
            suffix = "..." if len(analysis.dependencies.dependencies) > 10 else ""
            output.append(f"- Dependencies: {deps}{suffix}")
        if analysis.dependencies.dev_dependencies:
            deps = ", ".join(analysis.dependencies.dev_dependencies[:10])
            suffix = "..." if len(analysis.dependencies.dev_dependencies) > 10 else ""
            output.append(f"- Dev Dependencies: {deps}{suffix}")
        output.append("")

    if analysis.structure:
        output.append("## Directory Structure")
        output.append(_format_directory_tree(analysis.structure, 0, 3))

    return "\n".join(output)


def _format_directory_tree(node: DirectoryNode, depth: int, max_depth: int) -> str:
    """Format directory tree as indented text."""
    indent = "  " * depth
    lines = []

    if node.type == "directory":
        lines.append(f"{indent}{node.name}/")
        if node.children and depth < max_depth:
            for child in node.children[:15]:
                lines.append(_format_directory_tree(child, depth + 1, max_depth))
            if len(node.children) > 15:
                lines.append(f"{indent}  ... ({len(node.children) - 15} more)")
    else:
        lang_suffix = f" [{node.language}]" if node.language else ""
        lines.append(f"{indent}{node.name}{lang_suffix}")

    return "\n".join(lines)


def _format_file_analysis(analysis: FileAnalysis) -> str:
    """Format file analysis as readable output."""
    output = [f"# File Analysis: {analysis.path}", ""]

    output.append("## Overview")
    output.append(f"- Language: {analysis.language}")
    output.append(f"- Lines: {analysis.line_count}")
    output.append(f"- Size: {analysis.size / 1024:.2f} KB")
    output.append(f"- Purpose: {analysis.purpose}")
    output.append("")

    if analysis.complexity:
        output.append("## Complexity Metrics")
        output.append(f"- Cyclomatic Complexity: {analysis.complexity.cyclomatic_complexity}")
        output.append(f"- Cognitive Complexity: {analysis.complexity.cognitive_complexity}")
        output.append(f"- Maintainability Index: {analysis.complexity.maintainability_index}/100")
        output.append(f"- Lines of Code: {analysis.complexity.lines_of_code}")
        output.append(f"- Lines of Comments: {analysis.complexity.lines_of_comments}")
        output.append("")

    if analysis.imports:
        output.append("## Imports")
        for imp in analysis.imports[:15]:
            type_str = "(relative)" if imp.is_relative else "(external)"
            output.append(f"- {imp.source} {type_str}")
            if imp.specifiers:
                output.append(f"  Imports: {', '.join(imp.specifiers)}")
        if len(analysis.imports) > 15:
            output.append(f"- ... and {len(analysis.imports) - 15} more imports")
        output.append("")

    if analysis.exports:
        output.append("## Exports")
        for exp in analysis.exports:
            output.append(f"- {exp.name} ({exp.type})")
        output.append("")

    if analysis.functions:
        output.append("## Functions")
        for func in analysis.functions[:20]:
            async_str = "async " if func.is_async else ""
            export_str = "export " if func.is_exported else ""
            params = ", ".join(func.parameters)
            ret = f": {func.return_type}" if func.return_type else ""
            output.append(f"- Line {func.line}: {export_str}{async_str}{func.name}({params}){ret}")
        if len(analysis.functions) > 20:
            output.append(f"- ... and {len(analysis.functions) - 20} more functions")
        output.append("")

    if analysis.classes:
        output.append("## Classes")
        for cls in analysis.classes:
            export_str = "export " if cls.is_exported else ""
            ext = f" extends {cls.extends}" if cls.extends else ""
            impl = f" implements {', '.join(cls.implements)}" if cls.implements else ""
            output.append(f"- Line {cls.line}: {export_str}class {cls.name}{ext}{impl}")
            if cls.methods:
                output.append(f"  Methods: {', '.join(cls.methods)}")
            if cls.properties:
                output.append(f"  Properties: {', '.join(cls.properties)}")
        output.append("")

    if analysis.patterns:
        output.append("## Detected Patterns")
        output.append(", ".join(analysis.patterns))
        output.append("")

    if analysis.relationships:
        output.append("## File Relationships")
        for rel in analysis.relationships:
            output.append(f"- {rel.type}: {rel.target_file}")
            if rel.symbols:
                output.append(f"  Symbols: {', '.join(rel.symbols)}")
        output.append("")

    return "\n".join(output)


def _format_topic_analysis(analysis: TopicAnalysis) -> str:
    """Format topic analysis as readable output."""
    output = [f'# Topic Analysis: "{analysis.topic}"', "", analysis.summary, ""]

    if analysis.patterns:
        output.append("## Patterns Found")
        for pattern in analysis.patterns:
            output.append(f"### {pattern.name}")
            output.append(f"- Occurrences: {pattern.occurrences}")
            locs = ", ".join(pattern.locations[:5])
            suffix = "..." if len(pattern.locations) > 5 else ""
            output.append(f"- Found in: {locs}{suffix}")
            output.append("")

    if analysis.relevant_files:
        output.append("## Relevant Files")
        for file in analysis.relevant_files:
            output.append(f"### {file.path}")
            output.append(f"Relevance Score: {file.relevance}")
            if file.snippets:
                output.append("")
                output.append("Relevant snippets:")
                for snippet in file.snippets[:2]:
                    output.append("```")
                    output.append(snippet)
                    output.append("```")
            output.append("")

    if analysis.examples:
        output.append("## Code Examples")
        for example in analysis.examples:
            output.append(f"### {example.file}:{example.line}")
            output.append(example.explanation)
            output.append("```")
            output.append(example.code)
            output.append("```")
            output.append("")

    return "\n".join(output)


def _format_learning_summary(analysis: CodebaseAnalysis, format_type: str, focus: Optional[str]) -> str:
    """Format learning summary for onboarding."""
    output = []
    is_markdown = format_type == "markdown"

    def h1(text: str) -> str:
        return f"# {text}" if is_markdown else text.upper()

    def h2(text: str) -> str:
        return f"## {text}" if is_markdown else f"\n{text}"

    bullet = "-" if is_markdown else "*"

    output.append(h1("Codebase Learning Summary"))
    output.append("")

    output.append(h2("Quick Start"))
    output.append("")
    if analysis.languages:
        main_lang = analysis.languages[0]
        output.append(f"This is primarily a **{main_lang.language}** project.")
    if analysis.dependencies and analysis.dependencies.package_manager:
        output.append(f"Package manager: **{analysis.dependencies.package_manager}**")
    if analysis.entry_points:
        output.append(f"Main entry point: `{analysis.entry_points[0]}`")
    output.append("")

    if analysis.architecture:
        output.append(h2("Architecture Overview"))
        output.append("")
        output.append(f"Architecture Type: **{analysis.architecture.type}**")
        if analysis.architecture.layers:
            output.append(f"Layers: {' → '.join(analysis.architecture.layers)}")
        for flow in analysis.architecture.data_flow:
            output.append(f"{bullet} {flow}")
        output.append("")

    output.append(h2("Key Concepts"))
    output.append("")
    for pattern in analysis.patterns[:5]:
        output.append(f"{bullet} **{pattern.name}**: {pattern.description}")
    output.append("")

    output.append(h2("Important Files"))
    output.append("")
    for config in analysis.config_files[:5]:
        output.append(f"{bullet} `{config.path}`: {config.purpose}")
    if analysis.entry_points:
        output.append("")
        output.append("Entry points:")
        for entry in analysis.entry_points:
            output.append(f"{bullet} `{entry}`")
    output.append("")

    if analysis.architecture and analysis.architecture.components:
        output.append(h2("Directory Guide"))
        output.append("")
        for comp in analysis.architecture.components[:10]:
            output.append(f"{bullet} **{comp.name}/** ({comp.type})")
            if comp.responsibilities:
                output.append(f"  {', '.join(comp.responsibilities[:2])}")
        output.append("")

    if analysis.patterns:
        high_confidence = [p for p in analysis.patterns if p.confidence == "high"]
        if high_confidence:
            output.append(h2("Common Patterns"))
            output.append("")
            for pattern in high_confidence[:5]:
                output.append(f"{bullet} **{pattern.name}**")
                for evidence in pattern.evidence[:2]:
                    output.append(f"  {bullet} {evidence}")
            output.append("")

    output.append(h2("Development Workflow"))
    output.append("")
    has_test = any(c.type == "testing" for c in analysis.config_files)
    has_lint = any(c.type == "linting" for c in analysis.config_files)
    has_bundler = any(c.type == "bundler" for c in analysis.config_files)

    if analysis.dependencies and analysis.dependencies.package_manager == "npm":
        output.append("```bash")
        output.append("# Install dependencies")
        output.append("npm install")
        output.append("")
        if has_bundler:
            output.append("# Build project")
            output.append("npm run build")
            output.append("")
        if has_test:
            output.append("# Run tests")
            output.append("npm test")
            output.append("")
        if has_lint:
            output.append("# Lint code")
            output.append("npm run lint")
        output.append("```")
    elif analysis.dependencies and analysis.dependencies.package_manager == "pip":
        output.append("```bash")
        output.append("# Install dependencies")
        output.append("pip install -e .")
        output.append("")
        if has_test:
            output.append("# Run tests")
            output.append("pytest")
        output.append("```")
    output.append("")

    output.append(h2("Suggested Next Steps"))
    output.append("")
    output.append(f"1. Read the entry point: `{analysis.entry_points[0] if analysis.entry_points else 'index file'}`")
    if any(c.name == "package.json" for c in analysis.config_files):
        output.append("2. Review `package.json` for available scripts")
    output.append("3. Explore the main directories to understand the structure")
    if has_test:
        output.append("4. Run the test suite to verify setup")
    output.append("5. Use `learn_topic` to explore specific features")

    return "\n".join(output)
