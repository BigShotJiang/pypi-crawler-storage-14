"""
Edit tools for surgical file modifications using exact string replacement.

Features:
- Exact string matching (preserves indentation)
- Replace all occurrences or enforce uniqueness
- Unified diff preview
- Validation before writing
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from ..core.tool_runtime import ToolDefinition
from ..core.types import (
    JSONSchemaArray,
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
)
from .diff_utils import build_diff_segments, format_diff_lines


def create_edit_tools(working_dir: str) -> list[ToolDefinition]:
    """
    Create edit tool for surgical file modifications.

    Args:
        working_dir: Working directory for resolving relative paths

    Returns:
        List containing the Edit tool definition
    """
    working_path = Path(working_dir).resolve()

    async def edit_handler(args: dict[str, Any]) -> str:
        try:
            # Extract and validate arguments
            path_arg = args.get("file_path", "")
            old_string = args.get("old_string")
            new_string = args.get("new_string")
            replace_all = args.get("replace_all", False)

            # Validate inputs
            if not path_arg or not isinstance(path_arg, str) or not path_arg.strip():
                return "Error: file_path must be a non-empty string."

            if not isinstance(old_string, str):
                return "Error: old_string must be a string."

            if not isinstance(new_string, str):
                return "Error: new_string must be a string."

            if old_string == new_string:
                return "Error: old_string and new_string must be different."

            # Validate multi-line strings - provide helpful guidance
            if '\n' in old_string:
                # Multi-line is OK, but we should help the AI understand
                line_count = old_string.count('\n') + 1
                if line_count > 50:
                    return (
                        f"Error: old_string spans {line_count} lines which is too many. "
                        f"For large edits, break it into smaller chunks or use multiple Edit calls."
                    )

            # Resolve file path
            file_path = _resolve_path(working_path, path_arg)

            # Check file exists
            if not file_path.exists():
                return f"Error: File not found: {file_path}"

            if not file_path.is_file():
                return f"Error: Path is not a file: {file_path}"

            # Read current content
            current_content = file_path.read_text(encoding="utf-8")

            # Check if old_string exists in file
            if old_string not in current_content:
                # Provide helpful debugging info
                search_preview = repr(old_string[:100]) if len(old_string) > 100 else repr(old_string)

                # Try to find a close match
                suggestions = []
                old_lines = old_string.split('\n')
                first_line = old_lines[0].strip() if old_lines else ""

                if first_line and first_line in current_content:
                    suggestions.append(
                        f"The first line '{first_line[:50]}...' exists - check whitespace/indentation matches exactly"
                    )

                # Check if it's a whitespace issue
                old_stripped = old_string.strip()
                if old_stripped != old_string and old_stripped in current_content:
                    suggestions.append(
                        "Found match after stripping whitespace - ensure leading/trailing whitespace matches exactly"
                    )

                # Check for common issues
                if '\t' in old_string and '    ' in current_content:
                    suggestions.append("File uses spaces but old_string contains tabs")
                elif '    ' in old_string and '\t' in current_content:
                    suggestions.append("File uses tabs but old_string contains spaces")

                suggestion_text = ""
                if suggestions:
                    suggestion_text = "\n\nPossible issues:\n" + "\n".join(f"  - {s}" for s in suggestions)

                return (
                    f"Error: old_string not found in file. The exact text must match including all whitespace and indentation.\n\n"
                    f"File: {file_path}\n"
                    f"Searching for: {search_preview}"
                    f"{suggestion_text}\n\n"
                    f"Tip: Use read_file first to see the exact content, then copy the text precisely."
                )

            # Count occurrences
            occurrences = _count_occurrences(current_content, old_string)

            if not replace_all and occurrences > 1:
                return (
                    f"Error: old_string appears {occurrences} times in the file. Either:\n"
                    f"1. Provide a larger unique string that includes more context\n"
                    f"2. Set replace_all: true to replace all {occurrences} occurrences\n\n"
                    f"File: {file_path}"
                )

            # Perform replacement
            if replace_all:
                new_content = current_content.replace(old_string, new_string)
            else:
                # Replace only first occurrence
                new_content = current_content.replace(old_string, new_string, 1)

            # Generate diff
            diff_segments = build_diff_segments(current_content, new_content)

            # Write file
            file_path.write_text(new_content, encoding="utf-8")

            # Build summary
            try:
                display_path = file_path.relative_to(working_path)
            except ValueError:
                display_path = file_path

            added_lines = sum(1 for seg in diff_segments if seg.type == "added")
            removed_lines = sum(1 for seg in diff_segments if seg.type == "removed")
            occurrences_text = f" ({occurrences} occurrence{'s' if occurrences > 1 else ''})" if replace_all else ""

            # Format diff
            diff_lines = format_diff_lines(diff_segments)
            if diff_lines:
                diff_block = "```diff\n" + "\n".join(diff_lines) + "\n```"
            else:
                diff_block = "(No visual diff - whitespace or formatting changes only)"

            return "\n".join(
                [
                    f"✓ Edited {display_path}{occurrences_text}",
                    f"Lines changed: +{added_lines} / -{removed_lines}",
                    "",
                    "Diff preview:",
                    diff_block,
                ]
            )

        except Exception as error:
            return f"Error editing file: {error}"

    return [
        ToolDefinition(
            name="Edit",
            description="Performs exact string replacements in files. Use for surgical edits when you know the exact text to replace. The edit will FAIL if old_string is not unique unless replace_all is true.",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "file_path": JSONSchemaString(type="string",
                        description="The absolute path to the file to modify",
                    ),
                    "old_string": JSONSchemaString(type="string",
                        description="The exact text to replace (must match precisely including indentation and whitespace)",
                    ),
                    "new_string": JSONSchemaString(type="string",
                        description="The text to replace it with (must be different from old_string)",
                    ),
                    "replace_all": JSONSchemaBoolean(type="boolean",
                        description="Replace all occurrences of old_string (default false). When false, the edit fails if old_string appears multiple times.",
                    ),
                },
                required=["file_path", "old_string", "new_string"],
                additional_properties=False,
            ),
            handler=edit_handler,
        )
    ]


def _resolve_path(working_dir: Path, path: str) -> Path:
    """Resolve a path relative to working directory."""
    path_str = path.strip()
    if os.path.isabs(path_str):
        return Path(path_str)
    return (working_dir / path_str).resolve()


def _count_occurrences(text: str, search: str) -> int:
    """Count number of non-overlapping occurrences of search string in text."""
    if not search:
        return 0

    count = 0
    position = 0

    while True:
        position = text.find(search, position)
        if position == -1:
            break
        count += 1
        position += len(search)

    return count
